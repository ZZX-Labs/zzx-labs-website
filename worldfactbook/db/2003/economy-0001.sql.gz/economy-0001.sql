SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28bd90b293369787ef42b55efe1709492b82c5a5120ba9579c994f028b3718b5',2003,'ZW','Zimbabwe','economy',4,'GDP
GDP - real growth rate
GDP - per capita
Inflation rate (consumer prices)
Labor force
Unemployment rate
Industrial production growth rate
Electricity - production
Electricity - consumption
Oil - production
Oil - consumption
Oil - exports
Oil - imports
Oil - proved reserves
Natural Gas - proved reserves
Exports
Imports
Debt - external
This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview
This entry briefly describes the type of economy, including the degree
of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It
also characterizes major economic events and policy changes in the most
recent 12 months and may include a statement about one or two key
future macroeconomic trends.
Electricity - consumption
This entry consists of total electricity generated annually plus
imports and minus exports, expressed in kilowatt-hours. The discrepancy
between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in
transmission and distribution.
Electricity - exports
This entry is the total exported electricity in kilowatt-hours.
Electricity - imports
This entry is the total imported electricity in kilowatt-hours.
Electricity - production
This entry is the annual electricity generated expressed in kilowatt-
hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted
for as loss in transmission and distribution.
Electricity - production by source
This entry states the percentage share of electricity generated from
each energy source. These are fossil fuel, hydro, nuclear, and other
(solar, geothermal, and wind).
Elevation extremes
This entry includes both the highest point and the lowest point.
Entities
Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. "Independent state" refers to a people politically
organized into a sovereign state with a definite territory.
"Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an
independent state. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 268 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
192 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic Lands,
Glorioso Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte,
New Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island,
The UK annexed Southern Rhodesia from the South Africa
Company in 1923. A 1961 constitution was formulated that favored
whites in power. In 1965 the government unilaterally declared its
independence, but the UK did not recognize the act and demanded more
complete voting rights for the black African majority in the country
(then called Rhodesia). UN sanctions and a guerrilla uprising
finally led to free elections in 1979 and independence (as Zimbabwe)
in 1980. Robert MUGABE, the nation''s first prime minister, has been
the country''s only ruler (as president since 1987) and has dominated
the country''s political system since independence. His chaotic land
redistribution campaign begun in 2000 caused an exodus of white
farmers, crippled the economy, and ushered in widespread shortages
of basic commodities. Ignoring international condemnation, MUGABE
rigged the 2002 presidential election to ensure his reelection.
Opposition and labor groups launched general strikes in 2003 to
pressure MUGABE to retire early; security forces continued their
brutal repression of regime opponents.
This page was last updated on 18 December, 2003
======================================================================
@2030 Airports - with paved runways
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2002)
This page was last updated on 18 December, 2003
======================================================================
@2031 Airports - with unpaved runways
total: 413
1,524 to 2,437 m: 4
914 to 1,523 m: 197
under 914 m: 212 (2002)
This page was last updated on 18 December, 2003
======================================================================
@2032 Environment - current issues
deforestation; soil erosion; land degradation; air and
water pollution; the black rhinoceros herd - once the largest
concentration of the species in the world - has been significantly
reduced by poaching; poor mining practices have led to toxic waste
and heavy metal pollution
This page was last updated on 18 December, 2003
======================================================================
@2033 Environment - international agreements
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
This page was last updated on 18 December, 2003
======================================================================
@2034 Military expenditures - percent of GDP (%)
3.2% (FY02)
This page was last updated on 18 December, 2003
======================================================================
@2038 Electricity - production (kWh)
6.735 billion kWh (2001)
This page was last updated on 18 December, 2003
======================================================================
@2042 Electricity - consumption (kWh)
9.813 billion kWh (2001)
This page was last updated on 18 December, 2003
======================================================================
@2043 Electricity - imports (kWh)
3.55 billion kWh (2001)
This page was last updated on 18 December, 2003
======================================================================
@2044 Electricity - exports (kWh)
0 kWh (2001)
This page was last updated on 18 December, 2003
======================================================================
@2045 Electricity - production by source (%)
fossil fuel: 47%
hydro: 53%
nuclear: 0%
other: 0% (2001)
This page was last updated on 18 December, 2003
======================================================================
@2046 Population below poverty line (%)
70% (2002 est.)
This page was last updated on 18 December, 2003
======================================================================
@2047 Household income or consumption by percentage share (%)
lowest 10%: 1.97%
highest 10%: 40.42% (1995)
This page was last updated on 18 December, 2003
======================================================================
@2048 Labor force - by occupation (%)
agriculture 66%, services 24%, industry 10% (1996)
This page was last updated on 18 December, 2003
======================================================================
@2049 Exports - commodities
tobacco, gold, ferroalloys, textiles/clothing
This page was last updated on 18 December, 2003
======================================================================
@2050 Exports - partners (%)
China 6%, South Africa 5.7%, Germany 5.4%, UK 4.8%, Japan
4.7%, Netherlands 4.4%, US 4.1% (2002)
This page was last updated on 18 December, 2003
======================================================================
@2051 Administrative divisions
8 provinces and 2 cities* with provincial status;
Bulawayo*, Harare*, Manicaland, Mashonaland Central, Mashonaland
East, Mashonaland West, Masvingo, Matabeleland North, Matabeleland
South, Midlands
This page was last updated on 18 December, 2003
======================================================================
@2052 Agriculture - products
corn, cotton, tobacco, wheat, coffee, sugarcane, peanuts;
cattle, sheep, goats, pigs
This page was last updated on 18 December, 2003
======================================================================
@2053 Airports
430 (2002)
This page was last updated on 18 December, 2003
======================================================================
@2054 Birth rate (births/1,000 population)
30.34 births/1,000 population (2003 est.)
This page was last updated on 18 December, 2003
======================================================================
@2055 Military branches
Zimbabwe National Army, Air Force of Zimbabwe, Zimbabwe
Republic Police (includes Police Support Unit, Paramilitary Police)
This page was last updated on 18 December, 2003
======================================================================
@2056 Budget
revenues: $2.5 billion
expenditures: $2.6 billion, including capital expenditures of $NA
(2000)
This page was last updated on 18 December, 2003
======================================================================
@2057 Capital
The government of Zimbabwe faces a wide variety of
difficult economic problems as it struggles with an unsustainable
fiscal deficit, an overvalued exchange rate, soaring inflation, and
bare shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the country''s failure to meet budgetary goals.
Inflation rose from an annual rate of 32% in 1998 to 59% in 1999, to
60% in 2000, to over 100% by yearend 2001, to 228% in early 2003.
The government''s land reform program, characterized by chaos and
violence, has nearly destroyed the commercial farming sector, the
traditional source of exports and foreign exchange and the provider
of 400,000 jobs.
This page was last updated on 18 December, 2003
======================================================================
@2117 Pipelines (km)
refined products 261 km (2003)
This page was last updated on 18 December, 2003
======================================================================
@2118 Political parties and leaders','42f103f92436e39c96d7bd061c7def796ea4f0e03472539af860da55139f67c2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55d4daec976af4bb97101a1b2bc065d436d42a9377420d03fb6f1765a551e48a',2003,'WF','Wallis and Futuna','economy',12,'2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
15 UK - Anguilla, Bermuda, British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey,
Jersey, Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South
Georgia and the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Northern Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands,
Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West
Bank, Western Sahara
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific
Ocean, Southern Ocean
1 World
268 total
Environment - current issues
This entry lists the most pressing and important environmental
problems. The following terms and abbreviations are used throughout the
entry:
acidification - the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwater fish
and plants dependent on more neutral or alkaline conditions (see acid
rain).
acid rain - characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially deadly
to the earth''s fragile ecosystems; acidity is measured using the pH
scale where 7 is neutral, values greater than 7 are considered
alkaline, and values below 5.6 are considered acid precipitation; note
- a pH of 2.4 (the acidity of vinegar) has been measured in rainfall in
New England.
aerosol - a collection of airborne particles dispersed in a gas,
smoke, or fog.
afforestation - converting a bare or agricultural space by
planting trees and plants; reforestation involves replanting trees on
areas that have been cut or destroyed by fire.
asbestos - a naturally occurring soft fibrous mineral commonly
used in fireproofing materials and considered to be highly carcinogenic
in particulate form.
biodiversity - also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces an
ecosystem''s ability to recover from natural or man-induced disruption.
bio-indicators - a plant or animal species whose presence,
abundance, and health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given
area or volume.
carbon cycle - the term used to describe the exchange of carbon
(in various forms, e.g., as carbon dioxide) between the atmosphere,
ocean, terrestrial biosphere, and geological deposits.
catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited
freshwater resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless
insecticide that has toxic effects on most animals; the use of DDT was
banned in the US in 1972.
defoliants - chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g.,
unsustainable forestry practices, agricultural and range land clearing,
and the over exploitation of wood products for use as fuel) without
planting new growth.
desertification - the spread of desert-like conditions in arid or
semi-arid areas, due to overgrazing, loss of agriculturally productive
soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g.,
shellfish) or harvesting coral, often causing significant destruction
of reef and ocean-floor ecosystems.
drift-net fishing - done with a net, miles in extent, that is
generally anchored to a boat and left to float with the tide; often
results in an over harvesting and waste of large populations of non-
commercial marine species (by-catch) by its effect of "sweeping the
ocean clean".
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial
waste, which are released into the environment, subsequently polluting
it.
endangered species - a species that is threatened with extinction
either by direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources
include lakes, streams, rivers, glaciers, and underground aquifers.
greenhouse gas - a gas that "traps" infrared radiation in the
lower atmosphere causing surface warming; water vapor, carbon dioxide,
nitrous oxide, methane, hydrofluorocarbons, and ozone are the primary
greenhouse gases in the Earth''s atmosphere.
groundwater - water sources found below the surface of the earth
often in naturally occurring reservoirs in permeable rock strata; the
source for wells and natural springs.
Highlands Water Project - a series of dams constructed jointly by
Lesotho and South Africa to redirect Lesotho''s abundant water supply
into a rapidly growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the most costly
and controversial; objections to the project include claims that it
forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 125,000 Inuits
of Russia, Alaska, Canada, and Greenland in international environmental
issues; a panel convenes every three years to determine the focus of
the ICC; the most current concerns are long-range transport of
pollutants, sustainable development, and climate change.
metallurgical plants - industries which specialize in the science,
technology, and processing of metals; these plants produce highly
concentrated and toxic wastes which can contribute to pollution of
ground water and air when not properly disposed.
noxious substances - injurious, very harmful to living beings.
overgrazing - the grazing of animals on plant material faster than
it can naturally regrow leading to the permanent loss of plant cover, a
common effect of too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas
(O3) that resides approximately 25 miles above the Earth''s surface and
absorbs solar ultraviolet radiation that can be harmful to living
organisms.
poaching - the illegal killing of animals or fish, a great concern
with respect to endangered or threatened species.
pollution - the contamination of a healthy environment by man-made
waste.
potable water - water that is drinkable, safe to be consumed.
salination - the process through which fresh (drinkable) water
becomes salt (undrinkable) water; hence, desalination is the reverse
process; also involves the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that can
eventually render soil incapable of supporting crops.
siltation - occurs when water channels and reservoirs become
clotted with silt and mud, a side effect of deforestation and soil
erosion.
slash-and-burn agriculture - a rotating cultivation technique in
which trees are cut down and burned in order to clear land for
temporary agriculture; the land is used until its productivity declines
at which point a new plot is selected and the process repeats; this
practice is sustainable while population levels are low and time is
permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences
for the environment .
soil degradation - damage to the land''s productive capacity
because of poor agricultural practices such as the excessive use of
pesticides or fertilizers, soil compaction from heavy equipment, or
erosion of topsoil, eventually resulting in reduced ability to produce
agricultural products.
soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic
energy emitted by the sun and naturally filtered in the upper
atmosphere by the ozone layer; UV radiation can be harmful to living
organisms and has been linked to increasing rates of skin cancer in
humans.
water-born diseases - those in which the bacteria survive in, and
is transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements
This entry separates country participation in international
environmental agreements into two levels - party to and signed but not
ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements
This information is presented in Appendix C: Selected International
Environmental Agreements, which includes the name, abbreviation, date
opened for signature, date entered into force, objective, and parties
by category.
Ethnic groups
This entry provides a rank ordering of ethnic groups starting with the
largest and normally includes the percent of total population.
Exchange rates
This entry provides the official value of a country''s monetary unit at
a given date or over a given period of time, as expressed in units of
local currency per US dollar and as determined by international market
forces or official fiat.
Executive branch
This entry includes several subfields. Chief of state includes the name
and title of the titular leader of the country who represents the state
at official and ceremonial functions but may not be involved with the
day-to-day activities of the government. Head of government includes
the name and title of the top administrative leader who is designated
to manage the day-to-day activities of the government. For example, in
the UK, the monarch is the chief of state, and the prime minister is
the head of government. In the US, the president is both the chief of
state and the head of government. Cabinet includes the official name
for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in the
last election.
Exports
This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities
This entry provides a rank ordering of exported products starting with
the most important; it sometimes includes the percent of total dollar
value.
Exports - partners
This entry provides a rank ordering of trading partners starting with
the most important; it sometimes includes the percent of total dollar
value.
Fiscal year
This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but
which may begin in any month. All yearly references are for the
calendar year (CY) unless indicated as a noncalendar fiscal year (FY).
Flag description
This entry provides a written flag description produced from actual
flags or the best information available at the time the entry was
written. The flags of independent states are used by their dependencies
unless there is an officially recognized local flag. Some disputed and
other areas do not have flags.
Flag graphic
Most versions of the Factbook include a color flag at the beginning of
the country profile. The flag graphics were produced from actual flags
or the best information available at the time of preparation. The flags
of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not
have flags.
GDP
This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. GDP dollar
estimates in the Factbook are derived from purchasing power parity
(PPP) calculations. See the note on GDP methodology for more
information.
GDP methodology
In the Economy section, GDP dollar estimates for all countries are
derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method
involves the use of standardized international dollar price weights,
which are applied to the quantities of final goods and services
produced in a given economy. The data derived from the PPP method
provide the best available starting point for comparisons of economic
strength and well-being between countries. The division of a GDP
estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. Most of the GDP estimates are based on
extrapolation of PPP numbers published by the UN International
Comparison Program (UNICP) and by Professors Robert Summers and Alan
Heston of the University of Pennsylvania and their colleagues. In
contrast, the currency exchange rate method involves a variety of
international and domestic financial forces that often have little
relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Furthermore, exchange rates
may suddenly go up or down by 10% or more because of market forces or
official fiat whereas real output has remained unchanged. On 12 January
1994, for example, the 14 countries of the African Financial Community
(whose currencies are tied to the French franc) devalued their
currencies by 50%. This move, of course, did not cut the real output of
these countries by half. One important caution: the proportion of, say,
defense expenditures as a percentage of GDP in local currency accounts
may differ substantially from the proportion when GDP accounts are
expressed in PPP terms, as, for example, when an observer tries to
estimate the dollar level of Russian or Japanese military expenditures.
Note: the numbers for GDP and other economic data can not be chained
together from successive volumes of the Factbook because of changes in
the US dollar measuring rod, revisions of data by statistical agencies,
use of new or different sources of information, and changes in national
statistical methods and practices.
GDP - composition by sector
This entry gives the percentage contribution of agriculture, industry,
and services to total GDP.
GDP - per capita
This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
GDP - real growth rate
This entry gives GDP growth on an annual basis adjusted for inflation
and expressed as a percent.
Geographic coordinates
This entry includes rounded latitude and longitude figures for the
purpose of finding the approximate geographic center of an entity and
is based on the Gazetteer of Conventional Names, Third Edition, August
1988, US Board on Geographic Names and on other sources.
Geographic names
This information is presented in Appendix F: Cross-Reference List of
Geographic Names. It includes a listing of various alternate names,
former names, local names, and regional names referenced to one or more
related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Although discovered by the Dutch and the British
in the 17th and 18th centuries, it was the French who declared a
protectorate over the islands in 1842. In 1959, the inhabitants of
the islands voted to become a French overseas territory.
West Bank
The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements (the DOP), signed in Washington on 13
September 1993, provided for a transitional period not exceeding
five years of Palestinian interim self-government in the Gaza Strip
and the West Bank. Under the DOP, Israel agreed to transfer certain
powers and responsibilities to the Palestinian Authority, which
includes the Palestinian Legislative Council elected in January
1996, as part of the interim self-governing arrangements in the West
Bank and Gaza Strip. A transfer of powers and responsibilities for
the Gaza Strip and Jericho took place pursuant to the Israel-PLO 4
May 1994 Cairo Agreement on the Gaza Strip and the Jericho Area and
in additional areas of the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement, the Israel-PLO 15 January 1997
Protocol Concerning Redeployment in Hebron, the Israel-PLO 23
October 1998 Wye River Memorandum, and the 4 September 1999 Sharm
el-Sheikh Agreement. The DOP provides that Israel will retain
responsibility during the transitional period for external security
and for internal security and public order of settlements and
Israeli citizens. Direct negotiations to determine the permanent
status of Gaza and West Bank had begun in September 1999 after a
three-year hiatus, but have been derailed by a second intifadah that
broke out in September 2000. The resulting widespread violence in
the West Bank and Gaza Strip, Israel''s military response, and
instability within the Palestinian Authority continue to undermine
progress toward a permanent agreement.
total: 1
1,524 to 2,437 m: 1 (2002)
West Bank
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2002)
total: 1
914 to 1,523 m: 1 (2002)
deforestation (only small portions of the original
forests remain) largely as a result of the continued use of wood as
the main fuel source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone to erosion;
there are no permanent settlements on Alofi because of the lack of
natural fresh water resources
West Bank
adequacy of fresh water supply; sewage treatment
NA kWh
West Bank
NA kWh; note - most electricity imported from Israel; East
Jerusalem Electric Company buys and distributes electricity to
Palestinians in East Jerusalem and its concession in the West Bank;
the Israel Electric Company directly supplies electricity to most
Jewish residents and military facilities; some Palestinian
municipalities, such as Nablus and Janin, generate their own
electricity from small power plants
NA kWh
West Bank
NA kWh
0 kWh (2002)
West Bank
NA kWh
0 kWh (2002)
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0%
West Bank
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%
NA%
West Bank
60% (2002 est.)
lowest 10%: NA%
highest 10%: NA%
West Bank
lowest 10%: NA%
highest 10%: NA%
agriculture, livestock, and fishing 80%,
government 4% (2001 est.)
West Bank
services 66%, industry 21%, agriculture 13% (1996)
copra, chemicals, construction materials
West Bank
olives, fruit, vegetables, limestone
Italy 40%, Croatia 15%, US 14%, Denmark 13%
West Bank
Israel, Jordan, Gaza Strip (2000)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are three kingdoms at the second order named
Alo, Sigave, Wallis
breadfruit, yams, taro, bananas; pigs, goats
West Bank
olives, citrus, vegetables; beef, dairy products
2 (2002)
West Bank
3 (2002)
NA births/1,000 population (2003 est.)
West Bank
34.07 births/1,000 population (2003 est.)
revenues: $20 million
expenditures: $17 million, including capital expenditures of $NA
(1998 est.)
West Bank
revenues: $930 million
expenditures: $1.2 billion, including capital expenditures of $15
million
note: includes Gaza Strip (2000 est.)
The economy is limited to traditional subsistence
agriculture, with about 80% labor force earnings from agriculture
(coconuts and vegetables), livestock (mostly pigs), and fishing.
About 4% of the population is employed in government. Revenues come
from French Government subsidies, licensing of fishing rights to
Japan and South Korea, import taxes, and remittances from expatriate
workers in New Caledonia.
West Bank
Real per capita GDP for the West Bank and Gaza Strip
(WBGS) declined by about one-third between 1992 and 1996 due to the
combined effect of falling aggregate incomes and rapid population
growth. The downturn in economic activity was largely the result of
Israeli closure policies - the imposition of border closures in
response to security incidents in Israel - which disrupted labor and
commodity market relationships between Israel and the WBGS. The most
serious social effect of this downturn was rising unemployment;
unemployment in the WBGS during the 1980s was generally under 5%; by
1995 it had risen to over 20%. Israel''s use of comprehensive
closures during the next five years decreased and, in 1998, Israel
implemented new policies to reduce the impact of closures and other
security procedures on the movement of Palestinian goods and labor.
These changes fueled an almost three-year-long economic recovery in
the West Bank and Gaza Strip; real GDP grew by 5% in 1998 and 6% in
1999. Recovery was upended in the last quarter of 2000 with the
outbreak of violence, which triggered tight Israeli closures of
Palestinian self-rule areas and severely disrupted trade and labor
movements. In 2001, and even more severely in 2002, Israeli military
measures in Palestinian Authority areas have resulted in the
destruction of much capital plant and administrative structure,
widespread business closures, and a sharp drop in GDP. Another major
loss has been the decline in earnings of Palestinian workers in
Israel. International aid of $2 billion in 2001-02 to the West Bank
and Gaza Strip have prevented the complete collapse of the economy.','ac9fba02cff7d39b5f3a570161a729adc48bac03c93520c13eda2aed0f4c986e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8676071267fcdc818fa3f2fd82583b0aa338be0d5783ff3092fc95604b065878',2003,'TG','Togo','economy',51,'GDP:
purchasing power parity - $26.84 billion (2002 est.)
GDP - real growth rate:
4% (2002 est.)
GDP - per capita:
purchasing power parity - $1,700 (2002 est.)
GDP - composition by sector:
agriculture: 46%
industry: 21%
services: 33% (2001 est.)
Population below poverty line:
48% (2000 est.)
Household income or consumption by percentage share:
lowest 10%: 1.9%
highest 10%: 36.6% (1996)
Distribution of family income - Gini index:
47.7 (1996)
Inflation rate (consumer prices):
4.5% (2002 est.)
Labor force:
NA
Labor force - by occupation:
agriculture 70%, industry and commerce 13%, other 17%
Unemployment rate:
30% (2001 est.)
Budget:
revenues: $2.2 billion
expenditures: $2.1 billion, including capital expenditures of $NA
(FY 00/01 est.)
Industries:
petroleum production and refining, food processing, light consumer
goods, textiles, lumber
Industrial production growth rate:
4.2% (1999 est.)
Electricity - production:
3.613 billion kWh (2001)
Electricity - production by source:
fossil fuel: 2.7%
hydro: 97.3%
other: 0% (2001)
nuclear: 0%
Electricity - consumption:
3.36 billion kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
0 kWh (2001)
Oil - production:
76,650 bbl/day (2001 est.)
Oil - consumption:
22,000 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Oil - proved reserves:
200 million bbl (37257)
Natural gas - production:
0 cu m (2001 est.)
Natural gas - consumption:
0 cu m (2001 est.)
Natural gas - exports:
0 cu m (2001 est.)
Natural gas - imports:
0 cu m (2001 est.)
Natural gas - proved reserves:
55.22 billion cu m (37257)
Agriculture - products:
coffee, cocoa, cotton, rubber, bananas, oilseed, grains, root
starches; livestock; timber
Exports:
$1.9 billion f.o.b. (2002 est.)
Exports - commodities:
crude oil and petroleum products, lumber, cocoa beans, aluminum,
coffee, cotton
Exports - partners:
Italy 16.7%, Spain 16%, France 12.8%, US 8.3%, Netherlands 8.2%,
Taiwan 7.7%, China 5.2%, UK 4.4% (2002)
Imports:
$1.7 billion f.o.b. (2002 est.)
Imports - commodities:
machinery, electrical equipment, transport equipment, fuel, food
Imports - partners:
France 28.2%, Nigeria 12.8%, US 8%, Belgium 5.7%, Germany 5.3%,
Italy 4.3% (2002)
Debt - external:
$8.6 billion (2002 est.)
Economic aid - recipient:
on 23 January 2001, the Paris Club agreed to reduce Cameroon''s debt
of $1.3 billion by $900 million; total debt relief now amounts to
$1.26 billion
Currency:
Communaute Financiere Africaine franc (XAF); note - responsible
authority is the Bank of the Central African States
Currency code:
XAF
Exchange rates:
Communaute Financiere Africaine francs (XAF) per US dollar - 696.99
(2002), 733.04 (2001), 711.98 (2000), 615.7 (1999), 589.95 (1998)
Fiscal year:
1 July - 30 June
Communications Cameroon
Telephones - main lines in use:
95,000 (2001)
Telephones - mobile cellular:
300,000 (2002)
Telephone system:
general assessment: available only to business and government
domestic: cable, microwave radio relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations:
AM 2, FM 9, shortwave 3 (2002)
Radios:
2.27 million (1997)
Television broadcast stations:
1 (2002)
Televisions:
450,000 (1997)
Internet country code:
.cm
Internet Service Providers (ISPs):
1 (2002)
Internet users:
45,000
note: Cameroon also had more than 100 cyber-cafes in 2001 (December
2001)
Transportation Cameroon
Railways:
total: 1,008 km
narrow gauge: 1,008 km 1.000-m gauge (2002)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1999 est.)
Waterways:
2,090 km (of decreasing importance) (2002)
Pipelines:
gas 90 km; liquid petroleum gas 9 km; oil 1,124 km (2003)
Ports and harbors:
Bonaberi, Douala, Garoua, Kribi, Tiko
Airports:
49 (2002)
Airports - with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2002)
Airports - with unpaved runways:
total: 38
1,524 to 2,437 m: 7
914 to 1,523 m: 20
under 914 m: 11 (2002)
Military Cameroon
Military branches:
Army, Navy (includes naval infantry), Air Force, National
Gendarmerie, Presidential Guard
Military manpower - military age:
18 years of age (2003 est.)
Military manpower - availability:
males age 15-49: 3,799,841 (2003 est.)
Military manpower - fit for military service:
males age 15-49: 1,928,285 (2003 est.)
Military manpower - reaching military age annually:
males: 179,586 (2003 est.)
Military expenditures - dollar figure:
$118.6 million (FY00)
Military expenditures - percent of GDP:
1.4% (FY98)
Transnational Issues Cameroon
Disputes - international:
ICJ ruled in 2002 on the Cameroon-Nigeria land and maritime
boundary by awarding the potentially petroleum-rich Bakassi
Peninsula and offshore region to Cameroon; Nigeria rejected cession
of the peninsula, but the parties have formed a Joint Border
Commission to resolve differences bilaterally and have commenced
with demarcation in less-contested sections of the boundary; Lake
Chad Commission continues to urge signatories Cameroon, Chad, Niger,
and Nigeria to ratify delimitation treaty over the lake region,
which remains the site of armed clashes among local populations and
militias; Nigeria agreed to ratify the treaty and relinquish
sovereignty of disputed lands to Cameroon by December 2003
This page was last updated on 18 December, 2003
======================================================================
@Canada
Introduction Canada
French Togoland became Togo in 1960. Gen. Gnassingbe EYADEMA,
installed as military ruler in 1967, is Africa''s longest-serving
head of state. Despite the facade of multiparty elections instituted
in the early 1990s, the government continues to be dominated by
President EYADEMA, whose Rally of the Togolese People (RPT) party
has maintained power almost continually since 1967. In addition,
Togo has come under fire from international organizations for human
rights abuses and is plagued by political unrest. Most bilateral and
multilateral aid to Togo remains frozen.
total: 2
2,438 to 3,047 m: 2 (2002)
total: 7
914 to 1,523 m: 5
under 914 m: 2 (2002)
deforestation attributable to slash-and-burn agriculture and
the use of wood for fuel; water pollution presents health hazards
and hinders the fishing industry; air pollution increasing in urban
areas
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
1.8% (FY02)
101.6 million kWh (2001)
614.5 million kWh (2001)
520 million kWh; note - electricity supplied by Ghana (2001)
0 kWh (2001)
fossil fuel: 98.7%
hydro: 1.3%
nuclear: 0%
other: 0% (2001)
32% (1989 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture 65%, industry 5%, services 30% (1998 est.)
reexports, cotton, phosphates, coffee, cocoa
Ghana 17.7%, Benin 13.3%, Burkina Faso 8.2%, Philippines 4.9%,
Niger 4.1% (2002)
5 regions (regions, singular - region); De La Kara, Des
Plateaux, Des Savanes, Centrale, Maritime
coffee, cocoa, cotton, yams, cassava (tapioca), corn, beans,
rice, millet, sorghum; livestock; fish
9 (2002)
35.23 births/1,000 population (2003 est.)
Army, Navy, Air Force, Gendarmerie
revenues: $232 million
expenditures: $252 million, including capital expenditures of $NA
(1997 est.)
This small sub-Saharan economy is heavily dependent on both
commercial and subsistence agriculture, which provides employment
for 65% of the labor force. Some basic foodstuffs must still be
imported. Cocoa, coffee, and cotton generate about 40% of export
earnings, with cotton being the most important cash crop. Togo is
the world''s fourth-largest producer of phosphate, but production
fell an estimated 22% in 2002 due to power shortages and the cost of
developing new deposits. The government''s decade-long effort,
supported by the World Bank and the IMF, to implement economic
reform measures, encourage foreign investment, and bring revenues in
line with expenditures has moved slowly. Progress depends on
following through on privatization, increased openness in government
financial operations, progress toward legislative elections, and
continued support from foreign donors.','04b70586bead7af010a68363d49a009b0880592956629a37af564cf07163b765','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de6d68cf02c9e1bdc121e045b147edcc627dc09b5c601be3302cb5a1319b3048',2003,'SA','Saudi Arabia','economy',591,'In 1902, ABD AL-AZIZ bin Abd al-Rahman Al Saud captured
Riyadh and set out on a 30-year campaign to unify the Arabian
Peninsula. In the 1930s, the discovery of oil transformed the
country. Following Iraq''s invasion of Kuwait in 1990, Saudi Arabia
accepted the Kuwaiti royal family and 400,000 refugees while
allowing Western and Arab troops to deploy on its soil for the
liberation of Kuwait the following year. A burgeoning population,
aquifer depletion, and an economy largely dependent on petroleum
output and prices are all major governmental concerns.
total: 71
over 3,047 m: 31
2,438 to 3,047 m: 12
1,524 to 2,437 m: 24
914 to 1,523 m: 2
under 914 m: 2 (2002)
total: 138
over 3047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 79
914 to 1,523 m: 39
under 914 m: 13 (2002)
desertification; depletion of underground water
resources; the lack of perennial rivers or permanent water bodies
has prompted the development of extensive seawater desalination
facilities; coastal pollution from oil spills
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
13% (FY00)
122.4 billion kWh (2001)
113.8 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 12%, industry 25%, services 63% (1999 est.)
petroleum and petroleum products 90%
US 18.6%, Japan 15.6%, South Korea 10.1%, Singapore
5.1%, China 4.6% (2002)
13 provinces (mintaqat, singular - mintaqah); Al Bahah,
Al Hudud ash Shamaliyah, Al Jawf, Al Madinah, Al Qasim, Ar Riyad,
Ash Sharqiyah (Eastern Province), ''Asir, Ha''il, Jizan, Makkah,
Najran, Tabuk
wheat, barley, tomatoes, melons, dates, citrus; mutton,
chickens, eggs, milk
209 (2002)
37.2 births/1,000 population (2003 est.)
Land Force (Army), Navy, Air Force, Air Defense Force,
National Guard, Ministry of Interior Forces (paramilitary)
revenues: $46 billion
expenditures: $56.5 billion, including capital expenditures of $NA
(2003 est.)
This is an oil-based economy with strong government
controls over major economic activities. Saudi Arabia has the
largest reserves of petroleum in the world (26% of the proved
reserves), ranks as the largest exporter of petroleum, and plays a
leading role in OPEC. The petroleum sector accounts for roughly 75%
of budget revenues, 45% of GDP, and 90% of export earnings. About
25% of GDP comes from the private sector. Roughly 4 million foreign
workers play an important role in the Saudi economy, for example, in
the oil and service sectors. The government in 1999 announced plans
to begin privatizing the electricity companies, which follows the
ongoing privatization of the telecommunications company. The
government is supporting private sector growth to lessen the
kingdom''s dependence on oil and increase employment opportunities
for the swelling Saudi population. Priorities for government
spending in the short term include additional funds for the water
and sewage systems and for education. Water shortages and rapid
population growth constrain the government''s efforts to increase
self-sufficiency in agricultural products.
condensate 212 km; gas 837 km; liquid petroleum gas
1,187 km; oil 5,062 km; refined products 69 km (2003)','e6e22a159bbcaa03ddc9d89c12831ffeee17e61ee72bd49eb378aeb3203d5236','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26ffd82c3eafb4d25592ec44adf6db5e0868623139c6cbb99aaf1a5a62fc61fd',2003,'SN','Senegal','economy',592,'Independent from France in 1960, Senegal joined with The
Gambia to form the nominal confederation of Senegambia in 1982.
However, the envisaged integration of the two countries was never
carried out, and the union was dissolved in 1989. Despite peace
talks, a southern separatist group sporadically has clashed with
government forces since 1982. Senegal has a long history of
participating in international peacekeeping.
Serbia and Montenegro
The Kingdom of Serbs, Croats, and Slovenes was
formed in 1918; its name was changed to Yugoslavia in 1929.
Occupation by Nazi Germany in 1941 was resisted by various
paramilitary bands that fought themselves as well as the invaders.
The group headed by Marshal TITO took full control upon German
expulsion in 1945. Although Communist, his new government
successfully steered its own path between the Warsaw Pact nations
and the West for the next four and a half decades. In the early
1990s, post-TITO Yugoslavia began to unravel along ethnic lines:
Slovenia, Croatia, and The Former Yugoslav Republic of Macedonia all
declared their independence in 1991; Bosnia and Herzegovina in 1992.
The remaining republics of Serbia and Montenegro declared a new
"Federal Republic of Yugoslavia" (FRY) in 1992 and, under President
Slobodan MILOSEVIC, Serbia led various military intervention efforts
to unite Serbs in neighboring republics into a "Greater Serbia." All
of these efforts were ultimately unsuccessful. In 1999, massive
expulsions by FRY forces and Serb paramilitaries of ethnic Albanians
living in Kosovo provoked an international response, including the
NATO bombing of Serbia and the stationing of NATO, Russian, and
other peacekeepers in Kosovo. Federal elections in the fall of 2000,
brought about the ouster of MILOSEVIC and installed Vojislav
KOSTUNICA as president. The arrest of MILOSEVIC in 2001 allowed for
his subsequent transfer to the International Criminal Tribunal for
the Former Yugoslavia in The Hague to be tried for crimes against
humanity. In 2001, the country''s suspension was lifted, and it was
once more accepted into UN organizations under the name of
Yugoslavia. Kosovo has been governed by the UN Interim
Administration Mission in Kosovo (UNMIK) since June 1999, under the
authority of UN Security Council Resolution 1244. In 2002, the
Serbian and Montenegrin components of Yugoslavia began negotiations
to forge a looser relationship. These talks became a reality in
February 2003 when lawmakers restructured the country into a loose
federation of two republics called Serbia and Montenegro. An
agreement was also reached to hold a referendum in each republic in
three years on full independence.
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 2 (2002)
Serbia and Montenegro
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m: 2
under 914 m: 4 (2002)
total: 11
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 1 (2002)
Serbia and Montenegro
total: 26
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m: 12 (2002)
wildlife populations threatened by poaching; deforestation;
overgrazing; soil erosion; desertification; overfishing
Serbia and Montenegro
pollution of coastal waters from sewage
outlets, especially in tourist-related areas such as Kotor; air
pollution around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava which flows
into the Danube
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Serbia and Montenegro
party to: Air Pollution, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Biodiversity
1.4% (FY02)
Serbia and Montenegro
NA%
1.518 billion kWh (2001)
Serbia and Montenegro
31.71 billion kWh (2001)
1.412 billion kWh (2001)
Serbia and Montenegro
32.37 billion kWh (2001)
0 kWh (2001)
Serbia and Montenegro
3.33 billion kWh (2001)
0 kWh (2001)
Serbia and Montenegro
446 million kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Serbia and Montenegro
fossil fuel: 62.9%
hydro: 37.1%
nuclear: 0%
other: 0% (2001)
54% (2001 est.)
Serbia and Montenegro
30%
lowest 10%: 2.6%
highest 10%: 33.5% (1995)
Serbia and Montenegro
lowest 10%: NA%
highest 10%: NA%
agriculture 70%
Serbia and Montenegro
agriculture NA%, industry NA%, services NA%
fish, groundnuts (peanuts), petroleum products, phosphates,
cotton
Serbia and Montenegro
manufactured goods, food and live animals, raw
materials
India 20.7%, France 13%, Mali 8.9%, Greece 7.7%, Italy 4.4%
(2002)
Serbia and Montenegro
Italy 32%, Germany 19.5%, Greece 7%, Austria
6.1%, France 4.6% (2002)
10 regions (regions, singular - region); Dakar, Diourbel,
Fatick, Kaolack, Kolda, Louga, Saint-Louis, Tambacounda, Thies,
Ziguinchor
note: there may be another region called Matam
Serbia and Montenegro
2 republics (republike, singular - republika);
and 2 nominally autonomous provinces* (autonomn pokrajine, singular
- autonomna pokrajina); Kosovo*, Montenegro, Serbia, Vojvodina*
peanuts, millet, corn, sorghum, rice, cotton, tomatoes,
green vegetables; cattle, poultry, pigs; fish
Serbia and Montenegro
cereals, fruits, vegetables, tobacco, olives;
cattle, sheep, goats
20 (2002)
Serbia and Montenegro
45 (2002)
36.23 births/1,000 population (2003 est.)
Serbia and Montenegro
12.74 births/1,000 population (2003 est.)
Army, Navy, Air Force, National Gendarmerie, National Police
(Surete Nationale)
Serbia and Montenegro
Army (VJ) (including ground forces with border
troops, naval forces, air and air defense forces)
revenues: $1.373 billion
expenditures: $1.373 billion, including capital expenditures of $357
million (2002 est.)
Serbia and Montenegro
revenues: $3.9 billion
expenditures: $4.3 billion, including capital expenditures of $NA
(2001 est.)
In January 1994, Senegal undertook a bold and ambitious
economic reform program with the support of the international donor
community. This reform began with a 50% devaluation of Senegal''s
currency, the CFA franc, which was linked at a fixed rate to the
French franc. Government price controls and subsidies have been
steadily dismantled. After seeing its economy contract by 2.1% in
1993, Senegal made an important turnaround, thanks to the reform
program, with real growth in GDP averaging 5% annually during
1995-2002. Annual inflation had been pushed down to less than 1%,
but rose to an estimated 3.3% in 2001 and 3.0% in 2002. Investment
rose steadily from 13.8% of GDP in 1993 to 16.5% in 1997. As a
member of the West African Economic and Monetary Union (WAEMU),
Senegal is working toward greater regional integration with a
unified external tariff. Senegal also realized full Internet
connectivity in 1996, creating a miniboom in information
technology-based services. Private activity now accounts for 82% of
GDP. In 2003, GDP will probably again grow at about 5%. On the
negative side, Senegal faces deep-seated urban problems of chronic
unemployment, trade union militancy, juvenile delinquency, and drug
addiction.
Serbia and Montenegro
MILOSEVIC-era mismanagement of the economy, an
extended period of economic sanctions, and the damage to
Yugoslavia''s infrastructure and industry during the war in Kosovo
have left the economy only half the size it was in 1990. Since the
ousting of former Federal Yugoslav President MILOSEVIC in October
2000, the Democratic Opposition of Serbia (DOS) coalition government
has implemented stabilization measures and embarked on an aggressive
market reform program. After renewing its membership in the IMF in
December 2000, Yugoslavia continued to reintegrate into the
international community by rejoining the World Bank (IBRD) and the
European Bank for Reconstruction and Development (EBRD). A World
Bank-European Commission sponsored Donors'' Conference held in June
2001 raised $1.3 billion for economic restructuring. An agreement
rescheduling the country''s $4.5 billion Paris Club government debts
was concluded in November 2001; it will write off 66% of the debt; a
similar debt relief agreement on its $2.8 billion London Club
commercial debt is still pending. The smaller republic of Montenegro
severed its economy from federal control and from Serbia during the
MILOSEVIC era and continues to maintain its own central bank, uses
the euro instead of the Yugoslav dinar as official currency,
collects customs tariffs, and manages its own budget. Kosovo, while
technically still part of the Federal Republic of Yugoslavia (now
Serbia and Montenegro) according to United Nations Security Council
Resolution 1244, is moving toward local autonomy under United
Nations Interim Administration Mission in Kosovo (UNMIK) and is
dependent on the international community for financial and technical
assistance. The euro and the Yugoslav dinar are official currencies,
and UNMIK collects taxes and manages the budget. The complexity of
Serbia and Montenegro political relationships, slow progress in
privatization, and stagnation in the European economy are holding
back the economy. Arrangements with the IMF, especially requirements
for fiscal discipline, are an important element in policy formation.
Severe unemployment remains a key political economic problem.
gas 564 km (2003)
Serbia and Montenegro
gas 3,177 km; oil 393 km (2003)','c798d36c10fda1e035147fcf2f23c96fa69d1a749f740a9c16bbe064ab744534','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('215bd712f0b801e47c067a94a04b34db9252e3f7409838bb4250312db90088c5',2003,'SC','Seychelles','economy',593,'A lengthy struggle between France and Great Britain for
the islands ended in 1814, when they were ceded to the latter.
Independence came in 1976. Socialist rule was brought to a close
with a new constitution and free elections in 1993. The most recent
presidential elections were held 31 August-2 September 2001.
President RENE, who has served since 1977, was re-elected.
total: 7
2,438 to 3,047 m: 1
914 to 1,523 m: 4
under 914 m: 2 (2002)
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2002)
water supply depends on catchments to collect rainwater
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
1.8% (FY02)
160 million kWh (2001)
148.8 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
industry 19%, services 71%, agriculture 10% (1989)
canned tuna, frozen fish, cinnamon bark, copra, petroleum
products (reexports)
UK 28.6%, France 20%, Italy 8.7%, US 8.4%, Spain 6.7%,
Japan 6.7%, Netherlands 6.6%, Thailand 6.4% (2002)
23 administrative districts; Anse aux Pins, Anse Boileau,
Anse Etoile, Anse Louis, Anse Royale, Baie Lazare, Baie Sainte Anne,
Beau Vallon, Bel Air, Bel Ombre, Cascade, Glacis, Grand'' Anse (on
Mahe), Grand'' Anse (on Praslin), La Digue, La Riviere Anglaise, Mont
Buxton, Mont Fleuri, Plaisance, Pointe La Rue, Port Glaud, Saint
Louis, Takamaka
coconuts, cinnamon, vanilla, sweet potatoes, cassava
(tapioca), bananas; broiler chickens; tuna fish
14 (2002)
16.89 births/1,000 population (2003 est.)
Army, Coast Guard (includes Air Wing), Presidential
Protection Unit (includes Presidential Guard), Police Force
(includes Police Mobile Unit, a special weapons and tactics unit
capable of assisting the Army in maintaining internal stability)
revenues: $249 million
expenditures: $262 million, including capital expenditures of $NA
(1998 est.)
Since independence in 1976, per capita output in this
Indian Ocean archipelago has expanded to roughly seven times the old
near-subsistence level. Growth has been led by the tourist sector,
which employs about 30% of the labor force and provides more than
70% of hard currency earnings, and by tuna fishing. In recent years
the government has encouraged foreign investment in order to upgrade
hotels and other services. At the same time, the government has
moved to reduce the dependence on tourism by promoting the
development of farming, fishing, and small-scale manufacturing. A
sharp drop illustrated the vulnerability of the tourist sector in
1991-92 due largely to the Gulf war, and once again following the 11
September 2001 terrorist attacks on the US. Other issues facing the
government are the curbing of the budget deficit, including the
containment of social welfare costs, and further privatization of
public enterprises. Growth slowed in 1998-2002, due to sluggish
tourist and tuna sectors. Also, tight controls on exchange rates and
the scarcity of foreign exchange have impaired short-term economic
prospects. The black market value of the Seychelles rupee is half
the official exchange rate; without a devaluation of the currency
the tourist sector should remain sluggish as vacationers seek
cheaper destinations such as Comoros, Mauritius, and Madagascar.','42fb059ee1bdc0091931f674def0fc9bf4d7864474d07352197de6851ec51ecc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9baf8cc114bc500f185338e0971884ed97df3e20614b61ceb7120aec9177147c',2003,'SL','Sierra Leone','economy',594,'Since 1991, civil war between the government and the
Revolutionary United Front (RUF) has resulted in tens of thousands
of deaths and the displacement of more than 2 million people (well
over one-third of the population), many of whom are now refugees in
neighboring countries. After several setbacks, the end to the
11-year conflict in Sierra Leone may finally be near at hand. With
the support of the UN peacekeeping force and contributions from the
World Bank and international community, demobilization and
disarmament of the RUF and Civil Defense Forces (CDF) combatants has
been completed. National elections were held in May 2002 and the
government continues to slowly reestablish its authority.
total: 1
over 3,047 m: 1 (2002)
total: 9
914 to 1,523 m: 7
under 914 m: 2 (2002)
rapid population growth pressuring the environment;
overharvesting of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.5% (FY02)
250.1 million kWh (2001)
232.6 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
68% (1989 est.)
lowest 10%: 0.5%
highest 10%: 43.6% (1989)
agriculture NA%, industry NA%, services NA%
diamonds, rutile, cocoa, coffee, fish (1999)
Belgium 41.9%, Germany 28.1%, UK 3.6% (2002)
3 provinces and 1 area*; Eastern, Northern, Southern,
Western*
rice, coffee, cocoa, palm kernels, palm oil, peanuts;
poultry, cattle, sheep, pigs; fish
10 (2002)
43.89 births/1,000 population (2003 est.)
Army (RSLAF)
revenues: $96 million
expenditures: $351 million, including capital expenditures of $NA
(2000 est.)
Sierra Leone is an extremely poor African nation with
tremendous inequality in income distribution. It does have
substantial mineral, agricultural, and fishery resources. However,
the economic and social infrastructure is not well developed, and
serious social disorders continue to hamper economic development,
following a 11-year civil war. About two-thirds of the working-age
population engages in subsistence agriculture. Manufacturing
consists mainly of the processing of raw materials and of light
manufacturing for the domestic market. Plans continue to reopen
bauxite and rutile mines shut down during the conflict. The major
source of hard currency consists of the mining of diamonds. The fate
of the economy depends upon the maintenance of domestic peace and
the continued receipt of substantial aid from abroad, which is
essential to offset the severe trade imbalance and to supplement
government revenues.','b3c4694abce7422ea09493c99a2badd53689bcad4c1ec89ae9c407e8ed059c89','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09311979e2cd0c75eb217f42ca51d2716673a4f27c513cf23915589c8d709812',2003,'SG','Singapore','economy',595,'Singapore was founded as a British trading colony in 1819.
It joined the Malaysian Federation in 1963 but separated two years
later and became independent. It subsequently became one of the
world''s most prosperous countries with strong international trading
links (its port is one of the world''s busiest) and with per capita
GDP equal to that of the leading nations of Western Europe.
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (2002)
industrial pollution; limited natural fresh water
resources; limited land availability presents waste disposal
problems; seasonal smoke/haze resulting from forest fires in
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
4.9% (FY01)
30.48 billion kWh (2001)
28.35 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
financial, business, and other services 35%, manufacturing
21%, construction 13%, transportation and communication 9%, other 22%
machinery and equipment (including electronics), consumer
goods, chemicals, mineral fuels
Malaysia 17.4%, US 15.3%, Hong Kong 9.2%, Japan 7.1%,
China 5.5%, Taiwan 4.9%, Thailand 4.6%, South Korea 4.2% (2002)
none
rubber, copra, fruit, orchids, vegetables; poultry, eggs,
fish, ornamental fish
9 (2002)
12.75 births/1,000 population (2003 est.)
Army, Navy, Air Force, People''s Defense Force, Police Force
revenues: $27.9 billion
expenditures: $19.5 billion, including capital expenditures of $5.4
billion (FY 00/01 est.)
Singapore, a highly developed and successful free market
economy, enjoys a remarkably open and corruption-free environment,
stable prices, and one of the highest per capita GDPs in the world.
The economy depends heavily on exports, particularly in electronics
and manufacturing. It was hard hit in 2001-2002 by the global
recession and the slump in the technology sector. The government
hopes to establish a new growth path that will be less vulnerable to
the external business cycle than the current export-led model but is
unlikely to abandon efforts to establish Singapore as Southeast
Asia''s financial and high-tech hub.
gas 139 km (2003)','298977feb515af848eba32ea3b5f347d899aacebc6268d4b7bff7f2517e3ad37','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4a254d64cdf05a024248f493da6c5b841176c09823974b008d593cd9b3dd297',2003,'SK','Slovakia','economy',596,'In 1918 the Slovaks joined the closely related Czechs to
form Czechoslovakia. Following the chaos of World War II,
Czechoslovakia became a Communist nation within Soviet-ruled Eastern
Europe. Soviet influence collapsed in 1989 and Czechoslovakia once
more became free. The Slovaks and the Czechs agreed to separate
peacefully on 1 January 1993. Slovakia was invited to join NATO and
the EU in 2002.
total: 20
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 9 (2002)
total: 17
2,438 to 3,047 m: 1
914 to 1,523 m: 9
under 914 m: 7 (2002)
air pollution from metallurgical plants presents human
health risks; acid rain damaging forests
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
1.89% (2002)
30.29 billion kWh (2001)
24.41 billion kWh (2001)
1.381 billion kWh (2001)
5.141 billion kWh (2001)
fossil fuel: 30.3%
hydro: 16%
nuclear: 53.6%
other: 0% (2001)
NA%
lowest 10%: 5.1%
highest 10%: 18.2% (1992)
industry 29.3%, agriculture 8.9%, construction 8%,
transport and communication 8.2%, services 45.6% (1994)
machinery and transport equipment 39.4%, intermediate
manufactured goods 27.5%, miscellaneous manufactured goods 13%,
chemicals 8% (1999)
Germany 30.1%, Czech Republic 16.4%, Austria 10.7%, Italy
7.2%, Poland 5.7%, Hungary 4.6% (2002)
8 regions (kraje, singular - kraj); Banskobystricky,
Bratislavsky, Kosicky, Nitriansky, Presovsky, Trenciansky, Trnavsky,
Zilinsky
grains, potatoes, sugar beets, hops, fruit; pigs, cattle,
poultry; forest products
37 (2002)
10.1 births/1,000 population (2003 est.)
Army (Ground Forces), Air and Air Defense Forces, Home
Guards (Territorial Defense Forces), Civil Defense Force, Railway
Armed Forces (subordinate to the Ministry of Transportation, Post,
and Telecommunications)
revenues: $5.2 billion
expenditures: $5.6 billion, including capital expenditures of $NA
(1999)
Slovakia has mastered much of the difficult transition from
a centrally planned economy to a modern market economy. The DZURINDA
government has made excellent progress in 2001-03 in macroeconomic
stabilization and structural reform. Major privatizations are nearly
complete, the banking sector is almost completely in foreign hands,
and foreign investment has picked up. Slovakia''s economy exceeded
expectations in 2001-03, despite the general European slowdown.
Unemployment, at an unacceptable 15% in 2003, remains the economy''s
Achilles heel. The government faces other strong challenges in 2004,
especially the cutting of budget and current account deficits, the
containment of inflation, and the strengthening of the health care
system.
gas 6,769 km; oil 449 km (2003)','a7f848344a5115518434614c4a6d69689b9353bd2154e468735a7c618a790305','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fe434491a8da6b95e6248ff9005988d99136440cc034e6dc1b5ef4ae21bb0fd',2003,'SI','Slovenia','economy',597,'The Slovene lands were part of the Holy Roman Empire and
Austria until 1918 when the Slovenes joined the Serbs and Croats in
forming a new nation, renamed Yugoslavia in 1929. After World War
II, Slovenia became a republic of the renewed Yugoslavia, which
though Communist, distanced itself from Moscow''s rule. Dissatisfied
with the exercise of power of the majority Serbs, the Slovenes
succeeded in establishing their independence in 1991 after a short
10-day war. Historical ties to Western Europe, a strong economy, and
a stable democracy have assisted in Slovenia''s transformation to a
modern state. In December 2002, Slovenia received an invitation to
join NATO, and it is scheduled to accede to the EU along with nine
other states on 1 May 2004. In a March 2003 referendum on NATO and
EU membership, Slovenes voted 90% in favor of joining the EU and 66%
in favor of joining NATO.
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2002)
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 5 (2002)
Sava River polluted with domestic and industrial waste;
pollution of coastal waters with heavy metals and toxic chemicals;
forest damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid rain
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
1.7% (FY00)
13.69 billion kWh (2001)
13.83 billion kWh (2001)
4.1 billion kWh (2001)
3 billion kWh (2001)
fossil fuel: 35.2%
hydro: 27.3%
nuclear: 36.8%
other: 0.7% (2001)
NA%
lowest 10%: 3.9%
highest 10%: 23% (1998)
agriculture NA%, industry NA%, services NA%
manufactured goods, machinery and transport equipment,
chemicals, food
Germany 23.9%, Italy 12.7%, Austria 9.5%, Croatia 8%,
France 7.4%, Bosnia and Herzegovina 4.4% (2002)
182 municipalities (obcine, singular - obcina) and 11 urban
municipalities* (mestne obcine , singular - mestna obcina )
Ajdovscina, Beltinci, Benedikt, Bistrica ob Sotli, Bled, Bloke,
Bohinj, Borovnica, Bovec, Braslovce, Brda, Brezice, Brezovica,
Cankova, Celje*, Cerklje na Gorenjskem, Cerknica, Cerkno,
Cerkvenjak, Crensovci, Crna na Koroskem, Crnomelj, Destrnik, Divaca,
Dobje, Dobrepolje, Dobrna, Dobrova-Horjul-Polhov Gradec,
Dobrovnik-Dobronak, Dolenjske Toplice, Dol pri Ljubljani, Domzale,
Dornava, Dravograd, Duplek, Gorenja Vas-Poljane, Gorisnica, Gornja
Radgona, Gornji Grad, Gornji Petrovci, Grad, Grosuplje, Hajdina,
Hoce-Slivnica, Hodos-Hodos, Horjul, Hrastnik, Hrpelje-Kozina,
Idrija, Ig, Ilirska Bistrica, Ivancna Gorica, Izola-Isola, Jesenice,
Jezersko, Jursinci, Kamnik, Kanal, Kidricevo, Kobarid, Kobilje,
Kocevje, Komen, Komenda, Koper-Capodistria*, Kostel, Kozje, Kranj*,
Kranjska Gora, Krizevci, Krsko, Kungota, Kuzma, Lasko, Lenart,
Lendava-Lendva, Litija, Ljubljana*, Ljubno, Ljutomer, Logatec, Loska
Dolina, Loski Potok, Lovrenc na Pohorju, Luce, Lukovica, Majsperk,
Maribor*, Markovci, Medvode, Menges, Metlika, Mezica, Miklavz na
Dravskem Polju, Miren-Kostanjevica, Mirna Pec, Mislinja, Moravce,
Moravske Toplice, Mozirje, Murska Sobota*, Muta, Naklo, Nazarje,
Nova Gorica*, Novo Mesto*, Odranci, Oplotnica, Ormoz, Osilnica,
Pesnica, Piran-Pirano, Pivka, Podcetrtek, Podlehnik, Podvelka,
Polzela, Postojna, Prebold, Preddvor, Prevalje, Ptuj*, Puconci,
Race-Fram, Radece, Radenci, Radlje ob Dravi, Radovljica, Ravne na
Koroskem, Razkrizje, Ribnica, Ribnica na Pohorju, Rogasovci, Rogaska
Slatina, Rogatec, Ruse, Salovci, Selnica ob Dravi, Semic,
Sempeter-Vrtojba, Sencur, Sentilj, Sentjernej, Sentjur pri Celju,
Sevnica, Sezana, Skocjan, Skofja Loka, Skofljica, Slovenj Gradec*,
Slovenska Bistrica, Slovenske Konjice, Smarje pri Jelsah, Smartno ob
Paki, Smartno pri Litiji, Sodrazica, Solcava, Sostanj, Starse,
Store, Sveta Ana, Sveti Andraz v Slovenskih Goricah, Sveti Jurij,
Tabor, Tisina, Tolmin, Trbovlje, Trebnje, Trnovska Vas, Trzic,
Trzin, Turnisce, Velenje*, Velika Polana, Velike Lasce, Verzej,
Videm, Vipava, Vitanje, Vodice, Vojnik, Vransko, Vrhnika, Vuzenica,
Zagorje ob Savi, Zalec, Zavrc, Zelezniki, Zetale, Ziri, Zirovnica,
Zuzemberk, Zrece
note: there may be 45 more municipalities
potatoes, hops, wheat, sugar beets, corn, grapes; cattle,
sheep, poultry
16 (2002)
9.23 births/1,000 population (2003 est.)
Slovenian Army (includes Air and Naval Forces)
revenues: $8.11 billion
expenditures: $8.32 billion, including capital expenditures of $NA
(1997 est.)
Slovenia, with its historical ties to Western Europe,
enjoys a GDP per capita substantially higher than that of the other
transitioning economies of Central Europe. Privatization of the
economy proceeded at an accelerated pace in 2002-3, and the budget
deficit dropped from 3.0% of GDP in 2002 to 1.9% in 2003. Despite
the economic slowdown in Europe in 2001-03, Slovenia maintained 3%
growth. Structural reforms to improve the business environment allow
for greater foreign participation in Slovenia''s economy and help to
lower unemployment. Further measures to curb inflation are also
needed. Corruption and the high degree of coordination between
government, business, and central bank policy are issues of concern
in the run-up to Slovenia''s scheduled 1 May 2004 accession to the
European Union.
gas 2,526 km; oil 11 km (2003)','7622d4753902e22e978ba4f49ff1a3a1f411a181e268de064823731f23e586a2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccadf0e69259890af6a8c4cafc4262ee85f47e9530b6011518f5072b3f0ae944',2003,'SB','Solomon Islands','economy',598,'The UK established a protectorate over the Solomon
Islands in the 1890s. Some of the bitterest fighting of World War II
occurred on these islands. Self-government was achieved in 1976 and
independence two years later. Ethnic violence, government
malfeasance, and endemic crime have undermined stability and civil
society.
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
total: 30
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 20 (2002)
deforestation; soil erosion; many of the surrounding
coral reefs are dead or dying
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA%
32 million kWh (2001)
29.76 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 75%, industry 5%, services 20% (2000
est.)
timber, fish, copra, palm oil, cocoa
Japan 21.2%, China 18.8%, South Korea 16.3%,
Philippines 8.9%, Thailand 7.6%, Singapore 4.1% (2002)
9 provinces and 1 capital territory*; Central,
Choiseul (Lauru), Guadalcanal, Honiara*, Isabel, Makira, Malaita,
Rennell/Bellona, Temotu, Western
cocoa beans, coconuts, palm kernels, rice, potatoes,
vegetables, fruit; cattle, pigs; timber; fish
32 (2002)
32.45 births/1,000 population (2003 est.)
no regular military forces; Solomon Islands National
Reconnaissance and Surveillance Force; Royal Solomon Islands Police
(RSIP)
revenues: $38 million
expenditures: $NA, including capital expenditures of $NA (2001)
The bulk of the population depends on agriculture,
fishing, and forestry for at least part of their livelihood. Most
manufactured goods and petroleum products must be imported. The
islands are rich in undeveloped mineral resources such as lead,
zinc, nickel, and gold. However, severe ethnic violence, the closing
of key business enterprises, and an empty government treasury have
led to serious economic disarray, indeed near collapse. Tanker
deliveries of crucial fuel supplies (including those for electrical
generation) have become sporadic due to the government''s inability
to pay and attacks against ships. Telecommunications are threatened
by the nonpayment of bills and by the lack of technical and
maintenance staff many of whom have left the country.','859b1878098213e7e9002de4996c54c75d337ac83056696500c38b31530529f1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f024623543bf16c55ee0afa63f03f6a62844deae00a710d63ccbf995efaeb498',2003,'SO','Somalia','economy',599,'The SIAD BARRE regime was ousted in January 1991; turmoil,
factional fighting, and anarchy have followed for twelve years. In
May of 1991, northern clans declared an independent Republic of
Somaliland that now includes the administrative regions of Awdal,
Woqooyi Galbeed, Togdheer, Sanaag, and Sool. Although not recognized
by any government, this entity has maintained a stable existence,
aided by the overwhelming dominance of a ruling clan and economic
infrastructure left behind by British, Russian, and American
military assistance programs. The regions of Bari and Nugaal and
northern Mudug comprise a neighboring self-declared autonomous state
of Puntland, which has been self-governing since 1998, but does not
aim at independence; it has also made strides towards reconstructing
a legitimate, representative government, but has suffered civil
strife in 2002. Puntland disputes its border with Somaliland as it
also claims portions of eastern Sool and Sanaag. Beginning in 1993,
a two-year UN humanitarian effort (primarily in the south) was able
to alleviate famine conditions, but when the UN withdrew in 1995,
having suffered significant casualties, order still had not been
restored. The mandate of the Transitional National Government (TNG),
created in August 2000 in Arta, Djibouti, expires in August 2003 and
a new interim government was being created at peace talks held in
Kenya. Numerous warlords and factions are still fighting for control
of Mogadishu and the other southern regions. Suspicion of Somali
links with global terrorism further complicates the picture.
total: 6
over 3,047 m: 4
2438 to 3047 m: 1
1,524 to 2,437 m: 1 (2002)
total: 54
2,438 to 3,047 m: 3
1,524 to 2,437 m: 18
914 to 1,523 m: 30
under 914 m: 3 (2002)
famine; use of contaminated water contributes to human
health problems; deforestation; overgrazing; soil erosion;
desertification
party to: Endangered Species, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: Marine Dumping, Nuclear Test Ban
0.9% (FY02)
245.1 million kWh (2001)
227.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture (mostly pastoral nomadism) 71%, industry and
services 29%
livestock, bananas, hides, fish, charcoal, scrap metal
UAE 45.6%, Yemen 24.3%, Oman 9.5% (2002)
18 regions (plural - NA, singular - gobolka); Awdal, Bakool,
Banaadir, Bari, Bay, Galguduud, Gedo, Hiiraan, Jubbada Dhexe,
Jubbada Hoose, Mudug, Nugaal, Sanaag, Shabeellaha Dhexe, Shabeellaha
Hoose, Sool, Togdheer, Woqooyi Galbeed
cattle, sheep, goats; bananas, sorghum, corn, coconuts,
rice, sugarcane, mangoes, sesame seeds, beans; fish
60 (2002)
46.42 births/1,000 population (2003 est.)
A Somali National Army was attempted under the interim
government; numerous factions and clans maintain independent
militias, and the Somaliland and Puntland regional governments
maintain their own security and police forces
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Somalia''s economic fortunes are being driven by its deep
political divisions. The northern area has declared its independence
as "Somaliland"; the central area, Puntland, is a self-declared
autonomous state; and the remaining southern portion is riddled with
the struggles of rival factions. Economic life continues, in part
because much activity is local and relatively easily protected.
Agriculture is the most important sector, with livestock normally
accounting for about 40% of GDP and about 65% of export earnings,
but Saudi Arabia''s recent ban on Somali livestock, because of Rift
Valley Fever concerns, has severely hampered the sector. Nomads and
semi-nomads, who are dependent upon livestock for their livelihood,
make up a large portion of the population. Livestock, hides, fish,
charcoal, and bananas are Somalia''s principal exports, while sugar,
sorghum, corn, qat, and machined goods are the principal imports.
Somalia''s small industrial sector, based on the processing of
agricultural products, has largely been looted and sold as scrap
metal. Despite the seeming anarchy, Somalia''s service sector has
managed to survive and grow. Telecommunication firms provide
wireless services in most major cities and offer the lowest
international call rates on the continent. In the absence of a
formal banking sector, money exchange services have sprouted
throughout the country, handling between $200 million and $500
million in remittances annually. Mogadishu''s main market offers a
variety of goods from food to the newest electronic gadgets. Hotels
continue to operate, and security is provided by militias. The
ongoing civil disturbances and clan rivalries, however, have
interfered with any broad-based economic development and
international aid arrangements. In 2002 Somalia''s overdue financial
obligations to the IMF continued to grow.
crude oil 15 km','5f85b90b13ee00ca6d94669c1326cb6bbe8f11d57c17d00bcb58740c00bd7006','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5ab331178cc270a0f7e2b5a6bcb272785dc066db8822ae43d5dca0f63c0427b',2003,'ZA','South Africa','economy',600,'After the British seized the Cape of Good Hope area in
1806, many of the Dutch settlers (the Boers) trekked north to found
their own republics. The discovery of diamonds (1867) and gold
(1886) spurred wealth and immigration and intensified the
subjugation of the native inhabitants. The Boers resisted British
encroachments, but were defeated in the Boer War (1899-1902). The
resulting Union of South Africa operated under a policy of apartheid
- the separate development of the races. The 1990s brought an end to
apartheid politically and ushered in black majority rule.
total: 143
over 3,047 m: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m: 50
914 to 1,523 m: 67
under 914 m: 11 (2002)
total: 584
1,524 to 2,437 m: 34
914 to 1,523 m: 298
under 914 m: 252 (2002)
lack of important arterial rivers or lakes requires
extensive water conservation and control measures; growth in water
usage outpacing supply; pollution of rivers from agricultural runoff
and urban discharge; air pollution resulting in acid rain; soil
erosion; desertification
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Southern Ocean
the Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition, it is subject
to these agreements specific to the Antarctic region: International
Whaling Commission (prohibits commercial whaling south of 40 degrees
south [south of 60 degrees south between 50 degrees and 130 degrees
west]); Convention on the Conservation of Antarctic Seals (limits
sealing); Convention on the Conservation of Antarctic Marine Living
Resources (regulates fishing)
note: many nations (including the US) prohibit mineral resource
exploration and exploitation south of the fluctuating Polar Front
(Antarctic Convergence) which is in the middle of the Antarctic
Circumpolar Current and serves as the dividing line between the very
cold polar surface waters to the south and the warmer waters to the
north
1.7% (FY02)
195.6 billion kWh (2001)
181.2 billion kWh (2001)
6.2 billion kWh (2001)
6.91 billion kWh (2001)
fossil fuel: 93.5%
hydro: 1.1%
nuclear: 5.5%
other: 0% (2001)
50% (2000 est.)
lowest 10%: 1.1%
highest 10%: 45.9% (1994)
agriculture 30%, industry 25%, services 45% (1999 est.)
gold, diamonds, platinum, other metals and minerals,
machinery and equipment (1998 est.)
UK 12.8%, US 12.7%, Germany 9%, Japan 8.8%, Italy 5.8%
(2002)
9 provinces; Eastern Cape, Free State, Gauteng,
KwaZulu-Natal, Limpopo, Mpumalanga, North-West, Northern Cape,
Western Cape
corn, wheat, sugarcane, fruits, vegetables; beef,
poultry, mutton, wool, dairy products
727 (2002)
18.87 births/1,000 population (2003 est.)
South African National Defense Force (including Army,
Navy, Air Force, and Medical Services), South African Police Service
revenues: $22.6 billion
expenditures: $24.7 billion, including capital expenditures of $NA
billion (FY 02/03)
South Africa is a middle-income, emerging market with
an abundant supply of natural resources; well-developed financial,
legal, communications, energy, and transport sectors; a stock
exchange that ranks among the 10 largest in the world; and a modern
infrastructure supporting an efficient distribution of goods to
major urban centers throughout the region. However, growth has not
been strong enough to lower South Africa''s high unemployment rate;
and daunting economic problems remain from the apartheid era,
especially poverty and lack of economic empowerment among the
disadvantaged groups. High crime and HIV/AIDS infection rates also
deter investment. South African economic policy is fiscally
conservative, but pragmatic, focusing on targeting inflation and
liberalizing trade as means to increase job growth and household
income.
condensate 100 km; gas 741 km; oil 847 km; refined
products 1,354 km (2003)','ea7d92e6c2120db3e457c33eda445f0a7da28e4f1cd5f189c9113540af003fa8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3555ff8b8ddbb055ec6ded674c32660f793ef97fb5ee60b5839b80dca8df3ed',2003,'GS','South Georgia and the South Sandwich Islands','economy',601,'The islands lie
approximately 1,000 km east of the Falkland Islands and have been
under British administration since 1908, except for a brief period
in 1982 when Argentina occupied them. Grytviken, on South Georgia,
was a 19th and early 20th century whaling station. Famed explorer
Ernest SHACKLETON stopped there in 1914 en route to his ill-fated
attempt to cross Antarctica on foot. He returned some 20 months
later with a few companions in a small boat and arranged a
successful rescue for the rest of his crew, stranded off the
Antarctic Peninsula. He died in 1922 on a subsequent expedition and
is buried in Grytviken. Today, the station houses scientists from
the British Antarctic Survey. The islands have large bird and seal
populations, and, recognizing the importance of preserving the
marine stocks in adjacent waters, the UK, in 1993, extended the
exclusive fishing zone from 12 NM to 200 NM around each island.
Southern Ocean
A decision by the International Hydrographic
Organization in the spring of 2000 delimited a fifth world ocean -
the Southern Ocean - from the southern portions of the Atlantic
Ocean, Indian Ocean, and Pacific Ocean. The Southern Ocean extends
from the coast of Antarctica north to 60 degrees south latitude,
which coincides with the Antarctic Treaty Limit. The Southern Ocean
is now the fourth largest of the world''s five oceans (after the
Pacific Ocean, Atlantic Ocean, and Indian Ocean, but larger than the
Arctic Ocean).
NA
Southern Ocean
increased solar ultraviolet radiation resulting from
the Antarctic ozone hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and damaging the DNA
of some fish; illegal, unreported, and unregulated fishing in recent
years, especially the landing of an estimated five to six times more
Patagonian toothfish than the regulated fishery, which is likely to
affect the sustainability of the stock; large amount of incidental
mortality of seabirds resulting from long-line fishing for toothfish
note: the now-protected fur seal population is making a strong
comeback after severe overexploitation in the 18th and 19th centuries
none (2002)
Some fishing takes
place in adjacent waters. There is a potential source of income from
harvesting finfish and krill. The islands receive income from
postage stamps produced in the UK, sale of fishing licenses, and
harbor and landing fees from tourist vessels. Tourism from
specialized cruise ships is increasing rapidly.
Southern Ocean
Fisheries in 2000-01 (1 July to 30 June) landed
112,934 metric tons, of which 87% was krill and 11% Patagonian
toothfish. International agreements were adopted in late 1999 to
reduce illegal, unreported, and unregulated fishing, which in the
2000-01 season landed, by one estimate, 8,376 metric tons of
Patagonian and antarctic toothfish. In the 2000-01 antarctic summer
12,248 tourists, most of them seaborne, visited the Southern Ocean
and Antarctica, compared to 14,762 the previous year.','6c7fd3dec0716811d360b3c88530af9c5dea2a9e33ad60eaff9b8c6468d4648c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15e141b997a2655dc3afff33f69d6efd2e8c391184a54a53b1f6edb0b1cb5988',2003,'ES','Spain','economy',602,'Spain''s powerful world empire of the 16th and 17th centuries
ultimately yielded command of the seas to England. Subsequent
failure to embrace the mercantile and industrial revolutions caused
the country to fall behind Britain, France, and Germany in economic
and political power. Spain remained neutral in World Wars I and II,
but suffered through a devastating civil war (1936-39). In the
second half of the 20th century, Spain has played a catch-up role in
the western international community; it joined the EU in 1986.
Continuing concerns are Basque Fatherland and Liberty (ETA)
terrorism and further reductions in unemployment.
Spratly Islands
The Spratly Islands consist of more than 100 small
islands or reefs. They are surrounded by rich fishing grounds and
potentially by gas and oil deposits. They are claimed in their
entirety by China, Taiwan, and Vietnam, while portions are claimed
by Malaysia and the Philippines. About 50 islands are occupied by
China (about 450 soldiers), Malaysia (70-90), the Philippines (about
100), and Vietnam (about 1,500). Brunei is a claimant but has no
outposts. (2002)
total: 93
over 3,047 m: 15
2,438 to 3,047 m: 10
1,524 to 2,437 m: 18
914 to 1,523 m: 23
under 914 m: 27 (2002)
Spratly Islands
total: 1
914 to 1,523 m: 1 (2002)
total: 59
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 43 (2002)
Spratly Islands
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2002)
pollution of the Mediterranean Sea from raw sewage and
effluents from the offshore production of oil and gas; water quality
and quantity nationwide; air pollution; deforestation;
desertification
Spratly Islands
NA
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Desertification
1.15% (2002)
222.5 billion kWh (2001)
210.4 billion kWh (2001)
7.588 billion kWh (2001)
4.138 billion kWh (2001)
fossil fuel: 50.4%
hydro: 18.2%
nuclear: 27.2%
other: 4.1% (2001)
NA%
lowest 10%: 2.8%
highest 10%: 25.2% (1990)
services 64%, manufacturing, mining, and construction 29%,
agriculture 7% (2001 est.)
machinery, motor vehicles; foodstuffs, other consumer goods
France 19%, Germany 11.4%, UK 9.6%, Portugal 9.5%, Italy 9.3%,
US 4.6% (2002)
19 autonomous communities (comunidades autonomas, singular -
comunidad autonoma); Andalucia, Aragon, Asturias, Baleares (Balearic
Islands), Ceuta, Canarias (Canary Islands), Cantabria, Castilla-La
Mancha, Castilla y Leon, Cataluna, Communidad Valencian,
Extremadura, Galicia, La Rioja, Madrid, Melilla, Murcia, Navarra,
Pais Vasco (Basque Country)
note: three small Spanish possessions are located off the coast of
Morocco: Islas Chafarinas, Penon de Alhucemas, and Penon de Velez de
la Gomera; Ceuta and Melilla gained limited autonomous status in 1994
grain, vegetables, olives, wine grapes, sugar beets, citrus;
beef, pork, poultry, dairy products; fish
152 (2002)
Spratly Islands
3 (2002)
10.08 births/1,000 population (2003 est.)
Army, Navy, Air Force, Marines, Civil Guard, National Police,
Coastal Civil Guard
revenues: $105 billion
expenditures: $109 billion, including capital expenditures of $12.8
billion (2000 est.)
Spain''s mixed capitalist economy supports a GDP that on a per
capita basis is 80% that of the four leading West European
economies. Its center-right government successfully worked to gain
admission to the first group of countries launching the European
single currency (the euro) on 1 January 1999. The AZNAR
administration has continued to advocate liberalization,
privatization, and deregulation of the economy and has introduced
some tax reforms to that end. Unemployment has been steadily falling
under the AZNAR administration but remains high at 11.7%. The
government intends to make further progress in changing labor laws
and reforming pension schemes, which are key to the sustainability
of both Spain''s internal economic advances and its competitiveness
in a single currency area. A general strike in mid-2002 reduced
cooperation between labor and government. Growth of 2.4% in 2003 was
satisfactory given the background of a faltering European economy.
Adjusting to the monetary and other economic policies of an
integrated Europe - and reducing unemployment - will pose challenges
to Spain over the next few years.
Spratly Islands
Economic activity is limited to commercial fishing.
The proximity to nearby oil- and gas-producing sedimentary basins
suggests the potential for oil and gas deposits, but the region is
largely unexplored, and there are no reliable estimates of potential
reserves; commercial exploitation has yet to be developed.
gas 7,290 km; oil 730 km; refined products 3,110 km; unknown
(oil/water) 397 km (2003)','4860e9a421c299ea43d624768a9574d954dd28b104da899d62188b0aa860481f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5501f5b80403ae5f7dd7a347d5396192931dea33d36fe0b776e4f5f2b46f68d6',2003,'LK','Sri Lanka','economy',603,'The Sinhalese arrived in Sri Lanka late in the 6th century
B.C., probably from northern India. Buddhism was introduced
beginning in about the mid-third century B.C., and a great
civilization developed at the cities of Anuradhapura (kingdom from
circa 200 B.C. to circa 1000 A.D.) and Polonnaruwa (from about 1070
to 1200). In the 14th century, a south Indian dynasty seized power
in the north and established a Tamil kingdom. Occupied by the
Portuguese in the 16th century and by the Dutch in the 17th century,
the island was ceded to the British in 1796, became a crown colony
in 1802, and was united under British rule by 1815. As Ceylon, it
became independent in 1948; its name was changed to Sri Lanka in
1972. Tensions between the Sinhalese majority and Tamil separatists
erupted in violence in the mid-1980s. Tens of thousands have died in
an ethnic war that continues to fester. After two decades of
fighting, the government and Liberation Tigers of Tamil Eelam began
a ceasefire in December 2001, with Norway brokering peace
negotiations.
total: 14
over 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 6 (2002)
total: 1
under 914 m: 1 (2002)
deforestation; soil erosion; wildlife populations
threatened by poaching and urbanization; coastal degradation from
mining activities and increased pollution; freshwater resources
being polluted by industrial wastes and sewage runoff; waste
disposal; air pollution in Colombo
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
4.2% (FY98)
6.36 billion kWh (2001)
5.915 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 51.7%
hydro: 48.3%
nuclear: 0%
other: 0% (2001)
22% (1997 est.)
lowest 10%: 3.5%
highest 10%: 28% (1995)
services 45%, agriculture 38%, industry 17% (1998 est.)
textiles and apparel, tea, diamonds, coconut products,
petroleum products
US 39.1%, UK 12.9%, Belgium 4.7%, Germany 4.5% (2002)
8 provinces; Central, North Central, North Eastern, North
Western, Sabaragamuwa, Southern, Uva, Western; note - North Eastern
province may have been divided in two - Northern and Eastern
rice, sugarcane, grains, pulses, oilseed, spices, tea,
rubber, coconuts; milk, eggs, hides, beef
15 (2002)
16.12 births/1,000 population (2003 est.)
Army, Navy, Air Force, Police Force
revenues: $2.8 billion
expenditures: $4.1 billion, including capital expenditures of $NA
(2001 est.)
In 1977, Colombo abandoned statist economic policies and
its import substitution trade policy for market-oriented policies
and export-oriented trade. Sri Lanka''s most dynamic sectors now are
food processing, textiles and apparel, food and beverages,
telecommunications, and insurance and banking. By 1996 plantation
crops made up only 20% of exports (compared with 93% in 1970), while
textiles and garments accounted for 63%. GDP grew at an average
annual rate of 5.5% in the early 1990s until a drought and a
deteriorating security situation lowered growth to 3.8% in 1996. The
economy rebounded in 1997-2000 with average growth of 5.3%, but 2001
saw the first contraction in the country''s history, -1.4%, due to a
combination of power shortages, severe budgetary problems, the
global slowdown, and continuing civil strife. Growth recovered to
3.2% in 2002. About 800,000 Sri Lankans work abroad, 90% in the
Middle East. They send home about $1 billion a year.
crude oil and petroleum products 62 km (1987)','0c4e529ac34da3ff54cf30a3e80239a4630c2ac8577868f95e068af0194c81ae','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65788ecb934ae34a69215819887860405624a535985dce1d0c1ae1eea68f82c0',2003,'SD','Sudan','economy',604,'Military regimes favoring Islamic-oriented governments have
dominated national politics since independence from the UK in 1956.
Sudan has been embroiled in a civil war for all but 10 years of this
period (1972-82). The wars are rooted in northern economic,
political, and social domination of non-Muslim, non-Arab southern
Sudanese. Since 1983, the war and war- and famine-related effects
have led to more than 2 million deaths and over 4 million people
displaced. The ruling regime is a mixture of military elite and an
Islamist party that came to power in a 1989 coup. Some northern
opposition parties have made common cause with the southern rebels
and entered the war as a part of an anti-government alliance. Peace
talks gained momentum in 2002-03 with the signing of several
accords, including a cease-fire agreement.
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (2002)
total: 51
1,524 to 2,437 m: 17
914 to 1,523 m: 24
under 914 m: 10 (2002)
inadequate supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion; desertification;
periodic drought
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
2.5% (1999)
2.389 billion kWh (2001)
2.222 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 52.1%
hydro: 47.9%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 80%, industry and commerce 7%, government 13%
(1998 est.)
oil and petroleum products; cotton, sesame, livestock,
groundnuts, gum arabic, sugar
China 55.7%, Japan 14%, Saudi Arabia 4.9% (2002)
26 states (wilayat, singular - wilayah); A''ali an Nil, Al Bahr
al Ahmar, Al Buhayrat, Al Jazirah, Al Khartum, Al Qadarif, Al
Wahdah, An Nil al Abyad, An Nil al Azraq, Ash Shamaliyah, Bahr al
Jabal, Gharb al Istiwa''iyah, Gharb Bahr al Ghazal, Gharb Darfur,
Gharb Kurdufan, Janub Darfur, Janub Kurdufan, Junqali, Kassala, Nahr
an Nil, Shamal Bahr al Ghazal, Shamal Darfur, Shamal Kurdufan, Sharq
al Istiwa''iyah, Sinnar, Warab
cotton, groundnuts (peanuts), sorghum, millet, wheat, gum
arabic, sugarcane, cassava (tapioca), mangos, papaya, bananas, sweet
potatoes, sesame; sheep, livestock
63 (2002)
36.48 births/1,000 population (2003 est.)
Army, Navy, Air Force, Popular Defense Force Militia
revenues: $1.6 billion
expenditures: $1.9 billion, including capital expenditures of $NA
(2001 est.)
Sudan has turned around a struggling economy with sound
economic policies and infrastructure investments, but it still faces
formidable economic problems, notably the low level of per capita
output. From 1997 to date, Sudan has been implementing IMF
macroeconomic reforms. In 1999 Sudan began exporting crude oil and
in the last quarter of 1999 recorded its first trade surplus, which,
along with monetary policy, has stabilized the exchange rate.
Increased oil production, revived light industry, and expanded
export processing zones helped maintain GDP growth at 5.1% in 2002.
Agriculture production remains Sudan''s most important sector,
employing 80% of the work force and contributing 43% of GDP, but
most farms remain rain-fed and susceptible to drought. Chronic
domestic instability, lagging reforms, adverse weather, and weak
world agricultural prices - but, above all, the low starting point -
ensure that much of the population will remain at or below the
poverty line for years.
gas 156 km; oil 2,297 km; refined products 810 km (2003)','7de7d73c3068d281405565ab94a6e0f188901dfa78996dbafaf354c9c1935949','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4022fe55eafc53885582610858bd610efd71ff78a57296fed8f7437e19f46a59',2003,'SR','Suriname','economy',605,'Independence from the Netherlands was granted in 1975. Five
years later the civilian government was replaced by a military
regime that soon declared a socialist republic. It continued to rule
through a succession of nominally civilian administrations until
1987, when international pressure finally forced a democratic
election. In 1989, the military overthrew the civilian government,
but a democratically-elected government returned to power in 1991.
Svalbard
First discovered by the Norwegians in the 12th century, the
islands served as an international whaling base during the 17th and
18th centuries. Norway''s sovereignty was recognized in 1920; five
years later it officially took over the territory.
Swaziland
Autonomy for the Swazis of southern Africa was guaranteed
by the British in the late 19th century; independence was granted
1968. Student and labor unrest during the 1990s have pressured the
monarchy (one of the oldest on the continent) to grudgingly allow
political reform and greater democracy.
total: 5
over 3,047 m: 1
under 914 m: 4 (2002)
Svalbard
total: 2
1,524 to 2,437 m: 1
914 to 1523 m: 1 (2002)
Swaziland
total: 1
2,438 to 3,047 m: 1 (2002)
total: 41
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 35 (2002)
Svalbard
total: 2
under 914 m: 2 (2002)
Swaziland
total: 17
914 to 1,523 m: 7
under 914 m: 10 (2002)
deforestation as timber is cut for export; pollution of
inland waterways by small-scale mining activities
Svalbard
NA
Swaziland
limited supplies of potable water; wildlife populations
being depleted because of excessive hunting; overgrazing; soil
degradation; soil erosion
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
Swaziland
party to: Biodiversity, Climate Change, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Desertification, Law of the Sea
1.6% (FY97 est.)
Swaziland
4.75% (FY00)
1.959 billion kWh (2001)
Svalbard
NA kWh
Swaziland
348.3 million kWh (2001)
1.822 billion kWh (2001)
Svalbard
NA kWh
Swaziland
962.9 million kWh (2001)
0 kWh (2001)
Swaziland
639 million kWh; note - electricity supplied by South
Africa (2001)
0 kWh (2001)
Swaziland
0 kWh (2001)
fossil fuel: 25.2%
hydro: 74.8%
nuclear: 0%
other: 0% (2001)
Svalbard
fossil fuel: 58%
hydro: 42%
nuclear: 0%
other: 0%
Swaziland
fossil fuel: 58%
hydro: 42%
nuclear: 0%
other: 0% (2001)
70% (2002 est.)
Svalbard
NA%
Swaziland
40% (1995)
lowest 10%: NA%
highest 10%: NA%
Svalbard
lowest 10%: NA%
highest 10%: NA%
Swaziland
lowest 10%: 1%
highest 10%: 50.2% (1995)
agriculture NA%, industry NA%, services NA%
Swaziland
NA
alumina, crude oil, lumber, shrimp and fish, rice, bananas
Swaziland
soft drink concentrates, sugar, wood pulp, cotton yarn,
refrigerators, citrus and canned fruit
US 25.3%, Norway 20.4%, France 8.2%, Trinidad and Tobago
6.4%, Iceland 6%, Canada 5.9%, Netherlands 5.6% (2002)
Swaziland
South Africa 72%, EU 14.2%, Mozambique 3.7%, US 3.5%, UK
(1999)
10 districts (distrikten, singular - distrikt); Brokopondo,
Commewijne, Coronie, Marowijne, Nickerie, Para, Paramaribo,
Saramacca, Sipaliwini, Wanica
Swaziland
4 districts; Hhohho, Lubombo, Manzini, Shiselweni
paddy rice, bananas, palm kernels, coconuts, plantains,
peanuts; beef, chickens; forest products; shrimp
Swaziland
sugarcane, cotton, corn, tobacco, rice, citrus,
pineapples, sorghum, peanuts; cattle, goats, sheep
46 (2002)
Svalbard
4 (2002)
Swaziland
18 (2002)
19.4 births/1,000 population (2003 est.)
Svalbard
NA births/1,000 population (2003 est.)
Swaziland
29.37 births/1,000 population (2003 est.)
National Army (including small Navy and Air Force
elements), Civil Police
Swaziland
Umbutfo Swaziland Defense Force (Army), Royal Swaziland
Police Force
revenues: $393 million
expenditures: $403 million, including capital expenditures of $34
million (1997 est.)
Svalbard
revenues: $11.5 million
expenditures: $11.5 million, including capital expenditures of $NA
(1998 est.)
Swaziland
revenues: $448 million
expenditures: $506.9 million, including capital expenditures of $147
million (FY 01/02)
The economy is dominated by the bauxite industry, which
accounts for more than 15% of GDP and 70% of export earnings.
Suriname''s economic prospects for the medium term will depend on
renewed commitment to responsible monetary and fiscal policies and
to the introduction of structural reforms to liberalize markets and
promote competition. The government of Ronald VENETIAAN has begun an
austerity program, raised taxes, and attempted to control spending.
However, in 2002, President VENETIAAN agreed to a large pay raise
for civil servants, which threatens his earlier gains in stabilizing
the economy. The Dutch Government has agreed to restart the aid
flow, which will allow Suriname to access international development
financing. The short-term economic outlook depends on the
government''s ability to control inflation and on the development of
projects in the bauxite and gold mining sectors.
Svalbard
Coal mining is the major economic activity on Svalbard. The
treaty of 9 February 1920 gives the 41 signatories equal rights to
exploit mineral deposits, subject to Norwegian regulation. Although
US, UK, Dutch, and Swedish coal companies have mined in the past,
the only companies still mining are Norwegian and Russian. The
settlements on Svalbard are essentially company towns. The Norwegian
state-owned coal company employs nearly 60% of the Norwegian
population on the island, runs many of the local services, and
provides most of the local infrastructure. There is also some
trapping of seal, polar bear, fox, and walrus.
Swaziland
In this small, landlocked economy, subsistence agriculture
occupies more than 80% of the population. The manufacturing sector
has diversified since the mid-1980s. Sugar and wood pulp remain
important foreign exchange earners. Mining has declined in
importance in recent years with only coal and quarry stone mines
remaining active. Surrounded by South Africa, except for a short
border with Mozambique, Swaziland is heavily dependent on South
Africa from which it receives nine-tenths of its imports and to
which it sends more than two-thirds of its exports. Customs duties
from the Southern African Customs Union and worker remittances from
South Africa substantially supplement domestically earned income.
The government is trying to improve the atmosphere for foreign
investment. Overgrazing, soil depletion, drought, and sometimes
floods persist as problems for the future. More than one-fourth of
the population needed emergency food aid in 2002 because of drought,
and more than one-third of the adult population was infected by
HIV/AIDS.
oil 51 km (2003)','71e6cde515ee12cda0dc1e64a3e1431bf975d7e14c228a0f6c4e7e428303e114','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e1ddcf8fdafcf1b53475a40ca77391233d356fae4b4ac7df778e9e989509571',2003,'SE','Sweden','economy',606,'A military power during the 17th century, Sweden has not
participated in any war in almost two centuries. An armed neutrality
was preserved in both World Wars. Sweden''s long-successful economic
formula of a capitalist system interlarded with substantial welfare
elements was challenged in the 1990s by high unemployment, rising
maintenance costs, and a declining position in world markets.
Indecision over the country''s role in the political and economic
integration of Europe delayed Sweden''s entry into the EU until 1995,
and waived the introduction of the euro in 1999.
total: 145
over 3,047 m: 3
2,438 to 3,047 m: 11
1,524 to 2,437 m: 82
914 to 1,523 m: 24
under 914 m: 25 (2002)
total: 100
914 to 1,523 m: 10
under 914 m: 90 (2002)
acid rain damage to soils and lakes; pollution of the North
Sea and the Baltic Sea
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
2.1% (FY01)
152.9 billion kWh (2001)
134.9 billion kWh (2001)
11.14 billion kWh (2001)
18.45 billion kWh (2001)
fossil fuel: 4%
hydro: 50.8%
nuclear: 43%
other: 2.3% (2001)
NA%
lowest 10%: 3.7%
highest 10%: 20.1% (1992)
agriculture 2%, industry 24%, services 74% (2000 est.)
machinery 35%, motor vehicles, paper products, pulp and wood,
iron and steel products, chemicals
US 11.6%, Germany 10.1%, Norway 9%, UK 8.2%, Denmark 5.9%,
Finland 5.6%, Netherlands 5.3%, France 5.1%, Belgium 4.7% (2002)
21 counties (lan, singular and plural); Blekinge, Dalarnas,
Gavleborgs, Gotlands, Hallands, Jamtlands, Jonkopings, Kalmar,
Kronobergs, Norrbottens, Orebro, Ostergotlands, Skane,
Sodermanlands, Stockholms, Uppsala, Varmlands, Vasterbottens,
Vasternorrlands, Vastmanlands, Vastra Gotalands
barley, wheat, sugar beets; meat, milk
245 (2002)
9.71 births/1,000 population (2003 est.)
Army, Royal Navy (including Coast Artillery and Naval
Helicopter Service), Air Force
revenues: $119 billion
expenditures: $110 billion, including capital expenditures of $NA
(2001 est.)
Aided by peace and neutrality for the whole 20th century,
Sweden has achieved an enviable standard of living under a mixed
system of high-tech capitalism and extensive welfare benefits. It
has a modern distribution system, excellent internal and external
communications, and a skilled labor force. Timber, hydropower, and
iron ore constitute the resource base of an economy heavily oriented
toward foreign trade. Privately owned firms account for about 90% of
industrial output, of which the engineering sector accounts for 50%
of output and exports. Agriculture accounts for only 2% of GDP and
2% of the jobs. The government''s commitment to fiscal discipline
resulted in a substantial budgetary surplus in 2001, which was cut
by more than half in 2002, due to the global economic slowdown,
revenue declines, and spending increases. The Swedish central bank
(the Riksbank) is focusing on price stability with its inflation
target of 2%. Growth remained sluggish in 2003. On September 14,
2003, Swedish voters turned down entry into the euro system,
concerned about the impact on democracy and sovereignty.
gas 798 km (2003)','dd7a6347d24a100ea057a307d19fdede0c1273806f19aa35ec35c8bc8584fb77','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98763dd23d7a9bc4f2da38a62fed54b9077dedd551b40dd1ef8aa9c10bf4df2b',2003,'CH','Switzerland','economy',607,'Switzerland''s independence and neutrality have long been
honored by the major European powers, and Switzerland was not
involved in either of the two World Wars. The political and economic
integration of Europe over the past half century, as well as
Switzerland''s role in many UN and international organizations, has
strengthened Switzerland''s ties with its neighbors. However, the
country did not officially become a UN member until 2002.
Switzerland remains active in many UN and international
organizations, but retains a strong commitment to neutrality.
Syria
Following the breakup of the Ottoman Empire during World War
I, Syria was administered by the French until independence in 1946.
In the 1967 Arab-Israeli War, Syria lost the Golan Heights to
Israel. Since 1976, Syrian troops have been stationed in Lebanon,
ostensibly in a peacekeeping capacity. In recent years, Syria and
Israel have held occasional peace talks over the return of the Golan
Heights.
Taiwan
In 1895, military defeat forced China to cede Taiwan to
Japan. It reverted to Chinese control after World War II. Following
the Communist victory on the mainland in 1949, 2 million
Nationalists fled to Taiwan and established a government using the
1947 constitution drawn up for all of China. Over the next five
decades, the ruling authorities gradually democratized and
incorporated the native population within the governing structure.
In 2000, Taiwan underwent its first peaceful transfer of power from
the Nationalist to the Democratic Progressive Party. Throughout this
period, the island prospered and became one of East Asia''s economic
"Tigers." The dominant political issues continue to be the
relationship between Taiwan and China - specifically the question of
eventual unification - as well as domestic political and economic
reform.
total: 41
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 9
under 914 m: 14 (2002)
Syria
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 2
under 914 m: 1 (2002)
Taiwan
total: 37
over 3,047 m: 8
2,438 to 3,047 m: 8
1,524 to 2,437 m: 11
914 to 1,523 m: 8
under 914 m: 2 (2002)
total: 25
1524 to 2437 m: 1
under 914 m: 24 (2002)
Syria
total: 68
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 55 (2002)
Taiwan
total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2002)
air pollution from vehicle emissions and open-air
burning; acid rain; water pollution from increased use of
agricultural fertilizers; loss of biodiversity
Syria
deforestation; overgrazing; soil erosion; desertification;
water pollution from raw sewage and petroleum refining wastes;
inadequate potable water
Taiwan
air pollution; water pollution from industrial emissions, raw
sewage; contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste disposal
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur
85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol, Law of the Sea
Syria
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
Taiwan
party to: none of the selected agreements because of Taiwan''s
international status
signed, but not ratified: none of the selected agreements because of
Taiwan''s international status
1% (FY01)
Syria
5.9% (FY00)
Taiwan
2.7% (FY02)
68.68 billion kWh (2001)
Syria
23.26 billion kWh (2001)
Taiwan
151.1 billion kWh (2001)
53.43 billion kWh (2001)
Syria
21.63 billion kWh (2001)
Taiwan
140.5 billion kWh (2001)
24.1 billion kWh (2001)
Syria
0 kWh (2001)
Taiwan
0 kWh (2001)
34.54 billion kWh (2001)
Syria
0 kWh (2001)
Taiwan
0 kWh (2001)
fossil fuel: 1.3%
hydro: 59.5%
nuclear: 37.1%
other: 2% (2001)
Syria
fossil fuel: 57.6%
hydro: 42.4%
nuclear: 0%
other: 0% (2001)
Taiwan
fossil fuel: 71.4%
hydro: 6%
nuclear: 22.6%
other: 0% (2001)
NA%
Syria
15%-25%
Taiwan
1% (2000 est.)
lowest 10%: 2.6%
highest 10%: 25.2% (1992)
Syria
lowest 10%: NA%
highest 10%: NA%
Taiwan
lowest 10%: 6.4%
highest 10%: 41.1% (2002 est.)
services 69.1%, industry 26.3%, agriculture 4.6% (1998)
Syria
agriculture, industry, services NA (2002)
Taiwan
services 58%, industry 35%, agriculture 7% (2001 est.)
machinery, chemicals, metals, watches, agricultural
products
Syria
crude oil 70%, petroleum products 7%, fruits and vegetables
5%, cotton fiber 4%, clothing 3%, meat and live animals 2% (2000
est.)
Taiwan
machinery and electrical equipment 54%, metals, textiles,
plastics, chemicals (2002)
Germany 19.2%, US 10.2%, Italy 9.6%, France 8.9%, UK
7.7% (2002)
Syria
Germany 19.1%, Italy 17.5%, Turkey 7.8%, France 7.5%, Lebanon
5.2% (2002)
Taiwan
Hong Kong 23.9%, US 20.8%, Japan 9.3%, China 7.7% (2002)
26 cantons (cantons, singular - canton in French;
cantoni, singular - cantone in Italian; kantone, singular - kanton
in German); Aargau, Appenzell Ausser-Rhoden, Appenzell Inner-Rhoden,
Basel-Landschaft, Basel-Stadt, Bern, Fribourg, Geneve, Glarus,
Graubunden, Jura, Luzern, Neuchatel, Nidwalden, Obwalden, Sankt
Gallen, Schaffhausen, Schwyz, Solothurn, Thurgau, Ticino, Uri,
Valais, Vaud, Zug, Zurich
Syria
14 provinces (muhafazat, singular - muhafazah); Al Hasakah, Al
Ladhiqiyah, Al Qunaytirah, Ar Raqqah, As Suwayda'', Dar''a, Dayr az
Zawr, Dimashq, Halab, Hamah, Hims, Idlib, Rif Dimashq, Tartus
Taiwan
the central administrative divisions include the provinces of
Fu-chien (some 20 offshore islands of Fujian Province including
Quemoy and Matsu) and Taiwan (the island of Taiwan and the
Pescadores islands); Taiwan is further subdivided into 16 counties
(hsien, singular and plural), 5 municipalities* (shih, singular and
plural), and 2 special municipalities** (chuan-shih, singular and
plural); Chang-hua, Chia-i, Chia-i*, Chi-lung*, Hsin-chu, Hsin-chu*,
Hua-lien, I-lan, Kao-hsiung, Kao-hsiung**, Miao-li, Nan-t''ou,
P''eng-hu, P''ing-tung, T''ai-chung, T''ai-chung*, T''ai-nan, T''ai-nan*,
T''ai-pei, T''ai-pei**, T''ai-tung, T''ao-yuan, and Yun-lin; the
provincial capital is at Chung-hsing-hsin-ts''un
note: Taiwan uses the Wade-Giles system for romanization
grains, fruits, vegetables; meat, eggs
Syria
wheat, barley, cotton, lentils, chickpeas, olives, sugar
beets; beef, mutton, eggs, poultry, milk
Taiwan
rice, corn, vegetables, fruit, tea; pigs, poultry, beef,
milk; fish
66 (2002)
Syria
92 (2002)
Taiwan
39 (2002)
9.59 births/1,000 population (2003 est.)
Syria
29.54 births/1,000 population (2003 est.)
Taiwan
12.74 births/1,000 population (2003 est.)
Army, Air Force, Frontier Guards, Fortification Guards
Syria
Syrian Arab Army, Syrian Arab Navy, Syrian Arab Air Force
(includes Air Defense Forces), Police and Security Force
Taiwan
Army, Navy (including Marine Corps), Air Force, Coast Guard
Administration, Armed Forces Reserve Command, Combined Service
Forces Command
revenues: $30 billion
expenditures: $30 billion, including capital expenditures of $NA
(2001 est.)
Syria
revenues: $6 billion
expenditures: $7 billion, including capital expenditures of $3.6
billion (2002 est.)
Taiwan
revenues: $36 billion
expenditures: $36.1 billion, including capital expenditures of $NA
(2002 est.)
Switzerland is a prosperous and stable modern market
economy with low unemployment, a highly skilled labor force, and a
per capita GDP larger than that of the big western European
economies. The Swiss in recent years have brought their economic
practices largely into conformity with the EU''s to enhance their
international competitiveness. Switzerland remains a safe haven for
investors, because it has maintained a degree of bank secrecy and
has kept up the franc''s long-term external value. Reflecting the
anemic economic conditions of Europe, GDP growth dropped in 2001 to
about 0.8%, to 0.2% in 2002, and to -0.3% in 2003.
Syria
Syria''s predominantly statist economy has been growing, on
average, more slowly than its 2.4% annual population growth rate,
causing a persistent decline in per capita GDP. Recent legislation
allows private banks to operate in Syria, although a private banking
sector will take years and further government cooperation to
develop. External factors such as the international war on
terrorism, the Israeli-Palestinian conflict, and the war between the
US-led coalition and Iraq probably will drive real annual GDP growth
levels back below their 3.5% spike in 2002. A long-run economic
constraint is the pressure on water supplies caused by rapid
population growth, industrial expansion, and increased water
pollution.
Taiwan
Taiwan has a dynamic capitalist economy with gradually
decreasing guidance of investment and foreign trade by government
authorities. In keeping with this trend, some large government-owned
banks and industrial firms are being privatized. Exports have
provided the primary impetus for industrialization. The trade
surplus is substantial, and foreign reserves are the world''s third
largest. Agriculture contributes 2% to GDP, down from 32% in 1952.
While Taiwan is a major investor throughout Southeast Asia, China
has become the largest destination for investment and has overtaken
the US to become Taiwan''s largest export market. Because of its
conservative financial approach and its entrepreneurial strengths,
Taiwan suffered little compared with many of its neighbors from the
Asian financial crisis in 1998. The global economic downturn,
combined with problems in policy coordination by the administration
and bad debts in the banking system, pushed Taiwan into recession in
2001, the first year of negative growth ever recorded. Unemployment
also reached record levels. Output recovered moderately in 2002 in
the face of continued global slowdown, fragile consumer confidence,
and bad bank loans. Growing economic ties with China are a dominant
long-term factor. Exports to China - mainly parts and equipment for
the assembly of goods for export to developed countries - drove
Taiwan''s economic recovery in 2002.
gas 1,831 km; oil 212 km; refined products 7 km (2003)
Syria
gas 2,300 km; oil 2,183 km (2003)
Taiwan
condensate 25 km; gas 435 km (2003)','8c6ed0ae614d99e3834a92616eb28f71aebe69a3d7341fdd25ea8d1186b09190','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31d917d15d46106c23a83189e39a693d50ef9cb8d70a6b4dbfc8b14d823cd0f0',2003,'TJ','Tajikistan','economy',608,'Tajikistan has experienced three changes in government
and a five-year civil war since it gained independence in 1991 from
the USSR. A peace agreement among rival factions was signed in 1997,
and implemented in 2000. The central government''s less than total
control over some areas of the country has forced it to compromise
and forge alliances among factions. Attention by the international
community in the wake of the war in Afghanistan has brought
increased economic development assistance, which could create jobs
and increase stability in the long term. Tajikistan is in the early
stages of seeking World Trade Organization membership and has joined
NATO''s Partnership for Peace.
Tanzania
Shortly after independence, Tanganyika and Zanzibar merged
to form the nation of Tanzania in 1964. One-party rule came to an
end in 1995 with the first democratic elections held in the country
since the 1970s. Zanzibar''s semi-autonomous status and popular
opposition have led to two contentious elections since 1995, which
the ruling party won despite international observers'' claims of
voting irregularities.
total: 13
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2002)
Tanzania
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 53
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 36 (2002)
Tanzania
total: 112
1,524 to 2,437 m: 18
914 to 1,523 m: 60
under 914 m: 34 (2002)
inadequate sanitation facilities; increasing levels of
soil salinity; industrial pollution; excessive pesticides
Tanzania
soil degradation; deforestation; desertification;
destruction of coral reefs threatens marine habitats; recent
droughts affected marginal agriculture; wildlife threatened by
illegal hunting and trade, especially for ivory
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Tanzania
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: Nuclear Test Ban
3.9% (FY01)
Tanzania
0.2% (FY02)
14.18 billion kWh (2001)
Tanzania
2.906 billion kWh (2001)
14.52 billion kWh (2001)
Tanzania
2.752 billion kWh (2001)
5.242 billion kWh (2001)
Tanzania
50 million kWh (2001)
3.909 billion kWh (2001)
Tanzania
0 kWh (2001)
fossil fuel: 1.9%
hydro: 98.1%
nuclear: 0%
other: 0% (2001)
Tanzania
fossil fuel: 18.9%
hydro: 81.1%
nuclear: 0%
other: 0% (2001)
60% (2001 est.)
Tanzania
36% (2002 est.)
lowest 10%: 3.2%
highest 10%: 25.2% (1998)
Tanzania
lowest 10%: 2.8%
highest 10%: 30.1% (1993)
agriculture 67.2%, industry 7.5%, services 25.3% (2000
est.)
Tanzania
agriculture 80%, industry and services 20% (2002 est.)
aluminum, electricity, cotton, fruits, vegetable oil,
textiles
Tanzania
gold, coffee, cashew nuts, manufactures, cotton
Netherlands 29.4%, Turkey 16.1%, Russia 11.9%, Uzbekistan
9.9%, Switzerland 9.3%, Hungary 5.4%, Latvia 4.2% (2002)
Tanzania
India 15.2%, Japan 12.4%, Netherlands 9.2%, UK 6.8%,
Belgium 6.5%, Kenya 5.9%, Germany 4.8% (2002)
2 provinces (viloyatho, singular - viloyat) and 1
autonomous province* (viloyati mukhtor); Viloyati Mukhtori Kuhistoni
Badakhshon* (Khorugh), Viloyati Khatlon (Qurghonteppa), Viloyati
Sughd (Khujand)
note: the administrative center name follows in parentheses
Tanzania
25 regions; Arusha, Dar es Salaam, Dodoma, Iringa, Kagera,
Kigoma, Kilimanjaro, Lindi, Mara, Mbeya, Morogoro, Mtwara, Mwanza,
Pemba North, Pemba South, Pwani, Rukwa, Ruvuma, Shinyanga, Singida,
Tabora, Tanga, Zanzibar Central/South, Zanzibar North, Zanzibar
Urban/West
cotton, grain, fruits, grapes, vegetables; cattle, sheep,
goats
Tanzania
coffee, sisal, tea, cotton, pyrethrum (insecticide made
from chrysanthemums), cashew nuts, tobacco, cloves, corn, wheat,
cassava (tapioca), bananas, fruits, vegetables; cattle, sheep, goats
66 (2002)
Tanzania
123 (2002)
32.78 births/1,000 population (2003 est.)
Tanzania
39.5 births/1,000 population (2003 est.)
Army, Air Force and Air Defense Force, Presidential
National Guard, Security Forces (internal and border troops)
Tanzania
Tanzanian People''s Defense Force (including Army, Navy, and
Air Force), paramilitary Police Field Force Unit (including Police
Marine Unit and Police Air Wing), territorial militia
revenues: $502 million
expenditures: $520 million, including capital expenditures of $86
million (2002 est.)
Tanzania
revenues: $1.01 billion
expenditures: $1.38 billion, including capital expenditures of $NA
(FY 00/01 est.)
Tajikistan has the lowest per capita GDP among the 15
former Soviet republics. Only 8% to 10% of the land area is arable.
Cotton is the most important crop. Mineral resources, varied but
limited in amount, include silver, gold, uranium, and tungsten.
Industry consists only of a large aluminum plant, hydropower
facilities, and small obsolete factories mostly in light industry
and food processing. The civil war (1992-97) severely damaged the
already weak economic infrastructure and caused a sharp decline in
industrial and agricultural production. Even though 60% of its
people continue to live in abject poverty, Tajikistan has
experienced steady economic growth since 1997. Continued
privatization of medium and large state-owned enterprises will
further increase productivity. Tajikistan''s economic situation,
however, remains fragile due to uneven implementation of structural
reforms, weak governance, widespread unemployment, and the external
debt burden. A debt restructuring agreement was reached with Russia
in December 2002, including an interest rate of 4%, a 3-year grace
period, and a US $49.8 million credit to the Central Bank of
Tajikistan.
Tanzania
Tanzania is one of the poorest countries in the world. The
economy depends heavily on agriculture, which accounts for half of
GDP, provides 85% of exports, and employs 80% of the work force.
Topography and climatic conditions, however, limit cultivated crops
to only 4% of the land area. Industry traditionally featured the
processing of agricultural products and light consumer goods. The
World Bank, the International Monetary Fund, and bilateral donors
have provided funds to rehabilitate Tanzania''s out-of-date economic
infrastructure and to alleviate poverty. Growth in 1991-2002
featured a pickup in industrial production and a substantial
increase in output of minerals, led by gold. Oil and gas exploration
and development played an important role in this growth. Recent
banking reforms have helped increase private sector growth and
investment. Continued donor support and solid macroeconomic policies
should support continued real GDP growth of 5% in 2003.
gas 540 km; oil 38 km (2003)
Tanzania
gas 5 km; oil 866 km (2003)','7e38a64c45465f0b72545421ae62f2fafc3d576bb12ec688af3999571a441983','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb693c3f1dbef89a225734cc195b1d6bb0b970cf64e5932be3973c9e34825439',2003,'TH','Thailand','economy',609,'A unified Thai kingdom was established in the mid-14th
century. Known as Siam until 1939, Thailand is the only Southeast
Asian country never to have been taken over by a European power. A
bloodless revolution in 1932 led to a constitutional monarchy. In
alliance with Japan during World War II, Thailand became a US ally
following the conflict.
total: 62
over 3,047 m: 7
2,438 to 3,047 m: 10
1,524 to 2,437 m: 23
914 to 1,523 m: 17
under 914 m: 5 (2002)
total: 49
1,524 to 2,437 m: 1
914 to 1,523 m: 17
under 914 m: 31 (2002)
air pollution from vehicle emissions; water pollution from
organic and factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
party to: Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Biodiversity, Climate Change-Kyoto
Protocol, Law of the Sea
1.4% (FY00)
97.6 billion kWh (2001)
90.91 billion kWh (2001)
350 million kWh (2001)
200 million kWh (2001)
fossil fuel: 91.3%
hydro: 6.4%
nuclear: 0%
other: 2.4% (2001)
12.5% (1998 est.)
lowest 10%: 2.8%
highest 10%: 32.4% (1998)
agriculture 54%, industry 15%, services 31% (1996 est.)
computers, transistors, seafood, clothing, rice (2000)
US 19.6%, Japan 14.5%, Singapore 8.1%, Hong Kong 5.4%,
China 5.2%, Malaysia 4.1% (2002)
76 provinces (changwat, singular and plural); Amnat
Charoen, Ang Thong, Buriram, Chachoengsao, Chai Nat, Chaiyaphum,
Chanthaburi, Chiang Mai, Chiang Rai, Chon Buri, Chumphon, Kalasin,
Kamphaeng Phet, Kanchanaburi, Khon Kaen, Krabi, Krung Thep
Mahanakhon (Bangkok), Lampang, Lamphun, Loei, Lop Buri, Mae Hong
Son, Maha Sarakham, Mukdahan, Nakhon Nayok, Nakhon Pathom, Nakhon
Phanom, Nakhon Ratchasima, Nakhon Sawan, Nakhon Si Thammarat, Nan,
Narathiwat, Nong Bua Lamphu, Nong Khai, Nonthaburi, Pathum Thani,
Pattani, Phangnga, Phatthalung, Phayao, Phetchabun, Phetchaburi,
Phichit, Phitsanulok, Phra Nakhon Si Ayutthaya, Phrae, Phuket,
Prachin Buri, Prachuap Khiri Khan, Ranong, Ratchaburi, Rayong, Roi
Et, Sa Kaeo, Sakon Nakhon, Samut Prakan, Samut Sakhon, Samut
Songkhram, Sara Buri, Satun, Sing Buri, Sisaket, Songkhla,
Sukhothai, Suphan Buri, Surat Thani, Surin, Tak, Trang, Trat, Ubon
Ratchathani, Udon Thani, Uthai Thani, Uttaradit, Yala, Yasothon
rice, cassava (tapioca), rubber, corn, sugarcane, coconuts,
soybeans
111 (2002)
16.37 births/1,000 population (2003 est.)
Royal Thai Army, Royal Thai Navy (includes Royal Thai
Marine Corps), Royal Thai Air Force, paramilitary forces (includes
the Border Patrol Police [including Police Aerial Reinforcement
Unit], Thahan Phran, Special Action Forces, Police Aviation
Division, Thai Marine Police, and the Volunteer Defense Corps)
revenues: $19 billion
expenditures: $21 billion, including capital expenditures of $NA
(2000 est.)
Thailand has a free enterprise economy and welcomes foreign
investment. Exports feature computers and electrical appliances.
After enjoying the world''s highest growth rate from 1985 to 1995 -
averaging almost 9% annually - increased speculative pressure on
Thailand''s currency in 1997 led to a crisis that uncovered financial
sector weaknesses and forced the government to float the baht. Long
pegged at 25 to the dollar, the baht reached its lowest point of 56
to the dollar in January 1998, and the economy contracted by 10.2%
that same year. Thailand then entered a recovery stage, expanding by
4.2% in 1999 and 4.4% in 2000, largely due to strong exports. An
ailing financial sector and the slow pace of corporate debt
restructuring, combined with a softening of global demand, slowed
growth to 1.4% in 2001. Increased consumption and investment
spending pushed GDP growth up to 5.2% in 2002 despite a sluggish
global economy.
gas 3,066 km; refined products 265 km (2003)','9229d0b048bf01b5336b24fe40050cdc52f496c34b04e8edec1cb606b4bdec26','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c05c71f5d47bd8458c0752c9fa0d7163ad2566ff6d42cd9a6dee5e6d85a7f411',2003,'TK','Tokelau','economy',610,'Originally settled by Polynesian emigrants from surrounding
island groups, the Tokelau Islands were made a British protectorate
in 1889. They were transferred to New Zealand administration in 1925.
very limited natural resources and overcrowding are
contributing to emigration to New Zealand
NA kWh
NA kWh
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
stamps, copra, handicrafts
NZ (2000)
none (territory of New Zealand)
coconuts, copra, breadfruit, papayas, bananas; pigs,
poultry, goats
none; lagoon landings are possible by amphibious aircraft
(2002)
NA births/1,000 population (2003 est.)
revenues: $430,830
expenditures: $2.8 million, including capital expenditures of
$37,300 (1987 est.)
Tokelau''s small size (three villages), isolation, and lack
of resources greatly restrain economic development and confine
agriculture to the subsistence level. The people rely heavily on aid
from New Zealand - about $4 million annually - to maintain public
services, with annual aid being substantially greater than GDP. The
principal sources of revenue come from sales of copra, postage
stamps, souvenir coins, and handicrafts. Money is also remitted to
families from relatives in New Zealand.','a786335f38fb74a6d949e4111cd9b3c29ecf3c3fd9d3aecc046a5dc6a0ee1034','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a97116c80540d4f838ee1fe54104c103031430e3c99fe3b4079186f734a42d4',2003,'TO','Tonga','economy',611,'The archipelago of "The Friendly Islands" was united into a
Polynesian kingdom in 1845. It became a constitutional monarchy in
1875 and a British protectorate in 1900. Tonga acquired its
independence in 1970 and became a member of the Commonwealth of
Nations. It remains the only monarchy in the Pacific.
total: 1
2,438 to 3,047 m: 1 (2002)
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2002)
deforestation results as more and more land is being cleared
for agriculture and settlement; some damage to coral reefs from
starfish and indiscriminate coral and shell collectors; overhunting
threatens native sea turtle populations
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA%
27.27 million kWh (2001)
25.36 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 65% (1997 est.)
squash, fish, vanilla beans, root crops
Japan 43.2%, US 41.2%, Greece 4% (2002)
3 island groups; Ha''apai, Tongatapu, Vava''u
squash, coconuts, copra, bananas, vanilla beans, cocoa,
coffee, ginger, black pepper; fish
6 (2002)
24.51 births/1,000 population (2003 est.)
Tonga Defense Services (made up of three operational command
components and two support elements, including the Royal Marines,
Royal Guards, Maritime Force, a support/logistics group, and a
training group), Police; note - a new air wing that will be
subordinate to the Ministry of Defense is being developed
revenues: $39.9 million
expenditures: $52.4 million, including capital expenditures of $1.9
million (FY 99/00 est.)
Tonga has a small, open economy with a narrow export base in
agricultural goods. Squash, coconuts, bananas, and vanilla beans are
the main crops, and agricultural exports make up two-thirds of total
exports. The country must import a high proportion of its food,
mainly from New Zealand. Tourism is the second-largest source of
hard currency earnings following remittances. The country remains
dependent on external aid and remittances from Tongan communities
overseas to offset its trade deficit. The government is emphasizing
the development of the private sector, especially the encouragement
of investment, and is committing increased funds for health and
education. Tonga has a reasonably sound basic infrastructure and
well-developed social services.','c34f9447d09250c4bc7e7f0c064b3f59ed9f10fc569506773c118d04880368b8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcaab266036009d4fb9e8147bf8c2effd63cdd5f8fdf27c82f13050795b39eb9',2003,'TT','Trinidad and Tobago','economy',612,'The islands came under British control in the
19th century; independence was granted in 1962. The country is one
of the most prosperous in the Caribbean, thanks largely to petroleum
and natural gas production and processing. Tourism, mostly in
Tobago, is targeted for expansion and is growing.
Tromelin Island
First explored by the French in 1776, the island
came under the jurisdiction of Reunion in 1814. At present, it
serves as a sea turtle sanctuary and is the site of an important
meteorological station.
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2002)
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2002)
Tromelin Island
total: 1
under 914 m: 1 (2002)
water pollution from agricultural chemicals,
industrial wastes, and raw sewage; oil pollution of beaches;
deforestation; soil erosion
Tromelin Island
NA
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
1.4% (1999)
5.315 billion kWh (2001)
4.943 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 99.8%
hydro: 0%
nuclear: 0%
other: 0.2% (2001)
21% (1992 est.)
lowest 10%: NA%
highest 10%: NA%
construction and utilities 12.4%, manufacturing,
mining, and quarrying 14%, agriculture 9.5%, services 64.1% (1997
est.)
petroleum and petroleum products, chemicals,
steel products, fertilizer, sugar, cocoa, coffee, citrus, flowers
US 56.9%, Jamaica 7.3%, France 4.4% (2002)
8 counties, 3 municipalities*, and 1 ward**;
Arima*, Caroni, Mayaro, Nariva, Port-of-Spain*, Saint Andrew, Saint
David, Saint George, Saint Patrick, San Fernando*, Tobago**, Victoria
cocoa, sugarcane, rice, citrus, coffee,
vegetables; poultry
6 (2002)
Tromelin Island
1 (2002)
12.74 births/1,000 population (2003 est.)
Trinidad and Tobago Defense Force (including
Ground Force, Coast Guard, and Air Wing), Trinidad and Tobago Police
Service
revenues: $1.54 billion
expenditures: $1.6 billion, including capital expenditures of $117.3
million (1998)
Trinidad and Tobago has earned a reputation as
an excellent investment site for international businesses. A leading
performer the past four years has been the booming natural gas
sector. Tourism is a growing sector, although not proportionately as
important as in many other Caribbean islands. The economy benefits
from low inflation and a trade surplus. The year 2002 was marked by
solid growth in the oil sector, offset in part by domestic political
uncertainty.
Tromelin Island
no economic activity
condensate 253 km; gas 1,117 km; oil 478 km
(2003)','ea94ce6a9977bb4a11af63fee593067f697fa10942b2aa7e6a2b86531fea72fe','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c04e35cd7febfec5526c078359e6290e5b19c2bf57e810c12dff624da0d9b8f1',2003,'TN','Tunisia','economy',613,'Following independence from France in 1956, President Habib
BOURGUIBA established a strict one-party state. He dominated the
country for 31 years, repressing Islamic fundamentalism and
establishing rights for women unmatched by any other Arab nation. In
recent years, Tunisia has taken a moderate, non-aligned stance in
its foreign relations. Domestically, it has sought to defuse rising
pressure for a more open political society.
Turkey
Present-day Turkey was created in 1923 from the Turkish
remnants of the Ottoman Empire. Soon thereafter, the country
instituted secular laws to replace traditional religious fiats. In
1945 Turkey joined the UN, and in 1952 it became a member of NATO.
Turkey intervened militarily on Cyprus in 1974 to protect Turkish
Cypriots and prevent a Greek takeover of the island; the northern 37
percent of the island remains under Turkish Cypriot control.
Relations between the two countries remain strained, but have begun
to improve over the past few years. In 1984, the Kurdistan Workers''
Party (PKK), a Marxist-Leninist, separatist group, initiated an
insurgency in southeast Turkey, often using terrorist tactics to try
to attain its goal of an independent Kurdistan. The group - whose
leader, Abdullah OCALAN, was captured in Kenya in February 1999 -
has observed a unilateral cease-fire since September 1999, although
there have been occasional clashes between Turkish military units
and some of the 4,000-5,000 armed PKK militants, most of whom
currently are encamped in northern Iraq. The PKK changed its name to
the Kurdistan Freedom and Democracy Congress (KADEK) in April 2002.
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (2002)
Turkey
total: 86
over 3,047 m: 16
2,438 to 3,047 m: 30
1,524 to 2,437 m: 19
914 to 1,523 m: 16
under 914 m: 5 (2002)
total: 16
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 7 (2002)
Turkey
total: 34
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 24 (2002)
toxic and hazardous waste disposal is ineffective and poses
health risks; water pollution from raw sewage; limited natural fresh
water resources; deforestation; overgrazing; soil erosion;
desertification
Turkey
water pollution from dumping of chemicals and detergents; air
pollution, particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Turkey
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol,
Environmental Modification
1.5% (FY99)
Turkey
4.5% (2002 est.)
10.48 billion kWh (2001)
Turkey
116.6 billion kWh (2001)
9.748 billion kWh (2001)
Turkey
112.6 billion kWh (2001)
1 million kWh (2001)
Turkey
4.579 billion kWh (2001)
0 kWh (2001)
Turkey
433 million kWh (2001)
fossil fuel: 99.5%
hydro: 0.5%
nuclear: 0%
other: 0% (2001)
Turkey
fossil fuel: 79.3%
hydro: 20.4%
nuclear: 0%
other: 0.3% (2001)
6% (2000 est.)
Turkey
NA%
lowest 10%: 2.3%
highest 10%: 31.8% (1995)
Turkey
lowest 10%: 2.3%
highest 10%: 32.3% (1994)
services 55%, industry 23%, agriculture 22% (1995 est.)
Turkey
agriculture 39.7%, services 37.9%, industry 22.4% (3rd
quarter, 2001)
textiles, mechanical goods, phosphates and chemicals,
agricultural products, hydrocarbons
Turkey
apparel, foodstuffs, textiles, metal manufactures, transport
equipment
France 31.3%, Italy 21.6%, Germany 11.5%, Spain 4.8%, Libya
4.7%, Belgium 4.3% (2002)
Turkey
Germany 16.6%, US 9.2%, UK 8.5%, Italy 6.4%, France 6% (2002)
24 governorates; Ariana (Aryanah), Beja (Bajah), Ben Arous
(Bin ''Arus), Bizerte (Banzart), Gabes (Qabis), Gafsa (Qafsah),
Jendouba (Jundubah), Kairouan (Al Qayrawan), Kasserine (Al Qasrayn),
Kebili (Qibili), Kef (Al Kaf), Mahdia (Al Mahdiyah), Manouba
(Manubah), Medenine (Madanin), Monastir (Al Munastir), Nabeul
(Nabul), Sfax (Safaqis), Sidi Bou Zid (Sidi Bu Zayd), Siliana
(Silyanah), Sousse (Susah), Tataouine (Tatawin), Tozeur (Tawzar),
Tunis, Zaghouan (Zaghwan)
Turkey
81 provinces (iller, singular - il); Adana, Adiyaman, Afyon,
Agri, Aksaray, Amasya, Ankara, Antalya, Ardahan, Artvin, Aydin,
Balikesir, Bartin, Batman, Bayburt, Bilecik, Bingol, Bitlis, Bolu,
Burdur, Bursa, Canakkale, Cankiri, Corum, Denizli, Diyarbakir,
Duzce, Edirne, Elazig, Erzincan, Erzurum, Eskisehir, Gaziantep,
Giresun, Gumushane, Hakkari, Hatay, Igdir, Isparta, Istanbul, Izmir,
Kahramanmaras, Karabuk, Karaman, Kars, Kastamonu, Kayseri, Kilis,
Kirikkale, Kirklareli, Kirsehir, Kocaeli, Konya, Kutahya, Malatya,
Manisa, Mardin, Mersin, Mugla, Mus, Nevsehir, Nigde, Ordu, Osmaniye,
Rize, Sakarya, Samsun, Sanliurfa, Siirt, Sinop, Sirnak, Sivas,
Tekirdag, Tokat, Trabzon, Tunceli, Usak, Van, Yalova, Yozgat,
Zonguldak
olives, olive oil, grain, dairy products, tomatoes, citrus
fruit, beef, sugar beets, dates, almonds
Turkey
tobacco, cotton, grain, olives, sugar beets, pulse, citrus;
livestock
30 (2002)
Turkey
120 (2002)
16.53 births/1,000 population (2003 est.)
Turkey
17.59 births/1,000 population (2003 est.)
Army, Navy, Air Force, paramilitary forces, National Guard
Turkey
Land Forces, Navy (includes Naval Air and Naval Infantry),
Air Force, Coast Guard, Gendarmerie
revenues: $5.2 billion
expenditures: $5.7 billion, including capital expenditures of $1.6
billion (2002 est.)
Turkey
revenues: $42.4 billion
expenditures: $69.1 billion, including capital expenditures of $NA
(2001)
Tunisia has a diverse economy, with important agricultural,
mining, energy, tourism, and manufacturing sectors. Governmental
control of economic affairs while still heavy has gradually lessened
over the past decade with increasing privatization, simplification
of the tax structure, and a prudent approach to debt. Real growth
averaged 5.4% in 1997-2001 but slowed to 1.9% in 2002 because of
agricultural drought, slow investment, and lackluster tourism.
Increased rainfall portends higher growth levels for 2003, but
continued regional tension from the war in Iraq will most likely
continue to suppress tourism earnings. Tunisia has agreed to
gradually remove barriers to trade with the European Union over the
next decade. Broader privatization, further liberalization of the
investment code to increase foreign investment, improvements in
government efficiency, and reduction of the trade deficit are among
the challenges for the future.
Turkey
Turkey''s dynamic economy is a complex mix of modern industry
and commerce along with a traditional agriculture sector that in
2001 still accounted for 40% of employment. It has a strong and
rapidly growing private sector, yet the state still plays a major
role in basic industry, banking, transport, and communication. The
most important industry - and largest exporter - is textiles and
clothing, which is almost entirely in private hands. In recent years
the economic situation has been marked by erratic economic growth
and serious imbalances. Real GNP growth has exceeded 6% in many
years, but this strong expansion has been interrupted by sharp
declines in output in 1994, 1999, and 2001. Meanwhile, the public
sector fiscal deficit has regularly exceeded 10% of GDP - due in
large part to the huge burden of interest payments, which account
for more than 50% of central government spending. Inflation, in
recent years in the high double-digit range, fell to 26% in 2003.
Perhaps because of these problems, foreign direct investment in
Turkey remains low - less than $1 billion annually. In late 2000 and
early 2001 a growing trade deficit and serious weaknesses in the
banking sector plunged the economy into crisis - forcing Turkey to
float the lira and pushing the country into recession. Results in
2002-03 were much better, because of strong financial support from
the IMF and tighter fiscal policy. Continued slow global growth and
serious political tensions in the Middle East could result in
negative growth in 2004.
gas 3,059 km; oil 1,203 km; refined products 345 km (2003)
Turkey
gas 3,177 km; oil 3,562 km (2003)','16ec183c0a566a9bc0dcd2e2f93060c0696426defd711bf2fec1c0d923fcb08b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e96c1f69c8b6f62c9eed0b5ad8671f736fda4334d5bc91b7394357ad4de308aa',2003,'TM','Turkmenistan','economy',614,'Annexed by Russia between 1865 and 1885, Turkmenistan
became a Soviet republic in 1925. It achieved its independence upon
the dissolution of the USSR in 1991. President NIYAZOV retains
absolute control over the country and opposition is not tolerated.
Extensive hydrocarbon/natural gas reserves could prove a boon to
this underdeveloped country if extraction and delivery projects can
be worked out.
total: 13
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4 (2002)
total: 63
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 10
under 914 m: 41 (2002)
contamination of soil and groundwater with agricultural
chemicals, pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of a large
share of the flow of the Amu Darya into irrigation contributes to
that river''s inability to replenish the Aral Sea; desertification
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
3.4% (FY99)
10.18 billion kWh (2001)
8.509 billion kWh (2001)
20 million kWh (2001)
980 million kWh (2001)
fossil fuel: 99.9%
hydro: 0.1%
nuclear: 0%
other: 0% (2001)
34.4% (2001 est.)
lowest 10%: 2.6%
highest 10%: 31.7% (1998)
agriculture 48%, industry 15%, services 37% (1998 est.)
gas 57%, oil 26%, cotton fiber 3%, textiles 2% (2001)
Ukraine 49.7%, Italy 18%, Iran 13.1%, Turkey 6.2% (2002)
5 provinces (welayatlar, singular - welayat): Ahal
Welayaty (Ashgabat), Balkan Welayaty (Balkanabat), Dashoguz
Welayaty, Lebap Welayaty (Turkmenabat), Mary Welayaty
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
cotton, grain; livestock
76 (2002)
28.02 births/1,000 population (2003 est.)
Ministry of Defense (Army, Air and Air Defense, Navy,
Border Troops, and Internal Troops), National Guard
revenues: $588.6 million
expenditures: $658.2 million, including capital expenditures of $NA
(1999 est.)
Turkmenistan is largely desert country with intensive
agriculture in irrigated oases and large gas and oil resources.
One-half of its irrigated land is planted in cotton, making it the
world''s tenth-largest producer. With an authoritarian ex-Communist
regime in power and a tribally based social structure, Turkmenistan
has taken a cautious approach to economic reform, hoping to use gas
and cotton sales to sustain its inefficient economy. Privatization
goals remain limited. In 1998-2003, Turkmenistan suffered from the
continued lack of adequate export routes for natural gas and from
obligations on extensive short-term external debt. At the same time,
however, total exports rose by 38% in 2003, largely because of
higher international oil and gas prices. Overall prospects in the
near future are discouraging because of widespread internal poverty,
the burden of foreign debt, and the unwillingness of the government
to adopt market-oriented reforms. However, Turkmenistan''s
cooperation with the international community in transporting
humanitarian aid to Afghanistan may foreshadow a change in the
atmosphere for foreign investment, aid, and technological support.
Turkmenistan''s economic statistics are state secrets, and GDP and
other figures are subject to wide margins of error. In any event,
GDP increased substantially in 2003 because of a strong recovery in
agriculture and rapid industrial growth.
gas 6,634 km; oil 853 km (2003)','9b89c74b0fed4385df668bd6a0dc3a723557257c3958e2fdeb1a8c1d904da5f2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6f21a8d9cabcf6d78c0304d590fe9a5849f24d75708dcb18c272c31323b8421',2003,'TC','Turks and Caicos Islands','economy',615,'The islands were part of the UK''s Jamaican
colony until 1962, when they assumed the status of a separate crown
colony upon Jamaica''s independence. The governor of The Bahamas
oversaw affairs from 1965 to 1973. With Bahamian independence, the
islands received a separate governor in 1973. Although independence
was agreed upon for 1982, the policy was reversed and the islands
are presently a British overseas territory.
total: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2002)
limited natural fresh water resources,
private cisterns collect rainwater
5 million kWh (2001)
4.65 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
about 33% in government and 20% in
agriculture and fishing; significant numbers in tourism, financial,
and other services
lobster, dried and fresh conch, conch shells
US, UK
none (overseas territory of the UK)
corn, beans, cassava (tapioca), citrus
fruits; fish
8 (2002)
23.51 births/1,000 population (2003 est.)
revenues: $47 million
expenditures: $33.6 million, including capital expenditures of $NA
(1997-98 est.)
The Turks and Caicos economy is based on
tourism, fishing, and offshore financial services. Most capital
goods and food for domestic consumption are imported. The US is the
leading source of tourists, accounting for more than half of the
93,000 visitors in 1998. Major sources of government revenue include
fees from offshore financial activities and customs receipts.
Tourism fell by 6% in 2002 but appeared to be picking up at yearend.','8370b914d865ab5be1447dc5a2cff8fe2355fc44e5ed4b0a0265f08b1fdd1a79','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d42339ad4c8586de8657ee05d81f6a6983dae6657e2f356511b5fc2c8f0c6816',2003,'TV','Tuvalu','economy',616,'In 1974, ethnic differences within the British colony of the
Gilbert and Ellice Islands caused the Polynesians of the Ellice
Islands to vote for separation from the Micronesians of the Gilbert
Islands. The following year, the Ellice Islands became the separate
British colony of Tuvalu. Independence was granted in 1978. In 2000,
Tuvalu negotiated a contract leasing its Internet domain name ".tv"
for $50 million in royalties over the next dozen years.
total: 1
1,524 to 2,437 m: 1 (2002)
since there are no streams or rivers and groundwater is not
potable, most water needs must be met by catchment systems with
storage facilities (the Japanese Government has built one
desalination plant and plans to build one other); beachhead erosion
because of the use of sand for building materials; excessive
clearance of forest undergrowth for use as fuel; damage to coral
reefs from the spread of the Crown of Thorns starfish; Tuvalu is
very concerned about global increases in greenhouse gas emissions
and their effect on rising sea levels, which threaten the country''s
underground water table; in 2000, the government appealed to
Australia and New Zealand to take in Tuvaluans if rising sea levels
should make evacuation necessary
party to: Climate Change, Climate Change-Kyoto Protocol,
Desertification, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity, Law of the Sea
NA%
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
NA%
lowest 10%: NA%
highest 10%: NA%
people make a living mainly through exploitation of the sea,
reefs, and atolls and from wages sent home by those abroad (mostly
workers in the phosphate industry and sailors)
copra, fish
UK 58.3%, Italy 16.7%, Denmark 8.3%, Fiji 8.3% (2002)
none
coconuts; fish
1 (2002)
21.58 births/1,000 population (2003 est.)
no regular military forces; Police Force (includes Maritime
Surveillance Unit for search and rescue missions and surveillance
operations)
revenues: $22.5 million
expenditures: $11.2 million, including capital expenditures of $4.2
million (2000 est.)
Tuvalu consists of a densely populated, scattered group of
nine coral atolls with poor soil. The country has no known mineral
resources and few exports. Subsistence farming and fishing are the
primary economic activities. Fewer than 1,000 tourists, on average,
visit Tuvalu annually. Government revenues largely come from the
sale of stamps and coins and worker remittances. About 1,000
Tuvaluans work in Nauru in the phosphate mining industry. Nauru has
begun repatriating Tuvaluans, however, as phosphate resources
decline. Substantial income is received annually from an
international trust fund established in 1987 by Australia, NZ, and
the UK and supported also by Japan and South Korea. Thanks to wise
investments and conservative withdrawals, this Fund has grown from
an initial $17 million to over $35 million in 1999. The US
government is also a major revenue source for Tuvalu, because of
payments from a 1988 treaty on fisheries. In an effort to reduce its
dependence on foreign aid, the government is pursuing public sector
reforms, including privatization of some government functions and
personnel cuts of up to 7%. In 1998, Tuvalu began deriving revenue
from use of its area code for "900" lines and in 2000, from the
lease of its ".tv" Internet domain name. Royalties from these new
technology sources could increase substantially over the next
decade. With merchandise exports only a fraction of merchandise
imports, continued reliance must be placed on fishing and
telecommunications license fees, remittances from overseas workers,
official transfers, and investment income from overseas assets.','0ae123f10f06ef3e903d131c590621a401a584bf3e0107b2813db528b7a566c5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b9eeb04823eb79a07da7d61b2494fc4e6e30d8cb5edf3bab3dd8b2f8a218e8f',2003,'UG','Uganda','economy',617,'Uganda achieved independence from the UK in 1962. The
dictatorial regime of Idi AMIN (1971-79) was responsible for the
deaths of some 300,000 opponents; guerrilla war and human rights
abuses under Milton OBOTE (1980-85) claimed at least another 100,000
lives. During the 1990s, the government promulgated non-party
presidential and legislative elections.
total: 4
over 3,047 m: 3
1,524 to 2,437 m: 1 (2002)
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 9
under 914 m: 7 (2002)
draining of wetlands for agricultural use; deforestation;
overgrazing; soil erosion; water hyacinth infestation in Lake
Victoria; poaching is widespread
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Environmental Modification
2.1% (FY02)
1.928 billion kWh (2001)
1.62 billion kWh (2001)
1 million kWh (2001)
174 million kWh (2001)
fossil fuel: 0.9%
hydro: 99.1%
nuclear: 0%
other: 0% (2001)
35% (2001 est.)
lowest 10%: 4%
highest 10%: 21% (2000)
agriculture 82%, industry 5%, services 13% (1999 est.)
coffee, fish and fish products, tea; gold, cotton, flowers,
horticultural products
Belgium 16.2%, Netherlands 13.7%, Germany 7.5%, Spain 5.5%,
Hong Kong 4.9%, US 4.6%, UK 4.3%, Italy 4.1%, Portugal 4.1% (2002)
56 districts; Adjumani, Apac, Arua, Bugiri, Bundibugyo,
Bushenyi, Busia, Gulu, Hoima, Iganga, Jinja, Kabale, Kabarole,
Kaberamaido, Kalangala, Kampala, Kamuli, Kamwenge, Kanungu,
Kapchorwa, Kasese, Katakwi, Kayunga, Kibale, Kiboga, Kisoro, Kitgum,
Kotido, Kumi, Kyenjojo, Lira, Luwero, Masaka, Masindi, Mayuge,
Mbale, Mbarara, Moroto, Moyo, Mpigi, Mubende, Mukono, Nakapiripirit,
Nakasongola, Nebbi, Ntungamo, Pader, Pallisa, Rakai, Rukungiri,
Sembabule, Sironko, Soroti, Tororo, Wakiso, Yumbe
coffee, tea, cotton, tobacco, cassava (tapioca), potatoes,
corn, millet, pulses; beef, goat meat, milk, poultry, cut flowers
27 (2002)
46.57 births/1,000 population (2003 est.)
Ugandan Peoples'' Defense Force (including Army, Marine unit,
Air Wing)
revenues: $959 million
expenditures: $1.04 billion, including capital expenditures of $NA
(FY98/99 est.)
Uganda has substantial natural resources, including fertile
soils, regular rainfall, and sizable mineral deposits of copper and
cobalt. Agriculture is the most important sector of the economy,
employing over 80% of the work force. Coffee accounts for the bulk
of export revenues. Since 1986, the government - with the support of
foreign countries and international agencies - has acted to
rehabilitate and stabilize the economy by undertaking currency
reform, raising producer prices on export crops, increasing prices
of petroleum products, and improving civil service wages. The policy
changes are especially aimed at dampening inflation and boosting
production and export earnings. During 1990-2001, the economy turned
in a solid performance based on continued investment in the
rehabilitation of infrastructure, improved incentives for production
and exports, reduced inflation, gradually improved domestic
security, and the return of exiled Indian-Ugandan entrepreneurs.
Ongoing Ugandan involvement in the war in the Democratic Republic of
the Congo, corruption within the government, and slippage in the
government''s determination to press reforms raise doubts about the
continuation of strong growth. In 2000, Uganda qualified for
enhanced Highly Indebted Poor Countries (HIPC) debt relief worth
$1.3 billion and Paris Club debt relief worth $145 million. These
amounts combined with the original HIPC debt relief added up to
about $2 billion. Growth for 2001-02 was solid despite continued
decline in the price of coffee, Uganda''s principal export. Prospects
for 2003 are mixed, with probable strengthening of coffee prices yet
with halting growth in the economies of major export customers.','48d9e64bc93c22c4044b2e1886e069756b430d0da3b1aff0d9b825f714bab7f3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd7f3b4b960a45116daa4df77b4adc610d76fd54bb2c8b6ec4326c05c9dff71c',2003,'UA','Ukraine','economy',618,'Ukraine was the center of the first Slavic state, Kievan
Rus, which during the 10th and 11th centuries was the largest and
most powerful state in Europe. Weakened by internecine quarrels and
Mongol invasions, Kievan Rus was incorporated into the Grand Duchy
of Lithuania and eventually into the Polish-Lithuanian Commonwealth.
The cultural and religious legacy of Kievan Rus laid the foundation
for Ukrainian nationalism through subsequent centuries. A new
Ukrainian state, the Cossack Hetmanate, was established during the
mid-17th century after an uprising against the Poles. Despite
continuous Muscovite pressure, the Hetmanate managed to remain
autonomous for well over 100 years. During the latter part of the
18th century, most Ukrainian ethnographic territory was absorbed by
the Russian Empire. Following the collapse of czarist Russia in
1917, Ukraine was able to bring about a short-lived period of
independence (1917-1920), but was reconquered and forced to endure a
brutal Soviet rule that engineered two artificial famines (1921-22
and 1932-33) in which over 8 million died. In World War II, German
and Soviet armies were responsible for some 7 to 8 million more
deaths. Although independence was achieved in 1991 with the
dissolution of the USSR, true freedom remains elusive, as many of
the former Soviet elite remain entrenched, stalling efforts at
economic reform, privatization, and civil liberties.
total: 182
over 3,047 m: 13
2,438 to 3,047 m: 51
1,524 to 2,437 m: 31
914 to 1,523 m: 6
under 914 m: 81 (2002)
total: 608
over 3,047 m: 14
2,438 to 3,047 m: 36
1,524 to 2,437 m: 50
914 to 1,523 m: 42
under 914 m: 466 (2002)
inadequate supplies of potable water; air and water
pollution; deforestation; radiation contamination in the northeast
from 1986 accident at Chornobyl'' Nuclear Power Plant
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Antarctic-Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
1.4% (FY02)
164.7 billion kWh (2001)
152.4 billion kWh (2001)
0 kWh (2001)
800 million kWh (2001)
fossil fuel: 48.6%
hydro: 7.9%
nuclear: 43.5%
other: 0% (2001)
29% (2001 est.)
lowest 10%: 3.7%
highest 10%: 23.2% (1999)
industry 32%, agriculture 24%, services 44% (1996)
ferrous and nonferrous metals, fuel and petroleum products,
chemicals, machinery and transport equipment, food products
Russia 18.6%, Italy 7.4%, Turkey 5.6%, Germany 4.1%, China
4.1% (2002)
24 oblasti (singular - oblast''), 1 autonomous republic*
(avtomnaya respublika), and 2 municipalities (mista, singular -
misto) with oblast status**; Cherkas''ka (Cherkasy), Chernihivs''ka
(Chernihiv), Chernivets''ka (Chernivtsi), Dnipropetrovs''ka
(Dnipropetrovs''k), Donets''ka (Donets''k), Ivano-Frankivs''ka
(Ivano-Frankivs''k), Kharkivs''ka (Kharkiv), Khersons''ka (Kherson),
Khmel''nyts''ka (Khmel''nyts''kyy), Kirovohrads''ka (Kirovohrad),
Kyyiv**, Kyyivs''ka (Kiev), Luhans''ka (Luhans''k), L''vivs''ka (L''viv),
Mykolayivs''ka (Mykolayiv), Odes''ka (Odesa), Poltavs''ka (Poltava),
Avtonomna Respublika Krym* (Simferopol''), Rivnens''ka (Rivne),
Sevastopol''**, Sums''ka (Sumy), Ternopil''s''ka (Ternopil''), Vinnyts''ka
(Vinnytsya), Volyns''ka (Luts''k), Zakarpats''ka (Uzhhorod), Zaporiz''ka
(Zaporizhzhya), Zhytomyrs''ka (Zhytomyr); note - when using a place
name with an adjectival ending "s''ka" or "z''ka," the word Oblast''
should be added to the place name
note: oblasts have the administrative center name following in
parentheses
grain, sugar beets, sunflower seeds, vegetables; beef, milk
790 (2002)
9.89 births/1,000 population (2003 est.)
Ground Forces, Naval Forces, Air Force, Air Defense Forces,
Interior Troops, Border Troops
revenues: $10.2 billion
expenditures: $11.1 billion, including capital expenditures of $NA
(2002 est.)
After Russia, the Ukrainian republic was far and away the
most important economic component of the former Soviet Union,
producing about four times the output of the next-ranking republic.
Its fertile black soil generated more than one-fourth of Soviet
agricultural output, and its farms provided substantial quantities
of meat, milk, grain, and vegetables to other republics. Likewise,
its diversified heavy industry supplied the unique equipment (for
example, large diameter pipes) and raw materials to industrial and
mining sites (vertical drilling apparatus) in other regions of the
former USSR. Ukraine depends on imports of energy, especially
natural gas, to meet some 85% of its annual energy requirements.
Shortly after independence in December 1991, the Ukrainian
Government liberalized most prices and erected a legal framework for
privatization, but widespread resistance to reform within the
government and the legislature soon stalled reform efforts and led
to some backtracking. Output by 1999 had fallen to less than 40% of
the 1991 level. Loose monetary policies pushed inflation to
hyperinflationary levels in late 1993. Ukraine''s dependence on
Russia for energy supplies and the lack of significant structural
reform have made the Ukrainian economy vulnerable to external
shocks. Now in his second term, President KUCHMA has pledged to
reduce the number of government agencies, streamline the regulatory
process, create a legal environment to encourage entrepreneurs, and
enact a comprehensive tax overhaul. Reforms in the more politically
sensitive areas of structural reform and land privatization are
still lagging. Outside institutions - particularly the IMF - have
encouraged Ukraine to quicken the pace and scope of reforms. GDP in
2000 showed strong export-based growth of 6% - the first growth
since independence - and industrial production grew 12.9%. The
economy continued to expand in 2001 as real GDP rose 9% and
industrial output grew by over 14%. Growth of 4.1% in 2002 was more
moderate, in part a reflection of faltering growth in the developed
world. In general, growth has been undergirded by strong domestic
demand, low inflation, and solid consumer and investor confidence.
Growth was a sturdy 6% in 2003 despite a loss of mementum in needed
economic reforms.
gas 20,069 km; oil 4,435 km; refined products 4,098 km (2003)','3ee7621e11b8ee2cf31fe43dd133f26a6906631bbc2952277a9cf8558ad1297c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8436be2768245503f0e4d0cbd7d6c1c6c7e71814167be2b38c13b4241cb6fe70',2003,'AE','United Arab Emirates','economy',619,'The Trucial States of the Persian Gulf coast
granted the UK control of their defense and foreign affairs in 19th
century treaties. In 1971, six of these states - Abu Zaby, ''Ajman,
Al Fujayrah, Ash Shariqah, Dubayy, and Umm al Qaywayn - merged to
form the United Arab Emirates (UAE). They were joined in 1972 by
Ra''s al Khaymah. The UAE''s per capita GDP is not far below those of
leading West European nations. Its generosity with oil revenues and
its moderate foreign policy stance have allowed the UAE to play a
vital role in the affairs of the region.
total: 22
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 4 (2002)
total: 19
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 5 (2002)
lack of natural freshwater resources
compensated by desalination plants; desertification; beach pollution
from oil spills
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: Law of the Sea
3.1% (FY00)
37.74 billion kWh (2001)
35.1 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
services 78%, industry 15%, agriculture 7%
(2000 est.)
crude oil 45%, natural gas, reexports, dried
fish, dates
Japan 27.8%, South Korea 10.1%, Singapore 3.8%
(2002)
7 emirates (imarat, singular - imarah); Abu
Zaby (Abu Dhabi), ''Ajman, Al Fujayrah, Ash Shariqah (Sharjah),
Dubayy (Dubai), Ra''s al Khaymah, Umm al Qaywayn
dates, vegetables, watermelons; poultry, eggs,
dairy products; fish
41 (2002)
18.48 births/1,000 population (2003 est.)
Army, Navy (including Marines and Coast Guard),
Air Force, Air Defense, paramilitary forces (includes Federal Police
Force)
revenues: $20 billion
expenditures: $22 billion, including capital expenditures of $NA
(2000 est.)
The UAE has an open economy with a high per
capita income and a sizable annual trade surplus. Its wealth is
based on oil and gas output (about 33% of GDP), and the fortunes of
the economy fluctuate with the prices of those commodities. Since
1973, the UAE has undergone a profound transformation from an
impoverished region of small desert principalities to a modern state
with a high standard of living. At present levels of production, oil
and gas reserves should last for more than 100 years. The government
has increased spending on job creation and infrastructure expansion
and is opening up its utilities to greater private sector
involvement.
condensate 383 km; gas 1,765 km; liquid
petroleum gas 186 km; oil 1,266 km (2003)','499c78a4376aef2fbc48c859bc6b6bbf99f52b554620ac7d9b5e068ecd961438','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e8456b66d646242a71cb79a6dd75e6f2c369fe6a1861a7630028d61c142a35c',2003,'GB','United Kingdom','economy',620,'Great Britain, the dominant industrial and maritime
power of the 19th century, played a leading role in developing
parliamentary democracy and in advancing literature and science. At
its zenith, the British Empire stretched over one-fourth of the
earth''s surface. The first half of the 20th century saw the UK''s
strength seriously depleted in two World Wars. The second half
witnessed the dismantling of the Empire and the UK rebuilding itself
into a modern and prosperous European nation. As one of five
permanent members of the UN Security Council, a founding member of
NATO, and of the Commonwealth, the UK pursues a global approach to
foreign policy; it currently is weighing the degree of its
integration with continental Europe. A member of the EU, it chose to
remain outside the European Monetary Union for the time being.
Constitutional reform is also a significant issue in the UK. The
Scottish Parliament, the National Assembly for Wales, and the
Northern Ireland Assembly were established in 1999.
total: 334
over 3,047 m: 8
2,438 to 3,047 m: 33
1,524 to 2,437 m: 151
914 to 1,523 m: 83
under 914 m: 59 (2002)
total: 136
2438 to 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 22
under 914 m: 112 (2002)
continues to reduce greenhouse gas emissions (has met
Kyoto Protocol target of a 12.5% reduction from 1990 levels and
intends to meet the legally binding target and move towards a
domestic goal of a 20% cut in emissions by 2010); by 2005 the
government aims to reduce the amount of industrial and commercial
waste disposed of in landfill sites to 85% of 1998 levels and to
recycle or compost at least 25% of household waste, increasing to
33% by 2015; between 1998-99 and 1999-2000, household recycling
increased from 8.8% to 10.3%
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
2.32% (2002)
360.9 billion kWh (2001)
346.1 billion kWh (2001)
10.66 billion kWh (2001)
264 million kWh (2001)
fossil fuel: 73.8%
hydro: 0.9%
nuclear: 23.7%
other: 1.6% (2001)
17%
lowest 10%: 2.3%
highest 10%: 27.7% (1995)
agriculture 1%, industry 25%, services 74% (1999)
manufactured goods, fuels, chemicals; food,
beverages, tobacco
US 15.5%, Germany 11.2%, France 9.4%, Ireland 8%,
Netherlands 7.1%, Belgium 5.2%, Italy 4.4%, Spain 4.3% (2002)
England - 47 boroughs, 36 counties*, 29 London
boroughs**, 12 cities and boroughs***, 10 districts****, 12
cities*****, 3 royal boroughs******; Barking and Dagenham**,
Barnet**, Barnsley, Bath and North East Somerset****, Bedfordshire*,
Bexley**, Birmingham***, Blackburn with Darwen, Blackpool, Bolton,
Bournemouth, Bracknell Forest, Bradford***, Brent**, Brighton and
Hove, City of Bristol*****, Bromley**, Buckinghamshire*, Bury,
Calderdale, Cambridgeshire*, Camden**, Cheshire*, Cornwall*,
Coventry***, Croydon**, Cumbria*, Darlington, Derby*****,
Derbyshire*, Devon*, Doncaster, Dorset*, Dudley, Durham*, Ealing**,
East Riding of Yorkshire****, East Sussex*, Enfield**, Essex*,
Gateshead, Gloucestershire*, Greenwich**, Hackney**, Halton,
Hammersmith and Fulham**, Hampshire*, Haringey**, Harrow**,
Hartlepool, Havering**, Herefordshire*, Hertfordshire*,
Hillingdon**, Hounslow**, Isle of Wight*, Islington**, Kensington
and Chelsea******, Kent*, City of Kingston upon Hull*****, Kingston
upon Thames******, Kirklees, Knowsley, Lambeth**, Lancashire*,
Leeds***, Leicester*****, Leicestershire*, Lewisham**,
Lincolnshire*, Liverpool***, City of London*****, Luton,
Manchester***, Medway, Merton**, Middlesbrough, Milton Keynes,
Newcastle upon Tyne***, Newham**, Norfolk*, Northamptonshire*, North
East Lincolnshire****, North Lincolnshire****, North Somerset****,
North Tyneside, Northumberland*, North Yorkshire*, Nottingham*****,
Nottinghamshire*, Oldham, Oxfordshire*, Peterborough*****,
Plymouth*****, Poole, Portsmouth*****, Reading, Redbridge**, Redcar
and Cleveland, Richmond upon Thames**, Rochdale, Rotherham,
Rutland****, Salford***, Shropshire*, Sandwell, Sefton,
Sheffield***, Slough, Solihull, Somerset*, Southampton*****,
Southend-on-Sea, South Gloucestershire****, South Tyneside,
Southwark**, Staffordshire*, St. Helens, Stockport,
Stockton-on-Tees, Stoke-on-Trent*****, Suffolk*, Sunderland***,
Surrey*, Sutton**, Swindon, Tameside, Telford and Wrekin****,
Thurrock, Torbay, Tower Hamlets**, Trafford, Wakefield***, Walsall,
Waltham Forest**, Wandsworth**, Warrington, Warwickshire*, West
Berkshire****, Westminster***, West Sussex*, Wigan, Wiltshire*,
Windsor and Maidenhead******, Wirral, Wokingham****, Wolverhampton,
Worcestershire*, York*****; Northern Ireland - 24 districts, 2
cities*, 6 counties**; Antrim, County Antrim**, Ards, Armagh, County
Armagh**, Ballymena, Ballymoney, Banbridge, Belfast*, Carrickfergus,
Castlereagh, Coleraine, Cookstown, Craigavon, Down, County Down**,
Dungannon, Fermanagh, County Fermanagh**, Larne, Limavady, Lisburn,
County Londonderry**, Derry*, Magherafelt, Moyle, Newry and Mourne,
Newtownabbey, North Down, Omagh, Strabane, County Tyrone**; Scotland
- 32 council areas; Aberdeen City, Aberdeenshire, Angus, Argyll and
Bute, The Scottish Borders, Clackmannanshire, Dumfries and Galloway,
Dundee City, East Ayrshire, East Dunbartonshire, East Lothian, East
Renfrewshire, City of Edinburgh, Falkirk, Fife, Glasgow City,
Highland, Inverclyde, Midlothian, Moray, North Ayrshire, North
Lanarkshire, Orkney Islands, Perth and Kinross, Renfrewshire,
Shetland Islands, South Ayrshire, South Lanarkshire, Stirling, West
Dunbartonshire, Eilean Siar (Western Isles), West Lothian; Wales -
11 county boroughs, 9 counties*, 2 cities and counties**; Isle of
Anglesey*, Blaenau Gwent, Bridgend, Caerphilly, Cardiff**,
Ceredigion*, Carmarthenshire*, Conwy, Denbighshire*, Flintshire*,
Gwynedd, Merthyr Tydfil, Monmouthshire*, Neath Port Talbot, Newport,
Pembrokeshire*, Powys*, Rhondda Cynon Taff, Swansea**, Torfaen, The
Vale of Glamorgan*, Wrexham
cereals, oilseed, potatoes, vegetables; cattle,
sheep, poultry; fish
470 (2002)
10.99 births/1,000 population (2003 est.)
Army, Royal Navy (including Royal Marines), Royal Air
Force
revenues: $565 billion
expenditures: $540 billion, including capital expenditures of $NA
(FY 01)
The UK, a leading trading power and financial center,
is one of the quartet of trillion dollar economies of Western
Europe. Over the past two decades the government has greatly reduced
public ownership and contained the growth of social welfare
programs. Agriculture is intensive, highly mechanized, and efficient
by European standards, producing about 60% of food needs with only
1% of the labor force. The UK has large coal, natural gas, and oil
reserves; primary energy production accounts for 10% of GDP, one of
the highest shares of any industrial nation. Services, particularly
banking, insurance, and business services, account by far for the
largest proportion of GDP while industry continues to decline in
importance. GDP growth slipped in 2001-03 as the global downturn,
the high value of the pound, and the bursting of the "new economy"
bubble hurt manufacturing and exports. Still, the economy is one of
the strongest in Europe; inflation, interest rates, and unemployment
remain low. The relatively good economic performance has complicated
the BLAIR government''s efforts to make a case for Britain to join
the European Economic and Monetary Union (EMU). Critics point out,
however, that the economy is doing well outside of EMU, and they
point to public opinion polls that continue to show a majority of
Britons opposed to the single currency. Meantime, the government has
been speeding up the improvement of education, transport, and health
services, at a cost in higher taxes. The war in March-April 2003
between a US-led coalition and Iraq, together with the subsequent
problems of restoring the economy and the polity, involve a heavy
commitment of British military forces.
condensate 370 km; gas 21,263 km; liquid petroleum
gas 59 km; oil 6,420 km; oil/gas/water 63 km; refined products 4,474
km; water 650 km (2003)','24c4cf07c483394091df20dd1864030a3e16007b59f50496cd8976a56676028a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f4fcff88460b76116b72b148719fae82a5dd6a45cbd2d0e6ca777db05e743b3',2003,'US','United States','economy',621,'Britain''s American colonies broke with the mother
country in 1776 and were recognized as the new nation of the United
States of America following the Treaty of Paris in 1783. During the
19th and 20th centuries, 37 new states were added to the original 13
as the nation expanded across the North American continent and
acquired a number of overseas possessions. The two most traumatic
experiences in the nation''s history were the Civil War (1861-65) and
the Great Depression of the 1930s. Buoyed by victories in World Wars
I and II and the end of the Cold War in 1991, the US remains the
world''s most powerful nation-state. The economy is marked by steady
growth, low unemployment and inflation, and rapid advances in
technology.
total: 5,131
over 3,047 m: 185
2,438 to 3,047 m: 222
1,524 to 2,437 m: 1,365
914 to 1,523 m: 2,390
under 914 m: 969 (2002)
total: 9,670
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 158
914 to 1,523 m: 1,702
under 914 m: 7,802 (2002)
air pollution resulting in acid rain in both the US
and Canada; the US is the largest single emitter of carbon dioxide
from the burning of fossil fuels; water pollution from runoff of
pesticides and fertilizers; very limited natural fresh water
resources in much of the western part of the country require careful
management; desertification
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Marine Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change-Kyoto Protocol, Hazardous Wastes
3.2% (FY99 est.)
3.719 trillion kWh (2001)
3.602 trillion kWh (2001)
38.48 billion kWh (2001)
18.17 billion kWh (2001)
fossil fuel: 71.4%
hydro: 5.6%
nuclear: 20.7%
other: 2.3% (2001)
12.7% (2001 est.)
lowest 10%: 1.8%
highest 10%: 30.5% (1997)
managerial and professional 31%, technical, sales and
administrative support 28.9%, services 13.6%, manufacturing, mining,
transportation, and crafts 24.1%, farming, forestry, and fishing 2.4%
note: figures exclude the unemployed (2001)
capital goods, automobiles, industrial supplies and
raw materials, consumer goods, agricultural products
Canada 23.2%, Mexico 14.1%, Japan 7.4%, UK 4.8% (2002)
50 states and 1 district*; Alabama, Alaska, Arizona,
Arkansas, California, Colorado, Connecticut, Delaware, District of
Columbia*, Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa,
Kansas, Kentucky, Louisiana, Maine, Maryland, Massachusetts,
Michigan, Minnesota, Mississippi, Missouri, Montana, Nebraska,
Nevada, New Hampshire, New Jersey, New Mexico, New York, North
Carolina, North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode
Island, South Carolina, South Dakota, Tennessee, Texas, Utah,
Vermont, Virginia, Washington, West Virginia, Wisconsin, Wyoming
wheat, corn, other grains, fruits, vegetables, cotton;
beef, pork, poultry, dairy products; forest products; fish
14,801 (2002)
14.14 births/1,000 population (2003 est.)
Army, Navy and Marine Corps, Air Force, and Coast
Guard (Coast Guard administered in peacetime by the Department of
Homeland Security but in wartime reports to the Department of the
Navy)
revenues: $1.946 trillion
expenditures: $2.052 trillion, including capital expenditures of NA
(2002 est.)
The US has the largest and most technologically
powerful economy in the world, with a per capita GDP of $37,600. In
this market-oriented economy, private individuals and business firms
make most of the decisions, and the federal and state governments
buy needed goods and services predominantly in the private
marketplace. US business firms enjoy considerably greater
flexibility than their counterparts in Western Europe and Japan in
decisions to expand capital plant, lay off surplus workers, and
develop new products. At the same time, they face higher barriers to
entry in their rivals'' home markets than the barriers to entry of
foreign firms in US markets. US firms are at or near the forefront
in technological advances, especially in computers and in medical,
aerospace, and military equipment, although their advantage has
narrowed since the end of World War II. The onrush of technology
largely explains the gradual development of a "two-tier labor
market" in which those at the bottom lack the education and the
professional/technical skills of those at the top and, more and
more, fail to get comparable pay raises, health insurance coverage,
and other benefits. Since 1975, practically all the gains in
household income have gone to the top 20% of households. The years
1994-2000 witnessed solid increases in real output, low inflation
rates, and a drop in unemployment to below 5%. The year 2001 saw the
end of boom psychology and performance, with output increasing only
0.3% and unemployment and business failures rising substantially.
The response to the terrorist attacks of 11 September 2001 showed
the remarkable resilience of the economy. Moderate recovery took
place in 2002, with the GDP growth rate rising to 2.45%. A major
short-term problem in first half 2002 was a sharp decline in the
stock market, fueled in part by the exposure of dubious accounting
practices in some major corporations. The war in March/April 2003
between a US-led coalition and Iraq shifted resources to military
industries and introduced uncertainties about investment and
employment in other sectors of the economy. Long-term problems
include inadequate investment in economic infrastructure, rapidly
rising medical and pension costs of an aging population, sizable
trade deficits, and stagnation of family income in the lower
economic groups.
petroleum products 244,620 km; natural gas 548,665 km
(2003)','2674b504dd32290e3716598a99e4abe2efa7db2bc8457154a63d77f1f06be27c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42c20b20e3b102bf8d6a750f4d4f4bff599fb50f1710d777e4f72b25eb8c2128',2003,'UY','Uruguay','economy',622,'A violent Marxist urban guerrilla movement, the Tupamaros,
launched in the late 1960s, led Uruguay''s president to agree to
military control of his administration in 1973. By yearend, the
rebels had been crushed, but the military continued to expand its
hold throughout the government. Civilian rule was not restored until
1985. Uruguay''s political and labor conditions are among the freest
on the continent.
total: 15
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 7
under 914 m: 2 (2002)
total: 49
1,524 to 2,437 m: 2
914 to 1,523 m: 16
under 914 m: 31 (2002)
water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life Conservation,
Nuclear Test Ban
1.1% (2000)
7.963 billion kWh (2001)
6.152 billion kWh (2001)
123 million kWh (2001)
1.377 billion kWh (2001)
fossil fuel: 0.7%
hydro: 99.1%
nuclear: 0%
other: 0.3% (2001)
6% (1997)
lowest 10%: 3.7%
highest 10%: 25.8% (1997)
agriculture 14%, industry 16%, services 70%
meat, rice, leather products, wool, vehicles, dairy products
Brazil 21%, Argentina 15%, US 8.1%, Germany 5.1%, Italy 4%
(2002)
19 departments (departamentos, singular - departamento);
Artigas, Canelones, Cerro Largo, Colonia, Durazno, Flores, Florida,
Lavalleja, Maldonado, Montevideo, Paysandu, Rio Negro, Rivera,
Rocha, Salto, San Jose, Soriano, Tacuarembo, Treinta y Tres
rice, wheat, corn, barley; livestock; fish
64 (2002)
17.19 births/1,000 population (2003 est.)
Army, Navy (including Naval Air Arm, Coast Guard, Marines),
Air Force, Police (Coracero Guard, Grenadier Guard)
revenues: $3.7 billion
expenditures: $4.6 billion, including capital expenditures of $500
million (2000)
Uruguay''s economy is characterized by an export-oriented
agricultural sector, a well-educated workforce, and high levels of
social spending. After averaging growth of 5% annually during
1996-98, in 1999-2002 the economy suffered a major downturn,
stemming largely from lower demand in Argentina and Brazil, which
together account for nearly half of Uruguay''s exports. Total GDP in
these four years dropped by nearly 20%, with 2002 the worst year.
Unemployment rose to nearly 20% in 2002, inflation surged, and the
burden of external debt doubled. Cooperation with the IMF and the US
has limited the damage, which is still extensive. Moves to
reschedule debt and promote economic recovery may help limit a
further decline in output in 2003.
gas 192 km (2003)','4f6759bb0e675f74531faf377a381c4a33d9dd86eecbd844d8fcf16964e8da2c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eea9137bacf9f35a3f77a9022ade7f0456509dffaa5ab485b2d21ba4a02c6116',2003,'UZ','Uzbekistan','economy',623,'Russia conquered Uzbekistan in the late 19th century.
Stiff resistance to the Red Army after World War I was eventually
suppressed and a socialist republic set up in 1924. During the
Soviet era, intensive production of "white gold" (cotton) and grain
led to overuse of agrochemicals and the depletion of water supplies,
which have left the land poisoned and the Aral Sea and certain
rivers half dry. Independent since 1991, the country seeks to
gradually lessen its dependence on agriculture while developing its
mineral and petroleum reserves. Current concerns include terrorism
by Islamic militants, a nonconvertible currency, and the curtailment
of human rights and democratization.
total: 27
over 3,047 m: 3
2,438 to 3,047 m: 13
1,523 to 2,437 m: 5
under 914 m: 6 (2002)
total: 246
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 10
914 to 1,523 m: 12
under 914 m: 211 (2002)
shrinkage of the Aral Sea is resulting in growing
concentrations of chemical pesticides and natural salts; these
substances are then blown from the increasingly exposed lake bed and
contribute to desertification; water pollution from industrial
wastes and the heavy use of fertilizers and pesticides is the cause
of many human health disorders; increasing soil salination; soil
contamination from buried nuclear processing and agricultural
chemicals, including DDT
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
2% (FY97)
44.49 billion kWh (2001)
47.07 billion kWh (2001)
9.7 billion kWh (2001)
3.998 billion kWh (2001)
fossil fuel: 88.2%
hydro: 11.8%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: 1.2%
highest 10%: 32.8% (1998)
agriculture 44%, industry 20%, services 36% (1995)
cotton 41.5%, gold 9.6%, energy products 9.6%, mineral
fertilizers, ferrous metals, textiles, food products, automobiles
(1998 est.)
Russia 17.7%, Ukraine 11%, Italy 7.6%, Tajikistan 6.8%,
Poland 5.1%, South Korea 5%, Kazakhstan 4.5%, US 4.2% (2002)
12 provinces (viloyatlar, singular - viloyat), 1
autonomous republic* (respublika), and 1 city** (shahar); Andijon
Viloyati, Buxoro Viloyati, Farg''ona Viloyati, Jizzax Viloyati,
Namangan Viloyati, Navoiy Viloyati, Qashqadaryo Viloyati (Qarshi),
Qaraqalpog''iston Respublikasi* (Nukus), Samarqand Viloyati, Sirdaryo
Viloyati (Guliston), Surxondaryo Viloyati (Termiz), Toshkent
Shahri**, Toshkent Viloyati, Xorazm Viloyati (Urganch)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
cotton, vegetables, fruits, grain; livestock
273 (2002)
26.09 births/1,000 population (2003 est.)
Army, Air and Air Defense Forces, National Guard,
Security Forces (internal security and border troops)
revenues: $4 billion
expenditures: $4.1 billion, including capital expenditures of $NA
(1999 est.)
Uzbekistan is a dry, landlocked country of which 11%
consists of intensely cultivated, irrigated river valleys. More than
60% of its population lives in densely populated rural communities.
Uzbekistan is now the world''s second-largest cotton exporter, a
large producer of gold and oil, and a regionally significant
producer of chemicals and machinery. Following independence in
December 1991, the government sought to prop up its Soviet-style
command economy with subsidies and tight controls on production and
prices. Uzbekistan responded to the negative external conditions
generated by the Asian and Russian financial crises by emphasizing
import substitute industrialization and by tightening export and
currency controls within its already largely closed economy. The
government, while aware of the need to improve the investment
climate, sponsors measures that often increase, not decrease, the
government''s control over business decisions. A sharp increase in
the inequality of income distribution has hurt the lower ranks of
society since independence.
gas 9,012 km; oil 869 km; refined products 33 km (2003)
Venezuela
extra heavy crude 992 km; gas 5,262 km; oil 7,484 km;
refined products 1,681 km; unknown (oil/water) 141 km (2003)
Vietnam
condensate/gas 432 km; gas 210 km; oil 3 km; refined
products 206 km (2003)','571816b238f8b948eb4f5c2a3a51db5b5c9d4e7e259b24825c8967fdc4a0f880','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe8963695bb8190d4df9a50f88228d3be6e5fc1cfddcb70178101d233e861e40',2003,'VU','Vanuatu','economy',624,'The British and French, who settled the New Hebrides in the
19th century, agreed in 1906 to an Anglo-French Condominium, which
administered the islands until independence in 1980.
Venezuela
Venezuela was one of three countries that emerged from the
collapse of Gran Colombia in 1830 (the others being Colombia and
Ecuador). For most of the first half of the 20th century, Venezuela
was ruled by generally benevolent military strongmen, who promoted
the oil industry and allowed for some social reforms. Democratically
elected governments have held sway since 1959. Current concerns
include: an embattled president who is losing his once solid support
among Venezuelans, a divided military, drug-related conflicts along
the Colombian border, increasing internal drug consumption,
overdependence on the petroleum industry with its price
fluctuations, and irresponsible mining operations that are
endangering the rain forest and indigenous peoples.
Vietnam
France occupied all of Vietnam by 1884. Independence was
declared after World War II, but the French continued to rule until
1954 when they were defeated by Communist forces under Ho Chi MINH,
who took control of the North. US economic and military aid to South
Vietnam grew through the 1960s in an attempt to bolster the
government, but US armed forces were withdrawn following a
cease-fire agreement in 1973. Two years later, North Vietnamese
forces overran the South. Economic reconstruction of the reunited
country has proven difficult as aging Communist Party leaders have
only grudgingly initiated reforms necessary for a free market.
Virgin Islands
During the 17th century, the archipelago was divided
into two territorial units, one English and the other Danish.
Sugarcane, produced by slave labor, drove the islands'' economy
during the 18th and early 19th centuries. In 1917, the US purchased
the Danish portion, which had been in economic decline since the
abolition of slavery in 1848.
Wake Island
The US annexed Wake Island in 1899 for a cable station.
An important air and naval base was constructed in 1940-41. In
December 1941, the island was captured by the Japanese and held
until the end of World War II. In subsequent years, Wake was
developed as a stopover and refueling site for military and
commercial aircraft transiting the Pacific. Since 1974, the island''s
airstrip has been used by the US military and some commercial cargo
planes, as well as for emergency landings. There are over 700
landings a year on the island.
total: 3
2,438 to 3,047 m: 1
1524 to 2437 m: 1
914 to 1,523 m: 1 (2002)
Venezuela
total: 127
over 3,047 m: 5
2,438 to 3,047 m: 11
1,524 to 2,437 m: 32
914 to 1,523 m: 61
under 914 m: 18 (2002)
Vietnam
total: 24
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 6
914 to 1,523 m: 7
under 914 m: 6 (2002)
Virgin Islands
total: 2
1,524 to 2,437 m: 2 (2002)
Wake Island
total: 1
2,438 to 3,047 m: 1 (2002)
total: 27
914 to 1,523 m: 10
under 914 m: 17 (2002)
Venezuela
total: 246
1,524 to 2,437 m: 10
914 to 1,523 m: 97
under 914 m: 139 (2002)
Vietnam
total: 23
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 12 (2002)
a majority of the population does not have access to a
potable and reliable supply of water; deforestation
Venezuela
sewage pollution of Lago de Valencia; oil and urban
pollution of Lago de Maracaibo; deforestation; soil degradation;
urban and industrial pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem from irresponsible mining
operations
Vietnam
logging and slash-and-burn agricultural practices contribute
to deforestation and soil degradation; water pollution and
overfishing threaten marine life populations; groundwater
contamination limits potable water supply; growing urban
industrialization and population migration are rapidly degrading
environment in Hanoi and Ho Chi Minh City
Virgin Islands
lack of natural freshwater resources
Wake Island
NA
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Venezuela
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping
Vietnam
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
NA%
Venezuela
0.9% (FY99)
Vietnam
2.5% (FY98)
West Bank
NA%
43.46 million kWh (2001)
Venezuela
87.6 billion kWh (2001)
Vietnam
29.8 billion kWh (2001)
Virgin Islands
1.03 billion kWh (2001)
Wake Island
NA
40.42 million kWh (2001)
Venezuela
81.47 billion kWh (2001)
Vietnam
27.71 billion kWh (2001)
Virgin Islands
957.9 million kWh (2001)
0 kWh (2001)
Venezuela
0 kWh (2001)
Vietnam
0 kWh (2001)
Virgin Islands
0 kWh (2001)
0 kWh (2001)
Venezuela
0 kWh (2001)
Vietnam
0 kWh (2001)
Virgin Islands
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Venezuela
fossil fuel: 31.7%
hydro: 68.3%
nuclear: 0%
other: 0% (2001)
Vietnam
fossil fuel: 43.7%
hydro: 56.3%
nuclear: 0%
other: 0% (2001)
Virgin Islands
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
Venezuela
47% (1998 est.)
Vietnam
37% (1998 est.)
Virgin Islands
NA%
lowest 10%: NA%
highest 10%: NA%
Venezuela
lowest 10%: 0.8%
highest 10%: 36.5% (1998)
Vietnam
lowest 10%: 3.6%
highest 10%: 29.9% (1998)
Virgin Islands
lowest 10%: NA%
highest 10%: NA%
agriculture 65%, services 30%, industry 5% (2000 est.)
Venezuela
services 64%, industry 23%, agriculture 13% (1997 est.)
Vietnam
agriculture 63%, industry and services 37% (2000 est.)
Virgin Islands
agriculture 1%, industry 20%, services 79% (1990 est.)
copra, beef, cocoa, timber, kava, coffee
Venezuela
petroleum, bauxite and aluminum, steel, chemicals,
agricultural products, basic manufactures
Vietnam
crude oil, marine products, rice, coffee, rubber, tea,
garments, shoes
Virgin Islands
refined petroleum products
India 32.5%, Thailand 22.8%, South Korea 10.5%, Indonesia
6.3%, Japan 4.9% (2002)
Venezuela
US 53.4%, Netherlands Antilles 17.3%, Canada 2.9% (2002)
Vietnam
US 15.2%, Japan 14.9%, Australia 7.6%, China 6.6%, Germany
6.5%, Singapore 5.5%, UK 4.3% (2002)
Virgin Islands
US, Puerto Rico
6 provinces; Malampa, Penama, Sanma, Shefa, Tafea, Torba
Venezuela
23 states (estados, singular - estado), 1 federal
district* (distrito federal), and 1 federal dependency**
(dependencia federal); Amazonas, Anzoategui, Apure, Aragua, Barinas,
Bolivar, Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**,
Distrito Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas,
Nueva Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas,
Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Vietnam
58 provinces (tinh, singular and plural), and 3
municipalities* (thu do, singular and plural); An Giang, Bac Giang,
Bac Kan, Bac Lieu, Bac Ninh, Ba Ria-Vung Tau, Ben Tre, Binh Dinh,
Binh Duong, Binh Phuoc, Binh Thuan, Ca Mau, Can Tho, Cao Bang, Dac
Lak, Da Nang, Dong Nai, Dong Thap, Gia Lai, Ha Giang, Hai Duong, Hai
Phong*, Ha Nam, Ha Noi*, Ha Tay, Ha Tinh, Hoa Binh, Ho Chi Minh*,
Hung Yen, Khanh Hoa, Kien Giang, Kon Tum, Lai Chau, Lam Dong, Lang
Son, Lao Cai, Long An, Nam Dinh, Nghe An, Ninh Binh, Ninh Thuan, Phu
Tho, Phu Yen, Quang Binh, Quang Nam, Quang Ngai, Quang Ninh, Quang
Tri, Soc Trang, Son La, Tay Ninh, Thai Binh, Thai Nguyen, Thanh Hoa,
Thua Thien-Hue, Tien Giang, Tra Vinh, Tuyen Quang, Vinh Long, Vinh
Phuc, Yen Bai
Virgin Islands
none (territory of the US); there are no first-order
administrative divisions as defined by the US Government, but there
are three islands at the second order; Saint Croix, Saint John,
Saint Thomas
copra, coconuts, cocoa, coffee, taro, yams, coconuts,
fruits, vegetables; fish, beef
Venezuela
corn, sorghum, sugarcane, rice, bananas, vegetables,
coffee; beef, pork, milk, eggs; fish
Vietnam
paddy rice, corn, potatoes, rubber, soybeans, coffee, tea,
bananas, sugar; poultry, pigs; fish
Virgin Islands
fruit, vegetables, sorghum; Senepol cattle
30 (2002)
Venezuela
373 (2002)
Vietnam
47 (2002)
Virgin Islands
2 (2002)
Wake Island
1 (2002)
24.26 births/1,000 population (2003 est.)
Venezuela
19.78 births/1,000 population (2003 est.)
Vietnam
19.58 births/1,000 population (2003 est.)
Virgin Islands
15.8 births/1,000 population (2003 est.)
no regular military forces; Vanuatu Police Force (VPF;
including the paramilitary Mobile Force or VMF)
Venezuela
National Armed Forces (Fuerzas Armadas Nacionales or FAN)
includes Ground Forces or Army (Fuerzas Terrestres or Ejercito),
Naval Forces (Fuerzas Navales or Armada - including marines and
Coast Guard), Air Force (Fuerzas Aereas or Aviacion), Armed Forces
of Cooperation or National Guard (Fuerzas Armadas de Cooperacion or
Guardia Nacional)
Vietnam
People''s Army of Vietnam (includes Ground Forces, People''s
Navy Command [including Naval Infantry], Air and Air Defense Force,
Coast Guard)
revenues: $94.4 million
expenditures: $99.8 million, including capital expenditures of $30.4
million (1996 est.)
Venezuela
revenues: $21.5 billion
expenditures: $27 billion, including capital expenditures of $NA
(2000 est.)
Vietnam
revenues: $5.3 billion
expenditures: $5.6 billion, including capital expenditures of $1.8
billion (1999 est.)
Virgin Islands
revenues: $364.4 million
expenditures: $364.4 million, including capital expenditures of $NA
(1990 est.)
The economy is based primarily on subsistence or small-scale
agriculture, which provides a living for 65% of the population.
Fishing, offshore financial services, and tourism, with about 50,000
visitors in 1997, are other mainstays of the economy. Mineral
deposits are negligible; the country has no known petroleum
deposits. A small light industry sector caters to the local market.
Tax revenues come mainly from import duties. Economic development is
hindered by dependence on relatively few commodity exports,
vulnerability to natural disasters, and long distances from main
markets and between constituent islands. A severe earthquake in
November 1999 followed by a tsunami, caused extensive damage to the
northern island of Pentecote and left thousands homeless. Another
powerful earthquake in January 2002 caused extensive damage in the
capital, Port-Vila, and surrounding areas, and also was followed by
a tsunami. GDP growth rose less than 3% on average in the 1990s. In
response to foreign concerns, the government has promised to tighten
regulation of its offshore financial center. In mid-2002 the
government stepped up efforts to boost tourism. Australia and New
Zealand are the main suppliers of foreign aid.
Venezuela
Venezuela continues to be highly dependent on the
petroleum sector, which accounts for roughly one-third of GDP,
around 80% of export earnings, and more than half of government
operating revenues. Despite higher oil prices at the end of 2002 and
into 2003, domestic political instability, culminating in a
two-month national oil strike from December 2002 to February 2003,
temporarily halted economic activity. The economy is likely to
remain in a recession in 2003, after sinking an estimated 8.9
percent in 2002.
Vietnam
Vietnam is a poor, densely-populated country that has had to
recover from the ravages of war, the loss of financial support from
the old Soviet Bloc, and the rigidities of a centrally planned
economy. Substantial progress was achieved from 1986 to 1996 in
moving forward from an extremely low starting point - growth
averaged around 9% per year from 1993 to 1997. The 1997 Asian
financial crisis highlighted the problems in the Vietnamese economy
but, rather than prompting reform, reaffirmed the government''s
belief that shifting to a market-oriented economy would lead to
disaster. GDP growth of 8.5% in 1997 fell to 6% in 1998 and 5% in
1999. Growth then rose to 6% to 7% in 2000-02 even against the
background of global recession. These numbers mask some major
difficulties in economic performance. Many domestic industries,
including coal, cement, steel, and paper, have reported large
stockpiles of inventory and tough competition from more efficient
foreign producers. Meanwhile, Vietnamese authorities have moved to
implement the structural reforms needed to modernize the economy and
to produce more competitive, export-driven industries. The
US-Vietnam Bilateral Trade Agreement entered into force near the end
of 2001 and is expected to significantly increase Vietnam''s exports
to the US. The US is assisting Vietnam with implementing the legal
and structural reforms called for in the agreement.
Virgin Islands
Tourism is the primary economic activity, accounting
for more than 70% of GDP and 70% of employment. The islands normally
host 2 million visitors a year. The manufacturing sector consists of
petroleum refining, textiles, electronics, pharmaceuticals, and
watch assembly. The agricultural sector is small, with most food
being imported. International business and financial services are a
small but growing component of the economy. One of the world''s
largest petroleum refineries is at Saint Croix. The islands are
subject to substantial damage from storms. The government is working
to improve fiscal discipline, support construction projects in the
private sector, expand tourist facilities, reduce crime, and protect
the environment.
Wake Island
Economic activity is limited to providing services to
contractors located on the island. All food and manufactured goods
must be imported.','5b2d23090f989c2a9920126e19124fb7e8af636946baecad5dbbeaca369622f4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b713c9543d90f13ff39e0e1cf58a6e6add0596020ca1f42336bcf7f22c2d2f33',2003,'EH','Western Sahara','economy',625,'Morocco virtually annexed the northern two-thirds of
Western Sahara (formerly Spanish Sahara) in 1976, and the rest of
the territory in 1979, following Mauritania''s withdrawal. A
guerrilla war with the Polisario Front contesting Rabat''s
sovereignty ended in a 1991 UN-brokered cease-fire; a UN-organized
referendum on final status has been repeatedly postponed.
World
Globally, the 20th century was marked by: (a) two devastating
world wars; (b) the Great Depression of the 1930s; (c) the end of
vast colonial empires; (d) rapid advances in science and technology,
from the first airplane flight at Kitty Hawk, North Carolina (US) to
the landing on the moon; (e) the Cold War between the Western
alliance and the Warsaw Pact nations; (f) a sharp rise in living
standards in North America, Europe, and Japan; (g) increased
concerns about the environment, including loss of forests, shortages
of energy and water, the decline in biological diversity, and air
pollution; (h) the onset of the AIDS epidemic; and (i) the ultimate
emergence of the US as the only world superpower. The planet''s
population continues to explode: from 1 billion in 1820, to 2
billion in 1930, 3 billion in 1960, 4 billion in 1974, 5 billion in
1988, and 6 billion in 2000. For the 21st century, the continued
exponential growth in science and technology raises both hopes
(e.g., advances in medicine) and fears (e.g., development of even
more lethal weapons of war).
total: 3
2,438 to 3,047 m: 3 (2002)
total: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2002)
sparse water and lack of arable land
World
large areas subject to overpopulation, industrial disasters,
pollution (air, water, acid rain, toxic substances), loss of
vegetation (overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
NA%
World
roughly 2% of gross world product (1999 est.)
90 million kWh (2001)
World
14.85 trillion kWh (2001 est.)
83.7 million kWh (2001)
World
13.93 trillion kWh (2001 est.)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
World
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
NA%
lowest 10%: NA%
highest 10%: NA%
World
lowest 10%: NA%
highest 10%: NA%
animal husbandry and subsistence farming 50%
World
agriculture NA%, industry NA%, services NA%
phosphates 62%
World
the whole range of industrial and agricultural goods and
services
Morocco claims and administers Western Sahara, so
trade partners are included in overall Moroccan accounts
World
US 17.4%, Germany 7.6%, UK 5.4%, France 5.1%, Japan 4.8%,
China 4% (2002)
none (under de facto control of Morocco)
World
268 nations, dependent areas, other, and miscellaneous entries
fruits and vegetables (grown in the few oases);
camels, sheep, goats (kept by nomads)
11 (2002)
NA births/1,000 population (2003 est.)
World
20.43 births/1,000 population (2003 est.)
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Western Sahara depends on pastoral nomadism, fishing,
and phosphate mining as the principal sources of income for the
population. The territory lacks sufficient rainfall for sustainable
agricultural production, and most of the food for the urban
population must be imported. All trade and other economic activities
are controlled by the Moroccan Government. Moroccan energy interests
in 2001 signed contracts to explore for oil off the coast of Western
Sahara, which has angered the Polisario. Incomes and standards of
living in Western Sahara are substantially below the Moroccan level.
World
Growth in global output (gross world product, GWP) fell from
4.8% in 2000 to 2.2% in 2001 and 2.7% in 2002. The causes:
sluggishness in the US economy (21% of GWP) and in the 15 EU
economies (19% of GWP); continued stagnation in the Japanese economy
(7.2% of GWP); and spillover effects in the less developed regions
of the world. China, the second-largest economy in the world (12% of
GWP), proved an exception, continuing its rapid annual growth,
officially announced as 8% but estimated by many observers as
perhaps two percentage points lower. Russia (2.6% of GWP), with 4%
growth, continued to make uneven progress, its GDP per capita still
only one-third that of the leading industrial nations. The other 14
successor nations of the USSR and the other old Warsaw Pact nations
again experienced widely divergent growth rates; the three Baltic
nations continued as strong performers, in the 5% range of growth.
The developing nations also varied in their growth results, with
many countries facing population increases that erode gains in
output. Externally, the nation-state, as a bedrock
economic-political institution, is steadily losing control over
international flows of people, goods, funds, and technology.
Internally, the central government often finds its control over
resources slipping as separatist regional movements - typically
based on ethnicity - gain momentum, e.g., in many of the successor
states of the former Soviet Union, in the former Yugoslavia, in
India, in Indonesia, and in Canada. Externally, the central
government is losing decision-making powers to international bodies.
In Western Europe, governments face the difficult political problem
of channeling resources away from welfare programs in order to
increase investment and strengthen incentives to seek employment.
The addition of 80 million people each year to an already
overcrowded globe is exacerbating the problems of pollution,
desertification, underemployment, epidemics, and famine. Because of
their own internal problems and priorities, the industrialized
countries devote insufficient resources to deal effectively with the
poorer areas of the world, which, at least from the economic point
of view, are becoming further marginalized. The introduction of the
euro as the common currency of much of Western Europe in January
1999, while paving the way for an integrated economic powerhouse,
poses economic risks because of varying levels of income and
cultural and political differences among the participating nations.
The terrorist attacks on the US on 11 September 2001 accentuate a
further growing risk to global prosperity, illustrated, for example,
by the reallocation of resources away from investment to
anti-terrorist programs. The opening of war in March 2003 between a
US-led coalition and Iraq added new uncertainties to global economic
prospects. (For specific economic developments in each country of
the world in 2002, see the individual country entries.)','3416de6aa5154968d48cf25d0fa7331e95b3163addf153607e3a3ee5e402cbef','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('007b437974e602e1f92d8939adc986cc4c6f5d035c252e25a53137af6dd1ed57',2003,'YE','Yemen','economy',626,'North Yemen became independent of the Ottoman Empire in 1918.
The British, who had set up a protectorate area around the southern
port of Aden in the 19th century, withdrew in 1967 from what became
South Yemen. Three years later, the southern government adopted a
Marxist orientation. The massive exodus of hundreds of thousands of
Yemenis from the south to the north contributed to two decades of
hostility between the states. The two countries were formally
unified as the Republic of Yemen in 1990. A southern secessionist
movement in 1994 was quickly subdued. In 2000, Saudi Arabia and
Yemen agreed to a delimitation of their border.
total: 16
over 3,047 m: 3
2,438 to 3,047 m: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 11
under 914 m: 4 (2002)
very limited natural fresh water resources; inadequate
supplies of potable water; overgrazing; soil erosion; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: Nuclear Test Ban
5.2% (FY01)
3.01 billion kWh (2001)
2.8 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA
lowest 10%: 3%
highest 10%: 25.9% (1998)
most people are employed in agriculture and herding; services,
construction, industry, and commerce account for less than
one-fourth of the labor force
crude oil, coffee, dried and salted fish
India 21.1%, Thailand 16.9%, South Korea 11.2%, China 11.1%,
Malaysia 7.7%, US 6.7%, Singapore 4% (2002)
19 governorates (muhafazat, singular - muhafazah); Abyan,
''Adan, Ad Dali'', Al Bayda'', Al Hudaydah, Al Jawf, Al Mahrah, Al
Mahwit, ''Amran, Dhamar, Hadramawt, Hajjah, Ibb, Lahij, Ma''rib,
Sa''dah, San''a'', Shabwah, Ta''izz
note: there may be one additional governorate of the capital city of
Sanaa
grain, fruits, vegetables, pulses, qat (mildly narcotic
shrub), coffee, cotton; dairy products, livestock (sheep, goats,
cattle, camels), poultry; fish
44 (2002)
43.23 births/1,000 population (2003 est.)
Army (includes Special Forces, established in 1999), Navy, Air
Force, Air Defense Forces, Republican Guard
revenues: $3 billion
expenditures: $3.1 billion, including capital expenditures of NA
(2001 est.)
Yemen, one of the poorest countries in the Arab world,
reported strong growth in the mid-1990s with the onset of oil
production, but has been harmed by periodic declines in oil prices.
Yemen has embarked on an IMF-supported structural adjustment program
designed to modernize and streamline the economy, which has led to
substantial foreign debt relief and restructuring. International
donors, meeting in Paris in October 2002, agreed on a further $2.3
billion economic support package. Yemen has worked to maintain tight
control over spending and implement additional components of the IMF
program. A high population growth rate and internal political
dissension complicate the government''s task.
gas 88 km; oil 1,174 km (2003)','698c2f29add5f82093f63b8f5009ac0e523b31a7a046ac14e7268238d4808de5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf391151cd048642c744fa3a6f802d42b91f8ff290d7986c2c4f84b93d5609cf',2003,'ZM','Zambia','economy',627,'The territory of Northern Rhodesia was administered by the
South Africa Company from 1891 until it was taken over by the UK in
1923. During the 1920s and 1930s, advances in mining spurred
development and immigration. The name was changed to Zambia upon
independence in 1964. In the 1980s and 1990s, declining copper
prices and a prolonged drought hurt the economy. Elections in 1991
brought an end to one-party rule, but the subsequent vote in 1996
saw blatant harassment of opposition parties. The election in 2001
was marked by administrative problems with three parties filing a
legal petition challenging the election of ruling party candidate
Levy MWANAWASA. The new president launched a far-reaching
anti-corruption campaign in 2002, which resulted in the 2003 arrest
of the previous president Frederick CHILUBA and many of his
supporters. Opposition parties currently hold a majority of seats in
the National Assembly.
total: 11
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 1 (2002)
total: 98
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 63
under 914 m: 30 (2002)
air pollution and resulting acid rain in the mineral
extraction and refining region; chemical runoff into watersheds;
poaching seriously threatens rhinoceros, elephant, antelope, and
large cat populations; deforestation; soil erosion; desertification;
lack of adequate water treatment presents human health risks
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
0.9% (FY02)
7.751 billion kWh (2001)
5.458 billion kWh (2001)
0 kWh (2001)
1.75 billion kWh (2001)
fossil fuel: 0.5%
hydro: 99.5%
nuclear: 0%
other: 0% (2001)
86% (1993)
lowest 10%: 1.1%
highest 10%: 41% (1998)
agriculture 85%, industry 6%, services 9%
copper 55%, cobalt, electricity, tobacco, flowers, cotton
Malawi 10.3%, Thailand 9.2%, Japan 9.1%, Saint Pierre and
Miquelon 9.1%, Taiwan 8.5%, South Africa 7.8%, Egypt 6.4%, China
6.3%, Netherlands 5.5%, Tanzania 4.5% (2002)
9 provinces; Central, Copperbelt, Eastern, Luapula, Lusaka,
Northern, North-Western, Southern, Western
corn, sorghum, rice, peanuts, sunflower seed, vegetables,
flowers, tobacco, cotton, sugarcane, cassava (tapioca); cattle,
goats, pigs, poultry, milk, eggs, hides; coffee
109 (2002)
39.53 births/1,000 population (2003 est.)
Army, Air Force, Police, paramilitary forces
revenues: $1.2 billion
expenditures: $1.25 billion, including capital expenditures of $NA
(2001 est.)
Despite progress in privatization and budgetary reform,
Zambia''s economic growth remains below the 5% to 7% necessary to
reduce poverty significantly. Privatization of government-owned
copper mines relieved the government from covering mammoth losses
generated by the industry and greatly improved the chances for
copper mining to return to profitability and spur economic growth.
However, low mineral prices have slowed the benefits of privatizing
the mines and have reduced incentives for further private investment
in the sector. Cooperation continues with international bodies on
programs to reduce poverty.
oil 771 km (2003)','56b0d79266ad06e71d94aab1e2c6a03d11e4f43337c304d6689a654e663e486c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7695ef1e9236a2ec761857877f7a589193b002f04fcc51dc7b8463c4c16db43',2003,'AF','Afghanistan','economy',628,'total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 1 (2002)
total: 37
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 11 (2002)
limited natural fresh water resources; inadequate
supplies of potable water; soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification; air and water
pollution
party to: Desertification, Endangered Species,
Environmental Modification, Marine Dumping, Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
7.7% (FY02)
334.8 million kWh (2001)
511.4 million kWh (2001)
200 million kWh (2001)
0 kWh (2001)
fossil fuel: 36.3%
hydro: 63.7%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 80%, industry 10%, services 10% (1990 est.)
opium, fruits and nuts, handwoven carpets, wool, cotton,
hides and pelts, precious and semi-precious gems
Pakistan 26.8%, India 26.5%, Finland 5.8%, Germany 5.1%,
UAE 4.4%, Belgium 4.3%, Russia 4.2%, US 4.2% (2002)
32 provinces (velayat, singular - velayat); Badakhshan,
Badghis, Baghlan, Balkh, Bamian, Farah, Faryab, Ghazni, Ghowr,
Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Khowst, Konar,
Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Nurestan, Oruzgan,
Paktia, Paktika, Parvan, Samangan, Sar-e Pol, Takhar, Vardak, and
Zabol
opium, wheat, fruits, nuts, wool, mutton, sheepskins,
lambskins
47 (2002)
40.63 births/1,000 population (2003 est.)
NA; note - the December 2001 Bonn Agreement called for
all militia forces to come under the authority of the central
government, but regional leaders have continued to retain their
militias and the formation of a nation army will be a gradual
process; Afghanistan''s forces continue to be factionalized, largely
along ethnic lines
revenues: $200 million
expenditures: $550 million, including capital expenditures of $NA
(2003 plan est.)
Kabul
gas 651 km (2003)
NA; note - political parties in Afghanistan are in flux
and many prominent players have plans to create new parties; the
Transitional Islamic State of Afghanistan (TISA) is headed by
President Hamid KARZAI; the TISA is a coalition government formed of
leaders from across the Afghan political spectrum; there are also
several political factions not holding positions in the Transitional
government that are forming new groups and parties in the hopes of
participating in 2004 elections','ac75f5e52dd3462061d2ea49ff29bac55a6643729b70483329b21fb66d03f6f0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1789da6d59fa7dd0261c7f9262fad25969fa4673b93b0d65d12cb46fc670e073',2003,'AL','Albania','economy',629,'total: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1 (2002)
total: 8
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 4 (2002)
deforestation; soil erosion; water pollution from industrial
and domestic effluents
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.49% (FY02)
5.289 billion kWh (2001)
5.898 billion kWh (2001)
1.2 billion kWh (2001)
221 million kWh (2001)
fossil fuel: 2.9%
hydro: 97.1%
nuclear: 0%
other: 0% (2001)
30% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture 50%, industry and services 50%
textiles and footwear; asphalt, metals and metallic ores,
crude oil; vegetables, fruits, tobacco
Italy 76.6%, Germany 5.6%, Greece 2.7% (2002)
12 counties (qarqe, singular - qark); Qarku i Beratit, Qarku
i Dibres, Qarku i Durresit, Qarku i Elbasanit, Qarku i Fierit, Qarku
i Gjirokastres, Qarku i Korces, Qarku i Kukesit, Qarku i Lezhes,
Qarku i Shkodres, Qarku i Tiranes, Qarku i Vlores
wheat, corn, potatoes, vegetables, fruits, sugar beets,
grapes; meat, dairy products
12 (2002)
18.2 births/1,000 population (2003 est.)
Army, Navy, Air and Air Defense Forces, Interior Ministry
Troops, Border Guards
revenues: $697 million
expenditures: $1.5 billion, including capital expenditures of $368
million (2002 est.)
Tirana
gas 339 km; oil 207 km (2003)
Agrarian Party of Albania or PASH [Lufter XHUVELI];
Christian Democratic Party or PDK [Zef BUSHATI]; Communist Party of
Albania or PKSH [Hysni MILLOSHI]; Democratic Alliance or PAD
[Nerltan CEKA]; Democratic Party or PD [Sali BERISHA]; Legality
Movement Party or PLL [Guri DUROLLARI]; National Front Party (Balli
Kombetar) or PBK [Abaz ERMENJI]; Party of National Unity or PUK
[Idajet BEQUIRI]; Republican Party or PR [Fatmir MEDIU]; Social
Democracy or DS [Paskal MILO]; Social Democratic Party or PSD
[Skender GJINUSHI]; Socialist Party or PS (formerly the Albanian
Party of Labor) [Fatos NANO]; Union for Human Rights Party or PBDNJ
[Vasil MELO]','cfe633e9ad7978ab93fe5a35ae97f9b841c8f37feaca5084b8df2128641edbf6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0ebe1ad05d8422acf0fecf1327dc0592da7ea33a79cdae6a76486150532668c',2003,'DZ','Algeria','economy',630,'total: 54
over 3,047 m: 9
2,438 to 3,047 m: 27
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m: 1 (2002)
total: 82
2,438 to 3,047 m: 2
1,524 to 2,437 m: 23
914 to 1,523 m: 38
under 914 m: 19 (2002)
soil erosion from overgrazing and other poor farming
practices; desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is leading to the
pollution of rivers and coastal waters; Mediterranean Sea, in
particular, becoming polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
4.1% (FY99)
24.69 billion kWh (2001)
22.9 billion kWh (2001)
275 million kWh (2001)
340 million kWh (2001)
fossil fuel: 99.7%
hydro: 0.3%
nuclear: 0%
other: 0% (2001)
23% (1999 est.)
lowest 10%: 2.8%
highest 10%: 26.8% (1995)
government 29%, agriculture 25%, construction and public
works 15%, industry 11%, other 20% (1996 est.)
petroleum, natural gas, and petroleum products 97%
Italy 18.9%, Spain 13.1%, France 13%, US 12.1%, Netherlands
6%, Brazil 5.9%, Canada 5.7%, Turkey 5.3%, Belgium 5.1% (2002)
48 provinces (wilayas, singular - wilaya); Adrar, Ain Defla,
Ain Temouchent, Alger, Annaba, Batna, Bechar, Bejaia, Biskra, Blida,
Bordj Bou Arreridj, Bouira, Boumerdes, Chlef, Constantine, Djelfa,
El Bayadh, El Oued, El Tarf, Ghardaia, Guelma, Illizi, Jijel,
Khenchela, Laghouat, Mascara, Medea, Mila, Mostaganem, M''Sila,
Naama, Oran, Ouargla, Oum el Bouaghi, Relizane, Saida, Setif, Sidi
Bel Abbes, Skikda, Souk Ahras, Tamanghasset, Tebessa, Tiaret,
Tindouf, Tipaza, Tissemsilt, Tizi Ouzou, Tlemcen
wheat, barley, oats, grapes, olives, citrus, fruits; sheep,
cattle
136 (2002)
21.94 births/1,000 population (2003 est.)
People''s National Army (ANP), Algerian National Navy (ANN),
Air Force, Territorial Air Defense, National Gendarmerie
revenues: $20.3 billion
expenditures: $18.8 billion, including capital expenditures of $5.8
billion (2001 est.)
Algiers
condensate 1,344 km; gas 87,347 km; liquid petroleum gas
2,213 km; oil 6,496 km (2003)
Algerian National Front or FNA [Moussa TOUATI]; Democratic
National Rally or RND [Ahmed OUYAHIA, chairman]; Islamic Salvation
Front or FIS (outlawed April 1992) [Ali BELHADJ and Dr. Abassi
MADANI, Rabeh KEBIR (self-exile in Germany)]; Society of Peace
Movement or MSP [Boujerra SOLTANI]; National Entente Movement or MEN
[Ali BOUKHAZNA]; National Liberation Front or FLN [Ali BENFLIS,
secretary general]; National Reform Movement or MRN [Abdellah
DJABALLAH]; National Renewal Party or PRA [leader NA]; Progressive
Republican Party [Khadir DRISS]; Rally for Culture and Democracy or
RCD [Said SAADI, secretary general]; Renaissance Movement or EnNahda
Movement [Lahbib ADAMI]; Social Liberal Party or PSL [Ahmed KHELIL];
Socialist Forces Front or FFS [Hocine Ait AHMED, secretary general
(self-exile in Switzerland)]; Union for Democracy and Liberty
[Mouley BOUKHALAFA]; Workers Party or PT [Louisa HANOUN]
note: a law banning political parties based on religion was enacted
in March 1997','53d92a3b37d3c23c7d23845d113d798ad60c51745b110af832feb100246e49d4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7363ea0be7e310c95db1c68d4bacdc9ad321253b35061736f6a83552ef44dff',2003,'AS','American Samoa','economy',631,'total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2002)
total: 1
under 914 m: 1 (2002)
limited natural fresh water resources; the water
division of the government has spent substantial funds in the past
few years to improve water catchments and pipelines
130 million kWh (2001)
120.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
government 33%, tuna canneries 34%, other 33% (1990)
canned tuna 93%
Indonesia 71.1%, Japan 7.7%, Samoa 7.7%, Australia
6.7% (2002)
none (territory of the US); there are no first-order
administrative divisions as defined by the US Government, but there
are three districts and two islands* at the second order; Eastern,
Manu''a, Rose Island*, Swains Island*, Western
bananas, coconuts, vegetables, taro, breadfruit,
yams, copra, pineapples, papayas; dairy products, livestock
3 (2002)
23.26 births/1,000 population (2003 est.)
revenues: $121 million (37% in local revenue and 63%
in US grants)
expenditures: $127 million, including capital expenditures of $NA
(FY96/97)
Pago Pago
Democratic Party [leader NA]; Republican Party
[leader NA]','690cf775241538b113072c24a81cd3ed8a39c2302868f504ec46686f86b9c2dc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9d71a0041f4ed976352f850b9e817486255a489a90fb83477d1647d170a2f7b',2003,'AO','Angola','economy',632,'total: 32
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 14
914 to 1,523 m: 5
under 914 m: 1 (2002)
total: 211
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 30
914 to 1,523 m: 95
under 914 m: 80 (2002)
overuse of pastures and subsequent soil erosion attributable
to population pressures; desertification; deforestation of tropical
rain forest, in response to both international demand for tropical
timber and to domestic use as fuel, resulting in loss of
biodiversity; soil erosion contributing to water pollution and
siltation of rivers and dams; inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
5.4% (FY02)
1.45 billion kWh (2001)
1.348 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 36.4%
hydro: 63.6%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 85%, industry and services 15% (1997 est.)
crude oil, diamonds, refined petroleum products, gas, coffee,
sisal, fish and fish products, timber, cotton
US 41.2%, China 13.7%, France 8%, Belgium 6.3%, Taiwan 6.3%,
Japan 4.9%, Spain 4.3% (2002)
18 provinces (provincias, singular - provincia); Bengo,
Benguela, Bie, Cabinda, Cuando Cubango, Cuanza Norte, Cuanza Sul,
Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda Sul, Malanje,
Moxico, Namibe, Uige, Zaire
bananas, sugarcane, coffee, sisal, corn, cotton, manioc
(tapioca), tobacco, vegetables, plantains; livestock; forest
products; fish
243 (2002)
45.57 births/1,000 population (2003 est.)
Army, Navy, Air and Air Defense Forces, National Police Force
revenues: $928 million
expenditures: $2.5 billion, including capital expenditures of $963
million (1992 est.)
Luanda
gas 214 km; liquid natural gas 14 km; liquid petroleum gas 30
km; oil 845 km; refined products 56 km (2003)
Liberal Democratic Party or PLD [Analia de Victoria PEREIRA];
National Front for the Liberation of Angola or FNLA [disputed
leadership: Lucas NGONDA, Holden ROBERTO]; National Union for the
Total Independence of Angola or UNITA [interim leader: PAULO Lukamba
"Gato"], largest opposition party has engaged in years of armed
resistance; Popular Movement for the Liberation of Angola or MPLA
[Jose Eduardo DOS SANTOS], ruling party in power since 1975; Social
Renewal Party or PRS [disputed leadership: Eduardo KUANGANA, Antonio
MUACHICUNGO]
note: about a dozen minor parties participated in the 1992 elections
but only won a few seats and have little influence in the National
Assembly','c318386a268ca1c6561f38511a927a0dfa87e7d1282b16c08c7cb491d7c30892','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d95112543abd12bee54554f825b4ae488a07a7e05bc1c851363d8a5718e4be7',2003,'AI','Anguilla','economy',633,'total: 1
914 to 1,523 m: 1 (2002)
total: 2
under 914 m: 2 (2002)
supplies of potable water sometimes cannot meet increasing
demand largely because of poor distribution system
NA (2000)
42.6 million kWh
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
NA%
lowest 10%: NA%
highest 10%: NA%
commerce 36%, services 29%, construction 18%,
transportation and utilities 10%, manufacturing 3%,
agriculture/fishing/forestry/mining 4% (2000 est,)
lobster, fish, livestock, salt, concrete blocks, rum
UK, US, Puerto Rico, Saint-Martin (2000)
none (overseas territory of the UK)
small quantities of tobacco, vegetables; cattle raising
3 (2002)
14.68 births/1,000 population (2003 est.)
revenues: $22.8 million
expenditures: $22.5 million, including capital expenditures of NA
(2000 est.)
The Valley
Anguilla United Party or AUP [Hubert HUGHES]; The United
Front or UF [Osbourne FLEMING, Victor BANKS], a coalition of the
Anguilla Democratic Party or ADP and the Anguilla National Alliance
or ANA','91a965e4fd6d8e5d074e5563ffc43c5db85ab6e578fb8e1737edfb27006e02ee','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('664d88f83220ca69635e296db8f4b5fbc0ca26d49658a600e3c2fa150b3171b7',2003,'AG','Antigua and Barbuda','economy',634,'total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2002)
total: 1
under 914 m: 1 (2002)
water management - a major concern because of
limited natural fresh water resources - is further hampered by the
clearing of trees to increase crop production, causing rainfall to
run off quickly
Arctic Ocean
endangered marine species include walruses and whales;
fragile ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected agreements
NA%
105.3 million kWh (2001)
97.89 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
commerce and services 82%, agriculture 11%,
industry 7% (1983)
petroleum products 48%, manufactures 23%,
machinery and transport equipment 17%, food and live animals 4%,
other 8%
France 68.5%, Germany 26.4%, Italy 1.2% (2002)
6 parishes and 2 dependencies*; Barbuda*,
Redonda*, Saint George, Saint John, Saint Mary, Saint Paul, Saint
Peter, Saint Philip
cotton, fruits, vegetables, bananas, coconuts,
cucumbers, mangoes, sugarcane; livestock
3 (2002)
18.23 births/1,000 population (2003 est.)
Royal Antigua and Barbuda Defense Force, Royal
Antigua and Barbuda Police Force (including the Coast Guard)
revenues: $123.7 million
expenditures: $145.9 million, including capital expenditures of $NA
(2000 est.)
Saint John''s
Antigua Labor Party or ALP [Lester Bryant BIRD];
Barbuda People''s Movement or BPM [Thomas H. FRANK]; United
Progressive Party or UPP [Baldwin SPENCER] (a coalition of three
opposition parties - United National Democratic Party or UNDP,
Antigua Caribbean Liberation Movement or ACLM, and Progressive Labor
Movement or PLM)','749be1916cff3762f9140bd215d50eba7bdd446f730cee132b792db12559c81e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dacd66b0cc7a465d41f7df4bab99d129dc2ca5952e303f4d410aa28bf25c8cba',2003,'AR','Argentina','economy',635,'total: 145
over 3,047 m: 4
2,438 to 3,047 m: 26
1,524 to 2,437 m: 62
914 to 1,523 m: 44
under 914 m: 9 (2002)
total: 1,197
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 50
914 to 1,523 m: 572
under 914 m: 571 (2002)
environmental problems (urban and rural) typical of an
industrializing economy such as deforestation, soil degradation,
desertification, air pollution, and water pollution
note: Argentina is a world leader in setting voluntary greenhouse
gas targets
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
1.3% (FY00)
97.17 billion kWh (2001)
92.12 billion kWh (2001)
7.417 billion kWh (2001)
5.662 billion kWh (2001)
fossil fuel: 52.2%
hydro: 40.8%
nuclear: 6.7%
other: 0.2% (2001)
37% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
edible oils, fuels and energy, cereals, feed, motor
vehicles
Brazil 23.6%, US 10.9%, Chile 9.7%, Spain 4.3% (2002)
23 provinces (provincias, singular - provincia), and 1
autonomous city* (distrito federal); Buenos Aires, Buenos Aires
Capital Federal*, Catamarca, Chaco, Chubut, Cordoba, Corrientes,
Entre Rios, Formosa, Jujuy, La Pampa, La Rioja, Mendoza, Misiones,
Neuquen, Rio Negro, Salta, San Juan, San Luis, Santa Cruz, Santa Fe,
Santiago del Estero, Tierra del Fuego - Antartida e Islas del
Atlantico Sur, Tucuman
note: the US does not recognize any claims to Antarctica
sunflower seeds, lemons, soybeans, grapes, corn, tobacco,
peanuts, tea, wheat; livestock
1,342 (2002)
17.47 births/1,000 population (2003 est.)
Argentine Army, Navy of the Argentine Republic (includes
naval aviation and Marines), Coast Guard, Argentine Air Force,
National Gendarmerie, National Aeronautical Police Force
revenues: $44 billion
expenditures: $48 billion, including capital expenditures of $NA
(2000 est.)
Buenos Aires
gas 26,797 km; liquid petroleum gas 41 km; oil 3,668 km;
refined products 2,945 km; unknown (oil/water) 13 km (2003)
Action for the Republic or AR [Domingo CAVALLO];
Alternative for a Republic of Equals or ARI [Elisa CARRIO]; Front
for a Country in Solidarity or Frepaso (a four-party coalition)
[Dario Pedro ALESSANDRO]; Justicialist Party or PJ [Carlos Saul
MENEM] (Peronist umbrella political organization); Radical Civic
Union or UCR [Angel ROZAS]; Federal Recreate Movement [Ricardo LOPEZ
MURPHY]; several provincial parties','20901d9bd3224d72560bd1555a8bfb18f2374a0c13b494da84b1205969c7352a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0f832c4279983263eb456cc1ff46a7aabb0dddbce2525f09f23d755e3d7f715',2003,'AM','Armenia','economy',636,'total: 8
over 3,047 m: 2
2,438 to 3,047: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2002)
total: 7
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (2002)
soil pollution from toxic chemicals such as DDT; the energy
crisis of the 1990s led to deforestation when citizens scavenged for
firewood; pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its use as a
source for hydropower, threatens drinking water supplies; restart of
Metsamor nuclear power plant in spite of its location in a
seismically active zone
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
6.5% (FY01)
6.479 billion kWh (2001)
5.784 billion kWh (2001)
463 million kWh; note - imports an unknown quantity from
Iran (2001)
704 million kWh; note - exports an unknown quantity to
Georgia; includes exports to Nagorno-Karabakh region in Azerbaijan
(2001)
fossil fuel: 42.3%
hydro: 27%
nuclear: 30.7%
other: 0% (2001)
50% (2002 est.)
lowest 10%: 2.3%
highest 10%: 46.2% (1999)
agriculture 45%, services 30%, industry 25% (2002 est.)
diamonds, mineral products, foodstuffs, energy
Belgium 21.5%, Russia 14.6%, Israel 10.3%, Iran 9.4%, US
8.2%, Switzerland 6.8%, Germany 6.2% (2002)
11 provinces (marzer, singular - marz); Aragatsotn, Ararat,
Armavir, Geghark''unik'', Kotayk'', Lorri, Shirak, Syunik'', Tavush,
Vayots'' Dzor, Yerevan
fruit (especially grapes), vegetables; livestock
15 (2002)
12.57 births/1,000 population (2003 est.)
Army, Air and Air Defense Forces, Border Guards
revenues: $402 million
expenditures: $482 million, including capital expenditures of $NA
(2001 est.)
Yerevan
gas 2,031 km (2003)
Agro-Industrial Party [Vladimir BADALIAN]; Armenia Party
[Myasnik MALKHASYAN]; Armenian National Movement or ANM [Alex
ARZUMANYAN, chairman]; Armenian Ramkavar Liberal Party or HRAK
[Ruben MIRZAKHANYAN, chairman]; Armenian Revolutionary Federation
("Dashnak" Party) or ARF [Vahan HOVHANISSIAN]; Democratic Party
[Aram SARKISYAN]; Justice Bloc (comprised of the Democratic Party,
National Democratic Party, National Democratic Union, and the
People''s Party); National Democratic Party [Shavarsh KOCHARIAN];
National Democratic Union or NDU [Vazgen MANUKIAN]; National Unity
Party [Artashes GEGAMIAN, chairman]; People''s Party of Armenia
[Stepan DEMIRCHYAN]; Republic Party [Albert BAZEYAN and Aram
SARKISYAN, chairmen]; Republican Party or RPA [Andranik MARKARYAN];
Rule of Law Party [Artur BAGDASARIAN, chairman]; Union of
Constitutional Rights [Hrant KHACHATURYAN]; United Labor Party
[Gurgen ARSENIAN]','de99c69aae39f0049ac78e65dd6d65daa051e022872688e01c931b175de569ea','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('117d2b6e46f4aee7c637026255112fd13561850412a0b00a2aa2860297028d51',2003,'AW','Aruba','economy',637,'total: 1
2,438 to 3,047 m: 1 (2002)
NA
Ashmore and Cartier Islands
NA
Atlantic Ocean
endangered marine species include the manatee, seals,
sea lions, turtles, and whales; drift net fishing is hastening the
decline of fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern Brazil, and
eastern Argentina; oil pollution in Caribbean Sea, Gulf of Mexico,
Lake Maracaibo, Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North Sea, and
Mediterranean Sea
531.9 million kWh (2001)
494.7 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
most employment is in wholesale and retail trade and repair,
followed by hotels and restaurants; oil refining
live animals and animal products, art and collectibles,
machinery and electrical equipment, transport equipment
Netherlands 28.6%, Colombia 21.7%, Panama 16.8%, US 12.1%,
Netherlands Antilles 8.3%, Venezuela 7.6% (2002)
none (part of the Kingdom of the Netherlands)
aloes; livestock; fish
1 (2002)
11.86 births/1,000 population (2003 est.)
no regular indigenous military forces; Royal Dutch Navy and
Marines, Coast Guard
revenues: $135.81 million
expenditures: $147 million, including capital expenditures of $NA
(2000)
Oranjestad
Aruba Solidarity Movement or MAS [leader NA]; Aruban
Democratic Alliance or Aliansa [leader NA]; Aruban Democratic Party
or PDA [Leo BERLINSKI]; Aruban Liberal Party or OLA [Glenbert
CROES]; Aruban Patriotic Party or PPA [Benny NISBET]; Aruban
People''s Party or AVP [Jan (Henny) H. EMAN]; Concentration for the
Liberation of Aruba or CLA [leader NA]; People''s Electoral Movement
Party or MEP [Nelson O. ODUBER]; For a Restructured Aruba Now or
PARA [Urbana LOPEZ]; National Democratic Action or ADN [Pedro Charro
KELLY]','b740c7d3c9572f03f92a9e5c4e9a31f139c1797d86f7961f7818209a592976c7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f2a8236f5d52f2590a1809c2452380e16e13ff9cb39e006d3f71f0abd4743b5',2003,'AU','Australia','economy',638,'total: 294
over 3,047 m: 10
2,438 to 3,047 m: 11
1,524 to 2,437 m: 126
914 to 1,523 m: 134
under 914 m: 13 (2002)
total: 150
1,524 to 2,437 m: 20
914 to 1,523 m: 116
under 914 m: 14 (2002)
soil erosion from overgrazing, industrial development,
urbanization, and poor farming practices; soil salinity rising due
to the use of poor quality water; desertification; clearing for
agricultural purposes threatens the natural habitat of many unique
animal and plant species; the Great Barrier Reef off the northeast
coast, the largest coral reef in the world, is threatened by
increased shipping and its popularity as a tourist site; limited
natural fresh water resources
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
2.9% (FY02)
198.2 billion kWh (2001)
184.4 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 90.8%
hydro: 8.3%
nuclear: 0%
other: 0.9% (2001)
NA%
lowest 10%: 2%
highest 10%: 25.4% (1994)
services 73%, industry 22%, agriculture 5% (1997 est.)
coal, gold, meat, wool, alumina, iron ore, wheat,
machinery and transport equipment
Japan 18.5%, US 9.6%, South Korea 8.3%, China 6.9%, New
Zealand 6.5%, UK 4.7%, Singapore 4.1%, Taiwan 4% (2002)
6 states and 2 territories*; Australian Capital
Territory*, New South Wales, Northern Territory*, Queensland, South
Australia, Tasmania, Victoria, Western Australia
wheat, barley, sugarcane, fruits; cattle, sheep, poultry
444 (2002)
12.55 births/1,000 population (2003 est.)
Australian Army, Royal Australian Navy, Royal Australian
Air Force
revenues: $86.8 billion
expenditures: $84.1 billion, including capital expenditures of $NA
(FY 00/01 est.)
Canberra
condensate 36 km; condensate/gas 243 km; gas 27,321 km;
liquid petroleum gas 240 km; oil 4,779 km; oil/gas/water 104 km;
water 40 km (2003)
Australian Democrats [Andrew BARTLETT]; Australian Labor
Party [Mark LATHAM]; Australian Progressive Alliance [Meg LEES];
Country Labor Party [leader NA]; Australian Greens [Bob BROWN];
Liberal Party [John Winston HOWARD]; The Nationals [John ANDERSON];
One Nation Party [Len HARRIS]','4cdb50054deeaf1490ab20e8ae65c9758ff6d9acb8dacda3508756ded26a14c7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5d3998445839697a0a69cd09520082e185800d324db48d044ee2053a94e3fdd',2003,'AT','Austria','economy',639,'total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 14 (2002)
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 27 (2002)
some forest degradation caused by air and soil pollution;
soil pollution results from the use of agricultural chemicals; air
pollution results from emissions by coal- and oil-fired power
stations and industrial plants and from trucks transiting Austria
between northern and southern Europe
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
0.8% (FY01/02)
58.75 billion kWh (2001)
54.85 billion kWh (2001)
14.47 billion kWh (2001)
14.25 billion kWh (2001)
fossil fuel: 29.3%
hydro: 67.2%
nuclear: 0%
other: 3.5% (2001)
NA%
lowest 10%: 2.5%
highest 10%: 22.5% (1995)
services 67%, industry and crafts 29%, agriculture and
forestry 4% (2001 est.)
machinery and equipment, motor vehicles and parts, paper and
paperboard, metal goods, chemicals, iron and steel; textiles,
foodstuffs
Germany 31.5%, Italy 9.3%, Switzerland 5.4%, US 4.9%, UK
4.9%, France 4.7%, Hungary 4.3% (2002)
9 states (Bundeslaender, singular - Bundesland); Burgenland,
Kaernten, Niederoesterreich, Oberoesterreich, Salzburg, Steiermark,
Tirol, Vorarlberg, Wien
grains, potatoes, sugar beets, wine, fruit; dairy products,
cattle, pigs, poultry; lumber
55 (2002)
9.43 births/1,000 population (2003 est.)
Land Forces (KdoLdSK), Air Forces (KdoLuSK)
revenues: $53 billion
expenditures: $54 billion, including capital expenditures of $NA
(2001 est.)
Vienna
gas 2,722 km; oil 687 km; refined products 149 km (2003)
Austrian People''s Party or OeVP [Wolfgang SCHUESSEL];
Freedom Party of Austria or FPOe [Herbert HAUPT]; Social Democratic
Party of Austria or SPOe [Alfred GUSENBAUER]; The Greens Alternative
or GA [Alexander VAN DER BELLEN]','1c10480980b89cc5a3b6d15f496a70e80f963239b22c88ab35060baa2b8057b7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bb763a585f14cb07638a022e88d015f9cc0b11985a59b1f4bc48d7301bc401a',2003,'AZ','Azerbaijan','economy',640,'total: 27
over 3.047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 1 (2002)
Bahamas, The
total: 30
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 12
914 to 1,523 m: 11
under 914 m: 2 (2002)
total: 44
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 9
under 914 m: 27 (2002)
Bahamas, The
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 22 (2002)
local scientists consider the Abseron Yasaqligi (Apsheron
Peninsula) (including Baku and Sumqayit) and the Caspian Sea to be
the ecologically most devastated area in the world because of severe
air, soil, and water pollution; soil pollution results from oil
spills, from the use of DDT as a pesticide, and from toxic
defoliants used in the production of cotton
Bahamas, The
coral reef decay; solid waste disposal
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Bahamas, The
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2.6% (FY99)
Bahamas, The
0.7% (FY99)
18.23 billion kWh (2001)
Bahamas, The
1.56 billion kWh (2001)
16.65 billion kWh (2001)
Bahamas, The
1.451 billion kWh (2001)
400 million kWh (2001)
Bahamas, The
0 kWh (2001)
700 million kWh (2001)
Bahamas, The
0 kWh (2001)
fossil fuel: 89.7%
hydro: 10.3%
nuclear: 0%
other: 0% (2001)
Bahamas, The
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
49% (2002 est.)
Bahamas, The
NA%
lowest 10%: 2.8%
highest 10%: 27.8% (1995)
Bahamas, The
lowest 10%: NA%
highest 10%: NA%
agriculture and forestry 41%, industry 7%, services 52%
(2001)
Bahamas, The
tourism 50%, other services 40%, industry 5%,
agriculture 5% (1999 est.)
oil and gas 90%, machinery, cotton, foodstuffs
Bahamas, The
fish and crawfish; rum, salt, chemicals; fruit and
vegetables
Italy 28.7%, Germany 17.7%, Israel 10.6%, France 8.4%,
Georgia 6.7%, Russia 4.7% (2002)
Bahamas, The
US 39.1%, Germany 15.4%, Spain 10.8%, France 7.4%,
Poland 4.6%, Switzerland 4.3% (2002)
59 rayons (rayonlar; rayon - singular), 11 cities*
(saharlar; sahar - singular), 1 autonomous republic** (muxtar
respublika); Abseron Rayonu, Agcabadi Rayonu, Agdam Rayonu, Agdas
Rayonu, Agstafa Rayonu, Agsu Rayonu, Ali Bayramli Sahari*, Astara
Rayonu, Baki Sahari*, Balakan Rayonu, Barda Rayonu, Beylaqan Rayonu,
Bilasuvar Rayonu, Cabrayil Rayonu, Calilabad Rayonu, Daskasan
Rayonu, Davaci Rayonu, Fuzuli Rayonu, Gadabay Rayonu, Ganca Sahari*,
Goranboy Rayonu, Goycay Rayonu, Haciqabul Rayonu, Imisli Rayonu,
Ismayilli Rayonu, Kalbacar Rayonu, Kurdamir Rayonu, Lacin Rayonu,
Lankaran Rayonu, Lankaran Sahari*, Lerik Rayonu, Masalli Rayonu,
Mingacevir Sahari*, Naftalan Sahari*, Naxcivan Muxtar
Respublikasi**, Neftcala Rayonu, Oguz Rayonu, Qabala Rayonu, Qax
Rayonu, Qazax Rayonu, Qobustan Rayonu, Quba Rayonu, Qubadli Rayonu,
Qusar Rayonu, Saatli Rayonu, Sabirabad Rayonu, Saki Rayonu, Saki
Sahari*, Salyan Rayonu, Samaxi Rayonu, Samkir Rayonu, Samux Rayonu,
Siyazan Rayonu, Sumqayit Sahari*, Susa Rayonu, Susa Sahari*, Tartar
Rayonu, Tovuz Rayonu, Ucar Rayonu, Xacmaz Rayonu, Xankandi Sahari*,
Xanlar Rayonu, Xizi Rayonu, Xocali Rayonu, Xocavand Rayonu, Yardimli
Rayonu, Yevlax Rayonu, Yevlax Sahari*, Zangilan Rayonu, Zaqatala
Rayonu, Zardab Rayonu
Bahamas, The
21 districts; Acklins and Crooked Islands, Bimini, Cat
Island, Exuma, Freeport, Fresh Creek, Governor''s Harbour, Green
Turtle Cay, Harbour Island, High Rock, Inagua, Kemps Bay, Long
Island, Marsh Harbour, Mayaguana, New Providence, Nichollstown and
Berry Islands, Ragged Island, Rock Sound, Sandy Point, San Salvador
and Rum Cay
cotton, grain, rice, grapes, fruit, vegetables, tea,
tobacco; cattle, pigs, sheep, goats
Bahamas, The
citrus, vegetables; poultry
71 (2002)
Bahamas, The
64 (2002)
19.28 births/1,000 population (2003 est.)
Bahamas, The
18.57 births/1,000 population (2003 est.)
Army, Navy, Air and Air Defense Forces
Bahamas, The
Royal Bahamas Defense Force (Coast Guard only), Royal
Bahamas Police Force
revenues: $786 million
expenditures: $807 million, including capital expenditures of $NA
(2001 est.)
Bahamas, The
revenues: $918.5 million
expenditures: $956.5 million, including capital expenditures of
$106.7 million (FY 99/00)
Baku (Baki)
Bahamas, The
Nassau
gas 5,001 km; oil 1,631 km (2003)
Azerbaijan Popular Front or APF [Ali KARIMLI, leader of
"Reform" faction; Mirmahmud MIRALI-OGLU, leader of "Classic"
faction]; Civic Solidarity Party or CSP [Sabir RUSTAMKHANLY]; Civic
Union Party [Ayaz MUTALIBOV]; Communist Party of Azerbaijan or CPA
[Ramiz AHMADOV]; Compatriot Party [Mais SAFARLI]; Democratic Party
for Azerbaijan or DPA [Rasul QULIYEV, chairman]; Justice Party
[Ilyas ISMAILOV]; Liberal Party of Azerbaijan [Lala Shvkat
HACIYEVA]; Musavat [Isa GAMBAR, chairman]; New Azerbaijan Party or
NAP [Heydar ALIYEV, chairman]; Party for National Independence of
Azerbaijan or PNIA [Etibar MAMMADLI, chairman]; Social Democratic
Party of Azerbaijan or SDP [Zardust ALIZADE]
note: opposition parties regularly factionalize and form new parties
Bahamas, The
Free National Movement or FNM [Tommy TURNQUEST];
Progressive Liberal Party or PLP [Perry CHRISTIE]','dd4e9c190340f8e20b763c6cb1bf470a484fc4cd2a3fd6523ea04a7ded68ffc9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e47c5e183240179ca86d315b1aecfd32da748a6cce88ca31d59af77f8ad8191',2003,'BH','Bahrain','economy',641,'total: 3
over 3,047 m: 2
1524 to 2437 m: 1 (2002)
total: 1
1,524 to 2,437 m: 1 (2002)
desertification resulting from the degradation of limited
arable land, periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and sea vegetation)
resulting from oil spills and other discharges from large tankers,
oil refineries, and distribution stations; lack of freshwater
resources, groundwater and seawater are the only sources for all
water needs
Baker Island
no natural fresh water resources
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
6.7% (FY01)
6.257 billion kWh (2001)
5.819 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
industry, commerce, and service 79%, government 20%,
agriculture 1% (1997 est.)
petroleum and petroleum products, aluminum, textiles
US 4.5%, India 3.2%, Saudi Arabia 2.1% (2002)
12 municipalities (manatiq, singular - mintaqah); Al Hadd,
Al Manamah, Al Mintaqah al Gharbiyah, Al Mintaqah al Wusta, Al
Mintaqah ash Shamaliyah, Al Muharraq, Ar Rifa'' wa al Mintaqah al
Janubiyah, Jidd Hafs, Madinat Hamad, Madinat ''Isa, Juzur Hawar,
Sitrah
note: all municipalities administered from Manama
fruit, vegetables; poultry, dairy products; shrimp, fish
4 (2002)
Baker Island
1 abandoned World War II runway of 1,665 m, completely
covered with vegetation and unusable (2002)
19.02 births/1,000 population (2003 est.)
Bahrain Defense Forces (BDF) comprising Ground Force
(includes Air Defense), Navy, Air Force, Coast Guard, Police Force,
Amiri Guards, National Guard
revenues: $1.8 billion
expenditures: $2.2 billion, including capital expenditures of $700
million (2002 est.)
Manama
gas 20 km; oil 53 km (2003)
political parties prohibited but politically oriented
societies are allowed','65586796a1977751c68b46dd4b38da65bce5796e457e68471024961c459a9a73','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd441fe9339b455228037af52de268001807f630192e2ab858996dff4f2f6620',2003,'BD','Bangladesh','economy',642,'total: 15
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 6 (2002)
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2002)
many people are landless and forced to live on and
cultivate flood-prone land; water-borne diseases prevalent in
surface water; water pollution, especially of fishing areas, results
from the use of commercial pesticides; ground water contaminated by
naturally occurring arsenic; intermittent water shortages because of
falling water tables in the northern and central parts of the
country; soil degradation and erosion; deforestation; severe
overpopulation
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.8% (FY96)
15.33 billion kWh (2001)
14.25 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 93.7%
hydro: 6.3%
nuclear: 0%
other: 0% (2001)
35.6% (FY 95/96 est.)
lowest 10%: 3.9%
highest 10%: 28.6% (1995-96 est.)
agriculture 63%, services 26%, industry 11% (FY 95/96)
garments, jute and jute goods, leather, frozen fish and
seafood (2001)
US 27.6%, Germany 10.4%, UK 9.8%, France 5.7%, Italy 4%
(2002)
5 divisions; Barisal, Chittagong, Dhaka, Khulna,
Rajshahi; note - there may be one additional division named Sylhet
rice, jute, tea, wheat, sugarcane, potatoes, tobacco,
pulses, oilseeds, spices, fruit; beef, milk, poultry
18 (2002)
29.9 births/1,000 population (2003 est.)
Army, Navy, Air Force, Coast Guard, paramilitary forces
(includes Bangladesh Rifles, Bangladesh Ansars, Village Defense
Parties, Armed Police Battalions, National Cadet Corps)
revenues: $4.9 billion
expenditures: $6.8 billion, including capital expenditures of $NA
(FY99/00 est.)
Dhaka
gas 2,016 km (2003)
Awami League or AL [Sheikh HASINA]; Bangladesh Communist
Party or BCP [Saifuddin Ahmed MANIK]; Bangladesh Nationalist Party
or BNP [Khaleda ZIA, chairperson]; Islami Oikya Jote or IOJ [Mufti
Fazlul Haq AMINI]; Jamaat-E-Islami or JI [Motiur Rahman NIZAMI];
Jatiya Party or JP (Ershad faction) [Hussain Mohammad ERSHAD];
Jatiya Party (Manzur faction) [Naziur Rahman MANZUR]','5eded6e92f93bb354aa8a30727f491cd92cb8deb4680e9d438767cf61ab9e269','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b438ea2a6ef51a7e220d8e2c87f1946edb931aed9667da9e51e61a869ec9bcb',2003,'BB','Barbados','economy',643,'total: 1
over 3,047 m: 1 (2002)
pollution of coastal waters from waste disposal by ships;
soil erosion; illegal solid waste disposal threatens contamination
of aquifers
Bassas da India
NA
party to: Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity
NA%
780 million kWh (2001)
725.4 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
services 75%, industry 15%, agriculture 10% (1996 est.)
sugar and molasses, rum, other foods and beverages,
chemicals, electrical components
US 14.7%, Trinidad and Tobago 12%, UK 10.6%, Jamaica 6.2%,
Saint Lucia 4.7% (2002)
11 parishes; Christ Church, Saint Andrew, Saint George,
Saint James, Saint John, Saint Joseph, Saint Lucy, Saint Michael,
Saint Peter, Saint Philip, Saint Thomas; note - the city of
Bridgetown may be given parish status
sugarcane, vegetables, cotton
1 (2002)
13.15 births/1,000 population (2003 est.)
Royal Barbados Defense Force (including Ground Forces and
Coast Guard), Royal Barbados Police Force
revenues: $847 million (including grants)
expenditures: $886 million, including capital expenditures of $NA
(2000 est.)
Bridgetown
Barbados Labor Party or BLP [Owen ARTHUR]; Democratic Labor
Party or DLP [Clyde Mascoll]','4493c12e4958a84320428eceb12b8efda003fcb4589b396c17f98a1d1ada4f52','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ef0cbdd5d5f8980203df77fdb16f25f49cbcc2ceec4c697f34c9e22753c113e',2003,'BY','Belarus','economy',644,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 21
1,524 to 2,437 m: 4
under 914 m: 1 (2002)
total: 96
over 3,047 m: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 11
914 to 1,523 m: 14
under 914 m: 67 (2002)
soil pollution from pesticide use; southern part of the
country contaminated with fallout from 1986 nuclear reactor accident
at Chornobyl'' in northern Ukraine
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
1.4% (FY02)
24.4 billion kWh (2001)
26.69 billion kWh (2001)
4.3 billion kWh (2001)
300 million kWh (2001)
fossil fuel: 99.5%
hydro: 0.1%
nuclear: 0%
other: 0.4% (2001)
22% (1995 est.)
lowest 10%: 5.1%
highest 10%: 20% (1998)
industry and construction NA%, agriculture and forestry NA%,
services NA%
machinery and equipment, mineral products, chemicals,
metals; textiles, foodstuffs
Russia 50.8%, Latvia 7.3%, Ukraine 6.3%, Lithuania 4.1%,
Germany 4.1% (2002)
6 voblastsi (singular - voblasts'') and one municipality*
(harady, singular - horad); Brestskaya (Brest), Homyel''skaya
(Homyel''), Horad Minsk*, Hrodzyenskaya (Hrodna), Mahilyowskaya
(Mahilyow), Minskaya, Vitsyebskaya (Vitsyebsk); note - when using a
place name with the adjectival ending ''skaya,'' the word voblasts''
should be added to the place name
note: voblasti have the administrative center name following in
parentheses
grain, potatoes, vegetables, sugar beets, flax; beef, milk
124 (2002)
10.18 births/1,000 population (2003 est.)
Army, Air Force (including air defense), Interior Ministry
Troops, Border Guards
revenues: $4 billion
expenditures: $4.1 billion, including capital expenditures of $180
million (1997 est.)
Minsk
gas 4,519 km; oil 1,811 km; refined products 1,686 km (2003)
Agrarian Party or AP [Mikhail SHIMANSKY]; Belarusian
Communist Party or KPB [Viktor CHIKIN, chairman]; Belarusian
Ecological Green Party (merger of Belarusian Ecological Party and
Green Party of Belarus) [leader NA]; Belarusian Patriotic Movement
(Belarusian Patriotic Party) or BPR [Anatoliy BARANKEVICH,
chairman]; Belarusian Popular Front or BNF [Vintsuk VYACHORKA];
Belarusian Social-Democrat Party or SDBP [Nikolay STATKEVICH,
chairman]; Belarusian Social-Democratic Party or Hromada [Stanislav
SHUSHKEVICH, chairman]; Belarusian Socialist Party [Vyacheslav
KUZNETSOV]; Civic Accord Bloc (United Civic Party) or CAB [Anatol
LIABEDZKA]; Liberal Democratic Party or LDPB [Sergei GAYDUKEVICH,
chairman]; Party of Communists Belarusian or PKB [Sergei KALYAKIN,
chairman]; Republican Party of Labor and Justice or RPPS [Anatoliy
NETYLKIN, chairman]; Social-Democrat Party of Popular Accord or PPA
[Leanid SECHKA]; Women''s Party or "Nadezhda" [Valentina POLEVIKOVA,
chairperson]','7eabc62711d342cfe15a1a5f9f61e865dd8814f1122e85cb325b5ccaa83631c5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efcae302bbd2533c1be9df2adaf1abe5f7fcbed739afb0b4373c6eee7cd9f724',2003,'BE','Belgium','economy',645,'total: 25
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 7 (2002)
total: 17
914 to 1,523 m: 2
under 914 m: 15 (2002)
the environment is exposed to intense pressures from human
activities: urbanization, dense transportation network, industry,
extensive animal breeding and crop cultivation; air and water
pollution also have repercussions for neighboring countries;
uncertainties regarding federal and regional responsibilities (now
resolved) have slowed progress in tackling environmental challenges
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Air
Pollution-Sulphur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Kyoto
Protocol, Law of the Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.4% (FY01/02)
74.28 billion kWh (2001)
78.18 billion kWh (2001)
15.82 billion kWh (2001)
6.712 billion kWh (2001)
fossil fuel: 38.4%
hydro: 0.6%
nuclear: 59.3%
other: 1.8% (2001)
4%
lowest 10%: 3.2%
highest 10%: 23% (1996)
services 73%, industry 25%, agriculture 2% (1999 est.)
machinery and equipment, chemicals, diamonds, metals and
metal products, foodstuffs
Germany 18.6%, France 16.3%, Netherlands 11.6%, UK 9.6%, US
7.9%, Italy 5.4% (2002)
10 provinces (French: provinces, singular - province; Dutch:
provincies, singular - provincie) and 3 regions* (French: regions;
Dutch: gewesten); Antwerpen, Brabant Wallon, Brussels* (Bruxelles),
Flanders*, Hainaut, Liege, Limburg, Luxembourg, Namur,
Oost-Vlaanderen, Vlaams-Brabant, Wallonia*, West-Vlaanderen
sugar beets, fresh vegetables, fruits, grain, tobacco; beef,
veal, pork, milk
42 (2002)
10.45 births/1,000 population (2003 est.)
Army, Navy, Air Components, Federal Police
revenues: $113.4 billion
expenditures: $106 billion, including capital expenditures of $7.17
billion (2000)
Brussels
gas 1,485 km; oil 158 km; refined products 535 km (2003)
Bolivia
gas 4,860 km; liquid petroleum gas 47 km; oil 2,460 km;
refined products 1,589 km; unknown (oil/water) 247 km (2003)
AGALEV (Flemish Greens) [Dirk HOLEMANS]; Christian Democrats
and Flemish or CD & V [Yves LETERME]; note - used to be the Flemish
Christian Democrats or CVP; Ecolo (Francophone Greens) [Jean-Michel
JAVAUK, Evelyne HUYTEBROECK, Claude BROUIR]; Flemish Liberal
Democrats or VLD [Karel DE GUCHT]; Francophone Humanist and
Democratic Center of CDH (used to be Social Christian Party or PSC)
[Joelle MILQUET]; Francophone Reformist Movement or MR (used to be
Liberal Reformation Party or PRL) [Antoine DUQUESNE]; Francophone
Socialist Party or PS [Elio DI RUPO]; National Front or FN [Daniel
FERET]; New Flemish Alliance or NVA [Geert BOURGEOIS]; note - new
party that emerged after the demise of the People''s Union or VU;
Social Progressive Alternative Party or SP.A [Steve STEVAERT]; note
- was Flemish Socialist Party or SP; Spirit [Els VAN WEERT]; note -
new party that emerged after the demise of the People''s Union or VU;
Vlaams Blok or VB [Frank VANHECKE]; other minor parties','7026ee258022bfd4dfe7b7dd46d0d91148f65231c6f6696df2fdb9ba18c6815f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae62f85ad9704cc8301050293e2f155dc4b555772d5739a55358faa45b3da53a',2003,'BZ','Belize','economy',646,'total: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 2 (2002)
total: 38
2,438 to 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 27 (2002)
deforestation; water pollution from sewage, industrial
effluents, agricultural runoff; solid and sewage waste disposal
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.87% (FY00/01)
199.5 million kWh (2001)
185.5 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 59.9%
hydro: 40.1%
nuclear: 0%
other: 0% (2001)
33% (1999 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture 27%, industry 18%, services 55% (2001 est.)
sugar, bananas, citrus, clothing, fish products, molasses,
wood
US 40.5%, UK 23.2%, Peru 8.3% (2002)
6 districts; Belize, Cayo, Corozal, Orange Walk, Stann Creek,
Toledo
bananas, coca, citrus, sugar; fish, cultured shrimp; lumber;
garments
42 (2002)
30.46 births/1,000 population (2003 est.)
Belize Defense Force (includes Army, Maritime Wing, Air Wing,
and Volunteer Guard)
revenues: $224 million
expenditures: $209 million, including capital expenditures of $70
million (2002 est.)
Belmopan
People''s United Party or PUP [Said MUSA]; United Democratic
Party or UDP [Dean BARROW, party leader; Douglas SINGH, party
chairman]','25771a25298b3d57f044c9a656ec21553f16271229b90f019ddbd58af9996772','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('789a9e63e8b17bcff99688d0e87f8152ce95c71ebdbae18a49cc09204b21f6f3',2003,'BJ','Benin','economy',647,'total: 1
1,524 to 2,437 m: 1 (2002)
total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2002)
inadequate supplies of potable water; poaching threatens
wildlife populations; deforestation; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2.7% (FY02)
274.3 million kWh (2001)
631.1 million kWh (2001)
376 million kWh (2001)
0 kWh (2001)
fossil fuel: 14.2%
hydro: 85.8%
nuclear: 0%
other: 0% (2001)
37% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
cotton, crude oil, palm products, cocoa
India 25%, Italy 11.1%, Indonesia 7.4%, China 7.2%, Thailand
6.7%, Brazil 6.1%, UK 4.4%, Niger 4% (2002)
12 departments; Alibori, Atakora, Atlantique, Borgou,
Collines, Kouffo, Donga, Littoral, Mono, Oueme, Plateau, Zou
cotton, corn, cassava (tapioca), yams, beans, palm oil,
peanuts, livestock (2001)
5 (2002)
43.15 births/1,000 population (2003 est.)
Armed Forces (including Army, Navy, Air Force), National
Gendarmerie
revenues: $377.4 million
expenditures: $561.8 million, including capital expenditures of $NA
(2001)
Porto-Novo is the official capital; Cotonou is the seat of
African Congress for Renewal or DUNYA [Saka SALEY]; African
Movement for Democracy and Progress or MADEP [Sefou FAGBOHOUN];
Alliance of the Social Democratic Party or PSD [Bruno AMOUSSOU];
Coalition of Democratic Forces [Gatien HOUNGBEDJI]; Democratic
Renewal Party or PRD [Adrien HOUNGBEDJI]; Front for Renewal and
Development or FARD-ALAFIA [Jerome Sakia KINA]; Impulse for Progress
and Democracy or IPD [Bertin BORNA]; Key Force or FC [leader NA];
Presidential Movement (UBF, MADEP, FC, IDP, and 4 other small
parties); Renaissance Party du Benin or PRB [Nicephore SOGLO]; The
Star Alliance (Alliance E''toile) [Sacca LAFIA]; Union of Tomorrow''s
Benin or UBF [Bruno AMOUSSOU]
note: approximately 20 additional minor parties','41cb21c10d007996106edc751a6c139e97f303875c3d78ee04d23a4eeb802f18','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db672d2056f48de2ea6dfc141bc65c97a4750f895c2bb499989d72383b42f840',2003,'BM','Bermuda','economy',648,'total: 1
2,438 to 3,047 m: 1 (2002)
asbestos disposal; water pollution; preservation of open
space; sustainable development
0.11% (FY00/01)
643.7 million kWh (2001)
598.6 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
clerical 22%, services 20%, laborers 17%, professional and
technical 17%, administrative and managerial 13%, sales 8%,
agriculture and fishing 3% (2000 est.)
reexports of pharmaceuticals
France 77.4%, UK 2.8%, US 2.4% (2002)
9 parishes and 2 municipalities*; Devonshire, Hamilton,
Hamilton*, Paget, Pembroke, Saint George*, Saint George''s, Sandys,
Smith''s, Southampton, Warwick
bananas, vegetables, citrus, flowers; dairy products
1 (2002)
12.13 births/1,000 population (2003 est.)
no regular indigenous military forces; Bermuda Regiment,
Bermuda Police Force, Bermuda Reserve Constabulary
revenues: $609.5 million
expenditures: $574.6 million, including capital expenditures of
$54.8 million (FY 00/01)
National Liberal Party or NLP [Dessaline WALDRON];
Progressive Labor Party or PLP [Jennifer SMITH]; United Bermuda
Party or UBP [Chairman Wayne FURBERT]','6020f14415ed33ad38ca206615dca589f01dd5106c274be2189c35b148647d36','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f54afe630cf793325c67f2d9a1329181bc742d3b94c1ce22c4bea5efcbe363',2003,'BT','Bhutan','economy',649,'total: 1
1,524 to 2,437 m: 1 (2002)
Bolivia
total: 12
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2002)
total: 1
914 to 1,523 m: 1 (2002)
Bolivia
total: 1,069
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 64
914 to 1,523 m: 225
under 914 m: 776 (2002)
soil erosion; limited access to potable water
Bolivia
the clearing of land for agricultural purposes and the
international demand for tropical timber are contributing to
deforestation; soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture); desertification;
loss of biodiversity; industrial pollution of water supplies used
for drinking and irrigation
party to: Biodiversity, Climate Change, Nuclear Test Ban
signed, but not ratified: Law of the Sea
Bolivia
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Nuclear Test Ban, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection
1.9% (FY02)
Bolivia
1.8% (FY99)
1.896 billion kWh (2001)
Bolivia
3.901 billion kWh (2001)
379.5 million kWh (2001)
Bolivia
3.634 billion kWh (2001)
16 million kWh (2001)
Bolivia
9 million kWh (2001)
1.4 billion kWh (2001)
Bolivia
3 million kWh (2001)
fossil fuel: 0.1%
hydro: 99.9%
nuclear: 0%
other: 0% (2001)
Bolivia
fossil fuel: 44.4%
hydro: 54%
nuclear: 0%
other: 1.5% (2001)
NA%
Bolivia
70% (1999 est.)
lowest 10%: NA%
highest 10%: NA%
Bolivia
lowest 10%: 1.3%
highest 10%: 32% (1999)
agriculture 93%, services 5%, industry and commerce 2%
Bolivia
agriculture NA%, industry NA%, services NA%
electricity (to India), cardamom, gypsum, timber,
handicrafts, cement, fruit, precious stones, spices
Bolivia
soybeans, natural gas, zinc, gold, wood (2000)
US 24.1%, UK 23.9%, Pakistan 23.1%, France 13.9% (2002)
Bolivia
Brazil 24.3%, Switzerland 15.7%, US 14.1%, Venezuela 12.8%,
Colombia 10.2%, Peru 5.4% (2002)
18 districts (dzongkhag, singular and plural); Bumthang,
Chhukha, Chirang, Dagana, Geylegphug, Ha, Lhuntshi, Mongar, Paro,
Pemagatsel, Punakha, Samchi, Samdrup Jongkhar, Shemgang, Tashigang,
Thimphu, Tongsa, Wangdi Phodrang
note: there may be two new districts named Gasa and Yangtse
Bolivia
9 departments (departamentos, singular - departamento);
Chuquisaca, Cochabamba, Beni, La Paz, Oruro, Pando, Potosi, Santa
Cruz, Tarija
rice, corn, root crops, citrus, foodgrains; dairy products,
eggs
Bolivia
soybeans, coffee, coca, cotton, corn, sugarcane, rice,
potatoes; timber
2 (2002)
Bolivia
1,081 (2002)
34.82 births/1,000 population (2003 est.)
Bolivia
25.53 births/1,000 population (2003 est.)
Royal Bhutan Army, Royal Bodyguard, National Militia, Royal
Bhutan Police, Forest Guards
Bolivia
Army (Ejercito Boliviano), Navy (Fuerza Naval, includes
Marines), Air Force (Fuerza Aerea Boliviana), National Police Force
(Policia Nacional de Bolivia)
revenues: $146 million
expenditures: $152 million, including capital expenditures of NA
note: the government of India finances nearly three-fifths of
Bhutan''s budget expenditures (FY95/96 est.)
Bolivia
revenues: $4 billion
expenditures: $4 billion, including capital expenditures of $NA
(2002 est.)
no legal parties
Bolivia
Bolivian Socialist Falange or FSB [Romel PANTOJA]; Civic
Solidarity Union or UCS [Johnny FERNANDEZ]; Free Bolivia Movement or
MBL [Franz BARRIOS]; Marshal of Ayacucho Institutional Vanguard or
VIMA [Freddy ZABALA]; Movement of the Revolutionary Left or MIR
[Jaime PAZ Zamora]; Movement Toward Socialism or MAS [Evo MORALES];
Movement Without Fear or MSM [Juan DEL GRANADO]; Nationalist
Democratic Action or ADN [Jorge Fernando QUIROGA Ramirez];
Nationalist Revolutionary Movement or MNR [Gonzalo SANCHEZ DE
LOZADA]; New Republican Force or NFR [Manfred REYES-VILLA];
Pachakuti Indigenous Movement or MIP [Felipe QUISPE]; Socialist
Party or PS [Jeres JUSTINIANO]
note: the MNR, MIR, and UCS comprise the ruling coalition','913dbb63c0e954b1a5ee0746fc4e101fddeb7c72a7617a3bebfb16003bb53e8f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39518f79d39270e54b1b022b2bea6d6f4bcec357c35900120c8fc665def11e01',2003,'BA','Bosnia and Herzegovina','economy',650,'total: 14
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1523 m: 1
under 914 m: 3 (2002)
total: 18
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 10 (2002)
air pollution from metallurgical plants;
sites for disposing of urban waste are limited; water shortages and
destruction of infrastructure because of the 1992-95 civil strife
party to: Air Pollution, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
4.5% (FY02)
9.979 billion kWh (2001)
8.116 billion kWh (2001)
1.405 billion kWh (2001)
2.569 billion kWh (2001)
fossil fuel: 53.5%
hydro: 46.5%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
metals, clothing, wood products
Italy 31.6%, Croatia 18%, Germany 12.9%,
Austria 10.1%, Slovenia 6.9%, Greece 4.3% (2002)
there are two first-order administrative
divisions and one internationally supervised district* - Brcko
district (Brcko Distrikt)*, the Bosniak/Croat Federation of Bosnia
and Herzegovina (Federacija Bosna i Hercegovina) and the Bosnian
Serb-led Republika Srpska; note - Brcko district is in northeastern
Bosnia and is an administrative unit under the sovereignty of Bosnia
and Herzegovina; the district remains under international supervision
wheat, corn, fruits, vegetables; livestock
32 (2002)
12.65 births/1,000 population (2003 est.)
VF Army (the air and air defense forces are
subordinate commands within the Army), VRS Army (the air and air
defense forces are subordinate commands within the Army)
revenues: $1.9 billion
expenditures: $2.2 billion, including capital expenditures of $NA
(1999 est.)
gas 170 km; oil 9 km (2003)
Alliance of Independent Social Democrats or
SNSD [Milorad DODIK]; Bosnian Party or BOSS [Mirnes AJANOVIC]; Civic
Democratic Party or GDS [Ilija SIMIC]; Croatian Democratic Union of
Bosnia and Herzegovina or HDZ [Barisa COLAK (acting)]; Croat
Christian Democratic Union of Bosnia and Herzegovina or HKDU [Mijo
IVANIC-LONIC]; Croat Party of Rights or HSP [Zdravko HRISTIC]; Croat
Peasants Party or HSS [Ilija SIMIC]; Democratic National Union or
DNZ [Fikret ABDIC]; Liberal Democratic Party or LDS [Rasim KADIC];
New Croat Initiative or NHI [Kresimir ZUBAK]; Party for Bosnia and
Herzegovina or SBiH [Safet HALILOVIC]; Party of Democratic Action or
SDA [Sulejman TIHIC]; Party of Democratic Progress or PDP [Mladen
IVANIC]; Pro-European People''s Party or PROENS [Jadranko PRLIC];
Serb Democratic Party or SDS [Dragan KALINIC]; Serb Radical Party of
the Republika Srpska or SRS-RS [Radislav KANJERIC]; Social
Democratic Party of BIH or SDP [Zlatko LAGUMDZIJA]; Socialist Party
of Republika Srpska or SPRS [Petar DJOKIC]','b7c78f8d4a53299735969f7c0f663e21ed488c385772ef2cc7de470f0ff90597','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60227a423961242a9cddb977a79f334c3b282909ba8cec060822f44575f25f7b',2003,'BW','Botswana','economy',651,'total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2002)
total: 76
1,524 to 2,437 m: 3
914 to 1,523 m: 55
under 914 m: 18 (2002)
overgrazing; desertification; limited fresh water resources
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
3.5% (FY02)
409.8 million kWh (2001)
1.564 billion kWh (2001)
1.183 billion kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
47%
lowest 10%: NA%
highest 10%: NA%
NA
diamonds 90%, copper, nickel, soda ash, meat, textiles
European Free Trade Association (EFTA) 87%, Southern
African Customs Union (SACU) 7%, Zimbabwe 4% (2000)
9 districts and four town councils*; Central, Francistown*,
Gaborone*, Ghanzi, Kgalagadi, Kgatleng, Kweneng, Lobatse*,
Northwest, Northeast, Selebi-Pikwe*, Southeast, Southern
livestock, sorghum, maize, millet, beans, sunflowers,
groundnuts
86 (2002)
25.5 births/1,000 population (2003 est.)
Botswana Defense Force (including Army and Air Wing),
Botswana National Police
revenues: $2.3 billion
expenditures: $2.4 billion, including capital expenditures of $NA
(FY 01/02)
Botswana Democratic Party or BDP [Festus MOGAE]; Botswana
National Front or BNF [Otswoletse MOUPO]; Botswana Congress Party or
BCP [Mokgweetsi KGOSIPULA]; Botswana Alliance Movement or BAM
[Ephraim Lepetu SETSHWAELO]
note: a number of minor parties joined forces in 1999 to form the
BAM but did not capture any parliamentary seats; the BAM parties
are: the United Action Party [Ephraim Lepetu SETSHWAELO], the
Independence Freedom Party or IFP [Motsamai MPHO], and the Botswana
Progressive Union [D. K. KWELE]','0cd348d1c042a1cb53ca96981a071d71f994ce013db27910484fb8dc5fc43e90','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba044c433fddebff04acf7b250eb6063fbc1b57602c4a62f2ac8da13a6119d32',2003,'BR','Brazil','economy',652,'total: 665
over 3,047 m: 7
2,438 to 3,047 m: 23
1,524 to 2,437 m: 155
914 to 1,523 m: 435
under 914 m: 45 (2002)
total: 2,925
1,524 to 2,437 m: 70
914 to 1,523 m: 1,384
under 914 m: 1,471 (2002)
British Virgin Islands
total: 1
914 to 1,523 m: 1 (2002)
Brunei
total: 1
914 to 1,523 m: 1 (2002)
deforestation in Amazon Basin destroys the habitat and
endangers a multitude of plant and animal species indigenous to the
area; there is a lucrative illegal wildlife trade; air and water
pollution in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by improper
mining activities; wetland degradation; severe oil spills
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Brunei
party to: Endangered Species, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
1.9% (FY99)
Brunei
5% (FY02)
321.2 billion kWh (2001)
335.9 billion kWh (2001)
37.19 billion kWh; note - supplied by Paraguay (2001)
British Virgin Islands
0 kWh (2001)
Brunei
0 kWh (2001)
0 kWh (2001)
British Virgin Islands
0 kWh (2001)
Brunei
0 kWh (2001)
fossil fuel: 8.3%
hydro: 82.7%
nuclear: 4.4%
other: 4.6% (2001)
British Virgin Islands
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Brunei
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
22% (1998 est.)
British Virgin Islands
NA%
Brunei
NA%
lowest 10%: 0.7%
highest 10%: 48% (1998)
British Virgin Islands
lowest 10%: NA%
highest 10%: NA%
Brunei
lowest 10%: NA%
highest 10%: NA%
services 53%, agriculture 23%, industry 24%
British Virgin Islands
agriculture NA%, industry NA%, services NA%
Brunei
government 48%, production of oil, natural gas, services, and
construction 42%, agriculture, forestry, and fishing 10% (1999 est.)
transport equipment, iron ore, soybeans, footwear, coffee,
autos
British Virgin Islands
rum, fresh fish, fruits, animals; gravel, sand
Brunei
crude oil, natural gas, refined products
US 23.8%, Argentina 8.5%, Germany 5%, China 4.3%, Netherlands
4.2% (2002)
British Virgin Islands
Virgin Islands (US), Puerto Rico, US
Brunei
Japan 40.3%, South Korea 12.3%, Thailand 12.1%, Australia
9.2%, US 8.1%, China 6.4%, Singapore 5.7% (2002)
26 states (estados, singular - estado) and 1 federal
district* (distrito federal); Acre, Alagoas, Amapa, Amazonas, Bahia,
Ceara, Distrito Federal*, Espirito Santo, Goias, Maranhao, Mato
Grosso, Mato Grosso do Sul, Minas Gerais, Para, Paraiba, Parana,
Pernambuco, Piaui, Rio de Janeiro, Rio Grande do Norte, Rio Grande
do Sul, Rondonia, Roraima, Santa Catarina, Sao Paulo, Sergipe,
Tocantins
British Virgin Islands
none (overseas territory of the UK)
Brunei
4 districts (daerah-daerah, singular - daerah); Belait,
Brunei and Muara, Temburong, Tutong
coffee, soybeans, wheat, rice, corn, sugarcane, cocoa,
citrus; beef
British Virgin Islands
fruits, vegetables; livestock, poultry; fish
Brunei
rice, vegetables, fruits, chickens, water buffalo
3,590 (2002)
17.67 births/1,000 population (2003 est.)
British Virgin Islands
15 births/1,000 population (2003 est.)
Brunei
19.68 births/1,000 population (2003 est.)
Brazilian Army, Brazilian Navy (includes naval air and
marines), Brazilian Air Force, Federal Police (paramilitary)
Brunei
Land Forces, Navy, Air Force, Royal Brunei Police
revenues: $100.6 billion
expenditures: $91.6 billion, including capital expenditures of $NA
(2000)
British Virgin Islands
revenues: $121.5 million
expenditures: $115.5 million, including capital expenditures of $NA
(1997)
Brunei
revenues: $2.5 billion
expenditures: $2.6 billion, including capital expenditures of $1.35
billion (1997 est.)
condensate/gas 243 km; gas 10,984 km; liquid petroleum gas
341 km; oil 5,113 km; refined products 4,800 km (2003)
Brunei
gas 665 km; oil 439 km (2003)
Brazilian Democratic Movement Party or PMDB [Michel TEMER];
Brazilian Labor Party or PTB [Jose Carlos MARTINEZ]; Brazilian
Social Democracy Party or PSDB [Senator Jose ANIBAL]; Brazilian
Socialist Party or PSB [Miguel ARRAES]; Brazilian Progressive Party
or PPB [Paulo Salim MALUF]; Communist Party of Brazil or PCdoB
[Renato RABELLO]; Democratic Labor Party or PDT [Leonel BRIZOLA];
Green Party or PV [leader NA]; Liberal Front Party or PFL [Jorge
BORNHAUSEN]; Liberal Party or PL [Deputy Valdemar COSTA Neto];
National Order Reconstruction Party or PRONA [Dr. Eneas CARNEIRO];
Popular Socialist Party or PPS [Senator Roberto FREIRE]; Social
Democratic Party or PSD [leader NA]; Worker''s Party or PT [Jose
GENOINO]
British Virgin Islands
Concerned Citizens Movement or CCM [Ethlyn
SMITH]; National Democratic Party or NDP [Orlando SMITH]; United
Party or UP [Gregory MADURO]; Virgin Islands Party or VIP [Ralph T.
O''NEAL]
Brunei
Brunei Solidarity National Party or PPKB in Malay [Haji Mohd
HATTA bin Haji Zainal Abidin, president]; note - the PPKB is the
only legal political party in Brunei; it was registered in 1985 but
became largely inactive after 1988; it was revived in 1995 and again
in 1998; it has less than 200 registered party members; other
parties include Brunei People''s Party or PRB (banned in 1962) and
Brunei National Democratic Party (registered in May 1965,
deregistered by the Brunei Government in 1988)','11a59b2b8ee1f7e1f28263ccce52daa7e614e848282a08e06681ba595eb75ddc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a72a4983777e5261d3a672200814da6b6d04e8ab64789b9eea07cc56a1d7a86',2003,'IO','British Indian Ocean Territory','economy',653,'total: 1
over 3,047 m: 1 (2002)
British Virgin Islands
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2002)
Brunei
total: 1
over 3,047 m: 1 (2002)
NA
British Virgin Islands
limited natural fresh water resources (except
for a few seasonal streams and springs on Tortola, most of the
islands'' water supply comes from wells and rainwater catchments)
Brunei
seasonal smoke/haze resulting from forest fires in Indonesia
NA kWh; note - electricity supplied
by the US military
British Virgin Islands
38.1 million kWh (2001)
Brunei
2.497 billion kWh (2001)
NA kWh
British Virgin Islands
35.43 million kWh (2001)
Brunei
2.322 billion kWh (2001)
1 (2002)
British Virgin Islands
3 (2002)
Brunei
2 (2002)','3fcce136c69b7a334d12dc63aa40437edec362186f8e7df5a51905116b20d5a3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a8a21799eb81927ef3abd19aeb9096782f41a47278b8127af62f5f23875cfcc',2003,'BG','Bulgaria','economy',654,'total: 128
over 3,047 m: 1
2,438 to 3,047 m: 20
1,524 to 2,437 m: 14
914 to 1,523 m: 1
under 914 m: 92 (2002)
total: 88
1,524 to 2,437 m: 4
914 to 1,523 m: 10
under 914 m: 74 (2002)
air pollution from industrial emissions; rivers polluted
from raw sewage, heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical plants and
industrial wastes
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol
2.7% (FY02)
41.38 billion kWh (2001)
32.52 billion kWh (2001)
830 million kWh (2001)
6.79 billion kWh (2001)
fossil fuel: 47.8%
hydro: 8.1%
nuclear: 44.1%
other: 0% (2001)
12.6% (2001 est.)
lowest 10%: 4.5%
highest 10%: 22.8% (1997)
agriculture 26%, industry 31%, services 43% (1998 est.)
clothing, footwear, iron and steel, machinery and
equipment, fuels
Italy 15.5%, Germany 9.6%, Turkey 9.4%, Greece 9.2%, France
5.3%, US 4.8% (2002)
28 provinces (oblasti, singular - oblast); Blagoevgrad,
Burgas, Dobrich, Gabrovo, Khaskovo, Kurdzhali, Kyustendil, Lovech,
Montana, Pazardzhik, Pernik, Pleven, Plovdiv, Razgrad, Ruse, Shumen,
Silistra, Sliven, Smolyan, Sofiya, Sofiya-Grad, Stara Zagora,
Turgovishte, Varna, Veliko Turnovo, Vidin, Vratsa, Yambol
vegetables, fruits, tobacco, livestock, wine, wheat,
barley, sunflowers, sugar beets
216 (2002)
8.02 births/1,000 population (2003 est.)
Army, Navy, Air and Air Defense Forces (subordinate to
Ministry of Defense), Internal Forces (subordinate to Ministry of
Interior), Civil Defense Forces (subordinate to the president)
revenues: $5.57 billion
expenditures: $5.68 billion, including capital expenditures of $NA
(2001 est.)
gas 2,425 km; oil 339 km; refined products 156 km (2003)
Burma
gas 2,056 km; oil 558 km (2003)
Bulgarian Socialist Party or BSP [Sergei STANISHEV];
Coalition for Bulgaria or CfB (coalition of parties dominated by
BSP) [Sergei STANISHEV]; Internal Macedonian Revolutionary
Organization or VMRO [Krasimir KARAKACHANOV]; Movement for Rights
and Freedoms or MRF [Ahmed DOGAN]; National Movement for Simeon II
or NMS2 [Simeon SAXE-COBURG-GOTHA]; Union of Democratic Forces or
UDF [Nadezhda MIKHAYLOVA]; Union of Free Democrats or UFD [Stefan
SOFIYANSKI]; United Democratic Forces or UtdDF (a coalition between
the UDF and other center-right parties)','2423283d7d65986cbc6aac071bdbbb1d16d4aaa30806ec29b0a00ece3f8afd15','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8ad6c06c8eda4db6526c374d85058627fcdeb8919348ba5e95c004d627b49c8',2003,'BF','Burkina Faso','economy',655,'total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2002)
Burma
total: 8
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2002)
total: 31
1,524 to 2,437 m: 3
914 to 1,523 m: 11
under 914 m: 17 (2002)
Burma
total: 72
over 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 20
under 914 m: 34 (2002)
recent droughts and desertification severely affecting
agricultural activities, population distribution, and the economy;
overgrazing; soil degradation; deforestation
Burma
deforestation; industrial pollution of air, soil, and water;
inadequate sanitation and water treatment contribute to disease
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Nuclear Test Ban
Burma
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
1.4% (FY02)
Burma
2.1% (FY97)
279.2 million kWh (2001)
Burma
6.139 billion kWh (2001)
259.6 million kWh (2001)
Burma
5.709 billion kWh (2001)
0 kWh (2001)
Burma
0 kWh (2001)
0 kWh (2001)
Burma
0 kWh (2001)
fossil fuel: 69.9%
hydro: 30.1%
nuclear: 0%
other: 0% (2001)
Burma
fossil fuel: 44.4%
hydro: 55.6%
nuclear: 0%
other: 0% (2001)
45% (2001 est.)
Burma
25% (2000 est.)
lowest 10%: 2%
highest 10%: 46.8% (1994)
Burma
lowest 10%: 2.8%
highest 10%: 32.4% (1998)
agriculture 90% (2000 est.)
Burma
agriculture 70%, industry 7%, services 23% (2001 est.)
cotton, livestock, gold
Burma
gas, wood products, pulses, beans, fish, rice
Singapore 14.7%, Italy 11.3%, Colombia 8.6%, France
7.7%, India 6.9%, Ghana 6%, Japan 4.4%, Thailand 4.3% (2002)
Burma
Thailand 31.4%, US 13%, India 7.4%, China 4.7% (2002)
45 provinces; Bale, Bam, Banwa, Bazega, Bougouriba,
Boulgou, Boulkiemde, Comoe, Ganzourgou, Gnagna, Gourma, Houet, Ioba,
Kadiogo, Kenedougou, Komondjari, Kompienga, Kossi, Koulpelogo,
Kouritenga, Kourweogo, Leraba, Loroum, Mouhoun, Namentenga, Nahouri,
Nayala, Noumbiel, Oubritenga, Oudalan, Passore, Poni, Sanguie,
Sanmatenga, Seno, Sissili, Soum, Sourou, Tapoa, Tuy, Yagha, Yatenga,
Ziro, Zondoma, Zoundweogo
Burma
7 divisions* (taing-myar, singular - taing) and 7 states (pyi
ne-myar, singular - pyi ne); Chin State, Ayeyarwady*, Bago*, Kachin
State, Kayin State, Kayah State, Magway*, Mandalay*, Mon State,
Rakhine State, Sagaing*, Shan State, Tanintharyi*, Yangon*
cotton, peanuts, shea nuts, sesame, sorghum, millet,
corn, rice; livestock
Burma
rice, pulses, beans, sesame, groundnuts, sugarcane; hardwood;
fish and fish products
33 (2002)
Burma
80 (2002)
44.78 births/1,000 population (2003 est.)
Burma
19.15 births/1,000 population (2003 est.)
Army, Air Force, National Gendarmerie, National Police,
People''s Militia
Burma
Army, Navy, Air Force
revenues: $316 million
expenditures: $NA, including capital expenditures of $NA (2001)
Burma
revenues: $7.9 billion
expenditures: $12.2 billion, including capital expenditures of $5.7
billion (FY96/97)
African Democratic Rally-Alliance for Democracy and
Federation or RDA-ADF [Herman YAMEOGO]; Confederation for Federation
and Democracy or CFD [Amadou Diemdioda DICKO]; Congress for
Democracy and Progress or CDP [Roch Marc-Christian KABORE]; Movement
for Tolerance and Progress or MTP [Nayabtigungou Congo KABORE];
Party for African Independence or PAI [Philippe OUEDRAOGO]; Party
for Democracy and Progress or PDP [Joseph KI-ZERBO]; Union of Greens
for the Development of Burkina Faso or UVDB [Ram OVEDRAGO]
Burma
National League for Democracy or NLD [AUNG SHWE, chairman,
AUNG SAN SUU KYI, general secretary]; National Unity Party or NUP
(proregime) [THA KYAW]; Shan Nationalities League for Democracy or
SNLD [KHUN TUN OO]; Union Solidarity and Development Association or
USDA (proregime, a social and political organization) [THAN AUNG,
general secretary]; and other smaller parties','b7742f468db0901f696119a2221ea750ee7fd3f3f9290422931f5649cd3a416b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ad0c2611100a4a8b855c1bd767e3e3c9270a987f019dba9e28a313790b51199',2003,'BI','Burundi','economy',656,'total: 1
over 3,047 m: 1 (2002)
total: 6
914 to 1,523 m: 3
under 914 m: 3 (2002)
soil erosion as a result of overgrazing and the expansion of
agriculture into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for fuel); habitat
loss threatens wildlife populations
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear Test Ban
5.3% (FY02)
155.4 million kWh (2001)
177.5 million kWh (2001)
33 million kWh; note - supplied by the Democratic Republic
of the Congo (2001)
0 kWh (2001)
fossil fuel: 0.6%
hydro: 99.4%
nuclear: 0%
other: 0% (2001)
70% (2002 est.)
lowest 10%: 1.8%
highest 10%: 32.9% (1998)
NA
coffee, tea, sugar, cotton, hides
Switzerland 28.8%, Germany 20.2%, Belgium 9.4%, Kenya 7.8%,
Rwanda 6.5%, Netherlands 4.6% (2002)
16 provinces; Bubanza, Bujumbura, Bururi, Cankuzo, Cibitoke,
Gitega, Karuzi, Kayanza, Kirundo, Makamba, Muramvya, Muyinga, Mwaro,
Ngozi, Rutana, Ruyigi
coffee, cotton, tea, corn, sorghum, sweet potatoes, bananas,
manioc (tapioca); beef, milk, hides
7 (2002)
39.72 births/1,000 population (2003 est.)
Army (including naval and air units), Gendarmerie
revenues: $125 million
expenditures: $176 million, including capital expenditures of $NA
(2000 est.)
the two national, mainstream, governing parties are: Unity
for National Progress or UPRONA [Alphonse KADEGE, president];
Burundi Democratic Front or FRODEBU [Jean MINANI, president]
note: a multiparty system was introduced after 1998, included are:
Burundi African Alliance for the Salvation or ABASA [Terrence
NSANZE]; Rally for Democracy and Economic and Social Development or
RADDES [Joseph NZEYIMANA]; Party for National Redress or PARENA
[Jean-Baptiste BAGAZA]; People''s Reconciliation Party or PRP
[Mathias HITIMANA]','bdc7e3c1e06eb8c4ee194aa32983d2bb42087a3126b7df16f41a2f5af7670733','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6182f6918d565d400902f0e5439f8c44f272c1ab07a056620d3a21d21a5b6857',2003,'KH','Cambodia','economy',657,'total: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 1 (2002)
total: 16
1,524 to 2,437 m: 2
914 to 1,523 m: 13
under 914 m: 1 (2002)
illegal logging activities throughout the country and strip
mining for gems in the western region along the border with Thailand
have resulted in habitat loss and declining biodiversity (in
particular, destruction of mangrove swamps threatens natural
fisheries); soil erosion; in rural areas, a majority of the
population does not have access to potable water; toxic waste
delivery from Taiwan sparked unrest in Kampong Saom (Sihanoukville)
in December 1998
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
3% (FY01 est.)
119 million kWh (2001)
110.6 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 65%
hydro: 35%
nuclear: 0%
other: 0% (2001)
36% (1997 est.)
lowest 10%: 2.9%
highest 10%: 33.8% (1997)
agriculture 80% (2001 est.)
timber, garments, rubber, rice, fish
US 60.2%, Germany 9.1%, UK 7.1%, Singapore 4.4% (2002)
20 provinces (khett, singular and plural) and 4
municipalities* (krong, singular and plural); Banteay Mean Cheay,
Batdambang, Kampong Cham, Kampong Chhnang, Kampong Spoe, Kampong
Thum, Kampot, Kandal, Kaoh Kong, Keb*, Kracheh, Mondol Kiri, Otdar
Mean Cheay, Pailin*, Phnum Penh*, Pouthisat, Preah Seihanu*, Preah
Vihear, Prey Veng, Rotanah Kiri, Siem Reab, Stoeng Treng, Svay
Rieng, Takev
rice, rubber, corn, vegetables
21 (2002)
27.28 births/1,000 population (2003 est.)
Royal Cambodian Armed Forces (RCAF): Army, Navy, Air Force
revenues: $396 million
expenditures: $607 million, including capital expenditures of $254
million (2001 est.)
Buddhist Liberal Party or BLP [IENG MOULY]; Cambodian
Pracheachon Party or Cambodian People''s Party or CPP [CHEA SIM];
Khmer Citizen Party or KCP [NGUON SOEUR]; National United Front for
an Independent, Neutral, Peaceful, and Cooperative Cambodia or
FUNCINPEC [Prince NORODOM RANARIDDH]; Sam Rangsi Party or SRP
(formerly Khmer Nation Party or KNP) [SAM RANGSI]','2db13666c44c8d1160d5e1eb5953f337c6acb789e0acdf0fda6d0456123f7084','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba81dfef67be12a809f75e527a5f769561609b9e544bcd7914d940d054e0f393',2003,'CM','Cameroon','economy',658,'total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 38
1,524 to 2,437 m: 7
914 to 1,523 m: 20
under 914 m: 11 (2002)
water-borne diseases are prevalent; deforestation;
overgrazing; desertification; poaching; overfishing
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Nuclear Test Ban
1.4% (FY98)
3.613 billion kWh (2001)
3.36 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 2.7%
hydro: 97.3%
nuclear: 0%
other: 0% (2001)
48% (2000 est.)
lowest 10%: 1.9%
highest 10%: 36.6% (1996)
agriculture 70%, industry and commerce 13%, other 17%
crude oil and petroleum products, lumber, cocoa beans,
aluminum, coffee, cotton
Italy 16.7%, Spain 16%, France 12.8%, US 8.3%, Netherlands
8.2%, Taiwan 7.7%, China 5.2%, UK 4.4% (2002)
10 provinces; Adamaoua, Centre, Est, Extreme-Nord,
Littoral, Nord, Nord-Ouest, Ouest, Sud, Sud-Ouest
coffee, cocoa, cotton, rubber, bananas, oilseed, grains,
root starches; livestock; timber
49 (2002)
35.49 births/1,000 population (2003 est.)
Army, Navy (includes naval infantry), Air Force, National
Gendarmerie, Presidential Guard
revenues: $2.2 billion
expenditures: $2.1 billion, including capital expenditures of $NA
(FY 00/01 est.)
gas 90 km; liquid petroleum gas 9 km; oil 1,124 km (2003)
Cameroonian Democratic Union or UDC [Adamou NDAM NJOYA];
Democratic Rally of the Cameroon People or RDCP [Paul BIYA];
Movement for the Defense of the Republic or MDR [Dakole DAISSALA];
Movement for the Liberation and Development of Cameroon or MLDC
[leader Marcel YONDO]; Movement for the Youth of Cameroon or MYC
[Dieudonne TINA]; National Union for Democracy and Progress or UNDP
[Maigari BELLO BOUBA]; Social Democratic Front or SDF [John FRU
NDI]; Union of Cameroonian Populations or UPC [Augustin Frederic
KODOCK]','5286abb7056848c72fc5a77ca9aa1503123f1c789ae5c01d51be93b4e5879c4f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff1a43773ae190e42986d01a350a5f5396bf6a5110d64cb685fc39a5de198276',2003,'CA','Canada','economy',659,'total: 507
over 3,047 m: 18
2,438 to 3,047 m: 15
1,524 to 2,437 m: 149
914 to 1,523 m: 245
under 914 m: 80 (2002)
Cape Verde
total: 6
over 3,047 m: 1
914 to 1,523 m: 5 (2002)
total: 882
1,524 to 2,437 m: 73
914 to 1,523 m: 363
under 914 m: 446 (2002)
Cape Verde
total: 3
914 to 1,523 m: 3 (2002)
air pollution and resulting acid rain severely affecting
lakes and damaging forests; metal smelting, coal-burning utilities,
and vehicle emissions impacting on agricultural and forest
productivity; ocean waters becoming contaminated due to
agricultural, industrial, mining, and forestry activities
Cape Verde
soil erosion; demand for wood used as fuel has resulted
in deforestation; desertification; environmental damage has
threatened several species of birds and reptiles; illegal beach sand
extraction; overfishing
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Climate Change-Kyoto Protocol, Law
of the Sea, Marine Life Conservation
Cape Verde
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
1.1% (FY01/02)
Cape Verde
1.6% (FY02)
566.3 billion kWh (2001)
Cape Verde
42.03 million kWh (2001)
504.4 billion kWh (2001)
Cape Verde
39.08 million kWh (2001)
16.11 billion kWh (2001)
Cape Verde
0 kWh (2001)
38.4 billion kWh (2001)
Cape Verde
0 kWh (2001)
fossil fuel: 28%
hydro: 57.9%
nuclear: 12.9%
other: 1.3% (2001)
Cape Verde
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
Cape Verde
30% (2000)
lowest 10%: 2.8%
highest 10%: 23.8% (1994)
Cape Verde
lowest 10%: NA%
highest 10%: NA%
services 74%, manufacturing 15%, construction 5%, agriculture
3%, other 3% (2000)
motor vehicles and parts, industrial machinery, aircraft,
telecommunications equipment; chemicals, plastics, fertilizers; wood
pulp, timber, crude petroleum, natural gas, electricity, aluminum
Cape Verde
fuel, shoes, garments, fish, hides
US 87.7%, Japan 2%, UK 1.1% (2002)
Cape Verde
Portugal 38.5%, UK 26.4%, France 23.1%, US 8.2% (2002)
10 provinces and 3 territories*; Alberta, British Columbia,
Manitoba, New Brunswick, Newfoundland and Labrador, Northwest
Territories*, Nova Scotia, Nunavut*, Ontario, Prince Edward Island,
Quebec, Saskatchewan, Yukon Territory*
Cape Verde
17 municipalities (concelhos, singular - concelho); Boa
Vista, Brava, Maio, Mosteiros, Paul, Praia, Porto Novo, Ribeira
Grande, Sal, Santa Catarina, Santa Cruz, Sao Domingos, Sao Filipe,
Sao Miguel, Sao Nicolau, Sao Vicente, Tarrafal
wheat, barley, oilseed, tobacco, fruits, vegetables; dairy
products; forest products; fish
Cape Verde
bananas, corn, beans, sweet potatoes, sugarcane, coffee,
peanuts; fish
1,389 (2002)
Cape Verde
9
note: 3 airports are reported to be nonoperational (2002)
10.99 births/1,000 population (2003 est.)
Cape Verde
26.95 births/1,000 population (2003 est.)
Canadian Armed Forces (comprising Land Forces Command,
Maritime Command, Air Command, Communications Command, Training
Command)
Cape Verde
Army, Coast Guard
revenues: $178.6 billion
expenditures: $161.4 billion, including capital expenditures of $NA
(FY 00/01 est.)
Cape Verde
revenues: $112 million
expenditures: $198 million, including capital expenditures of $NA
(2000)
As an affluent, high-tech industrial society, Canada today
closely resembles the US in its market-oriented economic system,
pattern of production, and high living standards. Since World War
II, the impressive growth of the manufacturing, mining, and service
sectors has transformed the nation from a largely rural economy into
one primarily industrial and urban. The 1989 US-Canada Free Trade
Agreement (FTA) and the 1994 North American Free Trade Agreement
(NAFTA) (which includes Mexico) touched off a dramatic increase in
trade and economic integration with the US. As a result of the close
cross-border relationship, the economic sluggishness in the United
States in 2001-02 had a negative impact on the Canadian economy.
Real growth averaged nearly 3% during 1993-2000, but declined in
2001, with moderate recovery in 2002. Unemployment is up, with
contraction in the manufacturing and natural resource sectors.
Nevertheless, given its great natural resources, skilled labor
force, and modern capital plant Canada enjoys solid economic
prospects. Two shadows loom, the first being the continuing
constitutional impasse between English- and French-speaking areas,
which has been raising the specter of a split in the federation.
Another long-term concern is the flow south to the US of
professionals lured by higher pay, lower taxes, and the immense
high-tech infrastructure. A key strength in the economy is the
substantial trade surplus.
Cape Verde
This island economy suffers from a poor natural resource
base, including serious water shortages exacerbated by cycles of
long-term drought. The economy is service-oriented, with commerce,
transport, tourism, and public services accounting for 72% of GDP.
Although nearly 70% of the population lives in rural areas, the
share of agriculture in GDP in 2001 was only 11%, of which fishing
accounts for 1.5%. About 82% of food must be imported. The fishing
potential, mostly lobster and tuna, is not fully exploited. Cape
Verde annually runs a high trade deficit, financed by foreign aid
and remittances from emigrants; remittances supplement GDP by more
than 20%. Economic reforms are aimed at developing the private
sector and attracting foreign investment to diversify the economy.
Prospects for 2003 depend heavily on the maintenance of aid flows,
tourism, remittances, and the momentum of the government''s
development program.
crude and refined oil 23,564 km; natural gas 74,980 km
Bloc Quebecois [Gilles DUCEPPE]; Canadian Alliance [Stephen
HARPER]; Liberal Party [Paul MARTIN]; New Democratic Party [Jack
LAYTON]; Progressive Conservative Party [Peter MACKAY]
Cape Verde
African Party for Independence of Cape Verde or PAICV
[Jose Maria Pereira NEVES, chairman]; Democratic Alliance for Change
or ADM [Dr. Eurico MONTEIRO] (a coalition of PCD, PTS, and UCID);
Democratic Christian Party or PDC [Manuel RODRIGUES, chairman];
Democratic Renovation Party or PRD [Jacinto SANTOS, president];
Movement for Democracy or MPD [Agostinho LOPES, president]; Party
for Democratic Convergence or PCD [Dr. Eurico MONTEIRO, president];
Party of Work and Solidarity or PTS [Anibal MEDINA, president];
Social Democratic Party or PSD [Joao ALEM, president]','85b11f508c028fdc41fb7d0749aa9d06ec5282cdafeacb6814d6f4a907949ccd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bbee75da4c038d882934363e63cb2f3657b2c41bd438376b7ff98a7902610e6',2003,'KY','Cayman Islands','economy',660,'total: 2
1,524 to 2,437 m: 2 (2002)
total: 1
914 to 1,523 m: 1 (2002)
no natural fresh water resources; drinking water
supplies must be met by rainwater catchments
381.9 million kWh (2001)
355.2 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 1.4%, industry 12.6%, services 86% (1995)
turtle products, manufactured consumer goods
mostly US
8 districts; Creek, Eastern, Midland, South Town,
Spot Bay, Stake Bay, West End, Western
vegetables, fruit; livestock, turtle farming
3 (2002)
13.33 births/1,000 population (2003 est.)
no regular indigenous military forces; Royal Cayman
Islands Police Force (RCIPF)
revenues: $265.2 million
expenditures: $248.9 million, including capital expenditures of $NA
(1997)
With no direct taxation, the islands are a thriving
offshore financial center. More than 40,000 companies were
registered in the Cayman Islands as of 1998, including almost 600
banks and trust companies; banking assets exceed $500 billion. A
stock exchange was opened in 1997. Tourism is also a mainstay,
accounting for about 70% of GDP and 75% of foreign currency
earnings. The tourist industry is aimed at the luxury market and
caters mainly to visitors from North America. Total tourist arrivals
exceeded 1.2 million in 1997, with 600,000 from the US. About 90% of
the islands'' food and consumer goods must be imported. The
Caymanians enjoy one of the highest outputs per capita and one of
the highest standards of living in the world.
there are no formal political parties but the
following loose groupings act as political organizations; National
Team [leader NA]; Democratic Alliance [leader NA]; Team Cayman
[leader NA]; United Democratic Party [leader NA]','6b79680d013f08083da323f75a446ba47d03af8a49c2d2248014daf539ef71dc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8aac75b9a8821c057bc887106b27c7f43485229bb9758a8a67918219b706af2',2003,'CF','Central African Republic','economy',661,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2002)
total: 47
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 13 (2002)
tap water is not potable; poaching has
diminished its reputation as one of the last great wildlife refuges;
desertification; deforestation
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
1.1% (FY02)
106 million kWh (2001)
98.63 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 19.8%
hydro: 80.2%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: 0.7%
highest 10%: 47.7% (1993)
diamonds, timber, cotton, coffee, tobacco
Belgium 66.8%, Spain 6.4%, Kazakhstan 4%
(2002)
14 prefectures (prefectures, singular -
prefecture), 2 economic prefectures* (prefectures economiques,
singular - prefecture economique), and 1 commune**;
Bamingui-Bangoran, Bangui**, Basse-Kotto, Haute-Kotto, Haut-Mbomou,
Kemo, Lobaye, Mambere-Kadei, Mbomou, Nana-Grebizi*, Nana-Mambere,
Ombella-Mpoko, Ouaka, Ouham, Ouham-Pende, Sangha-Mbaere*, Vakaga
cotton, coffee, tobacco, manioc (tapioca),
yams, millet, corn, bananas; timber
50 (2002)
35.93 births/1,000 population (2003 est.)
Central African Armed Forces (FACA)
(including Republican Guard, Ground Forces, Naval Forces, and Air
Force), Presidential Security Guard, Gendarmerie, National Police
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Subsistence agriculture, together with
forestry, remains the backbone of the economy of the Central African
Republic (CAR), with more than 70% of the population living in
outlying areas. The agricultural sector generates half of GDP.
Timber has accounted for about 16% of export earnings and the
diamond industry for 54%. Important constraints to economic
development include the CAR''s landlocked position, a poor
transportation system, a largely unskilled work force, and a legacy
of misdirected macroeconomic policies. Factional fighting between
the government and its opponents remains a drag on economic
revitalization, with GDP growth likely to be no more than 1.3% in
2003. Distribution of income is extraordinarily unequal. Grants from
France and the international community can only partially meet
humanitarian needs.
Alliance for Democracy and Progress or ADP
[Jacques MBOLIEDAS]; Central African Democratic Assembly or RDC
[Andre KOLINGBA]; Civic Forum or FC [Gen. Timothee MALENDOMA];
Democratic Forum for Modernity or FODEM [Charles MASSI]; Liberal
Democratic Party or PLD [Nestor KOMBO-NAGUEMON]; Movement for
Democracy and Development or MDD [David DACKO]; Movement for the
Liberation of the Central African People or MLPC [the party of
deposed president, Ange-Felix PATASSE]; Patriotic Front for Progress
or FPP [Abel GOUMBA]; People''s Union for the Republic or UPR [Pierre
Sammy MAKFOY]; National Unity Party or PUN [Jean-Paul NGOUPANDE];
Social Democratic Party or PSD [Enoch LAKOUE]','b7c304f9564d8ea38cc721f9c089cf549ce6237159bf62249b6792afea905bca','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f8c1a00a5ee39c054a4b5a611822a5b6230caa67cec6c12206c38e7d070c8b5',2003,'TD','Chad','economy',662,'total: 7
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
under 914 m: 1 (2002)
total: 43
1,524 to 2,437 m: 13
914 to 1,523 m: 20
under 914 m: 10 (2002)
inadequate supplies of potable water; improper waste disposal
in rural areas contributes to soil and water pollution;
desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection,
Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
1.9% (FY02)
94.04 million kWh (2001)
87.46 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
80% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture more than 80% (subsistence farming, herding, and
fishing)
cotton, cattle, gum arabic
Portugal 28.3%, Germany 13.6%, US 7.8%, Czech Republic 6.5%,
France 5.8%, Nigeria 5.8%, Poland 5.5%, Spain 5.2%, Morocco 4.5%
(2002)
14 prefectures (prefectures, singular - prefecture); Batha,
Biltine, Borkou-Ennedi-Tibesti, Chari-Baguirmi, Guera, Kanem, Lac,
Logone Occidental, Logone Oriental, Mayo-Kebbi, Moyen-Chari,
Ouaddai, Salamat, Tandjile
note: instead of 14 prefectures, there may be a new administrative
structure of 28 departments (departments, singular - department),
and 1 city*; Assongha, Baguirmi, Bahr El Gazal, Bahr Koh, Batha
Oriental, Batha Occidental, Biltine, Borkou, Dababa, Ennedi, Guera,
Hadjer Lamis, Kabia, Kanem, Lac, Lac Iro, Logone Occidental, Logone
Oriental, Mandoul, Mayo-Boneye, Mayo-Dallah, Monts de Lam,
N''Djamena*, Ouaddai, Salamat, Sila, Tandjile Oriental, Tandjile
Occidental, Tibesti
cotton, sorghum, millet, peanuts, rice, potatoes, manioc
(tapioca); cattle, sheep, goats, camels
50 (2002)
47.06 births/1,000 population (2003 est.)
Armed Forces (including National Army, Air Force, and
Gendarmerie), Rapid Intervention Force, National and Nomadic Guard
(GNNT), Presidential Security Guard, Police
revenues: $198 million
expenditures: $218 million, including capital expenditures of $146
million (1998 est.)
Chad''s primarily agricultural economy will continue to be
boosted by major oilfield and pipeline projects that began in 2000.
Over 80% of Chad''s population relies on subsistence farming and
stock raising for its livelihood. Cotton, cattle, and gum arabic
provide the bulk of Chad''s export earnings, but Chad will begin to
export oil in 2004. Chad''s economy has long been handicapped by its
landlocked position, high energy costs, and a history of
instability. Chad relies on foreign assistance and foreign capital
for most public and private sector investment projects. A consortium
led by two US companies has been investing $3.7 billion to develop
oil reserves estimated at 1 billion barrels in southern Chad. Oil
production is scheduled to come on stream in late 2003.
oil 205 km (2003)
Federation Action for the Republic or FAR [Ngarlejy YORONGAR];
National Rally for Development and Progress or RNDP [Mamadou BISSO];
National Union for Democracy and Renewal or UNDR [Saleh KEBZABO];
Patriotic Salvation Movement or MPS [Mahamat Saleh AHMAT, chairman]
(originally in opposition but now the party in power and the party
of the president); Union for Renewal and Democracy or URD [Gen.
Wadal Abdelkader KAMOUGUE]; Viva Rally for Development and Progress
or Viva RNDP [Delwa Kassire COUMAKOYE]','a1449a306c5df3b4758764b7144d5ebaffcdb96cb71a896d06ba73c35b41d89c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d0ebe57b3791cf1db3eb431c440f67681bd501eb2e3667dda3dc831f5c8d0df',2003,'CL','Chile','economy',663,'total: 71
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 21
914 to 1,523 m: 23
under 914 m: 15 (2002)
total: 292
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 60
under 914 m: 216 (2002)
widespread deforestation and mining threaten natural
resources; air pollution from industrial and vehicle emissions;
water pollution from raw sewage
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
3.1% (FY99)
41.66 billion kWh (2001)
40.13 billion kWh (2001)
1.386 billion kWh (2001)
0 kWh (2001)
fossil fuel: 47%
hydro: 51.5%
nuclear: 0%
other: 1.4% (2001)
21% (1998 est.)
lowest 10%: 1.3%
highest 10%: 45.6% (1998)
agriculture 14%, industry 27%, services 59% (1997 est.)
copper, fish, fruits, paper and pulp, chemicals
US 19.1%, Japan 10.5%, China 6.7%, Mexico 5%, Italy 4.7%, UK
4.4% (2002)
13 regions (regiones, singular - region); Aisen del General
Carlos Ibanez del Campo, Antofagasta, Araucania, Atacama, Bio-Bio,
Coquimbo, Libertador General Bernardo O''Higgins, Los Lagos,
Magallanes y de la Antartica Chilena, Maule, Region Metropolitana
(Santiago), Tarapaca, Valparaiso
note: the US does not recognize claims to Antarctica
wheat, corn, grapes, beans, sugar beets, potatoes, fruit;
beef, poultry, wool; fish; timber
363 (2002)
16.1 births/1,000 population (2003 est.)
Army of the Nation, National Navy (including naval air, coast
guard, and marines), Air Force of the Nation, Chilean Carabineros
(National Police), Investigations Police
revenues: $17 billion
expenditures: $17 billion, including capital expenditures of $NA
(2001 est.)
Chile has a market-oriented economy characterized by a high
level of foreign trade. During the early 1990s, Chile''s reputation
as a role model for economic reform was strengthened when the
democratic government of Patricio AYLWIN - which took over from the
military in 1990 - deepened the economic reform initiated by the
military government. Growth in real GDP averaged 8% during 1991-97,
but fell to half that level in 1998 because of tight monetary
policies implemented to keep the current account deficit in check
and because of lower export earnings - the latter a product of the
global financial crisis. A severe drought exacerbated the recession
in 1999, reducing crop yields and causing hydroelectric shortfalls
and electricity rationing, and Chile experienced negative economic
growth for the first time in more than 15 years. Despite the effects
of the recession, Chile maintained its reputation for strong
financial institutions and sound policy that have given it the
strongest sovereign bond rating in South America. By the end of
1999, exports and economic activity had begun to recover, and growth
rebounded to 4.4% in 2000. Growth fell back to 2.8% in 2001 and 1.8%
in 2002, largely due to lackluster global growth and the devaluation
of the Argentine peso. Unemployment remains stubbornly high, putting
pressure on President LAGOS to improve living standards. One bright
spot was the signing of a free trade agreement with the US, which
will take effect on 1 January 2004.
gas 2,267 km; gas/liquid petroleum gas 42 km; liquid petroleum
gas 531 km; oil 983 km; refined products 545 km (2003)
Alliance for Chile ("Alianza") or APC - including RN and UDI;
Christian Democratic Party or PDC [Adolfo ZALDIVAR]; Coalition of
Parties for Democracy ("Concertacion") or CPD - including PDC, PS,
PPD, PRSD; Communist Party or PC [Gladys MARIN]; Independent
Democratic Union or UDI [Pablo LONGUEIRA]; National Renewal or RN
[Sebastian PINERA]; Party for Democracy or PPD [Guido GIRARDI];
Radical Social Democratic Party or PRSD [Orlando CANTUARIAS];
Socialist Party or PS [Camilo ESCALONA]','d764d16daf1b7ce2601518f62cc7f02de2843283e3fe2af04f92ea3c3ac1ca59','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cc812b04724be404d74528a5965d33365063ca16cd960627f6ac288d0f9beff',2003,'CN','China','economy',664,'total: 351
over 3,047 m: 32
2,438 to 3,047 m: 108
1,524 to 2,437 m: 143
914 to 1,523 m: 29
under 914 m: 39 (2002)
total: 149
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 25
914 to 1,523 m: 48
under 914 m: 71 (2002)
air pollution (greenhouse gases, sulfur dioxide particulates)
from reliance on coal produces acid rain; water shortages,
particularly in the north; water pollution from untreated wastes;
deforestation; estimated loss of one-fifth of agricultural land
since 1949 to soil erosion and economic development;
desertification; trade in endangered species
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
4.3% (FY02)
1.42 trillion kWh (2001)
1.312 trillion kWh (2001)
1.55 billion kWh (2001)
10.3 billion kWh (2001)
fossil fuel: 80.2%
hydro: 18.5%
nuclear: 1.2%
other: 0.1% (2001)
10% (2001 est.)
lowest 10%: 2.4%
highest 10%: 30.4% (1998)
agriculture 50%, industry 22%, services 28% (2001 est.)
machinery and equipment; textiles and clothing, footwear, toys
and sporting goods; mineral fuels
US 21.5%, Hong Kong 18%, Japan 14.9%, South Korea 4.8% (2002)
23 provinces (sheng, singular and plural), 5 autonomous
regions* (zizhiqu, singular and plural), and 4 municipalities**
(shi, singular and plural); Anhui, Beijing**, Chongqing**, Fujian,
Gansu, Guangdong, Guangxi*, Guizhou, Hainan, Hebei, Heilongjiang,
Henan, Hubei, Hunan, Jiangsu, Jiangxi, Jilin, Liaoning, Nei Mongol*,
Ningxia*, Qinghai, Shaanxi, Shandong, Shanghai**, Shanxi, Sichuan,
Tianjin**, Xinjiang*, Xizang* (Tibet), Yunnan, Zhejiang; note -
China considers Taiwan its 23rd province; see separate entries for
the special administrative regions of Hong Kong and Macau
rice, wheat, potatoes, sorghum, peanuts, tea, millet, barley,
cotton, oilseed; pork; fish
500 (2002)
12.96 births/1,000 population (2003 est.)
People''s Liberation Army (PLA): comprises ground forces, Navy
(including naval infantry and naval aviation), Air Force, and II
Artillery Corps (strategic missile force), People''s Armed Police
Force (internal security troops, nominally a state security body but
included by the Chinese as part of the "armed forces" and considered
to be an adjunct to the PLA), militia
revenues: $224.8 billion
expenditures: $267.1 billion, including capital expenditures of $NA
(2000)
In late 1978 the Chinese leadership began moving the economy
from a sluggish, Soviet-style centrally planned economy to a more
market-oriented system. Whereas the system operates within a
political framework of strict Communist control, the economic
influence of non-state organizations and individual citizens has
been steadily increasing. The authorities switched to a system of
household and village responsibility in agriculture in place of the
old collectivization, increased the authority of local officials and
plant managers in industry, permitted a wide variety of small-scale
enterprises in services and light manufacturing, and opened the
economy to increased foreign trade and investment. The result has
been a quadrupling of GDP since 1978. In 2003, with its 1.3 billion
people but a GDP of just $5,000 per capita, China stood as the
second-largest economy in the world after the US (measured on a
purchasing power parity basis). Agriculture and industry have posted
major gains, especially in coastal areas near Hong Kong and opposite
Taiwan, where foreign investment has helped spur output of both
domestic and export goods. The leadership, however, often has
experienced - as a result of its hybrid system - the worst results
of socialism (bureaucracy and lassitude) and of capitalism (windfall
gains and growing income disparities). China thus has periodically
backtracked, retightening central controls at intervals. The
government has struggled to (a) collect revenues due from provinces,
businesses, and individuals; (b) reduce corruption and other
economic crimes; and (c) keep afloat the large state-owned
enterprises, many of which had been shielded from competition by
subsidies and had been losing the ability to pay full wages and
pensions. From 80 to 120 million surplus rural workers are adrift
between the villages and the cities, many subsisting through
part-time low-paying jobs. Popular resistance, changes in central
policy, and loss of authority by rural cadres have weakened China''s
population control program, which is essential to maintaining
long-term growth in living standards. Another long-term threat to
growth is the deterioration in the environment, notably air
pollution, soil erosion, and the steady fall of the water table
especially in the north. China continues to lose arable land because
of erosion and economic development. Beijing says it will intensify
efforts to stimulate growth through spending on infrastructure -
such as water control and power grids - and poverty relief and
through rural tax reform aimed at eliminating arbitrary local levies
on farmers. Accession to the World Trade Organization helps
strengthen China''s ability to maintain strong growth rates but at
the same time puts additional pressure on the hybrid system of
strong political controls and growing market influences. China has
benefited from a huge expansion in computer internet use. Foreign
investment remains a strong element in China''s remarkable economic
growth.
gas 13,845 km; oil 15,143 km; refined products 3,280 km (2003)
Chinese Communist Party or CCP [HU Jintao, General Secretary
of the Central Committee]; eight registered small parties controlled
by CCP','af528d89d8c19beefb60a1d8235abf2559e4e18ee7d4db1f8b839c70281d5c42','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a241d487e1818969876e9466d5a65afbce4c4e700835cbe175905396c721dc6',2003,'CX','Christmas Island','economy',665,'total: 1
1,524 to 2,437 m: 1 (2002)
NA
Clipperton Island
NA
NA kWh
NA kWh
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
NA%
lowest 10%: NA%
highest 10%: NA%
tourism 400 people, mining 100 people (1995)
phosphate
Australia, NZ
none (territory of Australia)
NA
1 (2002)
NA births/1,000 population (2003 est.)
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Phosphate mining had been the only significant
economic activity, but in December 1987 the Australian Government
closed the mine. In 1991, the mine was reopened. With the support of
the government, a $34 million casino opened in 1993. The casino
closed in 1998. The Australian Government in 2001 agreed to support
the creation of a commercial space-launching site on the island,
slated to begin operation in 2003.
Clipperton Island
Although 115 species of fish have been identified
in the territorial waters of Clipperton Island, the only economic
activity is tuna fishing.
none','e2be7995a251073a7baf71ebc99764082d3af395a8a17dc62ada1146e2bef731','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a907d407a4a1f833cf437023f114a56c6dbac829dc8fa4d8f4152f1873b5ff37',2003,'CC','Cocos (Keeling) Islands','economy',666,'total: 1
1,524 to 2,437 m: 1 (2002)
fresh water resources are limited to
rainwater accumulations in natural underground reservoirs
NA kWh
NA kWh
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
NA%
lowest 10%: NA%
highest 10%: NA%
the Cocos Islands Cooperative Society Ltd.
employs construction workers, stevedores, and lighterage workers;
tourism employs others
copra
Australia (1999)
none (territory of Australia)
vegetables, bananas, pawpaws, coconuts
1 (2002)
NA births/1,000 population (2003 est.)
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Grown throughout the islands, coconuts are
the sole cash crop. Small local gardens and fishing contribute to
the food supply, but additional food and most other necessities must
be imported from Australia. There is a small tourist industry.
none','a6c0fe5edcd99d55b1794205ba87d90c80ff6e0ae2fe7991e3bb03aded632b20','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('767b8f321ab8cbd7f7c24edf9bfdc3bf2e925b6f133eb7b763ce1887efbe511d',2003,'CO','Colombia','economy',667,'total: 96
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 38
914 to 1,523 m: 36
under 914 m: 11 (2002)
total: 954
2,438 to 3,047 m: 1
1,524 to 2,437 m: 51
914 to 1,523 m: 315
under 914 m: 587 (2002)
Congo, Democratic Republic of the
total: 205
1,524 to 2,437 m: 19
914 to 1,523 m: 95
under 914 m: 91 (2002)
Congo, Republic of the
total: 27
1,524 to 2,437 m: 6
914 to 1,523 m: 10
under 914 m: 11 (2002)
deforestation; soil and water quality damage from overuse
of pesticides; air pollution, especially in Bogota, from vehicle
emissions
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Law of
the Sea, Marine Dumping
3.4% (FY01)
42.99 billion kWh (2001)
39.81 billion kWh (2001)
40 million kWh (2001)
210 million kWh (2001)
fossil fuel: 26%
hydro: 72.7%
nuclear: 0%
other: 1.3% (2001)
55% (2001)
lowest 10%: 1%
highest 10%: 44% (1999)
services 46%, agriculture 30%, industry 24% (1990)
petroleum, coffee, coal, apparel, bananas, cut flowers
US 44.8%, Venezuela 9.4%, Ecuador 6.8% (2002)
32 departments (departamentos, singular - departamento) and
1 capital district* (distrito capital); Amazonas, Antioquia, Arauca,
Atlantico, Distrito Capital de Bogota*, Bolivar, Boyaca, Caldas,
Caqueta, Casanare, Cauca, Cesar, Choco, Cordoba, Cundinamarca,
Guainia, Guaviare, Huila, La Guajira, Magdalena, Meta, Narino, Norte
de Santander, Putumayo, Quindio, Risaralda, San Andres y
Providencia, Santander, Sucre, Tolima, Valle del Cauca, Vaupes,
Vichada
coffee, cut flowers, bananas, rice, tobacco, corn,
sugarcane, cocoa beans, oilseed, vegetables; forest products; shrimp
1,050 (2002)
21.59 births/1,000 population (2003 est.)
Army (Ejercito Nacional), Navy (Armada Nacional, including
Marines and Coast Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
revenues: $24 billion
expenditures: $25.6 billion, including capital expenditures of $NA
(2001 est.)
Colombia''s economy suffers from weak domestic and foreign
demand, austere government budgets, and serious internal armed
conflict. Other economic problems facing the new president URIBE
range from reforming the pension system to reducing high
unemployment. Two of Colombia''s leading exports, oil and coffee,
face an uncertain future; new exploration is needed to offset
declining oil production, while coffee harvests and prices are
depressed. Colombian business leaders are calling for greater
progress in solving the conflict with insurgent groups. On the
positive side, several international financial institutions have
praised the economic reforms introduced by President URIBE and have
pledged enough funding to cover Colombia''s debt servicing costs in
2003.
gas 4,360 km; oil 6,134 km; refined products 3,140 km (2003)
Congo, Democratic Republic of the
gas 54 km; oil 71 km (2003)
Congo, Republic of the
gas 53 km; oil 673 km (2003)
Conservative Party or PSC [Carlos HOLGUIN Sardi]; Liberal
Party or PL [Piedad CORDOBA and Juan Manuel LOPEZ Cabrales];
Colombian Communist Party or PCC [Jaime CAICEDO]; 19 of April
Movement or M-19 [Antonio NAVARRO Wolff]
note: Colombia has about 60 formally recognized political parties,
most of which do not have a presence in either house of Congress','9f6d282997d3aa5d5d6988c5a2cce35d6a6ef3d87a0264e80af611454526ab8a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12a3d6c7d4becc3bac07deb822de868b88e2bf4822bd7a97e8074a5cc06355b3',2003,'KM','Comoros','economy',668,'total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2002)
Congo, Democratic Republic of the
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 2 (2002)
Congo, Republic of the
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3 (2002)
soil degradation and erosion results from crop cultivation
on slopes without proper terracing; deforestation
Congo, Democratic Republic of the
poaching threatens wildlife
populations; water pollution; deforestation; refugees responsible
for significant deforestation, soil erosion, and wildlife poaching;
mining of minerals (coltan - a mineral used in creating capacitors,
diamonds, and gold) causing environmental damage
Congo, Republic of the
air pollution from vehicle emissions; water
pollution from the dumping of raw sewage; tap water is not potable;
deforestation
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Congo, Democratic Republic of the
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Congo, Republic of the
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3% (FY02)
Congo, Democratic Republic of the
4.6% (FY97)
Congo, Republic of the
2.8% (FY01)
21.27 million kWh (2001)
Congo, Democratic Republic of the
5.243 billion kWh (2001)
Congo, Republic of the
358.1 million kWh (2001)
19.78 million kWh (2001)
Congo, Democratic Republic of the
3.839 billion kWh (2001)
Congo, Republic of the
633 million kWh (2001)
0 kWh (2001)
Congo, Democratic Republic of the
60 million kWh (2001)
Congo, Republic of the
300 million kWh (2001)
0 kWh (2001)
Congo, Democratic Republic of the
1.097 billion kWh (2001)
Congo, Republic of the
0 kWh (2001)
fossil fuel: 90.6%
hydro: 9.4%
nuclear: 0%
other: 0% (2001)
Congo, Democratic Republic of the
fossil fuel: 1.8%
hydro: 98.2%
nuclear: 0%
other: 0% (2001)
Congo, Republic of the
fossil fuel: 0.3%
hydro: 99.7%
nuclear: 0%
other: 0% (2001)
60% (2002 est.)
Congo, Democratic Republic of the
NA%
Congo, Republic of the
NA%
lowest 10%: NA%
highest 10%: NA%
Congo, Democratic Republic of the
lowest 10%: NA%
highest 10%: NA%
Congo, Republic of the
lowest 10%: NA%
highest 10%: NA%
agriculture 80%
Congo, Democratic Republic of the
NA
vanilla, ylang-ylang, cloves, perfume oil, copra
Congo, Democratic Republic of the
diamonds, copper, crude oil,
coffee, cobalt
Congo, Republic of the
petroleum, lumber, plywood, sugar, cocoa,
coffee, diamonds
France 32.4%, Germany 19.4%, US 17.6%, Singapore 11.5%,
Netherlands 6.5% (2002)
Congo, Democratic Republic of the
Belgium 64.4%, US 13.4%, Zimbabwe
6.7%, Finland 4.9% (2002)
Congo, Republic of the
Taiwan 28.1%, South Korea 20.4%, China 9.3%,
US 8.4%, Germany 6.6%, France 5.2% (2002)
3 islands; Grande Comore (Njazidja), Anjouan (Nzwani), and
Moheli (Mwali); note - there are also four municipalities named
Domoni, Fomboni, Moroni, and Moutsamoudou
Congo, Democratic Republic of the
10 provinces (provinces, singular
- province) and one city* (ville); Bandundu, Bas-Congo, Equateur,
Kasai-Occidental, Kasai-Oriental, Katanga, Kinshasa*, Maniema,
Nord-Kivu, Orientale, Sud-Kivu
Congo, Republic of the
9 regions (regions, singular - region) and 1
commune*; Bouenza, Brazzaville*, Cuvette, Kouilou, Lekoumou,
Likouala, Niari, Plateaux, Pool, Sangha
vanilla, cloves, perfume essences, copra, coconuts, bananas,
cassava (tapioca)
Congo, Democratic Republic of the
coffee, sugar, palm oil, rubber,
tea, quinine, cassava (tapioca), palm oil, bananas, root crops,
corn, fruits; wood products
Congo, Republic of the
cassava (tapioca), sugar, rice, corn,
peanuts, vegetables, coffee, cocoa; forest products
4 (2002)
Congo, Democratic Republic of the
229 (2002)
Congo, Republic of the
31 (2002)
38.5 births/1,000 population (2003 est.)
Congo, Democratic Republic of the
45.12 births/1,000 population
(2003 est.)
Congo, Republic of the
29.46 births/1,000 population (2003 est.)
Comoran Security Force
Congo, Democratic Republic of the
Army, Navy, Air Force, Special
Security Battalion
Congo, Republic of the
Army, Air Force, Navy, Gendarmerie, National
Police
revenues: $27.6 million
expenditures: $NA, including capital expenditures of $NA (2001 est.)
Congo, Democratic Republic of the
revenues: $269 million
expenditures: $244 million, including capital expenditures of $24
million (1996 est.)
Congo, Republic of the
revenues: $870 million
expenditures: $970 million, including capital expenditures of $NA
(1997 est.)
One of the world''s poorest countries, Comoros is made up of
three islands that have inadequate transportation links, a young and
rapidly increasing population, and few natural resources. The low
educational level of the labor force contributes to a subsistence
level of economic activity, high unemployment, and a heavy
dependence on foreign grants and technical assistance. Agriculture,
including fishing, hunting, and forestry, contributes 40% to GDP,
employs 80% of the labor force, and provides most of the exports.
The country is not self-sufficient in food production; rice, the
main staple, accounts for the bulk of imports. The government -
which is hampered by internal political disputes - is struggling to
upgrade education and technical training, to privatize commercial
and industrial enterprises, to improve health services, to diversify
exports, to promote tourism, and to reduce the high population
growth rate. Increased foreign support is essential if the goal of
4% annual GDP growth is to be met. Remittances from 150,000 Comorans
abroad help supplement GDP.
Congo, Democratic Republic of the
The economy of the Democratic
Republic of the Congo - a nation endowed with vast potential wealth
- has declined drastically since the mid-1980s. The war, which began
in August 1998, has dramatically reduced national output and
government revenue, has increased external debt, and has resulted in
the deaths from war, famine, and disease of perhaps 3.5 million
people. Foreign businesses have curtailed operations due to
uncertainty about the outcome of the conflict, lack of
infrastructure, and the difficult operating environment. The war has
intensified the impact of such basic problems as an uncertain legal
framework, corruption, inflation, and lack of openness in government
economic policy and financial operations. Conditions improved in
late 2002 with the withdrawal of a large portion of the invading
foreign troops. A number of IMF and World Bank missions have met
with the government to help it develop a coherent economic plan, and
President KABILA has begun implementing reforms. Much economic
activity lies outside the GDP data.
Congo, Republic of the
The economy is a mixture of village
agriculture and handicrafts, an industrial sector based largely on
oil, support services, and a government characterized by budget
problems and overstaffing. Oil has supplanted forestry as the
mainstay of the economy, providing a major share of government
revenues and exports. In the early 1980s, rapidly rising oil
revenues enabled the government to finance large-scale development
projects with GDP growth averaging 5% annually, one of the highest
rates in Africa. The government has mortgaged a substantial portion
of its oil earnings, contributing to a shortage of revenues. The 12
January 1994 devaluation of Franc Zone currencies by 50% resulted in
inflation of 61% in 1994, but inflation has subsided since. Economic
reform efforts continued with the support of international
organizations, notably the World Bank and the IMF. The reform
program came to a halt in June 1997 when civil war erupted. Denis
SASSOU-NGUESSO, who returned to power when the war ended in October
1997, publicly expressed interest in moving forward on economic
reforms and privatization and in renewing cooperation with
international financial institutions. However, economic progress was
badly hurt by slumping oil prices and the resumption of armed
conflict in December 1998, which worsened the republic''s budget
deficit. The current administration presides over an uneasy internal
peace and faces difficult economic problems of stimulating recovery
and reducing poverty.
Forces pour l''Action Republicaine or FAR [Col. Abdourazak
ABDULHAMID]; Forum pour la Redressement National or FRN (alliance of
12 parties); Front Democratique or FD [Moustoifa Said CHEIKH]; Front
National pour la Justice or FNJ (Islamic party in opposition) [Ahmed
RACHID]; Movement des Citoyens pour la Republique or MCR [Mahamoud
MRADABI]; Mouvement Populaire Anjouanais or MPA (Anjouan separatist
movement) [leader NA]; Mouvement pour la Democratie et le Progress
or MDP-NGDC [Abbas DJOUSSOUF]; Movement pour le Socialisme et la
Democratie or MSD (splinter group of FD) [Abdou SOEFOU]; Parti
Comorien pour la Democratie et le Progress or PCDP [Ali MROUDJAE];
Rassemblement National pour le Development or RND (party of the
government) [Omar TAMOU, Abdoulhamid AFFRAITANE]
Congo, Democratic Republic of the
Democratic Social Christian Party
or PDSC [Andre BO-BOLIKO]; Forces for Renovation for Union and
Solidarity or FONUS [Joseph OLENGHANKOY]; National Congolese
Lumumbist Movement or MNC [Francois LUMUMBA]; Popular Movement of
the Revolution or MPR (three factions: MPR-Fait Prive [Catherine
NZUZI wa Mbombo]; MPR/Vunduawe [Felix VUNDUAWE]; MPR/Mananga
[MANANGA Dintoka Mpholo]); Unified Lumumbast Party or PALU [Antoine
GIZENGA]; Union for Democracy and Social Progress or UDPS [Etienne
TSHISEKEDI wa Mulumba]; Union of Federalists and Independent
Republicans or UFERI (two factions: UFERI [Lokambo OMOKOKO];
UFERI/OR [Adolph Kishwe MAYA])
Congo, Republic of the
the most important of the many parties are
the Democratic and Patriotic Forces or FDP (an alliance of
Convention for Alternative Democracy, Congolese Labor Party or PCT,
Liberal Republican Party, National Union for Democracy and Progress,
Patriotic Union for the National Reconstruction, and Union for the
National Renewal) [Denis SASSOU-NGUESSO, president]; Congolese
Movement for Democracy and Integral Development or MCDDI [Michel
MAMPOUYA]; Pan-African Union for Social Development or UPADS [Martin
MBERI]; Rally for Democracy and Social Progress or RDPS [Jean-Pierre
Thystere TCHICAYA, president]; Rally for Democracy and the Republic
or RDR [Raymond Damasge NGOLLO]; Union for Democracy and Republic or
UDR [leader NA]; Union of Democratic Forces or UFD [Sebastian EBAO]','cf0e8a52d1dbece607e822547b1eca39c9689703a30f1bdc55daa17f53acba8a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff4805b863e7983ff15ed4ec062c56246fc929e800dc076549bd4bcf0e02fa80',2003,'CK','Cook Islands','economy',669,'total: 1
1,524 to 2,437 m: 1 (2002)
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (2002)
NA
Coral Sea Islands
no permanent fresh water resources
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the Sea
signed, but not ratified: none of the selected agreements
27.43 million kWh (2001)
25.51 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 29%, industry 15%, services 56%
note: shortage of skilled labor (1995)
copra, papayas, fresh and canned citrus fruit, coffee;
fish; pearls and pearl shells; clothing
Australia 34%, Japan 27%, New Zealand 25%, US 8% (2000)
none
copra, citrus, pineapples, tomatoes, beans, pawpaws,
bananas, yams, taro, coffee; pigs, poultry
7 (2002)
NA births/1,000 population (2003 est.)
revenues: $28 million
expenditures: $27 million, including capital expenditures of $3.3
million (FY 00/01 est.)
Like many other South Pacific island nations, the Cook
Islands'' economic development is hindered by the isolation of the
country from foreign markets, the limited size of domestic markets,
lack of natural resources, periodic devastation from natural
disasters, and inadequate infrastructure. Agriculture provides the
economic base with major exports made up of copra and citrus fruit.
Manufacturing activities are limited to fruit processing, clothing,
and handicrafts. Trade deficits are offset by remittances from
emigrants and by foreign aid, overwhelmingly from New Zealand. In
the 1980s and 1990s, the country lived beyond its means, maintaining
a bloated public service and accumulating a large foreign debt.
Subsequent reforms, including the sale of state assets, the
strengthening of economic management, the encouragement of tourism,
and a debt restructuring agreement, have rekindled investment and
growth.
Coral Sea Islands
no economic activity
Cook Islands People''s Party or CIP [Geoffrey HENRY];
Democratic Alliance Party or DAP [Terepai MAOATE]; New Alliance
Party or NAP [Norman GEORGE]; Cook Islands National Party or CIN
[Teariki HEATHER]','0824c3f75d5201aa815f71e56ee29124272c9d3c5a1f49a88c9d7a4c075c87c6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e52ed5a923a4f0c68eae44e422f1070d28c9e8915a07c2e1ae7e5902476d800',2003,'CR','Costa Rica','economy',670,'total: 30
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 19
under 914 m: 8 (2002)
Cote d''Ivoire
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2002)
total: 121
914 to 1,523 m: 28
under 914 m: 93 (2002)
Cote d''Ivoire
total: 29
1,524 to 2,437 m: 7
914 to 1,523 m: 14
under 914 m: 8 (2002)
deforestation and land use change, largely a result of
the clearing of land for cattle ranching and agriculture; soil
erosion; coastal marine pollution; fisheries protection; solid waste
management; air pollution
Cote d''Ivoire
deforestation (most of the country''s forests - once
the largest in West Africa - have been heavily logged); water
pollution from sewage and industrial and agricultural effluents
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Cote d''Ivoire
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
1.6% (FY99)
Cote d''Ivoire
1.4% (FY02)
6.839 billion kWh (2001)
Cote d''Ivoire
4.605 billion kWh (2001)
6.109 billion kWh (2001)
Cote d''Ivoire
2.983 billion kWh (2001)
128 million kWh (2001)
Cote d''Ivoire
0 kWh (2001)
379 million kWh (2001)
Cote d''Ivoire
1.3 billion kWh (2001)
fossil fuel: 1.5%
hydro: 81.9%
nuclear: 0%
other: 16.6% (2001)
Cote d''Ivoire
fossil fuel: 61.9%
hydro: 38.1%
nuclear: 0%
other: 0% (2001)
20.6% (1999 est.)
Cote d''Ivoire
37% (1995)
lowest 10%: 1.7%
highest 10%: 34.6% (2001)
Cote d''Ivoire
lowest 10%: 3.1%
highest 10%: 28.8% (1995)
agriculture 20%, industry 22%, services 58% (1999 est.)
coffee, bananas, sugar; pineapples; textiles, electronic
components, medical equipment
Cote d''Ivoire
cocoa, coffee, timber, petroleum, cotton, bananas,
pineapples, palm oil, fish
US 31.5%, Netherlands 8.9%, UK 4.5% (2002)
Cote d''Ivoire
France 14.5%, Netherlands 12.9%, US 7.6%, Germany
5.4%, Mali 4.6%, Belgium 4.4%, Spain 4.3% (2002)
7 provinces (provincias, singular - provincia); Alajuela,
Cartago, Guanacaste, Heredia, Limon, Puntarenas, San Jose
Cote d''Ivoire
58 departments (departements, singular - departement);
Abengourou, Abidjan, Aboisso, Adiake, Adzope, Agboville,
Agnibilekrou, Alepe, Bocanda, Bangolo, Beoumi, Biankouma, Bondoukou,
Bongouanou, Bouafle, Bouake, Bouna, Boundiali, Dabakala, Dabou,
Daloa, Danane, Daoukro, Dimbokro, Divo, Duekoue, Ferkessedougou,
Gagnoa, Grand-Bassam, Grand-Lahou, Guiglo, Issia, Jacqueville,
Katiola, Korhogo, Lakota, Man, Mankono, Mbahiakro, Odienne, Oume,
Sakassou, San-Pedro, Sassandra, Seguela, Sinfra, Soubre, Tabou,
Tanda, Tiebissou, Tingrela, Tiassale, Touba, Toulepleu, Toumodi,
Vavoua, Yamoussoukro, Zuenoula
coffee, pineapples, bananas, sugar, corn, rice, beans,
potatoes; beef; timber
Cote d''Ivoire
coffee, cocoa beans, bananas, palm kernels, corn,
rice, manioc (tapioca), sweet potatoes, sugar, cotton, rubber; timber
151 (2002)
Cote d''Ivoire
36 (2002)
19.4 births/1,000 population (2003 est.)
Cote d''Ivoire
40.01 births/1,000 population (2003 est.)
no regular indigenous military forces; Air Section,
Ministry of Public Forces (Fuerza Publica)
Cote d''Ivoire
Army, Navy, Air Force, paramilitary Gendarmerie,
Republican Guard (includes Presidential Guard)
revenues: $1.91 billion
expenditures: $2.35 billion, including capital expenditures of $NA
(2000 est.)
Cote d''Ivoire
revenues: $1.72 billion
expenditures: $2.4 billion, including capital expenditures of $420
million (2001 est.)
Costa Rica''s basically stable economy depends on tourism,
agriculture, and electronics exports. Poverty has been substantially
reduced over the past 15 years, and a strong social safety net has
been put into place. At the same time, distribution of income
remains severely unequal. Foreign investors remain attracted by the
country''s political stability and high education levels, and tourism
continues to bring in foreign exchange. However, traditional export
sectors have not kept pace. Low coffee prices and an overabundance
of bananas have hurt the agricultural sector. The government
continues to grapple with its large deficit and massive internal
debt, with the need to modernize the state-owned electricity and
telecommunications sector, and with the problem of bringing down
inflation.
Cote d''Ivoire
Cote d''Ivoire is among the world''s largest producers
and exporters of coffee, cocoa beans, and palm oil. Consequently,
the economy is highly sensitive to fluctuations in international
prices for these products and to weather conditions. Despite
government attempts to diversify the economy, it is still largely
dependent on agriculture and related activities, which engage
roughly 68% of the population. After several years of lagging
performance, the Ivorian economy began a comeback in 1994, due to
the 50% devaluation of the CFA franc and improved prices for cocoa
and coffee, growth in nontraditional primary exports such as
pineapples and rubber, limited trade and banking liberalization,
offshore oil and gas discoveries, and generous external financing
and debt rescheduling by multilateral lenders and France. Moreover,
government adherence to donor-mandated reforms led to a jump in
growth to 5% annually during 1996-99. Growth was negative in 2000-02
because of the difficulty of meeting the conditions of international
donors, continued low prices of key exports, and severe civil war
fighting.
refined products 421 km (2003)
Cote d''Ivoire
condensate 107 km; gas 223 km; oil 104 km (2003)
Agricultural Labor Action or PALA [Carlos Alberto SOLIS
Blanco]; Citizen Action Party or PAC [Otton SOLIS]; Costa Rican
Renovation Party or PRC [Justo OROZCO]; Democratic Force Party or
PFD [Jose M. NUNEZ]; Libertarian Movement Party or PML [Otto GUEVARA
Guth]; National Christian Alliance Party or ANC [Alejandro
MADRIGAL]; National Independent Party or PNI [Jorge GONZALEZ
Marten]; National Integration Party or PIN [Walter MUNOZ Cespedes];
National Liberation Party or PLN [Sonia PICADO]; Social Christian
Unity Party or PUSC [Luis Manuel CHACON]
note: mainly a two-party system - PUSC and PLN - until the 3
February 2002 election in which the PAC captured a significant
percentage, forcing a run-off in April 2002
Cote d''Ivoire
Democratic Party of Cote d''Ivoire-African Democratic
Rally or PDCI-RDA [Aime Henri Konan BEDIE]; Ivorian Popular Front or
FPI [Laurent GBAGBO]; Ivorian Worker''s Party or PIT [Francis WODIE];
Rally of the Republicans or RDR [Alassane OUATTARA]; Union for
Democracy and Peace or UDPCI [leader NA]; over 20 smaller parties','8d2af629c79cefb6fc40a4f9b096af2905ede50acbaea529bf612cd0a13a02ee','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a34f9853e773f1170c1cba6ebf6703ee6de31c3a45aecb73478217f6e79dcc1',2003,'HR','Croatia','economy',671,'total: 16
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 4
under 914 m: 9 (2002)
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 34 (2002)
air pollution (from metallurgical plants) and resulting acid
rain is damaging the forests; coastal pollution from industrial and
domestic waste; landmine removal and reconstruction of
infrastructure consequent to 1992-95 civil strife
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
2.39% (2002 est.)
12.12 billion kWh (2001)
14.27 billion kWh (2001)
3.386 billion kWh (2001)
386 million kWh (2001)
fossil fuel: 33.6%
hydro: 66%
nuclear: 0%
other: 0.4% (2001)
NA%
lowest 10%: 3.7%
highest 10%: 23.3% (1998)
agriculture 13.2% NA, industry 25.4% NA, services 46.4% NA
(2002)
transport equipment, textiles, chemicals, foodstuffs, fuels
Italy 22.4%, Bosnia and Herzegovina 14.4%, Germany 12.5%,
Slovenia 8%, Austria 7.3% (2002)
20 counties (zupanije, zupanija - singular) and 1 city*
(grad - singular); Bjelovarsko-Bilogorska Zupanija, Brodsko-Posavska
Zupanija, Dubrovacko-Neretvanska Zupanija, Istarska Zupanija,
Karlovacka Zupanija, Koprivnicko-Krizevacka Zupanija,
Krapinsko-Zagorska Zupanija, Licko-Senjska Zupanija, Medimurska
Zupanija, Osjecko-Baranjska Zupanija, Pozesko-Slavonska Zupanija,
Primorsko-Goranska Zupanija, Sibensko-Kninska Zupanija,
Sisacko-Moslavacka Zupanija, Splitsko-Dalmatinska Zupanija,
Varazdinska Zupanija, Viroviticko-Podravska Zupanija,
Vukovarsko-Srijemska Zupanija, Zadarska Zupanija, Zagreb*,
Zagrebacka Zupanija
wheat, corn, sugar beets, sunflower seed, barley, alfalfa,
clover, olives, citrus, grapes, soybeans, potatoes; livestock, dairy
products
59 (2002)
12.76 births/1,000 population (2003 est.)
Ground Forces (Hrvatska Vojska, HV), Naval Forces, Air and
Air Defense Forces
revenues: $8.6 billion
expenditures: $9 billion, including capital expenditures of $NA
(2001 est.)
Before the dissolution of Yugoslavia, the Republic of
Croatia, after Slovenia, was the most prosperous and industrialized
area, with a per capita output perhaps one-third above the Yugoslav
average. The economy emerged from its mild recession in 2000 with
tourism the main factor, but massive structural unemployment remains
a key negative element. The government''s failure to press the
economic reforms needed to spur growth is largely the result of
coalition politics and public resistance, particularly from the
trade unions. Opponents fear reforms would cut jobs, wages, and
social benefits. The government has a heavy backload of civil cases,
many involving tenure land. The country is likely to experience only
moderate growth without disciplined fiscal and structural reform.
gas 1,374 km; oil 583 km (2003)
Croatian Bloc or HB [Ivic PASALIC]; Croatian Christian
Democratic Union or HKDU [Anto KOVACEVIC]; Croatian Democratic Union
or HDZ [Ivo SANADER]; Croatian Party of Rights or HSP [Anto DJAPIC];
Croatian Peasant Party or HSS [Zlatko TOMCIC]; Croatian People''s
Party or HNS [Vesna PUSIC]; Croatian Social Liberal Party or HSLS
[Drazen BUDISA]; Croatian True Revival Party or HIP [Miroslav
TUDJMAN]; Democratic Centre or DC [Mate GRANIC]; Istrian Democratic
Assembly or IDS [Ivan JAKOVCIC]; Liberal Party or LS [Ivo BANAC];
Party of Liberal Democrats or LIBRA [Goran GRANIC]; Social
Democratic Party of Croatia or SDP [Ivica RACAN]
note: the Social Democratic Party or SDP and the Croatian Social
Liberal Party or HSLS formed a coalition as did the HSS, HNS, LP,
and IDS, which together defeated the Croatian Democratic Union or
HDZ in the 2000 lower house parliamentary election; the IDS
subsequently left the governing coalition in June 2001 over its
inability to win greater autonomy for Istria','ea6d75aadb7e11a4cbd030c47b0c38995fa6aeb47ca33be38a1706c1c48cd57c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('297f5ee3f4c3aff86c7fd3618af9c4a63f998cc8e59aef842bd1baa5faa585ea',2003,'CU','Cuba','economy',672,'total: 70
over 3,047 m: 7
2,438 to 3,047 m: 10
1,524 to 2,437 m: 22
under 914 m: 31 (2002)
total: 91
914 to 1,523 m: 28
under 914 m: 63 (2002)
air and water pollution; biodiversity loss; deforestation
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol, Marine Life Conservation
roughly 4% (FY95 est.)
14.38 billion kWh (2001)
13.38 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 93.9%
hydro: 0.6%
nuclear: 0%
other: 5.4% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 24%, industry 25%, services 51% (1999)
sugar, nickel, tobacco, fish, medical products, citrus, coffee
Netherlands 19.1%, Russia 18.1%, Canada 14.3%, Spain 9.5%,
China 7.3% (2002)
14 provinces (provincias, singular - provincia) and 1 special
municipality* (municipio especial); Camaguey, Ciego de Avila,
Cienfuegos, Ciudad de La Habana, Granma, Guantanamo, Holguin, Isla
de la Juventud*, La Habana, Las Tunas, Matanzas, Pinar del Rio,
Sancti Spiritus, Santiago de Cuba, Villa Clara
sugar, tobacco, citrus, coffee, rice, potatoes, beans; livestock
161 (2002)
11.87 births/1,000 population (2003 est.)
Revolutionary Armed Forces (FAR) including Revolutionary Army
(ER), Revolutionary Navy (MGR), Air and Air Defense Force (DAAFAR),
Territorial Militia Troops (MTT), and Youth Labor Army (EJT); note -
the Border Guard Troops (TGF) are controlled by the Interior Ministry
revenues: $14.9 billion
expenditures: $15.6 billion, including capital expenditures of $NA
(2000 est.)
The government continues to balance the need for economic
loosening against a desire for firm political control. It has
undertaken limited reforms in recent years to increase enterprise
efficiency and alleviate serious shortages of food, consumer goods,
and services but is unlikely to implement extensive changes. A major
feature of the economy is the dichotomy between relatively efficient
export enclaves and inefficient domestic sectors. The average
Cuban''s standard of living remains at a lower level than before the
severe economic depression of the early 1990s, which was caused by
the loss of Soviet aid and domestic inefficiencies. High oil import
prices, recessions in key export markets, damage from Hurricanes
Isidore and Lili, and the tourist slump after 11 September 2001
hampered growth in 2002.
gas 49 km; oil 230 km (2003)
Czech Republic
gas 7,020 km; oil 547 km; refined products 94 km
(2003)
only party - Cuban Communist Party or PCC [Fidel CASTRO Ruz,
first secretary]','986f7618e0d1484890c5c51e275ed4c6a585aab523d13dab4a9525e9b08558f1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d7ef26bc58129a1642290d06152f84c052b135637914a45cd5952136f84ed6f',2003,'CY','Cyprus','economy',673,'total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (2002)
Czech Republic
total: 44
2,438 to 3,047 m: 7
1,524 to 2,437 m: 16
914 to 1,523 m: 2
under 914 m: 19 (2002)
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2002)
Czech Republic
total: 100
1,524 to 2,437 m: 2
914 to 1,523 m: 36
under 914 m: 62 (2002)
water resource problems (no natural reservoir catchments,
seasonal disparity in rainfall, sea water intrusion to island''s
largest aquifer, increased salination in the north); water pollution
from sewage and industrial wastes; coastal degradation; loss of
wildlife habitats from urbanization
Czech Republic
air and water pollution in areas of northwest Bohemia
and in northern Moravia around Ostrava present health risks; acid
rain damaging forests; efforts to bring industry up to EU code
should improve domestic pollution
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
Czech Republic
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol
3.8% (FY02)
Czech Republic
2.1% (FY01)
3.401 billion kWh; Turkish Cypriot area: NA kWh (2001)
Czech Republic
70.04 billion kWh (2001)
Greek Cypriot area: 3.163 billion kWh; Turkish Cypriot area:
NA kWh (2001)
Czech Republic
55.6 billion kWh (2001)
0 kWh (2001)
Czech Republic
9.38 billion kWh (2001)
0 kWh (2001)
Czech Republic
18.92 billion kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Czech Republic
fossil fuel: 76.1%
hydro: 2.9%
nuclear: 20%
other: 1% (2001)
NA%
Czech Republic
NA%
lowest 10%: NA%
highest 10%: NA%
Czech Republic
lowest 10%: 4.3%
highest 10%: 22.4% (1996)
Greek Cypriot area: services 73%, industry 22%, agriculture
5% (2000); Turkish Cypriot area: services 56.4%, industry 22.8%,
agriculture 20.8% (1998)
Czech Republic
agriculture 5%, industry 35%, services 60% (2001 est.)
Greek Cypriot area: citrus, potatoes, pharmaceuticals,
cement, clothing and cigarettes; Turkish Cypriot area: citrus,
potatoes, textiles
Czech Republic
machinery and transport equipment 44%, intermediate
manufactures 25%, chemicals 7%, raw materials and fuel 7% (2000)
UK 28.2%, Greece 7%, UAE 5.3%, France 5.2% (2002)
Czech Republic
Germany 40.2%, Slovakia 7.1%, Austria 5.8%, UK 5.1%,
Poland 5%, France 4% (2002)
6 districts; Famagusta, Kyrenia, Larnaca, Limassol, Nicosia,
Paphos; note - Turkish Cypriot area''s administrative divisions
include Kyrenia, all but a small part of Famagusta, and small parts
of Lefkosa (Nicosia) and Larnaca
Czech Republic
13 regions (kraje, singular - kraj) and 1 capital
city* (hlavni mesto); Jihocesky Kraj, Jihomoravsky Kraj, Karlovarsky
Kraj, Kralovehradecky Kraj, Liberecky Kraj, Moravskoslezsky Kraj,
Olomoucky Kraj, Pardubicky Kraj, Plzensky Kraj, Praha*, Stredocesky
Kraj, Ustecky Kraj, Vysocina, Zlinsky Kraj
potatoes, citrus, vegetables, barley, grapes, olives,
vegetables
Czech Republic
wheat, potatoes, sugar beets, hops, fruit; pigs,
poultry
16 (2002)
Czech Republic
144 (2002)
12.77 births/1,000 population (2003 est.)
Czech Republic
9.01 births/1,000 population (2003 est.)
Greek Cypriot area: Greek Cypriot National Guard (GCNG;
including air and naval elements), Greek Cypriot Police
Turkish Cypriot area: Turkish Cypriot Security Force (GKK)
Czech Republic
Army, Air and Air Defense Forces, Territorial Defense
Force
revenues: Greek Cypriot area - $4.4 billion, Turkish Cypriot
area - $231.3 million (2002 est.)
expenditures: $3.7 billion, Greek Cypriot area - $539 million,
including capital expenditures of $539 million, Turkish Cypriot area
- $432.8 million, including capital expenditures of NA (2003 est.)
Czech Republic
revenues: $16.7 billion
expenditures: $18 billion, including capital expenditures of $NA
(2001 est.)
The Greek Cypriot economy is prosperous but highly
susceptible to external shocks. Erratic growth rates over the past
decade reflect the economy''s vulnerability to swings in tourist
arrivals, caused by political instability in the region and
fluctuations in economic conditions in Western Europe. Economic
policy is focused on meeting the criteria for admission to the EU.
As in the Turkish sector, water shortages are a perennial problem; a
few desalination plants are now online. The Turkish Cypriot economy
has roughly one-third of the per capita GDP of the south. Because it
is recognized only by Turkey, it has had much difficulty arranging
foreign financing and investment. It remains heavily dependent on
agriculture and government service, which together employ about half
of the work force. To compensate for the economy''s weakness, Turkey
provides grants and loans to support economic development. Ankara
provided $200 million in 2002 and pledged $450 million for the
2003-05 period. Future events throughout the island will be highly
influenced by the outcome of negotiations on the UN-sponsored
agreement to unite the Greek and Turkish areas and by the
arrangements under which the island joins the EU.
Czech Republic
One of the most stable and prosperous of the
post-Communist states, the Czech Republic has been recovering from
recession since mid-1999. Growth in 2000-03 was supported by exports
to the EU, primarily to Germany, and a near doubling of foreign
direct investment. Domestic demand is playing an ever more important
role in underpinning growth as interest rates drop and the
availability of credit cards and mortgages increases. High current
account deficits - averaging around 5% of GDP in the last several
years - could be a persistent problem. Inflation is under control.
The EU put the Czech Republic just behind Poland and Hungary in
preparations for accession, which will give further impetus and
direction to structural reform. Moves to complete banking,
telecommunications, and energy privatization will encourage
additional foreign investment, while intensified restructuring among
large enterprises and banks and improvements in the financial sector
should strengthen output growth. But revival in the European
economies remains essential to stepped-up growth.
Greek Cypriot area: Democratic Party or DIKO [Tassos
PAPADOPOULOS]; Democratic Rally or DISY [Nikos ANASTASIADHIS];
Fighting Democratic Movement or ADIK [Dinos MIKHAILIDIS]; Green
Party of Cyprus [George PERDIKIS]; New Horizons [Nikolaus KOUTSOU];
Restorative Party of the Working People or AKEL (Communist Party)
[Dimitrios CHRISTOFIAS]; Social Democrats Movement or KISOS
(formerly United Democratic Union of Cyprus or EDEK) [Yiannakis
OMIROU]; United Democrats Movement or EDE [George VASSILIOU];
Turkish Cypriot area: Communal Liberation Party or TKP [Mustafa
AKINCI]; Democratic Party or DP [Serder DENKTASH]; National Birth
Party or UDP [Enver EMIN]; National Unity Party or UBP [Dervis
EROGLU]; Our Party or BP [Okyay SADIKOGLU]; Patriotic Unity Movement
or YBH [Izzet IZCAN]; Republican Turkish Party or CTP [Mehmet ALI
TALAT]
Czech Republic
Christian and Democratic Union-Czechoslovak People''s
Party or KDU-CSL [Miroslav KALOUSEK, chairman]; Civic Democratic
Alliance or ODA [Michael ZANTOVSKY, chairman]; Civic Democratic
Party or ODS [Mirek TOPOLANEK, chairman]; Communist Party of Bohemia
and Moravia or KSCM [Miroslav GREBENICEK, chairman]; Communist Party
of Czechoslovakia or KSC [Miroslav STEPAN, chairman]; Czech National
Social Party of CSNS [Jan SULA, chairman]; Czech Social Democratic
Party or CSSD [Vladimir SPIDLA, chairman]; Freedom Union-Democratic
Union or US-DEU [Petr MARES, chairman]; Quad Coalition [Karel KUHNL,
chairman] (includes KDU-CSL, US, ODA, DEU)','e5e4d5ba1d98425c473c5d6ac262190476fde6c4d4111d3917c8da25f8666548','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3718fd9e60b2e65687c02697c922dcd3ea8463904dace477aaf8fd6ee6fdd74',2003,'DK','Denmark','economy',674,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2002)
total: 76
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 71 (2002)
air pollution, principally from vehicle and power plant
emissions; nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from animal wastes and
pesticides
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental Protocol, Law of
the Sea
1.4% (FY99/00)
35.47 billion kWh (2001)
32.41 billion kWh (2001)
8.199 billion kWh (2001)
8.775 billion kWh (2001)
fossil fuel: 82.7%
hydro: 0.1%
nuclear: 0%
other: 17.3% (2001)
NA%
lowest 10%: 2%
highest 10%: 24% (2000 est.)
services 79%, industry 17%, agriculture 4% (2002 est.)
machinery and instruments, meat and meat products, dairy
products, fish, chemicals, furniture, ships, windmills
Germany 17.1%, Sweden 11.6%, UK 7.8%, US 6.8%, France 5.8%,
Norway 5.7%, Japan 4.4% (2002)
metropolitan Denmark - 14 counties (amter, singular - amt)
and 2 boroughs* (amtskommuner, singular - amtskomunes); Arhus,
Bornholm, Fredericksberg*, Frederiksborg, Fyn, Kobenhavn,
Kobenhavns*, Nordjylland, Ribe, Ringkobing, Roskilde, Sonderjylland,
Storstrom, Vejle, Vestsjalland, Viborg
note: see separate entries for the Faroe Islands and Greenland,
which are part of the Kingdom of Denmark and are self-governing
overseas administrative divisions
barley, wheat, potatoes, sugar beets; pork, dairy products;
fish
104 (2002)
11.52 births/1,000 population (2003 est.)
Royal Danish Army, Royal Danish Navy, Royal Danish Air
Force, Home Guard
revenues: $52.9 billion
expenditures: $51.3 billion, including capital expenditures of $500
million (2001 est.)
This thoroughly modern market economy features high-tech
agriculture, up-to-date small-scale and corporate industry,
extensive government welfare measures, comfortable living standards,
a stable currency, and high dependence on foreign trade. Denmark is
a net exporter of food and energy and enjoys a comfortable balance
of payments surplus. Government objectives include streamlining the
bureaucracy and further privatization of state assets. The
government has been successful in meeting, and even exceeding, the
economic convergence criteria for participating in the third phase
(a common European currency) of the European Economic and Monetary
Union (EMU), but Denmark has decided not to join the 12 other EU
members in the euro; even so, the Danish Krone remains pegged to the
euro. Given the sluggish state of the European economy, growth in
2003 was a mere 1.1%.
condensate 12 km; gas 3,892 km; oil 455 km; oil/gas/water 2
km; unknown (oil/water) 64 km (2003)
Center Democratic Party [Mimi JAKOBSEN]; Christian People''s
Party [Marianne KARLSMOSE]; Conservative Party (sometimes known as
Conservative People''s Party) [Bendt BENDTSEN]; Danish People''s Party
[Pia KJAERSGAARD]; Liberal Party [Anders Fogh RASMUSSEN]; Social
Democratic Party [Mogens LYKKETOFT]; Social Liberal Party (sometimes
called the Radical Left) [Marianne JELVED, leader; Johannes LEBECH,
chairman]; Socialist People''s Party [Holger K. NIELSEN]; Red-Green
Unity List (bloc includes Left Socialist Party, Communist Party of
Denmark, Socialist Workers'' Party) [collective leadership]','830213a43093b1a0bf388646c6a6219b0f1f9ee70d5e515116bf56c9faf28f82','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c0f831c0ec155e64001ac5a10b9e812b700938e1a278fd108a0ba84f75e13d7',2003,'DJ','Djibouti','economy',675,'total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1524 to 2437 m: 1 (2002)
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2002)
inadequate supplies of potable water; limited arable land;
desertification; endangered species
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected agreements
4.4% (FY02)
180 million kWh (2001)
167.4 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
50% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
NA%
reexports, hides and skins, coffee (in transit)
Somalia 56.7%, Yemen 24.4%, Pakistan 4.8%, Ethiopia 4.4%,
UAE 4.1% (2002)
5 districts (cercles, singular - cercle); ''Ali Sabih,
Dikhil, Djibouti, Obock, Tadjoura
fruits, vegetables; goats, sheep, camels
13 (2002)
40.78 births/1,000 population (2003 est.)
Djibouti National Army (including Navy and Air Force)
revenues: $135 million
expenditures: $182 million, including capital expenditures of $NA
(1999 est.)
The economy is based on service activities connected with
the country''s strategic location and status as a free trade zone in
northeast Africa. Two-thirds of the inhabitants live in the capital
city, the remainder being mostly nomadic herders. Scanty rainfall
limits crop production to fruits and vegetables, and most food must
be imported. Djibouti provides services as both a transit port for
the region and an international transshipment and refueling center.
It has few natural resources and little industry. The nation is,
therefore, heavily dependent on foreign assistance to help support
its balance of payments and to finance development projects. An
unemployment rate of 50% continues to be a major problem. Inflation
is not a concern, however, because of the fixed tie of the franc to
the US dollar. Per capita consumption dropped an estimated 35% over
the last seven years because of recession, civil war, and a high
population growth rate (including immigrants and refugees). Faced
with a multitude of economic difficulties, the government has fallen
in arrears on long-term external debt and has been struggling to
meet the stipulations of foreign aid donors. Another factor limiting
growth is the negative impact on port activity now that Ethiopia has
more trade route options.
Democratic National Party or PND [ADEN Robleh Awaleh];
Democratic Renewal Party or PRD [Abdillahi HAMARITEH]; Djibouti
Development Party or PDD [Mohamed Daoud CHEHEM]; Front pour la
Restauration de l''Unite Democratique or FRUD [Ali Mohamed DAOUD];
People''s Progress Assembly or RPP (governing party) [Ismail Omar
GUELLEH]; Peoples Social Democratic Party or PPSD [Moumin Bahdon
FARAH]; Republican Alliance for Democracy or ARD [Ahmed Dini AHMED];
Union for Democracy and Justice or UDJ [leader NA]','6702154a6084c589da2cac6ace12c8c9a047a707e4c6285291af9b02a72f77e1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5a7242cc487ed65c86010306e3e97f5c6bb9456f3a88db4475bb2ce5ea574dd',2003,'DM','Dominica','economy',676,'total: 2
914 to 1,523 m: 2 (2002)
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA%
72.41 million kWh (2001)
67.35 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 47.1%
hydro: 52.9%
nuclear: 0%
other: 0% (2001)
30% (2002 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture 40%, industry and commerce 32%, services 28%
bananas, soap, bay oil, vegetables, grapefruit, oranges
UK 36.1%, Jamaica 18%, US 7.5%, Antigua and Barbuda 6.4%,
Guyana 5.4%, Trinidad and Tobago 4.4% (2002)
10 parishes; Saint Andrew, Saint David, Saint George, Saint
John, Saint Joseph, Saint Luke, Saint Mark, Saint Patrick, Saint
Paul, Saint Peter
bananas, citrus, mangoes, root crops, coconuts, cocoa;
forest and fishery potential not exploited
2 (2002)
16.78 births/1,000 population (2003 est.)
Commonwealth of Dominica Police Force (including Special
Service Unit, Coast Guard)
revenues: $73.9 million
expenditures: $84.4 million, including capital expenditures of $NA
(2001)
The Dominican economy depends on agriculture, primarily
bananas, and remains highly vulnerable to climatic conditions and
international economic developments. Hurricane Luis devastated the
country''s banana crop in 1995 after tropical storms wiped out a
quarter of the 1994 crop. The economy subsequently has been fueled
by increases in construction, soap production, and tourist arrivals.
Development of the tourism industry remains difficult however,
because of the rugged coastline, lack of beaches, and the absence of
an international airport. Economic growth is sluggish, and
unemployment is greater than 20%. The government has been attempting
to develop an offshore financial sector in order to diversify the
island''s production base.
Dominica Freedom Party or DFP [Charles SAVARIN]; Dominica
Labor Party or DLP [Pierre CHARLES]; United Workers Party or UWP
[Edison JAMES]','c9a99a3d412d5e4f7a241e922ab1cd728d1947b551aff2f01aef097fd9a4cd6c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a35c7feb859b3e1d94f7c34885c685cdd471dd904dece5b9588c05380f7240ae',2003,'DO','Dominican Republic','economy',677,'total: 13
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 1 (2002)
East Timor
total: 3
2,438 to 3,047 m: 1
1,524 to 2,427 m: 1
914 to 1,523 m: 1 (2002)
total: 17
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 10 (2002)
East Timor
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2002)
water shortages; soil eroding into the sea
damages coral reefs; deforestation; Hurricane Georges damage
East Timor
widespread use of slash and burn agriculture has led to
deforestation and soil erosion
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Law of the Sea
East Timor
NA
1.1% (FY98)
East Timor
NA%
9.186 billion kWh (2001)
East Timor
NA kWh (2001)
8.543 billion kWh (2001)
East Timor
NA kWh (2001)
0 kWh (2001)
East Timor
0 kWh (2001)
0 kWh (2001)
East Timor
0 kWh (2001)
fossil fuel: 92%
hydro: 7.6%
nuclear: 0%
other: 0.4% (2001)
East Timor
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
25%
East Timor
42% (2002 est.)
lowest 10%: 2.1%
highest 10%: 37.9% (1998)
East Timor
lowest 10%: NA%
highest 10%: NA%
services and government 58.7%, industry 24.3%,
agriculture 17% (1998 est.)
East Timor
NA
ferronickel, sugar, gold, silver, coffee, cocoa,
tobacco, meats, consumer goods
East Timor
coffee, sandalwood, marble; note - the potential for oil
and vanilla exports
US 85%, Canada 1.6%, UK 1.6% (2002)
East Timor
NA
29 provinces (provincias, singular - provincia)
and 1 district* (distrito); Azua, Baoruco, Barahona, Dajabon,
Distrito Nacional*, Duarte, Elias Pina, El Seibo, Espaillat, Hato
Mayor, Independencia, La Altagracia, La Romana, La Vega, Maria
Trinidad Sanchez, Monsenor Nouel, Monte Cristi, Monte Plata,
Pedernales, Peravia, Puerto Plata, Salcedo, Samana, Sanchez Ramirez,
San Cristobal, San Juan, San Pedro de Macoris, Santiago, Santiago
Rodriguez, Valverde
East Timor
13 administrative districts; Aileu, Ainaro, Baucau,
Bobonaro (Maliana), Cova-Lima (Suai), Dili, Ermera, Lautem (Los
Palos), Liquica, Manatuto, Manufahi (Same), Oecussi (Ambeno),
Viqueque
sugarcane, coffee, cotton, cocoa, tobacco, rice,
beans, potatoes, corn, bananas; cattle, pigs, dairy products, beef,
eggs
East Timor
coffee, rice, maize, cassava, sweet potatoes, soybeans,
cabbage, mangoes, bananas, vanilla
30 (2002)
East Timor
8 (2002)
23.94 births/1,000 population (2003 est.)
East Timor
27.75 births/1,000 population (2003 est.)
Army, Navy, Air Force, National Police
East Timor
The East Timor Defense Force or FALINTIL-FDTL comprises a
light-infantry Army and a small Naval component; note - plans are to
develop a force of 1,500 active personnel and 1,500 reserve
personnel over the next five years
revenues: $2.9 billion
expenditures: $3.2 billion, including capital expenditures of $1.1
billion (2001 est.)
East Timor
revenues: $36 million
expenditures: $97 million, including capital expenditures of $NA
(2003 est.)
The Dominican Republic''s economy experienced
dramatic growth over the last decade, even though the economy was
hit hard by Hurricane Georges in 1998. Although the country has long
been viewed primarily as an exporter of sugar, coffee, and tobacco,
in recent years the service sector has overtaken agriculture as the
economy''s largest employer, due to growth in tourism and free trade
zones. The country suffers from marked income inequality; the
poorest half of the population receives less than one-fifth of GNP,
while the richest 10% enjoy nearly 40% of national income. Growth
probably will slow in 2003 with reduced tourism and expected low
growth in the US economy, the source of 87% of export revenues.
East Timor
In late 1999, about 70% of the economic infrastructure of
East Timor was laid waste by Indonesian troops and anti-independence
militias, and 260,000 people fled westward. Over the next three
years, however, a massive international program, manned by 5,000
peacekeepers (8,000 at peak) and 1,300 police officers, led to
substantial reconstruction in both urban and rural areas. By
mid-2002, all but about 50,000 of the refugees had returned. The
country faces great challenges in continuing the rebuilding of
infrastructure and the strengthening of the infant civil
administration. One promising long-term project is the planned
development of oil resources in nearby waters.
crude oil 96 km; petroleum products 8 km
East Timor
NA
Dominican Liberation Party or PLD [Leonel
FERNANDEZ Reyna]; Dominican Revolutionary Party or PRD [Hatuey DE
CAMPS]; Social Christian Reformist Party or PRSC [Eduardo ESTRELLA]
East Timor
Associacao Social-Democrata Timorense or ASDT [Francisco
Xavier do AMARAL]; Christian Democratic Party of Timor or PDC
[Antonio XIMENES]; Christian Democratic Union of Timor or UDC
[Vicente da Silva GUTERRES]; Democratic Party or PD [Fernando de
ARAUJO]; Liberal Party or PL [leader NA]; Maubere Democratic Party
or PDM [leader NA]; People''s Party of Timor or PPT [Jacob XAVIER];
Revolutionary Front of Independent East Timor or FRETILIN [Lu OLO];
Social Democrat Party of East Timor or PSD [Mario CARRASCALAO];
Socialist Party of Timor or PST [leader NA]; Sons of the Mountain
Warriors (also known as Association of Timorese Heroes) or KOTA
[Clementino dos Reis AMARAL]; Timor Democratic Union or UDT [Joao
CARRASCALAO]; Timor Labor Party or PTT [Paulo Freitas DA SILVA];
Timorese Nationalist Party or PNT [Abilio ARAUJO]; Timorese Popular
Democratic Association or APODETI [Frederico Almeida-Santos DA COSTA]','9064c692fe2594df463df68e57f7bb0cb0e7bac06f627599ec7ec26fb3bd603a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc5546e15e35c3a39da1d423c8a0960909dd446c3cf256b157a5b4ebe9a23744',2003,'EC','Ecuador','economy',678,'total: 61
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 18
914 to 1,523 m: 18
under 914 m: 18 (2002)
total: 144
914 to 1,523 m: 31
under 914 m: 113 (2002)
deforestation; soil erosion; desertification; water
pollution; pollution from oil production wastes in ecologically
sensitive areas of the Galapagos Islands
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
3.4% (FY98)
75.23 billion kWh (2001)
69.96 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 81%
hydro: 19%
nuclear: 0%
other: 0% (2001)
70% (2001 est.)
lowest 10%: 2.2%
highest 10%: 33.8% (1995)
agriculture 30%, industry 25%, services 45% (2001 est.)
petroleum, bananas, shrimp, coffee, cocoa, cut flowers, fish
US 39%, Colombia 5.6%, South Korea 5.1%, Germany 5%, Italy
4.4% (2002)
22 provinces (provincias, singular - provincia); Azuay,
Bolivar, Canar, Carchi, Chimborazo, Cotopaxi, El Oro, Esmeraldas,
Galapagos, Guayas, Imbabura, Loja, Los Rios, Manabi,
Morona-Santiago, Napo, Orellana, Pastaza, Pichincha, Sucumbios,
Tungurahua, Zamora-Chinchipe
bananas, coffee, cocoa, rice, potatoes, manioc (tapioca),
plantains, sugarcane; cattle, sheep, pigs, beef, pork, dairy
products; balsa wood; fish, shrimp
205 (2002)
24.94 births/1,000 population (2003 est.)
Army, Navy (including Marines), Air Force, National Police
revenues: $5.6 billion
expenditures: planned $5.6 billion, including capital expenditures
of $NA (2001 est.)
Ecuador has substantial oil resources and rich agricultural
areas. Because the country exports primary products such as oil,
bananas, and shrimp, fluctuations in world market prices can have a
substantial domestic impact. Ecuador joined the World Trade
Organization (WTrO) in 1996, but has failed to comply with many of
its accession commitments. The aftermath of El Nino and depressed
oil market of 1997-98 drove Ecuador''s economy into a free-fall in
1999. The beginning of 1999 saw the banking sector collapse, which
helped precipitate an unprecedented default on external loans later
that year. Continued economic instability drove a 70% depreciation
of the currency throughout 1999, which forced a desperate government
to "dollarize" the currency regime in 2000. The move stabilized the
currency, but did not stave off the ouster of the government.
Gustavo NOBOA, who assumed the presidency in January 2000, has
managed to pass substantial economic reforms and mend relations with
international financial institutions. Ecuador completed its first
standby agreement since 1986 when the IMF Board approved a 10
December 2001 disbursement of $96 million, the final installment of
a $300 million standby credit agreement. In February 2003, newly
installed president Lucio GUTIERREZ faced a budget gap and massive
foreign debt. He has pledged to use oil revenues to pay off debt and
is seeking additional IMF support.
gas 71 km; oil 1,575 km; refined products 1,185 km (2003)
Concentration of Popular Forces or CFP [Averroes BUCARAM];
Democratic Left or ID [Rodrigo BORJA Cevallos]; National Action
Institutional Renewal Party or PRIAN [leader NA]; Pachakutik
Movement [Miguel LLUCO]; Patriotic Society Party or PSP [leader NA];
Popular Democracy or DP [Dr. Juan Manuel FUERTES]; Popular
Democratic Movement or MPD [Gustavo TERAN Acosta]; Radical Alfarista
Front or FRA [Fabian ALARCON, director]; Roldosist Party or PRE
[Abdala BUCARAM Ortiz, director]; Social Christian Party or PSC
[Pascual DEL CIOPPO]; Socialist Party or PS [leader NA]','9168cc3d73df6120db9ed36a8b9058b38969842f7ad4b8bfa160e65ee41f34d7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a24be722f1e20d3c3bf04d8200d81847f56877a92613442b25c924df190c96',2003,'EG','Egypt','economy',679,'total: 71
over 3,047 m: 13
2,438 to 3,047 m: 38
1,524 to 2,437 m: 17
under 914 m: 3 (2002)
total: 18
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 6
under 914 m: 9 (2002)
agricultural land being lost to urbanization and windblown
sands; increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs, beaches, and
marine habitats; other water pollution from agricultural pesticides,
raw sewage, and industrial effluents; very limited natural fresh
water resources away from the Nile which is the only perennial water
source; rapid growth in population overstraining the Nile and
natural resources
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
4.1% (FY99)
75.23 billion kWh (2001)
69.96 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 81%
hydro: 19%
nuclear: 0%
other: 0% (2001)
22.9% (FY 95/96 est.)
lowest 10%: 4.4%
highest 10%: 25% (1995)
agriculture 29%, industry 22%, services 49% (2000 est.)
crude oil and petroleum products, cotton, textiles, metal
products, chemicals
US 18.3%, Italy 13.7%, UK 8.4% (2002)
26 governorates (muhafazat, singular - muhafazah); Ad
Daqahliyah, Al Bahr al Ahmar, Al Buhayrah, Al Fayyum, Al Gharbiyah,
Al Iskandariyah, Al Isma''iliyah, Al Jizah, Al Minufiyah, Al Minya,
Al Qahirah, Al Qalyubiyah, Al Wadi al Jadid, Ash Sharqiyah, As
Suways, Aswan, Asyut, Bani Suwayf, Bur Sa''id, Dumyat, Janub Sina'',
Kafr ash Shaykh, Matruh, Qina, Shamal Sina'', Suhaj
cotton, rice, corn, wheat, beans, fruits, vegetables; cattle,
water buffalo, sheep, goats
89 (2002)
24.36 births/1,000 population (2003 est.)
Army, Navy, Air Force, Air Defense Command
revenues: $21.5 billion
expenditures: $26.2 billion, including capital expenditures of $5.9
billion (2001)
Egypt improved its macroeconomic performance throughout most
of the last decade by following IMF advice on fiscal, monetary, and
structural reform policies. As a result, Egypt managed to tame
inflation, slash budget deficits, and attract more foreign
investment. In the past four years, however, the pace of reform has
slackened, and excessive spending on national infrastructure
projects has widened budget deficits again. Lower foreign exchange
earnings since 1998 resulted in pressure on the Egyptian pound and
periodic dollar shortages. Monetary pressures have increased since
11 September 2001 because of declines in tourism and Suez Canal
tolls, and Egypt has devalued the pound several times in the past
year. The development of a gas export market is a major bright spot
for future growth prospects. In the short term, regional tensions
will continue to affect tourism and hold back prospects for economic
expansion.
condensate 327 km; condensate/gas 94 km; gas 6,145 km; liquid
petroleum gas 382 km; oil 5,726 km; oil/gas/water 36 km; water 62 km
(2003)
Nasserist Arab Democratic Party or Nasserists [Dia'' al-din
DAWUD]; National Democratic Party or NDP [President Mohammed Hosni
MUBARAK] - governing party; National Progressive Unionist Grouping
or Tagammu [Khalid MUHI AL-DIN]; New Wafd Party or NWP [No''man
GOMA]; Socialist Liberal Party or LSP [leader NA]
note: formation of political parties must be approved by the','99767995f856e0c17e26ffd858588636228f79032f069e1c545a5409b2d51d2a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c3c689d85666c552f3cbcaf6819bf992e14601a08275a40a3c15fb6a9be05ef',2003,'SV','El Salvador','economy',680,'total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2002)
total: 78
914 to 1,523 m: 17
under 914 m: 61 (2002)
deforestation; soil erosion; water pollution;
contamination of soils from disposal of toxic wastes
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
0.7% (FY99)
3.729 billion kWh (2001)
3.777 billion kWh (2001)
353 million kWh (2001)
44 million kWh (2001)
fossil fuel: 44%
hydro: 30.9%
nuclear: 0%
other: 25.1% (2001)
48% (1999 est.)
lowest 10%: 1.4%
highest 10%: 39.3% (2001)
agriculture 30%, industry 15%, services 55% (1999 est.)
offshore assembly exports, coffee, sugar, shrimp,
textiles, chemicals, electricity
US 63.3%, Guatemala 12%, Honduras 6.8%, Nicaragua 4.5%
(2002)
14 departments (departamentos, singular - departamento);
Ahuachapan, Cabanas, Chalatenango, Cuscatlan, La Libertad, La Paz,
La Union, Morazan, San Miguel, San Salvador, Santa Ana, San Vicente,
Sonsonate, Usulutan
coffee, sugar, corn, rice, beans, oilseed, cotton,
sorghum; shrimp; beef, dairy products
82 (2002)
27.9 births/1,000 population (2003 est.)
Army, Navy (FNES), Air Force
revenues: $2.1 billion
expenditures: $2.5 billion, including capital expenditures of $NA
(2001 est.)
In recent years, this Central American economy has been
suffering from a weak tax collection system, factory closings, the
aftermaths of Hurricane Mitch of 1998 and the devastating
earthquakes of early 2001, and weak world coffee prices. On the
bright side, inflation has fallen to single digit levels, and total
exports have grown substantially. The trade deficit has been offset
by annual remittances of almost $2 billion from Salvadorans living
abroad and by external aid. The US dollar is now the legal tender.
Because competitor countries have fluctuating exchange rates, El
Salvador must face the challenge of raising productivity and
lowering costs.','5b288cedf95668d6c4a3154374558d56ab36a1532c68a06fd9ccb5841b721654','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('070d91d4bee41538e11362d5ef2c5a031d825cdaa0e1d23002b25d40ca72fb4b',2003,'GQ','Equatorial Guinea','economy',681,'total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2002)
total: 1
under 914 m: 1 (2002)
tap water is not potable; deforestation
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species, Law of
the Sea, Ship Pollution
signed, but not ratified: none of the selected agreements
2.5% (FY02)
23.56 million kWh (2001)
21.91 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 94.3%
hydro: 5.7%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
petroleum, methanol, timber, cocoa
US 28.3%, Spain 25.3%, China 17.4%, Canada 10.6%,
France 4.9% (2002)
7 provinces (provincias, singular - provincia);
Annobon, Bioko Norte, Bioko Sur, Centro Sur, Kie-Ntem, Litoral,
Wele-Nzas
coffee, cocoa, rice, yams, cassava (tapioca),
bananas, palm oil nuts; livestock; timber
3 (2002)
36.94 births/1,000 population (2003 est.)
Army, Navy, Air Force, Rapid Intervention Force,
National Police
revenues: $200 million
expenditures: $158 million, including capital expenditures of $NA
(2001 est.)
The discovery and exploitation of large oil
reserves have contributed to dramatic economic growth in recent
years. Forestry, farming, and fishing are also major components of
GDP. Subsistence farming predominates. Although pre-independence
Equatorial Guinea counted on cocoa production for hard currency
earnings, the neglect of the rural economy under successive regimes
has diminished potential for agriculture-led growth (the government
has stated its intention to reinvest some oil revenue into
agriculture). A number of aid programs sponsored by the World Bank
and the IMF have been cut off since 1993 because of corruption and
mismanagement. No longer eligible for concessional financing because
of large oil revenues, the government has been unsuccessfully trying
to agree on a "shadow" fiscal management program with the World Bank
and IMF. Businesses, for the most part, are owned by government
officials and their family members. Undeveloped natural resources
include titanium, iron ore, manganese, uranium, and alluvial gold.
Growth will remain strong in 2003, led by oil.
condensate 37 km; gas 39 km; liquid natural gas 4
km; oil 24 km (2003)','bdad0d9d0b197085da2a78b6171107a283496752b69a2f562b090a364dd995bd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41bc6444f702be1b0c5679dc29ecfcc00955859faf544adbef66248d7955ddbb',2003,'ER','Eritrea','economy',682,'total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2002)
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 2 (2002)
deforestation; desertification; soil erosion; overgrazing;
loss of infrastructure from civil warfare
party to: Biodiversity, Climate Change, Desertification,
Endangered Species
signed, but not ratified: none of the selected agreements
12% (FY02)
220.5 million kWh (2001)
205.1 million kWh (2001)
0 kWh NA kWh (2001)
0 kWh NA kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
53% (1993/94)
lowest 10%: NA%
highest 10%: NA%
agriculture 80%, industry and services 20%
livestock, sorghum, textiles, food, small manufactures (2000)
Italy 36.9%, Germany 16.7%, France 10.3%, US 5.4%,
Netherlands 5.2% (2002)
6 regions (regions, singular - region); Central, Anelba,
Southern Red Sea, Northern Red Sea, Southern, Gash-Barka
sorghum, lentils, vegetables, corn, cotton, tobacco, coffee,
sisal; livestock, goats; fish
18 (2002)
39.44 births/1,000 population (2003 est.)
Army, Navy, Air Force
revenues: $206.4 million
expenditures: $615.7 million, including capital expenditures of $NA
(2000 est.)
Since independence from Ethiopia on 24 May 1993, Eritrea has
faced the economic problems of a small, desperately poor country.
Like the economies of many African nations, the economy is largely
based on subsistence agriculture, with 80% of the population
involved in farming and herding. The Ethiopian-Eritrea war in
1998-2000 severely hurt Eritrea''s economy. GDP growth fell to zero
in 1999 and to -1% in 2000. The May 2000 Ethiopian offensive into
northern Eritrea caused some $600 million in property damage and
loss, including losses of $225 million in livestock and 55,000
homes. The attack prevented planting of crops in Eritrea''s most
productive region, causing food production to drop by 62%. Even
during the war, Eritrea developed its transportation infrastructure,
asphalting new roads, improving its ports, and repairing war damaged
roads and bridges. Since the war ended, the government has
maintained a firm grip on the economy, expanding the use of the
military and party-owned businesses to complete Eritrea''s
development agenda. Erratic rainfall and the delayed demobilization
of agriculturalists from the military kept cereal production well
below normal, holding down growth in 2002. Eritrea''s economic future
depends upon its ability to master social problems such as
illiteracy, unemployment, and low skills, and to open its economy to
private enterprise so the diaspora''s money and expertise can foster
economic growth.','18d171c235cfd365444ce567e36d6dc60be9637bf124f38320af953b7fbe13bc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2942f9af1f4fc5ad56d243a746ba5d441ca804c7595381abbc62732b38449a0e',2003,'EE','Estonia','economy',683,'total: 14
2,438 to 3,047 m: 9
1,524 to 2,437 m: 1
under 914 m: 4 (2002)
total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 5
under 914 m: 6 (2002)
air polluted with sulfur dioxide from oil-shale burning
power plants in northeast; however, the amount of pollutants emitted
to the air have fallen steadily, the emissions of 2000 were 80% less
than in 1980; the amount of unpurified wastewater discharged to
water bodies in 2000 was one twentieth the level of 1980; in
connection with the start-up of new water purification plants, the
pollution load of wastewater decreased; Estonia has more than 1,400
natural and manmade lakes, the smaller of which in agricultural
areas need to be monitored; coastal seawater is polluted in certain
locations
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Ship Pollution, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
2% (2002 est.)
7.937 billion kWh (2001)
6.192 billion kWh (2001)
0 kWh (2001)
1.19 billion kWh (2001)
fossil fuel: 99.8%
hydro: 0.1%
nuclear: 0%
other: 0.2% (2001)
NA% (2000)
lowest 10%: 3%
highest 10%: 29.8% (1998)
industry 20%, agriculture 11%, services 69% (1999 est.)
machinery and equipment 33%, wood and paper 15%, textiles
14%, food products 8%, furniture 7%, metals, chemical products (2001)
Finland 19.2%, Sweden 13.2%, UK 10.6%, Latvia 7.4%, Germany
7.2% (2002)
15 counties (maakonnad, singular - maakond): Harjumaa
(Tallinn), Hiiumaa (Kardla), Ida-Virumaa (Johvi), Jarvamaa (Paide),
Jogevamaa (Jogeva), Laanemaa (Haapsalu), Laane-Virumaa (Rakvere),
Parnumaa (Parnu), Polvamaa (Polva), Raplamaa (Rapla), Saaremaa
(Kuressaare), Tartumaa (Tartu), Valgamaa (Valga), Viljandimaa
(Viljandi), Vorumaa (Voru)
note: counties have the administrative center name following in
parentheses
potatoes, vegetables; livestock and dairy products; fish
38 (2002)
9.24 births/1,000 population (2003 est.)
Estonia Defense Forces (including Ground Forces, Navy, Air
Force), Republic Security Forces (internal and border troops),
Volunteer Defense League (Kaitseliit), Maritime Border Guard, Coast
Guard
note: Border Guards and Ministry of Internal Affairs become part of
the Estonian Defense Forces in wartime; the Coast Guard is
subordinate to the Ministry of Defense in peacetime and the Estonian
Navy in wartime
revenues: $1.89 billion
expenditures: $1.89 billion, including capital expenditures of $NA
(2002 est.)
Estonia, as a new member of the World Trade Organization, is
steadily moving toward a modern market economy with increasing ties
to the West, including the pegging of its currency to the euro. The
economy benefits from strong electronics and telecoms sectors. A
major goal is accession to the EU, possibly by 2004. The economy is
greatly influenced by developments in Finland, Sweden, and Germany,
three major trading partners. The high current account deficit
remains a concern.
gas 859 km (2003)','c21b49cafdac604e64f65bc28285b2dd52488073963ea119816030d9a527c586','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7ae1496b3342b38ca54f3a120274c57450ea5895961d313c491521ccbdd7883',2003,'ET','Ethiopia','economy',684,'total: 14
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2002)
Falkland Islands (Islas Malvinas)
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2002)
total: 69
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 10
914 to 1,523 m: 32
under 914 m: 21 (2002)
Europa Island
total: 1
914 to 1,523 m: 1 (2002)
Falkland Islands (Islas Malvinas)
total: 3
under 914 m: 3 (2002)
deforestation; overgrazing; soil erosion; desertification;
water shortages in some areas from water-intensive farming and poor
management
Europa Island
NA
Falkland Islands (Islas Malvinas)
overfishing by unlicensed vessels
is a problem; reindeer were introduced to the islands in 2001 for
commercial reasons; this is the only commercial reindeer herd in the
world unaffected by the Chornobyl disaster
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Environmental Modification, Law of the
Sea, Nuclear Test Ban
12.6% (FY00)
Falkland Islands (Islas Malvinas)
NA%
1.713 billion kWh (2001)
Falkland Islands (Islas Malvinas)
16.33 million kWh (2001)
1.594 billion kWh (2001)
Falkland Islands (Islas Malvinas)
15.19 million kWh (2001)
0 kWh (2001)
Falkland Islands (Islas Malvinas)
0 kWh (2001)
0 kWh (2001)
Falkland Islands (Islas Malvinas)
0 kWh (2001)
fossil fuel: 1.3%
hydro: 97.6%
nuclear: 0%
other: 1.2% (2001)
Falkland Islands (Islas Malvinas)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
45% (2002 est.)
Falkland Islands (Islas Malvinas)
NA%
lowest 10%: 3%
highest 10%: 33.7% (1995)
Falkland Islands (Islas Malvinas)
lowest 10%: NA%
highest 10%: NA%
agriculture and animal husbandry 80%, government and
services 12%, industry and construction 8% (1985)
Falkland Islands (Islas Malvinas)
agriculture 95% (mostly
sheepherding and fishing)
coffee, qat, gold, leather products, live animals, oilseeds
Falkland Islands (Islas Malvinas)
wool, hides, meat
UK 16.2%, Djibouti 10.9%, Germany 7.6%, Italy 7.2%, Japan
6.7%, Saudi Arabia 6.5%, US 4.4% (2002)
Falkland Islands (Islas Malvinas)
Spain 76.2%, UK 9.2%, US 7.1%
(2002)
9 ethnically-based states (kililoch, singular - kilil) and
2 self-governing administrations* (astedaderoch, singular -
astedader); Adis Abeba* (Addis Ababa), Afar, Amara (Amhara),
Binshangul Gumuz, Dire Dawa*, Gambela Hizboch (Gambela Peoples),
Hareri Hizb (Harari People), Oromiya (Oromia), Sumale (Somali),
Tigray, Ye Debub Biheroch Bihereseboch na Hizboch (Southern Nations,
Nationalities and Peoples)
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)
cereals, pulses, coffee, oilseed, sugarcane, potatoes, qat;
hides, cattle, sheep, goats
Falkland Islands (Islas Malvinas)
fodder and vegetable crops; sheep,
dairy products
83 (2002)
Europa Island
1 (2002)
Falkland Islands (Islas Malvinas)
5 (2002)
39.81 births/1,000 population (2003 est.)
Falkland Islands (Islas Malvinas)
NA births/1,000 population
Ethiopian National Defense Force (Ground Forces, Air Force,
militia, police)
note: Ethiopia is landlocked and has no navy; following the
secession of Eritrea, Ethiopian naval facilities remained in
Eritrean possession
Falkland Islands (Islas Malvinas)
British Forces Falkland Islands no
regular indigenous military forces; (includes Army, Royal Air Force,
and Royal Navy), Police Force
revenues: $1.8 billion
expenditures: $1.9 billion, including capital expenditures of $600
million (2002 est.)
Falkland Islands (Islas Malvinas)
revenues: $66.2 million
expenditures: $67.9 million, including capital expenditures of $23.2
million (FY98/99 est.)
Ethiopia''s poverty-stricken economy is based on
agriculture, which accounts for half of GDP, 85% of exports, and 80%
of total employment. The agricultural sector suffers from frequent
drought and poor cultivation practices. Coffee is critical to the
Ethiopian economy with exports of some $270 million in 2000/01, but
historically low prices have seen many farmers switching to qat to
supplement their income. The war with Eritrea in 1999-2000 and
recurrent drought have buffeted the economy, in particular coffee
production. In November 2001 Ethiopia qualified for debt relief from
the Highly Indebted Poor Countries (HIPC) initiative. Under
Ethiopia''s land tenure system, the government owns all land and
provides long-term leases to the tenants; the system continues to
hamper growth in the industrial sector as entrepreneurs are unable
to use land as collateral for loans. Strong growth in 2002 resulted
from good rainfall early in the year, the cessation of hostilities,
and renewed foreign aid and debt relief. But drought struck again
late in 2002, and the World Food Program (WFP) estimates 14 million
Ethiopians need food immediately to survive into 2003. The
government estimates than annual growth of 7% is needed to reduce
poverty, yet the maintenance of 5% in 2003 will be quite difficult
(one estimate is for 1.5% growth).
Europa Island
no economic activity
Falkland Islands (Islas Malvinas)
The economy was formerly based on
agriculture, mainly sheep farming, but today fishing contributes the
bulk of economic activity. In 1987 the government began selling
fishing licenses to foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees total more than $40
million per year, which goes to support the island''s health,
education, and welfare system. Squid accounts for 75% of the fish
taken. Dairy farming supports domestic consumption; crops furnish
winter fodder. Exports feature shipments of high-grade wool to the
UK and the sale of postage stamps and coins. The islands are now
self-financing except for defense. The British Geological Survey
announced a 200-mile oil exploration zone around the islands in
1993, and early seismic surveys suggest substantial reserves capable
of producing 500,000 barrels per day; to date no exploitable site
has been identified. An agreement between Argentina and the UK in
1995 seeks to defuse licensing and sovereignty conflicts that would
dampen foreign interest in exploiting potential oil reserves.
Tourism, especially eco-tourism, is increasing rapidly, with about
30,000 visitors in 2001. Another large source of income is interest
paid on money the government has in the bank. The British military
presence also provides a sizeable economic boost.','fe8763d310ed4aa6cffe58fc3cba992a60a86a76181a65304b201d303f0d5db3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fefba2ff8c015088d28e08ae0207e45059c60a4252b53871a9f55656f77c6cb',2003,'FO','Faroe Islands','economy',685,'total: 1
914 to 1,523 m: 1 (2002)
NA
NA%
160.4 million kWh (2001)
149.1 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 62.4%
hydro: 37.6%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
fishing, fish processing, and manufacturing 33%,
construction and private services 33%, public services 34%
fish and fish products 94%, stamps, ships (1999)
Denmark 39.9%, UK 32.1%, Norway 7.4%, Netherlands 6.1%
(2002)
none (part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark); there are no
first-order administrative divisions as defined by the US
Government, but there are 49 municipalities
milk, potatoes, vegetables; sheep; salmon, other fish
1 (2002)
13.81 births/1,000 population (2003 est.)
no regular indigenous military forces; small Police
Force and Coast Guard are maintained
revenues: $488 million
expenditures: $484 million, including capital expenditures of $21
million (1999)
The Faroese economy has had a strong performance since
1994, mostly as a result of increasing fish landings and high and
stable export prices. Unemployment is falling and there are signs of
labor shortages in several sectors. The positive economic
development has helped the Faroese Home Rule Government produce
increasing budget surpluses, which in turn help to reduce the large
public debt, most of it owed to Denmark. However, the total
dependence on fishing makes the Faroese economy extremely
vulnerable, and the present fishing efforts appear in excess of what
is a sustainable level of fishing in the long term. Oil finds close
to the Faroese area give hope for deposits in the immediate Faroese
area, which may eventually lay the basis for a more diversified
economy and thus lessen dependence on Danish economic assistance.
Aided by a substantial annual subsidy (15% of GDP) from Denmark, the
Faroese have a standard of living not far below the Danes and other
Scandinavians.','6d97fc8ce6364bbf3b2465e972a0dbb7c5ad364475d5b2c885f3903a2484de69','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b10c57bbca3a5d30c16eb1ff61eb3b8c345d48c59273a89224b5304ebcd7966',2003,'FJ','Fiji','economy',686,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
total: 24
914 to 1,523 m: 6
under 914 m: 18 (2002)
deforestation; soil erosion
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
2.2% (FY02)
520.1 million kWh (2001)
483.7 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 18.5%
hydro: 81.5%
nuclear: 0%
other: 0% (2001)
25.5% (1990-91)
lowest 10%: NA%
highest 10%: NA%
agriculture, including subsistence agriculture 70% (2001 est.)
sugar, garments, gold, timber, fish, molasses, coconut oil
US 25.1%, Australia 19.5%, UK 10.6%, Japan 6.3%, Samoa 5.5%
(2002)
4 divisions and 1 dependency*; Central, Eastern, Northern,
Rotuma*, Western
sugarcane, coconuts, cassava (tapioca), rice, sweet potatoes,
bananas; cattle, pigs, horses, goats; fish
27 (2002)
23.06 births/1,000 population (2003 est.)
Republic of Fiji Military Forces (RFMF), includes ground
forces, naval division
revenues: $427.9 million
expenditures: $531.4 million, including capital expenditures of $NA
(2000 est.)
Fiji, endowed with forest, mineral, and fish resources, is one
of the most developed of the Pacific island economies, though still
with a large subsistence sector. Sugar exports and a growing tourist
industry - with 300,000 to 400,000 tourists annually - are the major
sources of foreign exchange. Sugar processing makes up one-third of
industrial activity. Long-term problems include low investment,
uncertain land ownership rights, and the government''s ability to
manage its budget.','e92244df22bae62c554dd1ff3dddb9fcc2ad9081337831ac893240cbe114e14e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec49beaaf2cdf44f924610efa273d2b9a6223d2eaea2450c7aea28bd78f1694',2003,'FI','Finland','economy',687,'total: 74
over 3,047 m: 2
2,438 to 3,047 m: 27
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 12 (2002)
total: 76
914 to 1,523 m: 4
under 914 m: 72 (2002)
air pollution from manufacturing and power plants
contributing to acid rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife populations
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
2% (FY98/99)
71.2 billion kWh (2001)
76.18 billion kWh (2001)
11.77 billion kWh (2001)
1.81 billion kWh (2001)
fossil fuel: 39%
hydro: 18.7%
nuclear: 30.4%
other: 11.8% (2001)
NA%
lowest 10%: 4.2%
highest 10%: 21.6% (1991)
public services 32%, industry 22%, commerce 14%, finance,
insurance, and business services 10%, agriculture and forestry 8%,
transport and communications 8%, construction 6%
machinery and equipment, chemicals, metals; timber, paper,
pulp (1999)
Germany 11.8%, UK 9.6%, US 9%, Sweden 8.5%, Russia 6.6%,
Netherlands 4.6%, France 4.5% (2002)
6 provinces (laanit, singular - laani); Aland, Etela-Suomen
Laani, Ita-Suomen Laani, Lansi-Suomen Laani, Lappi, Oulun Laani
barley, wheat, sugar beets, potatoes; dairy cattle; fish
150 (2002)
10.54 births/1,000 population (2003 est.)
Army, Navy, Air Force, Frontier Guard (including Sea Guard)
revenues: $36.1 billion
expenditures: $31 billion, including capital expenditures of $NA
(2000 est.)
Finland has a highly industrialized, largely free-market
economy, with per capita output roughly that of the UK, France,
Germany, and Italy. Its key economic sector is manufacturing -
principally the wood, metals, engineering, telecommunications, and
electronics industries. Trade is important, with exports equaling
almost one-third of GDP. Except for timber and several minerals,
Finland depends on imports of raw materials, energy, and some
components for manufactured goods. Because of the climate,
agricultural development is limited to maintaining self-sufficiency
in basic products. Forestry, an important export earner, provides a
secondary occupation for the rural population. Rapidly increasing
integration with Western Europe - Finland was one of the 11
countries joining the European Economic and Monetary Union (EMU) on
1 January 1999 - will dominate the economic picture over the next
several years. Growth in 2003 was held back by the global slowdown
but will pick up in 2004 provided the world economy suffers no
further blows.
gas 694 km (2003)','49bb921cecc3f80913bfc53292a0aad580a7c23d961f630df16976f33b887a85','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a050415c176c72b1a2f36bd8e346e4ddc875f9f7e6ccd44ad4f0f81ab90140a',2003,'FR','France','economy',688,'total: 273
over 3,047 m: 13
2,438 to 3,047 m: 28
1,524 to 2,437 m: 95
914 to 1,523 m: 80
under 914 m: 57 (2002)
total: 204
1,524 to 2,437 m: 2
914 to 1,523 m: 74
under 914 m: 128 (2002)
some forest damage from acid rain (major forest damage
occurred as a result of severe December 1999 windstorm); air
pollution from industrial and vehicle emissions; water pollution
from urban wastes, agricultural runoff
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Kyoto Protocol, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
2.57% (2002)
520.1 billion kWh (2001)
415.3 billion kWh (2001)
4.2 billion kWh (2001)
72.6 billion kWh (2001)
fossil fuel: 8.2%
hydro: 14%
nuclear: 77.1%
other: 0.7% (2001)
6.4% (1999)
lowest 10%: 2.8%
highest 10%: 25.1% (1995)
services 71%, industry 25%, agriculture 4% (1997)
machinery and transportation equipment, aircraft, plastics,
chemicals, pharmaceutical products, iron and steel, beverages
Germany 15%, UK 9.8%, Spain 9%, Italy 9%, US 7.8%, Belgium
6.9% (2002)
22 regions (regions, singular - region); Alsace, Aquitaine,
Auvergne, Basse-Normandie, Bourgogne, Bretagne, Centre,
Champagne-Ardenne, Corse, Franche-Comte, Haute-Normandie,
Ile-de-France, Languedoc-Roussillon, Limousin, Lorraine,
Midi-Pyrenees, Nord-Pas-de-Calais, Pays de la Loire, Picardie,
Poitou-Charentes, Provence-Alpes-Cote d''Azur, Rhone-Alpes
note: metropolitan France is divided into 22 regions (including the
"territorial collectivity" of Corse or Corsica) and is subdivided
into 96 departments; see separate entries for the overseas
departments (French Guiana, Guadeloupe, Martinique, Reunion) and the
overseas territorial collectivities (Mayotte, Saint Pierre and
Miquelon)
wheat, cereals, sugar beets, potatoes, wine grapes; beef,
dairy products; fish
477 (2002)
12.54 births/1,000 population (2003 est.)
Army (includes marines), Navy (includes naval air), Air Force
(includes Air Defense), National Gendarmerie
revenues: $286 billion
expenditures: $330 billion, including capital expenditures of $23
billion (2002 est.)
France is in the midst of transition, from a well-to-do
modern economy that has featured extensive government ownership and
intervention to one that relies more on market mechanisms. The
Socialist-led government has partially or fully privatized many
large companies, banks, and insurers, but still retains controlling
stakes in several leading firms, including Air France, France
Telecom, Renault, and Thales, and remains dominant in some sectors,
particularly power, public transport, and defense industries. The
telecommunications sector is gradually being opened to competition.
France''s leaders remain committed to a capitalism in which they
maintain social equity by means of laws, tax policies, and social
spending that reduce income disparity and the impact of free markets
on public health and welfare. The current government has lowered
income taxes and introduced measures to boost employment. At the end
of 2002 the government was focusing on the problems of the high cost
of labor and labor market inflexibility resulting from the 35-hour
workweek and restrictions on lay-offs. The government was also
pushing for pension reforms and simplification of administrative
procedures. The tax burden remains one of the highest in Europe. The
current economic slowdown and inflexible budget items have pushed
the deficit above the EU''s 3% debt limit. Business investment
remains listless because of low rates of capital utilization, high
debt, and the steep cost of capital.
gas 13,946 km; oil 3,024 km; refined products 4,889 km (2003)','6a93243b39b59ce63292f85df36add04df1966638dce7f258e48eee35f641821','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f7a9863af53f772b4bea7a70deb739ab2bcdf6082fbaecb315ae1818521a003',2003,'GF','French Guiana','economy',689,'total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2002)
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2002)
NA
NA%
455 million kWh (2001)
423.2 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
services, government, and commerce 60.6%, industry
21.2%, agriculture 18.2% (1980)
shrimp, timber, gold, rum, rosewood essence, clothing
France 62%, Switzerland 7%, US 2% (2001)
none (overseas department of France)
corn, rice, manioc (tapioca), sugar, cocoa,
vegetables, bananas; cattle, pigs, poultry
11 (2002)
21.33 births/1,000 population (2003 est.)
no regular indigenous military forces; French Forces,
Gendarmerie
revenues: $225 million
expenditures: $390 million, including capital expenditures of $105
million (1996)
The economy is tied closely to the larger French
economy through subsidies and imports. Besides the French space
center at Kourou (which accounts for 25% of GDP), fishing and
forestry are the most important economic activities. Forest and
woodland cover 90% of the country. The large reserves of tropical
hardwoods, not fully exploited, support an expanding sawmill
industry that provides sawn logs for export. Cultivation of crops is
limited to the coastal area, where the population is largely
concentrated; rice and manioc are the major crops. French Guiana is
heavily dependent on imports of food and energy. Unemployment is a
serious problem, particularly among younger workers.','8c39fb4286203fe0615a742bdca49329b0e6e149940b277248c19e27bc454055','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a7d8b20c9ea74d8608de2b167918dbc2420e23fe193e8be8a5eb71e4d08ddc',2003,'PF','French Polynesia','economy',690,'total: 37
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 22
under 914 m: 8 (2002)
total: 8
914 to 1,523 m: 3
under 914 m: 5 (2002)
NA
French Southern and Antarctic Lands
NA
428.3 million kWh (2001)
398.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 60.7%
hydro: 39.3%
nuclear: 0%
other: 0%; note - sun, wind, biomass (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 13%, industry 19%, services 68% (1997)
cultured pearls 50%, coconut products,
mother-of-pearl, vanilla, shark meat (1997)
France 37.4%, Japan 35.5%, US 17.5% (2002)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 5 archipelagic divisions named Archipel
des Marquises, Archipel des Tuamotu, Archipel des Tubuai, Iles du
Vent, and Iles Sous-le-Vent
note: Clipperton Island is administered by France from French
Polynesia
French Southern and Antarctic Lands
none (overseas territory of
France); there are no first-order administrative divisions as
defined by the US Government, but there are 3 districts named Ile
Crozet, Iles Kerguelen, and Iles Saint-Paul et Amsterdam; excludes
"Adelie Land" claim in Antarctica that is not recognized by the US
coconuts, vanilla, vegetables, fruits; poultry,
beef, dairy products, coffee
45 (2002)
French Southern and Antarctic Lands
none (2002)
17.74 births/1,000 population (2003 est.)
no regular indigenous military forces; French
Forces (including Army, Navy, Air Force), Gendarmerie
revenues: $1 billion
expenditures: $900 million, including capital expenditures of $185
million (1996)
Since 1962, when France stationed military
personnel in the region, French Polynesia has changed from a
subsistence agricultural economy to one in which a high proportion
of the work force is either employed by the military or supports the
tourist industry. With the halt of French nuclear testing in 1996,
the military contribution to the economy fell sharply. Tourism
accounts for about one-fourth of GDP and is a primary source of hard
currency earnings. Other sources of income are pearl farming and
deep-sea commercial fishing. The small manufacturing sector
primarily processes agricultural products. The territory benefits
substantially from development agreements with France aimed
principally at creating new businesses and strengthening social
services.
French Southern and Antarctic Lands
Economic activity is limited to
servicing meteorological and geophysical research stations and
French and other fishing fleets. The fish catches landed on Iles
Kerguelen by foreign ships are exported to France and Reunion.','640d77f07d519fa2016eb8f1512613f002b0d0b8b37e1428516acc91bbbc5922','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6048147c883555c324ac4f9130753ce8ed6d8c4a1cf2095e1cca2ccc05f7486',2003,'GA','Gabon','economy',691,'total: 10
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2002)
Gambia, The
total: 1
over 3,047 m: 1 (2002)
Gaza Strip
total: 1
over 3,047 m: 1 (2002)
total: 47
1,524 to 2,437 m: 8
914 to 1,523 m: 15
under 914 m: 24 (2002)
Gaza Strip
total: 1
under 914 m: 1 (2002)
deforestation; poaching
Gambia, The
deforestation; desertification; water-borne diseases
prevalent
Gaza Strip
desertification; salination of fresh water; sewage
treatment; water-borne disease; soil degradation; depletion and
contamination of underground water resources
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Gambia, The
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2% (FY02)
Gambia, The
0.3% (FY02)
Gaza Strip
NA%
798.4 million kWh (2001)
Gambia, The
85.33 million kWh (2001)
Gaza Strip
NA kWh; note - electricity supplied by Israel
742.5 million kWh (2001)
Gambia, The
79.36 million kWh (2001)
Gaza Strip
NA kWh
0 kWh (2001)
Gambia, The
0 kWh (2001)
Gaza Strip
NA kWh; note - electricity supplied by Israel (2001)
0 kWh (2001)
Gambia, The
0 kWh (2001)
Gaza Strip
0 kWh (2001)
fossil fuel: 34.5%
hydro: 65.5%
nuclear: 0%
other: 0% (2001)
Gambia, The
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
Gambia, The
NA%
Gaza Strip
60% (2002 est.)
lowest 10%: NA%
highest 10%: NA%
Gambia, The
lowest 10%: NA%
highest 10%: NA%
Gaza Strip
lowest 10%: NA%
highest 10%: NA%
agriculture 60%, services 25%, industry 15%
Gambia, The
agriculture 75%, industry, commerce, and services 19%,
government 6%
Gaza Strip
services 66%, industry 21%, agriculture 13% (1996)
crude oil 77%, timber, manganese, uranium (2001)
Gambia, The
peanut products, fish, cotton lint, palm kernels,
re-exports
Gaza Strip
citrus, flowers
US 46.5%, France 11.6%, China 6.5%, Netherlands Antilles 5.8%
(2002)
Gambia, The
France 21.9%, UK 19.1%, Malaysia 11.8%, Italy 11.1%,
Germany 7.3%, Belgium 6.3%, South Africa 4.2% (2002)
Gaza Strip
Israel, Egypt, West Bank
9 provinces; Estuaire, Haut-Ogooue, Moyen-Ogooue, Ngounie,
Nyanga, Ogooue-Ivindo, Ogooue-Lolo, Ogooue-Maritime, Woleu-Ntem
Gambia, The
5 divisions and 1 city*; Banjul*, Central River, Lower
River, North Bank, Upper River, Western
cocoa, coffee, sugar, palm oil, rubber; cattle; okoume (a
tropical softwood); fish
Gambia, The
rice, millet, sorghum, peanuts, corn, sesame, cassava
(tapioca), palm kernels; cattle, sheep, goats
Gaza Strip
olives, citrus, vegetables; beef, dairy products
57 (2002)
Gambia, The
1 (2002)
Gaza Strip
2 (2001)
note: includes Gaza International Airport (GIA), inaugurated on 24
November 1998 as part of agreements stipulated in the September 1995
Oslo II Accord and the 23 October 1998 Wye River Memorandum; GIA has
been largely closed since October 2000 by Israeli orders and its
runway was destroyed by the Israeli Defense Forces in December 2001
(2002)
36.54 births/1,000 population (2003 est.)
Gambia, The
40.77 births/1,000 population (2003 est.)
Gaza Strip
41.23 births/1,000 population (2003 est.)
Army, Navy, Air Force, Presidential (Republican) Guard
(charged with protecting the president and other senior officials),
National Gendarmerie, National Police
Gambia, The
Gambian National Army (GNA) (includes marine unit),
National Police, Presidential Guard
Gaza Strip
in accordance with the peace agreement, the Palestinian
Authority is not permitted conventional military forces; there are,
however, a Public Security Force and a civil Police Force
revenues: $1.8 billion
expenditures: $1.8 billion, including capital expenditures of $310
million (2002 est.)
Gambia, The
revenues: $90.5 million
expenditures: $80.9 million, including capital expenditures of $4.1
million (2001 est.)
Gaza Strip
revenues: $930 million
expenditures: $1.2 billion, including capital expenditures of $15
million (includes West Bank) (2000 est.)
Gabon enjoys a per capita income four times that of most
nations of sub-Saharan Africa. This has supported a sharp decline in
extreme poverty; yet because of high income inequality a large
proportion of the population remains poor. Gabon depended on timber
and manganese until oil was discovered offshore in the early 1970s.
The oil sector now accounts for 50% of GDP. Gabon continues to face
fluctuating prices for its oil, timber, and manganese exports.
Despite the abundance of natural wealth, poor fiscal management
hobbles the economy. Devaluation of its Francophone currency by 50%
on 12 January 1994 sparked a one-time inflationary surge, to 35%;
the rate dropped to 6% in 1996. The IMF provided a one-year standby
arrangement in 1994-95, a three-year Enhanced Financing Facility
(EFF) at near commercial rates beginning in late 1995, and stand-by
credit of $119 million in October 2000. Those agreements mandate
progress in privatization and fiscal discipline. France provided
additional financial support in January 1997 after Gabon had met IMF
targets for mid-1996. In 1997, an IMF mission to Gabon criticized
the government for overspending on off-budget items, overborrowing
from the central bank, and slipping on its schedule for
privatization and administrative reform. The rebound of oil prices
in 1999-2000 helped growth, but drops in production hampered Gabon
from fully realizing potential gains. In December 2000, Gabon signed
a new agreement with the Paris Club to reschedule its official debt.
A follow-up bilateral repayment agreement with the US was signed in
December 2001. Short-term progress depends on an upbeat world
economy and fiscal and other adjustments in line with IMF policies.
Gambia, The
The Gambia has no important mineral or other natural
resources and has a limited agricultural base. About 75% of the
population depends on crops and livestock for its livelihood.
Small-scale manufacturing activity features the processing of
peanuts, fish, and hides. Reexport trade normally constitutes a
major segment of economic activity, but a 1999 government-imposed
preshipment inspection plan, and instability of the Gambian dalasi
(currency) have drawn some of the reexport trade away from The
Gambia. The government''s 1998 seizure of the private peanut firm
Alimenta eliminated the largest purchaser of Gambian groundnuts; the
following two marketing seasons have seen substantially lower prices
and sales. A decline in tourism in 2000 has also held back growth.
Unemployment and underemployment rates are extremely high. Shortrun
economic progress remains highly dependent on sustained bilateral
and multilateral aid, on responsible government economic management
as forwarded by IMF technical help and advice, and on expected
growth in the construction sector.
Gaza Strip
Economic output in the Gaza Strip - under the
responsibility of the Palestinian Authority since the Cairo
Agreement of May 1994 - declined by about one-third between 1992 and
1996. The downturn was largely the result of Israeli closure
policies - the imposition of generalized border closures in response
to security incidents in Israel - which disrupted previously
established labor and commodity market relationships between Israel
and the WBGS (West Bank and Gaza Strip). The most serious negative
social effect of this downturn was the emergence of high
unemployment; unemployment in the WBGS during the 1980s was
generally under 5%; by 1995 it had risen to over 20%. Israel''s use
of comprehensive closures decreased during the next few years and,
in 1998, Israel implemented new policies to reduce the impact of
closures and other security procedures on the movement of
Palestinian goods and labor. These changes fueled an almost
three-year-long economic recovery in the West Bank and Gaza Strip;
real GDP grew by 5% in 1998 and 6% in 1999. Recovery was upended in
the last quarter of 2000 with the outbreak of violence, triggering
tight Israeli closures of Palestinian self-rule areas and a severe
disruption of trade and labor movements. In 2001, and even more
severely in 2002, Israeli military measures in Palestinian Authority
areas resulted in the destruction of capital plant and
administrative structure, widespread business closures, and a sharp
drop in GDP. Another major loss has been the decline in income
earned by Palestinian workers in Israel. International aid of $2
billion in 2001-02 to the Gaza Strip and West Bank have prevented
the complete collapse of the economy.
gas 210 km; oil 1,426 km; water 3 km (2003)','af0de1d902f6bbf7923e00c8c111d2614242721165e18b7821aa2a0f3506697d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b97a18700ee1b5fdca86f1cda6d4ba7c0f614f3a978ff50512d4f6d0ae330e0c',2003,'GE','Georgia','economy',692,'total: 22
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 4 (2002)
total: 18
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m: 7 (2002)
air pollution, particularly in Rust''avi; heavy pollution of
Mtkvari River and the Black Sea; inadequate supplies of potable
water; soil pollution from toxic chemicals
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.59% (FY00)
7.27 billion kWh (2001)
7.611 billion kWh (2001)
850 million kWh (2001)
0 kWh (2001)
fossil fuel: 19.7%
hydro: 80.3%
nuclear: 0%
other: 0% (2001)
54% (2001 est.)
lowest 10%: 2.3%
highest 10%: 27.9% (1996)
industry 20%, agriculture 40%, services 40% (1999 est.)
scrap metal, machinery, chemicals; fuel reexports; citrus
fruits, tea, wine
Turkey 23%, Italy 12.1%, Russia 11.4%, Greece 8.5%,
Netherlands 7.5%, Spain 5.9%, Turkmenistan 4.7%, Ukraine 4.3% (2002)
9 regions, (mkharebi, singular - mkhare), 9 cities*
(k''alak''ebi, singular - k''alak''i), and 2 autonomous republics**
(avtomnoy respubliki, singular - avtom respublika); Abkhazia or
Ap''khazet''is Avtonomiuri Respublika** (Sokhumi), Ajaria or Acharis
Avtonomiuri Respublika** (Bat''umi), Chiat''ura*, Gori*, Guria,
Imereti, Kakheti, K''ut''aisi*, Kvemo Kartli, Mtskheta-Mtianeti,
P''ot''i*, Racha-Lechkhumi and Kvemo Svaneti, Rust''avi*, Samegrelo and
Zemo Svaneti, Samtskhe-Javakheti, Shida Kartli, T''bilisi*, Tqibuli*,
Tsqaltubo*, Zugdidi*
note: the administrative centers of the 2 autonomous republics are
shown in parentheses
citrus, grapes, tea, hazlenuts, vegetables; livestock
40 (2002)
11.79 births/1,000 population (2003 est.)
Ground Forces (includes National Guard), combined Air and
Air Defense Forces, Naval Forces, Republic Security and Police
Forces (internal and border troops)
revenues: $499 million
expenditures: $554 million, including capital expenditures of $NA
(2001 est.)
Georgia''s main economic activities include the cultivation
of agricultural products such as citrus fruits, tea, hazelnuts, and
grapes; mining of manganese and copper; and output of a small
industrial sector producing alcoholic and nonalcoholic beverages,
metals, machinery, and chemicals. The country imports the bulk of
its energy needs, including natural gas and oil products. Its only
sizable internal energy resource is hydropower. Despite the severe
damage the economy has suffered due to civil strife, Georgia, with
the help of the IMF and World Bank, has made substantial economic
gains since 1995, achieving positive GDP growth and curtailing
inflation. However, the Georgian Government suffers from limited
resources due to a chronic failure to collect tax revenues. Georgia
also suffers from energy shortages; it privatized the T''bilisi
distribution network in 1998, but collection rates are low, making
the venture unprofitable. The country is pinning its hopes for
long-term growth on its role as a transit state for pipelines and
trade. The start of construction on the Baku-T''bilisi-Ceyhan oil
pipeline and the Baku-T''bilisi-Erzerum gas pipeline will bring
much-needed investment and job opportunities.
gas 1,495 km; oil 1,029 km; refined products 232 km (2003)','70ba48ff69a3b10ef34fd59f0717cd7c58abb2d4e2554a8d99c4a49f7865fdb7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48c135c241f03da887698602e20a601a51dae660ebd7a231ffa7fd75ff7a7866',2003,'DE','Germany','economy',693,'total: 328
over 3,047 m: 11
2,438 to 3,047 m: 54
1,524 to 2,437 m: 63
914 to 1,523 m: 69
under 914 m: 131 (2002)
total: 223
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 31
under 914 m: 189 (2002)
emissions from coal-burning utilities and industries
contribute to air pollution; acid rain, resulting from sulfur
dioxide emissions, is damaging forests; pollution in the Baltic Sea
from raw sewage and industrial effluents from rivers in eastern
Germany; hazardous waste disposal; government established a
mechanism for ending the use of nuclear power over the next 15
years; government working to meet EU commitment to identify nature
preservation areas in line with the EU''s Flora, Fauna, and Habitat
directive
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
1.38% (2002)
544.8 billion kWh (2001)
506.8 billion kWh (2001)
44 billion kWh (2001)
43.9 billion kWh (2001)
fossil fuel: 61.8%
hydro: 4.2%
nuclear: 29.9%
other: 4.1% (2001)
NA%
lowest 10%: 3.6%
highest 10%: 25.1% (1997)
industry 33.4%, agriculture 2.8%, services 63.8% (1999)
machinery, vehicles, chemicals, metals and manufactures,
foodstuffs, textiles
France 10.7%, US 10.3%, UK 8.4%, Italy 7.3%, Netherlands
6.1%, Austria 5.1%, Belgium 4.8%, Spain 4.6%, Switzerland 4.2% (2002)
16 states (Laender, singular - Land); Baden-Wuerttemberg,
Bayern, Berlin, Brandenburg, Bremen, Hamburg, Hessen,
Mecklenburg-Vorpommern, Niedersachsen, Nordrhein-Westfalen,
Rheinland-Pfalz, Saarland, Sachsen, Sachsen-Anhalt,
Schleswig-Holstein, Thueringen
potatoes, wheat, barley, sugar beets, fruit, cabbages;
cattle, pigs, poultry
551 (2002)
8.6 births/1,000 population (2003 est.)
Army, Navy (including naval air arm), Air Force, Medical
Corps, Joint Support Service
revenues: $802 billion
expenditures: $825 billion, including capital expenditures of $NA
(2001 est.)
Germany''s affluent and technologically powerful economy has
turned in a weak performance throughout much of the 1990s and early
2000s. The modernization and integration of the eastern German
economy continues to be a costly long-term problem, with annual
transfers from west to east amounting to roughly $70 billion.
Germany''s ageing population, combined with high unemployment, has
pushed social security outlays to a level exceeding contributions
from workers. Structural rigidities in the labor market - including
strict regulations on laying off workers and the setting of wages on
a national basis - have made unemployment a chronic problem. Growth
in 2002 and 2003 fell short of 1%. Corporate restructuring and
growing capital markets are setting the foundations that could allow
Germany to meet the long-term challenges of European economic
integration and globalization, particularly if labor market
rigidities are further addressed. In the short run, however, the
fall in government revenues and the rise in expenditures have raised
the deficit above the EU''s 3% debt limit.
condensate 325 km; gas 25,289 km; oil 3,743 km; refined
products 3,827 km (2003)','0e525106d38813f74523fbf9070a70c42de19169432707548817104d0b940a04','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12737de47be4590311d537b2c2caee26777f011a8d2bc30d34fbccb7476905ad',2003,'GH','Ghana','economy',694,'total: 7
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2002)
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2002)
Glorioso Islands
total: 1
914 to 1,523 m: 1 (2002)
recurrent drought in north severely affects agricultural
activities; deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations; water pollution;
inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
0.6% (FY02)
8.801 billion kWh (2001)
8.835 billion kWh (2001)
950 million kWh (2001)
300 million kWh (2001)
fossil fuel: 5%
hydro: 95%
nuclear: 0%
other: 0% (2001)
31.4% (1992 est.)
lowest 10%: 2.2%
highest 10%: 30.1% (1999)
agriculture 60%, industry 15%, services 25% (1999 est.)
gold, cocoa, timber, tuna, bauxite, aluminum, manganese ore,
diamonds
Netherlands 14.8%, UK 9.9%, US 7%, Germany 6.6%, France 5.8%,
Nigeria 4.8%, Belgium 4.4%, Italy 4.2% (2002)
10 regions; Ashanti, Brong-Ahafo, Central, Eastern, Greater
Accra, Northern, Upper East, Upper West, Volta, Western
cocoa, rice, coffee, cassava (tapioca), peanuts, corn, shea
nuts, bananas; timber
12 (2002)
25.84 births/1,000 population (2003 est.)
Army, Navy, Air Force, National Police Force
revenues: $1.603 billion
expenditures: $1.975 billion, including capital expenditures of $NA
(2001 est.)
Well endowed with natural resources, Ghana has roughly twice
the per capita output of the poorer countries in West Africa. Even
so, Ghana remains heavily dependent on international financial and
technical assistance. Gold, timber, and cocoa production are major
sources of foreign exchange. The domestic economy continues to
revolve around subsistence agriculture, which accounts for 36% of
GDP and employs 60% of the work force, mainly small landholders.
Ghana opted for debt relief under the Heavily Indebted Poor Country
(HIPC) program in 2002. Policy priorities include tighter monetary
and fiscal policies, accelerated privatization, and improvement of
social services.
refined products 74 km (2003)','391f2a5027ca1e7366216ad18a4bcb07602c9e5ae89c371e5e760579af8e428c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('211a04e3710acbf729087449b1b7ddb5bd86104613a7059da5463752d6d9f9c8',2003,'GI','Gibraltar','economy',695,'total: 1
1,524 to 2,437 m: 1 (2002)
limited natural freshwater resources: large concrete or
natural rock water catchments collect rainwater (no longer used for
drinking water) and adequate desalination plant
Glorioso Islands
NA
100 million kWh (2001)
93 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
services 60%, industry 40%, agriculture NEGL%
(principally reexports) petroleum 51%, manufactured goods
41%, other 8%
UK 27.7%, Switzerland 14.3%, Germany 12%, France 6.9%,
Spain 6.1%, Turkmenistan 5%, Ukraine 4.6% (2002)
none (overseas territory of the UK)
none
1 (2002)
Glorioso Islands
1 (2002)
11.09 births/1,000 population (2003 est.)
no regular indigenous military forces; British Army, Royal
Navy, Royal Air Force
revenues: $307 million
expenditures: $284 million, including capital expenditures of $NA
(FY 00/01 est.)
Gibraltar benefits from an extensive shipping trade,
offshore banking, and its position as an international conference
center. The British military presence has been sharply reduced and
now contributes about 7% to the local economy, compared with 60% in
1984. The financial sector, tourism (almost 5 million visitors in
1998), shipping services fees, and duties on consumer goods also
generate revenue. The financial sector, the shipping sector, and
tourism each contribute 25%-30% of GDP. Telecommunications accounts
for another 10%. In recent years, Gibraltar has seen major
structural change from a public to a private sector economy, but
changes in government spending still have a major impact on the
level of employment.
Glorioso Islands
no economic activity
0 km','92c7aced3b6c440d5098b84d4e81547319ee5507fbb22566e0de2648f2c4b5a9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2825fae64d0f14e950e89c96a7ba35999ae6965359e2320b55fba2a47574028',2003,'GR','Greece','economy',696,'total: 66
over 3,047 m: 6
2,438 to 3,047 m: 15
1,524 to 2,437 m: 19
914 to 1,523 m: 17
under 914 m: 9 (2002)
total: 13
914 to 1,523 m: 3
under 914 m: 10 (2002)
air pollution; water pollution
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Antarctic
Treaty, Climate Change-Kyoto Protocol
4.91% (FY99/00 est.)
49.79 billion kWh (2001)
48.8 billion kWh (2001)
3.562 billion kWh (2001)
1.062 billion kWh (2001)
fossil fuel: 94.5%
hydro: 3.8%
nuclear: 0%
other: 1.7% (2001)
NA%
lowest 10%: 3%
highest 10%: 25.3% (1993 est.)
industry 20%, agriculture 20%, services 59% (2000 est.)
food and beverages, manufactured goods, petroleum products,
chemicals, textiles
Germany 10.4%, Italy 8.5%, UK 6.3%, Bulgaria 5.4%, US 5.3%,
Cyprus 4.7% (2002)
51 prefectures (nomoi, singular - nomos)and 1 autonomous
region*; Agion Oros* (Mt. Athos), Achaia, Aitolia kai Akarmania,
Argolis, Arkadia, Arta, Attiki, Chalkidiki, Chanion, Chios,
Dodekanisos, Drama, Evros, Evrytania, Evvoia, Florina, Fokidos,
Fthiotis, Grevena, Ileia, Imathia, Ioannina, Irakleion, Karditsa,
Kastoria, Kavala, Kefallinia, Kerkyra, Kilkis, Korinthia, Kozani,
Kyklades, Lakonia, Larisa, Lasithi, Lefkas, Lesvos, Magnisia,
Messinia, Pella, Pieria, Preveza, Rethynnis, Rodopi, Samos, Serrai,
Thesprotia, Thessaloniki, Trikala, Voiotia, Xanthi, Zakynthos
wheat, corn, barley, sugar beets, olives, tomatoes, wine,
tobacco, potatoes; beef, dairy products
79 (note - new Athens airport at Spata opened in March 2001)
(2002)
9.79 births/1,000 population (2003 est.)
Hellenic Army, Hellenic Navy, Hellenic Air Force, Police,
National Guard
revenues: $45 billion
expenditures: $47.6 billion, including capital expenditures of $NA
(1998 est.)
Greece has a mixed capitalist economy with the public sector
accounting for half of GDP and with per capita GDP 70% of the
leading euro-zone economies. Tourism provides 15% of GDP. Immigrants
make up nearly one-fifth of the work force, mainly in menial jobs.
Greece is a major beneficiary of EU aid, equal to about 3.3% of GDP.
The economy has improved steadily with economic growth averaging 4%
since 1997, exceeding EU growth by more than 1 percentage point.
Remaining challenges include the reduction of the public debt,
inflation, and unemployment; and further restructuring of the
economy, including privatizing several state enterprises,
undertaking pension and other reforms, and minimizing bureaucratic
inefficiencies. The Olympic Games will be held in Athens in mid-2004.
gas 1,531 km; oil 108 km (2003)','1b55c7fcb9a409a7cdd1a362d296a6e8477fe3676991910b9dad8db101ec7f60','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('461a2d9595d888a6bc49f2a249501fa091c6756964d4c8f65d68e7e8b8c54c6d',2003,'GL','Greenland','economy',697,'total: 9
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 5 (2002)
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2002)
protection of the arctic environment; preservation of the
Inuit traditional way of life, including whaling and seal hunting
245 million kWh (2001)
227.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%
note: Greenland is shifting its electricity production from fossil
fuel to hydropower production (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
fish and fish products 94% (prawns 63%)
Denmark 60.3%, Japan 15.5%, US 6%, Thailand 5%, Germany 4%
(2002)
3 districts (landsdele); Avannaa (Nordgronland), Tunu
(Ostgronland), Kitaa (Vestgronland)
note: there are 18 municipalities in Greenland
forage crops, garden and greenhouse vegetables; sheep,
reindeer; fish
14 (2002)
16.09 births/1,000 population (2003 est.)
revenues: $646 million
expenditures: $629 million, including capital expenditures of $85
million (1999)
The economy remains critically dependent on exports of
fish and substantial support from the Danish Government, which
supplies about half of government revenues. The public sector,
including publicly owned enterprises and the municipalities, plays
the dominant role in the economy. Despite several interesting
hydrocarbon and minerals exploration activities, it will take
several years before production can materialize. Tourism is the only
sector offering any near-term potential, and even this is limited
due to a short season and high costs.','580b4cbb65350aa910d04003f71d108b20804d996c92f26c4bf6c424c7f23543','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07859299273ee52c0608376dc9c32f8582698698c30b9fe06f31f8e7e23b96af',2003,'GD','Grenada','economy',698,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2002)
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
NA%
138 million kWh (2001)
128.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
32% (2000)
lowest 10%: NA%
highest 10%: NA%
services 62%, agriculture 24%, industry 14% (1999 est.)
bananas, cocoa, nutmeg, fruit and vegetables, clothing, mace
Germany 14%, US 13.6%, Bangladesh 9.7%, Netherlands 8.6%,
Saint Lucia 6.4%, Antigua and Barbuda 4.3%, France 4.1% (2002)
6 parishes and 1 dependency*; Carriacou and Petit
Martinique*, Saint Andrew, Saint David, Saint George, Saint John,
Saint Mark, Saint Patrick
bananas, cocoa, nutmeg, mace, citrus, avocados, root crops,
sugarcane, corn, vegetables
3 (2002)
22.87 births/1,000 population (2003 est.)
Royal Grenada Police Force, Coast Guard
revenues: $85.8 million
expenditures: $102.1 million, including capital expenditures of $28
million (1997)
Grenada relies on tourism as its main source of foreign
exchange, especially since the construction of an international
airport in 1985. Strong performances in construction and
manufacturing, together with the development of an offshore
financial industry, have also contributed to growth in national
output.','15d41c012a9af523d1c59399be3d2c3ecc28f1d67bdae497273bbaecbbb455f0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2c575c7c35b93d527ff55bf586ee963220f4fa6cc0511e12bdf2a5757aa8950',2003,'GP','Guadeloupe','economy',699,'total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (2002)
total: 1
under 914 m: 1 (2002)
NA
1.155 billion kWh (2001)
1.074 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
NA
bananas, sugar, rum
France 60%, Martinique 18%, US 4% (1999)
none (overseas department of France)
bananas, sugarcane, tropical fruits and vegetables;
cattle, pigs, goats
9 (2002)
16.16 births/1,000 population (2003 est.)
no regular indigenous military forces; French Forces,
Gendarmerie
revenues: $225 million
expenditures: $390 million, including capital expenditures of $105
million (1996)
The Caribbean economy depends on agriculture, tourism,
light industry, and services. It also depends on France for large
subsidies and imports. Tourism is a key industry, with most tourists
from the US; an increasingly large number of cruise ships visit the
islands. The traditional sugarcane crop is slowly being replaced by
other crops, such as bananas (which now supply about 50% of export
earnings), eggplant, and flowers. Other vegetables and root crops
are cultivated for local consumption, although Guadeloupe is still
dependent on imported food, mainly from France. Light industry
features sugar and rum production. Most manufactured goods and fuel
are imported. Unemployment is especially high among the young.
Hurricanes periodically devastate the economy.','ab1d0281eaef450e57b0c7959e2dd567a150ded2ddf218df0295e90ceaa461eb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20c04a69d1bbc6fffa53d1d626e086d735bf4a713dc5aa99dfe979a2d000f165',2003,'GU','Guam','economy',700,'total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2002)
total: 1
under 914 m: 1 (2002)
extirpation of native bird population by the rapid
proliferation of the brown tree snake, an exotic, invasive species
830 million kWh (2001)
771.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
23% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
federal and territorial government 26%, private 74% (trade 24%,
other services 40%, industry 10%) (2000 est.)
mostly transshipments of refined petroleum products;
construction materials, fish, food and beverage products
Japan 81.7%, South Korea 6.1%, Canada 2.4% (2002)
none (territory of the US)
fruits, copra, vegetables; eggs, pork, poultry, beef
5 (2002)
23.19 births/1,000 population (2003 est.)
revenues: $340 million
expenditures: $445 million, including capital expenditures of $NA
(2000 est.)
The economy depends on US military spending, tourism, and the
export of fish and handicrafts. Total US grants, wage payments, and
procurement outlays amounted to $1 billion in 1998. Over the past 20
years, the tourist industry has grown rapidly, creating a
construction boom for new hotels and the expansion of older ones.
More than 1 million tourists visit Guam each year. The industry has
recently suffered setbacks because of the continuing Japanese
slowdown; the Japanese normally make up almost 90% of the tourists.
Most food and industrial goods are imported. Guam faces the problem
of building up the civilian economic sector to offset the impact of
military downsizing.','a3448963a1d51d73da06a2c9a9a2140a50a11663a651ec3ab6d0e7acbcd2e469','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72486c5047b089714b89c310628ab655c5310ffdfd8e72c2cfcd2fd6936e4cab',2003,'GT','Guatemala','economy',701,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (2002)
total: 455
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 115
under 914 m: 330 (2002)
deforestation in the Peten rainforest; soil erosion; water
pollution
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Antarctic-Environmental Protocol
0.6% (FY99)
6.237 billion kWh (2001)
5.559 billion kWh (2001)
95 million kWh (2001)
336 million kWh (2001)
fossil fuel: 51.9%
hydro: 35.2%
nuclear: 0%
other: 12.9% (2001)
75% (2002 est.)
lowest 10%: 1.6%
highest 10%: 46% (1998)
agriculture 50%, industry 15%, services 35% (1999 est.)
coffee, sugar, bananas, fruits and vegetables, cardamom,
meat, apparel, petroleum, electricity
US 58.7%, El Salvador 9.3%, Nicaragua 3.1% (2002)
22 departments (departamentos, singular - departamento);
Alta Verapaz, Baja Verapaz, Chimaltenango, Chiquimula, El Progreso,
Escuintla, Guatemala, Huehuetenango, Izabal, Jalapa, Jutiapa, Peten,
Quetzaltenango, Quiche, Retalhuleu, Sacatepequez, San Marcos, Santa
Rosa, Solola, Suchitepequez, Totonicapan, Zacapa
sugarcane, corn, bananas, coffee, beans, cardamom; cattle,
sheep, pigs, chickens
466 (2002)
35.05 births/1,000 population (2003 est.)
Army, Navy (includes Marines), Air Force
revenues: $2.3 billion
expenditures: $2.7 billion, including capital expenditures of $750
million (2002 est.)
The agricultural sector accounts for about one-fourth of
GDP, two-thirds of exports, and half of the labor force. Coffee,
sugar, and bananas are the main products. Former President ARZU
(1996-2000) worked to implement a program of economic liberalization
and political modernization. President PORTILLO has continued the
liberalization program but with more sporadic results. The 1996
signing of the peace accords, which ended 36 years of civil war,
removed a major obstacle to foreign investment, but numerous
corruption scandals associated with the PORTILLO administration have
dampened investor confidence. The distribution of income remains
highly unequal, with perhaps 75% of the population below the poverty
line. Ongoing challenges include increasing the government revenues,
negotiating further assistance from international donors, upgrading
both government and private financial operations, and narrowing the
trade deficit. A free trade agreement between the US and Central
American countries promises greater access to US and neighboring
markets.
oil 480 km (2003)','237c4976f5daeab74e2a8f69bb60a160be1dda488a16ee74e2786818b3a011b6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b70b7cb2f38a8c31cb118d7f10be6257748d624bdf2739ed5b06a233b76582cc',2003,'GG','Guernsey','economy',702,'total: 2
914 to 1,523 m: 1
under 914 m: 1 (2002)
NA
NA kWh
NA kWh
0 kWh (2002)
0 kWh (2002)
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0%
NA%
lowest 10%: NA%
highest 10%: NA%
tomatoes, flowers and ferns, sweet peppers, eggplant, other
vegetables
UK (regarded as internal trade)
none (British crown dependency); there are no first-order
administrative divisions as defined by the US Government, but there
are 10 parishes including Saint Peter Port, Saint Sampson, Vale,
Castel, Saint Saviour, Saint Pierre du Bois, Torteval, Forest, Saint
Martin, Saint Andrew
tomatoes, greenhouse flowers, sweet peppers, eggplant,
fruit; Guernsey cattle
2 (2002)
9.43 births/1,000 population (2003 est.)
revenues: $381.3 million
expenditures: $368.8 million, including capital expenditures of $NA
(2000 est.)
Financial services - banking, fund management, insurance,
etc. - account for about 55% of total income in this tiny Channel
Island economy. Tourism, manufacturing, and horticulture, mainly
tomatoes and cut flowers, have been declining. Light tax and death
duties make Guernsey a popular tax haven. The evolving economic
integration of the EU nations is changing the rules of the game
under which Guernsey operates.','354eacece69122c5949dc9da495e831a82f22c18f597f5dfbe83be6234ebb7d0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cfa2fb1311803f42afce39c24ed7d773c16438a2767fbfa505b05a515344c8f',2003,'GN','Guinea','economy',703,'total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2002)
total: 10
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 1 (2002)
deforestation; inadequate supplies of potable water;
desertification; soil contamination and erosion; overfishing,
overpopulation in forest region; poor mining practices have led to
environmental damage
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
3.3% (FY02)
790.6 million kWh (2001)
735.2 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 45.5%
hydro: 54.5%
nuclear: 0%
other: 0% (2001)
40% (1994 est.)
lowest 10%: 2.6%
highest 10%: 32% (1994)
agriculture 80%, industry and services 20% (2000 est.)
bauxite, alumina, gold, diamonds, coffee, fish, agricultural
products
South Korea 17.8%, Spain 10.1%, Cameroon 9.7%, Belgium 9.6%,
US 9.2%, Ireland 8.6%, France 7.1%, Russia 6.8%, Germany 5% (2002)
33 prefectures and 1 special zone (zone special)*; Beyla,
Boffa, Boke, Conakry*, Coyah, Dabola, Dalaba, Dinguiraye, Dubreka,
Faranah, Forecariah, Fria, Gaoual, Gueckedou, Kankan, Kerouane,
Kindia, Kissidougou, Koubia, Koundara, Kouroussa, Labe, Lelouma,
Lola, Macenta, Mali, Mamou, Mandiana, Nzerekore, Pita, Siguiri,
Telimele, Tougue, Yomou
rice, coffee, pineapples, palm kernels, cassava (tapioca),
bananas, sweet potatoes; cattle, sheep, goats; timber
15 (2002)
42.5 births/1,000 population (2003 est.)
Army, Navy, Air Force, Republican Guard, Presidential Guard,
paramilitary National Gendarmerie, National Police Force (Surete
National)
revenues: $395.7 million
expenditures: $472.4 million, including capital expenditures of $NA
million (2000 est.)
Guinea possesses major mineral, hydropower, and agricultural
resources, yet remains an underdeveloped nation. The country
possesses over 30% of the world''s bauxite reserves and is the
second-largest bauxite producer. The mining sector accounted for
about 75% of exports in 1999. Long-run improvements in government
fiscal arrangements, literacy, and the legal framework are needed if
the country is to move out of poverty. The government made
encouraging progress in budget management in 1997-99, and reform
progress was praised in the World Bank/IMF October 2000 assessment.
However, fighting along the Sierra Leonean and Liberian borders has
caused major economic disruptions. In addition to direct defense
costs, the violence has led to a sharp decline in investor
confidence. Foreign mining companies have reduced expatriate staff,
while panic buying has created food shortages and inflation in local
markets. Multilateral aid - including Heavily Indebted Poor
Countries (HIPC) debt relief - and single digit inflation permitted
moderate 3.7% growth in 2002. Growth should strengthen in 2003
because of a slowly improving security situation and increased
investor confidence.','a2ccbf15c9d3a6bbab9d488222253fecfc362af6e8393957c13e3bbc2641f42f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d9ad6805baa917d37c4bcfd43b5ed2bf5c0e75ad30513f7ffce81c292c5ac31',2003,'GW','Guinea-Bissau','economy',704,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
total: 25
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 20 (2002)
deforestation; soil erosion; overgrazing; overfishing
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Wetlands
signed, but not ratified: none of the selected agreements
2.8% (FY02)
55 million kWh (2001)
51.15 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: 0.5%
highest 10%: 42.4% (1991)
agriculture 82% (2000 est.)
cashew nuts, shrimp, peanuts, palm kernels, sawn lumber
India 51.5%, Uruguay 19.5%, Thailand 19.4% (2002)
9 regions (regioes, singular - regiao); Bafata,
Biombo, Bissau, Bolama, Cacheu, Gabu, Oio, Quinara, Tombali; note -
Bolama may have been renamed Bolama/Bijagos
rice, corn, beans, cassava (tapioca), cashew nuts,
peanuts, palm kernels, cotton; timber; fish
28 (2002)
38.41 births/1,000 population (2003 est.)
People''s Revolutionary Armed Force (FARP; includes
Army, Navy, and Air Force), paramilitary force
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
One of the 10 poorest countries in the world,
Guinea-Bissau depends mainly on farming and fishing. Cashew crops
have increased remarkably in recent years, and the country now ranks
sixth in cashew production. Guinea-Bissau exports fish and seafood
along with small amounts of peanuts, palm kernels, and timber. Rice
is the major crop and staple food. However, intermittent fighting
between Senegalese-backed government troops and a military junta
destroyed much of the country''s infrastructure and caused widespread
damage to the economy in 1998; the civil war led to a 28% drop in
GDP that year, with partial recovery in 1999-2002. Before the war,
trade reform and price liberalization were the most successful part
of the country''s structural adjustment program under IMF
sponsorship. The tightening of monetary policy and the development
of the private sector had also begun to reinvigorate the economy.
Because of high costs, the development of petroleum, phosphate, and
other mineral resources is not a near-term prospect. However,
unexploited offshore oil reserves could provide much-needed revenue
in the long run. The inequality of income distribution is one of the
most extreme in the world. The government and international donors
continue to work out plans to forward economic development from a
lamentably low base. Government drift and indecision, however, have
resulted in low growth in 2002 and dim prospects for 2003.','8ad4a6423fffa108bb5cae783d501816d06af8a63b16ff251133993ea76bdbf7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de6167c4aedbe406166c02e3c553b3050d8449d7e2a335c8ab2703f014bf25b9',2003,'GY','Guyana','economy',705,'total: 8
1,524 to 2,437 m: 3
under 914 m: 5 (2002)
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 34 (2002)
water pollution from sewage and agricultural and industrial
chemicals; deforestation
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
NA%
852 million kWh (2001)
792.4 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 99.4%
hydro: 0.6%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
sugar, gold, bauxite/alumina, rice, shrimp, molasses, rum,
timber
Canada 21.1%, US 17.9%, Netherlands Antilles 12.9%, UK 10.4%,
Jamaica 5.3%, Portugal 4.2% (2002)
10 regions; Barima-Waini, Cuyuni-Mazaruni, Demerara-Mahaica,
East Berbice-Corentyne, Essequibo Islands-West Demerara,
Mahaica-Berbice, Pomeroon-Supenaam, Potaro-Siparuni, Upper
Demerara-Berbice, Upper Takutu-Upper Essequibo
sugar, rice, wheat, vegetable oils; beef, pork, poultry,
dairy products; fish (shrimp)
51 (2002)
17.87 births/1,000 population (2003 est.)
Guyana Defense Force (including Ground Forces, Coast Guard,
and Air Corps), Guyana Police Force, Guyana People''s Militia, Guyana
National Service
revenues: $227 million
expenditures: $235.2 million, including capital expenditures of
$93.4 million (2000)
The Guyanese economy has exhibited moderate economic growth
in 2001-02, based on expansion in the agricultural and mining
sectors, a more favorable atmosphere for business initiatives, a
more realistic exchange rate, fairly low inflation, and the
continued support of international organizations. Chronic problems
include a shortage of skilled labor and a deficient infrastructure.
The government is juggling a sizable external debt against the
urgent need for expanded public investment. The bauxite mining
sector should benefit in the near term by restructuring and partial
privatization.','e0b09a55e6e5a2ad9c339aa03084b24ba7bc64c578705a3c3826ebf6c41bcb02','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143944ff72411bbee4c47b0b467782d70e5d5686fb643e17add346b86ebcc11a',2003,'HT','Haiti','economy',706,'total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2002)
total: 10
914 to 1,523 m: 4
under 914 m: 6 (2002)
extensive deforestation (much of the remaining forested land
is being cleared for agriculture and used as fuel); soil erosion;
inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection
signed, but not ratified: Hazardous Wastes, Nuclear Test Ban
Holy See (Vatican City)
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental Modification
1.3% (FY00)
580 million kWh (2001)
Holy See (Vatican City)
NA kWh
539.4 million kWh (2001)
Holy See (Vatican City)
NA kWh
0 kWh (2001)
Holy See (Vatican City)
NA kWh; note - electricity supplied by Italy
0 kWh (2001)
Holy See (Vatican City)
0 kWh
fossil fuel: 60.3%
hydro: 39.7%
nuclear: 0%
other: 0% (2001)
80% (2002 est.)
Holy See (Vatican City)
NA%
lowest 10%: NA%
highest 10%: NA%
Holy See (Vatican City)
lowest 10%: NA%
highest 10%: NA%
agriculture 66%, services 25%, industry 9%
Holy See (Vatican City)
essentially services with a small amount of
industry; note - dignitaries, priests, nuns, guards, and 3,000 lay
workers live outside the Vatican
manufactures, coffee, oils, cocoa
US 83.9%, Dominican Republic 6.6%, Canada 2.4% (2002)
9 departments (departements, singular - departement);
Artibonite, Centre, Grand ''Anse, Nord, Nord-Est, Nord-Ouest, Ouest,
Sud, Sud-Est
Holy See (Vatican City)
none
coffee, mangoes, sugarcane, rice, corn, sorghum; wood
12 (2002)
Holy See (Vatican City)
none (2002)
34.06 births/1,000 population (2003 est.)
Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force have been
demobilized but still exist on paper until or unless they are
constitutionally abolished
Holy See (Vatican City)
Swiss Guards Corps (Corpo della Guardia
Svizzera)
revenues: $273 million
expenditures: $361 million, including capital expenditures of $NA
(FY 00/01 est.)
Holy See (Vatican City)
revenues: $173.5 million
expenditures: $176.6 million, including capital expenditures of $NA
(2001)
About 80% of the population lives in abject poverty. Nearly
70% of all Haitians depend on the agriculture sector, which consists
mainly of small-scale subsistence farming and employs about
two-thirds of the economically active work force. Following
legislative elections in May 2000, fraught with irregularities,
international donors - including the US and EU - suspended almost
all aid to Haiti. The economy shrank an estimated 1.2% in 2001 and
an estimated 0.9% in 2002. The contraction will likely intensify in
2003 unless a political agreement with donors is reached on economic
policy. Suspended aid and loan disbursements totaled more than $500
million at the start of 2003.','31e8ce077a8fdafc27435f38fd5ff6bc2fbab8de273c75ec1cb2d6315f2662ee','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa0078e994c0700c323f5ec0197b8ba6bd02d66659a4150dd53d290d12863b9d',2003,'HN','Honduras','economy',707,'total: 12
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 4 (2002)
total: 103
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 83 (2002)
urban population expanding; deforestation results from
logging and the clearing of land for agricultural purposes; further
land degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as farming of
marginal lands; mining activities polluting Lago de Yojoa (the
country''s largest source of fresh water), as well as several rivers
and streams, with heavy metals
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
0.6% (FY99)
3.778 billion kWh (2001)
3.822 billion kWh (2001)
308 million kWh (2001)
0 kWh (2001)
fossil fuel: 50.2%
hydro: 49.8%
nuclear: 0%
other: 0% (2001)
53% (1993 est.)
lowest 10%: 0.6%
highest 10%: 42.7% (1998)
agriculture 34%, industry 21%, services 45% (2001 est.)
coffee, bananas, shrimp, lobster, meat; zinc, lumber (2000)
US 69.5%, El Salvador 3%, Guatemala 2% (2002)
18 departments (departamentos, singular - departamento);
Atlantida, Choluteca, Colon, Comayagua, Copan, Cortes, El Paraiso,
Francisco Morazan, Gracias a Dios, Intibuca, Islas de la Bahia, La
Paz, Lempira, Ocotepeque, Olancho, Santa Barbara, Valle, Yoro
bananas, coffee, citrus; beef; timber; shrimp
115 (2002)
31.67 births/1,000 population (2003 est.)
Army, Navy (including marines), Air Force
revenues: $607 million
expenditures: $411.9 million, including capital expenditures of $106
million (1999 est.)
Honduras, one of the poorest countries in the Western
Hemisphere with an extraordinarily unequal distribution of income,
is banking on expanded trade privileges under the Enhanced Caribbean
Basin Initiative and on debt relief under the Heavily Indebted Poor
Countries (HIPC) initiative. While the country has met most of its
macroeconomic targets, it failed to meet the IMF''s goals to
liberalize its energy and telecommunications sectors. Growth remains
dependent on the status of the US economy, its major trading
partner, on commodity prices, particularly coffee, and on reduction
of the high crime rate.','5f566ceecf4fca317a288392738e89e97dc7caba2f781fa72af9ba6ea0ae8076','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b546277ad726aec3e166169709a8523fef86fedd96bc54f7609f7b2c025ccf6',2003,'HK','Hong Kong','economy',708,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1523 m: 1 (2002)
air and water pollution from rapid urbanization
Howland Island
no natural fresh water resources
party to: Marine Dumping (associate member), Ship
Pollution (associate member)
NA% (FY02)
30.48 billion kWh (2001)
37.12 billion kWh (2001)
10.36 billion kWh (2001)
1.581 billion kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
wholesale and retail trade, restaurants, and hotels 31%,
financing, insurance, and real estate 13%, community and social
services 12%, manufacturing 6%, transport and communications 6%,
construction 5%, other 25% (2002 est.)
electrical machinery and appliances, textiles, apparel,
footwear, watches and clocks, toys, plastics, precious stones
China 34%, US 19.5%, UK 5.5%, Japan 4.8% (2002)
none (special administrative region of China)
fresh vegetables; poultry, fish, pork
3 (2002)
Howland Island
airstrip constructed in 1937 for scheduled refueling
stop on the round-the-world flight of Amelia EARHART and Fred NOONAN
- they left Lae, New Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable (2002)
10.71 births/1,000 population (2003 est.)
no regular indigenous military forces; Hong Kong garrison
of China''s People''s Liberation Army (PLA) including elements of the
PLA Ground Forces, PLA Navy, and PLA Air Force; these forces are
under the direct leadership of the Central Military Commission in
Beijing and under administrative control of the adjacent Guangzhou
Military Region
revenues: $22.8 billion
expenditures: $30.7 billion, including capital expenditures of $NA
(FY02/03)
Hong Kong has a free market economy highly dependent on
international trade. Natural resources are limited, and food and raw
materials must be imported. Imports and exports, including
reexports, each exceed GDP in dollar value. Even before Hong Kong
reverted to Chinese administration on 1 July 1997 it had extensive
trade and investment ties with China. Hong Kong has been further
integrating its economy with China because China''s growing openness
to the world economy has increased competitive pressure on Hong
Kong''s service industries, and Hong Kong''s re-export business from
China is a major driver of growth. Per capita GDP compares with the
level in the four big economies of Western Europe. GDP growth
averaged a strong 5% in 1989-1997, but Hong Kong suffered two
recessions in the past 6 years because of the Asian financial crisis
in 1998 and the global downturn of 2001-2002. The Severe Acute
Respiratory Syndrome (SARS) outbreak has also battered Hong Kong''s
economy but the resumption of strong growth began in 2003.
Howland Island
no economic activity','9171d082b0350dcead02b9494427e9d35635e3e2c823bbf72970bd0369b23524','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f5fe4368b0fd26fb62e0f90bf4f91975d5338fcb98cec829bc0458b80261c67',2003,'HU','Hungary','economy',709,'total: 17
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 32
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 16
under 914 m: 8 (2002)
the approximation of Hungary''s standards in waste
management, energy efficiency, and air, soil, and water pollution
with environmental requirements for EU accession will require large
investments
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Law of the Sea
1.75% (2002 est.)
34.39 billion kWh (2001)
35.15 billion kWh (2001)
10.43 billion kWh (2001)
7.261 billion kWh (2001)
fossil fuel: 60.1%
hydro: 0.5%
nuclear: 39%
other: 0.3% (2001)
8.6% (1993 est.)
lowest 10%: 4.1%
highest 10%: 20.5% (1998)
services 65%, industry 27%, agriculture 8% (1996)
machinery and equipment 57.6%, other manufactures 31.0%,
food products 7.5%, raw materials 1.9%, fuels and electricity 1.9%
(2001)
Germany 34.3%, Austria 8.5%, Italy 5.5%, France 5.4%, US
4.9%, UK 4.5% (2002)
19 counties (megyek, singular - megye), 20 urban counties*
(singular - megyei varos), and 1 capital city** (fovaros);
Bacs-Kiskun, Baranya, Bekes, Bekescsaba*, Borsod-Abauj-Zemplen,
Budapest**, Csongrad, Debrecen*, Dunaujvaros*, Eger*, Fejer, Gyor*,
Gyor-Moson-Sopron, Hajdu-Bihar, Heves, Hodmezovasarhely*,
Jasz-Nagykun-Szolnok, Kaposvar*, Kecskemet*, Komarom-Esztergom,
Miskolc*, Nagykanizsa*, Nograd, Nyiregyhaza*, Pecs*, Pest, Somogy,
Sopron*, Szabolcs-Szatmar-Bereg, Szeged*, Szekesfehervar*, Szolnok*,
Szombathely*, Tatabanya*, Tolna, Vas, Veszprem, Veszprem*, Zala,
Zalaegerszeg*
wheat, corn, sunflower seed, potatoes, sugar beets; pigs,
cattle, poultry, dairy products
49 (2002)
9.32 births/1,000 population (2003 est.)
Ground Forces, Air Forces
revenues: $13 billion
expenditures: $14.4 billion, including capital expenditures of $NA
(2000 est.)
Hungary has made the transition from a centrally planned to
a market economy, with a per capita income one-half that of the Big
Four European nations. Hungary continues to demonstrate strong
economic growth and to work toward accession to the European Union
in May 2004. The private sector accounts for over 80% of GDP.
Foreign ownership of and investment in Hungarian firms are
widespread, with cumulative foreign direct investment totaling more
than $23 billion since 1989. Hungarian sovereign debt was upgraded
in 2000 to the second-highest rating among all the Central European
transition economies. Inflation has declined substantially, from 14%
in 1998 to 4.7% in 2003; unemployment has persisted around the 6%
level. Germany is by far Hungary''s largest economic partner.
Short-term issues include the reduction of the public sector deficit
to 3% in 2004 and avoiding unjustified increases in wages.
gas 4,397 km; oil 990 km; refined products 335 km (2003)','de900416b3638522c131e0c9854e43cb121cc046750144533de79685a6d18cd2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ce1d095bb2573c283c541dd12a9c230a08e3344448dd4f86fb514ce765b2f78',2003,'IS','Iceland','economy',710,'total: 13
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2002)
total: 73
1,524 to 2,437 m: 3
914 to 1,523 m: 21
under 914 m: 49 (2002)
water pollution from fertilizer runoff; inadequate
wastewater treatment
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Environmental Protection through Criminal Law, Hazardous Wastes,
Kyoto Protocol, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Oil Pollution, Ozone Layer Protection, Persistent Organic
Pollutants, Ship Pollution, Transboundary Air Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Environmental Modification, Marine Life Conservation
7.894 billion kWh (2001)
7.341 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 0.1%
hydro: 82.5%
nuclear: 0%
other: 17.5% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 5.1%, fishing and fish processing 11.8%,
manufacturing 12.9%, construction 10.7%, other services 59.5% (1999)
fish and fish products 70%, animal products, aluminum,
diatomite, ferrosilicon
Germany 18.5%, UK 17.5%, Netherlands 11.4%, US 10.9%, Spain
5.2%, Denmark 4.6%, Portugal 4.3%, Norway 4.2% (2002)
23 counties (syslur, singular - sysla) and 14 independent
towns* (kaupstadhir, singular - kaupstadhur); Akranes*, Akureyri*,
Arnessysla, Austur-Bardhastrandarsysla, Austur-Hunavatnssysla,
Austur-Skaftafellssysla, Borgarfjardharsysla, Dalasysla,
Eyjafjardharsysla, Gullbringusysla, Hafnarfjordhur*, Husavik*,
Isafjordhur*, Keflavik*, Kjosarsysla, Kopavogur*, Myrasysla,
Neskaupstadhur*, Nordhur-Isafjardharsysla, Nordhur-Mulasys-la,
Nordhur-Thingeyjarsysla, Olafsfjordhur*, Rangarvallasysla,
Reykjavik*, Saudharkrokur*, Seydhisfjordhur*, Siglufjordhur*,
Skagafjardharsysla, Snaefellsnes-og Hnappadalssysla, Strandasysla,
Sudhur-Mulasysla, Sudhur-Thingeyjarsysla, Vesttmannaeyjar*,
Vestur-Bardhastrandarsysla, Vestur-Hunavatnssysla,
Vestur-Isafjardharsysla, Vestur-Skaftafellssysla
note: there may be four other counties
potatoes, green vegetables, chicken, pork, mutton; fish
86 (2002)
14.13 births/1,000 population (2003 est.)
no regular armed forces; Police, Coast Guard
revenues: $3.5 billion
expenditures: $3.3 billion, including capital expenditures of $467
million (1999)
Iceland''s Scandinavian-type economy is basically
capitalistic, yet with an extensive welfare system (including
generous housing subsidies), low unemployment, and remarkably even
distribution of income. In the absence of other natural resources
(except for abundant hydrothermal and geothermal power), the economy
depends heavily on the fishing industry, which provides 70% of
export earnings and employs 12% of the work force. The economy
remains sensitive to declining fish stocks as well as to
fluctuations in world prices for its main exports: fish and fish
products, aluminum, and ferrosilicon. Government policies include
reducing the budget and current account deficits, limiting foreign
borrowing, containing inflation, revising agricultural and fishing
policies, diversifying the economy, and privatizing state-owned
industries. The government remains opposed to EU membership,
primarily because of Icelanders'' concern about losing control over
their fishing resources. Iceland''s economy has been diversifying
into manufacturing and service industries in the last decade, and
new developments in software production, biotechnology, and
financial services are taking place. The tourism sector is also
expanding, with the recent trends in ecotourism and whale watching.
Growth had been remarkably steady in 1996-2001 at 3%-5%, but could
not be sustained in 2002 in an environment of global recession.
Growth resumed in 2003, and inflation dropped back from 5% to 2%.','50219a932b104ca4dd9a5db8b2b871810da71ed11492a3971c3f003aa6b98a25','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5da798979f81b764fb7553c0bbfabd60348b846b290954f8b26bb17ddc7e9c',2003,'IN','India','economy',711,'total: 232
over 3,047 m: 14
2,438 to 3,047 m: 47
1,524 to 2,437 m: 78
914 to 1,523 m: 73
under 914 m: 20 (2002)
total: 102
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
914 to 1,523 m: 42
under 914 m: 48 (2002)
deforestation; soil erosion; overgrazing; desertification; air
pollution from industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural pesticides; tap
water is not potable throughout the country; huge and growing
population is overstraining natural resources
Indian Ocean
endangered marine species include the dugong, seals,
turtles, and whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
2.3% (FY02)
533.3 billion kWh (2001)
497.2 billion kWh (2001)
1.54 billion kWh (2001)
321 million kWh (2001)
fossil fuel: 81.7%
hydro: 14.5%
nuclear: 3.4%
other: 0.3% (2001)
25% (2002 est.)
lowest 10%: 3.5%
highest 10%: 33.5% (1997)
agriculture 60%, services 23%, industry 17% (1999)
textile goods, gems and jewelry, engineering goods, chemicals,
leather manufactures
US 22.5%, UK 5.1%, UAE 5.1%, Hong Kong 4.5%, Germany 4.3%,
China 4.1% (2002)
28 states and 7 union territories*; Andaman and Nicobar
Islands*, Andhra Pradesh, Arunachal Pradesh, Assam, Bihar,
Chandigarh*, Chhattisgarh, Dadra and Nagar Haveli*, Daman and Diu*,
Delhi*, Goa, Gujarat, Haryana, Himachal Pradesh, Jammu and Kashmir,
Jharkhand, Karnataka, Kerala, Lakshadweep*, Madhya Pradesh,
Maharashtra, Manipur, Meghalaya, Mizoram, Nagaland, Orissa,
Pondicherry*, Punjab, Rajasthan, Sikkim, Tamil Nadu, Tripura,
Uttaranchal, Uttar Pradesh, West Bengal
rice, wheat, oilseed, cotton, jute, tea, sugarcane, potatoes;
cattle, water buffalo, sheep, goats, poultry; fish
334 (2002)
23.28 births/1,000 population (2003 est.)
Army, Navy (including naval air arm), Air Force, Strategic
Nuclear Command (SNC), Coast Guard, various security or paramilitary
forces (including Border Security Force, Assam Rifles, Rashtriya
Rifles, National Security Guards, Indo-Tibetan Border Police,
Special Frontier Force, Ladakh Scouts, Central Reserve Police Force,
Central Industrial Security Force, Railway Protection Force, Defense
Security Corps, and Indian Reserve Battalions)
revenues: $48.3 billion
expenditures: $78.2 billion, including capital expenditures of $14
(FY01/02 est.)
India''s economy encompasses traditional village farming,
modern agriculture, handicrafts, a wide range of modern industries,
and a multitude of support services. Overpopulation severely
handicaps the economy and about a quarter of the population is too
poor to be able to afford an adequate diet. Government controls have
been reduced on imports and foreign investment, and privatization of
domestic output has proceeded slowly. The economy has posted an
excellent average growth rate of 6% since 1990, reducing poverty by
about 10 percentage points. India has large numbers of well-educated
people skilled in the English language; India is a major exporter of
software services and software workers; the information technology
sector leads the strong growth pattern. The World Bank and others
worry about the continuing public-sector budget deficit, running at
approximately 10% of GDP in 1997-2002. In 2003 the state-owned
Indian Bank substantially reduced non-performing loans, attracted
new customers, and turned a profit. Deep-rooted problems remain,
notably conflicts among political and cultural groups.
Indian Ocean
The Indian Ocean provides major sea routes connecting
the Middle East, Africa, and East Asia with Europe and the Americas.
It carries a particularly heavy traffic of petroleum and petroleum
products from the oilfields of the Persian Gulf and Indonesia. Its
fish are of great and growing importance to the bordering countries
for domestic consumption and export. Fishing fleets from Russia,
Japan, South Korea, and Taiwan also exploit the Indian Ocean, mainly
for shrimp and tuna. Large reserves of hydrocarbons are being tapped
in the offshore areas of Saudi Arabia, Iran, India, and western
Australia. An estimated 40% of the world''s offshore oil production
comes from the Indian Ocean. Beach sands rich in heavy minerals and
offshore placer deposits are actively exploited by bordering
countries, particularly India, South Africa, Indonesia, Sri Lanka,
and Thailand.
gas 5,798 km; liquid petroleum gas 1,195 km; oil 5,613 km;
refined products 5,567 km (2003)','ef262401ef713f7a5ef4e9a03d4ab22efd1dc7ab94a443077c5496cc17fd7d7f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8828749d06ade81d7fd42aa0e710ee5b0a4fff486ad4916caf5049f7e004d673',2003,'ID','Indonesia','economy',712,'total: 153
over 3,047 m: 4
2,438 to 3,047 m: 12
1,524 to 2,437 m: 46
914 to 1,523 m: 48
under 914 m: 43 (2002)
Iran
total: 122
over 3,047 m: 39
2,438 to 3,047 m: 25
1,524 to 2,437 m: 27
914 to 1,523 m: 27
under 914 m: 4 (2002)
total: 478
1,524 to 2,437 m: 3
914 to 1,523 m: 25
under 914 m: 450 (2002)
Iran
total: 187
over 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 138
under 914 m: 39 (2002)
deforestation; water pollution from industrial wastes,
sewage; air pollution in urban areas; smoke and haze from forest
fires
Iran
air pollution, especially in urban areas, from vehicle
emissions, refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution in the
Persian Gulf; wetland losses from drought; soil degradation
(salination); inadequate supplies of potable water; water pollution
from raw sewage and industrial waste; urbanization
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Iran
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Environmental Modification, Law of the
Sea, Marine Life Conservation
1.3% (FY98)
Iran
3.1% (FY00)
95.78 billion kWh (2001)
Iran
124.6 billion kWh (2001)
89.08 billion kWh (2001)
Iran
115.9 billion kWh (2001)
0 kWh (2001)
Iran
0 kWh (2001)
0 kWh (2001)
Iran
0 kWh (2001)
fossil fuel: 86.9%
hydro: 10.5%
nuclear: 0%
other: 2.5% (2001)
Iran
fossil fuel: 97.1%
hydro: 2.9%
nuclear: 0%
other: 0% (2001)
27% (1999)
Iran
40% (2002 est.)
lowest 10%: 4%
highest 10%: 26.7% (1999)
Iran
lowest 10%: NA%
highest 10%: NA%
agriculture 45%, industry 16%, services 39% (1999 est.)
Iran
agriculture 30%, industry 25%, services 45% (2001 est.)
oil and gas, electrical appliances, plywood, textiles,
rubber
Iran
petroleum 85%, carpets, fruits and nuts, iron and steel,
chemicals
Japan 21.1%, US 13.2%, Singapore 9.4%, South Korea 7.2%,
China 5.1%, Taiwan 4.2% (2002)
Iran
Japan 17.4%, China 8.6%, UAE 7.6%, Italy 6.6%, South Korea
4.9%, South Africa 4.4% (2002)
27 provinces (propinsi-propinsi, singular - propinsi), 2
special regions* (daerah-daerah istimewa, singular - daerah
istimewa), and 1 special capital city district** (daerah khusus
ibukota); Aceh*, Bali, Banten, Bengkulu, Gorontalo, Jakarta Raya**,
Jambi, Jawa Barat, Jawa Tengah, Jawa Timur, Kalimantan Barat,
Kalimantan Selatan, Kalimantan Tengah, Kalimantan Timur, Kepulauan
Bangka Belitung, Lampung, Maluku, Maluku Utara, Nusa Tenggara Barat,
Nusa Tenggara Timur, Papua, Riau, Sulawesi Selatan, Sulawesi Tengah,
Sulawesi Tenggara, Sulawesi Utara, Sumatera Barat, Sumatera Selatan,
Sumatera Utara, Yogyakarta*; note - with the implementation of
decentralization on 1 January 2001, the 357 districts (regencies)
have become the key administrative units responsible for providing
most government services
note: following the 30 August 1999 provincial referendum for
independence that was overwhelmingly approved by the people of Timor
Timur and the October 1999 concurrence of Indonesia''s national
legislature, the name East Timor was adopted as the provisional name
for the political entity formerly known as Propinsi Timor Timur;
East Timor gained its formal independence on 20 May 2002
Iran
28 provinces (ostanha, singular - ostan); Ardabil, Azarbayjan-e
Gharbi, Azarbayjan-e Sharqi, Bushehr, Chahar Mahall va Bakhtiari,
Esfahan, Fars, Gilan, Golestan, Hamadan, Hormozgan, Ilam, Kerman,
Kermanshah, Khorasan, Khuzestan, Kohkiluyeh va Buyer Ahmad,
Kordestan, Lorestan, Markazi, Mazandaran, Qazvin, Qom, Semnan,
Sistan va Baluchestan, Tehran, Yazd, Zanjan
rice, cassava (tapioca), peanuts, rubber, cocoa, coffee,
palm oil, copra; poultry, beef, pork, eggs
Iran
wheat, rice, other grains, sugar beets, fruits, nuts, cotton;
dairy products, wool; caviar
631 (2002)
Iran
309 (2002)
21.49 births/1,000 population (2003 est.)
Iran
17.23 births/1,000 population (2003 est.)
Army, Navy (including marines and naval air arm), Air Force
Iran
Islamic Republic of Iran regular forces (includes Ground
Forces, Navy, Air Force and Air Defense Command), Iranian
Revolutionary Guards Corps (IRGC) (includes Ground Forces, Air
Force, Navy, Qods [special operations], and Basij [Popular
Mobilization Army] forces), Law Enforcement Forces
revenues: $26 billion
expenditures: $30 billion, including capital expenditures of $NA
(2000 est.)
Iran
revenues: $29.5 billion
expenditures: $31.6 billion, including capital expenditures of $NA
(2002 est.)
Indonesia, a vast polyglot nation, faces severe economic
development problems stemming from secessionist movements and the
low level of security in the regions; the lack of reliable legal
recourse in contract disputes; corruption; weaknesses in the banking
system; and strained relations with the IMF. Investor confidence
will remain low and few new jobs will be created under these
circumstances. In November 2001, Indonesia agreed with the IMF on a
series of economic reforms in 2002, thus enabling further IMF
disbursements. Negotiations with the IMF and bilateral donors
continued in 2002. Keys to future growth remain internal reform, the
build-up of the confidence of international donors and investors,
and a strong comeback in the global economy.
Iran
Iran''s economy is a mixture of central planning, state
ownership of oil and other large enterprises, village agriculture,
and small-scale private trading and service ventures. President
KHATAMI has continued to follow the market reform plans of former
President RAFSANJANI and has indicated that he will pursue
diversification of Iran''s oil-reliant economy although he has made
little progress toward that goal. Relatively high oil prices in
recent years have enabled Iran to amass some $15 billion in foreign
exchange reserves, but have not solved Iran''s structural economic
problems, including high unemployment and inflation.
condensate 672 km; condensate/gas 125 km; gas 8,183 km;
oil 7,429 km; oil/gas/water 66 km; refined products 1,329 km; water
72 km (2003)
Iran
condensate/gas 212 km; gas 16,998 km; liquid petroleum gas 570
km; oil 8,256 km; refined products 7,808 km (2003)','741c23ce3a8e24fbea021a2734eaaebea742a79233644e3dcdeb2dce4fd543f0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('131ad4f4dc2b7256e634ebd8a25a6f7bfe123fd97747b5bb2bc1fe5720a20214',2003,'IQ','Iraq','economy',713,'total: 77
over 3,047 m: 21
2,438 to 3,047 m: 36
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 9 (2002)
total: 73
over 3,047 m: 5
2,438 to 3,047 m: 5
1,524 to 2,437 m: 24
914 to 1,523 m: 28
under 914 m: 11 (2002)
government water control projects have drained most of the
inhabited marsh areas east of An Nasiriyah by drying up or diverting
the feeder streams and rivers; a once sizable population of Marsh
Arabs, who inhabited these areas for thousands of years, has been
displaced; furthermore, the destruction of the natural habitat poses
serious threats to the area''s wildlife populations; inadequate
supplies of potable water; development of the Tigris and Euphrates
rivers system contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation (salination) and
erosion; desertification
party to: Law of the Sea, Nuclear Test Ban
signed, but not ratified: Environmental Modification
NA%
36.01 billion kWh (2001)
33.49 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 98.4%
hydro: 1.6%
nuclear: 0%
other: 0% (2001)
NA
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
crude oil
US 40.9%, Canada 8.2%, France 8.2%, Jordan 7.5%, Netherlands
6.4%, Italy 5.4%, Morocco 4.7%, Spain 4.4% (2002)
18 governorates (muhafazat, singular - muhafazah); Al Anbar, Al
Basrah, Al Muthanna, Al Qadisiyah, An Najaf, Arbil, As Sulaymaniyah,
At Ta''mim, Babil, Baghdad, Dahuk, Dhi Qar, Diyala, Karbala'', Maysan,
Ninawa, Salah ad Din, Wasit
wheat, barley, rice, vegetables, dates, cotton; cattle, sheep
150 (2002); note - unknown number were damaged during the
March-April 2003 war
33.66 births/1,000 population (2003 est.)
Army, Republican Guard, Navy, Air Force, Air Defense Force,
Border Guard Force, Fedayeen Saddam; note - with the defeat of
Saddam Hussein''s regime in 2003, the data listed in the following
entries for Iraq is invalid, but is retained here for historical
purposes and until replaced by valid information related to the
future Iraqi Government (April 2003)
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Iraq''s economy is dominated by the oil sector, which has
traditionally provided about 95% of foreign exchange earnings. In
the 1980s financial problems caused by massive expenditures in the
eight-year war with Iran and damage to oil export facilities by Iran
led the government to implement austerity measures, borrow heavily,
and later reschedule foreign debt payments; Iraq suffered economic
losses from the war of at least $100 billion. After hostilities
ended in 1988, oil exports gradually increased with the construction
of new pipelines and restoration of damaged facilities. Iraq''s
seizure of Kuwait in August 1990, subsequent international economic
sanctions, and damage from military action by an international
coalition beginning in January 1991 drastically reduced economic
activity. Although government policies supporting large military and
internal security forces and allocating resources to key supporters
of the regime have hurt the economy, implementation of the UN''s
oil-for-food program beginning in December 1996 helped improve
conditions for the average Iraqi citizen. Iraq was allowed to export
limited amounts of oil in exchange for food, medicine, and some
infrastructure spare parts. In December 1999 the UN Security Council
authorized Iraq to export under the program as much oil as required
to meet humanitarian needs. Oil exports have recently been more than
three-quarters prewar level. However, 28% of Iraq''s export revenues
under the program have been deducted to meet UN Compensation Fund
and UN administrative expenses. The drop in GDP in 2001-02 was
largely the result of the global economic slowdown and lower oil
prices. Per capita food imports increased significantly, while
medical supplies and health care services steadily improved. Per
capita output and living standards were still well below the prewar
level, but any estimates have a wide range of error. The military
victory of the US-led coalition in March-April 2003 resulted in the
shutdown of much of the central economic administrative structure
and the loss of a comparatively small amount of capital plant.
gas 1,739 km; oil 5,418 km; refined products 1,343 km (2003)','c96f5c7be552115b81855a3a7d8fdb3fe32e530760dc4b6e50f3cd75c05b7d77','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('818aa380c01c2c45314a905d4d92de5e939256ad310c919e98e431592aa946b7',2003,'IE','Ireland','economy',714,'total: 16
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 6 (2002)
total: 20
914 to 1,523 m: 3
under 914 m: 17 (2002)
water pollution, especially of lakes, from agricultural
runoff
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Endangered Species, Marine Life Conservation
0.9% (FY00/01)
23.53 billion kWh (2001)
21.63 billion kWh (2001)
38 million kWh (2001)
285 million kWh (2001)
fossil fuel: 95.9%
hydro: 2.3%
nuclear: 0%
other: 1.7% (2001)
10% (1997 est.)
lowest 10%: 2%
highest 10%: 27.3% (1997)
agriculture 8%, industry 29%, services 64% (2002 est.)
machinery and equipment, computers, chemicals,
pharmaceuticals; live animals, animal products (1999)
UK 23.3%, US 16.7%, Belgium 14.6%, Germany 7.3%, France 5%
(2002)
26 counties; Carlow, Cavan, Clare, Cork, Donegal, Dublin,
Galway, Kerry, Kildare, Kilkenny, Laois, Leitrim, Limerick,
Longford, Louth, Mayo, Meath, Monaghan, Offaly, Roscommon, Sligo,
Tipperary, Waterford, Westmeath, Wexford, Wicklow
note: Cavan, Donegal, and Monaghan are part of Ulster Province
turnips, barley, potatoes, sugar beets, wheat; beef, dairy
products
36 (2002)
14.63 births/1,000 population (2003 est.)
Army (including Naval Service and Air Corps), National
Police (Garda Siochana)
revenues: $30.7 billion
expenditures: $30.5 billion, including capital expenditures of $5.5
billion (2002)
Ireland is a small, modern, trade-dependent economy with
growth averaging a robust 8% in 1995-2002. The global slowdown,
especially in the information technology sector, pressed growth down
to 2.7% in 2003. Agriculture, once the most important sector, is now
dwarfed by industry and services. Industry accounts for 46% of GDP
and about 80% of exports and employs 28% of the labor force.
Although exports remain the primary engine for Ireland''s growth, the
economy has also benefited from a rise in consumer spending,
construction, and business investment. Per capita GDP is 10% above
that of the four big European economies. Over the past decade, the
Irish Government has implemented a series of national economic
programs designed to curb inflation, reduce government spending,
increase labor force skills, and promote foreign investment. Ireland
joined in launching the euro currency system in January 1999 along
with 10 other EU nations.
gas 1,795 km (2003)','b9b79a153ae3a3396bf5a133bedab92b08fc6411e80a0be010e11b30ca3d6472','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('333ebd37b1aa14da7e7fa83908d6413b58bca93fe62143532136b52e6b81a3d8',2003,'IL','Israel','economy',715,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 7
914 to 1,523 m: 11
under 914 m: 4 (2002)
total: 24
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 20 (2002)
limited arable land and natural fresh water resources pose
serious constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from industrial and
domestic waste, chemical fertilizers, and pesticides
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
8.75% (FY02)
42.24 billion kWh (2001)
37.82 billion kWh (2001)
0 kWh (2001)
1.457 billion kWh (2001)
fossil fuel: 99.9%
hydro: 0.1%
nuclear: 0%
other: 0% (2001)
18% (2001 est.)
lowest 10%: 2.4%
highest 10%: 28.3% (1997)
public services 31.2%, manufacturing 20.2%, finance and
business 13.1%, commerce 12.8%, construction 7.5%, personal and
other services 6.4%, transport, storage, and communications 6.2%,
agriculture, forestry, and fishing 2.6% (1996)
machinery and equipment, software, cut diamonds, agricultural
products, chemicals, textiles and apparel
US 39.2%, Belgium 6.5%, Germany 4.4%, UK 4.2% (2002)
6 districts (mehozot, singular - mehoz); Central, Haifa,
Jerusalem, Northern, Southern, Tel Aviv
citrus, vegetables, cotton; beef, poultry, dairy products
52 (2002)
18.67 births/1,000 population (2003 est.)
Israel Defense Forces (IDF) (includes ground, naval, and air
components with Air Defense Forces), Pioneer Fighting Youth (Nahal);
note - historically there have been no separate Israeli military
services
revenues: $38.5 billion
expenditures: $45.1 billion, including capital expenditures of $NA
(2002 est.)
Israel has a technologically advanced market economy with
substantial government participation. It depends on imports of crude
oil, grains, raw materials, and military equipment. Despite limited
natural resources, Israel has intensively developed its agricultural
and industrial sectors over the past 20 years. Israel imports
significant quantities of grain but is largely self-sufficient in
other agricultural products. Cut diamonds, high-technology
equipment, and agricultural products (fruits and vegetables) are the
leading exports. Israel usually posts sizable current account
deficits, which are covered by large transfer payments from abroad
and by foreign loans. Roughly half of the government''s external debt
is owed to the US, which is its major source of economic and
military aid. The influx of Jewish immigrants from the former USSR
during the period 1989-99, coupled with the opening of new markets
at the end of the Cold War, energized Israel''s economy, which grew
rapidly in the early 1990s; growth began moderating in 1996 when the
government imposed tighter fiscal and monetary policies and the
immigration bonus petered out. Growth was a strong 7.2% in 2000, but
the bitter Israeli-Palestinian conflict, difficulties in the
high-technology, construction, and tourist sectors, and fiscal
austerity in the face of growing inflation led to small declines in
GDP in 2001 and 2002.
gas 100 km; oil 1,509 km (2003)','214114b08cba85ef8ad9a679db4d6922affb1d390254c8e65a95a40781568ad4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('235dcdb58a90541b86728667a90c772e401dec44fb381a140cd722eafb2a6257',2003,'IT','Italy','economy',716,'total: 96
over 3,047 m: 5
2,438 to 3,047 m: 34
1,524 to 2,437 m: 15
914 to 1,523 m: 30
under 914 m: 12 (2002)
total: 38
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 18 (2002)
air pollution from industrial emissions such as sulfur
dioxide; coastal and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
1.64% (2002)
258.8 billion kWh (2001)
289.1 billion kWh (2001)
48.93 billion kWh (2001)
556 million kWh (2001)
fossil fuel: 78.6%
hydro: 18.4%
nuclear: 0%
other: 3% (2001)
NA%
lowest 10%: 2.1%
highest 10%: 26.6% (2000)
services 63%, industry 32%, agriculture 5% (2001)
engineering products, textiles and clothing, production
machinery, motor vehicles, transport equipment, chemicals; food,
beverages and tobacco; minerals and nonferrous metals
Germany 13.7%, France 12.2%, US 9.8%, UK 6.9%, Spain 6.4%
(2002)
20 regions (regioni, singular - regione); Abruzzi, Basilicata,
Calabria, Campania, Emilia-Romagna, Friuli-Venezia Giulia, Lazio,
Liguria, Lombardia, Marche, Molise, Piemonte, Puglia, Sardegna,
Sicilia, Toscana, Trentino-Alto Adige, Umbria, Valle d''Aosta, Veneto
fruits, vegetables, grapes, potatoes, sugar beets, soybeans,
grain, olives; beef, dairy products; fish
134 (2002)
9.18 births/1,000 population (2003 est.)
Army, Navy, Air Force, Carabinieri
revenues: $504 billion
expenditures: $517 billion, including capital expenditures of $NA
(2001 est.)
Italy has a diversified industrial economy with roughly the
same total and per capita output as France and the UK. This
capitalistic economy remains divided into a developed industrial
north, dominated by private companies, and a less developed,
welfare-dependent agricultural south, with 20% unemployment. Most
raw materials needed by industry and more than 75% of energy
requirements are imported. Over the past decade, Italy has pursued a
tight fiscal policy in order to meet the requirements of the
Economic and Monetary Unions and has benefited from lower interest
and inflation rates. The current government has enacted numerous
short-term reforms aimed at improving competitiveness and long-term
growth. Italy has moved slowly, however, on implementing needed
structural reforms, such as lightening the high tax burden and
overhauling Italy''s rigid labor market and over-generous pension
system, because of the current economic slowdown and opposition from
labor unions.
gas 17,448 km; oil 1,245 km (2003)','63b9da2bea321285438884ae975575d4da5c822daa88a17de5b1fea9f6e6acba','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39aa7d9093c9b0dde58c4593037d776fce45957f99a4ff8c716c66553c313785',2003,'JM','Jamaica','economy',717,'total: 11
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 5 (2002)
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2002)
Jan Mayen
total: 1
1,524 to 2,437 m: 1 (2002)
heavy rates of deforestation; coastal waters polluted by
industrial waste, sewage, and oil spills; damage to coral reefs; air
pollution in Kingston results from vehicle emissions
Jan Mayen
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
NA%
6.272 billion kWh (2001)
5.833 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 96.8%
hydro: 1.8%
nuclear: 0%
other: 1.5% (2001)
34.2% (1992 est.)
lowest 10%: 2.7%
highest 10%: 30.3% (2000)
services 60%, agriculture 21%, industry 19% (1998)
alumina, bauxite; sugar, bananas, rum
US 28.1%, Canada 12.2%, Norway 10.7%, UK 10.5%, Germany 7%,
Netherlands 5.6% (2002)
14 parishes; Clarendon, Hanover, Kingston, Manchester,
Portland, Saint Andrew, Saint Ann, Saint Catherine, Saint Elizabeth,
Saint James, Saint Mary, Saint Thomas, Trelawny, Westmoreland
sugarcane, bananas, coffee, citrus, potatoes, vegetables;
poultry, goats, milk
35 (2002)
Jan Mayen
1 (2002)
17.35 births/1,000 population (2003 est.)
Jamaica Defense Force (including Ground Forces, Coast Guard,
and Air Wing), Jamaica Constabulary Force
revenues: $2.23 billion
expenditures: $2.56 billion, including capital expenditures of
$232.5 million (FY 99/00 est.)
The economy, which depends heavily on tourism and bauxite,
has been stagnant since 1995. After five years of recession, the
economy inched ahead, by 0.8% in 2000, 1.7% in 2001, and 0.8% in
2002; the global economic slowdown, particularly in the United
States after the 11 September 2001 terrorist attacks, has stunted
the economic recovery. Serious problems include: high interest
rates; increased foreign competition; a pressured, sometimes
sliding, exchange rate; a widening merchandise trade deficit; and a
growing internal debt, the result of government bailouts to various
ailing sectors of the economy, particularly the financial sector.
Depressed economic conditions have led to increased civil unrest,
including serious violent crime. Jamaica''s medium-term prospects
will depend upon encouraging investment and tourism, maintaining a
competitive exchange rate, selling off reacquired firms, and
implementing proper fiscal and monetary policies.
Jan Mayen
Jan Mayen is a volcanic island with no exploitable natural
resources. Economic activity is limited to providing services for
employees of Norway''s radio and meteorological stations located on
the island.
petroleum products 10 km','24a2dab9921acde1714555b5de5be3746851c71947ac9f2d5bd094da6839ac8a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb327c24ab12f2d21956ffd07c9de9085a874eae91db596d35691ea511720083',2003,'JP','Japan','economy',718,'total: 141
over 3,047 m: 7
2,438 to 3,047 m: 37
1,524 to 2,437 m: 38
914 to 1,523 m: 27
under 914 m: 32 (2002)
total: 31
over 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 26 (2002)
air pollution from power plant emissions results in acid rain;
acidification of lakes and reservoirs degrading water quality and
threatening aquatic life; Japan is one of the largest consumers of
fish and tropical timber, contributing to the depletion of these
resources in Asia and elsewhere
Jarvis Island
no natural fresh water resources
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
1% (FY02)
1.037 trillion kWh (2001)
Johnston Atoll
44.2 million kWh; note - approximate annual
production; there are six 25,000 kWh generators operated by the base
operating support contractor (1999)
964.2 billion kWh (2001)
Johnston Atoll
2.002 million kWh; note - approximate annual
consumption
0 kWh (2001)
0 kWh (2001)
fossil fuel: 60%
hydro: 8.4%
nuclear: 29.8%
other: 1.8% (2001)
NA%
lowest 10%: 4.8%
highest 10%: 21.7% (1993)
services 70%, industry 25%, agriculture 5% (2002 est.)
motor vehicles, semiconductors, office machinery, chemicals
US 28.8%, China 9.6%, South Korea 6.9%, Taiwan 6.2%, Hong Kong
6.1% (2002)
47 prefectures; Aichi, Akita, Aomori, Chiba, Ehime, Fukui,
Fukuoka, Fukushima, Gifu, Gumma, Hiroshima, Hokkaido, Hyogo,
Ibaraki, Ishikawa, Iwate, Kagawa, Kagoshima, Kanagawa, Kochi,
Kumamoto, Kyoto, Mie, Miyagi, Miyazaki, Nagano, Nagasaki, Nara,
Niigata, Oita, Okayama, Okinawa, Osaka, Saga, Saitama, Shiga,
Shimane, Shizuoka, Tochigi, Tokushima, Tokyo, Tottori, Toyama,
Wakayama, Yamagata, Yamaguchi, Yamanashi
rice, sugar beets, vegetables, fruit; pork, poultry, dairy
products, eggs; fish
172 (2002)
9.61 births/1,000 population (2003 est.)
Ground Self-Defense Force (Army), Maritime Self-Defense Force
(Navy), Air Self-Defense Force (Air Force), Coast Guard
revenues: $441 billion
expenditures: $718 billion, including capital expenditures (public
works only) of about $0 NA (FY 01/02 est.)
Government-industry cooperation, a strong work ethic, mastery
of high technology, and a comparatively small defense allocation (1%
of GDP) helped Japan advance with extraordinary rapidity to the rank
of second-most-technologically-powerful economy in the world after
the US and third-largest economy after the US and China. One notable
characteristic of the economy is the working together of
manufacturers, suppliers, and distributors in closely-knit groups
called keiretsu. A second basic feature has been the guarantee of
lifetime employment for a substantial portion of the urban labor
force. Both features are now eroding. Industry, the most important
sector of the economy, is heavily dependent on imported raw
materials and fuels. The much smaller agricultural sector is highly
subsidized and protected, with crop yields among the highest in the
world. Usually self-sufficient in rice, Japan must import about 50%
of its requirements of other grain and fodder crops. Japan maintains
one of the world''s largest fishing fleets and accounts for nearly
15% of the global catch. For three decades overall real economic
growth had been spectacular: a 10% average in the 1960s, a 5%
average in the 1970s, and a 4% average in the 1980s. Growth slowed
markedly in the 1990s, averaging just 1.7%, largely because of the
aftereffects of overinvestment during the late 1980s and
contractionary domestic policies intended to wring speculative
excesses from the stock and real estate markets. Government efforts
to revive economic growth have met with little success and were
further hampered in 2000-2003 by the slowing of the US, European,
and Asian economies. Japan''s huge government debt, which is
approaching 150% of GDP, and the ageing of the population are two
major long-run problems. Robotics constitutes a key long-term
economic strength with Japan possessing 410,000 of the world''s
720,000 "working robots." Internal conflict over the proper way to
reform the ailing banking system continues.
Jarvis Island
no economic activity
gas 2,719 km; oil 170 km; oil/gas/water 60 km (2003)','74257c72641e854132413ab0bc5b61fbe6ab3effb3f174012c063f76ae176d22','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c2531d5c4035b49e1fef95845e6100dd3a1b181376cc5c5d7e36e1a65bb3125',2003,'JE','Jersey','economy',719,'total: 1
1,524 to 2,437 m: 1 (2002)
Johnston Atoll
total: 1
2,438 to 3,047 m: 1 (2002)
NA
Johnston Atoll
no natural fresh water resources
NA kWh; note - electricity supplied by France
NA%
lowest 10%: NA%
highest 10%: NA%
light industrial and electrical goods, foodstuffs, textiles
UK
none (British crown dependency)
potatoes, cauliflower, tomatoes; beef, dairy products
1 (2002)
Johnston Atoll
1 (2002)
10.44 births/1,000 population (2003 est.)
revenues: $601 million
expenditures: $588 million, including capital expenditures of $98
million (2000 est.)
The economy is based largely on international financial
services, agriculture, and tourism. Potatoes, cauliflower, tomatoes,
and especially flowers are important export crops, shipped mostly to
the UK. The Jersey breed of dairy cattle is known worldwide and
represents an important export income earner. Milk products go to
the UK and other EU countries. In 1996 the finance sector accounted
for about 60% of the island''s output. Tourism, another mainstay of
the economy, accounts for 24% of GDP. In recent years, the
government has encouraged light industry to locate in Jersey, with
the result that an electronics industry has developed alongside the
traditional manufacturing of knitwear. All raw material and energy
requirements are imported, as well as a large share of Jersey''s food
needs. Light taxes and death duties make the island a popular tax
haven.
Johnston Atoll
Economic activity is limited to providing services to
US military personnel and contractors located on the island. All
food and manufactured goods must be imported.','ecc1caf7f0d78f8f8022f06aa1eca0c8352e01f8705d7df0ddb190772bec8cbe','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bad3169192a6df84292882a06e410b7ec436140eb7627e9778514405e3f97cbe',2003,'JO','Jordan','economy',720,'total: 15
over 3,047 m: 7
2,438 to 3,047 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 2
under 914 m: 2 (2002)
Juan de Nova Island
total: 1
914 to 1,523 m: 1 (2002)
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Juan de Nova Island
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
8.6% (FY01)
7.091 billion kWh (2001)
6.86 billion kWh (2001)
267 million kWh (2001)
2 million kWh (2001)
fossil fuel: 99.4%
hydro: 0.6%
nuclear: 0%
other: 0% (2001)
30% (2001 est.)
lowest 10%: 3.3%
highest 10%: 29.8% (1997)
services 82.5%, industry 12.5%, agriculture 5% (2001 est.)
phosphates, fertilizers, potash, agricultural products,
manufactures, pharmaceuticals
Iraq 20.1%, US 14.5%, India 8.1%, Saudi Arabia 5.4%, Israel
4.4% (2002)
12 governorates (muhafazat, singular - muhafazah); Ajlun, Al
''Aqabah, Al Balqa'', Al Karak, Al Mafraq, ''Amman, At Tafilah, Az
Zarqa'', Irbid, Jarash, Ma''an, Madaba
wheat, barley, citrus, tomatoes, melons, olives; sheep,
goats, poultry
17 (2002)
Juan de Nova Island
1 (2002)
23.68 births/1,000 population (2003 est.)
Jordanian Armed Forces (JAF) (Royal Jordanian Land Force,
Royal Naval Force, Royal Jordanian Air Force, and Special Operations
Command or SOCOM); note - Public Security Directorate normally falls
under Ministry of Interior but comes under JAF in wartime or crisis
situations
revenues: $2.7 billion
expenditures: $3 billion, including capital expenditures of $614
million (2002 est.)
Jordan is a small Arab country with inadequate supplies of
water and other natural resources such as oil. Debt, poverty, and
unemployment are fundamental problems, but King ABDALLAH since
assuming the throne in 1999 has undertaken some broad economic
reforms in a long-term effort to improve living standards. Amman in
the past three years has worked closely with the IMF, practiced
careful monetary policy, and made significant headway with
privatization. The government also has liberalized the trade regime
sufficiently to secure Jordan''s membership in the WTrO (2000), a
free trade accord with US (2000), and an association agreement with
the EU (2001). These measures have helped improve productivity and
have put Jordan on the foreign investment map. The US-led war in
Iraq in 2003 dealt an economic blow to Jordan, which was dependent
on Iraq for discounted oil. It remains unclear how Jordan will
finance energy imports in the absence of such a deal. Other ongoing
challenges include fiscal adjustment to reduce the budget deficit
and broader investment incentives to promote job-creating ventures.
Juan de Nova Island
Up to 12,000 tons of guano are mined per year.
gas 10 km; oil 743 km (2003)','2bcf8a90dc7420e32fbbccef7eefff8a4f1912b20c1417eecb6bab46d8760454','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f81121dc0899072e6a6dbd443d34b8b6693406aba8fde7c702164a628c8fcc3',2003,'KZ','Kazakhstan','economy',721,'total: 60
over 3,047 m: 7
2,438 to 3,047 m: 26
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 9 (2002)
total: 428
over 3,047 m: 11
2,438 to 3,047 m: 19
1,524 to 2,437 m: 44
914 to 1,523 m: 103
under 914 m: 251 (2002)
radioactive or toxic chemical sites associated with its
former defense industries and test ranges throughout the country
pose health risks for humans and animals; industrial pollution is
severe in some cities; because the two main rivers which flowed into
the Aral Sea have been diverted for irrigation, it is drying up and
leaving behind a harmful layer of chemical pesticides and natural
salts; these substances are then picked up by the wind and blown
into noxious dust storms; pollution in the Caspian Sea; soil
pollution from overuse of agricultural chemicals and salination from
poor infrastructure and wasteful irrigation practices
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
0.9% (Ministry of Defense expenditures) (FY02)
52.43 billion kWh (2001)
48.36 billion kWh (2001)
3.2 billion kWh (2001)
3.6 billion kWh (2001)
fossil fuel: 84.3%
hydro: 15.7%
nuclear: 0%
other: 0% (2001)
26% (2001 est.)
lowest 10%: 2.8%
highest 10%: 27.3% (2001)
industry 30%, agriculture 20%, services 50% (2002 est.)
oil and oil products 58%, ferrous metals 24%, chemicals
5%, machinery 3%, grain, wool, meat, coal (2001)
Russia 16.2%, Bermuda 12.1%, China 11.3%, Germany 8.8%,
Italy 5.5%, Ukraine 4.9%, France 4% (2002)
14 provinces (oblystar, singular - oblys) and 3 cities*
(qala, singular - qalasy); Almaty Oblysy, Almaty Qalasy*, Aqmola
Oblysy (Astana), Aqtobe Oblysy, Astana Qalasy*, Atyrau Oblysy, Batys
Qazaqstan Oblysy (Oral), Bayqongyr Qalasy*, Mangghystau Oblysy
(Aqtau), Ongtustik Qazaqstan Oblysy (Shymkent), Pavlodar Oblysy,
Qaraghandy Oblysy, Qostanay Oblysy, Qyzylorda Oblysy, Shyghys
Qazaqstan Oblysy (Oskemen), Soltustik Qazaqstan Oblysy
(Petropavlovsk), Zhambyl Oblysy (Taraz)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses); in 1995 the Governments of
Kazakhstan and Russia entered into an agreement whereby Russia would
lease for a period of 20 years an area of 6,000 sq km enclosing the
Baykonur space launch facilities and the city of Bayqongyr
(Baykonyr, formerly Leninsk)
grain (mostly spring wheat), cotton; livestock
488 (2002)
18.36 births/1,000 population (2003 est.)
Ground Forces, Air and Air Defense Forces, Naval Force,
Border Service, Republican Guard
revenues: $4.2 billion
expenditures: $5.1 billion, including capital expenditures of $NA
(2001 est.)
Kazakhstan, the largest of the former Soviet republics in
territory, excluding Russia, possesses enormous fossil fuel reserves
as well as plentiful supplies of other minerals and metals. It also
is a large agricultural - livestock and grain - producer.
Kazakhstan''s industrial sector rests on the extraction and
processing of these natural resources and also on a growing
machine-building sector specializing in construction equipment,
tractors, agricultural machinery, and some defense items. The
breakup of the USSR in December 1991 and the collapse in demand for
Kazakhstan''s traditional heavy industry products resulted in a
short-term contraction of the economy, with the steepest annual
decline occurring in 1994. In 1995-97, the pace of the government
program of economic reform and privatization quickened, resulting in
a substantial shifting of assets into the private sector. Kazakhstan
enjoyed double-digit growth in 2000-01 - and a solid 9.5% in 2002 -
thanks largely to its booming energy sector, but also to economic
reform, good harvests, and foreign investment. The opening of the
Caspian Consortium pipeline in 2001, from western Kazakhstan''s
Tengiz oilfield to the Black Sea, substantially raised export
capacity. The country has embarked upon an industrial policy
designed to diversify the economy away from overdependence on the
oil sector, by developing light industry. Additionally, the policy
aims to reduce the influence of foreign investment and foreign
personnel; the government has engaged in several disputes with
foreign oil companies over the terms of production agreements, and
tensions continue.
condensate 640 km; gas 10,527 km; oil 9,771 km; refined
products 1,187 km; water 1,465 km (2003)','d4f56e2d9fc441bba2dc2e060af4d320cc9825952986be371e4d1600d1d06473','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fbd4328ceee6a7365364c4e4a1e400cbf06f9b211753152bccf817b2aa6eb47',2003,'KE','Kenya','economy',722,'total: 19
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 10
under 914 m: 1 (2002)
total: 211
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 113
under 914 m: 83 (2002)
water pollution from urban and industrial wastes; degradation
of water quality from increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria; deforestation; soil
erosion; desertification; poaching
Kingman Reef
none
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.8% (FY02)
4.033 billion kWh (2001)
3.981 billion kWh (2001)
230 million kWh (2001)
0 kWh (2001)
fossil fuel: 71%
hydro: 17.7%
nuclear: 0%
other: 11.3% (2001)
50% (2000 est.)
lowest 10%: 2%
highest 10%: 37.2% (2000)
agriculture 75% 75%-80%
Korea, North
agricultural 36%, nonagricultural 64%
Korea, South
services 69%, industry 21.5%, agriculture 9.5% (2001)
tea, horticultural products, coffee, petroleum products, fish,
cement
Uganda 18.3%, UK 12.9%, US 8%, Netherlands 7.6%, Pakistan
4.9%, Tanzania 4.4%, Egypt 4.1% (2002)
7 provinces and 1 area*; Central, Coast, Eastern, Nairobi
Area*, North Eastern, Nyanza, Rift Valley, Western
tea, coffee, corn, wheat, sugarcane, fruit, vegetables; dairy
products, beef, pork, poultry, eggs
230 (2002)
Kingman Reef
lagoon was used as a halfway station between Hawaii and
American Samoa by Pan American Airways for flying boats in 1937 and
1938 (2002)
28.81 births/1,000 population (2003 est.)
Army, Navy, Air Force
revenues: $2.91 billion
expenditures: $2.97 billion, including capital expenditures of $NA
(2000 est.)
Kenya, the regional hub for trade and finance in East Africa,
is hampered by corruption and reliance upon several primary goods
whose prices remain low. Following strong economic growth in 1995
and 1996, Kenya''s economy has stagnated, with GDP growth failing to
keep up with the rate of population growth. In 1997, the IMF
suspended Kenya''s Enhanced Structural Adjustment Program due to the
government''s failure to maintain reforms and curb corruption. A
severe drought from 1999 to 2000 compounded Kenya''s problems,
causing water and energy rationing and reducing agricultural output.
As a result, GDP contracted by 0.3% in 2000. The IMF, which had
resumed loans in 2000 to help Kenya through the drought, again
halted lending in 2001 when the government failed to institute
several anticorruption measures. Despite the return of strong rains
in 2001, weak commodity prices, endemic corruption, and low
investment limited Kenya''s economic growth to 1%. Growth fell below
1% in 2002 because of erratic rains, low investor confidence, meager
donor support, and political infighting up to the elections. In the
key December 27, 2002 elections, Daniel Arap MOI''s 24-year-old reign
ended, and a new opposition government took on the formidable
economic problems facing the nation. Substantial donor support and
rooting out corruption are essential to making Kenya realize its
substantial economic potential.
Kingman Reef
no economic activity
refined products 752 km (2003)
Korea, North
oil 136 km (2003)
Korea, South
gas 1,433 km; refined products 827 km (2003)','a249222e7c1915790125d3ce5393326f84a261c8fc7080e6164f74c2c726bb31','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb1266b62e4c80dccba55f56404dc4f0ee5f6eb0389a4ea232edb8e72a11d644',2003,'KI','Kiribati','economy',723,'total: 4
1,524 to 2,437 m: 4 (2002)
Korea, North
total: 34
over 3,047 m: 5
2,438 to 3,047 m: 18
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 3 (2002)
Korea, South
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 18
1,524 to 2,437 m: 16
914 to 1,523 m: 11
under 914 m: 21 (2002)
total: 16
914 to 1,523 m: 12
under 914 m: 4 (2002)
Korea, North
total: 38
2,438 to 3,047 m: 2
1,524 to 2,437 m: 18
914 to 1,523 m: 11
under 914 m: 7 (2002)
Korea, South
total: 33
914 to 1,523 m: 2
under 914 m: 31 (2002)
heavy pollution in lagoon of south Tarawa atoll due to
heavy migration mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Korea, North
water pollution; inadequate supplies of potable water;
water-borne disease; deforestation; soil erosion and degradation
Korea, South
air pollution in large cities; acid rain; water
pollution from the discharge of sewage and industrial effluents;
drift net fishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Korea, North
party to: Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Antarctic-Environmental Protocol, Law of
the Sea
Korea, South
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA%
Korea, North
33.9% (FY02)
Korea, South
2.8% (FY02)
7 million kWh (2001)
Korea, North
30.01 billion kWh (2001)
Korea, South
290.7 billion kWh (2001)
6.51 million kWh (2001)
Korea, North
27.91 billion kWh (2001)
Korea, South
270.3 billion kWh (2001)
0 kWh (2001)
Korea, North
0 kWh (2001)
Korea, South
0 kWh (2001)
0 kWh (2001)
Korea, North
0 kWh (2001)
Korea, South
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Korea, North
fossil fuel: 29%
hydro: 71%
nuclear: 0%
other: 0% (2001)
Korea, South
fossil fuel: 62.4%
hydro: 0.8%
nuclear: 36.6%
other: 0.2% (2001)
NA%
Korea, North
NA%
Korea, South
4% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
Korea, North
lowest 10%: NA%
highest 10%: NA%
Korea, South
lowest 10%: 2.6%
highest 10%: 24.8% (1998 est.)
copra 62%, coconuts, seaweed, fish
Korea, North
minerals, metallurgical products, manufactures
(including armaments); textiles and fishery products
Korea, South
electronic products, machinery and equipment, motor
vehicles, steel, ships; textiles, clothing, footwear; fish
Japan 56.7%, Thailand 16.6%, South Korea 16.3% (2002)
Korea, North
China 23.5%, Japan 19.9%, Costa Rica 12.4%, Brazil 6.5%
(2002)
Korea, South
US 20.4%, China 14.7%, Japan 9.4%, Hong Kong 6.3% (2002)
3 units; Gilbert Islands, Line Islands, Phoenix Islands;
note - in addition, there are 6 districts (Banaba, Central Gilberts,
Line Islands, Northern Gilberts, Southern Gilberts, Tarawa) and 21
island councils - one for each of the inhabited islands (Abaiang,
Abemama, Aranuka, Arorae, Banaba, Beru, Butaritari, Kanton,
Kiritimati, Kuria, Maiana, Makin, Marakei, Nikunau, Nonouti, Onotoa,
Tabiteuea, Tabuaeran, Tamana, Tarawa, Teraina)
Korea, North
9 provinces (do, singular and plural) and 4 special
cities* (si, singular and plural); Chagang-do (Chagang Province),
Hamgyong-bukto (North Hamgyong Province), Hamgyong-namdo (South
Hamgyong Province), Hwanghae-bukto (North Hwanghae Province),
Hwanghae-namdo (South Hwanghae Province), Kaesong-si* (Kaesong
City), Kangwon-do (Kangwon Province), Najin Sonbong-si*, Namp''o-si*
(Namp''o City), P''yongan-bukto (North P''yongan Province),
P''yongan-namdo (South P''yongan Province), P''yongyang-si* (Pyongyang
City), Yanggang-do (Yanggang Province)
Korea, South
9 provinces (do, singular and plural) and 7
metropolitan cities* (gwangyoksi, singular and plural); Cheju-do,
Cholla-bukto, Cholla-namdo, Ch''ungch''ong-bukto, Ch''ungch''ong-namdo,
Inch''on-gwangyoksi*, Kangwon-do, Kwangju-gwangyoksi*, Kyonggi-do,
Kyongsang-bukto, Kyongsang-namdo, Pusan-gwangyoksi*,
Soul-t''ukpyolsi*, Taegu-gwangyoksi*, Taejon-gwangyoksi*,
Ulsan-gwangyoksi*
copra, taro, breadfruit, sweet potatoes, vegetables; fish
Korea, North
rice, corn, potatoes, soybeans, pulses; cattle, pigs,
pork, eggs
Korea, South
rice, root crops, barley, vegetables, fruit; cattle,
pigs, chickens, milk, eggs; fish
20 (2002)
Korea, North
72 (2002)
Korea, South
102 (2002)
31.24 births/1,000 population (2003 est.)
Korea, North
17.61 births/1,000 population (2003 est.)
Korea, South
12.6 births/1,000 population (2003 est.)
no regular military forces; Police Force (carries out law
enforcement functions and paramilitary duties; small police posts
are on all islands)
Korea, North
Korean People''s Army (includes Army, Navy, Air Force),
Civil Security Forces
Korea, South
Army, Navy, Air Force, Marine Corps, National Maritime
Police (Coast Guard)
revenues: $28.4 million
expenditures: $37.2 million, including capital expenditures of $NA
(2000 est.)
Korea, North
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Korea, South
revenues: $118.1 billion
expenditures: $95.7 billion, including capital expenditures of $22.6
billion (2000)
A remote country of 33 scattered coral atolls, Kiribati has
few natural resources. Commercially viable phosphate deposits were
exhausted at the time of independence from the UK in 1979. Copra and
fish now represent the bulk of production and exports. The economy
has fluctuated widely in recent years. Economic development is
constrained by a shortage of skilled workers, weak infrastructure,
and remoteness from international markets. Tourism provides more
than one-fifth of GDP. The financial sector is at an early stage of
development as is the expansion of private sector initiatives.
Foreign financial aid from UK, Japan, Australia, New Zealand, and
China is a critical supplement to GDP, equal to 25%-50% of GDP in
recent years. Remittances from workers abroad account for more than
$5 million each year.
Korea, North
North Korea, one of the world''s most centrally planned
and isolated economies, faces desperate economic conditions.
Industrial capital stock is nearly beyond repair as a result of
years of underinvestment and spare parts shortages. Industrial and
power output have declined in parallel. The nation has suffered its
tenth year of food shortages because of a lack of arable land;
collective farming; weather-related problems, including major
drought in 2000; and chronic shortages of fertilizer and fuel.
Massive international food aid deliveries have allowed the regime to
escape mass starvation since 1995-96, but the population remains the
victim of prolonged malnutrition and deteriorating living
conditions. Large-scale military spending eats up resources needed
for investment and civilian consumption. Recently, the regime has
placed emphasis on earning hard currency, developing information
technology, addressing power shortages, and attracting foreign aid,
but in no way at the expense of relinquishing central control over
key national assets or undergoing widespread market-oriented
reforms. In 2003, heightened political tensions with key donor
countries and general donor fatigue have held down the flow of
desperately needed food aid and have threatened fuel aid as well.
Korea, South
As one of the Four Tigers of East Asia, South Korea has
achieved an incredible record of growth and integration into the
high-tech modern world economy. Three decades ago GDP per capita was
comparable with levels in the poorer countries of Africa and Asia.
Today its GDP per capita is 18 times North Korea''s and equal to the
lesser economies of the European Union. This success through the
late 1980s was achieved by a system of close government/business
ties, including directed credit, import restrictions, sponsorship of
specific industries, and a strong labor effort. The government
promoted the import of raw materials and technology at the expense
of consumer goods and encouraged savings and investment over
consumption. The Asian financial crisis of 1997-99 exposed
longstanding weaknesses in South Korea''s development model,
including high debt/equity ratios, massive foreign borrowing, and an
undisciplined financial sector. Growth plunged to a negative 6.6% in
1998, then strongly recovered to 10.8% in 1999 and 9.2% in 2000.
Growth fell back to 3.3% in 2001 because of the slowing global
economy, falling exports, and the perception that much-needed
corporate and financial reforms had stalled. Led by consumer
spending and exports, growth in 2002 was an impressive 6.2%, despite
anemic global growth, followed by moderate 2.8% growth in 2003. In
2003 the six-day work week was reduced to five days.','61aafad10c9bb3a71daa38450741f59cbc3925b136a438880aa975cc45a1f55b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d88d9f5889d5778d4cfb27b43daf1833874e321fd7b21442a92a8c51c1858854',2003,'KW','Kuwait','economy',724,'total: 3
over 3,047 m: 1
2,438 to 3,047 m: 2 (2002)
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2002)
limited natural fresh water resources; some of world''s
largest and most sophisticated desalination facilities provide much
of the water; air and water pollution; desertification
party to: Climate Change, Desertification, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Biodiversity, Endangered Species, Marine
Dumping
5.5% (FY01)
31.49 billion kWh (2001)
29.29 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture NA, industries NA, services NA
oil and refined products, fertilizers
Japan 24.4%, South Korea 12.9%, US 11.9%, Singapore 10.1%,
Taiwan 7%, Netherlands 4.5%, Pakistan 4.4% (2002)
5 governorates (muhafazat, singular - muhafazah); Al Ahmadi,
Al Farwaniyah, Al ''Asimah, Al Jahra'', Hawalli
practically no crops; fish
6 (2002)
21.83 births/1,000 population (2003 est.)
Army, Navy, Air Force (including Air Defense Force), National
Police Force, National Guard, Coast Guard
revenues: $11 billion
expenditures: $17.5 billion, including capital expenditures of $NA
(FY 02/03)
Kuwait is a small, rich, relatively open economy with proved
crude oil reserves of about 98 billion barrels - 10% of world
reserves. Petroleum accounts for nearly half of GDP, 95% of export
revenues, and 80% of government income. Kuwait''s climate limits
agricultural development. Consequently, with the exception of fish,
it depends almost wholly on food imports. About 75% of potable water
must be distilled or imported. Kuwait continues its discussions with
foreign oil companies to develop fields in the northern part of the
country. Oil production declined by an estimated 8% in 2002 but is
expected to return to the 2001 level in 2003.
gas 169 km; oil 540 km; refined products 57 km (2003)','a943c3b0c666f603187ad83460ba42a06dd138db813822acd7427d893260b822','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('403e37299f058a75905f01945f253a2ea19bdda974017febb80ebcd34af83cf8',2003,'KG','Kyrgyzstan','economy',725,'total: 18
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 11
914 to 1,523 m: 1
under 914 m: 3 (2002)
Laos
total: 9
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2002)
total: 50
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 36 (2002)
Laos
total: 42
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 26 (2002)
water pollution; many people get their water directly
from contaminated streams and wells; as a result, water-borne
diseases are prevalent; increasing soil salinity from faulty
irrigation practices
Laos
unexploded ordnance; deforestation; soil erosion; a majority of
the population does not have access to potable water
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Laos
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
1.4% (FY01)
Laos
4.2% (FY96)
13.45 billion kWh (2001)
Laos
1.317 billion kWh (2001)
10.46 billion kWh (2001)
Laos
824.7 million kWh (2001)
200 million kWh (2001)
Laos
0 kWh (2001)
2.25 billion kWh (2001)
Laos
400 million kWh (2001)
fossil fuel: 7.6%
hydro: 92.4%
nuclear: 0%
other: 0% (2001)
Laos
fossil fuel: 1.4%
hydro: 98.6%
nuclear: 0%
other: 0% (2001)
55% (2001 est.)
Laos
40% (2002 est.)
lowest 10%: 3.2%
highest 10%: 27.7% (1999)
Laos
lowest 10%: 3.2%
highest 10%: 30.6% (1997)
agriculture 55%, industry 15%, services 30% (2000 est.)
Laos
agriculture 80% (1997 est.)
cotton, wool, meat, tobacco; gold, mercury, uranium,
natural gas, hydropower; machinery; shoes
Laos
wood products, garments, electricity, coffee, tin
Switzerland 19.9%, Russia 16.5%, UAE 14.2%, China 8.5%,
Kazakhstan 7.6%, US 7.4%, Uzbekistan 5.7% (2002)
Laos
Vietnam 25.7%, Thailand 19%, France 7.5%, Germany 5.3% (2002)
7 provinces (oblastlar, singular - oblasty) and 1 city*
(shaar); Batken Oblasty, Bishkek Shaary*, Chuy Oblasty (Bishkek),
Jalal-Abad Oblasty, Naryn Oblasty, Osh Oblasty, Talas Oblasty,
Ysyk-Kol Oblasty (Karakol)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
Laos
16 provinces (khoueng, singular and plural), 1 municipality*
(kampheng nakhon, singular and plural), and 1 special zone**
(khetphiset, singular and plural); Attapu, Bokeo, Bolikhamxai,
Champasak, Houaphan, Khammouan, Louangnamtha, Louangphabang,
Oudomxai, Phongsali, Salavan, Savannakhet, Viangchan*, Viangchan,
Xaignabouli, Xaisomboun**, Xekong, Xiangkhoang
tobacco, cotton, potatoes, vegetables, grapes, fruits and
berries; sheep, goats, cattle, wool
Laos
sweet potatoes, vegetables, corn, coffee, sugarcane, tobacco,
cotton; tea, peanuts, rice; water buffalo, pigs, cattle, poultry
68 (2002)
Laos
51 (2002)
26.06 births/1,000 population (2003 est.)
Laos
36.93 births/1,000 population (2003 est.)
Army, Air and Air Defense, Security Forces, Border Troops
Laos
Lao People''s Army (LPA; including Riverine Force), Air Force,
National Police Department
revenues: $207.4 million
expenditures: $238.7 million, including capital expenditures of $NA
(1999 est.)
Laos
revenues: $211 million
expenditures: $462 million, including capital expenditures of $NA
(FY98/99 est. est.)
Kyrgyzstan is a small, poor, mountainous country with a
predominantly agricultural economy. Cotton, tobacco, wool, and meat
are the main agricultural products, although only tobacco and cotton
are exported in any quantity. Industrial exports include gold,
mercury, uranium, and natural gas and electricity. Kyrgyzstan has
been fairly progressive in carrying out market reforms, such as an
improved regulatory system and land reform. Kyrgyzstan was the first
CIS country to be accepted into the World Trade Organization. With
fits and starts, inflation has been lowered to an estimated 7% in
2001, 2.1% in 2002, and 4.0% in 2003. Much of the government''s stock
in enterprises has been sold. Drops in production had been severe
after the breakup of the Soviet Union in December 1991, but by
mid-1995 production began to recover and exports began to increase.
Growth was held down to 2.1% in 1998 largely because of the
spillover from Russia''s economic difficulties, but moved ahead to
3.6% in 1999, 5% in 2000, and 5% again in 2001. The drop in output
at the Kumtor gold mine sparked a 0.5% decline in GDP in 2002 and
again in 2003. On the positive side, the government and the
international financial institutions have been engaged in a
comprehensive medium-term poverty reduction and economic growth
strategy. Further restructuring of domestic industry and success in
attracting foreign investment are keys to future growth.
Laos
The government of Laos - one of the few remaining official
Communist states - began decentralizing control and encouraging
private enterprise in 1986. The results, starting from an extremely
low base, were striking - growth averaged 7% in 1988-2001 except
during the short-lived drop caused by the Asian financial crisis
beginning in 1997. Despite this high growth rate, Laos remains a
country with a primitive infrastructure; it has no railroads, a
rudimentary road system, and limited external and internal
telecommunications. Electricity is available in only a few urban
areas. Subsistence agriculture accounts for half of GDP and provides
80% of total employment. The economy will continue to benefit from
aid from the IMF and other international sources and from new
foreign investment in food processing and mining.
gas 367 km; oil 13 km (2003)
Laos
refined products 540 km (2003)','a428c73fc76f2401a61ecf3ec945b21ac856f8e3ea54cf284c11688280bd91d2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d370a046a204532f3c529e22d834bef6525a0e83d61adc7d81eebe091141c179',2003,'LV','Latvia','economy',726,'total: 22
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 12 (2002)
total: 16
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 10 (2002)
Latvia''s environment has benefited from a shift to service
industries after the country regained independence; the main
environmental priorities are improvement of drinking water quality
and sewage system, household and hazardous waste management, and
reduction of air pollution; in 2001, Latvia closed the EU accession
negotiation chapter on environment committing to full enforcement of
EU environmental directives by 2010
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
1.2% (FY01)
4.365 billion kWh (2001)
6.046 billion kWh (2001)
2.69 billion kWh (2001)
703 million kWh (2001)
fossil fuel: 29.1%
hydro: 70.9%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: 2.9%
highest 10%: 25.9% (1998)
agriculture 15%, industry 25%, services 60% (2000 est.)
wood and wood products, machinery and equipment, metals,
textiles, foodstuffs
UK 21.6%, Sweden 13.1%, Germany 12.5%, US 6.4%, Lithuania
5.9%, Russia 4.6%, Estonia 4.2%, Denmark 4% (2002)
26 counties (singular - rajons) and 7 municipalities*:
Aizkraukles Rajons, Aluksnes Rajons, Balvu Rajons, Bauskas Rajons,
Cesu Rajons, Daugavpils*, Daugavpils Rajons, Dobeles Rajons,
Gulbenes Rajons, Jekabpils Rajons, Jelgava*, Jelgavas Rajons,
Jurmala*, Kraslavas Rajons, Kuldigas Rajons, Liepaja*, Liepajas
Rajons, Limbazu Rajons, Ludzas Rajons, Madonas Rajons, Ogres Rajons,
Preilu Rajons, Rezekne*, Rezeknes Rajons, Riga*, Rigas Rajons,
Saldus Rajons, Talsu Rajons, Tukuma Rajons, Valkas Rajons, Valmieras
Rajons, Ventspils*, Ventspils Rajons
grain, sugar beets, potatoes, vegetables; beef, pork, milk,
eggs; fish
38 (2002)
8.55 births/1,000 population (2003 est.)
Ground Forces, Navy, Air and Air Defense Forces, Border
Guard, National Guard
revenues: $2.4 billion
expenditures: $2.6 billion, including capital expenditures of $NA
(2002 est.)
Latvia''s transitional economy recovered from the 1998 Russian
financial crisis, largely due to the SKELE government''s budget
stringency and a gradual reorientation of exports toward EU
countries, lessening Latvia''s trade dependency on Russia. The
majority of companies, banks, and real estate have been privatized,
although the state still holds sizable stakes in a few large
enterprises. Latvia officially joined the World Trade Organization
in February 1999. Preparing for EU membership continues as a top
foreign policy goal. The current account and internal government
deficits remain major concerns, but the government''s efforts to
increase efficiency in revenue collection may lessen the budget
deficit.
gas 1,097 km; oil 412 km; refined products 421 km (2003)','bc1c0ed34cc3e4713842c9ae93bf28118c11254b4d5d88ab78f0afa844403c6d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b58baf47d92f2348e8fccc4c054b629cf8fc3e977bf2a4a5117f2dcf009be2d',2003,'LB','Lebanon','economy',727,'total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2002)
total: 3
914 to 1,523 m: 2
under 914 m: 1 (2002)
deforestation; soil erosion; desertification; air pollution
in Beirut from vehicular traffic and the burning of industrial
wastes; pollution of coastal waters from raw sewage and oil spills
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification, Marine
Dumping, Marine Life Conservation
4.8% (FY99)
6.728 billion kWh (2001)
7.44 billion kWh (2001)
1.183 billion kWh (2001)
0 kWh (2001)
fossil fuel: 97.2%
hydro: 2.8%
nuclear: 0%
other: 0% (2001)
28% (1999 est.)
lowest 10%: NA%
highest 10%: NA%
services NA%, industry NA%, agriculture NA%
foodstuffs and tobacco, textiles, chemicals, precious
stones, metal products, electrical products, jewelry, paper products
Switzerland 10.8%, Saudi Arabia 9%, UAE 8.6%, US 6.7%,
Jordan 4.6%, Turkey 4.3% (2002)
6 governorates (mohafazat, singular - mohafazah); Beyrouth,
Beqaa, Liban-Nord, Liban-Sud, Mont-Liban, Nabatiye
citrus, grapes, tomatoes, apples, vegetables, potatoes,
olives, tobacco; sheep, goats
8 (2002)
19.68 births/1,000 population (2003 est.)
Lebanese Armed Forces (LAF; includes Army, Navy, and Air
Force)
revenues: $3.1 billion
expenditures: $5.9 billion, including capital expenditures of $NA
(2001 est.)
The 1975-91 civil war seriously damaged Lebanon''s economic
infrastructure, cut national output by half, and all but ended
Lebanon''s position as a Middle Eastern entrepot and banking hub.
Peace enabled the central government to restore control in Beirut,
begin collecting taxes, and regain access to key port and government
facilities. Economic recovery was helped by a financially sound
banking system and resilient small- and medium-scale manufacturers.
Family remittances, banking services, manufactured and farm exports,
and international aid provided the main sources of foreign exchange.
Lebanon''s economy made impressive gains since the launch in 1993 of
"Horizon 2000," the government''s $20 billion reconstruction program.
Real GDP grew 8% in 1994, 7% in 1995, 4% in 1996 and in 1997, but
slowed to 1.2% in 1998, -1.6% in 1999, -0.6% in 2000, 0.8% in 2001,
and 1.5% in 2002. During the 1990s annual inflation fell to almost
0% from more than 100%. Lebanon has rebuilt much of its war-torn
physical and financial infrastructure. The government nonetheless
faces serious challenges in the economic arena. It has funded
reconstruction by borrowing heavily - mostly from domestic banks. In
order to reduce the ballooning national debt, the re-installed
HARIRI government began an economic austerity program to rein in
government expenditures, increase revenue collection, and privatize
state enterprises. The HARIRI government met with international
donors at the Paris II conference in November 2002 to seek bilateral
assistance restructuring its domestic debt at lower rates of
interest. While privatization of state-owned enterprises had not
occurred by the end of 2002, the government had successfully avoided
a currency devaluation and debt default in 2002.
oil 209 km (2003)','a91ae6e022ec3d3161430339730968e168a48cea38acac4438bc6ddaabba9133','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19ba60da3326709551fc48486b7397bafa06761aef568ad7cf68590eb10fc25d',2003,'LS','Lesotho','economy',728,'total: 4
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 2 (2002)
total: 24
914 to 1,523 m: 4
under 914 m: 20 (2002)
population pressure forcing settlement in marginal areas
results in overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls, stores, and
redirects water to South Africa
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection
signed, but not ratified: Endangered Species, Law of the Sea, Marine
Dumping
NA%
0 kWh NA kWh; note - electricity supplied by South Africa
(2001)
40 million kWh (2001)
40 million kWh; note - electricity supplied by South Africa
(2001)
0 kWh (2001)
49% (1999)
lowest 10%: 0.9%
highest 10%: 43.4%
86% of resident population engaged in subsistence
agriculture; roughly 35% of the active male wage earners work in
manufactures 75% (clothing, footwear, road vehicles), wool
and mohair, food and live animals (2000)
US 97.5%, Canada 0.9%, France 0.6% (2002)
10 districts; Berea, Butha-Buthe, Leribe, Mafeteng, Maseru,
Mohales Hoek, Mokhotlong, Qacha''s Nek, Quthing, Thaba-Tseka
corn, wheat, pulses, sorghum, barley; livestock
28 (2002)
27.26 births/1,000 population (2003 est.)
Lesotho Defense Force (LDF; including Army and Air Wing),
Royal Lesotho Mounted Police
revenues: $76 million
expenditures: $80 million, including capital expenditures of $15
million (FY 99/00 est.)
Small, landlocked, and mountainous, Lesotho relies on
remittances from miners employed in South Africa and customs duties
from the Southern Africa Customs Union for the majority of
government revenue, but the government has strengthened its tax
system to reduce dependency on customs duties. Completion of a major
hydropower facility in January 1998 now permits the sale of water to
South Africa, also generating royalties for Lesotho. As the number
of mineworkers has declined steadily over the past several years, a
small manufacturing base has developed based on farm products that
support the milling, canning, leather, and jute industries and a
rapidly growing apparel-assembly sector. The economy is still
primarily based on subsistence agriculture, especially livestock,
although drought has decreased agricultural activity. The extreme
inequality in the distribution of income remains a major drawback.
Lesotho has signed an Interim Poverty Reduction and Growth Facility
with the IMF.','ce563bfded3735e51008bd2a23fa4eb41ea855617375c5f4a0a85b84b8792f78','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eee6d401cf4309b8208b97673fcaf3fca80ce01560abe99827843cb3ded9613d',2003,'LR','Liberia','economy',729,'total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2002)
total: 45
1,524 to 2,437 m: 4
914 to 1,523 m: 7
under 914 m: 34 (2002)
tropical rain forest deforestation; soil erosion; loss of
biodiversity; pollution of coastal waters from oil residue and raw
sewage
party to: Biodiversity, Desertification, Endangered Species,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping, Marine Life
Conservation
1.3% (FY02)
468.8 million kWh (2001)
435.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
80%
lowest 10%: NA%
highest 10%: NA%
agriculture 70%, industry 8%, services 22% (2000 est.)
rubber, timber, iron, diamonds, cocoa, coffee
Germany 54.8%, Poland 8.9%, France 8.5%, China 4.9%, Italy
4.5%, US 4.2% (2002)
15 counties; Bomi, Bong, Gparbolu, Grand Bassa, Grand Cape
Mount, Grand Gedeh, Grand Kru, Lofa, Margibi, Maryland, Montserrado,
Nimba, River Cess, River Gee, Sinoe
rubber, coffee, cocoa, rice, cassava (tapioca), palm oil,
sugarcane, bananas; sheep, goats; timber
47 (2002)
45.28 births/1,000 population (2003 est.)
Army, Navy, Air Force
revenues: $85.4 million
expenditures: $90.5 million, including capital expenditures of $NA
(2000 est.)
Civil war and misgovernment have destroyed much of Liberia''s
economy, especially the infrastructure in and around Monrovia. Many
businessmen have fled the country, taking capital and expertise with
them. Some have returned; many will not. Richly endowed with water,
mineral resources, forests, and a climate favorable to agriculture,
Liberia had been a producer and exporter of basic products -
primarily raw timber and rubber. Local manufacturing, mainly foreign
owned, had been small in scope. The restoration of the
infrastructure and the raising of incomes in this ravaged economy
depend on the settlement of civil warfare, the implementation of
sound macro- and micro-economic policies, including the
encouragement of foreign investment, and generous support from donor
countries.','34cd0116aed9920af1f583cc0f90f22d5e0929d6f65968f5b2625472d103ffe7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('264dd40d0a640317d987b17697506a63dba557536a16f6dab5d3dd488a0f8fae',2003,'LY','Libya','economy',730,'total: 58
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 5
under 914 m: 2 (2002)
total: 78
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 39
under 914 m: 18 (2002)
desertification; very limited natural fresh water resources;
the Great Manmade River Project, the largest water development
scheme in the world, is being built to bring water from large
aquifers under the Sahara to coastal cities
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Nuclear Test Ban
3.9% (FY99)
20.18 billion kWh (2001)
18.77 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
services 54%, industry 29%, agriculture 17% (1997 est.)
crude oil, refined petroleum products (1999)
Italy 42.6%, Germany 14.1%, Spain 13.6%, Turkey 6.9%,
Switzerland 4.4% (2002)
25 municipalities (baladiyat, singular - baladiyah); Ajdabiya,
Al ''Aziziyah, Al Fatih, Al Jabal al Akhdar, Al Jufrah, Al Khums, Al
Kufrah, An Nuqat al Khams, Ash Shati'', Awbari, Az Zawiyah, Banghazi,
Darnah, Ghadamis, Gharyan, Misratah, Murzuq, Sabha, Sawfajjin, Surt,
Tarabulus, Tarhunah, Tubruq, Yafran, Zlitan; note - the 25
municipalities may have been replaced by 13 regions
wheat, barley, olives, dates, citrus, vegetables, peanuts,
soybeans; cattle
136 (2002)
27.43 births/1,000 population (2003 est.)
Armed Peoples on Duty (Army), Navy, Air and Air Defense
Command (includes Air Force)
revenues: $13.7 billion
expenditures: $8.6 billion, including capital expenditures of $NA
(2001 est.)
The socialist-oriented economy depends primarily upon revenues
from the oil sector, which contribute practically all export
earnings and about one-quarter of GDP. These oil revenues and a
small population give Libya one of the highest per capita GDPs in
Africa, but little of this income flows down to the lower orders of
society. Import restrictions and inefficient resource allocations
have led to periodic shortages of basic goods and foodstuffs. The
nonoil manufacturing and construction sectors, which account for
about 20% of GDP, have expanded from processing mostly agricultural
products to include the production of petrochemicals, iron, steel,
and aluminum. Climatic conditions and poor soils severely limit
agricultural output, and Libya imports about 75% of its food. Higher
oil prices in the last three years led to an increase in export
revenues, which has improved macroeconomic balances but has done
little to stimulate broad-based economic growth. Libya is making
slow progress toward economic liberalization and the upgrading of
economic infrastructure, but truly market-based reforms will be slow
in coming.
condensate 225 km; gas 3,196 km; oil 6,872 km (2003)','256043e4196e4d9cf90d7bc38eb31d6a615225c1b14447be5b21609a2827da05','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b477d73df07cf8cc6ddc2179bb9c05aa9873c49a2e30ffcee6f5dc33d6b67fa',2003,'LT','Lithuania','economy',731,'total: 22
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m: 2
under 914 m: 8 (2002)
total: 65
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 57 (2002)
contamination of soil and groundwater with petroleum
products and chemicals at military bases
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
1.9% (FY01)
14.62 billion kWh (2001)
8.683 billion kWh (2001)
1.389 billion kWh (2001)
6.3 billion kWh (2001)
fossil fuel: 16.5%
hydro: 5.7%
nuclear: 77.7%
other: 0% (2001)
NA%
lowest 10%: 3.1%
highest 10%: 25.6% (1996)
industry 30%, agriculture 20%, services 50% (1997 est.)
mineral products 23%, textiles and clothing 16%, machinery
and equipment 11%, chemicals 6%, wood and wood products 5%,
foodstuffs 5% (2001)
Latvia 12.8%, Germany 12%, UK 7.6%, Poland 6.3%, US 5.9%,
France 5.8%, Russia 5.7%, Sweden 5%, Denmark 4.3% (2002)
10 counties (apskritys, singular - apskritis); Alytaus,
Kauno, Klaipedos, Marijampoles, Panevezio, Siauliu, Taurages,
Telsiu, Utenos, Vilniaus
grain, potatoes, sugar beets, flax, vegetables; beef,
milk, eggs; fish
87 (2002)
10.48 births/1,000 population (2003 est.)
Ground Forces, Navy, Air and Air Defense Force, National
Volunteer Defense Forces (SKAT)
revenues: $1.59 billion
expenditures: $1.77 billion, including capital expenditures of $NA
(2001 est.)
Lithuania, the Baltic state that has conducted the most
trade with Russia, has slowly rebounded from the 1998 Russian
financial crisis. Unemployment remains high, still 10.7% in 2003,
but is improving. Growing domestic consumption and increased
investment have furthered recovery. Trade has been increasingly
oriented toward the West. Lithuania has gained membership in the
World Trade Organization and has moved ahead with plans to join the
EU. Privatization of the large, state-owned utilities, particularly
in the energy sector, is nearing completion. Overall, more than 80%
of enterprises have been privatized. Foreign government and business
support have helped in the transition from the old command economy
to a market economy.
gas 1,698 km; oil 331 km; refined products 109 km (2003)','0d460f1debe2429b7c0d326dd5f87ae4e438965e47a7bd388954899722a9dfef','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d87a06566cec44d6240b8f642f3b64b5e29da58972f4f37a83c15f6578fd0fc8',2003,'LU','Luxembourg','economy',732,'total: 1
over 3,047 m: 1 (2002)
Macau
total: 1
over 3,047 m: 1 (2002)
Macedonia, The Former Yugoslav Republic of
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (2002)
total: 1
under 914 m: 1 (2002)
Macedonia, The Former Yugoslav Republic of
total: 8
914 to 1,523 m: 4
under 914 m: 4 (2002)
air and water pollution in urban areas, soil pollution of
farmland
Macau
NA
Macedonia, The Former Yugoslav Republic of
air pollution from
metallurgical plants
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur
85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
Macedonia, The Former Yugoslav Republic of
party to: Air Pollution,
Biodiversity, Climate Change, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.8% (FY01/02)
Macedonia, The Former Yugoslav Republic of
6% (FY01/02 est.)
457 million kWh (2001)
Macau
1.611 billion kWh (2002)
Macedonia, The Former Yugoslav Republic of
6.465 billion kWh (2001)
6.07 billion kWh (2001)
Macau
1.688 billion kWh (2002)
Macedonia, The Former Yugoslav Republic of
6.112 billion kWh (2001)
6.389 billion kWh (2001)
Macau
193 million kWh (2002)
Macedonia, The Former Yugoslav Republic of
100 million kWh (2001)
744 million kWh (2001)
Macau
1 million kWh (2001)
Macedonia, The Former Yugoslav Republic of
0 kWh (2001)
fossil fuel: 57.3%
hydro: 25.2%
nuclear: 0%
other: 17.5% (2001)
Macau
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Macedonia, The Former Yugoslav Republic of
fossil fuel: 83.7%
hydro: 16.3%
nuclear: 0%
other: 0% (2001)
NA%
Macau
NA%
Macedonia, The Former Yugoslav Republic of
24% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
Macau
lowest 10%: NA%
highest 10%: NA%
Macedonia, The Former Yugoslav Republic of
lowest 10%: NA%
highest 10%: NA%
services 90.1%, industry 8%, agriculture 1.9% (1999 est.)
Macau
restaurants and hotels 12%, manufacturing 20%, other services
and agriculture 68% (2002 est.)
Macedonia, The Former Yugoslav Republic of
agriculture NA%, industry
NA%, services NA%
machinery and equipment, steel products, chemicals,
rubber products, glass
Macau
clothing, textiles, footwear, cement, machines, and parts
Macedonia, The Former Yugoslav Republic of
food, beverages, tobacco;
miscellaneous manufactures, iron and steel
Germany 23.9%, France 20.1%, Belgium 10.5%, UK 8.7%,
Italy 6.1%, Spain 4.5%, Netherlands 4.4% (2002)
Macau
US 48.6%, China 15.5%, Germany 7.4%, Hong Kong 5.8%, UK 5.4%
(2002)
Macedonia, The Former Yugoslav Republic of
Germany 19.2%, Italy
9.2%, US 6.7%, Croatia 5.5%, Greece 4.6% (2002)
3 districts; Diekirch, Grevenmacher, Luxembourg
Macau
none (special administrative region of China)
Macedonia, The Former Yugoslav Republic of
123 municipalities
(opstini, singular - opstina); Aracinovo, Bac, Belcista, Berovo,
Bistrica, Bitola, Blatec, Bogdanci, Bogomila, Bogovinje, Bosilovo,
Brvenica, Cair (Skopje), Capari, Caska, Cegrane, Centar (Skopje),
Centar Zupa, Cesinovo, Cucer-Sandevo, Debar, Delcevo, Delogozdi,
Demir Hisar, Demir Kapija, Dobrusevo, Dolna Banjica, Dolneni, Dorce
Petrov (Skopje), Drugovo, Dzepciste, Gazi Baba (Skopje), Gevgelija,
Gostivar, Gradsko, Ilinden, Izvor, Jegunovce, Kamenjane, Karbinci,
Karpos (Skopje), Kavadarci, Kicevo, Kisela Voda (Skopje), Klecevce,
Kocani, Konce, Kondovo, Konopiste, Kosel, Kratovo, Kriva Palanka,
Krivogastani, Krusevo, Kuklis, Kukurecani, Kumanovo, Labunista,
Lipkovo, Lozovo, Lukovo, Makedonska Kamenica, Makedonski Brod,
Mavrovi Anovi, Meseista, Miravci, Mogila, Murtino, Negotino,
Negotino-Polosko, Novaci, Novo Selo, Oblesevo, Ohrid, Orasac,
Orizari, Oslomej, Pehcevo, Petrovec, Plasnica, Podares, Prilep,
Probistip, Radovis, Rankovce, Resen, Rosoman, Rostusa, Samokov,
Saraj, Sipkovica, Sopiste, Sopotnica, Srbinovo, Star Dojran,
Staravina, Staro Nagoricane, Stip, Struga, Strumica, Studenicani,
Suto Orizari (Skopje), Sveti Nikole, Tearce, Tetovo, Topolcani,
Valandovo, Vasilevo, Velesta, Veles, Vevcani, Vinica, Vitoliste,
Vranestica, Vrapciste, Vratnica, Vrutok, Zajas, Zelenikovo, Zeleno,
Zitose, Zletovo, Zrnovci
note: the seven municipalities followed by Skopje in parentheses
collectively constitute "greater Skopje"
barley, oats, potatoes, wheat, fruits, wine grapes;
livestock products
Macau
vegetables, livestock
Macedonia, The Former Yugoslav Republic of
rice, tobacco, wheat,
corn, millet, cotton, sesame, mulberry leaves, citrus, vegetables;
beef, pork, poultry, mutton
2 (2002)
Macau
1 (2002)
Macedonia, The Former Yugoslav Republic of
18 (2002)
11.92 births/1,000 population (2003 est.)
Macau
12.07 births/1,000 population (2003 est.)
Macedonia, The Former Yugoslav Republic of
13.2 births/1,000
population (2003 est.)
Army, Grand Ducal Police
Macau
no regular indigenous military forces; responsibility for
defense reverted to China on 20 December 1999; there is a local
police force
Macedonia, The Former Yugoslav Republic of
Army (ARM), Air and Air
Defense Forces, Police Force
revenues: $5.5 billion
expenditures: $5.5 billion, including capital expenditures of $760
million (2002 est.)
Macau
revenues: $1.41 billion
expenditures: $1.19 billion, including capital expenditures of $194
million (2002)
Macedonia, The Former Yugoslav Republic of
revenues: $1.13 billion
expenditures: $1.02 billion, including capital expenditures of $NA
(2001 est.)
This stable, high-income economy features solid growth,
low inflation, and low unemployment. The industrial sector,
initially dominated by steel, has become increasingly diversified to
include chemicals, rubber, and other products. Growth in the
financial sector, which now accounts for about 22% of GDP, has more
than compensated for the decline in steel. Most banks are
foreign-owned and have extensive foreign dealings. Agriculture is
based on small family-owned farms. The economy depends on foreign
and trans-border workers for more than 30% of its labor force.
Although Luxembourg, like all EU members, has suffered from the
global economic slump, the country has maintained a fairly strong
growth rate and enjoys an extraordinarily high standard of living.
Macau
Macau''s economy four years after reversion to China remains
one of the most open in the world. The territory''s net exports of
goods and services account for 39% of GDP with tourism and apparel
exports as the mainstays. Although the territory was hit hard by the
1998 Asian financial crisis and the global downturn in 2001, its
economy grew an estimated 9.5% in 2002. A rapid rise in the number
of mainland visitors because of China''s easing of restrictions on
travel drove the recovery. The budget also returned to surplus in
2002 because of the surge in visitors from China and a hike in taxes
on gambling profits, which generated about 63% of government
revenue. The liberalization of Macao''s gambling monopoly may
contribute to GDP growth, as the three companies awarded gambling
licenses have pledged to invest $2.2 billion - roughly 33% of GDP -
in the territory. Much of Macau''s textile industry may move to the
mainland as the Multi-Fiber Agreement is phased out. The territory
may have to rely more on gambling and trade-related services to
generate growth. Growth fell to 4% in 2003, according to early
government forecasts, with the drop in large measure due to concerns
over the Severe Acute Respiratory Syndrome (SARS).
Macedonia, The Former Yugoslav Republic of
At independence in
November 1991, Macedonia was the least developed of the Yugoslav
republics, producing a mere 5% of the total federal output of goods
and services. The collapse of Yugoslavia ended transfer payments
from the center and eliminated advantages from inclusion in a de
facto free trade area. An absence of infrastructure, UN sanctions on
Yugoslavia, one of its largest markets, and a Greek economic embargo
over a dispute about the country''s constitutional name and flag
hindered economic growth until 1996. GDP subsequently rose each year
through 2000. However, the leadership''s commitment to economic
reform, free trade, and regional integration was undermined by the
ethnic Albanian insurgency of 2001. The economy shrank 4.5% because
of decreased trade, intermittent border closures, increased deficit
spending on security needs, and investor uncertainty. Growth barely
recovered in 2002 to 0.3%, then rose to 2.8% in 2003. Unemployment
at one-third of the workforce remains the most critical economic
problem. But even this issue is overshadowed by the fragile
political situation.
gas 155 km (2003)
Macedonia, The Former Yugoslav Republic of
gas 268 km; oil 120 km
(2003)','af669e2879214ccbff341e3d65547df1ee128141a023524b6a81c628c5737e4a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58656030c9e6386ad1c9e8a13fd5b132c58184b95927a8e5995736d9dd57a156',2003,'MG','Madagascar','economy',733,'total: 29
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (2002)
total: 92
1,524 to 2,437 m: 2
914 to 1,523 m: 46
under 914 m: 44 (2002)
soil erosion results from deforestation and overgrazing;
desertification; surface water contaminated with raw sewage and
other organic wastes; several species of flora and fauna unique to
the island are endangered
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.2% (FY02)
830.2 million kWh (2001)
772.1 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 36.1%
hydro: 63.9%
nuclear: 0%
other: 0% (2001)
71% (1999 est.)
lowest 10%: 3%
highest 10%: 29% (1999)
coffee, vanilla, shellfish, sugar; cotton cloth,
chromite, petroleum products
France 34%, US 24.6%, Netherlands 6%, Germany 5.9%,
Mauritius 4% (2002)
6 provinces (faritany); Antananarivo, Antsiranana,
Fianarantsoa, Mahajanga, Toamasina, Toliara
coffee, vanilla, sugarcane, cloves, cocoa, rice, cassava
(tapioca), beans, bananas, peanuts; livestock products
121 (2002)
42.16 births/1,000 population (2003 est.)
People''s Armed Forces (comprising Intervention Force,
Development Force, Aeronaval [Navy and Air] Force), Gendarmerie,
Presidential Security Regiment
revenues: $553 million
expenditures: $735 million, including capital expenditures of $NA
(1998 est.)
Having discarded past socialist economic policies,
Madagascar has since the mid 1990s followed a World Bank and IMF led
policy of privatization and liberalization, which has placed the
country on a slow and steady growth path. Agriculture, including
fishing and forestry, is a mainstay of the economy, accounting for
one-fourth of GDP and employing four-fifths of the population.
Export earnings primarily are earned in the small industrial sector,
which features textile manufacturing and agriculture processing.
Deforestation and erosion, aggravated by the use of firewood as the
primary source of fuel are serious concerns. The separatist
political crisis of 2002 undermined macroeconomic stability, with
the estimated drop in output being subject to a wide margin of
error. Poverty reduction will be the centerpiece of economic policy
for the next few years.','c691e8497828ab6aa26ee8e7911ff32803c1dc8fcec8fe07968cb2432a1ed73a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c79ff1d07c99d53b9f728cd8a748887138b7868bc68bb88b2fd49132f5240ac',2003,'MW','Malawi','economy',734,'total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 4 (2002)
total: 37
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 22 (2002)
deforestation; land degradation; water pollution from
agricultural runoff, sewage, industrial wastes; siltation of
spawning grounds endangers fish populations
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
0.7% (FY02)
769.2 million kWh (2001)
715.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 3.3%
hydro: 96.7%
nuclear: 0%
other: 0% (2001)
54% (FY 90/91 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture 86% (1997 est.)
tobacco 60%, tea, sugar, cotton, coffee, peanuts, wood
products, apparel
US 17.3%, Germany 13.6%, South Africa 10.2%, Egypt 6.2%,
Japan 6%, Netherlands 5.5%, Russia 4.8%, UK 4.3% (2002)
27 districts; Balaka, Blantyre, Chikwawa, Chiradzulu,
Chitipa, Dedza, Dowa, Karonga, Kasungu, Likoma, Lilongwe, Machinga
(Kasupe), Mangochi, Mchinji, Mulanje, Mwanza, Mzimba, Ntcheu, Nkhata
Bay, Nkhotakota, Nsanje, Ntchisi, Phalombe, Rumphi, Salima, Thyolo,
Zomba
tobacco, sugarcane, cotton, tea, corn, potatoes, cassava
(tapioca), sorghum, pulses; groundnuts, Macadamia nuts; cattle, goats
43 (2002)
44.7 births/1,000 population (2003 est.)
Army (including Air Wing and Naval Detachment), Police
(including paramilitary Mobile Force Unit)
revenues: $490 million
expenditures: $523 million, including capital expenditures of $NA
(FY 99/00 est.)
Landlocked Malawi ranks among the world''s least developed
countries. The economy is predominately agricultural, with about 90%
of the population living in rural areas. Agriculture accounted for
nearly 40% of GDP and 88% of export revenues in 2001. The economy
depends on substantial inflows of economic assistance from the IMF,
the World Bank, and individual donor nations. In late 2000, Malawi
was approved for relief under the Heavily Indebted Poor Countries
(HIPC) program. In November 2002 the World Bank approved a $50
million drought recovery package, which is to be used for famine
relief. The government faces strong challenges, e.g., to fully
develop a market economy, to improve educational facilities, to face
up to environmental problems, to deal with the rapidly growing
problem of HIV/AIDS, and to satisfy foreign donors that fiscal
discipline is being tightened. The performance of the tobacco sector
is key to short-term growth as tobacco accounts for over 50% of
exports.','67519055c7d003dfa67236fe59252f7959fb792b8f432f6efb71921b696ac348','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47d49469c753dc8122538e2504f4e4a6ebf5d644d3d8eea24aeba2c062f3e4c1',2003,'MY','Malaysia','economy',735,'total: 35
over 3,047 m: 5
2,438 to 3,047 m: 5
1,524 to 2,437 m: 11
914 to 1,523 m: 7
under 914 m: 7 (2002)
total: 79
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 72 (2002)
air pollution from industrial and vehicular emissions;
water pollution from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
2.03% (FY00)
68.34 billion kWh (2001)
63.48 billion kWh (2001)
0 kWh (2001)
75 million kWh (2001)
fossil fuel: 89.5%
hydro: 10.5%
nuclear: 0%
other: 0% (2001)
8% (1998 est.)
lowest 10%: 1.7%
highest 10%: 38.4% (1997 est.)
local trade and tourism 28%, manufacturing 27%,
agriculture, forestry, and fisheries 16%, services 10%, government
10%, construction 9% (2000 est.)
electronic equipment, petroleum and liquefied natural gas,
wood and wood products, palm oil, rubber, textiles, chemicals (2000)
US 21%, Singapore 17.4%, Japan 10.9%, China 6.5%, Hong Kong
5%, Thailand 4% (2002)
13 states (negeri-negeri, singular - negeri) and 3 federal
territories* (wilayah-wilayah persekutuan, singular - wilayah
persekutuan); Johor, Kedah, Kelantan, Labuan*, Melaka, Negeri
Sembilan, Pahang, Perak, Perlis, Pulau Pinang, Putrajaya*, Sabah,
Sarawak, Selangor, Terengganu, Wilayah Persekutuan*
note: the city of Kuala Lumpur is within the federal territory of
Wilayah Persekutuan; the terms therefore are not interchangeable;
Peninsular Malaysia - rubber, palm oil, cocoa, rice; Sabah
- subsistence crops, rubber, timber, coconuts, rice; Sarawak -
rubber, pepper; timber
114 (2002)
23.7 births/1,000 population (2003 est.)
Malaysian Army, Royal Malaysian Navy, Royal Malaysian Air
Force, Royal Malaysian Police Field Force, Marine Police, Sarawak
Border Scouts
revenues: $20.3 billion
expenditures: $27.2 billion, including capital expenditures of $9.4
billion (2001 est.)
Malaysia, a middle-income country, transformed itself from
1971 through the late 1990s from a producer of raw materials into an
emerging multi-sector economy. Growth was almost exclusively driven
by exports - particularly of electronics - and, as a result Malaysia
was hard hit by the global economic downturn and the slump in the
Information Technology (IT) sector in 2001. GDP in 2001 grew only
0.5% due to an estimated 11% contraction in exports, but a
substantial fiscal stimulus package mitigated the worst of the
recession and the economy rebounded in 2002. Healthy foreign
exchange reserves and relatively small external debt make it
unlikely that Malaysia will experience a crisis similar to the one
in 1997, but the economy remains vulnerable to a more protracted
slowdown in Japan and the US, top export destinations and key
sources of foreign investment.
condensate 279 km; gas 5,047 km; oil 1,841 km; refined
products 114 km (2003)','9c97af13fdfc5e630b4256eaad6399a0153270ba81417e9cdbcd01185fe18d93','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d792ac3e380a1574fdccb8e9a2f750d3685c99ce56296c327a3b76ff0c864ae',2003,'MV','Maldives','economy',736,'total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2002)
total: 3
914 to 1,523 m: 3 (2002)
depletion of freshwater aquifers threatens water supplies;
global warming and sea level rise; coral reef bleaching
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
8.6% (FY02)
117 million kWh (2001)
108.8 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 22%, industry 18%, services 60% (1995)
fish, clothing
US 51.7%, Sri Lanka 16.2%, Thailand 9.3%, Japan 7.6%, UK
4.6% (2002)
19 atolls (atholhu, singular and plural) and 1 other
first-order administrative division*; Alifu, Baa, Dhaalu, Faafu,
Gaafu Alifu, Gaafu Dhaalu, Gnaviyani, Haa Alifu, Haa Dhaalu, Kaafu,
Laamu, Lhaviyani, Maale*, Meemu, Noonu, Raa, Seenu, Shaviyani, Thaa,
Vaavu
coconuts, corn, sweet potatoes; fish
5 (2002)
36.71 births/1,000 population (2003 est.)
National Security Service
revenues: $224 million (excluding foreign grants)
expenditures: $282 million, including capital expenditures of $80
million (2002 est.)
Tourism, Maldives largest industry, accounts for 20% of GDP
and more than 60% of the Maldives'' foreign exchange receipts. Over
90% of government tax revenue comes from import duties and
tourism-related taxes. Almost 400,000 tourists visited the islands
in 1998. Fishing is a second leading sector. The Maldivian
Government began an economic reform program in 1989 initially by
lifting import quotas and opening some exports to the private
sector. Subsequently, it has liberalized regulations to allow more
foreign investment. Agriculture and manufacturing continue to play a
lesser role in the economy, constrained by the limited availability
of cultivable land and the shortage of domestic labor. Most staple
foods must be imported. Industry, which consists mainly of garment
production, boat building, and handicrafts, accounts for about 18%
of GDP. Maldivian authorities worry about the impact of erosion and
possible global warming on their low-lying country; 80% of the area
is one meter or less above sea level.','1710fac95a672d575bf3c0a216d5aaecb29125eb4c66e53e9fcd3698a7d9c59e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ef706ff201145522ab23a034df5ff1199ec62332aa7e78877326fb5b028dfed',2003,'ML','Mali','economy',737,'total: 7
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2002)
total: 19
1,524 to 2,437 m: 6
914 to 1,523 m: 5
under 914 m: 8 (2002)
deforestation; soil erosion; desertification; inadequate
supplies of potable water; poaching
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
15% (FY02)
480.2 million kWh (2001)
446.6 million kWh (2001)
0 kWh (2001)
0 kWh; note - recent hydropower developments may be providing
electricity to Senegal and Mauritania (2001)
fossil fuel: 41.7%
hydro: 58.3%
nuclear: 0%
other: 0% (2001)
64% average; 30% of the total population living in urban areas;
70% of the total population living in rural areas) (2001 est.)
lowest 10%: 1.8%
highest 10%: 40.4% (1994)
agriculture and fishing 80% (2001 est.)
cotton, gold, livestock
Thailand 13.9%, Italy 9.8%, India 7.7%, Brazil 5.5%, Germany
5%, Spain 4.9%, Portugal 4.3%, Taiwan 4.3% (2002)
8 regions (regions, singular - region); Gao, Kayes, Kidal,
Koulikoro, Mopti, Segou, Sikasso, Tombouctou
cotton, millet, rice, corn, vegetables, peanuts; cattle, sheep,
goats
26 (2002)
47.79 births/1,000 population (2003 est.)
Army, Air Force, Gendarmerie, Republican Guard, National Guard,
National Police (Surete Nationale)
revenues: $764 million
expenditures: $828 million, including capital expenditures of $NA
(2002 est.)
Mali is among the poorest countries in the world, with 65% of
its land area desert or semidesert and with a highly unequal
distribution of income. Economic activity is largely confined to the
riverine area irrigated by the Niger. About 10% of the population is
nomadic and some 80% of the labor force is engaged in farming and
fishing. Industrial activity is concentrated on processing farm
commodities. Mali is heavily dependent on foreign aid and vulnerable
to fluctuations in world prices for cotton, its main export, along
with gold. The government has continued its successful
implementation of an IMF-recommended structural adjustment program
that is helping the economy grow, diversify, and attract foreign
investment. Mali''s adherence to economic reform and the 50%
devaluation of the African franc in January 1994 have pushed up
economic growth to a sturdy 5% average in 1996-2002. Worker
remittances and external trade routes have been jeopardized by
continued unrest in neighboring Cote d''Ivoire.','5e61492ef2bef9ea6b1848c329a314f1db83264cfb2a2386207dfc8caf696f4b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9f15e9d014518413737a4dc7f780182c07a118290ab1982d83d8a80681f6f1e',2003,'MT','Malta','economy',738,'total: 1
over 3,047 m: 1 (2002)
Man, Isle of
total: 1
1,524 to 2,437 m: 1 (2002)
very limited natural fresh water resources; increasing
reliance on desalination
Man, Isle of
waste disposal (both household and industrial);
transboundary air pollution
party to: Air Pollution, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.7% (2000)
1.768 billion kWh (2001)
1.644 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
Man, Isle of
NA%
lowest 10%: NA%
highest 10%: NA%
Man, Isle of
lowest 10%: NA%
highest 10%: NA%
industry 24%, services 71%, agriculture 5% (1999 est.)
Man, Isle of
agriculture, forestry and fishing 3%, manufacturing
11%, construction 10%, transport and communication 8%, wholesale and
retail distribution 11%, professional and scientific services 18%,
public administration 6%, banking and finance 18%, tourism 2%,
entertainment and catering 3%, miscellaneous services 10%
machinery and transport equipment, manufactures
Man, Isle of
tweeds, herring, processed shellfish, beef, lamb
Singapore 17.3%, US 11.4%, UK 9.4%, Germany 9%, France 7.2%,
China 6.5%, Italy 6% (2002)
Man, Isle of
UK (2000 est.)
none (administered directly from Valletta); note - Local
Councils carry out administrative orders
Man, Isle of
there are no first-order administrative divisions as
defined by the US Government, but there are 24 local authorities
each with its own elections
potatoes, cauliflower, grapes, wheat, barley, tomatoes,
citrus, cut flowers, green peppers; pork, milk, poultry, eggs
Man, Isle of
cereals, vegetables; cattle, sheep, pigs, poultry
1 (2002)
Man, Isle of
1 (2002)
12.75 births/1,000 population (2003 est.)
Man, Isle of
11.38 births/1,000 population (2003 est.)
Armed Forces (including land forces [with subordinate air
squadron and maritime squadron] and the Revenue Security Corps),
Maltese Police Force
revenues: $1.5 billion
expenditures: $1.6 billion, including capital expenditures of $NA
(2000)
Man, Isle of
revenues: $485 million
expenditures: $463 million, including capital expenditures of $NA
(FY00/01 est.)
Major resources are limestone, a favorable geographic
location, and a productive labor force. Malta produces only about
20% of its food needs, has limited fresh water supplies, and has no
domestic energy sources. The economy is dependent on foreign trade,
manufacturing (especially electronics and textiles), and tourism.
Malta is privatizing state-controlled firms and liberalizing markets
in order to prepare for membership in the European Union. The island
remains divided politically, however, over the question of joining
the EU. Continued sluggishness in the global economy is holding back
exports, tourism, and overall growth.
Man, Isle of
Offshore banking, manufacturing, and tourism are key
sectors of the economy. The government''s policy of offering
incentives to high-technology companies and financial institutions
to locate on the island has paid off in expanding employment
opportunities in high-income industries. As a result, agriculture
and fishing, once the mainstays of the economy, have declined in
their shares of GDP. Trade is mostly with the UK. The Isle of Man
enjoys free access to EU markets.','0a9b5f69356074b6771903483ddff0809eeb527846546b4b7aad1d8121d714d0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42690e1f5b1640dc13530b583a822e92fcdbc5a6aa6205963bf3a798cca458d9',2003,'MH','Marshall Islands','economy',739,'total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2002)
total: 11
914 to 1,523 m: 10
under 914 m: 1 (2002)
inadequate supplies of potable water; pollution of
Majuro lagoon from household waste and discharges from fishing
vessels
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
NA%
fossil fuel: 99%
hydro: 0%
nuclear: 0%
other: 1% (solar)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 21.4%, industry 20.9%, services 57.7%
copra cake, coconut oil, handicrafts, fish
US, Japan, Australia, China (2000)
33 municipalities; Ailinginae, Ailinglaplap, Ailuk,
Arno, Aur, Bikar, Bikini, Bokak, Ebon, Enewetak, Erikub, Jabat,
Jaluit, Jemo, Kili, Kwajalein, Lae, Lib, Likiep, Majuro, Maloelap,
Mejit, Mili, Namorik, Namu, Rongelap, Rongrik, Toke, Ujae, Ujelang,
Utirik, Wotho, Wotje
coconuts, tomatoes, melons, taro, breadfruit,
fruits; pigs, chickens
15 (2002)
34.18 births/1,000 population (2003 est.)
no regular military forces; Police Force
revenues: $42 million
expenditures: $40 million, including capital expenditures of $NA
(1999)
US Government assistance is the mainstay of this
tiny island economy. Agricultural production is primarily
subsistence and is concentrated on small farms; the most important
commercial crops are coconuts and breadfruit. Small-scale industry
is limited to handicrafts, tuna processing, and copra. The tourist
industry, now a small source of foreign exchange employing less than
10% of the labor force, remains the best hope for future added
income. The islands have few natural resources, and imports far
exceed exports. Under the terms of the Compact of Free Association,
the US has provided more than $1 billion in aid since 1986.
Negotiations have continued for an extended agreement. Government
downsizing, drought, a drop in construction, the decline in tourism
and foreign investment due to the Asian financial difficulties, and
less income from the renewal of fishing vessel licenses have held
GDP growth to an average of 1% over the past decade.','34bdf5f04ce51b730034e38b51073d41ea52702bc7ac58717f8b51fda9d2e7e5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0ac1a48f6aee425bd6e7ff163eae6497386cc7e972fd496c58293068ecaf71d',2003,'MQ','Martinique','economy',740,'total: 1
over 3,047 m: 1 (2002)
total: 1
under 914 m: 1 (2002)
NA
1.151 billion kWh (2001)
1.07 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 10%, industry 17%, services 73% (1997)
refined petroleum products, bananas, rum, pineapples
(2001 est.)
France 45%, Guadeloupe 28% (2000)
none (overseas department of France)
pineapples, avocados, bananas, flowers, vegetables,
sugarcane
2 (2002)
14.96 births/1,000 population (2003 est.)
no regular indigenous military forces; French Forces
(Army, Navy, Air Force), Gendarmerie
revenues: $900 million
expenditures: $2.5 billion, including capital expenditures of $140
million (1996)
The economy is based on sugarcane, bananas, tourism, and
light industry. Agriculture accounts for about 6% of GDP and the
small industrial sector for 11%. Sugar production has declined, with
most of the sugarcane now used for the production of rum. Banana
exports are increasing, going mostly to France. The bulk of meat,
vegetable, and grain requirements must be imported, contributing to
a chronic trade deficit that requires large annual transfers of aid
from France. Tourism, which employs more than 11,000 people, has
become more important than agricultural exports as a source of
foreign exchange.','3f9f4b938ff551bbdec339ddc7eb33127126d7c686b041648e06517c2c1abb4c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be2838ea3dcea874bfaeffbc3192b76a4cbc691ac548f59c57882bd94ae5d3fd',2003,'MR','Mauritania','economy',741,'total: 10
2,438 to 3,047 m: 3
1,524 to 2,437 m: 7 (2002)
total: 16
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 6
under 914 m: 3 (2002)
overgrazing, deforestation, and soil erosion aggravated
by drought are contributing to desertification; very limited natural
fresh water resources away from the Senegal, which is the only
perennial river
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
3.7% (FY02)
157.4 million kWh (2001)
146.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 85.9%
hydro: 14.1%
nuclear: 0%
other: 0% (2001)
50% (2001 est.)
lowest 10%: 2.5%
highest 10%: 30.2% (2000)
agriculture 50%, services 40%, industry 10% (2001 est.)
iron ore, fish and fish products, gold
Italy 14.3%, France 14%, Spain 11.7%, Germany 10.9%,
Belgium 9.9%, Japan 7.1% (2002)
12 regions (regions, singular - region) and 1 capital
district*; Adrar, Assaba, Brakna, Dakhlet Nouadhibou, Gorgol,
Guidimaka, Hodh Ech Chargui, Hodh El Gharbi, Inchiri, Nouakchott*,
Tagant, Tiris Zemmour, Trarza
dates, millet, sorghum, rice, corn, dates; cattle, sheep
26 (2002)
42.16 births/1,000 population (2003 est.)
Army, Navy, Air Force, National Gendarmerie, National
Guard, National Police, Presidential Guard
revenues: $421 million
expenditures: $378 million, including capital expenditures of $154
million (2002 est.)
Half the population still depends on agriculture and
livestock for a livelihood, even though many of the nomads and
subsistence farmers were forced into the cities by recurrent
droughts in the 1970s and 1980s. Mauritania has extensive deposits
of iron ore, which account for nearly 40% of total exports. The
decline in world demand for this ore, however, has led to cutbacks
in production. The nation''s coastal waters are among the richest
fishing areas in the world, but overexploitation by foreigners
threatens this key source of revenue. The country''s first deepwater
port opened near Nouakchott in 1986. In the past, drought and
economic mismanagement resulted in a buildup of foreign debt. In
February 2000, Mauritania qualified for debt relief under the
Heavily Indebted Poor Countries (HIPC) initiative and in December
2001 received strong support from donor and lending countries at a
triennial Consultative Group review. In 2001, exploratory oil wells
in tracts 80 km offshore indicated potential extraction at current
world oil prices. A new investment code approved in December 2001
improved the opportunities for direct foreign investment. Ongoing
negotiations with the IMF involve problems of economic reforms and
fiscal discipline. Substantial oil production and exports probably
will not begin until 2005.','1276fd3081dd883ff73928ef99f6fa9612d332eef64b3a89380f330c9fe934f2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89cd32efe59a4eb5e335383587ae36105c478d38a139a4f23c0fe49f91ffa5f9',2003,'MU','Mauritius','economy',742,'total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (2002)
total: 3
914 to 1,523 m: 2
under 914 m: 1 (2002)
water pollution, degradation of coral reefs
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.2% (FY02)
1.311 billion kWh (2001)
1.219 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 90.8%
hydro: 9.2%
nuclear: 0%
other: 0% (2001)
10% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
construction and industry 36%, services 24%, agriculture
and fishing 14%, trade, restaurants, hotels 16%, transportation and
communication 7%, finance 3% (1995)
clothing and textiles, sugar, cut flowers, molasses
UK 27.7%, France 25.5%, US 16.4%, Madagascar 6.2%, Belgium
5% (2002)
9 districts and 3 dependencies*; Agalega Islands*, Black
River, Cargados Carajos Shoals*, Flacq, Grand Port, Moka,
Pamplemousses, Plaines Wilhems, Port Louis, Riviere du Rempart,
Rodrigues*, Savanne
sugarcane, tea, corn, potatoes, bananas, pulses; cattle,
goats; fish
5 (2002)
16.1 births/1,000 population (2003 est.)
National Police Force (includes the paramilitary Special
Mobile Force or SMF and National Coast Guard)
revenues: $1.1 billion
expenditures: $1.2 billion, including capital expenditures of $NA
(1999 est.)
Since independence in 1968, Mauritius has developed from a
low-income, agriculturally based economy to a middle-income
diversified economy with growing industrial, financial, and tourist
sectors. For most of the period, annual growth has been in the order
of 5% to 6%. This remarkable achievement has been reflected in more
equitable income distribution, increased life expectancy, lowered
infant mortality, and a much-improved infrastructure. Sugarcane is
grown on about 90% of the cultivated land area and accounts for 25%
of export earnings. The government''s development strategy centers on
foreign investment. Mauritius has attracted more than 9,000 offshore
entities, many aimed at commerce in India and South Africa, and
investment in the banking sector alone has reached over $1 billion.
Mauritius, with its strong textile sector and responsible fiscal
management, has been well poised to take advantage of the Africa
Growth and Opportunity Act (AGOA). The government is encouraging
foreign investment in the information technology field.','228a338523110b9f4a2e7f2785c0eab0f9853b46973bdba1218ad98db85f3247','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f5ea417c3e32b8168ecf18f5f913fd7b0fb90655b22ee0e6fda90263a040ee0',2003,'YT','Mayotte','economy',743,'total: 1
1,524 to 2,437 m: 1 (2002)
NA
NA kWh
NA kWh
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0%
NA%
lowest 10%: NA%
highest 10%: NA%
ylang-ylang (perfume essence), vanilla, copra, coconuts,
coffee, cinnamon
France 80%, Comoros 15%, Reunion (2000)
none (territorial collectivity of France)
vanilla, ylang-ylang (perfume essence), coffee, copra
1 (2002)
42.86 births/1,000 population (2003 est.)
revenues: $NA
expenditures: $73 million, including capital expenditures of $NA
(1991 est.)
Economic activity is based primarily on the agricultural
sector, including fishing and livestock raising. Mayotte is not
self-sufficient and must import a large portion of its food
requirements, mainly from France. The economy and future development
of the island are heavily dependent on French financial assistance,
an important supplement to GDP. Mayotte''s remote location is an
obstacle to the development of tourism.','89ef7121bc6c1ed172bb5650b6a15a29fff770dbabab0b3479bfe3e79b5734c7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5538d4274911536edcf97b96bf1c45f90d009eb4b527d875810615d41dc9245f',2003,'MX','Mexico','economy',744,'total: 231
over 3,047 m: 11
2,438 to 3,047 m: 28
1,524 to 2,437 m: 83
914 to 1,523 m: 82
under 914 m: 27 (2002)
total: 1,592
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 69
914 to 1,523 m: 454
under 914 m: 1,067 (2002)
scarcity of hazardous waste disposal facilities; rural to
urban migration; natural fresh water resources scarce and polluted
in north, inaccessible and poor quality in center and extreme
southeast; raw sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion; desertification;
deteriorating agricultural lands; serious air and water pollution in
the national capital and urban centers along US-Mexico border; land
subsidence in Valley of Mexico caused by groundwater depletion
note: the government considers the lack of clean water and
deforestation national security issues
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1% (FY99)
Moldova
0.4% (FY02)
198.6 billion kWh (2001)
186.7 billion kWh (2001)
2.068 billion kWh (2001)
Moldova
60 million kWh (2001)
77 million kWh (2001)
Moldova
0 kWh (2001)
fossil fuel: 78.7%
hydro: 14.2%
nuclear: 4.2%
other: 2.9% (2001)
40% (2001 est.)
lowest 10%: 1.6%
highest 10%: 41.1% (2001)
agriculture 20%, industry 24%, services 56% (1998)
manufactured goods, oil and oil products, silver, fruits,
vegetables, coffee, cotton
US 82.7%, Canada 5.4%, Japan 1.1% (2002)
31 states (estados, singular - estado) and 1 federal
district* (distrito federal); Aguascalientes, Baja California, Baja
California Sur, Campeche, Chiapas, Chihuahua, Coahuila de Zaragoza,
Colima, Distrito Federal*, Durango, Guanajuato, Guerrero, Hidalgo,
Jalisco, Mexico, Michoacan de Ocampo, Morelos, Nayarit, Nuevo Leon,
Oaxaca, Puebla, Queretaro de Arteaga, Quintana Roo, San Luis Potosi,
Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz-Llave,
Yucatan, Zacatecas
corn, wheat, soybeans, rice, beans, cotton, coffee, fruit,
tomatoes; beef, poultry, dairy products; wood products
1,823 (2002)
21.92 births/1,000 population (2003 est.)
National Defense Secretariat (SEDENA) (including Army and Air
Force), Navy Secretariat (including Naval Air and Marines)
Moldova
Ground Forces (includes Air and Air Defense Forces),
Republic Security Forces (includes paramilitary Internal Troops and
Border Troops)
revenues: $136 billion
expenditures: $140 billion, including capital expenditures of $NA
(2001 est.)
Mexico has a free market economy with a mixture of modern and
outmoded industry and agriculture, increasingly dominated by the
private sector. Recent administrations have expanded competition in
seaports, railroads, telecommunications, electricity, natural gas
distribution, and airports. Income distribution remains highly
unequal. Trade with the US and Canada has tripled since the
implementation of NAFTA in 1994. Following 6.9% growth in 2000, real
GDP fell 0.3% in 2001, recovering to only a plus 1% in 2002, with
the US slowdown the principal cause. Mexico implemented free trade
agreements with Guatemala, Honduras, El Salvador, and the European
Free Trade Area in 2001, putting more than 90% of trade under free
trade agreements. Foreign direct investment reached $25 billion in
2001, of which $12.5 billion came from the purchase of Mexico''s
second-largest bank, Banamex, by Citigroup.
crude oil 28,200 km; petroleum products 10,150 km; natural
gas 13,254 km; petrochemical 1,400 km
Midway Islands
7.8 km
Moldova
gas 606 km (2003)','c937079a77d1ff6ae813ac286425383226ad13033f5bafd654193f840dfc683e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8798af4001a78334a78db38513164a135170b18fd58be908123afd71ee05741a',2003,'FM','Micronesia, Federated States of','economy',745,'total: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2002)
Midway Islands
total: 2
1,524 to 2,437 m: 2 (2002)
Moldova
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
under 914 m: 2 (2002)
total: 1
914 to 1,523 m: 1 (2002)
Moldova
total: 28
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 12 (2002)
overfishing, climate change,
pollution
Midway Islands
NA
Moldova
heavy use of agricultural chemicals, including banned
pesticides such as DDT, has contaminated soil and groundwater;
extensive soil erosion from poor farming methods
party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Moldova
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
NA kWh
Moldova
3.394 billion kWh (2001)
NA kWh
Moldova
3.216 billion kWh (2001)
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0%
Moldova
fossil fuel: 90.6%
hydro: 9.4%
nuclear: 0%
other: 0% (2001)
26.7%
Moldova
80% (2001 est.)
lowest 10%: NA%
highest 10%: NA%
Moldova
lowest 10%: 2.2%
highest 10%: 30.7% (1997)
two-thirds are government employees
Moldova
agriculture 40%, industry 14%, services 46% (1998)
fish, garments, bananas, black pepper
Moldova
foodstuffs, textiles, machinery
Japan, US, Guam (2000)
Moldova
Russia 35%, Italy 11.7%, Germany 8.8%, Ukraine 8.5%, Romania
5.7%, US 5.2%, Belarus 4.5%, Spain 4.1% (2002)
4 states; Chuuk (Truk), Kosrae
(Kosaie), Pohnpei (Ponape), Yap
Moldova
9 counties (judetele, singular - judetul), 1 municipality*
(municipiul), 1 autonomous territorial unit** (unitate teritoriala
autonoma), and 1 territorial unit*** (unitate teritoriala); Balti,
Cahul, Chisinau, Chisinau*, Edinet, Gagauzia**, Lapusna, Orhei,
Soroca, Stinga Nistrului***, Tighina, Ungheni
black pepper, tropical fruits and
vegetables, coconuts, cassava (tapioca), betel nuts, sweet potatoes;
pigs, chickens
Moldova
vegetables, fruits, wine, grain, sugar beets, sunflower
seed, tobacco; beef, milk
7 (2002)
Midway Islands
2 (2002)
Moldova
36 (2002)
26.47 births/1,000 population (2003
est.)
Moldova
14.31 births/1,000 population (2003 est.)
revenues: $161 million ($69 million
less grants)
expenditures: $160 million, including capital expenditures of $NA
(1998 est.)
Moldova
revenues: $536 million
expenditures: $594 million, including capital expenditures of $NA
(1998 est.)
Economic activity consists primarily
of subsistence farming and fishing. The islands have few mineral
deposits worth exploiting, except for high-grade phosphate. The
potential for a tourist industry exists, but the remote location, a
lack of adequate facilities, and limited air connections hinder
development. In November 2002, the country experienced a further
reduction in future revenues from the Compact of Free Association -
the agreement with the US in which Micronesia received $1.3 billion
in financial and technical assistance over a 15-year period until
2001. The country''s medium-term economic outlook appears fragile due
not only to the reduction in US assistance but also to the slow
growth of the private sector. Geographical isolation and a poorly
developed infrastructure remain major impediments to long-term
growth.
Midway Islands
The economy is based on providing support services
for the national wildlife refuge activities located on the islands.
All food and manufactured goods must be imported.
Moldova
Moldova remains a very poor country despite recent progress
from its small economic base. It enjoys a favorable climate and good
farmland but has no major mineral deposits. As a result, the economy
depends heavily on agriculture, featuring fruits, vegetables, wine,
and tobacco. Moldova must import all of its supplies of oil, coal,
and natural gas, largely from Russia. Energy shortages contributed
to sharp production declines after the breakup of the Soviet Union
in 1991. As part of an ambitious reform effort, Moldova introduced a
convertible currency, freed all prices, stopped issuing preferential
credits to state enterprises, backed steady land privatization,
removed export controls, and freed interest rates. The government
entered into agreements with the World Bank and the IMF to promote
growth and reduce poverty. The economy returned to positive growth,
of 2.1% in 2000, 6.1% in 2001, 7.2% in 2002, and 5.3% in 2003.
Further reforms will come slowly because of strong political forces
backing government controls. The economy remains vulnerable to
higher fuel prices, poor agricultural weather, and the skepticism of
foreign investors.','cfce4f92d1bbeb0d70005eadfbbbbd3626e1f81422a8022e4d2c61effd1c74bb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94fdb138828505feb9435a0e54bfc831e569ad2b48411709ba34be782fd3ad41',2003,'MN','Mongolia','economy',746,'total: 10
2,438 to 3,047 m: 9
under 914 m: 1 (2002)
total: 40
over 3,047 m: 3
2,438 to 3,047 m: 9
1,524 to 2,437 m: 13
914 to 1,523 m: 3
under 914 m: 12 (2002)
limited natural fresh water resources in some areas; the
policies of former Communist regimes promoted rapid urbanization and
industrial growth that had negative effects on the environment; the
burning of soft coal in power plants and the lack of enforcement of
environmental laws severely polluted the air in Ulaanbaatar;
deforestation, overgrazing, and the converting of virgin land to
agricultural production increased soil erosion from wind and rain;
desertification and mining activities had a deleterious effect on
the environment
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
2.2% (FY02)
2.225 billion kWh (2001)
2.194 billion kWh (2001)
196 million kWh (2001)
25 million kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
36% (2001 est.)
lowest 10%: 2.9%
highest 10%: 24.5% (1995)
primarily herding/agricultural
copper, livestock, animal products, cashmere, wool, hides,
fluorspar, other nonferrous metals
China 43.8%, US 33.6%, Russia 9.6% (2002)
21 provinces (aymguud, singular - aymag) and 1
municipality* (singular - hot); Arhangay, Bayanhongor, Bayan-Olgiy,
Bulgan, Darhan Uul, Dornod, Dornogovi, Dundgovi, Dzavhan,
Govi-Altay, Govi-Sumber, Hentiy, Hovd, Hovsgol, Omnogovi, Orhon,
Ovorhangay, Selenge, Suhbaatar, Tov, Ulaanbaatar*, Uvs
wheat, barley, potatoes, forage crops; sheep, goats,
cattle, camels, horses
50 (2002)
21.39 births/1,000 population (2003 est.)
Mongolian Armed Forces (includes General Purpose Forces,
Air and Air Defense Forces, Civil Defense Troops); note - Border
Troops are under Ministry of Justice and Home Affairs in peacetime
revenues: $386 million
expenditures: $427 million, including capital expenditures of $NA
(2002 est.)
Economic activity traditionally has been based on
agriculture and breeding of livestock. Mongolia also has extensive
mineral deposits; copper, coal, molybdenum, tin, tungsten, and gold
account for a large part of industrial production. Soviet
assistance, at its height one-third of GDP, disappeared almost
overnight in 1990-1991 at the time of the dismantlement of the USSR.
Mongolia was driven into deep recession, prolonged by the Mongolian
People''s Revolutionary Party''s (MPRP) reluctance to undertake
serious economic reform. The Democratic Coalition (DC) government
embraced free-market economics, eased price controls, liberalized
domestic and international trade, and attempted to restructure the
banking system and the energy sector. Major domestic privatization
programs were undertaken, as well as the fostering of foreign
investment through international tender of the oil distribution
company, a leading cashmere company, and banks. Reform was held back
by the ex-Communist MPRP opposition and by the political instability
brought about through four successive governments under the DC.
Economic growth picked up in 1997-1999 after stalling in 1996 due to
a series of natural disasters and declines in world prices of copper
and cashmere. In August and September 1999, the economy suffered
from a temporary Russian ban on exports of oil and oil products, and
Mongolia remains vulnerable in this sector. Mongolia joined the
World Trade Organization (WTrO) in 1997. The international donor
community pledged over $300 million per year at the Consultative
Group Meeting, held in Ulaanbaatar in June 1999. The MPRP
government, elected in July 2000, is anxious to improve the
investment climate; it must also deal with a heavy burden of
external debt. Falling prices for Mongolia''s mainly primary sector
exports, widespread opposition to privatization, and adverse effects
of weather on agriculture in early 2000 and 2001 restrained real GDP
growth in 2000-2001. Despite drought problems in 2002, GDP rose
4.0%, followed by a solid 5.0% increase in 2003. The first
applications under the land privatization law have been marked by a
number of disputes over particular sites. Russia claims Mongolia
owes it $11 billion from the old Soviet period; any settlement could
substantially increase Mongolia''s foreign debt burden.','98ab979f35405172cc46d5a36bf7d1ac46f7ef042e98d01138223138f32ef0e8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dce8b8bd57b3abaa9b7a5715403a187266c0ec9376af88e970a318c80c73ce20',2003,'MA','Morocco','economy',747,'total: 26
over 3,047 m: 11
2,438 to 3,047 m: 5
1,524 to 2,437 m: 8
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 37
2,438 to 3,047 m: 1
1,524 to 2,437 m: 11
914 to 1,523 m: 14
under 914 m: 11 (2002)
land degradation/desertification (soil erosion resulting
from farming of marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw sewage; siltation of
reservoirs; oil pollution of coastal waters
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Environmental Modification, Law of the Sea
4% (FY99)
13.35 billion kWh (2001)
14.61 billion kWh (2001)
2.2 billion kWh (2001)
0 kWh (2001)
fossil fuel: 95.4%
hydro: 4.6%
nuclear: 0%
other: 0% (2001)
19% (1999 est.)
lowest 10%: 2.6%
highest 10%: 30.9% (1998-99)
agriculture 50%, services 35%, industry 15% (1999 est.)
clothing, fish, inorganic chemicals, transistors, crude
minerals, fertilizers (including phosphates), petroleum products,
fruits, vegetables
France 26.5%, Spain 14.3%, UK 7.9%, Germany 5.8%, Italy
5.6%, US 4.8% (2002)
37 provinces and 2 wilayas*; Agadir, Al Hoceima, Azilal,
Beni Mellal, Ben Slimane, Boulemane, Casablanca*, Chaouen, El
Jadida, El Kelaa des Sraghna, Er Rachidia, Essaouira, Fes, Figuig,
Guelmim, Ifrane, Kenitra, Khemisset, Khenifra, Khouribga, Laayoune,
Larache, Marrakech, Meknes, Nador, Ouarzazate, Oujda, Rabat-Sale*,
Safi, Settat, Sidi Kacem, Tanger, Tan-Tan, Taounate, Taroudannt,
Tata, Taza, Tetouan, Tiznit; three additional provinces of Ad Dakhla
(Oued Eddahab), Boujdour, and Es Smara as well as parts of Tan-Tan
and Laayoune fall within Moroccan-claimed Western Sahara
note: as part of a 1997 decentralization/regionalization law passed
by the legislature 16 new regions (provided below) were created
although full details and scope of the reorganization are limited :
Casablanca, Chaouia-Ourdigha, Doukkala-Abda, Fes-Boulmane,
Gharb-Chrarda-Beni Hssen, Guelmim-Es Smara, Laayoune-Boujdour-Sakia
El Hamra, Marrakech-Tensift-El Haouz, Meknes-Tafilalet, Oriental,
Oued Eddahab-Lagouira, Rabat-Sale-Zemmour-Zaer, Souss-Massa-Draa,
Tadla-Azilal, Tangier-Tetouan, Taza-Al Hoceima-Taounate
barley, wheat, citrus, wine, vegetables, olives; livestock
63 (2002)
23.26 births/1,000 population (2003 est.)
Royal Armed Forces (includes Army, Navy, Air Force),
Gendarmerie, Auxiliary Forces
revenues: $13.8 billion
expenditures: $14.6 billion, including capital expenditures of $2.1
billion (2001 est.)
Morocco faces the problems typical of developing countries -
restraining government spending, reducing constraints on private
activity and foreign trade, and achieving sustainable economic
growth. Following structural adjustment programs supported by the
IMF, World Bank, and the Paris Club, the dirham is now fully
convertible for current account transactions, and reforms of the
financial sector have been implemented. Droughts depressed activity
in the key agricultural sector and contributed to a stagnant economy
in 1999 and 2000. During that time, however, Morocco reported large
foreign exchange inflows from the sale of a mobile telephone license
and partial privatization of the state-owned telecommunications
company. Favorable rainfall in 2001 led to a growth of 6.5%. Good
harvest conditions continued to support GDP growth in 2002.
Formidable long-term challenges include: servicing the external
debt; modernizing the industrial sector; preparing the economy for
freer trade with the EU and US; and improving education and
attracting foreign investment to boost living standards and job
prospects for Morocco''s youth.
gas 695 km; oil 285 km (2003)','ab5ded401a3dfe01b0f2aa2ef2ad787c8f5123276ac26136c522346ed9ababc1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eec5fdafb69246306e74f70a004b3d396f195316080d15411a5b72a2b803282',2003,'MZ','Mozambique','economy',748,'total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (2002)
total: 143
2,438 to 3,047 m: 1
1,524 to 2,437 m: 16
914 to 1,523 m: 35
under 914 m: 91 (2002)
a long civil war and recurrent drought in the hinterlands
have resulted in increased migration of the population to urban and
coastal areas with adverse environmental consequences;
desertification; pollution of surface and coastal waters; elephant
poaching for ivory is a problem
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
1% (2000 est.)
7.193 billion kWh (2001)
1.39 billion kWh (2001)
500 million kWh (2001)
5.8 billion kWh (2001)
fossil fuel: 2.9%
hydro: 97.1%
nuclear: 0%
other: 0% (2001)
70% (2001 est.)
lowest 10%: 2.5%
highest 10%: 31.7% (1997)
agriculture 81%, industry 6%, services 13% (1997 est.)
aluminum, prawns, cashews, cotton, sugar, citrus, timber;
bulk electricity
Belgium 24.3%, South Africa 9.1%, Germany 6.2% (2002)
10 provinces (provincias, singular - provincia), 1 city*;
Cabo Delgado, Gaza, Inhambane, Manica, Maputo, Maputo City*,
Nampula, Niassa, Sofala, Tete, Zambezia
cotton, cashew nuts, sugarcane, tea, cassava (tapioca),
corn, coconuts, sisal, citrus and tropical fruits, potatoes,
sunflowers; beef, poultry
165 (2002)
38.2 births/1,000 population (2003 est.)
Army, Naval Command, Air and Air Defense Forces, Special
Forces, Militia
revenues: $393.1 million
expenditures: $1.025 billion, including capital expenditures of
$479.4 million (2001 est.)
At independence in 1975, Mozambique was one of the
world''s poorest countries. Socialist mismanagement and a brutal
civil war from 1977-92 exacerbated the situation. In 1987, the
government embarked on a series of macroeconomic reforms designed to
stabilize the economy. These steps, combined with donor assistance
and with political stability since the multi-party elections in
1994, have led to dramatic improvements in the country''s growth
rate. Inflation was brought to single digits during the late 1990s
although it returned to double digits in 2000-02. Fiscal reforms,
including the introduction of a value-added tax and reform of the
customs service, have improved the government''s revenue collection
abilities. In spite of these gains, Mozambique remains dependent
upon foreign assistance for much of its annual budget, and the
majority of the population remains below the poverty line.
Subsistence agriculture continues to employ the vast majority of the
country''s workforce. A substantial trade imbalance persists although
the opening of the MOZAL aluminum smelter, the country''s largest
foreign investment project to date has increased export earnings.
Additional investment projects in titanium extraction and processing
and garment manufacturing should further close the import/export
gap. Mozambique''s once substantial foreign debt has been reduced
through forgiveness and rescheduling under the IMF''s Heavily
Indebted Poor Countries (HIPC) and Enhanced HIPC initiatives, and is
now at a manageable level.
gas 189 km; refined products 292 km (2003)','4952aedb9db284bb7969691c20eb5c1a03ea0983ba8936deff8bac1e172fc0b3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4f9a9eb9fb4c33bd1fa4fbc6165bd55845afc6540cb2c84bb9a5e26a57fc98',2003,'NA','Namibia','economy',749,'total: 21
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 13
914 to 1,523 m: 4 (2002)
total: 114
2,438 to 3,047 m: 2
1,524 to 2,437 m: 22
914 to 1,523 m: 71
under 914 m: 19 (2002)
very limited natural fresh water resources; desertification;
wildlife poaching; land degradation has led to few conservation areas
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
2.4% (FY02)
26.95 million kWh (2001)
603.1 million kWh (2001)
578 million kWh; note - electricity supplied by South Africa
(2001)
0 kWh (2001)
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0%
50% (2002 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture 47%, industry 20%, services 33% (1999 est.)
diamonds, copper, gold, zinc, lead, uranium; cattle,
processed fish, karakul skins
EU 79%, US 4% (2001)
13 regions; Caprivi, Erongo, Hardap, Karas, Khomas, Kunene,
Ohangwena, Okavango, Omaheke, Omusati, Oshana, Oshikoto, Otjozondjupa
millet, sorghum, peanuts; livestock; fish
135 (2002)
34.1 births/1,000 population (2003 est.)
National Defense Force (Army, including Air Wing), Police
revenues: $883 million
expenditures: $950 million, including capital expenditures of $NA
(1998)
The economy is heavily dependent on the extraction and
processing of minerals for export. Mining accounts for 20% of GDP.
Rich alluvial diamond deposits make Namibia a primary source for
gem-quality diamonds. Namibia is the fourth-largest exporter of
nonfuel minerals in Africa, the world''s fifth-largest producer of
uranium, and the producer of large quantities of lead, zinc, tin,
silver, and tungsten. The mining sector employs only about 3% of the
population while about half of the population depends on subsistence
agriculture for its livelihood. Namibia normally imports about 50%
of its cereal requirements; in drought years food shortages are a
major problem in rural areas. A high per capita GDP, relative to the
region, hides the great inequality of income distribution; nearly
one-third of Namibians had annual incomes of less than $1400 in
constant 1994 dollars, according to a 1993 study. The Namibian
economy is closely linked to South Africa with the Namibian dollar
pegged to the South African rand. Privatization of several
enterprises in coming years may stimulate long-run foreign
investment.','ae05b5eea6696364551be02e326e3e1ee7ba3dc2b2c104fc67cb504525463fee','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83e3c4d199d2d202b5cfabeba822a3a8c4d68f5277948ce70a9c5660c85a5fd8',2003,'NR','Nauru','economy',750,'total: 1
1,524 to 2,437 m: 1 (2002)
limited natural fresh water resources, roof storage tanks
collect rainwater, but mostly dependent on a single, aging
desalination plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and NZ consortium - has left the
central 90% of Nauru a wasteland and threatens limited remaining
land resources
Navassa Island
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
NA%
30 million kWh (2001)
27.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
employed in mining phosphates, public administration,
education, and transportation
phosphates
India 46.1%, South Korea 18.3%, Australia 10.6%, New Zealand
7.8%, Netherlands 5.6% (2002)
14 districts; Aiwo, Anabar, Anetan, Anibare, Baiti, Boe,
Buada, Denigomodu, Ewa, Ijuw, Meneng, Nibok, Uaboe, Yaren
coconuts
1 (2002)
26.09 births/1,000 population (2003 est.)
no regular military forces; Nauru Police Force
revenues: $23.4 million
expenditures: $64.8 million, including capital expenditures of $NA
(FY 95/96)
Revenues of this tiny island have come from exports of
phosphates, but reserves are expected to be exhausted within a few
years. Phosphate production has declined since 1989, as demand has
fallen in traditional markets and as the marginal cost of extracting
the remaining phosphate increases, making it less internationally
competitive. While phosphates have given Nauruans one of the highest
per capita incomes in the Third World, few other resources exist
with most necessities being imported, including fresh water from
Australia. The rehabilitation of mined land and the replacement of
income from phosphates are serious long-term problems. In
anticipation of the exhaustion of Nauru''s phosphate deposits,
substantial amounts of phosphate income have been invested in trust
funds to help cushion the transition and provide for Nauru''s
economic future. The government has been borrowing heavily from the
trusts to finance fiscal deficits. To cut costs the government has
called for a freeze on wages, a reduction of over-staffed public
service departments, privatization of numerous government agencies,
and closure of some overseas consulates. In recent years Nauru has
encouraged the registration of offshore banks and corporations. Tens
of billions of dollars have been channeled through their accounts.
Few comprehensive statistics on the Nauru economy exist, with
estimates of Nauru''s GDP varying widely.
Navassa Island
no economic activity','4c758ce2f626ede041690ccf0cc8f7bd5b2a0c4f7c163b9938175bd776adbff8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a065dfd4f679a563ae6167bb8e6b1c4898b90f5c0594adcbd7e6fc5599c6cbd',2003,'NP','Nepal','economy',751,'total: 9
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 7 (2002)
total: 36
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 28 (2002)
deforestation (overuse of wood for fuel and lack of
alternatives); contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Marine Dumping, Marine Life Conservation
1.1% (FY02)
1.755 billion kWh (2001)
1.764 billion kWh (2001)
227 million kWh (2001)
95 million kWh (2001)
fossil fuel: 8.5%
hydro: 91.5%
nuclear: 0%
other: 0% (2001)
42% (1995-96)
lowest 10%: 3.2%
highest 10%: 29.8% (1995-96)
agriculture 81%, services 16%, industry 3%
carpets, clothing, leather goods, jute goods, grain
India 47.5%, US 27.6%, Germany 7.5% (2002)
14 zones (anchal, singular and plural); Bagmati, Bheri,
Dhawalagiri, Gandaki, Janakpur, Karnali, Kosi, Lumbini, Mahakali,
Mechi, Narayani, Rapti, Sagarmatha, Seti
rice, corn, wheat, sugarcane, root crops; milk, water buffalo
meat
45 (2002)
32.46 births/1,000 population (2003 est.)
Royal Nepalese Army (includes Royal Nepalese Army Air
Service), Nepalese Police Force
revenues: $665 million
expenditures: $1.1 billion, including capital expenditures of $NA
(FY 99/00 est.)
Nepal is among the poorest and least developed countries in
the world with 42% of its population living below the poverty line.
Agriculture is the mainstay of the economy, providing a livelihood
for over 80% of the population and accounting for 40% of GDP.
Industrial activity mainly involves the processing of agricultural
produce including jute, sugarcane, tobacco, and grain. Textile and
carpet production, accounting for about 80% of foreign exchange
earnings in recent years, contracted in 2001-02 due to the overall
slowdown in the world economy and pressures by Maoist insurgents on
factory owners and workers. Security concerns in the wake of the
Maoist conflict and the September 11, 2001 terrorist attacks in the
US have led to a decrease in tourism, another key source of foreign
exchange. Since 1991, the government has been moving forward with
economic reforms, e.g., by reducing business licenses and
registration requirements to simplify investment procedures,
reducing subsidies, privatizing state industries, and laying off
civil servants. Nepal has considerable scope for exploiting its
potential in hydropower and tourism, areas of recent foreign
investment interest. Prospects for foreign trade or investment in
other sectors will remain poor, however, because of the small size
of the economy, its technological backwardness, its remoteness, its
landlocked geographic location, and its susceptibility to natural
disaster. The international community''s role of funding more than
60% of Nepal''s development budget and more than 28% of total
budgetary expenditures will likely continue as a major ingredient of
growth.','1563be538a4f9761a5b37704dfc14b308b1095a37efdd7cbbda282c70c9a35bf','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bc3a730ee20459a1d5271a75ad69242380c8606a7e50cbfc72086893515c7e6',2003,'NL','Netherlands','economy',752,'total: 21
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 2 (2002)
Netherlands Antilles
total: 5
over 3,047 m: 1
2038 to 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2002)
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2002)
water pollution in the form of heavy metals, organic
compounds, and nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Netherlands Antilles
NA
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur
85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Kyoto Protocol, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
1.5% (FY00/01 est.)
88.32 billion kWh (2001)
Netherlands Antilles
1.061 billion kWh (2001)
99.42 billion kWh (2001)
Netherlands Antilles
986.8 million kWh (2001)
21.49 billion kWh (2001)
Netherlands Antilles
0 kWh (2001)
4.209 billion kWh (2001)
Netherlands Antilles
0 kWh (2001)
fossil fuel: 89.9%
hydro: 0.1%
nuclear: 4.3%
other: 5.7% (2001)
Netherlands Antilles
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
Netherlands Antilles
NA%
lowest 10%: 2.8%
highest 10%: 25.1% (1994)
Netherlands Antilles
lowest 10%: NA%
highest 10%: NA%
services 73%, industry 23%, agriculture 4% (1998 est.)
Netherlands Antilles
agriculture 1%, industry 13%, services 86%
(2000 est.)
machinery and equipment, chemicals, fuels; foodstuffs
Netherlands Antilles
petroleum products
Germany 25.1%, Belgium 12.7%, UK 10.7%, France 10.2%,
Italy 6%, US 4.6% (2002)
Netherlands Antilles
US 20.9%, Guatemala 12%, Venezuela 10.5%,
Guyana 6.6%, Singapore 4.4%, Cuba 4% (2002)
12 provinces (provincies, singular - provincie);
Drenthe, Flevoland, Friesland, Gelderland, Groningen, Limburg,
Noord-Brabant, Noord-Holland, Overijssel, Utrecht, Zeeland,
Zuid-Holland
Netherlands Antilles
none (part of the Kingdom of the Netherlands)
note: each island has its own government
grains, potatoes, sugar beets, fruits, vegetables;
livestock
Netherlands Antilles
aloes, sorghum, peanuts, vegetables, tropical
fruit
28 (2002)
Netherlands Antilles
5 (2002)
11.31 births/1,000 population (2003 est.)
Netherlands Antilles
15.76 births/1,000 population (2003 est.)
Royal Netherlands Army, Royal Netherlands Navy
(including Naval Air Service and Marine Corps), Royal Netherlands
Air Force, Royal Constabulary
Netherlands Antilles
no regular indigenous military forces; Royal
Netherlands Navy, Marine Corps, Royal Netherlands Air Force,
National Guard, Police Force
revenues: $134 billion
expenditures: $134 billion, including capital expenditures of $NA
(2001 est.)
Netherlands Antilles
revenues: $710.8 million
expenditures: $741.6 million, including capital expenditures of $NA
(1997 est.)
The Netherlands is a prosperous and open economy
depending heavily on foreign trade. The economy is noted for stable
industrial relations, moderate unemployment and inflation, a sizable
current account surplus, and an important role as a European
transportation hub. Industrial activity is predominantly in food
processing, chemicals, petroleum refining, and electrical machinery.
A highly mechanized agricultural sector employs no more than 4% of
the labor force but provides large surpluses for the food-processing
industry and for exports. The Netherlands, along with 11 of its EU
partners, began circulating the euro currency on 1 January 2002. The
country continues to be one of the leading European nations for
attracting foreign direct investment. Economic growth slowed
considerably in 2001-03, as part of the global economic slowdown,
but for the four years before that, annual growth averaged nearly
4%, well above the EU average. The government is wrestling with a
deteriorating budget position, and is moving toward the EU 3% limit.
Netherlands Antilles
Tourism, petroleum refining, and offshore
finance are the mainstays of this small economy, which is closely
tied to the outside world. Although GDP has declined or remained
even in each of the past six years, the islands enjoy a high per
capita income and a well-developed infrastructure compared with
other countries in the region. Almost all consumer and capital goods
are imported, the US and Mexico being the major suppliers. Poor
soils and inadequate water supplies hamper the development of
agriculture.
condensate 325 km; gas 6,998 km; oil 590 km; refined
products 716 km (2003)','31dd7df6032130e8b22584da96b4374b78a8a77634d0e550dc8e35875342e2fc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51c2065ebfb6cd5a2333d458fe8ce962ce30f409bfa4f80f439ff238901f625f',2003,'NC','New Caledonia','economy',753,'total: 9
over 3,047 m: 1
914 to 1,523 m: 6
under 914 m: 2 (2002)
total: 21
914 to 1,523 m: 12
under 914 m: 9 (2002)
erosion caused by mining exploitation and forest fires
5.3% (FY96)
1.613 billion kWh (2001)
1.5 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 76.3%
hydro: 23.7%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 7%, industry 23%, services 70% (1999 est.)
ferronickels, nickel ore, fish
Japan 20.6%, France 20.4%, Taiwan 16.3%, South Africa
11.3%, Spain 7.7%, South Korea 5.4%, Australia 5.4%, Italy 5.3%
(2002)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 3 provinces named Iles Loyaute, Nord, and
Sud
vegetables; beef, deer, other livestock products
30 (2002)
19.45 births/1,000 population (2003 est.)
no regular indigenous military forces; French Armed
Forces (including Army, Navy, Air Force, Gendarmerie); Police Force
revenues: $861.3 million
expenditures: $735.3 million, including capital expenditures of $52
million (1996 est.)
New Caledonia has about 25% of the world''s known
nickel resources. Only a small amount of the land is suitable for
cultivation, and food accounts for about 20% of imports. In addition
to nickel, substantial financial support from France - equal to more
than one-fourth of GDP - and tourism are keys to the health of the
economy. Substantial new investment in the nickel industry, combined
with the recovery of global nickel prices, brightens the economic
outlook for the next several years.','76be7326283fea87458412657ab441fe18026a312eba2ebdb83e91b84baa2e6b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4345a6d09dc1dc3f2b0ed1ea570bcedcfeabd8d9307b6766b3f5a2b5e13c3963',2003,'NZ','New Zealand','economy',754,'total: 46
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 28
under 914 m: 5 (2002)
total: 67
1,524 to 2,437 m: 2
914 to 1,523 m: 26
under 914 m: 39 (2002)
deforestation; soil erosion; native flora and fauna
hard-hit by species introduced from outside
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic Seals, Climate Change-Kyoto
Protocol, Marine Life Conservation
1% (FY02)
37.51 billion kWh (2001)
34.88 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 31.6%
hydro: 57.8%
nuclear: 0%
other: 10.7% (2001)
NA%
lowest 10%: 0.3%
highest 10%: 29.8% (1991 est.)
services 65%, industry 25%, agriculture 10% (1995)
dairy products, meat, wood and wood products, fish,
machinery
Australia 20.3%, US 15.5%, Japan 11.5%, UK 4.8%, China
4.6%, South Korea 4.4% (2002)
16 regions; Auckland, Bay of Plenty, Canterbury,
Gisborne, Hawke''s Bay, Marlborough, Nelson, Northland, Otago,
Southland, Taranaki, Tasman, Waikato, Manawatu-Wanganui, Wellington,
West Coast
wheat, barley, potatoes, pulses, fruits, vegetables;
wool, beef, dairy products; fish
113 (2002)
14.14 births/1,000 population (2003 est.)
New Zealand Army, Royal New Zealand Navy, Royal New
Zealand Air Force
revenues: $29.2 billion
expenditures: $31.2 billion, including capital expenditures of $NA
(2002)
Since 1984 the government has accomplished major
economic restructuring, transforming New Zealand from an agrarian
economy dependent on concessionary British market access to a more
industrialized, free market economy that can compete globally. This
dynamic growth has boosted real incomes (but left behind many at the
bottom of the ladder), broadened and deepened the technological
capabilities of the industrial sector, and contained inflationary
pressures. While per capita incomes have been rising, however, they
remain below the level of the four largest EU economies, and there
is some government concern that New Zealand is not closing the gap.
New Zealand is heavily dependent on trade - particularly in
agricultural products - to drive growth, and it has been affected by
the global economic slowdown and the slump in commodity prices. Thus
far the New Zealand economy has been relatively resilient, although
growth may slow to 2.5% in 2003.
gas 2,213 km; liquid petroleum gas 79 km; oil 160 km;
refined products 304 km (2003)','5ffb13e65916b03d495ba2bf5f1b3b57d0a42e30339cbee7c68e59c9448aaaab','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9efb0ede00910dbf4fdc27c714125ea55fb18c79dc1638127bdc15cd4eada333',2003,'NI','Nicaragua','economy',755,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2002)
total: 165
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 141 (2002)
deforestation; soil erosion; water pollution
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.2% (FY98)
2.549 billion kWh (2001)
2.388 billion kWh (2001)
17 million kWh (2001)
0 kWh (2001)
fossil fuel: 83.9%
hydro: 7.7%
nuclear: 0%
other: 8.4% (2001)
50% (2001 est.)
lowest 10%: 0.7%
highest 10%: 48.8% (1998)
services 43%, agriculture 42%, industry 15% (1999 est.)
coffee, shrimp and lobster, cotton, tobacco, bananas,
beef, sugar, gold
US 59.4%, El Salvador 7.5%, Honduras 4.8% (2002)
15 departments (departamentos, singular - departamento)
and 2 autonomous regions* (regiones autonomistas, singular - region
autonomista); Atlantico Norte*, Atlantico Sur*, Boaco, Carazo,
Chinandega, Chontales, Esteli, Granada, Jinotega, Leon, Madriz,
Managua, Masaya, Matagalpa, Nueva Segovia, Rio San Juan, Rivas
coffee, bananas, sugarcane, cotton, rice, corn, tobacco,
sesame, soya, beans; beef, veal, pork, poultry, dairy products
176 (2002)
26.29 births/1,000 population (2003 est.)
Army, Navy, Air Force
revenues: $726 million
expenditures: $908 million, including capital expenditures of $NA
(2000 est.)
Nicaragua, one of the hemisphere''s poorest countries,
faces low per capita income, flagging socio-economic indicators, and
huge external debt. Distribution of income is one of the most
unequal on the globe. While the country has made progress toward
macroeconomic stability over the past few years, a banking crisis
and scandal has shaken the economy. Nicaragua will continue to be
dependent on international aid and debt relief under the Heavily
Indebted Poor Countries (HIPC) initiative. Donors have made aid
conditional on the openness of government financial operation,
poverty alleviation, and human rights. Nicaragua met the conditions
for additional debt service relief in December 2000. Growth should
move up moderately in 2003 because of increased private investment
and exports.
oil 54 km (2003)','b0b7402afa6de1abf33d0281aa4de277fc8812390143c51bd9e84d17499442b5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed9106b5e9d26b93724e015894fea416a373db242ef14968379155348afeb1dd',2003,'NE','Niger','economy',756,'total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
under 914 m: 1 (2002)
total: 18
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 2 (2002)
overgrazing; soil erosion; deforestation; desertification;
wildlife populations (such as elephant, hippopotamus, giraffe, and
lion) threatened because of poaching and habitat destruction
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Law of the
Sea
1.1% (FY02)
242 million kWh (2001)
325.1 million kWh (2001)
100 million kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
63% (1993 est.)
lowest 10%: 0.8%
highest 10%: 35.4% (1995)
agriculture 90%, industry and commerce 6%, government 4%
uranium ore, livestock, cowpeas, onions
France 39%, Nigeria 33.2%, Japan 17.1% (2002)
7 departments (departements, singular - departement) and 1
capital district* (capitale district); Agadez, Diffa, Dosso, Maradi,
Niamey*, Tahoua, Tillaberi, Zinder
cowpeas, cotton, peanuts, millet, sorghum, cassava (tapioca),
rice; cattle, sheep, goats, camels, donkeys, horses, poultry
27 (2002)
49.54 births/1,000 population (2003 est.)
Army, Air Force, Gendarmerie, National Intervention and
Security Force
revenues: $320 million - including $134 million from foreign
sources
expenditures: $320 million, including capital expenditures of $178
million (2002 est.)
Niger is a poor, landlocked Sub-Saharan nation, whose economy
centers on subsistence agriculture, animal husbandry, and reexport
trade, and increasingly less on uranium, because of declining world
demand. The 50% devaluation of the West African franc in January
1994 boosted exports of livestock, cowpeas, onions, and the products
of Niger''s small cotton industry. The government relies on bilateral
and multilateral aid - which was suspended following the April 1999
coup d''etat - for operating expenses and public investment. In
2000-01, the World Bank approved a structural adjustment loan of
$105 million to help support fiscal reforms. However, reforms could
prove difficult given the government''s bleak financial situation.
The IMF approved a $73 million poverty reduction and growth facility
for Niger in 2000 and announced $115 million in debt relief under
the Heavily Indebted Poor Countries (HIPC) initiative. Further
disbursements of aid occurred in 2002. Future growth may be
sustained by exploitation of oil, gold, coal, and other mineral
resources.','cb20211185d239747b25fb0ab7b909576211ae7847b24429a042fc48d204cbfd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b11028c7f57e87a75ba3404599bc550d820b8991fea2528024692e3a72bd5b5',2003,'NG','Nigeria','economy',757,'total: 36
over 3,047 m: 7
2,438 to 3,047 m: 10
1,524 to 2,437 m: 10
914 to 1,523 m: 6
under 914 m: 3 (2002)
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 18 (2002)
soil degradation; rapid deforestation; urban air and water
pollution; desertification; oil pollution - water, air, and soil;
has suffered serious damage from oil spills; loss of arable land;
rapid urbanization
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
1% (FY02)
15.67 billion kWh (2001)
14.55 billion kWh (2001)
0 kWh (2001)
20 million kWh (2001)
fossil fuel: 61.9%
hydro: 38.1%
nuclear: 0%
other: 0% (2001)
60% (2000 est.)
lowest 10%: 1.6%
highest 10%: 40.8% (1996-97)
agriculture 70%, industry 10%, services 20% (1999 est.)
petroleum and petroleum products 95%, cocoa, rubber
US 32.3%, Brazil 8.3%, Spain 7.2%, Indonesia 5.9%, France
5.6%, India 4.6% (2002)
36 states and 1 territory*; Abia, Abuja Federal Capital
Territory*, Adamawa, Akwa Ibom, Anambra, Bauchi, Bayelsa, Benue,
Borno, Cross River, Delta, Ebonyi, Edo, Ekiti, Enugu, Gombe, Imo,
Jigawa, Kaduna, Kano, Katsina, Kebbi, Kogi, Kwara, Lagos, Nassarawa,
Niger, Ogun, Ondo, Osun, Oyo, Plateau, Rivers, Sokoto, Taraba, Yobe,
Zamfara
cocoa, peanuts, palm oil, corn, rice, sorghum, millet,
cassava (tapioca), yams, rubber; cattle, sheep, goats, pigs; timber;
fish
70 (2002)
38.75 births/1,000 population (2003 est.)
Army, Navy, Air Force, Police Force
revenues: $3.4 billion
expenditures: $3.6 billion, including capital expenditures of $NA
(2000 est.)
The oil-rich Nigerian economy, long hobbled by political
instability, corruption, and poor macroeconomic management, is
undergoing substantial reform under the new civilian administration.
Nigeria''s former military rulers failed to diversify the economy
away from overdependence on the capital-intensive oil sector, which
provides 20% of GDP, 95% of foreign exchange earnings, and about 65%
of budgetary revenues. The largely subsistence agricultural sector
has failed to keep up with rapid population growth, and Nigeria,
once a large net exporter of food, now must import food. Following
the signing of an IMF stand-by agreement in August 2000, Nigeria
received a debt-restructuring deal from the Paris Club and a $1
billion credit from the IMF, both contingent on economic reforms.
The agreement was allowed to expire by the IMF in November 2001,
however, and Nigeria apparently received much less multilateral
assistance than expected in 2002. Nonetheless, increases in foreign
oil investment and oil production kept growth at 3% in 2002. The
government lacks the strength to implement the market-oriented
reforms urged by the IMF, such as modernization of the banking
system; to curb inflation by blocking excessive wage demands; and to
resolve regional disputes over the distribution of earnings from the
oil industry. When the uncertainties in the global economy are added
in, estimates of Nigeria''s prospects for 2003 must have a wide
margin of error.
condensate 105 km; gas 1,660 km; oil 3,634 km (2003)','daf8acc68b5e4c9623bb9f290da75ba1d619874d93cb8e90e10a67536e1ab178','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31a052eecddb9eb3178f2dcdf1e1d43f5514a65e0c7d80b51a92570a8ef52b85',2003,'NU','Niue','economy',758,'total: 1
1,524 to 2,437 m: 1 (2002)
increasing attention to conservationist practices to counter
loss of soil fertility from traditional slash and burn agriculture
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification
signed, but not ratified: Law of the Sea
3 million kWh (2001)
2.79 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
most work on family plantations; paid work exists only in
government service, small industry, and the Niue Development Board
canned coconut cream, copra, honey, vanilla, passion fruit
products, pawpaws, root crops, limes, footballs, stamps, handicrafts
NZ mainly, Fiji, Cook Islands, Australia (2000)
none; note - there are no first-order administrative divisions
as defined by the US Government, but there are 14 villages at the
second order
coconuts, passion fruit, honey, limes, taro, yams, cassava
(tapioca), sweet potatoes; pigs, poultry, beef cattle
1 (2002)
NA births/1,000 population (2003 est.)
no regular indigenous military forces; Police Force
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
The economy suffers from the typical Pacific island problems of
geographic isolation, few resources, and a small population.
Government expenditures regularly exceed revenues, and the shortfall
is made up by critically needed grants from New Zealand that are
used to pay wages to public employees. Niue has cut government
expenditures by reducing the public service by almost half. The
agricultural sector consists mainly of subsistence gardening,
although some cash crops are grown for export. Industry consists
primarily of small factories to process passion fruit, lime oil,
honey, and coconut cream. The sale of postage stamps to foreign
collectors is an important source of revenue. The island in recent
years has suffered a serious loss of population because of migration
of Niueans to New Zealand. Efforts to increase GDP include the
promotion of tourism and a financial services industry, although
Premier LAKATANI announced in February 2002 that Niue will shut down
the offshore banking industry. Economic aid from New Zealand in 2002
was about $2.6 million.','23da4e9b6ee2da9e22deb16bf6c3d52423840659d55d4204fb15925a0d3757ef','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58e924f3594e1ed01737994ce673977170dbe749c9fa5969c5d98d5d0c18f20d',2003,'NF','Norfolk Island','economy',759,'total: 1
1,524 to 2,437 m: 1 (2002)
NA
NA kWh
NA kWh
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0% (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
tourism NA%, subsistence agriculture NA%
postage stamps, seeds of the Norfolk Island pine and
Kentia palm, small quantities of avocados
Australia, other Pacific island countries, NZ, Asia,
Europe
none (territory of Australia)
Norfolk Island pine seed, Kentia palm seed, cereals,
vegetables, fruit; cattle, poultry
1 (2002)
NA births/1,000 population (2003 est.)
revenues: $4.6 million
expenditures: $4.8 million, including capital expenditures of $NA
(FY 92/93)
Tourism, the primary economic activity, has steadily
increased over the years and has brought a level of prosperity
unusual among inhabitants of the Pacific islands. The agricultural
sector has become self-sufficient in the production of beef,
poultry, and eggs.','12f40f9b03a1e5d9a532dd1214b728cf1c5e89b1404b22da3eca00549e8bf339','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce5100b4499741f9b630a32fcbdac385b1501b5c8bff7ebd06132e61fae78010',2003,'MP','Northern Mariana Islands','economy',760,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2002)
total: 3
2,438 to 3,047 m: 1
under 914 m: 2 (2002)
contamination of groundwater on Saipan may
contribute to disease; clean-up of landfill; protection of
endangered species conflicts with development
NA kWh
NA kWh
0 kWh
0 kWh
NA%
lowest 10%: NA%
highest 10%: NA%
NA
garments
US (2000)
none (commonwealth in political union with
the US); there are no first-order administrative divisions as
defined by the US Government, but there are four municipalities at
the second order; Northern Islands, Rota, Saipan, Tinian
coconuts, fruits, vegetables; cattle
6 (2002)
19.97 births/1,000 population (2003 est.)
revenues: $193 million
expenditures: $223 million, including capital expenditures of NA (FY
01/02 est.)
The economy benefits substantially from
financial assistance from the US. The rate of funding has declined
as locally generated government revenues have grown. The key tourist
industry employs about 50% of the work force and accounts for
roughly one-fourth of GDP. Japanese tourists predominate. Annual
tourist entries have exceeded one-half million in recent years, but
financial difficulties in Japan have caused a temporary slowdown.
The agricultural sector is made up of cattle ranches and small farms
producing coconuts, breadfruit, tomatoes, and melons. Garment
production is by far the most important industry with employment of
17,500 mostly Chinese workers and sizable shipments to the US under
duty and quota exemptions.','abcfcace50949ed5036740ae7c99cb102bbebf095662726bfb03472e81802e38','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('137b547a42308c1477373a8e172eb25e477781c9ece9dd1146583b1b8141b132',2003,'NO','Norway','economy',761,'total: 66
2,438 to 3,047 m: 13
1,524 to 2,437 m: 13
914 to 1,523 m: 14
under 914 m: 26 (2002)
total: 36
914 to 1,523 m: 7
under 914 m: 29 (2002)
water pollution; acid rain damaging forests and adversely
affecting lakes, threatening fish stocks; air pollution from vehicle
emissions
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
2.13% (2002)
120.1 billion kWh (2001)
115.3 billion kWh (2001)
10.76 billion kWh (2001)
7.162 billion kWh (2001)
fossil fuel: 0.4%
hydro: 99.3%
nuclear: 0%
other: 0.4% (2001)
NA%
lowest 10%: 4.1%
highest 10%: 21.8% (1995)
services 74%, industry 22%, agriculture, forestry, and
fishing 4% (1995)
petroleum and petroleum products, machinery and equipment,
metals, chemicals, ships, fish
UK 18.1%, Germany 13.8%, France 11%, US 9.2%, Netherlands
8.2%, Sweden 8% (2002)
19 provinces (fylker, singular - fylke); Akershus,
Aust-Agder, Buskerud, Finnmark, Hedmark, Hordaland, More og Romsdal,
Nordland, Nord-Trondelag, Oppland, Oslo, Ostfold, Rogaland, Sogn og
Fjordane, Sor-Trondelag, Telemark, Troms, Vest-Agder, Vestfold
barley, wheat, potatoes; pork, beef, veal, milk; fish
102 (2002)
12.17 births/1,000 population (2003 est.)
Norwegian Army, Royal Norwegian Navy (including Coast
Artillery and Coast Guard), Royal Norwegian Air Force, Home Guard
revenues: $71.7 billion
expenditures: $57.6 billion, including capital expenditures of $NA
(2000 est.)
The Norwegian economy is a prosperous bastion of welfare
capitalism, featuring a combination of free market activity and
government intervention. The government controls key areas, such as
the vital petroleum sector (through large-scale state enterprises).
The country is richly endowed with natural resources - petroleum,
hydropower, fish, forests, and minerals - and is highly dependent on
its oil production and international oil prices; in 1999, oil and
gas accounted for 35% of exports. Only Saudi Arabia and Russia
export more oil than Norway. Norway opted to stay out of the EU
during a referendum in November 1994. The government has moved ahead
with privatization. With arguably the highest quality of life
worldwide, Norwegians still worry about that time in the next two
decades when the oil and gas begin to run out. Accordingly, Norway
has been saving its oil-boosted budget surpluses in a Government
Petroleum Fund, which is invested abroad and now is valued at more
than $43 billion. GDP growth was a lackluster 1% in 2002 and 2003
against the background of a faltering European economy.
condensate 411 km; gas 6,199 km; oil 2,213 km; oil/gas/water
746 km; unknown (oil/water) 38 km; water 96 km (2003)','6d625a766b4bbdab69683d722b052fd7232d7e441e9ea2a83d25c05b0eeccd6d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9950b21d02b605136114c88aaca700902e9bd43e57be13672064c41fd792b455',2003,'OM','Oman','economy',762,'total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2002)
total: 133
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 55
914 to 1,523 m: 37
under 914 m: 32 (2002)
rising soil salinity; beach pollution from oil spills; very
limited natural fresh water resources
Pacific Ocean
endangered marine species include the dugong, sea
lion, sea otter, seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
12.2% (FY01)
9.274 billion kWh (2001)
8.625 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
petroleum, reexports, fish, metals, textiles
Japan 20.5%, South Korea 18.5%, China 14.1%, Thailand 11.7%,
UAE 9.2%, Singapore 4.3%, US 4.1% (2002)
6 regions (mintaqat, singular - mintaqah) and 2 governorates*
(muhafazat, singular - muhafazah) Ad Dakhiliyah, Al Batinah, Al
Wusta, Ash Sharqiyah, Az Zahirah, Masqat, Musandam*, Zufar*; note -
the US Embassy in Oman reports that Masqat is a governorate, but
this has not been confirmed by the US Board on Geographic Names (BGN)
dates, limes, bananas, alfalfa, vegetables; camels, cattle; fish
139 (2002)
37.47 births/1,000 population (2003 est.)
Royal Omani Armed Forces (Army, Navy, Air Force), Royal Omani
Police
revenues: $9.2 billion
expenditures: $6.9 billion, including capital expenditures of $NA
(2000 est.)
Oman''s economic performance improved significantly in 2000 due
largely to the upturn in oil prices. The government is moving ahead
with privatization of its utilities, the development of a body of
commercial law to facilitate foreign investment, and increased
budgetary outlays. Oman continues to liberalize its markets and
joined the World Trade Organization (WTrO) in November 2000. GDP
growth improved in 2001 despite the global slowdown and then fell
back to 2.2% in 2002. In order to reduce unemployment, the
government is trying to replace expatriate workers with local
workers. Another government objective is the development of the
nation''s gas resources.
Pacific Ocean
The Pacific Ocean is a major contributor to the world
economy and particularly to those nations its waters directly touch.
It provides low-cost sea transportation between East and West,
extensive fishing grounds, offshore oil and gas fields, minerals,
and sand and gravel for the construction industry. In 1996, over 60%
of the world''s fish catch came from the Pacific Ocean. Exploitation
of offshore oil and gas reserves is playing an ever-increasing role
in the energy supplies of US, Australia, NZ, China, and Peru. The
high cost of recovering offshore oil and gas, combined with the wide
swings in world prices for oil since 1985, has slowed but not
stopped new drillings.
gas 3,599 km; oil 3,187 km (2003)','f3af4d4a908f7445a98c6ca3d28dd0111977ff5a23729d743f0a75fe92996c10','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5911e4b8d65501ede87864a9e7327151e802d300b756ca66aec0c1c1c19778d4',2003,'PK','Pakistan','economy',763,'total: 87
over 3,047 m: 14
2,438 to 3,047 m: 21
1,524 to 2,437 m: 32
914 to 1,523 m: 17
under 914 m: 3 (2002)
total: 37
1,524 to 2,437 m: 9
914 to 1,523 m: 9
under 914 m: 19 (2002)
water pollution from raw sewage, industrial wastes, and
agricultural runoff; limited natural fresh water resources; a
majority of the population does not have access to potable water;
deforestation; soil erosion; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation, Nuclear Test Ban
4.6% (FY02)
66.96 billion kWh (2001)
62.27 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 68.8%
hydro: 28.2%
nuclear: 3%
other: 0% (2001)
35% (2001 est.)
lowest 10%: 4.1%
highest 10%: 27.6% (1996-97)
agriculture 44%, industry 17%, services 39% (1999 est.)
textiles (garments, cotton cloth, and yarn), rice, leather,
sports goods, and carpets and rugs
US 24.5%, UAE 8.5%, UK 7.2%, Germany 4.9%, Hong Kong 4.8%
(2002)
4 provinces, 1 territory*, and 1 capital territory**;
Balochistan, Federally Administered Tribal Areas*, Islamabad Capital
Territory**, North-West Frontier Province, Punjab, Sindh
note: the Pakistani-administered portion of the disputed Jammu and
Kashmir region includes Azad Kashmir and the Northern Areas
cotton, wheat, rice, sugarcane, fruits, vegetables; milk,
beef, mutton, eggs
124 (2002)
29.59 births/1,000 population (2003 est.)
Army, Navy, Air Force, Civil Armed Forces, National Guard
revenues: $12.6 billion
expenditures: $14.8 billion, including capital expenditures of $NA
(FY02/03 est.)
Pakistan, an impoverished and underdeveloped country,
suffers from internal political disputes, low levels of foreign
investment, and a costly, ongoing confrontation with neighboring
India. Pakistan''s economic prospects, although still marred by poor
human development indicators, continued to improve in 2002 following
unprecedented inflows of foreign assistance beginning in 2001.
Foreign exchange reserves have grown to record levels, supported
largely by fast growth in recorded worker remittances. Trade levels
rebounded after a sharp decline in late 2001. The government has
made significant inroads in macroeconomic reform since 2000, but
progress is beginning to slow. Although it is in the second year of
its $1.3 billion IMF Poverty Reduction and Growth Facility,
Islamabad continues to require waivers for politically difficult
reforms. Long-term prospects remain uncertain as development
spending remains low, regional tensions remain high, and political
tensions weaken Pakistan''s commitment to lender-recommended economic
reforms. GDP growth will continue to hinge on crop performance;
dependence on foreign oil leaves the import bill vulnerable to
fluctuating oil prices; and efforts to open and modernize the
economy remain uneven.
gas 9,945 km; oil 1,821 km (2003)','04930588b413d41b41e673635b503e5930f10462312cec6d2bdee6d241748266','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5514772bcdf5e2f17ea73b6f7bfdc8b329b55f70c8c92edfcd97199f179a8f62',2003,'PW','Palau','economy',764,'total: 1
1,524 to 2,437 m: 1 (2002)
total: 2
1,524 to 2,437 m: 2 (2002)
Palmyra Atoll
total: 1
1,524 to 2,437 m: 1 (2002)
inadequate facilities for disposal of solid waste; threats to
the marine ecosystem from sand and coral dredging, illegal fishing
practices, and overfishing
Palmyra Atoll
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
NA%
0%
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 20%, industry NA%, services NA% (1990)
shellfish, tuna, copra, garments
US, Japan, Singapore (2000)
16 states; Aimeliik, Airai, Angaur, Hatobohei, Kayangel,
Koror, Melekeok, Ngaraard, Ngarchelong, Ngardmau, Ngatpang,
Ngchesar, Ngeremlengui, Ngiwal, Peleliu, Sonsoral
coconuts, copra, cassava (tapioca), sweet potatoes
3 (2002)
Palmyra Atoll
1 (2002)
19.02 births/1,000 population (2003 est.)
NA
revenues: $57.7 million
expenditures: $80.8 million, including capital expenditures of $17.1
million (FY 98/99 est.)
The economy consists primarily of tourism, subsistence
agriculture and fishing. The government is the major employer of the
work force, relying heavily on financial assistance from the US.
Business and tourist arrivals numbered 50,000 in FY00/01. The
population enjoys a per capita income twice that of the Philippines
and much of Micronesia. Long-run prospects for the key tourist
sector have been greatly bolstered by the expansion of air travel in
the Pacific, the rising prosperity of leading East Asian countries,
and the willingness of foreigners to finance infrastructure
development.
Palmyra Atoll
no economic activity','3a237ec96653f5e7ca38c01b382c76912f8292ca1b44f4a7b0573b7e558df237','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da68da9d741ec49b493f869af00eae9fa41ec9677d55afe5f007074f62dc4364',2003,'PA','Panama','economy',765,'total: 41
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 21 (2002)
total: 62
914 to 1,523 m: 12
under 914 m: 50 (2002)
water pollution from agricultural runoff threatens fishery
resources; deforestation of tropical rain forest; land degradation
and soil erosion threatens siltation of Panama Canal; air pollution
in urban areas; mining threatens natural resources
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
1.3% (FY99)
4.039 billion kWh (2001)
3.681 billion kWh (2001)
43 million kWh (2001)
118 million kWh (2001)
fossil fuel: 37%
hydro: 61.3%
nuclear: 0%
other: 1.7% (2001)
37% (1999 est.)
lowest 10%: 1.2%
highest 10%: 35.7% (1997)
agriculture 20.8%, industry 18%, services 61.2% (1995 est.)
bananas, shrimp, sugar, coffee, clothing (1999)
US 47.8%, Sweden 5.8%, Costa Rica 4.8%, Honduras 4.4% (2002)
9 provinces (provincias, singular - provincia) and 1
territory* (comarca); Bocas del Toro, Chiriqui, Cocle, Colon,
Darien, Herrera, Los Santos, Panama, San Blas*, and Veraguas
bananas, rice, corn, coffee, sugarcane, vegetables;
livestock; shrimp
103 (2002)
20.78 births/1,000 population (2003 est.)
an amendment to the Constitution abolished the armed forces,
but there are security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National Maritime Service,
and National Air Service)
revenues: $1.9 billion
expenditures: $2 billion, including capital expenditures of $471
million (2000 est.)
Panama''s economy is based primarily on a well-developed
services sector that accounts for three-fourths of GDP. Services
include operating the Panama Canal, banking, the Colon Free Zone,
insurance, container ports, flagship registry, and tourism. A slump
in Colon Free Zone and agricultural exports, the global slowdown,
and the withdrawal of US military forces held back economic growth
in 2000-02. The government has been backing public works programs,
tax reforms, new regional trade agreements, and development of
tourism in order to stimulate growth.
crude oil 130 km (2001)','72ad80f61461c9cfcf93fa9a3775a123ce5ae0d0c9e614ed2a458419d530b41d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0e9a9883022a1fe1fd2f75f39933fd2061edc6aa5418613155306c884ceb9a1',2003,'PG','Papua New Guinea','economy',766,'total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 1 (2002)
Paracel Islands
total: 1
1,524 to 2,437 m: 1 (2002)
total: 470
1,524 to 2,437 m: 11
914 to 1,523 m: 56
under 914 m: 403 (2002)
rain forest subject to deforestation as a result of
growing commercial demand for tropical timber; pollution from mining
projects; severe drought
Paracel Islands
NA
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol
1.4% (FY02)
1.496 billion kWh (2001)
1.391 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 54.1%
hydro: 45.9%
nuclear: 0%
other: 0% (2001)
37% (2002 est.)
lowest 10%: 1.7%
highest 10%: 40.5% (1996)
agriculture 85%, industry NA%, services NA%
oil, gold, copper ore, logs, palm oil, coffee,
cocoa, crayfish, prawns
Australia 23.7%, Japan 9.3%, China 5.3% (2002)
20 provinces; Bougainville, Central, Chimbu,
Eastern Highlands, East New Britain, East Sepik, Enga, Gulf, Madang,
Manus, Milne Bay, Morobe, National Capital, New Ireland, Northern,
Sandaun, Southern Highlands, Western, Western Highlands, West New
Britain
coffee, cocoa, coconuts, palm kernels, tea, rubber,
sweet potatoes, fruit, vegetables; poultry, pork
491 (2002)
Paracel Islands
1 (2002)
31.07 births/1,000 population (2003 est.)
Papua New Guinea Defense Force (includes Ground
Force, Maritime Operations Element, and Air Operations Element)
revenues: $894 million
expenditures: $1.1 billion, including capital expenditures of $344
million (2000 est.)
Papua New Guinea is richly endowed with natural
resources, but exploitation has been hampered by rugged terrain and
the high cost of developing infrastructure. Agriculture provides a
subsistence livelihood for 85% of the population. Mineral deposits,
including oil, copper, and gold, account for 72% of export earnings.
The economy has faltered over the past three years but will probably
improve slightly in 2003. Former Prime Minister Mekere MORAUTA had
tried to restore integrity to state institutions, stabilize the
kina, restore stability to the national budget, privatize public
enterprises where appropriate, and ensure ongoing peace on
Bougainville. The government has had considerable success in
attracting international support, specifically gaining the backing
of the IMF and the World Bank in securing development assistance
loans. Significant challenges face Prime Minister Michael SOMARE,
including gaining further investor confidence, continuing efforts to
privatize government assets, and maintaining the support of members
of Parliament.
Paracel Islands
China announced plans in 1997 to open the islands
for tourism.
oil 264 km (2003)','e615bb120342f6594f1da523ec8bfaba443b28a4dee25aae38abecfcf68f31d5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4812b41df554f77bfd76e7f2d55670eba43f5383fbada8e53cc754b14927ab24',2003,'PY','Paraguay','economy',767,'total: 11
over 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 4 (2002)
total: 868
1,524 to 2,437 m: 27
914 to 1,523 m: 323
under 914 m: 518 (2002)
deforestation; water pollution; inadequate means for waste
disposal present health risks for many urban residents; loss of
wetlands
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: Nuclear Test Ban
1.4% (FY98)
44.89 billion kWh (2001)
2.637 billion kWh (2001)
0 kWh (2001)
39.11 billion kWh (2001)
fossil fuel: 0%
hydro: 99.9%
nuclear: 0%
other: 0.1% (2001)
36% (2001 est.)
lowest 10%: 0.5%
highest 10%: 43.8% (1998)
agriculture 45%
soybeans, feed, cotton, meat, edible oils, electricity
Brazil 25.1%, Argentina 23%, Chile 5.5%, Bermuda 4% (2002)
17 departments (departamentos, singular - departamento) and
1 capital city*; Alto Paraguay, Alto Parana, Amambay, Asuncion*,
Boqueron, Caaguazu, Caazapa, Canindeyu, Central, Concepcion,
Cordillera, Guaira, Itapua, Misiones, Neembucu, Paraguari,
Presidente Hayes, San Pedro
cotton, sugarcane, soybeans, corn, wheat, tobacco, cassava
(tapioca), fruits, vegetables; beef, pork, eggs, milk; timber
879 (2002)
30.14 births/1,000 population (2003 est.)
Army, Navy (includes Naval Air and Marines), Air Force
revenues: $1.3 billion
expenditures: $2 billion, including capital expenditures of $700
million (1999 est.)
Paraguay has a market economy marked by a large informal
sector. The informal sector features both reexport of imported
consumer goods to neighboring countries as well as the activities of
thousands of microenterprises and urban street vendors. Because of
the importance of the informal sector, accurate economic measures
are difficult to obtain. A large percentage of the population
derives their living from agricultural activity, often on a
subsistence basis. The formal economy grew by an average of about 3%
annually in 1995-97; but GDP declined slightly in 1998, 1999, and
2000, rose slightly in 2001, only to fall again in 2002. On a per
capita basis, real income has stagnated at 1980 levels. Most
observers attribute Paraguay''s poor economic performance to
political uncertainty, corruption, lack of progress on structural
reform, substantial internal and external debt, and deficient
infrastructure.','c9b4a6630a2e0f145d24c06bd6227129c0bcabbd76e0259422341666247ce508','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b02a996f563f8df76e99bd5e4c5184027c145cd6de6043735fd83cc831d73ad',2003,'PE','Peru','economy',768,'total: 49
over 3,047 m: 5
2,438 to 3,047 m: 20
1,524 to 2,437 m: 13
914 to 1,523 m: 9
under 914 m: 2 (2002)
total: 184
1,524 to 2,437 m: 23
914 to 1,523 m: 61
under 914 m: 100 (2002)
deforestation (some the result of illegal logging); overgrazing
of the slopes of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers and
coastal waters from municipal and mining wastes
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
1.8% (FY01)
20.59 billion kWh (2001)
19.15 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 14.5%
hydro: 84.7%
nuclear: 0%
other: 0.8% (2001)
50% (2000 est.)
lowest 10%: 1.6%
highest 10%: 35.4% (1996)
agriculture, mining and quarrying, manufacturing, construction,
transport, services
fish and fish products, gold, copper, zinc, crude petroleum and
byproducts, lead, coffee, sugar, cotton
US 28.1%, China 10.5%, UK 7%, Switzerland 6.1%, Japan 5.6%
(2002)
24 departments (departamentos, singular - departamento) and 1
constitutional province* (provincia constitucional); Amazonas,
Ancash, Apurimac, Arequipa, Ayacucho, Cajamarca, Callao*, Cusco,
Huancavelica, Huanuco, Ica, Junin, La Libertad, Lambayeque, Lima,
Loreto, Madre de Dios, Moquegua, Pasco, Piura, Puno, San Martin,
Tacna, Tumbes, Ucayali
note: some reports indicate that the 24 departments and 1
constitutional province are now being referred to as regions; Peru
is implementing a decentralization program whereby these 25
administrative divisions will begin to exercise greater governmental
authority over their territories; in November 2002, voters chose
their new regional presidents and other regional leaders; the
authority that the regional government will exercise has not yet
been clearly defined, but it will be devolved to the regions over
the course of several years
coffee, cotton, sugarcane, rice, wheat, potatoes, corn,
plantains, coca; poultry, beef, dairy products, wool; fish
233 (2002)
22.81 births/1,000 population (2003 est.)
Army (Ejercito Peruano), Navy (Marina de Guerra del Peru;
includes Naval Air, Marines, and Coast Guard), Air Force (Fuerza
Aerea del Peru; FAP), National Police (includes General Police,
Security Police, and Technical Police)
revenues: $10.4 billion
expenditures: $10.4 billion, including capital expenditures of $NA
(2002 est.)
Thanks to foreign investment and the cooperation between the
government and the IMF and World Bank, growth was strong in 1994-97
and inflation was brought under control. In 1998, El Nino''s impact
on agriculture, the financial crisis in Asia, and instability in
Brazilian markets undercut growth. The following year was again lean
year for Peru, with the aftermath of El Nino and the Asian financial
crisis working its way through the economy. Political instability
resulting from the presidential election and FUJIMORI''s subsequent
departure from office limited growth in 2000. The downturn in the
global economy further curtailed growth in 2001. President TOLEDO,
who assumed the presidency in July 2001, has been working to
reinvigorate the economy and reduce unemployment. Economic growth in
2002 is estimated at 4.8%, led by construction in the retail and gas
sectors.
gas 388 km; oil 1,557 km; refined products 13 km (2003)','d3e63f64f8de0b9fc850c918fc1f6de3c12d37de1cac44a83ccead19cad873fd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c37cb6e2472c2365ee6d54ccbbe94d0d0ce43080cd54642646ed8d040c0140d',2003,'PH','Philippines','economy',769,'total: 82
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 26
914 to 1,523 m: 34
under 914 m: 13 (2002)
total: 175
1,524 to 2,437 m: 5
914 to 1,523 m: 71
under 914 m: 99 (2002)
uncontrolled deforestation in watershed areas; soil
erosion; air and water pollution in Manila; increasing pollution of
coastal mangrove swamps that are important fish breeding grounds
Pitcairn Islands
deforestation (only a small portion of the original
forest remains because of burning and clearing for settlement)
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
1.5% (FY98)
45.21 billion kWh (2001)
Pitcairn Islands
NA kWh; note - electric power is provided by a
small diesel-powered generator
42.04 billion kWh (2001)
Pitcairn Islands
NA kWh
0 kWh (2001)
0 kWh (2001)
fossil fuel: 55.6%
hydro: 17.5%
nuclear: 0%
other: 26.9% (2001)
40% (2001 est.)
Pitcairn Islands
NA%
lowest 10%: 1.5%
highest 10%: 39.3% (1998)
Pitcairn Islands
lowest 10%: NA%
highest 10%: NA%
agriculture 45%, industry 15%, services 40% (2003 est.)
Pitcairn Islands
no business community in the usual sense; some
public works; subsistence farming and fishing
electronic equipment, machinery and transport equipment,
garments, coconut products, chemicals
Pitcairn Islands
fruits, vegetables, curios, stamps
US 26.2%, Japan 14.9%, China 7.4%, Taiwan 5.8%,
Singapore 5.7%, Hong Kong 5.3%, Malaysia 5.3%, Netherlands 5%,
Germany 4.6%, South Korea 4.3% (2002)
Pitcairn Islands
NA (2000)
73 provinces and 61 chartered cities*; Abra, Agusan del
Norte, Agusan del Sur, Aklan, Albay, Angeles*, Antique, Aurora,
Bacolod*, Bago*, Baguio*, Bais*, Basilan, Basilan City*, Bataan,
Batanes, Batangas, Batangas City*, Benguet, Bohol, Bukidnon,
Bulacan, Butuan*, Cabanatuan*, Cadiz*, Cagayan, Cagayan de Oro*,
Calbayog*, Caloocan*, Camarines Norte, Camarines Sur, Camiguin,
Canlaon*, Capiz, Catanduanes, Cavite, Cavite City*, Cebu, Cebu
City*, Cotabato*, Dagupan*, Danao*, Dapitan*, Davao City*, Davao del
Norte, Davao del Sur, Davao Oriental, Dipolog*, Dumaguete*, Eastern
Samar, General Santos*, Gingoog*, Ifugao, Iligan*, Ilocos Norte,
Ilocos Sur, Iloilo, Iloilo City*, Iriga*, Isabela, Kalinga-Apayao,
La Carlota*, Laguna, Lanao del Norte, Lanao del Sur, Laoag*,
Lapu-Lapu*, La Union, Legaspi*, Leyte, Lipa*, Lucena*, Maguindanao,
Mandaue*, Manila*, Marawi*, Marinduque, Masbate, Mindoro Occidental,
Mindoro Oriental, Misamis Occidental, Misamis Oriental, Mountain,
Naga*, Negros Occidental, Negros Oriental, North Cotabato, Northern
Samar, Nueva Ecija, Nueva Vizcaya, Olongapo*, Ormoc*, Oroquieta*,
Ozamis*, Pagadian*, Palawan, Palayan*, Pampanga, Pangasinan, Pasay*,
Puerto Princesa*, Quezon, Quezon City*, Quirino, Rizal, Romblon,
Roxas*, Samar, San Carlos* (in Negros Occidental), San Carlos* (in
Pangasinan), San Jose*, San Pablo*, Silay*, Siquijor, Sorsogon,
South Cotabato, Southern Leyte, Sultan Kudarat, Sulu, Surigao*,
Surigao del Norte, Surigao del Sur, Tacloban*, Tagaytay*,
Tagbilaran*, Tangub*, Tarlac, Tawi-Tawi, Toledo*, Trece Martires*,
Zambales, Zamboanga*, Zamboanga del Norte, Zamboanga del Sur
Pitcairn Islands
none (overseas territory of the UK)
rice, coconuts, corn, sugarcane, bananas, pineapples,
mangoes; pork, eggs, beef; fish
Pitcairn Islands
wide variety of fruits and vegetables, goats,
chickens
257 (2002)
Pitcairn Islands
none (2002)
26.3 births/1,000 population (2003 est.)
Pitcairn Islands
NA births/1,000 population (2003 est.)
Army, Navy (including Coast Guard and Marine Corps), Air
Force, paramilitary units
revenues: $10.9 billion
expenditures: $15 billion, including capital expenditures of $NA
(2002 est.)
Pitcairn Islands
revenues: $729,884
expenditures: $878,119, including capital expenditures of $NA (FY
94/95 est.)
In 1998, the Philippine economy - a mixture of
agriculture, light industry, and supporting services - deteriorated
as a result of spillover from the Asian financial crisis and poor
weather conditions. Growth fell to 0.6% in 1998 from 5% in 1997, but
recovered to about 3.3% in 1999, 4.5% in 2000, and 4.5% in 2001. In
2002, the Philippines recorded GDP growth of 4.4% but also incurred
a record budget deficit. As a result, the Philippines is burdened
with a public sector debt equal to more than 100% of GDP. Growth
eased to 3.8% in 2003. The government has promised economic reforms
including going forward with privatization, reforming the tax
system, and promoting additional trade integration within its
region. Considerable drive is required to update the educational
system and the road network.
Pitcairn Islands
The inhabitants of this tiny isolated economy exist
on fishing, subsistence farming, handicrafts, and postage stamps.
The fertile soil of the valleys produces a wide variety of fruits
and vegetables, including citrus, sugarcane, watermelons, bananas,
yams, and beans. Bartering is an important part of the economy. The
major sources of revenue are the sale of postage stamps to
collectors and the sale of handicrafts to passing ships.
gas 565 km; oil 135 km; refined products 100 km (2003)','d37e00c6ac4a834a497ab16b6c1167885fd36141222b5506b41db7b658eb44f4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c40644826bf485e53f75c15f37c9ebeff95f8609f9b8881500212a5c253a79c5',2003,'PL','Poland','economy',770,'total: 88
over 3,047 m: 3
2,438 to 3,047 m: 30
1,524 to 2,437 m: 39
914 to 1,523 m: 7
under 914 m: 9 (2002)
total: 62
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 15
under 914 m: 43 (2002)
situation has improved since 1989 due to decline in heavy
industry and increased environmental concern by post-Communist
governments; air pollution nonetheless remains serious because of
sulfur dioxide emissions from coal-fired power plants, and the
resulting acid rain has caused forest damage; water pollution from
industrial and municipal sources is also a problem, as is disposal
of hazardous wastes; pollution levels should continue to decrease as
industrial establishments bring their facilities up to European
Union code, but at substantial cost to business and the government
party to: Air Pollution, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94,
Climate Change-Kyoto Protocol
1.71% (2002)
135 billion kWh (2001)
118.8 billion kWh (2001)
4.306 billion kWh (2001)
11.04 billion kWh (2001)
fossil fuel: 98.1%
hydro: 1.5%
nuclear: 0%
other: 0.4% (2001)
18.4% (2000 est.)
lowest 10%: 3.2%
highest 10%: 24.7% (1998)
industry 22.1%, agriculture 27.5%, services 50.4% (1999)
machinery and transport equipment 30.2%, intermediate
manufactured goods 25.5%, miscellaneous manufactured goods 20.9%,
food and live animals 8.5% (1999)
Germany 33%, Italy 5.7%, France 5%, UK 4.8%, Czech Republic
4.3% (2002)
16 provinces (wojewodztwa, singular - wojewodztwo);
Dolnoslaskie, Kujawsko-Pomorskie, Lodzkie, Lubelskie, Lubuskie,
Malopolskie, Mazowieckie, Opolskie, Podkarpackie, Podlaskie,
Pomorskie, Slaskie, Swietokrzyskie, Warminsko-Mazurskie,
Wielkopolskie, Zachodniopomorskie
potatoes, fruits, vegetables, wheat; poultry, eggs, pork
150 (2002)
10.47 births/1,000 population (2003 est.)
Army, Navy, Air and Air Defense Force
revenues: $49.6 billion
expenditures: $52.3 billion, including capital expenditures of $NA
(1999)
Poland has steadfastly pursued a policy of economic
liberalization throughout the 1990s and today stands out as a
success story among transition economies. Even so, much remains to
be done. The privatization of small and medium state-owned companies
and a liberal law on establishing new firms has encouraged the
development of the private business sector, but legal and
bureaucratic obstacles alongside persistent corruption are hampering
its further development. Poland''s agricultural sector remains
handicapped by structural problems, surplus labor, inefficient small
farms, and lack of investment. Restructuring and privatization of
"sensitive sectors" (e.g., coal, steel, railroads, and energy),
while recently initiated, have stalled due to a lack of political
will on the part of the government. Structural reforms in health
care, education, the pension system, and state administration have
resulted in larger than expected fiscal pressures. Further progress
in public finance depends mainly on privatization of Poland''s
remaining state sector, the reduction of state employment, and an
overhaul of the tax code to incorporate the growing gray economy and
farmers most of whom pay no tax. The government''s determination to
enter the EU has shaped most aspects of its economic policy and new
legislation; in June 2003, 77% of the voters approved membership,
now scheduled for May 2004. Improving Poland''s export
competitiveness and containing the internal budget deficit are top
priorities. Due to political uncertainty, the zloty has recently
depreciated in relation to the euro and the dollar while currencies
of the other euro-zone aspirants have been appreciating. GDP per
capita equals that of the 3 Baltic states.
gas 12,901 km; oil 737 km (2003)','5e9681938e53ceb2388108f1499db65a908c22ee4cbad004313a382a2c14e99f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('359010c6f91dc3654e864a04d23b8047a7a76a337b124e66ebbcf75707dcf3ff',2003,'PT','Portugal','economy',771,'total: 40
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4
914 to 1,523 m: 15
under 914 m: 7 (2002)
total: 26
914 to 1,523 m: 1
under 914 m: 25 (2002)
soil erosion; air pollution caused by industrial and
vehicle emissions; water pollution, especially in coastal areas
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Environmental
Modification, Nuclear Test Ban
2.2% (FY99/00)
44.32 billion kWh (2001)
41.48 billion kWh (2001)
3.743 billion kWh (2001)
3.479 billion kWh (2001)
fossil fuel: 64.5%
hydro: 31.3%
nuclear: 0%
other: 4.1% (2001)
NA%
lowest 10%: 3.1%
highest 10%: 28.4% (1995 est.)
services 60%, industry 30%, agriculture 10% (1999 est.)
clothing and footwear, machinery, chemicals, cork and paper
products, hides
Spain 20.3%, Germany 18.4%, France 12.6%, UK 10.5%, US
5.8%, Italy 4.8%, Belgium 4.5% (2002)
18 districts (distritos, singular - distrito) and 2
autonomous regions* (regioes autonomas, singular - regiao autonoma);
Aveiro, Acores (Azores)*, Beja, Braga, Braganca, Castelo Branco,
Coimbra, Evora, Faro, Guarda, Leiria, Lisboa, Madeira*, Portalegre,
Porto, Santarem, Setubal, Viana do Castelo, Vila Real, Viseu
grain, potatoes, olives, grapes; sheep, cattle, goats,
poultry, beef, dairy products
66 (2002)
11.45 births/1,000 population (2003 est.)
Army, Navy (PON) (includes Marines), Air Force, Republican
Guard (includes Fiscal Guard)
revenues: $45 billion
expenditures: $48 billion, including capital expenditures of $NA
(2001 est.)
Portugal has become a diversified and increasingly
service-based economy since joining the European Community in 1986.
Over the past decade, successive governments have privatized many
state-controlled firms and liberalized key areas of the economy,
including the financial and telecommunications sectors. The country
qualified for the European Monetary Union (EMU) in 1998 and began
circulating the euro on 1 January 2002 along with 11 other EU member
economies. Economic growth has been above the EU average for much of
the past decade, but fell back in 2001-03. GDP per capita stands at
70% of that of the leading EU economies. A poor educational system,
in particular, has been an obstacle to greater productivity and
growth. Portugal has been increasingly overshadowed by lower-cost
producers in Central Europe and Asia as a target for foreign direct
investment. The coalition government faces tough choices in its
attempts to boost Portugal''s economic competitiveness and to keep
the budget deficit within the 3% EU ceiling.
gas 482 km (2003)','d243b877b8e6086d6203502698a28a9ec1140a6ce71255336f56fe30b79411e7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d75d9eb786a06970da696a6ed57404f1ad083719bc2701dfa0fe1b4c78dfabb',2003,'PR','Puerto Rico','economy',772,'total: 19
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 8
under 914 m: 5 (2002)
total: 12
914 to 1,523 m: 2
under 914 m: 10 (2002)
erosion; occasional drought causing water shortages
20.9 billion kWh (2001)
19.44 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 99.2%
hydro: 0.8%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 3%, industry 20%, services 77% (2000 est.)
Reunion
agriculture 13%, industry 12%, services 75% (2000)
chemicals, electronics, apparel, canned tuna, rum,
beverage concentrates, medical equipment
US 88.2%, UK 1.5%, Dominican Republic 1.4% (2001)
none (commonwealth associated with the US); there are no
first-order administrative divisions as defined by the US
Government, but there are 78 municipalities (municipios, singular -
municipio) at the second order; Adjuntas, Aguada, Aguadilla, Aguas
Buenas, Aibonito, Anasco, Arecibo, Arroyo, Barceloneta,
Barranquitas, Bayamon, Cabo Rojo, Caguas, Camuy, Canovanas,
Carolina, Catano, Cayey, Ceiba, Ciales, Cidra, Coamo, Comerio,
Corozal, Culebra, Dorado, Fajardo, Florida, Guanica, Guayama,
Guayanilla, Guaynabo, Gurabo, Hatillo, Hormigueros, Humacao,
Isabela, Jayuya, Juana Diaz, Juncos, Lajas, Lares, Las Marias, Las
Piedras, Loiza, Luquillo, Manati, Maricao, Maunabo, Mayaguez, Moca,
Morovis, Naguabo, Naranjito, Orocovis, Patillas, Penuelas, Ponce,
Quebradillas, Rincon, Rio Grande, Sabana Grande, Salinas, San
German, San Juan, San Lorenzo, San Sebastian, Santa Isabel, Toa
Alta, Toa Baja, Trujillo Alto, Utuado, Vega Alta, Vega Baja,
Vieques, Villalba, Yabucoa, Yauco
sugarcane, coffee, pineapples, plantains, bananas;
livestock products, chickens
31 (2002)
15 births/1,000 population (2003 est.)
no regular indigenous military forces; paramilitary
National Guard, Police Force
revenues: $6.7 billion
expenditures: $9.6 billion, including capital expenditures of $NA
(FY 99/00)
Puerto Rico has one of the most dynamic economies in the
Caribbean region. A diverse industrial sector has far surpassed
agriculture as the primary locus of economic activity and income.
Encouraged by duty-free access to the US and by tax incentives, US
firms have invested heavily in Puerto Rico since the 1950s. US
minimum wage laws apply. Sugar production has lost out to dairy
production and other livestock products as the main source of income
in the agricultural sector. Tourism has traditionally been an
important source of income, with estimated arrivals of nearly 5
million tourists in 1999. Growth fell off in 2001-02, largely due to
the slowdown in the US economy.','aef21b2e951bca468d0d9c2360aacd82cfef7bd8bfa732792b6a268247553f26','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6c5be71536e8b5f37f12278a78030f4391402901b2ff6eef456f888d33bbf11',2003,'QA','Qatar','economy',773,'total: 2
over 3,047 m: 2 (2002)
Reunion
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2002)
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2002)
limited natural fresh water resources are increasing
dependence on large-scale desalination facilities
Reunion
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
10% (FY00)
9.264 billion kWh (2001)
Reunion
1.08 billion kWh (2001)
8.616 billion kWh (2001)
Reunion
1.005 billion kWh (2001)
0 kWh (2001)
Reunion
0 kWh (2001)
0 kWh (2001)
Reunion
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Reunion
fossil fuel: 55.5%
hydro: 44.5%
nuclear: 0%
other: 0% (2001)
NA%
Reunion
NA%
lowest 10%: NA%
highest 10%: NA%
Reunion
lowest 10%: NA%
highest 10%: NA%
petroleum products, fertilizers, steel
Reunion
sugar 63%, rum and molasses 4%, perfume essences 2%, lobster
3%, (1993)
Japan 40.1%, South Korea 16.6%, Singapore 8.2%, US 4.1% (2002)
Reunion
France 74%, Japan 6%, Comoros 4% (2000)
10 municipalities (baladiyat, singular - baladiyah); Ad
Dawhah, Al Ghuwayriyah, Al Jumayliyah, Al Khawr, Al Wakrah, Ar
Rayyan, Jarayan al Batinah, Madinat ash Shamal, Umm Sa''id, Umm Salal
Reunion
none (overseas department of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 4 arrondissements, 24 communes, and 47
cantons
fruits, vegetables; poultry, dairy products, beef; fish
Reunion
sugarcane, vanilla, tobacco, tropical fruits, vegetables,
corn
4 (2002)
Reunion
2 (2002)
15.68 births/1,000 population (2003 est.)
Reunion
20.17 births/1,000 population (2003 est.)
Army, Navy, Air Force
Reunion
no regular indigenous military forces; French forces
(including Army, Navy, Air Force, and Gendarmerie)
revenues: $5 billion
expenditures: $5.5 billion, including capital expenditures of $2.2
billion (FY 02/03 est.)
Reunion
revenues: $1.26 billion
expenditures: $2.62 billion, including capital expenditures of $NA
(1998)
Oil and gas account for more than 55% of GDP, roughly 85% of
export earnings, and 70% of government revenues. Oil and gas have
given Qatar a per capita GDP comparable to that of the leading West
European industrial countries. Proved oil reserves of 14.5 billion
barrels should ensure continued output at current levels for 23
years. Production and export of natural gas are becoming
increasingly important to the economy. Qatar''s proved reserves of
natural gas exceed 17.9 trillion cubic meters, more than 5% of the
world total and third largest in the world. Long-term goals feature
the development of offshore natural gas reserves. Since 2000, Qatar
has consistently posted trade surpluses largely because of high oil
prices and increased natural gas exports, and Qatar''s economy is
expected to receive an added boost as it begins to increase liquid
natural gas exports.
Reunion
The economy has traditionally been based on agriculture, but
services now dominate. Sugarcane has been the primary crop for more
than a century, and in some years it accounts for 85% of exports.
The government has been pushing the development of a tourist
industry to relieve high unemployment, which amounts to one-third of
the labor force. The gap in Reunion between the well-off and the
poor is extraordinary and accounts for the persistent social
tensions. The white and Indian communities are substantially better
off than other segments of the population, often approaching
European standards, whereas minority groups suffer the poverty and
unemployment typical of the poorer nations of the African continent.
The outbreak of severe rioting in February 1991 illustrates the
seriousness of socioeconomic tensions. The economic well-being of
Reunion depends heavily on continued financial assistance from
France.
condensate 90 km; condensate/gas 209 km; gas 902 km; liquid
petroleum gas 87 km; oil 722 km; oil/gas/water 41 km (2003)','21058b24e32b4b656e19076c730598a39d7c7aecc9b417f72759fecb828d5591','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e930ea245f5bb2fa39efee2bca53336f326125479b5e9ee146ece7293006494',2003,'RO','Romania','economy',774,'total: 26
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12 (2002)
Russia
total: 471
over 3,047 m: 56
2,438 to 3,047 m: 178
1,524 to 2,437 m: 76
914 to 1,523 m: 69
under 914 m: 92 (2002)
total: 39
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m: 25 (2002)
Russia
total: 2,272
over 3,047 m: 28
2,438 to 3,047 m: 118
1,524 to 2,437 m: 204
914 to 1,523 m: 324
under 914 m: 1,598 (2002)
soil erosion and degradation; water pollution; air pollution
in south from industrial effluents; contamination of Danube delta
wetlands
Russia
air pollution from heavy industry, emissions of coal-fired
electric plants, and transportation in major cities; industrial,
municipal, and agricultural pollution of inland waterways and
seacoasts; deforestation; soil erosion; soil contamination from
improper application of agricultural chemicals; scattered areas of
sometimes intense radioactive contamination; groundwater
contamination from toxic waste; urban solid waste management;
abandoned stocks of obsolete pesticides
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol
Russia
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol, Persistent Organic Pollutants
2.47% (2002)
Russia
NA%
50.86 billion kWh (2001)
Russia
846.5 billion kWh (2001)
46.1 billion kWh (2001)
Russia
773 billion kWh (2001)
400 million kWh (2001)
Russia
7 billion kWh (2001)
1.6 billion kWh (2001)
Russia
21.16 billion kWh (2001)
fossil fuel: 62.5%
hydro: 27.6%
nuclear: 9.9%
other: 0% (2001)
Russia
fossil fuel: 64.3%
hydro: 20.5%
nuclear: 14.8%
other: 0.4% (2001)
44.5% (2000)
Russia
25% (37622 est.)
lowest 10%: 3.2%
highest 10%: 25% (1998)
Russia
lowest 10%: 5.9%
highest 10%: 47% (2001)
agriculture 40%, industry 25%, services 35% (1998)
Russia
agriculture 12.3%, industry 22.7%, services 65% (2002 est.)
textiles and footwear, metals and metal products, machinery
and equipment, minerals and fuels
Russia
petroleum and petroleum products, natural gas, wood and wood
products, metals, chemicals, and a wide variety of civilian and
military manufactures
Italy 24.4%, Germany 15.5%, France 7.7%, UK 5.4%, US 5%,
Turkey 4.4% (2002)
Russia
Germany 7.5%, Italy 6.9%, Netherlands 6.7%, China 6.3%, US
6.1%, Ukraine 5.5%, Belarus 5.4%, Switzerland 5% (2002)
41 counties (judete, singular - judet) and 1 municipality*
(municipiu); Alba, Arad, Arges, Bacau, Bihor, Bistrita-Nasaud,
Botosani, Braila, Brasov, Bucuresti*, Buzau, Calarasi,
Caras-Severin, Cluj, Constanta, Covasna, Dimbovita, Dolj, Galati,
Gorj, Giurgiu, Harghita, Hunedoara, Ialomita, Iasi, Ilfov,
Maramures, Mehedinti, Mures, Neamt, Olt, Prahova, Salaj, Satu Mare,
Sibiu, Suceava, Teleorman, Timis, Tulcea, Vaslui, Vilcea, Vrancea
Russia
49 oblasts (oblastey, singular - oblast), 21 republics*
(respublik, singular - respublika), 10 autonomous
okrugs**(avtonomnykh okrugov, singular - avtonomnyy okrug), 6
krays*** (krayev, singular - kray), 2 federal cities (singular -
gorod)****, and 1 autonomous oblast*****(avtonomnaya oblast'');
Adygeya (Maykop)*, Aginskiy Buryatskiy (Aginskoye)**, Altay
(Gorno-Altaysk)*, Altayskiy (Barnaul)***, Amurskaya
(Blagoveshchensk), Arkhangel''skaya, Astrakhanskaya, Bashkortostan
(Ufa)*, Belgorodskaya, Bryanskaya, Buryatiya (Ulan-Ude)*, Chechnya
(Groznyy)*, Chelyabinskaya, Chitinskaya, Chukotskiy (Anadyr'')**,
Chuvashiya (Cheboksary)*, Dagestan (Makhachkala)*, Evenkiyskiy
(Tura)**, Ingushetiya (Nazran'')*, Irkutskaya, Ivanovskaya,
Kabardino-Balkariya (Nal''chik)*, Kaliningradskaya, Kalmykiya
(Elista)*, Kaluzhskaya, Kamchatskaya (Petropavlovsk-Kamchatskiy),
Karachayevo-Cherkesiya (Cherkessk)*, Kareliya (Petrozavodsk)*,
Kemerovskaya, Khabarovskiy***, Khakasiya (Abakan)*,
Khanty-Mansiyskiy (Khanty-Mansiysk)**, Kirovskaya, Komi
(Syktyvkar)*, Koryakskiy (Palana)**, Kostromskaya, Krasnodarskiy***,
Krasnoyarskiy***, Kurganskaya, Kurskaya, Leningradskaya, Lipetskaya,
Magadanskaya, Mariy-El (Yoshkar-Ola)*, Mordoviya (Saransk)*,
Moskovskaya, Moskva (Moscow)****, Murmanskaya, Nenetskiy
(Nar''yan-Mar)**, Nizhegorodskaya, Novgorodskaya, Novosibirskaya,
Omskaya, Orenburgskaya, Orlovskaya (Orel), Penzenskaya, Permskaya,
Komi-Permyatskiy (Kudymkar)**, Primorskiy (Vladivostok)***,
Pskovskaya, Rostovskaya, Ryazanskaya, Sakha (Yakutiya)*,
Sakhalinskaya (Yuzhno-Sakhalinsk), Samarskaya, Sankt-Peterburg
(Saint Petersburg)****, Saratovskaya, Severnaya Osetiya-Alaniya
[North Ossetia] (Vladikavkaz)*, Smolenskaya, Stavropol''skiy***,
Sverdlovskaya (Yekaterinburg), Tambovskaya, Tatarstan (Kazan'')*,
Taymyrskiy (Dudinka)**, Tomskaya, Tul''skaya, Tverskaya, Tyumenskaya,
Tyva (Kyzyl)*, Udmurtiya (Izhevsk)*, Ul''yanovskaya, Ust''-Ordynskiy
Buryatskiy (Ust''-Ordynskiy)**, Vladimirskaya, Volgogradskaya,
Vologodskaya, Voronezhskaya, Yamalo-Nenetskiy (Salekhard)**,
Yaroslavskaya, Yevreyskaya*****; note - when using a place name with
an adjectival ending ''skaya'' or ''skiy,'' the word Oblast'' or
Avonomnyy Okrug or Kray should be added to the place name
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
wheat, corn, barley, sugar beets, sunflower seed, potatoes,
grapes; eggs, sheep
Russia
grain, sugar beets, sunflower seed, vegetables, fruits; beef,
milk
65 (2002)
Russia
2,743 (2002)
10.79 births/1,000 population (2003 est.)
Russia
10.09 births/1,000 population (2003 est.)
Army, Navy, Air and Air Defense Forces (AMR), Paramilitary
Forces, Civil Defense, Border Guards
Russia
Ground Forces, Navy, Air Forces; Airborne troops, Strategic
Rocket Forces, and Military Space Forces are classified as
independent combat arms, not subordinate to any of the three branches
revenues: $11.7 billion
expenditures: $12.4 billion, including capital expenditures of $NA
(1999 est.)
Russia
revenues: $70 billion
expenditures: $62 billion, including capital expenditures of $NA
(2002 est.)
Romania began the transition from Communism in 1989 with a
largely obsolete industrial base and a pattern of output unsuited to
the country''s needs. The country emerged in 2000 from a punishing
three-year recession thanks to strong demand in EU export markets.
Despite the global slowdown in 2001-02, strong domestic activity in
construction, agriculture, and consumption have kept growth above
4%. An IMF Standby Agreement, signed in 2001, has been accompanied
by slow but palpable gains in privatization, deficit reduction, and
the curbing of inflation. Nonetheless, recent macroeconomic gains
have done little to address Romania''s widespread poverty, while
corruption and red tape hinder foreign investment.
Russia
A decade after the implosion of the Soviet Union in December
1991, Russia is still struggling to establish a modern market
economy and achieve strong economic growth. In contrast to its
trading partners in Central Europe - which were able within 3 to 5
years to overcome the initial production declines that accompanied
the launch of market reforms - Russia saw its economy contract for
five years, as the executive and legislature dithered over the
implementation of many of the basic foundations of a market economy.
Russia achieved a slight recovery in 1997, but the government''s
stubborn budget deficits and the country''s poor business climate
made it vulnerable when the global financial crisis swept through in
1998. The crisis culminated in the August depreciation of the ruble,
a debt default by the government, and a sharp deterioration in
living standards for most of the population. The economy
subsequently has rebounded, growing by an average of more than 6%
annually in 1999-2002 on the back of higher oil prices and the 60%
depreciation of the ruble in 1998. These GDP numbers, along with a
renewed government effort to advance lagging structural reforms,
have raised business and investor confidence over Russia''s prospects
in its second decade of transition. Yet serious problems persist.
Oil, natural gas, metals, and timber account for more than 80% of
exports, leaving the country vulnerable to swings in world prices.
Russia''s industrial base is increasingly dilapidated and must be
replaced or modernized if the country is to maintain vigorous
economic growth. Other problems include a weak banking system, a
poor business climate that discourages both domestic and foreign
investors, corruption, local and regional government intervention in
the courts, and widespread lack of trust in institutions. In 2003
President PUTIN further tightened his control over the "oligarchs,"
especially in the realm of political expression.
gas 3,508 km; oil 2,427 km (2003)
Russia
gas 135,771 km; oil 70,833 km; refined products 11,536 km;
water 23 km (2003)','49577d2a808b9a2da263a8ba39dd0f32fddcf95cdae87f3688e3080ed1408744','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e306c7e47abf4ac887e76e48949d5b37b326f744bb930224fa061f9b911fb94',2003,'RW','Rwanda','economy',775,'total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2002)
Saint Helena
total: 1
over 3,047 m: 1 (2002)
total: 5
914 to 1,523 m: 2
under 914 m: 3 (2002)
deforestation results from uncontrolled cutting of trees for
fuel; overgrazing; soil exhaustion; soil erosion; widespread poaching
Saint Helena
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Law of the Sea
3% (FY02)
96.78 million kWh (2001)
Saint Helena
5 million kWh (2001)
140 million kWh (2001)
Saint Helena
4.65 million kWh (2001)
50 million kWh (2001)
Saint Helena
0 kWh (2001)
0 kWh (2001)
Saint Helena
0 kWh (2001)
fossil fuel: 2.3%
hydro: 97.7%
nuclear: 0%
other: 0% (2001)
Saint Helena
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
60% (2001 est.)
Saint Helena
NA%
lowest 10%: 4.2%
highest 10%: 24.2% (1985)
Saint Helena
lowest 10%: NA%
highest 10%: NA%
agriculture 90%
Saint Helena
agriculture and fishing 6%, industry (mainly
construction) 48%, services 46% (1987 est.)
coffee, tea, hides, tin ore
Saint Helena
fish (frozen, canned, and salt-dried skipjack, tuna),
coffee, handicrafts
Indonesia 30.8%, Germany 14.6%, Hong Kong 9%, South Africa
5.5% (2002)
Saint Helena
US 23.7%, Japan 20.5%, Netherlands 16%, Tanzania 15.4%,
Spain 6.4%, UK 5.1%, Indonesia 4.5% (2002)
12 prefectures (in French - prefectures, singular -
prefecture; in Kinyarwanda - plural - NA, singular - prefegitura);
Butare, Byumba, Cyangugu, Gikongoro, Gisenyi, Gitarama, Kibungo,
Kibuye, Kigali Rurale, Kigali-ville, Umutara, Ruhengeri
Saint Helena
1 administrative area and 2 dependencies*; Ascension*,
Saint Helena, Tristan da Cunha*
coffee, tea, pyrethrum (insecticide made from
chrysanthemums), bananas, beans, sorghum, potatoes; livestock
Saint Helena
corn, potatoes, vegetables; timber; fish, crawfish (on
Tristan da Cunha)
9 (2002)
Saint Helena
1 (2002)
40.1 births/1,000 population (2003 est.)
Saint Helena
12.9 births/1,000 population (2003 est.)
Army, Navy, Air Force, Gendarmerie
revenues: $199.3 million
expenditures: $445 million, including capital expenditures of $NA
(2001 est.)
Saint Helena
revenues: $11.2 million
expenditures: $11 million, including capital expenditures of $NA
(FY92)
Rwanda is a poor rural country with about 90% of the
population engaged in (mainly subsistence) agriculture. It is the
most densely populated country in Africa; landlocked with few
natural resources and minimal industry. Primary foreign exchange
earners are coffee and tea. The 1994 genocide decimated Rwanda''s
fragile economic base, severely impoverished the population,
particularly women, and eroded the country''s ability to attract
private and external investment. However, Rwanda has made
substantial progress in stabilizing and rehabilitating its economy
to pre-1994 levels, although poverty levels are higher now. GDP has
rebounded, and inflation has been curbed. Export earnings, however,
have been hindered by low beverage prices, depriving the country of
much needed hard currency. Attempts to diversify into
non-traditional agriculture exports such as flowers and vegetables
have been stymied by a lack of adequate transportation
infrastructure. Despite Rwanda''s fertile ecosystem, food production
often does not keep pace with population growth, requiring food to
be imported. Rwanda continues to receive substantial amounts of aid
money and was approved for IMF-World Bank Heavily Indebted Poor
Country (HIPC) initiative debt relief in late 2000. But Kigali''s
high defense expenditures cause tension between the government and
international donors and lending agencies.
Saint Helena
The economy depends largely on financial assistance
from the UK, which amounted to about $5 million in 1997 or almost
one-half of annual budgetary revenues. The local population earns
income from fishing, the raising of livestock, and sales of
handicrafts. Because there are few jobs, 25% of the work force has
left to seek employment on Ascension Island, on the Falklands, and
in the UK.','b4f9e55e07aff31b346e89762b55564d218fb81b36f2630a043b1d564704bf48','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccfbe8687bf881fcc083f37cf47b0aac31edb682da2084d74153ce3470492eb8',2003,'KN','Saint Kitts and Nevis','economy',776,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
NA
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA%
100.3 million kWh (2001)
93.26 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
NA
machinery, food, electronics, beverages,
tobacco
US 66.5%, UK 7.6%, Canada 6.8%, Portugal 6%
(2002)
14 parishes; Christ Church Nichola Town, Saint
Anne Sandy Point, Saint George Basseterre, Saint George Gingerland,
Saint James Windward, Saint John Capesterre, Saint John Figtree,
Saint Mary Cayon, Saint Paul Capesterre, Saint Paul Charlestown,
Saint Peter Basseterre, Saint Thomas Lowland, Saint Thomas Middle
Island, Trinity Palmetto Point
sugarcane, rice, yams, vegetables, bananas;
fish
2 (2002)
18.45 births/1,000 population (2003 est.)
Saint Kitts and Nevis Defense Force (including
Coast Guard), Royal Saint Kitts and Nevis Police Force (including
Special Service Unit)
revenues: $89.7 million
expenditures: $128.2 million, including capital expenditures of
$19.5 million (2003 est.)
Sugar was the traditional mainstay of the
Saint Kitts economy until the 1970s. Although the crop still
dominates the agricultural sector, activities such as tourism,
export-oriented manufacturing, and offshore banking have assumed
larger roles in the economy. As tourism revenues are now the chief
source of the islands'' foreign exchange, a decline in stopover
tourist arrivals following the September 11, 2001 terrorist attacks
has eroded government finances. The opening of a 1,000+ bed Marriott
hotel in February 2003 is expected to bring in much-needed revenue.','55b634db2c13922ae15f0ecb3e5e222e3003099c8979090af3f3457a7f5ad9a2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d6e2688d96e01010030f3908541cab7e021509be78c534ecc4aa9b253f96995',2003,'LC','Saint Lucia','economy',777,'total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2002)
deforestation; soil erosion, particularly in the
northern region
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
$NA
120.2 million kWh (2001)
111.8 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 21.7%, services 53.6%, industry, commerce,
and manufacturing 24.7% (2002 est.)
bananas 41%, clothing, cocoa, vegetables, fruits,
coconut oil
UK 48.6%, US 27.8%, Barbados 7.6% (2002)
11 quarters; Anse-la-Raye, Castries, Choiseul, Dauphin,
Dennery, Gros-Islet, Laborie, Micoud, Praslin, Soufriere, Vieux-Fort
bananas, coconuts, vegetables, citrus, root crops, cocoa
2 (2002)
20.93 births/1,000 population (2003 est.)
Royal Saint Lucia Police Force (includes Special Service
Unit and Coast Guard)
revenues: $141.2 million
expenditures: $146.7 million, including capital expenditures of
$25.1 million (2000 est.)
The recent changes in the EU import preference regime
and the increased competition from Latin American bananas have made
economic diversification increasingly important in Saint Lucia. The
island nation has been able to attract foreign business and
investment, especially in its offshore banking and tourism
industries. The manufacturing sector is the most diverse in the
Eastern Caribbean area, and the government is trying to revitalize
the banana industry. Economic fundamentals remain solid.','a4afb041e992033e0a6d75d88d95b19c2e926c6be1c3f3990553483b060dbfb9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f223ee3957e1b749e644fceaa9e03c9c36914d0fab474d584b487971dda7c730',2003,'PM','Saint Pierre and Miquelon','economy',778,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
recent test drilling for oil in waters
around Saint Pierre and Miquelon may bring future development that
would impact the environment
42.03 million kWh (2001)
39.08 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
fishing 18%, industry (mainly
fish-processing) 41%, services 41% (1996 est.)
fish and fish products, soybeans, animal
feed, mollusks and crustaceans, fox and mink pelts
US 33.3%, Zambia 30.3%, Ecuador 16.2%,
France 5.1%, Canada 4%, Spain 4% (2002)
none (territorial collectivity of France);
note - there are no first-order administrative divisions as defined
by the US Government, but there are two communes - Saint Pierre,
Miquelon at the second order
vegetables; poultry, cattle, sheep, pigs;
fish
2 (2002)
14.62 births/1,000 population (2003 est.)
revenues: $70 million
expenditures: $60 million, including capital expenditures of $24
million (1996 est.)
The inhabitants have traditionally earned
their livelihood by fishing and by servicing fishing fleets
operating off the coast of Newfoundland. The economy has been
declining, however, because of disputes with Canada over fishing
quotas and a steady decline in the number of ships stopping at Saint
Pierre. In 1992, an arbitration panel awarded the islands an
exclusive economic zone of 12,348 sq km to settle a longstanding
territorial dispute with Canada, although it represents only 25% of
what France had sought. The islands are heavily subsidized by France
to the great betterment of living standards. The government hopes an
expansion of tourism will boost economic prospects. Recent test
drilling for oil may pave the way for development of the energy
sector.','61aa46e8d8e2f4f1d0ea0c0144920469a50c676c009b88da93cd49ec9d36b4ae','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6239110030de8f66da4b373b6d24e9149b016f46f600868418bafd0756a42dc4',2003,'VC','Saint Vincent and the Grenadines','economy',779,'total: 5
914 to 1,523 m: 3
under 914 m: 2 (2002)
total: 1
under 914 m: 1 (2002)
pollution of coastal waters and
shorelines from discharges by pleasure yachts and other effluents;
in some areas, pollution is severe enough to make swimming
prohibitive
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA%
92.48 million kWh (2001)
86 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 69.3%
hydro: 30.7%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 26%, industry 17%,
services 57% (1980 est.)
bananas 39%, eddoes and dasheen
(taro), arrowroot starch, tennis racquets
France 25.2%, Greece 19.1%, Spain
16.4%, UK 9.5%, US 7.1% (2002)
6 parishes; Charlotte, Grenadines,
Saint Andrew, Saint David, Saint George, Saint Patrick
bananas, coconuts, sweet potatoes,
spices; small numbers of cattle, sheep, pigs, goats; fish
6 (2002)
17.16 births/1,000 population (2003
est.)
Royal Saint Vincent and the
Grenadines Police Force (includes Special Service Unit), Coast Guard
revenues: $94.6 million
expenditures: $85.8 million, including capital expenditures of $NA
(2000 est.)
Bananas and other agricultural
products remain the staple of this lower-middle income country''s
economy. Although tourism and other services have been growing
moderately in recent years, the government has been ineffective at
introducing new industries. Unemployment remains high, and economic
growth hinges upon seasonal variations in the agricultural and
tourism sectors. Tropical storms wiped out substantial portions of
crops in 1994, 1995, and 2002, and tourism in the Eastern Caribbean
has suffered low arrivals following 11 September 2001. Saint Vincent
is home to a small offshore banking sector, but its restrictive
secrecy laws have come under international review. As of June 2001,
it remained on the Financial Action Task Force''s list of
noncooperative jurisdictions. Saint Vincent is also the largest
producer of marijuana in the Eastern Caribbean and is increasingly
being used as a transshipment point for illegal narcotics from South
America.','bcc5c201c05c5466c5d0a2f614b4c1d1641cccdd582070a4fb73c7460d7c5e24','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb5804f473f504bf54d670bf81ad8c2d984ba1626ed56a737046192a68f02ae9',2003,'WS','Samoa','economy',780,'total: 3
2,438 to 3,047 m: 1
under 914 m: 2 (2002)
total: 1
under 914 m: 1 (2002)
soil erosion, deforestation, invasive species, overfishing
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
NA%
105.1 million kWh (2001)
97.74 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 58%
hydro: 42%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
NA
fish, coconut oil and cream, copra, taro, automotive parts,
garments, beer
Australia 66.1%, US 10%, Japan 3.7% (2002)
11 districts; A''ana, Aiga-i-le-Tai, Atua, Fa''asaleleaga,
Gaga''emauga, Gagaifomauga, Palauli, Satupa''itea, Tuamasaga,
Va''a-o-Fonoti, Vaisigano
coconuts, bananas, taro, yams, coffee, cocoa
4 (2002)
15.41 births/1,000 population (2003 est.)
no regular armed services; Samoa Police Force
revenues: $105 million
expenditures: $119 million, including capital expenditures of $NA
(2001/2002)
The economy of Samoa has traditionally been dependent on
development aid, family remittances from overseas, and agriculture
and fishing. The country is vulnerable to devastating storms.
Agriculture employs two-thirds of the labor force, and furnishes 90%
of exports, featuring coconut cream, coconut oil, and copra. The
manufacturing sector mainly processes agricultural products. The
decline of fish stocks in the area is a continuing problem. Tourism
is an expanding sector, accounting for 25% of GDP; about 88,000
tourists visited the islands in 2001. The Samoan Government has
called for deregulation of the financial sector, encouragement of
investment, and continued fiscal discipline, meantime protecting the
environment. Observers point to the flexibility of the labor market
as a basic strength for future economic advances. Foreign reserves
are in a relatively healthy state, the external debt is stable, and
inflation is low.','9192f84ee7d379866ed49ba1c3d849a79a47ba7254f05df94966617b89bfe225','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fc9c5ce17f27a8bd633355116ade18a6a196b31822276586d6947761529bb6f',2003,'ST','Sao Tome and Principe','economy',781,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
deforestation; soil erosion and exhaustion
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
0.8% (FY01)
17 million kWh (2001)
15.81 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 41.2%
hydro: 58.8%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
population mainly engaged in subsistence
agriculture and fishing
note: shortages of skilled workers
cocoa 80%, copra, coffee, palm oil
Netherlands 30.1%, Poland 11.8%, Canada 9.7%,
Germany 7.5%, Philippines 7.5%, Spain 7.5%, Belgium 6.5%, France
4.3%, Portugal 4.3% (2002)
2 provinces; Principe, Sao Tome
note: Principe has had self-government since 29 April 1995
cocoa, coconuts, palm kernels, copra,
cinnamon, pepper, coffee, bananas, papayas, beans; poultry; fish
2 (2002)
41.87 births/1,000 population (2003 est.)
Army, Navy, Security Police
revenues: $58 million
expenditures: $114 million, including capital expenditures of $54
million (1993 est.)
This small poor island economy has become
increasingly dependent on cocoa since independence 28 years ago.
Cocoa production has substantially declined in recent years because
of drought and mismanagement, but strengthening prices brighten
prospects for 2003. Sao Tome has to import all fuels, most
manufactured goods, consumer goods, and a substantial amount of
food. Over the years, it has been unable to service its external
debt and has had to depend on concessional aid and debt
rescheduling. Sao Tome benefited from $200 million in debt relief in
December 2000 under the Highly Indebted Poor Countries (HIPC)
program. Sao Tome''s success in implementing structural reforms has
been rewarded by international donors, who pledged increased
assistance in 2001. Considerable potential exists for development of
a tourist industry, and the government has taken steps to expand
facilities in recent years. The government also has attempted to
reduce price controls and subsidies. Sao Tome is optimistic that
substantial petroleum discoveries are forthcoming in its territorial
waters in the oil-rich waters of the Gulf of Guinea; production
could begin as early as 2004.','832f314b021fc0434466a547a8d27ed7f2e3c6a39b9fda686dcd38d7fca37550','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d5b310b7fc23ff693e97e91d244ecf2e840e35340a199e47a4f906f8905e9c4',2003,'AQ','Antarctica','economy',782,'total: 19
over 3,047 m: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 5 (2002)
in 1998, NASA satellite data showed that the antarctic
ozone hole was the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased ultraviolet
light coming through the hole damages the DNA of icefish, an
antarctic fish lacking hemoglobin; ozone depletion earlier was shown
to harm one-celled antarctic marine plants; in 2002, significant
areas of ice shelves disintegrated in response to regional warming
30
note: 30 stations, operated by 16 national governments party to the
Antarctic Treaty, have aircraft landing facilities for either
helicopters and/or fixed-wing aircraft; commercial enterprises
operate two additional aircraft landing facilities; helicopter pads
are available at 27 stations; runways at 15 locations are gravel,
sea-ice, blue-ice, or compacted snow suitable for landing wheeled,
fixed-wing aircraft; of these, 1 is greater than 3 km in length, 6
are between 2 km and 3 km in length, 3 are between 1 km and 2 km in
length, 3 are less than 1 km in length, and 2 are of unknown length;
snow surface skiways, limited to use by ski-equipped, fixed-wing
aircraft, are available at another 15 locations; of these, 4 are
greater than 3 km in length, 3 are between 2 km and 3 km in length,
2 are between 1 km and 2 km in length, 2 are less than 1 km in
length, and 4 are of unknown length; aircraft landing facilities
generally subject to severe restrictions and limitations resulting
from extreme seasonal and geographic conditions; aircraft landing
facilities do not meet ICAO standards; advance approval from the
respective governmental or nongovernmental operating organization
required for landing; landed aircraft are subject to inspection in
accordance with Article 7, Antarctic Treaty (2002)','483c015e83f2db2665bfccaf80323dcb13e76cadc7826867a05ad4fbd30d34ea','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e89c2290c380df967e85cf74ceba19e70021e6ca15b1abc9cf8a7423f577ac44',2003,'AD','Andorra','economy',783,'deforestation; overgrazing of mountain meadows contributes
to soil erosion; air pollution; wastewater treatment and solid waste
disposal
party to: Hazardous Wastes
signed, but not ratified: none of the selected agreements
NA kWh
NA kWh
NA kWh; note - most electricity supplied by Spain and
France; Andorra generates a small amount of hydropower
0 kWh (2002)
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0%
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 1%, industry 21%, services 78% (2000 est.)
tobacco products, furniture
Spain 58%, France 34% (2000)
7 parishes (parroquies, singular - parroquia); Andorra la
Vella, Canillo, Encamp, La Massana, Escaldes-Engordany, Ordino, Sant
Julia de Loria
small quantities of rye, wheat, barley, oats, vegetables;
sheep
none (2002)
9.65 births/1,000 population (2003 est.)
no regular military forces, but there is a police force
revenues: $385 million
expenditures: $342 million, including capital expenditures of $NA
(1997)
Andorra la Vella
Democratic Party or PD (formerly part of National Democratic
Group or AND) [Ladislau BARO SOLO]; Liberal Party of Andorra or PLA
[Marc FORNE MOLNE] (used to be Liberal Union or UL); Liberal Union
or UL [Francesc CERQUEDA]; National Democratic Group or AND
[Ladislau BARO SOLO]; National Democratic Initiative or IDN [Vicenc
MATEU ZAMORA]; New Democracy or ND [Jaume BARTOMEU CASSANY]; Social
Democratic Party or PSD (formerly part of National Democratic Group
of AND) [leader NA]; Union of the People of Ordino (Unio Parroquial
d''Ordino) or UPO [Simo DURO COMA]
note: there are two other small parties','a86944acb6715976d78db02d3ae29e5639065d8cfb6bc835b49c23ff658e6ef7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7a4559090b1574007913401dfdb24bf63ec122ce19973e9c74a59d139bd10c',2003,'HM','Heard Island and McDonald Islands','economy',784,'NA
Holy See (Vatican City)
NA
No indigenous economic activity,
but the Australian Government allows limited fishing around the
islands.
Holy See (Vatican City)
This unique, noncommercial economy is
supported financially by an annual tax on Roman Catholic dioceses
throughout the world, as well as by special collections (known as
Peter''s Pence); the sale of postage stamps, coins, medals, and
tourist mementos; fees for admission to museums; and the sale of
publications. Investments and real estate income also account for a
sizable portion of revenue. The incomes and living standards of lay
workers are comparable to those of counterparts who work in the city
of Rome.','5423b18fc2c23512e221705a7809537b4a34086f38a593731034e18db136b36c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad83ccd57097e23e7a707a97dc667160dab20791bf197fd880a27abb8d3d3f40',2003,'LI','Liechtenstein','economy',785,'NA
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Law of the Sea
NA kWh
0 kWh (2002)
0 kWh (2002)
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0% (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
industry 47.4%, services 51.3%, agriculture 1.3%
(37256 est.)
small specialty machinery, connectors for audio and
video, parts for motor vehicles, dental products, hardware, prepared
foodstuffs, electronic equipment, optical products
EU 62.6% (Germany 24.3%, Austria 9.5%, France 8.9%,
Italy 6.6%, UK 4.6%), US 18.9%, Switzerland 15.7%
11 communes (Gemeinden, singular - Gemeinde); Balzers,
Eschen, Gamprin, Mauren, Planken, Ruggell, Schaan, Schellenberg,
Triesen, Triesenberg, Vaduz
wheat, barley, corn, potatoes; livestock, dairy
products
none (2002)
10.92 births/1,000 population (2003 est.)
revenues: $424.2 million
expenditures: $414.1 million, including capital expenditures of $NA
(1998 est.)
Despite its small size and limited natural resources,
Liechtenstein has developed into a prosperous, highly
industrialized, free-enterprise economy with a vital financial
service sector and living standards on a par with its large European
neighbors. The Liechtenstein economy is widely diversified with a
large number of small businesses. Low business taxes - the maximum
tax rate is 20% - and easy incorporation rules have induced many
holding or so-called letter box companies to establish nominal
offices in Liechtenstein, providing 30% of state revenues. The
country participates in a customs union with Switzerland and uses
the Swiss franc as its national currency. It imports more than 90%
of its energy requirements. Liechtenstein has been a member of the
European Economic Area (an organization serving as a bridge between
the European Free Trade Association (EFTA) and the EU) since May
1995. The government is working to harmonize its economic policies
with those of an integrated Europe.
gas 20 km (2003)','b0b76cf4c2925e8114cf81b7c537ce5a3d686f0403db9e69a2eb05ecf468563e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acdb62f52f86a9f696a64162506f806b31802c1438d3c4414231c9d057817232',2003,'MC','Monaco','economy',786,'NA
party to: Air Pollution, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA kWh
NA kWh
note: electricity supplied by France
NA%
lowest 10%: NA%
highest 10%: NA%
none; there are no first-order administrative divisions as
defined by the US Government, but there are four quarters
(quartiers, singular - quartier); Fontvieille, La Condamine,
Monaco-Ville, Monte-Carlo
none
none; linked to airport in Nice, France, by helicopter
service (2002)
9.46 births/1,000 population (2003 est.)
revenues: $518 million
expenditures: $531 million, including capital expenditures of $NA
(1995)
Monaco, situated on the French Mediterranean coast, is a
popular resort, attracting tourists to its casino and pleasant
climate. In 2001, a major new construction project will extend the
pier used by cruise ships in the main harbor. The principality has
successfully sought to diversify into services and small,
high-value-added, nonpolluting industries. The state has no income
tax and low business taxes and thrives as a tax haven both for
individuals who have established residence and for foreign companies
that have set up businesses and offices. The state retains
monopolies in a number of sectors, including tobacco, the telephone
network, and the postal service. Living standards are high, roughly
comparable to those in prosperous French metropolitan areas. Monaco
does not publish national income figures; the estimates below are
extremely rough.','6be79e415f57246618fc163526b1d31a38ec9d4fa77e83fe91e2eb62bad15d86','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('263caf7e0da04db57754e0ce8c7fd52b4a2480d565014e2cb75edbab32526106',2003,'MS','Montserrat','economy',787,'land erosion occurs on slopes that have been cleared for
cultivation
2.5 million kWh (2001)
2.325 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
electronic components, plastic bags, apparel, hot
peppers, live plants, cattle
US, Antigua and Barbuda
3 parishes; Saint Anthony, Saint Georges, Saint Peter
cabbages, carrots, cucumbers, tomatoes, onions, peppers;
livestock products
none; only airport was destroyed by volcanic activity; a
helicopter service to Antigua is used (2002)
17.57 births/1,000 population (2003 est.)
no regular indigenous military forces; Police Force
revenues: $31.4 million
expenditures: $31.6 million, including capital expenditures of $8.4
million (1997 est.)
Severe volcanic activity, which began in July 1995, has
put a damper on this small, open economy. A catastrophic eruption in
June 1997 closed the airports and seaports, causing further economic
and social dislocation. Two-thirds of the 12,000 inhabitants fled
the island. Some began to return in 1998, but lack of housing
limited the number. The agriculture sector continued to be affected
by the lack of suitable land for farming and the destruction of
crops. Prospects for the economy depend largely on developments in
relation to the volcano and on public sector construction activity.
The UK has launched a three-year $122.8 million aid program to help
reconstruct the economy. Half of the island is expected to remain
uninhabitable for another decade.','4b67abbcf7f5aa3653e9c998783ed29ae68417d97e548e242668c5e07283f5f1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be8ad87403f3ca97fc2ee53c54cbce9c1ad3650d70f8114689d67f66fdca675b',2003,'SM','San Marino','economy',788,'NA
party to: Biodiversity, Climate Change, Desertification,
Nuclear Test Ban
signed, but not ratified: Air Pollution
NA%
NA
NA (2000)
0 kWh
note: electricity supplied by Italy
0 kWh
note: electric power supplied by Italy
fossil fuel: 41.18%
hydro: 58.82%
nuclear: 0%
other: 0%
NA%
lowest 10%: NA%
highest 10%: NA%
services 57%, industry 42%, agriculture 1% (2000 est.)
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, ceramics
9 municipalities (castelli, singular - castello);
Acquaviva, Borgo Maggiore, Chiesanuova, Domagnano, Faetano,
Fiorentino, Monte Giardino, San Marino, Serravalle
wheat, grapes, corn, olives; cattle, pigs, horses, beef,
cheese, hides
none (2002)
10.49 births/1,000 population (2003 est.)
Voluntary Military Force (Corpi Militari Voluntar),
Gendarmerie; note - the Voluntary Military Force performs ceremonial
duties and limited police assistance
revenues: $400 million
expenditures: $400 million, including capital expenditures of $NA
(2000 est.)
The tourist sector contributes over 50% of GDP. In 2000
more than 3 million tourists visited San Marino. The key industries
are banking, wearing apparel, electronics, and ceramics. Main
agricultural products are wine and cheeses. The per capita level of
output and standard of living are comparable to those of the most
prosperous regions of Italy, which supplies much of its food.','505700cdd2d827afcd4f6b5550638ac754abac7c20436a6f18dcdf5bde9c926a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

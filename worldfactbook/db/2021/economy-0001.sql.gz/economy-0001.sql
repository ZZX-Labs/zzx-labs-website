SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('078f4e65c7f9549273b03b810dd1e1f382731ca99b37d5f1f2f1d8024704d3ce',2021,'US','United States','economy',44,'GDP (purchasing power parity): GDP—real
growth rate:
GDP—per capita (PPP):
Gross national saving:
Industrial production growth rate: Labor force:
Unemployment rate:
Taxes and other revenues:
Budget surplus (+) or deficit (-): Public debt:
Inflation rate (consumer prices): Current
account balance:
Exports:
Imports:
Reserves of foreign exchange and gold: Debt—
external:','22b928f393c9e93bd8765ced361d39fef94fb815e33e1689407a4cb7325e7ba1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f396a30ce88c59ce3a4f97c6d1aae3be4ab9a1317832d3f62c8391fbc9ce919d',2021,'CY','Cyprus','economy',58,'Economy—overview: Economic activity is limited to providing
services to the military and their families located in
Akrotiri. All food and manufactured goods must be
imported.
Exchange rates: note: uses the euro','d8825987750c6cc6cce6e73f49eecf28e8f97c966ac6aac9fd79ded4b73b60d4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32a5b5f5efcd63601cad6f746490352149ea6a07789bf583eafc02853106836e',2021,'DZ','Algeria','economy',74,'Economy—overview: Algeria’s economy remains dominated by
the state, a legacy of the country’s socialist post-
independence development model. In recent years the
Algerian Government has halted the privatization of state-
owned industries and imposed restrictions on imports and
foreign involvement in its economy, pursuing an explicit
import substitution policy.
Hydrocarbons have long been the backbone of the
economy, accounting for roughly 30% of GDP 60% of
budget revenues, and nearly 95% of export earnings.
Algeria has the 10th-largest reserves of natural gas in the
world-including the 3rd-largest reserves of shale gas—and
is the 6th-largest gas exporter. It ranks 16th in proven oil
reserves. Hydrocarbon exports enabled Algeria to maintain
macroeconomic stability, amass large foreign currency
reserves, and maintain low external debt while global oil
prices were high. With lower oil prices since 2014,
Algeria’s foreign exchange reserves have declined by more
than half and its oil stabilization fund has decreased from
about $20 billion at the end of 2013 to about $7 billion in
2017, which is the statutory minimum.
Declining oil prices have also reduced the government’s
ability to use state-driven growth to distribute rents and
fund generous public subsidies, and the government has
been under pressure to reduce spending. Over the past
three years, the government has enacted incremental
increases in some taxes, resulting in modest increases in
prices for gasoline, cigarettes, alcohol, and _ certain
imported goods, but it has refrained from reducing
subsidies, particularly for education, healthcare, and
housing programs.
Algiers has increased protectionist measures since 2015
to limit its import bill and encourage domestic production
of non-oil and gas industries. Since 2015, the government
has imposed additional restrictions on access to foreign
exchange for imports, and import quotas for specific
products, such as cars. In January 2018 the government
imposed an indefinite suspension on the importation of
roughly 850 products, subject to periodic review.
President BOUTEFLIKA announced in fall 2017 that
Algeria intends to develop its non-conventional energy
resources. Algeria has_ struggled to develop non-
hydrocarbon industries because of heavy regulation and an
emphasis on state-driven growth. Algeria has not increased
non-hydrocarbon exports, and hydrocarbon exports have
declined because of field depletion and increased domestic
demand.
GDP (purchasing power parity): $630 billion (2017 est.)
$621.3 billion (2016 est.)
$602 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 36
GDP (official exchange rate): $167.6 billion (2017 est.)
GDP—real growth rate: 1.4% (2017 est.)
3.2% (2016 est.)
3.7% (2015 est.)
country comparison to the world: 174
GDP—per capita (PPP): $15,200 (2017 est.)
$15,200 (2016 est.)
$15,100 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 109
Gross national saving: 37.8% of GDP (2017 est.)
37.4% of GDP (2016 est.)
36.4% of GDP (2015 est.)
country comparison to the world: 13
GDP—composition, by end use: Household consumption: 42.7%
(2017 est.) government consumption: 20.2% (2017 est.)
investment in fixed capital: 38.1% (2017 est.)
investment in inventories: 11.2% (2017 est.)
exports of goods and services: 23.6% (2017 est.)
imports of goods and services: -35.8% (2017 est.)
GDP—composition, by sector of origin: agriculture: 13.3% (2017
est.)
industry: 39.3% (2017 est.)
services: 47.4% (2017 est.)
Agriculture—products: Wheat, barley, oats, grapes, olives,
citrus, fruits; sheep, cattle
Industries: petroleum, natural gas, light industries, mining,
electrical, petrochemical, food processing Industrial
production growth rate: 0.6% (2017 est.)
country comparison to the world: 164
Labor force: 11.82 million (2017 est.)
country comparison to the world: 50
Labor force—by occupation: agriculture: 10.8%
industry: 30.9%
services: 58.4% (2011 est.)
Unemployment rate: 11.7% (2017 est.)
10.5% (2016 est.)
country comparison to the world: 155
Population below poverty line: 23% (2006 est.)
Household income or consumption by percentage share: Jowest 10%:
2.8%
highest 10%: 26.8% (1995)
Budget: revenues: 54.15 billion (2017 est.)
expenditures: 70.2 billion (2017 est.)
Taxes and other revenues: 32.3% (of GDP) (2017 est.)
country comparison to the world: 67
Budget surplus (+) or deficit (-): -9.6% (of GDP) (2017 est.)
country comparison to the world: 207
Public debt: 27.5% of GDP (2017 est.)
20.4% of GDP (2016 est.)
note: data cover central government debt as well as debt
issued by subnational entities and intra-governmental debt
country comparison to the world: 170
Fiscal year: Calendar year
Inflation rate (consumer prices): 5.6% (2017 est.)
6.4% (2016 est.)
country comparison to the world: 179
Current account balance: -$22.1 billion (2017 est.)
-$26.47 billion (2016 est.)
country comparison to the world: 199
Exports: $34.37 billion (2017 est.)
$29.06 billion (2016 est.)
country comparison to the world: 58
Exports—partners: Italy 17.4%, Spain 13%, France 11.9%, US
9.4%, Brazil 6.2%, Netherlands 5.5% (2017) Exports—
commodities: petroleum, natural gas, and petroleum products
97% (2009 est.)
Imports: $48.54 billion (2017 est.)
$49.43 billion (2016 est.)
country comparison to the world: 55
Imports—commodities: Capital goods, foodstuffs, consumer
goods
Imports—partners: China 18.2%, France 9.1%, Italy 8%,
Germany 7%, Spain 6.9%, Turkey 4.4% (2017) Reserves of
foreign exchange and gold: $97.89 billion (31 December 2017
est.)
$114.7 billion (31 December 2016 est.)
country comparison to the world: 26
Debt—external: $6.26 billion (31 December 2017 est.)
$5.088 billion (31 December 2016 est.)
country comparison to the world: 128
Exchange rates: Algerian dinars (DZD) per US dollar
108.9 (2017 est.)
109.443 (2016 est.)
109.443 (2015 est.)
100.691 (2014 est.)
80.579 (2013 est.)','3789d7a050d44d7325fd6ea5b7965f2601d7c33a6bd7dd959ba088fe72e302c5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b548fdda40956948d1a15d3298e857211eb88b02b58759b95dacbdadf5a2d29c',2021,'NA','Namibia','economy',104,'Economy—overview: Tourism continues to dominate Antigua
and Barbuda’s economy, accounting for nearly 60% of GDP
and 40% of investment. The dual-island nation’s
agricultural production is focused on the domestic market
and constrained by a limited water supply and a labor
shortage stemming from the lure of higher wages in
tourism and _ construction. Manufacturing comprises
enclave-type assembly for export with major products being
bedding, handicrafts, and electronic components.
Like other countries in the region, Antigua’s economy
was severely hit by effects of the global economic recession
in 2009. The country suffered from the collapse of its
largest private sector employer, a steep decline in tourism,
a rise in debt, and a sharp economic contraction between
2009 and 2011. Antigua has not yet returned to its pre-
crisis growth levels. Barbuda suffered significant damages
after hurricanes Irma and Maria passed through the
Caribbean in 2017.
Prospects for economic growth in the medium term will
continue to depend on tourist arrivals from the US, Canada,
and Europe and could be disrupted by potential damage
from natural disasters. The new government, elected in
2014 and led by Prime Minister Gaston Browne, continues
to face significant fiscal challenges. The government places
some hope in a new Citizenship by Investment Program, to
both reduce public debt levels and spur growth, and a
resolution of a WTO dispute with the US.
GDP (purchasing power parity): $2.398 billion (2017 est.)
$2.334 billion (2016 est.)
$2.215 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 194
GDP (official exchange rate): $1.524 billion (2017 est.)
GDP—real growth rate: 2.8% (2017 est.)
59.3% (2016 est.)
4.1% (2015 est.)
country comparison to the world: 120
GDP—per capita (PPP): $26,400 (2017 est.)
$25,900 (2016 est.)
$24,900 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 78
Gross national saving: 17.3% of GDP (2017 est.)
24.5% of GDP (2016 est.)
30.7% of GDP (2015 est.)
country comparison to the world: 115
GDP—composition, by end use: Household consumption: 53.5%
(2017 est.)
government consumption: 15.2% (2017 est.)
investment in fixed capital: 23.9% (2017 est.)
investment in inventories: 0.1% (2017 est.)
exports of goods and services: 73.9% (2017 est.)
imports of goods and services: -66.5% (2017 est.)
GDP—composition, by sector of origin: agriculture: 1.8% (2017
est.)
industry: 20.8% (2017 est.)
services: 77.3% (2017 est.)
Agriculture—products: cotton, fruits, vegetables, bananas,
coconuts, cucumbers, mangoes, sugarcane; livestock
Industries: tourism, construction, light manufacturing
(clothing, alcohol, household appliances) Industrial production
growth rate: 6.8% (2017 est.)
country comparison to the world: 32
Labor force: 30,000 (1991)
country comparison to the world: 204
Labor force—by occupation: agriculture: 7%
industry: 11%
services: 82% (1983 est.)
Unemployment rate: 11% (2014 est.)
country comparison to the world: 148
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
NA
highest 10%: NA
Budget: revenues: 298.2 million (2017 est.)
expenditures: 334 million (2017 est.)
Taxes and other revenues: 19.6% (of GDP) (2017 est.)
country comparison to the world: 154
Budget surplus (+) or deficit (-): -2.4% (of GDP) (2017 est.)
country comparison to the world: 112
Public debt: 86.8% of GDP (2017 est.)
86.2% of GDP (2016 est.)
country comparison to the world: 30
Fiscal year: 1 April—31 March
Inflation rate (consumer prices): 2.5% (2017 est.)
-0.5% (2016 est.)
country comparison to the world: 122
Current account balance: -$112 million (2017 est.)
$2 million (2016 est.)
country comparison to the world: 88
Exports: $86.7 million (2017 est.)
$56.5 million (2016 est.)
country comparison to the world: 198
Exports—partners: Poland 62.2%, Cameroon 9.5%, US 5.1%,
UK 4.5% (2017)
Exports—commodities: petroleum products, bedding,
handicrafts, electronic components, transport equipment,
food and live animals Imports: $560 million (2017 est.)
$503.4 million (2016 est.)
country comparison to the world: 198
Imports—commodities: food and live animals, machinery and
transport equipment, manufactures, chemicals, oil Imports—
partners: US 48%, Spain 4.2% (2017)
Debt—external: $441.2 million (31 December 2012)
$458 million June 2010)
country comparison to the world: 181
Exchange rates: East Caribbean dollars (XCD) per US dollar—
2.7 (2017 est.)
2.7 (2016 est.)
2.7 (2015 est.)
2.7 (2014 est.)
2.7 (2013 est.)
Economy—overview: Economic activity is limited to the
exploitation of natural resources, including petroleum,
natural gas, fish, and seals.
7
Marine fisheries: the Arctic fishery region (Region 18) is the
smallest in the world with a catch of only 52 mt in 2016,
although the Food and Agriculture Organization assesses
that some Arctic catches are reported in adjacent regions;
Russia and Canada were historically the major producers;
in 2017, the five littoral states including Canada, Denmark
(Greenland), Norway, Russia, and the US agreed to a 16
year ban on fishing in the Central Arctic Ocean to allow for
time to study the ecological system of these waters','e9ff1f590a860be8421568e89a6c136721d1392303078ec6629678bf1d4f1e71','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128ac9f86d5ed721b2478f788278d24120b91b3e2df92feafb078ef379c570de',2021,'NF','Norfolk Island','economy',137,'Economy—overview: Australia is an open market with minimal
restrictions on imports of goods and services. The process
of opening up has increased productivity, stimulated
growth, and made the economy more flexible and dynamic.
Australia plays an active role in the WTO, APEC, the G20,
and other trade forums. Australia’s free trade agreement
(FTA) with China entered into force in 2015, adding to
existing FTAs with the Republic of Korea, Japan, Chile,
Malaysia, New Zealand, Singapore, Thailand, and the US,
and a regional FTA with ASEAN and New Zealand.
Australia continues to negotiate bilateral agreements with
Indonesia, as well as larger agreements with its Pacific
neighbors and the Gulf Cooperation Council countries, and
an Asia-wide Regional Comprehensive Economic
Partnership that includes the 10 ASEAN countries and
China, Japan, Korea, New Zealand, and India.
Australia is a significant exporter of natural resources,
energy, and food. Australia’s abundant and diverse natural
resources attract high levels of foreign investment and
include extensive reserves of coal, iron, copper, gold,
natural gas, uranium, and renewable energy sources. A
series of major investments, such as the US$40 billion
Gorgon Liquid Natural Gas Project, will significantly
expand the resources sector.
For nearly two decades up till 2017, Australia had
benefited from a dramatic surge in its terms of trade. As
export prices increased faster than import prices, the
economy experienced continuous growth, low
unemployment, contained inflation, very low public debt,
and a strong and stable financial system. Australia entered
2018 facing a range of growth constraints, principally
driven by the sharp fall in global prices of key export
commodities. Demand for resources and energy from Asia
and especially China is growing at a slower pace and sharp
drops in export prices have impacted growth.
GDP (purchasing power parity): $1.248 trillion (2017 est.)
$1.221 trillion (2016 est.)
$1.19 trillion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 19
GDP (official exchange rate): $1.38 trillion (2017 est.)
GDP—real growth rate: 2.2% (2017 est.)
2.6% (2016 est.)
2.5% (2015 est.)
country comparison to the world: 144
GDP—per capita (PPP): $50,400 (2017 est.)
$50,100 (2016 est.)
$49,600 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 29
Gross national saving: 21% of GDP (2017 est.)
20.5% of GDP (2016 est.)
21.5% of GDP (2015 est.)
country comparison to the world: 88
GDP—composition, by end use: Household consumption: 56.9%
(2017 est.) government consumption: 18.4% (2017 est.)
investment in fixed capital: 24.1% (2017 est.)
investment in inventories: 0.1% (2017 est.)
exports of goods and services: 21.5% (2017 est.)
imports of goods and services: -21% (2017 est.)
GDP—composition, by sector of origin: agriculture: 3.6% (2017
est.) industry: 25.3% (2017 est.)
services: 71.2% (2017 est.)
Agriculture—products: wheat, barley, sugarcane, fruits; cattle,
sheep, poultry
Industries: Mining, industrial and transportation equipment,
food processing, chemicals, steel Industrial production growth
rate: 1.4% (2017 est.)
country comparison to the world: 144
Labor force: 12.91 million (2017 est.)
country comparison to the world: 44
Labor force—by occupation: agriculture: 3.6%
industry: 21.1%
services: 75.3% (2009 est.)
Unemployment rate: 5.6% (2017 est.)
5.7% (2016 est.)
country comparison to the world: 81
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
2%
highest 10%: 25.4% (1994)
Budget: revenues: 490 billion (2017 est.)
expenditures: 496.9 billion (2017 est.)
Taxes and other revenues: 35.5% (of GDP) (2017 est.)
country comparison to the world: 61
Budget surplus (+) or deficit (-): -0.5% (of GDP) (2017 est.)
country comparison to the world: 60
Public debt: 40.8% of GDP (2017 est.)
40.6% of GDP (2016 est.)
country comparison to the world: 123
Fiscal year: 1 July—30 June
Inflation rate (consumer prices): 2% (2017 est.)
1.3% (2016 est.)
country comparison to the world: 103
Current account balance: -$36.01 billion (2017 est.)
-$41.45 billion (2016 est.)
country comparison to the world: 201
Exports: $231.6 billion (2017 est.)
$191.7 billion (2016 est.)
country comparison to the world: 22
Exports—partners: China 33.5%, Japan 14.6%, South Korea
6.6%, India 5%, Hong Kong 4% (2017) Exports—commodities:
iron ore, coal, gold, natural gas, beef, aluminum ores and
conc, wheat, meat (excluding beef), wool, alumina, alcohol
Imports: $221 billion (2017 est.)
$198.7 billion (2016 est.)
country comparison to the world: 24
Imports—commodities: motor vehicles, refined petroleum,
telecommunication equipment and parts; crude petroleum,
medicaments, goods vehicles, gold, computers Imports—
partners: China 22.9%, US 10.8%, Japan 7.5%, Thailand
5.1%, Germany 4.9%, South Korea 4.5% (2017) Reserves of
foreign exchange and gold: $66.58 billion (31 December 2017
est.)
$55.07 billion (31 December 2016 est.)
country comparison to the world: 33
Debt—external: $1.714 trillion (31 December 2017 est.)
$1.547 trillion (31 December 2016 est.)
country comparison to the world: 11
Exchange rates: Australian dollars (AUD) per US dollar—
1.311 (2017 est.)
1.3442 (2016 est.)
1.3442 (2015 est.)
1.3291 (2014 est.)
1.1094 (2013 est.)
Economy—overview: [The Bahamas has the second highest per
capita GDP in the English-speaking Caribbean with an
economy heavily dependent on tourism and _ financial
services. Tourism accounts for approximately 50% of GDP
and directly or indirectly employs half of the archipelago’s
labor force. Financial services constitute the second-most
important sector of the Bahamian economy, accounting for
about 15% of GDP. Manufacturing and _ agriculture
combined contribute less than 7% of GDP and show little
growth, despite government incentives aimed at those
sectors. The new government led by Prime Minister Hubert
MINNIS has prioritized addressing fiscal imbalances and
rising debt, which stood at 75% of GDP in 2016. Large
capital projects like the Baha Mar Casino and Hotel are
driving growth. Public debt increased in 2017 in large part
due to hurricane reconstruction and relief financing. The
primary fiscal balance was a deficit of 0.4% of GDP in 2016.
The Bahamas is the only country in the Western
Hemisphere that is not a member of the World Trade
Organization.
GDP (purchasing power parity):
$12.06 billion (2017 est.)
$11.89 billion (2016 est.)
$12.09 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 156
GDP (official exchange rate):
$12.16 billion (2017 est.)
GDP—real growth rate: 1.4% (2017 est.)
-1.7% (2016 est.)
1% (2015 est.)
country comparison to the world: 175
GDP—per capita (PPP): $32,400 (2017 est.)
$32,300 (2016 est.)
$33,200 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 62
Gross national saving:
11.4% of GDP (2017 est.)
18.2% of GDP (2016 est.)
12.3% of GDP (2015 est.)
country comparison to the world: 155
GDP—composition, by end use:
household consumption: 68% (2017 est.)
government consumption: 13% (2017 est.)
investment in fixed capital: 26.3% (2017 est.)
investment in inventories: 0.7% (2017 est.)
exports of goods and services: 33.7% (2017 est.)
imports of goods and services: -41.8% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 2.3% (2017 est.)
industry: 7.7% (2017 est.)
services: 90% (2017 est.)
Agriculture—products: Citrus, vegetables; poultry; seafood
Industries: tourism, banking, oil bunkering, maritime
industries, transshipment and logistics, salt, aragonite,
pharmaceuticals Industrial production growth rate:
9.8% (2017 est.)
country comparison to the world: 44
Labor force: 196,900 (2013 est.)
country comparison to the world: 173
Labor force—by occupation: agriculture: 3%
industry: 11%
services: 49%
tourism: 37% (2011 est.)
Unemployment rate: 10.1% (2017 est.)
12.2% (2016 est.)
country comparison to the world: 140
Population below poverty line: 9.3% (2010 est.)
Household income or consumption by percentage share: Jowest 10%:
1%
highest 10%: 22% (2007 est.)
Budget: revenues: 2.139 billion (2017 est.)
expenditures: 2.46 billion (2017 est.)
Taxes and other revenues:
17.6% (of GDP) (2017 est.)
country comparison to the world: 166
Budget surplus (+) or deficit (-): -2.6% (of GDP) (2017 est.)
country comparison to the world: 115
Public debt:
54.6% of GDP (2017 est.)
50.5% of GDP (2016 est.)
country comparison to the world: 80
Fiscal year: 1 July—30 June
Inflation rate (consumer prices): 1.4% (2017 est.)
-0.3% (2016 est.)
country comparison to the world: 75
Current account balance:
-$1.909 billion (2017 est.)
-$868 million (2016 est.)
country comparison to the world: 163
Exports: $550 million (2017 est.)
$444.3 million (2016 est.)
country comparison to the world: 174
Exports—partners: US 63.9%, Namibia 19.3% (2017)
Exports—commodities: Rock lobster, aragonite, crude salt,
polystyrene products
Imports: $3.18 billion (2017 est.)
$2.594 billion (2016 est.)
country comparison to the world: 146
Imports—commodities: Machinery and transport equipment,
manufactures, chemicals, mineral fuels; food and _ live
animals Imports—partners: US 83.2% (2017)
Reserves of foreign exchange and gold:
$1.522 billion (31 December 2017 est.)
$1.002 billion (31 December 2016 est.)
country comparison to the world: 125
Debt—external:
$17.56 billion (31 December 2013 est.)
$16.35 billion (31 December 2012 est.)
country comparison to the world: 98
Exchange rates: Bahamian dollars (BSD) per US dollar—
1 (2017 est.)
1 (2016 est.)
1 (2015 est.)
1 (2014 est.)
1 (2013 est.)','b00f884bc95dd4d33cf5ab30d5899d1d5c504bea6bc8d5b9d0894874f5c3de60','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c643ff3de836bfc052c23b11c91909b55019eb869ff329d773de17f4e515aa4e',2021,'HN','Honduras','economy',180,'Economy—overview: Tourism is the number one _ foreign
exchange earner in this small economy, followed by exports
of sugar, bananas, citrus, marine products, and crude oil.
The government’s expansionary monetary and _ fiscal
policies, initiated in September 1998, led to GDP growth
averaging nearly 4% in 1999-2007, but GPD growth has
averaged only 2.1% from 2007-2016, with 2.5% growth
estimated for 2017. Belize’s dependence on energy imports
makes it susceptible to energy price shocks.
Although Belize has the third highest per capita income
in Central America, the average income figure masks a
huge income disparity between rich and poor, and a key
government objective remains reducing poverty and
inequality with the help of international donors. High
unemployment, a growing trade deficit and heavy foreign
debt burden continue to be major concerns. Belize faces
continued pressure from rising sovereign debt, and a
growing trade imbalance.
GDP (purchasing power parity):
$3.218 billion (2017 est.)
$3.194 billion (2016 est.)
$3.21 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 187
GDP (official exchange rate):
$1.854 billion (2017 est.)
GDP—real growth rate: 0.8% (2017 est.)
-0.5% (2016 est.)
3.8% (2015 est.)
country comparison to the world: 186
GDP—per capita (PPP): $8,300 (2017 est.)
$8,500 (2016 est.)
$8,800 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 149
Gross national saving:
11.3% of GDP (2017 est.)
13.3% of GDP (2016 est.)
14.2% of GDP (2015 est.)
country comparison to the world: 157
GDP—composition, by end use:
household consumption: 75.1% (2017 est.)
government consumption: 15.2% (2017 est.)
investment in fixed capital: 22.5% (2017 est.)
investment in inventories: 1.2% (2017 est.)
exports of goods and services: 49.1% (2017 est.)
imports of goods and services: -63.2% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 10.3% (2017 est.)
industry: 21.6% (2017 est.)
services: 68% (2017 est.)
Agriculture—products: bananas, cacao, citrus, sugar; fish,
cultured shrimp; lumber Industries: garment production,
food processing, tourism, construction, oil
Industrial production growth rate:
-0.6% (2017 est.)
country comparison to the world: 172
Labor force: 120,500 (2008 est.)
note: shortage of skilled labor and all types of technical
personnel
country comparison to the world: 180
Labor force—by occupation: agriculture: 10.2%
industry: 18.1%
services: 71.7% (2007 est.)
Unemployment rate: 9% (2017 est.)
8% (2016 est.)
country comparison to the world: 130
Population below poverty line: 41% (2013 est.)
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 553.5 million (2017 est.)
expenditures: 572 million (2017 est.)
Taxes and other revenues:
29.9% (of GDP) (2017 est.)
country comparison to the world: 78
Budget surplus (+) or deficit (-): -1% (of GDP) (2017 est.)
country comparison to the world: 75
Public debt:
99% of GDP (2017 est.)
95.9% of GDP (2016 est.)
country comparison to the world: 17
Fiscal year: 1 April—31 March
Inflation rate (consumer prices): 1.1% (2017 est.)
0.7% (2016 est.)
country comparison to the world: 55
Current account balance:
-$143 million (2017 est.)
-$163 million (2016 est.)
country comparison to the world: 91
Exports: $457.5 million (2017 est.)
$442.7 million (2016 est.)
country comparison to the world: 177
Exports—partners: UK 33.9%, US 22%; Jamaica 6.7%, Italy
6.4%, Barbados 5.9%, Ireland 5.5%, Netherlands 4.3%
(2017) Exports—commodities: Sugar, bananas, citrus, clothing,
fish products, molasses, wood, crude oil Imports: $845.9
million (2017 est.)
$916.2 million (2016 est.)
country comparison to the world: 188
Imports—commodities: Machinery and transport equipment,
manufactured goods; fuels, chemicals, pharmaceuticals;
food, beverages, tobacco Imports—partners: US 35.6%, China
11.2%, Mexico 11.2%, Guatemala 6.9% (2017)
Reserves of foreign exchange and gold:
$312.1 million (31 December 2017 est.)
$376.7 million (31 December 2016 est.)
country comparison to the world: 167
Debt—external:
$1.315 billion (31 December 2017 est.)
$1.338 billion (31 December 2016 est.)
country comparison to the world: 162
Exchange rates: Belizean dollars (BZD) per US dollar—
2 (2017 est.)
2 (2016 est.)
2 (2015 est.)
2 (2014 est.)
2 (2013 est.)','1700c3cdb2d531ee8f512ad7cf403801364e4ea42526e29a88ccdb4dd3ddf1f0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57add3cba12771ddbacfee2fe2c85a0f4cc203d0c5ce796fb9ed393bba6465f8',2021,'CM','Cameroon','economy',286,'Economy—overview: Cameroon’s market-based, diversified
economy features oil and _ gas, timber, aluminum,
agriculture, mining and the service sector. Oil remains
Cameroon’s main export commodity, and despite falling
global oil prices, still accounts for nearly 40% of exports.
Cameroon’s economy suffers from factors that often impact
underdeveloped countries, such as stagnant per capita
income, a relatively inequitable distribution of income, a
top-heavy civil service, endemic corruption, continuing
inefficiencies of a large parastatal system in key sectors,
and a_- generally unfavorable climate for business
enterprise.
Since 1990, the government has embarked on various
IMF and World Bank programs designed to spur business
investment, increase efficiency in agriculture, improve
trade, and recapitalize the nation’s banks. The IMF
continues to press for economic reforms, including
increased budget transparency, privatization, and poverty
reduction programs. The Government of Cameroon
provides subsidies for electricity, food, and fuel that have
strained the federal budget and diverted funds from
education, healthcare, and infrastructure projects, as low
oil prices have led to lower revenues. Cameroon devotes
significant resources to several large infrastructure
projects currently under construction, including a deep
seaport in Kribi and the Lom Pangar Hydropower Project.
Cameroon’s energy sector continues to diversify, recently
opening a natural gas-powered electricity generating plant.
Cameroon continues to seek foreign investment to improve
its inadequate infrastructure, create jobs, and improve its
economic footprint, but its unfavorable’ business
environment remains a significant deterrent to foreign
investment.
GDP (purchasing power parity):
$89.54 billion (2017 est.)
$86.47 billion (2016 est.)
$82.63 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 88
GDP (official exchange rate):
$34.99 billion (2017 est.)
GDP—real growth rate: 3.5% (2017 est.)
4.6% (2016 est.)
5.7% (2015 est.)
country comparison to the world: 98
GDP—per capita (PPP): $3,700 (2017 est.)
$3,700 (2016 est.)
$3,600 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 182
Gross national saving:
25.5% of GDP (2017 est.)
25.2% of GDP (2016 est.)
23.9% of GDP (2015 est.)
country comparison to the world: 56
GDP—composition, by end use:
household consumption: 66.3% (2017 est.)
government consumption: 11.8% (2017 est.)
investment in fixed capital: 21.6% (2017 est.)
investment in inventories: -0.3% (2017 est.)
exports of goods and services: 21.6% (2017 est.)
imports of goods and services: -20.9% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 16.7% (2017 est.)
industry: 26.5% (2017 est.)
services: 56.8% (2017 est.)
Agriculture—products: Coffee, cocoa, cotton, rubber, bananas,
oilseed, grains, cassava (manioc, tapioca); livestock; timber
Industries: petroleum production and refining, aluminum
production, food processing, light consumer goods, textiles,
lumber, ship repair Industrial production growth rate:
3.3% (2017 est.)
country comparison to the world: 94
Labor force: 9.912 million (2017 est.)
country comparison to the world: 52
Labor force—by occupation: agriculture: 70%
industry: 13%
services: 17% (2001 est.)
Unemployment rate: 4.3% (2014 est.)
30% (2001 est.)
country comparison to the world: 57
Population below poverty line: 30% (2001 est.)
Household income or consumption by percentage share: Jowest 10%:
37.5%
highest 10%: 35.4% (2001)
Budget: revenues: 5.363 billion (2017 est.)
expenditures: 6.556 billion (2017 est.)
Taxes and other revenues: 15.3% (of GDP) (2017 est.)
country comparison to the world: 191
Budget surplus (+) or deficit (-): -3.4% (of GDP) (2017 est.)
country comparison to the world: 143
Public debt:
36.9% of GDP (2017 est.)
32.5% of GDP (2016 est.)
country comparison to the world: 143
Fiscal year: 1 July—30 June
Inflation rate (consumer prices): 0.6% (2017 est.)
0.9% (2016 est.)
country comparison to the world: 31
Current account balance:
-§932 million (2017 est.)
-$1.034 billion (2016 est.)
country comparison to the world: 141
Exports: $4.732 billion (2017 est.)
$4.561 billion (2016 est.)
country comparison to the world: 109
Exports—partners: Netherlands 15.6%, France 12.6%, China
11.7%, Belgium 6.8%, Italy 6.3%, Algeria 4.8%, Malaysia
4.4% (2017) Exports—commodities: crude oil and petroleum
products, lumber, cocoa beans, aluminum, coffee, cotton
Imports: $4.812 billion (2017 est.)
$4.827 billion (2016 est.)
country comparison to the world: 132
Imports—commodities: machinery, electrical equipment,
transport equipment, fuel, food Imports—partners: China 19%,
France 10.3%, Thailand 7.9%, Nigeria 4.1% (2017)
Reserves of foreign exchange and gold:
$3.235 billion (31 December 2017 est.)
$2.26 billion (31 December 2016 est.)
country comparison to the world: 107
Debt—external:
$9.375 billion (31 December 2017 est.)
$7.364 billion (31 December 2016 est.)
country comparison to the world: 115
Exchange rates: Cooperation Financiere en Afrique Centrale
francs (XAF) per US dollar— 605.3 (2017 est.)
993.01 (2016 est.)
993.01 (2015 est.)
991.45 (2014 est.)
494.42 (2013 est.)','e48ccdfd0e1450814ee11ac3bce9c1556a5992b504fa142d6aaa98feb285f357','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c05f62ca3ce6019fb5382cc3786f352279322655b5ba52ef4b1a3dc05d4c652b',2021,'CA','Canada','economy',295,'Economy—overview: Canada resembles the US in its market-
oriented economic system, pattern of production, and high
living standards. Since World War II, the impressive growth
of the manufacturing, mining, and service sectors has
transformed the nation from a largely rural economy into
one primarily industrial and urban. Canada has a large oil
and natural gas sector with the majority of crude oil
production derived from oil sands in the western provinces,
especially Alberta. Canada now ranks third in the world in
proved oil reserves behind Venezuela and Saudi Arabia and
is the world’s seventh-largest oil producer.
TThe 1989 Canada-US Free Trade Agreement and the
1994 North American Free Trade Agreement (which
includes Mexico) dramatically increased trade and
economic integration between the US and Canada. Canada
and the US enjoy the world’s most comprehensive bilateral
trade and investment relationship, with goods and services
trade totaling more than $680 billion in 2017, and two-way
investment stocks of more than $800 billion. Over three-
fourths of Canada’s merchandise exports are destined for
the US each year. Canada is the largest foreign supplier of
energy to the US, including oil, natural gas, and electric
power, and a top source of US uranium imports.
Given its abundant natural resources, highly skilled
labor force, and modern capital stock, Canada enjoyed solid
economic growth from 1993 through 2007. The global
economic crisis of 2007-08 moved the Canadian economy
into sharp recession by late 2008, and Ottawa posted its
first fiscal deficit in 2009 after 12 years of surplus.
Canada’s major banks emerged from the financial crisis of
2008-09 among the strongest in the world, owing to the
financial sector’s tradition of conservative lending practices
and strong capitalization. Canada’s economy posted strong
growth in 2017 at 3%, but most analysts are projecting
Canada’s economic growth will drop back closer to 2% in
2018.
GDP (purchasing power parity):
$1.774 trillion (2017 est.)
$1.721 trillion (2016 est.)
$1.697 trillion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 17
GDP (official exchange rate):
$1.653 trillion (2017 est.)
GDP—real growth rate: 3% (2017 est.)
1.4% (2016 est.)
1% (2015 est.)
country comparison to the world: 112
GDP—per capita (PPP): $48,400 (2017 est.)
$47,500 (2016 est.)
$47,400 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 34
Gross national saving:
20.8% of GDP (2017 est.)
20% of GDP (2016 est.)
20.5% of GDP (2015 est.)
country comparison to the world: 90
GDP—composition, by end use:
household consumption: 57.8% (2017 est.)
government consumption: 20.8% (2017 est.)
investment in fixed capital: 23% (2017 est.)
investment in inventories: 0.7% (2017 est.)
exports of goods and services: 30.9% (2017 est.)
imports of goods and services: -33.2% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 1.6% (2017 est.)
industry: 28.2% (2017 est.)
services: 70.2% (2017 est.)
Agriculture—products: wheat, barley, oilseed, tobacco, fruits,
vegetables; dairy products; fish; forest products Industries:
transportation equipment, chemicals, processed and
unprocessed minerals, food products, wood and paper
products, fish products, petroleum, natural gas _ Industrial
production growth rate:
4.9% (2017 est.)
country comparison to the world: 60
Labor force: 19.52 million (2017 est.)
country comparison to the world: 31
Labor force—by occupation: agriculture: 2%
industry: 13%
services: 6%
industry and services: 76%
manufacturing: 3% (2006 est.)
Unemployment rate: 6.3% (2017 est.)
7% (2016 est.)
country comparison to the world: 94
Population below poverty line: 9.4% (2008 est.)
note: this figure is the Low Income Cut-Off, a calculation
that results in higher figures than found in many
comparable economies; Canada does not have an official
poverty line Household income or consumption by percentage share:
lowest 10%: 2.6%
highest 10%: 24.8% (2000)
Budget: revenues: 649.6 billion (2017 est.)
expenditures: 665.7 billion (2017 est.)
Taxes and other revenues:
39.3% (of GDP) (2017 est.)
country comparison to the world: 48
Budget surplus (+) or deficit (-): -1% (of GDP) (2017 est.)
country comparison to the world: 77
Public debt:
89.7% of GDP (2017 est.)
91.1% of GDP (2016 est.)
note: figures are for gross general government debt, as
opposed to net federal debt; gross general government
debt includes both intragovernmental debt and the debt of
public entities at the sub-national level country comparison
to the world: 25
Fiscal year: 1 April—31 March
Inflation rate (consumer prices): 1.6% (2017 est.)
1.4% (2016 est.)
country comparison to the world: 87
Current account balance:
-$48.75 billion (2017 est.)
-$49.32 billion (2016 est.)
country comparison to the world: 204
Exports: $423.5 billion (2017 est.)
$393.5 billion (2016 est.)
country comparison to the world: 11
Exports—partners: US 76.4%, China 4.3% (2017)
Exports—commodities: motor vehicles and parts, industrial
machinery, aircraft, telecommunications equipment;
chemicals, plastics, fertilizers; wood pulp, timber, crude
petroleum, natural gas, electricity, aluminum _ Imports:
$442.1 billion (2017 est.)
$413.4 billion (2016 est.)
country comparison to the world: 12
Imports—commodities: machinery and equipment, motor
vehicles and parts, crude oil, chemicals, electricity, durable
consumer goods Imports—partners: US 51.5%, China 12.6%,
Mexico 6.3% (2017)
Reserves of foreign exchange and gold:
$86.68 billion (31 December 2017 est.)
$82.72 billion (31 December 2016 est.)
country comparison to the world: 28
Debt—external:
$1.608 trillion (31 March 2016 est.)
$1.55 trillion (31 March 2015 est.)
country comparison to the world: 13
Exchange rates: Canadian dollars (CAD) per US dollar—
1.308 (2017 est.)
1.3256 (2016 est.)
1.3256 (2015 est.)
1.2788 (2014 est.)
1.0298 (2013 est.)','d36451ed2dc6e2959b0a6d160afd65ca9db65e84e2f52cef9cc5e6621fbaadd3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee4e9ae7500074c84a7f0ce5217d9fa310ea55c553123d2ddd1d4506812454e',2021,'CO','Colombia','economy',440,'Economy—overview: Ecuador is substantially dependent on its
petroleum resources, which accounted for about a third of
the country’s export earnings in 2017. Remittances from
overseas Ecuadorian are also important.
In 1999/2000, Ecuador’s economy suffered from a
banking crisis that lead to some reforms, including
adoption of the US dollar as legal tender. Dollarization
stabilized the economy, and positive growth returned in
most of the years that followed. China has become
Ecuador’s largest foreign lender since 2008 and now
accounts for 77.7% of the Ecuador’s bilateral debt. Various
economic policies under the CORREA administration, such
as an announcement in 2017 that Ecuador would terminate
13 bilateral investment treaties—including one with the US,
generated economic uncertainty and discouraged private
investment.
Faced with a 2013 trade deficit of $1.1 billion, Ecuador
imposed tariff surcharges from 5% to 45% on an estimated
32% of imports. Ecuador’s economy fell into recession in
2015 and remained in recession in 2016. Declining oil
prices and exports forced the CORREA administration to
cut government oulays. Foreign investment in Ecuador is
low as a result of the unstable regulatory environment and
weak rule of law.
n April of 2017, Lenin MORENO was elected President
of Ecuador by popular vote. His immediate challenge was
to reengage the private sector to improve cash flow in the
country. Ecuador’s economy returned to positive, but
sluggish, growth. In early 2018, the MORENO
administration held a public referendum on seven economic
and political issues in a move counter to CORREA-
administration policies, reduce corruption, strengthen
democracy, and revive employment and the economy. The
referendum resulted in repeal of taxes associated with
recovery from the earthquake of 2016, reduced restrictions
on metal mining in the Yasuni Intangible Zone—a protected
area, and several political reforms.
GDP (purchasing power parity):
$193 billion (2017 est.)
$188.6 billion (2016 est.)
$190.9 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 66
GDP (official exchange rate):
$104.3 billion (2017 est.)
GDP—real growth rate: 2.4% (2017 est.)
-1.2% (2016 est.)
0.1% (2015 est.)
country comparison to the world: 138
GDP—per capita (PPP): $11,500 (2017 est.)
$11,400 (2016 est.)
$11,700 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 132
Gross national saving:
25.9% of GDP (2017 est.)
26.4% of GDP (2016 est.)
24.7% of GDP (2015 est.)
country comparison to the world: 51
GDP—composition, by end use:
household consumption: 60.7% (2017 est.)
government consumption: 14.4% (2017 est.)
investment in fixed capital: 24.3% (2017 est.)
investment in inventories: 1% (2017 est.)
exports of goods and services: 20.8% (2017 est.)
imports of goods and services: -21.3% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 6.7% (2017 est.)
industry: 32.9% (2017 est.)
services: 60.4% (2017 est.)
Agriculture—products: bananas, coffee, cocoa, rice, potatoes,
cassava (manioc, tapioca), plantains, sugarcane; cattle,
sheep, pigs, beef, pork, dairy products; fish, shrimp; balsa
wood Industries: petroleum, food processing, textiles, wood
products, chemicals
Industrial production growth rate:
-0.6% (2017 est.)
note: excludes oil refining
country comparison to the world: 173
Labor force: 8.086 million (2017 est.)
country comparison to the world: 62
Labor force—by occupation: agriculture: 26.1%
industry: 18.4%
services: 55.5% (2017 est.)
Unemployment rate: 4.6% (2017 est.)
5.2% (2016 est.)
country comparison to the world: 66
Population below poverty line: 21.5% (December 2017 est.)
Household income or consumption by percentage share: Jowest 10%:
1.4%
highest 10%: 35.4% (2012 est.)
note: data are for urban households only
Budget: revenues: 33.43 billion (2017 est.)
expenditures: 38.08 billion (2017 est.)
Taxes and other revenues:
32% (of GDP) (2017 est.)
country comparison to the world: 69
Budget surplus (+) or deficit (-): -4.5% (of GDP) (2017 est.)
country comparison to the world: 164
Public debt:
45.4% of GDP (2017 est.)
43.2% of GDP (2016 est.)
country comparison to the world: 114
Fiscal year: Calendar year
Inflation rate (consumer prices): 0.4% (2017 est.)
1.7% (2016 est.)
country comparison to the world: 23
Current account balance:
-§349 million (2017 est.)
$1.442 billion (2016 est.)
country comparison to the world: 109
Exports: $19.62 billion (2017 est.)
$16.8 billion (2016 est.)
country comparison to the world: 70
Exports—partners: US 31.5%, Vietnam 7.6%, Peru 6.7%, Chile
6.5%, Panama 4.9%, Russia 4.4%, China 4% (2017) Exports—
commodities: petroleum, bananas, cut flowers, shrimp, cacao,
coffee, wood, fish
Imports: $19.31 billion (2017 est.)
$15.86 billion (2016 est.)
country comparison to the world: 78
Imports—commodities: industrial materials, fuels and
lubricants, nondurable consumer goods
Imports—partners: US 22.8%, China 15.4%, Colombia 8.7%,
Panama 6.4%, Brazil 4.4%, Peru 4.2% (2017) Reserves of
foreign exchange and gold:
$2.395 billion (31 December 2017 est.)
$4.259 billion (31 December 2016 est.)
country comparison to the world: 116
Debt—external:
$39.29 billion (31 December 2017 est.)
$38.14 billion (31 December 2016 est.)
country comparison to the world: 77
Exchange rates: the US dollar became Ecuador’s currency in
2001','9e75e1cd2f79780057902475a262e063480e00c20ddc73dba6cc5115e53b5671','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('935de005315e728034eb8f1d498d17291203f163f5dc45302fe6ac38fc8fe8b6',2021,'FO','Faroe Islands','economy',507,'Economy—overview: The Faroese economy has experienced a
period of significant growth since 2011, due to higher fish
prices and increased salmon farming and catches in the
pelagic fisheries. Fishing has been the main source of
income for the Faroe Islands since the late 19th century,
but dependence on fishing makes the economy vulnerable
to price fluctuations. Nominal GDP, measured in current
prices, grew 5.6% in 2015 and 6.8% in 2016. GDP growth
was forecast at 6.2% in 2017, slowing to 0.5% in 2018, due
to lower fisheries quotas, higher oil prices and fewer
farmed salmon combined with lower salmon prices. The
fisheries sector accounts for about 97% of exports, and half
of GDP. Unemployment is low, estimated at 2.1% in early
2018. Aided by an annual subsidy from Denmark, which
amounts to about 11% of Faroese GDP, Faroese have a
standard of living equal to that of Denmark. The Faroe
Islands have bilateral free trade agreements with the EU,
Iceland, Norway, Switzerland, and Turkey.
For the first time in 8 years, the Faroe Islands managed
to generate a public budget surplus in 2016, a trend which
continued in 2017. The local government intends to use this
to reduce public debt, which reached 38% of GDP in 2015.
A fiscal sustainability analysis of the Faroese economy
shows that a long-term tightening of fiscal policy of 5% of
GDP is required for fiscal sustainability.
Increasing public infrastructure investments are likely
to lead to continued growth in the short term, and the
Faroese economy is becoming somewhat more diversified.
Growing industries include financial services, petroleum-
related businesses, shipping, maritime manufacturing
services, civil aviation, IT, telecommunications, and
tourism.
GDP (purchasing power parity):
$2.001 billion (2014 est.)
$1.89 billion (2013 est.)
$1.608 billion (2012 est.)
country comparison to the world: 197
GDP (official exchange rate):
$2.765 billion (2014 est.)
GDP—real growth rate: 5.9% (2017 est.)
7.9% (2016 est.)
2.4% (2015 est.)
country comparison to the world: 35
GDP—per capita (PPP): $40,000 (2014 est.)
country comparison to the world: 45
Gross national saving:
25.7% of GDP (2012 est.)
25.2% of GDP (2011 est.)
25.9% of GDP (2010 est.)
country comparison to the world: 53
GDP—composition, by end use:
household consumption: 52% (2013)
government consumption: 29.6% (2013)
investment in fixed capital: 18.4% (2013)
GDP—composition, by sector of origin:
agriculture: 18% (2013 est.)
industry: 39% (2013 est.)
services: 43% (2013 est.)
Agriculture—products: milk, potatoes, vegetables, sheep,
salmon, herring, mackerel and other fish Industries: fishing,
fish processing, tourism, small ship repair and
refurbishment, handicrafts Industrial production growth rate:
3.4% (2009 est.)
country comparison to the world: 91
Labor force: 27,540 (2017 est.)
country comparison to the world: 206
Labor force—by occupation: agriculture: 15%
industry: 15%
services: 70% (December 2016 est.)
Unemployment rate: 2.2% (2017 est.)
3.4% (2016 est.)
country comparison to the world: 20
Population below poverty line: 10% (2015 est.)
Household income or consumption by percentage share: Jowest 10%:
NA
highest 10%: NA
Budget: revenues: 835.6 million (2014 est.)
expenditures: 883.8 million (2014)
note: Denmark supplies the Faroe Islands with almost one-
third of its public funds
Taxes and other revenues:
30.2% (of GDP) (2014 est.)
country comparison to the world: 76
Budget surplus (+) or deficit (-): -1.7% (of GDP) (2014 est.)
country comparison to the world: 95
Public debt:
35% of GDP (2014 est.)
country comparison to the world: 152
Fiscal year: Calendar year
Inflation rate (consumer prices): -0.3% (2016)
-1.7% (2015)
country comparison to the world: 8
Exports: $1.184 billion (2016 est.)
$1.019 billion (2015 est.)
country comparison to the world: 153
Exports—partners: Russia 26.4%, UK 14.1%, Germany 8.4%,
China 7.9%, Spain 6.8%, Denmark 6.2%, US 4.7%, Poland
4.4%, Norway 4.1% (2017) Exports—commodities: fish and fish
products (97%) (2017 est.)
Imports: $978.4 million (2016 est.)
$906.1 million (2015 est.)
country comparison to the world: 186
Imports—commodities: goods for household consumption,
machinery and transport equipment, fuels, raw materials
and semi-manufactures, Cars Imports—partners: Denmark
33%, China 10.7%, Germany 7.6%, Poland 6.8%, Norway
6.7%, Ireland 5%, Chile 4.3% (20177) Debt—external:
$387.6 million (2012)
$274.5 million (2010)
country comparison to the world: 182
Exchange rates: Danish kroner (DKK) per US dollar—
6.586 (2017 est.)
6.7269 (2016 est.)
6.7269 (2015 est.)
6.7236 (2014 est.)
5.6125 (2013 est.)','281eac09aecedb2cd31001370ba7230ef2f267f407728da0aae259dd33b176aa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54440275289c4824dc95f8b4f121c4f664b52ad29a6d2dc14361df074255be73',2021,'CN','China','economy',590,'Economy—overview: India’s diverse economy encompasses
traditional village farming, modern agriculture,
handicrafts, a wide range of modern industries, and a
multitude of services. Slightly less than half of the
workforce is in agriculture, but services are the major
source of economic growth, accounting for nearly two-
thirds of India’s output but employing less than one-third of
its labor force. India has capitalized on its large educated
English-speaking population to become a major exporter of
information technology services, business outsourcing
services, and software workers. Nevertheless, per capita
income remains below the world average. India is
developing into an open-market economy, yet traces of its
past autarkic policies remain. Economic liberalization
measures, including industrial deregulation, privatization
of state-owned enterprises, and reduced controls on foreign
trade and investment, began in the early 1990s and served
to accelerate the country’s growth, which averaged nearly
7% per year from 1997 to 2017.
India’s economic growth slowed in 2011 because of a
decline in investment caused by high interest rates, rising
inflation, and investor pessimism about the government’s
commitment to further economic reforms and about slow
world growth. Investors’ perceptions of India improved in
early 2014, due to a reduction of the current account
deficit and expectations of post-election economic reform,
resulting in a surge of inbound capital flows and
stabilization of the rupee. Growth rebounded in 2014
through 2016. Despite a high growth rate compared to the
rest of the world, India’s government-owned banks faced
mounting bad debt, resulting in low credit growth. Rising
Macroeconomic imbalances in India and improving
economic conditions in Western countries led investors to
shift capital away from India, prompting a_ sharp
depreciation of the rupee through 2016.
The economy slowed again in 2017, due to shocks of
“demonetizaton” in 2016 and introduction of GST in 2017.
Since the election, the government has passed an
important goods and services tax bill and raised foreign
direct investment caps in some sectors, but most economic
reforms have focused on administrative and governance
changes, largely because the ruling party remains a
minority in India’s upper house of Parliament, which must
approve most bills.
India has a young population and corresponding low
dependency ratio, healthy savings and investment rates,
and is increasing integration into the global economy.
However, long-term challenges remain _ significant,
including: India’s discrimination against women and girls,
an inefficient power generation and distribution system,
ineffective enforcement of intellectual property rights,
decades-long civil litigation dockets, inadequate transport
and agricultural infrastructure, limited non-agricultural
employment opportunities, high spending and _ poorly
targeted subsidies, inadequate availability of quality basic
and higher education, and accommodating rural-to-urban
migration.
GDP (purchasing power parity):
$9.474 trillion (2017 est.)
$8.88 trillion (2016 est.)
$8.291 trillion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 3
GDP (official exchange rate):
$2.602 trillion (2017 est.)
GDP—real growth rate: 6.7% (2017 est.)
7.1% (2016 est.)
8.2% (2015 est.)
country comparison to the world: 27
GDP—per capita (PPP): $7,200 (2017 est.)
$6,800 (2016 est.)
$6,500 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 156
Gross national saving:
28.8% of GDP (2017 est.)
29.7% of GDP (2016 est.)
30.7% of GDP (2015 est.)
country comparison to the world: 36
GDP—composition, by end use:
household consumption: 59.1% (2017 est.)
government consumption: 11.5% (2017 est.)
investment in fixed capital: 28.5% (2017 est.)
investment in inventories: 3.9% (2017 est.)
exports of goods and services: 19.1% (2017 est.)
imports of goods and services: -22% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 15.4% (2016 est.)
industry: 23% (2016 est.)
services: 61.5% (2016 est.)
Agriculture—products: rice, wheat, oilseed, cotton, jute, tea,
sugarcane, lentils, onions, potatoes; dairy products, sheep,
goats, poultry; fish Industries: textiles, chemicals, food
processing, steel, transportation equipment, cement,
mining, petroleum, machinery, software, pharmaceuticals
Industrial production growth rate:
53.9% (2017 est.)
country comparison to the world: 49
Labor force: 521.9 million (2017 est.)
country comparison to the world: 2
Labor force—by occupation: agriculture: 47%
industry: 22%
services: 31% (FY 2014 est.)
Unemployment rate: 8.5% (2017 est.)
8.5% (2016 est.)
country comparison to the world: 122
Population below poverty line: 21.9% (2011 est.)
Household income or consumption by percentage share: Jowest 10%:
3.6%
highest 10%: 29.8% (2011)
Budget: revenues: 238.2 billion (2017 est.)
expenditures: 329 billion (2017 est.)
Taxes and other revenues:
9.2% (of GDP) (2017 est.)
country comparison to the world: 215
Budget surplus (+) or deficit (-): -3.5% (of GDP) (2017 est.)
country comparison to the world: 146
Public debt: 71.2% of GDP (2017 est.)
69.5% of GDP (2016 est.)
note: data cover central government debt, and exclude debt
instruments issued (or owned) by government entities
other than the treasury; the data include treasury debt held
by foreign entities; the data exclude debt issued by
subnational entities, as well as intragovernmental debt;
intragovernmental debt consists of treasury borrowings
from surpluses in the social funds, such as for retirement,
medical care, and unemployment; debt instruments for the
social funds are not sold at public auctions country
comparison to the world: 47
Fiscal year: 1 April—31 March
Inflation rate (consumer prices): 3.6% (2017 est.)
4.5% (2016 est.)
country comparison to the world: 143
Current account balance:
-$48.66 billion (2017 est.)
-$14.35 billion (2016 est.)
country comparison to the world: 203
Exports: $304.1 billion (2017 est.)
$268.6 billion (2016 est.)
country comparison to the world: 19
Exports—partners: US 15.6%, UAE 10.2%, Hong Kong 4.9%,
China 4.3% (2017)
Exports—commodities: petroleum products, precious stones,
vehicles, machinery, iron and _ steel, chemicals,
pharmaceutical products, cereals, apparel Imports: $452.2
billion (2017 est.)
$376.1 billion (2016 est.)
country comparison to the world: 11
Imports—commodities: crude oil, precious stones, machinery,
chemicals, fertilizer, plastics, iron and steel Imports—partners:
China 16.3%, US 5.5%, UAE 5.2%, Saudi Arabia 4.8%,
Switzerland 4.7% (2017) Reserves of foreign exchange and gold:
$409.8 billion (31 December 2017 est.)
$359.7 billion (31 December 2016 est.)
country comparison to the world: 8
Debt—external:
$501.6 billion (31 December 2017 est.)
$456.4 billion (31 December 2016 est.)
country comparison to the world: 24
Exchange rates: Indian rupees (INR) per US dollar—
65.17 (2017 est.)
67.195 (2016 est.)
67.195 (2015 est.)
64.152 (2014 est.)
61.03 (2013 est.)','d4a21db61c67e919b1ac0d2d3ab10c3ec89dc8670bce67dc477c5ee769c0021f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0e9291094ab200d64d788aec34b594de48bc0c9dadd55ac76da8ddfb01e6510',2021,'EG','Egypt','economy',605,'Economy—overview: Israel has a technologically advanced free
market economy. Cut diamonds, high-technology
equipment, and pharmaceuticals are among its leading
exports. Its major imports include crude oil, grains, raw
materials, and military equipment. Israel usually posts
sizable trade deficits, which are offset by tourism and other
service exports, as well as significant foreign investment
inflows.
Between 2004 and 2013, growth averaged nearly 5%
per year, led by exports. The global financial crisis of 2008-
09 spurred a brief recession in Israel, but the country
entered the crisis with solid fundamentals, following years
of prudent fiscal policy and a resilient banking sector.
Israel’s economy also weathered the 2011 Arab Spring
because strong trade ties outside the Middle East insulated
the economy from spillover effects.
Slowing domestic and international demand and
decreased investment resulting from Israel’s uncertain
security situation reduced GDP growth to an average of
roughly 2.8% per year during the period 2014-17. Natural
gas fields discovered off Israel’s coast since 2009 have
brightened Israel’s energy security outlook. The Tamar and
Leviathan fields were some of the world’s largest offshore
natural gas finds in the last decade. Political and regulatory
issues have delayed the development of the massive
Leviathan field, but production from Tamar provided a
0.8% boost to Israel’s GDP in 2013 and a 0.3% boost in
2014. One of the most carbon intense OECD countries,
Israel generates about 57% of its power from coal and only
2.6% from renewable sources.
Income inequality and high housing and commodity
prices continue to be a concern for many Israelis. Israel’s
income inequality and poverty rates are among the highest
of OECD countries, and there is a broad perception among
the public that a small number of “tycoons” have a cartel-
like grip over the major parts of the economy. Government
officials have called for reforms to boost the housing supply
and to increase competition in the banking sector to
address these public grievances. Despite calls for reforms,
the restricted housing supply continues to impact younger
Israelis seeking to purchase homes. Tariffs and non-tariff
barriers, coupled with guaranteed prices and customs
tariffs for farmers kept food prices high in 2016. Private
consumption is expected to drive growth through 2018,
with consumers benefitting from low inflation and a strong
currency.
In the long term, Israel faces structural issues including
low labor participation rates for its fastest growing social
segments—the ultraorthodox and Arab-Israeli communities.
Also, Israel’s progressive, globally competitive, knowledge-
based technology sector employs only about 8% of the
workforce, with the rest mostly employed in manufacturing
and services—sectors which face downward wage
pressures from global competition. Expenditures on
educational institutions remain low compared to most other
OECD countries with similar GDP per capita.
GDP (purchasing power parity):
$317.1 billion (2017 est.)
$307 billion (2016 est.)
$295.3 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 54
GDP (official exchange rate):
$350.7 billion (2017 est.)
GDP—real growth rate: 3.3% (2017 est.)
4% (2016 est.)
2.6% (2015 est.)
country comparison to the world: 105
GDP—per capita (PPP): $36,400 (2017 est.)
$35,900 (2016 est.)
$35,200 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 55
Gross national saving:
23.6% of GDP (2017 est.)
24.2% of GDP (2016 est.)
25% of GDP (2015 est.)
country comparison to the world: 72
GDP—composition, by end use:
household consumption: 55.1% (2017 est.)
government consumption: 22.8% (2017 est.)
investment in fixed capital: 20.1% (2017 est.)
investment in inventories: 0.7% (2017 est.)
exports of goods and services: 28.9% (2017 est.)
imports of goods and services: -27.5% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 2.4% (2017 est.)
industry: 26.5% (2017 est.)
services: 69.5% (2017 est.)
Agriculture—products: Citrus, vegetables, cotton; beef, poultry,
dairy products
Industries: high-technology products (including aviation,
communications, computer-aided design and manufactures,
medical electronics, fiber optics), wood and paper
products, potash and phosphates, food, beverages, and
tobacco, caustic soda, cement, pharmaceuticals,
construction, metal products, chemical products, plastics,
cut diamonds, textiles, footwear Industrial production growth
rate:
3.5% (2017 est.)
country comparison to the world: 86
Labor force: 4.021 million (2017 est.)
country comparison to the world: 93
Labor force—by occupation: agriculture: 1.1%
industry: 17.3%
services: 81.6% (2015 est.)
Unemployment rate: 4.2% (2017 est.)
4.8% (2016 est.)
country comparison to the world: 55
Population below poverty line: 22% (2014 est.) (2014 est.)
note: Israel’s poverty line is $7.30 per person per day
Household income or consumption by percentage share: Jowest 10%:
1.7%
highest 10%: 31.3% (2010)
Budget: revenues: 93.11 billion (2017 est.)
expenditures: 100.2 billion (2017 est.)
Taxes and other revenues:
26.5% (of GDP) (2017 est.)
country comparison to the world: 110
Budget surplus (+) or deficit (-): -2% (of GDP) (2017 est.)
country comparison to the world: 105
Public debt:
60.9% of GDP (2017 est.)
62.3% of GDP (2016 est.)
country comparison to the world: 73
Fiscal year: Calendar year
Inflation rate (consumer prices): 0.2% (2017 est.)
-0.5% (2016 est.)
country comparison to the world: 17
Current account balance:
$10.12 billion (2017 est.)
$11.94 billion (2016 est.)
country comparison to the world: 22
Exports: $58.67 billion (2017 est.)
$56.17 billion (2016 est.)
country comparison to the world: 48
Exports—partners: US 28.8%, UK 8.2%, Hong Kong 7%, China
5.4%, Belgium 4.5% (2017)
Exports—commodities: machinery and equipment, software,
cut diamonds, agricultural products, chemicals, textiles and
apparel Imports: $68.61 billion (2017 est.)
$63.9 billion (2016 est.)
country comparison to the world: 46
Imports—commodities: raw materials, military equipment,
investment goods, rough diamonds, fuels, grain, consumer
goods Imports—partners: US 11.7%, China 9.5%, Switzerland
8%, Germany 6.8%, UK 6.2%, Belgium 5.9%, Netherlands
4.2%, Turkey 4.2%, Italy 4% (2017) Reserves of foreign
exchange and gold:
$113 billion (31 December 2017 est.)
$95.45 billion (31 December 2016 est.)
country comparison to the world: 23
Debt—external:
$88.66 billion (31 December 2017 est.)
$87.96 billion (31 December 2016 est.)
country comparison to the world: 54
Exchange rates: new Israeli shekels (ILS) per US dollar—
3.606 (2017 est.)
3.8406 (2016 est.)
3.8406 (2015 est.)
3.8869 (2014 est.)
3.5779 (2013 est.)','f7c1f7da1a9d2b5799e36555bea6b81ba464ea4ceaaf44b14a4cbf6be4b8c4e9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33454d5243ba809e993370e589e0abfe0290ef8b6b79229dd17763febad2c512',2021,'KZ','Kazakhstan','economy',639,'Economy—overview: North Korea, one of the world’s most
centrally directed and least open economies, faces chronic
economic problems. Industrial capital stock is nearly
beyond repair as a result of years of underinvestment,
shortages of spare parts, and poor maintenance. Large-
scale military spending and development of its ballistic
missile and nuclear program severely draws off resources
needed for investment and civilian consumption. Industrial
and power outputs have stagnated for years at a fraction of
pre-1990 levels. Frequent weather-related crop failures
aggravated chronic food shortages caused by on-going
systemic problems, including a lack of arable _ land,
collective farming practices, poor soil quality, insufficient
fertilization, and persistent shortages of tractors and fuel.
The mid 1990s through mid-2000s were marked by
severe famine and widespread starvation. Significant food
aid was provided by the international community through
2009. Since that time, food assistance has declined
significantly. In the last few years, domestic corn and rice
production has improved, although domestic production
does not fully satisfy demand. A large portion of the
population continues to suffer from prolonged malnutrition
and poor living conditions. Since 2002, the government has
allowed semi-private markets to begin selling a wider range
of goods, allowing North Koreans to partially make up for
diminished public distribution system rations. It also
implemented changes in the management process of
communal farms in an effort to boost agricultural output.
In December 2009, North Korea carried out a
redenomination of its currency, capping the amount of
North Korean won that could be exchanged for the new
notes, and limiting the exchange to a one-week window. A
concurrent crackdown on markets and foreign currency
use yielded severe shortages and inflation, forcing
Pyongyang to ease the restrictions by February 2010. In
response to the sinking of the South Korean warship
Cheonan and the shelling of Yeonpyeong Island in 2010,
South Korea’s government cut off most aid, trade, and
bilateral cooperation activities. In February 2016, South
Korea ceased its remaining bilateral economic activity by
closing the Kaesong Industrial Complex in response to
North Korea’s fourth nuclear test a month earlier. This
nuclear test and another in September 2016 resulted in two
United Nations Security Council Resolutions that targeted
North Korea’s foreign currency earnings, particularly coal
and other mineral exports. Throughout 2017, North Korea’s
continued nuclear and missile tests led to a tightening of
UN sanctions, resulting in full sectoral bans on DPRK
exports and drastically limited key imports. Over the last
decade, China has been North Korea’s primary trading
partner.
The North Korean Government continues to stress its
goal of improving the overall standard of living, but has
taken few steps to make that goal a reality for its populace.
In 2016, the regime used two mass mobilizations—one
totaling 70 days and another 200 days—to spur the
population to increase production and _ complete
construction projects quickly. The regime released a five-
year economic development strategy in May 2016 that
outlined plans for promoting growth across sectors. Firm
political control remains the government’s overriding
concern, which likely will inhibit formal changes to North
Korea’s current economic system.
GDP (purchasing power parity):
$40 billion (2015 est.)
$40 billion (2014 est.)
$40 billion (2013 est.)
note: data are in 2015 US dollars
North Korea does not publish reliable National Income
Accounts data; the data shown are derived from purchasing
power parity (PPP) GDP estimates that were made by
Angus MADDISON in a study conducted for the OECD; his
figure for 1999 was extrapolated to 2015 using estimated
real growth rates for North Korea’s GDP and an inflation
factor based on the US GDP deflator; the results were
rounded to the nearest $10 billion.
country comparison to the world: 118
GDP (official exchange rate):
$28 billion (2013 est.)
GDP—real growth rate: -1.1% (2015 est.)
1% (2014 est.)
1.1% (2013 est.)
country comparison to the world: 204
GDP—per capita (PPP): $1,700 (2015 est.)
$1,800 (2014 est.)
$1,800 (2013 est.)
note: data are in 2015 US dollars
country comparison to the world: 214
Gross national saving: NA
GDP—composition, by end use:
household consumption: NA (2014 est.)
government consumption: NA (2014 est.)
investment in fixed capital: NA (2014 est.)
investment in inventories: NA (2014 est.)
exports of goods and services: 5.9% (2016 est.)
imports of goods and services: -11.1% (2016 est.)
GDP—composition, by sector of origin:
agriculture: 22.5% (2017 est.)
industry: 47.6% (2017 est.)
services: 29.9% (2017 est.)
Agriculture—products: rice, corn, potatoes, wheat, soybeans,
pulses, beef, pork, eggs, fruit, nuts Industries: military
products; machine building, electric power, chemicals;
mining (coal, iron ore, limestone, magnesite, graphite,
copper, zinc, lead, and precious metals), metallurgy;
textiles, food processing; tourism Industrial production growth
rate:
1% (2017 est.)
country comparison to the world: 156
Labor force: 14 million (2014 est.)
note: estimates vary widely
country comparison to the world: 41
Labor force—by occupation: agriculture: 37%
industry: 63% (2008 est.)
Unemployment rate: 25.6% (2013 est.)
25.5% (2012 est.)
country comparison to the world: 197
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 3.2 billion (2007 est.)
expenditures: 3.3 billion (2007 est.)
Taxes and other revenues:
11.4% (of GDP) (2007 est.)
note: excludes earnings from state-operated enterprises
country comparison to the world: 209
Budget surplus (+) or deficit (-): -0.4% (of GDP) (2007 est.)
country comparison to the world: 58
Fiscal year: Calendar year
Inflation rate (consumer prices): NA
Exports: $222 million (2018)
$4.582 billion (2017 est.)
$2.908 billion (2015 est.)
country comparison to the world: 188
Exports—partners: China 86.3% (2017)
Exports—commodities: minerals, metallurgical products,
manufactures (including armaments), textiles, agricultural
and fishery products Imports: $2.32 billion (2018 est.)
$3.86 billion (2016 est.)
country comparison to the world: 160
Imports—commodities: petroleum, coking coal, machinery and
equipment, textiles, grain Imports—partners: China 91.9%
(2017)
Debt—external: $5 billion (2013 est.)
country comparison to the world: 132
Exchange rates: North Korean won (KPW) per US dollar
(average market rate)—
135 (2017 est.)
130 (2016 est.)
130 (2015 est.)
98.5 (2013 est.)
155.5 (2012 est.)
ELECTRICITY ACCESS: ENERGY
population without electricity: 19 million (2017)
electrification—total population: 26% (2016)
electrification—urban areas: 36% (2016)
electrification—rural areas: 11% (2016)
Electricity—production: 16.57 billion kWh (2016 est.)
country comparison to the world: 87
Electricity—consumption: 13.89 billion kWh (2016 est.)
country comparison to the world: 83
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 154
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 165
Electricity—installed generating capacity: 10.01 million kW (2016
est.)
country comparison to the world: 60
Electricity—from fossil fuels: 45% of total installed capacity
(2016 est.)
country comparison to the world: 161
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 120
Electricity—from hydroelectric plants: 55% of total installed
Capacity (2017 est.)
country comparison to the world: 31
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 195
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 156
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 147
Crude oil—imports: 10,640 bbl/day (2015 est.)
country comparison to the world: 72
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 152
Refined petroleum products—production: 11,270 bbl/day (2015
est.)
country comparison to the world: 99
Refined petroleum products—consumption: 18,000 bbl/day (2016
est.)
country comparison to the world: 145
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 168
Refined petroleum products—imports: 8,260 bbl/day (2015 est.)
country comparison to the world: 151
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 152
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 163
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 130
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 144
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 153
Carbon dioxide emissions from consumption of energy: 27.83 million
Mt (2017 est.)
country comparison to the world: 74
Communications :: KOREA, NORTH
Telephones—fixed lines: total subscriptions: 1.18 million
subscriptions per 100 inhabitants: 5 (July 2016 est.)
country comparison to the world: 72
Telephones—mobile cellular:
total subscriptions: 3.606 million
subscriptions per 100 inhabitants: 14 (July 2016 est.)
country comparison to the world: 134
Telephone system: general assessment: nationwide fiber-optic
network; mobile-cellular service expanded beyond
Pyongyang; infrastructure underdeveloped yet growing
mobile penetration by means of foreign investment; low
broadband penetration; mobile penetration in North Korea
believed to stay well below other Asian nations due to
government restrictions; 3G network deployed among
universal population coverage (2018) domestic: fiber-optic
links installed down to the county level; telephone
directories unavailable; mobile service launched in late
2008 for the Pyongyang area and considerable progress in
expanding to other parts of the country since; fixed-lines
are 5 per 100 and mobile-cellular 14 per 100 persons
(2018) international: country code—850; satellite earth
stations—2 (1 Intelsat—Indian Ocean, 1 Russian—Indian
Ocean region); other international connections through
Moscow and Beijing Broadcast media: no independent media;
radios and TVs are pre-tuned to government stations; 4
government-owned TV stations; the Korean Workers’ Party
owns and operates the Korean Central Broadcasting
Station, and the state-run Voice of Korea operates an
external broadcast service; the government prohibits
listening to and jams foreign broadcasts (2019) Internet
country code: .kp
Economy—overview: After emerging from the 1950-53 war
with North Korea, South Korea emerged as one of the 20th
century''s most remarkable economic success stories,
becoming a developed, globally connected, high-technology
society within decades. In the 1960s, GDP per capita was
comparable with levels in the poorest countries in the
world. In 2004, South Korea’s GDP surpassed one trillion
dollars.
Beginning in the 1960s under President PARK Chung-
hee, the government promoted the import of raw materials
and technology, encouraged saving and investment over
consumption, kept wages low, and directed resources to
export-oriented industries that remain important to the
economy to this day. Growth surged under these policies,
and frequently reached double-digits in the 1960s and
1970s. Growth gradually moderated in the 1990s as the
economy matured, but remained strong enough to propel
South Korea into the ranks of the advanced economies of
the OECD by 1997. These policies also led to the
emergence of family-owned chaebol conglomerates such as
Daewoo, Hyundai, and Samsung, which retained their
dominant positions even as the government loosened its
grip on the economy amid the political changes of the
1980s and 1990s.
The Asian financial crisis of 1997-98 hit South Korea’s
companies hard because of their excessive reliance on
short-term borrowing, and GDP ultimately plunged by 7%
in 1998. South Korea tackled difficult economic reforms
following the crisis, including restructuring some chaebols,
increasing labor market flexibility, and opening up to more
foreign investment and imports. These steps lead to a
relatively rapid economic recovery. South Korea also began
expanding its network of free trade agreements to help
bolster exports, and has since implemented 16 free trade
agreements covering 58 countries—including the United
State and China—that collectively cover more than three-
quarters of global GDP.
In 2017, the election of President MOON Jae-in brought
a surge in consumer confidence, in part, because of his
successful efforts to increase wages and government
spending. These factors combined with an uptick in export
growth to drive real GDP growth to more than 3%, despite
disruptions in South Korea’s trade with China over the
deployment of a US missile defense system in South Korea.
In 2018 and beyond, South Korea will contend with
gradually slowing economic growth—in the 2-3% range—
not uncommon for advanced economies. This could be
partially offset by efforts to address challenges arising from
its rapidly aging population, inflexible labor market,
continued dominance of the chaebols, and heavy reliance
on exports rather than domestic consumption.
Socioeconomic problems also persist, and include rising
inequality, poverty among the elderly, high youth
unemployment, long working hours, low worker
productivity, and corruption.
GDP (purchasing power parity):
$2.035 trillion (2017 est.)
$1.974 trillion (2016 est.)
$1.918 trillion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 14
GDP (official exchange rate):
$1.54 trillion (2017 est.)
GDP—real growth rate: 3.1% (2017 est.)
2.9% (2016 est.)
2.8% (2015 est.)
country comparison to the world: 109
GDP—per capita (PPP): $39,500 (2017 est.)
$38,500 (2016 est.)
$37,600 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 46
Gross national saving:
36.6% of GDP (2017 est.)
36.3% of GDP (2016 est.)
36.6% of GDP (2015 est.)
country comparison to the world: 15
GDP—composition, by end use:
household consumption: 48.1% (2017 est.)
government consumption: 15.3% (2017 est.)
investment in fixed capital: 31.1% (2017 est.)
investment in inventories: 0% (2017 est.)
exports of goods and services: 43.1% (2017 est.)
imports of goods and services: -37.7% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 2.2% (2017 est.)
industry: 39.3% (2017 est.)
services: 58.3% (2017 est.)
Agriculture—products: rice, root crops, barley, vegetables,
fruit, cattle, pigs, chickens, milk, eggs, fish Industries:
electronics, telecommunications, automobile production,
chemicals, shipbuilding, steel Industrial production growth rate:
4.6% (2017 est.)
country comparison to the world: 63
Labor force: 27.75 million (2017 est.)
country comparison to the world: 23
Labor force—by occupation: agriculture: 4.8%
industry: 24.6%
services: 70.6% (2017 est.)
Unemployment rate: 3.7% (2017 est.)
3.7% (2016 est.)
country comparison to the world: 45
Population below poverty line: 14.4% (2016 est.)
Household income or consumption by percentage share: Jowest 10%:
6.8%
highest 10%: 48.5% (2015 est.)
Budget: revenues: 357.1 billion (2017 est.)
expenditures: 335.8 billion (2017 est.)
Taxes and other revenues:
23.2% (of GDP) (2017 est.)
country comparison to the world: 129
Budget surplus (+) or deficit (-): 1.4% (of GDP) (2017 est.)
country comparison to the world: 24
Public debt:
39.5% of GDP (2017 est.)
39.9% of GDP (2016 est.)
country comparison to the world: 133
Fiscal year: Calendar year
Inflation rate (consumer prices): 1.9% (2017 est.)
1% (2016 est.)
country comparison to the world: 97
Current account balance:
$78.46 billion (2017 est.)
$99.24 billion (2016 est.)
country comparison to the world: 6
Exports: $577.4 billion (2017 est.)
$512 billion (2016 est.)
country comparison to the world: 5
Exports—partners: China 25.1%, US 12.2%, Vietnam 8.2%,
Hong Kong 6.9%, Japan 4.7% (2017) Exports—commodities:
semiconductors, petrochemicals, automobile/auto parts,
ships, wireless communication equipment, flat displays,
steel, electronics, plastics, computers Imports: $457.5
billion (2017 est.)
$393.1 billion (2016 est.)
country comparison to the world: 9
Imports—commodities: crude oil/petroleum products,
semiconductors, natural gas, coal, steel, computers,
wireless communication equipment, automobiles, fine
chemicals, textiles Imports—partners: China 20.5%, Japan
11.5%, US 10.5%, Germany 4.2%, Saudi Arabia 4.1%
(2017) Reserves of foreign exchange and gold:
$389.2 billion (31 December 2017 est.)
$371.1 billion (31 December 2016 est.)
country comparison to the world: 9
Debt—external:
$384.6 billion (31 December 2017 est.)
$384.1 billion (31 December 2016 est.)
country comparison to the world: 29
Exchange rates: South Korean won (KRW) per US dollar—
1,130.48 (2017 est.)
1,160.41 (2016 est.)
1,160.77 (2015 est.)
1,130.95 (2014 est.)
1,052.96 (2013 est.)','d5b6cfe7f2e43975197c34808ebfa30d2cb371fcecf0ce975272e772f9a3572d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32de10c3ebfd0af5f4a0aba637427ae1503d17b5244101eee10b420e10834efb',2021,'RS','Serbia','economy',644,'country comparison to the world: 156
Labor force—by occupation: agriculture: 4.4%
industry: 17.4%
services: 78.2% (2017 est.)
Unemployment rate: 30.5% (2017 est.)
27.9% (2016 est.)
note: Kosovo has a large informal sector that may not be
reflected in these data country comparison to the world:
208
Population below poverty line: 17.6% (2015 est.)
Household income or consumption by percentage share: Jowest 10%:
3.8%
highest 10%: 22% (2015 est.)
Budget: revenues: 2.054 billion (2017 est.)
expenditures: 2.203 billion (2017 est.)
Taxes and other revenues:
29% (of GDP) (2017 est.)
country comparison to the world: 87
Budget surplus (+) or deficit (-): -2.1% (of GDP) (2017 est.)
country comparison to the world: 108
Public debt: 21.2% of GDP (2017 est.)
19.4% of GDP (2016 est.)
country comparison to the world: 186
Inflation rate (consumer prices): 1.5% (2017 est.)
0.3% (2016 est.)
country comparison to the world: 82
Current account balance:
-$467 million (2017 est.)
-$533 million (2016 est.)
country comparison to the world: 117
Exports: $428 million (2017 est.)
$340 million (2016 est.)
country comparison to the world: 179
Exports—partners: Albania 16%, India 14%, Macedonia, The
Former Yugo Rep of 12.1%, Serbia 10.6%, Switzerland
5.6%, Germany 5.4% (2017) Exports—commodities: mining and
processed metal products, scrap metals, leather products,
machinery, appliances, prepared foodstuffs, beverages and
tobacco, vegetable products, textiles and apparel Imports:
$3.223 billion (2017 est.)
$2.876 billion (2016 est.)
country comparison to the world: 145
Imports—commodities: foodstuffs, livestock, wood, petroleum,
chemicals, machinery, minerals, textiles, stone, ceramic
and glass products, electrical equipment Imports—partners:
Germany 12.4%, Serbia 12.3%, Turkey 9.6%, China 9.1%,
Italy 6.4%, Macedonia, The Former Yugo Rep of 5.1%,
Albania 5%, Greece 4.4% (2017) Reserves of foreign exchange
and gold:
$683.9 million (31 December 2016 est.)
$708.7 million (31 December 2015 est.)
country comparison to the world: 142
Debt—external: $506 million (31 December 2017 est.)
$448 million (31 December 2016 est.)
country comparison to the world: 179
Exchange rates: euros (EUR) per US dollar—
0.885 (2017 est.)
0.903 (2016 est.)
0.9214 (2015 est.)
0.885 (2014 est.)
0.7634 (2013 est.)
Economy—overview: Serbia has a transitional economy largely
dominated by market forces, but the state sector remains
Significant in certain areas. The economy relies on
manufacturing and exports, driven largely by foreign
investment. MILOSEVIC-era mismanagement of the
economy, an extended period of international economic
sanctions, civil war, and the damage to Yugoslavia’s
infrastructure and industry during the NATO airstrikes in
1999 left the economy worse off than it was in 1990. In
2015, Serbia’s GDP was 27.5% below where it was in 1989.
After former Federal Yugoslav President MILOSEVIC
was ousted in September 2000, the Democratic Opposition
of Serbia (DOS) coalition government implemented
stabilization measures and embarked on a market reform
program. Serbia renewed its membership in the IMF in
December 2000 and rejoined the World Bank and the
European Bank for Reconstruction and Development.
Serbia has made progress in trade liberalization and
enterprise restructuring and privatization, but many large
enterprises—including the power utilities,
telecommunications company, natural gas company, and
others—remain state-owned. Serbia has made some
progress towards EU membership, gaining candidate status
in March 2012. In January 2014, Serbia’s EU accession
talks officially opened and, as of December 2017, Serbia
had opened 12 negotiating chapters including one on
foreign trade. Serbia’s negotiations with the WTO are
advanced, with the country’s complete ban on the trade
and cultivation of agricultural biotechnology products
representing the primary remaining obstacle to accession.
Serbia maintains a three-year Stand-by Arrangement with
the IMF worth approximately $1.3 billion that is scheduled
to end in February 2018. The government has shown
progress implementing economic reforms, such as fiscal
consolidation, privatization, and reducing public spending.
Unemployment in Serbia, while relatively low (16% in
2017) compared with its Balkan neighbors, remains
significantly above the European average. Serbia is slowly
implementing structural economic reforms needed to
ensure the country’s long-term prosperity. Serbia reduced
its budget deficit to 1.7% of GDP and its public debt to 71%
of GDP in 2017. Public debt had more than doubled
between 2008 and 2015. Serbia’s concerns about inflation
and exchange-rate stability preclude the use _ of
expansionary monetary policy.
Major economic challenges ahead include: stagnant
household incomes; the need for private sector job
creation; structural reforms of state-owned companies;
strategic public sector reforms; and the need for new
foreign direct investment. Other serious longer-term
challenges include an inefficient judicial system, high levels
of corruption, and an aging population. Factors favorable to
Serbia’s economic growth include the economic reforms it
is undergoing as part of its EU accession process and IMF
agreement, its strategic location, a relatively inexpensive
and skilled labor force, and free trade agreements with the
EU, Russia, Turkey, and countries that are members of the
Central European Free Trade Agreement.
GDP (purchasing power parity):
$105.7 billion (2017 est.)
$103.8 billion (2016 est.)
$101 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 82
GDP (official exchange rate):
$41.43 billion (2017 est.)
GDP—real growth rate: 1.9% (2017 est.)
2.8% (2016 est.)
0.8% (2015 est.)
country comparison to the world: 158
GDP—per capita (PPP): $15,100 (2017 est.)
$14,700 (2016 est.)
$14,200 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 111
Gross national saving:
15.3% of GDP (2017 est.)
16% of GDP (2016 est.)
14.1% of GDP (2015 est.)
country comparison to the world: 134
GDP—composition, by end use:
household consumption: 78.2% (2017 est.)
government consumption: 10.1% (2017 est.)
investment in fixed capital: 18.5% (2017 est.)
investment in inventories: 2% (2017 est.)
exports of goods and services: 52.5% (2017 est.)
imports of goods and services: -61.3% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 9.8% (2017 est.)
industry: 41.1% (2017 est.)
services: 49.1% (2017 est.)
Agriculture—products: wheat, maize, sunflower, sugar beets,
grapes/wine, fruits (raspberries, apples, sour cherries),
vegetables (tomatoes, peppers, potatoes), beef, pork, and
meat products, milk and _ dairy products Industries:
automobiles, base metals, furniture, food processing,
machinery, chemicals, sugar, tires, clothes,
pharmaceuticals Industrial production growth rate:
3.9% (2017 est.)
country comparison to the world: 78
Labor force: 2.92 million (2017 est.)
country comparison to the world: 106
Labor force—by occupation: agriculture: 19.4%
industry: 24.5%
services: 56.1% (2017 est.)
Unemployment rate: 14.1% (2017 est.)
15.9% (2016 est.)
country comparison to the world: 170
Population below poverty line: 8.9% (2014 est.)
Household income or consumption by percentage share: Jowest 10%:
2.2%
highest 10%: 23.8% (2011)
Budget: revenues: 17.69 billion (2017 est.)
expenditures: 17.59 billion (2017 est.)
note: data include both central government and _ local
goverment budgets
Taxes and other revenues:
42.7% (of GDP) (2017 est.)
country comparison to the world: 30
Budget surplus (+) or deficit (-): 0.2% (of GDP) (2017 est.)
country comparison to the world: 43
Public debt:
62.5% of GDP (2017 est.)
73.1% of GDP (2016 est.)
country comparison to the world: 70
Inflation rate (consumer prices): 3.1% (2017 est.)
1.1% (2016 est.)
country comparison to the world: 133
Current account balance:
-$2.354 billion (2017 est.)
-$1.189 billion (2016 est.)
country comparison to the world: 170
Exports: $15.92 billion (2017 est.)
$13.99 billion (2016 est.)
country comparison to the world: 73
Exports—partners: Italy 13.5%, Germany 12.8%, Bosnia and
Herzegovina 8.2%, Russia 6%, Romania 4.9% (2017) Exports
—commodities: automobiles, iron and steel, rubber, clothes,
wheat, fruit and vegetables, nonferrous metals, electric
appliances, metal products, weapons and ammunition
Imports: $20.44 billion (2017 est.)
$17.63 billion (2016 est.)
country comparison to the world: 76
Imports—commodities: machinery and transport equipment,
fuels and lubricants, manufactured goods, chemicals, food
and live animals, raw materials Imports—partners: Germany
12.7%, Italy 10%, China 8.2%, Russia 7.3%, Hungary 4.9%,
Poland 4.1% (2017) Reserves of foreign exchange and gold:
$11.91 billion (31 December 2017 est.)
$10.76 billion (31 December 2016 est.)
country comparison to the world: 70
Debt—external:
$29.5 billion (31 December 2017 est.)
$30.38 billion (31 December 2016 est.)
country comparison to the world: 81
Exchange rates: Serbian dinars (RSD) per US dollar—
112.4 (2017 est.)
111.278 (2016 est.)
111.278 (2015 est.)
108.811 (2014 est.)
88.405 (2013 est.)','c25000aa83b6e2a81c48db42b1956127320c91fea6f011134ef209cd99aee39c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abe1225b5c0e39c677073c5b8bf44b11e5d48b3dae20e663c19e3d6c950a1960',2021,'KW','Kuwait','economy',659,'Economy—overview: The government of Laos, one of the few
remaining one-party communist states, began
decentralizing control and encouraging private enterprise
in 1986. Economic growth averaged more than 6% per year
in the period 1988-2008, and Laos’ growth has more
recently been amongst the fastest in Asia, averaging more
than 7% per year for most of the last decade.
Nevertheless, Laos remains a country with an
underdeveloped infrastructure, particularly in rural areas.
It has a basic, but improving, road system, and limited
external and internal land-line telecommunications.
Electricity is available to 83% of the _ population.
Agriculture, dominated by rice cultivation in lowland areas,
accounts for about 20% of GDP and 73% of total
employment. Recently, the country has faced a persistent
current account deficit, falling foreign currency reserves,
and growing public debt.
Laos’ economy is heavily dependent on capital-intensive
natural resource exports. The economy has benefited from
high-profile foreign direct investment in hydropower dams
along the Mekong River, copper and gold mining, logging,
and construction, although some _ projects in these
industries have drawn criticism for their environmental
impacts.
Laos gained Normal Trade Relations status with the US
in 2004 and applied for Generalized System of Preferences
trade benefits in 2013 after being admitted to the World
Trade Organization earlier in the year. Laos held the
chairmanship of ASEAN in 2016. Laos is in the process of
implementing a value-added tax system. The government
appears committed to raising the country’s profile among
foreign investors and has developed special economic
zones replete with generous tax incentives, but a limited
labor pool, a small domestic market, and corruption remain
impediments to investment. Laos also has ongoing
problems with the business environment, including onerous
registration requirements, a gap between legislation and
implementation, and unclear or conflicting regulations.
GDP (purchasing power parity):
$49.34 billion (2017 est.)
$46.16 billion (2016 est.)
$43.13 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 111
GDP (official exchange rate):
$16.97 billion (2017 est.)
GDP—real growth rate: 6.9% (2017 est.)
7% (2016 est.)
7.3% (2015 est.)
country comparison to the world: 22
GDP—per capita (PPP): $7,400 (2017 est.)
$7,000 (2016 est.)
$6,600 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 155
Gross national saving:
22.7% of GDP (2017 est.)
21.3% of GDP (2016 est.)
15.8% of GDP (2015 est.)
country comparison to the world: 79
GDP—composition, by end use:
household consumption: 63.7% (2017 est.)
government consumption: 14.1% (2017 est.)
investment in fixed capital: 30.9% (2017 est.)
investment in inventories: 3.1% (2017 est.)
exports of goods and services: 34.6% (2017 est.)
imports of goods and services: -43.2% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 20.9% (2017 est.)
industry: 33.2% (2017 est.)
services: 45.9% (2017 est.)
Agriculture—products: Sweet potatoes, vegetables, corn, coffee,
sugarcane, tobacco, cotton, tea, peanuts, rice; cassava
(manioc, tapioca), water buffalo, pigs, cattle, poultry
Industries: mining (copper, tin, gold, gypsum); timber,
electric power, agricultural processing, rubber,
construction, garments, cement, tourism Industrial production
growth rate:
8% (2017 est.)
country comparison to the world: 23
Labor force: 3.582 million (2017 est.)
country comparison to the world: 100
Labor force—by occupation: agriculture: 73.1%
industry: 6.1%
services: 20.6% (2012 est.)
Unemployment rate: 0.7% (2017 est.)
0.7% (2016 est.)
country comparison to the world: 4
Population below poverty line: 22% (2013 est.)
Household income or consumption by percentage share: Jowest 10%:
3.3%
highest 10%: 30.3% (2008)
Budget: revenues: 3.099 billion (2017 est.)
expenditures: 4.038 billion (2017 est.)
Taxes and other revenues:
18.3% (of GDP) (2017 est.)
country comparison to the world: 161
Budget surplus (+) or deficit (-): -5.5% (of GDP) (2017 est.)
country comparison to the world: 172
Public debt:
63.6% of GDP (2017 est.)
58.4% of GDP (2016 est.)
country comparison to the world: 64
Fiscal year: 1 October—30 September
Inflation rate (consumer prices): 0.8% (2017 est.)
1.6% (2016 est.)
country comparison to the world: 42
Current account balance:
-$2.057 billion (2017 est.)
-$2.07 billion (2016 est.)
country comparison to the world: 165
Exports: $3.654 billion (2017 est.)
$2.705 billion (2016 est.)
country comparison to the world: 120
Exports—partners: Thailand 42.6%, China 28.7%, Vietnam
10.4%, India 4.4% (2017)
Exports—commodities: wood products, coffee, electricity, tin,
copper, gold, cassava
Imports: $4.976 billion (2017 est.)
$4.739 billion (2016 est.)
country comparison to the world: 131
Imports—commodities: machinery and equipment, vehicles,
fuel, consumer goods
Imports—partners: Thailand 59.1%, China 21.5%, Vietnam
9.8% (2017)
Reserves of foreign exchange and gold:
$1.27 billion (31 December 2017 est.)
$940.1 million (31 December 2016 est.)
country comparison to the world: 128
Debt—external:
$14.9 billion (31 December 2017 est.)
$12.9 billion (31 December 2016 est.)
country comparison to the world: 104
Exchange rates: kips (LAK) per US dollar—
8,231.1 (2017 est.)
8,129.1 (2016 est.)
8,129.1 (2015 est.)
8,147.9 (2014 est.)
8,049 (2013 est.)','7775a99db260a818c7cf1352bdd108a68fc7d91c675d4a48bb1985d584fedf3b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a05ad75a391881983201da34f6641d6dc4bd3b2660d3507885e333b8f221b2f',2021,'LR','Liberia','economy',675,'Economy—overview: Liberia is a low-income country that relies
heavily on foreign assistance and remittances from the
diaspora. It is richly endowed with water, mineral
resources, forests, and a climate favorable to agriculture.
Its principal exports are iron ore, rubber, diamonds, and
gold. Palm oil and cocoa are emerging as new export
products. The government has attempted to revive raw
timber extraction and is encouraging oil exploration.
In the 1990s and early 2000s, civil war and government
mismanagement destroyed much of Liberia’s economy,
especially infrastructure in and around the capital. Much of
the conflict was fueled by control over Liberia’s natural
resources. With installation of a democratically elected
government in 2006, businesses that had fled the country
began to return. The country achieved high growth during
the period 2010-13 due to favorable world prices for its
commodities. However, during the 2014-2015 Ebola crisis,
the economy declined and many foreign-owned businesses
departed with their capital and expertise. The epidemic
forced the government to divert scarce resources to
combat the spread of the virus, reducing funds available for
needed public investment. The cost of addressing the Ebola
epidemic coincided with decreased economic activity
reducing government revenue, although higher donor
support significantly offset this loss. During the same
period, global commodities prices for key exports fell and
have yet to recover to pre- Ebola levels.
In 2017, gold was a key driver of growth, as a new
mining project began its first full year of production; iron
ore exports are also increased as Arcelor Mittal opened
new mines at Mount Gangra. The completion of the
rehabilitation of the Mount Coffee Hydroelectric Dam
increased electricity production to support ongoing and
future economic activity, although electricity tariffs remain
high relative to other countries in the region and
transmission infrastructure is limited. Presidential and
legislative elections in October 2017 generated election-
related spending pressures.
Revitalizing the economy in the future will depend on
economic diversification, increasing investment and trade,
higher global commodity prices, sustained foreign aid and
remittances, development of infrastructure and institutions,
combating corruption, and maintaining political stability
and security.
GDP (purchasing power parity):
$6.112 billion (2017 est.)
$5.965 billion (2016 est.)
$6.064 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 173
GDP (official exchange rate):
$3.285 billion (2017 est.)
GDP—real growth rate: 2.5% (2017 est.)
-1.6% (2016 est.)
0% (2015 est.)
country comparison to the world: 129
GDP—per capita (PPP): $1,300 (2017 est.)
$1,300 (2016 est.)
$1,300 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 221
Gross national saving: NA% (2017)
-21.9% of GDP (2016 est.)
1.9% of GDP (2016 est.)
country comparison to the world: 184
GDP—composition, by end use:
household consumption: 128.8% (2016 est.)
government consumption: 16.7% (2016 est.)
investment in fixed capital: 19.5% (2016 est.)
investment in inventories: 6.7% (2016 est.)
exports of goods and services: 17.5% (2016 est.)
imports of goods and services: -89.2% (2016 est.)
GDP—composition, by sector of origin:
agriculture: 34% (2017 est.)
industry: 13.8% (2017 est.)
services: 52.2% (2017 est.)
Agriculture—products: rubber, coffee, cocoa, rice, cassava
(manioc, tapioca), palm oil, sugarcane, bananas; sheep,
goats; timber Industries: mining (iron ore and gold), rubber
processing, palm oil processing, diamonds
Industrial production growth rate:
9% (2017 est.)
country comparison to the world: 19
Labor force: 1.677 million (2017 est.)
country comparison to the world: 128
Labor force—by occupation: agriculture: 70%
industry: 8%
services: 22% (2000 est.)
Unemployment rate: 2.8% (2014 est.)
country comparison to the world: 31
Population below poverty line: 54.1% (2014 est.)
Household income or consumption by percentage share: Jowest 10%:
2.4%
highest 10%: 30.1% (2007)
Budget: revenues: 553.6 million (2017 est.)
expenditures: 693.8 million (2017 est.)
Taxes and other revenues:
16.9% (of GDP) (2017 est.)
country comparison to the world: 174
Budget surplus (+) or deficit (-): -4.3% (of GDP) (2017 est.)
country comparison to the world: 161
Public debt:
34.4% of GDP (2017 est.)
28.3% of GDP (2016 est.)
country comparison to the world: 154
Fiscal year: Calendar year
Inflation rate (consumer prices): 12.4% (2017 est.)
8.8% (2016 est.)
country comparison to the world: 207
Current account balance:
-$627 million (2017 est.)
-$464 million (2016 est.)
country comparison to the world: 125
Exports: $260.6 million (2017 est.)
$169.8 million (2016 est.)
country comparison to the world: 185
Exports—partners: Germany 36.2%, Switzerland 14.2%, UAE
8.8%, US 6.8%, Indonesia 4.7% (2017)
Exports—commodities: rubber, timber, iron, diamonds, cocoa,
coffee
Imports: $1.166 billion (2017 est.)
$1.296 billion (2016 est.)
country comparison to the world: 179
Imports—commodities: fuels, chemicals, machinery,
transportation equipment, manufactured goods; foodstuffs
Imports—partners: Singapore 29.8%, China 24.4%, South
Korea 17.5%, Japan 9.4% (2017)
Reserves of foreign exchange and gold:
$459.8 million (31 December 2017 est.)
$528.7 million (31 December 2016 est.)
country comparison to the world: 154
Debt—external:
$1.036 billion (31 December 2017 est.)
$938.9 million (31 December 2016 est.)
country comparison to the world: 165
Exchange rates: Liberian dollars (LRD) per US dollar—
109.4 (2017 est.)
93.4 (2016 est.)
93.4 (2015 est.)
85.3 (2014 est.)
83.893 (2013 est.)
Economy—overview: Libya’s economy, almost _ entirely
dependent on oil and gas exports, has struggled since 2014
given security and political instability, disruptions in oil
production, and decline in global oil prices. The Libyan
dinar has lost much of its value since 2014 and the
resulting gap between official and black market exchange
rates has spurred the growth of a shadow economy and
contributed to inflation. The country suffers from
widespread power outages, caused by shortages of fuel for
power generation. Living conditions, including access to
clean drinking water, medical services, and safe housing
have all declined since 2011. Oil production in 2017
reached a five-year high, driving GDP growth, with daily
average production rising to 879,000 barrels per day.
However, oil production levels remain below the average
pre-Revolution highs of 1.6 million barrels per day.
The Central Bank of Libya continued to pay government
salaries to a majority of the Libyan workforce and to fund
subsidies for fuel and food, resulting in an estimated
budget deficit of about 17% of GDP in 2017. Low consumer
confidence in the banking sector and the economy as a
whole has driven a severe liquidity shortage.
GDP (purchasing power parity):
$61.97 billion (2017 est.)
$37.78 billion (2016 est.)
$40.8 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 106
GDP (official exchange rate):
$30.57 billion (2017 est.)
GDP—real growth rate: 64% (2017 est.)
-7.4% (2016 est.)
-13% (2015 est.)
country comparison to the world: 1
GDP—per capita (PPP): $9,600 (2017 est.)
$5,900 (2016 est.)
$6,500 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 141
Gross national saving:
9% of GDP (2017 est.)
-9% of GDP (2016 est.)
-25.1% of GDP (2015 est.)
country comparison to the world: 177
GDP—composition, by end use:
household consumption: 71.6% (2017 est.)
government consumption: 19.4% (2017 est.)
investment in fixed capital: 2.7% (2017 est.)
investment in inventories: 1.3% (2016 est.)
exports of goods and services: 38.8% (2017 est.)
imports of goods and services: -33.8% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 1.3% (2017 est.)
industry: 52.3% (2017 est.)
services: 46.4% (2017 est.)
Agriculture—products: Wheat, barley, olives, dates, citrus,
vegetables, peanuts, soybeans; cattle Industries: petroleum,
petrochemicals, aluminum, iron and steel, food processing,
textiles, handicrafts, cement Industrial production growth rate:
60.3% (2017 est.)
country comparison to the world: 1
Labor force: 1.114 million (2017 est.)
country comparison to the world: 143
Labor force—by occupation: agriculture: 17%
industry: 23%
services: 59% (2004 est.)
Unemployment rate: 30% (2004 est.)
country comparison to the world: 207
Population below poverty line: note: about one-third of Libyans
live at or below the national poverty line Household income or
consumption by percentage share: Jowest 10%: NA highest 10%:
NA
Budget: revenues: 15.78 billion (2017 est.)
expenditures: 23.46 billion (2017 est.)
Taxes and other revenues:
51.6% (of GDP) (2017 est.)
country comparison to the world: 14
Budget surplus (+) or deficit (-): -25.1% (of GDP) (2017 est.)
country comparison to the world: 219
Public debt:
4.7% of GDP (2017 est.)
7.9% Of GDP (2016 est.)
country comparison to the world: 205
Fiscal year: Calendar year
Inflation rate (consumer prices): 28.5% (2017 est.)
25.9% (2016 est.)
country comparison to the world: 221
Current account balance:
$2.574 billion (2017 est.)
-$4.575 billion (2016 est.)
country comparison to the world: 35
Exports: $18.38 billion (2017 est.)
$11.99 billion (2016 est.)
country comparison to the world: 71
Exports—partners: Italy 19%, Spain 12.5%, France 11%, Egypt
8.6%, Germany 8.6%, China 8.3%, US 4.9%, UK 4.6%,
Netherlands 4.5% (2017) Exports—commodities: crude oil,
refined petroleum products, natural gas, chemicals Imports:
$11.36 billion (2017 est.)
$8.667 billion (2016 est.)
country comparison to the world: 94
Imports—commodities: Machinery, semi-finished goods, food,
transport equipment, consumer products Imports—partners:
China 13.5%, Turkey 11.3%, Italy 6.9%, South Korea 5.9%,
Spain 4.8% (2017) Reserves of foreign exchange and gold:
$74.71 billion (31 December 2017 est.)
$66.05 billion (31 December 2016 est.)
country comparison to the world: 31
Debt—external:
$3.02 billion (31 December 2017 est.)
$3.116 billion (31 December 2016 est.)
country comparison to the world: 143
Exchange rates: Libyan dinars (LYD) per US dollar—
1.413 (2017 est.)
1.3904 (2016 est.)
1.3904 (2015 est.)
1.379 (2014 est.)
1.2724 (2013 est.)','8f7aef8a611540e243d1698589af4010259582c21237f19e8d85cad88833957b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('064c5e445dadf3e5769348e4a8a0db6df25520f5478dc0ddeb4d719a66d8cde5',2021,'MZ','Mozambique','economy',696,'Economy—overview: Malaysia, an upper middle-income
country, has transformed itself since the 1970s from a
producer of raw materials into a multi-sector economy.
Under current Prime Minister NAJIB, Malaysia is
attempting to achieve high-income status by 2020 and to
move further up the value-added production chain by
attracting investments in high technology, knowledge-
based industries and_ services. NAJIB’s Economic
Transformation Program is a series of projects and policy
measures intended to accelerate the country’s economic
growth. The government has also taken steps to liberalize
some services sub-sectors. Malaysia is vulnerable to a fall
in world commodity prices or a general slowdown in global
economic activity.
The NAJIB administration is continuing efforts to boost
domestic demand and reduce the economy’s dependence
on exports. Domestic demand continues to anchor
economic growth, supported mainly by private
consumption, which accounts for 53% of GDP.
Nevertheless, exports—particularly of electronics, oil and
gas, and palm oil—remain a significant driver of the
economy. In 2015, gross exports of goods and services were
equivalent to 73% of GDP. The oil and gas sector supplied
about 22% of government revenue in 2015, down
significantly from prior years amid a decline in commodity
prices and_ diversification of government revenues.
Malaysia has embarked on a fiscal reform program aimed
at achieving a balanced budget by 2020, including
rationalization of subsidies and the 2015 introduction of a
6% value added tax. Sustained low commodity prices
throughout the period not only strained government
finances, but also shrunk Malaysia’s current account
surplus and weighed heavily on the Malaysian ringgit,
which was among the region’s worst performing currencies
during 2013-17. The ringgit hit new lows following the US
presidential election amid a broader selloff of emerging
market assets.
Bank Negara Malaysia (the central bank) maintains
adequate foreign exchange reserves; a_ well-developed
regulatory regime has limited Malaysia’s exposure to
riskier financial instruments, although it remains
vulnerable to volatile global capital flows. In order to
increase Malaysia’s competitiveness, Prime Minister NAJIB
raised possible revisions to the special economic and social
preferences accorded to ethnic Malays under the New
Economic Policy of 1970, but retreated in 2013 after he
encountered significant opposition from Malay nationalists
and other vested interests. In September 2013 NAJIB
launched the new Bumiputra Economic Empowerment
Program, policies that favor and advance the economic
condition of ethnic Malays.
Malaysia signed the 12-nation Trans-Pacific Partnership
(TPP) free trade agreement in February 2016, although the
future of the TPP remains unclear following the US
withdrawal from the agreement. Along with nine other
ASEAN members, Malaysia established the ASEAN
Economic Community in 2015, which aims to advance
regional economic integration.
GDP (purchasing power parity):
$933.3 billion (2017 est.)
$881.3 billion (2016 est.)
$845.6 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 26
GDP (official exchange rate):
$312.4 billion (2017 est.)
GDP—real growth rate: 5.9% (2017 est.)
4.2% (2016 est.)
5.1% (2015 est.)
country comparison to the world: 37
GDP—per capita (PPP): $29,100 (2017 est.)
$27,900 (2016 est.)
$27,100 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 71
Gross national saving:
28.5% of GDP (2017 est.)
28.3% of GDP (2016 est.)
28.2% of GDP (2015 est.)
country comparison to the world: 38
GDP—composition, by end use:
household consumption: 55.3% (2017 est.)
government consumption: 12.2% (2017 est.)
investment in fixed capital: 25.3% (2017 est.)
investment in inventories: 0.3% (2017 est.)
exports of goods and services: 71.4% (2017 est.)
imports of goods and services: -64.4% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 8.8% (2017 est.)
industry: 37.6% (2017 est.)
services: 53.6% (2017 est.)
Agriculture—products: Peninsular Malaysia—palm oil, rubber,
cocoa, rice;Sabah—palm oil, subsistence crops; rubber,
timber;Sarawak—palm oil, rubber, timber; pepper Industries:
Peninsular Malaysia—rubber and oil palm processing and
manufacturing, petroleum and _ natural’ gas, light
manufacturing, pharmaceuticals, medical technology,
electronics and semiconductors, timber processing;Sabah—
logging, petroleum and natural gas production;Sarawak—
agriculture processing, petroleum and natural gas
production, logging Industrial production growth rate:
5% (2017 est.)
country comparison to the world: 55
Labor force: 14.94 million (2017 est.)
country comparison to the world: 39
Labor force—by occupation: agriculture: 11%
industry: 36%
services: 53% (2012 est.)
Unemployment rate: 3.4% (2017 est.)
3.5% (2016 est.)
country comparison to the world: 41
Population below poverty line: 3.8% (2009 est.)
Household income or consumption by percentage share: Jowest 10%:
1.8%
highest 10%: 34.7% (2009 est.)
Budget: revenues: 51.25 billion (2017 est.)
expenditures: 60.63 billion (2017 est.)
Taxes and other revenues:
16.4% (of GDP) (2017 est.)
country comparison to the world: 180
Budget surplus (+) or deficit (-): -3% (of GDP) (2017 est.)
country comparison to the world: 133
Public debt:
94.1% of GDP (2017 est.)
56.2% of GDP (2016 est.)
note: this figure is based on the amount of federal
government debt, RM501.6 billion ($167.2 billion) in 2012;
this includes Malaysian Treasury bills and _ other
government securities, as well as loans raised externally
and bonds and notes issued overseas; this figure excludes
debt issued by non-financial public enterprises and
guaranteed by the federal government, which was an
additional $47.7 billion in 2012
country comparison to the world: 86
Fiscal year: Calendar year
Inflation rate (consumer prices): 3.8% (2017 est.)
2.1% (2016 est.)
note: approximately 30% of goods are price-controlled
country comparison to the world: 151
Current account balance:
$9.296 billion (2017 est.)
$7.236 billion (2016 est.)
country comparison to the world: 24
Exports: $187.9 billion (2017 est.)
$165.3 billion (2016 est.)
country comparison to the world: 28
Exports—partners: Singapore 15.1%, China 12.6%, US 9.4%,
Japan 8.2%, Thailand 5.7%, Hong Kong 4.5% (2017) Exports
—commodities: semiconductors and electronic equipment,
palm oil, petroleum and liquefied natural gas, wood and
wood products, palm oil, rubber, textiles, chemicals, solar
panels Imports: $160.7 billion (2017 est.)
$141 billion (2016 est.)
country comparison to the world: 27
Imports—commodities: electronics, machinery, petroleum
products, plastics, vehicles, iron and _ steel products,
chemicals Imports—partners: China 19.9%, Singapore 10.8%,
US 8.4%, Japan 7.6%, Thailand 5.8%, South Korea 4.5%,
Indonesia 4.4% (2017) Reserves of foreign exchange and gold:
$102.4 billion (31 December 2017 est.)
$94.5 billion (31 December 2016 est.)
country comparison to the world: 25
Debt—external:
$217.2 billion (31 December 2017 est.)
$195.3 billion (31 December 2016 est.)
country comparison to the world: 33
Exchange rates: ringgits (MYR) per US dollar—
4.343 (2017 est.)
4.15 (2016 est.)
4.15 (2015 est.)
3.91 (2014 est.)
3.27 (2013 est.)','7156b6580f50099f1e937af499252e2d73a8a86a7fc58ed3974b663736705fd0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38d75e95928da16d38c6993c8c8b8a39647bce6b4d79046c7a34b6b34b3ca82e',2021,'SN','Senegal','economy',719,'Economy—overview: Mauritania’s economy is dominated by
extractive industries (oil and mines), fisheries, livestock,
agriculture, and services. Half the population still depends
on farming and raising livestock, even though many
nomads and subsistence farmers were forced into the cities
by recurrent droughts in the 1970s, 1980s, 2000s, and
2017. Recently, GDP growth has been driven largely by
foreign investment in the mining and oil sectors.
Mauritania’s extensive mineral resources include iron
ore, gold, copper, gypsum, and phosphate rock, and
exploration is ongoing for tantalum, uranium, crude oil, and
natural gas. Extractive commodities make up about three-
quarters of Mauritania’s total exports, subjecting the
economy to price swings in world commodity markets.
Mining is also a growing source of government revenue,
rising from 13% to 30% of total revenue from 2006 to 2014.
The nation’s coastal waters are among the richest fishing
areas in the world, and fishing accounts for about 15% of
budget revenues, 45% of foreign currency earnings.
Mauritania processes a total of 1,800,000 tons of fish per
year, but overexploitation by foreign and national fleets
threaten the sustainability of this key source of revenue.
The economy is highly sensitive to international food
and extractive commodity prices. Other risks’ to
Mauritania’s economy include its recurring droughts,
dependence on foreign aid and investment, and insecurity
in neighboring Mali, as well as significant shortages of
infrastructure, institutional capacity, and human capital. In
December 2017, Mauritania and the IMF agreed to a three
year agreement under the Extended Credit Facility to
foster economic growth, maintain macroeconomic stability,
and reduce poverty. Investment in agriculture and
infrastructure are the largest components of the country’s
public expenditures.
GDP (purchasing power parity):
$17.28 billion (2017 est.)
$16.7 billion (2016 est.)
$16.4 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 154
GDP (official exchange rate):
$4.935 billion (2017 est.)
GDP—real growth rate: 3.5% (2017 est.)
1.8% (2016 est.)
0.4% (2015 est.)
country comparison to the world: 99
GDP—per capita (PPP): $4,500 (2017 est.)
$4,400 (2016 est.)
$4,400 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 173
Gross national saving:
24.2% of GDP (2017 est.)
24.8% of GDP (2016 est.)
19% of GDP (2015 est.)
country comparison to the world: 68
GDP—composition, by end use:
household consumption: 64.9% (2017 est.)
government consumption: 21.8% (2017 est.)
investment in fixed capital: 56.1% (2017 est.)
investment in inventories: -3.2% (2017 est.)
exports of goods and services: 39% (2017 est.)
imports of goods and services: -78.6% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 27.8% (2017 est.)
industry: 29.3% (2017 est.)
services: 42.9% (2017 est.)
Agriculture—products: dates, millet, sorghum, rice, corn;
cattle, camel and sheep
Industries: fish processing, oil production, mining (iron ore,
gold, copper)
note: gypsum deposits have never been exploited
Industrial production growth rate:
1% (2017 est.)
country comparison to the world: 157
Labor force: 1.437 million (2017 est.)
country comparison to the world: 133
Labor force—by occupation: agriculture: 50%
industry: 1.9%
services: 48.1% (2014 est.)
Unemployment rate: 10.2% (2017 est.)
10.1% (2016 est.)
country comparison to the world: 142
Population below poverty line: 31% (2014 est.)
Household income or consumption by percentage share: Jowest 10%:
2.5%
highest 10%: 29.5% (2000)
Budget: revenues: 1.354 billion (2017 est.)
expenditures: 1.396 billion (2017 est.)
Taxes and other revenues:
27.4% (of GDP) (2017 est.)
country comparison to the world: 100
Budget surplus (+) or deficit (-): -0.8% (of GDP) (2017 est.)
country comparison to the world: 69
Public debt:
96.6% of GDP (2017 est.)
100% of GDP (2016 est.)
country comparison to the world: 21
Fiscal year: Calendar year
Inflation rate (consumer prices): 2.3% (2017 est.)
1.5% (2016 est.)
country comparison to the world: 117
Current account balance:
-$711 million (2017 est.)
-$707 million (2016 est.)
country comparison to the world: 129
Exports: $1.722 billion (2017 est.)
$1.401 billion (2016 est.)
country comparison to the world: 147
Exports—partners: China 31.2%, Switzerland 14.4%, Spain
10.1%, Germany 8.2%, Japan 8.1% (2017) Exports—
commodities: iron ore, fish and fish products, livestock, gold,
copper, crude oil
Imports: $2.094 billion (2017 est.)
$1.9 billion (2016 est.)
country comparison to the world: 166
Imports—commodities: Machinery and equipment, petroleum
products, capital goods, foodstuffs, consumer goods Imports
—partners: Belgium 11.5%, UAE 11.3%, US 9.2%, China
7.9%, France 7.4%, Netherlands 6.1%, Morocco 6%,
Slovenia 4.8%, Vanuatu 4.7%, Spain 4.7% (2017) Reserves of
foreign exchange and gold:
$875 million (31 December 2017 est.)
$849.3 million (31 December 2016 est.)
country comparison to the world: 138
Debt—external:
$4.15 billion (31 December 2017 est.)
$3.899 billion (31 December 2016 est.)
country comparison to the world: 138
Exchange rates: OUgUiyas (MRO) per US dollar—
363.6 (2017 est.)
352.37 (2016 est.)
352.37 (2015 est.)
319.7 (2014 est.)
299.5 (2013 est.)','e81f7d78fbdfc7fec230d2e80eff94527479829a4de6e31299e6290fde3c85dd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e8051165258cfcc37918f8be4507321e2a1b0c19c99190259589d9d117ea5fb',2021,'AL','Albania','economy',772,'Economy—overview: Severe volcanic activity, which began in
July 1995, has put a damper on this small, open economy. A
catastrophic eruption in June 1997 closed the airport and
seaports, causing further economic and social dislocation.
Two-thirds of the 12,000 inhabitants fled the island. Some
began to return in 1998 but lack of housing limited the
number. The agriculture sector continued to be affected by
the lack of suitable land for farming and the destruction of
crops.
Prospects for the economy depend largely on
developments in relation to the volcanic activity and on
public sector construction activity. Half of the island
remains uninhabitable. In January 2013, the EU announced
the disbursement of a $55.2 million aid package to
Montserrat in order to boost the country’s economic
recovery, with a_ specific focus on _ public finance
management, public sector reform, and prudent economic
management. Montserrat is tied to the EU through the UK.
Although the UK is leaving the EU, Montserrat’s aid will
not be affected as Montserrat maintains a direct agreement
with the EU regarding aid.
GDP (purchasing power parity):
$167.4 million (2011 est.)
$155.9 million (2010 est.)
$162.7 million (2009 est.)
country comparison to the world: 223
GDP (official exchange rate):
$167.4 million (2011 est.)
GDP—real growth rate: 7.4% (2011 est.)
-4.2% (2010 est.)
country comparison to the world: 15
GDP—per capita (PPP): $34,000 (2011 est.)
$31,100 (2010 est.)
$32,300 (2009 est.)
country comparison to the world: 60
GDP—composition, by end use:
household consumption: 90.8% (2017 est.)
government consumption: 50.4% (2017 est.)
investment in fixed capital: 17.9% (2017 est.)
investment in inventories: -0.1% (2017 est.)
exports of goods and services: 29.5% (2017 est.)
imports of goods and services: -88.6% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 1.9% (2017 est.)
industry: 7.8% (2017 est.)
services: 90.3% (2017 est.)
Agriculture—products: cabbages, carrots, cucumbers,
tomatoes, onions, peppers; livestock products Industries:
tourism, rum, textiles, electronic appliances
Industrial production growth rate:
-21% (2017 est.)
country comparison to the world: 200
Labor force: 4,521 (2012)
country comparison to the world: 222
Labor force—by occupation: agriculture: 1.4%
industry: 12.7%
services: 85.9% (2017 est.)
Unemployment rate: 5.6% (2017 est.)
6% (1998 est.)
country comparison to the world: 83
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 66.67 million (2017 est.)
expenditures: 47.04 million (2017 est.)
Fiscal year: 1 April—31 March
Inflation rate (consumer prices): 1.2% (2017 est.)
-0.2% (2016 est.)
country comparison to the world: 66
Current account balance:
-§15.4 million (2017 est.)
-$12.2 million (2016 est.)
country comparison to the world: 71
Exports: $4.4 million (2017 est.)
$5.2 million (2016 est.)
country comparison to the world: 218
Exports—partners: US 29%, France 23%, Saint Kitts and Nevis
22.2% (2017)
Exports—commodities: electronic components, plastic bags,
apparel; hot peppers, limes, live plants; cattle Imports:
$39.44 million (2017 est.)
$36.1 million (2016 est.)
country comparison to the world: 221
Imports—commodities: machinery and transportation
equipment, foodstuffs, manufactured goods, fuels,
lubricants Imports—partners: US 72.8%, Trinidad and Tobago
6%, UK 4.1% (2017)
Reserves of foreign exchange and gold:
$47.58 million (31 December 2017 est.)
$51.47 million (31 December 2015 est.)
country comparison to the world: 187
Debt—external: $8.9 million (1997)
country comparison to the world: 200
Exchange rates: East Caribbean dollars (XCD) per US dollar—
2.7 (2017 est.)
2.7 (2016 est.)
2.7 (2015 est.)
2.7 (2014 est.)
2.7 (2013 est.)','b279f68869a23cee79632dfb2fb835dbd8b28024745bf0b5623540565d5515df','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98a29d5292f5263141a826580da55cb9a1b9283cde3d405a83e75753c9ca192f',2021,'NL','Netherlands','economy',801,'Economy—overview: The Netherlands, the — sixth-largest
economy in the European Union, plays an important role as
a European transportation hub, with a consistently high
trade surplus, stable industrial relations, and low
unemployment. Industry focuses on food processing,
chemicals, petroleum refining, and electrical machinery. A
highly mechanized agricultural sector employs only 2% of
the labor force but provides large surpluses for food-
processing and underpins the country’s status as the
world’s second largest agricultural exporter.
The Netherlands is part of the euro zone, and as such,
its monetary policy is controlled by the European Central
Bank. The Dutch financial sector is highly concentrated,
with four commercial banks possessing over 80% of
banking assets, and is four times the size of Dutch GDP.
In 2008, during the financial crisis, the government
budget deficit hit 5.3% of GDP. Following a protracted
recession from 2009 to 2013, during which unemployment
doubled to 7.4% and household consumption contracted for
four consecutive years, economic growth began inching
forward in 2014. Since 2010, Prime Minister Mark
RUTTE’s government has implemented significant austerity
measures to improve public finances and has instituted
broad structural reforms in key policy areas, including the
labor market, the housing sector, the energy market, and
the pension system. In 2017, the government budget
returned to a surplus of 0.7% of GDP, with economic
growth of 3.2%, and GDP per capita finally surpassed pre-
crisis levels. The fiscal policy announced by the new
government in the 2018-2021 coalition plans for increases
in government consumption and public investment, fueling
domestic demand and household consumption and
investment. The new government’s policy also plans to
increase demand for workers in the public and private
sector, forecasting a further decline in the unemployment
rate, which hit 4.8% in 2017.
GDP (purchasing power parity):
$924.4 billion (2017 est.)
$898.6 billion (2016 est.)
$879.4 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 27
GDP (official exchange rate):
$832.2 billion (2017 est.)
GDP—real growth rate: 2.9% (2017 est.)
2.2% (2016 est.)
2% (2015 est.)
country comparison to the world: 118
GDP—per capita (PPP): $53,900 (2017 est.)
$52,800 (2016 est.)
$51,900 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 23
Gross national saving:
31.2% of GDP (2017 est.)
28.5% of GDP (2016 est.)
28.8% of GDP (2015 est.)
country comparison to the world: 28
GDP—composition, by end use:
household consumption: 44.3% (2017 est.)
government consumption: 24.2% (2017 est.)
investment in fixed capital: 20.5% (2017 est.)
investment in inventories: 0.2% (2017 est.)
exports of goods and services: 83% (2017 est.)
imports of goods and services: -72.3% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 1.6% (2017 est.)
industry: 17.9% (2017 est.)
services: 70.2% (2017 est.)
Agriculture—products: vegetables, ornamentals, dairy, poultry
and livestock products; propagation materials Industries:
agroindustries, metal and engineering products, electrical
machinery and equipment, chemicals, petroleum,
construction, microelectronics, fishing Industrial production
growth rate:
3.3% (2017 est.)
country comparison to the world: 96
Labor force: 7.969 million (2017 est.)
country comparison to the world: 63
Labor force—by occupation: agriculture: 1.2%
industry: 17.2%
services: 81.6% (2015 est.)
Unemployment rate: 4.9% (2017 est.)
6% (2016 est.)
country comparison to the world: 69
Population below poverty line: 8.8% (2015 est.)
Household income or consumption by percentage share: Jowest 10%:
2.3%
highest 10%: 24.9% (2014 est.)
Budget: revenues: 361.4 billion (2017 est.)
expenditures: 352.4 billion (2017 est.)
Taxes and other revenues:
43.4% (of GDP) (2017 est.)
country comparison to the world: 27
Budget surplus (+) or deficit (-): 1.1% (of GDP) (2017 est.)
country comparison to the world: 32
Public debt:
56.5% of GDP (2017 est.)
61.3% of GDP (2016 est.)
note: data cover general government debt and include debt
instruments issued (or owned) by government entities
other than the treasury; the data include treasury debt held
by foreign entities; the data include debt issued by
subnational entities, as well as intragovernmental debt;
intragovernmental debt consists of treasury borrowings
from surpluses in the social funds, such as for retirement,
medical care, and unemployment, debt instruments for the
social funds are not sold at public auctions country
comparison to the world: 78
Fiscal year: Calendar year
Inflation rate (consumer prices): 1.3% (2017 est.)
0.1% (2016 est.)
country comparison to the world: 70
Current account balance:
$87.46 billion (2017 est.)
$62.92 billion (2016 est.)
country comparison to the world: 4
Exports: $555.6 billion (2017 est.)
$495.4 billion (2016 est.)
country comparison to the world: 6
Exports—partners: Germany 24.2%, Belgium 10.7%, UK 8.8%,
France 8.8%, Italy 4.2% (2017)
Exports—commodities: machinery and transport equipment,
chemicals, mineral fuels; food and livestock, manufactured
goods Imports: $453.8 billion (2017 est.)
$402.9 billion (2016 est.)
country comparison to the world: 10
Imports—commodities: machinery and transport equipment,
chemicals, fuels, foodstuffs, clothing
Imports—partners: China 16.4%, Germany 15.3%, Belgium
8.5%, US 6.9%, UK 5.1%, Russia 4.3% (2017)
Reserves of foreign exchange and gold:
$38.44 billion (31 December 2017 est.)
$38.21 billion (31 December 2015 est.)
country comparison to the world: 46
Debt—external:
$4.063 trillion (31 December 2016 est.)
$4.054 trillion (31 December 2015 est.)
country comparison to the world: 5
Exchange rates: euros (EUR) per US dollar—
0.885 (2017 est.)
0.903 (2016 est.)
0.9214 (2015 est.)
0.885 (2014 est.)
0.7634 (2013 est.)','e5e51973000f466ae11f0535d85e1ef0fc240723be903d402a9aa1f206bb6437','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c595fb3b2e165e9d5a55b05ef485f3d0b2c49170297496c7ae90a79368e2857',2021,'AU','Australia','economy',807,'Economy—overview: New Caledonia has 11% of the world’s
nickel reserves, representing the second largest reserves
on the planet. Only a small amount of the land is suitable
for cultivation, and food accounts for about 20% of imports.
In addition to nickel, substantial financial support from
France—equal to more than 15% of GDP—and tourism are
keys to the health of the economy.
With the gradual increase in the production of two new
nickel plants in 2015, average production of metallurgical
goods stood at a record level of 94 thousand tons. However,
the sector is exposed to the high volatility of nickel prices,
which have been in decline since 2016. In 2017, one of the
three major mining firms on the island, Vale, put its
operations up for sale, triggering concerns of layoffs ahead
of the 2018 independence referendum.
GDP (purchasing power parity):
$11.11 billion (2017 est.)
$10.89 billion (2016 est.)
$10.77 billion (2015 est.)
note: data are in 2015 dollars
country comparison to the world: 159
GDP (official exchange rate):
$9.77 billion (2017 est.)
GDP—real growth rate: 2% (2017 est.)
1.1% (2016 est.)
3.2% (2015 est.)
country comparison to the world: 154
GDP—per capita (PPP): $31,100 (2015 est.)
$32,100 (2014 est.)
$29,800 (2012 est.)
country comparison to the world: 66
GDP—composition, by end use:
household consumption: 64.3% (2017 est.)
government consumption: 24% (2017 est.)
investment in fixed capital: 38.4% (2017 est.)
investment in inventories: 0% (2017 est.)
exports of goods and services: 18.7% (2017 est.)
imports of goods and services: -45.5% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 1.4% (2017 est.)
industry: 26.4% (2017 est.)
services: 72.1% (2017 est.)
Agriculture—products: vegetables; beef, venison,
livestock products; fish
Industries: nickel mining and smelting
Industrial production growth rate:
3.5% (2017 est.)
country comparison to the world: 87
Labor force: 119,500 (2016 est.)
other
country comparison to the world: 181
Labor force—by occupation: agriculture: 2.7%
industry: 22.4%
services: 74.9% (2010)
Unemployment rate: 14.7% (2014)
14% (2009)
country comparison to the world: 171
Population below poverty line: 17% (2008)
Household income or consumption by percentage share: Jowest 10%:
NA
highest 10%: NA
Budget: revenues: 1.995 billion (2015 est.)
expenditures: 1.993 billion (2015 est.)
Taxes and other revenues:
20.4% (of GDP) (2015 est.)
country comparison to the world: 147
Budget surplus (+) or deficit (-): 0% (of GDP) (2015 est.)
country comparison to the world: 45
Public debt:
6.5% of GDP (2015 est.)
6.5% of GDP (2014 est.)
country comparison to the world: 203
Fiscal year: Calendar year
Inflation rate (consumer prices): 1.4% (2017 est.)
0.6% (2016 est.)
country comparison to the world: 79
Current account balance:
-$1.469 billion (2014 est.)
-$1.861 billion (2013 est.)
country comparison to the world: 156
Exports: $2.207 billion (2014 est.)
country comparison to the world: 137
Exports—partners: China 25.4%, Japan 16.6%, South Korea
14.8%, France 8.2%, Belgium 5%, US 4.6% (2017) Exports—
commodities: ferronickels, nickel ore, fish
Imports: $2.715 billion (2015 est.)
$4.4 billion (2014 est.)
country comparison to the world: 153
Imports—commodities: machinery and equipment, fuels,
chemicals, foodstuffs
Imports—partners: France 24.2%, Singapore 13.1%, China
9.2%, Australia 7.1%, South Korea 5.2%, Malaysia 4.7%,
NZ 4.4%, US 4.4% (2017) Debt—external:
$112 million (31 December 2013 est.)
$79 million (31 December 1998 est.)
country comparison to the world: 192
Exchange rates: Comptoirs Francais du Pacifique francs (XPF)
per US dollar -
110.2 (2017 est.)
107.84 (2016 est.)
107.84 (2015 est.)
89.85 (2013 est.)
90.56 (2012 est.)
Economy—overview: Norfolk Island is suffering from a severe
economic downturn. Tourism, the primary economic
activity, is the main driver of economic growth. The
agricultural sector has become self-sufficient in the
production of beef, poultry, and eggs.
GDP (purchasing power parity): NA
Agriculture—products: Norfolk Island pine seed, Kentia palm
seed, cereals, vegetables, fruit; cattle, poultry Industries:
tourism, light industry, ready mixed concrete
Labor force: 978 (2006)
country comparison to the world: 229
Labor force—by occupation: agriculture: 6%
industry: 14%
services: 80% (2006 est.)
Budget: revenues: 4.6 million (FY99/00)
expenditures: 4.8 million (FY99/00)
Fiscal year: 1 July—30 June
Exports: NA
Exports—commodities: postage stamps, seeds of the Norfolk
Island pine and Kentia palm, small quantities of avocados
Imports: $NA
Imports—commodities: NA
Debt—external: NA
Exchange rates: AuStralian dollars (AUD) per US dollar—
1.311 (2017 est.)
1.3291 (2016 est.)
1.3291 (2015)
1.3291 (2014 est.)
1.1094 (2013 est.)','d348d59605737dbddeb6b8b3d8aecdcc4ab1a04a24b0307c9c584b8cac3bb04c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fba14af174561c5092e44e5a869e7ec414e722deeaf9068edc84c282a7a7c74',2021,'DK','Denmark','economy',835,'Economy—overview: Norway has a stable economy with a
vibrant private sector, a large state sector, and an extensive
social safety net. Norway opted out of the EU during a
referendum in November 1994. However, as a member of
the European Economic Area, Norway partially participates
in the EU’s single market and contributes sizably to the EU
budget.
The country is richly endowed with natural resources
such as oil and gas, fish, forests, and minerals. Norway is a
leading producer and the world’s second largest exporter
of seafood, after China. The government manages the
country’s petroleum resources’ through’ extensive
regulation. The petroleum sector provides about 9% of
jobs, 12% of GDP, 13% of the state’s revenue, and 37% of
exports, according to official national estimates. Norway is
one of the world’s leading petroleum exporters, although
oil production is close to 50% below its peak in 2000. Gas
production, conversely, has more than doubled since 2000.
Although oil production is historically low, it rose in 2016
for the third consecutive year due to the higher production
of existing oil fields and to new fields coming on stream.
Norway’s domestic electricity production relies almost
entirely on hydropower.
In anticipation of eventual declines in oil and gas
production, Norway saves state revenue from petroleum
sector activities in the world’s largest sovereign wealth
fund, valued at over $1 trillion at the end of 2017. To help
balance the federal budget each year, the government
follows a “fiscal rule,” which states that spending of
revenues from petroleum and fund investments shall
correspond to the expected real rate of return on the fund,
an amount it estimates is sustainable over time. In
February 2017, the government revised the expected rate
of return for the fund downward from 4% to 3%.
After solid GDP growth in the 2004-07 period, the
economy slowed in 2008, and contracted in 2009, before
returning to modest, positive growth from 2010 to 2017.
The Norwegian economy has been adjusting to lower
energy prices, as demonstrated by growth in labor force
participation and employment in 2017. GDP growth was
about 1.5% in 2017, driven largely by domestic demand,
which has been boosted by the rebound in the labor market
and supportive fiscal policies. Economic growth is expected
to remain constant or improve slightly in the next few
years.
GDP (purchasing power parity):
$381.2 billion (2017 est.)
$374 billion (2016 est.)
$370 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 48
GDP (official exchange rate):
$398.8 billion (2017 est.)
GDP—real growth rate: 1.9% (2017 est.)
1.1% (2016 est.)
2% (2015 est.)
country comparison to the world: 156
GDP—per capita (PPP): $72,100 (2017 est.)
$71,200 (2016 est.)
$71,100 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 11
Gross national saving:
34.3% of GDP (2017 est.)
33.1% of GDP (2016 est.)
35.5% of GDP (2015 est.)
country comparison to the world: 18
GDP—composition, by end use:
household consumption: 44.8% (2017 est.)
government consumption: 24% (2017 est.)
investment in fixed capital: 24.1% (2017 est.)
investment in inventories: 4.8% (2017 est.)
exports of goods and services: 35.5% (2017 est.)
imports of goods and services: -33.2% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 2.3% (2017 est.)
industry: 33.7% (2017 est.)
services: 64% (2017 est.)
Agriculture—products: barley, wheat, potatoes; pork, beef, veal,
milk; fish Industries: petroleum and gas, shipping, fishing,
aquaculture, food processing, shipbuilding, pulp and paper
products, metals, chemicals, timber, mining, textiles
Industrial production growth rate:
1.5% (2017 est.)
country comparison to the world: 143
Labor force: 2.797 million (2017 est.)
country comparison to the world: 108
Labor force—by occupation: agriculture: 2.1%
industry: 19.3%
services: 78.6% (2016 est.)
Unemployment rate: 4.2% (2017 est.)
4.7% (2016 est.)
country comparison to the world: 56
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
3.8%
highest 10%: 21.2% (2014)
Budget: revenues: 217.1 billion (2017 est.) expenditures:
199.5 billion (2017 est.)
Taxes and other revenues:
54.4% (of GDP) (2017 est.)
country comparison to the world: 9
Budget surplus (+) or deficit (-): 4.4% (of GDP) (2017 est.)
country comparison to the world: 8
Public debt:
36.5% of GDP (2017 est.)
36.4% of GDP (2016 est.)
note: data cover general government debt and include debt
instruments issued (or owned) by government entities
other than the treasury; the data exclude treasury debt
held by foreign entities; the data exclude debt issued by
subnational entities, as well as intragovernmental debt;
intragovernmental debt consists of treasury borrowings
from surpluses in the social funds, such as for retirement,
medical care, and unemployment; debt instruments for the
social funds are not sold at public auctions country
comparison to the world: 146
Fiscal year: Calendar year
Inflation rate (consumer prices): 1.9% (2017 est.)
3.6% (2016 est.)
country comparison to the world: 99
Current account balance:
$22.01 billion (2017 est.)
$14.09 billion (2016 est.)
country comparison to the world: 16
Exports: $102.8 billion (2017 est.)
$88.88 billion (2016 est.)
country comparison to the world: 36
Exports—partners: UK 21.1%, Germany 15.5%, Netherlands
9.9%, Sweden 6.6%, France 6.4%, Belgium 4.8%, Denmark
4.7%, US 4.6% (2017) Exports—commodities: petroleum and
petroleum products, machinery and equipment, metals,
chemicals, ships, fish Imports: $95.06 billion (2017 est.)
$74.94 billion (2016 est.)
country comparison to the world: 36
Imports—commodities: Machinery and equipment, chemicals,
metals, foodstuffs Imports—partners: Sweden 11.4%, Germany
11%, China 9.8%, US 6.8%, South Korea 6.7%, Denmark
5.4%, UK 4.7% (2017) Reserves of foreign exchange and gold:
$65.92 billion (31 December 2017 est.)
$57.46 billion (31 December 2015 est.)
country comparison to the world: 34
Debt—external:
$642.3 billion (31 March 2016 est.)
$640.1 billion (31 March 2015 est.)
note: Norway is a net external creditor
country comparison to the world: 17
Exchange rates: Norwegian kroner (NOK) per US dollar—
8.308 (2017 est.)
8.3978 (2016 est.)
8.3978 (2015 est.)
8.0646 (2014 est.)
6.3021 (2013 est.)','5b95c0b68f7a056fb401e01f2d179007d29cc89d3eac7197cdb1b0bcbef4925c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a7f82abe0d7680100350961ce66f22755d4cf96a8f852849365d9e3c96af54a',2021,'PH','Philippines','economy',864,'Economy—overview: The inhabitants of this tiny isolated
economy exist on fishing, subsistence farming, handicrafts,
and postage stamps. The fertile soil of the valleys produces
a wide variety of fruits and vegetables, including citrus,
Sugarcane, watermelons, bananas, yams, and _ beans.
Bartering is an important part of the economy. The major
sources of revenue are the sale of postage stamps to
collectors and the sale of handicrafts to passing ships.
GDP (purchasing power parity): NA
Agriculture—products: honey; wide variety of fruits and
vegetables; goats, chickens; fish
Industries: postage stamps, handicrafts, beekeeping, honey
Labor force: 15 (2004)
country comparison to the world: 232
Labor force—by occupation: Note: no business community in the
usual sense; some public works; subsistence farming and
fishing Budget: revenues: 746,000 (FY04/05)
expenditures: 1.028 million (FY04/05)
Fiscal year: 1 April—31 March
Exports: NA
Exports—commodities: honey, fruits, vegetables, curios,
postage stamps
Imports: NA
Imports—commodities: fuel oil, machinery, building materials,
flour, sugar, other foodstuffs
Exchange rates: New Zealand dollars (NZD) per US dollar—
1.416 (2017 est.)
1.4279 (2016 est.)
1.4279 (2015)
1.4279 (2014 est.)
1.2039 (2013 est.)','641a3bf2d97c8319ba4968cb299de84713ba66a1b6c03fc6e5123e3ff5521b55','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a67f2ee9d418bb3244bf2ca10e70a863fcfa4935e74f2b88659ed7dc9ab1877',2021,'PR','Puerto Rico','economy',873,'Economy—overview: Puerto Rico had one of the most dynamic
economies in the Caribbean region until 2006; however,
growth has been negative for each of the last 11 years. The
downturn coincided with the phaseout of tax preferences
that had led US firms to invest heavily in the
Commonwealth since the 1950s, and a steep rise in the
price of oil, which generates most of the island’s electricity.
Diminished job opportunities prompted a sharp rise in
outmigration, as many Puerto Ricans sought jobs on the US
mainland. Unemployment reached 16% in 2011, but
declined to 11.5% in December 2017. US minimum wage
laws apply in Puerto Rico, hampering job expansion. Per
Capita income is about two-thirds that of the US mainland.
The industrial sector greatly exceeds agriculture as the
locus of economic activity and income. Tourism has
traditionally been an important source of income with
estimated arrivals of more than 3.6 million tourists in 2008.
Puerto Rico’s merchandise trade surplus is exceptionally
strong, with exports nearly 50% greater than imports, and
its current account surplus about 10% of GDP.
Closing the budget deficit while restoring economic
growth and employment remain the central concerns of the
government. The gap between revenues and expenditures
amounted to 0.6% of GDP in 2016, although analysts
believe that not all expenditures have been accounted for
in the budget and a better accounting of costs would yield
an overall deficit of roughly 5% of GDP. Public debt
remained steady at 92.5% of GDP in 2017, about $17,000
per person, or nearly three times the per capita debt of the
State of Connecticut, the highest in the US. Much of that
debt was issued by _ state-run schools and_ public
corporations, including water and electric utilities. In June
2015, Governor Alejandro GARCIA Padilla announced that
the island could not pay back at least $73 billion in debt
and that it would seek a deal with its creditors.
Hurricane Maria hit Puerto Rico square on in September
2017, causing electrical power outages to 90% of the
territory, as well as extensive loss of housing and
infrastructure and contamination of potable water. Despite
massive efforts, more than 40% of the territory remained
without electricity as of yearend 2017. As a result of the
destruction, many Puerto Ricans have emigrated to the US
mainland.
GDP (purchasing power parity):
$130 billion (2017 est.)
$133.1 billion (2016 est.)
$134.9 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 81
GDP (official exchange rate):
$104.2 billion (2017 est.)
GDP—real growth rate: -2.4% (2017 est.)
-1.3% (2016 est.)
-1% (2015 est.)
country comparison to the world: 207
GDP—per capita (PPP): $39,400 (2017 est.)
$39,000 (2016 est.)
$38,800 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 47
GDP—composition, by end use:
household consumption: 87.7% (2017 est.)
government consumption: 12.2% (2017 est.)
investment in fixed capital: 11.7% (2017 est.)
investment in inventories: 0.5% (2017 est.)
exports of goods and services: 117.8% (2017 est.)
imports of goods and services: -129.8% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 0.8% (2017 est.)
industry: 50.1% (2017 est.)
services: 49.1% (2017 est.)
Agriculture—products: sugarcane, coffee, pineapples,
plantains, bananas; livestock products, chickens
Industries: pharmaceuticals, electronics, apparel, food
products, tourism
Industrial production growth rate:
-2.1% (2017 est.)
country comparison to the world: 184
Labor force: 1.139 million (December 2014 est.)
country comparison to the world: 142
Labor force—by occupation: agriculture: 2.1%
industry: 19%
services: 79% (2005 est.)
Unemployment rate: 10.8% (2017 est.)
11.8% (2016 est.)
country comparison to the world: 146
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
NA
highest 10%: NA
Budget: revenues: 9.268 billion (2017 est.)
expenditures: 9.974 billion (2017 est.)
Taxes and other revenues:
8.9% (of GDP) (2017 est.)
country comparison to the world: 217
Budget surplus (+) or deficit (-): -0.7% (of GDP) (2017 est.)
country comparison to the world: 68
Public debt:
51.6% of GDP (2017 est.)
50.1% of GDP (2016 est.)
country comparison to the world: 97
Fiscal year: 1 July—30 June
Inflation rate (consumer prices): 1.8% (2017 est.)
-0.3% (2016 est.)
country comparison to the world: 95
Current account balance:
$0 (2017 est.)
$0 (2016 est.)
country comparison to the world: 66
Exports: $73.17 billion (2017 est.)
$73.2 billion (2016 est.)
country comparison to the world: 41
Exports—commodities: Chemicals, electronics, apparel, canned
tuna, rum, beverage concentrates, medical equipment
Imports: $49.01 billion (2017 est.)
$48.86 billion (2016 est.)
country comparison to the world: 54
Imports—commodities: Chemicals, machinery and equipment,
clothing, food, fish, petroleum products
Debt—external:
$56.82 billion (31 December 2010 est.)
$52.98 billion (31 December 2009 est.)
country comparison to the world: 61
Exchange rates: the US dollar is used
Economy—overview: Qatar’s oil and natural gas resources are
the country’s main economic engine and government
revenue source, driving Qatar’s high economic growth and
per capita income levels, robust state spending on public
entitlements, and booming’ construction spending,
particularly as Qatar prepares to host the World Cup in
2022. Although the government has maintained high
capital spending levels for ongoing infrastructure projects,
low oil and natural gas prices in recent years have led the
Qatari Government to tighten some spending to help stem
its budget deficit.
Qatar’s reliance on oil and natural gas is likely to persist
for the foreseeable future. Proved natural gas reserves
exceed 25 trillion cubic meters—13% of the world total
and, among countries, third largest in the world. Proved oil
reserves exceed 25 billion barrels, allowing production to
continue at current levels for about 56 years. Despite the
dominance of oil and natural gas, Qatar has made
significant gains in strengthening non-oil sectors, such as
manufacturing, construction, and financial services, leading
non-oil GDP to steadily rise in recent years to just over half
the total.
Following trade restriction imposed by Saudi Arabia, the
UAE, Bahrain, and Egypt in 2017, Qatar established new
trade routes with other countries to maintain access to
imports.
GDP (purchasing power parity):
$339.5 billion (2017 est.)
$334.2 billion (2016 est.)
$327.3 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 52
GDP (official exchange rate):
$166.9 billion (2017 est.)
GDP—real growth rate: 1.6% (2017 est.)
2.1% (2016 est.)
3.7% (2015 est.)
country comparison to the world: 169
GDP—per capita (PPP): $124,100 (2017 est.) $127,700 (2016
est.)
$134,200 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 2
Gross national saving:
90.2% of GDP (2017 est.)
42.4% of GDP (2016 est.)
47.4% of GDP (2015 est.)
country comparison to the world: 1
GDP—composition, by end use:
household consumption: 24.6% (2017 est.) government
consumption: 17% (2017 est.)
investment in fixed capital: 43.1% (2017 est.) investment in
inventories: 1.5% (2017 est.) exports of goods and services:
591% (2017 est.) imports of goods and services: -37.3%
(2017 est.) GDP—composition, by sector of origin:
agriculture: 0.2% (2017 est.)
industry: 50.3% (2017 est.)
services: 49.5% (2017 est.)
Agriculture—products: fruits, vegetables; poultry, dairy
products, beef; fish Industries: liquefied natural gas, crude
oil production and_ refining, ammonia, fertilizer,
petrochemicals, steel reinforcing bars, cement, commercial
ship repair Industrial production growth rate:
3% (2017 est.)
country comparison to the world: 105
Labor force: 1.953 million (2017 est.)
country comparison to the world: 126
Unemployment rate: 8.9% (2017 est.)
11.1% (2016 est.)
country comparison to the world: 128
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
1.3%
highest 10%: 35.9% (2007)
Budget: revenues: 44.1 billion (2017 est.) expenditures:
53.82 billion (2017 est.)
Taxes and other revenues:
26.4% (of GDP) (2017 est.)
country comparison to the world: 112
Budget surplus (+) or deficit (-): -5.8% (of GDP) (2017 est.)
country comparison to the world: 179
Public debt:
53.8% of GDP (2017 est.)
46.7% of GDP (2016 est.)
country comparison to the world: 88
Fiscal year: 1 April—31 March
Inflation rate (consumer prices): 0.4% (2017 est.) 2.7% (2016
est.)
country comparison to the world: 25
Current account balance:
$6.426 billion (2017 est.)
-$8.27 billion (2016 est.)
country comparison to the world: 27
Exports: $67.5 billion (2017 est.)
$57.25 billion (2016 est.)
country comparison to the world: 44
Exports—partners: Japan 17.3%, South Korea 16%, India
12.6%, China 11.2%, Singapore 8.2%, UAE 6.4% (2017)
Exports—commodities: liquefied natural gas (LNG), petroleum
products, fertilizers, steel Imports: $30.77 billion (2017 est.)
$31.93 billion (2016 est.)
country comparison to the world: 67
Imports—commodities: machinery and transport equipment,
food, chemicals Imports—partners: China 10.9%, US 8.9%,
UAE 8.5%, Germany 8.1%, UK 5.5%, India 5.4%, Japan
9.3%, Italy 4.3% (2017) Reserves of foreign exchange and gold:
$15.01 billion (31 December 2017 est.)
$31.89 billion (31 December 2016 est.)
country comparison to the world: 68
Debt—external:
$167.8 billion (31 December 2017 est.)
$157.9 billion (31 December 2016 est.)
country comparison to the world: 39
Exchange rates: Qatari rials (QAR) per US dollar— 3.64 (2017
est.)
3.64 (2016 est.)
3.64 (2015 est.)
3.64 (2014 est.)
3.64 (2013 est.)','7c494edfdfe72763c07b863a1bf258dfbed5a2f83481bb32bca4e5f43821cdce','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07391be52d60ba6bd5503f6d10de0f20a790a60c5e44e7074377974db0ee7cd1',2021,'CG','Congo','economy',885,'Economy—overview: The economy of Saint Barthelemy is
based upon high-end tourism and duty-free luxury
commerce, serving visitors primarily from North America.
The luxury hotels and villas host 70,000 visitors each year
with another 130,000 arriving by boat. The relative
isolation and high cost of living inhibits mass tourism. The
construction and public sectors also enjoy significant
investment in support of tourism. With limited fresh water
resources, all food must be imported, as must all energy
resources and most manufactured goods. The tourism
sector creates a strong employment demand and attracts
labor from Brazil and Portugal. The country’s currency is
the euro.
Exchange rates: 2013 est.)
0.885 (2017 est.)
0.903 (2016 est.)
0.9214 (2015 est.)
0.885 (2014 est.)','20774c5261ecf3bf8e2b5c90ca947ea37ac87b146f95661b7b92d55d28ca4a2c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2948cdb57d99bf3451311b69d768289049dd2a40eb4f8531bbddc5e745ddb7',2021,'FR','France','economy',959,'Economy—overview: Economic’ activity is limited to
commercial fishing. The proximity to nearby oil- and gas-
producing sedimentary basins indicate potential oil and gas
deposits, but the region is largely unexplored. No reliable
estimates of potential reserves are available. Commercial
exploitation has yet to be developed.','cd60772bb95cbb1ce9259259066d165be94b08a4a7eb0fae1a8f81cddc45f300','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1aa156a5034f4f93d2168b28eb08482f50902357edb7079919d9d1e78d19baf',2021,'JE','Jersey','economy',978,'Economy—overview: Syria’s economy has deeply deteriorated
amid the ongoing conflict that began in 2011, declining by
more than 70% from 2010 to 2017. The government has
struggled to fully address the effects of international
sanctions, widespread infrastructure damage, diminished
domestic consumption and production, reduced subsidies,
and high inflation, which have caused dwindling foreign
exchange reserves, rising budget and trade deficits, a
decreasing value of the Syrian pound, and falling household
purchasing power. In 2017, some economic indicators
began to stabilize, including the exchange rate and
inflation, but economic activity remains depressed and GDP
almost certainly fell.
During 2017, the ongoing conflict and continued unrest
and economic decline worsened the humanitarian crisis,
necessitating high levels of international assistance, as
more than 13 million people remain in need inside Syria,
and the number of registered Syrian refugees increased
from 4.8 million in 2016 to more than 5.4 million.
Prior to the turmoil, Damascus had begun liberalizing
economic policies, including cutting lending interest rates,
opening private banks, consolidating multiple exchange
rates, raising prices on some _ subsidized items, and
establishing the Damascus Stock Exchange, but the
economy remains highly regulated. Long-run economic
constraints include foreign trade barriers, declining oil
production, high unemployment, rising budget deficits,
increasing pressure on water supplies caused by heavy use
in agriculture, industrial contaction, water pollution, and
widespread infrastructure damage.
GDP (purchasing power parity):
$50.28 billion (2015 est.)
$55.8 billion (2014 est.)
$61.9 billion (2013 est.)
note: data are in 2015 US dollars
the war-driven deterioration of the economy resulted in a
disappearance of quality national level statistics in the
2012-13 period country comparison to the world: 110
GDP (official exchange rate):
$24.6 billion (2014 est.)
GDP—real growth rate: -36.5% (2014 est.)
-30.9% (2013 est.)
note: data are in 2015 dollars
country comparison to the world: 224
GDP—per capita (PPP): $2,900 (2015 est.)
$3,300 (2014 est.)
$2,800 (2013 est.)
note: data are in 2015 US dollars
country comparison to the world: 194
Gross national saving:
17% of GDP (2017 est.)
15.3% of GDP (2016 est.)
16.1% of GDP (2015 est.)
country comparison to the world: 121
GDP—composition, by end use:
household consumption: 73.1% (2017 est.)
government consumption: 26% (2017 est.)
investment in fixed capital: 18.6% (2017 est.)
investment in inventories: 12.3% (2017 est.)
exports of goods and services: 16.1% (2017 est.)
imports of goods and services: -46.1% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 20% (2017 est.)
industry: 19.5% (2017 est.)
services: 60.8% (2017 est.)
Agriculture—products: wheat, barley, cotton, lentils, chickpeas,
olives, sugar beets; beef, mutton, eggs, poultry, milk
Industries: petroleum, textiles, food processing, beverages,
tobacco, phosphate rock mining, cement, oil seeds
crushing, automobile assembly Industrial production growth
rate:
4.3% (2017 est.)
country comparison to the world: 70
Labor force: 3.767 million (2017 est.)
country comparison to the world: 95
Labor force—by occupation: agriculture: 17%
industry: 16%
services: 67% (2008 est.)
Unemployment rate: 50% (2017 est.)
50% (2016 est.)
country comparison to the world: 217
Population below poverty line: 82.5% (2014 est.)
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 1.162 billion (2017 est.)
expenditures: 3.211 billion (2017 est.)
note: government projections for FY2016
Taxes and other revenues:
4.2% (of GDP) (2017 est.)
country comparison to the world: 219
Budget surplus (+) or deficit (-): -8.7% (of GDP) (2017 est.)
country comparison to the world: 203
Public debt:
94.8% of GDP (2017 est.)
91.3% of GDP (2016 est.)
country comparison to the world: 23
Fiscal year: Calendar year
Inflation rate (consumer prices): 28.1% (2017 est.)
47.3% (2016 est.)
country comparison to the world: 220
Current account balance:
-$2.123 billion (2017 est.)
-$2.077 billion (2016 est.)
country comparison to the world: 167
Exports: $1.85 billion (2017 est.)
$1.705 billion (2016 est.)
country comparison to the world: 143
Exports—partners: Lebanon 31.5%, Iraq 10.3%, Jordan 8.8%,
China 7.8%, Turkey 7.5%, Spain 7.3% (2017) Exports—
commodities: crude oil, minerals, petroleum products, fruits
and vegetables, cotton fiber, textiles, clothing, meat and
live animals, wheat Imports: $6.279 billion (2017 est.)
$5.496 billion (2016 est.)
country comparison to the world: 119
Imports—commodities: machinery and transport equipment,
electric power machinery, food and livestock, metal and
metal products, chemicals and chemical products, plastics,
yarn, Paper Imports—partners: Russia 32.4%, Turkey 16.7%,
China 9.5% (2017)
Reserves of foreign exchange and gold:
$407.3 million (31 December 2017 est.)
$504.6 million (31 December 2016 est.)
country comparison to the world: 159
Debt—external:
$4.989 billion (31 December 2017 est.)
$5.085 billion (31 December 2016 est.)
country comparison to the world: 133
Exchange rates: Syrian pounds (SYP) per US dollar—
914.6 (2017 est.)
459.2 (2016 est.)
459.2 (2015 est.)
236.41 (2014 est.)
153.695 (2013 est.)','361b761b124b2ceb927ad8ecf391c119e95c1eb5b47d14f3c93902909c3a4c14','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d47bbbb7b54d56c0265ae76dd1b4a00f9971e3c65140865cb8a241dbfc21c2',2021,'AE','United Arab Emirates','economy',1014,'Economy—overview: The UK, a leading trading power and
financial center, is the third largest economy in Europe
after Germany and France. Agriculture is intensive, highly
mechanized, and efficient by European — standards,
producing about 60% of food needs with less than 2% of
the labor force. The UK has large coal, natural gas, and oil
resources, but its oil and natural gas reserves are
declining; the UK has been a net importer of energy since
2005. Services, particularly banking, insurance, and
business services, are key drivers of British GDP growth.
Manufacturing, meanwhile, has declined in importance but
still accounts for about 10% of economic output.
In 2008, the global financial crisis hit the economy
particularly hard, due to the importance of its financial
sector. Falling home prices, high consumer debt, and the
global economic slowdown compounded the UK’s economic
problems, pushing the economy into recession in the latter
half of 2008 and prompting the then BROWN (Labour)
government to implement a number of measures to
stimulate the economy and stabilize the financial markets.
Facing burgeoning public deficits and debt levels, in 2010
the then CAMERON-led coalition government (between
Conservatives and Liberal Democrats) initiated an austerity
program, which has continued under the Conservative
government. However, the deficit still remains one of the
highest in the G7, standing at 3.6% of GDP as of 2017, and
the UK has pledged to lower its corporation tax from 20%
to 17% by 2020. The UK had a debt burden of 90.4% GDP
at the end of 2017.
The UK economy has begun to slow since the
referendum vote to leave the EU in June 2016. A sustained
depreciation of the British pound has increased consumer
and producer prices, weighing on consumer spending
without spurring a meaningful increase in exports. The UK
has an extensive trade relationship with other EU members
through its single market membership, and economic
observers have warned the exit will jeopardize its position
as the central location for European financial services. The
UK is slated to leave the EU at the end of January 2020.
GDP (purchasing power parity):
$2.925 trillion (2017 est.)
$2.877 trillion (2016 est.)
$2.827 trillion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 9
GDP (official exchange rate):
$2.628 trillion (2017 est.)
GDP—real growth rate: 1.7% (2017 est.)
1.8% (2016 est.)
2.3% (2015 est.)
country comparison to the world: 166
GDP—per capita (PPP): $44,300 (2017 est.)
$43,800 (2016 est.)
$43,400 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 39
Gross national saving:
13.6% of GDP (2017 est.)
12% of GDP (2016 est.)
12.3% of GDP (2015 est.)
country comparison to the world: 142
GDP—composition, by end use:
household consumption: 65.8% (2017 est.)
government consumption: 18.3% (2017 est.)
investment in fixed capital: 17.2% (2017 est.)
investment in inventories: 0.2% (2017 est.)
exports of goods and services: 30.2% (2017 est.)
imports of goods and services: -31.5% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 0.7% (2017 est.)
industry: 20.2% (2017 est.)
services: 79.2% (2017 est.)
Agriculture—products: cereals, oilseed, potatoes, vegetables;
cattle, sheep, poultry; fish; milk, eggs Industries: machine
tools, electric power equipment, automation equipment,
railroad equipment, shipbuilding, aircraft, motor vehicles
and parts, electronics and communications equipment,
metals, chemicals, coal, petroleum, paper and paper
products, food processing, textiles, clothing, other
consumer goods Industrial production growth rate:
3.4% (2017 est.)
country comparison to the world: 93
Labor force: 33.5 million (2017 est.)
country comparison to the world: 17
Labor force—by occupation: agriculture: 1.3%
industry: 15.2%
services: 83.5% (2014 est.)
Unemployment rate: 4.4% (2017 est.)
4.9% (2016 est.)
country comparison to the world: 61
Population below poverty line: 15% (2013 est.)
Household income or consumption by percentage share: Jowest 10%:
1.7%
highest 10%: 31.1% (2012)
Budget: revenues: 1.028 trillion (2017 est.)
expenditures: 1.079 trillion (2017 est.)
Taxes and other revenues:
39.1% (of GDP) (2017 est.)
country comparison to the world: 49
Budget surplus (+) or deficit (-): -1.9% (of GDP) (2017 est.)
country comparison to the world: 102
Public debt:
87.5% of GDP (2017 est.)
87.9% of GDP (2016 est.)
note: data cover general government debt and include debt
instruments issued (or owned) by government entities
other than the treasury; the data include treasury debt held
by foreign entities; the data include debt issued by
subnational entities, as well as intragovernmental debt;
intragovernmental debt consists of treasury borrowings
from surpluses in the social funds, such as for retirement,
medical care, and unemployment; debt instruments for the
social funds are not sold at public auctions country
comparison to the world: 29
Fiscal year: 6 April—5 April
Inflation rate (consumer prices): 2.7% (2017 est.)
0.7% (2016 est.)
country comparison to the world: 126
Current account balance:
-$99.21 billion (2017 est.)
-$139.3 billion (2016 est.)
country comparison to the world: 205
Exports: $441.2 billion (2017 est.)
$407.3 billion (2016 est.)
country comparison to the world: 10
Exports—partners: US 13.2%, Germany 10.5%, France 7.4%,
Netherlands 6.2%, Ireland 5.6%, China 4.8%, Switzerland
4.5% (2017) Exports—commodities: manufactured goods, fuels,
chemicals; food, beverages, tobacco
Imports: $615.9 billion (2017 est.)
$591 billion (2016 est.)
country comparison to the world: 5
Imports—commodities: Manufactured goods, machinery, fuels;
foodstuffs
Imports—partners: Germany 13.7%, US 9.5%, China 9.3%,
Netherlands 8%, France 5.4%, Belgium 5% (2017) Reserves
of foreign exchange and gold:
$150.8 billion (31 December 2017 est.)
$129.6 billion (31 December 2015 est.)
country comparison to the world: 17
Debt—external:
$8.126 trillion (31 March 2016 est.)
$8.642 trillion (31 March 2015 est.)
country comparison to the world: 2
Exchange rates: British pounds (GBP) per US dollar—
0.7836 (2017 est.)
0.738 (2016 est.)
0.738 (2015 est.)
0.607 (2014 est.)
0.6391 (2013 est.)','2359cd415fdf007d411a80a7e7d2124b9702a15962282cf0029da27a984d9a99','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4abc1289ec6bc108f06ef169c2fbca22878fee3b48432f70a892700f094f3c3',2021,'BR','Brazil','economy',1016,'Economy—overview: Uruguay has a free market economy
characterized by an export-oriented agricultural sector, a
well-educated workforce, and high levels of social
spending. Uruguay has sought to expand trade within the
Common Market of the South (Mercosur) and with non-
Mercosur members, and President VAZQUEZ has
maintained his predecessor’s mix of pro-market policies
and a strong social safety net.
Following financial difficulties in the late 1990s and
early 2000s, Uruguay’s economic growth averaged 8%
annually during the 2004-08 period. The 2008-09 global
financial crisis put a brake on Uruguay’s vigorous growth,
which decelerated to 2.6% in 2009. Nevertheless, the
country avoided a recession and kept growth rates positive,
mainly through higher public expenditure and investment;
GDP growth reached 8.9% in 2010 but slowed markedly in
the 2012-16 period as a result of a renewed slowdown in
the global economy and in Uruguay’s main trade partners
and Mercosur counterparts, Argentina and Brazil. Reforms
in those countries should give Uruguay an economic boost.
Growth picked up in 2017.
GDP (purchasing power parity):
$78.16 billion (2017 est.)
$76.14 billion (2016 est.)
$74.87 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 96
GDP (official exchange rate):
$59.18 billion (2017 est.)
GDP—real growth rate: 2.7% (2017 est.)
1.7% (2016 est.)
0.4% (2015 est.)
country comparison to the world: 127
GDP—per capita (PPP): $22,400 (2017 est.)
$21,900 (2016 est.)
$21,600 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 85
Gross national saving:
17.2% of GDP (2017 est.)
18.6% of GDP (2016 est.)
18.7% of GDP (2015 est.)
country comparison to the world: 119
GDP—composition, by end use:
household consumption: 66.8% (2017 est.)
government consumption: 14.3% (2017 est.)
investment in fixed capital: 16.7% (2017 est.)
investment in inventories: -1% (2017 est.)
exports of goods and services: 21.6% (2017 est.)
imports of goods and services: -18.4% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 6.2% (2017 est.)
industry: 24.1% (2017 est.)
services: 69.7% (2017 est.)
Agriculture—products: Cellulose, beef, soybeans, rice, wheat;
dairy products; fish; lumber, tobacco, wine Industries: food
processing, electrical machinery, transportation equipment,
petroleum products, textiles, chemicals, beverages Industrial
production growth rate:
-3.6% (2017 est.)
country comparison to the world: 190
Labor force: 1.748 million (2017 est.)
country comparison to the world: 127
Labor force—by occupation: agriculture: 13%
industry: 14%
services: 73% (2010 est.)
Unemployment rate: 7.6% (2017 est.)
7.9% (2016 est.)
country comparison to the world: 112
Population below poverty line: 9.7% (2015 est.)
Household income or consumption by percentage share: Jowest 10%:
1.9%
highest 10%: 30.8% (2014 est.)
Budget: revenues: 17.66 billion (2017 est.)
expenditures: 19.72 billion (2017 est.)
Taxes and other revenues:
29.8% (of GDP) (2017 est.)
country comparison to the world: 79
Budget surplus (+) or deficit (-): -3.5% (of GDP) (2017 est.)
country comparison to the world: 149
Public debt: 65.7% of GDP (2017 est.)
61.6% of GDP (2016 est.)
note: data cover general government debt and include debt
instruments issued (or owned) by government entities
other than the treasury; the data include treasury debt held
by foreign entities; the data include debt issued by
subnational entities, as well as intragovernmental debt;
intragovernmental debt consists of treasury borrowings
from surpluses in the social funds, such as for retirement,
medical care, and unemployment; debt instruments for the
social funds are not sold at public auctions.
country comparison to the world: 57
Fiscal year: Calendar year
Inflation rate (consumer prices): 6.2% (2017 est.)
9.6% (2016 est.)
country comparison to the world: 189
Current account balance:
$879 million (2017 est.)
$410 million (2016 est.)
country comparison to the world: 51
Exports: $11.41 billion (2017 est.)
$8.387 billion (2016 est.)
country comparison to the world: 86
Exports—partners: China 19%, Brazil 16.1%, US 5.7%,
Argentina 5.4% (2017)
Exports—commodities: beef, soybeans, cellulose, rice, wheat,
wood, dairy products, wool Imports: $8.607 billion (2017
est.)
$8.463 billion (2016 est.)
country comparison to the world: 106
Imports—commodities: refined oil, crude oil, passenger and
other transportation vehicles, vehicle parts, cellular phones
Imports—partners: China 20%, Brazil 19.5%, Argentina 12.6%,
US 10.9% (2017)
Reserves of foreign exchange and gold:
$15.96 billion (31 December 2017 est.)
$13.47 billion (31 December 2016 est.)
country comparison to the world: 66
Debt—external:
$28.37 billion (31 December 2017 est.)
$27.9 billion (31 December 2016 est.)
country comparison to the world: 84
Exchange rates: Uruguayan pesos (UYU) per US dollar—
28.77 (2017 est.)
30.16 (2016 est.)
30.16 (2015 est.)
27.52 (2014 est.)
23.25 (2013 est.)
Economy—overview: Venezuela remains highly dependent on
oil revenues, which account for almost all export earnings
and nearly half of the government’s revenue, despite a
continued decline in oil production in 2017. In the absence
of official statistics, foreign experts estimate that GDP
contracted 12% in 2017, inflation exceeded 2000%, people
faced widespread shortages of consumer goods and
medicine, and the central bank’s international reserves
dwindled. In late 2017, Venezuela also entered selective
default on some of its sovereign and state oil company,
Petroleos de Venezuela, S.A., (PDVSA) bonds. Domestic
production and _ industry continues’ to _ severely
underperform and the Venezuelan Government continues to
rely on imports to meet its basic food and consumer goods
needs.
Falling oil prices since 2014 have aggravated
Venezuela’s economic crisis. Insufficient access to dollars,
price controls, and rigid labor regulations have led some
US and multinational firms to reduce or shut down their
Venezuelan operations. Market uncertainty and PDVSA’s
poor cash flow have slowed investment in the petroleum
sector, resulting in a decline in oil production.
Under President Nicolas MADURO, the Venezuelan
Government’s response to the economic crisis has been to
increase state control over the economy and blame the
private sector for shortages. MADURO has given authority
for the production and distribution of basic goods to the
military and to local socialist party member committees.
The Venezuelan Government has maintained strict currency
controls since 2003. The government has been unable to
sustain its mechanisms for distributing dollars to the
private sector, in part because it needed to withhold some
foreign exchange reserves to make its foreign bond
payments. As a result of price and currency controls, local
industries have struggled to purchase production inputs
necessary to maintain their operations or sell goods at a
profit on the local market. Expansionary monetary policies
and currency controls have created opportunities for
arbitrage and corruption and fueled a rapid increase in
black market activity.
GDP (purchasing power parity):
$381.6 billion (2017 est.)
$443.7 billion (2016 est.)
$531.1 billion (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 47
GDP (official exchange rate):
$210.1 billion (2017 est.)
GDP—real growth rate: -14% (2017 est.)
-16.5% (2016 est.)
-6.2% (2015 est.)
country comparison to the world: 222
GDP—per capita (PPP): $12,500 (2017 est.)
$14,400 (2016 est.)
$17,300 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 126
Gross national saving:
12.1% of GDP (2017 est.)
8.6% of GDP (2016 est.)
31.8% of GDP (2015 est.)
country comparison to the world: 150
GDP—composition, by end use:
household consumption: 68.5% (2017 est.)
government consumption: 19.6% (2017 est.)
investment in fixed capital: 13.9% (2017 est.)
investment in inventories: 1.7% (2017 est.)
exports of goods and services: 7% (2017 est.)
imports of goods and services: -10.7% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 4.7% (2017 est.)
industry: 40.4% (2017 est.)
services: 54.9% (2017 est.)
Agriculture—products: corn, sorghum, sugarcane, rice,
bananas, vegetables, coffee; beef, pork, milk, eggs; fish
Industries: agricultural products, livestock, raw materials,
machinery and equipment, transport equipment,
construction materials, medical equipment,
pharmaceuticals, chemicals, iron and steel products, crude
oil and petroleum products Industrial production growth rate:
-2% (2017 est.)
country comparison to the world: 183
Labor force: 14.21 million (2017 est.)
country comparison to the world: 40
Labor force—by occupation: agriculture: 7.3%
industry: 21.8%
services: 70.9% (4th quarter, 2011 est.)
Unemployment rate: 27.1% (2017 est.)
20.6% (2016 est.)
country comparison to the world: 199
Population below poverty line: 19.7% (2015 est.)
Household income or consumption by percentage share: Jowest 10%:
1.7%
highest 10%: 32.7% (2006)
Budget: revenues: 92.8 billion (2017 est.) expenditures:
189.7 billion (2017 est.)
Taxes and other revenues:
44.2% (of GDP) (2017 est.)
country comparison to the world: 25
Budget surplus (+) or deficit (-): -46.1% (of GDP) (2017 est.)
country comparison to the world: 220
Public debt:
38.9% of GDP (2017 est.)
31.3% of GDP (2016 est.)
note: data cover central government debt, as well as the
debt of state-owned oil company PDVSA; the data include
treasury debt held by foreign entities; the data include
some debt issued by subnational entities, as well as
intragovernmental debt; intragovernmental debt consists of
treasury borrowings from surpluses in the social funds,
such as for retirement, medical care, and unemployment;
some debt instruments for the social funds are sold at
public auctions country comparison to the world: 135
Fiscal year: Calendar year
Inflation rate (consumer prices): 1,087.5% (2017 est.)
254.4% (2016 est.)
country comparison to the world: 226
Current account balance:
$4.277 billion (2017 est.)
-$3.87 billion (2016 est.)
country comparison to the world: 32
Exports: $32.06 billion (2017 est.)
$27.2 billion (2016 est.)
country comparison to the world: 62
Exports—partners: US 34.8%, India 17.2%, China 16%,
Netherlands Antilles 8.2%, Singapore 6.3%, Cuba 4.2%
(2017) Exports—commodities: petroleum and _ petroleum
products, bauxite and aluminum, minerals, chemicals,
agricultural products Imports: $11 billion (2017 est.)
$16.34 billion (2016 est.)
country comparison to the world: 99
Imports—commodities: agricultural products, livestock, raw
materials, machinery and equipment, transport equipment,
construction materials, medical equipment, petroleum
products, pharmaceuticals, chemicals, iron and _ steel
products Imports—partners: US 24.8%, China 14.2%, Mexico
9.5% (2017)
Reserves of foreign exchange and gold:
$9.661 billion (31 December 2017 est.)
$11 billion (31 December 2016 est.)
country comparison to the world: 75
Debt—external:
$100.3 billion (31 December 2017 est.)
$109.8 billion (31 December 2016 est.)
country comparison to the world: 47
Exchange rates: bolivars (VEB) per US dollar—
3,345 (2017 est.)
673.76 (2016 est.)
48.07 (2015 est.)
13.72 (2014 est.)
6.284 (2013 est.)','91f79bbb9a7ea80e21300cc6aa75f35b9273cd8611780a809898cd066329664a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92b85cb2efba9721ee5a784ede6ed1bc8cb9814388139314ea887d5a5aa06d2a',2021,'SB','Solomon Islands','economy',1022,'Economy—overview: This South Pacific island economy is
based primarily on small-scale agriculture, which provides
a living for about two thirds of the population. Fishing,
offshore financial services, and tourism, with more than
330,000 visitors in 2017, are other mainstays of the
economy. Tourism has struggled after Efate, the most
populous and most popular island for tourists, was
damaged by Tropical Cyclone Pam in 2015. Ongoing
infrastructure difficulties at Port Vila’s Bauerfield Airport
have caused air travel disruptions, further hampering
tourism numbers. Australia and New Zealand are the main
source of tourists and foreign aid. A small light industry
sector caters to the local market. Tax revenues come
mainly from import duties. Mineral deposits are negligible;
the country has no known petroleum deposits.
Economic development is hindered by dependence on
relatively few commodity exports, vulnerability to natural
disasters, and long distances from main markets and
between constituent islands. In response to foreign
concerns, the government has promised to _ tighten
regulation of its offshore financial center.
Since 2002, the government has stepped up efforts to
boost tourism through improved air connections, resort
development, and cruise ship facilities. Agriculture,
especially livestock farming, is a second target for growth.
GDP (purchasing power parity):
$772 million (2017 est.)
$740.9 million (2016 est.)
$716.1 million (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 207
GDP (official exchange rate):
$870 million (2017 est.)
GDP—real growth rate: 4.2% (2017 est.)
3.5% (2016 est.)
0.2% (2015 est.)
country comparison to the world: 73
GDP—per capita (PPP): $2,700 (2017 est.)
$2,700 (2016 est.)
$2,700 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 196
GDP—composition, by end use:
household consumption: 59.9% (2017 est.)
government consumption: 17.4% (2017 est.)
investment in fixed capital: 28.7% (2017 est.)
investment in inventories: 0% (2017 est.)
exports of goods and services: 42.5% (2017 est.)
imports of goods and services: -48.5% (2017 est.)
GDP—composition, by sector of origin:
agriculture: 27.3% (2017 est.)
industry: 11.8% (2017 est.)
services: 60.8% (2017 est.)
Agriculture—products: Copra, coconuts, cocoa, coffee, taro,
yams, fruits, vegetables; beef; fish Industries: food and fish
freezing, wood processing, meat canning
Industrial production growth rate:
4.5% (2017 est.)
country comparison to the world: 68
Labor force: 115,900 (2007 est.)
country comparison to the world: 182
Labor force—by occupation: agriculture: 65%
industry: 5%
services: 30% (2000 est.)
Unemployment rate: 1.7% (1999 est.)
country comparison to the world: 16
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 236.7 million (2017 est.)
expenditures: 244.1 million (2017 est.)
Taxes and other revenues:
27.2% (of GDP) (2017 est.)
country comparison to the world: 102
Budget surplus (+) or deficit (-): -0.9% (of GDP) (2017 est.)
country comparison to the world: 73
Public debt:
48.4% of GDP (2017 est.)
46.1% of GDP (2016 est.)
country comparison to the world: 107
Fiscal year: Calendar year
Inflation rate (consumer prices): 3.1% (2017 est.)
0.8% (2016 est.)
country comparison to the world: 134
Current account balance:
-$13 million (2017 est.)
-$37 million (2016 est.)
country comparison to the world: 70
Exports: $44.7 million (2017 est.)
$53.5 million (2016 est.)
country comparison to the world: 204
Exports—partners: Philippines 23.9%, Australia 16.5%, US
10.4%, Japan 8.8%, Venezuela 8%, France 4.8%, Fiji 4.5%,
Hong Kong 4.4% (2017) Exports—commodities: copra, beef
(veal), cocoa, timber, kava, coffee, coconut oil, shell,
cowhides, coconut meal, fish Imports: $273.7 million (2017
est.)
$308.5 million (2016 est.)
country comparison to the world: 207
Imports—commodities: Machinery and equipment, foodstuffs,
fuels
Imports—partners: Russia 35.2%, Australia 19.8%, NZ 9.8%,
China 6.3%, Fiji 5.5% (2017) Reserves of foreign exchange and
gold:
$395.1 million (31 December 2017 est.)
$267.4 million (31 December 2016 est.)
country comparison to the world: 160
Debt—external:
$200.5 million (31 December 2017 est.)
$182.5 million (31 December 2016 est.)
country comparison to the world: 188
Exchange rates: vatu (VUV) per US dollar—
109.7 (2017 est.)
112.28 (2016 est.)
2015 est.)
108.99 (2014 est.)
97.07 (2013 est.)','4bd207e17ec983cb072d398c6a05f26bbb2abaeb5637cd2866aa4b657d2485bc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6af4cf362ce435d3d2cfed6cf2861a25a8cdf793a8a0e63166368f582b8a00c',2021,'WF','Wallis and Futuna','economy',1030,'Economy—overview: The economy is limited to traditional
subsistence agriculture, with about 80% of labor force
earnings coming from agriculture (coconuts and
vegetables), livestock (mostly pigs), and fishing. However,
roughly 70% of the labor force is employed in the public
sector, although only about a third of the population is in
salaried employment.
Revenues come from French Government subsidies,
licensing of fishing rights to Japan and South Korea, import
taxes, and remittances from expatriate workers in New
Caledonia. France directly finances the public sector and
health-care and education services. It also provides funding
for key development projects in a range of areas, including
infrastructure, economic development, environmental
management, and health-care facilities.
A key concern for Wallis and Futuna is an aging
population with consequent economic development issues.
Very few people aged 18-30 live on the islands due to the
limited formal employment opportunities. Improving job
creation is a current priority for the territorial government.
GDP (purchasing power parity):
$60 million (2004 est.)
country comparison to the world: 225
GDP (official exchange rate):
$195 million (2005) (2005)
GDP—real growth rate: NA
GDP—per capita (PPP): $3,800 (2004 est.)
country comparison to the world: 181
GDP—composition, by end use:
household consumption: 26% (2005)
government consumption: 54% (2005)
GDP—composition, by sector of origin:
agriculture: NA
industry: NA
services: NA
Agriculture—products: coconuts, breadfruit, yams, taro,
bananas; pigs, goats; fish
Industries: Copra, handicrafts, fishing, lumber
Industrial production growth rate: NA
Labor force: 4,482 (2013)
country comparison to the world: 223
Labor force—by occupation: agriculture: 74%
industry: 3%
services: 23% (2015 est.)
Unemployment rate:
8.8% (2013 est.)
12.2% (2008 est.)
country comparison to the world: 126
Population below poverty line: NA
Household income or consumption by percentage share: Jowest 10%:
NA highest 10%: NA
Budget: revenues: 32.54 million NA (2015 est.)
expenditures: 34.18 million NA (2015 est.)
Taxes and other revenues:
16.7% (of GDP) NA (2015 est.)
country comparison to the world: 175
Budget surplus (+) or deficit (-): -0.8% (of GDP) NA (2015 est.)
country comparison to the world: 70
Public debt:
5.6% of GDP (2004 est.)
note: offical data; data cover general government debt and
include debt instruments issued (or owned) by government
entities other than the treasury; the data include treasury
debt held by foreign entities; the data include debt issued
by subnational entities, as well as intragovernmental debt;
intragovernmental debt consists of treasury borrowings
from surpluses in the social funds, such as for retirement,
medical care, and unemployment; debt instruments for the
social funds are not sold at public auctions country
comparison to the world: 204
Fiscal year: Calendar year
Inflation rate (consumer prices): 0.9% (2015)
2.8% (2005)
country comparison to the world: 48
Exports: $47,450 (2004 est.)
country comparison to the world: 222
Exports—commodities: copra, chemicals, construction
materials
Imports: $61.17 million (2004 est.)
country comparison to the world: 220
Imports—commodities: chemicals, machinery, consumer goods
Debt—external:
$3.67 million (2004)
country comparison to the world: 201
Exchange rates: Comptoirs Francais du Pacifique francs (XPF)
per US dollar—
110.2 (2015 est.)
89.8 (2014 est.)
89.85 (2013 est.)
90.56 (2012 est.)','d649f8659c859b1b709a6ec12e231a841dcc32f054a0854b9b4e7c506ff6dc90','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

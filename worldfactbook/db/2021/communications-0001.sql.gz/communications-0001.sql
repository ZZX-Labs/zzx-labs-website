SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d88a8d527dc2aa950c6892ff161b2c6b89ef6ce5333aba9b2e02763553e5493',2021,'US','United States','communications',40,'Telephones—fixed lines: total subscriptions
subscriptions per 100 inhabitants Telephones—mobile
cellular: total subscriptions
subscriptions per 100 inhabitants Telephone system:
general assessment
domestic
international
Broadcast media: Internet country code:
Internet users: total
percent of population
Broadband—fixed subscriptions: total
subscriptions per 100 inhabitants Communications—
note: MILITARY AND SECURITY
Military expenditures: Military and security
forces: Military service age and obligation:
Maritime threats: Military—note:
Telephones—fixed lines:
Telephones—mobile cellular: Internet users:
Broadband—fixed subscriptions:
Telephones—fixed lines: total subscriptions: 109.961 million
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 2
Telephones—mobile cellular:
total subscriptions: 422 million
subscriptions per 100 inhabitants: 129 (2018 est.)
country comparison to the world: 3
Telephone —_ system: general assessment: a _ large,
technologically advanced, multipurpose communications
system; mobile subscriber penetration rate of about 127%;
9G technologies and commercial services into 2019 and
2020; developing technologies based on 5G for non-
commercial customers as well; FttP rather than FttN
efforts (2018) domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries every form of telephone traffic; a rapidly
growing cellular system carries mobile telephone traffic
throughout the country; fixed-line 27 per 100 and mobile-
cellular 121 per 100 (2018) international: country code—1;
landing points for the Quintillion Subsea Cable Network,
TERRA SW, AU-Aleutian, KKFL, AKORN, Alaska United -
West, & -East & -Southeast, North Star, Lynn Canal Fiber,
KetchCar 1, PC-1, SCCN, Tat TGN-Pacific & -Atlantic,
Jupiter, Hawaiki, NCP FASTER, HKA, JUS, AAG, BtoBE,
Currie, Southern Cross NEXT, SxS, PLCN, Utility EAC-
Pacific, SEA-US, Paniolo Cable Network, HICS, HIFN, ASH,
Telstra Endeavor, Honotua, AURORA, ARCOS, AMX-1,
Americas -I & -II, Columbus IIb & -III, Maya-1, MAC,
GTMO-1, BICS, CFX-1, GlobeNet, Monet, SAm-1, Bahamas
2, PCCS, BRUSA, Dunant, MAREA, SAE x1, TAT 14, Apollo,
Gemini Bermuda, Havfrue/AEC-2, Seabras-1, WALL-LI,
NYNJ-1, FLAG Atalantic-1, Yellow, Atlantic Crossing-1, AE
Connect -1, sea2shore, Challenger Bermuda-1, and GTT
Atlantic submarine cable systems providing international
connectivity to Europe, Africa, the Middle East, Asia,
Southeast Asia, Australia, New Zealand, Pacific, & Atlantic,
and Indian Ocean Islands, Central and South America,
Caribbean, Canada and US; satellite earth stations—61
Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5
Intersputnik (Atlantic Ocean region), and 4 Inmarsat
(Pacific and Atlantic Ocean regions) (2020) Broadcast media: 4
major terrestrial TV networks with affiliate stations
throughout the country, plus cable and satellite networks,
independent stations, and a limited public broadcasting
sector that is largely supported by private grants; overall,
thousands of TV stations broadcasting; multiple national
radio networks with many affiliate stations; while most
stations are commercial, National Public Radio (NPR) has a
network of some 900 member stations; satellite radio
available; in total, over 15,000 radio stations operating
(2018) Internet country code: .US
Internet users: total: 246,809,221
percent of population: 76.2% (July 2016 est.)
country comparison to the world: 3
Broadband—fixed subscriptions: total: 110.568 million
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 2
Communications—note: note 1: The Library of Congress,
Washington DC, USA, claims to be the largest library in the
world with more than 167 million items (as of 2018); its
collections are universal, not limited by subject, format, or
national boundary, and include materials from all parts of
the world and in over 450 languages; collections include:
books, newspapers, magazines, sheet music, sound and
video recordings, photographic images, artwork,
architectural drawings, and copyright data note 2: Cape
Canaveral, Florida, USA, hosts one of four dedicated
ground antennas that assist in the operation of the Global
Positioning System (GPS) navigation system (the others are
on Ascension (Saint Helena, Ascension, and Tistan da
Cunha), Diego Garcia (British Indian Ocean Territory), and
at Kwajalein (Marshall Islands) MILITARY AND SECURITY
Military expenditures:
3.42% of GDP (2019 est.)
3.3% of GDP (2018)
3.31% of GDP (2017)
3.52% of GDP (2016)
3.52% of GDP (2015)
country comparison to the world: 19
Military and security forces: United States Armed Forces: US
Army, US Navy (includes Marine Corps), US Air Force, US
Coast Guard (administered in peacetime by the Department
of Homeland Security, but in wartime reports to the
Department of the Navy), National Guard (Army National
Guard and Air National Guard) (2019) Military service age and
obligation: 18 years of age (17 years of age with parental
consent) for male and female voluntary service; no
conscription; maximum enlistment age 34 (Army), 39 (Air
Force), 39 (Navy), 28 (Marines), 31 (Coast Guard); 8-year
service obligation, including 2-5 years active duty (Army), 2
years active (Navy), 4 years active (Air Force, Marines,
Coast Guard); all military occupations and positions open to
women (2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
92 (2015) inventory of registered aircraft operated by air
carriers: 6,817 (2015)
annual passenger traffic on registered air carriers: 798.23
million (2015)
annual freight traffic on registered air carriers: 37.219
billion mt-km (2015)
Civil aircraft registration country code prefix: N (2016)
Airports: 13,513 (2013)
country comparison to the world: 1
Airports—with paved runways:
total: 5,054 (2013)
over 3,047 m: 189 (2013)
2,438 to 3,047 m: 235 (2013)
1,524 to 2,437 m: 1,478 (2013)
914 to 1,523 m: 2,249 (2013)
under 914 m: 903 (2013)
Airports—with unpaved runways:
total: 8,459 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 6 (2013)
1,524 to 2,437 m: 140 (2013)
914 to 1,523 m: 1,552 (2013)
under 914 m: 6,760 (2013)
Heliports: 5,287 (2013)
Pipelines: 1,984,321 km natural gas, 240,711 km petroleum
products (2013)
Railways: total: 293,564 km (2014)
standard gauge: 293,564.2 km 1.435-m gauge (2014)
country comparison to the world: 1
Roadways: total: 6,586,610 km (2012)
paved: 4,304,715 km (includes 76,334 km of expressways)
(2012)
unpaved: 2,281,895 km (2012)
country comparison to the world: 1
Waterways: 41,009 km (19,312 km used for commerce; Saint
Lawrence Seaway of 3,769 km, including the Saint
Lawrence River of 3,058 km, is shared with Canada) (2012)
country comparison to the world: 5
Merchant marine: total: 3,692
by type: bulk carrier 5, container ship 61, general cargo
115, oil tanker 71, other 3440 (2018) country comparison
to the world: 5
Ports and terminals: Oil terminal(s): LOOP terminal, Haymark
terminal
container port(s) (TEUs): Charleston (2,177,000), Hampton
Roads (2,841,000), Houston (2,459,000), Long Beach
(7,544,000), Los Angeles (9,343,000), New York/New Jersey
(6,710,000), Oakland (2,420,000), Savannah (4,046,000),
Seattle/Tacoma (3,665,000) (2017) LNG terminal(s)
(export): Cameron (LA), Corpus Christi (TX), Cove Point
(MD), Elba Island (GA), Freeport (TX), Sabine Pass (LA)
note—two’ additional export facilities are under
construction and expected to begin commercial operations
in 2023-2024
LNG terminal(s) (import): Cove Point (MD), Elba Island
(GA), Everett (MA), Freeport (TX), Golden Pass (TX),
Hackberry (LA), Lake Charles (LA), Neptune (offshore),
Northeast Gateway (offshore), Pascagoula (MS), Sabine
Pass (TX) cargo ports: Baton Rouge, Corpus Christi,
Hampton Roads, Houston, Long Beach, Los Angeles, New
Orleans, New York, Plaquemines (LA), Tampa, Texas City
cruise departure ports (passengers): Miami (2,032,000),
Port Everglades (1,277,000), Port Canaveral (1,189,000),
Seattle (430,000), Long Beach (415,000) (2009)
Union of Soviet Socialist Republics (Soviet
Union); used for information dated before 25
December 1991
Coordinated Universal Time
ultraviolet
very-high-frequency
very small aperture terminal
West African Development Bank
West African Economic and Monetary Union
World Confederation of Labor
World Customs Organization
Convention on Wetlands of International
Importance Especially As Waterfowl Habitat
Western European Union
World Food Program
World Federation of Trade Unions
International Convention for the Regulation of
Whaling
World Health Organization
World Intellectual Property Organization
World Meteorological Organization
Warsaw Pact
World Trade Organization
Zangger Committee
APPENDIX B
INTERNATIONAL ORGANIZATIONS
AND GROUPS
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid
industrial development; see newly industrializing economies (NIEs)
advanced economies
a term used by the International Monetary FUND (IMF) for the top group in its
hierarchy of advanced economies, countries in transition, and developing
countries; it includes the following 33 advanced economies: Australia, Austria,
Belgium, Canada, Cyprus, Czechia, Denmark, Estonia, Finland, France,
Germany, Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan, South
Korea, Latvia, Lithuania, Luxembourg, Malta, Netherlands, NZ, Norway,
Portugal, Singapore, Slovakia, Slovenia, Spain, Sweden, Switzerland, Taiwan,
Uk, US; note—this group would presumably also cover the following nine
smaller countries of Andorra, Bermuda, Faroe Islands, Guernsey, Holy See,
Jersey, Liechtenstein, Monaco, and San Marino that are included in the more
comprehensive group of “developed countries”
African Development Bank Group (AfDB)
note—regional multilateral development finance institution temporarily located
in Tunis, Tunisia; the Bank Group consists of the African Development Bank,
the African Development Fund, and the Nigerian Trust Fund
established—10 September 1964
aim—to promote economic development and social progress
regional members—(54) Algeria, Angola, Benin, Botswana, Burkina Faso,
Burundi, Cabo Verde, Cameroon, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Gabon, The
Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique,
Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Somalia, South Africa, South Sudan, Sudan, Tanzania, Togo,
Tunisia, Uganda, Zambia, Zimbabwe
nonregional members—(27) Argentina, Austria, Belgium, Brazil, Canada, China,
Denmark, Finland, France, Germany, India, Italy, Japan, South Korea, Kuwait,
Luxembourg, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden,
Switzerland, Turkey, UAE (ADF members only), UK, US
African Union (AU)
note—replaces Organization of African Unity (OAU)
established—8 July 2001
aim—to achieve greater unity among African States; to defend states’ integrity
and independence; to accelerate political, social, and economic integration; to
encourage international cooperation; to promote democratic principles and
institutions
members—(55) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cabo
Verde, Cameroon, Central African Republic (suspended), Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt (suspended), Equatorial Guinea, Eritrea, Eswatini, Ethiopia,
Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau (suspended), Kenya,
Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius,
Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi Arab
Democratic Republic (Western Sahara), Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Somalia, South Africa, South Sudan, Sudan, Tanzania,
Togo, Tunisia, Uganda, Zambia, Zimbabwe
African Union Mission in Somalia (AMISOM)
established—2007
aim—United Nations-approved, African Union peacekeeping mission for
assisting Somali government forces in providing security for a stable political
process, enabling the gradual handing over of security responsibilities from
AMISOM to the Somali security forces, and reducing the threat posed by AIl-
Shabaab and other armed opposition groups
members—Sudan, Eritrea, Uganda, Djibouti, Burundi, Nigeria, Ghana, Malawi
African Union/United Nations Hybrid Operation in Darfur (UNAMID)
established—31 July 2007
aim—to contribute to the restoration of security conditions which will allow
safe humanitarian assistance throughout Darfur, to contribute to the protection
of civilian populations under imminent threat of physical attack, to monitor,
observe compliance with, and verify the implementation of various ceasefire
agreements
members—(42) Bangladesh, Bhutan, Bolivia, Burkina Faso, Burundi, Cambodia,
Cameroon, China, Djibouti, Ecuador, Egypt, Ethiopia, The Gambia, Germany,
Ghana, Indonesia, Iran, Jordan, Kenya, Kyrgyzstan, Malawi, Malaysia, Mali,
Mongolia, Namibia, Nepal, Nigeria, Pakistan, Papua New Guinea, Peru,
Rwanda, Senegal, Sierra Leone, South Africa, Tanzania, Thailand, Togo,
Tunisia, Turkey, Yemen, Zambia, Zimbabwe
African, Caribbean, and Pacific Group of States (ACP Group)
established—6 June 1975
aim—to manage their preferential economic and aid relationship with the EU
members—(79) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize,
Benin, Botswana, Burkina Faso, Burundi, Cabo Verde, Cameroon, Central
African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Cook Islands, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican
Republic, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Fiji, Gabon, The
Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica,
Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali, Marshall Islands,
Mauritania, Mauritius, Federated States of Micronesia, Mozambique, Namibia,
Nauru, Niger, Nigeria, Niue, Palau, Papua New Guinea, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia,
South Africa, Sudan, Suriname, Tanzania, Timor-Leste, Togo, Tonga, Trinidad
and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
Agency for the Prohibition of Nuclear Weapons in Latin America and
the Caribbean (OPANAL)
note—acronym from Organismo para la Proscripcion de las Armas Nucleares en
la America Latina y el Caribe (OPANAL)
established—14 February 1967 under the Treaty of Tlatelolco; effective—25
April 1969 on the 11th ratification
aim—to encourage the peaceful uses of atomic energy and prohibit nuclear
weapons
members—(33) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras,
Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago,
Uruguay, Venezuela
Alliance of Small Island States (AOSIS)
established—November 1990
aim—to call attention to threats of sea-level rise and coral bleaching to small
islands and low-lying coastal developing states from global warming; to
emphasize the importance of information and information technology in the
process of achieving sustainable development
members—(39) Antigua and Barbuda, The Bahamas, Barbados, Belize, Cabo
Verde, Comoros, Cook Islands, Cuba, Dominica, Dominican Republic, Fiji,
Grenada, Guinea-Bissau, Guyana, Haiti, Jamaica, Kiribati, Maldives, Marshall
Islands, Mauritius, Federated States of Micronesia, Nauru, Niue, Palau, Papua
New Guinea, St. Kitts and Nevis, St. Lucia, St. Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Seychelles, Singapore, Solomon Islands,
Suriname, Timor-Leste, Tonga, Trinidad and Tobago, Tuvalu, Vanuatu
observers—(5) American Samoa, Guam, Netherlands Antilles, Puerto Rico, U.S.
Virgin Islands
Andean Community (CAN)
note—formerly known as the Andean Group (AG) and the Andean Common
Market (Ancom)
established—26 May 1969; present name established 1 October 1992; effective
—16 October 1969
aim—to promote harmonious development through economic integration
members—(4) Bolivia, Colombia, Ecuador, Peru
associate members—(5) Argentina, Brazil, Chile, Paraguay, Uruguay
observers—(3) Mexico, Panama, Spain
Arab Bank for Economic Development in Africa (ABEDA)
note—also known as Banque Arabe de Developpement Economique en Afrique
(BADEA)
established—18 February 1974; effective—16 September 1974
aim—to promote economic development
members—(17 plus the State of Palestine) Algeria, Bahrain, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia,
Sudan, Syria, Tunisia, UAE, State of Palestine; note—these are all the members
of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Fund for Economic and Social Development (AFESD)
established—16 May 1968
aim—to promote economic and social development
members—(21 plus Palestine) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq,
Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Palestine, Qatar,
Saudi Arabia, Somalia (suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen
Arab Maghreb Union (AMU)
established—17 February 1989
aim—to promote cooperation and integration among the Arab states of
northern Africa
members—(5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF)
established—27 April 1976; effective—2 February 1977
aim—to promote Arab cooperation, development, and integration in monetary
and economic affairs
members—(21 plus Palestine) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq,
Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Palestine, Qatar,
Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen
Arctic Council
established—18 September 1996
aim—to address the common concerns and challenges faced by Arctic
governments and the people of the Arctic; to protect the Arctic environment
members—(8) Canada, Denmark (Greenland, Faroe Islands), Finland, Iceland,
Norway, Russia, Sweden, US
permanent participants—(6) Aleut International Association, Arctic Athabaskan
Council, Gwich’in Council International, Inuit Circumpolar Conference, Russian
Association of Indigenous People of the North, Saami Council
observers—(13) China, France, Germany, India, Italy, Japan, South Korea,
Netherlands, Poland, Singapore, Spain, Switzerland, UK
ASEAN Regional Forum (ARF)
established—25 July 1994
aim—to foster constructive dialogue and consultation on political and security
issues of common interest and concern
members—(27) Australia, Bangladesh, Brunei, Burma, Cambodia, Canada,
China, EU, India, Indonesia, Japan, North Korea, South Korea, Laos, Malaysia,
Mongolia, NZ, Pakistan, Papua New Guinea, Philippines, Russia, Singapore, Sri
Lanka, Thailand, Timor-Leste, US, Vietnam
Asia-Pacific Economic Cooperation (APEC)
established—7 November 1989
aim—to promote trade and investment in the Pacific basin
members—(21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia,
Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea, Peru,
Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers—(3) Association of Southeast Asian Nations, Pacific Economic
Cooperation Council, Pacific Islands Forum Secretariat
Asian Development Bank (ADB)
established—19 December 1966
aim—to promote regional economic cooperation
members—(48) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh,
Bhutan, Brunei, Burma, Cambodia, China, Cook Islands, Fiji, Georgia, Hong
Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan,
Laos, Malaysia, Maldives, Marshall Islands, Federated States of Micronesia,
Mongolia, Nauru, Nepal, NZ, Pakistan, Palau, Papua New Guinea, Philippines,
Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan, Thailand,
Timor-Leste, Tonga, Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members—(19) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Luxembourg, Netherlands, Norway, Portugal,
Spain, Sweden, Switzerland, Turkey, UK, US
Asian Infrastructure Investment Bank (AIIB)
established— January 2016
aim— to improve social and economic outcomes in Asia
regional members (including prospective members)—(48) Afghanistan,
Australia, Azerbaijan, Bangladesh, Brunei, Burma, Cambodia, China, Fiji,
Georgia, Hong Kong, India, Indonesia, Iran, Israel, Jordan, Kazakhstan, Korea,
Kyrgyzstan, Laos, Malaysia, Maldives, Mongolia, Nepal, New Zealand, Oman,
Pakistan, Philippines, Qatar, Russia, Samoa, Saudi Arabia, Singapore, Sri
Lanka, Tajikistan, Thailand, Timor-Leste, Turkey, UAE, Uzbekistan, Vanuatu,
Vietnam—Prospective—Armenia, Bahrain, Cook Islands, Cyprus, Kuwait, Tonga
non-regional members (including prospective members)—(36) Austria,
Denmark, Egypt, Ethiopia, Finland, France, Germany, Hungary, Iceland,
Ireland, Italy, Luxembourg, Malta, Netherlands, Norway, Poland, Portugal,
Spain, Sweden, Switzerland, UK—Prospective—Argentina, Belarus, Belgium,
Bolivia, Brazil, Canada, Chile, Ecuador, Greece, Madagascar, Peru, Romania,
South Africa, Sudan, Venezuela
Association of Southeast Asian Nations (ASEAN)
established—8 August 1967
aim—to encourage regional economic, social, and cultural cooperation among
the non-Communist countries of Southeast Asia
members—(10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
dialogue partners—(11) Australia, Canada, China, EU, India, Japan, South
Korea, NZ, Pakistan, Russia, US
observers—(2) Papua New Guinea, Timor-Leste
Australia Group (AG)
established—June, 1985
aim—to consult on and coordinate export controls related to chemical and
biological weapons
members—(43) Argentina, Australia, Austria, Belgium, Bulgaria, Canada,
Croatia, Cyprus, Czechia, Denmark, Estonia, European Union, Finland, France,
Germany, Greece, Hungary, Iceland, India, Ireland, Italy, Japan, South Korea,
Latvia, Lithuania, Luxembourg, Malta, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Turkey, Ukraine, UK, US
Australia-New Zealand-United States Security Treaty (ANZUS)
established—1 September 1951; effective—29 April 1952
aim—to implement a trilateral mutual security agreement, although the US
suspended security obligations to NZ on 11 August 1986; Australia and the US
continue to hold annual meetings
members—(3) Australia, NZ, US
Baltic Assembly (BA)
established—12 May 1990
aim—to thoroughly discuss various cooperation issues between Baltic states
members—(3) Estonia, Latvia, Lithuania
Bank for International Settlements (BIS)
established—20 January 1930; effective—17 March 1930
aim—to promote cooperation among central banks in international financial
settlements
members—(60) Algeria, Argentina, Australia, Austria, Belgium, Bosnia and
Herzegovina, Brazil, Bulgaria, Canada, Chile, China, Colombia, Croatia,
Czechia, Denmark, European Central Bank, Estonia, Finland, France, Germany,
Greece, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy,
Japan, South Korea, Latvia, Lithuania, Luxembourg, Malaysia, Mexico,
Netherlands, NZ, North Macedonia, Norway, Peru, Philippines, Poland,
Portugal, Romania, Russia, Saudi Arabia, Serbia, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sweden, Switzerland, Thailand, Turkey, UAE, UK, US; note
—Montenegro has a separate central bank; its links with BIS are currently
under review
Bay of Bengal Initiative for Multi-Sectoral Technical and Economic
Cooperation (BIMSTEC)
established—June 1997
aim—to foster socio-economic cooperation among members
members—(7) Bangladesh, Bhutan, Burma, India, Nepal, Sri Lanka, Thailand
Benelux Union (Benelux)
note—acronym from Belgiu','55e30274f875ff9f97a64dbf21c7012d80995ffb43a0dda34c0fb444886f9a45','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9736b078e0e917f65241c476e92a0ec5e3658656d71ce8bbbeb5e6059de0b3c4',2021,'US','United States','communications',41,'m, Netherlands, and Luxembourg; was formerly
known as Benelux Economic Union
established—3 February 1958; effective—1 November 1960; changed names 17
June 2008
aim—to develop closer economic and legal cooperation and integration
members—(3) Belgium, Luxembourg, Netherlands
Black Sea Economic Cooperation Zone (BSEC)
established—25 June 1992
aim—to enhance regional stability through economic cooperation
members—(12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece,
Moldova, Romania, Russia, Serbia, Turkey, Ukraine; note— North Macedonia is
in the process of joining
observers—(17) Austria, Belarus, Black Sea Commission, EU, Croatia, Czechia,
Egypt, Energy Charter Secretariat, France, Germany, International Black Sea
Club, Israel, Italy, Poland, Slovakia, Tunisia, US; note—Bosnia and Herzegovina
and Slovenia have applied for observer status
BRICS
note—the name of the organization stands for the first letter of each of the five
members’ names
established—BRIC established 16 June 2009; BRICS established 24 December
2011
aim—to seek common ground in political and economic venues; to achieve
peace, security, development, and cooperation; to contribute significantly to the
development of humanity and to establish a more equitable world
members—(5) Brazil, Russia, India, China, South Africa
Caribbean Community and Common Market (Caricom)
established—A4 July 1973; effective—1 August 1973
aim—to promote economic integration and development, especially among the
less developed countries
members—(15) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members—(5) Anguilla, Bermuda, British Virgin Islands, Cayman
Islands, Turks and Caicos Islands
observers—(8) Aruba, Colombia, Curacao, Dominican Republic, Mexico, Puerto
Rico, Sint Maarten, Venezuela
Caribbean Development Bank (CDB)
established—18 October 1969; effective—26 January 1970
aim—to promote economic development and cooperation
regional members—(19) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia, Dominica,
Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago,
Barrows,
Scale 1:360,000
RUSSIA 5 Kilometers
5 Miles
Ament','b0dfa4d81774f26f9b639cbd44601f51fd133615d226ebe7242e65a56ead21a4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87eb52d082ed378b5c3edc4b841e6a92d26e1903783f38ed9837e3d03563e3ac',2021,'PK','Pakistan','communications',51,'Telephones—fixed lines: total subscriptions: 127,794
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 135
Telephones—mobile cellular: total subscriptions: 21,976,355
subscriptions per 100 inhabitants: 63 (2018 est.)
country comparison to the world: 53
Telephone system: general assessment: progress has been
made on Afghanistan’s first limited fixed-line telephone
service and nationwide optical fiber backbone; aided by the
presence of multiple providers, mobile-cellular telephone
service continues to improve swiftly; the Afghan Ministry of
Communications and Information claims that more than
90% of the population live in areas with access to mobile-
cellular services (2018) domestic: less than 1 per 100 for
fixed-line teledensity; 63 per 100 for mobile-cellular; an
increasing number of Afghans utilize mobile-cellular phone
networks (2018) international: country code—93; multiple
VSAT’s provide international and domestic voice and data
connectivity (2019) Broadcast media: state-owned
broadcaster, Radio Television Afghanistan (RTA), operates a
series of radio and television stations in Kabul and the
provinces; an estimated 174 private radio stations, 83 TV
stations, and about a dozen international broadcasters are
available (2019) Internet country code: .af
Internet users: total: 3,531,770
percent of population: 10.6 (July 2016 est.)
Broadband—fixed subscriptions: total: 15,999
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 160
Telephones—fixed lines: total subscriptions: 2,798,606
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 49
Telephones—mobile cellular:
total subscriptions: 153,986,607
subscriptions per 100 inhabitants: 69 (2018 est.)
country comparison to the world: 10
Telephone system: general assessment: the
telecommunications infrastructure is improving, with
investments in mobile-cellular networks increasing, but
fixed-line subscriptions declining; system consists. of
microwave radio relay, coaxial cable, fiber-optic cable,
cellular, and satellite networks; 4G mobile services broadly
available; 5G not before 2030; mobile platform and mobile
broadband doing well (2018) domestic: mobile-cellular
subscribership has skyrocketed; more than 90% of
Pakistanis live within areas that have cell phone coverage;
fiber-optic networks are being constructed throughout the
country to increase broadband access, though broadband
penetration in Pakistan is still relatively low; fixed-line 1
per 100 and mobile-cellular 71 per 100 persons (2018)
international: country code—92; landing points for the SEA-
ME-WE-3, -4, -5, AAE-1, IMEWE, Orient Express, PEACE
Cable, and TW1 submarine cable systems that provide links
to Europe, Africa, the Middle East, Asia, Southeast Asia,
and Australia; satellite earth stations—3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean); 3 operational international
gateway exchanges (1 at Karachi and 2 at Islamabad);
microwave radio relay to neighboring countries (2019)
Broadcast media: media is government regulated; 1 dominant
state-owned TV broadcaster, Pakistan Television
Corporation (PTV), operates a network consisting of 8
channels; private TV broadcasters are permitted; to date 69
foreign satellite channels are operational; the state-owned
radio network operates more than 30 stations; nearly 200
commercially licensed, privately owned radio stations
provide programming mostly limited to music and talk
shows (2019) Internet country code: .pk
Internet users: total: 31,338,715
percent of population: 15.5% (July 2016 est.)
country comparison to the world: 23
Broadband—fixed subscriptions: total: 1,811,365
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 57
Telephones—fixed lines: total subscriptions: 7,204
subscriptions per 100 inhabitants: 34 (July 2016 est.)
country comparison to the world: 200
Telephones—mobile cellular:
total subscriptions: 24,000
subscriptions per 100 inhabitants: 112 (July 2016 est.)
country comparison to the world: 210
Telephone system: general assessment: well-developed mobile
sector recently boosted by satellite network capacity
upgrades; 3G services available with satellite; lack of
telecom regulations; (2018) domestic: fixed-line 34 per 100
and mobile-cellular services 112 per 100 persons (2018)
international: country code—680; landing point for the
SEA-US submarine cable linking Palau, Philippines,
Micronesia, Indonesia, Hawaii (US), Guam (US) and
California (US); satellite earth station—1 Intelsat (Pacific
Ocean) (2019) Broadcast media: no broadcast TV stations; a
cable TV network covers the major islands and provides
access to 4 local cable stations, rebroadcasts (on a delayed
basis) of a number of US stations, as well as access to a
number of real-time satellite TV channels; about a half
dozen radio stations (1 government-owned) (2019) Internet
country code: .DW
Internet users: total: 7,650
percent of population: 36% (July 2016 est.)
country comparison to the world: 211','571a35d5baed1dd1894c0acf29965bedf91283d728e63bdfdd678ae4788f633a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c4b70597c38c65e8e27b29bf9cf89c172fff05b8e100ce8052cd99dd63c7195',2021,'CY','Cyprus','communications',59,'Broadcast media: British Forces Broadcast Service (BFBS)
provides multi-channel satellite TV service as well as BFBS
radio broadcasts to the Akrotiri Sovereign Base Area
Telephones—fixed lines: total subscriptions: 311,559
subscriptions per 100 inhabitants: 25 (2018 est.)
country comparison to the world: 112
Telephones—mobile cellular:
total subscriptions: 1,200,378
subscriptions per 100 inhabitants: 97 (2018 est.)
country comparison to the world: 158
Telephone system: general assessment: despite the growth of
Cyprus’s telecom sector, the market overall continues to be
dominated by the incumbent, Cyprus Telecommunications
Authority (CyTA), which is still fully-owned by the state, but
it is losing ground to its competition annually; improved
regulatory circumstances, especially in relation to network
interconnection and access, has given competing operators
the certainty to invest in network infrastructure, to launch
competing services (2018) domestic: fixed-line is 25 per
100, and 97 per 100 for mobile-cellular; open-wire, fiber-
optic cable, and microwave’ radio relay (2018)
international: country code—357 (area administered by
Turkish Cypriots uses the country code of Turkey—90); a
number of submarine cables, including the SEA-ME-WE-3,
CADMOS, MedNautilus Submarine System, POSEIDON, TE
North/TGN-Eurasia/SEACOM/Alexandros/Medes, UGARIT,
Aphrodite2, Hawk, Lev Submarine System, and Tamares
combine to provide connectivity to Europe, the Middle
East, Africa, Asia, Australia, and Southeast Asia; Turcyos-1
and Turcyos-2 submarine cable in Turkish North Cyprus
link to Turkey; tropospheric scatter; satellite earth stations
—8 (3 Intelsat—1 Atlantic Ocean and 2 Indian Ocean, 2
Eutelsat, 2 Intersputnik, and 1 Arabsat) (2019) Broadcast
media: mixture of state and privately run TV and radio
services; the public broadcaster operates 2 TV channels
and 4 radio stations; 6 private TV broadcasters, satellite
and cable TV services including telecasts from Greece and
Turkey, and a number of private radio stations are
available; in areas administered by Turkish Cypriots, there
are 2 public TV stations, 4 public radio stations, and 7
privately owned TV and 21 radio broadcast stations plus 6
radio and 4 TV channels of local universities, plus 1 radio
station of military, security forces and 1 radio station of
civil defense cooperation, as well as relay stations from
Turkey (2019) Internet country code: .Cy
Internet users: total: 915,036
percent of population: 75.9% (July 2016 est.)
country comparison to the world: 133
Broadband—fixed subscriptions:
total: 313,462
subscriptions per 100 inhabitants: 25 (2018 est.)
country comparison to the world: 101
Broadcast media: British Forces Broadcast Service (BFBS)
provides multi-channel satellite TV service as well as BFBS
radio broadcasts to the Dhekelia Sovereign Base MILITARY
AND SECURITY
Military—note: defense is the responsibility of the UK;
includes Dhekelia Garrison and Ayios Nikolaos Station
connected by a roadway DJIBOUTI','0de0460d13e2ab41b3787444c4d7083de0d03e050487fa307ef6c7be4780f3ca','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89be621d661eee5bd29f7f8b15f9ea159b689b6aeb54b1ce6c09821cd803691e',2021,'GR','Greece','communications',70,'Telephones—fixed lines: total subscriptions: 248,631
subscriptions per 100 inhabitants: 8 (2018 est.)
country comparison to the world: 122
Telephones—mobile cellular: total subscriptions: 2,714,878
subscriptions per 100 inhabitants: 89 (2018 est.)
country comparison to the world: 145
Telephone system: general assessment: consistent with the
region; offsetting the deficit of fixed-line capacity, mobile-
cellular phone service has been available since 1996; four
companies presently providing mobile services and mobile
teledensity; Internet broadband services initiated in 2005,
and the penetration rate rose to over 65% by 2016;
Internet cafes are popular in major urban areas; 1.3 million
use mobile broadband services (3G/4G) (2019) domestic:
fixed-line 8 per 100, teledensity continues to decline due to
heavy use of mobile-cellular telephone services; mobile-
cellular telephone use is widespread and_ generally
effective, 89 per 100 for mobile-cellular (2019)
international: country code—355; submarine cables for the
Adria 1 and Italy-Albania provide connectivity to Italy,
Croatia, and Greece; a combination submarine cable and
land fiber-optic system, provides additional connectivity to
Bulgaria, Macedonia, and Turkey; international traffic
carried by fiber-optic cable and, when necessary, by
microwave radio relay from the Tirana exchange to Italy
and Greece (2019) Broadcast media: Albania has more than
65 TV stations, including several that broadcast nationally;
Albanian TV broadcasts are also available to Albanian-
speaking populations in neighboring countries; many
viewers have access to Italian and Greek TV broadcasts via
terrestrial reception; Albania’s TV stations have begun a
government-mandated conversion from analog to digital
broadcast; the government has pledged to provide analog-
to-digital converters to low-income families affected by this
decision; cable TV service is available; 2 public radio
networks and roughly 78 private radio stations; several
international broadcasters are available (2019) Internet
country code: cal
Internet users: total: 2,016,516
percent of population: 66.4% (July 2016 est.)
country comparison to the world: 111
Broadband—fixed subscriptions: total: 361,947
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 94
Telephones—fixed lines: total subscriptions: 1,120,392
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 76
Telephones—mobile cellular:
total subscriptions: 8,387,160
subscriptions per 100 inhabitants: 119 (2018 est.)
country comparison to the world: 98
Telephone system: general assessment: inherited an extensive
but antiquated telecommunications network from _ the
Soviet era; quality has improved with a modern digital
trunk line now connecting switching centers in most of the
regions; remaining areas are connected by digital
microwave radio relay; Bulgaria has a mature mobile
market with active competition (2018) domestic: fixed-line
16 per 100 persons, mobile-cellular teledensity, fostered by
multiple service providers, is over 119 telephones per 100
persons (2018) international: country code—359; Caucasus
Cable System via submarine cable provides connectivity to
Ukraine, Georgia and Russia; a combination submarine
cable and land fiber-optic system provides connectivity to
Italy, Albania, and Macedonia; satellite earth stations—3 (1
Intersputnik in the Atlantic Ocean region, 2 Intelsat in the
Atlantic and Indian Ocean regions) (2019) Broadcast media: 4
national terrestrial TV stations with 1 state-owned and 3
privately owned; a vast array of TV stations are available
from cable and satellite TV providers; state-owned national
radio broadcasts over 3 networks; large number of private
radio stations broadcasting, especially in urban areas
Internet country code: .bg
Internet users: total: 4,274,328
percent of population: 59.8% (July 2016 est.)
country comparison to the world: 85
Broadband—fixed subscriptions:
total: 1,903,946
subscriptions per 100 inhabitants: 27 (2018 est.)
country comparison to the world: 55
Telephones—fixed lines: total subscriptions: 76,760
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 146
Telephones—mobile cellular:
total subscriptions: 19,339,109
subscriptions per 100 inhabitants: 98 (2018 est.)
country comparison to the world: 61
Telephone system: general assessment: system includes
microwave radio relay, open-wire, and radiotelephone
communication stations; with slow regulatory procedures,
insufficient mobile spectrum, and poor condition of fixed-
line networks the development of fixed-line Internet
services leave Burkina Faso with some of the most
expensive telecommunications globally; mobile telephony
has experienced growth, but below the African average;
Burkina Faso joins G5 Sahel countries to stop roaming fees
in 2019; govt proposes technology-neutral licenses to boost
mobile broadband connectivity (2018) domestic: fixed-line
connections stand at less than 1 per 100 persons; mobile-
cellular usage 98 per 100, with multiple providers there is
competition and the hope for growth from a low base;
Internet penetration is 11% countrywide, but higher in
urban areas (2018) international: country code—226;
satellite earth station—1 Intelsat (Atlantic Ocean)
Broadcast media: Since the official inauguration of Terrestrial
Digital Television (TNT) in December 2017, Burkina Faso
now has 14 digital TV channels among which 2 are state-
owned; there are more than 140 radio _ stations
(commercial, religious, community) available throughout
the country including a national and regional state-owned
network; the state-owned Radio Burkina and the private
Radio Omega are among the most widespread stations and
both include broadcasts in French and local languages
(2019) Internet country code: .bf
Internet users: total: 2,723,950
percent of population: 14% (July 2016 est.)
country comparison to the world: 98
Broadband—fixed subscriptions: total: 13,818
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 162
Telephones—fixed lines: total subscriptions: 382,901
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 103
Telephones—mobile cellular:
total subscriptions: 1,969,109
subscriptions per 100 inhabitants: 93 (2018 est.)
country comparison to the world: 152
Telephone system: general assessment: being part of the EU
pre-accession process has led to a stronger teledensity with
closer regulatory framework and independent regulators;
administrative ties with the European Union have led to
progress; broadband services are widely available; more
customers moving to fiber networks; 2 mobile network
operators; end of roaming tariffs (2018) domestic: fixed-line
17 per 100 and mobile-cellular 101 per 100 subscriptions
(2018)
international: country code—389
Broadcast media: public service TV broadcaster Macedonian
Radio and Television operates 3 national terrestrial TV
channels and 2 satellite TV channels; additionally, there are
10 regional TV stations that broadcast nationally using
terrestrial transmitters, 54 TV channels with concession for
cable TV, 9 regional TV stations with concessions for cable
TV; 4 satellite TV channels broadcasting on a national level,
21 local commercial TV channels, and a large number of
cable operators that offer domestic and international
programming; the public radio broadcaster operates over 3
stations; there are 4 privately owned radio stations that
broadcast nationally; 17 regional radio stations, and 49
local commercial radio stations (2019) Internet country code:
mk
Internet users: total: 1.475 million
percent of population: 70.4% (July 2016 est.)
country comparison to the world: 121
Broadband—fixed subscriptions:
total: 427,964
subscriptions per 100 inhabitants: 20 (2018 est.)
country comparison to the world: 88','b70c7b10b14e8cebd7f549fc78edc35843857751b33c5c6c9ebacebf19ddfee7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d393a838623d04c417f076e004e20232b104572e3ecd12f25fe00530ceed2b18',2021,'DZ','Algeria','communications',76,'Telephones—fixed lines: total subscriptions: 4,200,919
subscriptions per 100 inhabitants: 10 (2018 est.)
country comparison to the world: 34
Telephones—mobile cellular: total subscriptions: 47,154,264
subscriptions per 100 inhabitants: 113 (2018 est.)
country comparison to the world: 32
Telephone system: general assessment: privatization of
Algeria’s telecommunications sector began in 2000; three
mobile-cellular licenses have been issued; regulator
permits network operators to extend LTE services to
additional provinces; a consortium led by Egypt’s Orascom
Telecom won a 15-year license to build and operate a fixed-
line network in Algeria; migration to 5G (2018) domestic: a
limited network of fixed-lines with a teledensity of less than
10 telephones per 100 persons has been offset by the rapid
increase in mobile-cellular subscribership; mobile-cellular
teledensity was roughly 113 telephones per 100 persons
(2018) international: country code—213; ALPAL-2 is a
submarine telecommunications cable system in _ the
Mediterranean Sea linking Algeria and the Spanish
Balearic island of Majorca; ORVAL is a submarine cable to
Spain; landing points for the TE £North/TGN-
Eurasia/SEACOM/SeaMeWe-4 fiber-optic submarine cable
system that provides links to Europe, the Middle East, and
Asia; MED cable connecting Algeria with France;
microwave radio relay to Italy, France, Spain, Morocco, and
Tunisia; coaxial cable to Morocco and Tunisia; new
submarine cables to link to the US and France (2019)
Broadcast media: State-run Radio-Television Algerienne
operates the broadcast media and carries programming in
Arabic, Berber dialects, and French; use of satellite dishes
is widespread, providing easy access to European and Arab
satellite stations; state-run radio operates several national
networks and roughly 40 regional radio stations Internet
country code: .dz
Internet users: total: 17,291,463
percent of population: 42.9% (July 2016 est.)
country comparison to the world: 37
Broadband—fixed subscriptions: total: 3,067,022
subscriptions per 100 inhabitants: 7 (2018 est.)
country comparison to the world: 43
Telephones—fixed lines: total subscriptions: 228,097
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 123
Telephones—mobile cellular:
total subscriptions: 21,955,565
subscriptions per 100 inhabitants: 119 (2018 est.)
country comparison to the world: 54
Telephone system: general assessment: domestic system
improving; increasing use of local radio loops to extend
network coverage to remote areas; geography a challenge
for telecommunications; poverty, security, high illiteracy
and low PC use has taken its toll; 4 mobile operators in
market; potential for mobile broadband services; local
plans for Internet Exchange Point (2018) domestic: fixed-
line subscribership remains less than 1 per 100 persons;
mobile-cellular subscribership has increased sharply to
over 113 per 100 persons (2018) international: country
code—223; satellite communications center and fiber-optic
links to neighboring countries; satellite earth stations—2
Intelsat (1 Atlantic Ocean, 1 Indian Ocean); new
competition with submarine fiber optic cables in the region
Broadcast media: National public TV broadcaster; 2 privately
owned companies provide subscription services to foreign
multi-channel TV _ packages; national public’ radio
broadcaster supplemented by a large number of privately
owned and community broadcast stations; transmissions of
multiple international broadcasters are available (2019)
Internet country code: .ml
Internet users: total: 1,940,978
percent of population: 11.1% (July 2016 est.)
country comparison to the world: 114
Broadband—fixed subscriptions:
total: 120,934
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 119','ec9abb115c5bd679b90a967119441f287bb39bdc120d0a2c868f93ecaf1cfa82','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5db86e0e018c501bbd62bcd3bdbbd3c3e1ded354f6277add42f67880cd599e0',2021,'AS','American Samoa','communications',83,'Telephones—fixed lines: total subscriptions: 10,000
subscriptions per 100 inhabitants: 18 (July 2016 est.)
country comparison to the world: 192
Telephone system: general assessment: good telex, telegraph,
facsimile, and cellular telephone services; one of the most
complete and modern telecommunications systems in the
South Pacific Islands; all inhabited islands have telephone
connectivity domestic: 18 per 100 fixed-line teledensity,
domestic satellite system with 1 Comsat earth station
international: country code—1-684; landing points for the
ASH, Southern Cross NEXT and MHawaiki providing
connectivity to New Zealand, Australia, American Samoa,
Hawaii, California, and SAS connecting American Samoa
with Samoa; satellite earth station—1 (Intelsat-Pacific
Ocean) (2019) Broadcast media: 3 TV stations; multi-channel
pay TV services are available; about a dozen radio stations,
some of which are repeater stations Internet country code: .aS
Internet users: total: 17,000
percent of population: 31.3% (July 2016 est.)
country comparison to the world: 206','ff1aec36990be1b1664fc4a9232cb55ad33ecfe7613f98a33469d1e91a188d72','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cb68bf68dbcf2354d8dde08a3e8fbe83ed6b3e19d5f17393a80817a2b47f490',2021,'AD','Andorra','communications',88,'Telephones—fixed lines: total subscriptions: 39,375
subscriptions per 100 inhabitants: 46 (2018 est.)
country comparison to the world: 163
Telephones—mobile cellular: total subscriptions: 82,614
subscriptions per 100 inhabitants: 96 (2018 est.)
country comparison to the world: 196
Telephone system: general assessment: modern automatic
telephone system; broadband Internet and LTE mobile lines
for both consumer and enterprise customers available
(2019) domestic: 46 per 100 fixed-line, 96 per 100 mobile-
cellular (2019)
international: country code—376; landline circuits to
France and Spain; modern system with microwave radio
relay connections between exchanges (2019) Broadcast
media: 1 public TV station and 2 public radio stations; about
10 commercial radio stations; good reception of radio and
TV broadcasts from stations in France and Spain; upgraded
to terrestrial digital TV broadcasting in 2007; roughly 25
international TV channels available (2019) Internet country
code: .ad
Internet users: total: 83,887
percent of population: 97.9% (July 2016 est.)
country comparison to the world: 178
Broadband—fixed subscriptions: total: 35,663
subscriptions per 100 inhabitants: 42 (2018 est.)
country comparison to the world: 139','0b886c5587738f1112f45991bcbe4cb3d228d3a59c4d55c6986a7b089094f50f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad9012cea51d24b27dc4d92e20785ab4f419d3e0d051881bd78e56a063f7dde1',2021,'NA','Namibia','communications',99,'Telephones—fixed lines: total subscriptions: 171,858
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 126
Telephones—mobile cellular: total subscriptions: 13,288,421
subscriptions per 100 inhabitants: 44 (2018 est.)
country comparison to the world: 70
Telephone system: general assessment: in the process of a
restructure plan and opening up the telecom sector to new
competitors, while still retaining a 45% govt portion of the
share; slow progress in LITE network development, with
only about 10% of the country covered by network
infrastructure at the end of 2017 (2018) domestic: only
about one fixed-line per 100 persons; mobile-cellular
teledensity about 44 telephones per 100 persons (2018)
international: country code—244; landing points for the
SAT-3/WASC, WACS, ACE and SACS fiber-optic submarine
cable that provides connectivity to other countries in west
Africa, Brazil, Europe and Asia; satellite earth stations—29
(2019) Broadcast media: state controls all broadcast media
with nationwide reach; state-owned Televisao Popular de
Angola (TPA) provides terrestrial TV service on 2 channels;
a third TPA channel is available via cable and satellite; TV
subscription services are available; state-owned Radio
Nacional de Angola (RNA) broadcasts on 5 stations; about a
half-dozen private radio stations broadcast locally Internet
country code: .aO
Internet users: total: 2,622,403
percent of population: 13% (July 2016 est.)
country comparison to the world: 103
Broadband—fixed subscriptions: total: 109,561
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 120
Telephones—fixed lines: total subscriptions: 6,000
subscriptions per 100 inhabitants: 37 (July 2016 est.)
country comparison to the world: 203
Telephones—mobile cellular: total subscriptions: 26,000
subscriptions per 100 inhabitants: 158 (July 2016 est.)
country comparison to the world: 209
Telephone system: general assessment: modern internal
telephone system with fiber-optic trunk lines; telecom
sector provides a realatively high contribution to overall
GDP; numerous competitors licensed, but small and
localized domestic: fixed-line teledensity is about 37 per
100 persons; mobile-cellular teledensity is roughly 158 per
100 persons international: country code—1-264; landing
points for the SSCS, ECFS, GCN and Southern Caribbean
Fiber with submarine cable links to Caribbean islands and
to the US; microwave radio relay to island of Saint
Martin/Sint Maarten (2019) Broadcast media: 1 private TV
station; multi-channel cable TV subscription services are
available; about 10 radio stations, one of which is
government-owned Internet country code: .al
Internet users: total: 13,665
percent of population: 81.6% (July 2016 est.)
country comparison to the world: 210
Telephone system: general assessment: local systems at some
research stations (2019) domestic: commercial cellular
networks operating in a small number of locations (2019)
international: country code—none allocated; via satellite
(including mobile Inmarsat and Iridium systems) to and
from all research stations, ships, aircraft, and most field
parties Internet country code: .aq
Internet users: total: 4,400
percent of population: 100% (July 2016 est.)
country comparison to the world: 216
Telephones—fixed lines: total subscriptions: 22,504
subscriptions per 100 inhabitants: 24 (July 2016 est.)
country comparison to the world: 172
Telephones—mobile cellular: total subscriptions: 180,000
subscriptions per 100 inhabitants: 190 (2017 est.)
country comparison to the world: 186
Telephone system: general assessment: good automatic
telephone system with fiber-optic lines; telecom sector
contributes heavily to GDP; numerous mobile network
competitors licensed, but small and local (2018) domestic:
fixed-line teledensity roughly 24 per 100 persons; mobile-
cellular teledensity is about 190 per 100 persons (2018)
international: country code—1-268; landing points for the
ECFS and Southern Caribbean Fiber submarine cable
systems with links to other islands in the eastern
Caribbean; satellite earth stations—1 Intelsat (Atlantic
Ocean) (2019) Broadcast media: state-controlled Antigua and
Barbuda Broadcasting Service (ABS) operates 1 TV station;
multi-channel cable TV subscription services are available;
ABS operates 1 radio station; roughly 15 radio stations,
some broadcasting on multiple frequencies Internet country
code: .ag
Internet users: total: 60,000
percent of population: 65.2% (July 2016 est.)
country comparison to the world: 186
Broadband—fixed subscriptions: total: 9,261
subscriptions per 100 inhabitants: 10 (2017 est.)
country comparison to the world: 172','4c8a5b4b13d5fecc1f083da557ef25203b4bc1e3b7d654cbe510b2de1b5b0239','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8118d72e7a232858058ae8b614a5a646f5cddf8850dca640f0e28310c3f43e87',2021,'AQ','Antarctica','communications',112,'Telephones—fixed lines: total subscriptions: 9,764,014
subscriptions per 100 inhabitants: 22 (2018 est.)
country comparison to the world: 18
Telephones—mobile cellular: total subscriptions: 58,598,041
subscriptions per 100 inhabitants: 131 (2018 est.)
country comparison to the world: 27
Telephone system: general assessment: Argentina opened its
telecommunications market to competition and foreign
investment encouraging the growth of modern
telecommunications technology in 1998; major networks
are entirely digital and the availability of telephone service
continues to improve to rural areas; even with numerous
providers there is a lack of competition; still Argentina is
the 3rd largest in the region after Brazil and Mexico (2018)
domestic: 22 per 100 fixed-line, 131 per 100 mobile-
cellular; microwave radio relay, fiber-optic cable, and a
domestic satellite system with 40 earth stations serve the
trunk network (2018) international: country code—54;
landing points for the UNISUR, Bicentenario, Atlantis-2,
SAm-1, and SAC, Tannat, Malbec and ARBR submarine
cable systems that provide links to Europe, Africa, South
and Central America, and US; satellite earth stations—112
(2019) Broadcast media: government owns a TV station and
radio network; more than 2 dozen TV stations and
hundreds of privately owned radio stations; high rate of
cable TV subscription usage Internet country code: .ar
Internet users: total: 30,786,889
percent of population: 70.2% (July 2016 est.)
country comparison to the world: 24
Broadband—fixed subscriptions: total: 8,473,655
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 21
Telephones—fixed lines: total subscriptions: 2,997,192
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 47
Telephones—mobile cellular:
total subscriptions: 25,178,981
subscriptions per 100 inhabitants: 140 (2018 est.)
country comparison to the world: 49
Telephone system: general assessment: most advanced
telecommunications infrastructure in South America;
modern system based on extensive microwave radio relay
facilities; although Chile has one of the highest mobile
penetration rates in the region, the number of subscribers
has fallen due to subscribers ending multiple SIM card use;
this downward trend is expected to be halted as the
availability of LTE networks and services broaden; in terms
of available broadband speeds in the country rank second
highest in South and Central America (2018) domestic:
number of fixed-line connections have stagnated to 17 per
100 in recent years as mobile-cellular usage continues to
increase, reaching 140 telephones per 100 _ persons;
domestic satellite system with 3 earth stations (2018)
international: country code—56; landing points for the Pan-
Am, Prat, SAm-1, American Movil-Telxius West Coast Cable,
FOS Quellon-Chacabuco, Fibra Optical Austral, SAC and
Curie submarine cables providing links to the US,
Caribbean and to Central and South America; satellite
earth stations—2 Intelsat (Atlantic Ocean) (2019) Broadcast
media: national and local terrestrial TV channels, coupled
with extensive cable TV networks; the _ state-owned
Television Nacional de Chile (TVN) network is self-financed
through commercial advertising revenues and is not under
direct government control; large number of privately
owned TV stations; about 250 radio stations Internet country
code: .cl
Internet users: total: 11,650,840
percent of population: 66% (July 2016 est.)
country comparison to the world: 46
Broadband—fixed subscriptions:
total: 3,250,678
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 39
cura
POLITICAL MAP OF THE WORLD
Political Map of the World, January 2015','7a762f2dd31cf561f5b6f5d921b50ae53f37274d763e1456ddd1946d8d504554','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e7d45e03089da710f77d9c621f616a1fe387a35301bb895a4f339dcd57b5cad',2021,'AM','Armenia','communications',120,'Telephones—fixed lines: total subscriptions: 477,932
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 96
Telephones—mobile cellular: total subscriptions: 3,579,257
subscriptions per 100 inhabitants: 118 (2018 est.)
country comparison to the world: 135
Telephone system: general assessment: telecommunications
investments have made major inroads in modernizing and
upgrading the outdated telecommunications network
inherited from the Soviet era; now 100% privately owned
and undergoing continued modernization and expansion
(2019) domestic: 16 per 100 fixed-line, 118 per 100 mobile-
cellular; reliable fixed-line and mobile-cellular services are
available across Yerevan and in major cities and towns;
mobile-cellular coverage available in most rural areas
(2019) international: country code—374; Yerevan is
connected to the Caucasus Cable System fiber-optic cable
through Georgia and Iran to Europe; additional
international service is available by microwave radio relay
and landline connections to the other countries of the
Commonwealth of Independent States, through the
Moscow international switch, and by satellite to the rest of
the world; satellite earth stations—3 (2019) Broadcast media:
Armenia’s government-run Public Television network
operates alongside 100 privately owned TV stations that
provide local to near nationwide coverage; three Russian
TV companies are broadcast in Armenia under interstate
agreements; subscription cable TV services are available in
most regions; several major international broadcasters are
available, including CNN; Armenian TV _ completed
conversion from analog to digital broadcasting in late 2016;
Public Radio of Armenia is a national, state-run broadcast
network that operates alongside 18 privately owned radio
stations (2019)
Internet country code: .am
Internet users: total: 1,891,775
percent of population: 62% (July 2016 est.)
country comparison to the world: 115
Broadband—fixed subscriptions: total: 347,448
subscriptions per 100 inhabitants: 11 (2018 est.)
country comparison to the world: 97
Telephones—fixed lines: total subscriptions: 35,000
subscriptions per 100 inhabitants: 31 (July 2016 est.)
country comparison to the world: 168
Telephones—mobile cellular: total subscriptions: 141,000
subscriptions per 100 inhabitants: 126 (July 2016 est.)
country comparison to the world: 189
Telephone system: general assessment: modern fully
automatic telecommunications system; increased
competition through privatization has increased mobile-
cellular teledensity; three mobile-cellular service providers
are now licensed; MNO (mobile network operator)
launched island-wide LTE services; MNP (mobile number
portability) introduced (2018) domestic: ongoing changes
in regulations and competition improving teledensity; 31
per 100 fixed-line, 126 per 100 mobile-cellular (2018)
international: country code—297; landing points for the
PAN-AM, PCCS, Deep Blue Cable, and Alonso de Ojeda
submarine telecommunications cable system that extends
from Trinidad and Tobago, Florida, Puerto Ricco, Jamaica,
Guyana, Sint Eustatius & Saba, Suriname, Dominican
Republic, BVI, USVI, Haiti, Cayman Islands, the
Netherlands Antilles, through Aruba to Panama, Venezuela,
Colombia, Ecuador, Peru and Chile; extensive interisland
microwave radio relay links (2019) Broadcast media: 2
commercial TV stations; cable TV subscription service
provides access to foreign channels; about 19 commercial
radio stations broadcast (2017) Internet country code: .aw
Internet users: total: 106,309
percent of population: 93.5% (July 2016 est.)
country comparison to the world: 176','966b313d88ca853f997358b16e75dcb6e47a1f8a4cbb00d844a6b3dd154f31cd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8836faebcd1a896678258d8f6ae00401dfe9042ca1e70703ff2099296cf8ece',2021,'NF','Norfolk Island','communications',139,'Telephones—fixed lines: total subscriptions: 8.09 million
subscriptions per 100 inhabitants: 33 (2018 est.)
country comparison to the world: 20
Telephones—mobile cellular: total subscriptions: 28.279 million
subscriptions per 100 inhabitants: 114 (2018 est.)
country comparison to the world: 47
Telephone system: general assessment: excellent domestic
and international service; domestic satellite system;
significant use of radiotelephone in areas of low population
density; rapid growth of mobile telephones; 5G
technologies in preparation and anticipation for 2020
(2018) domestic: 33 per 100 fixed-line, 114 per 100 mobile-
cellular; more subscribers to mobile services than there are
people; 90% of all mobile device sales are now
smartphones, growth in mobile traffic brisk (2018)
international: country code—61; landing points for more
than 20 submarine cables including: the SeaMeWe-3 optical
telecommunications submarine cable with links to Asia, the
Middle East, and Europe; the INDIGO-Central, INDIGO
West and ASC, North West Cable System, Australia-Papua
New Guinea cable, CSCS, PPC-1, Gondwana-1, SCCN,
Hawaiki, TGA, Basslink, Bass Strait-1, Bass Strait-2, JGA-S,
with links to other Australian cities, New Zealand and many
countries in southeast Asia, US and Europe; the H2 Cable,
AJC, Telstra Endeavor, Southern Cross NEXT with links to
Japan, Hong Kong, and other Pacific Ocean countries as
well as the US; satellite earth stations—10 Intelsat (4
Indian Ocean and 6 Pacific Ocean), 2 Inmarsat, 2
Globalstar, 5 other (2019) Broadcast media: the Australian
Broadcasting Corporation (ABC) runs multiple national and
local radio networks and TV stations, as well as Australia
Network, a TV service that broadcasts throughout the Asia-
Pacific region and is the main public broadcaster; Special
Broadcasting Service (SBS), a second large _ public
broadcaster, operates radio and TV networks broadcasting
in multiple languages; several large national commercial
TV networks, a large number of local commercial TV
stations, and hundreds of commercial radio stations are
accessible; cable and satellite systems are available Internet
country code: .au
Internet users: total: 20,288,409
percent of population: 88.2% (July 2016 est.)
country comparison to the world: 33
Broadband—fixed subscriptions: total: 7.64 million
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 22
Telephones—fixed lines: total subscriptions: 3,772,429
subscriptions per 100 inhabitants: 43 (2018 est.)
country comparison to the world: 38
Telephones—mobile cellular: total subscriptions: 10.984 million
subscriptions per 100 inhabitants: 125 (2018 est.)
country comparison to the world: 80
Telephone system: general assessment: mobile-cellular
subscribership is everywhere; cable networks are very
extensive, the fiber-optic net is being developed; all
telephone applications and Internet services are accessible;
broadband is available in all large municipalities; and is
planned to be accessible nation-wide by 2020; the roll-out
of 5G has begun in a test phase in 2019 and is planned to
be available nation-wide in 2025 (2019) domestic:
developed and efficient; 43 per 100 fixed-line for
households, 174 per 100 for companies; 125 per 100
mobile-cellular; broadband: 138 per 100 on smartphones;
62 per 100 fixed broadband, 54 per 100 mobile broadband
(2019) international: country code—43; earth stations
available in the Astra, Intelsat, Eutelsat satellite systems
(2019) Broadcast media: worldwide cable and satellite TV are
available; the public incumbent ORF competes with three
other major, several regional domestic, and up to 400
international TV stations; TV coverage is in principle 100%,
but only 90% use broadcast media; Internet streaming not
only complements, but increasingly replaces regular TV
stations (2019) Internet country code: .at
Internet users: total: 7,346,055
percent of population: 84.3% (July 2016 est.)
country comparison to the world: 58
Broadband—fixed subscriptions: total: 2,521,100
subscriptions per 100 inhabitants: 29 (2018 est.)
country comparison to the world: 49
Communications—note: note 1: the Austrian National Library
contains important collections of the Imperial Library of
the Holy Roman Empire and of the Austrian Empire, as well
as of the Austrian Republic; among its more than 12 million
items are outstanding holdings of rare books, maps, globes,
papyrus, and music; its Globe Museum is the only one in
the world note 2: on 1 October 1869, Austria-Hungary
introduced the world’s first postal card—postal stationery
with an imprinted stamp indicating the prepayment of
postage; simple and cheap (sent for a fraction of the cost of
a regular letter), postal cards became an instant success,
widely produced in the millions worldwide note 3: Austria
followed up with the creation of the world’s first
commercial picture postcards—cards bearing a picture or
photo to which postage is affixed—in May 1871; sent from
Vienna, the image served as a souvenir of the city; together,
postal cards and post cards served as the world’s e-mails of
the late 19th and early 20th centuries note 4: Austria was
also an airmail pioneer; from March to October of 1918, it
conducted the world’s first regular (daily) airmail service—
between the imperial cities of Vienna, Krakow, and
Lemberg—a combined distance of some 650 km (400 mi)
(earlier airmail services had been set up in a few parts of
the world, but only for short stretches and none lasted
beyond a few days or weeks); an expansion of the route in
June of 1918 allowed private mail to be flown to Kyiv, in
newly independent Ukraine, which made the route the
world’s first regular international airmail service (covering
a distance of some 1,200 km; 750 mi) MILITARY AND
SECURITY
Military expenditures: 0.74% of GDP (2018)
0.73% of GDP (2017)
0.75% of GDP (2016)
0.71% of GDP (2015)
0.75% of GDP (2014)
country comparison to the world: 134
Military and security forces: Austrian Armed Forces: Land
Forces Command, Air Forces Command, plus a Logistics
Command and Service Support & Cyber Defence Command
(2019) Military service age and _ obligation: registration
requirement at age 17, the legal minimum age _ for
voluntary military service; 18 is the legal minimum age for
compulsory military service (6 months), or optionally,
alternative civil/community service (9 months); males 18 to
50 years old in the militia or inactive reserve are subject to
compulsory service; in a January 2012 referendum, a
majority of Austrians voted in favor of retaining the system
of compulsory military service (with the option of
alternative/non-military service) instead of switching to a
professional army system (2015) TRANSPORTATION
National air transport system: number of registered air Carriers:
11 (2015) inventory of registered aircraft operated by air
carriers: 130 (2015)
annual passenger traffic on registered air Carriers:
14,718,641 (2015)
annual freight traffic on registered air carriers: 351.379
million mt-km (2015)
Civil aircraft registration country code prefix: OE (2016)
Airports: 52 (2013)
country comparison to the world: 89
Airports—with paved runways: total: 24 (2017)
over 3,047 m: 1 (2017)
2,438 to 3,047 m: 5 (2017)
1,524 to 2,437 m: 1 (2017)
914 to 1,523 m: 4 (2017)
under 914 m: 13 (2017)
Airports—with unpaved runways: total: 28 (2013)
1,524 to 2,437 m: 1 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 24 (2013)
Heliports: 1 (2013)
Pipelines: 1888 km gas, 594 km oil, 157 km refined products
(2017)
Railways: total: 5,800 km (2017)
standard gauge: 5,300 km 1.435-m gauge (3,826 km
electrified) (2016)
country comparison to the world: 33
Roadways: total: 137,039 km (2018)
paved: 137,039 km (includes 2,232 km of expressways)
(2018)
country comparison to the world: 39
Waterways: 358 km (2011)
country comparison to the world: 89
Ports and terminals: river port(s): Enns, Krems, Linz,
Vienna (Danube)
Telephones—fixed lines: total subscriptions: 1,681,407
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 62
Telephones—mobile cellular: total subscriptions: 10,339,700
subscriptions per 100 inhabitants: 103 (2018 est.)
country comparison to the world: 84
Telephone system: general assessment: more competition
exists in the mobile-cellular market; Azerbaijan has
moderate mobile, mobile broadband and fixed broadband
penetration compared to other Asian nations; Pre-5G
network operating on the TD-LITE standard (2018)
domestic: teledensity of some 17 fixed-lines per 100
persons; mobile-cellular teledensity has increased to 103
telephones per 100 persons; satellite service connects Baku
to a modern switch in its exclave of Naxcivan (Nakhchivan)
(2018) international: country code—994; the TAE fiber-
optic link transits Azerbaijan providing international
connectivity to neighboring countries; the old Soviet
system of cable and microwave is still serviceable; satellite
earth stations—2 (2019) Broadcast media: 3 state-run and 1
public TV channels; 4 domestic commercial TV stations and
about 15 regional TV stations; cable TV services are
available in Baku; 1 state-run and 1 public radio network
operating; a small number of private commercial radio
stations broadcasting; local FM relays of Baku commercial
stations are available in many localities; note—all broadcast
media is pro-government, and most private broadcast
media outlets are owned by entities directly linked to the
government Internet country code: .aZ
Internet users: total: 7,720,502
percent of population: 78.2% (July 2016 est.)
country comparison to the world: 55
Broadband—fixed subscriptions: total: 1,890,913
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 56
Telephones—fixed lines: total subscriptions: 113,455
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 139
Telephones—mobile cellular:
total subscriptions: 381,591
subscriptions per 100 inhabitants: 115 (2018 est.)
country comparison to the world: 177
Telephone system: general assessment: modern facilities; the
telecom sector provides a relatively high contribution to
overall GDP; activation of Mobile Number Portability
(MNP) in April 2017, allowing mobile subscribers to port
their numbers between competing MNO (mobile network
operators) (2018) domestic: totally automatic system;
highly developed; operators focus investment on mobile
networks; 34 per 100 fixed- line, 115 per 100 mobile-
cellular (2018) international: country code—1-242; landing
points for the ARCOS-1, BICS, Bahamas 2-US, and BDSN
fiber-optic submarine cables that provide links to South and
Central America, parts of the Caribbean, and the US;
satellite earth stations—2; the Bahamas Domestic
Submarine Network links all of the major islands; (2019)
Broadcast media: _ The Bahamas has 4 major TV providers that
provide service to all major islands in the archipelago; 1 TV
station is operated by government-owned, commercially
run Broadcasting Corporation of the Bahamas (BCB) and
competes freely with 4 privately owned TV stations; multi-
channel cable TV subscription service is widely available;
there are 32 licensed broadcast (radio) service providers,
31 are privately owned FM radio stations operating on New
Providence, Grand Bahama Island, Abaco Island, and on
smaller islands in the country; the BCB operates a multi-
channel radio broadcasting network that has national
coverage; the sector is regulated by the Utilities Regulation
and Competition Authority (2019) Internet country code: .bs
Internet users: total: 261,853
percent of population: 80% (July 2016 est.)
country comparison to the world: 164
Broadband—fixed subscriptions:
total: 87,067
subscriptions per 100 inhabitants: 26 (2018 est.)
country comparison to the world: 125','038a682299022f123d5fc480c28fcc962703349f243d3682bc3df25f0bec1a17','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e28935650a78f3dbe69811e2c1b5b792d1d414e336206ab043d84f60df2bb4a9',2021,'BH','Bahrain','communications',146,'Telephones—fixed lines: total subscriptions: 274,733
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 117
Telephones—mobile cellular:
total subscriptions: 2,092,714
subscriptions per 100 inhabitants: 145 (2018 est.)
country comparison to the world: 149
Telephone system: general assessment: modern system; well-
developed LTE networks, 5G trials tested and deployment
in near future; mobile penetration is high compared to the
region; development of its own National Broadband
Network (NBN); competition is good and telecoms are
regulated (2018) domestic: 19 per 100 fixed-line, 145 per
100 mobile-cellular; modern fiber-optic integrated services;
digital network with rapidly growing use of mobile-cellular
telephones (2018) international: country code—973;
landing points for the FALCON, Tata TGN-Gulf,
GBICS/MENA, and FOG submarine cable network that
provides links to Asia, the Middle East, and Africa;
tropospheric scatter to Qatar and UAE; microwave radio
relay to Saudi Arabia; satellite earth station—1 (2019)
Broadcast media: State-run Bahrain Radio and Television
Corporation (BRTC) operates 5 terrestrial TV networks and
several radio stations; satellite TV systems provide access
to international broadcasts; 1 private FM station directs
broadcasts to Indian listeners; radio and TV broadcasts
from countries in the region are available (2019) Internet
country code: .bh
Internet users: total: 1,351,326
percent of population: 98% (July 2016 est.)
country comparison to the world: 124
Broadband—fixed subscriptions:
total: 184,603
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 111','568543a43393d6a538fcb7819eb07a31fa9831af5f1e713d4da60bf42d660422','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8034b0b91a3324206db07926519f07d409e4b70ddeeb3c5510f39172a27d643d',2021,'IN','India','communications',153,'Telephones—fixed lines: total subscriptions: 1,449,646
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 66
Telephones—mobile cellular:
total subscriptions: 161,771,617
subscriptions per 100 inhabitants: 101 (2018 est.)
country comparison to the world: 9
Telephone system: general assessment: inadequate for a
modern country; introducing digital systems; trunk systems
include VHF and UHF microwave radio relay links, and
some fiber-optic cable in _ cities; fixed broadband
penetration in Bangladesh remains very low mainly due to
the dominance of the mobile platform (2018) domestic:
fixed-line teledensity remains less than 1 per 100 persons;
mobile-cellular telephone subscribership has _ been
increasing rapidly and now exceeds 101 telephones per 100
persons; mobile subscriber growth is anticipated over the
next five years to 2023; strong local competition (2018)
international: country code—880; landing points for the
SeaMeWe-4 and SeaMeWe-5 fiber-optic submarine cable
system that provides links to Europe, the Middle East, and
Asia; satellite earth stations—6; international
radiotelephone communications and landline service to
neighboring countries (2019) Broadcast media: state-owned
Bangladesh Television (BTV) broadcasts throughout the
country. Some channels, such as BIV World, operate via
satellite. The government also owns a medium wave radio
channel and some private FM radio broadcast news
channels. Of the 41 Bangladesh approved TV stations, 26
are currently being used to broadcast. Of those, 23 operate
under private management via cable distribution.
Collectively, TV channels can reach more than 50 million
people across the country.
Internet country code: .bd
Internet users: total: 28,499,324
percent of population: 18.2% (July 2016 est.)
country comparison to the world: 26
Broadband—fixed subscriptions:
total: 10,237,003
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 17','9e6033fd78fa4bb97d626e4534d0b21b81824bbdafbddfe7209e5677611fcc63','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9596026bc9b34ab47b7d33f008258a7c64d5bdbbc99d14e69ee261dccced1fb5',2021,'BB','Barbados','communications',164,'Telephones—fixed lines: total subscriptions: 128,043
subscriptions per 100 inhabitants: 44 (2018 est.)
country comparison to the world: 134
Telephones—mobile cellular:
total subscriptions: 329,326
subscriptions per 100 inhabitants: 112 (2018 est.)
country comparison to the world: 178
Telephone system: general assessment: island-wide automatic
telephone system; telecom sector across the Caribbean
region remains one of the key growth areas; numerous
competitors licensed, but small and localized (2018)
domestic: fixed-line teledensity of roughly 44 per 100
persons; mobile-cellular telephone density about 112 per
100 persons (2018) international: country code -1-246;
landing points for the ECFS and Southern Caribbean Fiber
submarine cable with links to 15 other islands in the
eastern Caribbean extending from the British Virgin Islands
to Trinidad and Puerto Ricco; satellite earth stations -1
(Intelsat—Atlantic Ocean); tropospheric scatter to Trinidad
and Saint Lucia (2019) Broadcast media: government-owned
Caribbean Broadcasting Corporation (CBC) operates the
lone terrestrial TV station; CBC also operates a multi-
channel cable TV subscription service; roughly a dozen
radio stations, consisting of a CBC-operated network
operating alongside privately owned radio stations Internet
country code: .bb
Internet users: total: 231,883
percent of population: 79.5% (July 2016 est.)
country comparison to the world: 167
Broadband—fixed subscriptions:
total: 89,340
subscriptions per 100 inhabitants: 30 (2018 est.)
country comparison to the world: 124
Telephones—fixed lines: total subscriptions: 4,488,821
subscriptions per 100 inhabitants: 47 (2018 est.)
country comparison to the world: 32
Telephones—mobile cellular:
total subscriptions: 11,619,651
subscriptions per 100 inhabitants: 122 (2018 est.)
country comparison to the world: 77
Telephone system: general assessment: fiber network reaches
two million establishments; trial 5G services during the
first half of 2019; 10,000km of fiber cabling laid; August
2018 almost two million GPON connections (Gigabit
Passive Optical Network, point-to-multi point access
mechanism); 5 year plan is on track; Belarus launched its
first telecoms satellite in 2016; LTE use reaches 75% of
mobile subscribers (2018) domestic: fixed-line teledensity
is improving although rural areas continue to be
underserved, 47 per 100 _ fixed-line; mobile-cellular
teledensity now approaches 122 telephones per 100
persons (2018) international: country code—375; Belarus is
landlocked and therefore a member of the Trans-European
Line (TEL), Trans-Asia-Europe (TAE) fiber-optic line, and
has access to the Trans-Siberia Line (TSL); 3 fiber-optic
segments provide connectivity to Latvia, Poland, Russia,
and Ukraine; worldwide service is available to Belarus
through this infrastructure; additional analog lines to
Russia; Intelsat, Eutelsat, and Intersputnik earth stations
Broadcast media: 7 state-controlled national TV channels;
Polish and Russian TV broadcasts are available in some
areas; state-run Belarusian Radio operates 5 national
networks and an external service; Russian and Polish radio
broadcasts are available (2019) Internet country code: .by
Internet users: total: 6,805,786
percent of population: 71.1% (July 2016 est.)
country comparison to the world: 62
Broadband—fixed subscriptions:
total: 3,201,519
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 41','021984ba861421bbeaccb38e3a7ba208fc5bedc87b60a5b671c930517c7c7ab4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d60b3e695ed80f01e5bc2e72a8541acaaa4dd87c5fddf7fdf011e88eee85b4e9',2021,'FR','France','communications',176,'Telephones—fixed lines: total subscriptions: 4,105,557
subscriptions per 100 inhabitants: 35 (2018 est.)
country comparison to the world: 37
Telephones—mobile cellular:
total subscriptions: 11,447,351
subscriptions per 100 inhabitants: 99 (2018 est.)
country comparison to the world: 78
Telephone system: general assessment: highly developed,
technologically advanced, and completely automated
domestic and international telephone and_ telegraph
facilities; LTE availability is nearly universal in mobile
sector; ongoing investments in developing applications and
services for 5G; consumer are interested in quad-play
services (broadband +television +telephone +wireless
services) which will mean MNOs (mobile network
operators) are enhancing their fixed-line offerings (2018)
domestic: 35 per 100 fixed-line, 99 per 100 mobile-cellular;
nationwide mobile-cellular telephone system; extensive
cable network; limited microwave radio relay network
(2018) international: country code—32; landing points for
Concerto, UK-Belgium, Tangerine, and SeaMeWe-3,
submarine cables that provide links to Europe, the Middle
East, Australia and Asia; satellite earth stations—7 (Intelsat
—3) (2019) Broadcast media: a segmented market with the
three major communities (Flemish, French, and German-
speaking) each having responsibility for their own
broadcast media; multiple TV channels exist for each
community; additionally, in excess of 90% of households are
connected to cable and can access broadcasts of TV
stations from neighboring countries; each community has a
public radio network coexisting with private broadcasters
Internet country code: .be
Internet users: total: 9,870,734
percent of population: 86.5% (July 2016 est.)
country comparison to the world: 48
Broadband—fixed subscriptions:
total: 4,502,950
subscriptions per 100 inhabitants: 39 (2018 est.)
country comparison to the world: 31
Telephones—fixed lines: total subscriptions: 38.62 million
subscriptions per 100 inhabitants: 57 (2018 est.)
country comparison to the world: 5
Telephones—mobile cellular:
total subscriptions: 70.422 million
subscriptions per 100 inhabitants: 105 (2018 est.)
country comparison to the world: 22
Telephone system: general assessment: extensive cable and
microwave radio relay; extensive use of fiber-optic cable;
domestic satellite system; highly developed; 3rd largest in
Europe; broadband subscriber rate remains strong at 4%
(2018) domestic: 57 per 100 persons for fixed-line and 105
per 100 for mobile-cellular subscriptions (2018)
international: country code—33; landing points for Circe
South, TAT-14, INGRID, FLAG Atlantic-1, Apollo, HUGO,
IFC-1, ACE, SeaMeWe-3 & 4, Dunant, Africa-1, AAE-1, Atlas
Offshore, Hawk, IMEWE, Med Cable, PEACE Cable, and TE
North/TGN-Eurasia/SEACOM/Alexandros/Medex submarine
cables providing links throughout Europe, Asia, Australia,
the Middle East, Southeast Asia, Africa and US; satellite
earth stations—more than 3 (2 Intelsat (with total of 5
antennas—2 for Indian Ocean and 3 for Atlantic Ocean), NA
Eutelsat, 1 Inmarsat—Atlantic Ocean region); HF
radiotelephone communications with more than 20
countries (2019) overseas departments: Country codes: French
Guiana—594; landing points for Ella Link, Kanawa,
Americas II to South America, Europe, Caribbean and US;
Guadeloupe—590; landing points for GCN, Southern
Caribbean Fiber, and ECFS around the Caribbean and US;
Martinique—596; landing points for Ameicas II, ECFS, and
Southern Caribbean Fiber to South America, US and
around the Caribbean; Mayotte—262; landing points for
FLY-LION3 and LION2 to East Africa and East African
Islands in Indian Ocean; Reunion—262; landing points for
SAFE, METISS, and LION submarine cables to Asia, South
and East Africa, Southeast Asia and nearby Indian Ocean
Island countries of Mauritius, and Madagascar (2019)
Broadcast media: a mix of both publicly operated and
privately owned TV stations; state-owned France television
stations operate 4 networks, one of which is a network of
regional stations, and has part-interest in several thematic
cable/satellite channels and international channels; a large
number of privately owned regional and local TV stations;
multi-channel satellite and cable services provide a large
number of channels; public broadcaster Radio France
operates 7 national networks, a series of regional networks,
and operates services for overseas territories and foreign
audiences; Radio France Internationale, under the Ministry
of Foreign Affairs, is a leading international broadcaster; a
large number of commercial FM stations, with many of
them consolidating into commercial networks Internet country
code: metropolitan France—.fr; French Guiana—.gf;
Guadeloupe—.gp; Martinique—.mq; Mayotte—.yt; Reunion
—.re Internet users: total: 57,226,585
percent of population: 85.6% (July 2016 est.)
country comparison to the world: 12
Broadband—fixed subscriptions:
total: 29.1 million
subscriptions per 100 inhabitants: 43 (2018 est.)
country comparison to the world: 7
Telephones—fixed lines: total subscriptions: 19,484,361
subscriptions per 100 inhabitants: 39 (2018 est.)
country comparison to the world: 14
Telephones—mobile cellular:
total subscriptions: 54,161,014
subscriptions per 100 inhabitants: 110 (2018 est.)
country comparison to the world: 28
Telephone system: general assessment: well-developed,
modern facilities; one of the largest in Europe, average
mobile penetration for Europe; effective competition with
encouraging regulation; investment in 5G technologies and
services; more than 60 percent of households have access
to fiber to the home broadband connections (2018)
domestic: fixed-line 42 per 100 and mobile-cellular 113
telephones per 100 persons (2018)
international: country code—34; landing points for the
MAREA, Tata TGN-Western Europe, Pencan-9, SATI-3/WASC,
Canalink, Atlantis-2, Columbus -111, Estepona-Tetouan,
FEA, Balalink, ORVAL and PENBAL-5 submarine cables
providing connectivity to Europe, the Middle East, Africa,
South America, Asia, Southeast Asia and the US; satellite
earth stations—2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean), NA Eutelsat; tropospheric scatter to adjacent
countries (2019) Broadcast media: a mixture of both publicly
operated and privately owned TV and radio stations;
overall, hundreds of TV channels are available including
national, regional, local, public, and international channels;
satellite and cable TV systems available; multiple national
radio networks, a large number of regional radio networks,
and a larger number of local radio stations; overall,
hundreds of radio stations (2019)
Internet country code: .e€S
Internet users: total: 39,123,384
percent of population: 80.6% (July 2016 est.)
country comparison to the world: 18
Broadband—fixed subscriptions:
total: 15,176,954
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 13','7ace96cca298be792c4723a2cc9940cfcba876d7bf605cb816e2e688d22039e7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2e53e61f8eb167c33dc0a03bc2e994c22c05ead8b454eee131afad1a52a6f35',2021,'HN','Honduras','communications',182,'Telephones—fixed lines: total subscriptions: 20,869
subscriptions per 100 inhabitants: 5 (2018 est.)
country comparison to the world: 176
Telephones—mobile cellular:
total subscriptions: 327,629
subscriptions per 100 inhabitants: 85 (2018 est.)
country comparison to the world: 179
Telephone system: general assessment: govt telecom company,
Belize Telemedia Ltd. (BTL), continues to hold a monopoly
in fixed-line services and mobile and broadband fixed-line
teledensity; small market, underinvestment with lack of
competition, yet BTL reports stable telecom revenue (2018)
domestic: 5 per 100 fixed-line and wmobile-cellular
teledensity approaching 85 per 100 persons; mobile sector
accounting for over 90% of all phone subscriptions (2018)
international: country code—501; landing points for the
ARCOS and SEUL fiber-optic telecommunications
submarine cable that provides links to South and Central
America, parts of the Caribbean, and the US; satellite earth
station—8 (Intelsat—2, unknown—6) (2019) Broadcast media:
8 privately owned TV stations; multi-channel cable TV
provides access to foreign stations; about 25 radio stations
broadcasting on roughly 50 different frequencies; state-run
radio was privatized in 1998 (2019) Internet country code: .bz
Internet users: total: 157,735
percent of population: 44.6% (July 2016 est.)
country comparison to the world: 172
Broadband—fixed subscriptions: total: 24,658
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 148','bd085dc9408bee5819d66d0df5b91227092856335d73073f4115cac50ad036cc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d153b4a8dc7b995f1b40dbdd3dbfbd27375badea006be06bdf90c9d92e634af',2021,'ET','Ethiopia','communications',189,'Telephones—fixed lines: total subscriptions: 48,508
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 159
Telephones—mobile cellular:
total subscriptions: 9,461,872
subscriptions per 100 inhabitants: 79 (2018 est.)
country comparison to the world: 87
Telephone system: general assessment: fixed-line network
characterized by aging, deteriorating equipment; mobile
networks account for almost all Internet connections; govt
aims to provide telecoms services to 80% of the country,
mostly via mobile infrastructure; govt aims to restructure
state-owned telcos and has partially done so; Mobile
Number Portability (MNP) is available; Benin joins free
roaming scheme (2018) domestic: fixed-line teledensity
only about 1 per 100 persons; spurred by the presence of
multiple mobile-cellular providers, cellular telephone
subscribership has increased rapidly, exceeding 79 per 100
persons (2018) international: country code—229; landing
points for the SAT-3/WASC and ACE fiber-optic submarine
cable that provides connectivity to Europe, and most West
African countries; satellite earth stations—7 (Intelsat-
Atlantic Ocean) (2019) Broadcast media: state-run Office de
Radiodiffusion et de Television du Benin (ORTB) operates a
TV station providing a wide broadcast reach; several
privately owned TV stations broadcast from Cotonou;
satellite TV subscription service is available; state-owned
radio, under ORTB control, includes a national station
supplemented by a number of regional stations; substantial
number of privately owned radio broadcast stations;
transmissions of a few international broadcasters are
available on FM in Cotonou (2019) Internet country code: .bj
Internet users: total: 1,288,336
percent of population: 12% (July 2016 est.)
country comparison to the world: 126
Broadband—fixed subscriptions:
total: 27,034
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 145
Telephones—fixed lines: total subscriptions: 21,883
subscriptions per 100 inhabitants: 31 (2017 est.)
country comparison to the world: 174
Telephones—mobile cellular:
total subscriptions: 64,997
subscriptions per 100 inhabitants: 92 (2017 est.)
country comparison to the world: 200
Telephone system: general assessment: a good, fully automatic
digital telephone system with fiber-optic trunk lines;
telecom sector provides a relatively high contribution to
overall GDP; numerous competitors licensed, but small and
localized (2018) domestic: the system has a high fixed-line
teledensity 31 per 100, coupled with a mobile-cellular
teledensity of roughly 92 per 100 persons (2018)
international: country code—1-441; landing points for the
GlobeNet, Gemini Bermuda, CBUS, and the CB-1
submarine cables to the Caribbean, South America and the
US; satellite earth stations—3 (2019) Broadcast media: 3 TV
stations; cable and satellite TV subscription services are
available; roughly 13 radio stations operating Internet country
code: .bm
Internet users: total: 69,126
percent of population: 98% (July 2016 est.)
country comparison to the world: 180
Telephones—fixed lines: total subscriptions: 37,691
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 164
Telephones—mobile cellular:
total subscriptions: 6,144,507
subscriptions per 100 inhabitants: 75 (2018 est.)
country comparison to the world: 114
Telephone system: general assessment: fair system based on a
network of microwave radio relay routes supplemented by
open-wire lines and a mobile-cellular system; (2018)
domestic: fixed-line less than 1 per 100 and mobile-cellular
78 telephones per 100 persons with mobile-cellular use
predominating (2018) international: country code—228;
landing point for the WACS submarine cable, linking
countries along the west coast of Africa with each other
and with Portugal; satellite earth stations—1 Intelsat
(Atlantic Ocean), 1 Symphonie (2020) Broadcast media: 1
state-owned TV station with multiple transmission sites;
five private TV stations broadcast locally; cable TV service
is available; state-owned radio network with two stations
(in Lome and Kara); several dozen private radio stations
and a few community radio stations; transmissions of
multiple international broadcasters available (2019) Internet
country code: .tg
Internet users: total: 877,310
percent of population: 11.3% (July 2016 est.)
country comparison to the world: 134
Broadband—fixed subscriptions:
total: 26,156
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 146
Telephones—fixed lines: total subscriptions: 300
subscriptions per 100 inhabitants: 21 (July 2016 est.)
country comparison to the world: 218
Telephone system: general assessment: modern satellite-based
communications system; 4G LTE service (2018) domestic:
radiotelephone service between islands; fixed-line less than
1 per 100 (2018)
international: country code—690; landing point for the
Southern Cross NEXT submarine cable linking Australia,
Tokelau, Samoa, Kiribati, Fiji, New Zealand and Los
Angeles, CA (USA); radiotelephone service to Samoa;
government-regulated telephone service (TeleTok); satellite
earth stations—3 (2020) Broadcast media: Sky TV access for
around 30% of the population; each atoll operates a radio
service that provides shipping news and weather reports
(2019) Internet country code: .tk
Internet users: total: 805
percent of population: 60.2% (July 2016 est.)
country comparison to the world: 223
Telephones—fixed lines: total subscriptions: 14,697
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 188
Telephones—mobile cellular: total subscriptions: 107,938
subscriptions per 100 inhabitants: 101 (2018 est.)
country comparison to the world: 193
Telephone system: general assessment: high speed Internet
provided by 3 MNOs, which has subsequently allowed for
better health care services, faster connections for
education and growing e-commerce services; fixed-line
teledensity has dropped given mobile subscriptions; mobile
technology dominates given the island geography; satellite
technology is widespread and is important especially in
areas away from the city (2018) domestic: fixed-line 14 per
100 and mobile-cellular teledensity 70 telephones per 100;
fully automatic switched network (2018) international:
country code—676; landing point for the Tonga Cable and
the TDCE connecting to Fiji and 3 separate Tonga islands;
satellite earth station—1 Intelsat (Pacific Ocean) (2020)
Broadcast media: 1 state-owned TV station and 3 privately
owned TV stations; satellite and cable TV services are
available; 1 state-owned and 5 privately owned radio
stations; Radio Australia broadcasts available via satellite
(2019) Internet country code: .to
Internet users: total: 42,552
percent of population: 40% (July 2016 est.)
country comparison to the world: 197
Broadband—fixed subscriptions:
total: 2,519
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 186','89975b983c6ab2cc13e9ca0479cc37b49056cb34937a19b43c6c78f30681080c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('079d3c26f60277fa06a7457d20842a1ae9b780c0b0101efe03dcc7d0558c4c63',2021,'BT','Bhutan','communications',198,'Telephones—fixed lines: total subscriptions: 22,015
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 173
Telephones—mobile cellular:
total subscriptions: 703,554
subscriptions per 100 inhabitants: 92 (2018 est.)
country comparison to the world: 165
Telephone system: general assessment: urban towns and
district headquarters have telecommunications services;
telecom sector has been continuing on a_ steady
development path; fixed broadband penetration remains
very low, due to the preeminence of the mobile platform; in
the next five years to 2023 low to moderate growth is
expected from this small base (2018) domestic: 3 to 100
fixed-line, 92 to 100 mobile cellular; domestic service
inadequate, notably in rural areas (2018) international:
country code—975; international telephone and telegraph
service via landline and microwave relay through India;
satellite earth station—1 Intelsat Broadcast media: state-
owned TV station established in 1999; cable TV service
offers dozens of Indian and other international channels;
first radio station, privately launched in 1973, is now state-
owned; 5 private radio stations are currently broadcasting
(2012) Internet country code: .bt
Internet users: total: 313,347
percent of population: 41.8% (July 2016 est.)
country comparison to the world: 160
Broadband—fixed subscriptions:
total: 10,802
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 169','a9609360cc31fbacc642baaf07e079ee9f89810f45a71ba72def84b409825874','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91004855d5133819a715a95852fba1315b8cc29b1282e76b343ac9f72b947b0a',2021,'BR','Brazil','communications',214,'Telephones—fixed lines: total subscriptions: 711,961
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 87
Telephones—mobile cellular:
total subscriptions: 11,445,830
subscriptions per 100 inhabitants: 101 (2018 est.)
country comparison to the world: 79
Telephone system: general assessment: state-owned Empresa
Nacional de Telecomunicaciones (Entel) is the country’s
incumbent long-distance operator, and _ offers _ local
telephone service, DSL, and satellite TV; its subsidiary
Entel Movil is Bolivia’s largest mobile network provider,
reliability, and coverage have steadily improved, but some
remote areas are still underserved; Entel plans to extend
fiber to all 339 municipal capital cities by 2022; MNP
(mobile number potability) launched in October 2018;
Bolivian Space Agency planning to launch a second telecom
satellite after 2020 (2019) domestic: 6 per 100 fixed-line,
mobile-cellular telephone use expanding rapidly and
teledensity stands at 101 per 100 persons; most telephones
are concentrated in La Paz, Santa Cruz, and other capital
cities (2018) international: country code—591; Bolivia has
no direct access to submarine cable networks and must
therefore connect to the rest of the world either via
satellite or through terrestrial links across neighboring
countries; satellite earth station—1 Intelsat (Atlantic
Ocean) (2019) Broadcast media: large number of radio and TV
stations broadcasting with private media _ outlets
dominating; state-owned and private radio and TV stations
generally operating freely, although both pro-government
and anti-government groups have attacked media outlets in
response to their reporting Internet country code: .bo
Internet users: total: 4,354,678
percent of population: 39.7% (July 2016 est.)
country comparison to the world: 83
Broadband—fixed subscriptions:
total: 504,097
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 85
Telephones—fixed lines: total subscriptions: 38,311,930
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 6
Telephones—mobile cellular:
total subscriptions: 207,046,810
subscriptions per 100 inhabitants: 99 (2018 est.)
country comparison to the world: 6
Telephone system: general assessment: good working system
including an extensive microwave radio relay system and a
domestic satellite system with 64 earth stations; four major
mobile operators offering a range of voice and data
services; one of the largest broadband markets in Latin
America, broadband penetration only behind Chile,
Argentina, and Uruguay; country is a pioneer in the region
for m-commerce (electronic commerce conducted on
mobile phones) (2018) domestic: fixed-line connections
have remained relatively stable in recent years and stand at
about 18 per 100 persons; less-expensive mobile-cellular
technology has been a major impetus broadening telephone
service to the lower-income segments of the population
with mobile-cellular teledensity roughly 99 per 100 persons
(2018) international: country code—55; landing points for a
number of submarine cables, including Malbec, ARBR,
Tamnat, SAC, SAm-1, Atlantis -2, Seabras-1, Monet,
EllaLink, BRUSA, GlobeNet, AMX-1, Brazilian Festoon,
Bicentenario, Unisur, Junior, Americas -II, SAE x1, SAIL,
SACS and SABR that provide direct connectivity to South
and Central America, the Caribbean, the US, Africa, and
Europe; satellite earth stations—3 Intelsat (Atlantic Ocean),
1 Inmarsat (Atlantic Ocean region east), connected by
microwave relay system to Mercosur Brazilsat B3 satellite
earth station; satellites is a major communication platform,
as it is almost impossible to lay fibre optic cable in the thick
vegetation (2019) Broadcast media: state-run Radiobras
operates a radio and a TV network; more than 1,000 radio
stations and more than 100 TV channels operating—mostly
privately owned; private media ownership highly
concentrated Internet country code: .br
Internet users: total: 122,841,218
percent of population: 59.7% (July 2016 est.)
country comparison to the world: 4
Broadband—fixed subscriptions:
total: 31,233,004
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 6
Telephones—fixed lines: total subscriptions: 6,973,573
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 22
Telephones—mobile cellular:
total subscriptions: 64,513,977
subscriptions per 100 inhabitants: 134 (2018 est.)
country comparison to the world: 24
Telephone system: general assessment: modern system with a
nationwide microwave radio relay system, a domestic
satellite system with 41 earth stations, and a fiber-optic
network linking 50 cities; the cable sector commands about
half of the market by subscribers, with DSL having a
declining share and with fiber-based broadband developing
strongly; competition among the MVNO (mobile virtual
network operator) sector has promoted 2.9 million
subscribers as of mid-2018; most infrastructure is primarily
in high-density urban areas (2018) domestic: fixed-line
connections stand at about 14 per 100 persons; mobile
cellular telephone subscribership is about 134 per 100
persons; competition among cellular service providers is
resulting in falling local and international calling rates and
contributing to the steep decline in the market share of
fixed-line services (2018) international: country code—57;
landing points for the SAC, Maya-1, SAIT, ACROS, AMX-1,
CFX-1, PCCS, Deep Blue Cable, Globe Net, PAN-AM, SAm-1
submarine cable systems providing links to the US, parts of
the Caribbean, and Central and South America; satellite
earth stations—10 (6 Intelsat, 1 Inmarsat, 3 fully digitalized
international switching centers) (2019) Broadcast media:
combination of state-owned and privately owned broadcast
media provide service; more than 500 radio stations and
many national, regional, and local TV stations (2019)
Internet country code: .CO
Internet users: total: 27,452,550
percent of population: 58.1% (July 2016 est.)
country comparison to the world: 28
Broadband—fixed subscriptions:
total: 6,678,543
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 25
Telephones—fixed lines: total subscriptions: 10,320
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 191
Telephones—mobile cellular:
total subscriptions: 498,903
subscriptions per 100 inhabitants: 61 (2018 est.)
country comparison to the world: 173
Telephone system: general assessment: sparse system of
microwave radio relay and HF __ radiotelephone
communication stations; telephone service limited to the
islands’ few towns (2018) domestic: fixed-line connections
only about 1 per 100 persons; mobile-cellular usage over 61
per 100 persons; two companies, Comoros Telecom and
Telma, provide domestic and international mobile service
and wireless data (2018) international: country code—269;
landing point for the EASSy, Comoros Domestic Cable
System, Avassa, and FLY-LION3 fiber-optic submarine cable
system connecting East Africa with Europe; HF
radiotelephone communications to Madagascar and
Reunion (2019) Broadcast media: national state-owned TV
station and a TV station run by Anjouan regional
government; national state-owned radio; regional
governments on the islands of Grande Comore and Anjouan
each operate a radio station; a few independent and small
community radio stations operate on the islands of Grande
Comore and Moheli, and these two islands have access to
Mayotte Radio and French TV
Internet country code: .km
Internet users: total: 63,084
percent of population: 7.9% (July 2016 est.)
country comparison to the world: 184
Broadband—fixed subscriptions:
total: 1,531
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 191
Telephones—fixed lines: total subscriptions: 135,795
subscriptions per 100 inhabitants: 18 (2017 est.)
country comparison to the world: 133
Telephones—mobile cellular:
total subscriptions: 643,210
subscriptions per 100 inhabitants: 87 (2017 est.)
country comparison to the world: 166
Telephone system: general assessment: reliable international
long distance service; 100% digital network; national
transmission supported by fiber optic cable and rural
network by microwaves; more than 150,000 lines; many
areas still lack fixed-line telephone services; 2019 budget
allocates funds for ICT (Information and Communications
Technology) development (2018) domestic: fixed-line
teledensity is about 20 per 100 persons; mobile-cellular
teledensity about 87 per 100 persons (2018) international:
country code—592; landing point for the SG-SCS
submarine cable to Suriname, and the Caribbean; satellite
earth station—1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: government-dominated broadcast media; _ the
National Communications Network (NCN) TV is _ state-
owned; a few private TV stations relay satellite services;
the state owns and operates 2 radio stations broadcasting
on multiple frequencies capable of reaching the entire
country; government limits on licensing of new private
radio stations has constrained competition in broadcast
media Internet country code: .gy
Internet users: total: 262,425
percent of population: 35.7% (July 2016 est.)
country comparison to the world: 163
Broadband—fixed subscriptions:
total: 64,889
subscriptions per 100 inhabitants: 9 (2017 est.)
country comparison to the world: 129
Telephones—fixed lines: total subscriptions: 5,922
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 204
Telephones—mobile cellular:
total subscriptions: 6,399,044
subscriptions per 100 inhabitants: 59 (2018 est.)
country comparison to the world: 111
Telephone system: general assessment: telecommunications
infrastructure is among the least-developed in Latin
America and the Caribbean; domestic cell service is
functional (2018) domestic: fixed-line is less than 1 per 100;
mobile-cellular telephone services have expanded greatly in
the last decade due to low-cost GSM (Global Systems for
Mobile) phones and pay-as-you-go plans; mobile-cellular
teledensity is 61 per 100 persons (2018) international:
country code—509; landing points for the BDSNi and
Fibralink submarine cables to 14 points in the Bahamas
and Dominican Republic; satellite earth station—1 Intelsat
(Atlantic Ocean) (2019) Broadcast media: 98 television
stations throughout the country, including 1 government-
owned; cable TV subscription service available; 850 radio
stations (of them, only 346 are licensed), including 1
government-owned; more than 100 community radio
stations; over 64 FM stations in Port-au-Prince alone; VOA
Creole Service broadcasts daily on 30 affiliate stations
(2016) Internet country code: .ht
Internet users: total: 1,282,686
percent of population: 12.2% (July 2016 est.)
country comparison to the world: 127
Broadband—fixed subscriptions:
total: 31,100
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 142
Telephones—fixed lines: total subscriptions: 88,098
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 144
Telephones—mobile cellular:
total subscriptions: 752,270
subscriptions per 100 inhabitants: 126 (2018 est.)
country comparison to the world: 164
Telephone system: general assessment: international facilities
are good; state-owned fixed-line and broadband services;
competition in the mobile sector; fixed-line effective along
the coastline and poor in the interior (2018) domestic:
fixed-line 15 per 100 and mobile-cellular teledensity 134
telephones per 100 persons; microwave radio relay
network is in place (2018) international: country code—
997; landing point for the SG-SCS submarine cable linking
South America with the Caribbean; satellite earth stations
—2 Intelsat (Atlantic Ocean) (2019) Broadcast media: 2 state-
owned TV stations; 1 state-owned radio station; multiple
private radio and TV stations (2019) Internet country code: .Sr
Internet users: total: 265,964
percent of population: 45.4% (July 2016 est.)
country comparison to the world: 162
Broadband—fixed subscriptions:
total: 73,176
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 127
Telephones—fixed lines: total subscriptions: 1,153,533
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 74
Telephones—mobile cellular:
total subscriptions: 5,170,624
subscriptions per 100 inhabitants: 153 (2018 est.)
country comparison to the world: 120
Telephone system: general assessment: fully digitalized; one of
the highest broadband penetrations in Latin America; high
fixed-line and mobile penetrations as well; FttP coverage by
2022; nationwide 3G coverage (2018) domestic: most
modern facilities concentrated in Montevideo; nationwide
microwave radio relay network; overall fixed-line 34 per
100 and mobile-cellular teledensity 152 per 100 persons
(2018) international: country code—598; landing points for
the Unisor, Tannat, and Bicentenario submarine cable
system providing direct connectivity to Brazil and
Argentina; Bicentenario 2012 and Tannat 2017 cables
helped end-users with Internet bandwidth; satellite earth
stations—2 Intelsat (Atlantic Ocean) (2020) Broadcast media:
mixture of privately owned and state-run broadcast media;
more than 100 commercial radio stations and about 20 TV
channels; cable TV is available; many community radio and
TV stations; adopted the hybrid Japanese/Brazilian HDTV
standard (ISDB-T) in December 2010 (2019) Internet country
code: .Uy
Internet users: total: 2,225,075
percent of population: 66.4% (July 2016 est.)
country comparison to the world: 107
Broadband—fixed subscriptions: total: 977,390
subscriptions per 100 inhabitants: 29 (2018 est.)
country comparison to the world: 70
Telephones—fixed lines: total subscriptions: 5,547,291
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 27
Telephones—mobile cellular:
total subscriptions: 20,731,169
subscriptions per 100 inhabitants: 70 (2018 est.)
country comparison to the world: 56
Telephone system: general assessment: modern and
expanding; by late 2018 teledensity has fallen due to
political upheaval in the country with people holding on to
mobile service, but cancelling fixed-line telecom services;
poor quality of service in many areas of the country due to
financial concerns of customers, decrepit sate of fixed-line
network and difficulty to pay for equipment from foreign
vendors; popularity of social networks has given growth to
mobile data traffic; LTE population coverage about 47%
(2018) domestic: two domestic satellite systems with three
earth stations; recent substantial improvement in telephone
service in rural areas; installation of a national inter-urban
fiber-optic network capable of digital multimedia services;
3 major providers operate in the mobile market and
compete with state-owned company; fixed-line 19 per 100
and mobile-cellular telephone subscribership about 78 per
100 persons (2018) international: country code—58;
landing points for the Venezuela Festoon, ARCOS, PAN-AM,
SAC, GlobeNet, ALBA-1 and Americas II submarine cable
system providing connectivity to the Caribbean, Central
and South America, and US; satellite earth stations—1
Intelsat (Atlantic Ocean) and 1 PanAmSat (2020) Broadcast
media: government supervises a mixture of state-run and
private broadcast media; 13 public service networks, 61
privately owned TV networks, a privately owned news
channel with limited national coverage, and a government-
backed Pan-American channel; state-run radio network
includes roughly 65 news stations and another 30 stations
targeted at specific audiences; state-sponsored community
broadcasters include 235 radio stations and 44 TV stations;
the number of private broadcast radio stations has been
declining, but many still remain in operation Internet country
code: .ve
Internet users: total: 18,547,381
percent of population: 72% (2017 est.)
country comparison to the world: 35
Broadband—fixed subscriptions: total: 2,604,578
subscriptions per 100 inhabitants: 9 (2018 est.)
country comparison to the world: 47
Telephones—fixed lines: total subscriptions: 4,296,301
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 33
Telephones—mobile cellular:
total subscriptions: 140,639,140
subscriptions per 100 inhabitants: 145 (2018 est.)
country comparison to the world: 11
Telephone system: general assessment: Vietnam is putting
considerable effort into modernization and expansion of its
telecommunication system; competition is thriving in the
market place; mobile dominates over fixed-line; FttH
market growing, as is e-commerce; govt driving force for
growth; data sovereignty is a key driver for local centers;
4G licenses awarded to 5 major operators; Ho Chi Minh
City to become the first smart city in Vietnam with cloud
computing infrastructure, big data, data centers and
security-monitoring centers (2018) domestic: all provincial
exchanges are digitalized and connected to Hanoi, Da
Nang, and Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; main lines have been
increased, and the use of mobile telephones is growing
rapidly; fixed-line 5 per 100 and mobile-cellular 125 per
100 (2018) international: country code—84; landing points
for the SeaMeWe-3, APG, SJC2, AAE-1, AAG and the TGN-
IA submarine cable system providing connectivity to
Europe, Africa, the Middle East, Asia, Southeast Asia,
Australia, and the US; satellite earth stations—2
Intersputnik (Indian Ocean region) (2020) Broadcast media:
government controls all broadcast media exercising
oversight through the Ministry of Information and
Communication (MIC); government-controlled national TV
provider, Vietnam Television (VIV), operates a network of
several channels with regional broadcasting centers;
programming is relayed nationwide via a network of
provincial and municipal TV stations; law limits access to
satellite TV but many households are able to access foreign
programming via home satellite equipment; government-
controlled Voice of Vietnam, the national radio broadcaster,
broadcasts on several channels and is repeated on AM, FM,
and shortwave stations throughout Vietnam (2018) Internet
country code: . vn
Internet users: total: 49.741 million
percent of population: 52.7% (July 2016 est.)
country comparison to the world: 14
Broadband—fixed subscriptions: total: 12,994,451
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 16
Telephones—fixed lines: total subscriptions: 76,000
subscriptions per 100 inhabitants: 73 (July 2016 est.)
country comparison to the world: 148
Telephone system: general assessment: modern system with
total digital switching, uses fiber-optic cable and
microwave radio relay; good interisland and international
connections; broadband access; expansion of FttP (Fiber to
the Home) markets; LTE launches; regulatory development
(2018) domestic: full range of services available; fixed-line
73 per 100 persons (2018) international: country code—1-
340; landing points for the BSCS, St Thomas-ST Croix
System, Southern Caribbean Fiber, Americas II, GCN, MAC,
PAN-AM and SAC submarine cable connections to US, the
Caribbean, Central and South America; satellite earth
stations—NA (2020) Broadcast media: about a dozen TV
broadcast stations including 1 public TV station; multi-
channel cable and satellite TV services are available; 24
radio stations Internet country code: . Vi
Internet users: total: 57,000
percent of population: 54.8% (July 2016 est.)
country comparison to the world: 189
Telephone system: general assessment: satellite
communications; 2 Defense Switched Network circuits off
the Overseas Telephone System (OTS); located in the
Hawaii area code—808 (2018) Broadcast media: American
Armed Forces Radio and Television Service (AFRTS)
provides satellite radio/TV broadcasts (2018) MILITARY
AND SECURITY
Military—note: defense is the responsibility of the US; the US
Air Force is responsible for overall administration and
operation of the island facilities; the launch support facility
is administered by the US Missile Defense Agency (MDA)
Antaretica
POLITICAL MAP OF SOUTH AMERICA
Caribbean Sea
Anuba
flare)
Barranquill.
Cartagen.
Lima
Pacific |
South
Ocean
Tropic of CAPRI Y. — —
sata \\
Isla San po)
amity Viele San Ambrosio
\\ {CHILE
\\ CHILE
\\
\\
\\
ARCHIPIELAGO \\ VOY
JUAN FERNANDEZ) Santia,
cme) .
\\
\\
Concepeldt
Scale 1:35,000,000
Azimuthal Equal-Area Projection \\
500 Kilometers
500 Miles
Boundary representation is
not necessarily authoritative.
Curacao:
eT
d
North
Atlantic
Georgetown
Paramaribo Ocean
Cayenne
omodoro
Rivadavia
Rio
allegos
om. Strait of
‘Magellan
nas
:
Fortaleza
“™\\natal
pena
y hrecte
BRAZI L ie
2 .
| {ss Ivador
‘ Brasil las of
7 semoaen|
—, Uberlindia af f pee
Aa Nee Sf
¥y Vitéria
‘ Pos
bondrina ue “a |
SO PRUE * Rio de Janeiro
Curitiba,
Jol vile r4
i loriandpolis
South
Atlantic
‘Mar del Plata Ocean
Stanley
Falkland Islands
(islas Malvinas) South Georgia and
claimed by ARGENTINA / south sandwich Islands
er
a
/ y
40
B0S543A1 (00186) 6-12
PHYSICAL MAP OF SOUTH AMERICA
< 90
Caribbean Sea
North
Atlantic
Ocean
South
Pacific
South
aaeaate
Ocean
RIO
GRANDE
RISE
Z
803521AI (G00186) 11-11
POLITICAL MAP OF SOUTHEAST ASIA_
Naniing) 205.
Hefei” “ye
eae
Changsha
OdWVN
invave)
s
y
» NICOBAR
+ ISLANDS
Pulaw stent
KEPULAUAN mt
MENTAWAL
‘Christmas Island
(AUSTRALIA),
hanjiang br
Obino-tori-
jaikow
shima
(JAPAN),
p
J Hainan
= Dao
is + PARACEL Philippine
DaNang “ ~ ISLANDS i
ETNAM — Sed
South','07661fc17b3cf9c78b260c16c6f0345ccc1023d67e7ceabef0c38de4646d8e97','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12cd2695a92fecc9a1e1de5d271ec88c5108cf49a34137bc9a6109074a432f3f',2021,'ME','Montenegro','communications',220,'Telephones—fixed lines: total subscriptions: 792,535
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 83
Telephones—mobile cellular:
total subscriptions: 3,461,058
subscriptions per 100 inhabitants: 90 (2018 est.)
country comparison to the world: 137
Telephone system: general assessment: post-war
reconstruction of the telecommunications network, aided
by an internationally sponsored program, resulted in sharp
increases in fixed-line telephone availability; integration
with the EU has given stability to the present economy,
additionally a regulatory framework and the market has
been liberalised; DSL and cable are the chief platforms for
fixed-line connectivity, there is a small market presence of
fibre broadband; new mobile roaming fees come into effect
similar to other EU countries; rural areas still suffer from
insufficient connectivity (2018) domestic: fixed-line
teledensity roughly 21 per 100 persons and mobile-cellular
subscribership has been increasing rapidly and stands at
roughly 90 telephones per 100 persons’ (2018)
international: country code—387; no satellite earth stations
Broadcast media: 3 public TV broadcasters: Radio and TV of
Bosnia and Herzegovina, Federation TV (operating 2
networks), and Republika Srpska Radio-TV; a_ local
commercial network of 5 TV stations; 3 private, near-
national TV stations and dozens of small independent TV
broadcasting stations; 3 large public radio broadcasters
and many private radio stations Internet country code: .ba
Internet users: total: 2,677,502
percent of population: 69.3% (July 2016 est.)
country comparison to the world: 99
Broadband—fixed subscriptions:
total: 693,554
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 77','9916d598ca31c065505251fee72242c5c5d5b4926a8c49c2832130ce9b714c94','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e978bb4fdeed8daefab601f5a5d2d2176f3b32b5f21ec2e991b949e9013a2c38',2021,'ZA','South Africa','communications',230,'Telephones—fixed lines: total subscriptions: 142,481
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 129
Telephones—mobile cellular:
total subscriptions: 3,381,228
subscriptions per 100 inhabitants: 150 (2018 est.)
country comparison to the world: 138
Telephone system: general assessment: effective regulatory
reform has turned the Botswana’s telecom market into one
of the most liberalized in the region; Botswana has one of
the highest mobile penetration rates in Africa; 3 MNOs
have entered the underdeveloped broadband sector with
the adoption of 3G, LTE and WiMAX technologies; mobile
Internet remains the preferred choice (2018) domestic:
fixed-line teledensity has declined in recent years and now
stands at roughly 6 telephones per 100 persons; mobile-
cellular teledensity has advanced to 150 telephones per
100 persons (2018) international: country code—267;
international calls are made _ via _ satellite, using
international direct dialing; 2 international exchanges;
digital microwave radio relay links to Namibia, Zambia,
Zimbabwe, and South Africa; satellite earth station—1
Intelsat (Indian Ocean) Botswana is participating in
regional development efforts; expanding fully digital
system with fiber-optic cables linking the major population
centers in the east as well as a system of open-wire lines,
microwave radio relays links, and _ radiotelephone
communication stations; the Botswana Telecommunications
Corporation is rolling out 4G service to over 95 sites in the
country that will improve network connectivity Broadcast
media: 2 TV stations—1 state-owned and 1 privately owned;
privately owned satellite TV subscription service is
available; 2 state-owned national radio stations; 4 privately
owned radio stations broadcast locally (2019) Internet country
code: .bW
Internet users: total: 869,610
percent of population: 39.4% (July 2016 est.)
country comparison to the world: 135
Broadband—fixed subscriptions:
total: 40,044
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 138
Internet country code: .Dv
Communications: note: has an automated meteorological
station
Telephones—fixed lines: total subscriptions: 8,328
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 195
Telephones—mobile cellular:
total subscriptions: 2,380,804
subscriptions per 100 inhabitants: 122 (2017 est.)
country comparison to the world: 147
Telephone system: general assessment: rudimentary system
consisting of a modest number of landlines, a small
microwave radio relay system, and a small radiotelephone
communication system; fixed-line teledensity is low; mobile-
cellular telephone system is expanding; commercial
services with LTE technology (2018) domestic: mobile-
cellular service dominates the market with a subscribership
now over 122 per 100 persons; fixed-line is 1 per 100
subscriptions (2018) international: country code—266;
satellite earth station—1 Intelsat (Atlantic Ocean); Internet
accessibility has improved with several submarine fibre
optic cables that land on African east and west coasts, but
the country’s land locked position makes access prices
expensive (2019) Broadcast media: 1 state-owned TV station
and 2 state-owned radio stations; government controls
most private broadcast media; satellite TV subscription
service available; transmissions of multiple international
broadcasters obtainable (2019) Internet country code: .1S
Internet users: total: 534,360
percent of population: 27.4% (July 2016 est.)
country comparison to the world: 148
Broadband—fixed subscriptions:
total: 5,763
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 178','60e3e5d0d2c43976f67333cb18f328262ca74f311bc758df01b61ddad81a3682','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4940cfd659322b38c02c4e9ce986d32797d07d605697e4f8486415f0f00d8601',2021,'IO','British Indian Ocean Territory','communications',235,'Telephone system: general assessment: separate facilities for
military and public needs are available (2018) domestic: all
commercial telephone services are available, including
connection to the Internet (2018) international: country
code (Diego Garcia)—246; landing point for the SAFE
submarine cable that provides direct connectivity to Africa,
Asia and near-by Indian Ocean island _ countries;
international telephone service is carried by satellite (2019)
Broadcast media: Armed Forces Radio and Television Service
(AFRTS) broadcasts over 3 separate frequencies for US and
UK military personnel stationed on the islands Internet
country code: .10
Communications—note: Diego Garcia hosts one of four
dedicated ground antennas that assist in the operation of
the Global Positioning System (GPS) navigation system (the
others are on Kwajalein (Marshall Islands), at Cape
Canaveral, Florida (US), and on Ascension Island (Saint
Helena, Ascension, and Tristan da Cunha)) MILITARY AND
SECURITY
Military and security forces: no regular military forces (2014)
Military—note: defense is the responsibility of the UK; in
November 2016, the UK extended the US lease on Diego
Garcia for 20 years; the lease now expires in December
2036 (2016) TRANSPORTATION
Airports: 1 (2013)
country comparison to the world: 215
Airports—with paved runways:
total: 1 (2019)
over 3,047 m: 1
Roadways: note: short section of paved road between port
and airfield on Diego Garcia
Ports and terminals: Major seaport(s): Diego Garcia','2409cc0745088b606b7224203c1fb88a25b1932ec35233091cd6f929addbd746','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66e0a32795930801bc2bd92142a8e3ff9ea3ada3bd82f695cc7e04d7063ca7d3',2021,'PR','Puerto Rico','communications',240,'Telephones—fixed lines: total subscriptions: 6,222
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 202
Telephones—mobile cellular:
total subscriptions: 39,954
subscriptions per 100 inhabitants: 112 (2018 est.)
country comparison to the world: 206
Telephone system: general assessment: good overall telephone
service; major expansion sectors include the mobile
telephony and data segments, which continue to appeal to
operator investment; several operators licensed to provide
services within individual markets, most of them are small
and localised (2018) domestic: fixed-line connections
exceed 17 per 100 persons and mobile cellular
subscribership is roughly 112 per 100 persons (2018)
international: country code—1-284; landing points for
PCCS, ECFS, CBUS, Deep Blue Cable, East-West, PAN-AM,
Americas-1, Southern Caribbean Fiber, Columbus- IIb, St
Thomas—St Croix System, Taino-Carib, and Americas I-
North via submarine cable to Caribbean, Central and South
America, and US (2019) Broadcast media: 1 private TV
station; multi-channel TV is available from cable and
satellite subscription services; about a half-dozen private
radio stations Internet country code: .Vg
Internet users: total: 14,600
percent of population: 43.6% (July 2016 est.)
country comparison to the world: 209
Broadband—fixed subscriptions:
total: 4,715
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 180
Telephones—fixed lines: total subscriptions: 82,588
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 145
Telephones—mobile cellular:
total subscriptions: 565,949
subscriptions per 100 inhabitants: 126 (2018 est.)
country comparison to the world: 170
Telephone system: general assessment: service throughout the
country is good; international service is good to Southeast
Asia, Middle East, Western Europe, and the US; while fixed-
line is slowing down, mobile broadband has taken over in
the advancement in the telecoms access’ market;
broadband penetration slow to moderate growth predicted
over the next five years to 2023 (2018) domestic: every
service available; 18 per 100 fixed-line, 126 per 100 mobile-
cellular (2018) international: country code—673; landing
points for the SEA-ME-WE-3, SJC, AAG, Lubuan-Brunei
Submarine Cable via _ optical telecommunications
submarine cables that provides links to Asia, the Middle
East, Southeast Asia, Africa, Australia, and the US; satellite
earth stations—2 Intelsat (1 Indian Ocean and 1 Pacific
Ocean) (2019) Broadcast media: state-controlled Radio
Television Brunei (RTB) operates 5 channels; 3 Malaysian
TV stations are available; foreign TV broadcasts are
available via satellite systems; RTB operates 5 radio
networks and broadcasts on multiple frequencies; British
Forces Broadcast Service (BFBS) provides radio broadcasts
on 2 FM stations; some radio broadcast stations from
Malaysia are available via repeaters Internet country code: .bn
Internet users: total: 410,800 (2019 est.)
percent of population: 94% (Feb 2019 est.)
country comparison to the world: 153
Broadband—fixed subscriptions:
total: 49,452
subscriptions per 100 inhabitants: 11 (2018 est.)
country comparison to the world: 135
Telephones—fixed lines: total subscriptions: 703,266
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 88
Telephones—mobile cellular:
total subscriptions: 3,330,286
subscriptions per 100 inhabitants: 101 (2018 est.)
country comparison to the world: 139
Telephone system: general assessment: modern system
integrated with that of the US by high-capacity submarine
cable and Intelsat with high-speed data capability; havoc
caused by the hurricane in 2017 has left the island lagging
behind the mainland US_ both economically and
technologically; competition among network operators
helps with growth; availability of LTE coverage increasing
to 90% (2018) domestic: digital telephone system; mobile-
cellular services; fixed-line 23 per 100 and mobile-cullular
101 per 100 persons (2018) international: country code—1-
787, 939; landing points for the GTMO-PR, AMX-1, BRUSA,
GCN, PCCS, SAm-1, Southern Caribbean Fiber, Americas-II,
Antillas, ARCOS, SMPR-1, and Taino-Carib submarine
cables providing connectivity to the US, Caribbean, Central
and South America; satellite earth station—1 Intelsat
(2019) Broadcast media: more than 30 TV stations operating;
cable TV subscription services are available; roughly 125
radio stations Internet country code: .pr
Internet users: total: 2,873,895
percent of population: 80.3% (July 2016 est.)
country comparison to the world: 97
Broadband—fixed subscriptions:
total: 609,027
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 80
Telephones—fixed lines: total subscriptions: 452,088
subscriptions per 100 inhabitants: 19 (2018 est.) country
comparison to the world: 100
Telephones—mobile cellular:
total subscriptions: 3,945,978
subscriptions per 100 inhabitants: 167 (2018 est.) country
comparison to the world: 130
Telephone system: general assessment: modern system
centered in Doha; notable efforts to deploy 5G wireless
technology; steady LITE networks; one of the most
connected markets in the Middle East with broadband
penetration; ADSL, Fiber-to-the-Home (FttP), wireless and
mobile services (2019) domestic: fixed-line 19 per 100 and
mobile-cellular telephone subscribership 169 telephones
per 100 persons (2018) international: country code—974;
landing points for the Qatar-UAE Submarine Cable System,
AAE-1, FOG, GBICS/East North Africa MENA and the
FALCON submarine cable network that provides links to
Asia, Africa, the Middle East, Europe and Southeast Asia;
tropospheric scatter to Bahrain; microwave radio relay to
Saudi Arabia and the UAE; satellite earth stations—2
Intelsat (1 Atlantic Ocean and 1 Indian Ocean) and 1
Arabsat; retains full ownership of two commercial
satellites, Es’hailSat 1 and 2 (2019) Broadcast media: TV and
radio broadcast licensing and access to local media
markets are state controlled; home of the satellite TV
channel Al-Jazeera, which was originally owned and
financed by the Qatari government but has evolved to
independent corporate status; Al-Jazeera claims editorial
independence in broadcasting; local radio transmissions
include state, private, and international broadcasters on
FM frequencies in Doha; in August 2013, Qatar’s satellite
company Es’hailSat launched its first communications
satellite Es’hail 1 (manufactured in the US), which entered
commercial service in December 2013 to provide improved
television broadcasting capability and expand availability of
voice and Internet; Es’hailSat launched its second
commercial satellite in 2018 with aid of SpaceX (2019)
Internet country code: .ga
Internet users: total: 2,129,360
percent of population: 94.3% (July 2016 est.) country
comparison to the world: 109
Broadband—fixed subscriptions:
total: 267,906
subscriptions per 100 inhabitants: 11 (2018 est.) country
comparison to the world: 105','2244ac01d6279845629a1741cde4aa040ba82f7a835b610998d40a96de50045d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89c9adb4ef7e673c4334e5cbd3182443da5209ace5645e94347172fdfb18eac0',2021,'MM','Myanmar','communications',252,'Telephones—fixed lines: total subscriptions: 520,863
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 94
Telephones—mobile cellular:
total subscriptions: 61,143,964
subscriptions per 100 inhabitants: 110 (2018 est.)
country comparison to the world: 26
Telephone system: general assessment: remains one of the last
underdeveloped telecoms markets in Asia; the mobile
market has experienced rapid growth, in 2014 foreign
competition was allowed to compete in the market (2018)
domestic: fixed-line is less than 1 per 100, while mobile-
cellular is 110 per 100 and shows great potential for the
future (2018) international: country code—95; landing
points for the SeaMeWe-3, SeaMeWe-5, AAE-1 and
Singapore-Myanmar optical telecommunications submarine
cable that provides links to Asia, the Middle East, Africa,
Southeast Asia, Australia and Europe; satellite earth
stations—2, Intelsat (Indian Ocean) and ShinSat (2019)
Broadcast media: government controls all domestic broadcast
media; 2 state-controlled TV stations with 1 of the stations
controlled by the armed forces; 2 pay-TV stations are joint
state-private ventures; access to satellite TV is limited; 1
state-controlled domestic radio station and 9 FM stations
that are joint state-private ventures; transmissions of
several international broadcasters are available in parts of
Burma; the Voice of America (VOA), Radio Free Asia (RFA),
BBC Burmese service, the Democratic Voice of Burma
(DVB), and Radio Australia use shortwave to broadcast in
Burma; VOA, RFA, and DVB produce daily TV news
programs that are transmitted by satellite to audiences in
Burma; in March 2017, the government granted licenses to
5. private broadcasters, allowing them digital free-to-air TV
channels to be operated in partnership with government-
owned Myanmar Radio and Television (MRTV) and will rely
upon MRIV’s transmission infrastructure (2019) Internet
country code: .™mM
Internet users: total: 14,264,308
percent of population: 25.1% (July 2016 est.)
country comparison to the world: 41
Broadband—fixed subscriptions:
total: 129,050
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 118','ca08383ad4a29d33f841519869d573b886d10832974fa88f0c657c134fc238db','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc71f436338670438c4932fb6d782e36abf7ea6ad4c5bc5db3d277b0f5cd3f77',2021,'BI','Burundi','communications',261,'Telephones—fixed lines: total subscriptions: 24,810
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 171
Telephones—mobile cellular:
total subscriptions: 6,317,965
subscriptions per 100 inhabitants: 56 (2018 est.)
country comparison to the world: 112
Telephone system: general assessment: with the great
population density Burundi remains one of the most
alluring telecom markets in Africa for investors; the
government in early 2018 began the Burundi Broadband
project, which plans to deliver nationwide connectivity by
2025; mobile operators have launched 3G and LTE mobile
services to capitalize on the expanding demand for Internet
access (2018) domestic: telephone density one of the
lowest in the world; fixed-line connections stand at well
less than 1 per 100 persons; mobile-cellular usage is 56 per
100 persons (2018) international: country code—257;
satellite earth station—1 Intelsat (Indian Ocean); the
government, supported by the Word Bank, has backed a
joint venture with a number of prominent telecoms to build
a national fiber backbone network, offering onward
connectivity to submarine cable infrastructure landings in
Kenya and Tanzania (2019) Broadcast media: state-controlled
Radio Television Nationale de Burundi (RITNB) operates a
TV station and a national radio network; 3 private TV
stations and about 10 privately owned radio stations;
transmissions of several international broadcasters are
available in Bujumbura (2019) Internet country code: .bi
Internet users: total: 574,236
percent of population: 5.2% (July 2016 est.)
country comparison to the world: 146
Broadband—fixed subscriptions:
total: 3,935
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 184','23fce2c16fa5d00b72b595b5a750f58497a28acb7bd1664b1d8faf0991b23b47','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a24f601bf05eb9d16f5c4dd1148f63a0274be9dbe22ab0c768e9e8e50e2c9f0',2021,'CV','Cabo Verde','communications',270,'Telephones—fixed lines: total subscriptions: 62,680
subscriptions per 100 inhabitants: 11 (2018 est.)
country comparison to the world: 155
Telephones—mobile cellular:
total subscriptions: 610,328
subscriptions per 100 inhabitants: 107 (2018 est.)
country comparison to the world: 168
Telephone system: general assessment: good _ system,
extensive modernization from 1996-2000 following partial
privatization in 1995; major service provider is Cabo Verde
Telecom (CVT) (2018) domestic: 11 per 100 fixed-line and
107 per 100 mobile-cellular; fiber-optic ring, completed in
2001, links all islands providing Internet access and ISDN
services; cellular service introduced in 1998; broadband
services launched early in the decade; moving to 4G (2018)
international: country code-238; landing points for the
Atlantis-2, EllaLink, Cabo Verde Telecom Domestic
Submarine Cable Phase 1, 2, 3 and WACS fiber-optic
transatlantic telephone cable that provides links to South
America, Africa, and Europe; HF radiotelephone to Senegal
and Guinea-Bissau; satellite earth station—1 Intelsat
(Atlantic Ocean) (2019) Broadcast media: state-run TV and
radio broadcast network plus a growing number of private
broadcasters; Portuguese public TV and radio services for
Africa are available; transmissions of a few international
broadcasters are available (2019) Internet country code: .CV
Internet users: total: 266,562
percent of population: 48.2% (July 2016 est.)
country comparison to the world: 161
Broadband—fixed subscriptions:
total: 15,657
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 161','218823eb30cbe348fd43f914c8d91b40bcee7f26d1cef8ff5823a681e77cbe16','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d299d3656e6d6cb288a2856736adf17aa91e6c2be49339aa60098072efd07d72',2021,'TH','Thailand','communications',275,'Telephones—fixed lines: total subscriptions: 88,157
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 143
Telephones—mobile cellular:
total subscriptions: 19,417,123
subscriptions per 100 inhabitants: 118 (2018 est.)
country comparison to the world: 60
Telephone system: general assessment: adequate fixed-line
and/or cellular service in Phnom Penh and other provincial
cities; mobile-cellular phone systems are widely used in
urban areas to bypass deficiencies in the fixed-line
network; mobile-phone coverage is rapidly spreading in
rural areas; about 50% of Cambodians own at least one
smart phone; in 2018 the MPTC began a free Wi-Fi service
for visitors and residents of Phnom Penh, in selected parks
around the city customers can access free Wi-Fi services
(2018) domestic: fixed-line connections stand at about 1
per 100 persons and declining; mobile-cellular usage, aided
by competition among service providers, has increased to
about 118 per 100 persons; in 2021 Cambodia hopes to
launch it first communications satellite into orbit; fixed
broadband penetration is predicted to reach over 2% by
2023 (2018) international: country code—855; landing
points for MCT and AAE-1 via submarine cables providing
communication to Asia, the Middle East, Europe and Africa;
adequate but expensive landline and cellular service
available to all countries from Phnom Penh and major
provincial cities; satellite earth station—1 Intersputnik
(Indian Ocean region) (2019) Broadcast media: mixture of
state-owned, joint public-private, and privately owned
broadcast media; 27 TV broadcast stations with most
operating on multiple channels, including 1 state-operated
station broadcasting from multiple locations, 11 stations
either jointly operated or privately owned with some
broadcasting from several locations; multi-channel cable
and satellite systems are available (2019); 84 radio
broadcast stations—1 state-owned broadcaster with
multiple stations and a large mixture of public and private
broadcasters; one international broadcaster is available
(2019) as well as one Chinese joint venture television
station with the Ministry of Interior; several television and
radio operators broadcast online only (often via Facebook)
(2019) Internet country code: .kh
Internet users: total: 4,080,372
percent of population: 25.6% (July 2016 est.)
country comparison to the world: 86
Broadband—fixed subscriptions:
total: 166,200
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 114','020ca0e63f6dfc584c70f1ba44b528621e093ebfb786f357991b37894212306b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37e0d83df695f50604f1457dfd2131394a077265499782e484954a9d4fda3aba',2021,'CM','Cameroon','communications',288,'Telephones—fixed lines: total subscriptions: 902,253
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 79
Telephones - mobile cellular:
total subscriptions: 18,455,836
subscriptions per 100 inhabitants: 70 (2018 est.)
country comparison to the world: 62
Telephone system: general assessment: equipment is old and
outdated, and connections with many parts of the country
are unreliable; 3G service and LTE service both developing
given growing competition, along with a fast-developing
mobile broadband sector (2018) domestic: only about 3 per
100 persons for fixed-line subscriptions; mobile-cellular
usage has increased sharply, reaching a subscribership
base of over 70 per 100 persons (2018) international:
country code—237; landing points for the SAT-3/WASC,
SAIL, ACE, NCSCS, Ceiba-2, and WACS fiber-optic
submarine cable that provides connectivity to Europe,
South America, and West Africa; satellite earth stations—2
Intelsat (Atlantic Ocean); (2019) Broadcast media:
government maintains tight control over broadcast media;
state-owned Cameroon Radio’ Television (CRIV),
broadcasting on both a TV and radio network, was the only
officially recognized and fully licensed broadcaster until
August 2007, when the government finally issued licenses
to 2 private TV broadcasters and 1 private radio
broadcaster; about 70 privately owned, unlicensed radio
stations operating but are subject to closure at any time;
foreign news services required to partner with state-owned
national station (2019) Internet country code: .cm
Internet users: total: 6,090,201
percent of population: 25% (July 2016 est.)
country comparison to the world: 67
Broadband—fixed subscriptions:
total: 17,987
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 156
Telephones—fixed lines: total subscriptions: 17,000
subscriptions per 100 inhabitants: less than 1 (July 2016
est.)
country comparison to the world: 183
Telephones—mobile cellular:
total subscriptions: 5 million
subscriptions per 100 inhabitants: 99 (2018 est.)
country comparison to the world: 121
Telephone system: general assessment: primary network
consists of microwave radio relay and coaxial cable with
services barely adequate for government use; key
exchanges are in Brazzaville, Pointe-Noire, and Loubomo;
intercity lines frequently out of order (2018) domestic:
fixed-line infrastructure inadequate, providing less than 1
fixed-line connection per 100 persons; in the absence of an
adequate fixed-line infrastructure, mobile-cellular
subscribership has surged to 99 per 100 persons (2018)
international: country code—242; WACS submarine cables
to Europe and Western and South Africa; satellite earth
station—1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: 1 state-owned TV and 3 state-owned radio stations;
several privately owned TV and radio stations; satellite TV
service is available; rebroadcasts of several international
broadcasters are available Internet country code: .cg
Internet users: total: 362,000
percent of population: 7.6% (July 2016 est.)
country comparison to the world: 155
Telephones—fixed lines: total subscriptions: 7,800
subscriptions per 100 inhabitants: 75 (July 2016 est.)
country comparison to the world: 198
Telephones—mobile cellular:
total subscriptions: 11,000
subscriptions per 100 inhabitants: 105 (July 2016 est.)
country comparison to the world: 213
Telephone system: general assessment: Telecom Cook Islands
offers international direct dialing, Internet, email, and fax;
individual islands are connected by a combination of
satellite earth stations, microwave systems, and VHF and
HF radiotelephone (2018) domestic: service is provided by
small exchanges connected to subscribers by open-wire,
cable, and fiber-optic cable; 75 per 100 fixed-line, 105 per
100 mobile-cellular (2018) international: country code—
682; the Manatua submarine cable to surrounding islands
of Niue, Samoa, French Polynesia and other Cook Islands,
the topography of the South Pacific region has made
Internet connectivity a serious issue for many of the remote
islands; submarine fiber-optic networks are expensive to
build and maintain; satellite earth station—1 Intelsat
(Pacific Ocean) (2019) Broadcast media: 1 privately owned
TV station broadcasts from Rarotonga providing a mix of
local news and overseas-sourced programs (2019) Internet
country code: .ck
Internet users: total: 5,160
percent of population: 54% (July 2016 est.)
country comparison to the world: 212
Military and Security :: COOK ISLANDS
Military and security forces: NO regular military forces; Cook
Islands Police Service. (2018) military—note: defense is the
responsibility of New Zealand in consultation with the Cook
Islands and at its request TRANSPORTATION
National air transport system:
number of registered air carriers: 1 (2015)
inventory of registered aircraft operated by air carriers: 1
(2015)
Civil aircraft registration country code prefix: E5 (2016)
Airports: 11 (2013)
country comparison to the world: 154
Airports—with paved runways:
total: 1 (2019)
1,524 to 2,437 m: 1
Airports—with unpaved runways:
total: 10 (2013)
1,524 to 2,437 m: 2 (2013)
914 to 1,523 m: 7 (2013)
under 914 m: 1 (2013)
Roadways: total: 295 km (2018)
paved: 207 km (2018)
unpaved: 88 km (2018)
country comparison to the world: 196
Merchant marine: total: 215
by type: bulk carrier 23, container ship 5, general cargo 91,
oil tanker 25, other 71 (2018) country comparison to the
world: 63
Ports and terminals: Major seaport(s): Avatiu','b8be9fafd517a7eb51bb5fa71fb32d500bbf7016557553a4beb02335fa6b2117','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('009f0dd404768aeea2e4e29fbc2fcd8553a36546ff10c6859db04c8fa5d62c38',2021,'CA','Canada','communications',297,'Telephones—fixed lines: total subscriptions: 13.842 million
subscriptions per 100 inhabitants: 37 (2018 est.)
country comparison to the world: 15
Telephones—mobile cellular:
total subscriptions: 33,211,401
subscriptions per 100 inhabitants: 90 (2018 est.)
country comparison to the world: 43
Telephone system: general assessment: excellent service
provided by modern technology; consumer demand for
mobile data services have promted telecos to invest and
advance LTE infrastructure, and further investment in 5G;
government policy has aided the extension of broadband to
rural and regional areas, with the result that services are
almost universally accessible (2018) domestic: 37 per 100
fixed-line; 90 per 100 mobile-cellular; comparatively low
mobile penetration provides further room for growth;
domestic satellite system with about 300 earth stations
(2018) international: country code—1; landing points for
the Nunavut Undersea Fibre Optic Network System,
Greenland Connect, Persona, GIT Atlantic, and Express,
KetchCan 1 Submarine Fiber Cable system, St Pierre and
Miquelon Cable submarine cables providing links to the US
and Europe; satellite earth stations—7 (5 Intelsat—4
Atlantic Ocean and 1 Pacific Ocean, and 2 Intersputnik—
Atlantic Ocean region) (2019) Broadcast media: 2 public TV
broadcasting networks, 1 in English and 1 in French, each
with a large number of network affiliates; several private-
commercial networks also with multiple network affiliates;
overall, about 150 TV stations; multi-channel satellite and
cable systems provide access to a wide range of stations
including US stations; mix of public and commercial radio
broadcasters with the Canadian Broadcasting Corporation
(CBC), the public radio broadcaster, operating 4 radio
networks, Radio Canada International, and radio services
to indigenous populations in the north; roughly 1,119
licensed radio stations (2016) Internet country code: .ca
Internet users: total: 31,770,034
percent of population: 89.8% (July 2016 est.)
country comparison to the world: 22
Broadband—fixed subscriptions:
total: 14,445,606
subscriptions per 100 inhabitants: 39 (2018 est.)
country comparison to the world: 14
—
Whitehorse
.
Valdez
Anchoragey y,
Bethel
’
Washington, D.C.
white House
Scale 1:37,000,000 =
400 Kilometers Theale US Capitol
400 Nes Virginia
(RO2418)
Pentagon
(RO2437)
.
Edmonton
Zé | o Regina
AeoSeattle | —
& Olympia
° Auguste 4s
Bismarck ~J - ro
®
Helena
@Concord
gBopton
2) } a@Pididence
Pierre x @ 4
\\ Lansing Hansford
\\ @ ¥
sy
Detroii BNew York
Philadelphia gs tEntom
}
Cheyenne Harrisburg
~ Lincoln, Des Moines ic \\
s
— UI
‘Ban Francisco. at
®
\\aneaee Carson City Salt Lake City
«
7 Columbus
Indianapolis
® Denver ae
Springfield
Topeka
a Slows, e Charleston
®
Jefferson City.) Frankfort
Las Vegay
.
@ Nashville
hos Angeles Santa Fe ;
® Memphis Columbia
Oklahoma City e. \\
e
Little Rock o Atlanta
Mexicali
\\ Montgomery
_ Dallas +
Austh
® State capital O — .Hermositio pot
Scale 1:27,000,000
Albers Equal-Area Projection . Nie ~
standard parallels 28°30''N and 45°30''N MEXICO - lof : : THE” BAHAMAS
500 Kilometers v , | ¢ v aa b Roane
, Nassau»
“ ~\\
.
.
Houston \\>
»
“Chihuahua
S
., Monterrey
500 Miles
(RO2420!
Midway s
Islands
Kawa!
Scale 1:34,000,000 Honolulu
°
400 Kilometers Oak Se Maul
° 400 Miles Hawaii
(R02419)
WORLD OCEANS','d5a38e8389269895aacc581d794022f6e2a7e6d0870285840789116f97f0af41','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e6b173e62c86c8fe3fd86a851e5062090f16d58f4147b396ad786717cc6f73c',2021,'KY','Cayman Islands','communications',304,'Telephones—fixed lines: total subscriptions: 34,116
subscriptions per 100 inhabitants: 60 (July 2016 est.)
country comparison to the world: 169
Telephones—mobile cellular:
total subscriptions: 95,656
subscriptions per 100 inhabitants: 164 (July 2016 est.)
country comparison to the world: 195
Telephone system: general assessment: reasonably good
overall telephone system with a high fixed-line teledensity;
given the high dependence of tourism and activities such as
fisheries and offshore financial services, the telecom sector
provides a relatively high contribution to overall GDP; good
competion in all sectors promotes advancement in mobile
telephony and data segments (2018) domestic: introduction
of competition in the mobile-cellular market in 2004
boosted subscriptions dramatically; 60 per 100 fixed-line,
164 per 100 mobile-cellular (2018) international: country
code—1-345; landing points for the Maya-1, Deep Blue
Cable, and the Cayman-Jamaica Fiber System submarine
cables that provide links to the US and parts of Central and
South America; satellite earth station—1 Intelsat (Atlantic
Ocean) (2019) Broadcast media: 4 TV stations; cable and
satellite subscription services offer a_ variety of
international programming; government-owned Radio
Cayman operates 2 networks broadcasting on 5 stations; 10
privately owned radio fstations operate alongside Radio
Cayman Internet country code: .ky
Internet users: total: 45,242
percent of population: 79% (July 2016 est.)
country comparison to the world: 196
Broadband—fixed subscriptions:
total: 24,535
subscriptions per 100 inhabitants: 42 (2017 est.)
country comparison to the world: 150','e7e7734bbf196ad50fa423da3f20884ea688c8a2f701afc6fb9a9d1de73b75c1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86481241204ab70ec7eb1039c7c1233f83a7358a9793f29736ee176e401e038b',2021,'CG','Congo','communications',313,'Telephones—fixed lines: total subscriptions: 2,193
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 214
Telephones—mobile cellular:
total subscriptions: 1,279,261
subscriptions per 100 inhabitants: 22 (2018 est.)
country comparison to the world: 157
Telephone system: general assessment: network consists
principally of microwave radio relay and at low-capacity;
ongoing conflict has obstructed telecommunication and
media development, although there are ISP (Internet
service providers) and mobile phone carriers, radio is the
most-popular communications medium (2018) domestic:
very limited telephone service with less than 1 fixed-line
connection per 100 persons; with the presence of multiple
providers mobile-cellular service has reached 22 per 100
mobile-cellular subscribers; cellular usage is increasing
from a low base; most fixed-line and mobile-cellular
telephone services are concentrated in Bangui (2018)
international: country code-236; satellite earth station-1
Intelsat (Atlantic Ocean)
Broadcast media: government-owned network, Radiodiffusion
Television Centrafricaine, provides limited domestic TV
broadcasting; state-owned radio network is supplemented
by a small number of privately owned broadcast stations as
well as a few community radio stations; transmissions of at
least 2 international broadcasters are available (2017)
Internet country code: .cf
Internet users: total: 246,000
percent of population: 4.6% (July 2016 est.)
country comparison to the world: 165
Broadband—fixed subscriptions: total: 608
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 199
Telephones—fixed lines: total subscriptions: 12,960
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 189
Telephones—mobile cellular:
total subscriptions: 9,700,609
subscriptions per 100 inhabitants: 80 (2018 est.)
country comparison to the world: 86
Telephone system: general assessment: small, inadequate
telephone system primarily serves business, education, and
government; government carries out investment in smart
city infrastructure; expands wholesale LTE services (2018)
domestic: the capital, Kigali, is connected to provincial
centers by microwave radio relay and, recently, by cellular
telephone service; much of the network depends on wire
and HF radiotelephone; fixed-line less than 1 per 100 and
mobile-cellular telephone density has increased 74
telephones per 100 persons (2018) international: country
code—250; international connections employ microwave
radio relay to neighboring countries and _ satellite
communications to more distant countries; satellite earth
stations—1 Intelsat (Indian Ocean) in Kigali (includes telex
and telefax service); international submarine fiber-optic
cables on the African east coast has brought international
bandwidth and lessened the dependency on satellites
Broadcast media: 13 TV stations; 35 radio stations registered,
including international broadcasters, government owns
most popular TV and radio stations; regional satellite-based
TV services available Internet country code: .CW
Internet users: total: 3,724,678
percent of population: 29.8% (Dec 2017 est.)
country comparison to the world: 90
Broadband—fixed subscriptions: total: 7,501
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 175
Telephone system: general assessment: fully integrated
access; 4G and LTE services (2018) domestic: direct dial
capability with both fixed and wireless systems (2018)
international: country code—590; landing points for the
SSCS and the Southern Caribbean Fiber submarine cables
providing voice and data connectivity to numerous
Caribbean Islands (2019) Broadcast media: no local TV
broadcasters; 3 FM radio channels (2019)
Internet country code: .bl; note—.gp, the Internet country code
for Guadeloupe, and .fr, the Internet country code for
France, might also be encountered MILITARY AND
SECURITY
Military—note: defense is the responsibility of France
Telephones—fixed lines: total subscriptions: 576
subscriptions per 100 inhabitants: 35 (July 2016 est.)
country comparison to the world: 217
Telephones—mobile cellular:
total subscriptions: 3,018
subscriptions per 100 inhabitants: 39 (July 2016 est.)
country comparison to the world: 218
Telephone system: general assessment: can communicate
worldwide; ADSL-broadband service; LTE service; Wi-Fi
hotspots in Jamestown, 1 ISP many services are not offered
locally but made available for visitors (2018) domestic:
automatic digital network; fixed-line 35 per 100 and
moblie-cellular 39 per 100 persons (2018) international:
country code (Saint Helena)—290, (Ascension Island)—247;
landing point for the SaEx1l submarine cable providing
connectivity to South Africa, Brazil, Virginia Beach (US)
and islands in Saint Helena, Ascension and Tristan de
Cunha; international direct dialing; satellite voice and data
communications; satellite earth stations—5 (Ascension
Island—4, Saint Helena—1) (2019) Broadcast media: Saint
Helena has no local TV station; 2 local radio stations, one of
which is relayed to Ascension Island; satellite TV stations
rebroadcast terrestrially; Ascension Island has no local TV
station but has 1 local radio station and receives relays of
broadcasts from 1 radio station on Saint Helena;
broadcasts from the British Forces Broadcasting Service
(BFBS) are available, as well as TV services for the US
military; Tristan da Cunha has 1 local radio station and
receives BFBS TV and radio broadcasts Internet country code:
.sh; note—Ascension Island assigned .ac
Internet users: total: 1,800
percent of population: 23.1% (July 2016 est.)
country comparison to the world: 220
Broadband—fixed subscriptions:
total: 1,347
subscriptions per 100 inhabitants: 17 (2017 est.)
country comparison to the world: 193
Communications—note: Ascension Island hosts one of four
dedicated ground antennas that assist in the operation of
the Global Positioning System (GPS) navigation system (the
others are on Diego Garcia (British Indian Ocean Territory),
Kwajalein (Marshall Islands), and at Cape Canaveral,
Florida (US)); South Africa maintains a meteorological
station on Gough Island in the Tristan da Cunha
archipelago MILITARY AND SECURITY
Military—note: defense is the responsibility of the UK
metric ton
Mt.
NA
NAFTA
NAM
NATO
NC
NEA
NEGL
NGA
NGO
NIB
NIC
NIE
NIS
nm
NMT
NSG
Nuclear Test Ban
NZ
OAPEC
OAS
OAU
ODA
OECD
OECS
OHCHR
OIC
OIF
Mount
not available
North American Free Trade Agreement
Nonaligned Movement
North Atlantic Treaty Organization
Nordic Council
Nuclear Energy Agency
negligible
National Geospatial-Intelligence Agency
nongovernmental organization
Nordic Investment Bank
newly industrializing country
newly industrializing economy
new independent states
nautical mile
Nordic Mobile Telephone
Nuclear Suppliers Group
Treaty Banning Nuclear Weapons Tests in the
Atmosphere, in Outer Space, and Under
Water','a4a196909a2d9cca50db08f2b1eaf5d5e633b578b279265c3a726c2a994670c8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa1d34f41391aecdefe4052388652ca8741e1087827765a73f24007b5e6fab1',2021,'TD','Chad','communications',322,'Telephones—fixed lines: total subscriptions: 9,036
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 193
Telephones—mobile cellular:
total subscriptions: 6,984,130
subscriptions per 100 inhabitants: 44 (2018 est.)
country comparison to the world: 108
Telephone system: general assessment: inadequate system of
radio telephone communication stations with high
maintenance costs and low telephone density; Chad
remains one of the least developed on the African
continent, telecom infrastructure is particularly low, with
penetration rates in all sectors-fixed, mobile and Internet -
well below African averages (2018) domestic: fixed-line
connections less than 1 per 100 persons, with mobile-
cellular subscribership base of about 44 per 100 persons
(2018) international: country code—235; satellite earth
station—1 Intelsat (Atlantic Ocean)
Broadcast media: 1 state-owned TV station; 2 privately-
owned TV __ stations; state-owned _ radio network,
Radiodiffusion Nationale Tchadienne (RNT), operates
national and regional stations; over 10 private radio
stations; some _ stations rebroadcast programs from
international broadcasters (2017) Internet country code: .td
Internet users: total: 592,623
percent of population: 5% (July 2016 est.)
country comparison to the world: 145
Broadband—fixed subscriptions: total: 334
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 202','ceefddb022a7b4764423699a40203695d713667e76c9416756b907d517c82e27','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecf92ca3b573bebb93e6854c56a484a7490750412144c9e7cc7ad7c62163b701',2021,'CN','China','communications',339,'Telephones—fixed lines: total subscriptions: 192.085 million
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 1
Telephones—mobile cellular:
total subscriptions: 1,649,301,700
subscriptions per 100 inhabitants: 119 (2018 est.)
country comparison to the world: 1
Telephone system: general assessment: China has become the
largest Internet market in the world, with the majority,
98.6%, of users accessing the Internet through mobile
devices; moderate growth is predicted over the next five
years in the fixed broadband segment; one of the biggest
drivers of commercial growth is its increasing urbanisation
rate as rural residents move to cities; China will be the
world’s largest 5G market (2018) domestic: 14 per 100
fixed line and 119 per 100 mobile-cellular; a domestic
satellite system with several earth stations has been in
place since 2018 (2018) international: country code—86;
landing points for the RJCN, EAC-C2C, TPE, APCN-2, APG,
NCP TEA, SeaMeWe-3, SJC2, Taiwan Strait Express-1,
AAEF-1, APCN-2, AAG, FEA, FLAG and TSE submarine
cables providing connectivity to Asia, the Middle East,
Europe, and the US; satellite earth stations—7 (5 Intelsat—
4 Pacific Ocean and 1 Indian Ocean; 1 Intersputnik—Indian
Ocean region; and 1 Inmarsat—Pacific and Indian Ocean
regions) (2019) Broadcast media: all broadcast media are
owned by, or affiliated with, the Communist Party of China
or a government agency; no privately owned TV or radio
stations; state-run Chinese Central TV, provincial, and
municipal stations offer more than 2,000 channels; the
Central Propaganda Department sends directives to all
domestic media outlets to guide its reporting with the
government maintaining authority to approve all
programming; foreign-made TV programs must be
approved prior to broadcast; increasingly, Chinese turn to
online and satellite television to access Chinese and
international films and television shows (2019) Internet
country code: .cCn
Internet users: total: 730,723,960
percent of population: 53.2% (July 2016 est.)
country comparison to the world: 1
Broadband—fixed subscriptions:
total: 407.382 million
subscriptions per 100 inhabitants: 29 (2018 est.)
country comparison to the world: 1
Telephone system: general assessment: service provided by
the Australian network domestic: local area code—08; GSM
mobile-cellular telephone service is provided by Telstra as
part of the Australian network international: international
code—61 8; ASC submarine cable to Singapore and
Australia; satellite earth station—1 (Intelsat provides
telephone and telex service) (2019) Broadcast media: 1
community radio station; satellite broadcasts of several
Australian radio and TV stations (2017)
Internet country code: .CX
Internet users: total: 790
percent of population: 35.8% (July 2016 est.)
country comparison to the world: 224
Telephones—fixed lines: total subscriptions: 4,196,061
subscriptions per 100 inhabitants: 58 (2018 est.)
country comparison to the world: 35
Telephones—mobile cellular:
total subscriptions: 19,901,856
subscriptions per 100 inhabitants: 276 (2018 est.)
country comparison to the world: 59
Telephone system: general assessment: modern facilities
provide excellent domestic and international services; some
of the highest peak average broadband speeds in the world;
HK aims to be among the earliest adopters of 5G mobile
technology as early as 2020; almost all households have
access to high-speed broadband connectivity; in the next
five years the government has organized the development
of ‘smart cities’ in six areas—”smart mobility”, “smart
living”, “smart environment”, “smart people”, “smart
government”, and “smart economy” by 2022 (2018)
domestic: microwave radio relay links and extensive fiber-
optic network; fixed-line is 59 per 100 and mobile-cellular
is 255 per 100 (2018) international: country code—852;
APG, ASE, EAC-C2C, HK-G, Bay-to-Bay Express Cable
System, H2 Cable, HKA, SJC, SJC2, PLCN, SeaMeWe-3,
TGN-IA, APCN-2, AAG, FLAG and FEA submarine cables
provide connections to Asia, US, Australia, the Middle East,
and Europe; satellite earth stations—3 Intelsat (1 Pacific
Ocean and 2 Indian Ocean); coaxial cable to Guangzhou,
China (2019) Broadcast media: 4 Commercial terrestrial TV
networks each with multiple’ stations; multi-channel
satellite and cable TV systems available; 3 licensed
broadcasters of terrestrial radio, one of which is
government funded, operate about 12 radio stations; note—
4 digital radio broadcasters operated in Hong Kong from
2010 to 2017, but all digital radio services were terminated
in September 2017 due to weak market demand (2019)
Internet country code: .hk
Internet users: total: 6.066 million
percent of population: 85% (July 2016 est.)
country comparison to the world: 68
Broadband—fixed subscriptions:
total: 2,714,679
subscriptions per 100 inhabitants: 38 (2018 est.)
country comparison to the world: 45
Telephones—fixed lines: total subscriptions: 3,016,878
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 46
Telephones—mobile cellular:
total subscriptions: 10,041,939
subscriptions per 100 inhabitants: 102 (2018 est.)
country comparison to the world: 85
Telephone system: general assessment: modern telephone
system is digital and highly automated; trunk services are
carried by fiber-optic cable and digital microwave radio
relay; regulator preps for 5G spectrum auction in 2019
(2018) domestic: competition among mobile-cellular service
providers has led to a sharp increase in the use of mobile-
cellular phones, 122 per 100, and a decrease in the number
of fixed-line connections, 32 per 100 persons (2018)
international: country code—36; Hungary has fiber-optic
cable connections with all neighboring countries; the
international switch is in Budapest; satellite earth stations
—2 Intelsat (Atlantic Ocean and Indian Ocean regions), 1
Inmarsat, 1 very small aperture terminal (VSAT) system of
ground terminals Broadcast media: mixed system of state-
supported public service broadcast media and private
broadcasters; the 5 publicly owned TV channels and the 2
main privately owned TV stations are the major national
broadcasters; a large number of special interest channels;
highly developed market for satellite and cable TV services
with about two-thirds of viewers utilizing their services; 4
state-supported public-service radio networks; a large
number of local stations including commercial, public
service, nonprofit, and community radio stations; digital
transition completed at the end of 2013; government-linked
businesses have’ greatly consolidated ownership in
broadcast and print media Internet country code: .hu
Internet users: total: 7,826,695
percent of population: 79.3% (July 2016 est.)
country comparison to the world: 54
Broadband—fixed subscriptions:
total: 3,079,549
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 42
Telephones—fixed lines: total subscriptions: 136,713
subscriptions per 100 inhabitants: 40 (2018 est.)
country comparison to the world: 132
Telephones—mobile cellular:
total subscriptions: 424,720
subscriptions per 100 inhabitants: 124 (2018 est.)
country comparison to the world: 175
Telephone system: general assessment: telecommunications
infrastructure is modern and fully digitized, with satellite-
earth stations, fiber-optic cables, and an _ extensive
broadband network; LTE licenses providing 99% population
coverage (2018) domestic: liberalization of the
telecommunications sector beginning in the late 1990s has
led to increased competition especially in the mobile
services segment of the market; 43 per 100 for fixed line
and 121 per 100 for mobile-cellular subscriptions (2018)
international: country code—354; the CANTAT-3, FARICE-1,
Greenland Connect and DANICE submarine cable system
provides connectivity to Canada, the Faroe Islands,
Greenland, UK, Denmark, and Germany; satellite earth
stations—2 Intelsat (Atlantic Ocean), 1 Inmarsat (Atlantic
and Indian Ocean regions); note—Iceland shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden) (2019) Broadcast
media: State-owned public TV broadcaster (RUV) operates
21 TV channels nationally (RUV and RUV 2, though RUV 2
is used less frequently); RUV broadcasts nationally, every
household in Iceland is required to have RUV as it doubles
as the emergency broadcast network; RUV also operates
stringer offices in the north (Akureyri) and the east
(Egilsstadir) but operations are all run out of RUV
headquarters in Reykjavik; there are 3 privately owned TV
stations; Stod 2 (Channel 2) is owned by Syn, following 365
Media and Vodafone merger, and is headquartered in
Reykjavik; Syn also operates 4 sports channels under Stod
2; N4 is the only television station headquartered outside of
Reykjavik, in Akureyri, with local programming for the
north, south, and east of Iceland; Hringbraut is the newest
station and is headquartered in Reykjavik; all of these
television stations have nationwide penetration as 100% of
households have multi-channel services though digital
and/or fiber-optic connections RUV operates 3 radio
stations (RAS 1, RAS2, and Rondo) as well as 4 regional
stations (but they mostly act as range extenders for RUV
radio broadcasts nationwide); there is 1 privately owned
radio conglomerate, Syn (4 stations), that broadcasts
nationwide, and 3 other radio stations that broadcast to the
most densely populated regions of the country. In addition
there are upwards of 20 radio stations that operate
regionally (2019) Internet country code: .iS
Internet users: total: 329,967
percent of population: 98.2% (July 2016 est.)
country comparison to the world: 156
Broadband—fixed subscriptions:
total: 136,556
subscriptions per 100 inhabitants: 40 (2018 est.)
Telephones—fixed lines: total subscriptions: 21,868,192
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 11
Telephones—mobile cellular:
total subscriptions: 1,176,021,869
subscriptions per 100 inhabitants: 91 (2018 est.)
country comparison to the world: 2
Telephone system: general assessment: supported by
deregulation and liberalization of telecommunications laws
and policies, India has emerged as one of the fastest-
growing telecom markets in the world; implementation of
4G/LTE services shift to data services across the country;
steps taken towards 5G _ services; fixed broadband
penetration is expected to grow at a moderate rate over the
next five years to 2023 (2018) domestic: fixed-line
subscriptions stands at 2 per 100 and mobile-cellular at 91
per 100; mobile cellular service introduced in 1994 and
organized nationwide into four metropolitan areas and 19
telecom circles, each with multiple private’ service
providers and one or more state-owned service providers;
in recent years significant trunk capacity added in the form
of fiber-optic cable and one of the world’s largest domestic
satellite systems, the Indian National Satellite system
(INSAT), with 6 satellites supporting 33,000 very small
aperture terminals (VSAT) (2018) international: country
code—91; a number of major international submarine cable
systems, including SEA-ME-WE-3 & 4, AAE-1, BBG, EIG,
FALCON, FEA, GBICS, MENA, IMEWE, SEACOM/ Tata
TGN-Eurasia, SAFE, WARF, Bharat Lanka Cable System,
IOX, Chennai-Andaman & Nicobar Island Cable, SAEx2,
Tata TGN-Tata Indicom and i2icn submarine cables to
Europe, Africa, Asia, the Middle East, South East Asia,
numerous Indian Ocean islands including Australia;
satellite earth stations—8 Intelsat (Indian Ocean) and 1
Inmarsat (Indian Ocean region (2019) Broadcast media:
Doordarshan, India’s public TV network, has a monopoly on
terrestrial broadcasting and operates about 20 national,
regional, and local services; a large and increasing number
of privately owned TV stations are distributed by cable and
satellite service providers; in 2015, more than 230 million
homes had access to cable and satellite TV offering more
than 700 TV channels; government controls AM radio with
All India Radio operating domestic and external networks;
news broadcasts via radio are limited to the All India Radio
Network; since 2000, privately owned FM stations have
been permitted and their numbers have increased rapidly
Internet country code: .iN
Internet users: total: 374,328,160
percent of population: 29.5% (July 2016 est.)
country comparison to the world: 2
Broadband—fixed subscriptions: total: 18.17 million
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 11
Telephones—fixed lines: total subscriptions: 8,303,511
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 19
Telephones—mobile cellular:
total subscriptions: 319,434,605
subscriptions per 100 inhabitants: 122 (2018 est.)
country comparison to the world: 4
Telephone system: general assessment: domestic service
includes an interisland microwave system, an HF radio
police net, and a domestic satellite communications system;
international service good; Indonesia has very low fixed
line and fixed broadband penetration, high mobile
penetration and moderate mobile broadband penetration
(2018) domestic: fixed-line 4 per 100 and mobile-cellular
175 per 100 persons; coverage provided by existing
network has been expanded by use of over 200,000
telephone kiosks many located in remote areas; mobile-
cellular subscribership growing rapidly (2018)
international: country code—62; landing points for the SEA-
ME-WE-3 & 5, DAMAI, JASUKA, BDM, Dumai-Melaka Cable
System, IGG, JIBA, Link 1, 3, 4, & 5, PGASCOM, B3J2,
Tanjung Pandam-Sungai Kakap Cable System, JAKABARE,
JAYABAYA, INDIGO-West, Matrix Cable System, ASC, SJJK,
Jaka2LaDeMa, S-U-B Cable System, JBCS, MKCS, BALOK,
Palapa Ring East, West and Middle, SMPCS Packet-1 and 2,
LTCS, TSCS, SEA-US and Kamal Domestic Submarine
Cable System, 35 submarine cable networks that provide
links throughout Asia, the Middle East, Australia, Southeast
Asia, Africa and Europe; satellite earth stations—2 Intelsat
(1 Indian Ocean and 1 Pacific Ocean) (2019) Broadcast media:
mixture of about a dozen national TV networks—1 public
broadcaster, the remainder private broadcasters—each
with multiple transmitters; more than 100 local TV stations;
widespread use of satellite and cable TV systems; public
radio broadcaster operates 6 national networks, as well as
regional and local stations; overall, more than 700 radio
stations with more than 650 privately operated (2019)
Internet country code: .id
Internet users: total: 65,525,226
percent of population: 25.4% (July 2016 est.)
country comparison to the world: 10
Broadband—fixed subscriptions:
total: 8,874,116
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 20
Telephones—fixed lines: total subscriptions: 30,481,734
subscriptions per 100 inhabitants: 37 (2018 est.)
country comparison to the world: 8
Telephones—mobile cellular:
total subscriptions: 88,722,442
subscriptions per 100 inhabitants: 107 (2018 est.)
country comparison to the world: 18
Telephone system: general assessment: opportunities for
telecoms growth, but the disadvantage of lack of significant
investment; one of the largest populations in the Middle
East with a huge demand for services; mobile penetration
is high with over 93% accessing 3G, and 4G LTE becoming
available; Iranian-net, is currently expanding a fiber
network to have 8 million customers by 2020 (2018)
domestic: 38 per 100 for fixed-line (2017 est.) and 140 per
100 (2019 est.) for mobile-cellular subscriptions; heavy
investment by Iran’s state-owned telecom company has
greatly improved and expanded both the fixed-line and
mobile cellular networks; a huge percentage of the cell
phones in the market have been smuggled into the country
(2019) international: country code—98; landing points for
Kuwait-Iran, GBICS & MENA, FALCON, OMRAN/3PEG
Cable System, POI and UAE-Iran submarine fiber-optic
cable to the Middle East, Africa and India; Trans-Asia-
Europe (TAE) fiber-optic line runs from Azerbaijan through
the northern portion of Iran to Turkmenistan with
expansion to Georgia and Azerbaijan; HF radio and
microwave radio relay to Turkey, Azerbaijan, Pakistan,
Afghanistan, Turkmenistan, Syria, Kuwait, Tajikistan, and
Uzbekistan; satellite earth stations—13 (9 Intelsat and 4
Inmarsat) (2019) Broadcast media: state-run broadcast media
with no private, independent broadcasters; Islamic
Republic of Iran Broadcasting (IRIB), the state-run TV
broadcaster, operates 19 nationwide channels including a
news channel, about 34 provincial channels, and several
international channels; about 20 foreign Persian-language
TV stations broadcasting on satellite TV are capable of
being seen in Iran; satellite dishes are illegal and, while
their use is subjectively tolerated, authorities confiscate
satellite dishes from time to time; IRIB operates 16
nationwide radio networks, a number of provincial stations,
and an external service; most major international
broadcasters transmit to Iran (2019) Internet country code: .ir
Internet users: total: 67.6 million
percent of population: 82% (Dec 2019 est.)
country comparison to the world: 9
Broadband—fixed subscriptions:
total: 9,806,123
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 18
Telephones—fixed lines: total subscriptions: 2,705,028
subscriptions per 100 inhabitants: 7 (2018 est.)
country comparison to the world: 51
Telephones—mobile cellular:
total subscriptions: 36,527,353
subscriptions per 100 inhabitants: 98 (2018 est.)
country comparison to the world: 40
Telephone system: general assessment: the 2003 liberation of
Iraq severely disrupted telecommunications throughout
Iraq; widespread government efforts to rebuild domestic
and international communications have slowed due _ to
political unrest; 2018 showed signs of stability and
installations of new fibre-optic cables and growth in mobile
broadband subscribers; the most popular plans are pre-
paid (2018) domestic: the mobile cellular market continues
to expand; 3G services offered by three major mobile
operators; 4G offered by one operator in Iraqi Kurdistan
Region; conflict has destroyed infrastructure in areas; 7 per
100 for fixed-line and 85 per 100 for mobile-cellular
subscriptions (2018) international: country code—964;
landing points for FALCON, and GBICS/MENA submarine
cables providing connections to the Middle East, Africa and
India; satellite earth stations—4 (2 Intelsat—1 Atlantic
Ocean and 1 Indian Ocean, 1 Intersputnik—Atlantic Ocean
region, and 1 Arabsat (inoperative)); local microwave radio
relay connects border regions to Jordan, Kuwait, Syria, and
Turkey (2019) Broadcast media: the number of private radio
and TV stations has increased rapidly since 2003;
government-owned TV and radio stations are operated by
the publicly funded Iraqi Media Network; private broadcast
media are mostly linked to political, ethnic, or religious
groups; satellite TV is available to an estimated 70% of
viewers and many of the broadcasters are based abroad;
transmissions of multiple international radio broadcasters
are accessible (2019) Internet country code: .iq
Internet users: total: 8,098,401
percent of population: 21.2% (July 2016 est.)
country comparison to the world: 53
Broadband—fixed subscriptions:
total: 4,492,328
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 32
Telephones—fixed lines: total subscriptions: 123,469
subscriptions per 100 inhabitants: 20 (2018 est.)
country comparison to the world: 137
Telephones—mobile cellular:
total subscriptions: 2,181,194
subscriptions per 100 inhabitants: 360 (2018 est.)
country comparison to the world: 148
Telephone system: general assessment: modern
communication facilities maintained for domestic and
international services; high mobile subscriber numbers and
mobile penetration with 4 network operators and a mobile
virtual network operator (MNVO), offering 4 G and LTE
services; 5G wireless technology for commercial use in
2020, possible synchronizing with neighboring regions
(2018) domestic: fixed-line 20 per 100 and mobile-cellular
344 per 100 persons (2018)
international: country code—853; landing point for the
SEA-ME-WE-3 submarine cable network that provides links
to Asia, Africa, Australia, the Middle East, and Europe; HF
radiotelephone communication facility; satellite earth
station—1 Intelsat (Indian Ocean) (2019) Broadcast media:
local government dominates broadcast media; 2 television
stations operated by the government with one broadcasting
in Portuguese and the other in Cantonese and Mandarin; 1
cable TV and 4 satellite TV services available; 3 radio
stations broadcasting, of which 2 are government-operated
(2019) Internet country code: .mo
Internet users: total: 460,000
percent of population: 77.6% (July 2016 est.)
country comparison to the world: 149
Broadband—fixed subscriptions: total: 193,057
subscriptions per 100 inhabitants: 32 (2018 est.)
country comparison to the world: 108
Collective Security Treaty Organization (CSTO)
established—7 October 2002
aim—to coordinate military and political cooperation, to develop multilateral
structures and mechanisms of cooperation for ensuring national security of the
member states
members—(7) Armenia, Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan,
Sear, hi
foe
*reD. STATES or
“ISLANDS . Sulta Se an de Oro .
Zamboan;
ghtelekeok CONTI
Bandar Seri er PALAU
: ; : North
EPULAUAN Celebes sc 5
ae MA Pacific
Ocean
allton
Java Sea
IN DON
Madura
lores|Sea
Flores
yt -
EAST TIMOR
ae Thwor
Timor
Ashmore and
Cartier Islands
(AUSTRALIA)
Indian Ocean
Scale 1:32,000,000
Mercator Projection
500 kilometers
500 miles
Boundary representation is not necessarily authoritative.
Names in Vietnam are shown without diacritical marks.','5de922151246927880939557e1fad052456a185925d079ba0cb1501a537172ff','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47c6dcd095abe1928ab428e02358ebb9d5740e46e8ff0d79e3040bf2cf2d7da2',2021,'CC','Cocos (Keeling) Islands','communications',351,'Telephone system: general assessment: telephone service is
part of the Australian network; an operational local mobile-
cellular network available; wireless Internet connectivity
available domestic: local area code—08
international: international code—61 8; telephone, telex,
and facsimile communications with Australia and elsewhere
via satellite; satellite earth station—1 (Intelsat) Broadcast
media: 1 local radio station staffed by community
volunteers; satellite broadcasts of several Australian radio
and TV stations available (2017) Internet country code: . CC','db1022ca56928cea8611635c5838bfdace094c3de0e0ea7a0f9c582ae40a3f16','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e050d63cead8c39061ffd49245b0e89131920655449beed86ecf627e821bf9a5',2021,'AO','Angola','communications',362,'Telephones—fixed lines: total subscriptions: 0 NA
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 219
Telephones—mobile cellular:
total subscriptions: 36,470,600
subscriptions per 100 inhabitants: 38 (2018 est.)
country comparison to the world: 41
Telephone system: general assessment: barely adequate wire
and microwave radio relay service in and between urban
areas; domestic satellite system with 14 earth stations;
inadequate fixed-line infrastructure; efforts have been
made to improve regulating the telecom sector; wars and
social upheaval have not promoted advancement; a revised
Telecommunications Act adopted in May 2018 (2018)
domestic: fixed-line connections less than 1 per 100
persons; given the backdrop of a wholly inadequate fixed-
line infrastructure, the use of mobile-cellular services is
over 38 per 100 persons (2018) international: country code
—243; ACE and WACS submarine cables to West and South
Africa and Europe; satellite earth station—1 Intelsat
(Atlantic Ocean) (2019) Broadcast media: state-owned TV
broadcast station with near national coverage; more than a
dozen privately owned TV stations—2 with near national
coverage; 2 state-owned radio stations are supplemented
by more than 100 private radio stations; transmissions of at
least 2 international broadcasters are available Internet
country code: .cd
Internet users: total: 3.016 million
percent of population: 3.8% (July 2016 est.)
country comparison to the world: 96
Broadband—fixed subscriptions:
total: 4,620
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 181
Telephones—fixed lines: total subscriptions: 154,816
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 127
Telephones—mobile cellular:
total subscriptions: 2,759,293
subscriptions per 100 inhabitants: 109 (2018 est.)
country comparison to the world: 144
Telephone system: general assessment: good system; core
fiber-optic network links most centers with digital
connections; 3G and LTE services; Internet and broadband
sector fairly competitive; infrastructure investment through
2021 (2018) domestic: fixed-line still a government
monopoly with plans to open to competition soon; multiple
mobile-cellular providers; fixed-line subscribership of 8 per
100 and mobile-cellular 107 per 100 persons (2019)
international: country code—264; landing points for the
ACE and WACS fiber-optic submarine cable linking
southern and western African countries to Europe; satellite
earth stations—4 Intelsat (2019) Broadcast media: 1 private
and 1 state-run TV station; satellite and cable TV service
available; state-run radio service broadcasts in multiple
languages; about a dozen private radio _ stations;
transmissions of multiple international broadcasters
available Internet country code: .na
Internet users: total: 756,118
percent of population: 31% (July 2016 est.)
country comparison to the world: 139
Broadband—fixed subscriptions:
total: 61,968
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 131','ce1dc5cf8fc2790907ff4ef2bd840ecc6110c9ddcc2f9db3c91894089d326a62','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a3d19e16eb886786de938336e74e06a08b0082ed2d33d4a89ea2ad117561ab',2021,'AU','Australia','communications',367,'Communications—note: automatic weather stations on many of
the isles and reefs relay data to the mainland MILITARY
AND SECURITY
Military—note: defense is the responsibility of Australia
Telephones—fixed lines: total subscriptions: 92,000
subscriptions per 100 inhabitants: 34 (July 2016 est.)
country comparison to the world: 141
Telephones—mobile cellular:
total subscriptions: 246,000
subscriptions per 100 inhabitants: 91 (July 2016 est.)
country comparison to the world: 182
Telephone system: general assessment: well advanced
telecoms sector; 4G network services (2018) domestic:
fixed-line 34 per 100 and mobile-cellular telephone
subscribership 91 per 100 persons (2018) international:
country code—687; landing points for the Gondwana-1 and
Picot-1 providing connectivity via submarine cables around
New Caledonia and to Australia; satellite earth station—1
Intelsat (Pacific Ocean) (2019) Broadcast media: the publicly
owned French Overseas Network (RFO), which operates in
France’s overseas departments and territories, broadcasts
over the RFO Nouvelle-Calédonie TV and radio stations; a
small number of privately owned radio stations also
broadcast Internet country code: .NC
Internet users: total: 201,000
percent of population: 74% (July 2016 est.)
country comparison to the world: 169
Telephones—fixed lines: total subscriptions: 1.76 million
subscriptions per 100 inhabitants: 37 (2018 est.)
country comparison to the world: 61
Telephones—mobile cellular:
total subscriptions: 6.4 million
subscriptions per 100 inhabitants: 134 (2018 est.)
country comparison to the world: 110
Telephone system: general assessment: excellent domestic
and international systems; mobile and P2P services soar;
LTE rates some of the fastest in the world; investment and
development of infrastructure enable network capabilities
to propel the digital economy, digital media sector along
with e-government, e-commerce across the country (2018)
domestic: fixed-line 30 per 100 and _ mobile-cellular
telephone subscribership 142 per 100 persons (2018)
international: country code—64; landing points for the
Southern Cross NEXT, Aqualink, Nelson-Levin, SCCN and
Hawaiki submarine cable system providing links to
Australia, Fiji, American Samoa, Kiribati, Samo, Tokelau,
US and around New Zealand; satellite earth stations—8 (1
Inmarsat—Pacific Ocean, 7 other) (2019) Broadcast media:
state-owned Television New Zealand operates multiple TV
networks and state-owned Radio New Zealand operates 3
radio networks and an external shortwave radio service to
the South Pacific region; a small number of national
commercial TV and radio stations and many regional
commercial television and radio stations are available;
cable and satellite TV systems are available, as are a range
of streaming services (2019) Internet country code: .nZ
Internet users: total: 3,958,642
percent of population: 88.5% (July 2016 est.)
country comparison to the world: 88
Broadband—fixed subscriptions:
total: 1.647 million
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 59
Telephone system: general assessment: adequate
domestic: free local calls
international: country code—672; submarine cable links
with Australia and New Zealand; satellite earth station—1
Broadcast media: 1 local radio station; broadcasts of several
Australian radio and TV stations available via satellite
(2009) Internet country code: .nf
Internet users: total: 765
percent of population: 34.6% (July 2016 est.)
country comparison to the world: 225
— “Port rt Hedland
*karratha
Mount Isa”
803620AI (G00834) 8-13
PHYSICAL MAP OF SOUTHEAST ASIA
»
Philippine
Sea
Challenger Deep
Oworld’s greatest
ocean depth,
10924) —
North
Pacific
TA “4”
YIRENCH
Deepest point of
Indian Ocean
(7258 mp
Indian”“Ocean
STANDARD TIME ZONE OF THE WORLD
Lie | 3 a] 3 | 3
Py) ELE GEAR','0529756b64676bd6d12d92b383e32d6276bb9a24189090dc57191363c2df5b2e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f12d23f78c4a50214d786d2fe1deaec9fd702912295d05f068291f20289ab7fe',2021,'NI','Nicaragua','communications',375,'Telephones—fixed lines: total subscriptions: 774,303
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 84
Telephones—mobile cellular:
total subscriptions: 8,495,585
subscriptions per 100 inhabitants: 170 (2018 est.)
country comparison to the world: 96
Telephone system: general assessment: good domestic
telephone service in terms of breadth of coverage; in recent
years growth has been achieved from liberalistion of the
telecom sector and has seen substantial expansion in all
sectors; Costa Rica’s broadband market is the most
advanced in Central America, with the highest broadband
penetration for this sub-region; broadband penetration
does lag behind many South American countries; with the
implementation of number portability there is greater
opportunity for increased competition in the future (2018)
domestic: 16 per 100 fixed-line, 170 per 100 mobile-
cellular; point-to-point and point-to-multi-point microwave,
fiber-optic, and coaxial cable link rural areas; Internet
service is available (2018) international: country code—
506; landing points for the ARCOS-1, MAYA-1, and the PAC
submarine cables that provide links to South and Central
America, parts of the Caribbean, and the US; connected to
Central American Microwave System; satellite earth
stations—2 Intelsat (Atlantic Ocean) (2019) Broadcast media:
multiple privately owned TV stations and 1 publicly owned
TV station; cable network services are widely available;
more than 100 privately owned radio stations and a public
radio network (2017) Internet country code: .Cr
Internet users: total: 3,217,277
percent of population: 66% (July 2016 est.)
country comparison to the world: 94
Broadband—fixed subscriptions:
total: 834,784
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 73
Telephones—fixed lines: total subscriptions: 532,004
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 93
Telephones—mobile cellular:
total subscriptions: 7,588,554
subscriptions per 100 inhabitants: 84 (2018 est.)
country comparison to the world: 100
Telephone system: general assessment: fixed-line connections
are increasing but still limited; competition among multiple
providers of mobile-cellular services is contributing to a
sharp increase in subscribership; demand for broadband
increasing and some investment needed in network
upgrades; mobile penetration below regional average
(2018) domestic: private sub-operators allowed to provide
fixed lines in order to expand telephone coverage
contributing to a small increase in fixed-line teledensity 5
per 100; mobile-cellular subscribership is roughly 91 per
100 persons (2018) international: country code—504;
landing points for both the ARCOS and the MAYA-1 fiber-
optic submarine cable systems that together provide
connectivity to South and Central America, parts of the
Caribbean, and the US; satellite earth stations—2 Intelsat
(Atlantic Ocean); connected to Central American
Microwave System (2019) Broadcast media: multiple privately
owned terrestrial TV networks, supplemented by multiple
cable TV networks; Radio Honduras is the _ lone
government-owned radio network; roughly 300 privately
owned radio stations Internet country code: .hn
Internet users: total: 2,667,978
percent of population: 30% (July 2016 est.)
country comparison to the world: 102
Broadband—fixed subscriptions:
total: 354,861
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 96','c28ca516687295d3b60cbbb4c7d007c6c80e46a282a4382b8d57546a687b5c1a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c39f70cd9ff0e83d65d8a31e8e5516de4799fbb456388a260ccbda3de461541f',2021,'BF','Burkina Faso','communications',382,'Telephones—fixed lines: total subscriptions: 302,398
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 114
Telephones—mobile cellular:
total subscriptions: 33,807,850
subscriptions per 100 inhabitants: 129 (2018 est.)
country comparison to the world: 42
Telephone system: general assessment: well-developed by
African standards; telecommunications sector privatized in
late 1990s and operational fixed-lines have increased since
that time with 2 fixed-line providers operating over open-
wire lines, microwave radio relay, and fiber-optics; 90%
digitalized; Cote d’Ivoire continues to benefit from strong
economic growth; the fixed Internet and broadband sectors
have remained lagging (2018) domestic: less than 1 per
100 _ fixed-line, with multiple mobile-cellular service
providers competing in the market, usage has increased to
about 129 per 100 persons (2018) international: country
code—225; landing point for the SAT-3/WASC, ACE,
MainOne, and WACS fiber-optic submarine cable that
provides connectivity to Europe and South and West Africa;
satellite earth stations—2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean) (2019) Broadcast media: state-controlled
Radiodiffusion Television Ivoirieinne (RTI) is made up of 2
radios stations (Radio Cote d’Ivoire and Frequence2) and 2
television stations (RII1 and RITI2), with nationwide
coverage, broadcasts mainly in French; after 2011 post-
electoral crisis, President OUATTARA’s administration
reopened RII Bouake’, the broadcaster’s office in Cote
d’Ivoire’s 2nd largest city, where facilities were destroyed
during the 2002 rebellion; Cote d’Ivoire is also home to 178
proximity radios stations,16 religious radios stations,5
commercial radios stations, and 5 international radios
stations, according to the Haute Autorite’ de la
Communication Audiovisuelle (HACA); govt now runs radio
UNOCIFM, a radio station previously owned by the UN
Operation in Cote d''Ivoire; in Dec 2016, the govt
announced 4 companies had been granted licenses to
operate—Live TV, Optimum Media Cote d''Ivoire, the
Audiovisual Company of Cote d’Ivoire (Sedaci), and Sorano-
CI, out of the 4 companies only one has started operating
(2019) Internet country code: .Ci
Internet users: total: 6,297,676
percent of population: 26.5% (July 2016 est.)
country comparison to the world: 66
Broadband—fixed subscriptions:
total: 175,918
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 112','cb893e523225da2c000a2fe657ba0726291ddeb8204f262788bc57c83f796e35','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8be903636ee9ff27a8c3f1008b123f17cd7171208c8b7dc982f279320c2fe228',2021,'HR','Croatia','communications',387,'Telephones—fixed lines: total subscriptions: 1,355,662
subscriptions per 100 inhabitants: 32 (2018 est.)
country comparison to the world: 68
Telephones—mobile cellular:
total subscriptions: 4,388,476
subscriptions per 100 inhabitants: 103 (2018 est.)
country comparison to the world: 126
Telephone system: general assessment: the
telecommunications network has improved steadily since
the mid-1990s, covering much of what were once
inaccessible areas; local lines are digital; telecoms market
in Croatia has been shaped by Croatia becoming part of the
European Union in 2013, a process which opened up the
market and the creation of a regulatory environment
leading to competition; the mobile market has one of the
highest penetration rates in the Balkans region; trials for
9G technologies underway (2018) domestic: fixed-line
teledensity has dropped somewhat to about 32 per 100
persons; mobile-cellular telephone subscriptions 103 per
100 (2018) international: country code—385; the ADRIA-1
submarine cable provides connectivity to Albania and
Greece; digital international service is provided through
the main switch in Zagreb; Croatia participates in the
Trans-Asia-Europe fiber-optic project, which consists of 2
fiber-optic trunk connections with Slovenia and a fiber-
optic trunk line from Rijeka to Split and Dubrovnik (2019)
Broadcast media: the national state-owned public broadcaster,
Croatian Radiotelevision, operates 4 terrestrial TV
networks, a satellite channel that rebroadcasts programs
for Croatians living abroad, and 6 regional TV centers; 2
private broadcasters operate national terrestrial networks;
29 privately owned regional TV stations; multi-channel
cable and satellite TV subscription services are available;
state-owned public broadcaster operates 4 national radio
networks and 23 regional radio stations; 2 privately owned
national radio networks and 117 local radio stations (2019)
Internet country code: Jor
Internet users: total: 3,135,949
percent of population: 72.7% (July 2016 est.)
country comparison to the world: 95
Broadband—fixed subscriptions:
total: 1,127,591
subscriptions per 100 inhabitants: 26 (2018 est.)
country comparison to the world: 67
Telephones—fixed lines: total subscriptions: 1,444,480
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 67
Telephones—mobile cellular:
total subscriptions: 5,373,316
subscriptions per 100 inhabitants: 48 (2018 est.)
country comparison to the world: 119
Telephone system: general assessment: fixed-line and mobile
services run by the state-run ETESCA; mobile-cellular
telephone service is expensive and must be paid in
convertible pesos; the Cuban Government has opened
several hundred Wi-Fi hotspots around the island, which
are expensive, and launched a new residential Internet
pilot in Havana and other provinces; as of 2018, 3G mobile
service is available, if limited (2018) domestic: fixed-line
density remains low at about 13 per 100 inhabitants;
mobile-cellular service is expanding to about 48 per 100
persons (2018) international: country code—53; the ALBA-
1, GTMO-1, and GTMO-PR fiber-optic submarine cables link
Cuba, Jamaica, and Venezuela; satellite earth station—1
Intersputnik (Atlantic Ocean region) (2019) Broadcast media:
Government owns and controls all broadcast media: five
national TV channels (Cubavision, Tele Rebelde,
Multivision, Educational Channel 1 and 2,) 2 international
Channels (Cubavision Internacional and Caribe,) 16
regional TV stations, 6 national radio networks and
multiple regional stations; the Cuban government beams
over the Radio-TV Marti signal; although private ownership
of electronic media is_ prohibited, several online
independent news sites exist; those that are not openly
critical of the government are often tolerated; the others
are blocked by the government; there are no independent
TV channels, but several outlets have created strong
audiovisual content (El Toque, for example); a community
of young Youtubers is also growing, mostly with channels
about sports, technology and _ fashion; Christian
denominations are creating original video content to
distribute via social media (2019) Internet country code: .cu
Internet users: total: 4,334,022
percent of population: 38.8% (July 2016 est.)
note: private citizens are prohibited from buying computers
or accessing the Internet without special authorization;
foreigners may access the Internet in large hotels but are
subject to firewalls; some Cubans buy illegal passwords on
the black market or take advantage of public outlets to
access limited email and the government-controlled
“intranet”
country comparison to the world: 84
Broadband—fixed subscriptions: total: 98,838
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 122
Telephones—fixed lines: total subscriptions: 58,805
subscriptions per 100 inhabitants: 39 (2018 est.)
country comparison to the world: 157
Telephones—mobile cellular:
total subscriptions: 186,390
subscriptions per 100 inhabitants: 124 (2018 est.)
country comparison to the world: 183
Telephone system: general assessment: modern fully
automatic telecommunications system; telecom sector
across the Caribbean region continues to be one of the
growth areas; given the lack of economic diversity in the
region, with a high dependence on tourism and activities
such as fisheries and offshore financial services (2020)
domestic: 39 per 100 users for fixed-line and 124 per 100
users for cellular-mobile, majority of the islanders have
internet; market revenue has been affected in recent
quarters as a result of competition and _ regulatory
measures on termination rates and roaming tariffs (2020)
international: country code—+599, PCCS submarine cable
system to US, Caribbean and Central and South America
(2019) Broadcast media: government-run TeleCuracao
operates a TV station and a radio station; 2 other privately
owned TV stations and several privately owned radio
stations (2019) Internet country code: .CW
Internet users: total: 138,750
percent of population: 93.9% (July 2016 est.)
country comparison to the world: 173
Broadband—fixed subscriptions:
total: 51,836
subscriptions per 100 inhabitants: 35 (2018 est.)
country comparison to the world: 134','26d8db8271fb35fa8dfb48fc47411fccc551eaef7b462b9c1dac092fae707477','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdcbd1e9ca2474b06417102e38f388e56bc115c28ef2e0065c1dc8f5dce7365a',2021,'HU','Hungary','communications',401,'Telephones—fixed lines: total subscriptions: 1,511,942
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 64
Telephones—mobile cellular:
total subscriptions: 12,704,262
subscriptions per 100 inhabitants: 119 (2018 est.)
country comparison to the world: 72
Telephone system: general assessment: good telephone and
Internet service; the Czech Republic has a sophisticated
telecom market, with competition in all sectors provided by
a number of alternate operators; the incumbent telco O2
Czech Republic remains the dominant player though other
operators are gaining market share, through merger and
acquisition activity; regulator makes progress for 5G
services; fixed wireless broadband remains strong, with
penetration among the highest in the EU (2018) domestic:
access to the fixed-line telephone network expanded
throughout the 1990s, 14 per 100 fixed-line, and mobile
telephone usage increased to 119 per 100 mobile-cellular,
and the number of cellular telephone subscriptions now
greatly exceeds the population (2018) international:
country code—420;_ satellite earth stations—6 (2
Intersputnik—Atlantic and Indian Ocean regions, 1 Intelsat,
1 Eutelsat, 1 Inmarsat, 1 Globalstar) (2019) Broadcast
media: 22 TV stations operate nationally, with 17 of them in
private hands; publicly operated Czech Television has 5
national channels; throughout the country, there are some
350 TV channels in operation, many through cable,
satellite, and IPTV _ subscription services; 63 radio
broadcasters are registered, operating over 80 radio
stations, including 7 multiregional radio stations or
networks; publicly operated broadcaster Czech Radio
operates 4 national, 14 regional, and 4 Internet stations;
both Czech Radio and Czech Television are partially
financed through a license fee (2019) Internet country code:
.CZ
Internet users: total: 8,141,303
percent of population: 76.5% (July 2016 est.)
country comparison to the world: 52
Broadband—fixed subscriptions:
total: 3,222,835
subscriptions per 100 inhabitants: 30 (2018 est.)
country comparison to the world: 40
Telephones—fixed lines: total subscriptions: 20,396,603
subscriptions per 100 inhabitants: 33 (2018 est.)
country comparison to the world: 13
Telephones—mobile cellular:
total subscriptions: 83,342,486
subscriptions per 100 inhabitants: 134 (2018 est.)
country comparison to the world: 19
Telephone system: general assessment: modern, well-
developed, fast; fully automated telephone, telex, and data
services; highest mobile penetration rates in Europe;
leading edge of development with 5G; Rome, Turin and
Naples have 5G commercially for users (2018) domestic:
high-capacity cable and microwave radio relay trunks; 33
per 100 for fixed-line and 135 per 100 for mobile-cellular
subscriptions (2018) international: country code—39;
landing points for Italy-Monaco, Italy-Libya, Italy-Malta,
Italy-Greece-1, Italy-Croatia, BlueMed, Janna, FEA,
SeaMeWe-3 & 4 & 5, Trapani-Kelibia, Columbus-III, Didon,
GO-1, HANNIBAL System, MENA, Bridge International,
Malta-Italy Interconnector, Melital, IMEWE, VMSCS, AAE-
1, and OTEGLOBE, submarine cables provide links to Asia,
the Middle East, Europe, North Africa, Southeast Asia,
Australia and US; satellite earth stations—3 Intelsat (with a
total of 5 antennas—3 for Atlantic Ocean and 2 for Indian
Ocean) (2019) Broadcast media: two Italian media giants
dominate—the publicly owned Radiotelevisione Italiana
(RAI) with 3 national terrestrial stations and privately
owned Mediaset with 3 national terrestrial stations; a large
number of private stations and Sky Italia—a satellite TV
network; RAI operates 3 AM/FM nationwide radio stations;
about 1,300 commercial radio stations Internet country code:
Ait
Internet users: total: 38,025,661
percent of population: 61.3% (July 2016 est.)
country comparison to the world: 20
Broadband—fixed subscriptions:
total: 17,060,505
subscriptions per 100 inhabitants: 27 (2018 est.)
country comparison to the world: 12','d8ee4014df2923267f4c8976bda8375a062c4b4bd5f3a62767855f421ed2347f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39a719adeddf2f878c732f4a529b8f4620168ae3702a50c90265dd496bf80151',2021,'DK','Denmark','communications',411,'Telephones—fixed lines: total subscriptions: 1,131,064
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 75
Telephones—mobile cellular:
total subscriptions: 7.197 million
subscriptions per 100 inhabitants: 124 (2018 est.)
country comparison to the world: 104
Telephone system: general assessment: excellent telephone
and Internet services; Denmark’s competitive telecom
market has led to the country having the second highest
broadband penetration rate in Europe; the fixed-line sector
continues to see a decline in revenue while customers move
to VoIP (Voice over Internet Protocol) and mobile
alternatives; growth has been stimulated by the availability
of LTE services; the government is able to offer broadband
coverage in rural areas (2018) domestic: fixed-line 19 per
100, 124 per 100 for mobile-cellular (2018)
international: country code—45; landing points for the
NSC, COBRAcable, CANTAT-3, DANICE, Havfrue/AEC-2,
TAT- 14m Denmark-Norway-5 & 6, Skagenfiber West &
East, GC1, GC2, GC3, GC-KPN, Kattegat 1 & 2 & 3,
Energinet Lyngsa- Laeso, Energinet Laeso-Varberg,
Fehmarn Balt, Baltica, German-Denmark 2 & 3, Ronne-
Rodvig, Denmark-Sweden 15 & 16 & 17 & 18, IP-Only
Denmark-Sweden, Scandinavian South, Scandinavian Ring
North, Danica North, 34 series of fiber-optic submarine
cables link Denmark with Canada, Faroe Islands, Germany,
Iceland, Netherlands, Norway, Poland, Russia, Sweden, US
and UK; satellite earth stations—18 (6 Intelsat, 10 Eutelsat,
1 Orion, 1 Inmarsat (Blaavand-Atlantic- East)); note—the
Nordic countries (Denmark, Finland, Iceland, Norway, and
Sweden) share the Danish earth station and the Eik,
Norway, station for worldwide Inmarsat access (2019)
Broadcast media: strong public-sector TV presence with state-
owned Danmarks Radio (DR) operating 6 channels and
publicly owned TV2 operating roughly a_ half-dozen
channels; broadcasts of privately owned stations are
available via satellite and cable feed; DR operates 4
nationwide FM radio stations, 10 digital audio broadcasting
stations, and 14 web-based radio stations; 140 commercial
and 187 community (non-commercial) radio stations (2019)
Internet country code: .dk
Internet users: total: 5,424,169
percent of population: 97% (July 2016 est.)
country comparison to the world: 72
Broadband—fixed subscriptions:
total: 2,534,348
subscriptions per 100 inhabitants: 44 (2018 est.)
country comparison to the world: 48
Telephones—fixed lines: total subscriptions: 76,522
subscriptions per 100 inhabitants: 8 (2018 est.)
country comparison to the world: 147
Telephones—mobile cellular:
total subscriptions: 1,033,915
subscriptions per 100 inhabitants: 112 (2017 est.)
country comparison to the world: 160
Telephone system: general assessment: modern local,
interisland, and international (wire/radio integrated) public
and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio communications center; subject to
occasional devastating cyclones; Fiji is a leader in the
Pacific region in terms of development of its ICT
(Information & Communications Technology) sector and
investment in telecoms infrastructure; initial progress
towards 5G readiness (2018) domestic: telephone or radio
telephone links to almost all inhabited islands; most towns
and large villages have automatic telephone exchanges and
direct dialing; fixed-line 8 per 100 persons and mobile-
cellular teledensity roughly 112 per 100 persons (2018)
international: country code—679; landing points for the
ICN1, SCCN, Southern Cross NEXT, Tonga Cable and Tui-
Samoa submarine cable links to US, NZ, Australia and
Pacific islands of Fiji, Vanuatu, Kiribati, Samoa, Tokelau,
Tonga, Fallis & Futuna, and American Samoa; satellite
earth stations—2 Inmarsat (Pacific Ocean) (2019) Broadcast
media: Fiji TV, a publicly traded company, operates a free-to-
air channel; Digicel Fiji operates the Sky Fiji and Sky
Pacific multi-channel pay-TV services; state-owned
commercial company, Fiji Broadcasting Corporation, Ltd,
operates 6 radio stations -2 public broadcasters and 4
commercial broadcasters with multiple repeaters; 5 radio
stations with repeaters operated by Communications Fiji,
Ltd; transmissions of multiple international broadcasters
are available Internet country code: .fj
Internet users: total: 425,680
percent of population: 46.5% (July 2016 est.)
country comparison to the world: 151
Broadband—fixed subscriptions:
total: 13,033
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 165
Telephones—fixed lines: total subscriptions: 8,060
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 196
Telephones—mobile cellular:
total subscriptions: 62,537
subscriptions per 100 inhabitants: 108 (2018 est.)
country comparison to the world: 201
Telephone system: general assessment: adequate domestic
and international service provided by satellite, cables, and
microwave radio relay; the fundamental
telecommunications infrastructure consists of a digital
radio link from Nanortalik in south Greenland to
Uummannag in north Greenland; satellites cover north and
east Greenland for domestic and foreign
telecommunications; a marine cable connects south and
west Greenland to the rest of the world, extending from
Nuuk and Qagqortog to Canada and Iceland (2018)
domestic: 14 per 100 for fixed-line subscriptions and 111
per 100 for mobile-cellular (2018) international: country
code—299; landing points for Greenland Connect,
Greenland Connect North, Nunavut Undersea Fiber System
submarine cables to Greenland, Iceland, and Canada;
satellite earth stations—15 (12 Intelsat, 1 Eutelsat, 2
Americom GE-2 (all Atlantic Ocean)) (2019) Broadcast media:
the Greenland Broadcasting Company provides public radio
and TV services throughout the island with a broadcast
station and a series of repeaters; a few private local TV and
radio stations; Danish public radio rebroadcasts are
available (2019) Internet country code: .gl
Internet users: total: 39,544
percent of population: 68.5% (July 2016 est.)
country comparison to the world: 198
Broadband—fixed subscriptions: total: 13,192
subscriptions per 100 inhabitants: 23 (2018 est.)
country comparison to the world: 164
Telephones—fixed lines: total subscriptions: 560,945
subscriptions per 100 inhabitants: 10 (2018 est.)
country comparison to the world: 91
Telephones—mobile cellular:
total subscriptions: 5,720,892
subscriptions per 100 inhabitants: 106 (2018 est.)
country comparison to the world: 117
Telephone system: general assessment: modern in _ all
respects; one of the most advanced telecommunications
networks in Europe; forward leaning in LTE-A
developments; looking to close 3G and 2G networks by
2025 and preparing for 5G; broadband penetration rate is
among the best in Europe (2018) domestic: Norway has a
domestic satellite system; the prevalence of rural areas
encourages the wide use of mobile-cellular systems; fixed-
line 14 per 100 and mobile-cellular 108 per 100 (2018)
international: country code—47; landing points for the
Svalbard Undersea Cable System, Polar Circle Cable, Bodo-
Rost Cable, NORSKE Viking, Celtic Norse, Tempnet
Offshore FOC Network, England Cable, Denmark-
Norwary6, MHavfrue/AEC-2, Skagerrak 4, and_ the
Skagenfiber West & East submarine cables providing links
to other Nordic countries, Europe and the US; satellite
earth stations—Eutelsat, Intelsat (Atlantic Ocean), and 1
Inmarsat (Atlantic and Indian Ocean regions); note—
Norway shares the Inmarsat earth station with the other
Nordic countries (Denmark, Finland, Iceland, and Sweden)
(2019) Broadcast media: state-owned public radio-TV
broadcaster operates 3 nationwide TV _ stations, 3
nationwide radio stations, and 16 regional radio stations;
roughly a dozen privately owned TV stations broadcast
nationally and roughly another 25 local TV _ stations
broadcasting; nearly 75% of households have access to
multi-channel cable or satellite TV; 2 privately owned radio
stations broadcast nationwide and another 240 stations
operate locally; Norway is the first country in the world to
phase out FM radio in favor of Digital Audio Broadcasting
(DAB), a process scheduled for completion in late 2017
(2019) Internet country code: .nO
Internet users: total: 5,122,904
percent of population: 97.3% (July 2016 est.)
country comparison to the world: 75
Broadband—fixed subscriptions:
total: 2,206,519
subscriptions per 100 inhabitants: 41 (2018 est.)
country comparison to the world: 53
Telephones—fixed lines: total subscriptions: 560,326
subscriptions per 100 inhabitants: 16 (2018 est.) country
comparison to the world: 92
Telephones—mobile cellular:
total subscriptions: 6,440,889
subscriptions per 100 inhabitants: 184 (2018 est.) country
comparison to the world: 109
Telephone system: general assessment: modern system
consisting of open-wire, microwave, and radiotelephone
communication stations; coaxial cable; domestic satellite
system with 8 earth stations; both 3G and 4G LTE
networks; exploring 5G options; competition among mobile
network operators (MNO) (2018) domestic: fixed-line 11
per 100 and mobile-cellular 151 per 100, subscribership
both increasing with fixed-line phone service gradually
being introduced to remote villages using wireless local
loop systems (2018) international: country code—968;
landing points for GSA, AAE-1, SeaMeWe-5, Tata TGN-Gulf,
FALCON, GBICS/MENA, MENA/Guld Bridge International,
TW1, BBG, EIG, OMRAN/EPEG, and POI submarine cables
providing connectivity to Asia, Africa, the Middle East,
Southeast Asia and Europe; satellite earth stations—2
Intelsat (Indian Ocean) (2019) Broadcast media: 1 state-run
TV broadcaster; TV stations transmitting from Saudi
Arabia, the UAE, Iran, and Yemen available via satellite TV;
state-run radio operates multiple stations; first private
radio station began operating in 2007 and _ several
additional stations now operating (2019) Internet country code:
om
Internet users: total: 2,342,483
percent of population: 69.8% (July 2016 est.) country
comparison to the world: 106
Broadband—fixed subscriptions:
total: 422,035
subscriptions per 100 inhabitants: 12 (2018 est.) country
comparison to the world: 89','b2da43fb22aa4296e2a74c29004a705dc566c4109c002a36525cea7f47860c11','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447beb594b409c8de3c60628799642e9ed8674051a8dbec4d823b5d2774caf38',2021,'DJ','Djibouti','communications',420,'Telephones—fixed lines: total subscriptions: 36,855
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 165
Telephones—mobile cellular:
total subscriptions: 395,037
subscriptions per 100 inhabitants: 45 (2018 est.)
country comparison to the world: 176
Telephone system: general assessment: telephone facilities in
the city of Djibouti are adequate, as are the microwave
radio relay connections to outlying areas of the country;
Djibouti is one of the few remaining countries in which the
national telco, Djibouti Telecom (DT), has a monopoly on all
telecom services, including fixed lines, mobile, Internet and
broadband; the lack of competition has meant that the
market has not lived up to its potential (2018) domestic: 4
per 100 fixed-line and 45 per 100 mobile-cellular; Djibouti
Telecom (DT) is the sole provider of telecommunications
services and utilizes mostly a microwave radio relay
network; fiber-optic cable is installed in the capital; rural
areas connected via wireless local loop radio systems;
mobile cellular coverage is primarily limited to the area in
and around Djibouti city (2019) international: country code
—253; landing points for the SEA-ME-WE-3 & 5, EASSy,
Aden-Djibouti, Africa-1, DARE-1, EIG, MENA, Bridge
International, PEACE Cable, and SEACOM fiber-optic
submarine cable systems providing links to Asia, the
Middle East, Europe, Southeast Asia, Australia and Africa;
satellite earth stations—2 (1 Intelsat—Indian Ocean and 1
Arabsat) (2019) Broadcast media: state-owned Radiodiffusion-
Television de Djibouti operates the sole terrestrial TV
station, as well as the only 2 domestic radio networks; no
private TV or radio stations; transmissions of several
international broadcasters are available (2019) Internet
country code: .dj
Internet users: total: 111,212
percent of population: 13.1% (July 2016 est.)
country comparison to the world: 175
Broadband—fixed subscriptions:
total: 25,508
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 147
Telephones—fixed lines: total subscriptions: 2,660
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 210
Telephones—mobile cellular:
total subscriptions: 75,771
subscriptions per 100 inhabitants: 102 (2018 est.)
country comparison to the world: 198
Telephone system: general assessment: fully automatic
network; there are multiple operators licensed to provide
services, most of them are small and localized; the telecom
sector across the Caribbean region remains one of the key
growth areas (2018) domestic: fixed-line connections
continue to decline slowly with only two active operators
providing about 4 fixed-line connections per 100 persons;
subscribership among the three mobile-cellular providers is
about 102 per 100 persons (2018) international: country
code—1-767; landing points for the ECFS and the Southern
Caribbean Fiber submarine cables providing connectivity to
other islands in the eastern Caribbean extending from the
British Virgin Islands to Trinidad and to the US; microwave
radio relay and SHF radiotelephone links to Martinique and
Guadeloupe; VHF and UHF radiotelephone links to Saint
Lucia (2019) Broadcast media: no terrestrial TV service
available; subscription cable TV provider offers some
locally produced programming plus channels from the US,
Latin America, and the Caribbean; state-operated radio
broadcasts on 6 stations; privately owned radio broadcasts
on about 15 stations (2019) Internet country code: .dm
Internet users: total: 49,439
percent of population: 67% (July 2016 est.)
country comparison to the world: 194
Broadband—fixed subscriptions:
total: 11,514
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 167','6f364c896cf21786c8e73bb24f985b56f6e07ab2d53ab8ee924948d4705df42e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3956ac13db50ecc4e267031aaf539f51e08f5ad8223e2b1a63d82ac7c7a9c688',2021,'JE','Jersey','communications',433,'Telephones—fixed lines: total subscriptions: 1,277,247
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 70
Telephones—mobile cellular:
total subscriptions: 8,937,647
subscriptions per 100 inhabitants: 87 (2018 est.)
country comparison to the world: 90
Telephone system: general assessment: relatively efficient
system based on _ island-wide microwave radio relay
network; there are multiple operators licensed to provide
services, most of them are small and localized; the telecom
sector across the Caribbean region remains one of the key
growth areas (2018) domestic: fixed-line teledensity is
about 12 per 100 persons; multiple providers of mobile-
cellular service with a subscribership of 82 per 100 persons
(2018) international: country code—1-809; 1-829; 1-849;
landing point for the ARCOS-1, Antillas 1, AMX-1, SAm-1,
East-West, Deep Blue Cable and the Fibralink submarine
cables that provide links to South and Central America,
parts of the Caribbean, and US; satellite earth station—1
Intelsat (Atlantic Ocean) (2019) Broadcast media: combination
of state-owned and privately owned broadcast media; 1
state-owned TV network and a number of private TV
networks; networks operate repeaters to extend signals
throughout country; combination of state-owned and
privately owned radio stations with more than 300 radio
stations operating (2019) Internet country code: .do
Internet users: total: 6,504,998
percent of population: 61.3% (July 2016 est.)
country comparison to the world: 65
Broadband—fixed subscriptions:
total: 794,788
subscriptions per 100 inhabitants: 8 (2018 est.)
country comparison to the world: 74
Telephones—fixed lines: total subscriptions: 3,302,836
subscriptions per 100 inhabitants: 40 (2018 est.)
country comparison to the world: 43
Telephones—mobile cellular:
total subscriptions: 10,808,148
subscriptions per 100 inhabitants: 130 (2018 est.)
country comparison to the world: 81
Telephone system: general assessment: highly developed
telecommunications infrastructure with extensive domestic
and international services; one of the highest broadband
penetration rates in Europe; although not a member of the
EU, Switzerland follows the EU’s telecom framework, and
regulations; broad DSL infrastructure and cable broadband
network with good competition; LTE, DOCSIS3.1 and 5G
promotions by the govt (2018) domestic: ranked among
leading countries for fixed-line teledensity and
infrastructure; fixed-line 45 per 100 and mobile-cellular
subscribership 137 per 100 persons; extensive cable and
microwave radio relay networks (2018) international:
country code—41; satellite earth stations—2 Intelsat
(Atlantic Ocean and Indian Ocean) Broadcast media: the
publicly owned radio and TV_ broadcaster, Swiss
Broadcasting Corporation (SRG/SSR), operates 8 national
TV networks, 3 broadcasting in German, 3 in French, and 2
in Italian; private commercial TV stations broadcast
regionally and locally; TV broadcasts from stations in
Germany, Italy, and France are widely available via multi-
channel cable and satellite TV services; SRG/SSR operates
17 radio stations that, along with private broadcasters,
provide national to local coverage) (2019) Internet country
code: .ch
Internet users: total: 7,312,744
percent of population: 89.4% (July 2016 est.)
country comparison to the world: 59
Broadband—fixed subscriptions:
total: 3,957,669
subscriptions per 100 inhabitants: 48 (2018 est.)
country comparison to the world: 36
Telephones—fixed lines: total subscriptions: 2.74 million
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 50
Telephones—mobile cellular:
total subscriptions: 17,129,676
subscriptions per 100 inhabitants: 97 (2018 est.)
country comparison to the world: 63
Telephone system: general assessment: the armed insurgency
that began in 2011 has led to major disruptions to the
network and has caused telephone and Internet outages
throughout the country; 2018 saw some _ stabilizing;
telecoms have become decentralized with expensive
satellite communications in the country; fairly high mobile
penetration; potential for growth given that subscription
numbers are low; mobile broadband infrastructure is still
based predominantly on 3G, despite the launch of LTE in
2017; Syria has two mobile telephone operators, MTN
Syria and Syriatel (2019) domestic: the number of fixed-line
connections increased markedly prior to the civil war in
2011 and now stands at 15 per 100; mobile-cellular service
stands at about 87 per 100 persons (2018) international:
country code—963; landing points for the Aletar, BERYTAR
and UGART submarine cable connections to Egypt,
Lebanon, and Cyprus; satellite earth stations—1 Intelsat
(Indian Ocean) and 1 Intersputnik (Atlantic Ocean region);
coaxial cable and microwave radio relay to Irag, Jordan,
Lebanon, and Turkey; participant in Medarabtel (2019)
Broadcast media: State-run TV and radio broadcast networks;
state operates 2 TV networks and 5 satellite channels;
roughly two-thirds of Syrian homes have a satellite dish
providing access to foreign TV broadcasts; 3 state-run radio
channels; first private radio station launched in 2005;
private radio broadcasters prohibited from transmitting
news or political content (2018) Internet country code: .Sy
Internet users: total: 5,476,850
percent of population: 31.9% (July 2016 est.)
country comparison to the world: 71
Broadband—fixed subscriptions: total: 1,328,688
subscriptions per 100 inhabitants: 7 (2018 est.)
country comparison to the world: 66
Telephones—fixed lines: total subscriptions: 13,174,334
subscriptions per 100 inhabitants: 56 (2018 est.)
country comparison to the world: 16
Telephones—mobile cellular:
total subscriptions: 29,340,886
subscriptions per 100 inhabitants: 125 (2018 est.)
country comparison to the world: 46
Telephone system: general assessment: good
telecommunications infrastructure and competitive mobile
market; Taiwan has a stable regulatory system and an
educated workforce building on availability of fixed and
mobile broadband networks; fixed-line will decline in the
next 5 years; 5 mobile network operators; 4G LTE and trials
on 5G (2018) domestic: fixed-line 48 per 100 and mobile-
cellular 124 per 100 (2018)
international: country code—886; landing points for the
EAC-C2C, APCN-2, FASTER, SJC2, TSE-1, TPE, APG,
SeaMeWe-3, FLAG North Asia Loop/REACH North Asia
Loop, HKA, NCP, and PLCN submarine fiber cables provide
links throughout Asia, Australia, the Middle East, Europe,
Africa and the US; satellite earth stations—2 (2019)
Broadcast media: 5 nationwide television networks operating
roughly 22 TV stations; more than 300 satellite TV channels
are available; about 60% of households utilize multi-
channel cable TV; 99.9% of households subscribe to digital
cable TV; national and regional radio networks with about
171 radio stations (2019) Internet country code: . tw
Internet users: total: 20.601 million
percent of population: 88% (July 2016 est.)
country comparison to the world: 32
Broadband—fixed subscriptions:
total: 5,725,022
subscriptions per 100 inhabitants: 24 (2018 est.)
country comparison to the world: 28
Telephones—fixed lines: total subscriptions: 468,000
subscriptions per 100 inhabitants: 6 (July 2016 est.)
country comparison to the world: 99
Telephones—mobile cellular:
total subscriptions: 9.4 million
subscriptions per 100 inhabitants: 111 (July 2016 est.)
country comparison to the world: 89
Telephone system: general assessment: foreign investment in
the telephone system has resulted in major improvements;
conversion of the existing fixed network from analogue to
digital was completed in 2012; the country has endeavored
to launch 4G/LTE services with mixed results; 7 major cities
have 4G coverage; 5 major operators in the market; low
broadband penetration (2018) domestic: fixed line
availability has not changed significantly since 1998, while
mobile cellular subscribership, aided by competition among
multiple operators, has expanded rapidly; coverage now
extends to all major cities and towns; fixed- line 6 per 100
and mobile-cellular 111 per 100 (2018) international:
country code—992; linked by cable and microwave radio
relay to other CIS republics and by leased connections to
the Moscow international gateway switch; Dushanbe linked
by Intelsat to international gateway switch in Ankara
(Turkey); satellite earth stations—3 (2 Intelsat and 1 Orbita
Broadcast media: state-run TV _ broadcasters’ transmit
nationally on 9 TV and 10 radio stations, and regionally on
4 stations; 31 independent TV and 20 radio stations
broadcast locally and regionally; many households are able
to receive Russian and other foreign stations via cable and
satellite (2016) Internet country code: .tj
Internet users: total: 1,705,345
percent of population: 20.5% (July 2016 est.)
country comparison to the world: 118
Broadband—fixed subscriptions: total: 6,000
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 177','303018b2604b76256d4acda92e63b9edb3bd72e16d63d44efbdafc75a7cbd405','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c588ca291e8fe829b0a99048914bccd581be16d08d838294b6553a26017a74a4',2021,'CO','Colombia','communications',442,'Telephones—fixed lines: total subscriptions: 2,360,581
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 56
Telephones—mobile cellular:
total subscriptions: 15,772,838
subscriptions per 100 inhabitants: 96 (2018 est.)
country comparison to the world: 65
Telephone system: general assessment: fixed-line service and
sophisticated 4G LTE ultra-broadband network; much of
the country’s fixed-line structure is influenced by
topographical challenges associated with the Andes
Mountains; Ecuador has a small telecom market with a
dominant mobile sector; the state-owned incumbent CNT
dominates the fixed-line market, and therefore the DSL
broadband market as well (2018) domestic: fixed-line
services with digital networks provided by multiple
telecommunications operators; fixed-line teledensity stands
at about 14 per 100 persons and mobile-cellular use has
surged and subscribership has reached 96 per 100 persons
(2018) international: country code—593; landing points for
the PAN-AM, PCCS, America Movil-Telxius West Coast
Cable and SAm-1 submarine cables that provide links to
South and Central America, and extending onward to the
Caribbean and the US; satellite earth station—1 Intelsat
(Atlantic Ocean) (2019) Broadcast media: about 60 media
outlets are recognized as national; the Ecuadorian
Government controls 12 national outlets and multiple radio
stations; there are multiple TV networks and many local
channels, as well as more than 300 radio stations; many TV
and radio stations are privately owned; broadcast media is
required by law to give the government free airtime to
broadcast programs produced by the state; the Ecuadorian
Government is the biggest advertiser and _ grants
advertising contracts to outlets that provide favorable
coverage; an antimonopoly law and communication law
limit ownership and investment in the media by non-media
businesses (2019) Internet country code: .e€C
Internet users: total: 8,693,739
percent of population: 54.1% (July 2016 est.)
country comparison to the world: 51
Broadband—fixed subscriptions:
total: 1,953,607
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 54','78c63e4d028b856c3579fdc564c92c24f2f5e4e1e84c10a4be5c7efe6c78e4e5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1656ddab722a60482a3d65860f3be21f7eef589c7d08734406c6492fdda9c0d',2021,'EG','Egypt','communications',448,'Telephones—fixed lines: total subscriptions: 7,865,286
subscriptions per 100 inhabitants: 8 (2018 est.)
country comparison to the world: 21
Telephones—mobile cellular:
total subscriptions: 93,784,497
subscriptions per 100 inhabitants: 94 (2018 est.)
country comparison to the world: 16
Telephone system: general assessment: one of the largest
fixed-line systems in Africa and the Arab region; 4 mobile-
cellular networks (3 international and 1 local) cover most
populated area of Egypt; Telecom Egypt, the country’s only
fixed-line operator, is 80% state owned; principal centers at
Alexandria, Cairo, Al Mansurah, Ismailia, Suez, and Tanta
are connected by coaxial cable and microwave radio relay;
launch of LTE in late 2017 greatly helped the capabilities of
mobile broadband services and will continue to do so for
future development (2018) domestic: fixed-line 8 per 100,
mobile-cellular 94 per 100 (2018)
international: country code—20; landing points for Aletar,
Africa-1, FEA, Hawk, IMEWE, and the SEA-ME-WE-3 & 4
submarine cable networks linking to Asia, Africa, the
Middle East, and Australia; satellite earth stations—4 (2
Intelsat—Atlantic Ocean and Indian Ocean,1 Arabsat, and 1
Inmarsat); tropospheric scatter to Sudan; microwave radio
relay to Israel; a participant in Medarabtel (2019) Broadcast
media: mix of state-run and private broadcast media; state-
run TV operates 2 national and 6 regional terrestrial
networks, as well as a few satellite channels; dozens of
private satellite channels and a large number of Arabic
satellite channels are available for free; some limited
satellite services are also available via subscription; state-
run radio operates about 30 stations belonging to 8
networks; privately-owned radio includes 8 major stations,4
of which belong to 1 network (2019) Internet country code: .eg
Internet users: total: 39,097,468
percent of population: 41.3% (2016 est.)
country comparison to the world: 19
Broadband—fixed subscriptions:
total: 6,579,762
subscriptions per 100 inhabitants: 7 (2018 est.)
country comparison to the world: 26
Communications—note: one of the largest and most famous
libraries in the ancient world was the Great Library of
Alexandria in Egypt (founded about 295 B. C., it may have
survived in some form into the 5th century A. D.); seeking
to resurrect the great center of learning and
communication, the Egyptian Government in 2002
inaugurated the Bibliotheca Alexandrina, an Egyptian
National Library on the site of the original Great Library,
which commemorates the original archive and also serves
as a center of cultural and scientific excellence MILITARY
AND SECURITY
Military expenditures:
1.25% of GDP (2018)
1.42% of GDP (March 2017)
1.67% of GDP (2016)
1.72% of GDP (2015)
1.69% of GDP (2014)
country comparison to the world: 100
Military and security forces: Egyptian Armed Forces (EAP):
Army (includes surface-to-surface missile forces, special
forces, Republican Guard), Navy (includes coastal defense,
Coast Guard), Air Force, Air Defense Command; Ministry of
Interior: Central Security Forces, National Police (2019)
Military service age and obligation: 18-30 years of age for male
conscript military service; service obligation—18-36
months, followed by a 9-year reserve obligation; voluntary
enlistment possible from age 15 (2017) Military—note: the
Multinational Force & Observers (MFO) has operated in
the Sinai since 1982 as a peacekeeping and monitoring
force to supervise the implementation of the security
provisions of the 1979 Egyptian-Israeli Treaty of Peace; the
MFO is an independent international organization, created
by agreement between the Arab Republic of Egypt and the
State of Israel; it is composed of 1,150 troops from 13
countries TRANSPORTATION
National air transport system:
number of registered air carriers: 14 (2015)
inventory of registered aircraft operated by air carriers:
101 (2015)
annual passenger traffic on registered air Carriers:
10,159,464 (2015)
annual freight traffic on _ registered air _ Carriers:
397,531,535 mt-km (2015)
Civil aircraft registration country code prefix: SU (2016)
Airports: 83 (2013)
country comparison to the world: 65
Airports—with paved runways:
total: 72 (2017)
over 3,047 m: 15 (2017)
2,438 to 3,047 m: 36 (2017)
1,524 to 2,437 m: 15 (2017)
under 914 m: 6 (2017)
Airports—with unpaved runways:
total: 11 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 3 (2013)
914 to 1,523 m: 4 (2013)
under 914 m: 3 (2013)
Heliports: 7 (2013)
Pipelines: 486 km condensate,74 km condensate/gas,7986
km gas,957 km liquid petroleum gas,5225 km oil,37 km
oil/gas/water, 895 km refined products,65 km water (2013)
Railways: total: 5,085 km (2014)
standard gauge: 5,085 km 1.435-m gauge (62 km
electrified) (2014)
country comparison to the world: 39
Roadways: total: 65,050 km (2017)
paved: 48,000 km (2017)
unpaved: 17,050 km (2017)
country comparison to the world: 73
Waterways: 3,500 km (includes the Nile River, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller canals
in Nile Delta; the Suez Canal (193.5 km _ including
approaches) is navigable by oceangoing vessels drawing up
to 17.68 m) (2011) country comparison to the world: 29
Merchant marine: total: 389
by type: bulk carrier 14, container ship 8, general cargo 33,
oil tanker 36, other 298 (2018) country comparison to the
world: 44
Ports and terminals: Major seaport(s): Mediterranean Sea—
Alexandria, Damietta, El Dekheila, Port Said oil terminal(s):
Ain Sukhna terminal, Sidi Kerir terminal
container port(s) (TEUs): Alexandria (1,613,000), Port Said
(East) (2,968,308) (2017)
LNG terminal(s) (export): Damietta, Idku (Abu Qir Bay),
Gulf of Suez—Suez
Telephones—fixed lines: total subscriptions: 3.2 million
subscriptions per 100 inhabitants: 38 (2018 est.)
country comparison to the world: 44
Telephones—mobile cellular:
total subscriptions: 10.7 million
subscriptions per 100 inhabitants: 127 (2018 est.)
country comparison to the world: 82
Telephone system: general assessment: most highly developed
system in the Middle East; mobile broadband 100%
population penetration; consumers enjoy inexpensive 3G
services; 4G cellular service; fixed broadband available to
99% of all households (2019) domestic: good system of
coaxial cable and microwave radio relay; all systems are
digital; competition among both fixed-line and mobile
cellular providers results in good coverage countrywide;
fixed-line 39 per 100 and 127 per 100 for mobile-cellular
subscriptions (2019) international: country code—972;
landing points for the MedNautilus Submarine System,
Tameres North, Jonah and Lev Submarine System
submarine cables provide links to Europe, Cyprus, and
parts of the Middle East; satellite earth stations—3 Intelsat
(2 Atlantic Ocean and 1 Indian Ocean) (2019) Broadcast
media: the Israel Broadcasting Corporation (est 2015)
broadcasts on 3 channels, two in Hebrew and the other in
Arabic; multi-channel satellite and cable TV packages
provide access to foreign channels; the Israeli Broadcasting
Corporation broadcasts on 8 radio networks with multiple
repeaters and Israel Defense Forces Radio broadcasts over
multiple stations; about 15 privately owned radio stations;
overall more than 100 stations and repeater stations (2019)
Internet country code: .il
Internet users: total: 6,740,287
percent of population: 79.7% (December 2017 est.)
country comparison to the world: 63
Broadband—fixed subscriptions:
total: 2.41 million
subscriptions per 100 inhabitants: 29 (2018 est.)
country comparison to the world: 51','dbbaa00b75c00f8d21c545c93b4596ac752bcd11bfd2d2231d0615d4bf906749','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('431c89e33bbdac304c991f2ddcf1a72112582b8c5ce6559e2a9b4e0e5204cb04',2021,'GT','Guatemala','communications',454,'Telephones—fixed lines: total subscriptions: 923,029
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 78
Telephones—mobile cellular:
total subscriptions: 9,433,495
subscriptions per 100 inhabitants: 148 (2018 est.)
country comparison to the world: 88
Telephone system: general assessment: multiple mobile-
cellular services began rolling out Long Term Evolution
(LTE) data services in late- 2016; Internet usage grew
almost 400% between 2007 and 2015; 6% of phones are
fixed while 94% are mobile (2018) domestic: nationwide
microwave radio relay system; growth in fixed-line services
14 per 100, has slowed in the face of mobile-cellular
competition at 148 per 100 (2019) international: country
code—503; satellite earth station—1 Intelsat (Atlantic
Ocean); connected to Central American Microwave System
(2019) Broadcast media: multiple privately owned national
terrestrial TV networks, supplemented by cable TV
networks that carry international channels; hundreds of
commercial radio broadcast stations and 1 government-
owned radio broadcast station; transition to digital
transmission to begin in 2018 along with adaptation of the
Japanese-Brazilian Digital Standard (ISDB-T) Internet country
code: .SV
Internet users: total: 1,785,254
percent of population: 29% (July 2016 est.)
country comparison to the world: 117
Broadband—fixed subscriptions:
total: 492,265
subscriptions per 100 inhabitants: 8 (2018 est.)
country comparison to the world: 86','f01de056bebdf590e177eb824d40f9793dcc7f587fee5d3304bb50f28d013bfe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d40f6d14a6324f881e4335bd4bb085085bbb12832af8fdf302595d1197c8579e',2021,'GN','Guinea','communications',463,'Telephones—fixed lines: total subscriptions: 10,848
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 190
Telephones—mobile cellular:
total subscriptions: 591,223
subscriptions per 100 inhabitants: 74 (2018 est.)
country comparison to the world: 169
Telephone system: general assessment: digital fixed-line
network in most major urban areas and decent mobile
cellular coverage; 3G technology has allowed for estimated
9.5% of growth during 2016 -2021; mobile data will be the
fastest-growing segment 2016-2021 (2018) domestic: fixed-
line density is about 1 per 100 persons and mobile-cellular
subscribership has been increasing to 74 per hundred
(2018) international: country code—240; landing points for
the ACE, Ceiba-1, and Ceiba-2 submarine cables providing
communication from Bata and Malabo, Equatorial Guinea
to numerous Western African and European countries;
satellite earth station—1 Intelsat (Indian Ocean) (2019)
Broadcast media: the state maintains control of broadcast
media with domestic broadcast media limited to 1 state-
owned TV station, 1 private TV station owned by the
president’s eldest son (who is the Vice President), 1 state-
owned radio station, and 1 private radio station owned by
the president’s eldest son; satellite TV service is available;
transmissions of multiple international broadcasters are
generally accessible (2019) Internet country code: .gq
Internet users: total: 180,597
percent of population: 23.8% (July 2016 est.)
country comparison to the world: 171
Broadband—fixed subscriptions:
total: 1,620
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 188
Telephones—fixed lines: total subscriptions: 66,086
subscriptions per 100 inhabitants: 1 (July 2016 est.)
country comparison to the world: 152
Telephones—mobile cellular:
total subscriptions: 506,000
subscriptions per 100 inhabitants: 9 (July 2016 est.)
country comparison to the world: 172
Telephone system: general assessment: woefully inadequate
service provided by state-owned telecom monopoly; most
fixed-line telephones are in Asmara; cell phone use is
limited by government control of SIM card issuance; no
data service; only about 3% of households having
computers with 2% Internet; untapped market ripe for
competition; direct phone service between Eritrea and
Ethiopia was restored in September 2018; government
telco working on roll-out of 3G network (2018) domestic:
fixed-line subscribership is less than 1 per 100 person and
mobile-cellular 9 per 100 (2018) international: country
code—291 (2019)
Broadcast media: government controls broadcast media with
private ownership prohibited; 1 state-owned TV station;
state-owned radio operates 2 networks; purchases of
satellite dishes and subscriptions to international broadcast
media are permitted (2019) Internet country code: .er
Internet users: total: 69,095
percent of population: 1.2% (July 2016 est.)
country comparison to the world: 181
Broadband—fixed subscriptions:
total: 600
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 201
Telephones—fixed lines: total subscriptions: 0
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 221
Telephones—mobile cellular:
total subscriptions: 1,480,491
subscriptions per 100 inhabitants: 81 (2018 est.)
country comparison to the world: 155
Telephone system: general assessment: small system including
a combination of microwave radio relay, open-wire lines,
radiotelephone, and mobile cellular communications; 2
mobile network operators (MTN and Orange) (2018)
domestic: fixed-line teledensity less than 1 per 100 persons;
mobile cellular teledensity is roughly 70 per 100 persons
(2018) international: country code—245; ACE submarine
cable connecting Guinea-Bissau with 20 landing points in
Western and South Africa and Europe (2019) Broadcast
media: 1 state-owned TV station, Televisao da Guine-Bissau
(TGB) and a second station, Radio e Televisao de Portugal
(RIP) Africa, is operated by Portuguese public broadcaster
(RTP); 1 state-owned radio station, several private radio
stations, and some community radio stations; multiple
international broadcasters are available (2019) Internet
country code: .gWw
Internet users: total: 66,169
percent of population: 3.8% (July 2016 est.)
country comparison to the world: 183
Broadband—fixed subscriptions: total: 1,204
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 195
Telephones—fixed lines: total subscriptions: 154,000
subscriptions per 100 inhabitants: 2 (July 2016 est.)
country comparison to the world: 128
Telephones—mobile cellular:
total subscriptions: 3.782 million
subscriptions per 100 inhabitants: 55 (July 2016 est.)
country comparison to the world: 131
Telephone system: general assessment: services are minimal;
facilities provide radiotelephone and telegraph, coastal
radio, aeronautical radio, and _ international radio
communication services; a great deal of the population is
under served in telecommunications; terrain, living
conditions and economice stability is not high; 3G and 4G
LTE in urban areas (2018) domestic: access to telephone
services is not widely available; fixed-line 2 per 100 and
mobile-cellular 55 per 100 person, teledensity has
increased (2018) international: country code—675; landing
points for the Kumul Domestic Submarine Cable System,
PNG-LNG, APNG-2, CSCS and the PPC-1 submarine cables
to Australia, Guam, PNG and Solomon Islands; satellite
earth station—1 Intelsat (Pacific Ocean); international radio
communication service (2019) Broadcast media: 4 TV stations:
1 commercial station operating since 1987, 1 state-run
station launched in 2008, 1 digital free-to-view network
launched in 2014, and 1 satellite network Click TV
(PNGTV) launched in 2015; the’ state-run National
Broadcasting Corporation operates 3 radio networks with
multiple repeaters and about 20 provincial stations; several
commercial radio stations with multiple transmission points
as well as several community stations; transmissions of
several international broadcasters are accessible (2018)
Internet country code: .pg
Internet users: total: 652,071
percent of population: 9.6% (July 2016 est.)
country comparison to the world: 144
Broadband—fixed subscriptions:
total: 17,000
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 157
Telephones—fixed lines: total subscriptions: 302,754
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 113
Telephones—mobile cellular:
total subscriptions: 7,439,692
subscriptions per 100 inhabitants: 106 (2018 est.)
country comparison to the world: 102
Telephone system: general assessment: the fixed-line market
is a state monopoly and fixed-line telephone service is
meager; principal switching center is in Asuncion; DSL,
cable modem, FttP (fiber to the home) and WiMAX
technologies available; competition in mobile market
among 4 operators; 18 mobile phones for every fixed-line
service phone (2018) domestic: deficiencies in provision of
fixed-line service have resulted in a rapid expansion of
mobile-cellular services fostered by competition among
multiple providers; Internet market also open_ to
competition; fixed-line 4 per 100 and mobile-cellular 106
per 100 (2018) international: country code—595;
Paraguay’s landlocked position means they must depend on
neighbors for interconnection with submarine cable
networks, making it cost more for broadband services;
satellite earth station—1 Intelsat (Atlantic Ocean) (2019)
Broadcast media: 6 privately owned TV stations; about 75
commercial and community radio stations; 1 state-owned
radio network (2019) Internet country code: .py
Internet users: total: 3,524,045
percent of population: 51.3% (July 2016 est.)
country comparison to the world: 92
Broadband—fixed subscriptions: total: 320,700
subscriptions per 100 inhabitants: 5 (2018 est.)
country comparison to the world: 99
Telephones—fixed lines: total subscriptions: 302,243
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 115
Telephones—mobile cellular:
total subscriptions: 16,559,942
subscriptions per 100 inhabitants: 110 (2018 est.)
country comparison to the world: 64
Telephone system: general assessment: good system with
microwave radio relay, coaxial cable and fiber-optic cable in
trunk system; mobile penetration reached 108% in March
2019; mobile broadband accounts for close to 100%
(97.2%) Internet accesses; 3G and LTE services (2018)
domestic: generally reliable urban system with a fiber-optic
network; about two-thirds of all fixed-line connections are
in Dakar; mobile-cellular service is steadily displacing
fixed-line service, even in urban areas; fixed-line 2 per 100
and mobile-cellular 107 per 100 persons (2018)
international: country code—221; landing points for the
ACE, Atlantis-2, MainOne and SAT-3/WASC_ submarine
cables providing connectivity from South Africa, numerous
western African countries, Europe and South America;
satellite earth station—1 Intelsat (Atlantic Ocean) (2019)
Broadcast media: state-run Radiodiffusion Television
Senegalaise (RTS) broadcasts TV programs from five cities
in Senegal; in most regions of the country, viewers can
receive TV programming from at least 7 _ private
broadcasters; a wide range of independent TV
programming is available via satellite; RTS operates a
national radio network and a number of regional FM
stations; at least 7 community radio stations and 18
private-broadcast radio stations are available;
transmissions of at least 5 international broadcasters are
accessible on FM in Dakar (2019) Internet country code: .Sn
Internet users: total: 3,675,209
percent of population: 25.7% (July 2016 est.)
country comparison to the world: 91
Broadband—fixed subscriptions:
total: 129,820
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 117
Telephones—fixed lines: total subscriptions: 17,000
subscriptions per 100 inhabitants: less than 1 (July 2016
est.)
country comparison to the world: 184
Telephones—mobile cellular:
total subscriptions: 6,279,270
subscriptions per 100 inhabitants: 102 (July 2016 est.)
country comparison to the world: 113
Telephone system: general assessment: telephone service
improving with the expansion of the mobile sector; the
national microwave radio relay trunk system connects
Freetown to Bo and Kenema; mobile-cellular service has
grown rapidly from a small base, overcoming the
deficiencies of the fixed-line sector; mobile sector high
penetration; investments in upgrades to LITE (2018)
domestic: fixed-line less than 1 per 100 and mobile-cellular
102 per 100 (2018)
international: country code—232; landing point for the ACE
submarine cable linking South Africa, over 20 western
African countries and Europe; satellite earth station—1
Intelsat (Atlantic Ocean) (2019) Broadcast media: 1
government-owned TV station; 3 private TV stations; a pay-
TV service began operations in late 2007; 1 government-
owned national radio station; about two-dozen private radio
stations primarily clustered in major cities; transmissions
of several international broadcasters are available (2019)
Internet country code: Sl
Internet users: total: 708,615
percent of population: 11.8% (July 2016 est.)
country comparison to the world: 141','2040fcb8640c64a4a55e1377925bd5f19c05e877468cb2418fe4a672edd24f62','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c6f16ca9fe518e2af7686c08bfe0f554e8d59d3bf4b4e49bce55ece8bdb40fd',2021,'LV','Latvia','communications',477,'Telephones—fixed lines: total subscriptions: 345,690
subscriptions per 100 inhabitants: 28 (2018 est.)
country comparison to the world: 107
Telephones—mobile cellular:
total subscriptions: 1,924,034
subscriptions per 100 inhabitants: 155 (2018 est.)
country comparison to the world: 153
Telephone system: general assessment: a range of regulatory
measures, competition and foreign investment in the form
of joint business ventures has greatly improved telephone
service with a wide range of high-quality voice, data, and
Internet services; one of the most advanced mobile markets
in Europe; 5G trials for further growth commercially
available by 2020; highest broadband penetration in
Europe (2018) domestic: 28 per 100 for fixed-line and 155
per 100 for mobile-cellular; substantial fiber-optic cable
systems carry telephone, TV, and radio traffic in the digital
mode; Internet services are widely available; schools and
libraries are connected to the Internet, a large percentage
of the population files income tax returns online, and online
voting—in local and parliamentary elections—has climbed
steadily since first being introduced in 2005; 85% of
Estonian households have broadband access (2018)
international: country code—372; landing points for the EE-
S-1, EESF-3, Baltic Sea Submarine Cable, FEC and EESF-2
fiber-optic submarine cables to other Estonia points,
Finland, and Sweden; 2 international switches are located
in Tallinn (2019) Broadcast media: the publicly owned
broadcaster, Eesti Rahvusringhaaling (ERR), operates 3 TV
channels and 5 radio networks; growing number of private
commercial radio’ stations broadcasting nationally,
regionally, and locally; fully transitioned to digital television
in 2010; national private TV channels expanding service; a
range of channels are aimed at Russian-speaking viewers;
in 2016, there were 42 on-demand services available in
Estonia, including 19 pay TVOD and SVOD services;
roughly 85% of households accessed digital television
Services Internet country code: .€e
Internet users: total: 1,097,921
percent of population: 87.2% (July 2016 est.)
country comparison to the world: 131
Broadband—fixed subscriptions:
total: 441,167
subscriptions per 100 inhabitants: 35 (2018 est.)
country comparison to the world: 87
Telephones—fixed lines: total subscriptions: 427,066
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 102
Telephones—mobile cellular:
total subscriptions: 4,590,441
subscriptions per 100 inhabitants: 164 (2018 est.)
country comparison to the world: 123
Telephone system: general assessment: adequate; being
modernized to provide improved international capability
and better residential access; SIM card penetration is high
for the region; prepaid sector accounts for most
subscribers; postpaid subscribers is increasing; LTE
networks available to more than 99% of the population;
Lithuanian FttP (fiber to the home cable connections for
Internet) penetration ranked third highest in Europe (2018)
domestic: 17 per 100 for fixed-line subscriptions; rapid
expansion of mobile-cellular services has resulted in a
steady decline in the number of fixed-line connections;
mobile-cellular teledensity stands at about 154 per 100
persons (2018) international: country code—370; landing
points for the BCS East, BCS East-West Interlink and
NordBalt connecting Lithuania to Sweden, and Latvia ;
further transmission by satellite; landline connections to
Latvia and Poland (2019) Broadcast media: public broadcaster
operates 3 channels with the third channel—a satellite
channel—introduced in 2007; various privately owned
commercial TV broadcasters operate national and multiple
regional channels; many privately owned local TV stations;
multi-channel cable and satellite TV services available;
publicly owned broadcaster operates 3 radio networks;
many privately owned commercial broadcasters, with
repeater stations in various regions throughout the country
Internet country code: .1t
Internet users: total; 2,122,884
percent of population: 74.4% (July 2016 est.)
country comparison to the world: 110
Broadband—fixed subscriptions:
total: 788,743
subscriptions per 100 inhabitants: 28 (2018 est.)
country comparison to the world: 76','8b26dccfc428c4ea48c7092127bb20b6860a3cd66c9c09ccb53df1f54930eedd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e29fe0a35b4a16d78e4679088e746974ccc29c5173419f03339a775a50dbdf43',2021,'MZ','Mozambique','communications',490,'Telephones—fixed lines: total subscriptions: 42,000
subscriptions per 100 inhabitants: 3 (July 2016 est.)
country comparison to the world: 162
Telephones—mobile cellular:
total subscriptions: 995,000
subscriptions per 100 inhabitants: 68 (July 2016 est.)
country comparison to the world: 161
Telephone system: general assessment: earlier government
monopoly in telecommunications hindered its growth; new
regulatory authority established in 2013 has aided
expansion in the telecom sector; 2G,3G,4G and LTE
services (2018) domestic: Eswatini has 2 mobile-cellular
providers; communication infrastructure has a geographic
coverage of about 90% and a rising subscriber base; fixed-
line stands at 3 per 100 and mobile-cellular teledensity
roughly 68 telephones per 100 persons; telephone system
consists of carrier-equipped, open-wire lines and low-
capacity, microwave radio relay (2018) international:
country code—268; satellite earth station—1 Intelsat
(Atlantic Ocean) Broadcast media: 1 state-owned TV station;
satellite dishes are able to access South African providers;
state-owned radio network with 3 channels; 1 private radio
station (2019) Internet country code: .SZ
Internet users: total: 414,724
percent of population: 28.6% (July 2016 est.)
country comparison to the world: 152
Broadband—fixed subscriptions:
total: 7,000
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 176
Telephones—fixed lines: total subscriptions: 14,992
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 187
Telephones—mobile cellular:
total subscriptions: 7,076,906
subscriptions per 100 inhabitants: 36 (2018 est.)
country comparison to the world: 107
Telephone system: general assessment: rudimentary; 2 fixed-
line and 3 mobile-cellular operators govern the market;
some mobile services to rural areas; in a resolution to
discourage crime the regulatory has imposed SIM card
registration since 2018; 50 licensed ISPs; DSL services are
available; LTE services are available (2018) domestic:
limited fixed-line subscribership less than 1 per 100
households; mobile-cellular services are expanding but
network coverage is limited and is based around the main
urban areas; mobile-cellular subscribership approaching 40
per 100 households (2018) international: country code—
265; satellite earth stations—2 Intelsat (1 Indian Ocean, 1
Atlantic Ocean) (2019) Broadcast media: radio is the main
broadcast medium; privately owned Zodiak radio has the
widest national broadcasting reach, followed by state-run
radio; numerous private and community radio stations
broadcast in cities and towns around the country; the
largest TV network is government-owned, but at least 4
private TV networks broadcast in urban areas; relays of
multiple international broadcasters are available (2019)
Internet country code: .™1W
Internet users: total: 1,785,369
percent of population: 9.6% (July 2016 est.)
country comparison to the world: 116
Broadband—fixed subscriptions: total: 11,358
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 168
Telephones—fixed lines: total subscriptions: 6,433,300
subscriptions per 100 inhabitants: 20 (2018 est.)
country comparison to the world: 24
Telephones—mobile cellular:
total subscriptions: 42,413,400
subscriptions per 100 inhabitants: 133 (2018 est.)
country comparison to the world: 35
Telephone system: general assessment: modern system
featuring good intercity services mainly by microwave
radio relay and an adequate intercity microwave radio
relay network between Sabah and Sarawak via Brunei;
international service excellent; one of the most advanced
telecom networks; roll-out of a national broadband network
(2018) domestic: fixed-line 21 per 100 and mobile-cellular
teledensity exceeds 135 per 100 persons; domestic satellite
system with 2 earth stations (2018) international: country
code—60; landing points for BBG, FEA, SAFE, SeaMeWe-3
& 4 & 5, AAE-1, JASUKA, BDM, Dumai-Melaka Cable
System, BRCS, ACE, AAG, East-West Submarine Cable
System, SEAX-1, SKR1IM, APCN-2, APG, BtoBe, MCT,
BaSICS, and Labuan-Brunei Submarine cable providing
connectivity via international submarine cable networks to
Asia, the Middle East, Southeast Asia, Australia and
Europe; satellite earth stations—2 Intelsat (1 Indian Ocean,
1 Pacific Ocean) (2019) Broadcast media: state-owned TV
broadcaster operates 2 TV networks with relays throughout
the country, and the leading private commercial media
group operates 4 TV stations with numerous relays
throughout the country; satellite TV subscription service is
available; state-owned radio broadcaster operates multiple
national networks, as well as regional and local stations;
many private commercial radio broadcasters and some
subscription satellite radio services are available; about 55
radio stations overall (2019) Internet country code: .my
Internet users: total: 24,384,952
percent of population: 78.8% (July 2016 est.)
country comparison to the world: 29
Broadband—fixed subscriptions:
total: 2.696 million
subscriptions per 100 inhabitants: 8 (2018 est.)
country comparison to the world: 46
Telephones—fixed lines: total subscriptions: 18,754
subscriptions per 100 inhabitants: 5 (2018 est.)
country comparison to the world: 179
Telephones—mobile cellular:
total subscriptions: 857,934
subscriptions per 100 inhabitants: 219 (2018 est.)
country comparison to the world: 162
Telephone system: general assessment: all inhabited islands
and resorts are connected with telephone and fax service;
two mobile operators extend LTE coverage; tourism has
strengthened the telecom market with investment; the
unusually high mobile penetration rate is also helped by
tourism; Internet bandwidth increased 37% in 2016; mobile
penetration passes 250% (2018) domestic: fixed-line is at 5
per 100 persons and high mobile-cellular subscriptions
stands at 229 per 100 persons (2018) international: country
code—960; landing points for Dhiraagu Cable Network,
NaSCOM, Dhiraagu-SLIT Submarine Cable Networks and
WARF submarine cables providing connections to 8 points
in Maldives, India, and Sri Lanka; satellite earth station—3
Intelsat (Indian Ocean) (2019) Broadcast media: state-owned
radio and TV monopoly until recently; 4 state-operated and
7 privately owned TV stations and 4 state-operated and 7
privately owned radio stations (2019) Internet country code:
mv
Internet users: total: 232,210
percent of population: 59.1% (July 2016 est.)
country comparison to the world: 166
Broadband—fixed subscriptions: total: 53,470
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 133
Telephones—fixed lines: total subscriptions: 63,006
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 154
Telephones—mobile cellular:
total subscriptions: 14,074,248
subscriptions per 100 inhabitants: 49 (2018 est.)
country comparison to the world: 69
Telephone system: general assessment: the mobile segment
has shown strong growth given competition; poor fixed-line
infrastructure means most Internet access is through
mobile accounts; DSL, cable broadband, WiMAX
(broadband over long distances), 3G and some fibre
broadband available; LTE services launched (2018)
domestic: extremely low fixed-line teledensity contrasts
with rapid growth in the mobile-cellular network; operators
provide coverage that includes all the main cities and key
roads; fixed-line less than 1 per 100 and 45 per 100 mobile-
cellular teledensity (2018) international: country code—
258; landing points for the EASSy and SEACOM/ Tata TGN-
Eurasia fiber-optic submarine cable systems _ linking
numerous east African countries, the Middle East and Asia;
satellite earth stations—5 Intelsat (2 Atlantic Ocean and 3
Indian Ocean) (2019) Broadcast media: 1 state-run TV station
supplemented by private TV station; Portuguese state TV’s
African service, RIP Africa, and Brazilian-owned TV
Miramar are available; state-run radio provides nearly
100% territorial coverage and broadcasts in multiple
languages; a number of privately owned and community-
operated stations; transmissions of multiple international
broadcasters are available (2019) Internet country code: .MZ
Internet users: total: 4,543,284
percent of population: 17.5% (July 2016 est.)
country comparison to the world: 81
Broadband—fixed subscriptions:
total: 70,142
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 128
Telephones—fixed lines: total subscriptions: 124,238
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 136
Telephones—mobile cellular:
total subscriptions: 43,497,261
subscriptions per 100 inhabitants: 78 (2018 est.)
country comparison to the world: 34
Telephone system: general assessment: telecommunications
services are marginal; system operating below capacity and
being modernized for better service; 2 fixed-line operators
and 8 operational mobile networks; unfortunate high tariffs
on telecoms; mobile penetration is 83%; 3G/LTE services
(2018) domestic: fixed-line telephone network inadequate
with less than 1 connection per 100 persons; mobile-
cellular service, aided by multiple providers, is increasing
rapidly and exceeds 74 telephones per 100 persons; trunk
service provided by open-wire, microwave radio relay,
tropospheric scatter, and fiber-optic cable; some links being
made digital (2018) international: country code—255;
landing points for the EASSy, SEACOM/Tata TGN-Eurasia,
and SEAS fiber-optic submarine cable system linking East
Africa with the Middle East; satellite earth stations—2
Intelsat (1 Indian Ocean, 1 Atlantic Ocean) (2019) Broadcast
media: a State-owned TV station and multiple privately
owned TV stations; state-owned national radio station
supplemented by more than 40 privately owned radio
stations; transmissions of several international
broadcasters are available (2019) Internet country code: .tz
Internet users: total: 6,822,754
percent of population: 13% (July 2016 est.)
country comparison to the world: 61
Broadband—fixed subscriptions: total: 861,234
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 71
Telephones—fixed lines: total subscriptions: 268,849
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 119
Telephones—mobile cellular:
total subscriptions: 12,908,992
subscriptions per 100 inhabitants: 92 (2018 est.)
country comparison to the world: 71
Telephone system: general assessment: continued economic
instability given fractious elections in 2013 and
infrastructure limitations, such as reliable power, hinder
progress; competition has driven rapid expansion of
telecommunications, particularly cellular voice and mobile
broadband, in recent years; 3 mobile network operators
continue to invest in m-commerce and m-banking facilities;
3G and VoIP services are widely available with 4G/LTE
service being deployed (2018) domestic: consists of
microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local
loop installations, fiber-optic cable, VSAT terminals, and a
substantial mobile-cellular network; Internet connection is
most readily available in Harare and major towns; two
government owned and two private cellular providers;
fixed-line 2 per 100 and mobile-cellular 102 per 100 (2018)
international: country code—263; fiber-optic connections to
neighboring states provide access to international networks
via undersea cable; satellite earth stations—2 Intelsat; 5
international digital gateway exchanges Broadcast media:
government owns all local radio and TV stations; foreign
shortwave broadcasts and satellite TV are available to
those who can afford antennas and receivers; in rural
areas, access to TV broadcasts is extremely limited; analog
TV only, no digital service (2017) Internet country code: .ZW
Internet users: total: 3,363,256
percent of population: 23.1% (July 2016 est.)
country comparison to the world: 93
Broadband—fixed subscriptions: total: 203,056
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 107','e3ee0206ba5c79fbf00e2493762e4522ddeeac1b3deafe2dc980346d4f6d986e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b08be836e4888341e46ac4c803645d423fd01e508b7c3b5245154a4db31b872a',2021,'YE','Yemen','communications',499,'Telephones—fixed lines: total subscriptions: 1.181 million
subscriptions per 100 inhabitants: 1 (2017 est.)
country comparison to the world: 71
Telephones—mobile cellular:
total subscriptions: 62.617 million
subscriptions per 100 inhabitants: 59 (2017 est.)
country comparison to the world: 25
Telephone system: general assessment: Ethio Telecom
maintains a monopoly over telecommunication services;
open-wire, microwave radio relay; radio communication in
the HF, VHF, and UHF frequencies; mobile broadband
services via 3G and LIE networks; 2 domestic satellites
provide the national trunk service; international Internet
bandwidth increased 56% in 2016 to reach 35 Gb/s (2018)
domestic: fixed-line subscriptions at 1 per 100 while
mobile-cellular stands at 59 per 100; the number of mobile
telephones is increasing steadily (2018) international:
country code—251; open-wire to Sudan and _ Djibouti;
microwave radio relay to Kenya and Djibouti; satellite earth
stations—3 Intelsat (1 Atlantic Ocean and 2 Pacific Ocean)
(2016) Broadcast media: 6 public TV stations broadcasting
nationally and 10 public radio broadcasters; 7 private radio
stations and 19 community radio stations (2017) Internet
country code: .et
Internet users: total: 15,731,741
percent of population: 15.4% (July 2016 est.)
country comparison to the world: 38
Broadband—fixed subscriptions:
total: 580,120
subscriptions per 100 inhabitants: 1 (2017 est.)
country comparison to the world: 81
Telephones—fixed lines: total subscriptions: 2,255
subscriptions per 100 inhabitants: 77 (July 2016 est.)
country comparison to the world: 212
Telephones—mobile cellular:
total subscriptions: 4,674
subscriptions per 100 inhabitants: 146 (July 2016 est.)
country comparison to the world: 217
Telephone system: general assessment: government-operated
radiotelephone and _ private VHF/CB_ radiotelephone
networks provide effective service to almost all points on
both islands domestic: fixed-line subscriptions 77 per 100,
146 per 100 for mobile-cellular (2015)
international: country code—500; satellite earth station—1
Intelsat (Atlantic Ocean) with links through London to
other countries (2015) Broadcast media: TV service provided
by a multi-channel service provider; radio services provided
by the public broadcaster, Falkland Islands Radio Service,
broadcasting on both AM and FM frequencies, and by the
British Forces Broadcasting Service (BFBS) (2007) Internet
country code: fk
Internet users: total: 3,000
percent of population: 98.3% (July 2016 est.)
country comparison to the world: 218
Broadband—fixed subscriptions:
total: 1,610
subscriptions per 100 inhabitants: 50 (2017 est.)
country comparison to the world: 189
Telephones—fixed lines: total subscriptions: 5,387,405
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 28
Telephones—mobile cellular:
total subscriptions: 41,310,584
subscriptions per 100 inhabitants: 125 (2018 est.)
country comparison to the world: 36
Telephone system: general assessment: modern system
including a combination of extensive microwave radio
relays, coaxial cables, and fiber-optic cables; broadband is
available with DSL, fiber, and wireless; mobile penetration
is steep in Saudi Arabia; 4G/5G use in early 2019 (2019)
domestic: fixed-line 13 per 100 - = mobile-cellular
subscribership has been increasing rapidly 141 per 100
persons (2018) international: country code—966; landing
points for the SeaMeWe-3, -4, -5, AAF-1, EIG, FALCON,
FEA, IMEWE, MENA/Gulf Bridge International, SEACOM,
SAS-1, -2, GBICS/MENA, and the Tata TGN-Gulf submarine
cables providing connectivity to Europe, Africa, the Middle
East, Asia, Southeast Asia and Australia ;microwave radio
relay to Bahrain, Jordan, Kuwait, Qatar, UAE, Yemen, and
Sudan; coaxial cable to Kuwait and Jordan; satellite earth
stations—5 Intelsat (3 Atlantic Ocean and 2 Indian Ocean),
1 Arabsat, and 1 Inmarsat (Indian Ocean region) (2019)
Broadcast media: broadcast media are state-controlled; state-
run TV operates 4 networks; Saudi Arabia is a major
market for pan-Arab satellite TV broadcasters; state-run
radio operates several networks; multiple international
broadcasters are available Internet country code: .Sa
Internet users: total: 20,768,456
percent of population: 73.8% (July 2016 est.)
country comparison to the world: 31
Broadband—fixed subscriptions:
total: 6,821,873
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 24
Communications—note: the innovative King Abdulaziz Center
for World Culture (informally known as Ithra, meaning
“enrichment”) opened on 1 December 2017 in Dhahran,
Eastern Region; its facilities include a grand library, several
museums, an archive, an Idea Lab, a theater, a cinema, and
an Energy Exhibit, all which are meant to provide visitors
an immersive and transformative experience MILITARY
AND SECURITY
Military expenditures:
8.78% of GDP (2018)
10.25% of GDP (2017)
9.87% of GDP (2016)
13.33% of GDP (2015)
10.68% of GDP (2014)
country comparison to the world: 1
Military and security forces: Ministry of Defense: Royal Saudi
Land Forces, Royal Saudi Naval Forces (includes marines,
special forces, naval aviation), Royal Saudi Air Force, Royal
Saudi Air Defense Forces, Royal Saudi Strategic Missiles
Force; Ministry of the National Guard (SANG); Ministry of
Interior: Border Guard, Facilities Security Force (2019)
note: SANG (also known as the White Army) is a land force
separate from the Ministry of Defense that is responsible
for internal security, protecting the royal family, and
external defense Military service age and obligation: 17 is the
legal minimum age for voluntary military service; no
conscription; in 2018, women were allowed to serve as
soldiers in the internal security services under certain
requirements (2018) TRANSPORTATION
National air transport system: number of registered air Carriers:
12 (2015) inventory of registered aircraft operated by air
carriers: 214 (2015)
annual passenger traffic on registered air Carriers:
32,778,827 (2015)
annual freight traffic on _ registered air _ carriers:
1,783,086,000 mt-km (2015)
Civil aircraft registration country code prefix: HZ (2016)
Airports: 214 (2013)
country comparison to the world: 26
Airports—with paved runways:
total: 82 (2017)
over 3,047 m: 33 (2017)
2,438 to 3,047 m: 16 (2017)
1,524 to 2,437 m: 27 (2017)
914 to 1,523 m: 2 (2017)
under 914 m: 4 (2017)
Airports—with unpaved runways:
total: 132 (2013)
2,438 to 3,047 m: 7 (2013)
1,524 to 2,437 m: 72 (2013)
914 to 1,523 m: 37 (2013)
under 914 m: 16 (2013)
Heliports: 10 (2013)
Pipelines: 209 km condensate, 2940 km gas, 1183 km liquid
petroleum gas, 5117 km oil, 1151 km refined products
(2013) Railways: total: 5,410 km (2016)
standard gauge: 5,410 km 1.435-m gauge (with branch
lines and sidings) (2016)
country comparison to the world: 36
Roadways: total: 221,372 km (2006)
paved: 47,529 km (includes 3,891 km of expressways)
(2006)
unpaved: 173,843 km (2006)
country comparison to the world: 24
Merchant marine: total: 380
by type: bulk carrier 5, container ship 1, general cargo 19,
oil tanker 65, other 290 (2018)
country comparison to the world: 45
Ports and terminals: Major seaport(s): Ad Dammam, Al Jubayl,
Jeddah, King Abdulla, Yanbu’
container port(s) (TEUs): Ad Dammam (1,582,388), Jeddah
(4,150,000), King Abdulla (1,695,322) (2017) TERRORISM
Terrorist groups—foreign based:
al-Qa’ida (AQ): aim(s): oppose the Saudi Islamic monarchy
due to its cooperation with the US and the West,
particularly US military bases in the Kingdom; eradicate
US and Western influence and presence from Saudi Arabia
area(s) of operation: maintains familial connections but
lacks a persistent operational presence; probably retains
some supporters in the country who could facilitate future
operations (2018) al-Qa’ida in the Arabian Peninsula (AQAP):
aim(s): ultimately overthrow the Saudi Islamic monarchy;
eradicate US and Western influence and presence from
Yemen and the rest of the Arabian Peninsula area(s) of
operation: maintains familial connections but lacks an
operational presence inside Saudi Arabia; operates widely
in neighboring Yemen (2018) Islamic State of Iraq and ash-Sham
(ISIS)-Saudi Arabia: aim(s): replace the Saudi Islamic
monarchy with an Islamic state applying ISIS’s strict
interpretation of Sharia; target minority Shia Muslims,
Saudi security personnel, and their interests area(s) of
operation: maintains a recruitment presence; conducts
deadly strikes against Saudi security personnel and bombs
Shia Muslim mosques, markets, and other places where
Shia Muslims gather (2018) TRANSNATIONAL ISSUES
Disputes—International: Saudi Arabia has _ reinforced its
concrete-filled security barrier along sections of the now
fully demarcated border with Yemen to stem illegal cross-
border activities; Kuwait and Saudi Arabia continue
discussions on a maritime boundary with Iran; Saudi Arabia
claims Egyptian-administered islands of Tiran and Sanafir
Refugees and internally displaced persons: refugees (country of
origin): 30,000 (Yemen) (2017) stateless persons: 70,000
(2018); note—thousands of biduns (stateless Arabs) are
descendants of nomadic tribes who were not officially
registered when national borders were established, while
others migrated to Saudi Arabia in search of jobs; some
have temporary identification cards that must be renewed
every five years, but their rights remain restricted; most
Palestinians have only legal resident status; some
naturalized Yemenis were made stateless after being
stripped of their passports when Yemen backed Iraq in its
invasion of Kuwait in 1990; Saudi women cannot pass their
citizenship on to their children, so if they marry a non-
national, their children risk statelessness Trafficking in
persons: Current situation: Saudi Arabia is a destination
country for men and women subjected to forced labor and,
to a lesser extent, forced prostitution; men and women
from South and East Asia, the Middle East, and Africa who
voluntarily travel to Saudi Arabia as domestic servants or
low-skilled laborers subsequently face conditions of
involuntary servitude, including nonpayment and
withholding of passports; some migrant workers are forced
to work indefinitely beyond the term of their contract
because their employers will not grant them a required exit
visa; female domestic workers are particularly vulnerable
because of their isolation in private homes; women,
primarily from Asian and African countries, are believed to
be forced into prostitution in Saudi Arabia, while other
foreign women were reportedly kidnapped and forced into
prostitution after running away from abusive employers;
children from South Asia, East Africa, and Yemen are
subjected to forced labor as beggars and street vendors in
Saudi Arabia, facilitated by criminal gangsS tier rating: Tier 2
Watch List—Saudi Arabia does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do_ so;
government officials and high-level religious leaders
demonstrated greater political will to combat trafficking
and publically acknowledged the problem—specifically
forced labor; the government reported increased numbers
of prosecutions and convictions of trafficking offenders;
however, it did not proactively investigate and prosecute
employers for potential labor trafficking crimes following
their withholding of workers’ wages and passports, which
are illegal; authorities did not systematically use formal
criteria to proactively identify victims, resulting in some
unidentified victims being arrested, detained, deported,
and sometimes prosecuted; more victims were identified
and referred to protective services in 2014 than the
previous year, but victims of sex trafficking and male
trafficking victims were not provided with shelter and
remained vulnerable to punishment (2015) Illicit drugs:
regularly enforces the death penalty for drug traffickers,
with foreigners being convicted and _ executed
disproportionately; improving anti-money-laundering
legislation and enforcement SENEGAL
International Monetary Fund (IMF)
established—22 July 1944; effective—27 December 1945
aim—to promote world monetary stability and economic development; a UN
specialized agency
members—(194) includes all UN member countries except Andorra, Cuba,
North Korea, Liechtenstein, Monaco; plus Kosovo; note—includes the following
dependencies or areas of special interest: China (Hong Kong and Macau),
Netherlands (Aruba, Curacao, Sint Maarten), UK ( Anguilla, Montserrat)
International Olympic Committee (IOC)
established—23 June 1894
aim—to promote the Olympic ideals and administer the Olympic games: 2020
Summer Olympics in Tokyo, Japan; 2022 Winter Olympics in Beijing, China;
2024 Summer Olympics in Paris, France; 2026 Winter Olympics in Milan and
Cortina d’Ampezzo, Italy
National Olympic Committees—(205 and the Palestine Liberation Organization)
Afghanistan, Albania, Algeria, American Samoa, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British
Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde,
Cambodia, Cameroon, Canada, Cayman Islands, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Cyprus, Czechia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kosovo, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, North Macedonia, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, South Sudan, Spain, Sri
Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Taiwan, Tajikistan,
Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen, Zambia,
Zimbabwe, Palestine Liberation Organization
International Organization for Migration (1OM)
note—established as Provisional Intergovernmental Committee for the
Movement of Migrants from Europe; renamed Intergovernmental Committee
for European Migration (ICEM) on 15 November 1952; renamed
Intergovernmental Committee for Migration (ICM) in November 1980; current
name adopted 14 November 1989
established—5 December 1951
aim—to facilitate orderly international emigration and immigration
members—(168) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cyprus, Czechia, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia,
Eswatini, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Holy See, Honduras, Hungary, Iceland, India, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kyrgyzstan,
Latvia, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Madagascar, Malawi,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federation of Micronesia, Moldova, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, North Macedonia, Norway, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Timor-Leste,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
observers—(8) Bahrain, Bhutan, Cuba, Indonesia, Qatar, Russia, San Marino,
Organization of Arab Petroleum Exporting Countries (OAPEC)
established—9 January 1968
aim—to promote cooperation in the petroleum industry
members—(14) Algeria, Bahrain, Congo, Egypt, Equatorial Guinea, Gabon,
Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, Tunisia (suspended), UAE
note—Indonesia left OPEC in 2008, returned again on 1 January 2016, and
suspended its membership once again on 30 November 2016
Organization of Eastern Caribbean States (OECS)
established—18 June 1981; effective—4 July 1981
aim—to promote political, economic, and defense cooperation
members—(10) Anguilla, Antigua and Barbuda, British Virgin Islands,
Dominica, Grenada, Martinique, Montserrat, Saint Kitts and Nevis, Saint Lucia,','72d3d6eef72567a0e56ed90ab520b11d57d406db203337ed5ca8cc150cf8b4ba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e90f5227742fdf2a1753613a3eaf48f06e9edf33b8478c99a02596276c8909a7',2021,'FO','Faroe Islands','communications',509,'Telephones—fixed lines: total subscriptions: 17,188
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 182
Telephones—mobile cellular:
total subscriptions: 56,792
subscriptions per 100 inhabitants: 111 (2018 est.)
country comparison to the world: 203
Telephone system: general assessment: good international
communications; good domestic facilities domestic: 34 per
100 for fixed-line and 111 per 100 for mobile-cellular;
conversion to digital system completed in 1998; both NMT
(analog) and GSM (digital) mobile telephone systems are
installed international: country code—298; landing points
for the SHEFA-2, FARICE-1, and CANTAT3 fiber-optic
submarine cables from the Faeroe Islands, to Denmark,
Germany, UK and Iceland; satellite earth stations—1 Orion;
(2019) Broadcast media: 1 publicly owned TV station; the
Faroese telecommunications company distributes local and
international channels through its digital terrestrial
network; publicly owned radio station supplemented by 3
privately owned stations broadcasting over multiple
frequencies Internet country code: .f0
Internet users: total: 47,988
percent of population: 95.1% (July 2016 est.)
country comparison to the world: 195
Broadband—fixed subscriptions:
total: 18,181
subscriptions per 100 inhabitants: 36 (2018 est.)
country comparison to the world: 155','8daf1b902a8db8ebdd6b01499b36852a607c9c6cc27e6de8fc55588147570b48','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87f03ba8b887baa94ff0d85fe1258967b0df9e852b0f18720e5c89a905085bab',2021,'EE','Estonia','communications',516,'Telephones—fixed lines: total subscriptions: 323,000
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 110
Telephones—mobile cellular:
total subscriptions: 7.15 million
subscriptions per 100 inhabitants: 129 (2018 est.)
country comparison to the world: 105
Telephone system: general assessment: modern system with
excellent service; one of the most progressive in Europe;
one of the highest broadband and mobile penetrations rates
in the region; forefront in testing 5G networks; for 2025
and 2030 FttP (fiber to the home) and DOCSIS3.1 (new
generation of cable services for high speed connections)
technologies (2018) domestic: digital fiber-optic, fixed-line
6 per 100 subscription and 129 per 100 mobile-cellular
(2018) international: country code—358; landing points for
Botnia, BCS North-1 & 2, SFL, SFS-4, C-Lion1, Eastern
Lights, Baltic Sea Submarine Cable, FEC, and EESF-2 & 3
submarine cables that provide links to many Finland points,
Estonia, Sweden, Germany, and Russia; satellite earth
stations—access to Intelsat transmission service via a
Swedish satellite earth station, 1 Inmarsat (Atlantic and
Indian Ocean regions); note—Finland shares the Inmarsat
earth station with the other Nordic countries (Denmark,
Iceland, Norway, and Sweden) (2019) Broadcast media: a mix
of 3 publicly operated TV stations and numerous privately
owned TV stations; several free and special-interest pay-TV
channels; cable and satellite multi-channel subscription
services are available; all TV signals are broadcast
digitally; Internet television, such as Netflix and others, is
available; public broadcasting maintains a network of 13
national and 25 regional radio stations; a large number of
private radio broadcasters and access to Internet radio
Internet country code: .finote—Aland Islands assigned .ax
Internet users: total: 4,822,132
percent of population: 87.7% (July 2016 est.)
country comparison to the world: 77
Broadband—fixed subscriptions:
total: 1.737 million
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 58','b3c60bb570407f559b73e26ea596266dfb8aec90cface0d7bc56f484fc32dcf4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('028d862d31600a7d928a69a1f33f517f214c898ec703441108c33365f3e0f38b',2021,'PF','French Polynesia','communications',524,'Telephones—fixed lines: total subscriptions: 90,278
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 142
Telephones—mobile cellular:
total subscriptions: 302,673
subscriptions per 100 inhabitants: 104 (2018 est.)
country comparison to the world: 180
Telephone system: general assessment: one of the most
advanced telecom infrastructures for the Pacific islands
region; 85% mobile broadband coverage (2018) domestic:
fixed-line subscriptions 31 per 100 persons and mobile-
cellular density is roughly 104 per 100 persons (2018)
international: country code—689; landing points for the
NATITUA, Manatua, and Honotua submarine cables to
other French Polynesian Islands, Cook Islands, Niue,
Samoa and US; satellite earth station—1 Intelsat (Pacific
Ocean) (2019) Broadcast media: French public overseas
broadcaster Reseau Outre-Mer provides 2 TV channels and
1 radio station; 1 government-owned TV station; a small
number of privately owned radio stations (2019) Internet
country code: .pf
Internet users: total: 195,275
percent of population: 68.4% (July 2016 est.)
country comparison to the world: 170
Broadband—fixed subscriptions: total: 59,790
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 132
Internet country code: .tf
Communications—note: haS one or more meteorological
stations on each possession
Telephones—fixed lines: total subscriptions: 21,818
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 175
Telephones—mobile cellular:
total subscriptions: 2,930,554
subscriptions per 100 inhabitants: 138 (2018 est.)
country comparison to the world: 143
Telephone system: general assessment: adequate system of
cable, microwave radio relay, tropospheric scatter,
radiotelephone communication stations, and a domestic
satellite system with 12 earth stations; competition among
telecoms, independent regulatory authority, and reduction
in cost connecting, makes for strong telecommunications
(2018) domestic: fiixed-line is 1 per 100 subscriptions; a
growing mobile cellular network with multiple providers is
making telephone service more widely available with
mobile cellular teledensity at 138 per 100 persons (2018)
international: country code—241; landing points for the
SAT-3/WASC, ACE and Libreville-Port Gentil Cable fiber-
optic submarine cable that provides connectivity to Europe
and West Africa; satellite earth stations—3 Intelsat (Atlantic
Ocean) (2019) Broadcast media: state owns and operates 2 TV
stations and 2 radio broadcast stations; a few private radio
and TV stations; transmissions of at least 2 international
broadcasters are accessible; satellite service subscriptions
are available Internet country code: .ga
Internet users: total: 835,408
percent of population: 48.1% (July 2016 est.)
country comparison to the world: 137
Broadband—fixed subscriptions:
total: 29,099
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 143
Telephones—fixed lines: total subscriptions: 44,000
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 160
Telephones—mobile cellular:
total subscriptions: 3,181,393
subscriptions per 100 inhabitants: 152 (2018 est.)
country comparison to the world: 140
Telephone system: general assessment: adequate microwave
radio relay and open-wire network; state-owned Gambia
Telecommunications partially privatized but still retaining a
monopoly; multiple mobile networks offering effective
competition; three licensed ISPs which serve local area
without much competion (2018) domestic: fixed-line stands
at 2 per 100 subscriptions with one dominant company and
mobile-cellular teledensity, aided by multiple mobile-
cellular providers, is over 152 per 100 persons (2018)
international: country code—220; landing point for the ACE
submarine cable to West Africa and Europe; microwave
radio relay links to Senegal and Guinea-Bissau; satellite
earth station—1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: 1 state-run TV-channel; one privately-owned TV-
station; 1 Online TV-station; three state-owned radio station
and 31 privately owned radio stations; eight community
radio stations; transmissions of multiple international
broadcasters are available, some via shortwave radio; cable
and satellite TV subscription services are obtainable in
some parts of the country (2019) Internet country code: .gm
Internet users: total: 371,785
percent of population: 18.5% (July 2016 est.)
country comparison to the world: 154
Broadband—fixed subscriptions:
total: 4,433
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 182','ed235faf25eb97b0b246d266d438f83d513b6f56ad4b8754db4e7e470aa1aa7e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da7365bccd4137d506eaab5bad6fdc6d2b0e17e55a84a2c5c0dd658a0ccde99',2021,'IL','Israel','communications',531,'Telephones—fixed lines: total subscriptions: 472,293 (includes
the West Bank); (July 2016 est.) subscriptions per 100
inhabitants: 9 (includes the West Bank); (July 2016 est.)
country comparison to the world: 97
Telephones—mobile cellular:
total subscriptions: 4,135,363 (includes the West Bank)
subscriptions per 100 inhabitants: 76 (includes the West
Bank) (2017 est.)
country comparison to the world: 128
Telephone system: general assessment: Israel has final say in
allocating frequencies in the Gaza Strip and does not
permit anything beyond a 2G network (2018) domestic:
Israeli company BEZEK and the Palestinian company
PALTEL are responsible for fixed-line services; the
Palestinian JAWWAL company provides cellular services; a
slow 2G network allows calls and limited data transmission
international: country code 970 or 972 (2018)
Broadcast media: 1 TV station and about 10 radio stations;
satellite TV accessible
Internet country code: .pSnote—same as the West Bank
Internet users: total: 2.673 million (includes the West Bank)
percent of population: 57.4% (July 2016 est.)
country comparison to the world: 100
Broadband—fixed subscriptions:
total: 320,500
subscriptions per 100 inhabitants: 14 (2016 est.)
note: includes West Bank
country comparison to the world: 100
Telephones—fixed lines: total subscriptions: 604,348
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 90
Telephones—mobile cellular:
total subscriptions: 5,459,239
subscriptions per 100 inhabitants: 111 (2018 est.)
country comparison to the world: 118
Telephone system: general assessment: fixed-line
telecommunications network has limited coverage outside
Tbilisi; multiple mobile-cellular providers provide services
to an increasing subscribership throughout the country;
broadband subscribers steadily increasing; with the recent
investment in infrastructure customers are moving from
copper to fiber networks (2018) domestic: fixed-line 12 per
100, cellular telephone networks cover the entire country;
mobile-cellular teledensity roughly 111 per 100 persons;
intercity facilities include a fiber-optic line between T’bilisi
and K’ut’aisi (2018) international: country code—995;
landing points for the Georgia-Russia, Diamond Link
Global, and Caucasus Cable System fiber-optic submarine
cable that provides connectivity to Russia, Romania and
Bulgaria; international service is available by microwave,
landline, and_ satellite through the Moscow — switch;
international electronic mail and telex service are available
(2019) Broadcast media: The Thilisi-based Georgian Public
Broadcaster (GPB) includes Channel 1, Channel 2 as well
as the Batumi-based Adjara TV, and the State Budget funds
all three; there are also a number of independent
commercial television broadcasters, such as Imedi, Rustavi
2, Pirveli TV, Maestro, Kavkasia, Georgian Dream Studios
(GDS), Obiektivi, Mtavari Arkhi, and a small Russian
language operator TOK TV; Tabula and Post TV are web-
based television outlets; all of these broadcasters and web-
based television outlets, except GDS, carry the news; the
Georgian Orthodox Church also operates a satellite-based
television station called Unanimity; there are 26 regional
television broadcasters across Georgia that are members of
the Georgian Association of Regional Broadcasters and/or
the Alliance of Georgian Broadcasters; the broadcaster
organizations seek to strengthen the regional media’s
Capacities and _ distribution of regional products: a
nationwide digital switchover occurred in 2015; there are
several dozen private radio stations; GPB operates 2 radio
stations (2019) Internet country code: .ge
Internet users: total: 2,464,107
percent of population: 50% (July 2016 est.)
country comparison to the world: 105
Broadband—fixed subscriptions:
total: 840,603
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 72','efa822352ebe0d65de7b7503be16c572b7d86b89782dbf29bf47494e21fbb690','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65bd104124a33433b22fe590565b878637164db15e6cea82935aa502cbddd6e4',2021,'AT','Austria','communications',543,'Telephones—fixed lines: total subscriptions: 42.5 million
subscriptions per 100 inhabitants: 53 (2018 est.)
country comparison to the world: 4
Telephones—mobile cellular:
total subscriptions: 107.5 million
subscriptions per 100 inhabitants: 134 (2018 est.)
country comparison to the world: 15
Telephone system: general assessment: one of the world’s
most technologically advanced telecommunications
systems; as a result of intensive capital expenditures since
reunification, the formerly backward system of the eastern
part of the country, dating back to World War II, has been
modernized and integrated with that of the western part;
universal 3G available infrastructure and LTE networks;
penetration in broadband and mobile sectors average for
region (2018) domestic: extensive system of automatic
telephone exchanges connected by modern networks of
fiber-optic cable, coaxial cable, microwave radio relay, and
a domestic satellite system; cellular telephone service is
widely available, expanding rapidly, and includes roaming
service to many foreign countries; 53 per 100 for fixed-line
and 134 per 100 for mobile-cellular (2018) international:
country code—49; landing points for SeaMeWe-3, TAT-14,
AC-1, CONTACT-3, Fehmarn'' Balt, C-Lion1, GC1,
GlobalConnect-KPN, and Germany-Denmark 2 & 3—
submarine cables to Europe, Africa, the Middle East, Asia,
Southeast Asia and Australia; as well as earth stations in
the Inmarsat, Intelsat, Eutelsat, and Intersputnik satellite
systems (2019) Broadcast media: a mixture of publicly
operated and privately owned TV and radio stations; 70
national and regional public broadcasters compete with
nearly 400 privately owned national and regional TV
stations; more than 90% of households have cable or
satellite TV; hundreds of radio stations including multiple
national radio networks, regional radio networks, and a
large number of local radio stations Internet country code: .de
Internet users: total: 72,365,643
percent of population: 89.6% (July 2016 est.)
country comparison to the world: 8
Broadband—fixed subscriptions:
total: 34,174,900
subscriptions per 100 inhabitants: 42 (2018 est.)
country comparison to the world: 4
Telephones—fixed lines: total subscriptions: 278,379
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 116
Telephones—mobile cellular:
total subscriptions: 40,934,875
subscriptions per 100 inhabitants: 146 (2018 est.)
country comparison to the world: 37
Telephone system: general assessment: primarily microwave
radio relay; wireless local loop has been installed; new
universal access licenses; government invested in fiber
infrastructure; one of the most active mobile markets in
Africa (2018) domestic: fixed-line 1 per 100 subscriptions;
competition among multiple mobile-cellular providers has
spurred growth with a subscribership of more than 146 per
100 persons and rising (2018) international: country code—
233; landing points for the SAT-3/WASC, MainOne, ACE,
WACS and GLO-1 fiber-optic submarine cables that provide
connectivity to South and West Africa, and Europe; satellite
earth stations—4 Intelsat (Atlantic Ocean); microwave
radio relay link to Panaftel system connects Ghana to its
neighbors (2019) Broadcast media: state-owned TV station,2
state-owned radio networks; several privately owned TV
stations and a large number of privately owned radio
stations; transmissions of multiple international
broadcasters are accessible; several cable and satellite TV
subscription services are obtainable Internet country code: .gh
Internet users: total: 9,328,018
percent of population: 34.7% (July 2016 est.)
country comparison to the world: 49
Broadband—fixed subscriptions:
total: 62,320
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 130','d6b5e2d16e2fe4b23430ffd18d69af6017d5ab3b1b8e4afb3ad1d2b8775bbd59','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baf8aaaec4b8bf2b356a54d4332220695d23bff35d26f2284f60cff903cf01a4',2021,'GI','Gibraltar','communications',550,'Telephones—fixed lines: total subscriptions: 17,671
subscriptions per 100 inhabitants: 60 (2018 est.)
country comparison to the world: 180
Telephones—mobile cellular:
total subscriptions: 41,045
subscriptions per 100 inhabitants: 139 (2018 est.)
country comparison to the world: 205
Telephone system: general assessment: adequate, automatic
domestic system and adequate international facilities
(2018) domestic: automatic exchange facilities; 67 per 100
fixed-line and 140 per 100 mobile-cellular (2018)
international: country code—350; landing point for the EIG
to Europe, Asia, Africa and the Middle East via submarine
cables; radiotelephone; microwave radio relay; satellite
earth station—1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: Gibraltar Broadcasting Corporation (GBC) provides
TV and radio broadcasting services via 1 TV station and 4
radio stations; British Forces Broadcasting Service (BFBS)
operates 1 radio station; broadcasts from Spanish radio
and TV stations are accessible Internet country code: .gi
Internet users: total: 277,699
percent of population: 94.4% (July 2016 est.)
country comparison to the world: 203
Broadband—fixed subscriptions:
total: 19,232
subscriptions per 100 inhabitants: 65 (2018 est.)
country comparison to the world: 154
Telephones—fixed lines: total subscriptions: 5,078,083
subscriptions per 100 inhabitants: 48 (2018 est.)
country comparison to the world: 30
Telephones—mobile cellular:
total subscriptions: 12,170,757
subscriptions per 100 inhabitants: 114 (2018 est.)
country comparison to the world: 74
Telephone system: general assessment: adequate, modern
networks reach all areas; good mobile telephone and
international service; 3 mobile network operators; 2019 5G
trials and LTE use; despite rough economic conditions
broadband penetration developing (2018) domestic:
microwave radio relay trunk system; extensive open-wire
connections; submarine cable to offshore islands; 48 per
100 for fixed-line and 120 per 100 for mobile-cellular
(2018) international: country code—30; landing points for
the SEA-ME-WE-3, Adria-1, Italy-Greece 1, OTEGLOBE,
MedNautilus Submarine System, Aphrodite 2, AAE-1 and
Silphium optical telecommunications submarine cable that
provides links to Europe, the Middle East, Africa, Southeast
Asia, Asia and Australia; tropospheric scatter; satellite
earth stations—4 (2 Intelsat—1 Atlantic Ocean and 1 Indian
Ocean, 1 Eutelsat, and 1 Inmarsat—Indian Ocean region)
(2019) Broadcast media: broadcast media dominated by the
private sector; roughly 150 private TV channels, about 10
of which broadcast nationwide; 1 government-owned
terrestrial TV channel with national coverage; 3 privately
owned satellite channels; multi-channel satellite and cable
TV services available; upwards of 1,500 radio stations, all
of them privately owned; government-owned broadcaster
has 2 national radio stations Internet country code: .gr
Internet users: total: 7,443,016
percent of population: 69.1% (July 2016 est.)
country comparison to the world: 57
Broadband—fixed subscriptions:
total: 3,961,864
subscriptions per 100 inhabitants: 37 (2018 est.)
country comparison to the world: 35','cb36036a9d4affbb7bf2a734b1594cfbb337418068b87610ffaabecd8b6e68b8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e93aa6c2a86ad35d57d6a4ce4479a0f7f56b72b8b193520a53c777e798e6fb4c',2021,'GD','Grenada','communications',557,'Telephones—fixed lines: total subscriptions: 32,491
subscriptions per 100 inhabitants: 29 (2017 est.)
country comparison to the world: 170
Telephones—mobile cellular:
total subscriptions: 113,177
subscriptions per 100 inhabitants: 101 (2017 est.)
country comparison to the world: 192
Telephone system: general assessment: adequate, automatic,
island-wide telephone system; lack of local competition but
telecoms are a high contributor to overall GDP (2018)
domestic: interisland VHF and UHF radiotelephone links;
29 per 100 for fixed-line and 101 per 100 for mobile-
cellular (2018) international: country code—1-473; landing
points for the ECFS, Southern Caribbean Fiber and
CARCIP submarine cables with links to 13 Caribbean
islands extending from the British Virgin Islands to
Trinidad & Tobago including Puerto Rico and Barbados;
SHF radiotelephone links to Trinidad and Tobago and Saint
Vincent; VHF and UHF radio links to Trinidad (2019)
Broadcast media: multiple publicly and privately owned
television and radio stations; Grenada Information Service
(GIS) is government-owned and provides television and
radio services; the Grenada Broadcasting Network, jointly
owned by the government and the Caribbean
Communications Network of Trinidad and Tobago, operates
a TV station and 2 radio stations; Meaningful Television
(MTV) broadcasts island-wide and is part of a locally-owned
media house, Moving Target Company, that also includes
an FM radio station and a weekly newspaper; multi-channel
cable TV subscription service is provided by Columbus
Communications Grenada (FLOW GRENADA) and _ is
available island wide; approximately 25 private radio
stations also broadcast throughout the country (2019)
Internet country code: .gd
Internet users: total: 62,123
percent of population: 55.9% (July 2016 est.)
country comparison to the world: 185
Broadband—fixed subscriptions:
total: 22,235
subscriptions per 100 inhabitants: 20 (2017 est.)
country comparison to the world: 151
Telephones—fixed lines: total subscriptions: 68,000
subscriptions per 100 inhabitants: 42 (July 2016 est.)
country comparison to the world: 151
Telephones—mobile cellular:
total subscriptions: 181,000
subscriptions per 100 inhabitants: 113 (July 2016 est.)
country comparison to the world: 185
Telephone system: general assessment: modern’ system,
integrated with US facilities for direct dialing, including
free use of 800 numbers (2018) domestic: three major
companies provide both fixed-line and mobile services, as
well as access to the Internet; fixed-line 42 per 100 and 113
per 100 for mobile-cellular (2018) international: country
code—1-671; major landing points for Atisa, HANTRU1,
HK-G, JGA-N, JGA-S, PIPE-1, SEA-US, SxS, Tata TGN-
Pacific, AJC, GOKI, AAG, AJC and Mariana-Guam Cable
submarine cables between Asia, Australia, and the US
(Guam is a transpacific communications hub for major
carriers linking the US and Asia); satellite earth stations—2
Intelsat (Pacific Ocean) (2019) Broadcast media: about a
dozen TV channels, including digital channels; multi-
channel cable TV services are available; roughly 20 radio
stations Internet country code: .gu
Internet users: total: 125,328
percent of population: 77% (July 2016 est.)
country comparison to the world: 174','3787fcd4344ffc84361de3faac5da75e701dc2a8f55ab123c2bdc23b94ce1931','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3dce6cccbdc03c67e9d62f104e01dc049888d54e7419e69c6859925fe9eafcf',2021,'SV','El Salvador','communications',568,'Telephones—fixed lines: total subscriptions: 2,436,093
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 54
Telephones—mobile cellular:
total subscriptions: 20,467,520
subscriptions per 100 inhabitants: 123 (2018 est.)
country comparison to the world: 57
Telephone system: general assessment: fairly modern network
centered in the city of Guatemala; one of the lowest
teledensities in the region especially in the country; state-
owned telecommunications company privatized in the late
1990s opened the way for competition; steady improvement
of fixed-line which has also spurred growth in mobile-
cellular and broadband; open regulatory framework
coupled with competition and greater disposable household
revenue spurs growth (2018) domestic: fixed-line
teledensity roughly 15 per 100 persons; fixed-line
investments are being concentrated on improving rural
connectivity; mobile-cellular teledensity about 129 per 100
persons (2018) international: country code—502; landing
points for the ARCOS, AMX-1, American Movil-Texius West
Coast Cable and the SAm-1 fiber-optic submarine cable
system that, together, provide connectivity to South and
Central America, parts of the Caribbean, and the US;
connected to Central American Microwave System; satellite
earth station—1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: 4 privately owned national terrestrial TV channels
dominate TV broadcasting; multi-channel satellite and
cable services are available; 1 government-owned radio
station and hundreds of privately owned radio stations
(2019) Internet country code: .gt
Internet users: total: 5,241,952
percent of population: 65% (2018 est.)
country comparison to the world: 74
Broadband—fixed subscriptions:
total: 506,000
subscriptions per 100 inhabitants: 3 (2017 est.)
country comparison to the world: 84','a7c0dc2d8df39abe16691b5840a93327107b6e15830d95795c662803d63aab2d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e096a71342ff4bfcc3a60be0c683dc5a463a02dd83b93ff67b3a51c03c53d34',2021,'LR','Liberia','communications',577,'Telephones—fixed lines: total subscriptions: 0
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 220
Telephones—mobile cellular:
total subscriptions: 12.013 million
subscriptions per 100 inhabitants: 101 (2018 est.)
country comparison to the world: 75
Telephone system: general assessment: huge improvement
over the last ten years; in May 2019, 4G wifi was launched
in the capital; the capital and the regional administrative
centers have 3G access; in 2018 the set up of an IXP
(Internet Exchange Point) will reduce cost of Internet
bandwidth and improve infrastructure (2018) domestic:
there is national coverage and Conakry is reasonably well-
served; coverage elsewhere remains inadequate but is
improving; fixed-line teledensity less than 1 per 100
persons; mobile-cellular subscribership is expanding
rapidly and now approaches 90 per 100 persons (2018)
international: country code—224; ACE submarine cable
connecting Guinea with 20 landing points in Western and
South Africa and Europe; satellite earth station—1 Intelsat
(Atlantic Ocean (2019) Broadcast media: government
maintains marginal control over broadcast media; single
state-run TV station; state-run radio broadcast station also
operates several stations in rural areas; a dozen private
television stations; a steadily increasing number of
privately owned radio stations, nearly all in Conakry, and
about a dozen community radio stations; foreign TV
programming available via satellite and cable subscription
services (2019) Internet country code: .gn
Internet users: total: 1,185,148
percent of population: 9.8% (July 2016 est.)
country comparison to the world: 129
Broadband—fixed subscriptions:
total: 1,213
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 194
Telephones—fixed lines: total subscriptions: 8,000
subscriptions per 100 inhabitants: less than 1 (July 2016
est.)
country comparison to the world: 197
Telephones—mobile cellular:
total subscriptions: 3,117,002
subscriptions per 100 inhabitants: 66 (July 2016 est.)
country comparison to the world: 141
Telephone system: general assessment: the limited services
available are found almost exclusively in the capital,
Monrovia; fixed-line service stagnant and extremely
limited; telephone coverage extended to a number of other
towns and rural areas by four mobile-cellular network
operators; almost entirely wireless telecommunications
market; mobile market penetration is low compared to
others in the region; number of operators avoid paying
dues and operate despite regulations (2018) domestic:
fixed-line less than 1 per 100; mobile-cellular subscription
base growing and teledensity approached 66 per 100
persons (2018) international: country code—231; landing
point for the ACE submarine cable linking 20 West African
countries and Europe; satellite earth station—1 Intelsat
(Atlantic Ocean) (2019) Broadcast media: 8 private and 1
government-owned TV _ station; satellite TV _ service
available; 1 state-owned radio station; approximately 20
independent radio stations broadcasting in Monrovia, with
approximately 80 more local stations operating in other
areas; transmissions of 4 international (including the
British Broadcasting Corporation and Radio France
Internationale) broadcasters are available (2019) Internet
country code: .lr
Internet users: total: 314,717
percent of population: 7.3% (July 2016 est.)
country comparison to the world: 159
Broadband—fixed subscriptions:
total: 8,000
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 174
Telephones—fixed lines: total subscriptions: 1.576 million
subscriptions per 100 inhabitants: 23.95 (July 2017 est.)
country comparison to the world: 63
Telephones—mobile cellular:
total subscriptions: 6.02 million
subscriptions per 100 inhabitants: 91.48 (July 2017 est.)
country comparison to the world: 115
Telephone system: general assessment: political and security
instability in Libya has disrupted its telecommunications
sector, but much of its infrastructure remains superior to
that in most other African countries; registering a SIM card
now requires proof of ID; govt. established new
independent regulatory authority; LTE-based fixed
broadband network launched (2019) domestic: 23.95 per
100 fixed-line and 91.48 per 100 = mobile-cellular
subscriptions; service generally adequate, but pressure to
rebuild damaged _ infrastructure growing (2019)
international: country code—218; landing points for LFON,
EIG, Italy-Libya, Silphium and Tobrok-Emasaed submarine
cable system connecting Europe, Africa, the Middle East
and Asia; satellite earth stations—4 Intelsat, Arabsat, and
Intersputnik; microwave radio relay to Tunisia and Egypt;
tropospheric scatter to Greece; participant in Medarabtel
(2019) Broadcast media: state-funded and private TV stations;
some provinces operate local TV stations; pan-Arab satellite
TV stations are available; state-funded radio (2019) Internet
country code: .ly
Internet users: total: 1,389,750
percent of population: 21.3% (July 2017 est.)
country comparison to the world: 123
Broadband—fixed subscriptions:
total: 168,920
subscriptions per 100 inhabitants: 3 (2017 est.)
country comparison to the world: 113
Telephones—fixed lines: total subscriptions: 15,243
subscriptions per 100 inhabitants: 40 (2018 est.)
country comparison to the world: 186
Telephones—mobile cellular:
total subscriptions: 47,272
subscriptions per 100 inhabitants: 123 (2018 est.)
country comparison to the world: 204
Telephone system: general assessment: automatic telephone
system; 44 Internet service providers in Liechtenstein and
Switzerland combined (2018) domestic: fixed-line 41 per
100 and mobile-cellular services 122 per 100; widely
available (2018) international: country code—423; linked to
Swiss networks by cable and microwave radio relay
Broadcast media: relies on foreign terrestrial and satellite
broadcasters for most broadcast media services; first
Liechtenstein-based TV station established August 2008;
Radio Liechtenstein operates multiple radio stations; a
Swiss-based broadcaster operates one radio station in
Liechtenstein Internet country code: .li
Internet users: total: 37,214
percent of population: 98.1% (July 2016 est.)
country comparison to the world: 200
Broadband—fixed subscriptions:
total: 16,712
subscriptions per 100 inhabitants: 43 (2018 est.)
country comparison to the world: 158','89bd7f4c04eef27d69a8be1418544853b08474d56defcdfbe01932a1d4056aeb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3454ee2cd65f2b4789c982aa317fe88a613061fd42c90a1cbfbf2f18beeb4984',2021,'IT','Italy','communications',587,'Telephone system: general assessment: automatic digital
exchange (2018) domestic: connected via fiber-optic cable
to Telecom Italia network (2018)
international: country code—39; uses Italian system
Broadcast media: the Vatican Television Center (CTV)
transmits live broadcasts of the Pope’s Sunday and
Wednesday audiences, as well as the Pope’s_ public
celebrations; CTV also produces documentaries; Vatican
Radio is the Holy See’s official broadcasting service
broadcasting via shortwave, AM and FM frequencies, and
via satellite and Internet connections Internet country code:
va
Communications—note: the Vatican Apostolic Library is one of
the world’s oldest libraries, formally established in 1475,
but actually much older; it holds a significant collection of
historic texts including 1.1 million printed books and
75,000 codices (manuscript books with handwritten
contents); it serves as a research library for history, law,
philosophy, science, and theology; the library’s collections
have been described as “the world’s greatest treasure
house of the writings at the core of Western tradition”','aa335ee2acc5ec93a3a55d3fecd4b8d5a4804aea357677824a2eb422a907495b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32257b7b648a6b12f7eac02e8b53a2e29e0c235e77b239c6d32b1f48e0c1279c',2021,'IE','Ireland','communications',599,'Telephones—fixed lines: total subscriptions: 1,829,166
subscriptions per 100 inhabitants: 36 (2018 est.)
country comparison to the world: 60
Telephones—mobile cellular:
total subscriptions: 4,971,493
subscriptions per 100 inhabitants: 98 (2018 est.)
country comparison to the world: 122
Telephone system: general assessment: modern digital system
using cable and microwave radio relay; previous depressed
economic climate has changed to one with Ireland having
one of the highest GDP growth rates in Europe which
translates to mean spending among telecom consumers;
introduction of flat-rate plans; upgraded LTE technologies
in rural areas; government intends to spend millions on the
National Broadband Plan (NBP) initiative to change the
broadband landscape (2018) domestic: increasing levels of
broadband access particularly in urban areas; fixed-line 37
per 100 and mobile-cellular 98 per 100 subscriptions
(2018) international: country code—353; landing point for
the AEConnect -1, Celtic-Norse, Havfrue/AEC-2, GTT
Express, Cleltic, ESAT-1, IFC-1, Solas, Pan European
Crossing, ESAT-2, CeltixConnect -1 & 2, GTT Atlantic,
Sirius South, Emerald Bridge Fibres and Geo Eirgrid
submarine cable with links to the US, Canada, Norway, Isle
of Man and UK; satellite earth stations—81 (2019) Broadcast
media: publicly owned broadcaster Radio Telefis Eireann
(RTE) operates 4 TV stations; commercial TV stations are
available; about 75% of households utilize multi-channel
satellite and TV services that provide access to a wide
range of stations; RTE operates 4 national radio stations
and has launched digital audio broadcasts on several
stations; a number of commercial broadcast stations
operate at the national, regional, and local levels (2019)
Internet country code: .ie
Internet users: total: 4,069,432
percent of population: 82.2% (July 2016 est.)
country comparison to the world: 87
Broadband—fixed subscriptions:
total: 1,430,160
subscriptions per 100 inhabitants: 28 (2018 est.)
country comparison to the world: 65
Telephone system: domestic: landline, telefax, mobile cellular
telephone system
international: country code—44; _ fiber-optic cable,
microwave radio relay, satellite earth station, submarine
cable Broadcast media: national public radio broadcasts over
3 FM stations and 1 AM station; 2 commercial broadcasters
operating with 1 having multiple FM stations; receives
radio and TV services via relays from British TV and radio
broadcasters Internet country code: .im','1740b68ebf2f2beec75132f1906e88d4cfd1cc50169a7ae708e554468ee8069c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac26ff26056b5e1a27c9a5f0f038acaa830bb772b714db943872af2b2c794f74',2021,'CU','Cuba','communications',612,'Telephones—fixed lines: total subscriptions: 363,820
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 106
Telephones—mobile cellular: total subscriptions: 2,964,974
subscriptions per 100 inhabitants: 105 (2018 est.)
country comparison to the world: 142
Telephone system: general assessment: fully automatic
domestic telephone network; LTE networks providing
coverage to 90% of the island population (2018) domestic:
the 1999 agreement to open the '' market for
telecommunications services resulted in rapid growth in
mobile-cellular telephone usage, 103 per 100 subscriptions,
while the number of fixed-lines, 10 per 100, subscriptions
has declined (2018) international: country code—1-876 and
1-658; landing points for the ALBA-1, CFX-1, Fibralink,
East-West, and Cayman- Jamaican Fiber System submarine
cables providing connections to South America, parts of the
Caribbean, Central America and the US; satellite earth
stations—2 Intelsat (Atlantic Ocean) (2019) Broadcast media:
3 free-to-air TV stations, subscription cable services, and
roughly 30 radio stations (2019) Internet country code: .jm
Internet users: total: 1,336,653
percent of population: 45% (July 2016 est.)
country comparison to the world: 125
Broadband—fixed subscriptions:
total: 284,756
subscriptions per 100 inhabitants: 10 (2018 est.)
country comparison to the world: 103
Broadcast media: a CoaStal radio station has been remotely
operated since 1994
Telephones—fixed lines: total subscriptions: 63,525,713
subscriptions per 100 inhabitants: 50 (2018 est.)
country comparison to the world: 3
Telephones—mobile cellular:
total subscriptions: 179,872,794
subscriptions per 100 inhabitants: 143 (2018 est.)
country comparison to the world: 7
Telephone system: general assessment: excellent domestic
and international service; Japan has exceedingly high
mobile, mobile broadband and_ (fixed broadband
penetration; one of Japan’s largest e-commerce companies
planning to build its own nationwide stand-alone 5G mobile
network; in 2019, Japan govt released spectrum for 5G
services to be commercially available in 2020 (2018)
domestic: high level of modern technology and excellent
service of every kind; 51 per 100 for fixed-line and 135 per
100 for mobile-cellular subscriptions (2018) international:
country code—81; numerous submarine cables with landing
points for HSCS, JIH, RJCN, APCN-2, JUS, EAC-C2C, PC-1,
Tata TGN-Pacific, FLAG North Asia Loop/REACH North
Asia Loop, APCN-2, FASTER, SJC, SJC2, Unity/EAC-Pacific,
JGA-N, APG, ASE, AJC, JUPITER, MOC, Okinawa Cellular
Cable, KJCN, GOKI, KJCN, and SeaMeWE-3, submarine
cables provide links throughout Asia, Australia, the Middle
East, Europe, Southeast Asia, Africa and US; satellite earth
stations—7 Intelsat (Pacific and Indian Oceans), 1
Intersputnik (Indian Ocean region), 2 Inmarsat (Pacific and
Indian Ocean regions), and 8 SkyPerfect JSAT (2019)
Broadcast media: a mixture of public and commercial
broadcast TV and radio stations; 6 national terrestrial TV
networks including 1 public broadcaster; the large number
of radio and TV stations available provide a wide range of
choices; satellite and cable services provide access to
international channels (2019) Internet country code: .jp
Internet users: total: 116,565,962
percent of population: 92% (July 2016 est.)
country comparison to the world: 5
Broadband—fixed subscriptions:
total: 41,496,293
subscriptions per 100 inhabitants: 33 (2018 est.)
country comparison to the world: 3
Telephones—fixed lines: total subscriptions: 55,938
subscriptions per 100 inhabitants: 58 (July 2016 est.)
country comparison to the world: 158
Telephones—mobile cellular:
total subscriptions: 122,668
subscriptions per 100 inhabitants: 119 (July 2016 est.)
country comparison to the world: 191
Telephone system: general assessment: modern system with
broadband access (2018) domestic: fixed-line and mobile-
cellular services widely available; fixed-line 58 per 100 and
mobile-cellular 119 per 100 _ subscriptions (2018)
international: country code—44; landing points for the
INGRID, Uk-Channel Islands-8, and Guernsey-Jersey-4,
submarine cable connectivity to Guernsey, the UK, and
France (2019) Broadcast media: multiple UK terrestrial TV
broadcasts are received via a transmitter in Jersey; satellite
packages available; BBC Radio Jersey and 1 other radio
station operating Internet country code: .je
Internet users: total: 58,000
percent of population: 59.6% (July 2016 est.)
country comparison to the world: 188','f0b834dba8af2409cd778114b795ff352cb7c235c0e52f68888f78581dc31b41','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98cb172b7a66647326eaa628347f25e59908b7fd2128a664291a1a3b2d3c18b8',2021,'JO','Jordan','communications',621,'Telephones—fixed lines: total subscriptions: 369,145
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 105
Telephones—mobile cellular:
total subscriptions: 8,731,760
subscriptions per 100 inhabitants: 83 (2018 est.)
country comparison to the world: 93
Telephone system: general assessment: microwave radio relay
transmission and coaxial and fiber-optic cable are
employed on trunk lines; growing mobile-cellular usage in
both urban and rural areas is reducing use of fixed-line
services; recent influx of refugees putting burden on
country’s economy, infrastructure and society; mobile
broadband area of growth with 4G services (2019)
domestic: 1995 telecommunications law opened all non-
fixed-line services to private competition; in 2005,
monopoly over fixed-line services terminated and the entire
telecommunications sector was opened to competition;
currently multiple mobile-cellular providers with
subscribership up to 96 per 100 persons; fixed-line 4 per
100 persons (2018) international: country code—962;
landing point for the FEA and Taba-Agaba submarine cable
networks providing connectivity to Europe, the Middle
East, Southeast Asia and Asia; satellite earth stations—33
(3 Intelsat, 1 Arabsat, and 29 land and maritime Inmarsat
terminals (2019) Broadcast media: radio and TV dominated by
the government-owned Jordan Radio and_ Television
Corporation (JRIV) that operates a main network, a sports
network, a film network, and a satellite channel; first
independent TV broadcaster aired in 2007; international
satellite TV and Israeli and Syrian TV broadcasts are
available; roughly 30 radio stations with JRTV operating the
main government-owned station; transmissions of multiple
international radio broadcasters are available Internet
country code: .jO
Internet users: total: 5,099,674
percent of population: 62.3% (July 2016 est.)
country comparison to the world: 76
Broadband—fixed subscriptions:
total: 399,596
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 90','e3081e3e6a62485e8dbe86a5ef40426f317a0dcf6275ef3ac8cfba275c59b4c2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81c541b6ce25fcdcb6c47f74c56690ce88fe42489648df0726d3a0be3ac1d504',2021,'KZ','Kazakhstan','communications',630,'Telephones—fixed lines: total subscriptions: 3,350,900
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 41
Telephones—mobile cellular:
total subscriptions: 26,065,600
subscriptions per 100 inhabitants: 139 (2018 est.)
country comparison to the world: 48
Telephone system: general assessment: one of the most
progressive telecoms sectors in Central Asia; vast 4G
network; low fixed-line and fixed-broadband penetration,
moderate mobile broadband penetration and high mobile
penetration (2018) domestic: intercity by landline and
microwave radio relay; number of fixed-line connections is
20 per 100 persons; mobile-cellular usage increased rapidly
and the subscriber base approaches 143 per 100 persons
(2018) international: country code—7; international traffic
with other former Soviet republics and China carried by
landline and microwave radio relay and with other
countries by satellite and by the Trans-Asia-Europe (TAE)
fiber-optic cable; satellite earth stations—2 Intelsat
Broadcast media: the state owns nearly all radio and TV
transmission facilities and operates national TV and radio
networks; there are 96 TV channels, many of which are
owned by the government, and 4 state-run radio stations;
some former state-owned media outlets have been
privatized; households with satellite dishes have access to
foreign media; a small number of commercial radio stations
operate along with state-run radio stations; recent
legislation requires all media outlets to register with the
government and all TV providers to broadcast in digital
format by 2018; broadcasts reach some 99% of the
population as well as neighboring countries Internet country
code: .Kz
Internet users: total: 14,100,751
percent of population: 76.8% (July 2016 est.)
country comparison to the world: 42
Broadband—fixed subscriptions:
total: 2,462,900
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 50
Telephones—fixed lines: total subscriptions: 65,644
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 153
Telephones—mobile cellular:
total subscriptions: 49,501,430
subscriptions per 100 inhabitants: 97 (2018 est.)
country comparison to the world: 31
Telephone system: general assessment: the mobile-cellular
system is generally good, especially in urban areas; fixed-
line telephone system is small and inefficient; trunks are
primarily microwave’ radio_ relay; to encourage
advancement of the LTE services the govt. has fostered an
open-access approach; govt. progresses with national
broadband strategy; more licensing being awarded has led
to competition which is good for growth (2018) domestic:
multiple providers in the mobile-cellular segment of the
market fostering a boom in mobile-cellular telephone usage
with teledensity reaching 90 per 100 persons; fixed-line
subscriptions stand at less than 1 per 100 persons (2018)
international: country code—254; landing point for the
EASSy, TEAMS, LION2, DARE1, PEACE Cable, and
SEACOM fiber-optic submarine cable systems covering
East, North and South Africa, Europe, the Middle East, and
Asia; satellite earth stations—4 Intelsat; launched first
micro satellites in 2018 (2019) Broadcast media: about a half-
dozen large-scale privately owned media companies with
TV and radio stations, as well as a state-owned TV
broadcaster, provide service nationwide; satellite and cable
TV subscription services available; state-owned radio
broadcaster operates 2 national radio channels and
provides regional and local radio services in multiple
languages; many private radio stations broadcast on a
national level along with over 100 private and non-profit
regional stations broadcasting in local languages; TV
transmissions of all major international broadcasters
available, mostly via paid subscriptions; direct radio
frequency modulation transmissions available for several
foreign government-owned broadcasters (2019) Internet
country code: .ke
Internet users: total: 12,165,597
percent of population: 26% (July 2016 est.)
country comparison to the world: 45
Broadband—fixed subscriptions:
total: 371,498
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 92
Telephones—fixed lines: total subscriptions: 0
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 222
Telephones—mobile cellular:
total subscriptions: 58,838
subscriptions per 100 inhabitants: 54 (2018 est.)
country comparison to the world: 202
Telephone system: general assessment: generally good quality
national and international service; wireline service
available on Tarawa and Kiritimati (Christmas Island);
connections to outer islands by HF/VHF radiotelephone;
recently formed mobile network operator (MNO) is
implementing the first phase of improvements with 3G and
4G upgrades on some islands; islands are connected to
each other and the rest of the world via satellite domestic:
fixed-line 1 per 100 and mobile-cellular 43 per 100
subscriptions
international: country code—686; landing point for the
Southern Cross NEXT submarine cable system from
Australia, 7 Pacific Ocean island countries to the US;
satellite earth station—1 Intelsat (Pacific Ocean) (2019)
Broadcast media: Multi-channel TV packages provide access
to Australian and US stations; 1 government-operated radio
station broadcasts on AM, FM, and shortwave (2017)
Internet country code: .ki
Internet users: total: 14,649
percent of population: 13.7% (July 2016 est.)
country comparison to the world: 208
Broadband—fixed subscriptions:
total: 884
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 198
Telephones—fixed lines: total subscriptions: 25,906,849
subscriptions per 100 inhabitants: 50 (2018 est.)
country comparison to the world: 10
Telephones—mobile cellular:
total subscriptions: 66,355,778
subscriptions per 100 inhabitants: 129 (2018 est.)
country comparison to the world: 23
Telephone system: general assessment: excellent domestic
and international services featuring rapid incorporation of
new technologies; ranked ist out of 34 Asian telecoms;
exceedingly high mobile and mobile broadband penetration
and very high fixed broadband penetration; strong support
from govt, savvy population has catapulted the nation into
one of the world’s most active telecommunication markets;
5G services to go live for enterprise customers in 2019;
slower growth predicted over the next five years to 2023;
Chinese telecommunications company Huawei has
partnered with other MNOs in South Korea (2018)
domestic: fixed-line 52 per 100 and mobile-cellular services
124 per 100 persons widely available; rapid assimilation of
a full range of telecommunications technologies leading to
a boom in e-commerce (2018) international: country code—
82; landing points for EAC-C2C, FEA, SeaMeWe-3, TPE,
APCN-2, APG, FLAG North Asia Loop/REACH North Asia
Loop, KJCN, NCP and SJC2 submarine cables providing
links throughout Asia, Australia, the Middle East, Africa,
Europe, Southeast Asia and US; satellite earth stations—66
(2019) Broadcast media: multiple national TV networks with 2
of the 3 largest networks publicly operated; the largest
privately owned network, Seoul Broadcasting Service
(SBS), has ties with other commercial TV networks; cable
and satellite TV subscription services available; publicly
operated radio broadcast networks and many privately
owned radio broadcasting networks, each with multiple
affiliates, and independent local stations Internet country code:
.kr
Internet users: total; 44.153 million
percent of population: 89.9% (July 2016 est.)
country comparison to the world: 17
Broadband—fixed subscriptions:
total: 21,285,858
subscriptions per 100 inhabitants: 41 (2018 est.)
country comparison to the world: 9
Telephones—fixed lines: total subscriptions: 5.315 million
subscriptions per 100 inhabitants: 132 (Jjanuary 2019 est.)
country comparison to the world: 29
Telephones—mobile cellular:
total subscriptions: 8.575 million
subscriptions per 100 inhabitants: 160 (July 2016 est.)
country comparison to the world: 94
Telephone system: general assessment: telecommunications
network is gradually improving for the former Soviet
republic; state control over most economic activities has
not helped growth; mobile market will see slow growth;
some rural areas are still without telephones; mobile
broadband is in the early stages of development (2018)
domestic: Turkmentelekom, in cooperation with foreign
partners, has installed high-speed fiber-optic lines and has
upgraded most of the country’s telephone exchanges and
switching centers with new digital technology; fixed-line 13
per 100 and mobile-cellular teledensity is about 160 per
100 persons; Russia’s Mobile TeleSystems (MTS), the only
foreign mobile-cellular service provider in Turkmenistan,
suspended operations in September 2017 due to the state-
owned telecom company cutting MTS’ access. to
international and long-distance communication services
and Internet; Turkmenistan’s first telecommunication
satellite was launched in 2015 and is expected to greatly
improve connectivity in the country (2018) international:
country code—993; linked by fiber-optic cable and
microwave radio relay to other CIS republics and to other
countries by leased connections to the Moscow
international gateway switch; an exchange in Ashgabat
switches international traffic through Turkey via Intelsat;
satellite earth stations—1 Orbita and 1 Intelsat (2018)
Broadcast media: broadcast media is government controlled
and censored; 7 state-owned TV and 4 state-owned radio
networks; satellite dishes and programming provide an
alternative to the state-run media; officials sometimes limit
access to satellite TV by removing satellite dishes Internet
country code: .t{m
Internet users: total: 951,925 (2019 est.) percent of population:
24% (July 2016 est.)
country comparison to the world: 132
Broadband—fixed subscriptions: total: 4,000
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 183
Telephone system: general assessment: fully digital system
with international direct dialing; broadband access;
expanded FttP (Fiber to the Home) markets; LTE launches;
regulatory development (2018) domestic: full range of
services available; GSM wireless service available; (2018)
international: country code—1-649; landing point for the
ARCOS fiber-optic telecommunications submarine cable
providing connectivity to South and Central America, parts
of the Caribbean, and the US; satellite earth station—1
Intelsat (Atlantic Ocean) (2020) Broadcast media: no local
terrestrial TV stations, broadcasts from the Bahamas can
be received and multi-channel cable and satellite TV
services are available; government-run radio network
operates alongside private broadcasters with a total of
about 15 stations Internet country code: .tc
Telephones—fixed lines: total subscriptions: 2,000
subscriptions per 100 inhabitants: 18 (July 2016 est.)
country comparison to the world: 215
Telephones—mobile cellular:
total subscriptions: 7,600
subscriptions per 100 inhabitants: 69 (July 2016 est.)
country comparison to the world: 215
Telephone’ system: general assessment: serves particular
needs for internal communications; small global scale of
10,000 people on 9 inhabited islands; mobile subscriber
penetration at 40% and broadband at 10% penetration;
govt owned and sole provider of telecommunications
services; Satellite technology; hopeful future 5-year
contract to improve high speed Internet for schools,
hospitals and banks; 3G not launched yet (2018) domestic:
radiotelephone communications between islands; fixed-line
18 per 100 and mobile-cellular 69 per 100 (2018)
international: country code—688; international calls can be
made by satellite Broadcast media: no TV stations; many
households use _ satellite dishes to watch foreign TV
stations; 1 government-owned radio station, Radio Tuvalu,
includes relays of programming from _ international
broadcasters (2019) Internet country code: .tv
Internet users: total: 5,042
percent of population: 46% (July 2016 est.)
country comparison to the world: 214
Broadband—fixed subscriptions:
total: 1,000
subscriptions per 100 inhabitants: 9 (2017 est.)
country comparison to the world: 197
Telephones—fixed lines: total subscriptions: 3,460,258
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 40
Telephones—mobile cellular:
total subscriptions: 23,226,156
subscriptions per 100 inhabitants: 77 (2018 est.)
country comparison to the world: 51
Telephone system: general assessment: digital exchanges in
large cities and in rural areas; increased investment in
infrastructure and growing subscriber base; fixed-line is
underdeveloped due to preeminence of mobile market;
growth in broadband penetration in the future; Wi-Fi
hotspot in the city of Tashkent in the future (2018)
domestic: fixed-line 12 per 100 person and mobile-cellular
82 per 100; the state-owned telecommunications company,
Uzbek Telecom, owner of the fixed-line telecommunications
system, has used loans from the Japanese government and
the China Development Bank to upgrade fixed-line services
including conversion to digital exchanges; mobile-cellular
services are provided by 2 private and 3 state-owned
operators with a total subscriber base of 22.8 million as of
January 2018 (2018) international: country code—998;
linked by fiber-optic cable or microwave radio relay with
CIS member states and to other countries by leased
connection via the Moscow international gateway switch;
the country also has a link to the Trans-Asia-Europe (TAE)
fiber-optic cable; Uzbekistan has supported the national
fiber- optic backbone project of Afghanistan since 2008
Broadcast media: the government controls media; 17 state-
owned broadcasters—13 TV and 4 radio—provide service to
virtually the entire country; about 20 privately owned TV
stations, overseen by local officials, broadcast to local
markets; privately owned TV stations are required to lease
transmitters from the government-owned Republic TV and
Radio Industry Corporation; in 2019, the Uzbek Agency for
Press and Information was reorganized into the Agency of
Information and Mass Communications and became part of
the Uzbek Presidential Administration with recent
appointment of the Uzbek President’s elder daughter as it
deputy director (2019) Internet country code: .UZ
Internet users: total: 15,157,210
percent of population: 46.8% (July 2018 est.)
country comparison to the world: 40
Broadband—fixed subscriptions:
total: 4,123,508
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 33','5fb670532b23596a41be7b9b61fac0164accaf576232200767a78a5f90ab95ed','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('553c22d059fdb2a4ffb43ace59c734f57bc106e30845aa5aed05c5e8b054d8a5',2021,'RS','Serbia','communications',646,'Telephones—fixed lines: total subscriptions: 831,470
subscriptions per 100 inhabitants: 45 (July 2016 est.)
country comparison to the world: 81
Telephones—mobile cellular:
total subscriptions: 562,000
subscriptions per 100 inhabitants: 31 (July 2016 est.)
country comparison to the world: 171
Telephone system: general assessment: Kosovo being part of
the EU pre-accession process has helped with their
progress in the telecom industry, following a regulatory
framework, European standards, and a market of new
players encourages development in its telecommunications;
2 MNOs dominate the sector; poor telecom infrastructure
means low fixed-line penetration (2018) domestic: fixed-line
stands at 45 per 100 and mobile-cellular 31 per 100
persons (2018) international: country code—383
Internet country code: xk
note: assigned as a temporary code under UN Security
Council resolution 1244/99
Telephones—fixed lines: total subscriptions: 2,574,691
subscriptions per 100 inhabitants: 36 (2018 est.)
country comparison to the world: 52
Telephones—mobile cellular:
total subscriptions: 8,431,365
subscriptions per 100 inhabitants: 119 (2018 est.)
country comparison to the world: 97
Telephone system: general assessment: Serbia’s integration
with the EU has helped regulator reforms and promotion of
telecoms; wireless service are available through multiple
providers; national coverage is growing very rapidly; best
telecommunications services are centered in urban centers;
4G/LTE mobile network launched; 5G trials (2018)
domestic: fixed-line 37 per 100 and mobile-cellular 121 per
100 persons (2018)
international: country code—381
Internet country code: .rS
Internet users: total: 4,790,488
percent of population: 67.1% (July 2016 est.)
country comparison to the world: 78
Broadband—fixed subscriptions: total: 1,552,160
subscriptions per 100 inhabitants: 22 (2018 est.)
country comparison to the world: 62','d6778572859058e5b7436afff86c1ad8662470a242c5e48deaa66bec1223c51f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01355cf3eeba7945879cd058cfa889edd4da2fcf7c98767f6bf3370d7e6c55b0',2021,'KW','Kuwait','communications',656,'Telephones—fixed lines: total subscriptions: 515,542
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 95
Telephones—mobile cellular:
total subscriptions: 7,099,848
subscriptions per 100 inhabitants: 243 (2018 est.)
country comparison to the world: 106
Telephone system: general assessment: the quality of service
is excellent; new telephone exchanges provide a large
capacity for new subscribers; trunk traffic is carried by
microwave radio relay, coaxial cable, and open-wire and
fiber-optic cable; a 4G LTE mobile-cellular telephone
system operates throughout Kuwai; Internet access is
available via 4G LTE connections for fixed and mobile
users; high ownership of smart phone in Kuwait; one of the
highest mobile penetration rates in the world (2018)
domestic: fixed-line subscriptions are 19 per 100 and
mobile-cellular stands at 179 per 100 subscriptions (2018)
international: country code—965; landing points for the
FOG, GBICS, MENA, Kuwait-Iran, and FALCON submarine
cables linking Africa, the Middle East, and Asia; microwave
radio relay to Saudi Arabia; satellite earth stations—6 (3
Intelsat—1 Atlantic Ocean and 2 Indian Ocean, 1 Inmarsat
—Atlantic Ocean, and 2 Arabsat) (2019) Broadcast media:
state-owned TV broadcaster operates 4 networks and a
satellite channel; several private TV broadcasters have
emerged; satellite TV available and pan-Arab TV stations
are especially popular; state-owned Radio Kuwait
broadcasts on a number of channels in Arabic and English;
first private radio station emerged in 2005; transmissions
of at least 2 international radio broadcasters are available
(2019) Internet country code: .kKw
Internet users: total: 2,219,972
percent of population: 78.4% (July 2016 est.)
country comparison to the world: 108
Broadband—fixed subscriptions:
total: 103,821
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 121
Telephones—fixed lines: total subscriptions: 331,140
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 108
Telephones—mobile cellular:
total subscriptions: 8,735,246
subscriptions per 100 inhabitants: 149 (2018 est.)
country comparison to the world: 92
Telephone system: general assessment: digital radio-relay
stations, and fiber-optic links; low fixed-line and _ fixed-
broadband penetration and low to moderate mobile
broadband penetration; international connectivity
continues to grow; 4 mobile networks in operation; 4G
networks cover over 50% of the nation, eventually 5G
networks will be available (2018) domestic: fixed-line
penetration 6 per 100 persons remains low and
concentrated in urban areas; mobile-cellular subscribership
up to over 127 per 100 persons (2018) international:
country code—996; connections with other CIS countries
by landline or microwave radio relay and with other
countries by leased connections with Moscow international
gateway switch and by satellite; satellite earth stations—2
(1 Intersputnik, 1 Intelsat) (2019) Broadcast media: state-
funded public TV broadcaster KIRK has nationwide
coverage; also operates Ala-Too 24 news channel which
broadcasts 24/7 and 4 other educational, cultural, and
sports channels; ELTR and Channel 5 are state-owned
stations with national reach; the switchover to digital TV in
2017 resulted in private TV station growth; approximately
20 stations are struggling to increase their own content up
to 50% of airtime, as required by law, instead of
rebroadcasting primarily programs from Russian channels
or airing unlicensed movies and music; 3 Russian TV
stations also broadcast; state-funded radio stations and
about 10 significant private radio stations also exist (2019)
Internet country code: .kg
Internet users: total: 1,976,006
percent of population: 34.5% (July 2016 est.)
country comparison to the world: 113
Broadband—fixed subscriptions:
total: 355,640
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 95
Telephones—fixed lines: total subscriptions: 1,482,276
subscriptions per 100 inhabitants: 20 (2018 est.)
country comparison to the world: 65
Telephones—mobile cellular:
total subscriptions: 3,662,336
subscriptions per 100 inhabitants: 51 (2018 est.)
country comparison to the world: 133
Telephone system: general assessment: service to public is
generally improving; the government relies on a
radiotelephone network to communicate with remote areas;
regulatory reform below industry standards; low fixed-
broadband penetration due to dominance of mobile
platforms; strong boost in mobile broadband penetration
but still low compared to other Asian markets; development
of mobile broadband Internet services given the expansion
of 4G services (2018) domestic: fixed-line 16 per 100 and
92 per 100 for mobile-cellular subscriptions (2018)
international: country code—856; satellite earth station—1
Intersputnik (Indian Ocean region) and a second to be
developed by China Broadcast media: 6 TV stations operating
out of Vientiane—3 government-operated and the others
commercial; 17 provincial stations operating with nearly all
programming relayed via satellite from the government-
operated stations in Vientiane; Chinese and Vietnamese
programming relayed via satellite from Lao National TV;
broadcasts available from stations in Thailand and Vietnam
in border areas; multi-channel satellite and cable TV
systems provide access to a wide range of foreign stations;
state-controlled radio with state-operated Lao National
Radio (LNR) broadcasting on 5 frequencies—1 AM, 1 SW,
and 3 FM; LNR’s AM and FM programs are relayed via
satellite constituting a large part of the programming
schedules of the provincial radio stations; Thai radio
broadcasts available in border areas and transmissions of
multiple international broadcasters are also accessible
Internet country code: la
Internet users: total: 1.258 million
percent of population: 18.2% (July 2016 est.)
country comparison to the world: 128
Broadband—fixed subscriptions:
total: 45,379
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 136','4fe0f8e2ecd429d03ef35f030e0d1e71cdf5ad7af4f5a30bb8814c681c836029','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6773b3f89f607170494e25ada13cb752049f44ac86668a633068b347d27bdea7',2021,'BY','Belarus','communications',665,'Telephones—fixed lines: total subscriptions: 266,214
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 120
Telephones—mobile cellular:
total subscriptions: 2,070,180
subscriptions per 100 inhabitants: 108 (2018 est.)
country comparison to the world: 150
Telephone system: general assessment: recent efforts focused
on bringing competition to the telecommunications sector;
the number of fixed lines is decreasing as mobile-cellular
telephone service expands; EU regulatory policies, and
framework provide guidelines for growth; govt. adopted
measures to build a national fiber broadband network, part-
funded by European Commission; commercial 5G services
coming in 2019 (2018) domestic: fixed-line 18 per 100 and
mobile-cellular 127 per 100 subscriptions (2018)
international: country code—371; the Latvian network is
now connected via fiber-optic cable to Estonia, Finland, and
Sweden Broadcast media: several national and regional
commercial TV stations are foreign-owned, 2 national TV
stations are publicly owned; system supplemented by
privately owned regional and local TV stations; cable and
satellite multi-channel TV services with domestic and
foreign broadcasts available; publicly owned broadcaster
operates 4 radio networks with dozens of stations
throughout the country; dozens of private broadcasters also
operate radio stations Internet country code: .lv
Internet users: total: 1,570,374
percent of population: 79.9% (July 2016 est.)
country comparison to the world: 119
Broadband—fixed subscriptions:
total: 525,995
subscriptions per 100 inhabitants: 27 (2018 est.)
country comparison to the world: 83','90de7ee1b476e001fe086b1ba368ce8298f574a58f8fd7376f30500405a37c23','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c72a3826971faf4bfb40b7dc5e2fa366685b52c539976b47ff8740f168c22c6',2021,'LB','Lebanon','communications',670,'Telephones—fixed lines: total subscriptions: 893,529
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 80
Telephones—mobile cellular:
total subscriptions: 4,424,185
subscriptions per 100 inhabitants: 73 (2018 est.)
country comparison to the world: 125
Telephone system: general assessment: new landlines and
fiber-optic networks installed along with faster DSL in
2017; two mobile-cellular networks provide good service,
with 4G LTE services; preparing for 5G service; future
improvements to fiber-optic infrastructure for total nation
coverage in 2020 (2018) domestic: fixed-line 17 per 100
and 79 per 100 for mobile-cellular subscriptions (2018)
international: country code—961; landing points for the
IMEWE, BERYTAR AND CADMOS submarine cable links to
Europe, Africa, the Middle East and Asia; satellite earth
stations—2 Intelsat (1 Indian Ocean and 1 Atlantic Ocean)
(2019) Broadcast media: 7 TV stations, 1 of which is state
owned; more than 30 radio stations, 1 of which is state
owned; satellite and cable TV_ services _ available;
transmissions of at least 2 international broadcasters are
accessible through partner stations (2019) Internet country
code: .lb
Internet users: total: 4,747,542
percent of population: 76.1% (July 2016 est.)
country comparison to the world: 79
Broadband—fixed subscriptions: total: 9,395
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 171','c6d0368bd7de23488992bcd4a313ae4eb6a4e7cc28d4eb94fbe1593977c0008d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19c7d5672bd1c4493080a8971511143519b3f40e7ac1b410aa69412817f6986d',2021,'LU','Luxembourg','communications',683,'Telephones—fixed lines: total subscriptions: 273,530
subscriptions per 100 inhabitants: 45 (2018 est.)
country comparison to the world: 118
Telephones—mobile cellular:
total subscriptions: 798,600
subscriptions per 100 inhabitants: 132 (2018 est.)
country comparison to the world: 163
Telephone system: general assessment: highly developed,
completely automated and efficient system; by 2020 the
government’s program is to provide a 1Gb/s service to all
citizens, and to make Luxembourg the first fully fibred
country in Europe; new law requiring SIM cards be
registered has slowed down growth for mobile subscribers;
9G launch by 2020 (2018) domestic: fixed-line teledensity
about 46 per 100 persons; nationwide mobile-cellular
telephone system with market for mobile-cellular phones
virtually saturated with 134 per 100 mobile-cellular (2018)
international: country code—352
Broadcast media: Luxembourg has a long tradition of
operating radio and TV services for pan-European
audiences and is home to Europe’s largest privately owned
broadcast media group, the RTL Group, which operates 46
TV stations and 29 radio stations in Europe; also home to
Europe’s largest satellite operator, Societe Europeenne des
Satellites (SES); domestically, the RTL Group operates TV
and radio networks; other domestic private radio and TV
operators and French and German stations available;
satellite and cable TV services available Internet country code:
lu
Internet users: total: 567,698
percent of population: 97.5% (July 2016 est.)
country comparison to the world: 147
Broadband—fixed subscriptions:
total: 224,300
subscriptions per 100 inhabitants: 37 (2018 est.)
country comparison to the world: 106','4aaa582ef1ad265452e5992848f25072c1296f0d8f118472a69d935b0d0316a4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d90ee352060f321bba218564fb46cbf4df295a0a68116e2d417edd4acec84a',2021,'MG','Madagascar','communications',691,'Telephones—fixed lines: total subscriptions: 69,046
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 150
Telephones—mobile cellular:
total subscriptions: 10,654,710
subscriptions per 100 inhabitants: 41 (2018 est.)
country comparison to the world: 83
Telephone system: general assessment: system is above
average for the region; competition among the four mobile
service providers has spurred recent growth in the mobile
market and helped the service to be less expensive for the
consumer; LTE services available (2018) domestic: less
than 1 per 100 for fixed-line and mobile-cellular teledensity
about 35 per 100 persons (2018) international: country
code—261; landing points for the EASSy, METISS, and
LION fiber-optic submarine cable systems connecting to
numerous Indian Ocean Islands, South Africa, and Eastern
African countries; satellite earth stations—2 (1 Intelsat—
Indian Ocean, 1 Intersputnik—Atlantic Ocean region)
(2019) Broadcast media: state-owned Radio Nationale
Malagasy (RNM) and Television Malagasy (TVM) have an
extensive national network reach; privately owned radio
and TV broadcasters in cities and major towns; state-run
radio dominates in rural areas; relays of 2 international
broadcasters are available in Antananarivo (2019) Internet
country code: .g
Internet users: total: 1,151,563
percent of population: 4.7% (July 2016 est.)
country comparison to the world: 130
Broadband—fixed subscriptions:
total: 27,211
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 144
Telephones—fixed lines: total subscriptions: 20,290
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 177
Telephones—mobile cellular:
total subscriptions: 178,946
subscriptions per 100 inhabitants: 189 (2018 est.)
country comparison to the world: 187
Telephone system: general assessment: effective system;
radiotelephone communications between islands in the
archipelago (2018) domestic: fixed-line 21 per 100 and
mobile-cellular teledensity is 178 telephones per 100
persons (2018) international: country code—248; landing
points for the PEACE and the SEAS submarine cables
providing connectivity to Europe, the Middle East Africa
and Asia; direct radiotelephone communications with
adjacent island countries and African coastal countries;
satellite earth station—1 Intelsat (Indian Ocean) (2019)
Broadcast media: the national broadcaster, Seychelles
Broadcasting Corporation (SBC), which is funded by
taxpayer money, operates the only terrestrial TV station,
which provides local programming and airs broadcasts
from international services; a privately owned Internet
Protocol Television (IPTV) channel also provides local
programming multi-channel cable and satellite TV are
available through 2 providers; the national broadcaster
operates 1 AM and 1 FM radio station; there are 2 privately
operated radio stations; transmissions of 2 international
broadcasters are accessible in Victoria (2019) Internet
country code: .SC
Internet users: total: 52,664
percent of population: 56.5% (July 2016 est.)
country comparison to the world: 192
Broadband—fixed subscriptions: total: 19,696
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 153','531d4cbef3b09796ccc7228c9cc82356d606d01e15f6c6519fec1575eef623cf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acaf30badaf2d325a74683ebb9fa592707bf3cbd590a5fa5b955a187774260fe',2021,'MT','Malta','communications',708,'Telephones—fixed lines: total subscriptions: 255,437
subscriptions per 100 inhabitants: 57 (2018 est.)
country comparison to the world: 121
Telephones—mobile cellular:
total subscriptions: 615,843
subscriptions per 100 inhabitants: 137 (2018 est.)
country comparison to the world: 167
Telephone system: general assessment: automatic system
featuring submarine cable and microwave radio relay
between islands; one of the most advanced telecoms in
Europe, high penetration of mobile and broadband, and a
way forward to expand e-commerce opportunities; ‘5G
ready’ and LTE _ network; regulatory system _ that
encourages investors (2018) domestic: fixed-line 58 per 100
persons and mobile-cellular subscribership 135 per 100
persons (2018) international: country code—356; landing
points for the Malta-Gozo Cable, VMSCS, GO-1
Mediterranean Cable System, Malta Italy Interconnector,
Melita-1, and the Italy-Malta submarine cable connections
to Italy; satellite earth station—1 Intelsat (Atlantic Ocean)
(2019) Broadcast media: 2 publicly owned TV stations,
Television Malta broadcasting nationally plus = an
educational channel; several privately owned national
television stations, 2 of which are owned by political
parties; Italian and British broadcast programs are
available; multi-channel cable and satellite TV services are
available; publicly owned radio broadcaster operates 3
stations; roughly 20 commercial radio stations (2019)
Internet country code: .mt
Internet users: total: 320,902
percent of population: 77.3% (July 2016 est.)
country comparison to the world: 157
Broadband—fixed subscriptions:
total: 191,833
subscriptions per 100 inhabitants: 43 (2018 est.)
country comparison to the world: 110','f9ac6b33bb3f2a53805b3624ba216cc89e6a5828037d816796a1bd45b5adff00','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('084e184b61b35cf04c95cb39690c34a380994b0df53fbc9f668e0534b9a20eb4',2021,'MH','Marshall Islands','communications',714,'Telephones—fixed lines: total subscriptions: 2,361
subscriptions per 100 inhabitants: 3 (July 2016 est.)
country comparison to the world: 211
Telephones—mobile cellular: total subscriptions: 16,000
subscriptions per 100 inhabitants: 21 (July 2016 est.)
country comparison to the world: 212
Telephone’ system: general assessment: some _ telecom
infrastructure improvements made in recent years; modern
services include fiber optic cable service, cellular, Internet,
international calling, caller ID, and leased data circuits; the
US Government, World Bank, UN and_ International
Telecommunication Union (ITU), have aided _ in
improvements and monetary aid to the islands telecom;
mobile penetrations is around 30%; radio communication is
especially vital to remote islands (2018) domestic: Majuro
Atoll and Ebeye and Kwajalein islands have regular, seven-
digit, direct-dial telephones; other islands interconnected
by high frequency radiotelephone (used mostly for
government purposes) and mini-satellite telephones; fixed-
line 3 per 100 persons and mobile-cellular is 21 per 100
persons (2018) international: country code—692; satellite
earth stations—2 Intelsat (Pacific Ocean); US Government
satellite communications system on Kwajalein Broadcast
media: no TV broadcast station; a cable network is available
on Majuro with programming via videotape replay and
satellite relays; 4 radio broadcast stations; American
Armed Forces Radio and Television Service (AFRTS)
provides satellite radio and television service to Kwajalein
Atoll (2019) Internet country code: .mh
Internet users: total: 21,857
percent of population: 29.8% (July 2016 est.)
country comparison to the world: 204
Broadband—fixed subscriptions:
total: 1,000
subscriptions per 100 inhabitants: 1 (2017 est.)
country comparison to the world: 196
Communications—note: Kwajalein hosts one of four dedicated
ground antennas that assist in the operation of the Global
Positioning System (GPS) navigation system (the others are
at Cape Canaveral, Florida (US), on Ascension (Saint
Helena, Ascension, and Tristan da Cunha), and at Diego
Garcia (British Indian Ocean Territory)) MILITARY AND
SECURITY
Military and security forces: no regular military forces; Marshall
Islands Police Department (2019) Military—note: defense is
the responsibility of the US','979fcee60077f3a3db8e2db01eeeab52a3054047368255410cca2f2b52e6eba6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a1645c8acd6d9441a303d528099cc6e2e1206feadf0541abd79bc50b0ed0f4a',2021,'SN','Senegal','communications',721,'Telephones—fixed lines: total subscriptions: 59,959
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 156
Telephones—mobile cellular:
total subscriptions: 4,566,502
subscriptions per 100 inhabitants: 119 (2018 est.)
country comparison to the world: 124
Telephone system: general assessment: limited system of
cable and open-wire lines, minor microwave radio relay
links, and radiotelephone communications stations; mobile-
cellular services expanding rapidly; 3 mobile network
operators; 3G penetration high; mobile broadband speeds
are low; World Bank and European Investment Bank
Support attempts to improve telecom and improve
regulatory measures; efforts to improve backbone of
network; auction for fourth mobile provider and 4G service
in spring 2019 (2018) domestic: fixed-line teledensity 2 per
100 persons; mobile-cellular network coverage extends
mainly to urban areas with a teledensity of roughly 108 per
100 persons; mostly cable and open-wire lines; a domestic
satellite telecommunications system links Nouakchott with
regional capitals (2018) international: country code—222;
landing point for the ACE submarine cable for connectivity
for 19 West African countries and 2 European countries;
satellite earth stations—3 (1 Intelsat—Atlantic Ocean, 2
Arabsat) (2019) Broadcast media: 10 ‘TV stations: 5
government-owned and 5 private; in October 2017, the
government suspended all private TV stations due to non-
payment of broadcasting fees; as of April 2018, only one
private TV station was broadcasting, Al Mourabitoune, the
official TV of the Mauritanian Islamist party, Tewassoul; the
other stations are negotiating payment options with the
government and hope to be back on the air soon; 18 radio
broadcasters: 15 government-owned, 3 (Radio Nouakchott
Libre, Radio Tenwir, Radio Kobeni) private; all 3 private
radio stations broadcast from Nouakchott; of the 15
government stations, 3 broadcast from Nouakchott (Radio
Mauritanie, Radio Jeunesse, Radio Koran) and the other 12
broadcast from each of the 12 regions outside Nouakchott;
Radio Jeunesse and Radio Koran are now also being re-
broadcast in the regions (2019) Internet country code: .mr
Internet users: total: 661,913
percent of population: 18% (July 2016 est.)
country comparison to the world: 143
Broadband—fixed subscriptions:
total: 13,222
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 163','1f0d4aef3afc735f16cf5ebabe8c58dc0fc7aeee394132371ff8b2c6e6befdca','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('822f73ea63ae8d15411a98e1b258404a4a15f52bc31fa0f44ece9c3458b747c4',2021,'MU','Mauritius','communications',728,'Telephones—fixed lines: total subscriptions: 434,300
subscriptions per 100 inhabitants: 32 (2018 est.)
country comparison to the world: 101
Telephones—mobile cellular:
total subscriptions: 1.918 million
subscriptions per 100 inhabitants: 141 (2018 est.)
country comparison to the world: 154
Telephone system: general assessment: small system with
good service; LTE and fiber broadband service are
available; government building a national Wi-Fi network;
partial privatization of biggest telecommunications
company, open to competition (2018) domestic: fixed-line
teledensity roughly 30 per 100 persons; mobile-cellular
services teledensity approaching 136 per 100 persons
(2018) international: country code—230; landing points for
the SAFE, MARS, IOX Cable System, METISS and LION
submarine cable system that provides links to Asia, Africa,
Southeast Asia, Indian Ocean Islands of Reunion,
Madagascar, and Mauritius; satellite earth station—1
Intelsat (Indian Ocean); new microwave link to Reunion;
HF radiotelephone links to several countries (2019)
Broadcast media: the government maintains control over TV
broadcasting through the Mauritius Broadcasting
Corporation (MBC), which only operates digital TV stations
since June 2015; MBC is a shareholder in a local company
that operates 2 pay-IV stations; the state retains the
largest radio broadcast network with multiple stations;
several private radio broadcasters have entered the market
since 2001; transmissions of at least 2 international
broadcasters are available (2019) Internet country code: .mu
Internet users: total: 717,618
percent of population: 53.2% (July 2016 est.)
country comparison to the world: 140
Broadband—fixed subscriptions:
total: 274,200
subscriptions per 100 inhabitants: 20 (2018 est.)
country comparison to the world: 104','cad8297f6503293d89dcc16f8451bc664d286663625c4cc6d37edcf62bfebe3a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27d9ce5d6cecc589ef115c5c807a5ee0c838219b6e1bf8b87e26e1b463525c93',2021,'MX','Mexico','communications',734,'Telephones—fixed lines: total subscriptions: 21,645,699
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 12
Telephones—mobile cellular:
total subscriptions: 120,173,510
subscriptions per 100 inhabitants: 95 (2018 est.)
country comparison to the world: 14
Telephone system: general assessment: adequate telephone
service for business and government; improving quality and
increasing mobile cellular availability, with mobile
subscribers far outnumbering fixed-line subscribers;
domestic satellite system with 120 earth stations; extensive
microwave radio relay network; considerable use of fiber-
optic cable and coaxial cable; two main MNOs despite
efforts for competition; preparation for 5G and LTE-M
services; Mexico’s first local Internet Exchange Point opens
in Mexico City (2018) domestic: competition has spurred
the mobile-cellular market; fixed-line teledensity exceeds
17 per 100 persons; mobile-cellular teledensity is about 92
per 100 persons (2018) international: country code—52;
Columbus-2 fiber-optic submarine cable with access to the
US, Virgin Islands, Canary Islands, Spain, and Italy; the
Americas Region Caribbean Ring System (ARCOS-1) and
the MAYA-1 submarine cable system together provide
access to Central America, parts of South America and the
Caribbean, and the US; satellite earth stations—120 (32
Intelsat, 2 Solidaridad (giving Mexico improved access to
South America, Central America, and much of the US as
well as enhancing domestic communications), 1 Panamsat,
numerous Inmarsat mobile earth stations); linked to
Central American Microwave System of trunk connections
(2016) Broadcast media: telecom reform in 2013 enabled the
creation of new broadcast television channels after decades
of a quasi-monopoly; Mexico has 821 TV stations and 1,745
radio stations and most are privately owned; the Televisa
group once had a virtual monopoly in TV broadcasting, but
new broadcasting groups and foreign satellite and cable
operators are now available; in 2016, Mexico became the
first country in Latin America to complete the transition
from analog to digital transmissions, allowing for better
image and audio quality and a wider selection of
programming from networks Internet country code: .X
Internet users: total: 73,334,032
percent of population: 59.5% (July 2016 est.)
country comparison to the world: 7
Broadband—fixed subscriptions:
total: 18,359,028
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 10','418cb7c3fbfce693c3ebefc7ec38958b4726aa110c5d037d0d78d547e0606890','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a1404844236677899180fc6ea867bc4ceca16cd7cc0296b90ecb29516f4d89c',2021,'FM','Micronesia, Federated States of','communications',742,'Telephones—fixed lines: total subscriptions: 6,947
subscriptions per 100 inhabitants: 7 (2017 est.)
country comparison to the world: 201
Telephones—mobile cellular:
total subscriptions: 23,114
subscriptions per 100 inhabitants: 22 (2017 est.)
country comparison to the world: 211
Telephone system: general assessment: adequate system
(2016) domestic: islands interconnected by shortwave
radiotelephone (used mostly for government purposes),
satellite (Intelsat) ground stations, and some coaxial and
fiber-optic cable; mobile-cellular service available on the
major islands (2016) international: country code—691;
landing points for the Chuukk-Pohnpei Cable and HANTRU-
1 submarine cable system linking the Federated States of
Micronesia and the US; satellite earth stations—5 Intelsat
(Pacific Ocean) (2019) Broadcast media: no TV broadcast
stations; each state has a multi-channel cable service with
TV transmissions carrying roughly 95% imported
programming and 5% local programming; about a half-
dozen radio stations (2009) Internet country code: .fm
Internet users: total: 33,000
percent of population: 31.5% (July 2016 est.)
country comparison to the world: 201
Broadband—fixed subscriptions:
total: 3,776
subscriptions per 100 inhabitants: 4 (2017 est.)
country comparison to the world: 185','ddf3821d2089aac294a299d1832615eef4a8dacaa4ae5c2f4e4e9a3f3ae4945b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1d3343bd44e0d1a6da4e10e8138805cb23abf2c9dcc65c6b0a8444608d1a40b',2021,'UA','Ukraine','communications',749,'Telephones—fixed lines: total subscriptions: 1,108,200
subscriptions per 100 inhabitants: 32 (2018 est.)
country comparison to the world: 77
Telephones—mobile cellular:
total subscriptions: 3,566,276
subscriptions per 100 inhabitants: 104 (2018 est.)
country comparison to the world: 136
Telephone system: general assessment: the mobile market has
extended the reach of service to outside the cities and
across most of the country; endeavors to join the EU have
promoted regulatory issues to be in line with EU principles
and standards; market is competitive with 80 ISPs active;
LTE services available and mobile broadband growth
(2018) domestic: competition among mobile telephone
providers has spurred subscriptions; little interest in
expanding fixed-line service 33 per 100; mobile-cellular
teledensity sits at 105 per 100 persons (2018)
international: country code—373; service through Romania
and Russia via landline; satellite earth stations—at least 3
(Intelsat, Eutelsat, and Intersputnik) Broadcast media: sState-
owned national radio-ITV broadcaster operates 1 TV and 1
radio station; a total of nearly 70 terrestrial TV channels
and some 50 radio stations are in operation; Russian and
Romanian channels also are available (2019) Internet country
code: .md
Internet users: total: 2,492,444
percent of population: 71% (July 2016 est.)
country comparison to the world: 104
Broadband—fixed subscriptions:
total: 623,135
subscriptions per 100 inhabitants: 18 (2018 est.)
country comparison to the world: 78','909021b5afcbbba5c7a8048b860d4f941f0bc5801005b1288a0c80178ccab6eb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a478c85c06e347a1c55ae9efee51c7ebe181596a7b387b56890aa62720f79142',2021,'MN','Mongolia','communications',762,'Telephones—fixed lines: total subscriptions: 369,853
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 104
Telephones—mobile cellular:
total subscriptions: 4,222,041
subscriptions per 100 inhabitants: 136 (2018 est.)
country comparison to the world: 127
Telephone system: general assessment: network is improving
with international direct dialing available in many areas; a
fiber-optic network has been installed that is improving
broadband and communication services between major
urban centers with multiple companies providing inter-city
fiber-optic cable services; compared to other Asian
countries, Mongolia’s growth in telecommunications is
moderate; mobile broadband is growing with 4 competitive
MNOs (mobile network operators) along with better
tarriffs; 3G mobile broadband products are very popular
with 4G services by 2022; in May 2018 a South Korean
company completed the sale of 40% stake back to
Mongolian government (2019) domestic: very low fixed-line
teledensity 10 per 100; there are four mobile-cellular
providers and subscribership is increasing with 131 per
100 persons (2018) international: country code—976;
satellite earth stations—7 (2016)
Broadcast media: following a law passed in 2005, Mongolia’s
state-run radio and TV provider converted to a public
service provider; also available are 68 radio and 160 TV
stations, including multi-channel satellite and cable TV
providers; transmissions of multiple international
broadcasters are available (2019) Internet country code: .mn
Internet users: total: 674,949
percent of population: 22.3% (July 2016 est.)
country comparison to the world: 142
Broadband—fixed subscriptions:
total: 306,150
subscriptions per 100 inhabitants: 10 (2018 est.)
country comparison to the world: 102','99cc40a19def5fcfda8d5d3207eeeb3d851f644b34b3e17886da523e7400a535','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2200253e6b522dc8d525d82b765fedf43f5038f7301ce77cf9ae7a290915857b',2021,'AL','Albania','communications',770,'Telephones—fixed lines: total subscriptions: 172,880
subscriptions per 100 inhabitants: 28 (2018 est.)
country comparison to the world: 125
Telephones—mobile cellular:
total subscriptions: 1,134,412
subscriptions per 100 inhabitants: 185 (2018 est.)
country comparison to the world: 159
Telephone system: general assessment: modern
telecommunications system with access to European
satellites; telecom sector in-line with EU norms which
means competition, access and tariff structures; DSL,
cable, leased line, fiber and wireless; seasonal tourist have
boosted mobile penetration; LTE technologies available
(2018) domestic: GSM mobile-cellular service, available
through multiple providers with national coverage, is
growing; fixed-line 24 per 100 and mobile-cellular 163 per
100 persons (2018) international: country code—382; 2
international switches connect the national system Broadcast
media: State-funded national radio-TV broadcaster operates
2 terrestrial TV networks, 1 satellite TV channel, and 2
radio networks; 4 local public TV stations and 14 private TV
stations; 14 local public radio stations, 35 private radio
stations, and several on-line media (2019) Internet country
code: .me
Internet users: total: 450,442
percent of population: 69.9% (July 2016 est.)
country comparison to the world: 150
Broadband—fixed subscriptions:
total: 159,029
subscriptions per 100 inhabitants: 26 (2018 est.)
country comparison to the world: 115
Telephones—fixed lines: total subscriptions: 3,000
subscriptions per 100 inhabitants: 57 (July 2016 est.)
country comparison to the world: 209
Telephones—mobile cellular:
total subscriptions: 5,000
subscriptions per 100 inhabitants: 95 (July 2016 est.)
country comparison to the world: 216
Telephone system: general assessment: modern and fully
digitalized; high dependency on tourism and offshore
financial services; operators expand FttP (Fiber to Home)
services; LTE launches and operators invest in mobile
networks (2018) domestic: fixed-line 57 per 100 and
mobile-cellular teledensity 95 per 100 persons (2018)
international: country code—1-664; landing point for the
ECFS optic submarine cable with links to 14 other islands
in the eastern Caribbean extending from the British Virgin
Islands to Trinidad (2019) Broadcast media: Radio
Montserrat, a public radio broadcaster, transmits on 1
station and has a repeater transmission to a second station;
repeater transmissions from the GEM Radio Network of
Trinidad and Tobago provide another 2 radio stations; cable
and satellite TV available (2007) Internet country code: .mS
Internet users: total: 2,860
percent of population: 54.6% (July 2016 est.)
country comparison to the world: 219
West African Development Bank (WADB)
note—also known as Banque Ouest-Africaine de Développement (BOAD); is a
financial institution of WAEMU
established—14 November 1973
aim—to promote regional economic development and integration
regional members—(8) Benin, Burkina Faso, Cote d’Ivoire, Guinea-Bissau, Mali,
Niger, Senegal, Togo
West African Economic and Monetary Union (WAEMU)
note—also known as Union Economique et Monétaire Ouest Africaine (UEMOA)
established—1 August 1994
aim—to increase competitiveness of members’ economic markets; to create a
common market
members—(8) Benin, Burkina Faso, Cote d’Ivoire, Guinea-Bissau, Mali, Niger,
Senegal, Togo
Western European Union (WEU)
established—23 October 1954; effective—6 May 1955
aim—to provide mutual defense and to move toward political unification
members: (10) Belgium, France, Germany, Greece, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK; 6 associate members: Czechia, Hungary,
Iceland, Norway, Poland, Turkey; 7 associate partners: Bulgaria, Estonia,
Latvia, Lithuania, Romania, Slovakia, Slovenia; 5 observers: Austria, Denmark,
Finland, Ireland, Sweden
note—ceased existence completely on 30 June 2011
World Bank Group
includes International Bank for Reconstruction and Development (IBRD),
International Development Association (IDA), International Finance
Corporation (IFC), and Multilateral Investment Guarantee Agency (MIGA)
World Confederation of Labor (WCL)
established—19 June 1920 as the International Federation of Christian Trade
Unions (IFCTU), renamed 4 October 1968
aim—to promote the trade union movement; on 31 October 2006 it merged
with the International Confederation of Free Trade Unions (ICFTU) to form the
International Trade Union Confederation (ITUC)
members—(105 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria,
Burkina Faso, Cameroon, Canada, Central African Republic, Chad, Chile,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d’Ivoire, Cuba, Cyprus, Czechia, Denmark, Dominica, Dominican
Republic, Ecuador, El Salvador, France, French Guiana, Gabon, The Gambia,
Ghana, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong,
Hungary, India, Indonesia, Iran, Italy, Japan, Kazakhstan, South Korea, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Malta, Martinique, Mauritania, Mauritius, Mexico, Morocco, Namibia, Nepal,
Netherlands, Nicaragua, Niger, North Macedonia, Pakistan, Panama, Paraguay,
Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint
Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Senegal,
Serbia, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka,
Suriname, Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago, Ukraine,
US, Uruguay, Venezuela, Vietnam, Zambia, Zimbabwe
World Customs Organization (WCO)
note—began as the Customs Cooperation Council (CCC)
established—15 December 1950
aim—to promote international cooperation in customs matters
members—(181 and the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium,
Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d’Ivoire, Croatia, Cuba, Curacao, Cyprus, Czechia, Denmark,
Djibouti, Dominican Republic, EU, Ecuador, Egypt, El Salvador, Eritrea,
Estonia, Eswatini, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kosovo,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
North Macedonia, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa,
South Sudan, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe and the Palestine
Liberation Organization
World Federation of Trade Unions (WFTU)
established—3 October 1945
aim—to promote the trade union movement
members—(in 2019 there were 130 participating nations and territories and
the Palestine Liberation Union); Afghanistan, Albania, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain,
Bangladesh, Barbados, Belarus, Benin, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Cambodia, Cameroon, Canada, Chile, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Cuba,
Cyprus, Czechia, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador,
Eritrea, Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan, Jordan,
Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico,
Mozambique, Nepal, New Caledonia, NZ, Niger, Nigeria, Oman, Pakistan,
Palestine, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal,
Puerto Rico, Reunion, Romania, Russia, Saint Lucia, Saint Pierre and Miquelon,
Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Sierra Leone,
Slovakia, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden,
Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zimbabwe
World Food Program (WFP)
established—24 November 1961
aim—to provide food aid in support of economic development or disaster relief;
an ECOSOC organization
members (Executive Board)—(36) selected on a rotating basis from all regions
World Health Organization (WHO)
established—22 July 1946; effective—7 April 1948
aim—to deal with health matters worldwide; a UN specialized agency
members—(194) includes all UN member countries except Liechtenstein (192
total); plus Cook Islands and Niue
World Intellectual Property Organization (WIPO)
established—14 July 1967; effective—26 April 1970
aim—to furnish protection for literary, artistic, and scientific works; a UN
specialized agency
members—(1881) includes all UN member countries except Federated States
of Micronesia, Nauru, Palau, Solomon Islands, South Sudan (180 total); plus
Holy See
World Meteorological Organization (WMO)
established—11 October 1947; effective—4 April 1951
aim—to sponsor meteorological cooperation; a UN specialized agency
members—(185) includes all UN member countries except Andorra, Equatorial
Guinea, Grenada, Liechtenstein, Marshall Islands, Nauru, Palau, Saint Kitts and
Nevis, Saint Vincent and the Grenadines, San Marino (183 total); plus Cook
Islands and Niue
World Tourism Organization (UNWTO)
established—2 January 1975
aim—to promote tourism as a means of contributing to economic development,
international understanding, and peace
members—(159) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czechia, Djibouti, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Eswatini, Ethiopia,
Fiji, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Irag, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North
Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Lithuania, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, North Macedonia, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste,
Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,','892741fd26f264f1d6a1c9647100d2a755e7f02fe8dbd9385380560cd77bee89','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3ee42e285126672007b5fb5c5516300a55dc9a1a76fb167cf5d3d82798815ea',2021,'EH','Western Sahara','communications',778,'Telephones—fixed lines: total subscriptions: 2,199,140
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 58
Telephones—mobile cellular:
total subscriptions: 44,737,885
subscriptions per 100 inhabitants: 128 (2018 est.)
country comparison to the world: 33
Telephone system: general assessment: good system
composed of open-wire lines, cables, and microwave radio
relay links; principal switching centers are Casablanca and
Rabat; national network nearly 100% digital using fiber-
optic links; improved rural service employs microwave
radio relay; one of the most state-of-the-art markets in
Africa; high mobile penetration rates in the region with low
cost for broadband Internet access; LTE and VoD (Video on
Demand) launched (2018) domestic: fixed-line teledensity is
6 per 100 persons; mobile-cellular subscribership exceeds
129 per 100 persons (2018) international: country code—
212; landing point for the Atlas Offshore, Estepona-
Tetouan, Canalink and SEA-ME-WE-3 fiber-optic
telecommunications undersea cables’ that provide
connectivity to Asia, Africa, the Middle East, Europe and
Australia; satellite earth stations—2 Intelsat (Atlantic
Ocean) and 1 Arabsat; microwave radio relay to Gibraltar,
Spain, and Western Sahara (2019) Broadcast media: 2 TV
broadcast networks’ with state-run’ Radio-Television
Marocaine (RIM) operating one network and the state
partially owning the other; foreign TV broadcasts are
available via satellite dish; 3 radio broadcast networks with
RIM operating one; the government-owned network
includes 10 regional radio channels in addition to its
national service (2019) Internet country code: .ma
Internet users: total: 19,611,643
percent of population: 58.3% (July 2016 est.)
country comparison to the world: 34
Broadband—fixed subscriptions:
total: 1,552,599
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 61
Communications—note: the University of al-Quarawiyyin
Library in Fez is recognized as the oldest existing,
continually operating library in the world, dating back to
A.D. 859; among its holdings are approximately 4,000
ancient Islamic manuscripts (2018) MILITARY AND
SECURITY
Military expenditures:
3.1% of GDP (2018)
3.19% of GDP (2017)
3.21% of GDP (2016)
3.23% of GDP (2015)
3.68% of GDP (2014)
country comparison to the world: 23
Military and_ security forces: Royal Armed Forces: Royal
Moroccan Army, Royal Moroccan Navy (includes Coast
Guard, marines), Royal Moroccan Air Force, Royal
Morroccan Gendarmerie, Morroccan Royal Guard (provides
security for the royal family; officially part of the Royal
Army); Force Auxiliaire (a paramilitary force under the
Ministry of Interior that supplements the military and the
police as needed) (2019) Military service age and obligation: 19
years of age for compulsory military service; both sexes are
obligated to military service; conscript service obligation—
12 months (2019) TRANSPORTATION
National air transport system:
number of registered air carriers: 4 (2015)
inventory of registered aircraft operated by air carriers: 65
(2015)
annual passenger traffic on registered air Carriers:
6,786,850 (2015)
annual freight traffic on registered air carriers: 47,828,227
mt-km (2015) Civil aircraft registration country code prefix: CN
(2016)
Airports: 55 (2013)
country comparison to the world: 84
Airports—with paved runways:
total: 31 (2017)
over 3,047 m: 11 (2017)
2,438 to 3,047 m: 9 (2017)
1,524 to 2,437 m: 7 (2017)
914 to 1,523 m: 4 (2017)
Airports—with unpaved runways:
total: 24 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 7 (2013)
914 to 1,523 m: 11 (2013)
under 914 m: 5 (2013)
Heliports: 1 (2013)
Pipelines: 944 km gas, 270 km oil, 175 km refined products
(2013)
Railways: total: 2,067 km (2014)
standard gauge: 2,067 km 1.435-m gauge (1,022 km
electrified) (2014)
country comparison to the world: 73
Roadways: total: 57,300 km (2018)
country comparison to the world: 79
Merchant marine: total: 87
by type: container ship 7, general cargo 6, oil tanker 3,
other 71 (2018) country comparison to the world: 93
Ports and terminals: Major seaport(s): Casablanca, Jorf Lasfar,
Mohammedia, Safi, Tangier container port(s) (TEUs):
Tangier (3,312,409) (2017)
LNG terminal(s) (import): Jorf Lasfar
United Nations Multidimensional Integrated
Stabilization Mission in the Central African
Republic
United Nations Multidimensional Integrated
Stabilization Mission in Mali
United Nations Stabilization Mission in Haiti
millimeter
United Nations Organization Stabilization
Mission in the Democratic Republic of the
Developing Eight (D-8)
established—15 June 1997
aim—to improve developing countries’ positions in the world economy, diversify
and create new opportunities in trade relations, enhance participation in
decision-making at the international level, provide better standards of living
member—(8) Bangladesh, Egypt, Indonesia, Iran, Malaysia, Nigeria, Pakistan,
Turkey
East African Community (EAC)
note—originally established in 1967, it was disbanded in 1977
established—January 2001
aim—to establish a political and economic union among the countries
members—(5) Burundi, Kenya, Rwanda, Tanzania, Uganda
East African Development Bank (EADB)
established—6 June 1967; effective—1 December 1967
aim—to promote economic development
members—(4) Kenya, Rwanda, Tanzania, Uganda
East Asia Summit (EAS)
established—14 December 2005
aim—to promote cooperation in political and security issues; to promote
development, financial stability, energy security, economic integration and
growth; to eradicate poverty and narrow the development gap in East Asia, and
to promote deeper cultural understanding
members—(18) Australia, Brunei, Burma, Cambodia, China, India, Indonesia,
Japan, South Korea, Laos, Malaysia, NZ, Philippines, Russia, Singapore,
Thailand, US, Vietnam
Economic and Monetary Community of Central Africa (CEMAC)
note—was formerly the Central African Customs and Economic Union (UDEAC)
established—8 December 1964; effective—1 January 1966
aim—to promote the establishment of a Central African Common Market
members—(11) Angola, Burundi, Cameroon, Central African Republic, Chad,
Democratic Republic of the Congo, Republic of the Congo, Equatorial Guinea,
Gabon, Sao Tome and Principe, Rwanda
Economic and Monetary Union (EMU)
note—an integral part of the European Union; also known as the European
Economic and Monetary Union
established—1-2 December 1969 (proposed at summit conference of heads of
government; 7 February 1992 (Maastricht Treaty signed)
aim—to promote a single market by creating a single currency, the euro;
timetable—2 May 1998: European exchange rates fixed for 1 January 1999; 1
January 1999: all banks and stock exchanges begin using euros; 1 January
2002: the euro goes into circulation; 1 July 2002 local currencies no longer
accepted
members—(28) Austria, Belgium, Bulgaria, Croatia, Cyprus, Czechia, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia,
Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania,
Slovakia, Slovenia, Spain, Sweden, UK
Economic and Social Council (ECOSOC)
established—26 June 1945; effective—24 October 1945
aim—to coordinate the economic and social work of the UN; includes five
regional commissions (Economic Commission for Africa, Economic Commission
for Europe, Economic Commission for Latin America and the Caribbean,
Economic and Social Commission for Asia and the Pacific, Economic and Social
Commission for Western Asia) and nine functional commissions (Commission
for Social Development, Commission on Human Rights, Commission on
Narcotic Drugs, Commission on the Status of Women, Commission on
Population and Development, Statistical Commission, Commission on Science
and Technology for Development, Commission on Sustainable Development,
and Commission on Crime Prevention and Criminal Justice)
members—(54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL)
note—acronym from Communauté Economique des Pays des Grands Lacs
established—20 September 1976
aim—to promote regional economic cooperation and integration
members—(3) Burundi, Democratic Republic of the Congo, Rwanda; note—
organization collapsed because of fighting in 1998; reactivated in 2006
Economic Community of West African States (ECOWAS)
established—28 May 1975
aim—to promote regional economic cooperation
members—(15) Benin, Burkina Faso, Cabo Verde, Cote d’Ivoire, The Gambia,
Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger, Nigeria, Senegal, Sierra
Leone, Togo
Economic Cooperation Organization (ECO)
established—27-29 January 1985
aim—to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members—(10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
Eurasian Economic Community (EAEC or EurasEC)
note—merged with Central Asian Cooperation Organization (CACO) in 2005
established—10 October 2000
aim—to create a common economic and energy policy
members—(6) Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
(suspended)
observers—(3) Armenia, Moldova, Ukraine
Eurasian Economic Union (EAEU)
note—treaty signed 29 May 2014
established—came into being 1 January 2015
aim—to form a large economic market for its members
members—(5) Armenia, Belarus, Kazakhstan, Kyrgyzstan, Russia
Euro-Atlantic Partnership Council (EAPC)
note—began as the North Atlantic Cooperation Council (NACC); an extension of
NATO
established—8 November 1991; effective—20 December 1991
aim—to discuss cooperation on mutual political and security issues
members—(50) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia
and Herzegovina, Bulgaria, Canada, Croatia, Czechia, Denmark, Estonia,
Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, Malta, Moldova,
Montenegro, Netherlands, North Macedonia, Norway, Poland, Portugal,
Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and Development (EBRD)
established—8-9 January 1990 (proposals made); 15 April 1991 (bank
inaugurated)
aim—to facilitate the transition of seven centrally planned economies in Europe
(Bulgaria, former Czechoslovakia, Hungary, Poland, Romania, former USSR,
and former Yugoslavia) to market economies by committing 60% of its loans to
privatization
members—(68) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, China, Croatia, Cyprus,
Czechia, Denmark, Egypt, EU, European Investment Bank (EIB), Estonia,
Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel,
Italy, Japan, Jordan, Kazakhstan, South Korea, Kosovo, Kyrgyzstan, Latvia,
Lebanon, Liechtenstein, Lithuania, Luxembourg, Malta, Mexico, Moldova,
Mongolia, Montenegro, Morocco, Netherlands, NZ, North Macedonia, Norway,
Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Tajikistan, Tunisia, Turkey, Turkmenistan, Ukraine, UK, US,','f3ac0ed298d235b50c69b7b466b4269abc1fa252efcf925959ad9c7bda0ceb2c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('470b3f3a9d8815d8dc982f8f52197e2b1a927ad97b8d7e786342482a54ff7520',2021,'NR','Nauru','communications',788,'Telephones—fixed lines: total subscriptions: 1,900
subscriptions per 100 inhabitants: 14 (July 2016 est.)
country comparison to the world: 216
Telephones—mobile cellular:
total subscriptions: 9,900
subscriptions per 100 inhabitants: 87 (July 2016 est.)
country comparison to the world: 214
Telephone system: general assessment: adequate local and
international radiotelephone communication provided via
Australian facilities; geography is a challenge for the
islands; there is a need to service the tourism sector and
thus the South Pacific Islands economy; mobile technology
is booming (2018) domestic: fixed-line 14 per 100 and
mobile-cellular 87 per 100 (2018)
international: country code—674; satellite earth station—1
Intelsat (Pacific Ocean)
Broadcast media: 1 government-owned TV _ station
broadcasting programs from New Zealand sent via satellite
or on videotape; 1 government-owned radio station,
broadcasting on AM and FM, utilizes Australian and British
programs (2019) Internet country code: .nr
Internet users: total: 5,100
percent of population: 53.5% (July 2016 est.)
country comparison to the world: 213','70738388e699561cbfb0c526ea39351a01fa3109a1f6ec08031d6b9ce028e6d5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24adb15f23f1aeaa54062625885c19f53db32f97b9752cee14ffc00306169593',2021,'NP','Nepal','communications',794,'Telephones—fixed lines: total subscriptions: 799,368
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 82
Telephones—mobile cellular:
total subscriptions: 39,178,451
subscriptions per 100 inhabitants: 132 (2018 est.)
country comparison to the world: 38
Telephone system: general assessment: mountainous
topography hinders development of telecom infrastructure;
fair radiotelephone communication service; 20% of the
market share is fixed (wired) broadband, 2% is fixed
(wireless) broadband, and 78% is mobile broadband (2019);
fixed broadband is low due to limited number of fixed lines
and preeminence of the mobile platform; accelerated
mobile broadband penetration the last five years; 90% of
the population will have access to broadband by 2020
(2018) domestic: mobile service has been extended to all
75 districts covering 90% of Nepal’s land area; 3G
coverage is available in 20 major cities (2019); disparity
between high coverage in cities and coverage available in
underdeveloped rural regions; fixed-line 3 per 100 persons
and mobile-cellular 109 per 100 persons (2018)
international: country code—977; Nepal, China and Tibet
connected across borders with underground and_all-
dielectric self-supporting (ADSS) fiber-optic cables;
radiotelephone communications; microwave and _ fiber
landlines to India; satellite earth station—1 Intelsat (Indian
Ocean) (2019) Broadcast media: state operates 3 TV stations,
as well as national and regional radio stations; 117
television channels are licensed, among those 71 are cable
television channels, three are distributed through Direct-
To-Home (DTH) system, and four are digital terrestrial; 736
FM radio stations are licensed and at least 314 of those
radio stations are community radio stations (2019) Internet
country code: .np
Internet users: total: 5,716,419
percent of population: 19.7% (July 2016 est.)
country comparison to the world: 69
Broadband—fixed subscriptions:
total: 791,961
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 75','dfbf734e96f00f776fa4243e0bb72e8f007066fcbf4dd6fa51ff71e55ad650f5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d81c33784152da4faec7365f2f8f1734b102eeaeee8b6ae7318f8547b0c4f597',2021,'NL','Netherlands','communications',803,'Telephones—fixed lines: total subscriptions: 5.9 million
subscriptions per 100 inhabitants: 34 (2018 est.)
country comparison to the world: 26
Telephones—mobile cellular:
total subscriptions: 21.108 million
subscriptions per 100 inhabitants: 123 (2018 est.)
country comparison to the world: 55
Telephone system: general assessment: highly developed and
well maintained; while fixed-line voice market is in decline
the VoIP (voice over Internet protocol) and mobile
platforms advance; one of the highest fixed broadband
penetration rates in the world; government investments;
preparations for 5G trials, plans for 3G network shutdown
in 2022; LTE-A services; MNOs and banks launch m-
payments system (2019) domestic: extensive fixed-line,
fiber-optic network; large cellular telephone system with
five major operators utilizing the third generation of the
Global System for Mobile Communications technology; one
in five households now use Voice over the Internet Protocol
services; fixed-line 38 per 100 and mobile-cellular 120 per
100 persons (2018) international: country code—31;
landing points for Farland North, TAT-14, Circe North,
Concerto, Ulysses 2, AC-1, UkK-Netherlands 14, and
COBRAcable submarine cables which provide links to the
US and Europe; satellite earth stations—5 (3 Intelsat—1
Indian Ocean and 2 Atlantic Ocean, 1 Eutelsat, and 1
Inmarsat) (2019) Broadcast media: more than 90% of
households are connected to cable or satellite TV systems
that provide a wide range of domestic and foreign
channels; public service broadcast system includes multiple
broadcasters, 3 with a national reach and the remainder
operating in regional and local markets; 2 major
nationwide commercial television companies, each with 3
or more stations, and many commercial TV stations in
regional and local markets; nearly 600 radio stations with a
mix of public and private stations providing national or
regional COVerage Internet country code: nl
Internet users: total: 15,385,203
percent of population: 90.4% (July 2016 est.)
country comparison to the world: 39
Broadband—fixed subscriptions:
total: 7,406,700
subscriptions per 100 inhabitants: 43 (2018 est.)
country comparison to the world: 23
United Nations Educational, Scientific, and Cultural Organization
(UNESCO)
established—16 November 1945; effective—4 November 1946
aim—to promote cooperation in education, science, and culture
members—(194 plus Palestine) includes all UN member countries except
Liechtenstein (192 total); plus Cook Islands, Niue, Palestine
associate members—(11) Anguilla, Aruba, British Virgin Islands, Cayman
Islands, Curacao, Faroe Islands, Macau, Montserrat, New Caledonia, Sint
Maarten, Tokelau
United Nations Environment Program (UNEP)
established—15 December 1972
aim—to promote international cooperation on all environmental matters
members—(58) Governing Council selected on a rotating basis from all regions
United Nations General Assembly
established—26 June 1945; effective—24 October 1945
aim—to function as the primary deliberative organ of the UN
members—(193) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR)
established—3 December 1949; effective—1 January 1951
aim—to ensure the humanitarian treatment of refugees and find permanent
solutions to refugee problems
members (executive committee)—(102) Afghanistan, Algeria, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belarus, Belgium, Benin,
Brazil, Bulgaria, Cameroon, Canada, Chad, Chile, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire,
Croatia, Cyprus, Czechia, Denmark, Djibouti, Ecuador, Egypt, Estonia, Ethiopia,
Fiji, Finland, France, Georgia, Germany, Ghana, Greece, Guinea, Holy See,
Hungary, India, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, South Korea,
Latvia, Lebanon, Lesotho, Lithuania, Luxembourg, Madagascar, Mexico,
Moldova, Montenegro, Morocco, Mozambique, Namibia, Netherlands, NZ,
Nicaragua, Nigeria, North Macedonia, Norway, Pakistan, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Rwanda, Senegal, Serbia,
Slovakia, Slovenia, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland,
Tanzania, Thailand, Togo, Tunisia, Turkey, Turkmenistan, Uganda, Uruguay,
UK, US, Venezuela, Yemen, Zambia, Zimbabwe
United Nations Industrial Development Organization (UNIDO)
established—14 November 1966; effective—1 January 1967
aim—UN specialized agency that promotes industrial development especially
among the members
members—(167) includes all UN member countries except Andorra, Antigua
and Barbuda, Australia, Belgium, Brunei, Canada, Denmark, Estonia, France,
Greece, Iceland, Latvia, Liechtenstein, Lithuania, Federated States of
Micronesia, Nauru, NZ, Palau, Portugal, San Marino, Singapore, Slovakia,
Solomon Islands, South Sudan, UK, US
United Nations Institute for Training and Research (UNITAR)
established—11 December 1963 adoption of the resolution establishing the
Institute; effective—24 March 1965
aim—to help the UN become more effective through training and research
members (Board of Trustees)—(14) Algeria, China, Fiji, Finland, Germany,
Japan, India, Mexico, Nigeria, Russia, Sweden, Switzerland, UK, US
note—the UN Secretary General can appoint up to 30 members
United Nations Integrated Mission in Timor-Leste (UNMIT)
established—25 August 2006; ended on 31 December 2012
aim—to support the Government, to support the electoral process, to ensure
the restoration and maintenance of public security
members—Australia, Bangladesh, Brazil, China, Fiji, Japan, India, Malaysia,
Nepal, NZ, Pakistan, Philippines, Portugal, Sierra Leone, Singapore; UNMIT
was dissolved on 31 December 2012
United Nations Interim Administration Mission in Kosovo (UNMIK)
established—10 June 1999
aim—to promote the establishment of substantial autonomy and _ self-
government in Kosovo; to perform basic civilian administrative functions; to
support the reconstruction of key infrastructure and humanitarian and disaster
relief
note—gives civilian support only; works closely with NATO Kosovo Force
(KFOR)
United Nations Interim Force in Lebanon (UNIFIL)
established—19 March 1978
aim—to confirm the withdrawal of Israeli forces, and assist in reestablishing
Lebanese authority in southern Lebanon; established by the UN Security
Council
members—(42) Armenia, Austria, Bangladesh, Belarus, Belgium, Brazil, Brunei,
Cambodia, China, Colombia, Croatia, Cyprus, El Salvador, Estonia, Finland,
France, Germany, Ghana, Greece, Guatemala, Hungary, India, Indonesia,
Ireland, Italy, Kazakhstan, Kenya, South Korea, Malaysia, Mexico, Nepal,
Netherlands, Nigeria, North Macedonia, Qatar, Serbia, Sierra Leone, Slovenia,
Spain, Sri Lanka, Tanzania, Turkey, Uruguay
United Nations Interim Security Force for Abyei (UNISFA)
established—27 June 2011
aim—to protect civilians and humanitarian workers in Abyei
members—(34) Bahrain, Benin, Bhutan, Bolivia, Brazil, Burkina Faso, Burundi,
Cambodia, Dominican Republic, Ecuador, El Salvador, Ethiopia, Ghana,
Guatemala, Guinea, India, Indonesia, Jordan, Malawi, Mongolia, Namibia,
Nepal, Nigeria, Peru, Russia, Rwanda, Seychelles, Sierra Leone, Sri Lanka,
Tanzania, Ukraine, Vietnam, Zambia, Zimbabwe
United Nations Military Observer Group in India and Pakistan (UNMOGIP)
established—24 January 1949
aim—to observe the 1949 India-Pakistan cease-fire; established by the UN
Security Council members—(9) Chile, Croatia, Finland, Italy, South Korea,
Philippines, Sweden, Thailand, Uruguay
United Nations Mission for the Referendum in Western Sahara
(MINURSO)
established—29 April 1991
aim—to supervise the cease-fire and conduct a referendum in Western Sahara;
established by the UN Security Council
members—(42) Argentina, Austria, Bangladesh, Bhutan, Brazil, China, Croatia,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, France, Germany,
Ghana, Guinea, Honduras, Hungary, India, Indonesia, Ireland, Italy, Japan,
Jordan, Kazakhstan, South Korea, Malawi, Malaysia, Mexico, Mongolia, Nepal,
Nigeria, Pakistan, Philippines, Poland, Portugal, Russia, Sri Lanka, Sweden
Switzerland, Togo, UN
United Nations Mission in Liberia (UNMIL)
established—19 September 2003; ended in 30 March 2018
aim—to support the cease-fire agreement and peace process, protect UN
facilities and people, support humanitarian activities, and assist in national
security reform
members—Bangladesh, Benin, Bolivia, Brazil, Bulgaria, Burma, China, Ecuador,
Egypt, Ethiopia, France, The Gambia, Germany, Ghana, Guinea-Bissau,
Indonesia, Jordan, Kyrgyzstan, Malaysia, Mali, Moldova, Namibia, Nepal, Niger,
Nigeria, Pakistan, Philippines, Poland, Russia, Senegal, Serbia, Togo, Ukraine,
US, Yemen, Zambia, Zimbabwe
United Nations Mission in the Central African Republic and Chad
(MINURCAT)
established—25 September 2007
aim—to create the security and conditions which will to contribute to the
protection of refugees, displaced persons, and citizens in danger, to facilitate
the provision of humanitarian assistance in eastern Chad and the northeastern
Central African Republic, to create favorable conditions for the reconstruction
and economic and social development of these areas
members—Bangladesh, Benin, Burkina Faso, Democratic Republic of the
Congo, Egypt, Ethiopia, Ghana, Ireland, Kenya, Mali, Mongolia, Namibia,
Nepal, Nigeria, Norway, Pakistan, Poland, Russia, Rwanda, Senegal, Serbia, Sri
Lanka, Togo, Tunisia, US; MINURCAT was dissolved in December 2010
United Nations Mission in the Republic of South Sudan (UNMISS)
established—8 July 2011
aim—to consolidate peace and security and to establish the conditions in South
Sudan which will strengthen its ability to govern effectively and democratically
and establish good relations with its neighbors
members—(67) Algeria, Argentina, Australia, Austria, Bangladesh, Benin,
Bhutan, Botswana, Brazil, Cambodia, Canada, China, Colombia, Croatia,
Denmark, Djibouti, Ecuador, Egypt, Fiji, Finland, Germany, Ghana, Greece,
Guatemala, Hungary, India, Indonesia, Italy, Japan, Jordan, Kenya, Samoa,
South Africa, South Korea, Spain, Malawi, Namibia, Nepal, Netherlands, NZ,
Nigeria, Norway, Oman, Pakistan, Papua New Guinea, Paraguay, Peru, Poland,
Romania, Russia, Rwanda, Senegal, Sri Lanka, Sweden, Switzerland, Tanzania,
Thailand, Togo, Turkey, Uganda, Ukraine, UK, US, Uruguay, Vietnam, Yemen,
Zambia, Zimbabwe
United Nations Mission in the Sudan (UNMIS)
established—March 2005
aim—to support implementation of the comprehensive Peace Agreement by
monitoring and verifying the implementation of the Cease Fire Agreement, by
observing and monitoring movements of armed groups, and by helping disarm,
demobilizing and reintegrating armed bands
members—Australia, Bangladesh, Belgium, Benin, Bolivia, Brazil, Burkina Faso,
Cambodia, Canada, China, Croatia, Denmark, Ecuador, Egypt, El Salvador, Fiji,
Finland, Germany, Greece, Guatemala, Guinea, India, Indonesia, Iran, Japan,
Jordan, Kenya, Kyrgyzstan, Malaysia, Moldova, Mongolia, Morocco, Namibia,
Nepal, Netherland, NZ, Niger, Norway, Pakistan, Paraguay, Peru, Philippines,
Poland, Qatar, Romania, Russia, Rwanda, Sierra Leone, Spain, Sweden,
Switzerland, Tanzania, Thailand, Turkey, Uganda, Ukraine, UK, Yemen, Zambia,
Zimbabwe; UNMIS was dissolved on 9 July 2011
United Nations Multidimensional Integrated Stabilization Mission in
Mali (MINUSMA)
established—25 April 2013
aim—to support political processes and carry out a number of security-related
tasks
members—(56) Armenia, Austria, Bangladesh, Belgium, Benin, Bhutan, Bosnia
and Herzegovina, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Chad,
China, Cote d’Ivoire, Czechia, Denmark, Egypt, El Salvador, Estonia, Ethiopia,
Finland, France, The Gambia, Germany, Ghana, Guatemala, Guinea, Indonesia,
Italy, Jordan, Kenya, Latvia, Liberia, Lithuania, Mauritania, Mexico, Nepal,
Netherlands, NZ, Niger, Nigeria, Norway, Pakistan, Portugal, Romania,
Senegal, Sierra Leone, Spain, Sri Lanka, Sweden, Switzerland, Togo, Tunisia,
UK, US
United Nations Operation in Cote d’Ivoire (UNOCI)
established—27 February 2004; ended 30 June 2017
aim—to facilitate the implementation by the Ivorian parties of the peace
agreement signed by them in January 2003
members—Algeria, Bangladesh, Belgium, Benin, Bolivia, Bosnia and
Herzegovina, Brazil, Burkina Faso, Cameroon, Canada, CAR, Chad, China,
Ecuador, Egypt, El Salvador, Ethiopia, France, The Gambia, Ghana, Guatemala,
Guinea, India, Ireland, Ivory Coast Jordan, Kazakhstan, South Korea, Malawi,
Moldova, Morocco, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru,
Philippines, Poland, Romania, Russia, Senegal, Serbia, Spain, Tanzania, Togo,
Tunisia, Uganda, Ukraine, Uruguay, Yemen, Zambia, Zimbabwe
United Nations Organization Stabilization Mission in the Democratic
Republic of the Congo (MONUSCO)
established—28 May 2010
aim—to protect the civilians to assist the government in the areas of
stabilization and peace consolidation
members—(50) Bangladesh, Belgium, Benin, Bolivia, Bosnia and Herzegovina,
Brazil, Burkina Faso, Cameroon, Canada, China, Cote d’Ivoire, Czechia, Egypt,
France, Ghana, Guatemala, Guinea, India, Indonesia, Ireland, Jordan, Kenya,
Malawi, Malaysia, Mali, Mongolia, Morocco, Nepal, Niger, Nigeria, Pakistan,
Paraguay, Peru, Poland, Romania, Russia, Senegal, Serbia, South Africa, Sri
Lanka, Sweden, Switzerland, Tunisia, Ukraine, UK, US, Uruguay, Yemen,','256528a3878b37669938e14803f1200ca33ad258a1cddc9e9e16c1893b17a684','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5579cc2e22253d503e3940fd71c5153078d69a754b722a61810c2429a4cb69f0',2021,'CR','Costa Rica','communications',812,'Telephones—fixed lines: total subscriptions: 325,821
subscriptions per 100 inhabitants: 5 (2018 est.)
country comparison to the world: 109
Telephones—mobile cellular:
total subscriptions: 7,441,527
subscriptions per 100 inhabitants: 122 (2018 est.)
country comparison to the world: 101
Telephone system: general assessment: system being
upgraded by foreign investment; nearly all installed
telecommunications capacity now uses digital technology,
owing to investments since privatization of the formerly
state-owned telecommunications company; lowest fixed-line
teledensity and mobile penetration in Central America; a
Russian state corporation is operating in the area; LTE
service in 60 towns and cities (2018) domestic: since
privatization, access to fixed-line and mobile-cellular
services has improved; fixed-line teledensity roughly 6 per
100 persons; mobile-cellular telephone subscribership has
increased to 136 per 100 persons (2018) international:
country code—505; landing point for the ARCOS fiber-optic
submarine cable which provides connectivity to South and
Central America, parts of the Caribbean, and the US;
satellite earth stations—1 Intersputnik (Atlantic Ocean
region) and 1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: multiple terrestrial TV stations, supplemented by
cable TV in most urban areas; nearly all are government-
owned or affiliated; more than 300 radio stations, both
government-affiliated and privately owned (2019) Internet
country code: .ni
Internet users: total: 1,466,152
percent of population: 24.6% (July 2016 est.)
country comparison to the world: 122
Broadband—fixed subscriptions:
total: 192,413
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 109','d7a5f0ff1a95f06807c722978a85ff79ed522ce229486d162d09b9fc311de6d9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d40fe514bac880f1762f9582f5306e1a06042d86e10b1d695c5c8c918e26b44f',2021,'NG','Nigeria','communications',817,'Telephones—fixed lines: total subscriptions: 114,352
subscriptions per 100 inhabitants: 1 (2017 est.)
country comparison to the world: 138
Telephones—mobile cellular:
total subscriptions: 8,778,884
subscriptions per 100 inhabitants: 46 (2017 est.)
country comparison to the world: 91
Telephone system: general assessment: small system of wire,
radio telephone communications, and microwave radio
relay links concentrated in southwestern Niger; mobile
services stronger than fixed telecoms; broadband
penetration inconsequential; LTE license secured for the
future; government tax of telecom sector (2018) domestic:
fixed-line 1 per 100 persons and mobile-cellular teledensity
remains 46 per 100 persons despite a rapidly increasing
cellular subscribership base; domestic satellite system with
3 earth stations and 1 planned (2018) international:
country code—227; satellite earth stations—2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean) Broadcast media: state-
run TV station; 3 private TV stations provide a mix of local
and foreign programming; state-run radio has only radio
station with national coverage; about 30 private radio
stations operate locally; as many as 100 community radio
stations broadcast; transmissions of multiple international
broadcasters are available Internet country code: .ne
Internet users: total: 805,702
percent of population: 4.3% (July 2016 est.)
country comparison to the world: 138
Broadband—fixed subscriptions:
total: 8,650
subscriptions per 100 inhabitants: less than 1 (2017 est.)
country comparison to the world: 173
Telephones—fixed lines: total subscriptions: 140,491
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 130
Telephones—mobile cellular:
total subscriptions: 172,730,603
subscriptions per 100 inhabitants: 85 (2018 est.)
country comparison to the world: 8
Telephone system: general assessment: one of the larger
telecom markets in Africa; foreign investment; market
competition; LTE technologies available but GSM
technology dominate; unified licensing regime; government
committed to expanding broadband penetration; in Q1
2018, the Nigerian Communications Commission approved
seven licenses to telecom companies to deploy fiber optic
cable in the six geopolitical zones and Lagos (2018)
domestic: fixed-line subscribership remains less than 1 per
100 persons; mobile-cellular services growing rapidly, in
part responding to the shortcomings of the fixed-line
network; multiple cellular providers operate nationally with
subscribership base over 76 per 100 persons (2018)
international: country code—234; landing point for the SAT-
3/WASC, NCSCS, MainOne, Glo-1 & 2, ACE, and Equiano
fiber-optic submarine cable that provides connectivity to
Europe and South and West Africa; satellite earth stations
—3 Intelsat (2 Atlantic Ocean and 1 Indian Ocean) (2019)
Broadcast media: nearly 70 federal government-controlled
national and regional TV stations; all 36 states operate TV
stations; several private TV stations operational; cable and
satellite TV subscription services are available; network of
federal government-controlled national, regional, and state
radio stations; roughly 40 state government-owned radio
stations typically carry their own programs except for news
broadcasts; about 20 private radio stations; transmissions
of international broadcasters are available; digital
broadcasting migration process completed in three states
in 2018 (2019) Internet country code: .ng
Internet users: total: 47,759,904
percent of population: 25.7% (July 2016 est.)
country comparison to the world: 15
Broadband—fixed subscriptions:
total: 73,965
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 126','71435aca8e17b84012eeb33d643fa6803c6740c4ebf8158e12f97b2de249add9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1632f2fb9606e9c083c376ad6237f2f3dfa2d8e34e50af3042dcd2cbadaf9b4',2021,'TO','Tonga','communications',824,'Telephone system: general assessment: sole provider services
for over 1000 landlines and fixed wireless lines; cellular
telephone service operates on AMPS and GSM platforms;
difficult geography presents challenges for rural areas
(2018) domestic: single-line (fixed line) telephone system
connects all villages (and virtually all households) on island
(2018) international: country code—683; landing point for
the Manatua submarine cable linking Niue to several South
Pacific Ocean Islands (2019) Broadcast media: 1 government-
owned TV station with many of the programs supplied by
Television New Zealand; 1 government-owned radio station
broadcasting in AM and FM (2019) Internet country code: .nu
Internet users: total: 1,090
percent of population: 91.6% (July 2016 est.)
country comparison to the world: 222','0285acb719ffa766fbbd44fdc27594860b2e53ea81bda15f8baa7097d401cc6f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1753f49c48548b323b83fef008c8befba55264321b2fc9c04aa19a5f936a460a',2021,'MP','Northern Mariana Islands','communications',832,'Telephone system: general assessment: digital fiber-optic
cables and satellites connect the islands to worldwide
networks; future launch of 5G (2018) domestic: wide
variety of services available including dial-up and
broadband Internet, mobile cellular, international private
lines, payphones, phone cards, voicemail, and automatic
call distribution systems (2018) international: country code
—1-670; landing points for the Atisa and Mariana-Guam
submarine cables linking Mariana islands to Guam; satellite
earth stations—2 Intelsat (Pacific Ocean) (2019) Broadcast
media: 1 TV broadcast station on Saipan; multi-channel
cable TV services are available on Saipan; 9 licensed radio
broadcast stations (2009) Internet country code: .mp
Internet users: total: 16,000
percent of population: 30.6% (July 2016 est.)
country comparison to the world: 207','3b9e1165f3ab535c4fcb6e90246f947eef0b673282f0573628325e86f6ffcf1e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a567024b7214a639c90e221fac6030a7f18ff6ce5737c6bda850303c20cdc42',2021,'PA','Panama','communications',841,'Telephones—fixed lines: total subscriptions: 728,379
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 85
Telephones—mobile cellular:
total subscriptions: 5,722,370
subscriptions per 100 inhabitants: 151 (2018 est.)
country comparison to the world: 116
Telephone system: general assessment: domestic and
international facilities well-developed; investment from
international operators; competition among operators helps
reduce price of services; launches LTE services; (2018)
domestic: fixed-line 16 per 100 and _ mobile-cellular
telephone 159 per 100 and subscribership has increased
rapidly (2018) international: country code—507; landing
points for the PAN-AM, ARCOS, SAC, AURORA, PCCS, PAC,
and the MAYA-1, submarine cable systems that together
provide links to the US and parts of the Caribbean, Central
America, and South America; satellite earth stations—2
Intelsat (Atlantic Ocean); connected to the Central
American Microwave System (2019) Broadcast media:
multiple privately owned TV networks and a government-
owned educational TV station; multi-channel cable and
satellite TV subscription services are available; more than
100 commercial radio stations (2019) Internet country code:
.pa
Internet users: total: 2,000,833
percent of population: 54% (July 2016 est.)
country comparison to the world: 112
Broadband—fixed subscriptions:
total: 540,220
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 82','7bc03db948095315b7015fe776ff89610cebc23ef06f4a872177b5fadb637e9b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66199fec917b86f64bfb111984773467cda1cd319e52d9da4c4d4c04a609431b',2021,'EC','Ecuador','communications',851,'Telephones—fixed lines: total subscriptions: 3,082,036
subscriptions per 100 inhabitants: 10 (2017 est.)
country comparison to the world: 45
Telephones—mobile cellular:
total subscriptions: 38,915,386
subscriptions per 100 inhabitants: 125 (2017 est.)
country comparison to the world: 39
Telephone system: general assessment: adequate for most
requirements; nationwide microwave radio relay system
and a domestic satellite system with 12 earth stations; 3G
network and new LIE services begun; 2019 the year to try
9G; Peru is seen as a potential market for growth in
broadband with government work with fiber-optic
backbone to remote areas (2018) domestic: fixed-line
teledensity is only about 10 per 100 persons; mobile-
cellular teledensity, spurred by competition among multiple
providers, now 125 telephones per 100 persons (2018)
international: country code—51; landing points for the
SAM-1, IGW, American Movil-Telxius, SAC and PAN-AM
submarine cable systems provide links to parts of Central
and South America, the Caribbean, and US; satellite earth
stations—2 Intelsat (Atlantic Ocean) (2019) Broadcast media:
10 major TV networks of which only one, Television
Nacional de Peru, is state owned; multi-channel cable TV
services are available; in excess of 2,000 radio stations
including a substantial number of indigenous language
stations (2019) Internet country code: .pe
Internet users: total: 13,975,422
percent of population: 45.5% (July 2016 est.)
country comparison to the world: 43
Broadband—fixed subscriptions:
total: 2,310,217
subscriptions per 100 inhabitants: 7 (2017 est.)
country comparison to the world: 52','1670e2b806259dc5713c8910866e617af762332608b208eced0b4b999e5f7a99','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa07db7823d6e32f6b3a7599e34bf2616bb7ab63a77b43b5b15fe9fcce18a590',2021,'PH','Philippines','communications',859,'Telephones—fixed lines: total subscriptions: 4,132,490
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 36
Telephones—mobile cellular:
total subscriptions: 134,592,608
subscriptions per 100 inhabitants: 127 (2018 est.)
country comparison to the world: 12
Telephone system: general assessment: good international
radiotelephone and submarine cable services; domestic and
interisland service adequate; National Broadband Plan to
improve connectivity in rural areas underway; 4G available
now in some areas with 5G pilots planned to commence in
2019-2020 (2018) domestic: telecommunications
infrastructure includes the following platforms: fixed line,
mobile cellular, cable TV, over-the-air TV, radio and Very
Small Aperture Terminal (VSAT), fiber-optic cable, and
satellite for redundant international connectivity; fixed-line
4 per 100 and mobile-cellular 111 per 100 (2018)
international: country code—63; landing points for the
NDTN, TGN-IA, AAG, PLCN, EAC-02C, DFON, SJC, APCN-2,
SeaMeWe, Boracay-Palawan Submarine Cable System,
Palawa-Illoilo Cable System, NDTN, SEA-US, SSSFOIP, ASE
and JUPITAR submarine cables that together provide
connectivity to the US, Southeast Asia, Asia, Europe,
Africa, the Middle East, and Australia (2019) Broadcast media:
multiple national private TV and radio networks; multi-
channel satellite and cable TV systems available; more than
400 TV stations; about 1,500 cable TV providers with more
than 2 million subscribers, and some 1,400 radio stations;
the Philippines adopted Japan’s Integrated Service Digital
Broadcast—Terrestrial standard for digital terrestrial
television in November 2013 and is scheduled to complete
the switch from analog to digital broadcasting by the end of
2023 (2019) Internet country code: .ph
Internet users: total: 56,956,436
percent of population: 55.5% (July 2016 est.)
country comparison to the world: 13
Broadband—fixed subscriptions:
total: 3,919,713
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 37
Telephone system: general assessment: satellite-based phone
services; rural connectivity a challenge (2018) domestic:
local phone service with international connections via
Internet (2018)
international: country code—872; satellite earth station—1
(Inmarsat)
Broadcast media: Satellite TV from Fiji-based Sky Pacific
offering a wide range of international channels
Internet country code: .pn
Internet users: total: 54
percent of population: 100% (July 2016 est.)
country comparison to the world: 226
Communications—note: Satellite-based local phone service and
broadband Internet connections available in all homes','0324279ddd8f54c2f0d94f91bb3855e619e31a9ac5100a3b22f09c941f35c306','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b51f872f5e03e2f30750b57393c8c00236bd51b4f7e90d5d80d3d0170954103',2021,'PL','Poland','communications',871,'Telephones—fixed lines: total subscriptions: 6,575,246
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 23
Telephones—mobile cellular:
total subscriptions: 51,098,747
subscriptions per 100 inhabitants: 133 (2018 est.)
country comparison to the world: 30
Telephone system: general assessment: modernization of the
telecommunications network has accelerated with market-
based competition; fixed-line service, dominated by the
former state-owned company, is dwarfed by the growth in
mobile-cellular services; regulatory is framed by EU
principles of competition; mobile penetration is above
European average; 5G trials begin; LTE-B and VoWi-Fi
technologies; launch of 1Gb/s cable services (2018)
domestic: several nation-wide networks provide mobile-
cellular service; coverage is generally good; fixed-line 24
per 100 service lags in rural areas, mobile-cellular 130 per
100 persons (2018) international: country code—48;
landing points for the Baltica and the Denmark-Poland2
submarine cables connecting Poland, Denmark and
Sweden; international direct dialing with automated
exchanges; satellite earth station—1 with access to Intelsat,
Eutelsat, Inmarsat, and Intersputnik (2019) Broadcast media:
state-run public TV operates 2 national channels
supplemented by 16 regional channels and several niche
channels; privately owned entities operate several national
TV networks and a number of special interest channels;
many privately owned channels broadcasting locally;
roughly half of all households are linked to either satellite
or cable TV systems providing access to foreign television
networks; state-run public radio operates 5 national
networks and 17 regional radio stations; 2 privately owned
national radio networks, several commercial stations
broadcasting to multiple cities, and many privately owned
local radio stations (2019) Internet country code: .pl
Internet users: total: 28,237,820
percent of population: 73.3% (July 2016 est.)
country comparison to the world: 27
Broadband—fixed subscriptions:
total: 6,114,926
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 27
Telephones—fixed lines: total subscriptions: 5,073,458
subscriptions per 100 inhabitants: 49 (2018 est.)
country comparison to the world: 31
Telephones—mobile cellular:
total subscriptions: 11,859,548
subscriptions per 100 inhabitants: 115 (2018 est.)
country comparison to the world: 76
Telephone system: general assessment: Portugal’s telephone
system has a state-of-the-art network with broadband, high-
speed capabilities; FttP by 2020; 3G comprehensive and 4G
upgrades; 5G developing; LTE-A trials; DSL moves to fibre
services; FttP for over 5 million customers by 2020
providing national coverage; (2018) domestic: integrated
network of coaxial cables, open-wire, microwave radio
relay, and domestic satellite earth stations; fixed-line 45 per
100 persons and mobile-cellular 109 per 100 persons
(2018) international: country code—351; landing points for
the Ella Link, BUGIO, EIG, SAT-3/WASC, SeaMeWe-3,
Equino, MainOne, Tat TGN-Western Europe, WACS, ACE,
Atlantis2 and Columbus-III submarine cables provide
connectivity to Europe, Africa, the Middle East, Asia,
Southeast Asia, Australia, South America and the US;
satellite earth stations—3 Intelsat (2 Atlantic Ocean and 1
Indian Ocean), NA Eutelsat; tropospheric scatter to Azores
(2019) Broadcast media: Radio e Televisao de Portugal (RTP),
the publicly owned TV broadcaster, operates 4 domestic
channels and external service channels to Africa; overall,
roughly 40 domestic TV stations; viewers have widespread
access to international broadcasters with more than half of
all households connected to multi-channel cable or satellite
TV systems; publicly owned radio operates 3 national
networks and provides regional and external services;
several privately owned national radio stations and some
300 regional and local commercial radio stations Internet
country code: .pt
Internet users: total: 7,629,560
percent of population: 70.4% (July 2016 est.)
country comparison to the world: 56
Broadband—fixed subscriptions:
total: 3,784,684
subscriptions per 100 inhabitants: 37 (2018 est.)
country comparison to the world: 38','684d35e48a3d02c8935487c411c868611d65081adfe2b731be97ccd0a89cbf47','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('503ae487b638d2d87041953dee01cd3888298e33f22912443d3f8cca8d7c5c75',2021,'BG','Bulgaria','communications',882,'Telephones—fixed lines: total subscriptions: 3.66 million
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 39
Telephones—mobile cellular:
total subscriptions: 22.675 million
subscriptions per 100 inhabitants: 106 (2018 est.)
country comparison to the world: 52
Telephone system: general assessment: the
telecommunications sector is being expanded and
modernized; domestic and international service improving
rapidly, especially mobile-cellular services; competition
among a number of telecoms; LIE services; 1Gb/FttP
offering; government secures EU funding to extend
broadband to areas of the country not yet connected (2018)
domestic: fixed-line teledensity is about 18 telephones per
100 persons; mobile market served by four mobile network
operators; mobile-cellular teledensity over 105 telephones
per 100 persons (2018) international: country code—40;
landing point for the Diamond Link Global submarine cable
linking Romania with Georgia; satellite earth stations—10;
digital, international, direct-dial exchanges operate in
Bucharest (2019) Broadcast media: a mixture of public and
private TV stations; there are 7 public TV stations (2
national, 5 regional) using terrestrial broadcasting and 187
private TV stations (out of which 171 offer local coverage)
using terrestrial broadcasting, plus 11 public TV stations
using satellite broadcasting and 86 private TV stations
using satellite broadcasting; state-owned public radio
broadcaster operates 4 national networks and regional and
local stations, having in total 20 public radio stations by
terrestrial broadcasting plus 4 public radio stations by
satellite broadcasting; there are 502 operational private
radio stations using terrestrial broadcasting and 26 private
radio stations using satellite broadcasting Internet country
code: .roO
Internet users: total: 12,852,696
percent of population: 59.5% (July 2016 est.)
country comparison to the world: 44
Broadband—fixed subscriptions:
total: 5.083 million
subscriptions per 100 inhabitants: 24 (2018 est.)
country comparison to the world: 30
Telephones—fixed lines: total subscriptions: 30,108,289
subscriptions per 100 inhabitants: 21 (2018 est.)
country comparison to the world: 9
Telephones—mobile cellular:
total subscriptions: 229,431,008
subscriptions per 100 inhabitants: 161 (2018 est.)
country comparison to the world: 5
Telephone system: general assessment: telecom sector
impacted by sanctions related to the annexations in
Ukraine; the estimated number of mobile subscribers
jumped from fewer than 1 million in 1998 to 255 million in
2016; fixed-line service has improved but a large demand
remains; Russia is one of Europe’s fastest growing markets
for fibre-based broadband; 5G trials; FttP/FttB, DSL, cable
and LTE services (2018) domestic: cross-country digital
trunk lines run from Saint Petersburg to Khabarovsk, and
from Moscow to Novorossiysk; the telephone systems in 60
regional capitals have modern digital infrastructures;
cellular services, both analog and digital, are available in
many areas; in rural areas, telephone services are still
outdated, inadequate, and low-density; 22 per 100 for fixed-
line and mobile-cellular 160 per 100 persons (2018)
international: country code—7; landing points for the Far
East Submarine Cable System, HSCS, Sakhalin-Kuril Island
Cable, RSCN, BCS North-Phase 2, Kerch Strait Cable and
the Georgia-Russian submarine cable system connecting
Russia, Japan, Finland, Georgia and Ukraine; satellite earth
stations provide access to Intelsat, Intersputnik, Eutelsat,
Inmarsat, and Orbita systems (2019) Broadcast media: 13
national TV stations with the federal government owning 1
and holding a controlling interest in a second; state-owned
Gazprom maintains a controlling interest in 2 of the
national channels; government-affiliated Bank Rossiya
owns controlling interest in a fourth and fifth, while a sixth
national channel is owned by the Moscow city
administration; the Russian Orthodox Church and the
Russian military, respectively, own 2 additional national
channels; roughly 3,300 national, regional, and local TV
stations with over two-thirds completely or partially
controlled by the federal or local governments; satellite TV
services are available; 2 state-run national radio networks
with a third majority-owned by Gazprom; roughly 2,400
public and commercial radio stations Internet country code:
.ru; note—Russia also has responsibility for a legacy
domain “.su” that was allocated to the Soviet Union and is
being phased out Internet users: total: 108,772,470
percent of population: 76.4% (July 2016 est.)
country comparison to the world: 6
Broadband—fixed subscriptions:
total: 32,062,780
subscriptions per 100 inhabitants: 23 (2018 est.)
country comparison to the world: 5','e293722902e951d25e395b1b96444f2dc85aca1e368660c6a57630e08d3ad138','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('882bc5cd8842f60c08b5de6cbc15c57471e7957a0a2140800837fdb22f6385df',2021,'KN','Saint Kitts and Nevis','communications',893,'Telephones—fixed lines: total subscriptions: 17,293
subscriptions per 100 inhabitants: 33 (2017 est.)
country comparison to the world: 181
Telephones—mobile cellular:
total subscriptions: 76,878
subscriptions per 100 inhabitants: 146 (2017 est.)
country comparison to the world: 197
Telephone system: general assessment: good interisland and
international connections; broadband access; expanded
FttP (Fiber to the Home) and LTE markets; regulatory
development (2018) domestic: interisland links via ECFS;
fixed-line teledensity about 33 per 100 persons; mobile-
cellular teledensity is roughly 146 per 100 persons (2018)
international: country code—1-869; landing points for the
ECFS, Southern Caribbean Fiber and the SSCS submarine
cables providing connectivity for numerous Caribbean
Islands (2019) Broadcast media: the government operates a
national TV network that broadcasts on 2 channels; cable
subscription services provide access to local and
international channels; the government operates a national
radio network; a mix of government-owned and privately
owned broadcasters operate roughly 15 radio stations
Internet country code: .kn
Internet users: total: 39,000
percent of population: 75.7% (July 2016 est.)
country comparison to the world: 199
Broadband—fixed subscriptions:
total: 16,400
subscriptions per 100 inhabitants: 31 (2017 est.)
country comparison to the world: 159
Telephones—fixed lines: total subscriptions: 36,469
subscriptions per 100 inhabitants: 22 (2018 est.)
country comparison to the world: 167
Telephones—mobile cellular:
total subscriptions: 184,944
subscriptions per 100 inhabitants: 112 (2018 est.)
country comparison to the world: 184
Telephone system: general assessment: an adequate system
that is automatically switched; good interisland and
international connections broadband access; expanded FttP
(Fiber to the Home) and LTE markets; regulatory
development (2018) domestic: fixed-line teledensity is 21
per 100 persons and mobile-cellular teledensity is roughly
107 per 100 persons (2018) international: country code—1-
758; landing points for the ECFS and Southern Caribbean
Fiber submarine cables providing connectivity to numerous
Caribbean islands; direct microwave radio relay link with
Martinique and Saint Vincent and the Grenadines;
tropospheric scatter to Barbados (2019) Broadcast media: 3
privately owned TV stations; 1 public TV station operating
on a cable network; multi-channel cable TV_ service
available; a mix of state-owned and privately owned
broadcasters operate nearly 25 radio stations including
repeater transmission stations Internet country code: .1C
Internet users: total: 86,000
percent of population: 52.4% (July 2016 est.)
country comparison to the world: 177
Broadband—fixed subscriptions: total: 32,265
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 140
Telephone system: general assessment: fully integrated
access; good interisland and international connections;
broadband access; expanded FttP (Fiber to the Home) and
LTE markets; regulatory development (2018) domestic:
direct dial capability with both fixed and wireless systems
(2018)
international: country code—590; landing points for the
SMPR-1, Southern Caribbean Fiber and the SSCS
submarine cables providing connectivity to numerous
Caribbean islands (2019) Broadcast media: 1 local TV station;
access to about 20 radio stations, including RFO
Guadeloupe radio broadcasts via repeater Internet country
code: .mf; note—.gp, the Internet country code for
Guadeloupe, and .fr, the Internet country code for France,
might also be encountered Internet users: total: 1,100
percent of population: 3.5% (July 2016 est.)
country comparison to the world: 221
Telephones—fixed lines: total subscriptions: 4,800
subscriptions per 100 inhabitants: 80 (July 2016 est.)
country comparison to the world: 206
Telephone system: general assessment: adequate (2018)
international: country code—508; landing point for the St
Pierre and Miquelon Cable connecting Saint Pierre &
Miquelon and Canada; radiotelephone communication with
most countries in the world; satellite earth station—1 in
French domestic satellite system (2019) Broadcast media: 2
TV stations with a third repeater station, all part of the
French Overseas Network; radio stations on St. Pierre and
on Miguelon are part of the French Overseas Network
Internet country code: .pM
Internet users: total: 4,500
percent of population: 79.5% (July 2016 est.)
country comparison to the world: 215
Telephones—fixed lines: total subscriptions: 19,219
subscriptions per 100 inhabitants: 19 (2018 est.)
country comparison to the world: 178
Telephones—mobile cellular:
total subscriptions: 105,875
subscriptions per 100 inhabitants: 104 (2018 est.)
country comparison to the world: 194
Telephone system: general assessment: adequate islandwide,
fully automatic telephone system; broadband access;
expand FttP (Fiber to the Home) markets; LTE launches;
regulatory development (2018) domestic: fixed-line
teledensity exceeds 20 per 100 persons and mobile-cellular
teledensity is about 114 per 100 persons (2018)
international: country code—1-784; landing points for the
ECFS, CARCIP and Southern Caribbean Fiber submarine
cables providing connectivity to US and Caribbean Islands;
connectivity also provided by VHF/UHF radiotelephone
from Saint Vincent to Barbados; SHF radiotelephone to
Grenada and Saint Lucia; access to Intelsat earth station in
Martinique through Saint Lucia (2019) Broadcast media: St.
Vincent and the Grenadines Broadcasting Corporation
operates 1 TV station and 5 repeater stations that provide
near total coverage to the multi-island state; multi-channel
cable TV service available; a partially government-funded
national radio service broadcasts on 1 station and has 2
repeater stations; about a dozen privately owned radio
stations and repeater stations Internet country code: . VC
Internet users: total: 53,000
percent of population: 51.8% (July 2016 est.)
country comparison to the world: 191
Broadband—fixed subscriptions:
total: 24,613
subscriptions per 100 inhabitants: 24 (2018 est.)
country comparison to the world: 149','5badf3422523cc4ce34219634311e9f875ed61e2a6c9ad7465a76c1674e7982b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4a9d1450903e92284ce45479c8e30c619850ee090e22a00bbb0e5f9ae67a72a',2021,'WS','Samoa','communications',901,'Telephones—fixed lines: total subscriptions: 8,454
subscriptions per 100 inhabitants: 4 (2017 est.)
country comparison to the world: 194
Telephones—mobile cellular:
total subscriptions: 124,211
subscriptions per 100 inhabitants: 62 (2017 est.)
country comparison to the world: 190
Telephone system: general assessment: most households have
at least one mobile phone; all businesses in the greater
Apia area have access to broadband and Wi-Fi, which is
reasonably reliable and fast; in rural Upolu and on Savaii
Island there is now readily available high-speed Internet
and Wi-Fi; due to the establishment of a regulatory
infrastructure, liberalization and competition of the mobile
market the telecom market has increased coverage and
reduced cost; 4G LTE services accessible to about 95% of
residents (2018) domestic: fixed-line 4 per 100 and mobile-
cellular teledensity 62 telephones per 100 persons (2018)
international: country code—685; landing points for the
Tui-Samo, Manatua, SAS, and Southern Cross NEXT
submarine cables providing connectivity to Samoa, Fiji,
Wallis & Futuna, Cook Islands, Niue, French Polynesia,
American Samoa, Australia, New Zealand, Kiribati, Los
Angeles (US), and Tokelau; satellite earth station—1
Intelsat (Pacific Ocean) (2019) Broadcast media: state-owned
TV station privatized in 2008; 4 privately owned television
broadcast stations; about a half-dozen privately owned
radio stations and one state-owned radio station; TV and
radio broadcasts of several stations from American Samoa
are available (2019) Internet country code: .WS
Internet users: total: 58,508
percent of population: 29.4% (July 2016 est.)
country comparison to the world: 187
Broadband—fixed subscriptions: total: 1,692
subscriptions per 100 inhabitants: 1 (2017 est.)
country comparison to the world: 187','183cf4fa6e9ea715caaae9a1aaff9402d03a8414595869924f94afa66ee93a4c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3a7d3ebe1861a3522836506590fb1851de2f0e32c87e0035e889588d66452ed',2021,'SM','San Marino','communications',907,'Telephones—fixed lines: total subscriptions: 15,800
subscriptions per 100 inhabitants: 47 (2017 est.)
country comparison to the world: 185
Telephones—mobile cellular:
total subscriptions: 38,000
subscriptions per 100 inhabitants: 113 (2017 est.)
country comparison to the world: 207
Telephone system: general assessment: automatic telephone
system completely integrated into Italian system (2018)
domestic: fixed-line 47 per 100 and _ mobile-cellular
teledensity 113 telephones per 100 persons (2018)
international: country code—378; connected to Italian
international network
Broadcast media: State-owned public broadcaster operates 1
TV station and 3 radio stations; receives radio and TV
broadcasts from Italy (2019) Internet country code: .Sm
Internet users: total: 17,200
percent of population: 52.6% (July 2016 est.)
country comparison to the world: 205
Broadband—fixed subscriptions: total: 12,500
subscriptions per 100 inhabitants: 37 (2017 est.)
country comparison to the world: 166','bd060365f6f961c8d3ad4fd40632c578cf4cb5bf1cb092fc981179912d0096f5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c51a301819244c90c75af0eeed325eb46a2fe73d178d0d6068c00d5ebb1d0aae',2021,'ST','Sao Tome and Principe','communications',914,'Telephones—fixed lines: total subscriptions: 5,299
subscriptions per 100 inhabitants: 3 (2018 est.)
country comparison to the world: 205
Telephones—mobile cellular:
total subscriptions: 162,610
subscriptions per 100 inhabitants: 80 (2018 est.)
country comparison to the world: 188
Telephone system: general assessment: local telephone
network of adequate quality with most lines connected to
digital switches; mobile cellular superior choice to
landland; dial-up quality low; broadband expensive (2018)
domestic: fixed-line 3 per 100 and _ mobile-cellular
teledensity 86 telephones per 100 persons (2018)
international: country code—239; landing points for the
Ultramar GE and ACE submarine cables from South Africa
to over 20 West African countries and Europe; satellite
earth station—1 Intelsat (Atlantic Ocean) (2019) Broadcast
media: 1 government-owned TV station; 1 government-
owned radio station; 3 independent local radio stations
authorized in 2005 with 2 operating at the end of 2006;
transmissions of multiple international broadcasters are
available Internet country code: .St
Internet users: total: 50,000
percent of population: 25.8% (July 2016 est.)
country comparison to the world: 193
Broadband—fixed subscriptions: total: 1,557
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 190','0a1af490fdfc8b011afaf41f0cc28d8ca91a8920d71ca9fb1577f0f6f2037784','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c44f3417ba48808363a5b31ed1a82674f60a1f8779927d048cc080990d902b',2021,'ID','Indonesia','communications',919,'Telephones—fixed lines: total subscriptions: 2.001 million
subscriptions per 100 inhabitants: 33 (2018 est.)
country comparison to the world: 59
Telephones—mobile cellular:
total subscriptions: 8,568,400
subscriptions per 100 inhabitants: 143 (2018 est.)
country comparison to the world: 95
Telephone system: general assessment: excellent service;
world leader in telecommunications and perhaps the first
‘Smart Nation’ where a sensor network is implemented;
saturated mobile audience; roll out of 4G and 5G networks
to ensure faster speeds; wireless and fiber broadband
growing segments of telecommunications (2018) domestic:
excellent domestic facilities; fixed-line 34.9 per 100 and
mobile-cellular 149.6 per 100 teledensity; multiple
providers of high-speed Internet connectivity (2018)
international: country code—65; landing points for
INDIGO-West, SeaMeWe -3,-4,-5, SIGMAR, SJC, i2icn,
PGASCOM, BSCS, IGG, B3JS, SAEx2, APCN-2, APG, ASC,
SEAX-1, ASE, EAC-C2C, Matrix Cable System and SJC2
submarine cables providing links throughout Asia,
Southeast Asia, Africa, Australia, the Middle East, and
Europe; satellite earth stations—3, Bukit Timah, Seletar,
and Sentosa; supplemented by VSAT coverage (2019)
Broadcast media: State controls broadcast media; 6 domestic
TV stations operated by MediaCorp which is wholly owned
by a state investment company; broadcasts from Malaysian
and Indonesian stations available; satellite dishes banned;
multi-channel cable TV services available; a total of 19
domestic radio stations broadcasting, with MediaCorp
operating 11, Singapore Press Holdings, also government-
linked, another 5, 2 controlled by the Singapore Armed
Forces Reservists Association and one owned by BBC
Radio; Malaysian and Indonesian radio stations are
available as is BBC; a number of Internet service radio
stations are also available (2019) Internet country code: .Sg
Internet users: total: 4,683,200
percent of population: 81% (July 2016 est.)
country comparison to the world: 80
Broadband—fixed subscriptions:
total: 1,610,500
subscriptions per 100 inhabitants: 27 (2018 est.)
country comparison to the world: 60
Military expenditures:
Telephone system: general assessment: generally adequate
facilities (2018) domestic: extensive interisland microwave
radio relay links (2018)
international: country code—1-721; landing points for
SMPR-1 and the ECFS submarine cables providing
connectivity to the Caribbean; satellite earth stations—2
Intelsat (Atlantic Ocean) (2019) Internet country code: .sx; note
—IANA has designated .sx for Sint Maarten, but has not yet
assigned it to a sponsoring organization MILITARY AND
SECURITY
Military and security forces: NO regular military forces; Police
Department for local law enforcement, supported by the
Royal Netherlands Marechaussee (Gendarmerie), the Dutch
Caribbean Police Force (Korps Politie Caribisch Nederland
or KPCN), and the Dutch Caribbean Coast Guard
(Kustwacht Caribisch Gebied or KWCARIBO)) (2019) Military
—note: defense is the responsibility of the Kingdom of the
Telephones—fixed lines: total subscriptions: 2,206
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 213
Telephones—mobile cellular:
total subscriptions: 1,468,495
subscriptions per 100 inhabitants: 111 (2018 est.)
country comparison to the world: 156
Telephone system: general assessment: rudimentary service in
urban and some rural areas, which is expanding with the
entrance of new competitors; 3G LTE service, with about
97% of population having access, among 3 mobile
operators; increase in mobile broadband penetration
(2018) domestic: system suffered significant damage during
the violence associated with independence; limited fixed-
line services; less than 1 per 100 and mobile-cellular
services have been expanding and are now available in
urban and most rural areas with teledensity of 120 per 100
(2018) international: country code—670; international
service is available; geostationary earth orbit satellite
agreement in the works Broadcast media: 7 TV stations (3
nationwide satellite coverage; 2 terrestrial coverage,
mostly in Dili; 2 cable) and 21 radio stations (3 nationwide
coverage) (2019) Internet country code: .tl
Internet users: total: 318,373
percent of population: 25.2% (July 2016 est.)
country comparison to the world: 158
Broadband—fixed subscriptions: total: 603
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 200','474a1644123548b52ff181871056cbb7f029c326822f2240372dec31c664b024','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01691ed1f2135c513fa51384f0a8e0a1b1c13fc563308f0e628def6844fe24f7',2021,'SK','Slovakia','communications',926,'Telephones—fixed lines: total subscriptions: 722,704
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 86
Telephones—mobile cellular:
total subscriptions: 7,241,702
subscriptions per 100 inhabitants: 133 (2018 est.)
country comparison to the world: 103
Telephone system: general assessment: a modem
telecommunications system; near monopoly of fixed-line
market; competition in mobile and fixed broadband market;
poor mobile virtual network operator (MVNO); regulatory
preparing for 5G; broadband growth in recent years;
competition among DSL, cable and fiber platforms; wireless
broadband options from mobile network operators; FttP
growth in cities (2019) domestic: four companies have a
license to operate cellular networks and provide nationwide
cellular services (cellular operators); a few other
companies provide services but do not have their own
networks; fixed-line 14 per 100 and mobile-cellular 131 per
100 teledesity (2018) international: country code—421; 3
international exchanges (1 in Bratislava and 2 in Banska
Bystrica) are available; Slovakia is participating in several
international telecommunications projects that will
increase the availability of external services (2017)
Broadcast media: State-owned public broadcaster, Radio and
Television of Slovakia (RIVS), operates 2 national TV
stations and multiple national and regional radio networks;
roughly 50 privately owned TV _ stations operating
nationally, regionally, and locally; about 40% of households
are connected to multi-channel cable or satellite TV; 32
privately owned radio stations Internet country code: .Sk
Internet users: total: 4,382,558
percent of population: 80.5% (July 2016 est.)
country comparison to the world: 82
Broadband—fixed subscriptions: total: 1,507,998
subscriptions per 100 inhabitants: 28 (2018 est.)
country comparison to the world: 64','52b5cc1d0e77e43c923408728ac0dcc4229719ed9ba6f8dbf78804f739cda322','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e152a521d55ce5cb0100f76d2d0c98c67fa14f2d91c2a7e3b0ae2bace569ce1e',2021,'SI','Slovenia','communications',932,'Telephones—fixed lines: total subscriptions: 694,709
subscriptions per 100 inhabitants: 33 (2018 est.)
country comparison to the world: 89
Telephones—mobile cellular: total subscriptions: 2,465,857
subscriptions per 100 inhabitants: 117 (2018 est.)
country comparison to the world: 146
Telephone system: general assessment: well-developed
telecommunications infrastructure; four mobile network
operators; regulatory intervention has improved; trials for
use of 5G; unbundles fiber infrastructure; FttP to 90% of
population by 2020 (2018) domestic: fixed-line 36 per 100
and mobile-cellular 124 per 100 teledensity (2018)
international: country code—386 (2016)
Broadcast media: public TV broadcaster, Radiotelevizija
Slovenija (RTV), operates a system of national and regional
TV stations; 35 domestic commercial TV stations operating
nationally, regionally, and locally; about 60% of households
are connected to multi-channel cable TV; public radio
broadcaster operates 3 national and 4 regional stations;
more than 75 regional and local commercial and non-
commercial radio stations Internet country code: .Si
Internet users: total: 1,493,382
percent of population: 75.5% (July 2016 est.)
country comparison to the world: 120
Broadband—fixed subscriptions: total: 612,737
subscriptions per 100 inhabitants: 29 (2018 est.)
country comparison to the world: 79
Telephones—fixed lines: total subscriptions: 7,430
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 199
Telephones—mobile cellular:
total subscriptions: 482,029
subscriptions per 100 inhabitants: 73 (2018 est.)
country comparison to the world: 174
Telephone system: general assessment: Internet penetration
has reached 20%; 3G mobile networks expanding and even
4G LTE services launched in the capital; otherwise 2G and
satellite services for communication and Internet access;
increase in broadband subscriptions (2018) domestic: fixed-
line is 1 per 100 persons and mobile-cellular telephone
density is about 72 per 100 persons; domestic cable system
to extend to key major islands (2018) international: country
code—677; landing points for the CSCS and ICNS2
submarine cables providing connectivity from Solomon
Islands, to PNG, Vanuatu and Australia; satellite earth
station—1 Intelsat (Pacific Ocean) (2019) Broadcast media:
Solomon Islands Broadcasting Corporation (SIBC) does not
broadcast television; multi-channel pay-TV is available;
SIBC operates 2 national radio stations and 2 provincial
stations; there are 2 local commercial radio stations; Radio
Australia is available via satellite feed (since 2009) (2019)
Internet country code: “sb
Internet users: total: 69,859
percent of population: 11% (July 2016 est.)
country comparison to the world: 179
Broadband—fixed subscriptions: total: 1,488
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 192','9d4b5ccc93013f37ee03819e0004d607f4f71358f6c2a17d359604f58658c94f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf9ebe7dc0925db99f1641bc8dbe8222f9b20bbedd51e213d40f46c3883827d2',2021,'SO','Somalia','communications',940,'Telephones—fixed lines: total subscriptions: 74,800
subscriptions per 100 inhabitants: 1 less than 1 (2018 est.)
country comparison to the world: 149
Telephones—mobile cellular:
total subscriptions: 7,653,040
subscriptions per 100 inhabitants: 68 (2018 est.)
country comparison to the world: 99
Telephone system: general assessment: the public telecom
system was almost completely destroyed or dismantled
during the civil war; private companies offer limited local
fixed-line service, and private wireless companies offer
service in most major cities, while charging some of the
lowest rates on the continent; Al Shabaab Islamic militant
group has forced closure of Internet services in some parts
of the country; new telecom regulatory sector in place
(2018) domestic: seven networks compete for customers in
the mobile sector; some of these mobile-service providers
offer fixed-lines and Internet services; fixed-line less than 1
per 100 and _ wmobile-cellular 60 per 100 (2018)
international: country code—252; landing points for the
G2A, DARE1, PEACE, and EASSy fiber-optic submarine
cable system linking East Africa, Indian Ocean Islands, the
Middle East, North Africa and Europe (2019) Broadcast
media: 2 private TV stations rebroadcast Al-Jazeera and
CNN; Somaliland has 1 government-operated TV station
and Puntland has 1 private TV station; the transitional
government operates Radio Mogadishu; 1 SW and roughly
10 private FM radio stations broadcast in Mogadishu;
several radio stations operate in central and southern
regions; Somaliland has 1 government-operated radio
station; Puntland has roughly a half-dozen private radio
stations; transmissions of at least 2 international
broadcasters are available (2019) Internet country code: .SO
Internet users: total: 203,366
percent of population: 1.9% (July 2016 est.)
country comparison to the world: 168
Broadband—fixed subscriptions: total: 92,000
subscriptions per 100 inhabitants: 1 (2017 est.)
country comparison to the world: 123
Telephones—fixed lines: total subscriptions: 3,345,440
subscriptions per 100 inhabitants: 6 (2018 est.)
country comparison to the world: 42
Telephones—mobile cellular:
total subscriptions: 92,427,958
subscriptions per 100 inhabitants: 167 (2018 est.)
country comparison to the world: 17
Telephone system: general assessment: the system is the best-
developed and most modern in Africa; mobile Internet
accounts for about 95% of Internet connections; 94% with
access to WiMAX/LTE services; 5G trials; LTE-A services
launched for commercial use (2018) domestic: fixed-line 7
per 100 persons and mobile-cellular 168 telephones per
100 persons; consists of carrier-equipped open-wire lines,
coaxial cables, microwave radio relay links, fiber-optic
cable, radiotelephone communication stations, and wireless
local loops; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria (2018)
international: country code—27; landing points for the
WACS, ACE, SAFE, SAT-3, Equiano, SABR, SAEx1, SAEx2,
IOX Cable System, METISS, EASSy, and SEACOM/ Tata
TGN-Eurasia fiber-optic submarine cable systems
connecting South Africa, East Africa, West Africa, Europe,
Southeast Asia, Asia, South America, Indian Ocean Islands,
and the US; satellite earth stations—3 Intelsat (1 Indian
Ocean and 2 Atlantic Ocean) (2019) Broadcast media: the
South African Broadcasting Corporation (SABC) operates 4
TV stations, 3 are free-to-air and 1 is pay TV; e.tv, a private
station, is accessible to more than half the population;
multiple subscription TV services provide a mix of local and
international channels; well-developed mix of public and
private radio stations at the national, regional, and local
levels; the SABC radio network, state-owned and controlled
but nominally independent, operates 18 stations, one for
each of the 11 official languages, 4 community stations, and
3 commercial stations; more than 100 community-based
stations extend coverage to rural areas Internet country code:
Za
Internet users: total: 29,322,380
percent of population: 54% (July 2016 est.)
country comparison to the world: 25
Broadband—fixed subscriptions: total: 1,107,013
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 68
EQUATORIAL GUINEA - ra wy Z
Gulf of Guinea , — ~ _*™ogadishu
S40 TOME " / A
AND PRINCIPE yr lb
Sdo Tome GABON 4
aun O01) DEM. REP. \\RWANDS Indian
OF THE CONGO
4 ‘Kinshasa )
Mbuli-Mayl. |
Br. -e
Pointe-Noll Ocean
. Ascension
South
Atlantic
Ocean
‘Windhoek
Walvis Bay,
\\ NAMIBIA | Gabo
Tropic of Capricorn
Saint Helena, Ascension,
and Tristan da Cunha ‘
(OK) ~
Scale 1:51,400,000
Azimuthal Equal-Area Projection
° 800 Kilometers
—_—_—_—_—_—_—_
800 Miles:
Boundary representation Is
not necessarily authoritative.
f
60
803535Al (G00392) 6-12
PHYSICAL MAP OF AFRICA
Pi SS ¢ AO xt ie NG jo
North yn a
Atlantic rage oe,
mY
Ocean aa
ce s\\Re gra
wot
ROM a
Indian
Ocean
: Port Elizabeth SOUTH
@ Year-round research station * AFRICA
Scale 1:68,000,000 South|Atlantic
Azimuthal Equal-Area Projection
Ocean
° 500 1000 Kilometers
° 500 1000 Miles
Twenty-one of 28 Antarctic consultative countries have
made no claims to Antarctic territory (although Russia and
the United States have reserved the right to do so) and
they do not recognize the claims of the other countries. Bouvet island
(NORWAY) PRINCE EDWARD IStANDS
** (SOUTH AFRICA)
South Georgia and
South Sandwich Islands BRITISH
(administered by, U.K. CLAIM
claimed by ARGENTINA)
is Southern » ies
‘Ocean NORWEGIAN CLAIM aa
Ocean "
ARGENTINE undefined limit
Falkland Islands CLAIM
Uislas Malvinas) Z > =
(administered by UK Scotia Se Orcadas < SANAE IV French Southern
claimed by ARGENTINA) JM (ARGENTINA) Neumayer (SOUTH — Novolazarevskaya and Antarctic Lands
4 SOUTH ORKNEY (GERMANY) AFRICA ber 9 eRUSSIA) &
£ ISLANDS ay YY (FRANCE)
4 Maitri a
er ae \\INDIA) Syowal\\ JAPAN)
\\ . AC, °2 ,
ARGENTINA; SHETL area of — BMolodezhnaya ~
s zi a sflargement SY Queen Maud Land ay Les
" z Ushmaia ISLANDS enlargeme * (RUSSIA) KERGUELEN
. Drakg Biidley(u.K)
2 c wy ‘ el
Beh y a be ead by :
i (ARGENTINA) Mawson .
CHILE 5 nme screnqosrRauia) feed a
ar slands
—£% (AUSTRALIA)
Zhong Shani(CHINA ” a
CHILEAN Progress (RUSSIA) 4 Davis(AUSTRALIA)
CLAIM \\4 ean
Ellsworth & Indian
f 4vinson Messif aerepmenal >
: Sitagrest pont m Artavctca, 297m) Se asad (U.S.) 4 Mirnyy
south Pol 5 YY
eter | eae £} land becoach ee Vostok @ RUSSIA) Ocean
Ry v gy RUSSIA) .
t Bentley Subglacial Trench | a7
, fiomest Point i USeDEd, -2540 em) Pe cklet
Marle By: Concordia ° L
South a : (FRANCE AND / ~ s
4
ITALY) *
Pacific n '' v 5 S
: ’ = Casey >
) ‘ t 23 . (AUSTRALIA)
Ucean K t McMurdo sy y¥
\\(U.S.) Vy
| ! &
bY
} S
Victoria Land r
Fuk ont d’Urville
Argentina, Brazil, Chile, China, Poland, C .
Russia, South Korea, Uruguay each have (FRANCE)
a station on King George Island. _ Scott
B = island Sig
(J @ Esperanza by BALLENY -«
rs | ARGENTINA) ISLANDS FRENCH
6 ‘ $ Marambio Southern CLAIM
ARGENTINA pane V3
s Ane )
*CHILEC. “Bernardo | My %, Ocean «ahh
‘es OHigeins! ~ Ey pus UN
Sf @ ~s GHIDE)| “E403 im fo)
D RL 2 CLAIM
f . Macquarte Islartd
} é 1 re (AUSTRALIA)
? , Campbell
raha South island
» Sand "4 (NEW ZEALAND) AUCKLAND ISLANDS
§ Q Pacific 47 Sem AMD) Tasmania
* vernadsky> LL Hobart = .
Antarcti KRAINEL 4 Ocean SNARES ISLANDS x
intarctic - (NEW ZEALAND) AE i ¢
re) = <>
Peninsula NEW 4 y
CHATHAM ISLANDS ZEALAND) South island \\\\ . Canberra
SeiFistchurc \\ 7
F . . (NEW ZEALAND) 2 Chtistchurch *
Southern “s sanMditin Wellington, ¢ ? AUSTRALIA
Ice »S_ (ARGENTINAY { ydney?
Ocean RotReka AK i 4 _— Sydney
(OK gy North Island
803412AI (RO2207) 6-09
POLITICAL MAP OF ARCTIC REGION
= —~ 150
% 1sbAnos es
= Wg ieens >
Sais
ap 2 occupied by thé Soviet Union in 1945:
Petropaviovsk- 77" gdmtsinteren} ty Russia: clalnes by lapen
Kamchatskly / ~/
\\
ee
\\
&
Gulf of
Alaska
f , ; Beaufort
i ¢ Sea
b 4 w
} y ~
Arctic
\\ Ocean/
Baffin
Bay ~
oP
Davis Strat
oa','e67cad9dfd0a969f222997072ebdefb8ae449fa550eff04b0cd42bfcf422a111','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b81b17031d786090e67d600b95776bad326b98957e4026e63f985eae89feb4',2021,'SD','Sudan','communications',953,'Telephones—fixed lines: total subscriptions: 0
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 223
Telephones—mobile cellular:
total subscriptions: 3,672,871
subscriptions per 100 inhabitants: 36 (2018 est.)
country comparison to the world: 132
Telephone system: general assessment: one of the least
developed telecommunications and Internet systems in the
world; domestic mobile providers are waiting for a political
settlement and the return of social stability in order to
expand their networks; the few carriers in the market have
reduced the areas in which they offer service, not expanded
them; the government shut down the largest cellphone
carrier, Vivacell, in March 2018, stranding 1.4 million
customers over a disputed service fee arrangement (2018)
domestic: fixed-line 0 total subscriptions, mobile-cellular 12
per 100 persons (2018)
international: country code—211 (2017)
Broadcast media: a Single TV channel and a radio station are
controlled by the government; several community and
commercial FM stations are operational, mostly sponsored
by outside aid donors; some foreign radio broadcasts are
available (2019) Internet country code: .SS
Broadband—fixed subscriptions: total: 200
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 203
Telephones—fixed lines: total subscriptions: 136,923
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 131
Telephones—mobile cellular:
total subscriptions: 30,100,412
subscriptions per 100 inhabitants: 70 (2018 est.)
country comparison to the world: 45
Telephone system: general assessment: well-equipped system
by regional standards and being upgraded; cellular
communications started in 1996 and have expanded
substantially with wide coverage of most major cities;
economic climate has not encouraged growth in telecoms,
but some investment has been made to build mobile towers
and expand LTE services (2018) domestic: consists of
microwave radio relay, cable, fiber optic, radiotelephone
communications, tropospheric scatter, and a domestic
satellite system with 14 earth stations; teledensity fixed-
line less than 1 per 100 and mobile-cellular 77 telephones
per 100 persons (2018) international: country code—249;
landing points for the EASSy, FALCON and SAS-1,-2, fiber-
optic submarine cable systems linking Africa, the Middle
East, Indian Ocean Islands and Asia; satellite earth stations
—1 Intelsat (Atlantic Ocean) (2019) Broadcast media: the
Sudanese Government directly controls TV and radio,
requiring that both media reflect government policies; TV
has a permanent military censor; a private radio station is
in operation (2019) Internet country code: .Sd
Internet users: total: 10,284,260
percent of population: 28% (July 2016 est.)
country comparison to the world: 47
Broadband—fixed subscriptions: total: 31,352
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 141','7af9388748285c3e0b02920b9e6a5a6230f5c4e0b031b95c31bc8dfe695d5b70','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e542e27e753ed57c4f596832c6eda15cf24b00bd2c3f7f3dcd4b221f23fb81f5',2021,'LK','Sri Lanka','communications',965,'Telephones—fixed lines: total subscriptions: 2,473,875
subscriptions per 100 inhabitants: 11 (2018 est.)
country comparison to the world: 53
Telephones—mobile cellular:
total subscriptions: 30,282,984
subscriptions per 100 inhabitants: 134 (2018 est.)
country comparison to the world: 44
Telephone system: general assessment: telephone services
have improved significantly and are available in most parts
of the country; 4G moving to 5G trials; strong growth
anticipated as Sri Lanka is lagging behind other Asian
telecoms; increase in mobile broadband penetration (2018)
domestic: fixed-line 12 per 100 and mobile-cellular 126 per
100; national trunk network consists of digital microwave
radio relay and fiber-optic links; fixed wireless local loops
have been installed; competition is strong in mobile cellular
systems and mobile cellular subscribership is increasing
(2018) international: country code—94; landing points for
the SeaMeWe_ -3,-5, Dhiraagu-SLT Submarine Cable
Network, WARF Submarine Cable, Bharat Lanka Cable
System and the Bay of Bengal Gateway submarine cables
providing connectivity to Asia, Africa, Southeast Asia,
Australia, the Middle East, and Europe; satellite earth
stations—2 Intelsat (Indian Ocean) (2019) Broadcast media:
government operates 5 TV channels and 19 radio channels;
multi-channel satellite and cable TV subscription services
available; 25 private TV stations and about 43 radio
stations; 6 non-profit TV stations and 4 radio stations
Internet country code: Jk
Internet users: total: 7,126,540
percent of population: 32.1% (July 2016 est.)
country comparison to the world: 60
Broadband—fixed subscriptions: total: 1,544,313
subscriptions per 100 inhabitants: 7 (2018 est.)
country comparison to the world: 63','721217e0b7be74aa69b03b91ece75ff0ff97b8df7d4fbc64eaf06eb5d5083310','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0792687f439cd29f626e680009ccdb8045b834f983385437a96b88d140a47d',2021,'NO','Norway','communications',971,'Telephone system: general assessment: modern, well-
developed (2018) domestic: the Svalbard Satellite Station—
connected to the mainland via the Svalbard Undersea
Cable System—is the only Arctic ground station that can
see low-altitude, polar-orbiting satellites; it provides
ground services to more satellites than any other facility in
the world (2018) international: country code—47-790; the
Svalbard Undersea Cable System is a twin communications
cable that connects Svalbard to mainland Norway; the
system is the sole telecommunications link to the
archipelago (2019) Broadcast media: the Norwegian
Broadcasting Corporation (NRK) began _ direct TV
transmission to Svalbard via _ satellite in 1984;
Longyearbyen households have access to 3 NRK radio and
2 TV stations Internet country code: .Sj
Telephones—fixed lines: total subscriptions: 2,392,386
subscriptions per 100 inhabitants: 24 (2018 est.)
country comparison to the world: 55
Telephones—mobile cellular:
total subscriptions: 12,647,103
subscriptions per 100 inhabitants: 126 (2018 est.)
country comparison to the world: 73
Telephone system: general assessment: highly developed
telecommunications infrastructure; ranked among leading
countries for fixed-line, mobile-cellular, Internet, and
broadband penetration; best developed LTE infrastructures
in the region; first in the world to deliver 5G services
(2018) domestic: fixed-line 28 per 100 and mobile-cellular
125 per 100; coaxial and multiconductor cables carry most
of the voice traffic; parallel microwave radio relay systems
carry some additional telephone channels (2018)
international: country code—46; landing points for Botina,
SFL, SFS-4, Baltic Sea Submarine Cable, Eastern Light,
Sweden-Latvia, BCS North-Phasel, EE-S1, LV-SE1, BCS
East-West Interlink, NordBalt, Baltica, Denmark-Sweden-
15,-17,-18, Scandinavian Ring -North,-South, IP-Only
Denmark-Sweden, Donica North, Kattegate-1,-2, Energinet
Laeso-Varberg and GC2 submarine cables providing links to
other Nordic countries and Europe; satellite earth stations
—1 Intelsat (Atlantic Ocean), 1 Eutelsat, and 1 Inmarsat
(Atlantic and Indian Ocean regions); note—Sweden shares
the Inmarsat earth station with the other Nordic countries
(Denmark, Finland, Iceland, and Norway) (2019) Broadcast
media: publicly owned TV broadcaster operates 2 terrestrial
networks plus regional stations; multiple privately owned
TV broadcasters operating nationally, regionally, and
locally; about 50 local TV stations; widespread access to
pan-Nordic and international broadcasters through multi-
Channel cable and satellite TV; publicly owned radio
broadcaster operates 3 national stations and a network of
25 regional channels; roughly 100 privately owned local
radio stations with some consolidating into near national
networks; an estimated 900 community and neighborhood
radio stations broadcast intermittently Internet country code:
se
Internet users: total: 9,041,427
percent of population: 91.5% (July 2016 est.)
country comparison to the world: 50
Broadband—fixed subscriptions:
total: 3,973,622
subscriptions per 100 inhabitants: 40 (2018 est.)
country comparison to the world: 34','4eea8c2adb81c9db08c6ff5b1baab10097673a211428d5b1cffbc29c26276d99','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e962be950fc70c1852e1d71b02b16f3fb66dc3cbd32920d11915a69660fd6167',2021,'MY','Malaysia','communications',986,'Telephones—fixed lines: total subscriptions: 2.929 million
subscriptions per 100 inhabitants: 4 (2018 est.)
country comparison to the world: 48
Telephones—mobile cellular:
total subscriptions: 125.098 million
subscriptions per 100 inhabitants: 182 (2018 est.)
country comparison to the world: 13
Telephone system: general assessment: high quality system,
especially in urban areas like Bangkok; mobile and mobile
broadband penetration are on the increase; Fibre-to-the-
home (FttH) has seen strong growth in the major cities; 4G
TD-LTE and moving to 5G trials; seven smart cities with the
hope of 100 smart cities within its borders in the next two
decades; one of the biggest e-commerce markets in
Southeast Asia (2018) domestic: fixed-line system provided
by both a government-owned and commercial provider;
wireless service expanding rapidly; fixed-line 4 per 100 and
mobile-cellular 178 per 100 (2018) international: country
code—66; landing points for the AAE-1, FEA, SeaMeWe-
3,-4, APG, SJC2, TIS, MCT and AAG submarine cable
systems providing links throughout Asia, Australia, Africa,
Middle East, Europe, and US; satellite earth stations—2
Intelsat (1 Indian Ocean, 1 Pacific Ocean) (2019) Broadcast
media: 26 digital TV stations in Bangkok broadcast
nationally, 6 terrestrial TV stations in Bangkok broadcast
nationally via relay stations—2 of the stations are owned by
the military, the other 4 are government-owned or
controlled, leased to private enterprise, and all are
required to broadcast government-produced news
programs twice a day; multi-channel satellite and cable TV
subscription services are available; radio frequencies have
been allotted for more than 500 government and
commercial radio stations; many small community radio
stations operate with low-power transmitters (2017) Internet
country code: .th
Internet users: total: 32,398,778
percent of population: 47.5% (July 2016 est.)
country comparison to the world: 21
Broadband—fixed subscriptions: total: 9.189 million
subscriptions per 100 inhabitants: 13 (2018 est.)
country comparison to the world: 19','4ee44d490a154d723298a2c7273b7f2636d657b201892ed01d94caa5d5ba7c63','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41675640b9c596dd0da304c6131b9ed2a4bb0a0ea7348de4bcb59d4d7120902b',2021,'TT','Trinidad and Tobago','communications',997,'Telephones—fixed lines: total subscriptions: 321,434
subscriptions per 100 inhabitants: 26 (2018 est.)
country comparison to the world: 111
Telephones—mobile cellular:
total subscriptions: 1,972,595
subscriptions per 100 inhabitants: 162 (2018 est.)
country comparison to the world: 151
Telephone system: general assessment: excellent international
service; good local service; broadband access; expand FttP
(Fiber to the Home) markets; LTE launches; regulatory
development (2018) domestic: fixed-line 21 per 100 and
mobile-cellular teledensity 167 per 100 persons (2018)
international: country code—1-868; landing points for the
EC Link, ECFS, Southern Caribbean Fiber, SG-SCS and
Americas II submarine cable systems provide connectivity
to US and parts of the Caribbean and South America;
satellite earth station—1 Intelsat (Atlantic Ocean);
tropospheric scatter to Barbados and Guyana (2020)
Broadcast media: 6 free-to-air TV networks, 2 of which are
state-owned; 24 subscription providers (cable and
satellite); over 36 radio frequencies (2019) Internet country
code: .tt
Internet users: total: 846,000
percent of population: 69.2% (July 2016 est.)
country comparison to the world: 136
Broadband—fixed subscriptions: total: 341,045
subscriptions per 100 inhabitants: 28 (2018 est.)
country comparison to the world: 98
Telephones—fixed lines: total subscriptions: 1,302,015
subscriptions per 100 inhabitants: 11 (2018 est.)
country comparison to the world: 69
Telephones—mobile cellular:
total subscriptions: 14,769,594
subscriptions per 100 inhabitants: 128 (2018 est.)
country comparison to the world: 68
Telephone system: general assessment: above the African
average and continuing to be upgraded; key centers are
Sfax, Sousse, Bizerte, and Tunis; telephone network is
completely digitized; Internet access available throughout
the country; penetration rates and Internet services are
among the highest in the region; launched Tunisia’s first
commercial 3G mobile service; in 2016 the regulator
accepted 3 MNO (mobile network operator) bids for LTE
licenses; government Internet censorship abolished in 2013
(2018) domestic: in an effort to jumpstart expansion of the
fixed-line network, the government awarded a concession
to build and operate a VSAT network with international
connectivity; rural areas are served by wireless local loops;
competition between’ several mobile-cellular service
providers has resulted in lower activation and usage
charges and a strong surge in subscribership; fixed-line is
10 per 100 and mobile-cellular teledensity has reached
about 126 telephones per 100 persons (2018) international:
country code—216; landing points for the SEA-ME-WE-4,
Didon, HANNIBAL System and Trapani- Kelibia submarine
cable systems that provides links to Europe, Africa, the
Middle East, Asia and Southeast Asia; satellite earth
stations—1 Intelsat (Atlantic Ocean) and 1 Arabsat; coaxial
cable and microwave radio relay to Algeria and Libya;
participant in Medarabtel; 2 international gateway digital
switches (2020) Broadcast media: 1 state-owned TV station
with multiple transmission sites; 5 private TV stations
broadcast locally; cable TV service is available; state-owned
radio network with 2 stations (in Lome and Kara); several
dozen private radio stations and a few community radio
stations; transmissions of multiple international
broadcasters available (2019) Internet country code: .tn
Internet users: total: 5,665,242
percent of population: 50.9% (July 2016 est.)
country comparison to the world: 70
Broadband—fixed subscriptions: total: 1,014,395
subscriptions per 100 inhabitants: 9 (2018 est.)
country comparison to the world: 69
Telephones—fixed lines: total subscriptions: 11,633,461
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 17
Telephones—mobile cellular:
total subscriptions: 80,117,999
subscriptions per 100 inhabitants: 99 (2018 est.)
country comparison to the world: 20
Telephone = system: general assessment: comprehensive
telecommunications network undergoing rapid
modernization and expansion, especially in mobile-cellular
services; rise in subscribers and increase in bundled
packages; DSL has largest share of fixed broadband
technologies, but fibre-optic is growing with significant
investment; 4G LTE networks well incorporated in Turkey,
87% coverage of the population; 5G trials (2018) domestic:
additional digital exchanges are permitting a rapid increase
in subscribers; the construction of a network of
technologically advanced intercity trunk lines, using both
fiber-optic cable and digital microwave radio relay, is
facilitating communication between urban centers; remote
areas are reached by a domestic satellite system; fixed-line
14 per 100 and mobile-cellular teledensity is 96 telephones
per 100 persons (2018) international: country code—90;
landing points for the SeaMeWe-3 & -5, MedNautilus
Submarine System, Turcyos-1 & -2 submarine cables
providing connectivity to Europe, Africa, the Middle East,
Asia, Southeast Asia and Australia ; satellite earth stations
—12 Intelsat; mobile satellite terminals—328 in the
Inmarsat and Eutelsat systems (2020) Broadcast media:
Turkish Radio and Television Corporation (TRT) operates
multiple TV and radio networks and stations; multiple
privately owned national television stations and 567 private
regional and local television stations; multi-channel cable
TV subscriptions available; 1,007 private radio broadcast
stations (2019) Internet country code: .tr
Internet users: total: 46,838,412
percent of population: 58.3% (July 2016 est.)
country comparison to the world: 16
Broadband—fixed subscriptions: total: 13,407,226
subscriptions per 100 inhabitants: 16 (2018 est.)
country comparison to the world: 15','02b94f8e5cd1301ef96cd3f2dc0742d6e87c46ecdb95f727495de5e7c01557f8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('646bb727c1d1cc6cc8f6012d1101a187257504586717c0bd7e55cea11dc0a16e',2021,'SS','South Sudan','communications',1003,'Telephones—fixed lines: total subscriptions: 186,902
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 124
Telephones—mobile cellular:
total subscriptions: 24,472,033
subscriptions per 100 inhabitants: 60 (2018 est.)
country comparison to the world: 50
Telephone’ system: general assessment: in recent years,
telecommunications infrastructure has developed through
private partnerships; private companies have laid over
1,800 km of fiber optics in Uganda since 2015; as of 2018,
fixed fiber backbone infrastructure is available in over half
of Uganda’s districts; mobile phone companies now provide
4G networks across all major cities and national parks,
while offering 3G coverage in second-tier cities and most
rural areas with road access; between 2016 and 2018,
commercial Internet services dropped in price from
$300/Mbps to $80/Mbps. (2018) domestic: fixed-line 1 per
100 and mobile-cellular systems teledensity about 60 per
100 persons; intercity traffic by wire, microwave radio
relay, and radiotelephone communication stations (2018)
international: country code—256; satellite earth stations—1
Intelsat (Atlantic Ocean) and 1 Inmarsat; analog and digital
links to Kenya and ‘Tanzania Broadcast media: public
broadcaster, Uganda Broadcasting Corporation (UBC),
operates radio and TV networks; 31 Free-To-Air (FTA) TV
stations, 2 digital terrestrial TV stations, 3 cable TV
stations, and 5 digital satellite TV stations; 258 operational
FM stations Internet country code: .ug
Internet users: total: 18,148,923
percent of population: 45.9% (September 2017)
country comparison to the world: 36
Broadband—fixed subscriptions: total: 9,485
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 170
Telephones—fixed lines: total subscriptions: 6,074,255
subscriptions per 100 inhabitants: 14 (2018 est.)
country comparison to the world: 25
Telephones—mobile cellular:
total subscriptions: 53,933,592
subscriptions per 100 inhabitants: 123 (2018 est.)
country comparison to the world: 29
Telephone system: general assessment: Ukraine’s
telecommunication development plan emphasizes
improving domestic trunk lines, international connections,
and the mobile-cellular system; Turkey and Russia have
made investments to telecom market; competition available
between 3 alternative operators; LTE services available;
FttP networks taking over DSL platforms; political tensions
have not added to growth and telecom regulators must not
count Crimea numbers (Annexed by Russia in 2014);
mobile broadband services present a growth opportunity
(2018) domestic: the country’s former sole telephone
provider, Ukrtelekom, was successfully privatized 2011 and
independent foreign-invested private companies now
provide substantial telecommunications services; fixed-line
teledensity is 16 per 100; the mobile-cellular telephone
system’s expansion has slowed, largely due to saturation of
the market that is now 127 mobile phones per 100 persons
(2018) international: country code—380; landing point for
the Kerch Strait Cable to Russia, 2 new domestic trunk
lines are a part of the fiber-optic Trans-Asia-Europe (TAE)
system and 3 Ukrainian links have been installed in the
fiber-optic Trans-European Lines (TEL) project that
connects 18 countries; additional international service is
provided by the Italy-Turkey-Ukraine-Russia (ITUR) fiber-
optic submarine cable and by an unknown number of earth
stations in the Intelsat, Inmarsat, and Intersputnik satellite
systems; new cable to Crimean peninsula is operational
Broadcast media: Ukraine’s media landscape is dominated by
oligarch-owned news outlets, which are often politically
motivated and at odds with one another and/or the
government; while polls suggest most Ukrainians still
receive news from traditional media sources, social media
is a crucial component of information dissemination in
Ukraine; almost all Ukrainian politicians and opinion
leaders communicate with the public via social media and
maintain at least one social media page, if not more; this
allows them direct communication with audiences, and
news often breaks on Facebook or Twitter before being
picked up by traditional news outlets Ukraine television
serves as the principal source of news; the largest national
networks are controlled by oligarchs: TRK Ukraina is
owned by Rinat Akhmetov; Studio 1+1 is owned by Ihor
Kolomoyskyy; Inter is owned by Dmytro Firtash and Serhiy
Lyovochkin; and StarlightMedia channels (ICTV, STB, and
Novyi Kanal) are owned by Victor Pinchuk; a set of 24-hour
news channels also have clear political affiliations: 112-
Ukraine and NewsOne tacitly support pro-Russian
opposition and are believed to be controlled by political and
business tycoon Viktor Medvedchuk; pro-Ukrainian
government Channel 5 and Pryamyi are linked to President
Petro Poroshenko; 24 and ZIK are owned by opposition, but
not pro-Russian, politicians; UA: Suspilne is a_ public
television station under the umbrella of the National Public
Broadcasting Company of Ukraine; while it is often praised
by media experts for balanced coverage, it lags in
popularity; Ukrainian Radio, institutionally linked to UA:
Suspilne, is one of only two national talk radio networks,
with the other being the privately owned Radio NV (2019)
Internet country code: .ua
Internet users: total: 23,202,067
percent of population: 52.5% (July 2016 est.)
country comparison to the world: 30
Broadband—fixed subscriptions:
total: 5,405,125
subscriptions per 100 inhabitants: 12 (2018 est.)
country comparison to the world: 29
Communications—note: a sorting code to expeditiously handle
large volumes of mail was first set up in Ukraine (then part
of the Soviet Union) in the 1930s; the sophisticated, three-
part (number-letter-number) postal code system, referred
to as an “index,” was the world’s first postal zip code; the
system functioned well and was in use from 1932 to 1939
when it was abruptly discontinued MILITARY AND
SECURITY
Military expenditures:
3.78% of GDP (2018)
3.5% of GDP (2017)
3.67% of GDP (2016)
3.97% of GDP (2015)
3.02% of GDP (2014)
country comparison to the world: 15
Military and security forces: Armed Forces of Ukraine (Zbroyni
Syly Ukrayiny, ZSU): Ground Forces (Sukhoputni Viys’ka),
Naval Forces (Viys’kovo-Mors’ki Syly, VMS), Air Forces
(Povitryani Syly, PS), Air Assault Forces (Desantno-
shturmovi Viyska, DShV); Ministry of Internal Affairs:
National Guard of Ukraine, State Border Guard Service of
Ukraine (includes Maritime Border Guard) (2019) Military
service age and obligation: 20-27 years of age for compulsory
military service; conscript service obligation is 12 months
(2019) TRANSPORTATION
National air transport system: number of registered air Carriers:
17 (2015) inventory of registered aircraft operated by air
carriers: 92 (2015)
annual passenger traffic on registered air Carriers:
4,613,224 (2015)
annual freight traffic on registered air carriers: 37,721,565
mt-km (2015)
Civil aircraft registration country code prefix: UR (2016)
Airports: 187 (2013)
country comparison to the world: 31
Airports—with paved runways:
total: 108 (2013)
over 3,047 m: 13 (2013)
2,438 to 3,047 m: 42 (2013)
1,524 to 2,437 m: 22 (2013)
914 to 1,523 m: 3 (2013)
under 914 m: 28 (2013)
Airports—with unpaved runways:
total: 79 (2013)
1,524 to 2,437 m: 5 (2013)
914 to 1,523 m: 5 (2013)
under 914 m: 69 (2013)
Heliports: 9 (2013)
Pipelines: 36720 km gas, 4514 km oil, 4363 km refined
products (2013)
Railways: total: 21,733 km (2014)
standard gauge: 49 km 1.435-m gauge (49 km electrified)
(2014)
broad gauge: 21,684 km 1.524-m gauge (9,250 km
electrified) (2014)
country comparison to the world: 12
Roadways: total: 169,694 km (2012)
paved: 166,095 km (includes 17 km of expressways) (2012)
unpaved: 3,599 km (2012)
country comparison to the world: 32
Waterways: 1,672 km (most on Dnieper River) (2012)
country comparison to the world: 46
Merchant marine: total: 417
by type: container ship 1, general cargo 92, oil tanker 14,
other 310 (2018)
country comparison to the world: 42
Ports and terminals: Major seaport(s): Feodosiya (Theodosia),
Illichivsk, Mariupol’, Mykolayiv, Odesa, Yuzhnyy','007a8b2b160ec33eb837e62351a6e24b2cf77cdab244dfc8b8b49b9a16fbd1c5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed7f63f9de810cd52eee3be26c93b5fed56890286e688512278f22b1d90ba1de',2021,'AE','United Arab Emirates','communications',1011,'Telephones—fixed lines: total subscriptions: 2,341,392
subscriptions per 100 inhabitants: 24 (2018 est.)
country comparison to the world: 57
Telephones—mobile cellular:
total subscriptions: 20,081,015
subscriptions per 100 inhabitants: 207 (2018 est.)
country comparison to the world: 58
Telephone system: general assessment: modern fiber-optic
integrated services; digital network with rapidly growing
use of mobile-cellular telephones; key centers are Abu
Dhabi and Dubai; 5G technology developing; two operators
are competitive, but majority owned by the government;
HSPA (high speed packet access) + LTE networks cover
most of the population; low cost smart phones readily
available; well-established fiber-broadband network
provides future growth (2019) domestic: microwave radio
relay, fiber-optic and coaxial cable; fixed-line 38 per 100
and mobile-cellular 326 per 100 (2018) international:
country code—971; landing points for the FLAG, SEA-ME-
WE-3, -4 & -5, Qater UAE Submarine Cable System,
FALCON, FOG, Tat TGN-Gulf, OMRAN/EPEG Cable System,
AAE-1, BBG, EIG, FEA, GBICS/MENA, IMEWE, Orient
Express, TEAMS, TW1 and the UAE-Iran submarine cables,
linking to Europe, Africa, the Middle East, Asia, Southeast
Asia and Australia; satellite earth stations—3 Intelsat (1
Atlantic Ocean and 2 Indian) (2020) Broadcast media: except
for the many organizations now operating in media free
zones in Abu Dhabi and Dubai, most TV and radio stations
remain government-owned; widespread use of Satellite
dishes provides access to pan-Arab and other international
broadcasts; restrictions since June 2017 on some satellite
channels and websites originating from or otherwise linked
to Qatar (2018) Internet country code: .ae
Internet users: total: 5,370,299
percent of population: 90.6% (July 2016 est.)
country comparison to the world: 73
Broadband—fixed subscriptions: total: 3,024,565
subscriptions per 100 inhabitants: 31 (2018 est.)
country comparison to the world: 44
Telephones—fixed lines: total subscriptions: 31,919,894
subscriptions per 100 inhabitants: 49 (2018 est.)
country comparison to the world: 7
Telephones—mobile cellular: total subscriptions: 79,472,341
subscriptions per 100 inhabitants: 122 (2018 est.)
country comparison to the world: 21
Telephone system: general assessment: technologically
advanced domestic and international system; one of the
largest markets in Europe for revenue and subscribers; will
complete the switch to fiber by 2025; mobile penetration
above the EU average; govt funding for trial 5G
technologies; FttP provided to over million customers;
super-fast broadband available to about 95% of customers
(2018) domestic: equal mix of buried cables, microwave
radio relay, and fiber-optic systems; fixed-line 49 per 100
and mobile-cellular 122 per 100 (2018) international:
country code—44; Landing points for the GTT Atlantic,
Scotland-Northern Ireland -1, & -2, Lanis 1,-2, &-3, Sirius
North, BI-MT-1, SHEFA-2, BT Highlands and Islands
Submarine Cable System, Northern Lights, FARICE-1,
Celtic Norse, Tampnet Offshore FOC Network, England
Cable, CC-2, E-LLan, Sirius South, ESAT -1 & -2, Rockabill,
Geo-Eirgrid, UK-Netherlands-14, Circle North & South,
Ulysses2, Conceto, Farland North, Pan European Crossing,
Solas, Swansea-Bream, GTT Express, Tata TGN-Atlantic & -
Western Europe, Apollo, EIG, Glo-1, TAT-14, Yellow, Celtic,
FLAG Atlantic-1, FEA, Isle of Scilly Cable, UK-Channel
Islands-8 and SeaMeWe-3 submarine cables providing links
throughout Europe, Asia, Africa, the Middle East,
Southeast Asia, Australia, and US; satellite earth stations—
10 Intelsat (7 Atlantic Ocean and 3 Indian Ocean), 1
Inmarsat (Atlantic Ocean region), and 1 Eutelsat; at least 8
large international switching centers (2020) Broadcast media:
public service broadcaster,’ British Broadcasting
Corporation (BBC), is the largest broadcasting corporation
in the world; BBC operates multiple TV networks with
regional and local TV service; a mixed system of public and
commercial TV broadcasters along with satellite and cable
systems provide access to hundreds of TV _ stations
throughout the world; BBC operates multiple national,
regional, and local radio networks with multiple
transmission sites; a large number of commercial radio
stations, as well as satellite radio services are available
(2018) Internet country code: .uk
Internet users: total: 61,064,454
percent of population: 94.8% (July 2016 est.)
country comparison to the world: 11
Broadband—fixed subscriptions:
total: 26,586,110
subscriptions per 100 inhabitants: 41 (2018 est.)
country comparison to the world: 8
Communications—note:
note 1: the British Library claims to be the largest library in
the world with well over 150 million items and in most
known languages; it receives copies of all books produced
in the UK or Ireland, as well as a significant proportion of
overseas titles distributed in the UK; in addition to books
(print and digital), holdings include: journals, manuscripts,
newspapers, Magazines, sound and music recordings,
videos, maps, prints, patents, and drawings note 2: on 1
May 1840, the United Kingdom led the world with the
introduction of postage stamps; the Austrian Empire had
examined the idea of an “adhesive tax postmark” for the
prepayment of postage in 1835; while the suggestion was
reviewed in detail, it was rejected for the time being; other
countries (including Austria) soon followed the UK’s
example with their own postage stamps; by the 1860s, most
countries were issuing stamps; originally, stamps had to be
cut from sheets; the UK issued the first postage stamps
with perforations in 1854
Central African Customs and Economic Union
Ultra-high-frequency','9aa26cb2c780e26fcb181a92601015e1e4c50d848be3674ba19a317d99f676aa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469ebc452673b189a1ccc657ecb08c9294aee28bfbe8465afea763b88a063a9e',2021,'SB','Solomon Islands','communications',1024,'Telephones—fixed lines: total subscriptions: 4,154
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 207
Telephones—mobile cellular:
total subscriptions: 251,428
subscriptions per 100 inhabitants: 87 (2018 est.)
country comparison to the world: 181
Telephone system: general assessment: telecom services have
progressed significantly in recent years; mobile phones are
now the primary means of communication and more than
92% of the population is covered by a mobile network;
2016 saw the launch of LTE services and the introduction
of rural satellite broadband services; mobile phone use in
some rural areas is constrained by electricity shortages;
investment in fixed broadband saw recent growth with
fiber-optic cables; mobile broadband infrastructure also
expanded with a reduction in prices; general broadband
penetration is at 45% (2018) domestic: fixed-line 1 per 100
and mobile-cellular 81 per 100 (2018)
international: country code—678; landing points for the
ICN1 & ICN2 submarine cables providing connectivity to
the Solomon Islands and Fiji; cables helped end-users with
Internet bandwidth; satellite earth station—1 Intelsat
(Pacific Ocean) (2020) Broadcast media: 1 state-owned TV
station; multi-channel pay TV is available; state-owned
Radio Vanuatu operates 2 radio stations; 2 privately owned
radio broadcasters; programming from multiple
international broadcasters is available Internet country code: .
vu
Internet users: total: 66,613
percent of population: 24% (July 2016 est.)
country comparison to the world: 182
Broadband—fixed subscriptions: total: 4,718
subscriptions per 100 inhabitants: 2 (2018 est.)
country comparison to the world: 179','a34dee83c308174eab58a708ecba6524d6677440ffbd2651ca7a70784bb3b9f9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4779543453007f19af4a3e079cd890dc703b3c50db716313571094760395968c',2021,'WF','Wallis and Futuna','communications',1031,'Telephones—fixed lines: total subscriptions: 3,132
subscriptions per 100 inhabitants: 20 (July 2016 est.)
country comparison to the world: 208
Telephone system: general assessment: bandwidth is limited
and broadband is expensive; mobile subscriber numbers
are higher than fixed-line and better suited for islands;
good mobile coverage in the capital cities and also
reasonable coverage across more remote atolls; new
satellite broadband access and speeds (2018) international:
country code—681; landing point for the Tui-Samoa
submarine cable network connecting Wallis & Futuna,
Samoa and Fiji (2020) Broadcast media: the publicly owned
French Overseas Network (RFO), which broadcasts to
France’s overseas departments, collectivities, and
territories, is carried on the RFO Wallis and Fortuna TV and
radio stations (2019) Internet country code: .wf
Internet users: total: 3,450
percent of population: 22.1% (July 2016 est.)
country comparison to the world: 217
Telephones—fixed lines: total subscriptions: 472,293 (includes
Gaza Strip) (2017 est.) subscriptions per 100 inhabitants: 9
(includes Gaza Strip) (2016 est.)
country comparison to the world: 98
Telephones—mobile cellular:
total subscriptions: 4,135,363 (includes Gaza Strip) (2017
est.)
subscriptions per 100 inhabitants: 76 (includes Gaza Strip)
(2017 est.)
country comparison to the world: 129
Telephone system: general assessment: continuing political
and economic instability has impeded liberalization of the
telecommunications industry (2018) domestic: Israeli
company BEZEK and the Palestinian company PALTEL are
responsible for fixed-line services; two Palestinian cellular
providers, JAWWAL and WATANIYA MOBILE, launched 3G
mobile networks in the West Bank in January 2018 after
Israel lifted its ban (2018) international: country code 970
or 972; 1 international switch in Ramallah
Broadcast media: the Palestinian Authority operates 1 TV and
1 radio station; about 20 private TV and 40 radio stations;
both Jordanian TV and satellite TV are accessible Internet
country code: .pSnote—same as Gaza Strip
Internet users: total: 2.673 million (includes Gaza Strip)
percent of population: 57.4% (July 2016 est.)
country comparison to the world: 101
Broadband—fixed subscriptions: total: 371,299
subscriptions per 100 inhabitants: 14 (2017 est.)
note: includes Gaza Strip
country comparison to the world: 93','68187520da12e5094e16e5128fe6b836353d9937f75302005bdbfd3e523b02ef','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7723e83b7b71d8e237044c7dfb243bb0c79c6e1ce650682a294635f7c0babc4',2021,'MA','Morocco','communications',1043,'Telephone system: general assessment: sparse and limited
system international: country code—212; tied _ into
Morocco’s system by microwave radio relay, tropospheric
scatter, and satellite; satellite earth stations—2 Intelsat
(Atlantic Ocean) linked to Rabat, Morocco Broadcast media:
Morocco’s’ state-owned broadcaster, Radio-Television
Marocaine (RTM), operates a radio service from Laayoune
and relays TV service; a Polisario-backed radio station also
broadcasts Internet country code: eh
Telephones—fixed lines: total subscriptions: 984,289,950
subscriptions per 100 inhabitants: 1 (2017 est.)
Telephones—mobile cellular:
total subscriptions: 7,806,142,681
subscriptions per 100 inhabitants: 105 (2017 est.)
Internet users: total: 3,174,000,000 (2018 est.)
percent of population: 43%
top ten countries by Internet usage (in millions): 730.7
China; 374.3 India; 246.8 United States; 122.8 Brazil; 116.6
Japan; 108.8 Russia; 73.3 Mexico; 72.3 Germany; 65.5
Indonesia; 61 United Kingdom Broadband—fixed subscriptions:
total: 1,002,793,951
subscriptions per 100 inhabitants: 14 (2017)
Communications—note: three major data centers—which
provide colocation, telecommunications, cloud services,
and content ecosystems—compete to be called the world’s
biggest in terms of physical space occupied: no. 1: a data
farm in Langfang, Hebei Province, China, identified as the
Range International Information Group, claims to be the
largest with 585,000 sq m (6.3 million sq ft), no. 2: a data
farm in Las Vegas, Nevada, USA, known as the Switch
SuperNAP data center, comes in second with over 325,000
sq m (3.5 million sq ft); it intends to expand to over 1.615
million sq m (17.4 million sq ft) by 2020, no. 3: a data farm
in Ashburn, Virginia, USA, referred to as the DFT Data
Center, is a transit point for 70% of the world’s Internet
traffic; it includes 150,000 sg m (1.6 million sq ft) spread
out over six separate buildings MILITARY AND SECURITY
Military expenditures:
2.14% of GDP (2018)
2.16% of GDP (2017)
2.2% of GDP (2016)
2.25% of GDP (2015)
2.24% of GDP (2014)
Maritime threats: The International Maritime Bureau (IMB)
reports that 2018 saw an increase in global pirate
activities; in 2018, pirates attacked a total of 201 ships
worldwide including boarding 143 ships, hijacking six
ships, and firing on 18; this activity is an increase from 180
incidents in 2017; in 2018, the number of hostages
increased to 141, however, the number of seafarers
kidnapped for ransom increased to 83 compared with 75 in
2017, with nearly all taken off West Africa Operation Ocean
Shield, the NATO naval task force established in 2009 to
combat Somali piracy, concluded its operations in
December 2016 as a result of the drop in reported
incidents over the last few years; the EU naval mission,
Operation ATALANTA, continues its operations in the Gulf
of Aden and Indian Ocean through 2020; naval units from
Japan, India, and China also operate in conjunction with EU
forces; China has established a logistical base in Djibouti to
support its deployed naval units in the Horn of Africa The
Horn of Africa continued to see pirate activities with three
incidents in 2018, a slight decrease over 2017; the
decrease in successful pirate attacks off the Horn of Africa
since the peak in 2007 was due, in part, to anti-piracy
operations by international naval forces, the hardening of
vessels, and the increased use of armed security teams
aboard merchant ships; despite these preventative
measures, the assessed risk remains high West African
piracy more than doubled in 2018 to become the most
dangerous area in the world with 85 attacks in 2018
compared to 33 in 2017; Nigerian pirates are very
aggressive, operating as far as 200 nm offshore and
boarding 29 ships in 2018; attacks in South Asian waters
remain at low levels with 12 attacks off Bangladesh in
2018, up from 11 in 2017; Peru reported four incidents in
2018, up from two in 2017; attacks in Vietnam rose from
two in 2017 to four in 2018; the majority of global attacks
against shipping have occurred in the offshore waters of
five countries—Nigeria, Indonesia, Philippines, Venezuela,
and Bangladesh.
(2018)','9f298f88a04dae73f406fd790f3a66a01eb112b8ec31d72382c0ccb7504f95c0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84fce5300cf3fc1fc3ae03e8586f1e0a5460ef69fb96dc608a7f420b1e2b4f01',2021,'SA','Saudi Arabia','communications',1050,'Telephones—fixed lines: total subscriptions: 1,165,828
subscriptions per 100 inhabitants: 4 (July 2016 est.)
country comparison to the world: 73
Telephones—mobile cellular:
total subscriptions: 15,297,789
subscriptions per 100 inhabitants: 53 (2018 est.) country
comparison to the world: 67
Telephone system: general assessment: due to 75% of
population needing humanitarian assistance, and given the
civil conflict, telecommunications services are vital but
disrupted; mobile towers are often deliberately targeted;
maintenance is dangerous to staff; aid organization rely on
satellite and radio communications; scarcity of
telecommunications equipment in rural areas (2018)
domestic: the national network consists of microwave radio
relay, cable, tropospheric scatter, GSM and CDMA mobile-
cellular telephone systems; fixed-line teledensity remains
low by regional standards at 4 per 100 but mobile cellular
use expanding at 59 per 100 (2018) international: country
code—967; landing points for the FALCON, SeaMeWe-5,
Aden-Djibouti, and the AAE-1 international submarine cable
connecting Europe, Africa, the Middle East, Asia and
Southeast Asia; satellite earth stations—3 Intelsat (2 Indian
Ocean and 1 Atlantic Ocean), 1 Intersputnik (Atlantic
Ocean region), and 2 Arabsat; microwave radio relay to
Saudi Arabia and Djibouti (2020) Broadcast media: state-run
TV with 2 stations; state-run radio with 2 national radio
stations and 5 local stations; stations from Oman and Saudi
Arabia can be accessed Internet country code: .ye
Internet users: total: 6,732,928
percent of population: 24.6% (July 2016 est.) country
comparison to the world: 64
Broadband—fixed subscriptions: total: 386,330
subscriptions per 100 inhabitants: 1 (2018 est.) country
comparison to the world: 91
International Organization for Standardization (ISO)
established—February 1947
aim—to promote the development of international standards with a view to
facilitating international exchange of goods and services and to developing
cooperation in the sphere of intellectual, scientific, technological and economic
activity
members—(121 national standards organizations) Afghanistan, Algeria,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Benin, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Cameroon, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Cyprus, Czechia, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, Germany, Ghana, Greece,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Latvia,
Lebanon, Libya, Lithuania, Luxembourg, Malawi, Malaysia, Mali, Malta,
Mauritius, Mexico, Mongolia, Morocco, Namibia, Nepal, Netherlands, NZ,
Nigeria, North Macedonia, Norway, Oman, Pakistan, Panama, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saudi Arabia,
Senegal, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vietnam,
Yemen, Zimbabwe
correspondent members—(39 plus the Palestine Liberation Organization)
Albania, Angola, The Bahamas, Bhutan, Bolivia, Brunei, Burma, Burundi,
Cambodia, Republic of the Congo, Dominica, Dominican Republic, Eritrea,
Eswatini, The Gambia, Georgia, Guatemala, Guinea, Guyana, Haiti, Honduras,
Hong Kong, Kyrgyzstan, Laos, Macau, Madagascar, Mauritania, Moldova,
Montenegro, Mozambique, Nicaragua, Niger, Papua New Guinea, Paraguay,
Saint Kitts and Nevis, Seychelles, Sierra Leone, Tajikistan, Turkmenistan,
Zambia, Palestine Liberation Organization
subscriber members—(3) Antigua and Barbuda, Belize, Saint Vincent and the
Grenadines
International Organization of the French-speaking World (OIF)
note—name changed from Agency of Cultural and Technical Cooperation
(ACCT) in 1997; also known as Organisation Internationale de la Francophonie
established—20 March 1970
aim—founded around a common language to promote and spread the cultures
of its members and to reinforce cultural and technical cooperation between
them
members—(61) Albania, Andorra, Armenia, Belgium, French Community of
Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cabo Verde, Cambodia,
Cameroon, Canada, Canada—New Brunswick, Canada—Quebec, Central
African Republic, Chad, Comoros, Democratic Republic of Congo, Republic of
Congo, Cote d’Ivoire, Cyprus, Djibouti, Dominica, Egypt, Equatorial Guinea,
France, Gabon, Ghana, Greece, Guinea, Guinea-Bissau, Haiti, Kosovo, Laos,
Lebanon, Luxembourg, Madagascar, Mali, Mauritania, Mauritius, Moldova,
Monaco, Morocco, New Caledonia, Niger, North Macedonia, Qatar, Romania,
Rwanda, Saint Lucia, Sao Tome and Principe, Senegal, Serbia, Seychelles,
Switzerland, Togo, Tunisia, UAE, Vanuatu, Vietnam
observers—(27) Argentina, Austria, Bosnia and Herzegovina, Canada—Ontario,
Costa Rica, Croatia, Czechia, Dominican Republic, Estonia, Gambia, Georgia,
Hungary, Ireland, South Korea, Latvia, Lithuania, Lousiana, Malta, Mexico,
Montenegro, Mozambique, Poland, Slovakia, Slovenia, Thailand, Ukraine,','a7e547ad21545ec64e24c0c1c434cb51eaba501bb7b0bea1096ef942b05dfbc4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c84195956d7154a2e861cdb8efb86a0509e032e385c1f9b14fcc7d5d96ac4c8',2021,'ZW','Zimbabwe','communications',1056,'Telephones—fixed lines: total subscriptions: 100,444
subscriptions per 100 inhabitants: 1 (2018 est.)
country comparison to the world: 140
Telephones—mobile cellular: total subscriptions: 15,470,270
subscriptions per 100 inhabitants: 94 (2018 est.)
country comparison to the world: 66
Telephone system: general assessment: service is among the
best in Sub-Saharan Africa; regulatory approach promotes
competition and a cohort of private sector service providers
offering mobile voice and Internet at some of the lowest
prices in the region (2018) domestic: fiber optic
connections are available between most larger towns and
cities with microwave radio relays serving more rural
areas; 3 cellular telephone providers currently in operation
plus several data only ISPs; fixed-line infrastructure has
degraded significantly and is often being discontinued or
replaced with fixed wireless service; Internet service is
widely available via mobile or fixed wireless terminals (LTE
and 3G), with FTTx in limited urban areas and private Ku
or Ka band VSAT terminals in remote locations; fixed-line 1
per 100 and _ wmobile-cellular 84 per 100 (2018)
international: country code—260; multiple providers
operate overland fiber optic routes via Zimbabwe/South
Africa, Botswana/Namibia and Tanzania provide access to
the major undersea cables Broadcast media: according to the
Independent Broadcast Authority, there are 137 radio
stations and 47 television stations in Zambia; out of the 137
radio stations, 133 are private (categorized as either
commercial or community radio stations), while 4 are
public-owned; state-owned Zambia National Broadcasting
Corporation (ZNBC) operates 2 television channels and 3
radio stations; ZNBC owns 75% shares in GoTV, 40% in
MultiChoice, and 40% in ‘TopStar Communications
Company, all of which operate in-country (2019) Internet
country code: .ZM
Internet users: total: 3,956,252
percent of population: 25.5% (July 2016 est.)
country comparison to the world: 89
Broadband—fixed subscriptions: total: 43,365
subscriptions per 100 inhabitants: less than 1 (2018 est.)
country comparison to the world: 137
Group of 20 (G-20)
established—created 1999; inaugurated 15-16 December 1999
aim—to promote open and constructive discussion between industrial and
emerging-market countries on any issues related to global economic stability;
helps to support growth and development across the globe
members—(20) Argentina, Australia, Brazil, Canada, China, EU, France,
Germany, India, Indonesia, Italy, Japan, South Korea, Mexico, Russia, Saudi
Arabia, South Africa, Turkey, UK, US
Group of 24 (G-24)
established—1 August 1989
aim—to promote the interests of developing countries in Africa, Asia, and Latin
America within the IMF
members—(29) Algeria, Argentina, Brazil, China, Colombia, Democratic
Republic of the Congo, Cote d’Ivoire, Ecuador, Egypt, Ethiopia, Gabon, Ghana,
Guatemala, Haiti, India, Iran, Kenya, Lebanon, Mexico, Morocco, Nigeria,
Pakistan, Peru, Philippines, South Africa, Sri Lanka, Syria, Trinidad and
Tobago, Venezuela
special invitee—(3) Indonesia, UAE, Saudi Arabia
Group of 3 (G-3)
established—September 1990 and ended in 2014
aim—to be a mechanism for policy coorein mechanism for policy coordination
members—Colombia, Mexico, and Venezuela (which left the Group in 2006)
Group of 5 (G-5)
note—with the addition of Italy, Canada, and Russia, it is now known as the
Group of 8 or G-8; meanwhile the Group of 5 now refers to Brazil, China, India,
Mexico, and South Africa
established—22 September 1985
aim—to coordinate the economic policies of five major noncommunist economic
powers
members—(5) France, Germany, Japan, UK, US
Group of 6 (G-6)
also known as Groupe des Six Sur le Désarmement (not to be confused with the
Big Six) was established in 22 May 1984 with the aim of achieving nuclear
disarmament; its members were Argentina, Greece, India, Mexico, Sweden,
Tanzania
Group of 7 (G-7)
note—membership is the same as the Big Seven
established—22 September 1985
aim—to facilitate economic cooperation among the seven major noncommunist
economic powers
members—(8) Group of 5 (France, Germany, Japan, UK, US) plus Canada, EU,
and Italy
Group of 77 (G-77)
established—15 June1964; October 1967 first ministerial meeting
aim—to promote economic cooperation among developing countries; name
persists in spite of increased membership
members—(133 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cabo
Verde, Cameroon, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Fiji, Gabon,
The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, Kiribati,
North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius,
Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands,
Somalia, South Africa, South Sudan, Sri Lanka, Sudan, Suriname, Syria,
Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkmenistan, Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
Group of 8 (G-8)
established—October 1975
aim—to facilitate economic cooperation among the developed countries (DCs)
that participated in the Conference on International Economic Cooperation
(CIEC), held in several sessions between December 1975 and 3 June 1977;
Russia admitted in 1997 but suspended in 2014 following the annexation of
Crimea in Ukraine; the EU has been represented in the G-8 since the 1980s
members—(9) Canada, EU, France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9)
established—NA
aim—to discuss matters of mutual interest on an informal basis
members—(9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Serbia, Sweden; may not be active
Gulf Cooperation Council (GCC)
note—also known as the Cooperation Council for the Arab States of the Gulf
established—25 May 1981
aim—to promote regional cooperation in economic, social, political, and
military affairs
members—(6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
high income countries
another term for the industrialized countries with high per capita GDPs; see
developed countries (DCs)
Indian Ocean Commission (InOC)
established—21 December 1982
aim—to organize and promote regional cooperation in all sectors, especially
economic
members—(5) Comoros, France (for Reunion), Madagascar, Mauritius,
note—Andorra is a member but have not been assigned to a list
International Hydrographic Organization (IHO)
note—name changed from International Hydrographic Bureau on 22
September 1970 June 1919; effective—June 1921
aim—to train hydrographic surveyors and nautical cartographers to achieve
standardization in nautical charts and electronic chart displays; to provide
advice on nautical cartography and hydrography; to develop the sciences in the
field of hydrography and techniques used for descriptive oceanography
members—(89) Algeria, Argentina, Australia, Bahrain, Bangladesh, Belgium,
Brazil, Brunei, Bulgaria, Burma, Cameroon, Canada, Chile, China (including
Hong Kong and Macau), Colombia, Democratic Republic of the Congo, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Ecuador, Egypt, Estonia, Fiji,
Finland, France, Georgia, Germany, Greece, Guatemala, Iceland, India,
Indonesia, Iran, Ireland, Italy, Jamaica, Japan, North Korea, South Korea,
Kuwait, Latvia, Malaysia, Malta, Mauritius, Mexico, Monaco, Montenegro,
Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan,
Papua New Guinea, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saudi Arabia, Serbia, Seychelles, Singapore, Slovenia, South Africa,
Spain, Sri Lanka, Suriname, Sweden, Syria, Thailand, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela,
Vietnam
International Labor Organization (ILO)
established—28 June 1919 set up as part of Treaty of Versailles; 11 April 1919
became operative; 14 December 1946 affiliated with the UN
aim—to deal with world labor issues; a UN specialized agency
members—(190) includes all UN member countries except Andorra, Bhutan,
North Korea, Liechtenstein, Federated States of Micronesia, Monaco, Nauru;
note—includes the following dependencies: Netherlands (Aruba, Curacao, Sint
Maarten), New Zealand (Cook Islands)
International Maritime Organization (IMO)
note—name changed from Intergovernmental Maritime Consultative
Organization (IMCO) on 22 May 1982
established—6 March 1948 set up as the Inter-Governmental Maritime
Consultative Organization; effective—17 March 1958
aim—to deal with international maritime affairs; a UN specialized agency
members—(174) includes all UN member countries except Afghanistan,
Andorra, Bhutan, Botswana, Burkina Faso, Burundi, Central African Republic,
Chad, Eswatini, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Mali, Federated
States of Micronesia, Niger, Rwanda, South Sudan, Tajikistan, Uzbekistan; and
the Cook Islands
associate members—(3) Faroe Islands, Hong Kong, Macau
International Mobile Satellite Organization (IMSO)
established—15 April 1999
aim—acts as watchdog over Inmarsat (International Maritime Satellite
Organization), a private company, to make sure it follows ICAO standards and
recommended practices; plays an active role in the development of
international telecommunications policies
members—(103) Algeria, Antigua and Barbuda, Argentina, Australia, The
Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Bosnia and Herzegovina,
Brazil, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Comoros,
Cook Islands, Costa Rica, Croatia, Cuba, Cyprus, Czechia, Denmark, Ecuador,
Egypt, Fiji, Finland, France, Gabon, Georgia, Germany, Ghana, Greece,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Israel, Italy, Japan,
Jordan, Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia,
Libya, Malaysia, Malta, Marshall Islands, Mauritius, Mexico, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Palau, Panama, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia,
South Africa, Spain, Sri Lanka, Sweden, Switzerland, Tanzania, Thailand,
Tonga, Tunisia, Turkey, Ukraine, UAE, UK, US, Vanuatu, Venezuela, Vietnam,
associate members—(6) Aruba, Flemish Community of Belgium, Hong Kong,
Macau, Madeira Islands, Puerto Rico
observers—(1 plus Palestine Liberation Organization) Holy See, Palestine
Liberation Organization
World Trade Organization (WTO)
note—succeeded General Agreement on Tariff and Trade (GATT)
established—15 April 1994; effective—1 January 1995
aim—to provide a forum to resolve trade conflicts between members and to
carry on negotiations with the goal of further lowering and/or eliminating
tariffs and other trade barriers
members—(164) Afghanistan, Albania, Angola, Antigua and _ Barbuda,
Argentina, Armenia, Australia, Austria, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cabo Verde, Cambodia, Cameroon, Canada, Central
African Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus,
Czechia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Eswatini, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Liechtenstein,
Lithuania, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, North Macedonia, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Chinese Taipei, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
observers—(22) Algeria, Andorra, Azerbaijan, The Bahamas, Belarus, Bhutan,
Bosnia and Herzegovina, Comoros, Equatorial Guinea, Ethiopia, Holy See, Iran,
Iraq, Lebanon, Libya, Sao Tome and Principe, Serbia, Somalia, Sudan, Syria,
Timor-Leste Uzbekistan
note—with the exception of the Holy See, an observer must start accession
negotiations within five years of becoming an observer
Zangger Committee (ZC)
established—early 1970s
aim—to establish guidelines for the export control provisions of the
Nonproliferation of Nuclear Weapons Treaty (NPT)
members—(38) Argentina, Australia, Austria, Belarus, Belgium, Bulgaria,
Canada, China, Croatia, Czechia, Denmark, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Japan, Kazakhstan, South Korea, Luxembourg,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia,
South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observers—(1) EU
APPENDIX C
SELECTED INTERNATIONAL
ENVIRONMENTAL AGREEMENTS
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Heavy Metals
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Heavy Metals Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or Their
Transboundary Fluxes Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary Fluxes
by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions Air Pollution-Volatile
Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic Compounds
or Their Transboundary Fluxes Antarctic—Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature—1 December 1959
entered into force—23 June 1961
objective—to ensure that Antarctica is used for peaceful purposes only (such as
international cooperation in scientific research); to defer the question of
territorial claims asserted by some nations and not recognized by others; to
provide an international forum for management of the region; applies to land
and ice shelves south of 60 degrees south latitude parties—(53) Argentina,
Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, Chile, China,
Colombia, Cuba, Czechia, Denmark, Ecuador, Estonia, Finland, France,
Germany, Greece, Guatemala, Hungary, Iceland, India, Italy, Japan, Kazakhstan,
North Korea, South Korea, Malaysia, Monaco, Mongolia, Netherlands, NZ,
Norway, Pakistan, Papua New Guinea, Peru, Poland, Portugal, Romania, Russia,
Slovakia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US,
Uruguay, Venezuela Basel Convention on the Control of Transboundary
Movements of Hazardous Wastes and Their Disposal note—abbreviated as
Hazardous Wastes
opened for signature—22 March 1989
entered into force—5 May 1992
objective—to reduce transboundary movements of wastes subject to the
Convention to a minimum consistent with the environmentally sound and
efficient management of such wastes; to minimize the amount and toxicity of
wastes generated and ensure their environmentally sound management as
closely as possible to the source of generation; and to assist LDCs in
environmentally sound management of the hazardous and other wastes they
generate parties—(186 and the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czechia,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, EU, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Irag, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Latvia, Laos, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, North Macedonia, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine
Liberation Organization countries that have signed, but not yet ratified—(1) US
Biodiversity
see Convention on Biological Diversity
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate
Change
Convention for the Conservation of Antarctic Seals
note—abbreviated as Antarctic Seals
opened for signature—1 June 1972
entered into force—11 March 1978
objective—to promote and achieve the protection, scientific study, and rational
use of Antarctic seals, and to maintain a satisfactory balance within the
ecological system of Antarctica parties—(17) Argentina, Australia, Belgium,
Brazil, Canada, Chile, France, Germany, Italy, Japan, Norway, Pakistan, Poland,
Russia, South Africa, UK, US
countries that have signed, but not yet ratified—(1) NZ
Convention on Biological Diversity
note—abbreviated as Biodiversity
opened for signature—5 June 1992
entered into force—29 December 1993
objective—to develop national strategies for the conservation and sustainable
use of biological diversity and to address the fair and equitable sharing of
benefits arising out of the utilization of genetic resources parties—(195 and the
Palestine Liberation Organization) Afghanistan, Albania, Algeria, Andorra,
Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium,
Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czechia, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, North
Macedonia, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization countries that have signed, but not yet
ratified—(1) US
Convention on Fishing and Conservation of Living Resources of the
High Seas
note—abbreviated as Marine Life Conservation
opened for signature—29 April 1958
entered into force—20 March 1966
objective—to solve through international cooperation the problems involved in
the conservation of living resources of the high seas, considering that because
of the development of modern technology some of these resources are in
danger of being overexploited parties—(39) Australia, Belgium, Bosnia and
Herzegovina, Burkina Faso, Cambodia, Colombia, Republic of the Congo,
Denmark, Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya,
Lesotho, Madagascar, Malawi, Malaysia, Mauritius, Mexico, Montenegro,
Netherlands, Nigeria, Portugal, Senegal, Serbia, Sierra Leone, Solomon
Islands, South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad and
Tobago, Uganda, UK, US, Venezuela countries that have signed, but not yet
ratified—(21) Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba,
Ghana, Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ,
Pakistan, Panama, Sri Lanka, Tunisia, Uruguay Convention on Long-Range
Transboundary Air Pollution
note—abbreviated as Air Pollution
opened for signature—13 November 1979
entered into force—16 March 1983
objective—to protect the human environment against air pollution and, as far
as possible, to gradually reduce and prevent air pollution, including long-range
transboundary air pollution parties—(51) Albania, Armenia, Austria, Azerbaijan,
Bel','6d9aad8c50d2469ab78edef52260826fd5b2fa954b7c93cd3d5283d7afb091dd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f61c00438991d0b3ff6d1698a82db54a31bf6df6a3276e170001c65760f01f2f',2021,'ZW','Zimbabwe','communications',1057,'arus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czechia, Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein,
Lithuania, Luxembourg, Malta, Moldova, Monaco, Montenegro, Netherlands,
North Macedonia, Norway, Poland, Portugal, Romania, Russia, Serbia, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
countries that have signed, but not yet ratified—(1) Holy See, San Marino
Convention on the Conservation of Antarctic Marine Living Resources
note—abbreviated as Antarctic-Marine Living Resources
opened for signature—5 May 1980
entered into force—7 April 1982
objective—to safeguard the environment and protect the integrity of the
ecosystem of the seas surrounding Antarctica, and to conserve Antarctic
marine living resources members—(25) Argentina, Australia, Belgium, Brazil,
Chile, China, EU, France, Germany, India, Italy, Japan, South Korea, Namibia,
NZ, Norway, Poland, Russia, South Africa, Spain, Sweden, Ukraine, UK, US,
Uruguay acceding states—(11) Bulgaria, Canada, Cook Islands, Finland,
Greece, Mauritius, Netherlands, Pakistan, Panama, Peru, Vanuatu Convention
on the International Trade in Endangered Species of Wild Flora and Fauna
(CITES) note—abbreviated as Endangered Species
opened for signature—3 March 1973
entered into force—1 July 1975
objective—to protect certain endangered species from overexploitation by
means of a system of import/export permits parties—(183) Afghanistan,
Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Eswatini, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, North Macedonia, Norway, Oman, Palau,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention) note—abbreviated as Marine Dumping
opened for signature—29 December 1972
entered into force—30 August 1975
objective—to promote effective control of all sources of marine pollution and to
take all practicable steps to prevent pollution of the sea by dumping and to
encourage regional agreements supplementary to the Convention parties—(87)
Afghanistan, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados,
Belarus, Belgium, Benin, Bolivia, Brazil, Bulgaria, Canada, Cape Verde, Chile,
China, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Equatorial Guinea,
Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras,
Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
South Korea, Libya, Luxembourg, Malta, Mexico, Monaco, Montenegro,
Morocco, Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Peru, Philippines, Poland, Portugal, Russia, Saint Lucia,
Saint Vincent and the Grenadines, Serbia, Seychelles, Sierra Leon, Slovenia,
Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Syria,
Tanzania, Tonga, Tunisia, Ukraine, UAE, UK, US, Vanuatu associate members to
the London Convention—(3) Faroe Islands, Hong Kong, Macau countries that
have signed, but not yet ratified—(3) Chad, Kuwait, Uruguay Convention on the
Prohibition of Military or Any Other Hostile Use of Environmental Modification
Techniques note—abbreviated as Environmental Modification
opened for signature—18 May 1977
entered into force—5 October 1978
objective—to prohibit the military or other hostile use of environmental
modification techniques in order to further world peace and trust among
nations parties—(77 and the Palestine Liberation Organization) Afghanistan,
Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Bangladesh, Belarus, Belgium, Benin, Brazil, Bulgaria, Canada, Cameroon,
Cape Verde, Chile, China, Costa Rica, Cuba, Cyprus, Czechia, Denmark,
Dominica, Egypt, Estonia, Finland, Germany, Ghana, Greece, Guatemala,
Honduras, Hungary, India, Ireland, Italy, Japan, Kazakhstan, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Lithuania, Malawi, Mauritius,
Mongolia, Netherlands, NZ, Nicaragua, Niger, Norway, Pakistan, Panama,
Papua New Guinea, Poland, Romania, Russia, Saint Lucia, Saint Vincent and
the Grenadines, Sao Tome and Principe, Slovakia, Slovenia, Solomon Islands,
Spain, Sri Lanka, Sweden, Switzerland, Tajikistan, Tunisia, Ukraine, UK, US,
Uruguay, Uzbekistan, Vietnam, Yemen, Palestine Liberation Organization
countries that have signed, but not yet ratified—(16) Bolivia, Democratic
Republic of the Congo, Ethiopia, Holy See, Iceland, Iran, Iraq, Lebanon,
Liberia, Luxembourg, Morocco, Portugal, Sierra Leone, Syria, Turkey, Uganda
Convention on Wetlands of International Importance Especially as Waterfowl
Habitat (Ramsar) note— abbreviated as Wetlands
opened for signature—2 February 1971
entered into force—21 December 1975
objective—to stem the progressive encroachment on and loss of wetlands now
and in the future parties —(170) Albania, Algeria, Andorra, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burma, Burundi, Cabo Verde, Cambodia, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus,
Czechia, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Estonia, Eswatini, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea,
Kyrgyzstan, Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, North Macedonia, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Rwanda, Saint Lucia, Samoa, Sao Tome and
Principe, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tanzania, Tajikistan, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe Desertification
see United Nations Convention to Combat Desertification in those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora
and Fauna (CITES) Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal International Convention for the
Regulation of Whaling
note—abbreviated as Whaling
opened for signature—2 December 1946
entered into force—10 November 1948
objective—to protect all species of whales from overhunting; to establish a
system of international regulation for the whale fisheries to ensure proper
conservation and development of whale stocks; and to safeguard for future
generations the great natural resources represented by whale stocks parties—
(89) Antigua and Barbuda, Argentina, Australia, Austria, Belgium, Belize,
Benin, Brazil, Bulgaria, Cambodia, Cameroon, Chile, China, Colombia, Republic
of the Congo, Costa Rica, Cote D’Ivoire, Croatia, Cyprus, Czechia, Denmark,
Dominica, Dominican Republic, Ecuador, Eritrea, Estonia, Finland, France,
Gabon, The Gambia, Germany, Ghana, Grenada, Guinea, Guinea-Bissau,
Hungary, Iceland, India, Ireland, Israel, Italy, Japan, Kenya, Kiribati, South
Korea, Laos, Liberia, Lithuania, Luxembourg, Mali, Marshall Islands,
Mauritania, Mexico, Monaco, Mongolia, Morocco, Nauru, Netherlands, NZ,
Nicaragua, Norway, Oman, Palau, Panama, Peru, Poland, Portugal, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
San Marino, Sao Tome and Principe, Senegal, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tanzania, Togo,
Tuvalu, UK, US, Uruguay International Tropical Timber Agreement, 2006
note—abbreviated as Tropical Timber, 2006; ITTA, 2006; or ITTA3
opened for signature—3 April 2006
entered into force—7 December 2011; note—superseded the International
Tropical Timber Agreement, 1994, which itself superseded the International
Tropical Timber Agreement, 1983
objective—to promote the expansion and diversification of international trade
in tropical timber from sustainably managed and legally harvested forests and
to promote the sustainable management of tropical timber producing forests
parties—(74) Abania, Australia, Austria, Belgium, Benin, Brazil, Bulgaria,
Burma, Cambodia, Cameroon, Central African Republic, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cyprus, Czechia, Denmark, Ecuador, Estonia, EU, Fiji,
Finland, France, Gabon, Germany, Ghana, Greece, Guatemala, Guyana,
Honduras, Hungary, India, Indonesia, Ireland, Italy, Japan, South Korea, Latvia,
Liberia, Lithuania, Luxembourg, Madagascar, Malaysia, Mali, Malta, Mexico,
Mozambique, Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Suriname,
Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela,
Vietnam countries that have signed, but not yet ratified—(2) Nigeria, Paraguay
Kyoto Protocol to the United Nations Framework Convention on Climate
Change
note—abbreviated as Climate Change-Kyoto Protocol
opened for signature—16 March 1998
entered into force—16 February 2005
objective—to further reduce greenhouse gas emissions by enhancing the
national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries parties—
(192) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cabo Verde, Cambodia, Cameroon, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus,
Czechia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
North Macedonia, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe countries
that have signed, but not yet ratified—(1) US
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention) Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High
Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
note—abbreviated as Ozone Layer Protection
opened for signature—16 September 1987
entered into force—1 January 1989
objective—to protect the ozone layer by controlling emissions of substances
that deplete it parties—(197) Afghanistan, Albania, Algeria, Andorra, Angola,
Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Eswatini, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Irag, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, North Macedonia, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, South
Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Multi-effect Protocol
see Protocol to the 1979 Convention on Long- Range Transboundary Air
Pollution to Abate Acidification, Eutrophication, and Ground- Level Ozone
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space,
and Under Water Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL) note—abbreviated
as Ship Pollution
opened for signature—1 June 1978
entered into force—2 October 1983
objective—to preserve the marine environment in an attempt to completely
eliminate pollution by oil and other harmful substances and to minimize
accidental spillage of such substances parties—(153) Albania, Algeria, Angola,
Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Brazil,
Brunei, Bulgaria, Burma, Cabo Verde, Cambodia, Cameroon, Canada, Chile,
China, Colombia, Comoros, Republic of Congo, Cook Islands, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Irag, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya,
Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Montenegro, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Switzerland, Syria, Tanzania, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Tuvalu, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela,
Vietnam Protocol on Environmental Protection to the Antarctic Treaty
note—abbreviated as Antarctic-Environmental Protocol
opened for signature—4 October 1991
entered into force—14 January 1998
objective—to provide for comprehensive protection of the Antarctic
environment and dependent and associated ecosystems; applies to the area
covered by the Antarctic Treaty consultative parties—(29) Argentina, Australia,
Belgium, Brazil, Bulgaria, Chile, China, Czechia, Ecuador, Finland, France,
Germany, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru,
Poland, Russia, South Africa, Spain, Sweden, Ukraine, UK, US, Uruguay non
consultative parties—(24) Austria, Belarus, Canada, Colombia, Cuba, Denmark,
Estonia, Greece, Guatemala, Hungary, Iceland, Kazakhstan, North Korea,
Malaysia, Monaco, Mongolia, Pakistan, Papua New Guinea, Portugal, Romania,
Slovakia, Switzerland, Turkey, Venezuela Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution Concerning the Control of Emissions
of Nitrogen Oxides or Their Transboundary Fluxes note—abbreviated as Air
Pollution-Nitrogen Oxides
opened for signature—31 October 1988
entered into force—14 February 1991
objective—to provide for the control or reduction national of nitrogen oxide
emissions and their transboundary fluxes parties—(35) Albania, Austria,
Belarus, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czechia, Denmark,
Estonia, EU, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Liechtenstein, Lithuania, Luxembourg, Netherlands, North Macedonia, Norway,
Poland, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Ukraine, UK,
US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes note—abbreviated as Air
Pollution-Volatile Organic Compounds opened for signature—18
November 1991
entered into force—29 September 1997
objective—to provide for the control and reduction of national emissions of
volatile organic compounds in order to reduce their transboundary fluxes
parties—(24) Austria, Belgium, Bulgaria, Croatia, Czechia, Denmark, Estonia,
Finland, France, Germany, Hungary, Italy, Liechtenstein, Lithuania,
Luxembourg, Monaco, Netherlands, North Macedonia, Norway, Slovakia,
Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified—(6) Canada, EU, Greece,
Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions note—abbreviated
as Air Pollution-Sulphur 94
opened for signature—14 June 1994
entered into force—5 August 1998
objective—to provide for a further reduction in national sulfur emissions or
transboundary fluxes on a regional basis within Europe parties—(30) Austria,
Belgium, Bulgaria, Canada, Croatia, Cyprus, Czechia, Denmark, EU, Finland,
France, Germany, Greece, Hungary, Ireland, Italy, Liechtenstein, Lithuania,
Luxembourg, Monaco, Netherlands, North Macedonia, Norway, Poland,
Slovakia, Slovenia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified—(2) Russia, Ukraine Protocol to
the 1979 Convention on Long-Range Transboundary Air Pollution on Heavy
Metals note—abbreviated as Air Pollution-Heavy Metals
opened for signature—24 June 1998
entered into force—29 December 2003
objective—to reduce emissions of the heavy metals cadmium, lead, and
mercury from industrial sources, combustion processes, and waste incineration
parties—(34) Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czechia,
Denmark, Estonia, EU, Finland, France, Germany, Hungary, Iceland, Latvia,
Liechtenstein, Lithuania, Luxembourg, Moldova, Monaco, Montenegro,
Netherlands, North Macedonia, Norway, Portugal, Romania, Serbia, Slovakia,
Slovenia, Spain, Sweden, Switzerland, UK, US
countries that have signed, but not yet ratified—(7) Armenia, Greece, Iceland,
Ireland, Italy, Poland, Ukraine Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution on Persistent Organic Pollutants note—abbreviated
as Air Pollution-Persistent Organic Pollutants opened for signature—24 June
1998
entered into force—23 October 2003
objective—to provide for the control, reduction, or elimination of discharges,
emissions of persistent organic pollutants parties—(33) Austria, Belgium,
Bulgaria, Canada, Croatia, Cyprus, Czechia, Denmark, Estonia, EU, Finland,
France, Germany, Hungary, Iceland, Italy, Latvia, Liechtenstein, Lithuania,
Luxembourg, Moldova, Montenegro, Netherlands, North Macedonia, Norway,
Romania, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified—(7) Armenia, Greece, Ireland,
Poland, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or _ Their
Transboundary Fluxes by at Least 30%
note—abbreviated as Air Pollution-Sulphur 85
op','7b3c38adc7aa3c6c22828a141c0a0d404393ba5e1a49f8ea88cb7c2857855864','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e21c716092b8c92b05ca674b4b677f1b693cde9b97d275ffd18d944de1a34f70',2021,'ZW','Zimbabwe','communications',1058,'ened for signature—8 July 1985
entered into force—2 September 1987
objective—to provide for national reductions in sulfur emissions or
transboundary fluxes by 30% of 1980 emission or transboundary flux levels by
no later than 1993
parties—(25) Albania, Austria, Belarus, Belgium, Bulgaria, Canada, Czechia,
Denmark, Estonia, Finland, France, Germany, Hungary, Italy, Liechtenstein,
Lithuania, Luxembourg, Netherlands, North Macedonia, Norway, Russia,
Slovakia, Sweden, Switzerland, Ukraine note—Albania and Macedonia listed as
non-compliant
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution to Abate Acidification, Eutrophication, and Ground-Level
Ozone note—abbreviated as Multi-effect Protocol
opened for signature—30 November 1999
entered into force—17 May 2005
objective—to reduce acidification, eutrophication, and ground-level ozone by
setting emissions ceilings for sulphur dioxide, nitrogen oxides, volatile organic
compounds, and ammonia parties—(27) Belgium, Bulgaria, Canada, Croatia,
Cyprus, Czechia, Denmark, EU, Finland, France, Germany, Hungary, Latvia,
Lithuania, Luxembourg, Netherlands, North Macedonia, Norway, Portugal,
Romania, Slovakia, Slovenia, Spain, Sweden, Switzerland, UK, US
countries that have signed, but not yet ratified—(8) Armenia, Austria, Greece,
Ireland, Italy, Liechtenstein, Moldova, Poland Ship Pollution
see Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL) Treaty Banning Nuclear
Weapon Tests in the Atmosphere, in Outer Space, and Under Water note—
abbreviated as Nuclear Test Ban
opened for signature—5 August 1963
entered into force—10 October 1963
objective—to ban nuclear weapons testing in the atmosphere, outer space, or
under water parties—(125) Afghanistan, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, The Bahamas, Bangladesh, Belarus, Belgium,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burma, Cabo Verde, Canada, Central African Republic, Chad, Chile, Colombia,
Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cyprus,
Czechia, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eswatini,
Equatorial Guinea, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece,
Guatemala, Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait,
Laos, Lebanon, Liberia, Libya, Luxembourg, Madagascar, Malawi, Malaysia,
Malta, Mauritania, Mauritius, Mexico, Mongolia, Montenegro, Morocco, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua
New Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San
Marino, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden,
Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Yemen, Zambia
countries that have signed, but not yet ratified—(10) Algeria, Burkina-Faso,
Burundi, Cameroon, Ethiopia, Haiti, Mali, Paraguay, Portugal, Somalia Tropical
Timber, 2006
see International Tropical Timber Agreement, 2006
United Nations Convention on the Law of the Sea (LOS)
note—abbreviated as Law of the Sea
opened for signature—10 December 1982
entered into force—16 November 1994
objective—to provide a comprehensive legal regime for the sea and oceans
parties—(167 and the Palestine Liberation Organization) Albania, Algeria,
Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium,
Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cameroon, Canada,
Chad, Chile, China, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus,
Czechia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt,
Equatorial Guinea, Estonia, Eswatini, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea,
Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, North Macedonia,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Sweden, Switzerland, Tanzania, Thailand, Timor-Leste, Togo,
Tonga, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, Ukraine, UK, Uruguay,
Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization countries that have signed, but not yet ratified—(14) Afghanistan,
Bhutan, Burundi, Cambodia, Central African Republic, Colombia, El Salvador,
Ethiopia, Iran, North Korea, Libya, Liechtenstein, Rwanda, UAE
United Nations Convention to Combat Desertification in Those
Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa note—abbreviated as Desertification
opened for signature—14 October 1994
entered into force—26 December 1996
objective—to combat desertification and mitigate the effects of drought through
an integrated framework that is consistent with Agenda 21, employing
international cooperation and partnership arrangements, and effective action
at all levels parties—(196 and the Palestine Liberation Organization)
Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Cyprus, Czechia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, EU,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
North Macedonia, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanutu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization United Nations Framework Convention on
Climate Change
note—abbreviated as Climate Change
opened for signature—9 May 1992
entered into force—21 March 1994
objective—to achieve stabilization of greenhouse gas concentrations in the
atmosphere at a low enough level to prevent dangerous anthropogenic
interference with the climate system parties—(196 and the Palestine Liberation
Organization) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Eswatini, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, North Macedonia, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, South Sudan, Spain, Sri
Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar) Whaling
see International Convention for the Regulation of Whaling
REFERENCE MAPS
POLITICAL MAP OF AFRICA
55
Eye
North /
Atlantic
/
Ocean
Mediterranean Sea
|','d3ce0620cdd8046b8391a24db10db61fddb9319e20210fb16af0e522cce4f35c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4216d2346a4bab2236580de3649c2c312259c838dce1ae317eee8ceb396d45f',2021,'GU','Guam','communications',1061,'Organization for Democracy and Economic
Development; acronym for member states—
Georgia, Ukraine, Azerbaijan, Moldova
gross world product
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
HF
HIV/AIDS
IADB
IAEA
IANA
IBRD
ICAO
ICC
Icct
ICJ
ICRC
ICRM
ICSID
ICTR
ICTY
IDA
IDB
IDP
IEA
IFAD
IFC
IFRCS
IGAD
IHO
ILO
IMF
IMO
High-frequency
human immunodeficiency virus/acquired
immune deficiency syndrome
Inter-American Development Bank
International Atomic Energy Agency
Internet Assigned Numbers Authority
International Bank for Reconstruction and
Development (World Bank)
International Civil Aviation Organization
International Chamber of Commerce
International Criminal Court
International Court of Justice (World Court)
International Committee of the Red Cross
International Red Cross and Red Crescent
Movement
International Center for Settlement of
Investment Disputes
International Criminal Tribunal for Rwanda
International Criminal Tribunal for the former
Yugoslavia
International Development Association
Islamic Development Bank
Internally Displaced Person
International Energy Agency
International Fund for Agricultural
Development
International Finance Corporation
International Federation of Red Cross and Red
Crescent Societies
Inter-Governmental Authority on Development
International Hydrographic Organization
International Labor Organization
International Monetary Fund
International Maritime Organization
IMSO
In
Inmarsat
Inoc
Intelsat
Interpol
Intersputnik
10C
1IOM
IPU
ISO
ISP
ITC
ITSO
ITU
ITUC
kg
kHz
km
kW
kWh
LAES
LAIA
LAS
Law of the Sea
LDC
International Mobile Satellite Organization
inch
International Maritime Satellite Organization
Indian Ocean Commission
International Telecommunications Satellite
Organization
International Criminal Police Organization
International Organization of Space
International Olympic Committee
International Organization for Migration
Inter-Parliamentary Union
International Organization for Standardization
Internet Service Provider
International Trade Center
International Telecommunications Satellite
Organization
International Telecommunication Union
International Trade Union Confederation, the
successor to ICFTU (International
Confederation of Free Trade Unions) and the
WCL (World Confederation of Labor)
kilogram
kilohertz
kilometer
kilowatt
kilowatt-hour
Latin American and Caribbean Economic
System
Latin American Integration Association
League of Arab States
United Nations Convention on the Law of the
Sea (LOS)
less developed country
LLDC
LNG
London Convention
LOS
m
Marecs
Marine Dumping
Marine Life Conservation
MARPOL
Medarabtel
Mercosur
MFO
MICAH
MIGA
MINURCAT
MINURSO
MINUSCA
MINUSMA
MINUSTAH
mm
MONUSCO
mt
least developed country
liquefied natural gas
see Marine Dumping
see Law of the Sea
meter
Maritime European Communications Satellite
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other
Matter
Convention on Fishing and Conservation of
Living Resources of the High Seas
see Ship Pollution
Middle East Telecommunications Project of the
International Telecommunications Union
Southern Cone Common Market
Multinational Force & Observers— Sinai
megahertz
mile
International Civilian Support Mission in Haiti
Multilateral Investment Guarantee Agency
United Nations Mission in the Central African
Republic and Chad
United Nations Mission for the Referendum in','c59246e29d11760ecc540bb7921f2dca7de12a5a374bffc4959498233a1d8a7b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cc90baaf03dd5c6214c957caf4fd65a5ce9fced373c5c2007b95b36b5f5a156',2021,'NZ','New Zealand','communications',1062,'Organization of Arab Petroleum Exporting
Countries
Organization of American States
Organization of African Unity; see African
Union
official development assistance
Organization for Economic Cooperation and
Development
Organization of Eastern Caribbean States
Office of the United Nations High
Commissioner for Human Rights
Organization of the Islamic Conference
International Organization of the French-
OOF
OPANAL
OPCW
OPEC
OSCE
Ozone Layer Protection
PCA
PFP
PIF
PPP
Ramsar
RG
SAARC
SACEP
SACU
SADC
SAFE
Sco
SECI
SELEC
SHF
Ship Pollution
SICA
Sparteca
SPC
speaking World
other official flows
Agency for the Prohibition of Nuclear Weapons
in Latin America and the Caribbean
Organization for the Prohibition of Chemical
Weapons
Organization of Petroleum Exporting Countries
Organization for Security and Cooperation in
Europe
Montreal Protocol on Substances That Deplete
the Ozone Layer
Permanent Court of Arbitration
Partnership for Peace
Pacific Islands Forum
purchasing power parity
see Wetlands
Rio Group
South Asian
Cooperation
Association for Regional
South Asia Co-operative Environment Program
Southern African Customs Union
Southern African Development Community
South African Far East Cable
Shanghai Cooperation Organization
Southeast European Cooperative Initiative
Convention of the Southeast European Law
Enforcement Centers (successor to SECI)
Super-high-frequency
Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution
From Ships, 1973 (MARPOL)
Central American Integration System
South Pacific Regional Trade and Economic
Cooperation Agreement
Secretariat of the Pacific Communities
SPF
sq km
sq mi
TAT
TEU
Tropical Timber 83
Tropical Timber 94
UAE
UDEAC
UHF
UK
UN
UN-AIDS
UN-Habitat
UNAMA
UNAMID
UNASUR
UNCLOS
UNCTAD
UNDCP
UNDEF
UNDOF
UNDP
UNEP
UNESCO
UNFICYP
UNFPA
UNHCR
South Pacific Forum
square kilometer
square mile
Trans-Atlantic Telephone
Twenty-Foot Equivalent Unit, a unit of measure
for containerized cargo capacity
International Tropical Timber Agreement, 1983
International Tropical Timber Agreement, 1994','b7cfba504f339d6cf41fd070a844a196b91421e221a4eef9cb0994d0f5f47473','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('411baf4dc935538a1b230aedd8c6adbe439e1b2c154eaf0822768b957d3ad3bf',2021,'GB','United Kingdom','communications',1063,'United Nations
Joint United Nations Program on HIV/AIDS
United Nations Center for Human Settlements
United Nations Assistance Mission in','c4d91561e349754098910b8cf47bc9570d34c1575b32decd33571e3e56155564','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('359c480301269d2e8b523ff5865a12ddec9a05fa3ff9936846f9999fd1f5e4a0',2021,'AF','Afghanistan','communications',1064,'African Union/United Nations Hybrid
Operation in Darfur
Union of South American Nations
United Nations Convention on the Law of the
Sea, also known as LOS
United Nations Conference on Trade and
Development
United Nations Drug Control Program
United Nations Democracy Fund
United Nations Disengagement Observer Force
United Nations Development Program
United Nations Environment Program
United Nations Educational, Scientific, and
Cultural Organization
United Nations Peacekeeping Force in Cyprus
United Nations Population Fund
United Nations High Commissioner for
UNICEF
UNICRI
UNIDIR
UNIDO
UNIFIL
UNISFA
UNITAR
UNMIK
UNMIL
UNMIS
UNMISS
UNMIT
UNMOGIP
UNOCI
UNODC
UNOPS
UNRISD
UNRWA
UNSC
UNSOM
UNSSC
UNTSO
UNU
UNWTO
UPU
Refugees
United Nations Children’s Fund
United Nations Interregional Crime and Justice
Research Institute
United Nations Institute for Disarmament
Research
United Nations’ Industrial Development
Organization
United Nations Interim Force in Lebanon
United Nations Interim Force for Abyei
United Nations Institute for Training and
Research
United Nations Interim Administration Mission
in Kosovo
United Nations Mission in Liberia
United Nations Mission in the Sudan
United Nations Mission in South Sudan
United Nations Integrated Mission in Timor-
Leste
United Nations Military Observer Group in
India and Pakistan
United Nations Operation in Cote d’Ivoire
United Nations Office of Drugs and Crime
United Nations Office of Project Services
United Nations Research Institute for Social
Development
United Nations Relief and Works Agency for
Palestine Refugees in the Near East
United Nations Security Council
United Nations Assistance Mission in Somalia
United Nations System Staff College
United Nations Truce Supervision Organization
United Nations University
World Tourism Organization
Universal Postal Union
US
USSR
UTC
UV
VHF
VSAT
WADB
WAEMU
WCL
wco
Wetlands
WEU
WFP
WFTU
Whaling
WHO
WIPO
WMO
WP
WTO
ZC','c21bf7927a58070613f46eeb817b507b5fcebddedc16238446fa27eb3f2398b6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e582b3004ddc48d324785df027bb3005dd1666b2f336da363666e65f7d3afed2',2021,'TC','Turks and Caicos Islands','communications',1065,'other regional members—(4) Brazil, Colombia, Mexico, Venezuela (not entitled
to borrow funds from the bank)
nonregional members—(5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC)
see Economic and Monetary Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC)
note—acronym from Banque de Développement des Etats de 1’Afrique Centrale
established—3 December 1975
aim—to provide loans for economic development
members—(11) African Development Bank (AfDB), Cameroon, Central African
States Bank (BEAC), Central African Republic, Chad, Republic of the Congo,
Equatorial Guinea, France, Gabon, Kuwait, Libya
Central American Bank for Economic Integration (BCIE)
note—acronym from Banco Centroamericano de Integraci6n Econémico
established—13 December 1960 signature of Articles of Agreement; 31 May
1961 began operations
aim—to promote economic integration and development
members—(5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members—(8) Argentina, Belize, Colombia, Dominican Republic,
Mexico, Panama, Spain, Taiwan
Central American Common Market (CACM)
established—13 December 1960, collapsed in 1969, reinstated in 1991
aim—to promote establishment of a Central American Common Market
members—(5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
Central American Integration System (SICA)
established—13 December 1991; operational 1 February 1993
aim—to strengthen democracy; to set up a new model of regional security; to
promote freedom; to achieve a regional system of welfare and economic and
social justice; to attain economic unity and strengthen the area as an economic
bloc; to act as a bloc in international matters
members—(8) Belize, Costa Rica, Dominican Republic, El Salvador, Guatemala,
Honduras, Nicaragua, Panama
observers—(26) Argentina, Australia, Brazil, Chile, Colombia, Ecuador, EU,
France, Germany, Holy See, Italy, Japan, South Korea, Order of Malta, Mexico,
Morocco, New Zealand, Peru, Qatar, Serbia, Spain, Taiwan, Turkey, UK, US,','4f5e54a21f379d6c4f1c5faf59e7536a8dc6cb3a4dafb995f03550c02c755279','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('060362f72aee086842b370c4a55cd426289b9a86bc0f50f4e29ae676aa80ad34',2021,'UY','Uruguay','communications',1066,'Central European Initiative (CEI)
note—evolved from the Quadrilateral Initiative and the Hexagonal Initiative
established—11 November 1989 as the Quadrilateral Initiative, 27 July 1991
became the Hexagonal Initiative, July 1992 its present name was adopted
aim—to form an economic and political cooperation group for the region
between the Adriatic and the Baltic Seas
members—(18) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria,
Croatia, Czechia, Hungary, Italy, Moldova, Montenegro, North Macedonia,
Poland, Romania, Serbia, Slovakia, Slovenia, Ukraine
centrally planned economies
a term applied mainly to the traditionally communist states that looked to the
former USSR for leadership; most have now evolved toward more democratic
and market-oriented systems; also known formerly as the Second World or as
the communist countries; through the 1980s, this group included Albania,
Bulgaria, Cambodia, China, Cuba, Czechoslovakia, German Democratic
Republic, Hungary, North Korea, Laos, Mongolia, Poland, Romania, USSR,
Vietnam, Yugoslavia, but now is limited to Cuba and North Korea, and less so to
International Red Cross and Red Crescent Movement (ICRM)
established—1928
aim—to promote worldwide humanitarian aid through the International
Committee of the Red Cross (ICRC) in wartime, and International Federation of
Red Cross and Red Crescent Societies (IFRCS; formerly League of Red Cross
and Red Crescent Societies or LORCS) in peacetime
National Societies—(190 countries and the Palestine Liberation Organization);
note—same as membership for International Federation of Red Cross and Red
Crescent Societies (IFRCS)
International Telecommunication Satellite Organization (ITSO)
established—August 1964
aim—to act as a watchdog over Intelsat, Ltd., a private company, to make sure
it provides on a global and non-discriminatory basis public telecommunication
services
members—(149) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Burkina Faso, Cabo Verde, Cameroon, Canada, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czechia,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Estonia, Eswatini, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Holy See,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, the Federated States of
Micronesia, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal, Serbia, Singapore,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Uganda, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
International Telecommunication Union (ITU)
established—17 May 1865 set up as the International Telegraph Union; 9
December 1932 adopted present name; effective—1 January 1934; affiliated
with the UN—15 November 1947
aim—to deal with world telecommunications issues; a UN specialized agency
members—(193) includes all UN member countries except Palau (192 total);
plus Holy See
International Trade Union Confederation (ITUC)
note—its predecessors were the International Confederation of Free Trade
Unions (ICFTU) and the World Confederation of Labor (WCL)
established—3 November 2006
aim—to promote the trade union movement
members—(333 affiliated organizations in 164 countries or territories and the
Palestine Liberation Organization as of 2018) Albania, Algeria, Angola,
Andorra, Antigua and Barbuda, Armenia, Aruba, Argentina, Australia, Austria,
Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bermuda, Bhutan, Bolivia, Bonaire, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Curacao, Cyprus, Czechia,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Eritrea, Estonia, Eswatini, Ethiopia, Fiji, Finland, France, French Polynesia,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kosovo,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Maldives, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, New Caledonia, Monaco, NZ, Nicaragua,
Niger, Nigeria, North Macedonia, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand,
Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, and the Palestine Liberation
Organization
Islamic Development Bank (IDB)
established—15 December 1973 by declaration of intent; effective—12 August
1974
aim—to promote Islamic economic aid and social development
members—(56 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei, Burkina Faso,
Cameroon, Chad, Comoros, Cote d’Ivoire, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Guyana, Indonesia, Iran, Iraq, Jordan, Kazakhstan,
Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania,
Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia,
Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo,
Tunisia, Turkey, Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine
Liberation Organization
Latin American and Caribbean Economic System (LAES)
note—also known as Sistema Economico Latinoamericana (SELA)
established—17 October 1975
aim—to promote economic and _ social development through regional
cooperation
members—(26) Argentina, the Bahamas, Barbados, Belize, Bolivia, Brazil,
Chile, Colombia, Cuba, Dominican Republic, Ecuador, El Salvador, Guatemala,
Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Suriname, Trinidad and Tobago, Uruguay, Venezuela
Latin American Integration Association (LAIA)
note—also known as Asociacion Latinoamericana de Integracién (ALADI)
established—12 August 1980; effective—18 March 1981
aim—to promote freer regional trade
members—(13) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador,
Mexico, Panama, Paraguay, Peru, Uruguay, Venezuela
observers—(25) China, Costa Rica, Dominican Republic, EC, El Salvador,
Guatemala, Honduras, Inter-American AmericanDevelopment Development
Bank, Inter-American Institute for Cooperation on Agriculture, Italy, Japan,
South Korea, Latin America Economic System, Nicaragua, Organizacion
Panamericana de la Salud, Organization of American States, Panama, Portugal,
Romania, Russia, Spain, Switzerland, Ukraine, United Nations Development
Program, United Nations Economic Commission for Latin America and the
Caribbean
League of Arab States (LAS)
note—also known as Arab League (AL)
established—22 March 1945
aim—to promote economic, social, political, and military cooperation
members—(21 plus Palestine) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq,
Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Palestine, Qatar,
Saudi Arabia, Somalia, Sudan, Syria (Suspended), Tunisia, UAE, Yemen
observers—(5) Armenia, Brazil, Eritrea, India, Venezuela
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the
UN General Assembly in 1971 as having no significant economic growth, per
capita GDPs normally less than $1,000, and low literacy rates; also known as
the undeveloped countries; the 44 LLDCs are: Afghanistan, Bangladesh, Benin,
Bhutan, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Cote d’Ivoire,
Equatorial Guinea, Eritrea, Ethiopia, The Gambia, Ghana, Guinea, Guinea-
Bissau, Haiti, Kenya, Lesotho, Liberia, Malawi, Mali, Moldova, Mozambique,
Nepal, Niger, Rwanda, Sao Tome and Principe, Senegal, Sierra Leone, Somalia,
Sudan, Tajikistan, Tanzania, Togo, Tokelau, Tuvalu, Uganda, Zambia
less developed countries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries (LDCs);
mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000 and
often less than $1,500; however, the group also includes a number of countries
with high per capita incomes, areas of advanced technology, and rapid rates of
growth; includes the advanced developing countries, developing countries,
Four Dragons (Four Tigers), least developed countries (LLDCs), low-income
countries, middle-income countries, newly industrializing economies (NIEs),
the South, Third World, underdeveloped countries, undeveloped countries; the
172 LDCs are: Afghanistan, Algeria, American Samoa, Angola, Anguilla,
Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin
Islands, Brunei, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Cayman Islands, Central African Republic, Chad, Chile, China,
Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire,
Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French
Guiana, French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar,
Greenland, Grenada, Guadeloupe, Guam, Guatemala, Guernsey, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran,
Iraq, Isle of Man, Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar,
Malawi, Malaysia, Maldives, Mali, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands Antilles, New
Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Pitcairn Islands, Puerto Rico, Qatar, Reunion, Rwanda, Saint
Helena, Ascension, and Tristan da Cunha, Saint Kitts and Nevis, Saint Lucia,
Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Syria,
Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga, Trinidad and Tobago,
Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay, Vanuatu,
Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western
Sahara, Yemen, Zambia, Zimbabwe; note—similar to the new International
Monetary Fund (IMF) term “developing countries” which adds Malta, Mexico,
South Africa, and Turkey but omits in its recently published statistics American
Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas
Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French
Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada,
Guadeloupe, Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island,
Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint
Helena, Ascension, and Tristan da Cunha, Saint Pierre and Miquelon, Tokelau,
Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna,
West Bank, Western Sahara
low-income countries
another term for those less developed countries with below-average per capita
GDPs; see less developed countries (LDCs)
middle-income countries
another term for those less developed countries with above-average per capita
GDPs; see less developed countries (LDCs)
Multilateral Investment Guarantee Agency (MIGA)
established—12 April 1988
aim—encourages flow of foreign direct investment among member countries by
offering investment insurance, consultation, and negotiation on conditions for
foreign investment and technical assistance; a UN specialized agency
members—(181) includes all UN member countries except Andorra, Brunei,
Cuba, Kiribati, North Korea, Liechtenstein, Marshall Islands, Monaco, Nauru,
San Marino, Somalia, Tonga, Tuvalu; plus Kosovo, Holy See, and the Palestine
Liberation Organization Multinational Force & Observers the Multinational
Force & Observers ( MFO) has operated in the Sinai since 1982 as a
peacekeeping and monitoring force to supervise the implementation of the
security provisions of the 1979 Egyptian- Israeli Treaty of Peace; the MFO is an
independent international organization, created by agreement between the
Arab Republic of Egypt and the State of Israel; it is composed of 1,150 troops
from 13 countries (Australia, Canada, Colombia, the Czech Republic, the
Republic of the Fiji Islands, France, Italy, Japan, New Zealand, Norway, the
United Kingdom, the United States and Uruguay)
Near Abroad
Russian term for the 14 non-Russian successor states of the USSR, in which 25
million ethnic Russians live and in which Moscow has expressed a strong
national security interest; the 14 countries are Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
new independent states (NIS)
a term referring to all the countries of the FSU except the Baltic countries
(Estonia, Latvia, Lithuania)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing
economies (NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced
particularly rapid industrialization of their economies; formerly known as the
newly industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea,
Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM)
established—1-6 September 1961
aim—to establish political and military cooperation apart from the traditional
East or West blocs
members—(119 plus Palestinian Liberation Organization) Afghanistan, Algeria,
Angola, Antigua and Barbuda, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina
Faso, Burma, Burundi, Cabo Verde, Cambodia, Cameroon, Central African
Republic, Chad, Chile, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Fiji,
Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan,
Palestine, Panama, Papua New Guinea, Peru, Philippines, Qatar, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Somalia,
South Africa, Sri Lanka, Sudan, Suriname, Syria, Tanzania, Thailand, Timor-
Leste, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
observers—(17) Argentina, Armenia, Bosnia and Herzegovina, Brazil, China,
Costa Rica, Croatia, El Salvador, Kazakhstan, Kyrgyzstan, Mexico, Montenegro,
Paraguay, Serbia, Tajikistan, Ukraine, Uruguay
Nordic Council (NC)
established—16 March 1952; effective—12 February 1953
aim—to promote regional economic, cultural, and environmental cooperation
members—(5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
observers—(6) Estonia, Latvia, Lithuania, and the Sami (Lapp) local
parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
established—4 December 1975; effective—1 June 1976
aim—to promote economic cooperation and development
members—(8) Denmark (including Faroe Islands and Greenland), Estonia,
Finland (including Aland Islands), Iceland, Latvia, Lithuania, Norway, Sweden
North
a popular term for the rich industrialized countries generally located in the
northern portion of the Northern Hemisphere; the counterpart of the South;
see developed countries (DCs)
North American Free Trade Agreement (NAFTA)
established—17 December 1992
aim—to eliminate trade barriers, promote fair competition, increase investment
opportunities, provide protection of intellectual property rights, and create
procedures to settle disputes
members—(3) Canada, Mexico, US
North Atlantic Treaty Organization (NATO)
established—4 April 1949
aim—to promote mutual defense and cooperation
members—(29) Albania, Belgium, Bulgaria, Canada, Croatia, Czechia,
Denmark, Estonia, France, Germany, Greece, Hungary, Iceland, Italy, Latvia,
Lithuania, Luxembourg, Montenegro, Netherlands, Norway, Poland, Portugal,
Romania, Slovakia, Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA)
note—also known as OECD Nuclear Energy Agency
established—1 February 1958
aim—to promote the peaceful uses of nuclear energy; associated with OECD
members— (33) Argentina, Australia, Austria, Belgium, Canada, Czechia,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Turkey, UK, US
Nuclear Suppliers Group (NSG)
note—also known as the London Suppliers Group or the London Group
established—1974; effective—1975
aim—to establish guidelines for exports of nuclear materials, processing
equipment for uranium enrichment, and technical information to countries of
proliferation concern and regions of conflict and instability
members—(48) Argentina, Australia, Austria, Belarus, Belgium, Brazil,
Bulgaria, Canada, China, Croatia, Cyprus, Czechia, Denmark, Estonia, Finland,
France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Kazakhstan,
South Korea, Latvia, Lithuania, Luxembourg, Malta, Mexico, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia, South
Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observer—(2) Chairman of the Zangger Committee, European Commission (a
policy-planning body for the EU)
Organisation for Economic Cooperation and Development ( OECD)
established—14 December 1960;
effective— 30 September 1961
aim—to promote economic cooperation and development
members—(36) Australia, Austria, Belgium, Canada, Chile, Czechia, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Israel,
Italy, Japan, South Korea, Latvia, Lithuania, Luxembourg, Mexico, Netherlands,
NZ, Norway, Poland, Portugal, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Turkey, UK, US
special member—(1) EC
Organization for Democracy and Economic Development (GUAM)
note—acronym standing for the member countries, Georgia, Ukraine,
Azerbaijan, Moldova; formerly known as GUUAM before Uzbekistan withdrew
in 5 May 2005
established—7 June 2001
aim—commits the countries to cooperation and assistance in social and
economic development, the strengthening and broadening of trade and
economic relations, and the development and effective use of transport and
communications, highways, and related infrastructure crossing the boundaries
of the member states
members—(4) Azerbaijan, Georgia, Moldova, Ukraine
Organization for Security and Cooperation in Europe (OSCE)
note—formerly the Conference on Security and Cooperation in Europe (CSCE)
established 3 July 1975
established—1 January 1995
aim—to foster the implementation of human rights, fundamental freedoms,
democracy, and the rule of law; to act as an instrument of early warning,
conflict prevention, and crisis management; and to serve as a framework for
conventional arms control and confidence building measures
members—(57) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czechia,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Holy See,
Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein,
Lithuania, Luxembourg, Malta, Moldova, Monaco, Mongolia, Montenegro,
Netherlands, North Macedonia, Norway, Poland, Portugal, Romania, Russia,
San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
partners for cooperation—(11) Afghanistan, Algeria, Australia, Egypt, Israel,
Japan, Jordan, South Korea, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW)
established—29 April 1997
aim—to enforce the Convention on the Prohibition of the Development,
Production, Stockpiling, and Use of Chemical Weapons and on Their
Destruction; to provide a forum for consultation and cooperation among the
signatories of the Convention
members (countries that have ratified the Convention)—(192) Afghanistan,
Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde,
Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czechia,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Mad','b74878bfdb04721b00afeb8f850b86f77d1f483029c57f57a60fae50b478c1f1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8efcce68f4699762ab61d9a57ce42f5e3e3596038e284ac7cef7af2ec9e22285',2021,'UY','Uruguay','communications',1067,'agascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, North Macedonia, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, and the Palestine
Liberation Organization
signatory states (countries that have signed, but not ratified, the Convention)—
(1) Israel
Organization of African Unity (OAU)
see African Union
Organization of American States (OAS)
established—14 April 1890 as the International Union of American Republics;
30 April 1948 adopted present charter; effective—13 December 1951
aim—to promote regional peace and security as well as economic and social
development
members—(35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba (suspended),
Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala,
Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers—(70) Albania, Algeria, Angola, Armenia, Austria, Azerbaijan,
Belgium, Benin, Bosnia and Herzegovina, Bulgaria, China, Croatia, Cyprus,
Czechia, Denmark, Egypt, Equatorial Guinea, Estonia, EU, Finland, France,
Georgia, Germany, Ghana, Greece, Holy See, Hungary, Iceland, India, Ireland,
Israel, Italy, Japan, Kazakhstan, South Korea, Latvia, Lebanon, Liechtenstein,
Lithuania, Luxembourg, Malta, Monaco, Montenegro, Morocco, Netherlands,
Nigeria, North Macedonia, Norway, Pakistan, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Saudi Arabia, Serbia, Slovakia, Slovenia, Spain, Sri
Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, Vanuatu,','08bfb33bb85fbca0d5847040edb654d120c3c4fcc841f9f9c73270b515f740df','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19969f49a6b5d98ef3531941c320e9cbf62187fedc20444ed0f0f16ddbd452ef',2021,'UZ','Uzbekistan','communications',1068,'Colombo Plan (CP)
established—May 1950 proposal was adopted; 1 July 1951 commenced full
operations
aim—to promote economic and social development in Asia and the Pacific
members—(27) Afghanistan, Australia, Bangladesh, Bhutan, Brunei, Burma,
Fiji, India, Indonesia, Iran, Japan, South Korea, Laos, Malaysia, Maldives,
Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Saudi Arabia,
Singapore, Sri Lanka, Thailand, US, Vietnam
Common Market for Eastern and Southern Africa (COMESA)
note—formerly known as Preferential Trade Area for Eastern and Southern
Africa (PTA)
established—treaty signed 5 November 1993; treaty ratified 8 December 1994
aim—recognizing, promoting and protecting fundamental human rights,
commitment to the principles of liberty and rule of law, maintaining peace and
stability through the promotion and strengthening of good neighborliness,
commitment to peaceful settlement of disputes among member states
members—(19) Burundi, Comoros, Democratic Republic of the Congo, Djibouti,
Egypt, Eritrea, Eswatini, Ethiopia, Kenya, Libya, Madagascar, Malawi,
Mauritius, Rwanda, Seychelles, Sudan, Uganda, Zambia, Zimbabwe
Commonwealth (C)
note—also known as Commonwealth of Nations
established—31 December 1931
aim—to foster multinational cooperation and assistance, as a voluntary
association that evolved from the British Empire
members—(53) Antigua and Barbuda, Australia, The Bahamas, Bangladesh,
Barbados, Belize, Botswana, Brunei, Cameroon, Canada, Cyprus, Dominica,
Eswatini, Fiji (suspended), the Gambia, Ghana, Grenada, Guyana, India,
Jamaica, Kenya, Kiribati, Lesotho, Malawi, Malaysia, Malta, Mauritius,
Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (reinstated 2004), Papua
New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon Islands,
South Africa, Sri Lanka, Tanzania, Tonga, Trinidad and Tobago, Tuvalu,
Uganda, UK, Vanuatu, Zambia; note—on 7 December 2003 Zimbabwe withdrew
its membership from the Commonwealth
Commonwealth of Independent States (CIS)
established—8 December 1991; effective—21 December 1991
aim—to coordinate intercommonwealth relations and to provide a mechanism
for the orderly dissolution of the USSR
members—(9) Armenia, Azerbaijan, Belarus, Kazakhstan, Kyrgyzstan, Moldova,
Russia, Tajikistan, Uzbekistan associate member—(1) Turkmenistan; note—
Georgia left the organization in August 2009; Ukraine has not formally
withdrawn from the organization, but did formally end its participation in CIS
statutory bodies in May 2018
communist countries
traditionally the Marxist-Leninist states with authoritarian governments and
command economies based on the Soviet model; most of the original and the
successor states are no longer communist; see centrally planned economies
Community of Democracies (CD)
established—27 June 2000
aim—“to respect and uphold core democratic principles and _ practices”
including free and fair elections, freedom of speech and expression, equal
access to education, rule of law, and freedom of peaceful assembly
signatories of the Warsaw Declaration—(110) Albania, Algeria, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Cabo Verde, Canada, Chile, Colombia, Costa Rica, Croatia, Cyprus, Czechia,
Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia,
Finland, Georgia, Germany, Greece, Guatemala, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Japan, Jordan, Kenya,
South Korea, Kuwait, Latvia, Lesotho, Liechtenstein, Lithuania, Luxembourg,
Madagascar, Malawi, Mali, Malta, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, North Macedonia, Norway, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saint Lucia, Sao Tome and Principe, Senegal, Seychelles, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Tanzania,
Thailand, Tunisia, Turkey, Ukraine, UK, US, Uruguay, Venezuela, Yemen,
Yugoslavia
Community of Latin American and Caribbean States (CELAC)
note—successor to the Rio Group and the Latin America and Caribbean Summit
on Integration and Development
established—created 23 February 2010; established July 2011
aim—to deepen the integration within Latin American and to reduce the
influence of the US in the politics and economics of that part of the world
members—(33) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras,
Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, St. Kitts and Nevis, St.
Lucia, St. Vincent and the Grenadines, Suriname, Trinidad and Tobago,
Uruguay, Venezuela
Comuinidade dos Paises de Lingua Portuguesa (CPLP)
established—1996
aim—to establish a forum for friendship among Portuguese-speaking nations
where Portuguese is an official language
members—(9) Angola, Brazil, Cabo Verde, Equatorial Guinea, Guinea-Bissau,
Mozambique, Portugal, Sao Tome and Principe, Timor-Leste
associate observers—(10) Czechia, Georgia, Hungary, Japan, Mauritius,
Namibia, Senegal, Slovakia, Turkey, Uruguay
Conference of Interaction and Confidence-Building Measures in Asia
(CICA)
established—proposed 5 October 1992; established 14 September 1999
aim—promoting a multi-national forum for enhancing cooperation towards
promoting peace, security, and stability in Asia
members—(25 and the Palestine Liberation Organization) Afghanistan,
Azerbaijan, Bahrain, Bangladesh, Cambodia, China, Egypt, India, Iraq, Iran,
Israel, Jordan, Kazakhstan, Kyrgyzstan, Mongolia, Pakistan, Qatar, South Korea,
Russia, Tajikistan, Thailand, Turkey, UAE, Uzbekistan, Vietnam, and the
Palestine Liberation Organization
observers—(14) Belarus, Indonesia, International Organization for Migration,
Japan, Laos, League of Arab States, Malaysia, OSCE, Parliamentary Assembly
of the Turkic Speaking Countries, Philippines, Sri Lanka, Ukraine, UN, US
Convention of the Southeast European Law Enforcement Center
(SELEC)
note—successor to Southeast European Cooperative Initiative (SECI) formed in
1996 to help the Southeast European countries rebuild and stabilize through
access to resources
established—7 October 2011
aim—to provide support for Member States and enhance coordination in
preventing and combating crime in trans-border activity
members—(13) Albania, Bosnia and Herzegovina, Bulgaria, Croatia, Greece,
Hungary, Moldova, Montenegro, North Macedonia, Romania, Serbia, Slovenia,
Turkey
operational partners—(2) Italy, US
observers—(15) Austria, Belarus, Belgium, Czechia, France, Georgia, Germany,
Israel, Japan, The Netherlands, Slovakia, Spain, Switzerland, Ukraine, UK
Coordinating Committee on Export Controls (COCOM)
established control the export of strategic products and technical data from
member countries to proscribed destinations; members were: Australia,
Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan,
Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US; abolished
31 March 1994; COCOM members established a new organization, the
Wassenaar Arrangement, with expanded membership on 12 July 1996 that
focuses on nonproliferation export controls as opposed to East-West control of
advanced technology
Council for Mutual Economic Assistance (CEMA)
note—also known as CMEA or Comecon, was established on 25 January 1949
and abolished 1 January 1991; its aim was to promote the development of
socialist economies; there were 10 full members’ Bulgaria, Cuba,
Czechoslovakia, East Germany, Hungary, Mongolia, Poland, Romania, Soviet
Union, Vietnam—one associate member—Yugoslavia—Afghanistan, Angola,
China, Ethiopia, Finland, Iraq, North Korea, Laos, Mexico, Mozambique,
Nicaragua, South Yemen
note—East Germany withdrew from CEMA in 1990
Council of Arab Economic Unity (CAEU)
established—3 June 1957; effective—30 May 1964
aim—to promote economic integration among Arab nations
members—(17 plus Palestine) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Morocco, Oman, Palestine, Qatar, Saudi Arabia, Sudan, Syria,
Tunisia, UAE, Yemen
candidates—(4) Comoros, Djibouti, Mauritania, Somalia
Council of Europe (CE)
established—5 May 1949; effective—3 August 1949
aim—to promote increased unity and quality of life in Europe
members—(47) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium,
Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czechia, Denmark, Estonia,
Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Luxembourg, Malta, Moldova, Monaco,
Montenegro, Netherlands, North Macedonia, Norway, Poland, Portugal,
Romania, Russia, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK
observers—(6) Canada, Holy See, Israel, Japan, Mexico, US
Council of the Baltic Sea States (CBSS)
established—6 March 1992
aim—to promote cooperation among the Baltic Sea states in the areas of aid to
new democratic institutions, economic development, humanitarian aid, energy
and the environment, cultural programs and education, and transportation and
communication
members—(12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia,
Lithuania, Norway, Poland, Russia, Sweden
observers—(13) Belarus, France, Ireland, Italy, Netherlands, Norway, Romania,
Slovakia, Spain, Turkey, Ukraine, UK, US
Council of the Entente (Entente)
established—29 May 1959
aim—to promote economic, social, and political coordination
members—(5) Benin, Burkina Faso, Cote d’Ivoire, Niger, Togo
countries in transition
a term used by the International Monetary Fund (IMF) for the middle group in
its hierarchy of formerly centrally planned economies; IMF statistics include
the following 29 countries in transition: Albania, Armenia, Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria, Croatia, Czechia, Estonia, Georgia,
Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Mongolia,
Montenegro, North Macedonia, Poland, Romania, Russia, Serbia, Slovakia,
Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note—this group is
identical to the group traditionally referred to as the “former USSR/Eastern
Europe” except for the addition of Mongolia
Customs Cooperation Council (CCC)
note—see World Customs Organization (WCO)
developed countries (DCs)
the top group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries (LDCs);
includes the market-oriented economies of the mainly democratic nations in the
Organization for Economic Cooperation and Development (OECD), Bermuda,
Israel, South Africa, and the European ministates; also known as the First
World, high- income countries, the North, industrial countries; generally have a
per capita GDP in excess of $15,000 although four OECD countries and South
Africa have figures well under $15,000 and eight of the excluded OPEC
countries have figures of more than $20,000; the DCs include: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands,
Finland, France, Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy,
Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ, Norway,
Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK,
US; note—similar to the International Monetary Fund (IMF) term “advanced
economies” that adds Hong Kong, South Korea, Singapore, and Taiwan but
drops Malta, Mexico, South Africa, and Turkey
developing countries
a term used by the International Monetary Fund (IMF) for the bottom group in
its hierarchy of advanced economies, countries in transition, and developing
countries; IMF statistics include the following 126 developing countries:
Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, The
Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cabo Verde,
Cameroon, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eswatini, Ethiopia, Fiji, Gabon, The Gambia,
Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
India, Indonesia, Iran, Irag, Jamaica, Jordan, Kenya, Kiribati, Kuwait, Laos,
Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Morocco, Mozambique, Namibia, Nepal, Netherlands Antilles,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South
Africa, Sri Lanka, Sudan, Suriname, Syria, Tanzania, Thailand, Togo, Trinidad
and Tobago, Tunisia, Turkey, UAE, Uganda, Uruguay, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe; note—this category would presumably
also cover the following 46 other countries that are traditionally included in the
more comprehensive group of “less developed countries”: American Samoa,
Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas Island,
Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana,
French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau, Martinique,
Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern
Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena,
Ascension, and Tristan da Cunha, Saint Pierre and Miquelon, Tokelau, Tonga,
Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank,
European Central Bank (ECB)
established—1 June 1998
aim—to administer the monetary policy of the EU Eurozone member states
Furozone members—(19) Austria, Belgium, Cyprus, Estonia, Finland, France,
Germany, Greece, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta,
Netherlands, Portugal, Slovakia, Slovenia, Spain
non-Eurozone members—(10) Bulgaria, Croatia, Czechia, Denmark, Hungary,
Lithuania, Poland, Romania, Sweden
European Community (or European Communities, EC)
established 8 April 1965 to integrate the European Atomic Energy Community
(Euratom), the European Coal and Steel Community (ECSC), the European
Economic Community (EEC or Common Market), and to establish a completely
integrated common market and an eventual federation of Europe; merged into
the European Union (EU) on 7 February 1992; member states at the time of
merger were Belgium, Denmark, France, Germany, Greece, Ireland, Italy,
Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
established—A January 1960; effective—3 May 1960
aim—to promote expansion of free trade
members—(A4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB)
established—25 March 1957; effective—1 January 1958
aim—to promote economic development of the EU and its predecessors, the
EEC and the EC
members—(28) Austria, Belgium, Bulgaria, Croatia, Cyprus, Czechia, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia,
Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania,
Slovakia, Slovenia, Spain, Sweden, UK
European Organization for Nuclear Research (CERN)
note—acronym retained from the predecessor organization Conseil Européen
pour la Recherche Nucléaire
established—1 July 1953; effective—29 September 1954
aim—to foster nuclear research for peaceful purposes only
members—(22) Austria, Belgium, Bulgaria, Czechia, Denmark, Finland, France,
Germany, Greece, Hungary, Israel, Italy, Netherlands, Norway, Poland,
Portugal, Romania, Slovakia, Spain, Sweden, Switzerland, UK
associate members—(5) India, Lithuania, Pakistan, Turkey, Ukraine
observers—(5) EC, Japan, Russia, United Nations Educational, Scientific, and
Cultural Organization (UNESCO), US
European Space Agency (ESA)
established—31 May 1975
aim—to promote peaceful cooperation in space research and technology
members—(22) Austria, Belgium, Czechia, Denmark, Estonia, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Luxembourg, Netherlands, Norway,
Poland, Portugal, Romania, Spain, Sweden, Switzerland, UK
associate member—(1) Slovenia
cooperating states—(8) Bulgaria, Canada, Croatia, Cyprus, Latvia, Lithuania,
Malta, Slovakia
European Union (EU)
note—see European Union entry at the end of the “country” listings
Extractive Industry Transparency Initiative (EITI)
established—October 2002 Initiative announced; June 2003 first EITC Plenary
Conference
aim—to set a global standard for transparency in the extractive industries in an
effort to make natural resources benefit all
stake holders or implementing countries—(17) Australia, Belgium, Canada,
Denmark, Finland, France, Germany, Italy, Japan, Netherlands, Norway, Qatar,
Spain, Sweden, Switzerland, UK, US
compliant countries—(31) Albania, Burkina Faso, Cameroon, Central African
Republic (suspended), Chad, Cote d’Ivoire, Democratic Republic of the Congo,
Republic of the Congo, Ghana, Guatemala, Guinea, Indonesia, Iraq, Kazakhstan,
Kyrgyzstan, Liberia, Mali, Mauritania, Mongolia, Mozambique, Niger, Nigeria,
Norway, Peru, Sierra Leone, Tanzania, Timor-Leste, Togo, Trinidad and Tobago,
Yemen (suspended), Zambia
candidate countries—(20) Afghanistan, Azerbaijan, Burma, Colombia,
Dominican Republic, Ethiopia, Germany, Honduras, Madagascar, Malawi,
Papua New Guinea, Philippines, Sao Tome and Principe, Senegal, Seychelles,
Solomon Islands, Tajikistan, Ukraine, UK, US
Financial Action Task Force (FATF)
established—by G-7 Summit in Paris in 1989
aim—to develop and promote policies to combat money laundering and
terrorist financing
members—(37) Argentina, Australia, Austria, Belgium, Brazil, Canada, China,
Denmark, EC, Finland, France, Germany, Greece, Gulf Cooperation Council,
Hong Kong, Iceland, India, Ireland, Italy, Japan, South Korea, Luxembourg,
Malaysia, Mexico, Netherlands (Aruba, Curacao, Sint Maarten), NZ, Norway,
Portugal, Russia, Singapore, South Africa, Spain, Sweden, Switzerland, Turkey,
UK, US
First World
another term for countries with advanced, industrialized economies; this term
is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO)
established—16 October 1945
aim—to raise living standards and increase availability of agricultural products;
a UN specialized agency
members—(195) includes all UN member countries except Liechtenstein; plus
Cook Islands, EU, and Niue
associate members—(2) Faroe Islands, Tokelau
former Soviet Union (FSU)
former term often used to identify as a group the successor nations to the
Soviet Union or USSR; this group of 15 countries consists of: Armenia,
Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries (LDCs);
these countries are in political and economic transition and may well be
grouped differently in the near future; this group of 29 countries consists of:
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria,
Croatia, Czechia, Estonia, Georgia, Hungary, Kazakhstan, Kosovo, Kyrgyzstan,
Latvia, Lithuania, Moldova, Montenegro, North Macedonia, Poland, Romania,
Russia, Serbia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; this group is identical to the IMF group “countries in transition”
except for the IMF’s inclusion of Mongolia
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced
unusually rapid economic growth; also known as the Four Tigers; this group
consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are
included in the IMF’s “advanced economies” group
Franc Zone (FZ)
note—also known as Conference des Ministres des Finances des Pays de la
Zone Franc
established—1964
aim—to form a monetary union among countries whose currencies were linked
to the French franc
members—(16) Benin, Burkina Faso, Cameroon, Central African Republic,
Chad, Comoros, Republic of the Congo, Cote d’Ivoire, Equatorial Guinea,
France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of
existence; members included Angola, Botswana, Mozambique, Namibia,
Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT)
see the World Trade Organization (WTO)
General Confederation of Trade Unions (GCTU)
established—16 April 1992
aim—to consolidate trade union actions to protect citizens’ social and labor
rights and interests, to help secure trade unions’ rights and guarantees, and to
strengthen international trade union solidarity
members—(10) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan,
Moldova, Russia, Tajikistan, Ukraine
Group of 10 (G-10)
note—also known as the Paris Club; includes the wealthiest members of the
IMF who provide most of the money to be loaned and act as the informal
steering committee; name persists despite increased membership
established—October 1962
aim—to coordinate credit policy
members—(11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands,
Sweden, Switzerland, UK, US
observers—(4) BIS, EC, IMF, OECD
Group of 11 (G-11)
established—2006
aim—to narrow the income gap with the world’s richest nations
members—(11) Croatia, Ecuador, El Salvador, Georgia, Honduras, Indonesia,
Jordan, Morocco, Pakistan, Paraguay, Sri Lanka
Group of 15 (G-15)
note—byproduct of the Nonaligned Movement; name persists despite increased
membership
established—September 1989
aim—to promote economic cooperation among developing nations; to act as the
main political organ for the Nonaligned Movement
members—(17) Algeria, Argentina, Brazil, Chile, Egypt, India, Indonesia, Iran,
Jamaica, Kenya, Malaysia, Mexico, Nigeria, Senegal, Sri Lanka, Venezuela,','32249c2774acb5ec71ee3bb9e5efec981b2e4bef6e06a92cf5786be0c4285d9a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a85b2ed9f8405a35525e7fc8c991f5df22d1cb03205cacd43680d7c37fa4b3d1',2021,'SC','Seychelles','communications',1069,'industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (IADB)
note—also known as Banco Interamericano de Desarrollo (BID)
established—8 April 1959; effective—30 December 1959
aim—to promote economic and social development in Latin America
members—(48) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize,
Bolivia, Brazil, Canada, Chile, China, Colombia, Costa Rica, Croatia, Denmark,
Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan, South Korea,
Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru, Portugal,
Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US,
Uruguay, Venezuela
Inter-Governmental Authority on Development (IGAD)
note—formerly known as Inter-Governmental Authority on Drought and
Development (IGADD)
established—15-16 January 1986 as the Inter-Governmental Authority on
Drought and Development; revitalized—21 March 1996 as the _ Inter-
Governmental Authority on Development
aim—to promote a social, economic, and scientific community among its
members
members—(7) Djibouti, Ethiopia, Kenya, Somalia, South Sudan, Sudan, Uganda
partners—(34) African Development Bank, Australia, Austria, Belgium, Brazil,
Canada, China, Czechia, Denmark, EC, Finland, FAO, France, Germany, Greece,
India, Ireland, Italy, Japan, LAS, Luxembourg, Netherlands, New Zealand,
Norway, Russia, Spain, Sweden, Switzerland, Turkey, UK, UN Development
Program, US, World Bank, World Food Program
Inter-Parliamentary Union (IPU)
established—1889
aim—fosters contacts among parliamentarians, considers and expresses views
of international interest and concern with the purpose of bringing about action
by parliaments and parliamentarians, contributes to the defense and promotion
of human rights, contributes to better knowledge of representative institutions
members—(172 and Palestine) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh,
Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cabo Verde,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti, Dominican
Republic, Ecuador, El Salvador, Equatorial Guinea, Estonia, Eswatini, Ethiopia,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, North
Macedonia, Norway, Oman, Pakistan, Palau, Palestine, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tanzania, Tajikistan, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members—(11) Andean Parliament, Central American Parliament,
East African Legislative Assembly, European Parliament, Interparliamentary
Assembly of Member States of the Commonwealth of Independent States, Inter-
Parliamentary Committee of the West African Economic and Monetary Union,
Latin American Parliament, Parliament of the Economic Community of West
African States, Parliament of the Economic and Monetary Community of
Central Africa, Parliamentary Assembly of the Council of Europe
International Atomic Energy Agency (IAEA)
established—26 October 1956; effective—29 July 1957
aim—to promote peaceful uses of atomic energy
members—(66) Afghanistan, Albania, Algeria, Angola, Antiqua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia,
Eswatini, Ethiopia, Fiji, Finland, France, Gabon, Georgia, Germany, Ghana,
Greece, Guatemala, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar,
Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, North
Macedonia, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
San Marino, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
note—Cabo Verde, Comoros, the Gambia, Saint Lucia, and Tongo need to
deposit the necessary legal instruments with the IAEA
International Bank for Reconstruction and Development (IBRD)
note—also known as the World Bank
established—22 July 1944; effective—27 December 1945
aim—to provide economic development loans; a UN specialized agency
members—(189) includes all UN member countries except Andorra, Cuba,
North Korea, Liechtenstein, Monaco; plus Kosovo
International Chamber of Commerce (ICC)
establish—1919
aim—to promote free trade and private enterprise and to represent business
interests at national and international levels
members—128 plus Palestine
countries with national committees—(96 and the Palestine Liberation
Organization) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia,
Austria, Bahrain, Bangladesh, Belgium, Bolivia, Brazil, Bulgaria, Burkina Faso,
Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus,
Czechia, Denmark, Dominican Republic, Ecuador, Egypt, Estonia, Finland,
France, Georgia, Germany, Ghana, Greece, Guatemala, Hong Kong, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, South Korea,
Kuwait, Lebanon, Lithuania, Luxembourg, Macao, Malaysia, Mexico, Monaco,
Morocco, Netherlands, NZ, Nigeria, North Macedonia, Norway, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saudi Arabia, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sweden, Switzerland, Syria, Taiwan, Thailand, Tunisia, Turkey, Ukraine,
UAE, UK, US, Uruguay, Venezuela, Palestine Liberation Organization
countries with no national committees having direct members—(45)
Afghanistan, Andorra, Armenia, Azerbaijan, The Bahamas, Belarus, Bermuda,
Bosnia and Herzegovina, Botswana, Burma, Democratic Republic of the Congo,
Cote d’Ivoire, Eritrea, Ethiopia, Gibraltar, Haiti, Honduras, Hungary, Iraq,
Jamaica, Kazakhstan, North Korea, Latvia, Liberia, Malta, Mauritania,
Mauritius, Moldova, Mongolia, Montenegro, Mozambique, Nepal, Oman, Peru,
Seychelles, Sudan, Tajikistan, Tanzania, Turkey, Uganda, Vietnam
International Civil Aviation Organization (ICAO)
established—7 December 1944; effective—4 April 1947
aim—to promote international cooperation in civil aviation; a UN specialized
agency
members—(192) includes all UN member countries except Dominica, and
Liechtenstein (191 total); plus Cook Islands
International Civilian Support Mission in Haiti (MICAH)
established 17 December 1999 to promote respect for human rights; members
included Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo,
Tunisia, US; closed 2001
International Committee of the Red Cross (ICRC)
established—17 February 1863
aim—to provide humanitarian aid in wartime
members—(15-25 members of the Assembly Council) all Swiss nationals
International Court of Justice (ICJ)
also known as the World Court; primary judicial organ of the UN
established—26 June 1945 with the signing of the UN Charter (inaugural
sitting of the Court was on 18 April 1946); superseded Permanent Court of
International Justice (attached to the League of Nations)
aim—to settle disputes submitted by member states and to provide advice to
UN organs and other international agencies
members—(15 judges) elected by the UN General Assembly and Security
Council to represent all principal legal systems; judges elected to nine-year
terms (eligible for two additional terms); elections held every three years for
one-third of the judges
jurisdiction—based on the principle of consent in contentious issues; consent to
compulsory jurisdiction is outlined in Statute 36 of the ICJ; states provide
declarations of consent to compulsory jurisdiction of the ICJ either with or
without reservations (date in parens after each state is when the declaration
was deposited with the UN Secretary-General); Haiti, Luxembourg, Nicaragua,
and Uruguay deposited declarations with the Permanent Court of International
Justice prior to 1945 and these were later transferred to the ICJ)
states accepting compulsory jurisdiction with reservations—(61) Australia (22
March 2002), Barbados (1 August 1980), Belgium (17 June 1958), Botswana (16
March 1970), Bulgaria (21 June 1992), Cambodia (19 September 1957), Canada
(10 May 1994), Democratic Republic of the Congo (8 February 1989), Cote
d''Ivoire ( 29 September 2001), Cyprus (3 September 2002), Denmark (10
December 1956), Djibouti (2 September 2005), Egypt (22 July 1957), Estonia
(31 October 1991), Eswatini (26 May 1969), Finland (25 June 1958), The
Gambia (22 June 1966), Germany (30 April 2008), Greece (10 January 1994),
Guinea (4 December 1998), Honduras (6 June 1986), Hungary (22 October
1992), India (18 September 1974), Ireland (15 December 2011), Japan (9 July
2007), Italy (25 November 2014), Kenya (19 April 1965), Lesotho (6 September
2000), Liberia (20 March 1952), Liechtenstein (29 March 1950), Lithuania (26
September 2012), Madagascar (2 July 1992), Malawi (12 December 1966),
Malta (2 September 1983), Marshall Islands (23 April 2013), Mauritius (23
September 1968), Mexico (28 October 1947), Netherlands (1 August 1956),
New Zealand (23 September 1977), Nicaragua (24 September 1929), Nigeria
(30 April 1998), Norway (25 June 1996), Pakistan (13 September 1960),
Panama (25 October 1921), Peru (7 July 2003), Philippines (18 January 1972),
Poland (25 March 1996), Portugal (25 February 2005), Romania (23 June 2015),
Senegal (2 December 1985), Slovakia (28 May 2004), Somalia (11 April 1963),
Spain (20 October 1990), Sudan (2 January 1958), Suriname (31 August 1987),
Sweden (6 April 1957), Switzerland (28 July 1948), Timor-Leste (21 September
2012), Togo (25 October 1979), Uganda (3 October 1963), United Kingdom (5
July 2004)
states accepting compulsory jurisdiction without reservations—(12) Austria (19
May 1971), Cameroon (3 March 1994), Costa Rica (20 February 1973),
Dominica (31 March 2006), Dominican Republic (30 September 1924),
Equatorial Guinea (11 August 2017), Georgia (20 June 1995), Guinea-Bissau (7
August 1989), Haiti (4 October 1921), Luxembourg (15 September 1930),
Paraguay (25 September 1996), Uruguay (28 January 1921)
International Criminal Court (ICCt)
established—1 July 2002
aim—to hold all individuals and countries accountable to international laws of
conduct; to specify international standards of conduct; to provide an important
mechanism for implementing these standards; to ensure that perpetrators are
brought to justice
members—21 judges (three judges form the Presidency) and six judges each in
the Pre-trial, Trial, and Appeals Divisions; judges elected by secret ballot by the
Assembly of States Parties to the Rome Statute for nine-year terms (not eligible
for reelection) governed by the Statute of the International Criminal Court
treaty (or Rome Statute), adopted 17 July 1998 at the UN Conference of
Plenipotentiaries in Rome and entered into force 1 July 2002
states accepting jurisdiction—(123 with the Palestine Liberation Organization)
Afghanistan, Albania, Andorra, Antigua and Barbuda, Argentina, Australia,
Austria, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Cabo Verde, Cambodia,
Canada, Central African Republic, Chad, Chile, Colombia, Comoros, Cook
Islands, Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Czechia, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, El Salvador, Estonia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guyana, Honduras, Hungary, Iceland, Ireland, Italy, Japan, Jordan,
Kenya, South Korea, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania,
Luxembourg, Madagascar, Malawi, Maldives, Mali, Malta, Marshall Islands,
Mauritius, Mexico, Moldova, Mongolia, Montenegro, Namibia, Nauru,
Netherlands, NZ, Niger, Nigeria, North Macedonia, Norway, Panama, Paraguay,
Peru, Philippines, Poland, Portugal, Romania, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Serbia,
Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Suriname,
Sweden, Switzerland, Tajikistan, Tanzania, Timor-Leste, Trinidad and Tobago,
Tunisia, Uganda, UK, Uruguay, Vanuatu, Venezuela, Zambia, Palestine
Liberation Organization
International Criminal Police Organization (Interpol)
established—September 1923 set up as the International Criminal Police
Commission; 13 June 1956 constitution modified and present name adopted
aim—to promote international cooperation among police authorities in fighting
crime
members—(191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia, Cameroon, Canada,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Curacao, Cyprus, Czechia, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Eswatini, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, North Macedonia,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Sint Maarten, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus—(11) American Samoa, Anguilla, Bermuda, British Virgin Islands,
Cayman Islands, Gibraltar, Hong Kong, Macau, Montserrat, Puerto Rico, Turks
and Caicos Islands
International Development Association (IDA)
established—26 January 1960; effective—24 September 1960
aim—to provide economic loans for low-income countries; UN specialized
agency and IBRD affiliate
members—(180) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d’Ivoire, Croatia, Czechia, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Eswatini, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kosovo,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands,
Nicaragua, Niger, Nigeria, North Macedonia, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
West Bank and Gaza, Yemen, Zambia, Zimbabwe
International Energy Agency (IEA)
established—15 November 1974
aim—to promote cooperation on energy matters, especially emergency oil
sharing and relations between oil consumers and oil producers; established by
the OECD
members—(30) Australia, Austria, Belgium, Canada, Czechia, Denmark,
Estonia, EC, Estonia, Finland, France, Germany, Greece, Hungary, Ireland,
Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Poland,
Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies
(IFRCS)
note—formerly known as League of Red Cross and Red Crescent Societies
(LORCS)
established—5 May 1919
aim—to organize, coordinate, and direct international relief actions; to promote
humanitarian activities; to represent and encourage the development of
National Societies; to bring help to victims of armed conflicts, refugees, and
displaced people; to reduce the vulnerability of people through development
programs
members—(190 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czechia, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, North Macedonia, Norway, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
International Finance Corporation (IFC)
established—25 May 1955; effective—24 July 1956
aim—to support private enterprise in international economic development; a
UN specialized agency and IBRD affiliate
members—(184) includes all UN member countries except Andorra, Brunei,
Cuba, North Korea, Liechtenstein, Monaco, Nauru, Saint Vincent and the
Grenadines, San Marino, Tuvalu; plus Kosovo
International Fund for Agricultural Development (IFAD)
established—November 1974
aim—to promote agricultural development; a UN specialized agency
members—(176)
List A—(27 industrialized aid contributors) Austria, Belgium, Canada, Cyprus,
Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Iceland,
Ireland, Israel, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal,
Russia, Spain, Sweden, Switzerland, UK, US
List B—(12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia,
Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
List C—(137 aid recipients) Afghanistan, Albania, Angola, Antigua and
Barbuda, Argentina, Armenia, Azerbaijan, The Bahamas, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cabo Verde, Cambodia, Cameroon,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Fiji, The
Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, India, Jamaica, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia,
Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Nicaragua, Niger,
Niu','220393e969a6ac3521044e22eb4abccd2e4ef3a9db6d596628a82e3b811e840b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381fe57853df5787b17acc596c3f58b84c09d284f315534365787b934ef3c9e3',2021,'SC','Seychelles','communications',1070,'e, North Macedonia, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
South Sudan, Sri Lanka, Sudan, Suriname, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Tuvalu, Uganda, Uruguay, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia,','2a18c5b6dd6e28ca8d3ed3357360a555aafbd4332ebcee25bc4365453e6acd3b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('018dfef0f9276dd4b18bcc3d49590fdfe7f718621aeb91c26ba2ee72199a0db7',2021,'VC','Saint Vincent and the Grenadines','communications',1071,'Organization of Islamic Cooperation (OIC)
note—formerly the Organization of the Islamic Conference
established—22-25 September 1969
aim—to promote Islamic solidarity in economic, social, cultural, and political
affairs
members—(56 plus Palestine) Afghanistan, Albania, Algeria, Azerbaijan,
Bahrain, Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros,
Cote d''Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau,
Guyana, Indonesia, Iran, Irag, Jordan, Kazakhstan, Kuwait, Kyrgyzstan,
Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique,
Niger, Nigeria, Oman, Pakistan, Palestine, Qatar, Saudi Arabia, Senegal, Sierra
Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey,
Turkmenistan, Uganda, UAE, Uzbekistan, Yemen
observers—(12) AU, Bosnia and Herzegovina, Central African Republic, ECO,
LAS, Moro National Liberation Front, NAM, Parliamentary Union of the OIC
Member States, Russia, Thailand, Turkish Muslim Community of Kibris, UN
Organization of Petroleum Exporting Countries (OPEC)
established—14 September 1960
aim—to coordinate petroleum policies
members—(13) Algeria, Angola, Ecuador, Indonesia, Iran, Iraq, Kuwait, Libya,
Nigeria, Qatar, Saudi Arabia, UAE, Venezuela; note - Indonesia left OPEC in
2008 but returned on 1 January 2016
Pacific Alliance
established—28 April 2011
aim—to reduce trade barriers between member countries, to install visa-free
travel, to install a common stock exchange, and to set up joint embassies in
some countries
associate members—(4) Australia, Canada, New Zealand, Singapore observers
—(54) Argentina, Austria, Belarus, Belgium, Cambodia, China, Costa Rica,
Denmark, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Finland, France, Georgia, Germany, Greece, Guatemala, Haiti, Honduras,
Hungary, India, Indonesia, Israel, Italy, Japan, Laos, Lithuania, Morocco,
Netherlands, Norway, Panama, Paraguay, Poland, Portugal, Romania, Serbia,
Slovakia, Slovenia, South Korea, Spain, Sweden, Switzerland, Thailand,
Trinidad and Tobago, Turkey, Ukraine, UAE, UK, US, Uruguay
Pacific Community (SPC)
local name of the Secretariat of the Pacific Community
Pacific Islands Forum (PIF)
note—formerly known as South Pacific Forum (SPF)
established—5 August 1971
aim—to promote regional cooperation in political matters
members—(16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua New Guinea,
Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
associate members—(3) French Polynesia, New Caledonia, Tokelau
partners—(18) Canada, China, Cuba, EU, France, Germany, India, Indonesia,
Italy, Japan, South Korea, Malaysia, Philippines, Spain, Thailand, Turkey, UK,
US
observers—(12) ACP Group, American Samoa, Asia Development Bank, The
Commonwealth, Commonwealth of the Northern Marianas, Guam, international
Organization for Migration, Timor-Leste (special observer), UN, Wallis and
Futuna, Western and Central Pacific Fisheries Commission, the World Bank
Paris Club
established—1956
aim—to provide a forum for debtor countries to negotiate rescheduling of debt
service payments or loans extended by governments or official agencies of
participating countries; to help restore normal trade and project finance to
debtor countries
members—(22) Australia, Austria, Belgium, Brazil, Canada, Denmark, Finland,
France, Germany, Ireland, Israel, Italy, Japan, South Korea, Netherlands,
Norway, Russia, Spain, Sweden, Switzerland, UK, US
associate members—(11) Abu Dhabi, Argentina, China, Kuwait, Mexico,
Morocco, NZ, Portugal, South Africa, Trinidad and Tobago, Turkey
Partnership for Peace (PFP)
established—10-11 January 1994
aim—to expand and intensify political and military cooperation throughout
Europe, increase stability, diminish threats to peace, and build relationships by
promoting the spirit of practical cooperation and commitment to democratic
principles that underpin NATO; program under the auspices of NATO
members—(21) Armenia, Austria, Azerbaijan, Belarus, Bosnia and Herzegovina,
Finland, Georgia, Ireland, Kazakhstan, Kyrgyzstan, Malta, Moldova, North
Macedonia, Russia, Serbia, Sweden, Switzerland, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
note—a nation that becomes a member of NATO is no longer a member of PFP
Permanent Court of Arbitration (PCA)
established—29 July 1899
aim—to facilitate the settlement of international disputes
members—(121 and the Palestine Liberation Organization) Albania, Argentina,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium,
Belize, Benin, Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica,
Croatia, Cuba, Cyprus, Czechia, Denmark, Djibouti, Dominican Republic,
Ecuador, Egypt, El Salvador, Eritrea, Estonia, Eswatini, Ethiopia, Fiji, Finland,
France, Georgia, Germany, Greece, Guatemala, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, Kenya,
South Korea, Kosovo, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malaysia, Malta,
Mauritius, Mexico, Montenegro, Morocco, Netherlands, NZ, Nicaragua,
Nigeria, North Macedonia, Norway, Pakistan, Panama, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Thailand,
Togo, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Venezuela, Vietnam,
Zambia, Zimbabwe, Palestine Liberation Organization
Petrocaribe
established—29 June 2005
aim—to eliminate existing social inequities, to foster high standards of living, to
promote effective people’s participation in shaping their own destiny
members—(19) Antigua and Barbuda, The Bahamas, Belize, Cuba, Dominica,
Dominican Republic, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Nicaragua, St. Kitts and Nevis, St. Lucia, St. Vincent and
the Grenadines, Suriname, Venezuela
Rio Group (RG)
note—formerly known as Grupo de los Ocho, established NA December 1986;
composed of the Contadora Group and the Lima Group
established in 1988 to consult on regional Latin American issues; its members
were Argentina, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba,
Dominican Republic, Ecuador, El Salvador, Guatemala, Guyana, Haiti,
Honduras, Jamaica (representing CARICOM), Mexico, Nicaragua, Panama,
Paraguay, Peru, Uruguay, Venezuela; in 2010 joined with the Caribbean Summit
on Integration and Development (CALC) to form the Community of Latin
American and Caribbean States (CELAC)
Schengen Convention
established—signed June 1990; effective March 1995
aim—to allow free movement within an area without internal border controls
members—(26) Austria, Belgium, Czechia, Denmark, Estonia, Finland, France,
Germany, Greece, Hungary, Iceland, Italy, Latvia, Liechtenstein, Lithuania,
Luxembourg, Malta, Netherlands, Norway, Poland, Portugal, Slovakia, Slovenia,
Spain, Sweden, Switzerland
note—UK and Ireland have not joined; Cyprus will probably join in the near
future; Bulgaria and Romania are still not fully implemented
De Facto members—(microstates within or between Schengen states)—(4)
Andorra, Holy See, Monaco, San Marino
Second World
another term for the traditionally Marxist-Leninist states of the USSR and
Eastern Europe, with authoritarian governments and command economies
based on the Soviet model; the term is fading from use; see centrally planned
economies
Secretariat of the Pacific Community (SPC)
established—6 February 1947; effective 29 July 1948
aim—to serve island development in 22 Pacific countries; to develop technical
assistance and professional, scientific, and research support; to build planning
and management capability
members—(26) America Samoa, Australia, Cook Islands, Fiji, France, French
Polynesia, Guam, Kiribati, Marshall Islands, Federated States of Micronesia,
Nauru, New Caledonia, Niue, Northern Mariana Islands, NZ, Palau, Papua New
Guinea, Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu,
Vanuatu, US, Wallis and Futuna
Shanghai Cooperation Organization (SCO)
established—15 June 2001
aim—to combat terrorism, extremism, and separatism; to safeguard regional
security through mutual trust, disarmament, and cooperative security; and to
increase cooperation in political, trade, economic, scientific and technological,
cultural, and educational fields
members—(6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
dialogue members—(3) Belarus, Sri Lanka Turkey
observers—(5) Afghanistan, India, Iran, Mongolia, Pakistan
socialist countries
in general, countries in which the government owns and plans the use of the
major factors of production; note—the term is sometimes used incorrectly as a
synonym for communist countries
South
a popular term for the poorer, less industrialized countries generally located
south of the developed countries; the counterpart of the North; see less
developed countries (LDCs)
South American Community of Nations (CSN)
established on 9 December 2004; its aim was to coordinate common policies
regarding multilateral organizations, to integrate physical infrastructure, and
to consolidate the merger of CAN and Mercosur; the members were Argentina,
Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Surinam,
Uruguay, Venezuela; in 2008 it became Union of South American Nations
(UNASUR)
South Asia Co-operative Environment Program (SACEP)
established—January 1983
aim—to promote regional cooperation in South Asia in the field of environment,
both natural and human, and on issues of economic and social development; to
support conservation and management of natural resources of the region
members—(8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal,
Pakistan, Sri Lanka
South Asian Association for Regional Cooperation (SAARC)
established—8 December 1985
aim—to promote economic, social, and cultural cooperation
members—(8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal,
Pakistan, Sri Lanka
observers—(9) Australia, Burma, China, EU, Iran, Japan, South Korea,
Mauritius, US
South Pacific Forum (SPF)
note—see Pacific Island Forum
South Pacific Regional Trade and Economic Cooperation Agreement
(Sparteca)
established—1981
aim—to redress unequal trade relationships of Australia and New Zealand with
small island economies in the Pacific region
members—(19) Australia, Cook Islands, Fiji (suspended), French Polynesia,
Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, New
Caledonia, NZ, Niue, Palau, Papua New Guinea, Samoa, Solomon Islands,
Tonga, Tuvalu, Vanuatu, Wallis and Futuna
Southern African Customs Union (SACU)
established—11 December 1969
aim—to promote free trade and cooperation in customs matters
members—(5) Botswana, Eswatini, Lesotho, Namibia, South Africa
Southern African Development Community (SADC)
note—evolved from the Southern African Development Coordination
Conference (SADCC)
established—17 August 1992
aim—to promote regional economic development and integration
members—(16) Angola, Botswana, Comoros, Democratic Republic of the
Congo, Eswatini, Lesotho, Madagascar, Malawi, Mauritius, Mozambique,
Namibia, Seychelles, South Africa, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common
Market
note—also known as Mercado Comun del Sur (Mercosur Spanish); Mercado
Comum dol Sul (Mercosul—Portuguese)
established—26 March 1991
aim—to increase regional economic cooperation
members—(4) Argentina, Brazil, Paraguay, Uruguay
note—Venezuela was suspended
associate members—(7) Bolivia, Chile, Colombia, Ecuador, Guyana, Peru,','45387dcf666d6df2d149b715bc4c00e33b0c83996f78cb7549bada9b8d97f1b7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6860b4ae5cfc293f3a81101857cf98fb083c594879563b7f5b64eef0082e76d0',2021,'SR','Suriname','communications',1072,'observers—(2) New Zealand, Mexico
Third World
another term for the less developed countries; the term is obsolescent; see less
developed countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average
economic growth; see less developed countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little
prospect for economic growth; see least developed countries (LLDCs)
Union Latina
established—15 May 1954, became functional in 1983 to 2012; its aim was to
project, protect, and promote the common heritage and unifying identities of
the Latin and Latin-influenced world; on 26 January 2012, because of financial
difficulties, it announced the suspension of activities
aim—to project, protect, and promote the common heritage and unifying
identities of the Latin, and Latin-influence, world
members—(36) Angola, Bolivia, Brazil, Cabo Verde, Chile, Colombia, Cote
d''Ivoire, Costa Rica, Cuba, Dominican Republic, Ecuador, El Salvador, France,
Guatemala, Guinea-Bissau, Haiti, Honduras, Italy, Moldova, Monaco,
Mozambique, Nicaragua, Panama, Paraguay, Peru, Philippines, Portugal,
Romania, San Marino, Sao Tome and Principe, Senegal, Spain, Timor-Leste,
Uruguay, and Venezuela
observers—(4) Argentina, Holy See, Mexico, Order of Malta
Union of South American Nations (UNASUR—Spanish; UNASUL—
Portuguese)
formerly South American Community of Nations (CSN) which terminated on 16
April 2007
established—23 May 2008
aim—to model a community after the European Union which will include a
common currency, parliament, passport, and defense policy
members—(12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana,
Paraguay, Peru, Suriname, Uruguay, Venezuela
observers—(2) Mexico, Panama
United Nations (UN)
established—26 June 1945; effective—24 October 1945
aim—to maintain international peace and security and to promote cooperation
involving economic, social, cultural, and humanitarian problems
constituent organizations—the UN is composed of six principal organs and
numerous subordinate agencies and bodies as follows:
1) Secretariat
2) General Assembly: International Computing Center (ICC), International
Trade Center (ITC), Joint United Nations Program on HIV/AIDS (UN-AIDS),
Office of the United Nations High Commissioner for Refugees (UNHCR), United
Nations Capital Development Fund ( UNCDF), United Nations Center for
Human Settlements (UN-Habitat), United Nations Children’s Fund (UNICEF),
United Nations Conference on Trade and Development (UNCTAD), United
Nations Development Program (UNDP), United Nations Environment Program
(UNEP), United Nations Institute for Disarmament Research (UNIDIR), United
Nations Institute for Training and Research (UNITAR), United Nations
Interregional Crime and Justice Research Institute (UNICRI), United Nations
Office on Drugs and Crime (UNODC), United Nations Population Fund
(UNFPA), United Nations Office of Project Services (UNOPS), United Nations
International Strategy for Disaster Reduction (UNISDR), United Nations Relief
and Works Agency for Palestine Refugees in the Near East (UNRWA), United
Nations Research Institute for Social Development (UNRISD), United Nations
System Staff College (UNSSC), United Nations University (UNU), United
Nations Women, United Nations Volunteers (UNV), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former Yugoslavia
(ICTY) (1995-2012), International Criminal Tribunal for Rwanda (ICTR) (1993-
2012), United Nations Compensation Commission, United Nations
Disengagement Observer Force (UNDOF), African Union/United Nations
Hybrid Operation in Darfur (UNAMID), United Nations Assistance Mission in
Afghanistan (UNAMA), United Nations Interim Administration Mission in
Kosovo (UNMIK), United Nations Interim Force for Abyei (UNIFSA), United
Nations Interim Force in Lebanon (UNIFIL), United Nations Mission in Liberia
(UNMIL) (2003-2018), United Nations Military Observer Group in India and
Pakistan (UNMOGIP), United Nations Multidimensional Integrated
Stabilization Mission in Mali (MINUSMA), United Nations Operation in Cote
d’Ivoire (UNOCI) (2004-2016), United Nations Mission for the Referendum in
Western Sahara (MINURSO), United Nations Mission in South Sudan
(UNMISS), United Nations Organization Stabilization Mission in the
Democratic Republic of the Congo (MONUSCO), United Nations Peace-Keeping
Force in Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti
(MINUSTAH);
note—in 2017, transitioned into a smaller organization (MINUJUSTH), United
Nations Multidimensional Integrated Stabilization Mission in the Central
African Republic, and United Nations Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social
Development, Commission on Crime Prevention and Criminal Justice,
Commission on Narcotics Drugs, Commission on Population and Development,
Commission on Science and Technology for Development, Commission on
Sustainable Development, Commission on the Status of Women, Economic and
Social Commission for Asia and the Pacific (ESCAP), Economic and Social
Commission for Western Asia (ESCWA), Economic Commission for Africa
(ECA), Economic Commission for Europe (ECE), Economic Commission for
Latin America and the Caribbean (ECLAC), Statistical Commission, Food and
Agriculture Organization of the United Nations (FAO), International Atomic
Energy Agency (IAEA), Preparatory Commission for the Nuclear-Test-Ban
Treaty Organization (CTBTO), International Bank for Reconstruction and
Development (IBRD), International Center for Secretariat of Investment
Disputes (ICSID), International Civil Aviation Organization (ICAO),
International Development Association (IDA), International Finance
Corporation (IFC), International Fund for Agricultural Development (IFAD),
International Labor Organization (ILO), International Maritime Organization
(IMO), International Monetary Fund (IMF), International Telecommunication
Union (ITU), Multilateral Investment Guarantee Agency (MIGA), Statistical
Commission, United Nations Educational, Scientific, and Cultural Organization
(UNESCO), United Nations Forum on Forests, United Nations Industrial
Development Organization (UNIDO), Universal Postal Union (UPU), World
Health Organization (WHO), World Intellectual Property Organization (WIPO),
World Meteorological Organization (WMO), World Tourism Organization
(UNWTO), and World Trade Organization (WTO), United Nations Office on
Drugs and Crime (UNODC), World Bank Group (WBG), Statistical Commission,
UN Forum on Forests
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
UN members—(193) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cabo Verde, Cambodia, Cameroon, Canada, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Cyprus, Czechia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Eswatini, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, North
Macedonia, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela
observers—(1 plus Palestine Liberation Organization) Holy See, Palestine
Liberation Organization
United Nations Assistance Mission in Afghanistan (UNAMA)
established—January 2010
aim—to support the government of Afghanistan, in its attempt to improve
security, governance, and economic development and regional cooperation;
protect civilians and support efforts to support human rights
note—gives civilian support only
United Nations Children’s Fund (UNICEF)
note—acronym retained from the predecessor organization, UN International
Children’s Emergency Fund
established—11 December 1946
aim—to help establish child health and welfare services
executive board members—(36) selected on a rotating basis from all regions
United Nations Conference on Trade and Development (UNCTAD)
established—30 December 1964
aim—to promote international
trade members—(195) all UN members plus Holy See and the Palestine
Liberation Organization
United Nations Development Program (UNDP)
established—22 November 1965
aim—to provide technical assistance to stimulate economic and _ social
development
members (executive board)—(36) selected on a rotating basis from all regions
United Nations Disengagement Observer Force (UNDOF)
established—31 May 1974
aim—to observe the 1973 Arab-Israeli cease-fire; established by the UN
Security Council
members—(9) Bhutan, Czechia, Fiji, Finland, Ghana, India, Ireland, Nepal,','54a6f2fba0163577863b4b7e69480c1b2cad9bbd5b09ab79e7bb9281d70c734c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9eac690b67b0ef7671d5f8b37d43af7ede849e1e1bd848abe9d08fff24deb61',2021,'ZM','Zambia','communications',1073,'United Nations Peacekeeping Force in Cyprus (UNFICYP)
established—4 March 1964
aim—to serve as a peacekeeping force between Greek Cypriots and Turkish
Cypriots in Cyprus; established by the UN Security Council
members—(10) Austria, Australia. Canada, Denmark, Finland, Ireland, New
Zealand, Paraguay, Sweden, UK
United Nations Population Fund (UNFPA)
note—acronym retained from predecessor organization UN Fund for Population
Activities established—July 1967
aim—to assist both developed and developing countries to deal with their
population problems
members (executive board)—(36) selected on a rotating basis from all regions
United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA)
established—8 December 1949
aim—to provide assistance to Palestinian refugees
members (advisory commission)—(28) Australia, Belgium, Brazil, Canada,
Denmark, Egypt, Finland, France, Germany, Ireland, Italy, Japan, Jordan,
Kazakhstan, Kuwait, Lebanon, Luxembourg, Netherlands, Norway, Saudi
Arabia, Spain, Sweden, Switzerland, Syria, Turkey, UAE, Uk, US
observers—(3) EU, League of Arab States, Palestine Liberation Organization
United Nations Research Institute for Social Development (UNRISD)
established—1963
aim—to conduct research into the problems of economic development during
different phases of economic growth
members—no country members, but a Board of Directors currently consisting
of a chairman appointed by the UN Secretary General and 8 members
confirmed by ECOSOC and a representative of the Secretary General
United Nations Secretariat
established—24 June 1945; effective—24 October 1945
aim—to serve as the primary administrative organ of the UN; a Secretary
General is appointed for a five-year term by the General Assembly on the
recommendation of the Security Council
members—the UN Secretary General and staff
United Nations Security Council (UNSC)
established—26 June 1945; effective—24 October 1945
aim—to maintain international peace and security
permanent members—(5) China, France, Russia, UK, US
nonpermanent members—(10) elected for two-year terms by the UN General
Assembly; Belgium (2019-2020), Cote d''Ivoire (2018-2019), Dominican
Republic (2019-2020), Equatorial Guinea (2018-2019)), Germany (2019-2020),
Indonesia (2019-2020), Kuwait (2018-2019), Peru (2018-2019), Poland 2018-
2019), South Africa (2019-2020)
United Nations Truce Supervision Organization (UNTSO)
established—June 1948
aim—to supervise the 1948 Arab-lsraeli cease-fire; currently supports timely
deployment of reinforcements to other peacekeeping operations in the region
as needed; initially established by the UN Security Council
members—(23) Argentina, Australia, Austria, Belgium, Canada, Chile, China,
Denmark, Estonia, Finland, France, Ireland, Italy, Nepal, Netherlands, NZ,
Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
United Nations Trusteeship Council
established—26 June 1945, effective on 24 October 1945
aim—to supervise the administration of the 11 UN trust territories
members—China, France, Russia, UK, US; it formally suspended operations 1
November 1994 after the Trust Territory of the Pacific Islands (Palau) became
the Republic of Palau, a constitutional government in free association with the
US; the Trusteeship Council was not dissolved
United Nations University (UNU)
established—3 December 1973
aim—to conduct research in development, welfare, and human survival and to
train scholars
members—(12 members of UNU Council and the Rector are appointed by the
Secretary General of the United Nations and the Director General of UNESCO)
Universal Postal Union (UPU)
established—9 October 1874, affiliated with the UN 15 November 1947;
effective—1 July 1948
aim—to promote international postal cooperation; a UN specialized agency
members—(192) includes all UN member countries except Andorra, Marshall
Islands, Federated States of Micronesia, Palau (189 total); plus Aruba, Curacao,
and Sint Maarten; the Holy See; and Overseas Territories of the UK; note-
includes the following dependencies or areas of special interest: Australia
(Norfolk Island), China (Hong Kong, Macau), Denmark (Faroe Islands,
Greenland), France (French Guiana, French Polynesia including Clipperton
Island, French Southern and Antarctic Lands, Guadeloupe, Martinique,
Mayotte, New Caledonia, Reunion, Saint Barthelemy, Saint Martin, Saint Pierre
and Miquelon, Scattered Islands [Bassas da India, Europe, Juan de Nova,
Glorioso Islands, Tromelin], Wallis and Futuna), Netherlands (Aruba, Curacao,
Sint Maarten), NZ (Cook Island, Niue, Tokelau), UK (Guernsey, Isle of Man,
Jersey; Anguilla, Bermuda, British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands, Gibraltar, Montserrat, Pitcairn
Islands, Saint Helena, Ascension, and Tristan da Cunha, South Georgia and
South Sandwich Islands, Turks and Caicos), US (American Samoa, Guam,
Northern Mariana Islands, Puerto Rico, Virgin Islands)
Warsaw Pact (WP)
established—14 May 1955
aim—to promote mutual defense
members—met 1 July 1991 to dissolve the alliance; member states at the time
of dissolution were: Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and
the USSR; earlier members included German Democratic Republic (GDR) and','ec09afcb711d7a84c95c8b8d74fff6be2cd26ac16c836d992d850856e0973afd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f119000ff2a748ecbba6061d11d6441dd951634303c6c496df4fe92b48f8715',2021,'GL','Greenland','communications',1074,'Sea
Labrador Jan Mayen
sea ~se
silage
Denmark Strait > ~
7
. {
North Atlantic (pita) Saratov
Scale 1:39,000,000
Lambert Azimuthal Equal-Area Projection
° 500 Kilometers .
ee eee
500 Miles
180.
\\
&
~
North Pacific :
ya Bering|Sea
ANGtUCH) 4
Ofean a
, (DENMARK)
POLITICAL MAP OF ASI
20 a
saat ~ ert onl US Gan) ea
100 120 v. Wrangel
TRAYZ JOstr | Istand
% ano
ye” Anctic) Océan
| East Siberian
Bering
ea
“~s
R/U ‘Ss s\\I AS
>
ry, 4 SS, \\Oxcupled by thre Soviet Union ie 1043,
\\ . y YON. atententeres by
Xo, ; claiaed ty Magen
Philippine
Sea
Arabian Nishibdsopeteain ‘ South
E China
Se: :
rhe Bay of
Bengal
Andaman .<
Sea
ONO)
"| Celebes Sea
Equator
Scale 1:48,000,000
Azimuthal Equal-Area Projection
800 Kilometers In d ian
Cond Ocean
Boundary representation Is
not necessarily authoritative.
803537Al (G00543) 6-12
|
“|
= §
Lh
fe)
—i
<i
i
<i
<_ |
0
”
>
aE
a.
| ra >
|
j
y Anctic
/
Indian
POLITICAL MAP OF CENTRAL AMERICA AND THE CARIBBEAN
y= Nor th
Gulf/of Mexico hn "f THE BAHAMAS Atlantic
: f Ocean
op Tahiade
Campeche
Cludad det
Sen juan, _ Os ar aa
"Es ee tection oa Barthctony TRANCE)
=
North
| Pacific
Ocean
Seale I: 12,500,000
Lambert Conformal Conic Projection,
standard parallels 7°N aid 24° N
e 200
100 a 20 Mer
ee, BRAZIL
é
PHYSICAL MAP OF CENTRAL AMERICA AND THE CARIBBEAN
North
Laaettate
Ocean
PUERTO RICg
TREN,
North
Pacific
Ocean
POLITICAL MAP OF EUROPE
Barents
~ j
Denmark pe
Strait ~
. Arctic Circle
NORWA
\\
Gulf
of
Bothnia
\\
\\ Tu
North
Atlantic
Ocean
Bay of
Biscay
-
te \\
ITALY. eas atl io
SPAIN Valencla | i es
BALEARIC
ISLANDS lonian
Sea
Mediterranean Sea
.
‘Algiers = Scale 1:1 patooD hcepened
Lambert Conformal Conic re pape 5
‘A standard parallels 40°N and 68°N
o 0 Kilometers
o
803539Al (G00772) 6-12
PHYSICAL MAP OF EUROPE
North
Atlantic
Ocean Pa ee 6
19-9674 11-19
POLITICAL MAP OF MIDDLE EAST
0
A
Caspian
Sea
| Persian
+ Gulf
Arabian Sea
Gulf of Aden ~ ws Socotra
: (YEMEN)
\\
Boosaaso,
1 = Heights Is Isracli-occupled Eye. ees 0
—West Bank is Toraeloccupled with current status subject to |
the Israeli-Palestinian Interim Agreement, permanent status
to be determined through further negotiation. \\
The status of the Gaza Strip Is a final status Issue to be \\
resolved
Israel proclaimed Jerusalem as its capital in 1950, but the \\
US, lle nearly all other countries, maintains Its Embassy in us
Tel Aviv-Yafo.
803540Al (G00412) 6-12
PHYSICAL MAP OF MIDDLE EAST
50
Vy
Se
POLITICAL MAP OF NORTH AMERICA
Foneet =
365 14012010080 6Q “40,
f
East
Siberian
by /
SK pacific
nak Ocean~_
Atlantic
Ocean','052f42e5e287fbb78655aa9e96138cf98c2efdcbe8bd61c6d15b352625544b41','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d0b7827fa387c6e97b8df9a6cf13b70438b8b38492c3befe77ba5168ddc268c',2021,'BS','Bahamas','communications',1075,'a
Scale: 1:36,000,000
Lambert Conformal Conic Projection, Ne Face
standard parallels 25°N and 77°N pan cache an
Sea
\\
803541AI(G00694)6-12
a A. LS ~
180 160 140120100 80 6) 40, x
PHYSICAL MAP OF NORTH ERICA
Atlantic
Ocean
16-1909 2-16
POLITICAL MAP OF OCEANIA
Wenzhow? se as
z hat e
“ > ‘Saws . Aw
‘alan At,
fle 5 AN
a Ws Satonotls
1
Northern “s . 5
Mariana
Saipan, Islands
Nagata = f
MARSHALL Ocean
ISLANDS
Metekeotys a “ Majuro
; PALAU CAROLINE ISLANDS
Mansy Tarawa (clacar Mowand hand -nunnan
enn ISLANDS? . es
a ao * uk vanes z sake ond = z,
satkpapaee * i = NAURU us 1
: Seo one “ : RAWARI
Render > Gee sage 5 arnoents -
send sr PAPUADNEW GUINEA: KIRIBAT] mae
¢ Audange eve
jure INDONESIA Noe inca Sount Nw \\. SOLOMON “
aes oni =, _ ISLANDS dunsioa KIRIBATI “o wt,
None w. co eae oy <p f tateat a : sists
Nerang ag TMORLESTE psa x ie cuca) TUVALU
Moresby - ISLANDS
now Walls and
“Darwin * : Tutuna. — sanion Cook
Mata apis aP Ak? Islands they
uu American mz "bg
VANUATU FIJI “on ee Semon Ze
X Coral Sea us ; zh
aes Port-Vita - "og “Papeete s
lacs de = Jo Alot rie 7, Te
Townsvile™ iF) LANDS
vy om
as Mowat ta, (AUSTRALIA ae ° <= TONGA Avartia ; ©
sodns chy castes gasses Nuku''alofa * French Polynesia
“mance : : (FRANCE) otis
dS Adamstown
AUSTRALIA “, Pitcairn islands
“4, UK)
erste (Kingston
eRMADEC
ISLANDS
Nd.
weal
Bun tapepaese, l i
oAdla Canberra, fwotlengong
NEW — nes
fe ZEALAND
‘Wellington
Madar gf Tasmania Scale 1:41,000,000
1 ai Mercator Projection
PHYSICAL MAP OF OCEANIA
Went re rove uae
CHINA fumeae” pew hae Sosa
Nemeny? a 4 “en at UNITED STATES
gia 7 Wa,
<p tatwan Ta
bs tem en “
om i
4
Northern Waduaea °, © ramet
Mariana ~
amy Islands Pe
Manila 5) Spipan, *
Magitna,
PHILIPPINES toe
pay ee Ee MARSHALL
mere per ater TEDERATED STATES OF MICRONESIA ISLANDS
zanvearoy/Mbaeoae Metchovky nog To _Majuro Kinaran font
—_- San extaziva tarhnunsi ty hess
MALAYA Pye i
Boryés Manadyy Tarawag* (CiAEKT Mont alana
2 ISLANDS)
amannses, Pat, = Yawn Oisnie 7
Babepapar? Siovang, = to NAURU aed res o
aanarmoun > ay ne eyapad weve A ty AK
: basalt 6 et TRY RANG nh -
atone aaoog - PAPUA NEW QUINEA ISLANDS)
. Maange cake °
wom INDONESIA New Guinig “BSD. ar tan SOLOMON
oo enh om ISLANDS (see Tone KIRIBATI “o manauises
Ovnpaingy S to. Hleniara j . r
wea enne-) HmOREST »- as mein one TUVALU
Moresby SLANDS as ns
ane “Darwen i ecaiiean Cook
age ee Islands *tcy
Coral Sea — wmerican n Z
de VANUATU PIL Samoa 7 >
Sala New -Port-Vila TONGA : "0, sPapecte “s
AUSTRALIA Caledonia * Very, 00
Fownsvi oe Alot, rue phe
ga rama wie whet’ ga French Polynesia
‘Noumea iJ FRANCE tascve? as
Anco Sng, 5 catare
P anor ej Adamstown,
AUSTRALIA *o, Ptcaim islands
\\oxraidon ; Kingston “unos
x Sorktk stand na
, shen Hl
Rockingha wives, herd Mowe
neue ey Frenne tin
“bepecance {ora
oAdetaide “wotonpore North
Nand
4 Auch,
NEW _rateruoa flim
Launcieson, ZEALAND y
P Wellington
Niger f Peseonene Seale 141,000,000
Frenacturch
_— Mercator Projection
South Island msn 5
tower cept, —“*Denedin So oe we aro daies
Physical
Map of the World, January 2015
AMADA','be3cf73d091279bd0277a512c7d72a7da339be244195a102dfbf25da03bc0d06','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

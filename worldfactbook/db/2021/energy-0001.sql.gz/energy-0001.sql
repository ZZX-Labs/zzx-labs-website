SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d97429e44eb41b12d19c31b3fbcaae47c5fd754857b534097294a51a70fe7fd',2021,'US','United States','energy',45,'Electricity—production:
Electricity—consumption:
Electricity—exports:
Electricity—imports:
Electricity—installed generating capacity:
Electricity—from fossil fuels: Electricity—from
nuclear fuels: Electricity—from hydroelectric
plants: Electricity—from other renewable
sources: Crude oil—production:
Crude oil—exports:
Crude oil—imports:
Crude oil—proved reserves: Refined petroleum
products—production: Refined petroleum
products—consumption: Refined petroleum
products—exports: Refined petroleum products
—imports: Natural gas—production:
Natural gas—consumption:
Natural gas—exports:
Natural gas—imports:
Natural gas—proved reserves: Carbon dioxide
emissions from consumption of energy:
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 212','3b8afc019097443dd5913978484a95c1de503bc90f6476b820568aa427bd2af5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f711c85d0b475447a24c595986268ddac013e320c6b4929a076daed07ddbbe7',2021,'PK','Pakistan','energy',50,'Electricity access: DOpulation without electricity: 18,999,254
(2012) electrification—total population: 84.1% (2016)
electrification—urban areas: 98% (2016)
electrification—rural areas: 79% (2016)
Electricity—production: 1.211 billion kWh (2016 est.)
country comparison to the world: 146
Electricity—consumption: 5.526 billion kWh (2016 est.)
country comparison to the world: 119
Electricity—Exports: 0 kWh (2016 est.)
country comparison to the world: 96
Electricity—Imports: 4.4 billion kWh (2016 est.)
country comparison to the world: 42
Electricity—installed generating capacity: 634,100 kW (2016 est.)
country comparison to the world: 138
Electricity—from fossil fuels: 45% of total installed capacity
(2016 est.)
country comparison to the world: 159
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 32
Electricity—from hydroelectric plants: 52% of total installed
Capacity (2017 est.)
country comparison to the world: 34
Electricity—from other renewable sources: 4% of total installed
Capacity (2017 est.)
country comparison to the world: 111
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 101
Crude oil—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 82
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 84
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 99
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 110
Refined petroleum products—consumption: 35,000 bbl/day (2016
est.)
country comparison to the world: 117
Refined petroleum products—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 124
Refined petroleum products—Imports: 34,210 bbl/day (2015 est.)
country comparison to the world: 97
Natural gas—production: 164.2 million cu m (2017 est.)
country comparison to the world: 79
Natural gas—consumption: 164.2 million cu m (2017 est.)
country comparison to the world: 108
Natural gas—Exports: 0 cu m (2017 est.)
country comparison to the world: 57
Natural gas—Imports: 0 cu m (2017 est.)
country comparison to the world: 81
Natural gas—proved reserves: 49.55 billion cu m (1 January
2018 est.)
country comparison to the world: 62
Carbon dioxide emissions from consumption of energy: 9.067 million
Mt (2017 est.)
country comparison to the world: 111
Electricity access: DOpUulation without electricity: 52 million
(2017)
electrification—total population: 74% (2017)
electrification—urban areas: 90% (2017)
electrification—rural areas: 64% (2017)
Electricity—production: 109.7 billion kWh (2016 est.)
country comparison to the world: 32
Electricity—consumption: 92.33 billion kWh (2016 est.)
country comparison to the world: 34
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 182
Electricity—imports: 490 million kWh (2016 est.)
country comparison to the world: 80
Electricity—installed generating capacity: 26.9 million kW (2016
est.)
country comparison to the world: 35
Electricity—from fossil fuels: 62% of total installed capacity
(2016 est.)
country comparison to the world: 125
Electricity—from nuclear fuels: 5% of total installed capacity
(2017 est.)
country comparison to the world: 22
Electricity—from hydroelectric plants: 27% of total installed
Capacity (2017 est.)
country comparison to the world: 74
Electricity—from other renewable sources: 7% of total installed
capacity (2017 est.)
country comparison to the world: 94
Crude oil—production: 90,000 bbl/day (2018 est.)
country comparison to the world: 45
Crude oil—exports: 13,150 bbl/day (2015 est.)
country comparison to the world: 58
Crude oil—imports: 168,200 bbl/day (2015 est.)
country comparison to the world: 34
Crude oil—proved reserves: 332.2 million bbl (1 January 2018
est.)
country comparison to the world: 52
Refined petroleum products—production: 291,200 bbl/day (2015
est.)
country comparison to the world: 43
Refined petroleum products—consumption: 557,000 bbl/day (2016
est.)
country comparison to the world: 33
Refined petroleum products—exports: 25,5910 bbl/day (2015 est.)
country comparison to the world: 68
Refined petroleum products—imports: 264,500 bbl/day (2015 est.)
country comparison to the world: 27
Natural gas—production: 39.05 billion cu m (2017 est.)
country comparison to the world: 21
Natural gas—consumption: 45.05 billion cu m (2017 est.)
country comparison to the world: 20
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 165
Natural gas—imports: 6.003 billion cu m (2017 est.)
country comparison to the world: 32
Natural gas—proved reserves: 588.8 billion cu m (1 January
2018 est.)
country comparison to the world: 30
Carbon dioxide emissions from consumption of energy: 179.5 million
Mt (2017 est.)
country comparison to the world: 33
Electricity access: electrification—total population: 99.3%
(2016)
electrification—urban areas: 99.6% (2016)
electrification—rural areas: 97.2% (2016)','ea8320b5d3c1ba9ce3a17dec595216edb2e99b0e09bdef475155c225334b5e60','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5155a1e6488b465ba7f7ee70a38c0c660abffbcf4efa8768031daf6a14b649d4',2021,'GR','Greece','energy',69,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 7.138 billion kWh (2016 est.)
country comparison to the world: 111
Electricity—consumption: 5.11 billion kWh (2016 est.)
country comparison to the world: 122
Electricity—Exports: 1.869 billion kWh (2016 est.)
country comparison to the world: 46
Electricity—Imports: 1.827 billion kWh (2016 est.)
country comparison to the world: 58
Electricity—installed generating capacity: 2.109 million kW (2016
est.)
country comparison to the world: 112
Electricity—from fossil fuels: 5% of total installed capacity (2016
est.)
country comparison to the world: 202
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 33
Electricity—from hydroelectric plants: 95% of total installed
Capacity (2017 est.)
country comparison to the world: 5
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 172
Crude oil—production: 14,000 bbl/day (2018 est.)
country comparison to the world: 73
Crude oil—Exports: 17,290 bbl/day (2015 est.)
country comparison to the world: 51
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 85
Crude oil—proved reserves: 168.3 million bbl (1 January 2018
est.)
country comparison to the world: 59
Refined petroleum products—production: 5,638 bbl/day (2015 est.)
country comparison to the world: 103
Refined petroleum products—consumption: 29,000 bbl/day (2016
est.)
country comparison to the world: 120
Refined petroleum products—Exports: 3,250 bbl/day (2015 est.)
country comparison to the world: 98
Refined petroleum products—Imports: 26,660 bbl/day (2015 est.)
country comparison to the world: 103
Natural gas—production: 50.97 million cu m (2017 est.)
country comparison to the world: 86
Natural gas—consumption: 50.97 million cu m (2017 est.)
country comparison to the world: 112
Natural gas—Exports: 0 cu m (2017 est.)
country comparison to the world: 58
Natural gas—Imports: 0 cu m (2017 est.)
country comparison to the world: 82
Natural gas—proved reserves: 821.2 million cu m (1 January
2018 est.)
country comparison to the world: 101
Carbon dioxide emissions from consumption of energy: 4.5 million
Mt (2017 est.)
country comparison to the world: 136
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 42.29 billion kWh (2016 est.)
country comparison to the world: 57
Electricity—consumption: 32.34 billion kWh (2016 est.)
country comparison to the world: 60
Electricity—exports: 9.187 billion kWh (2017 est.)
country comparison to the world: 23
Electricity—imports: 4.568 billion kWh (2016 est.)
country comparison to the world: 41
Electricity—installed generating capacity: 10.75 million kW (2016
est.)
country comparison to the world: 57
Electricity—from fossil fuels: 39% of total installed capacity
(2016 est.)
country comparison to the world: 170
Electricity—from nuclear fuels: 20% of total installed capacity
(2017 est.)
country comparison to the world: 8
Electricity—from hydroelectric plants: 23% of total installed
Capacity (2017 est.)
country comparison to the world: 83
Electricity—from other renewable sources: 19% of total installed
Capacity (2017 est.)
country comparison to the world: 41
Crude oil—production: 1,000 bbl/day (2018 est.)
country comparison to the world: 91
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 99
Crude oil—imports: 133,900 bbl/day (2015 est.)
country comparison to the world: 39
Crude oil—proved reserves: 15 million bbl (1 January 2018 est.)
country comparison to the world: 84
Refined petroleum products—production: 144,300 bbl/day (2015
est.)
country comparison to the world: 60
Refined petroleum products—consumption: 97,000 bbl/day (2016
est.)
country comparison to the world: 82
Refined petroleum products—exports: 92,720 bbl/day (2015 est.)
country comparison to the world: 45
Refined petroleum products—imports: 49,260 bbl/day (2015 est.)
country comparison to the world: 83
Natural gas—production: 79.28 million cu m (2017 est.)
country comparison to the world: 83
Natural gas—consumption: 3.313 billion cu m (2017 est.)
country comparison to the world: 70
Natural gas—exports: 31.15 million cu m (2017 est.)
country comparison to the world: 52
Natural gas—imports: 3.256 billion cum (2017 est.)
country comparison to the world: 44
Natural gas—proved reserves: 5.663 billion cu m (1 January
2018 est.)
country comparison to the world: 88
Carbon dioxide emissions from consumption of energy: 46.31 million
Mt (2017 est.)
country comparison to the world: 63
Electricity access: Electrification—total population: 19.2%
(2016) Electrification—urban areas: 60.7% (2016)
Electrification—rural areas: 0.8% (2016)
Electricity—production: 990 million kWh (2016 est.)
country comparison to the world: 152
Electricity—consumption: 1.551 billion kWh (2016 est.)
country comparison to the world: 148
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 112
Electricity—imports: 630 million kWh (2016 est.)
country comparison to the world: 77
Electricity—installed generating capacity: 342,400 kW (2016 est.)
country comparison to the world: 153
Electricity—from fossil fuels: 80% of total installed capacity
(2016 est.)
country comparison to the world: 82
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 57
Electricity—from hydroelectric plants: 9% of total installed
capacity (2017 est.)
country comparison to the world: 117
Electricity—from other renewable sources: 12% of total installed
Capacity (2017 est.)
country comparison to the world: 72
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 116
Crude oil-exports: 0 bbl/day (2015 est.)
country comparison to the world: 100
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 102
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 112
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 124
Refined petroleum products—consumption: 23,000 bbl/day (2016
est.)
country comparison to the world: 132
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 136
Refined petroleum products—imports: 23,580 bbl/day (2015 est.)
country comparison to the world: 110
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 110
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 126
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 75
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 98
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 116
Carbon dioxide emissions from consumption of energy: 3.421 million
Mt (2017 est.)
country comparison to the world: 142
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 5.396 billion kWh (2016 est.)
country comparison to the world: 119
Electricity—consumption: 6.42 billion kWh (2016 est.)
country comparison to the world: 112
Electricity—exports: 58.5 million kWh (2016 est.)
country comparison to the world: 84
Electricity—imports: 2.191 billion kWh (2016 est.)
country comparison to the world: 55
Electricity—installed generating capacity: 1.828 million kW (2016
est.)
country comparison to the world: 115
Electricity—from fossil fuels: 60% of total installed capacity
(2016 est.)
country comparison to the world: 132
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 133
Electricity—from hydroelectric plants: 37% of total installed
Capacity (2017 est.)
country comparison to the world: 57
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 126
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 166
Crude oil—exports: 142 bbl/day (2015 est.)
country comparison to the world: 80
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 157
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 161
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 169
Refined petroleum products—consumption: 21,000 bbl/day (2016
est.)
country comparison to the world: 138
Refined petroleum products—exports: 3,065 bbl/day (2015 est.)
country comparison to the world: 99
Refined petroleum products—imports: 23,560 bbl/day (2015 est.)
country comparison to the world: 111
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 162
Natural gas—consumption: 198.2 million cu m (2017 est.)
country comparison to the world: 105
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 143
Natural gas—imports: 198.2 million cu m (2017 est.)
country comparison to the world: 72
Natural gas—proved reserves: 0 cu m (31 December 2016 est.)
country comparison to the world: 163
Carbon dioxide emissions from consumption of energy: 7.459 million
Mt (2017 est.)
country comparison to the world: 123','95efc5c28ff65f955cbebfc96c6a5ef5c8127cc3468d8f9fe41dc368ce985085','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a1cf803f4e4cb506c4af4b6ddabdd65149c2f589d261662c2bd8ab11770ee59',2021,'DZ','Algeria','energy',75,'Electricity access: population without electricity: 400,000
(2016)
electrification—total population: 99.4% (2016)
electrification—urban areas: 99.6% (2016)
electrification—rural areas: 99% (2016)
Electricity—production
66.89 billion kWh (2016 est.)
country comparison to the world: 42
Electricity -consumption:
55.96 billion kWh (2016 est.)
country comparison to the world: 46
Electricity—Exports: 641 million kWh (2015 est.)
country comparison to the world: 65
Electricity—Imports: 257 million kWh (2016 est.)
country comparison to the world: 91
Electricity—installed generating capacity: 19.27 million kW (2016
est.)
country comparison to the world: 45
Electricity—from fossil fuels: 96% of total installed capacity
(2016 est.)
country comparison to the world: 36
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 34
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 144
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.)
country comparison to the world: 130
Crude oil—production: 1.259 million bbl/day (2018 est.)
country comparison to the world: 18
Crude oil—Exports: 756,400 bbl/day (2015 est.)
country comparison to the world: 15
Crude oil—Imports: 5,340 bbl/day (2015 est.)
country comparison to the world: 75
Crude oil—proved reserves: 12.2 billion bbl (1 January 2018
est.)
country comparison to the world: 15
Refined petroleum products—production: 627,900 bbl/day (2015
est.)
country comparison to the world: 29
Refined petroleum products—consumption: 405,000 bbl/day (2016
est.)
country comparison to the world: 37
Refined petroleum products—Exports: 978,800 bbl/day (2015 est.)
country comparison to the world: 15
Refined petroleum products—Imports: 82,930 bbl/day (2015 est.)
country comparison to the world: 61
Natural gas production:
93.5 billion cu m (2017 est.)
country comparison to the world: 10
Natural gas—consumption: 41.28 billion cu m (2017 est.)
country comparison to the world: 25
Natural gas—Exports: 53.88 billion cu m (2017 est.)
country comparison to the world: 7
Natural gas—Imports: 0 cu m (2017 est.)
country comparison to the world: 83
Natural gas—proved reserves: 4.504 trillion cu m (1 January
2018 est.)
country comparison to the world: 10
Carbon dioxide emissions from consumption of energy: 135.9 million
Mt (2017 est.)
country comparison to the world: 34
Electricity access: DOpDUlation without electricity: 11 million
(2017) electrification—total population: 35.1% (2016)
electrification—urban areas: 83.6% (2016)
electrification—rural areas: 1.8% (2016)
Electricity—production: 2.489 billion kWh (2016 est.)
country comparison to the world: 136
Electricity—consumption: 2.982 billion kWh (2016 est.)
country comparison to the world: 136
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 166
Electricity—imports: 800 million kWh (2016 est.)
country comparison to the world: 73
Electricity—installed generating capacity: 590,000 kW (2016 est.)
country comparison to the world: 140
Electricity—from fossil fuels: 68% of total installed capacity
(2016 est.)
country comparison to the world: 113
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 138
Electricity—from hydroelectric plants: 31% of total installed
capacity (2017 est.)
country comparison to the world: 68
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 160
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 170
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 161
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 161
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 165
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 173
Refined petroleum products—consumption: 22,000 bbl/day (2016
est.)
country comparison to the world: 134
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 178
Refined petroleum products—imports: 20,610 bbl/day (2015 est.)
country comparison to the world: 119
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 166
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 172
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 147
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 154
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 167
Carbon dioxide emissions from consumption of energy: 3.388 million
Mt (2017 est.)
country comparison to the world: 143','792e12b26128da7f7fa2dd7f7dbff05a1eb1a3194b25cf7bb4033330089341a9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f1d53fc5289f7ce77976e63b7676392655b3bf2e239028ccce867a8be161ec0',2021,'AS','American Samoa','energy',82,'Electricity access: population without electricity: 22,219
(2012)
electrification—total population: 59% (2012)
electrification—urban areas: 60% (2012)
electrification—rural areas: 45% (2012)
Electricity—production: 169 million kWh (2016 est.)
country comparison to the world: 195
Electricity—consumption: 157.2 million kWh (2016 est.)
country comparison to the world: 197
Electricity—Exports: 0 kWh (2016 est.)
country comparison to the world: 97
Electricity—Imports: 0 kWh (2016 est.)
country comparison to the world: 118
Electricity—installed generating capacity: 43,000 kW (2016 est.)
country comparison to the world: 195
Electricity—from fossil fuels: 98% of total installed capacity
(2016 est.)
country comparison to the world: 27
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 35
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 152
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 131
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 102
Crude oil—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 83
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 86
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 100
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 111
Refined petroleum products—consumption: 2,375 bbl/day (2016
est.)
country comparison to the world: 192
Refined petroleum products—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 125
Refined petroleum products—Imports: 2,346 bbl/day (2015 est.)
country comparison to the world: 188
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 97
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 117
Natural gas—Exports: 0 cu m (2017 est.)
country comparison to the world: 59
Natural gas—Imports: 0 cu m (2017 est.)
country comparison to the world: 84
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 103
Carbon dioxide emissions from consumption of energy: 361,100 Mt
(2017 est.)
country comparison to the world: 189','319aac17c4067ca1cf1d7a3e68c8d05d6aec49b9732d444ecca8564dc4dcc260','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a360e67c3b1846c40b07f7e8a0278372769a9090dcea7fb17162305a4af4e246',2021,'AD','Andorra','energy',87,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 99.48 million kWh (2015 est.)
country comparison to the world: 201
Electricity—consumption: 221.6 million kWh (2015 est.)
country comparison to the world: 190
Electricity—Exports: 6,000 kWh (2015 est.)
country comparison to the world: 95
Electricity—Imports: 471.3 million kWh (2015 est.)
country comparison to the world: 81
Electricity—installed generating capacity: 520,000 kW (2010 est.)
country comparison to the world: 147
Electricity—from fossil fuels: 61% of total installed capacity
(2010 est.)
country comparison to the world: 126
Electricity—from nuclear fuels: 0% of total installed capacity
(2016 est.)
country comparison to the world: 36
Electricity—from hydroelectric plants: 23% of total installed
Capacity (2010 est.)
country comparison to the world: 82
Electricity—from other renewable sources: 15% of total installed
capacity (2010 est.)
country comparison to the world: 56
Crude oil—production: 0 bbl/day (2016)
country comparison to the world: 103
Crude oil—Exports: 0 bbl/day (2016) (2016)
country comparison to the world: 84
Crude oil—Imports: 0 bbl/day (2016) (2016)
country comparison to the world: 87
Crude oil—proved reserves: 0 bbl (2016) (2016)
country comparison to the world: 101
Refined petroleum products—production: 0 bbl/day (2016)
country comparison to the world: 112
Natural gas—production: 0 cu m (2016) (2016)
country comparison to the world: 98
Natural gas—consumption: 0 cu m (2016) (2016)
country comparison to the world: 118
Natural gas—Exports: Ocum (2016) (2016)
country comparison to the world: 60
Natural gas—Imports: Ocum (2016) (2016)
country comparison to the world: 85
Natural gas—proved reserves: 0 cu m (2016)
country comparison to the world: 104','dfeff965cfb3d63b4996271f286090075bf2b0078b8df00085d8010d50873959','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81db8ba0c57b4a2ed3c9c12aa5a02e13323aff5cf72992555557f02f853ee46a',2021,'NA','Namibia','energy',98,'Electricity access: DOpulation without electricity: 15 million
(2013)
electrification—total population: 40.5% (2016)
electrification—urban areas: 70.7% (2016)
electrification—rural areas: 16% (2016)
Electricity—production: 10.2 billion kWh (2016 est.)
country comparison to the world: 102
Electricity—consumption: 9.036 billion kWh (2016 est.)
country comparison to the world: 101
Electricity—Exports: 0 kWh (2016 est.)
country comparison to the world: 98
Electricity—Imports: 0 kWh (2016 est.)
country comparison to the world: 119
Electricity—installed generating capacity: 2.613 million kW (2016
est.)
country comparison to the world: 103
Electricity—from fossil fuels: 34% of total installed capacity
(2016 est.)
country comparison to the world: 180
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 37
Electricity—from hydroelectric plants: 64% of total installed
capacity (2017 est.)
country comparison to the world: 23
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 132
Crude oil—production: 1.593 million bbl/day (2018 est.)
country comparison to the world: 14
Crude oil—Exports: 1.782 million bbl/day (2015 est.)
country comparison to the world: 7
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 88
Crude oil—proved reserves: 9.523 billion bbl (1 January 2018
est.)
country comparison to the world: 16
Refined petroleum products—production: 53,480 bbl/day (2015
est.)
country comparison to the world: 80
Refined petroleum products—consumption: 130,000 bbl/day (2016
est.)
country comparison to the world: 72
Refined petroleum products—Exports: 30,340 bbl/day (2015 est.)
country comparison to the world: 62
Refined petroleum products—Imports: 111,600 bbl/day (2015 est.)
country comparison to the world: 50
Natural gas—production: 3.115 billion cu m (2017 est.)
country comparison to the world: 55
Natural gas—consumption: 821.2 million cu m (2017 est.)
country comparison to the world: 95
Natural gas—Exports: 3.993 billion cu m (2017 est.)
country comparison to the world: 33
Natural gas—Imports: 0 cu m (2017 est.)
country comparison to the world: 86
Natural gas—proved reserves: 308.1 billion cu m (1 January
2018 est.)
country comparison to the world: 36
Carbon dioxide emissions from consumption of energy: 20.95 million
Mt (2017 est.)
country comparison to the world: 85
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 104
Electricity access: DOpulation without electricity: 9,358 (2012)
electrification—total population: 97.4% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 96.5% (2016)
Electricity—production: 331 million kWh (2016 est.)
country comparison to the world: 179
Electricity—consumption: 307.8 million kWh (2016 est.)
country comparison to the world: 184
Electricity—Exports: 0 kWh (2016 est.)
country comparison to the world: 99
Electricity—Imports: 0 kWh (2016 est.)
country comparison to the world: 120
Electricity—installed generating capacity: 124,000 kW (2016 est.)
country comparison to the world: 177
Electricity—from fossil fuels: 97% of total installed capacity
(2016 est.)
country comparison to the world: 31
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 38
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.)
country comparison to the world: 153
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 119
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 105
Crude oil—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 85
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 89
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 102
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 113
Refined petroleum products—consumption: 5,000 bbl/day (2016
est.)
country comparison to the world: 177
Refined petroleum products—Exports: 91 bbl/day (2015 est.)
country comparison to the world: 119
Refined petroleum products—Imports: 5,065 bbl/day (2015 est.)
country comparison to the world: 172
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 99
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 119
Natural gas—Exports: 0 cu m (2017 est.)
country comparison to the world: 61
Natural gas—Imports: 0 cu m (2017 est.)
country comparison to the world: 87
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 105
Carbon dioxide emissions from consumption of energy: 740,300 Mt
(2017 est.)
country comparison to the world: 175','075d5ebc6df8323d0e68cda83ea4745e2848eeaa4e1cbc3977578c20374f4927','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5627edb067dfa65b9bf60fd9322358be91b2733c18647b949a58ec1364d14b78',2021,'AQ','Antarctica','energy',111,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 131.9 billion kWh (2016 est.)
country comparison to the world: 30
Electricity—consumption: 121 billion kWh (2016 est.)
country comparison to the world: 30
Electricity—Exports: 55 million kWh (2015 est.)
country comparison to the world: 85
Electricity—Imports: 9.851 billion kWh (2016 est.)
country comparison to the world: 26
Electricity—installed generating capacity: 38.35 million kW (2016
est.)
country comparison to the world: 27
Electricity—from fossil fuels: 69% of total installed capacity
(2016 est.)
country comparison to the world: 112
Electricity—from nuclear fuels: 4% of total installed capacity
(2017 est.)
country comparison to the world: 23
Electricity—from hydroelectric plants: 24% of total installed
Capacity (2017 est.)
country comparison to the world: 79
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 120
Crude oil—production: 489,000 bbl/day (2018 est.)
country comparison to the world: 29
Crude oil—Exports: 36,630 bbl/day (2015 est.)
country comparison to the world: 43
Crude oil—Imports: 16,740 bbl/day (2015 est.)
country comparison to the world: 68
Crude oil—proved reserves: 2.162 billion bbl (1 January 2018
est.)
country comparison to the world: 32
Refined petroleum products—production: 669,800 bbl/day (2015
est.)
country comparison to the world: 26
Refined petroleum products—consumption: 806,000 bbl/day (2016
est.)
country comparison to the world: 27
Refined petroleum products—Exports: 58,360 bbl/day (2015 est.)
country comparison to the world: 51
Refined petroleum products—Imports: 121,400 bbl/day (2015 est.)
country comparison to the world: 49
Natural gas—production: 40.92 billion cu m (2017 est.)
country comparison to the world: 20
Natural gas—consumption: 49.04 billion cu m (2017 est.)
country comparison to the world: 17
Natural gas—Exports: 76.45 million cu m (2017 est.)
country comparison to the world: 49
Natural gas—Imports: 9.826 billion cum (2017 est.)
country comparison to the world: 27
Natural gas—proved reserves: 336.6 billion cu m (1 January
2018 est.)
country comparison to the world: 35
Carbon dioxide emissions from consumption of energy: 203.7 million
Mt (2017 est.)
country comparison to the world: 32
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 76.09 billion kWh (2016 est.)
country comparison to the world: 39
Electricity—consumption: 73.22 billion kWh (2016 est.)
country comparison to the world: 38
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 121
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 135
Electricity—installed generating capacity: 24.53 million kW (2016
est.)
country comparison to the world: 37
Electricity—from fossil fuels: 59% of total installed capacity
(2016 est.)
country comparison to the world: 133
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 66
Electricity—from hydroelectric plants: 26% of total installed
capacity (2017 est.)
country comparison to the world: 75
Electricity—from other renewable sources: 15% of total installed
Capacity (2017 est.)
country comparison to the world: 57
Crude oil—production: 3,000 bbl/day (2018 est.)
country comparison to the world: 84
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 106
Crude oil—imports: 169,600 bbl/day (2017 est.)
country comparison to the world: 33
Crude oil—proved reserves: 150 million bbl (1 January 2018
est.)
country comparison to the world: 60
Refined petroleum products—production: 216,200 bbl/day (2017
est.)
country comparison to the world: 49
Refined petroleum products—consumption: 354,500 bbl/day (2017
est.)
country comparison to the world: 39
Refined petroleum products—exports: 7,359 bbl/day (2017 est.)
country comparison to the world: 87
Refined petroleum products—imports: 166,400 bbl/day (2017 est.)
country comparison to the world: 38
Natural gas—production: 1.218 billion cu m (2017 est.)
country comparison to the world: 65
Natural gas—consumption: 5.125 billion cu m (2017 est.)
country comparison to the world: 58
Natural gas—exports: 277.5 million cu m (2017 est.)
country comparison to the world: 43
Natural gas—imports: 4.446 billion cu m (2017 est.)
country comparison to the world: 38
Natural gas—proved reserves: 97.97 billion cu m (1 January
2018 est.)
country comparison to the world: 52
Carbon dioxide emissions from consumption of energy: 88.23 million
Mt (2017 est.)
country comparison to the world: 47','4ee08501cadf6074d27995b5eec6fac202cf41decdec3a03d2a5e106075f69d4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9daa8508bfb3a442c35ed51dabe0321e485f3ba96bdff51ec1db991b157634ca',2021,'AM','Armenia','energy',119,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 6.951 billion kWh (2016 est.)
country comparison to the world: 112
Electricity—consumption: 5.291 billion kWh (2016 est.)
country comparison to the world: 121
Electricity—Exports: 1.424 billion kWh (2015 est.)
country comparison to the world: 50
Electricity—Imports: 275 million kWh (2016 est.)
country comparison to the world: 90
Electricity—installed generating capacity: 4.08 million kW (2016
est.)
country comparison to the world: 86
Electricity—from fossil fuels: 58% of total installed capacity
(2016 est.)
country comparison to the world: 134
Electricity—from nuclear fuels: 9% of total installed capacity
(2017 est.)
country comparison to the world: 15
Electricity—from hydroelectric plants: 32% of total installed
Capacity (2017 est.)
country comparison to the world: 65
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 173
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 106
Crude oil—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 86
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 90
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 103
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 114
Refined petroleum products—consumption: 8,000 bbl/day (2016
est.)
country comparison to the world: 162
Refined petroleum products—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 126
Refined petroleum products—Imports: 7,145 bbl/day (2015 est.)
country comparison to the world: 158
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 100
Natural gas—consumption: 2.35 billion cu m (2017 est.)
country comparison to the world: 80
Natural gas—Exports: 0 cu m (2017 est.)
country comparison to the world: 62
Natural gas—Imports: 2.35 billion cu m (2017 est.)
country comparison to the world: 48
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 106
Carbon dioxide emissions from consumption of energy: 5.501 million
Mt (2017 est.)
country comparison to the world: 131
Electricity access: population without electricity: 11,364
(2012) electrification—total population: 95.6% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 92.5% (2016)
Electricity—production: 939 million kWh (2016 est.)
country comparison to the world: 153
Electricity—consumption: 873.3 million kWh (2016 est.)
country comparison to the world: 158
Electricity—Exports: 0 kWh (2016 est.)
country comparison to the world: 100
Electricity—Imports: 0 kWh (2016 est.)
country comparison to the world: 121
Electricity—installed generating capacity: 296,000 kW (2016 est.)
country comparison to the world: 159
Electricity—from fossil fuels: 87% of total installed capacity
(2016 est.)
country comparison to the world: 61
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 39
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.)
country comparison to the world: 154
Electricity—from other renewable sources: 13% of total installed
Capacity (2017 est.)
country comparison to the world: 66
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 107
Crude oil—Exports: 0 bbl/day (2015 est.)
country comparison to the world: 87
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 91
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 104
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 115
Refined petroleum products—consumption: 8,000 bbl/day (2016
est.)
country comparison to the world: 163
Refined petroleum products—Exports: 0) bbl/day (2015 est.)
country comparison to the world: 127
Refined petroleum products—Imports: 7,891 bbl/day (2015 est.)
country comparison to the world: 153
Natural gas—production: 1 cu m (2017 est.)
country comparison to the world: 96
Natural gas—consumption: 1 cu m (2017 est.)
country comparison to the world: 116
Natural gas—Exports: 1 cu m (2017 est.)
country comparison to the world: 56
Natural gas—Imports: 1 cu m (2017 est.)
country comparison to the world: 80
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 107
Carbon dioxide emissions from consumption of energy: 1.266 million
Mt (2017 est.)
country comparison to the world: 162','b05d62e5bdcb4b909ba627ea993ab7b8d4a9aadac7165f181d129803c66bad0c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adfb92c43efb49185dd36e27ab3e352fa5dc3ca273b4035c109e5adb217fad97',2021,'NF','Norfolk Island','energy',138,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 243 billion kWh (2016 est.)
country comparison to the world: 19
Electricity—consumption: 229.4 billion kWh (2016 est.)
country comparison to the world: 19
Electricity—Exports: 0 kWh (2016 est.)
country comparison to the world: 101
Electricity—Imports: 0 kWh (2016 est.)
country comparison to the world: 122
Electricity—installed generating capacity: 65.56 million kW (2016
est.)
country comparison to the world: 18
Electricity—from fossil fuels: 72% of total installed capacity
(2016 est.)
country comparison to the world: 101
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 40
Electricity—from hydroelectric plants: 11% of total installed
Capacity (2017 est.)
country comparison to the world: 113
Electricity—from other renewable sources: 17% of total installed
Capacity (2017 est.)
country comparison to the world: 49
Crude oil—production: 284,000 bbl/day (2018 est.)
country comparison to the world: 31
Crude oil—Exports: 192,500 bbl/day (2017 est.)
country comparison to the world: 31
Crude oil—Imports: 341,700 bbl/day (2017 est.)
country comparison to the world: 24
Crude oil—proved reserves: 1.821 billion bbl (1 January 2018
est.)
country comparison to the world: 35
Refined petroleum products—production: 462,500 bbl/day (2017
est.)
country comparison to the world: 35
Refined petroleum products—consumption: 1.175 million bbl/day
(2017 est.)
country comparison to the world: 20
Refined petroleum products—Exports: 64,120 bbl/day (2017 est.)
country comparison to the world: 48
Refined petroleum products—Imports: 619,600 bbl/day (2017 est.)
country comparison to the world: 12
Natural gas—production: 105.2 billion cu m (2017 est.)
country comparison to the world: 9
Natural gas—consumption: 45.25 billion cu m (2017 est.)
country comparison to the world: 19
Natural gas—Exports: 67.96 billion cu m (2017 est.)
country comparison to the world: 6
Natural gas—Imports: 5.776 billion cu m (2017 est.)
country comparison to the world: 33
Natural gas—proved reserves: 1.989 trillion cu m (1 January
2018 est.)
country comparison to the world: 17
Carbon dioxide emissions from consumption of energy: 439.1 million
Mt (2017 est.)
country comparison to the world: 15
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 60.78 billion kWh (2016 est.)
country comparison to the world: 48
Electricity—consumption: 64.6 billion kWh (2016 est.)
country comparison to the world: 41
Electricity—Exports: 19.21 billion kWh (2016 est.)
country comparison to the world: 9
Electricity—Imports: 26.37 billion kWh (2016 est.)
country comparison to the world: 6
Electricity—installed generating capacity: 24.79 million kW (2016
est.)
country comparison to the world: 36
Electricity—from fossil fuels: 25% of total installed capacity
(2016 est.)
country comparison to the world: 188
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 41
Electricity—from hydroelectric plants: 43% of total installed
Capacity (2017 est.)
country comparison to the world: 45
Electricity—from other renewable sources: 31% of total installed
Capacity (2017 est.)
country comparison to the world: 17
Crude oil—production: 13,000 bbl/day (2018 est.)
country comparison to the world: 75
Crude oil—Exports: 0 bbl/day (2017 est.)
country comparison to the world: 88
Crude oil—Imports: 146,600 bbl/day (2017 est.)
country comparison to the world: 37
Crude oil—proved reserves: 41.2 million bbl (1 January 2018
est.)
country comparison to the world: 78
Refined petroleum products—production: 186,500 bbl/day (2017
est.)
country comparison to the world: 54
Refined petroleum products—consumption: 268,000 bbl/day (2017
est.)
country comparison to the world: 47
Refined petroleum products—Exports: 49,960 bbl/day (2017 est.)
country comparison to the world: 55
Refined petroleum products—Imports: 135,500 bbl/day (2017 est.)
country comparison to the world: 42
Natural gas—production: 1.274 billion cu m (2017 est.)
country comparison to the world: 62
Natural gas—consumption: 9.486 billion cu m (2017 est.)
country comparison to the world: 50
Natural gas—Exports: 5.437 billion cu m (2017 est.)
country comparison to the world: 29
Natural gas—Imports: 14.02 billion cu m (2017 est.)
country comparison to the world: 22
Natural gas—proved reserves: 6.513 billion cu m (1 January
2018 est.)
country comparison to the world: 84
Carbon dioxide emissions from consumption of energy: 63.93 million
Mt (2017 est.)
country comparison to the world: 53
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 23.57 billion kWh (2016 est.)
country comparison to the world: 73
Electricity—consumption: 20.24 billion kWh (2016 est.)
country comparison to the world: 71
Electricity—Exports: 265 million kWh (2015 est.)
country comparison to the world: 71
Electricity—Imports: 114 million kWh (2016 est.)
country comparison to the world: 97
Electricity—installed generating capacity: 7.876 million kW (2016
est.)
country comparison to the world: 71
Electricity—from fossil fuels: 84% of total installed capacity
(2016 est.)
country comparison to the world: 74
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 42
Electricity—from hydroelectric plants: 14% of total installed
capacity (2017 est.)
country comparison to the world: 104
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 133
Crude oil—production: 798,000 bbl/day (2018 est.)
country comparison to the world: 23
Crude oil—Exports: 718,800 bbl/day (2015 est.)
country comparison to the world: 19
Crude oil—Imports: 0 bbl/day (2015 est.)
country comparison to the world: 92
Crude oil—proved reserves: 7 billion bbl (1 January 2018 est.)
country comparison to the world: 18
Refined petroleum products—production: 138,900 bbl/day (2015
est.)
country comparison to the world: 61
Refined petroleum products—consumption: 100,000 bbl/day (2016
est.)
country comparison to the world: 80
Refined petroleum products—Exports: 46,480 bbl/day (2015 est.)
country comparison to the world: 57
Refined petroleum products—Imports: 5,976 bbl/day (2015 est.)
country comparison to the world: 168
Natural gas—production: 16.96 billion cu m (2017 est.)
country comparison to the world: 35
Natural gas—consumption: 10.34 billion cu m (2017 est.)
country comparison to the world: 47
Natural gas—Exports: 8.042 billion cu m (2017 est.)
country comparison to the world: 24
Natural gas—Imports: 2.095 billion cu m (2017 est.)
country comparison to the world: 51
Natural gas—proved reserves: 991.1 billion cu m (1 January
2018 est.)
country comparison to the world: 25
Carbon dioxide emissions from consumption of energy: 35.6 million
Mt (2017 est.)
country comparison to the world: 72
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 1.778 billion kWh (2016 est.)
country comparison to the world: 140
Electricity—consumption: 1.654 billion kWh (2016 est.)
country comparison to the world: 145
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 102
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 123
Electricity—installed generating capacity: 577,000 kW (2016 est.)
country comparison to the world: 141
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 1
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 43
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 155
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 174
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 108
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 89
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 93
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 105
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 116
Refined petroleum products—consumption: 20,040 bbl/day (2016
est.)
country comparison to the world: 140
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 128
Refined petroleum products—imports: 19,150 bbl/day (2015 est.)
country comparison to the world: 123
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 101
Natural gas—consumption: 48,020 cu m (2017 est.)
country comparison to the world: 115
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 63
Natural gas—imports: 48,020 cu m (2017 est.)
country comparison to the world: 79
Natural gas—proved reserves: (0 cu m (1 January 2009 est.)
country comparison to the world: 108
Carbon dioxide emissions from consumption of energy: 3.089 million
Mt (2017 est.)
country comparison to the world: 147','b290194777f9b7363f1768238beb55335f147d8dacf496e275f31d28b6de4052','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57ab3930c5bfed12bb7abacc96452b27a5c0bbc69cb3434d5c22ad6dc992c4fe',2021,'BH','Bahrain','energy',145,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 26.81 billion kWh (2016 est.)
country comparison to the world: 70
Electricity—consumption: 26.11 billion kWh (2016 est.)
country comparison to the world: 67
Electricity—exports: 213 million kWh (2015 est.)
country comparison to the world: 74
Electricity—imports: 276 million kWh (2016 est.)
country comparison to the world: 89
Electricity—installed generating capacity: 3.928 million kW (2016
est.)
country comparison to the world: 90
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 2
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 44
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 156
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 175
Crude oil—production: 40,000 bbl/day (2018 est.)
country comparison to the world: 58
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 90
Crude oil—imports: 226,200 bbl/day (2015 est.)
country comparison to the world: 29
Crude oil—proved reserves: 124.6 million bbl (1 January 2018
est.)
country comparison to the world: 67
Refined petroleum products—production: 274,500 bbl/day (2015
est.)
country comparison to the world: 45
Refined petroleum products—consumption: 61,000 bbl/day (2016
est.)
country comparison to the world: 94
Refined petroleum products—exports: 245,300 bbl/day (2015 est.)
country comparison to the world: 30
Refined petroleum products—imports: 14,530 bbl/day (2015 est.)
country comparison to the world: 136
Natural gas—production: 15.89 billion cu m (2017 est.)
country comparison to the world: 36
Natural gas—consumption: 15.89 billion cu m (2017 est.)
country comparison to the world: 42
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 64
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 88
Natural gas—proved reserves: 92.03 billion cu m (1 January
2018 est.)
country comparison to the world: 53
Carbon dioxide emissions from consumption of energy: 37.98 million
Mt (2017 est.)
country comparison to the world: 67','5aa925ea2163a6589757938b412403a9eb7192c7712747388b7fa343313b98ea','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66170f70dba5a149fee2aa7b2b4378a60e1b43217d828c67a272d7ce0f9388a1',2021,'IN','India','energy',152,'Electricity access: DODUlation without electricity: 60.3 million
(2013) electrification—total population: 75.9% (2016)
electrification—urban areas: 94% (2016)
electrification—rural areas: 68.9% (2016)
Electricity—production: 60.51 billion kWh (2016 est.)
country comparison to the world: 49
Electricity—consumption: 53.65 billion kWh (2016 est.)
country comparison to the world: 48
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 103
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 124
Electricity—installed generating capacity: 11.9 million kW (2016
est.)
country comparison to the world: 56
Electricity—from fossil fuels: 97% of total installed capacity
(2016 est.)
country comparison to the world: 32
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 45
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 136
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.) country comparison to the world: 134
Crude oil—production: 3,000 bbl/day (2018 est.)
country comparison to the world: 83
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 91
Crude oil—imports: 21,860 bbl/day (2015 est.)
country comparison to the world: 63
Crude oil—proved reserves: 28 million bbl (1 January 2018 est.)
country comparison to the world: 81
Refined petroleum products—production: 26,280 bbl/day (2015
est.)
country comparison to the world: 86
Refined petroleum products—consumption: 106,000 bbl/day (2016
est.)
country comparison to the world: 77
Refined petroleum products—exports: 901 bbl/day (2015 est.)
country comparison to the world: 108
Refined petroleum products—imports: 81,570 bbl/day (2015 est.)
country comparison to the world: 63
Natural gas—production: 29.53 billion cu m (2017 est.)
country comparison to the world: 27
Natural gas—consumption: 29.53 billion cu m (2017 est.)
country comparison to the world: 32
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 65
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 89
Natural gas—proved reserves: 185.8 billion cu m (1 January
2018 est.)
country comparison to the world: 44
Carbon dioxide emissions from consumption of energy: 79.97 million
Mt (2017 est.)
country comparison to the world: 48','f7fe29c49a18f532dbbcd8a5e8c86a1b3754577d818e3b298fefdd0abb503023','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45bf61c296db57a460a876b95a8fb1fbc7f82c07d3b55e374d7f2ef34f51756b',2021,'BB','Barbados','energy',163,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 1.01 billion kWh (2016 est.)
country comparison to the world: 150
Electricity—consumption: 990 million kWh (2016 est.)
country comparison to the world: 155
Electricity—exports: 0 kWh (2017 est.)
country comparison to the world: 104
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 125
Electricity—installed generating capacity: 269,000 kW (2016 est.)
country comparison to the world: 162
Electricity—from fossil fuels: 93% of total installed capacity
(2016 est.)
country comparison to the world: 50
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 46
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.)
country comparison to the world: 157
Electricity—from other renewable sources: 7% of total installed
capacity (2017 est.) country comparison to the world: 91
Crude oil—production: 1,000 bbl/day (2018 est.)
country comparison to the world: 90
Crude oil—exports: 674 bbl/day (2015 est.)
country comparison to the world: 77
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 94
Crude oil—proved reserves: 2.534 million bbl (1 January 2018
est.)
country comparison to the world: 94
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 117
Refined petroleum products—consumption: 11,000 bbl/day (2016
est.)
country comparison to the world: 159
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 129
Refined petroleum products—imports: 10,630 bbl/day (2015 est.)
country comparison to the world: 147
Natural gas—production: 14.16 million cu m (2017 est.)
country comparison to the world: 91
Natural gas—consumption: 19.82 million cu m (2017 est.)
country comparison to the world: 113
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 66
Natural gas—imports: 5.653 million cu m (2017 est.)
country comparison to the world: 78
Natural gas—proved reserves: 141.6 million cu m (1 January
2018 est.)
country comparison to the world: 102
Carbon dioxide emissions from consumption of energy:
1.76 million Mt (2017 est.)
country comparison to the world: 160
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 31.58 billion kWh (2016 est.)
country comparison to the world: 63
Electricity—consumption: 31.72 billion kWh (2016 est.)
country comparison to the world: 61
Electricity—exports: 3.482 billion kWh (2015 est.)
country comparison to the world: 40
Electricity—imports: 6.319 billion kWh (2016 est.)
country comparison to the world: 32
Electricity—installed generating capacity: 10.04 million kW (2016
est.)
country comparison to the world: 59
Electricity—from fossil fuels: 96% of total installed capacity
(2016 est.)
country comparison to the world: 37
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 47
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 145
Electricity—from other renewable sources: 3% of total installed
capacity (2017 est.) country comparison to the world: 121
Crude oil—production: 31,000 bbl/day (2018 est.)
country comparison to the world: 62
Crude oil—exports: 31,730 bbl/day (2015 est.)
country comparison to the world: 44
Crude oil—imports: 468,400 bbl/day (2015 est.)
country comparison to the world: 21
Crude oil—proved reserves: 198 million bbl (1 January 2018
est.)
country comparison to the world: 56
Refined petroleum products—production: 477,200 bbl/day (2015
est.)
country comparison to the world: 34
Refined petroleum products—consumption: 141,000 bbl/day (2016
est.)
country comparison to the world: 68
Refined petroleum products—exports: 351,200 bbl/day (2015 est.)
country comparison to the world: 25
Refined petroleum products—imports: 14,630 bbl/day (2015 est.)
country comparison to the world: 135
Natural gas—production: 59.46 million cu m (2017 est.)
country comparison to the world: 84
Natural gas—consumption: 17.7 billion cu m (2017 est.)
country comparison to the world: 39
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 67
Natural gas—imports: 17.53 billion cu m (2017 est.)
country comparison to the world: 18
Natural gas—proved reserves: 2.832 billion cu m (1 January
2018 est.)
country comparison to the world: 95
Carbon dioxide emissions from consumption of energy: 56.07 million
Mt (2017 est.)
country comparison to the world: 54','5a0a3305cafbb52bb72f4bde95eb26b05f9d5f70ec500029774dce892728ce68','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23df44509803fc629602e5bdc400332d1287b6ef3f93e4f48cdf4c263e5d1a09',2021,'FR','France','energy',175,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 79.83 billion kWh (2016 est.)
country comparison to the world: 37
Electricity—consumption: 82.16 billion kWh (2016 est.)
country comparison to the world: 36
Electricity—exports: 8.465 billion kWh (2016 est.)
country comparison to the world: 25
Electricity—imports: 14.65 billion kWh (2016 est.)
country comparison to the world: 15
Electricity—installed generating capacity: 21.56 million kW (2016
est.)
country comparison to the world: 41
Electricity—from fossil fuels: 35% of total installed capacity
(2016 est.)
country comparison to the world: 177
Electricity—from nuclear fuels: 28% of total installed capacity
(2017 est.)
country comparison to the world: 2
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2017 est.) country comparison to the world: 146
Electricity—from other renewable sources: 36% of total installed
Capacity (2017 est.) country comparison to the world: 8
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 109
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 92
Crude oil—imports: 687,600 bbl/day (2017 est.)
country comparison to the world: 16
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 106
Refined petroleum products—production: 731,700 bbl/day (2017
est.)
country comparison to the world: 25
Refined petroleum products—consumption: 648,600 bbl/day (2017
est.)
country comparison to the world: 31
Refined petroleum products—exports: 680,800 bbl/day (2017 est.)
country comparison to the world: 12
Refined petroleum products—imports: 601,400 bbl/day (2017 est.)
country comparison to the world: 14
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 102
Natural gas—consumption: 17.61 billion cu m (2017 est.)
country comparison to the world: 40
Natural gas—exports: 736.2 million cu m (2017 est.)
country comparison to the world: 40
Natural gas—imports: 18.09 billion cu m (2017 est.)
country comparison to the world: 17
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 109
Carbon dioxide emissions from consumption of energy: 134.7 million
Mt (2017 est.) country comparison to the world: 35
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 529.1 billion kWh (2016 est.)
country comparison to the world: 9
Electricity—consumption: 450.8 billion kWh (2016 est.)
country comparison to the world: 10
Electricity—exports: 61.41 billion kWh (2016 est.)
country comparison to the world: 3
Electricity—imports: 19.9 billion kWh (2016 est.)
country comparison to the world: 10
Electricity—installed generating capacity: 130.8 million kW (2016
est.)
country comparison to the world: 9
Electricity—from fossil fuels: 17% of total installed capacity
(2016 est.)
country comparison to the world: 198
Electricity—from nuclear fuels: 50% of total installed capacity
(2017 est.)
country comparison to the world: 1
Electricity—from hydroelectric plants: 15% of total installed
Capacity (2017 est.)
country comparison to the world: 102
Electricity—from other renewable sources: 19% of total installed
Capacity (2017 est.)
country comparison to the world: 42
Crude oil—production: 16,000 bbl/day (2018 est.)
country comparison to the world: 71
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 126
Crude oil—imports: 1.147 million bbl/day (2017 est.)
country comparison to the world: 9
Crude oil—proved reserves: 65.97 million bbl (1 January 2018
est.)
country comparison to the world: 75
Refined petroleum products—production: 1.311 million bbl/day
(2017 est.)
country comparison to the world: 15
Refined petroleum products—consumption: 1.705 million bbl/day
(2017 est.)
country comparison to the world: 13
Refined petroleum products—exports: 440,600 bbl/day (2017 est.)
country comparison to the world: 19
Refined petroleum products—imports: 886,800 bbl/day (2017 est.)
country comparison to the world: 8
Natural gas—production: 16.99 million cu m (2017 est.)
country comparison to the world: 90
Natural gas—consumption: 41.88 billion cu m (2017 est.)
country comparison to the world: 24
Natural gas—exports: 6.031 billion cu m (2017 est.)
country comparison to the world: 26
Natural gas—imports: 48.59 billion cu m (2017 est.)
country comparison to the world: 10
Natural gas—proved reserves: 8.41 billion cu m (1 January 2018
est.)
country comparison to the world: 81
Carbon dioxide emissions from consumption of energy: 341.2 million
Mt (2017 est.)
country comparison to the world: 22
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 258.6 billion kWh (2016 est.)
country comparison to the world: 17
Electricity—consumption: 239.5 billion kWh (2016 est.)
country comparison to the world: 15
Electricity—exports: 14.18 billion kWh (2016 est.)
country comparison to the world: 13
Electricity—imports: 21.85 billion kWh (2016 est.)
country comparison to the world: 9
Electricity—installed generating capacity: 105.9 million kW (2016
est.)
country comparison to the world: 12
Electricity—from fossil fuels: 47% of total installed capacity
(2016 est.)
country comparison to the world: 157
Electricity—from nuclear fuels: 7% of total installed capacity
(2017 est.)
country comparison to the world: 19
Electricity—from hydroelectric plants: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 108
Electricity—from other renewable sources: 32% of total installed
Capacity (2017 est.)
country comparison to the world: 15
Crude oil—production: 1,700 bbl/day (2018 est.)
country comparison to the world: 88
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 198
Crude oil—imports: 1.325 million bbl/day (2017 est.)
country comparison to the world: 8
Crude oil—proved reserves: 150 million bbl (1 January 2018
est.)
country comparison to the world: 62
Refined petroleum products—production: 1.361 million bbl/day
(2017 est.)
country comparison to the world: 13
Refined petroleum products—consumption: 1.296 million bbl/day
(2017 est.)
country comparison to the world: 18
Refined petroleum products—exports: 562,400 bbl/day (2017 est.)
country comparison to the world: 16
Refined petroleum products—imports: 464,800 bbl/day (2017 est.)
country comparison to the world: 18
Natural gas—production: 36.81 million cu m (2017 est.)
country comparison to the world: 87
Natural gas—consumption: 31.27 billion cu m (2017 est.)
country comparison to the world: 29
Natural gas—exports: 2.888 billion cu m (2017 est.)
country comparison to the world: 36
Natural gas—imports: 34.63 billion cum (2017 est.)
country comparison to the world: 12
Natural gas—proved reserves: 2.548 billion cu m (1 January
2018 est.)
country comparison to the world: 96
Carbon dioxide emissions from consumption of energy: 286.7 million
Mt (2017 est.)
country comparison to the world: 25','ad51f9e4aeb192ae91fb6ba9c5b9fa5e86662e19feac72d248825d1659e1068f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c6d3f5f813073a3f68df0cfc03a828496782f630553fcbf9bb90eb9f2f6bbb2',2021,'HN','Honduras','energy',181,'Electricity access: electrification—total population: 92.2%
(2016) electrification—urban areas: 97.1% (2016)
electrification—rural areas: 88.4% (2016)
Electricity—production: 280 million kWh (2016 est.)
country comparison to the world: 186
Electricity—consumption: 453 million kWh (2016 est.)
country comparison to the world: 172
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 105
Electricity—imports: 243 million kWh (2016 est.)
country comparison to the world: 92
Electricity—installed generating capacity: 198,000 kW (2016 est.)
country comparison to the world: 165
Electricity—from fossil fuels: 51% of total installed capacity
(2016 est.)
country comparison to the world: 147
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 48
Electricity—from hydroelectric plants: 27% of total installed
capacity (2017 est.) country comparison to the world: 73
Electricity—from other renewable sources: 22% of total installed
capacity (2017 est.) country comparison to the world: 33
Crude oil—production: 2,000 bbl/day (2018 est.)
country comparison to the world: 85
Crude oil—exports: 1,220 bbl/day (2015 est.)
country comparison to the world: 73
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 95
Crude oil—proved reserves: 6.7 million bbl (1 January 2018 est.)
country comparison to the world: 93
Refined petroleum products—production: 36 bbl/day (2015 est.)
country comparison to the world: 109
Refined petroleum products—consumption: 4,000 bbl/day (2016
est.)
country comparison to the world: 182
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 130
Refined petroleum products—imports: 4,161 bbl/day (2015 est.)
country comparison to the world: 176
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 103
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 120
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 68
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 90
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 110
Carbon dioxide emissions from consumption of energy: 556,700 Mt
(2017 est.)
country comparison to the world: 183','198f7b948a4d578bcb5e3ad7b7e42e155deb46e0153df72cbee02ae43ffc17ad','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d49dfca210d320d442c01ab5e8a249cc11817198c1f65e885ece4ff531e426c5',2021,'ET','Ethiopia','energy',188,'Electricity access: DOpulation without electricity: 8 million
(2017) electrification—total population: 41.4% (2016)
electrification—urban areas: 70.8% (2016)
electrification—rural areas: 18% (2016)
Electricity—production: 335 million kWh (2016 est.)
country comparison to the world: 177
Electricity—consumption: 1.143 billion kWh (2016 est.)
country comparison to the world: 152
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 106
Electricity—imports: 1.088 billion kWh (2016 est.)
country comparison to the world: 68
Electricity—installed generating capacity: 321,000 kW (2016 est.)
country comparison to the world: 158
Electricity—from fossil fuels: 88% of total installed capacity
(2016 est.)
country comparison to the world: 58
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 49
Electricity—from hydroelectric plants: 9% of total installed
Capacity (2017 est.) country comparison to the world: 116
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.) country comparison to the world: 135
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 110
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 93
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 96
Crude oil—proved reserves: 8 million bbl (1 January 2018 est.)
country comparison to the world: 92
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 118
Refined petroleum products—consumption: 38,000 bbl/day (2016
est.)
country comparison to the world: 113
Refined petroleum products—exports: 1,514 bbl/day (2015 est.)
country comparison to the world: 107
Refined petroleum products—imports: 38,040 bbl/day (2015 est.)
country comparison to the world: 93
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 104
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 121
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 69
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 91
Natural gas—proved reserves: 1.133 billion cu m (1 January
2018 est.)
country comparison to the world: 98
Carbon dioxide emissions from consumption of energy: 5.664 million
Mt (2017 est.) country comparison to the world: 130
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 650 million kWh (2016 est.)
country comparison to the world: 159
Electricity—consumption: 604.5 million kWh (2016 est.)
country comparison to the world: 166
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 107
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 126
Electricity—installed generating capacity: 171,000 kW (2016 est.)
country comparison to the world: 169
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 3
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 50
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.) country comparison to the world: 158
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) note: the Tynes Bay Waste Treatment
Facility turns waste to electric energy
country comparison to the world: 176
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 111
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 94
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 97
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 107
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 119
Refined petroleum products—consumption: 5,000 bbl/day (2016
est.)
country comparison to the world: 178
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 131
Refined petroleum products—imports: 3,939 bbl/day (2015 est.)
country comparison to the world: 178
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 105
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 122
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 70
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 92
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 111
Carbon dioxide emissions from consumption of energy: 793,700 Mt
(2017 est.)
country comparison to the world: 174
Electricity access: DOpulation without electricity: 5 million
(2017) electrification—total population: 36% (2017)
electrification—urban areas: 64% (2017)
electrification—rural areas: 16% (2017)
Electricity—production: 232.6 million kWh (2016 est.)
country comparison to the world: 189
Electricity—consumption: 1.261 billion kWh (2016 est.)
country comparison to the world: 151
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 208
Electricity—imports: 1.14 billion kWh (2016 est.)
country comparison to the world: 67
Electricity—installed generating capacity: 230,000 kW (2016 est.)
country comparison to the world: 164
Electricity—from fossil fuels: 70% of total installed capacity
(2016 est.)
country comparison to the world: 110
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 195
Electricity—from hydroelectric plants: 29% of total installed
capacity (2017 est.)
country comparison to the world: 71
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 169
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 207
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 206
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 204
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 204
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 208
Refined petroleum products—consumption: 15,000 bbl/day (2016
est.)
country comparison to the world: 152
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 209
Refined petroleum products—imports: 13,100 bbl/day (2015 est.)
country comparison to the world: 142
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 206
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 206
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 200
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 200
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 200
Carbon dioxide emissions from consumption of energy: 2.651 million
Mt (2017 est.)
country comparison to the world: 151
Crude oil—proved reserves: 0 bbl (1 January 2010 est.)
country comparison to the world: 205
Electricity access: electrification—total population: 97%
(2016)
electrification—urban areas: 98.6% (2016)
electrification—rural areas: 96.6% (2016)
Electricity—production: 52 million kWh (2016 est.)
country comparison to the world: 205
Electricity—consumption: 48.36 million kWh (2016 est.)
country comparison to the world: 205
Electricity—exports: 0 kWh (2016)
country comparison to the world: 209
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 210
Electricity—installed generating capacity: 20,300 kW (2016 est.)
country comparison to the world: 204
Electricity—from fossil fuels: 74% of total installed capacity
(2016 est.)
country comparison to the world: 98
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 196
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.)
country comparison to the world: 205
Electricity—from other renewable sources: 26% of total installed
Capacity (2017 est.)
country comparison to the world: 28
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 208
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 207
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 205
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 206
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 209
Refined petroleum products—consumption: 900 bbl/day (2016 est.)
country comparison to the world: 207
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 210
Refined petroleum products—imports: 910 bbl/day (2015 est.)
country comparison to the world: 203
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 207
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 207
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 201
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 201
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 201
Carbon dioxide emissions from consumption of energy: 139,700 Mt
(2017 est.)
country comparison to the world: 205','8f526588c51d0e771b0618d2462fd4eacd58951fcb9dd52942e9a0726fed3083','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('690db4dc473f2a4304bcc0e667578b31d09ebf0efeb3a58d7f1eb23db9b406ae',2021,'BR','Brazil','energy',213,'Electricity access: DODUlation without electricity: 1.2 million
(2013) electrification—total population: 93% (2016)
electrification—urban areas: 99.3% (2016)
electrification—rural areas: 79.1% (2016)
Electricity—production: 8.951 billion kWh (2016 est.)
country comparison to the world: 107
Electricity—consumption: 7.785 billion kWh (2016 est.)
country comparison to the world: 105
Electricity—exports: 0 kWh (2017 est.)
country comparison to the world: 108
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 127
Electricity—installed generating capacity: 2.764 million kW (2016
est.)
country comparison to the world: 101
Electricity—from fossil fuels: 76% of total installed capacity
(2016 est.)
country comparison to the world: 93
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 52
Electricity—from hydroelectric plants: 18% of total installed
Capacity (2017 est.)
country comparison to the world: 92
Electricity—from other renewable sources: 7% of total installed
Capacity (2017 est.)
country comparison to the world: 92
Crude oil—production: 60,000 bbl/day (2018 est.)
country comparison to the world: 50
Crude oil—exports: 1,274 bbl/day (2015 est.)
country comparison to the world: 72
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 99
Crude oil—proved reserves: 211.5 million bbl (1 January 2018
est.)
country comparison to the world: 54
Refined petroleum products—production: 65,960 bbl/day (2015
est.)
country comparison to the world: 75
Refined petroleum products—consumption: 83,000 bbl/day (2016
est.)
country comparison to the world: 86
Refined petroleum products—exports: 9,686 bbl/day (2015 est.)
country comparison to the world: 82
Refined petroleum products—imports: 20,620 bbl/day (2015 est.)
country comparison to the world: 118
Natural gas—production: 18.69 billion cu m (2017 est.)
country comparison to the world: 32
Natural gas—consumption: 3.171 billion cu m (2017 est.)
country comparison to the world: 71
Natural gas—exports: 15.46 billion cum (2017 est.)
country comparison to the world: 15
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 94
Natural gas—proved reserves: 295.9 billion cu m (1 January
2018 est.)
country comparison to the world: 37
Carbon dioxide emissions from consumption of energy: 17.66 million
Mt (2017 est.)
country comparison to the world: 90
Electricity access: DOpulation without electricity: 1 million
(2017) electrification—total population: 99% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 95.7% (2016)
Electricity—production: 74.92 billion kWh (2016 est.)
country comparison to the world: 41
Electricity—consumption: 68.25 billion kWh (2016 est.)
country comparison to the world: 40
Electricity—exports: 460 million kWh (2015 est.)
country comparison to the world: 69
Electricity—imports: 378 million kWh (2016 est.)
country comparison to the world: 82
Electricity—installed generating capacity: 16.89 million kW (2016
est.)
country comparison to the world: 49
Electricity—from fossil fuels: 29% of total installed capacity
(2016 est.)
country comparison to the world: 184
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 67
Electricity—from hydroelectric plants: 69% of total installed
Capacity (2017 est.) country comparison to the world: 17
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.) country comparison to the world: 137
Crude oil—production: 863,000 bbl/day (2018 est.)
country comparison to the world: 22
Crude oil—exports: 726,700 bbl/day (2015 est.)
country comparison to the world: 18
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 110
Crude oil—proved reserves: 1.665 billion bbl (1 January 2018
est.)
country comparison to the world: 36
Refined petroleum products—production: 303,600 bbl/day (2015
est.)
country comparison to the world: 41
Refined petroleum products—consumption: 333,000 bbl/day (2016
est.)
country comparison to the world: 40
Refined petroleum products—exports: 56,900 bbl/day (2015 est.)
country comparison to the world: 52
Refined petroleum products—imports: 57,170 bbl/day (2015 est.)
country comparison to the world: 74
Natural gas—production: 10.02 billion cu m (2017 est.)
country comparison to the world: 41
Natural gas—consumption: 10.08 billion cu m (2017 est.)
country comparison to the world: 48
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 83
Natural gas—imports: 48.14 million cu m (2017 est.)
country comparison to the world: 76
Natural gas—proved reserves: 113.9 billion cu m (1 January
2018 est.)
country comparison to the world: 49
Carbon dioxide emissions from consumption of energy: 95.59 million
Mt (2017 est.) country comparison to the world: 45
Electricity access: population without electricity: 200,000
(2017) electrification—total population: 77.8% (2016)
electrification—urban areas: 92.1% (2016)
electrification—rural areas: 72.2% (2016)
Electricity—production: 42 million kWh (2016 est.)
country comparison to the world: 207
Electricity—consumption: 39.06 million kWh (2016 est.)
country comparison to the world: 207
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 122
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 136
Electricity—installed generating capacity: 27,000 kW (2016 est.)
country comparison to the world: 203
Electricity—from fossil fuels: 96% of total installed capacity
(2016 est.)
country comparison to the world: 38
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 68
Electricity—from hydroelectric plants: 4% of total installed
capacity (2017 est.) country comparison to the world: 131
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 181
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 122
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 107
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 111
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 118
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 131
Refined petroleum products—consumption: 1,300 bbl/day (2016
est.)
country comparison to the world: 202
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 144
Refined petroleum products—imports: 1,241 bbl/day (2015 est.)
country comparison to the world: 198
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 117
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 133
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 84
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 107
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 123
Carbon dioxide emissions from consumption of energy: 193,600 Mt
(2017 est.)
country comparison to the world: 201
Electricity access: electrification—total population: 84.2%
(2016) electrification—urban areas: 90.2% (2016)
electrification—rural areas: 81.9% (2016)
Electricity—production: 1.01 billion kWh (2016 est.)
country comparison to the world: 151
Electricity—consumption: 790.1 million kWh (2016 est.)
country comparison to the world: 161
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 146
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 158
Electricity—installed generating capacity: 428,000 kW (2016 est.)
country comparison to the world: 151
Electricity—from fossil fuels: 89% of total installed capacity
(2016 est.)
country comparison to the world: 57
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 105
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 177
Electricity—from other renewable sources: 11% of total installed
capacity (2017 est.) country comparison to the world: 78
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 147
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 135
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 139
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 143
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 155
Refined petroleum products—consumption: 14,000 bbl/day (2016
est.)
country comparison to the world: 154
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 164
Refined petroleum products—imports: 13,720 bbl/day (2015 est.)
country comparison to the world: 140
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 144
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 157
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 119
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 137
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 145
Carbon dioxide emissions from consumption of energy: 2.131 million
Mt (2017 est.)
country comparison to the world: 158
Electricity access: DOpUulation without electricity: 8 million
(2017) electrification—total population: 38.7% (2016)
electrification—urban areas: 65.4% (2016)
electrification—rural areas: 0.5% (2016)
Electricity—production: 1.023 billion kWh (2016 est.) country
comparison to the world: 149
Electricity—consumption: 406.2 million kWh (2016 est.)
country comparison to the world: 173
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 147
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 159
Electricity—installed generating capacity: 332,000 kW (2016 est.)
country comparison to the world: 155
Electricity—from fossil fuels: 82% of total installed capacity
(2016 est.)
country comparison to the world: 78
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 106
Electricity—from hydroelectric plants: 18% of total installed
Capacity (2017 est.)
country comparison to the world: 94
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 191
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 148
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 136
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 140
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 144
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 156
Refined petroleum products—consumption: 21,000 bbl/day (2016
est.)
country comparison to the world: 137
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 165
Refined petroleum products—imports: 20,030 bbl/day (2015 est.)
country comparison to the world: 122
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 145
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 158
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 120
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 138
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 146
Carbon dioxide emissions from consumption of energy: 3.595 million
Mt (2017 est.)
country comparison to the world: 141
Electricity access: electrification—total population: 87.2%
(2016) electrification—urban areas: 96.4% (2016)
electrification—rural areas: 69.3% (2016)
Electricity—production: 1.967 billion kWh (2016 est.)
country comparison to the world: 138
Electricity—consumption: 1.75 billion kWh (2016 est.)
country comparison to the world: 144
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 204
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 206
Electricity—installed generating capacity: 504,000 kW (2016 est.)
country comparison to the world: 149
Electricity—from fossil fuels: 61% of total installed capacity
(2016 est.) country comparison to the world: 129
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 189
Electricity—from hydroelectric plants: 38% of total installed
capacity (2017 est.) country comparison to the world: 56
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.) country comparison to the world: 145
Crude oil—production: 17,000 bbl/day (2018 est.)
country comparison to the world: 70
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 200
Crude oil—imports: 820 bbl/day (2015 est.)
country comparison to the world: 80
Crude oil—proved reserves: 84.2 million bbl (1 January 2018
est.)
country comparison to the world: 70
Refined petroleum products—production: 7,071 bbl/day (2015 est.)
country comparison to the world: 101
Refined petroleum products—consumption: 13,000 bbl/day (2016
est.)
country comparison to the world: 157
Refined petroleum products—exports: 14,000 bbl/day (2015 est.)
country comparison to the world: 74
Refined petroleum products—imports: 10,700 bbl/day (2015 est.)
country comparison to the world: 145
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 202
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 203
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 191
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 194
Natural gas—proved reserves: (0 cu m (1 January 2011 est.)
country comparison to the world: 198
Carbon dioxide emissions from consumption of energy: 2.075 million
Mt (2017 est.) country comparison to the world: 159
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 13.13 billion kWh (2016 est.)
country comparison to the world: 92
Electricity—consumption: 10.77 billion kWh (2016 est.)
country comparison to the world: 93
Electricity—exports: 1.321 billion kWh (2015 est.)
country comparison to the world: 53
Electricity—imports: 24 million kWh (2016 est.)
country comparison to the world: 111
Electricity—installed generating capacity: 4.808 million kW (2016
est.)
country comparison to the world: 81
Electricity—from fossil fuels: 29% of total installed capacity
(2016 est.)
country comparison to the world: 185
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 205
Electricity—from hydroelectric plants: 29% of total installed
Capacity (2017 est.)
country comparison to the world: 72
Electricity—from other renewable sources: 42% of total installed
capacity (2017 est.) country comparison to the world: 5
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 213
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 212
Crude oil—imports: 40,200 bbl/day (2015 est.)
country comparison to the world: 57
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 209
Refined petroleum products—production: 42,220 bbl/day (2015
est.)
country comparison to the world: 81
Refined petroleum products—consumption: 53,000 bbl/day (2016
est.)
country comparison to the world: 101
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 214
Refined petroleum products—imports: 9,591 bbl/day (2015 est.)
country comparison to the world: 150
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 211
Natural gas—consumption: 70.79 million cu m (2017 est.)
country comparison to the world: 110
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 207
Natural gas—imports: 70.79 million cu m (2017 est.)
country comparison to the world: 75
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 204
Carbon dioxide emissions from consumption of energy: 7.554 million
Mt (2017 est.)
country comparison to the world: 122
Electricity access: electrification—total population: 99.6%
(2016) electrification—urban areas: 100% (2016)
electrification—rural areas: 96.4% (2016)
Electricity—production: 109.3 billion kWh (2016 est.)
country comparison to the world: 34
Electricity—consumption: 71.96 billion kWh (2016 est.)
country comparison to the world: 39
Electricity—exports: 0 kWh (2015 est.)
country comparison to the world: 215
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 216
Electricity—installed generating capacity: 31 million kW (2016
est.)
country comparison to the world: 32
Electricity—from fossil fuels: 51% of total installed capacity
(2016 est.) country comparison to the world: 150
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 208
Electricity—from hydroelectric plants: 49% of total installed
capacity (2017 est.) country comparison to the world: 43
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 213
Crude oil—production: 1.484 million bbl/day (2018 est.)
country comparison to the world: 16
Crude oil—exports: 1.656 million bbl/day (2015 est.)
country comparison to the world: 8
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 212
Crude oil—proved reserves: 302.3 billion bbl (1 January 2018
est.)
country comparison to the world: 1
Refined petroleum products—production: 926,300 bbl/day (2015
est.)
country comparison to the world: 20
Refined petroleum products—consumption: 659,000 bbl/day (2016
est.)
country comparison to the world: 29
Refined petroleum products—exports: 325,800 bbl/day (2015 est.)
country comparison to the world: 27
Refined petroleum products—imports: 20,640 bbl/day (2015 est.)
country comparison to the world: 117
Natural gas—production: 27.07 billion cu m (2017 est.)
country comparison to the world: 28
Natural gas—consumption: 24.21 billion cu m (2017 est.)
country comparison to the world: 33
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 209
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 209
Natural gas—proved reserves: 5.739 trillion cu m (1 January
2018 est.)
country comparison to the world: 7
Carbon dioxide emissions from consumption of energy: 129.9 million
Mt (2017 est.) country comparison to the world: 36
Electricity access: DOpulation without electricity: 1 million
(2017) electrification—total population: 99% (2017)
electrification—urban areas: 100% (2017)
electrification—rural areas: 98% (2017)
Electricity—production: 158.2 billion kWh (2016 est.)
country comparison to the world: 24
Electricity—consumption: 143.2 billion kWh (2016 est.)
country comparison to the world: 25
Electricity—exports: 713 million kWh (2017 est.)
country comparison to the world: 63
Electricity—imports: 2.733 billion kWh (2016 est.)
country comparison to the world: 51
Electricity—installed generating capacity: 40.77 million kW (2016
est.)
country comparison to the world: 25
Electricity—from fossil fuels: 56% of total installed capacity
(2016 est.) country comparison to the world: 140
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 209
Electricity—from hydroelectric plants: 43% of total installed
capacity (2017 est.) country comparison to the world: 47
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 171
Crude oil—production: 242,000 bbl/day (2018 est.)
country comparison to the world: 33
Crude oil—exports: 324,600 bbl/day (2015 est.)
country comparison to the world: 25
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 213
Crude oil—proved reserves: 4.4 billion bbl (1 January 2018 est.)
country comparison to the world: 25
Refined petroleum products—production: 153,800 bbl/day (2015
est.)
country comparison to the world: 58
Refined petroleum products—consumption: 438,000 bbl/day (2016
est.)
country comparison to the world: 35
Refined petroleum products—exports: 25,620 bbl/day (2015 est.)
country comparison to the world: 67
Refined petroleum products—imports: 282,800 bbl/day (2015 est.)
country comparison to the world: 25
Natural gas—production: 8.098 billion cu m (2017 est.)
country comparison to the world: 44
Natural gas—consumption: 8.098 billion cu m (2017 est.)
country comparison to the world: 52
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 210
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 210
Natural gas—proved reserves: 699.4 billion cu m (1 January
2018 est.)
country comparison to the world: 27
Carbon dioxide emissions from consumption of energy: 235.3 million
Mt (2017 est.) country comparison to the world: 29
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 704 million kWh (2016 est.)
country comparison to the world: 157
Electricity—consumption: 654.7 million kWh (2016 est.)
country comparison to the world: 162
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 216
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 217
Electricity—installed generating capacity: 325,000 kW (2016 est.)
country comparison to the world: 157
Electricity—from fossil fuels: 98% of total installed capacity
(2016 est.) country comparison to the world: 30
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 210
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.) country comparison to the world: 212
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.) country comparison to the world: 146
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 215
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 214
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 214
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 211
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 214
Refined petroleum products—consumption: 1,240 bbl/day (2016
est.)
country comparison to the world: 204
Refined petroleum products—exports: 3,285 bbl/day (2015 est.)
country comparison to the world: 97
Refined petroleum products—imports: 23,480 bbl/day (2015 est.)
country comparison to the world: 112
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 213
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 212
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 211
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 211
Natural gas—proved reserves: (0 Cu m (1 January 2014 est.)
country comparison to the world: 206
Carbon dioxide emissions from consumption of energy: 2.764 million
Mt (2017 est.) country comparison to the world: 150
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 216','6bc786b50c2c18d8a433e3c2d1a13ee5a8dd991abe44c1b50329407fa69bdffb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5aa1eb46e80edfc8491c7fd81114b53d60d7226e5ae61d5b0ff72442259c1ed',2021,'ME','Montenegro','energy',219,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 16.99 billion kWh (2016 est.)
country comparison to the world: 86
Electricity—consumption: 11.87 billion kWh (2016 est.)
country comparison to the world: 89
Electricity—exports: 6.007 billion kWh (2015 est.)
country comparison to the world: 31
Electricity—imports: 3.084 billion kWh (2016 est.)
country comparison to the world: 49
Electricity—installed generating capacity: 4.676 million kW (2016
est.)
country comparison to the world: 83
Electricity—from fossil fuels: 49% of total installed capacity
(2016 est.)
country comparison to the world: 153
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 53
Electricity—from hydroelectric plants: 51% of total installed
Capacity (2017 est.)
country comparison to the world: 35
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 148
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 113
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 96
Crude oil—imports: 18,480 bbl/day (2015 est.)
country comparison to the world: 64
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 109
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 121
Refined petroleum products—consumption: 32,000 bbl/day (2016
est.)
country comparison to the world: 118
Refined petroleum products—exports: 4,603 bbl/day (2015 est.)
country comparison to the world: 92
Refined petroleum products—imports: 18,280 bbl/day (2015 est.)
country comparison to the world: 129
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 107
Natural gas—consumption: 226.5 million cu m (2017 est.)
country comparison to the world: 103
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 72
Natural gas—imports: 226.5 million cu m (2017 est.)
country comparison to the world: 70
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 113
Carbon dioxide emissions from consumption of energy: 22.07 million
Mt (2017 est.)
country comparison to the world: 84','fa339a749d30d52118fb7d60a74309922f89263d5cde86dd05dddda2770b32c4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16505ac8171b0ce86f0ce83d88d0eca28e105a7907ccf6029d5087a88e7ae9fd',2021,'ZA','South Africa','energy',229,'Electricity access: FElectrification—total population: 60.7%
(2016)
Electrification—urban areas: 77.7% (2016)
Electrification—rural areas: 37.5% (2016)
Electricity—production: 2.527 billion kWh (2016 est.)
country comparison to the world: 135
Electricity—consumption: 3.636 billion kWh (2016 est.)
country comparison to the world: 131
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 109
Electricity—imports: 1.673 billion kWh (2016 est.)
country comparison to the world: 59
Electricity—installed generating capacity: 735,000 kW (2016 est.)
country comparison to the world: 135
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 4
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 54
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 159
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 178
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 114
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 97
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 100
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 110
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 122
Refined petroleum products—consumption: 21,000 bbl/day (2016
est.)
country comparison to the world: 135
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 133
Refined petroleum products—imports: 21,090 bbl/day (2015 est.)
country comparison to the world: 116
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 108
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 124
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 73
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 95
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 114
Carbon dioxide emissions from consumption of energy: 6.235 million
Mt (2017 est.)
country comparison to the world: 127
Electricity access: DOpUulation without electricity: 1 million
(2017)
electrification—total population: 29.7% (2016)
electrification—urban areas: 66% (2016)
electrification—rural areas: 15.7% (2016)
Electricity—production: 510 million kWh (2016 est.)
country comparison to the world: 165
Electricity—consumption: 847.3 million kWh (2016 est.)
country comparison to the world: 160
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 158
Electricity—imports: 373 million kWh (2016 est.)
country comparison to the world: 84
Electricity—installed generating capacity: 80,400 kW (2016 est.)
country comparison to the world: 184
Electricity—from fossil fuels: 0% of total installed capacity (2016
est.)
country comparison to the world: 213
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 127
Electricity—from hydroelectric plants: 100% of total installed
capacity (2017 est.)
country comparison to the world: 1
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 159
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 162
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 154
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 152
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 157
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 165
Refined petroleum products—consumption: 5,000 bbl/day (2016
est.)
country comparison to the world: 179
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 171
Refined petroleum products—imports: 5,118 bbl/day (2015 est.)
country comparison to the world: 170
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 157
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 167
Natural gas-exports:
O cu m (2017 est.)
country comparison to the world: 138
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 148
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 158
Carbon dioxide emissions from consumption of energy: 711,100 Mt
(2017 est.)
country comparison to the world: 177','adbeec9764aeeb589fa85d91a90e641a928c0f5801d6a6f4d888a047edd903e7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d349ca8ba9d4a0b4834dedb972ea8a314bcd054d572b6247212a1b7c2527b4',2021,'PR','Puerto Rico','energy',239,'Electricity—production: 126.3 million kWh (2016 est.)
country comparison to the world: 198
Electricity—consumption: 117.5 million kWh (2016 est.)
country comparison to the world: 200
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 110
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 128
Electricity—installed generating capacity: 45,200 kW (2016 est.)
country comparison to the world: 193
Electricity—from fossil fuels: 97% of total installed capacity
(2016 est.)
country comparison to the world: 33
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 55
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 160
Electricity—from other renewable sources: 3% of total installed
capacity (2017 est.)
country comparison to the world: 122
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 115
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 98
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 101
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 111
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 123
Refined petroleum products—consumption: 20,000 bbl/day (2016
est.)
country comparison to the world: 141
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 134
Refined petroleum products—imports: 1,227 bbl/day (2015 est.)
country comparison to the world: 200
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 109
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 125
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 74
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 96
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 115
Carbon dioxide emissions from consumption of energy: 183,300 Mt
(2017 est.)
country comparison to the world: 202
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 4.014 billion kWh (2016 est.)
country comparison to the world: 127
Electricity—consumption: 3.771 billion kWh (2016 est.)
country comparison to the world: 129
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 111
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 129
Electricity—installed generating capacity: 821,000 kW (2016 est.)
country comparison to the world: 134
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 5
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 56
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 161
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 179
Crude oil—production: 100,000 bbl/day (2018 est.)
country comparison to the world: 42
Crude oil—exports: 127,400 bbl/day (2015 est.)
country comparison to the world: 33
Crude oil—imports: 160 bbl/day (2015 est.)
country comparison to the world: 82
Crude oil—proved reserves: 1.1 billion bbl (1 January 2018 est.)
country comparison to the world: 39
Refined petroleum products—production: 10,310 bbl/day (2015
est.)
country comparison to the world: 100
Refined petroleum products—consumption: 18,000 bbl/day (2016
est.)
country comparison to the world: 144
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 135
Refined petroleum products—imports: 6,948 bbl/day (2015 est.)
country comparison to the world: 159
Natural gas—production: 12.74 billion cu m (2017 est.)
country comparison to the world: 38
Natural gas—consumption: 3.936 billion cu m (2017 est.)
country comparison to the world: 66
Natural gas—exports: 8.268 billion cu m (2017 est.)
country comparison to the world: 23
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 97
Natural gas—proved reserves: 260.5 billion cu m (1 January
2018 est.)
country comparison to the world: 39
Carbon dioxide emissions from consumption of energy: 10.04 million
Mt (2017 est.)
country comparison to the world: 107
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 20.95 billion kWh (2016 est.)
country comparison to the world: 75
Electricity—consumption: 19.48 billion kWh (2016 est.)
country comparison to the world: 72
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 185
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 187
Electricity—installed generating capacity: 6.294 million kW (2016
est.)
country comparison to the world: 76
Electricity—from fossil fuels: 94% of total installed capacity
(2016 est.)
country comparison to the world: 47
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 168
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 142
Electricity—from other renewable sources: 4% of total installed
Capacity (2017 est.)
country comparison to the world: 117
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 188
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 181
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 182
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 183
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 190
Refined petroleum products—consumption: 98,000 bbl/day (2016
est.)
country comparison to the world: 81
Refined petroleum products—exports: 18,420 bbl/day (2015 est.)
country comparison to the world: 70
Refined petroleum products—imports: 127,100 bbl/day (2015 est.)
country comparison to the world: 46
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 185
Natural gas—consumption: 1.303 billion cu m (2017 est.)
country comparison to the world: 86
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 170
Natural gas—imports: 1.303 billion cum (2017 est.)
country comparison to the world: 57
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 183
Carbon dioxide emissions from consumption of energy: 19.85 million
Mt (2017 est.)
country comparison to the world: 87
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 39.78 billion kWh (2016 est.)
country comparison to the world: 58
Electricity—consumption: 37.24 billion kWh (2016 est.) country
comparison to the world: 58
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 186
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 188
Electricity—installed generating capacity: 8.796 million kW (2016
est.) country comparison to the world: 66
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.) country comparison to the world: 15
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 169
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 193
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 163
Crude oil—production: 1.464 million bbl/day (2018 est.) country
comparison to the world: 17
Crude oil—exports: 1.15 million bbl/day (2015 est.) country
comparison to the world: 13
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 183
Crude oil—proved reserves: 25.24 billion bbl (1 January 2018
est.) country comparison to the world: 13
Refined petroleum products—production: 273,800 bbl/day (2015
est.) country comparison to the world: 46
Refined petroleum products—consumption: 277,000 bbl/day (2016
est.) country comparison to the world: 45
Refined petroleum products—exports: 485,000 bbl/day (2015 est.)
country comparison to the world: 18
Refined petroleum products—imports: 12,300 bbl/day (2015 est.)
country comparison to the world: 143
Natural gas—production: 166.4 billion cu m (2017 est.) country
comparison to the world: 4
Natural gas—consumption: 39.9 billion cu m (2017 est.) country
comparison to the world: 26
Natural gas—exports: 126.5 billion cu m (2017 est.) country
comparison to the world: 2
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 176
Natural gas—proved reserves: 24.07 trillion cu m (1 January
2018 est.) country comparison to the world: 3
Carbon dioxide emissions from consumption of energy: 114.2 million
Mt (2017 est.) country comparison to the world: 40','7c9ddd55f2d6a55d835c26411538c5dec9c46e74804db7744fc6a20f54f6c32d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ca99e172407059773ec39be6876f0679a4478f7c14747c215fa9ebd5dad8fcb',2021,'MM','Myanmar','energy',251,'Electricity access: electrification—total population: 57%
(2016)
electrification—urban areas: 89.5% (2016)
electrification—rural areas: 39.8% (2016)
Electricity—production: 17.32 billion kWh (2016 est.)
country comparison to the world: 83
Electricity—consumption: 14.93 billion kWh (2016 est.)
country comparison to the world: 81
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 113
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 130
Electricity—installed generating capacity: 5.205 million kW (2016
est.)
country comparison to the world: 79
Electricity—from fossil fuels: 39% of total installed capacity
(2016 est.)
country comparison to the world: 171
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 58
Electricity—from hydroelectric plants: 61% of total installed
Capacity (2017 est.)
country comparison to the world: 28
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.)
country comparison to the world: 149
Crude oil—production: 11,000 bbl/day (2018 est.)
country comparison to the world: 77
Crude oil—exports: 1,824 bbl/day (2015 est.)
country comparison to the world: 71
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 103
Crude oil—proved reserves: 139 million bbl (1 January 2018
est.)
country comparison to the world: 63
Refined petroleum products—production: 13,330 bbl/day (2017
est.)
country comparison to the world: 97
Refined petroleum products—consumption: 123,000 bbl/day (2016
est.)
country comparison to the world: 73
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 137
Refined petroleum products—imports: 102,600 bbl/day (2015 est.)
country comparison to the world: 53
Natural gas—production: 18.41 billion cu m (2017 est.)
country comparison to the world: 33
Natural gas—consumption: 4.502 billion cu m (2017 est.)
country comparison to the world: 63
Natural gas—exports: 14.07 billion cu m (2017 est.)
country comparison to the world: 16
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 99
Natural gas—proved reserves: 637.1 billion cu m (1 January
2018 est.)
country comparison to the world: 29
Carbon dioxide emissions from consumption of energy: 27.01 million
Mt (2017 est.)
country comparison to the world: 77','7a2726d9227f4c6cfb33333cf8ecdef0e837ba39d5ff70a91db27e88498093d6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd96e32bd3b2a748fe0b0bea7cd8646ce2f7f7dedfff328eecc98da056e95709',2021,'BI','Burundi','energy',260,'Electricity access: DOpUulation without electricity: 10 million
(2017) electrification—total population: 7.6% (2016)
electrification—urban areas: 49.7% (2016)
electrification—rural areas: 1.7% (2016)
Electricity—production: 304 million kWh (2016 est.)
country comparison to the world: 183
Electricity—consumption: 382.7 million kWh (2016 est.)
country comparison to the world: 176
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 114
Electricity—imports: 100 million kWh (2016 est.)
country comparison to the world: 100
Electricity—installed generating capacity: 68,000 kW (2016 est.)
country comparison to the world: 186
Electricity—from fossil fuels: 14% of total installed capacity
(2016 est.)
country comparison to the world: 200
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 59
Electricity—from hydroelectric plants: 73% of total installed
Capacity (2017 est.)
country comparison to the world: 14
Electricity—from other renewable sources: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 61
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 117
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 101
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 104
Crude oil-proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 113
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 125
Refined petroleum products—consumption: 1,500 bbl/day (2016
est.)
country comparison to the world: 200
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 138
Refined petroleum products—imports: 1,374 bbl/day (2015 est.)
country comparison to the world: 196
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 111
Natural gas-consumption: 0 cu m (2017 est.)
country comparison to the world: 127
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 76
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 100
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 117
Carbon dioxide emissions from consumption of energy: 217,000 Mt
(2017 est.)
country comparison to the world: 199','254aa6faedf78d1e87c36251f69600aa402d4acb2c4700f33e24fdd680cdacbb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff2f801922239abcd719132d9ffbbba96b09d92371c4bc93625bc74abd097f88',2021,'CV','Cabo Verde','energy',269,'Electricity access: electrification—total population: 92.6%
(2016) electrification—urban areas: 93% (2016)
electrification—rural areas: 91.8% (2016)
Electricity-production:
395 million kWh (2016 est.)
country comparison to the world: 172
Electricity—consumption: 367.4 million kWh (2016 est.)
country comparison to the world: 179
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 115
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 131
Electricity—installed generating capacity: 162,500 kW (2016 est.)
country comparison to the world: 171
Electricity—from fossil fuels: 79% of total installed capacity
(2016 est.)
country comparison to the world: 84
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 60
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 162
Electricity—from other renewable sources: 21% of total installed
capacity (2017 est.) country comparison to the world: 35
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 118
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 102
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 105
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 114
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 126
Refined petroleum products—consumption: g0,600 bbl/day (2016
est.)
country comparison to the world: 173
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 139
Refined petroleum products—imports: 5,607 bbl/day (2015 est.)
country comparison to the world: 166
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 112
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 128
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 77
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 101
Natural gas—proved reserves: 0 cu m (1 January 2016 est.)
country comparison to the world: 118
Carbon dioxide emissions from consumption of energy: 867,800 Mt
(2017 est.)
country comparison to the world: 172','bf6d72f622ff5853f56ef1afabf6ee77c91bfe71dc5c1b32a9aa207f20757b13','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('478d4b59af556b4c104b3d338cf4553a4ccd8b566dc872eab9388c84790b098d',2021,'TH','Thailand','energy',274,'Electricity access: DOpulation without electricity: 6 (2017)
electrification—total population: 49.8% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 36.5% (2016)
Electricity—production: 5.21 billion kWh (2016 est.)
country comparison to the world: 121
Electricity—consumption: 5.857 billion kWh (2016 est.)
country comparison to the world: 117
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 116
Electricity—imports: 1.583 billion kWh (2016 est.)
country comparison to the world: 60
Electricity—installed generating capacity: 1.697 million kW (2016
est.)
country comparison to the world: 119
Electricity—from fossil fuels: 35% of total installed capacity
(2016 est.)
country comparison to the world: 178
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 61
Electricity—from hydroelectric plants: 63% of total installed
Capacity (2017 est.)
country comparison to the world: 27
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.) country comparison to the world: 136
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 119
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 103
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 106
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 115
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 127
Refined petroleum products—consumption: 45,000 bbl/day (2016
est.)
country comparison to the world: 108
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 140
Refined petroleum products—imports: 43,030 bbl/day (2015 est.)
country comparison to the world: 86
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 113
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 129
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 78
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 102
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 119
Carbon dioxide emissions from consumption of energy: 10.55 million
Mt (2017 est.)
country comparison to the world: 104','b135dfafc6da18179d33502829d2e049e6cb0b91f66f87571aa75d5dac56c96c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e356dd9d5a440cd0e4d6a5aa4b4a79f078a08bb3b3e12dc51aa7aa67a74af37e',2021,'CM','Cameroon','energy',287,'Electricity access: DOpUulation without electricity: 9 million
(2017) electrification—total population: 60.1% (2016)
electrification—urban areas: 91.9% (2016)
electrification—rural areas: 21.3% (2016)
Electricity—production: 8.108 billion kWh (2016 est.)
country comparison to the world: 109
Electricity—consumption: 6.411 billion kWh (2016 est.)
country comparison to the world: 113
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 117
Electricity—imports: 55 million kWh (2016 est.)
country comparison to the world: 105
Electricity—installed generating capacity: 1.558 million kW (2016
est.)
country comparison to the world: 122
Electricity—from fossil fuels: 52% of total installed capacity
(2016 est.)
country comparison to the world: 145
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 62
Electricity—from hydroelectric plants: 47% of total installed
Capacity (2017 est.)
country comparison to the world: 44
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.) country comparison to the world: 150
Crude oil—production: 69,000 bbl/day (2018 est.)
country comparison to the world: 47
Crude oil—exports: 96,370 bbl/day (2015 est.)
country comparison to the world: 35
Crude oil—imports: 36,480 bbl/day (2015 est.)
country comparison to the world: 59
Crude oil—proved reserves: 200 million bbl (1 January 2018
est.)
country comparison to the world: 55
Refined petroleum products—production: 39,080 bbl/day (2015
est.)
country comparison to the world: 82
Refined petroleum products—consumption: 45,000 bbl/day (2016
est.)
country comparison to the world: 109
Refined petroleum products—exports: 8,545 bbl/day (2015 est.)
country comparison to the world: 84
Refined petroleum products—imports: 14,090 bbl/day (2015 est.)
country comparison to the world: 138
Natural gas—production: 910.4 million cu m (2017 est.)
country comparison to the world: 69
Natural gas—consumption: 906.1 million cu m (2017 est.)
country comparison to the world: 93
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 79
Natural gas-imports: 0 cu m (2017 est.)
country comparison to the world: 103
Natural gas—proved reserves: 135.1 billion cu m (1 January
2018 est.)
country comparison to the world: 48
Carbon dioxide emissions from consumption of energy: 7.672 million
Mt (2017 est.)
country comparison to the world: 119
Electricity access: DOpulation without electricity: 2 million
(2017) electrification—total population: 56.6% (2016)
electrification—urban areas: 74.2% (2016)
electrification—rural areas: 22.6% (2016)
Electricity—production: 1.696 billion kWh (2016 est.)
country comparison to the world: 143
Electricity—consumption: 912 million kWh (2016 est.)
country comparison to the world: 157
Electricity—exports: 22 million kWh (2015 est.)
country comparison to the world: 90
Electricity—imports: 18 million kWh (2016 est.)
country comparison to the world: 115
Electricity—installed generating capacity: 591,500 kW (2016 est.)
country comparison to the world: 139
Electricity—from fossil fuels: 64% of total installed capacity
(2016 est.)
country comparison to the world: 121
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 70
Electricity—from hydroelectric plants: 36% of total installed
Capacity (2017 est.)
country comparison to the world: 59
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 183
Crude oil—production: 340,000 bbl/day (2018 est.)
country comparison to the world: 30
Crude oil—exports: 254,100 bbl/day (2015 est.)
country comparison to the world: 28
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 113
Crude oil—proved reserves: 1.6 billion bbl (1 January 2018 est.)
country comparison to the world: 37
Refined petroleum products—production: 15,760 bbl/day (2015
est.)
country comparison to the world: 93
Refined petroleum products—consumption: 17,000 bbl/day (2016
est.)
country comparison to the world: 149
Refined petroleum products—exports: 5,766 bbl/day (2015 est.)
country comparison to the world: 89
Refined petroleum products—imports: 7,162 bbl/day (2015 est.)
country comparison to the world: 156
Natural gas—production: 1.387 billion cu m (2017 est.)
country comparison to the world: 61
Natural gas—consumption: 1.387 billion cu m (2017 est.)
country comparison to the world: 85
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 86
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 109
Natural gas—proved reserves: 90.61 billion cu m (1 January
2018 est.)
country comparison to the world: 54
Carbon dioxide emissions from consumption of energy: 5.239 million
Mt (2017 est.)
country comparison to the world: 134
Electricity—production: 34 million kWh (2016 est.)
country comparison to the world: 209
Electricity—consumption: 31.62 million kWh (2016 est.)
country comparison to the world: 209
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 123
Electricity—imports: 0 KWh (2016 est.)
country comparison to the world: 137
Electricity—installed generating capacity: 14,000 kW (2016 est.)
country comparison to the world: 207
Electricity—from fossil fuels: 79% of total installed capacity
(2016 est.)
country comparison to the world: 85
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 71
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.)
country comparison to the world: 165
Electricity—from other renewable sources: 21% of total installed
capacity (2017 est.) country comparison to the world: 36
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 123
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 108
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 114
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 119
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 133
Refined petroleum products—consumption: 600 bbl/day (2016 est.)
country comparison to the world: 209
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 146
Refined petroleum products—imports: 611 bbl/day (2015 est.)
country comparison to the world: 205
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 119
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 135
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 87
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 110
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 124
Carbon dioxide emissions from consumption of energy: 88,810 Mt
(2017 est.)
country comparison to the world: 207','9646f7f91be84e95ab6620a9b03cc503e61fb66fb5048554e37804c7d59977ff','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db8839f329bb07958013567a61e3529172061204e409d0cad81a9758ce776983',2021,'CA','Canada','energy',296,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 649.6 billion kWh (2016 est.)
country comparison to the world: 6
Electricity—consumption: 522.2 billion kWh (2016 est.)
country comparison to the world: 7
Electricity—exports: 73.35 billion kWh (2016 est.)
country comparison to the world: 2
Electricity—imports: 2.682 billion kWh (2016 est.)
country comparison to the world: 52
Electricity—installed generating capacity: 143.5 million kW (2016
est.)
country comparison to the world: 8
Electricity—from fossil fuels: 23% of total installed capacity
(2016 est.)
country comparison to the world: 191
Electricity—from nuclear fuels: 9% of total installed capacity
(2017 est.)
country comparison to the world: 16
Electricity—from hydroelectric plants: 56% of total installed
Capacity (2017 est.)
country comparison to the world: 30
Electricity—from other renewable sources: 12% of total installed
capacity (2017 est.) country comparison to the world: 73
Crude oil—production: 4.264 million bbl/day (2018 est.)
country comparison to the world: 5
Crude oil—exports: 2.818 million bbl/day (2017 est.)
country comparison to the world: 4
Crude oil—imports: 806,700 bbl/day (2017 est.)
country comparison to the world: 14
Crude oil—proved reserves: 170.5 billion bbl (1 January 2018
est.)
country comparison to the world: 3
Refined petroleum products—production: 2.009 million bbl/day
(2017 est.)
country comparison to the world: 10
Refined petroleum products—consumption: 2.445 million bbl/day
(2017 est.)
country comparison to the world: 10
Refined petroleum products—exports: 1.115 million bbl/day (2017
est.)
country comparison to the world: 8
Refined petroleum products—imports: 405,700 bbl/day (2017 est.)
country comparison to the world: 21
Natural gas—production: 159.1 billion cu m (2017 est.)
country comparison to the world: 5
Natural gas—consumption: 124.4 billion cu m (2017 est.)
country comparison to the world: 6
Natural gas—exports: 83.96 billion cu m (2017 est.)
country comparison to the world: 5
Natural gas—imports: 26.36 billion cu m (2017 est.)
country comparison to the world: 13
Natural gas—proved reserves: 2.056 trillion cu m (1 January
2018 est.)
country comparison to the world: 16
Carbon dioxide emissions from consumption of energy: 640.6 million
Mt (2017 est.)
country comparison to the world: 9','806ae3cd25745f9fe47a3121a6287dbdbee2642821f4b99d6ecae08267825315','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('910b1af87edbe4a43e36f504b5c9e68ddbadcb9e9282a3d8c82afd848527f03b',2021,'KY','Cayman Islands','energy',303,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 650 million kWh (2016 est.)
country comparison to the world: 160
Electricity—consumption: 612 million kWh (2016 est.)
country comparison to the world: 165
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 118
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 132
Electricity—installed generating capacity: 132,000 kW (2016 est.)
country comparison to the world: 174
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 6
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 63
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 163
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 180
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 120
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 104
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 107
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 116
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 128
Refined petroleum products—consumption: 4,400 bbl/day (2016
est.)
country comparison to the world: 181
Refined petroleum products—exports: QO bbl/day (2015 est.)
country comparison to the world: 141
Refined petroleum products—imports: 4,285 bbl/day (2015 est.)
country comparison to the world: 175
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 114
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 130
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 80
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 104
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 120
Carbon dioxide emissions from consumption of energy: 643,800 Mt
(2017 est.)
country comparison to the world: 178','d009a81dd36d125331662281c9d1834927ceb3ff5a7553ff2cf3710e59305d59','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ac97c57958075cd049571577bf3f116e14db4f4e7913b160d07b0532d1bf996',2021,'CG','Congo','energy',312,'Electricity access: DOpulation without electricity: 5 million
(2017) electrification—total population: 14% (2016)
electrification—urban areas: 34.1% (2016)
electrification—rural areas: 0.4% (2016)
Electricity—production: 171.4 million kWh (2016 est.)
country comparison to the world: 194
Electricity—consumption: 159.4 million kWh (2016 est.)
country comparison to the world: 196
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 119
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 133
Electricity—installed generating capacity: 38,300 kW (2016 est.)
country comparison to the world: 197
Electricity—from fossil fuels: 50% of total installed capacity
(2016 est.)
country comparison to the world: 151
Electricity-from nuclear fuels:
0% of total installed capacity (2017 est.)
country comparison to the world: 64
Electricity—from hydroelectric plants: 50% of total installed
capacity (2017 est.)
country comparison to the world: 40
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 151
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 121
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 105
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 108
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 117
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 129
Refined petroleum products—consumption: 2,800 bbl/day (2016
est.)
country comparison to the world: 189
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 142
Refined petroleum products-imports: 2,799 bbl/day (2015 est.)
country comparison to the world: 185
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 115
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 131
Natural gas-exports: 0 cu m (2017 est.)
country comparison to the world: 81
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 105
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 121
Carbon dioxide emissions from consumption of energy: 413,800 Mt
(2017 est.)
country comparison to the world: 187
Electricity access: DOpulation without electricity: 7 million
(2017) electrification—total population: 43% (2017)
electrification—urban areas: 69% (2017)
electrification—rural areas: 37% (2017)
Electricity—production: 525 million kWh (2016 est.)
country comparison to the world: 164
Electricity—consumption: 527.3 million kWh (2016 est.)
country comparison to the world: 169
Electricity—exports: 4 million kWh (2015 est.)
country comparison to the world: 92
Electricity—imports: 42 million kWh (2016 est.)
country comparison to the world: 108
Electricity—installed generating capacity: 191,000 kW (2016 est.)
country comparison to the world: 166
Electricity—from fossil fuels: 42% of total installed capacity
(2016 est.)
country comparison to the world: 164
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 170
Electricity—from hydroelectric plants: 51% of total installed
capacity (2017 est.) country comparison to the world: 37
Electricity—from other renewable sources: 7% of total installed
capacity (2017 est.) country comparison to the world: 96
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 189
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 182
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 184
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 184
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 191
Refined petroleum products—consumption: 6,700 bbl/day (2016
est.)
country comparison to the world: 167
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 192
Refined petroleum products—imports: 6,628 bbl/day (2015 est.)
country comparison to the world: 162
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 186
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 188
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 171
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 177
Natural gas—proved reserves: 56.63 billion cu m (1 January
2018 est.)
country comparison to the world: 61
Carbon dioxide emissions from consumption of energy: 985,600 Mt
(2017 est.)
country comparison to the world: 169
Electricity—production: 7 million kWh (2016 est.)
country comparison to the world: 215
Electricity—consumption: 6.51 million kWh (2016 est.)
country comparison to the world: 214
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 187
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 189
Electricity—installed generating capacity: 8,000 kW (2016 est.)
country comparison to the world: 210
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 16
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 171
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 194
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 205
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 190
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 183
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 185
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 185
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 192
Refined petroleum products—consumption: 70 bbl/day (2016 est.)
country comparison to the world: 214
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 193
Refined petroleum products—imports: 65 bbl/day (2015 est.)
country comparison to the world: 210
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 187
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 189
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 172
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 178
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 184
Carbon dioxide emissions from consumption of energy: 10,650 Mt
(2017 est.)
country comparison to the world: 212','d7bb0f91a9e0d414e690794f9ca30a881858b38a3f43cc5c01ffe87aa5674710','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64424babc5dbee534671fcf30a6ca8c7f1ced3fe3c90cee97b424ab031ee90a3',2021,'TD','Chad','energy',321,'Electricity access: DOpUulation without electricity: 14 million
(2017) electrification—total population: 8.8% (2016)
electrification—urban areas: 31.4% (2016)
electrification—rural areas: 2.2% (2016)
Electricity—production: 224.3 million kWh (2016 est.)
country comparison to the world: 190
Electricity—consumption: 208.6 million kWh (2016 est.)
country comparison to the world: 192
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 120
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 134
Electricity—installed generating capacity: 48,200 kW (2016 est.)
country comparison to the world: 192
Electricity—from fossil fuels: 98% of total installed capacity
(2016 est.)
country comparison to the world: 28
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 65
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 164
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 123
Crude oil—production: 132,000 bbl/day (2018 est.)
country comparison to the world: 40
Crude oil—exports: 70,440 bbl/day (2015 est.)
country comparison to the world: 37
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 109
Crude oil—proved reserves: 1.5 billion bbl (1 January 2018 est.)
country comparison to the world: 38
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 130
Refined petroleum products—consumption: 2,300 bbl/day (2016
est.)
country comparison to the world: 193
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 143
Refined petroleum products—imports: 2,285 bbl/day (2015 est.)
country comparison to the world: 189
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 116
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 132
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 82
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 106
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 122
Carbon dioxide emissions from consumption of energy: 342,200 Mt
(2017 est.)
country comparison to the world: 190','4fe42b7cf699f11aaa45a88b005a4ee440e6d85c06f7a650a0161db55444960f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b72b5eeb6cc766c581f6447bb07b0a195d12c536e8d631c1ba587c2cadd968b',2021,'CN','China','energy',338,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 5.883 trillion kWh (2016 est.)
country comparison to the world: 1
Electricity—consumption: 5.564 trillion kWh (2016 est.)
country comparison to the world: 1
Electricity—exports: 18.91 billion kWh (2016 est.)
country comparison to the world: 10
Electricity—imports: 6.185 billion kWh (2016 est.)
country comparison to the world: 33
Electricity—installed generating capacity: 1.653 billion kW (2016
est.)
country comparison to the world: 1
Electricity—from fossil fuels: 62% of total installed capacity
(2016 est.)
country comparison to the world: 124
Electricity—from nuclear fuels: 2% of total installed capacity
(2017 est.)
country comparison to the world: 25
Electricity—from hydroelectric plants: 18% of total installed
Capacity (2017 est.)
country comparison to the world: 93
Electricity—from other renewable sources: 18% of total installed
Capacity (2017 est.)
country comparison to the world: 47
Crude oil—production: 3.773 million bbl/day (2018 est.)
country comparison to the world: 7
Crude oil—exports: 57,310 bbl/day (2015 est.)
country comparison to the world: 40
Crude oil—imports: 6.71 million bbl/day (2015 est.)
country comparison to the world: 2
Crude oil—proved reserves: 25.63 billion bbl (1 January 2018
est.)
country comparison to the world: 12
Refined petroleum products—production: 11.51 million bbl/day
(2015 est.)
country comparison to the world: 2
Refined petroleum products—consumption: 12.47 million bbl/day
(2016 est.)
country comparison to the world: 2
Refined petroleum products—exports: 848,400 bbl/day (2015 est.)
country comparison to the world: 9
Refined petroleum products—imports: 1.16 million bbl/day (2015
est.)
country comparison to the world: 4
Natural gas—production: 145.9 billion cu m (2017 est.)
country comparison to the world: 6
Natural gas—consumption: 238.6 billion cu m (2017 est.)
country comparison to the world: 3
Natural gas—exports: 3.37 billion cu m (2017 est.)
country comparison to the world: 35
Natural gas—imports: 97.63 billion cu m (2017 est.)
country comparison to the world: 3
Natural gas—proved reserves: 5.44 trillion cu m (1 January 2018
est.)
country comparison to the world: 9
Carbon dioxide emissions from consumption of energy: 11.67 billion
Mt (2017 est.)
country comparison to the world: 1
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 35.97 billion kWh (2016 est.)
country comparison to the world: 60
Electricity—consumption: 41.84 billion kWh (2016 est.)
country comparison to the world: 54
Electricity—exports: 1.205 billion kWh (2016 est.)
country comparison to the world: 55
Electricity—imports: 11.62 billion kWh (2016 est.)
country comparison to the world: 21
Electricity—installed generating capacity: 12.63 million kW (2016
est.)
country comparison to the world: 55
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 9
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 108
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 178
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 192
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 150
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 138
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 142
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 146
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 158
Refined petroleum products—consumption: 403,100 bbl/day (2016
est.)
country comparison to the world: 38
Refined petroleum products—exports: 13,570 bbl/day (2015 est.)
country comparison to the world: 76
Refined petroleum products—imports: 402,100 bbl/day (2015 est.)
country comparison to the world: 22
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 147
Natural gas—consumption: 3.37 billion cu m (2017 est.)
country comparison to the world: 69
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 122
Natural gas—imports: 3.37 billion cu m (2017 est.)
country comparison to the world: 43
Natural gas—proved reserves: 0 cu m (1 January 2016 est.)
country comparison to the world: 148
Carbon dioxide emissions from consumption of energy: 102.5 million
Mt (2017 est.)
country comparison to the world: 43
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 30.22 billion kWh (2016 est.)
country comparison to the world: 64
Electricity—consumption: 39.37 billion kWh (2016 est.)
country comparison to the world: 56
Electricity—exports: 5.24 billion kWh (2016 est.)
country comparison to the world: 34
Electricity—imports: 17.95 billion kWh (2016 est.)
country comparison to the world: 13
Electricity—installed generating capacity: 8.639 million kW (2016
est.)
country comparison to the world: 67
Electricity—from fossil fuels: 64% of total installed capacity
(2016 est.)
country comparison to the world: 122
Electricity—from nuclear fuels: 22% of total installed capacity
(2017 est.)
country comparison to the world: 5
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 148
Electricity—from other renewable sources: 13% of total installed
Capacity (2017 est.) country comparison to the world: 67
Crude oil—production: 16,000 bbl/day (2018 est.)
country comparison to the world: 72
Crude oil—exports: 2,713 bbl/day (2017 est.)
country comparison to the world: 69
Crude oil—imports: 121,000 bbl/day (2017 est.)
country comparison to the world: 40
Crude oil—proved reserves: 24 million bbl (1 January 2018 est.)
country comparison to the world: 82
Refined petroleum products—production: 152,400 bbl/day (2017
est.)
country comparison to the world: 59
Refined petroleum products—consumption: 167,700 bbl/day (2017
est.)
country comparison to the world: 62
Refined petroleum products—exports: 58,720 bbl/day (2017 est.)
country comparison to the world: 50
Refined petroleum products—imports: 82,110 bbl/day (2017 est.)
country comparison to the world: 62
Natural gas—production: 1.812 billion cu m (2017 est.)
country comparison to the world: 60
Natural gas—consumption: 10.39 billion cu m (2017 est.)
country comparison to the world: 46
Natural gas—exports: 3.52 billion cu m (2017 est.)
country comparison to the world: 34
Natural gas—imports: 13.37 billion cu m (2017 est.)
country comparison to the world: 24
Natural gas—proved reserves: 6.598 billion cu m (1 January
2018 est.)
country comparison to the world: 83
Carbon dioxide emissions from consumption of energy: 51.28 million
Mt (2017 est.)
country comparison to the world: 59
Electricity access: Electrification—total population: 100%
(2016)
Electricity—production: 18.17 billion kWh (2016 est.)
country comparison to the world: 80
Electricity—consumption: 17.68 billion kWh (2016 est.)
country comparison to the world: 73
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 148
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 160
Electricity—installed generating capacity: 2.772 million kW (2016
est.)
country comparison to the world: 100
Electricity—from fossil fuels: 4% of total installed capacity (2016
est.)
country comparison to the world: 206
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 109
Electricity—from hydroelectric plants: 71% of total installed
Capacity (2017 est.)
country comparison to the world: 16
Electricity—from other renewable sources: 25% of total installed
capacity (2017 est.)
country comparison to the world: 29
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 151
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 139
Crude oil—imports 0 bbl/day (2017 est.)
country comparison to the world: 143
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 147
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 159
Refined petroleum products—consumption: 20,850 bbl/day (2017
est.)
country comparison to the world: 139
Refined petroleum products—exports: 2,530 bbl/day (2017 est.)
country comparison to the world: 101
Refined petroleum products—imports: 20,220 bbl/day (2017 est.)
country comparison to the world: 120
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 148
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 160
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 123
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 140
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 149
Carbon dioxide emissions from consumption of energy: 3.228 million
Mt (2017 est.)
country comparison to the world: 144
Electricity access: DODUlation without electricity: 168 million
(2017) electrification—total population: 84.5% (2016)
electrification—urban areas: 98.4% (2016)
electrification—rural areas: 77.6% (2016)
Electricity—production: 1.386 trillion kWh (2016 est.)
country comparison to the world: 3
Electricity—consumption: 1.137 trillion kWh (2016 est.)
country comparison to the world: 3
Electricity—exports: 5.15 billion kWh (2015 est.)
country comparison to the world: 36
Electricity—imports: 5.617 billion kWh (2016 est.)
country comparison to the world: 35
Electricity—installed generating capacity: 367.8 million kW (2016
est.)
country comparison to the world: 3
Electricity—from fossil fuels: 71% of total installed capacity
(2016 est.)
country comparison to the world: 104
Electricity—from nuclear fuels: 2% of total installed capacity
(2017 est.)
country comparison to the world: 26
Electricity—from hydroelectric plants: 12% of total installed
Capacity (2017 est.)
country comparison to the world: 111
Electricity—from other renewable sources: 16% of total installed
Capacity (2017 est.)
country comparison to the world: 53
Crude oil—production: 709,000 bbl/day (2018 est.)
country comparison to the world: 25
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 140
Crude oil—imports: 4.057 million bbl/day (2015 est.)
country comparison to the world: 3
Crude oil—proved reserves: 4.495 billion bbl (1 January 2018
est.)
country comparison to the world: 23
Refined petroleum products—production: 4.897 million bbl/day
(2015 est.)
country comparison to the world: 4
Refined petroleum products—consumption: 4.521 million bbl/day
(2016 est.)
country comparison to the world: 3
Refined petroleum products—exports: 1.305 million bbl/day (2015
est.)
country comparison to the world: 7
Refined petroleum products—imports: 653,300 bbl/day (2015 est.)
country comparison to the world: 11
Natural gas—production: 31.54 billion cu m (2017 est.)
country comparison to the world: 25
Natural gas—consumption: 55.43 billion cu m (2017 est.)
country comparison to the world: 14
Natural gas—exports: 76.45 million cu m (2017 est.)
country comparison to the world: 50
Natural gas—imports: 23.96 billion cu m (2017 est.)
country comparison to the world: 14
Natural gas—proved reserves: 1.29 trillion cu m (1 January 2018
est.)
country comparison to the world: 22
Carbon dioxide emissions from consumption of energy: 2.383 billion
Mt (2017 est.)
country comparison to the world: 3
Electricity access: DOpulation without electricity: 14 million
(2017) electrification—total population: 97.6% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 94.8% (2016)
Electricity—production: 235.4 billion kWh (2016 est.)
country comparison to the world: 20
Electricity—consumption: 213.4 billion kWh (2016 est.)
country comparison to the world: 20
Electricity—exports: 0 kWh (2017 est.)
country comparison to the world: 149
Electricity—imports: 693 million kWh (2016 est.)
country comparison to the world: 76
Electricity—installed generating capacity: 61.43 million kW (2016
est.)
country comparison to the world: 19
Electricity—from fossil fuels: 85% of total installed capacity
(2016 est.)
country comparison to the world: 71
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 110
Electricity—from hydroelectric plants: 9% of total installed
Capacity (2017 est.)
country comparison to the world: 118
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 99
Crude oil—production: 772,000 bbl/day (2018 est.)
country comparison to the world: 24
Crude oil—exports: 302,300 bbl/day (2015 est.)
country comparison to the world: 27
Crude oil—imports: 498,500 bbl/day (2015 est.)
country comparison to the world: 18
Crude oil—proved reserves: 3.31 billion bbl (1 January 2018
est.)
country comparison to the world: 28
Refined petroleum products—production: 950,000 bbl/day (2015
est.)
country comparison to the world: 18
Refined petroleum products—consumption: 1.601 million bbl/day
(2016 est.)
country comparison to the world: 14
Refined petroleum products—exports: 79,930 bbl/day (2015 est.)
country comparison to the world: 47
Refined petroleum products—imports: 591,500 bbl/day (2015 est.)
country comparison to the world: 15
Natural gas—production: 72.09 billion cu m (2017 est.)
country comparison to the world: 12
Natural gas—consumption: 42.32 billion cu m (2017 est.)
country comparison to the world: 23
Natural gas—exports: 29.78 billion cu m (2017 est.)
country comparison to the world: 12
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 141
Natural gas—proved reserves: 2.866 trillion cu m (1 January
2018 est.)
country comparison to the world: 12
Carbon dioxide emissions from consumption of energy: 540.7 million
Mt (2017 est.)
country comparison to the world: 12
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 272.3 billion kWh (2016 est.)
country comparison to the world: 15
Electricity—consumption: 236.3 billion kWh (2016 est.)
country comparison to the world: 17
Electricity—exports: 6.822 billion kWh (2015 est.)
country comparison to the world: 28
Electricity—imports: 4.221 billion kWh (2016 est.)
country comparison to the world: 44
Electricity—installed generating capacity: 77.6 million kW (2016
est.)
country comparison to the world: 16
Electricity—from fossil fuels: 84% of total installed capacity
(2016 est.)
country comparison to the world: 75
Electricity—from nuclear fuels: 1% of total installed capacity
(2017 est.)
country comparison to the world: 29
Electricity—from hydroelectric plants: 15% of total installed
Capacity (2017 est.)
country comparison to the world: 103
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 193
Crude oil—production: 4.251 million bbl/day (2018 est.)
country comparison to the world: 6
Crude oil—exports: 750,200 bbl/day (2015 est.)
country comparison to the world: 16
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 144
Crude oil—proved reserves: 157.2 billion bbl (1 January 2018
est.)
country comparison to the world: 4
Refined petroleum products—production: 1.764 million bbl/day
(2015 est.)
country comparison to the world: 11
Refined petroleum products—consumption: 1.804 million bbl/day
(2016 est.)
country comparison to the world: 12
Refined petroleum products—exports: 397,200 bbl/day (2015 est.)
country comparison to the world: 21
Refined petroleum products—imports: 64,160 bbl/day (2015 est.)
country comparison to the world: 72
Natural gas—production: 214.5 billion cu m (2017 est.)
country comparison to the world: 3
Natural gas—consumption: 206.9 billion cu m (2017 est.)
country comparison to the world: 4
Natural gas—exports: 11.64 billion cu m (2017 est.)
country comparison to the world: 18
Natural gas—imports: 3.993 billion cu m (2017 est.)
country comparison to the world: 40
Natural gas—proved reserves: 33.72 trillion cu m (1 January
2018 est.)
country comparison to the world: 2
Carbon dioxide emissions from consumption of energy: 638.3 million
Mt (2017 est.)
country comparison to the world: 10
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 75.45 billion kWh (2016 est.)
country comparison to the world: 40
Electricity—consumption: 38.46 billion kWh (2016 est.)
country comparison to the world: 57
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 150
Electricity—imports: 11.97 billion kWh (2016 est.)
country comparison to the world: 20
Electricity—installed generating capacity: 27.09 million kW (2016
est.)
country comparison to the world: 34
Electricity—from fossil fuels: 91% of total installed capacity
(2016 est.)
country comparison to the world: 55
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 111
Electricity—from hydroelectric plants: 9% of total installed
capacity (2017 est.)
country comparison to the world: 119
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 194
Crude oil—production: 4.613 million bbl/day (2018 est.)
country comparison to the world: 4
Crude oil—exports: 3.092 million bbl/day (2015 est.)
country comparison to the world: 3
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 145
Crude oil—proved reserves: 148.8 billion bbl (1 January 2018
est.)
country comparison to the world: 5
Refined petroleum products—production: 398,000 bbl/day (2015
est.)
country comparison to the world: 37
Refined petroleum products—consumption: 826,000 bbl/day (2016
est.)
country comparison to the world: 26
Refined petroleum products—exports: 8,284 bbl/day (2015 est.)
country comparison to the world: 86
Refined petroleum products—imports: 255,100 bbl/day (2015 est.)
country comparison to the world: 28
Natural gas—production: 1.274 billion cu m (2017 est.)
country comparison to the world: 63
Natural gas—consumption: 2.633 billion cu m (2017 est.)
country comparison to the world: 76
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 124
Natural gas—imports: 1.359 billion cu m (2017 est.)
country comparison to the world: 56
Natural gas—proved reserves: 3.82 trillion cu m (1 January 2018
est.)
country comparison to the world: 11
Carbon dioxide emissions from consumption of energy: 117.9 million
Mt (2017 est.)
country comparison to the world: 37
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 929 million kWh (2016 est.)
country comparison to the world: 154
Electricity—consumption: 5.077 billion kWh (2016 est.)
country comparison to the world: 123
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 162
Electricity—imports: 4.306 billion kWh (2016 est.)
country comparison to the world: 43
Electricity—installed generating capacity: 472,000 kW (2016 est.)
country comparison to the world: 150
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 12
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 132
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 184
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 200
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 165
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 157
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 156
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 160
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 168
Refined petroleum products—consumption: 12,700 bbl/day (2016
est.)
country comparison to the world: 158
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 174
Refined petroleum products—imports: 14,180 bbl/day (2015 est.)
country comparison to the world: 137
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 161
Natural gas—consumption: 178.2 million cu m (2017 est.)
country comparison to the world: 107
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 142
Natural gas—imports: 175.5 million cu m (2017 est.)
country comparison to the world: 73
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 162
Carbon dioxide emissions from consumption of energy: 2.563 million
Mt (2017 est.)
country comparison to the world: 153','97055506867e3e7c9ca4794558fc43a790846a7c4bf9852c4232fa0ed4622ea4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baeaf8085a3069b88822d34cefece2cc2ef9767c1a252c1f679b48a1f2ddf5e9',2021,'AO','Angola','energy',361,'Electricity access: DOpulation without electricity: 69 million
(2017) electrification—total population: 17.1% (2016)
electrification—urban areas: 47.2% (2016)
electrification—rural areas: 0.4% (2016)
Electricity—production: 9.046 billion kWh (2016 est.)
country comparison to the world: 106
Electricity—consumption: 7.43 billion kWh (2016 est.)
country comparison to the world: 106
Electricity—exports: 422 million kWh (2015 est.)
country comparison to the world: 70
Electricity—imports: 20 million kWh (2016 est.)
country comparison to the world: 113
Electricity—installed generating capacity: 2.587 million kW (2016
est.)
country comparison to the world: 105
Electricity—from fossil fuels: 2% of total installed capacity (2016
est.)
country comparison to the world: 210
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 69
Electricity—from hydroelectric plants: 98% of total installed
Capacity (2017 est.) country comparison to the world: 4
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 182
Crude oil—production: 17,000 bbl/day (2018 est.)
country comparison to the world: 68
Crude oil—exports: 20,000 bbl/day (2015 est.)
country comparison to the world: 49
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 112
Crude oil—proved reserves: 180 million bbl (1 January 2018
est.)
country comparison to the world: 58
Refined petroleum products-production: 0 bbl/day (2017 est.)
country comparison to the world: 132
Refined petroleum products—consumption: 21,000 bbl/day (2016
est.)
country comparison to the world: 136
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 145
Refined petroleum products—imports: 21,140 bbl/day (2015 est.)
country comparison to the world: 115
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 118
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 134
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 85
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 108
Natural gas—proved reserves: 991.1 million cu m (1 January
2018 est.)
country comparison to the world: 99
Carbon dioxide emissions from consumption of energy: 3.146 million
Mt (2017 est.) country comparison to the world: 145
Electricity access: DOpUulation without electricity: 1 million
(2017)
electrification—total population: 51.8% (2016)
electrification—urban areas: 77.1% (2016)
electrification—rural areas: 28.7% (2016)
Electricity—production: 1.403 billion kWh (2016 est.)
country comparison to the world: 145
Electricity—consumption: 3.891 billion kWh (2016 est.)
country comparison to the world: 128
Electricity—exports: 88 million kWh (2015 est.)
country comparison to the world: 83
Electricity—imports: 3.073 billion kWh (2016 est.)
country comparison to the world: 50
Electricity—installed generating capacity: 535,500 kW (2016 est.)
country comparison to the world: 146
Electricity—from fossil fuels: 28% of total installed capacity
(2016 est.)
country comparison to the world: 187
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 150
Electricity—from hydroelectric plants: 64% of total installed
Capacity (2017 est.)
country comparison to the world: 26
Electricity—from other renewable sources: 8% of total installed
Capacity (2017 est.)
country comparison to the world: 89
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 179
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 171
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 172
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 174
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 183
Refined petroleum products—consumption: 27,000 bbl/day (2016
est.)
country comparison to the world: 125
Refined petroleum products—exports: 80 bbl/day (2015 est.)
country comparison to the world: 120
Refined petroleum products—imports: 26,270 bbl/day (2015 est.)
country comparison to the world: 105
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 175
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 179
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 157
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 162
Natural gas—proved reserves: 62.29 billion cu m (1 January
2018 est.)
country comparison to the world: 60
Carbon dioxide emissions from consumption of energy: 3.958 million
Mt (2017 est.)
country comparison to the world: 139','bdea71ac73949ac17f50e9b7508fec1e85ba98aad37edcc0a08acdb32f553f8d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb1d6b9ee7ca47ea0d2edf9655971e0e250478f50f67221514efc26afb8440a6',2021,'NI','Nicaragua','energy',374,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 10.79 billion kWh (2016 est.)
country comparison to the world: 100
Electricity—consumption: 9.812 billion kWh (2016 est.)
country comparison to the world: 98
Electricity—exports: 643 million kWh (2015 est.)
country comparison to the world: 64
Electricity—imports: 807 million kWh (2016 est.)
country comparison to the world: 72
Electricity—installed generating capacity: 3.584 million kW (2016
est.)
country comparison to the world: 94
Electricity—from fossil fuels: 18% of total installed capacity
(2016 est.)
country comparison to the world: 196
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 72
Electricity—from hydroelectric plants: 64% of total installed
Capacity (2017 est.)
country comparison to the world: 25
Electricity—from other renewable sources: 18% of total installed
capacity (2017 est.) country comparison to the world: 48
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 124
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 109
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 115
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 120
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 134
Refined petroleum products—consumption: 53,000 bbl/day (2016
est.)
country comparison to the world: 100
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 147
Refined petroleum products—imports: 51,320 bbl/day (2015 est.)
country comparison to the world: 80
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 120
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 136
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 88
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 111
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 125
Carbon dioxide emissions from consumption of energy: 7.653 million
Mt (2017 est.)
country comparison to the world: 120
Electricity access: DOpUlation without electricity: 2 million
(2017) electrification—total population: 87.6% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 72.2% (2016)
Electricity—production: 8.501 billion kWh (2016 est.)
country comparison to the world: 108
Electricity—consumption: 7.22 billion kWh (2016 est.)
country comparison to the world: 107
Electricity—exports: 536 million kWh (2015 est.)
country comparison to the world: 67
Electricity—imports: 195 million kWh (2016 est.)
country comparison to the world: 94
Electricity—installed generating capacity: 2.546 million kW (2016
est.)
country comparison to the world: 108
Electricity—from fossil fuels: 40% of total installed capacity
(2016 est.)
country comparison to the world: 169
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 107
Electricity—from hydroelectric plants: 25% of total installed
Capacity (2017 est.)
country comparison to the world: 77
Electricity—from other renewable sources: 34% of total installed
capacity (2017 est.) country comparison to the world: 11
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 149
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 137
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 141
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 145
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 157
Refined petroleum products—consumption: 59,000 bbl/day (2016
est.)
country comparison to the world: 97
Refined petroleum products—exports: 12,870 bbl/day (2015 est.)
country comparison to the world: 77
Refined petroleum products—imports: 56,120 bbl/day (2015 est.)
country comparison to the world: 75
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 146
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 159
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 121
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 139
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 147
Carbon dioxide emissions from consumption of energy: 9.436 million
Mt (2017 est.)
country comparison to the world: 110','aebb21ff5e571b569d8fc6a791108a49354202af85ece44d2f894795a44b1a51','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15dea9c5f1eb88b9c35bdf20d00efae82d036fc6c6a202cf1426babbe994ce41',2021,'BF','Burkina Faso','energy',381,'Electricity access: DOpulation without electricity: 10 million
(2017) electrification—total population: 64.3% (2016)
electrification—urban areas: 92% (2016)
electrification—rural areas: 38.1% (2016)
Electricity—production: 9.73 billion kWh (2016 est.)
country comparison to the world: 104
Electricity—consumption: 6.245 billion kWh (2016 est.)
country comparison to the world: 114
Electricity—exports: 872 million kWh (2015 est.)
country comparison to the world: 61
Electricity—imports: 19 million kWh (2016 est.)
country comparison to the world: 114
Electricity—installed generating capacity: 1.914 million kW (2016
est.)
country comparison to the world: 114
Electricity—from fossil fuels: 60% of total installed capacity
(2016 est.)
country comparison to the world: 130
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 73
Electricity—from hydroelectric plants: 40% of total installed
Capacity (2017 est.)
country comparison to the world: 51
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 184
Crude oil—production: 52,000 bbl/day (2018 est.)
country comparison to the world: 52
Crude oil—exports: 26,700 bbl/day (2015 est.)
country comparison to the world: 47
Crude oil—imports: 62,350 bbl/day (2015 est.)
country comparison to the world: 52
Crude oil—proved reserves: 100 million bbl (1 January 2018
est.)
country comparison to the world: 69
Refined petroleum products—production: 69,360 bbl/day (2017
est.)
country comparison to the world: 72
Refined petroleum products—consumption: 51,000 bbl/day (2016
est.)
country comparison to the world: 104
Refined petroleum products—exports: 31,450 bbl/day (2015 est.)
country comparison to the world: 61
Refined petroleum products—imports: 7,405 bbl/day (2015 est.)
country comparison to the world: 154
Natural gas—production: 2.322 billion cu m (2017 est.)
country comparison to the world: 59
Natural gas—consumption: 2.322 billion cu m (2017 est.)
country comparison to the world: 82
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 89
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 112
Natural gas—proved reserves: 28.32 billion cu m (1 January
2018 est.)
country comparison to the world: 68
Carbon dioxide emissions from consumption of energy: 11.54 million
Mt (2017 est.)
country comparison to the world: 101','7054e66e06fe923e9d29e3ef6550ec120cc0c8d1f368cd0c18673f7f53ec0617','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f615345ec0796d7f35c2738edae33c4e67058c75cf17820f8299b32fd400909',2021,'HR','Croatia','energy',386,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 12.2 billion kWh (2016 est.)
country comparison to the world: 95
Electricity—consumption: 15.93 billion kWh (2016 est.)
country comparison to the world: 76
Electricity—exports: 3.2 billion kWh (2016 est.)
country comparison to the world: 42
Electricity—imports: 8.702 billion kWh (2016 est.)
country comparison to the world: 28
Electricity—installed generating capacity: 4.921 million kW (2016
est.)
country comparison to the world: 80
Electricity—from fossil fuels: 45% of total installed capacity
(2016 est.)
country comparison to the world: 160
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 74
Electricity—from hydroelectric plants: 40% of total installed
Capacity (2017 est.)
country comparison to the world: 52
Electricity—from other renewable sources: 16% of total installed
capacity (2017 est.) country comparison to the world: 50
Crude oil—production: 14,000 bbl/day (2018 est.)
country comparison to the world: 74
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 110
Crude oil—imports: 55,400 bbl/day (2015 est.)
country comparison to the world: 55
Crude oil—proved reserves: 71 million bbl (1 January 2018 est.)
country comparison to the world: 74
Refined petroleum products—production: 74,620 bbl/day (2015
est.)
country comparison to the world: 70
Refined petroleum products—consumption: 73,000 bbl/day (2016
est.)
country comparison to the world: 91
Refined petroleum products—exports: 40,530 bbl/day (2015 est.)
country comparison to the world: 58
Refined petroleum products—imports: 35,530 bbl/day (2015 est.)
country comparison to the world: 94
Natural gas—production: 1.048 billion cu m (2017 est.)
country comparison to the world: 67
Natural gas—consumption: 2.577 billion cu m (2017 est.)
country comparison to the world: 77
Natural gas—exports: 172.7 million cu m (2017 est.)
country comparison to the world: 46
Natural gas—imports: 1.841 billion cu m (2017 est.)
country comparison to the world: 54
Natural gas—proved reserves: 24.92 billion cu m (1 January
2018 est.)
country comparison to the world: 71
Carbon dioxide emissions from consumption of energy: 17.96 million
Mt (2017 est.)
country comparison to the world: 89
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 19.28 billion kWh (2016 est.)
country comparison to the world: 76
Electricity—consumption: 16.16 billion kWh (2016 est.)
country comparison to the world: 75
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 124
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 138
Electricity—installed generating capacity: 6.998 million kW (2016
est.)
country comparison to the world: 74
Electricity—from fossil fuels: 91% of total installed capacity
(2016 est.)
country comparison to the world: 53
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 75
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 147
Electricity—from other renewable sources: 8% of total installed
capacity (2017 est.) country comparison to the world: 85
Crude oil—production: 50,000 bbl/day (2018 est.)
country comparison to the world: 53
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 111
Crude oil—imports: 112,400 bbl/day (2015 est.)
country comparison to the world: 41
Crude oil—proved reserves: 124 million bbl (1 January 2018
est.)
country comparison to the world: 68
Refined petroleum products—production: 104,100 bbl/day (2015
est.)
country comparison to the world: 67
Refined petroleum products—consumption: 175,000 bbl/day (2016
est.)
country comparison to the world: 60
Refined petroleum products—exports: 24,190 bbl/day (2015 est.)
country comparison to the world: 69
Refined petroleum products—imports: 52,750 bbl/day (2015 est.)
country comparison to the world: 78
Natural gas—production: 1.189 billion cu m (2017 est.)
country comparison to the world: 66
Natural gas—consumption: 1.189 billion cu m (2017 est.)
country comparison to the world: 90
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 90
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 113
Natural gas—proved reserves: 70.79 billion cu m (1 January
2018 est.)
country comparison to the world: 57
Carbon dioxide emissions from consumption of energy: 26.94 million
Mt (2017 est.)
country comparison to the world: 78
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 1.785 billion kWh (2012 est.)
country comparison to the world: 139
Electricity—consumption: 968 million kWh (2008 est.)
country comparison to the world: 156
Electricity—exports: 0 kWh (2009 est.)
country comparison to the world: 125
Electricity—imports: 0 kWh (2009 est.)
country comparison to the world: 139
Crude oil—production: 0 bbl/day (2017 est.)
country comparison to the world: 125
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 112
Crude oil—imports: 191,300 bbl/day (2015 est.)
country comparison to the world: 31
Crude oil—proved reserves: 0 bbl (1 January 2011 est.)
country comparison to the world: 121
Refined petroleum products—production: 189,800 bbl/day (2015
est.)
country comparison to the world: 53
Refined petroleum products—consumption: 70,000 bbl/day (2016
est.)
country comparison to the world: 93
Refined petroleum products—exports: 167,500 bbl/day (2015 est.)
country comparison to the world: 33
Refined petroleum products—imports: 45,800 bbl/day (2015 est.)
country comparison to the world: 85
Natural gas—production: 0 cu m (2009 est.)
country comparison to the world: 121
Natural gas—consumption: 0 cu m (2009 est.)
country comparison to the world: 137
Natural gas—exports: 0 cu m (2009 est.)
country comparison to the world: 91
Natural gas—imports: 0 cu m (2009 est.)
country comparison to the world: 114
Natural gas—proved reserves: 0 cu m (1 January 2011 est.)
country comparison to the world: 126','8f88e6e2785601b122d6fb34151617f7998fe05b86aecacb4639527487c70961','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c16fdcc52aaf0265ebb721447c3dca8d3a1beda77061db6d4c73227bd5c97075',2021,'CY','Cyprus','energy',393,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 4.618 billion kWh (2016 est.)
country comparison to the world: 123
Electricity—consumption: 4.355 billion kWh (2016 est.)
country comparison to the world: 126
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 126
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 140
Electricity—installed generating capacity: 1.77 million kW (2016
est.)
country comparison to the world: 117
Electricity—from fossil fuels: 85% of total installed capacity
(2016 est.)
country comparison to the world: 70
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 76
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 166
Electricity—from other renewable sources: 15% of total installed
capacity (2017 est.) country comparison to the world: 58
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 126
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 113
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 116
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 122
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 135
Refined petroleum products—consumption: 49,000 bbl/day (2016
est.)
country comparison to the world: 106
Refined petroleum products—exports: 500 bbl/day (2015 est.)
country comparison to the world: 110
Refined petroleum products—imports: 49,240 bbl/day (2015 est.)
country comparison to the world: 84
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 122
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 138
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 92
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 115
Natural gas—proved reserves: 141.6 billion cu m (1 January
2014 est.)
country comparison to the world: 47
Carbon dioxide emissions from consumption of energy: 7.72 million
Mt (2017 est.)
country comparison to the world: 118','ea5ad171e51581e5579206f00aad46aec86a383fd60849f36912dd9a4345e757','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7a3c1cde50e6d51a5f6d018c1c83218029dc8d0614c22ae7c0a778ff46efa09',2021,'HU','Hungary','energy',400,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 77.39 billion kWh (2016 est.)
country comparison to the world: 38
Electricity—consumption: 62.34 billion kWh (2016 est.)
country comparison to the world: 42
Electricity—exports: 24.79 billion kWh (2016 est.)
country comparison to the world: 7
Electricity—imports: 13.82 billion kWh (2016 est.)
country comparison to the world: 18
Electricity—installed generating capacity: 21.63 million kW (2016
est.)
country comparison to the world: 40
Electricity—from fossil fuels: 60% of total installed capacity
(2016 est.)
country comparison to the world: 131
Electricity—from nuclear fuels: 19% of total installed capacity
(2017 est.)
country comparison to the world: 10
Electricity—from hydroelectric plants: 5% of total installed
Capacity (2017 est.)
country comparison to the world: 130
Electricity—from other renewable sources: 16% of total installed
capacity (2017 est.) country comparison to the world: 51
Crude oil—production: 2,000 bbl/day (2018 est.)
country comparison to the world: 86
Crude oil—exports: 446 bbl/day (2017 est.)
country comparison to the world: 78
Crude oil—imports: 155,900 bbl/day (2017 est.)
country comparison to the world: 36
Crude oil—proved reserves: 15 million bbl (1 January 2018 est.)
country comparison to the world: 85
Refined petroleum products—production: 177,500 bbl/day (2017
est.)
country comparison to the world: 56
Refined petroleum products—consumption: 213,700 bbl/day (2017
est.)
country comparison to the world: 56
Refined petroleum products—exports: 52,200 bbl/day (2017 est.)
country comparison to the world: 54
Refined petroleum products—imports: 83,860 bbl/day (2017 est.)
country comparison to the world: 60
Natural gas—production: 229.4 million cu m (2017 est.)
country comparison to the world: 78
Natural gas—consumption: 8.721 billion cu m (2017 est.)
country comparison to the world: 51
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 93
Natural gas—imports: 8.891 billion cu m (2017 est.)
country comparison to the world: 28
Natural gas—proved reserves: 3.964 billion cu m (1 January
2018 est.)
country comparison to the world: 93
Carbon dioxide emissions from consumption of energy: 115.8 million
Mt (2017 est.)
country comparison to the world: 39
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 275.3 billion kWh (2016 est.)
country comparison to the world: 14
Electricity—consumption: 293.5 billion kWh (2016 est.)
country comparison to the world: 13
Electricity—exports: 6.155 billion kWh (2016 est.)
country comparison to the world: 30
Electricity—imports: 43.18 billion kWh (2016 est.)
country comparison to the world: 2
Electricity—installed generating capacity: 114.2 million kW (2016
est.)
country comparison to the world: 10
Electricity—from fossil fuels: 54% of total installed capacity
(2016 est.)
country comparison to the world: 143
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 114
Electricity—from hydroelectric plants: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 106
Electricity—from other renewable sources: 32% of total installed
Capacity (2017 est.)
country comparison to the world: 14
Crude oil—production: 90,000 bbl/day (2018 est.)
country comparison to the world: 44
Crude oil—exports: 13,790 bbl/day (2017 est.)
country comparison to the world: 57
Crude oil—imports: 1.341 million bbl/day (2017 est.)
country comparison to the world: 7
Crude oil—proved reserves: 487.8 million bbl (1 January 2018
est.)
country comparison to the world: 45
Refined petroleum products—production: 1.607 million bbl/day
(2017 est.)
country comparison to the world: 12
Refined petroleum products—consumption: 1.236 million bbl/day
(2017 est.)
country comparison to the world: 19
Refined petroleum products—exports: 615,900 bbl/day (2017 est.)
country comparison to the world: 13
Refined petroleum products—imports: 422,500 bbl/day (2017 est.)
country comparison to the world: 19
Natural gas—production: 5.55 billion cu m (2017 est.)
country comparison to the world: 50
Natural gas—consumption: 75.15 billion cu m (2017 est.)
country comparison to the world: 11
Natural gas—exports: 271.8 million cu m (2017 est.)
country comparison to the world: 44
Natural gas—imports: 69.66 billion cu m (2017 est.)
country comparison to the world: 5
Natural gas—proved reserves: 38.11 billion cu m (1 January
2018 est.)
country comparison to the world: 65
Carbon dioxide emissions from consumption of energy: 351 million
Mt (2017 est.)
country comparison to the world: 20','2ff5380eed37f0cdaa418d128a177bc2e08952447d061ad87f4ff141b7664094','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e28fe7781e571c92b396fbc4e026723846ceba805e98741ee14b1b7347addc4',2021,'DK','Denmark','energy',410,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 29.84 billion kWh (2016 est.)
country comparison to the world: 65
Electricity—consumption: 33.02 billion kWh (2016 est.)
country comparison to the world: 59
Electricity—exports: 9.919 billion kWh (2016 est.)
country comparison to the world: 20
Electricity—imports: 14.98 billion kWh (2016 est.)
country comparison to the world: 14
Electricity—installed generating capacity: 14.34 million kW (2016
est.)
country comparison to the world: 52
Electricity—from fossil fuels: 46% of total installed capacity
(2016 est.)
country comparison to the world: 158
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 77
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 167
Electricity—from other renewable sources: 54% of total installed
capacity (2017 est.) country comparison to the world: 3
Crude oil—production: 115,000 bbl/day (2018 est.)
country comparison to the world: 41
Crude oil—exports: 82,980 bbl/day (2017 est.)
country comparison to the world: 36
Crude oil—imports: 98,240 bbl/day (2017 est.)
country comparison to the world: 44
Crude oil—proved reserves: 439 million bbl (1 January 2018
est.)
country comparison to the world: 46
Refined petroleum products—production: 183,900 bbl/day (2017
est.)
country comparison to the world: 55
Refined petroleum products—consumption: 158,500 bbl/day (2017
est.)
country comparison to the world: 64
Refined petroleum products—exports: 133,700 bbl/day (2017 est.)
country comparison to the world: 38
Refined petroleum products—imports: 109,700 bbl/day (2017 est.)
country comparison to the world: 51
Natural gas—production: 4.842 billion cu m (2017 est.)
country comparison to the world: 52
Natural gas—consumption: 3.115 billion cu m (2017 est.)
country comparison to the world: 73
Natural gas—exports: 2.237 billion cu m (2017 est.)
country comparison to the world: 37
Natural gas—imports: 509.7 million cu m (2017 est.)
country comparison to the world: 65
Natural gas—proved reserves: 12.86 billion cu m (1 January
2018 est.)
country comparison to the world: 77
Carbon dioxide emissions from consumption of energy: 37.45 million
Mt (2017 est.) country comparison to the world: 70
Electricity access: electrification—total population: 98.6%
(2016)
electrification—urban areas: 99.2% (2016)
electrification—rural areas: 98% (2016)
Electricity—production: 914 million kWh (2016 est.)
country comparison to the world: 155
Electricity—consumption: 850 million kWh (2016 est.)
country comparison to the world: 159
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 135
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 149
Electricity—installed generating capacity: 338,000 kW (2016 est.)
country comparison to the world: 154
Electricity—from fossil fuels: 34% of total installed capacity
(2016 est.)
country comparison to the world: 181
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 91
Electricity—from hydroelectric plants: 38% of total installed
Capacity (2017 est.)
country comparison to the world: 55
Electricity—from other renewable sources: 27% of total installed
capacity (2017 est.)
country comparison to the world: 24
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 137
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 124
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 128
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 132
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 146
Refined petroleum products—consumption: 16,000 bbl/day (2016
est.)
country comparison to the world: 151
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 156
Refined petroleum products—imports: 17,460 bbl/day (2015 est.)
country comparison to the world: 131
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 133
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 147
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 105
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 126
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 136
Carbon dioxide emissions from consumption of energy: 2.369 million
Mt (2017 est.)
country comparison to the world: 155
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 538 million kWh (2016 est.)
country comparison to the world: 163
Electricity—consumption: 468 million kWh (2016 est.)
country comparison to the world: 170
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 141
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 153
Electricity—installed generating capacity: 187,000 kW (2016 est.)
country comparison to the world: 167
Electricity—from fossil fuels: 51% of total installed capacity
(2016 est.)
country comparison to the world: 149
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 99
Electricity—from hydroelectric plants: 49% of total installed
capacity (2017 est.)
country comparison to the world: 42
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 189
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 142
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 130
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 133
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 138
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 150
Refined petroleum products—consumption: 4,000 bbl/day (2016
est.)
country comparison to the world: 184
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 159
Refined petroleum products—imports: 3,973 bbl/day (2015 est.)
country comparison to the world: 177
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 138
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 151
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 113
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 131
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 140
Carbon dioxide emissions from consumption of energy: 613,800 Mt
(2017 est.)
country comparison to the world: 179
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 147.7 billion kWh (2016 est.)
country comparison to the world: 29
Electricity—consumption: 122.2 billion kWh (2016 est.) country
comparison to the world: 29
Electricity—exports: 15.53 billion kWh (2016 est.)
country comparison to the world: 12
Electricity—imports: 5.741 billion kWh (2016 est.)
country comparison to the world: 34
Electricity—installed generating capacity: 33.86 million kW (2016
est.) country comparison to the world: 30
Electricity—from fossil fuels: 3% of total installed capacity (2016
est.) country comparison to the world: 208
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 159
Electricity—from hydroelectric plants: 93% of total installed
capacity (2017 est.) country comparison to the world: 8
Electricity—from other renewable sources: 4% of total installed
capacity (2017 est.) country comparison to the world: 115
Crude oil—production: 1.517 million bbl/day (2018 est.) country
comparison to the world: 15
Crude oil—exports: 1.383 million bbl/day (2017 est.)
country comparison to the world: 10
Crude oil—imports: 36,550 bbl/day (2017 est.)
country comparison to the world: 58
Crude oil—proved reserves: 6.376 billion bbl (1 January 2018)
country comparison to the world: 20
Refined petroleum products—production: 371,600 bbl/day (2017
est.) country comparison to the world: 38
Refined petroleum products—consumption: 205,300 bbl/day (2017
est.) country comparison to the world: 57
Refined petroleum products—exports: 432,800 bbl/day (2017 est.)
country comparison to the world: 20
Refined petroleum products—imports: 135,300 bbl/day (2017 est.)
country comparison to the world: 43
Natural gas—production: 123.9 billion cu m (2017 est.) country
comparison to the world: 7
Natural gas—consumption: 4.049 billion cu m (2017 est.)
country comparison to the world: 65
Natural gas—exports: 120.2 billion cu m (2017 est.)
country comparison to the world: 3
Natural gas—imports: 5.663 million cu m (2017 est.)
country comparison to the world: 77
Natural gas—proved reserves: 1.782 trillion cu m (1 January
2018 est.) country comparison to the world: 20
Carbon dioxide emissions from consumption of energy: 39.8 million
Mt (2017 est.) country comparison to the world: 65
Electricity access: electrification—total population: 99%
(2016) electrification—urban areas: 100% (2016)
electrification—rural areas: 93% (2016) Electricity—production:
32.16 billion kWh (2016 est.) country comparison to the
world: 62
Electricity—consumption: 28.92 billion kWh (2016 est.) country
comparison to the world: 63
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 181
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 183
Electricity—installed generating capacity: 8.167 million kW (2016
est.) country comparison to the world: 70
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.) country comparison to the world: 14
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 160
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 192
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 204
Crude oil—production: 979,000 bbli/day (2018 est.) country
comparison to the world: 21
Crude oil—exports: 844,100 bbli/day (2015 est.) country
comparison to the world: 14
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 179
Crude oil—proved reserves: 5.373 billion bbl (1 January 2018
est.) country comparison to the world: 21
Refined petroleum products—production: 229,600 bbl/day (2015
est.) country comparison to the world: 48
Refined petroleum products—consumption: 188,000 bbl/day (2016
est.) country comparison to the world: 59
Refined petroleum products—exports: 33,700 bbl/day (2015 est.)
country comparison to the world: 60
Refined petroleum products—imports: 6,041 bbl/day (2015 est.)
country comparison to the world: 165
Natural gas—production: 31.23 billion cu m (2017 est.) country
comparison to the world: 26
Natural gas—consumption: 21.94 billion cu m (2017 est.)
country comparison to the world: 35
Natural gas—exports: 11.16 billion cu m (2017 est.) country
comparison to the world: 20
Natural gas—imports: 1.982 billion cu m (2017 est.) country
comparison to the world: 53
Natural gas—proved reserves: 651.3 billion cu m (1 January
2018 est.) country comparison to the world: 28
Carbon dioxide emissions from consumption of energy: 68.94 million
Mt (2017 est.) country comparison to the world: 52','3aed6ce714e45ee3745ac0f641ee1b27f2a7c74283258402e8dcd4e6a6d9c18a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ea08334c21255e35523fb1ef605c7bcdc32ea7155f287d43df77be2f4fc7914',2021,'DJ','Djibouti','energy',419,'Electricity access: Population without electricity: 400,000
(2016) electrification—total population: 51.8% (2016)
electrification—urban areas: 67.4% (2016)
electrification—rural areas: 2% (2016)
Electricity—production: 405.5 million kWh (2016 est.)
country comparison to the world: 170
Electricity—consumption: 377.1 million kWh (2016 est.)
country comparison to the world: 177
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 127
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 141
Electricity—installed generating capacity: 130,300 kW (2016 est.)
country comparison to the world: 175
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 7
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 78
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 168
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 185
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 127
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 114
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 117
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 123
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 136
Refined petroleum products—consumption: 6,360 bbl/day (2016
est.)
country comparison to the world: 170
Refined petroleum products—exports: 403 bbl/day (2015 est.)
country comparison to the world: 112
Refined petroleum products—imports: 6,692 bbl/day (2015 est.)
country comparison to the world: 161
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 123
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 139
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 94
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 116
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 127
Carbon dioxide emissions from consumption of energy: 950,200 Mt
(2017 est.)
country comparison to the world: 171
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 111.4 million kWh (2016 est.)
country comparison to the world: 199
Electricity—consumption: 103.6 million kWh (2016 est.)
country comparison to the world: 201
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 128
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 142
Electricity—installed generating capacity: 27,800 kW (2016 est.)
country comparison to the world: 201
Electricity—from fossil fuels: 72% of total installed capacity
(2016 est.)
country comparison to the world: 102
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 79
Electricity—from hydroelectric plants: 25% of total installed
capacity (2017 est.) country comparison to the world: 76
Electricity—from other renewable sources: 3% of total installed
capacity (2017 est.) country comparison to the world: 124
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 128
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 115
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 118
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 124
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 137
Refined petroleum products—consumption: 1,300 bbl/day (2016
est.)
country comparison to the world: 203
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 148
Refined petroleum products—imports: 1,237 bbl/day (2015 est.)
country comparison to the world: 199
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 124
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 140
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 95
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 117
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 128
Carbon dioxide emissions from consumption of energy: 199,600 Mt
(2017 est.)
country comparison to the world: 200','1b9f84695c62a01756533bccda1fcfec3dd4c69d0f12a40990f1e5bad774bfc9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d5b05a0ae63879a874b783cce9ea565d3cd126798c20e3059e41ef5a995db6a',2021,'JE','Jersey','energy',432,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 18.03 billion kWh (2016 est.)
country comparison to the world: 81
Electricity—consumption: 15.64 billion kWh (2016 est.)
country comparison to the world: 78
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 129
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 143
Electricity—installed generating capacity: 3.839 million kW (2016
est.)
country comparison to the world: 91
Electricity—from fossil fuels: 77% of total installed capacity
(2016 est.)
country comparison to the world: 92
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 80
Electricity—from hydroelectric plants: 16% of total installed
capacity (2017 est.) country comparison to the world: 99
Electricity—from other renewable sources: 7% of total installed
capacity (2017 est.) country comparison to the world: 93
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 129
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 116
Crude oil—imports: 16,980 bbl/day (2015 est.)
country comparison to the world: 67
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 125
Refined petroleum products—production: 16,060 bbl/day (2015
est.)
country comparison to the world: 92
Refined petroleum products—consumption: 134,000 bbl/day (2016
est.)
country comparison to the world: 70
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 149
Refined petroleum products—imports: 108,500 bbl/day (2015 est.)
country comparison to the world: 52
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 125
Natural gas—consumption: 1.161 billion cu m (2017 est.)
country comparison to the world: 92
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 96
Natural gas—imports: 1.161 billion cu m (2017 est.)
country comparison to the world: 60
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 129
Carbon dioxide emissions from consumption of energy: 23.79 million
Mt (2017 est.) country comparison to the world: 81
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 59.01 billion kWh (2016 est.)
country comparison to the world: 50
Electricity—consumption: 58.46 billion kWh (2016 est.)
country comparison to the world: 43
Electricity—exports: 30.17 billion kWh (2016 est.)
country comparison to the world: 5
Electricity—imports: 34.1 billion kWh (2016 est.)
country comparison to the world: 4
Electricity—installed generating capacity: 20.84 million kW (2016
est.)
country comparison to the world: 42
Electricity—from fossil fuels: 3% of total installed capacity (2016
est.)
country comparison to the world: 209
Electricity—from nuclear fuels: 18% of total installed capacity
(2017 est.)
country comparison to the world: 11
Electricity—from hydroelectric plants: 67% of total installed
Capacity (2017 est.)
country comparison to the world: 21
Electricity—from other renewable sources: 13% of total installed
Capacity (2017 est.)
country comparison to the world: 71
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 205
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 201
Crude oil—imports: 57,400 bbl/day (2017 est.)
country comparison to the world: 54
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 201
Refined petroleum products—production: 61,550 bbl/day (2017
est.)
country comparison to the world: 79
Refined petroleum products—consumption: 223,900 bbl/day (2017
est.)
country comparison to the world: 54
Refined petroleum products—exports: 7,345 bbl/day (2017 est.)
country comparison to the world: 88
Refined petroleum products—imports: 165,100 bbl/day (2017 est.)
country comparison to the world: 39
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 205
Natural gas—consumption: 3.709 billion cu m (2017 est.)
country comparison to the world: 68
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 194
Natural gas—imports: 3.681 billion cu m (2017 est.)
country comparison to the world: 42
Natural gas—proved reserves: NA cu m (1 January 2011 est.)
Carbon dioxide emissions from consumption of energy: 38.95 million
Mt (2017 est.)
country comparison to the world: 66
Electricity access: DOpulation without electricity: 1 million
(2017) electrification—total population: 92% (2017)
electrification—urban areas: 100% (2017)
electrification—rural areas: 84% (2017)
Electricity—production: 17.07 billion kWh (2016 est.)
country comparison to the world: 84
Electricity—consumption: 14.16 billion kWh (2016 est.)
country comparison to the world: 82
Electricity—exports: 262 million kWh (2015 est.)
country comparison to the world: 72
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 207
Electricity—installed generating capacity: 9.058 million kW (2016
est.)
country comparison to the world: 64
Electricity—from fossil fuels: 83% of total installed capacity
(2016 est.)
country comparison to the world: 77
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 190
Electricity—from hydroelectric plants: 17% of total installed
Capacity (2017 est.)
country comparison to the world: 98
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 207
Crude oil—production: 25,000 bbl/day (2018 est.)
country comparison to the world: 63
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 202
Crude oil—imports: 87,660 bbl/day (2015 est.)
country comparison to the world: 45
Crude oil—proved reserves: 2.5 billion bbl (1 January 2018 est.)
country comparison to the world: 30
Refined petroleum products—production: 111,600 bbl/day (2015
est.)
country comparison to the world: 66
Refined petroleum products—consumption: 134,000 bbl/day (2016
est.)
country comparison to the world: 71
Refined petroleum products—exports: 12,520 bbl/day (2015 est.)
country comparison to the world: 79
Refined petroleum products—imports: 38,080 bbl/day (2015 est.)
country comparison to the world: 92
Natural gas—production: 3.738 billion cu m (2017 est.)
country comparison to the world: 53
Natural gas—consumption: 3.738 billion cu m (2017 est.)
country comparison to the world: 67
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 195
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 196
Natural gas—proved reserves: 240.7 billion cu m (1 January
2018 est.)
country comparison to the world: 40
Carbon dioxide emissions from consumption of energy: 27.51 million
Mt (2017 est.)
country comparison to the world: 75
Electricity—production: 246.1 billion kWh (2016 est.)
country comparison to the world: 18
Electricity—consumption: 237.4 billion kWh (2016 est.)
country comparison to the world: 16
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 205
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 208
Electricity—installed generating capacity: 49.52 million kW (2016
est.)
country comparison to the world: 22
Electricity—from fossil fuels: 79% of total installed capacity
(2016 est.)
country comparison to the world: 88
Electricity—from nuclear fuels: 11% of total installed capacity
(2017 est.)
country comparison to the world: 14
Electricity—from hydroelectric plants: 4% of total installed
Capacity (2017 est.)
country comparison to the world: 133
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 105
Crude oil—production: 196 bbl/day (2018 est.)
country comparison to the world: 96
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 203
Crude oil—imports: 846,400 bbl/day (2015 est.)
country comparison to the world: 13
Crude oil—proved reserves: 2.38 million bbl (1 January 2018
est.)
country comparison to the world: 95
Refined petroleum products—production: 924,000 bbl/day (2015
est.)
country comparison to the world: 21
Refined petroleum products—consumption: 962,400 bbl/day (2016
est.)
country comparison to the world: 22
Refined petroleum products—exports: 349,600 bbl/day (2015 est.)
country comparison to the world: 26
Refined petroleum products—imports: 418,300 bbl/day (2015 est.)
country comparison to the world: 20
Natural gas—production: 237.9 million cu m (2017 est.)
country comparison to the world: 77
Natural gas—consumption: 22.45 billion cu m (2017 est.)
country comparison to the world: 34
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 196
Natural gas—imports: 22.14 billion cu m (2017 est.)
country comparison to the world: 15
Natural gas—proved reserves: 6.229 billion cu m (1 January
2018 est.)
country comparison to the world: 86
Carbon dioxide emissions from consumption of energy: 348.8 million
Mt (2017 est.)
country comparison to the world: 21
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 17.03 billion kWh (2016 est.)
country comparison to the world: 85
Electricity—consumption: 12.96 billion kWh (2016 est.)
country comparison to the world: 85
Electricity—exports: 1.4 billion kWh NA (2015 est.)
country comparison to the world: 52
Electricity—imports: 103 million kWh (2016 est.)
country comparison to the world: 98
Electricity—installed generating capacity: 5.508 million kW (2016
est.)
country comparison to the world: 78
Electricity—from fossil fuels: 6% of total installed capacity (2016
est.)
country comparison to the world: 201
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 191
Electricity—from hydroelectric plants: 94% of total installed
Capacity (2017 est.)
country comparison to the world: 6
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 208
Crude oil—production: 180 bbl/day (2018 est.)
country comparison to the world: 97
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 204
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 201
Crude oil—proved reserves: 12 million bbl (1 January 2018 est.)
country comparison to the world: 89
Refined petroleum products—production: 172 bbl/day (2015 est.)
country comparison to the world: 108
Refined petroleum products—consumption: 24,000 bbl/day (2016
est.)
country comparison to the world: 130
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 206
Refined petroleum products—imports: 22,460 bbl/day (2015 est.)
country comparison to the world: 114
Natural gas—production: 19.82 million cu m (2017 est.)
country comparison to the world: 89
Natural gas—consumption: 19.82 million cu m (2017 est.)
country comparison to the world: 114
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 197
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 197
Natural gas—proved reserves: 5.663 billion cu m (1 January
2018 est.)
country comparison to the world: 91
Carbon dioxide emissions from consumption of energy: 6.329 million
Mt (2017 est.)
country comparison to the world: 126','1929882106e7757471f34dee7bb84b3720a3f5bc870f3654e1a3e6ccfffaaa96','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5e3c2223b93dc5ba0a3ec49c8c9f379567b0e56bdf36c8ef1ac33c2d6d393dc',2021,'CO','Colombia','energy',441,'Electricity access: population without electricity: 500,000
(2016)
electrification—total population: 99.9% (2016)
electrification—urban areas: 100% (2016)
electrification—rural areas: 99.8% (2016)
Electricity—production: 26.5 billion kWh (2016 est.)
country comparison to the world: 71
Electricity—consumption: 22.68 billion kWh (2016 est.)
country comparison to the world: 70
Electricity—exports: 211 million kWh (2015 est.)
country comparison to the world: 75
Electricity—imports: 82 million kWh (2016 est.)
country comparison to the world: 102
Electricity—installed generating capacity: 8.192 million kW (2016
est.)
country comparison to the world: 69
Electricity—from fossil fuels: 43% of total installed capacity
(2016 est.)
country comparison to the world: 163
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 81
Electricity—from hydroelectric plants: 54% of total installed
Capacity (2017 est.)
country comparison to the world: 32
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 138
Crude oil—production: 517,000 bbl/day (2018 est.)
country comparison to the world: 28
Crude oil—exports: 383,500 bbl/day (2017 est.)
country comparison to the world: 22
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 119
Crude oil—proved reserves: 8.273 billion bbl (1 January 2018
est.)
country comparison to the world: 17
Refined petroleum products—production: 137,400 bbl/day (2015
est.)
country comparison to the world: 62
Refined petroleum products—consumption: 265,000 bbl/day (2016
est.)
country comparison to the world: 48
Refined petroleum products—exports: 25,870 bbl/day (2015 est.)
country comparison to the world: 66
Refined petroleum products—imports: 153,900 bbl/day (2015 est.)
country comparison to the world: 40
Natural gas—production: 477.8 million cu m (2017 est.)
country comparison to the world: 73
Natural gas—consumption: 453.1 million cu m (2017 est.)
country comparison to the world: 100
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 97
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 118
Natural gas—proved reserves: 10.9 billion cu m (1 January 2018
est.)
country comparison to the world: 78
Carbon dioxide emissions from consumption of energy: 37.54 million
Mt (2017 est.)
country comparison to the world: 69','b96eac95c7b14451dda8a02691b91e5d6b0581913b6e1de13d243f63ee117e21','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db47e66dfe7d7fd7b60795279914e4774db2f124f8f9e808e15c9a8ee96f471',2021,'EG','Egypt','energy',447,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 183.5 billion kWh (2016 est.)
country comparison to the world: 22
Electricity—consumption: 159.7 billion kWh (2016 est.)
country comparison to the world: 23
Electricity—exports: 1.158 billion kWh (2015 est.)
country comparison to the world: 57
Electricity—imports: 54 million kWh (2016 est.)
country comparison to the world: 106
Electricity—installed generating capacity: 45.12 million kW (2016
est.)
country comparison to the world: 23
Electricity—from fossil fuels: 91% of total installed capacity
(2016 est.)
country comparison to the world: 54
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 82
Electricity—from hydroelectric plants: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 129
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.)
country comparison to the world: 139
Crude oil—production: 639,000 bbl/day (2018 est.)
country comparison to the world: 27
Crude oil—exports: 246,500 bbl/day (2017 est.)
country comparison to the world: 29
Crude oil—imports: 64,760 bbl/day (2015 est.)
country comparison to the world: 51
Crude oil—proved reserves: 4.4 billion bbl (1 January 2018 est.)
country comparison to the world: 24
Refined petroleum products—production: 547,500 bbl/day (2015
est.)
country comparison to the world: 31
Refined petroleum products—consumption: 878,000 bbl/day (2016
est.)
country comparison to the world: 25
Refined petroleum products—exports: 47,360 bbl/day (2015 est.)
country comparison to the world: 56
Refined petroleum products—imports: 280,200 bbl/day (2015 est.)
country comparison to the world: 26
Natural gas—production: 50.86 billion cu m (2017 est.)
country comparison to the world: 16
Natural gas—consumption: 57.71 billion cu m (2017 est.)
country comparison to the world: 13
Natural gas—exports: 212.4 million cu m (2017 est.)
country comparison to the world: 45
Natural gas—imports: 7.079 billion cu m (2017 est.)
country comparison to the world: 29
Natural gas—proved reserves: 2.186 trillion cu m (1 January
2018 est.)
country comparison to the world: 15
Carbon dioxide emissions from consumption of energy: 232.7 million
Mt (2017 est.)
country comparison to the world: 30
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 63.09 billion kWh (2016 est.)
country comparison to the world: 46
Electricity—consumption: 55 billion kWh (2016 est.)
country comparison to the world: 47
Electricity—exports: 5.2 billion kWh (2016 est.)
country comparison to the world: 35
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 161
Electricity—installed generating capacity: 17.59 million kW (2016
est.)
country comparison to the world: 48
Electricity—from fossil fuels: 95% of total installed capacity
(2016 est.)
country comparison to the world: 44
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 113
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 179
Electricity—from other renewable sources: 5% of total installed
capacity (2017 est.)
country comparison to the world: 107
Crude oil—production: 390 bbl/day (2018 est.)
country comparison to the world: 94
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 141
Crude oil—imports: 231,600 bbl/day (2017 est.)
country comparison to the world: 28
Crude oil—proved reserves: 12.73 million bbl (1 January 2018
est.)
country comparison to the world: 87
Refined petroleum products—production: 294,300 bbl/day (2017
est.)
country comparison to the world: 42
Refined petroleum products—consumption: 242,200 bbl/day (2017
est.)
country comparison to the world: 52
Refined petroleum products—exports: 111,700 bbl/day (2017 est.)
country comparison to the world: 39
Refined petroleum products—imports: 98,860 bbl/day (2017 est.)
country comparison to the world: 54
Natural gas—production: 9.826 billion cu m (2017 est.)
country comparison to the world: 42
Natural gas—consumption: 9.995 billion cu m (2017 est.)
country comparison to the world: 49
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 126
Natural gas—imports: 509.7 million cu m (2017 est.)
country comparison to the world: 66
Natural gas—proved reserves: 176 billion cu m (1 January 2018
est.)
country comparison to the world: 45
Carbon dioxide emissions from consumption of energy: 73.82 million
Mt (2017 est.)
country comparison to the world: 49','1a41753dc0a1c9738fd2441e24f70bda1a0d32fabbd164a99516e36fb279b389','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad1c80c9f5aea0fb819edd275bb27693fb2c73b5ba73ceb77b0042e19c7ce9e1',2021,'GT','Guatemala','energy',453,'Electricity access: population without electricity: 400,000
(2016)
electrification—total population: 98.6% (2016)
electrification—urban areas: 98.6% (2016)
electrification—rural areas: 98.8% (2016)
Electricity—production: 5.83 billion kWh (2016 est.)
country comparison to the world: 116
Electricity—consumption: 5.928 billion kWh (2016 est.)
country comparison to the world: 116
Electricity—exports: 89.6 million kWh (2017 est.)
country comparison to the world: 82
Electricity—imports: 1.066 billion kWh (2016 est.)
country comparison to the world: 70
Electricity—installed generating capacity: 1.983 million kW (2016
est.)
country comparison to the world: 113
Electricity—from fossil fuels: 49% of total installed capacity
(2016 est.)
country comparison to the world: 154
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 83
Electricity—from hydroelectric plants: 23% of total installed
Capacity (2017 est.)
country comparison to the world: 84
Electricity—from other renewable sources: 29% of total installed
capacity (2017 est.)
country comparison to the world: 18
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 130
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 117
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 120
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 126
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 138
Refined petroleum products—consumption: 52,000 bbl/day (2016
est.)
country comparison to the world: 103
Refined petroleum products—exports: 347 bbl/day (2015 est.)
country comparison to the world: 115
Refined petroleum products—imports: 49,280 bbl/day (2015 est.)
country comparison to the world: 82
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 126
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 141
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 98
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 119
Natural gas—proved reserves: 0 cu m (1 January 2017 est.)
country comparison to the world: 130
Carbon dioxide emissions from consumption of energy: 7.331 million
Mt (2017 est.)
country comparison to the world: 124','43561dd3e6f8bb406c3d83417dc67f822b508ac6943ff1c3981550568297bb7c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3746a1b1ce2cb5124f2111b96aa8c5420158fdc7e2bd3e72b483ec119bf54254',2021,'GN','Guinea','energy',462,'Electricity access: population without electricity: 300,000
(2016)
electrification—total population: 67.9% (2016)
electrification—urban areas: 90.8% (2016)
electrification—rural areas: 52.6% (2016)
Electricity—production: 500 million kWh (2016 est.)
country comparison to the world: 166
Electricity—consumption: 465 million kWh (2016 est.)
country comparison to the world: 171
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 130
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 144
Electricity—installed generating capacity: 331,000 kW (2016 est.)
country comparison to the world: 156
Electricity—from fossil fuels: 61% of total installed capacity
(2016 est.)
country comparison to the world: 127
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 84
Electricity—from hydroelectric plants: 38% of total installed
Capacity (2017 est.)
country comparison to the world: 54
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 140
Crude oil—production: 172,000 bbl/day (2018 est.)
country comparison to the world: 38
Crude oil—exports: 308,700 bbl/day (2017 est.)
country comparison to the world: 26
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 121
Crude oil—proved reserves: 1.1 billion bbl (1 January 2018 est.)
country comparison to the world: 40
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 139
Refined petroleum products—consumption: 5,200 bbl/day (2016
est.)
country comparison to the world: 176
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 150
Refined petroleum products—imports: 5,094 bbl/day (2015 est.)
country comparison to the world: 171
Natural gas—production: 6.069 billion cu m (2017 est.)
country comparison to the world: 46
Natural gas—consumption: 1.189 billion cu m (2017 est.)
country comparison to the world: 91
Natural gas—exports: 4.878 billion cu m (2017 est.)
country comparison to the world: 30
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 120
Natural gas—proved reserves: 36.81 billion cu m (1 January
2018 est.)
country comparison to the world: 66
Carbon dioxide emissions from consumption of energy: 3.062 million
Mt (2017 est.)
country comparison to the world: 148
Electricity access: DOpulation without electricity: 3 million
(2017) electrification—total population: 46.7% (2016)
electrification—urban areas: 74.6% (2016)
electrification—rural areas: 39.3% (2016)
Electricity—production: 415.9 million kWh (2016 est.)
country comparison to the world: 168
Electricity—consumption: 353.9 million kWh (2016 est.)
country comparison to the world: 180
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 131
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 145
Electricity—installed generating capacity: 160,700 kW (2016 est.)
country comparison to the world: 172
Electricity—from fossil fuels: 99% of total installed capacity
(2016 est.)
country comparison to the world: 23
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 85
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 169
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 152
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 131
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 118
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 122
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 127
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 140
Refined petroleum products—consumption: 4,000 bbl/day (2016
est.)
country comparison to the world: 183
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 151
Refined petroleum products—imports: 3,897 bbl/day (2015 est.)
country comparison to the world: 179
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 127
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 142
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 99
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 121
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 131
Carbon dioxide emissions from consumption of energy: 597,100 Mt
(2017 est.)
country comparison to the world: 182
Electricity access: DOpulation without electricity: 2 million
(2017) electrification—total population: 14.7% (2016)
electrification—urban areas: 29.8% (2016)
electrification—rural areas: 4% (2016)
Electricity—production: 39 million kWh (2016 est.)
country comparison to the world: 208
Electricity—consumption: 36.27 million kWh (2016 est.)
country comparison to the world: 208
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 145
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 157
Electricity—installed generating capacity: 28,300 kW (2016 est.)
country comparison to the world: 200
Electricity—from fossil fuels: 99% of total installed capacity
(2016 est.)
country comparison to the world: 24
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 104
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 176
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 154
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 146
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 134
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 138
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 142
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 154
Refined petroleum products—consumption: 2,700 bbl/day (2016
est.)
country comparison to the world: 190
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 163
Refined petroleum products—imports: 2,625 bbl/day (2015 est.)
country comparison to the world: 186
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 143
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 156
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 118
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 136
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 144
Carbon dioxide emissions from consumption of energy: 397,900 Mt
(2017 est.)
country comparison to the world: 188
Electricity access: electrification—total population: 22.9%
(2016)
electrification—urban areas: 72.7% (2016)
electrification—rural areas: 15.5% (2016)
Electricity—production: 3.481 billion kWh (2016 est.)
country comparison to the world: 129
Electricity—consumption: 3.237 billion kWh (2016 est.)
country comparison to the world: 134
Electricity—exports: 0 kWh (2017 est.)
country comparison to the world: 183
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 184
Electricity—installed generating capacity: 900,900 kW (2016 est.)
country comparison to the world: 131
Electricity—from fossil fuels: 63% of total installed capacity
(2016 est.)
country comparison to the world: 123
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 162
Electricity—from hydroelectric plants: 30% of total installed
Capacity (2017 est.)
country comparison to the world: 69
Electricity—from other renewable sources: 7% of total installed
Capacity (2017 est.)
country comparison to the world: 95
Crude oil—production: 45,000 bbl/day (2018 est.)
country comparison to the world: 55
Crude oil—exports: 55,600 bbl/day (2015 est.)
country comparison to the world: 41
Crude oil—imports: 22,220 bbl/day (2015 est.)
country comparison to the world: 62
Crude oil—proved reserves: 183.8 million bbl (1 January 2018
est.)
country comparison to the world: 57
Refined petroleum products—production: 22,170 bbl/day (2015
est.)
country comparison to the world: 88
Refined petroleum products—consumption: 37,000 bbl/day (2016
est.)
country comparison to the world: 116
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 190
Refined petroleum products—imports: 17,110 bbl/day (2015 est.)
country comparison to the world: 134
Natural gas—production: 11.18 billion cu m (2017 est.)
country comparison to the world: 39
Natural gas—consumption: 99.11 million cu m (2017 est.)
country comparison to the world: 109
Natural gas—exports: 11.1 billion cu m (2017 est.)
country comparison to the world: 21
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 172
Natural gas—proved reserves: 210.5 billion cu m (1 January
2018 est.)
country comparison to the world: 41
Carbon dioxide emissions from consumption of energy: 6.082 million
Mt (2017 est.)
country comparison to the world: 129
Electricity access: electrification—total population: 98.4%
(2016)
electrification—urban areas: 99.9% (2016)
electrification—rural areas: 96.1% (2016)
Electricity—production: 63.13 billion kWh (2016 est.)
country comparison to the world: 45
Electricity—consumption: 10.9 billion kWh (2016 est.)
country comparison to the world: 92
Electricity—exports: 41.13 billion kWh (2015 est.)
country comparison to the world: 4
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 185
Electricity—installed generating capacity: 8.87 million kW (2016
est.)
country comparison to the world: 65
Electricity—from fossil fuels: 0% of total installed capacity (2016
est.)
country comparison to the world: 214
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 163
Electricity—from hydroelectric plants: 99% of total installed
capacity (2017 est.)
country comparison to the world: 3
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.)
country comparison to the world: 162
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 186
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 179
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 181
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 181
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 189
Refined petroleum products—consumption: 43,000 bbl/day (2016
est.)
country comparison to the world: 112
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 191
Refined petroleum products—imports: 40,760 bbl/day (2015 est.)
country comparison to the world: 89
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 183
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 187
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 167
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 173
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 181
Carbon dioxide emissions from consumption of energy: 7.74 million
Mt (2017 est.)
country comparison to the world: 117
Electricity access: DOpulation without electricity: 6 million
(2017)
electrification—total population: 65% (2017)
electrification—urban areas: 90% (2017)
electrification—rural areas: 43% (2017)
Electricity—production: 4.167 billion kWh (2016 est.)
country comparison to the world: 126
Electricity—consumption: 3.497 billion kWh (2016 est.)
country comparison to the world: 133
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 195
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 197
Electricity—installed generating capacity: 977,000 kW (2016 est.)
country comparison to the world: 129
Electricity—from fossil fuels: 82% of total installed capacity
(2016 est.)
country comparison to the world: 79
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 179
Electricity—from hydroelectric plants: 7% of total installed
Capacity (2017 est.)
country comparison to the world: 127
Electricity—from other renewable sources: 11% of total installed
Capacity (2017 est.)
country comparison to the world: 80
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 197
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 190
Crude oil—imports: 17,880 bbl/day (2015 est.)
country comparison to the world: 65
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 192
Refined petroleum products—production: 17,590 bbl/day (2015
est.)
country comparison to the world: 90
Refined petroleum products—consumption: 48,000 bbl/day (2016
est.)
country comparison to the world: 107
Refined petroleum products—exports: 4,063 bbl/day (2015 est.)
country comparison to the world: 94
Refined petroleum products—imports: 32,050 bbl/day (2015 est.)
country comparison to the world: 98
Natural gas—production: 59.46 million cu m (2017 est.)
country comparison to the world: 85
Natural gas—consumption: 59.46 million cu m (2017 est.)
country comparison to the world: 111
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 180
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 186
Natural gas—proved reserves: 0 cu m (1 January 2012 est.)
country comparison to the world: 191
Carbon dioxide emissions from consumption of energy: 8.644 million
Mt (2017 est.)
country comparison to the world: 113
Electricity access: DOpulation without electricity: 6 million
(2017) electrification—total population: 20% (2017)
electrification—urban areas: 19% (2017)
electrification—rural areas: 20% (2017)
Electricity—production: 300 million kWh (2016 est.)
country comparison to the world: 185
Electricity—consumption: 279 million kWh (2016 est.)
country comparison to the world: 188
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 197
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 199
Electricity—installed generating capacity: 113,300 kW (2016 est.)
country comparison to the world: 179
Electricity—from fossil fuels: 23% of total installed capacity
(2016 est.)
country comparison to the world: 194
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 182
Electricity—from hydroelectric plants: 51% of total installed
Capacity (2017 est.)
country comparison to the world: 38
Electricity—from other renewable sources: 26% of total installed
capacity (2017 est.)
country comparison to the world: 27
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 199
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 192
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 194
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 194
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 200
Refined petroleum products—consumption: 6,500 bbl/day (2016
est.)
country comparison to the world: 169
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 201
Refined petroleum products—imports: 6,439 bbl/day (2015 est.)
country comparison to the world: 164
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 195
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 197
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 183
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 188
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 193
Carbon dioxide emissions from consumption of energy: 984,800 Mt
(2017 est.)
country comparison to the world: 170','7adafd1bc9a3b2c5389ba6e0262226de8726d26aff74f79f2fb64d1c7ffc7ef7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f4d68a101bf55fae6f4c7e64a142d39de251bf9ecd118b0b3195d97abe3b096',2021,'LV','Latvia','energy',476,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 11.55 billion kWh (2016 est.)
country comparison to the world: 97
Electricity—consumption: 8.795 billion kWh (2016 est.)
country comparison to the world: 102
Electricity—exports: 5.613 billion kWh (2016 est.)
country comparison to the world: 33
Electricity—imports: 3.577 billion kWh (2016 est.)
country comparison to the world: 46
Electricity—installed generating capacity: 2.578 million kW (2016
est.)
country comparison to the world: 106
Electricity—from fossil fuels: 72% of total installed capacity
(2016 est.)
country comparison to the world: 103
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 86
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 170
Electricity—from other renewable sources: 28% of total installed
capacity (2017 est.) country comparison to the world: 22
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 132
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 119
Crude oil—imports: 0 bbl/day (2017 est.)
country comparison to the world: 123
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 128
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 141
Refined petroleum products—consumption: 28,300 bbl/day (2017
est.)
country comparison to the world: 121
Refined petroleum products—exports: 27,150 bbl/day (2017 est.)
country comparison to the world: 64
Refined petroleum products—imports: 35,520 bbl/day (2017 est.)
country comparison to the world: 95
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 128
Natural gas—consumption: 481.4 million cu m (2017 est.)
country comparison to the world: 98
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 100
Natural gas—imports: 481.4 million cu m (2017 est.)
country comparison to the world: 67
Natural gas—proved reserves: 0 cu m (2016 est.)
country comparison to the world: 132
Carbon dioxide emissions from consumption of energy: 5.306 million
Mt (2017 est.) country comparison to the world: 133
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 3.131 billion kWh (2016 est.)
country comparison to the world: 131
Electricity—consumption: 10.5 billion kWh (2016 est.)
country comparison to the world: 95
Electricity—exports: 730 million kWh (2015 est.)
country comparison to the world: 62
Electricity—imports: 11.11 billion kWh (2016 est.)
country comparison to the world: 22
Electricity—installed generating capacity: 3.71 million kW (2016
est.)
country comparison to the world: 93
Electricity—from fossil fuels: 73% of total installed capacity
(2016 est.) country comparison to the world: 100
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 130
Electricity—from hydroelectric plants: 4% of total installed
capacity (2017 est.) country comparison to the world: 132
Electricity—from other renewable sources: 23% of total installed
Capacity (2017 est.) country comparison to the world: 31
Crude oil—production: 2,000 bbl/day (2018 est.)
country comparison to the world: 87
Crude oil—exports: 1,002 bbl/day (2015 est.)
country comparison to the world: 75
Crude oil—imports: 182,900 bbl/day (2015 est.)
country comparison to the world: 32
Crude oil—proved reserves: 12 million bbl (1 January 2018 est.)
country comparison to the world: 88
Refined petroleum products—production: 196,500 bbl/day (2015
est.)
country comparison to the world: 51
Refined petroleum products—consumption: 58,000 bbl/day (2016
est.)
country comparison to the world: 98
Refined petroleum products—exports: 174,800 bbl/day (2015 est.)
country comparison to the world: 32
Refined petroleum products—imports: 42,490 bbl/day (2015 est.)
country comparison to the world: 87
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 159
Natural gas—consumption: 2.492 billion cu m (2017 est.)
country comparison to the world: 79
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 140
Natural gas—imports: 2.492 billion cu m (2017 est.)
country comparison to the world: 47
Natural gas—proved reserves: 0 cu m (2016 est.)
country comparison to the world: 160
Carbon dioxide emissions from consumption of energy: 13.49 million
Mt (2017 est.) country comparison to the world: 97','115d371cb3ab9d7024208a0966afab36278ee0372348f6ed84971bd4650b7c72','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a58b0581df247bbd056ea308a5cc3ac5e8b65b6207a33df50bfe73fb09c0e267',2021,'MZ','Mozambique','energy',489,'Electricity access: population without electricity: 900,000
(2017) electrification—total population: 65.8% (2016)
electrification—urban areas: 82.8% (2016)
electrification—rural areas: 61.2% (2016)
Electricity—production: 381 million kWh (2016 est.)
country comparison to the world: 173
Electricity—consumption: 1.431 billion kWh (2016 est.)
country comparison to the world: 149
Electricity—exports: 0 kWh (2016)
country comparison to the world: 132
Electricity—imports: 1.077 billion kWh (2016 est.)
country comparison to the world: 69
Electricity—installed generating capacity: 295,900 kW (2016 est.)
country comparison to the world: 160
Electricity—from fossil fuels: 39% of total installed capacity
(2016 est.)
country comparison to the world: 172
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 87
Electricity—from hydroelectric plants: 20% of total installed
capacity (2017 est.) country comparison to the world: 87
Electricity—from other renewable sources: 41% of total installed
capacity (2017 est.) country comparison to the world: 6
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 133
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 120
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 124
Crude oil—proved reserves: 0 bbl (1 January 2018)
country comparison to the world: 129
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 142
Refined petroleum products—consumption: 5,300 bbl/day (2016
est.)
country comparison to the world: 175
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 152
Refined petroleum products—imports: 5,279 bbl/day (2015 est.)
country comparison to the world: 169
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 129
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 143
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 101
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 122
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 133
Carbon dioxide emissions from consumption of energy: 1.14 million
Mt (2017 est.) country comparison to the world: 166
Electricity access: DOpulation without electricity: 17 million
(2017) electrification—total population: 11% (2016)
electrification—urban areas: 42% (2016)
electrification—rural areas: 4% (2016)
Electricity—production: 1.42 billion kWh (2016 est.)
country comparison to the world: 144
Electricity—consumption: 1.321 billion kWh (2016 est.)
country comparison to the world: 150
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 164
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 170
Electricity—installed generating capacity: 375,000 kW (2016 est.)
country comparison to the world: 152
Electricity—from fossil fuels: 1% of total installed capacity (2016
est.)
country comparison to the world: 212
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 135
Electricity—from hydroelectric plants: 93% of total installed
Capacity (2017 est.)
country comparison to the world: 7
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 100
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 168
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 159
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 159
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 163
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 171
Refined petroleum products—consumption: 6,000 bbl/day (2016
est.)
country comparison to the world: 171
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 176
Refined petroleum products—imports: 4,769 bbl/day (2015 est.)
country comparison to the world: 173
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 164
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 170
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 145
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 152
Natural gas—proved reserves: 0 cu m (2017 est.)
country comparison to the world: 165
Carbon dioxide emissions from consumption of energy: 1.082 million
Mt (2017 est.)
country comparison to the world: 167
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 148.3 billion kWh (2016 est.)
country comparison to the world: 28
Electricity—consumption: 136.9 billion kWh (2016 est.)
country comparison to the world: 26
Electricity—exports: 3 million kWh (2015 est.)
country comparison to the world: 93
Electricity—imports: 33 million kWh (2016 est.)
country comparison to the world: 109
Electricity—installed generating capacity: 33 million kW (2016
est.)
country comparison to the world: 31
Electricity—from fossil fuels: 78% of total installed capacity
(2016 est.)
country comparison to the world: 90
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 136
Electricity—from hydroelectric plants: 18% of total installed
Capacity (2017 est.)
country comparison to the world: 95
Electricity—from other renewable sources: 4% of total installed
Capacity (2017 est.)
country comparison to the world: 113
Crude oil—production: 647,000 bbl/day (2018 est.)
country comparison to the world: 26
Crude oil—exports: 326,200 bbl/day (2015 est.)
country comparison to the world: 24
Crude oil—imports: 166,000 bbl/day (2015 est.)
country comparison to the world: 35
Crude oil—proved reserves: 3.6 billion bbl (1 January 2018 est.)
country comparison to the world: 27
Refined petroleum products—production: 528,300 bbl/day (2015
est.)
country comparison to the world: 32
Refined petroleum products—consumption: 704,000 bbl/day (2016
est.)
country comparison to the world: 28
Refined petroleum products—exports: 208,400 bbl/day (2015 est.)
country comparison to the world: 31
Refined petroleum products—imports: 304,600 bbl/day (2015 est.)
country comparison to the world: 24
Natural gas—production: 69.49 billion cu m (2017 est.)
country comparison to the world: 13
Natural gas—consumption: 30.44 billion cu m (2017 est.)
country comparison to the world: 31
Natural gas—exports: 38.23 billion cu m (2017 est.)
country comparison to the world: 9
Natural gas—imports: 2.803 billion cu m (2017 est.)
country comparison to the world: 45
Natural gas—proved reserves: 1.183 trillion cu m (1 January
2018 est.)
country comparison to the world: 23
Carbon dioxide emissions from consumption of energy: 226.8 million
Mt (2017 est.)
country comparison to the world: 31
Electricity access: DOpUulation without electricity: 21 million
(2017) electrification—total population: 24.2% (2016)
electrification—urban areas: 64.2% (2016)
electrification—rural areas: 5% (2016)
Electricity—production: 18.39 billion kWh (2016 est.)
country comparison to the world: 79
Electricity—consumption: 11.57 billion kWh (2016 est.)
country comparison to the world: 90
Electricity—exports: 12.88 billion kWh (2015 est.)
country comparison to the world: 16
Electricity—imports: 9.928 billion kWh (2016 est.)
country comparison to the world: 25
Electricity—installed generating capacity: 2.626 million kW (2016
est.)
country comparison to the world: 102
Electricity—from fossil fuels: 16% of total installed capacity
(2016 est.) country comparison to the world: 199
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 149
Electricity—from hydroelectric plants: 83% of total installed
capacity (2017 est.) country comparison to the world: 12
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 161
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 178
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 170
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 171
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 173
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 182
Refined petroleum products—consumption: 26,000 bbl/day (2016
est.)
country comparison to the world: 128
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 185
Refined petroleum products—imports: 25,130 bbl/day (2015 est.)
country comparison to the world: 107
Natural gas—production: 6.003 billion cu m (2017 est.)
country comparison to the world: 47
Natural gas—consumption: 1.841 billion cu m (2017 est.)
country comparison to the world: 84
Natural gas—exports: 4.162 billion cu m (2017 est.)
country comparison to the world: 32
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 161
Natural gas—proved reserves: 2.832 trillion cu m (1 January
2018 est.)
country comparison to the world: 13
Carbon dioxide emissions from consumption of energy: 11.12 million
Mt (2017 est.) country comparison to the world: 102
Electricity access: DOpUulation without electricity: 39 million
(2017)
electrification—total population: 33% (2017)
electrification—urban areas: 65% (2017)
electrification—rural areas: 17% (2017)
Electricity—production: 6.699 billion kWh (2016 est.)
country comparison to the world: 114
Electricity—consumption: 5.682 billion kWh (2016 est.)
country comparison to the world: 118
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 206
Electricity—imports: 102 million kWh (2016 est.)
country comparison to the world: 99
Electricity—installed generating capacity: 1.457 million kW (2016
est.)
country comparison to the world: 124
Electricity—from fossil fuels: 55% of total installed capacity
(2016 est.)
country comparison to the world: 141
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 192
Electricity—from hydroelectric plants: 40% of total installed
Capacity (2017 est.)
country comparison to the world: 53
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 106
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 206
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 205
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 202
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 202
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 206
Refined petroleum products—consumption: 72,000 bbl/day (2016
est.)
country comparison to the world: 92
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 207
Refined petroleum products—imports: 67,830 bbl/day (2015 est.)
country comparison to the world: 69
Natural gas—production: 3.115 billion cu m (2017 est.)
country comparison to the world: 56
Natural gas—consumption: 3.115 billion cu m (2017 est.)
country comparison to the world: 74
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 198
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 198
Natural gas—proved reserves: 6.513 billion cu m (1 January
2018 est.)
country comparison to the world: 85
Carbon dioxide emissions from consumption of energy: 14.57 million
Mt (2017 est.)
country comparison to the world: 93','f53a65d40cdbd9ed00ab01e7938db18908dbd9b08bdd8062366362af5d2c9205','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c95d4327bc3861fb7901394d94a993c28932daa7a1aabeab2fa3e4973f0320',2021,'YE','Yemen','energy',498,'Electricity access: DOpulation without electricity: 58 million
(2017) electrification—total population: 42.9% (2016)
electrification—urban areas: 85.4% (2016)
electrification—rural areas: 26.5% (2016)
Electricity—production: 11.15 billion kWh (2016 est.)
country comparison to the world: 99
Electricity—consumption: 9.062 billion kWh (2016 est.)
country comparison to the world: 100
Electricity—exports: 166 million kWh (2015 est.)
country comparison to the world: 78
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 146
Electricity—installed generating capacity: 2.784 million kW (2016
est.)
country comparison to the world: 99
Electricity—from fossil fuels: 3% of total installed capacity (2016
est.)
country comparison to the world: 207
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 88
Electricity—from hydroelectric plants: 86% of total installed
Capacity (2017 est.) country comparison to the world: 11
Electricity—from other renewable sources: 11% of total installed
capacity (2017 est.) country comparison to the world: 76
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 134
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 121
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 125
Crude oil—proved reserves: 428,000 bbl (1 January 2018 est.)
country comparison to the world: 98
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 143
Refined petroleum products—consumption: 74,000 bbl/day (2016
est.)
country comparison to the world: 89
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 153
Refined petroleum products—imports: 69,970 bbl/day (2015 est.)
country comparison to the world: 67
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 130
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 144
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 102
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 123
Natural gas—proved reserves: 24.92 billion cu m (1 January
2018 est.)
country comparison to the world: 72
Carbon dioxide emissions from consumption of energy: 12.18 million
Mt (2017 est.) country comparison to the world: 99
Electricity—production: 3.043 trillion kWh (2015 est.)
Electricity—consumption: 2.845 trillion kWh (2015 est.)
Electricity—exports: 390 billion kWh (2015 est.)
Electricity—imports: 397 billion kWh (2015 est.)
Electricity—installed generating capacity: 975 million kW (2015
est.)
Electricity—from fossil fuels: 44% of total installed capacity
(2015 est.)
Electricity—from nuclear fuels: 12% of total installed capacity
(2015 est.)
Electricity—from hydroelectric plants: 11% of total installed
Capacity (2015 est.) Electricity—from other renewable sources:
44% of total installed capacity (2015 est.) Crude oil—
production: 1.488 million bbl/day (2016 est.)
Crude oil—proved reserves: 5.1 billion bbl (2016 est.)
Refined petroleum products—production: 11.66 million bbl/day
(2016 est.)
Refined petroleum products—consumption: 12.89 million bbl/day
(2015 est.)
Refined petroleum products—exports: 2.196 million bbl/day (2017
est.)
Refined petroleum products—imports: 8.613 million bbl/day (2017
est.)
Natural gas—production: 118.2 billion cu m (2016 est.)
Natural gas—consumption: 428.8 billion cu m (2016 est.)
Natural gas—exports: 93.75 billion cu m (2010 est.)
Natural gas—imports: 420.6 billion cu m (2010 est.)
Natural gas—proved reserves: 1.3 trillion cu m (1 January 2017
est.)
Carbon dioxide emissions from consumption of energy: 3.475 billion
Mt (2015 est.) COMMUNICATIONS
Telephones—fixed lines: total subscriptions: 210,621,546
subscriptions per 100 inhabitants: 4 (2017 est.)
Telephones—mobile cellular:
total subscriptions: 625,000,799
subscriptions per 100 inhabitants: 121 (2017 est.)
Telephone system: note—see individual country entries of
member states
Internet country code: .e€u; note—see country entries of
member states for individual country codes Internet users:
total: 398.1 million (2018 est.)
percent of population: 85%
Broadband—fixed subscriptions:
total: 174,634,171
subscriptions per 100 inhabitants: 3 (2017)
Electricity—production: 19 million kWh (2016 est.)
country comparison to the world: 213
Electricity—consumption: 17.67 million kWh (2016 est.)
country comparison to the world: 213
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 133
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 147
Electricity—installed generating capacity: 12,100 kW (2016 est.)
country comparison to the world: 208
Electricity—from fossil fuels: 74% of total installed capacity
(2016 est.)
country comparison to the world: 96
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 89
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 171
Electricity—from other renewable sources: 26% of total installed
Capacity (2017 est.)
country comparison to the world: 26
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 135
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 122
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 126
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 130
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 144
Refined petroleum products—consumption: 290 bbl/day (2016 est.)
country comparison to the world: 213
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 154
Refined petroleum products—imports: 286 bbl/day (2015 est.)
country comparison to the world: 209
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 131
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 145
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 103
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 124
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 134
Carbon dioxide emissions from consumption of energy: 44,070 Mt
(2017 est.)
country comparison to the world: 211
Electricity access: electrification—total population: 99%
(2017)
electrification—urban areas: 100% (2017)
electrification—rural areas: 98% (2017)
Electricity—production: 324.1 billion kWh (2016 est.)
country comparison to the world: 11
Electricity—consumption: 296.2 billion kWh (2016 est.)
country comparison to the world: 12
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 194
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 196
Electricity—installed generating capacity: 82.94 million kW (2016
est.)
country comparison to the world: 14
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 17
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 178
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 198
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 206
Crude oil—production: 10.425 million bbl/day (2018 est.)
country comparison to the world: 3
Crude oil—exports: 7.341 million bbl/day (2015 est.)
country comparison to the world: 1
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 192
Crude oil—proved reserves: 266.2 billion bbl (1 January 2018
est.)
country comparison to the world: 2
Refined petroleum products—production: 2.476 million bbl/day
(2015 est.)
country comparison to the world: 8
Refined petroleum products—consumption: 3.287 million bbl/day
(2016 est.)
country comparison to the world: 6
Refined petroleum products—exports: 1.784 million bbl/day (2015
est.)
country comparison to the world: 5
Refined petroleum products—imports: 609,600 bbl/day (2015 est.)
country comparison to the world: 13
Natural gas—production: 109.3 billion cu m (2017 est.)
country comparison to the world: 8
Natural gas—consumption: 109.3 billion cu m (2017 est.)
country comparison to the world: 7
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 179
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 185
Natural gas—proved reserves: 8.619 trillion cu m (1 January
2018 est.)
country comparison to the world: 4
Carbon dioxide emissions from consumption of energy: 657.1 million
Mt (2017 est.)
country comparison to the world: 8','ab329c61059d953b3c2e40acc4224915af85060f91a3261fef8fd7aeb3fa3e08','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23a7a0c37422ad97f4ed8c56ccc4af35d913498c7c5915b3a16c2479d427460c',2021,'FO','Faroe Islands','energy',508,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 307 million kWh (2016 est.)
country comparison to the world: 180
Electricity—consumption: 285.5 million kWh (2016 est.)
country comparison to the world: 185
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 134
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 148
Electricity—installed generating capacity: 128,300 kW (2016 est.)
country comparison to the world: 176
Electricity—from fossil fuels: 54% of total installed capacity
(2016 est.)
country comparison to the world: 142
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 90
Electricity—from hydroelectric plants: 31% of total installed
Capacity (2017 est.)
country comparison to the world: 66
Electricity—from other renewable sources: 16% of total installed
Capacity (2017 est.)
country comparison to the world: 52
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 136
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 123
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 127
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 131
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 145
Refined petroleum products—consumption: 4,600 bbl/day (2016
est.)
country comparison to the world: 180
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 155
Refined petroleum products—imports: 4,555 bbl/day (2015 est.)
country comparison to the world: 174
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 132
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 146
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 104
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 125
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 135
Carbon dioxide emissions from consumption of energy: 739,300 Mt
(2017 est.)
country comparison to the world: 176','d055ed2fbd38e773c1d957a85a2fc2098f65ff4f11de5a399c9413ef008c9e96','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c95d0f2dbb70c51af352b0081d8be0eabdfb3a5c9ebecd28fb08974c8d7f43c0',2021,'EE','Estonia','energy',515,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 66.54 billion kWh (2016 est.)
country comparison to the world: 43
Electricity—consumption: 82.79 billion kWh (2016 est.)
country comparison to the world: 35
Electricity—exports: 3.159 billion kWh (2016 est.)
country comparison to the world: 43
Electricity—imports: 22.11 billion kWh (2016 est.)
country comparison to the world: 8
Electricity—installed generating capacity: 16.27 million kW (2016
est.)
country comparison to the world: 50
Electricity—from fossil fuels: 41% of total installed capacity
(2016 est.)
country comparison to the world: 165
Electricity—from nuclear fuels: 17% of total installed capacity
(2017 est.)
country comparison to the world: 12
Electricity—from hydroelectric plants: 20% of total installed
capacity (2017 est.)
country comparison to the world: 88
Electricity—from other renewable sources: 23% of total installed
Capacity (2017 est.)
country comparison to the world: 30
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 138
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 125
Crude oil—imports: 236,700 bbl/day (2017 est.)
country comparison to the world: 27
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 133
Refined petroleum products—production: 310,600 bbl/day (2017
est.)
country comparison to the world: 40
Refined petroleum products—consumption: 217,100 bbl/day (2017
est.)
country comparison to the world: 55
Refined petroleum products—exports: 166,200 bbl/day (2017 est.)
country comparison to the world: 34
Refined petroleum products—imports: 122,200 bbl/day (2017 est.)
country comparison to the world: 48
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 134
Natural gas—consumption: 2.35 billion cu m (2017 est.)
country comparison to the world: 81
Natural gas—exports: 4 million cu m (2017 est.)
country comparison to the world: 54
Natural gas—imports: 2.322 billion cu m (2017 est.)
country comparison to the world: 49
Natural gas—proved reserves: NA cu m (1 January 2016 est.)
Carbon dioxide emissions from consumption of energy: 46.01 million
Mt (2017 est.)
country comparison to the world: 64','492ceb4fba80ce6f5fa58884ea095f8f4c2d494e4aae8e71380403ba040c1438','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d79a784b973e9d830bbb5594808a9c5fd3ae5bf6bbfbb29a9bc52f102637119',2021,'PF','French Polynesia','energy',523,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 677.3 million kWh (2016 est.)
country comparison to the world: 158
Electricity—consumption: 629.9 million kWh (2016 est.)
country comparison to the world: 164
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 136
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 150
Electricity—installed generating capacity: 253,000 kW (2016 est.)
country comparison to the world: 163
Electricity—from fossil fuels: 70% of total installed capacity
(2016 est.)
country comparison to the world: 108
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 92
Electricity—from hydroelectric plants: 19% of total installed
Capacity (2017 est.)
country comparison to the world: 89
Electricity—from other renewable sources: 11% of total installed
Capacity (2017 est.)
country comparison to the world: 77
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 139
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 127
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 129
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 134
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 147
Refined petroleum products—consumption: 6,600 bbl/day (2016
est.)
country comparison to the world: 168
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 157
Refined petroleum products—imports: 6,785 bbl/day (2015 est.)
country comparison to the world: 160
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 135
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 148
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 106
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 127
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 137
Carbon dioxide emissions from consumption of energy: 1.03 million
Mt (2017 est.)
country comparison to the world: 168
Electricity access: population without electricity: 200,000
(2017) electrification—total population: 91.4% (2016)
electrification—urban areas: 96.7% (2016)
electrification—rural areas: 55% (2016)
Electricity—production: 2.244 billion kWh (2016 est.)
country comparison to the world: 137
Electricity—consumption: 2.071 billion kWh (2016 est.)
country comparison to the world: 143
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 137
Electricity—imports: 344 million kWh (2016 est.)
country comparison to the world: 85
Electricity—installed generating capacity: 671,000 kW (2016 est.)
country comparison to the world: 137
Electricity—from fossil fuels: 51% of total installed capacity
(2016 est.)
country comparison to the world: 148
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 93
Electricity—from hydroelectric plants: 49% of total installed
Capacity (2017 est.)
country comparison to the world: 41
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 186
Crude oil—production: 196,000 bbl/day (2018 est.)
country comparison to the world: 35
Crude oil—exports: 214,200 bbl/day (2017 est.)
country comparison to the world: 30
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 130
Crude oil—proved reserves: 2 billion bbl (1 January 2018 est.)
country comparison to the world: 34
Refined petroleum products—production: 16,580 bbl/day (2017
est.)
country comparison to the world: 91
Refined petroleum products—consumption: 24,000 bbl/day (2016
est.)
country comparison to the world: 129
Refined petroleum products—exports: 4,662 bbl/day (2015 est.)
country comparison to the world: 91
Refined petroleum products—imports: 10,680 bbl/day (2015 est.)
country comparison to the world: 146
Natural gas—production: 401 million cu m (2017 est.)
country comparison to the world: 74
Natural gas—consumption: 401 million cu m (2017 est.)
country comparison to the world: 101
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 107
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 128
Natural gas—proved reserves: 28.32 billion cu m (1 January
2018 est.)
country comparison to the world: 69
Carbon dioxide emissions from consumption of energy: 4.293 million
Mt (2017 est.)
country comparison to the world: 137
Electricity access: DOpulation without electricity: 1 million
(2017) electrification—total population: 47.8% (2016)
electrification—urban areas: 69% (2016)
electrification—rural areas: 15.5% (2016)
Electricity—production: 304.1 million kWh (2016 est.)
country comparison to the world: 182
Electricity—consumption: 282.8 million kWh (2016 est.)
country comparison to the world: 186
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 138
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 151
Electricity—installed generating capacity: 117,000 kW (2016 est.)
country comparison to the world: 178
Electricity—from fossil fuels: 97% of total installed capacity
(2016 est.)
country comparison to the world: 34
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 94
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 172
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 125
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 140
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 128
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 131
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 135
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 148
Refined petroleum products—consumption: 3,800 bbl/day (2016
est.)
country comparison to the world: 185
Refined petroleum products—exports: 42 bbl/day (2015 est.)
country comparison to the world: 122
Refined petroleum products—imports: 3,738 bbl/day (2015 est.)
country comparison to the world: 181
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 136
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 149
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 108
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 129
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 138
Carbon dioxide emissions from consumption of energy: 607,300 Mt
(2017 est.)
country comparison to the world: 180','3b3137ae78c0a1e8973fa496d0f5d83247661917e48af165d92b046a76681d35','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30185025234272b48274cd932e69109cf9efcf5359f0521332aafab8fbff259b',2021,'IL','Israel','energy',530,'Electricity access: population without electricity: 80,930
(2012) electrification—total population: 98% (2012)
electrification—urban areas: 99% (2012)
electrification—rural areas: 93% (2012)
note: data for Gaza Strip and West Bank combined
Electricity—production: 51,000 kWh (2011 est.)
country comparison to the world: 218
Electricity—consumption: 202,000 kWh (2009 est.)
country comparison to the world: 216
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 139
Electricity—imports: 193,000 kWh (2011 est.)
country comparison to the world: 117
Crude oil—proved reserves: 0 bbl (1 January 2010 est.)
country comparison to the world: 136
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 13.24 billion kWh (2016 est.)
country comparison to the world: 91
Electricity—consumption: 12.37 billion kWh (2016 est.)
country comparison to the world: 87
Electricity—exports: 560 million kWh (2016 est.)
country comparison to the world: 66
Electricity—imports: 1.329 billion kWh (2016 est.)
country comparison to the world: 63
Electricity—installed generating capacity: 4.641 million kW (2016
est.)
country comparison to the world: 84
Electricity—from fossil fuels: 35% of total installed capacity
(2016 est.)
country comparison to the world: 179
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 95
Electricity—from hydroelectric plants: 65% of total installed
Capacity (2017 est.)
country comparison to the world: 22
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 187
Crude oil—production: 400 bbl/day (2018 est.)
country comparison to the world: 93
Crude oil—exports: 3,006 bbl/day (2017 est.)
country comparison to the world: 68
Crude oil—imports: 2,660 bbl/day (2015 est.)
country comparison to the world: 78
Crude oil—proved reserves: 35 million bbl (1 January 2018 est.)
country comparison to the world: 80
Refined petroleum products—production: 247 bbl/day (2017 est.)
country comparison to the world: 106
Refined petroleum products—consumption: 27,000 bbl/day (2016
est.)
country comparison to the world: 122
Refined petroleum products—exports: 2,052 bbl/day (2015 est.)
country comparison to the world: 104
Refined petroleum products—imports: 28,490 bbl/day (2015 est.)
country comparison to the world: 101
Natural gas—production: 7.363 million cu m (2017 est.)
country comparison to the world: 95
Natural gas—consumption: 2.294 billion cu m (2017 est.)
country comparison to the world: 83
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 109
Natural gas—imports: 2.294 billion cu m (2017 est.)
country comparison to the world: 50
Natural gas—proved reserves: 8.495 billion cu m (1 January
2018 est.)
country comparison to the world: 80
Carbon dioxide emissions from consumption of energy: 9.912 million
Mt (2017 est.)
country comparison to the world: 109','129d18ddde2aee4bcbd568a0df37d384a457389585abb5b732104ab2d1eb03fe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e23e6a56b3e0609a7d6e0c117e0c75e36ea434b4465366d159d2f9c2bd0cd82d',2021,'AT','Austria','energy',542,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 612.8 billion kWh (2016 est.)
country comparison to the world: 7
Electricity—consumption: billion kWh (2016 est.)
country comparison to the world: 6
Electricity—exports: 78.86 billion kWh (2016 est.)
country comparison to the world: 1
Electricity—imports: 28.34 billion kWh (2016 est.)
country comparison to the world: 5
Electricity—installed generating capacity: 208.5 million kW (2016
est.)
country comparison to the world: 6
Electricity—from fossil fuels: 41% of total installed capacity
(2016 est.)
country comparison to the world: 166
Electricity—from nuclear fuels: 5% of total installed capacity
(2017 est.)
country comparison to the world: 21
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 137
Electricity—from other renewable sources: 52% of total installed
capacity (2017 est.) country comparison to the world: 4
Crude oil—production: 41,000 bbl/day (2018 est.)
country comparison to the world: 56
Crude oil—exports: 6,569 bbl/day (2017 est.)
country comparison to the world: 63
Crude oil—imports: 1.836 million bbl/day (2017 est.)
country comparison to the world: 6
Crude oil—proved reserves: 129.6 million bbl (1 January 2018
est.)
country comparison to the world: 65
Refined petroleum products—production: 2.158 million bbl/day
(2017 est.)
country comparison to the world: 9
Refined petroleum products—consumption: 2.46 million bbl/day
(2017 est.)
country comparison to the world: 9
Refined petroleum products—exports: 494,000 bbl/day (2017 est.)
country comparison to the world: 17
Refined petroleum products—imports: 883,800 bbl/day (2017 est.)
country comparison to the world: 9
Natural gas—production: 7.9 billion cu m (2017 est.)
country comparison to the world: 45
Natural gas—consumption: 93.36 billion cu m (2017 est.)
country comparison to the world: 8
Natural gas—exports: 34.61 billion cum (2017 est.)
country comparison to the world: 11
Natural gas—imports: 119.5 billion cu m (2017 est.)
country comparison to the world: 1
Natural gas—proved reserves: 39.5 billion cu m (1 January 2018
est.)
country comparison to the world: 64
Carbon dioxide emissions from consumption of energy: 847.6 million
Mt (2017 est.)
country comparison to the world: 6
Electricity access: DOpUulation without electricity: 5 million
(2017) electrification—total population: 79.3% (2016)
electrification—urban areas: 89.8% (2016)
electrification—rural areas: 66.6% (2016)
Electricity—production: 12.52 billion kWh (2016 est.)
country comparison to the world: 94
Electricity—consumption: 9.363 billion kWh (2016 est.)
country comparison to the world: 99
Electricity—exports: 187 million kWh (2016 est.)
country comparison to the world: 76
Electricity—imports: 511 million kWh (2016 est.)
country comparison to the world: 79
Electricity—installed generating capacity: 3.801 million kW (2016
est.)
country comparison to the world: 92
Electricity—from fossil fuels: 58% of total installed capacity
(2016 est.)
country comparison to the world: 135
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 96
Electricity—from hydroelectric plants: 42% of total installed
Capacity (2017 est.)
country comparison to the world: 48
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 153
Crude oil—production: 173,000 bbl/day (2018 est.)
country comparison to the world: 37
Crude oil—exports: 104,000 bbl/day (2017 est.)
country comparison to the world: 34
Crude oil—imports: 6,220 bbl/day (2015 est.)
country comparison to the world: 74
Crude oil—proved reserves: 660 million bbl (1 January 2018
est.)
country comparison to the world: 41
Refined petroleum products—production: 2,073 bbl/day (2015 est.)
country comparison to the world: 104
Refined petroleum products—consumption: 90,000 bbl/day (2016
est.)
country comparison to the world: 83
Refined petroleum products—exports: 2,654 bbl/day (2015 est.)
country comparison to the world: 100
Refined petroleum products—imports: 85,110 bbl/day (2015 est.)
country comparison to the world: 59
Natural gas—production: 914.4 million cu m (2017 est.)
country comparison to the world: 68
Natural gas—consumption: 1.232 billion cu m (2017 est.)
country comparison to the world: 87
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 110
Natural gas—imports: 317.4 million cu m (2017 est.)
country comparison to the world: 68
Natural gas—proved reserves: 22.65 billion cu m (1 January
2018 est.)
country comparison to the world: 73
Carbon dioxide emissions from consumption of energy: 13.67 million
Mt (2017 est.)
country comparison to the world: 96','82ccb15f2258de04265a02d3ed408b3bbe0eb37368aab786fa2fe105a4f06281','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d70c38d893bf37248fa938aecc8a1ab04239d23095e9ee7a734a61c65c2eaf85',2021,'GI','Gibraltar','energy',549,'Electricity—production: 238.8 million kWh (2016 est.)
country comparison to the world: 187
Electricity—consumption: 230.8 million kWh (2016 est.)
country comparison to the world: 189
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 140
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 152
Electricity—installed generating capacity: 43,000 kW (2016 est.)
country comparison to the world: 196
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 8
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 97
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.)
country comparison to the world: 173
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 188
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 141
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 129
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 132
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 137
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 149
Refined petroleum products—consumption: 78,000 bbl/day (2016
est.)
country comparison to the world: 88
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 158
Refined petroleum products—imports: 74,200 bbl/day (2015 est.)
country comparison to the world: 66
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 137
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 150
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 111
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 130
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 139
Carbon dioxide emissions from consumption of energy: 13.34 million
Mt (2017 est.)
country comparison to the world: 98
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 52.05 billion kWh (2016 est.)
country comparison to the world: 53
Electricity—consumption: 56.89 billion kWh (2016 est.)
country comparison to the world: 45
Electricity—exports: 1.037 billion kWh (2016 est.)
country comparison to the world: 58
Electricity—imports: 9.833 billion kWh (2016 est.)
country comparison to the world: 27
Electricity—installed generating capacity: 19.17 million kW (2016
est.)
country comparison to the world: 46
Electricity—from fossil fuels: 57% of total installed capacity
(2016 est.)
country comparison to the world: 137
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 98
Electricity—from hydroelectric plants: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 105
Electricity—from other renewable sources: 29% of total installed
capacity (2017 est.)
country comparison to the world: 19
Crude oil—production: 4,100 bbl/day (2018 est.)
country comparison to the world: 80
Crude oil—exports: 3,229 bbl/day (2017 est.)
country comparison to the world: 67
Crude oil—imports: 484,300 bbl/day (2017 est.)
country comparison to the world: 20
Crude oil—proved reserves: 10 million bbl (1 January 2018 est.)
country comparison to the world: 90
Refined petroleum products—production: 655,400 bbl/day (2017
est.)
country comparison to the world: 28
Refined petroleum products—consumption: 304,100 bbl/day (2017
est.)
country comparison to the world: 43
Refined petroleum products—exports: 371,900 bbl/day (2017 est.)
country comparison to the world: 22
Refined petroleum products—imports: 192,200 bbl/day (2017 est.)
country comparison to the world: 35
Natural gas—production: 8 million cu m (2017 est.)
country comparison to the world: 93
Natural gas—consumption: 4.927 billion cu m (2017 est.)
country comparison to the world: 61
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 112
Natural gas—imports: 4.984 billion cu m (2017 est.)
country comparison to the world: 36
Natural gas—proved reserves: 991.1 million cu m (1 January
2018 est.)
country comparison to the world: 100
Carbon dioxide emissions from consumption of energy: 69.37 million
Mt (2017 est.)
country comparison to the world: 51','603c5fc24270495e8d8440298f4d98ff872a35c63362a84ed851304a3c55782f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('569ccc25c844c3cdd840ad1b3eee914443d255ae8d3ad984590cb1e5d533b3aa',2021,'GD','Grenada','energy',556,'Electricity access: electrification—total population: 92.3%
(2016) electrification—urban areas: 92.3% (2016)
electrification—rural areas: 92.3% (2016)
Electricity—production: 202.1 million kWh (2016 est.)
country comparison to the world: 192
Electricity—consumption: 185.1 million kWh (2016 est.)
country comparison to the world: 194
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 142
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 154
Electricity—installed generating capacity: 51,100 kW (2016 est.)
country comparison to the world: 191
Electricity—from fossil fuels: 96% of total installed capacity
(2016 est.)
country comparison to the world: 39
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 100
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 174
Electricity—from other renewable sources: 4% of total installed
capacity (2017 est.)
country comparison to the world: 112
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 143
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 131
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 134
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 139
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 151
Refined petroleum products—consumption: 2,000 bbl/day (2016
est.)
country comparison to the world: 194
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 160
Refined petroleum products—imports: 1,886 bbl/day (2015 est.)
country comparison to the world: 191
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 139
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 152
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 114
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 132
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 141
Carbon dioxide emissions from consumption of energy: 283,600 Mt
(2017 est.)
country comparison to the world: 193
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 1.722 billion kWh (2016 est.)
country comparison to the world: 141
Electricity—consumption: 1.601 billion kWh (2016 est.)
country comparison to the world: 146
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 143
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 155
Electricity—installed generating capacity: 560,000 kW (2016 est.)
country comparison to the world: 143
Electricity—from fossil fuels: 94% of total installed capacity
(2016 est.)
country comparison to the world: 46
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 101
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 175
Electricity—from other renewable sources: 6% of total installed
capacity (2017 est.)
country comparison to the world: 98
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 144
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 132
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 135
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 140
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 152
Refined petroleum products—consumption: 14,000 bbl/day (2016
est.)
country comparison to the world: 153
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 161
Refined petroleum products—imports: 13,500 bbl/day (2015 est.)
country comparison to the world: 141
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 140
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 153
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 115
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 133
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 142
Carbon dioxide emissions from consumption of energy: 2.214 million
Mt (2017 est.)
country comparison to the world: 157','dcc4f8a7f9908c55cbb006be1e821806fb8b7bab7f987c526f60a856753a22e8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af56d0309abe163d704944adfaae974c0b21325ae69151705d662390f910108f',2021,'SV','El Salvador','energy',567,'Electricity access: DOpulation without electricity: 1 million
(2017) electrification—total population: 91.8% (2016)
electrification—urban areas: 96.8% (2016)
electrification—rural areas: 86.4% (2016)
Electricity—production: 12.12 billion kWh (2016 est.) country
comparison to the world: 96
Electricity—consumption: 10.1 billion kWh (2016 est.)
country comparison to the world: 96
Electricity—exports: 1.858 billion kWh (2017 est.)
country comparison to the world: 47
Electricity—imports: 747 million kWh (2016 est.)
country comparison to the world: 75
Electricity—installed generating capacity: 4.605 million kW (2016
est.)
country comparison to the world: 85
Electricity—from fossil fuels: 41% of total installed capacity
(2016 est.)
country comparison to the world: 167
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 102
Electricity—from hydroelectric plants: 31% of total installed
Capacity (2017 est.)
country comparison to the world: 67
Electricity—from other renewable sources: 28% of total installed
capacity (2017 est.) country comparison to the world: 23
Crude oil—production: 9,600 bbl/day (2018 est.)
country comparison to the world: 78
Crude oil—exports: 9,383 bbl/day (2017 est.)
country comparison to the world: 59
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 136
Crude oil—proved reserves: 83.07 million bbl (1 January 2018
est.)
country comparison to the world: 71
Refined petroleum products—production: 1,162 bbl/day (2015 est.)
country comparison to the world: 105
Refined petroleum products—consumption: 89,000 bbl/day (2016
est.)
country comparison to the world: 84
Refined petroleum products—exports: 10,810 bbl/day (2015 est.)
country comparison to the world: 80
Refined petroleum products—imports: 97,900 bbl/day (2015 est.)
country comparison to the world: 55
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 141
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 154
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 116
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 134
Natural gas—proved reserves: 2.96 billion cu m (1 January 2006
est.)
country comparison to the world: 94
Carbon dioxide emissions from consumption of energy: 17.15 million
Mt (2017 est.)
country comparison to the world: 91
Electricity access: electrification—total population: 100%
(2016) COMMUNICATIONS
Telephones—fixed lines: total subscriptions: 36,547
subscriptions per 100 inhabitants: 60 (July 2016 est.)
country comparison to the world: 166
Telephones—mobile cellular:
total subscriptions: 71,249
subscriptions per 100 inhabitants: 113 (July 2016 est.)
country comparison to the world: 199
Telephone system: general assessment: high performance
global connections with quality service; connections to
major cities around the world to rival and attract future
investment and future needs of islanders and businesses
(2018) domestic: fixed-line 60 per 100 and mobile-cellular
113 per 100 persons (2018)
international: country code—44; landing points for
Guernsey-Jersey, HUGO, INGRID, Channel Islands -9
Liberty and UkK-Channel Islands-7 submarine cable to UK
and France (2019) Broadcast media: multiple UK terrestrial
TV broadcasts are received via a transmitter in Jersey with
relays in Jersey, Guernsey, and Alderney; satellite packages
are available; BBC Radio Guernsey and 1 other radio
station operating Internet country code: .gg
Internet users: total: 55,050
percent of population: 83.3% (July 2016 est.)
country comparison to the world: 190','6ce187817fc5dd368f8c00b9f6e8bc7500c3708a5e606fb20c6dfeb820ec401a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afb47bd9a883e714ff39521663d829060031c05fcecfa1956496644ff0624c88',2021,'LR','Liberia','energy',576,'Electricity access: DODUulation without electricity: 11 million
(2017) electrification—total population: 33.5% (2016)
electrification—urban areas: 82.2% (2016)
electrification—rural areas: 6.9% (2016)
Electricity—production: 598 million kWh (2016 est.)
country comparison to the world: 162
Electricity—consumption: 556.1 million kWh (2016 est.)
country comparison to the world: 168
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 144
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 156
Electricity—installed generating capacity: 550,000 kW (2016 est.)
country comparison to the world: 145
Electricity—from fossil fuels: 33% of total installed capacity
(2016 est.)
country comparison to the world: 182
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 103
Electricity—from hydroelectric plants: 67% of total installed
Capacity (2017 est.)
country comparison to the world: 20
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 190
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 145
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 133
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 137
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 141
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 153
Refined petroleum products—consumption: 19,000 bbl/day (2016
est.)
country comparison to the world: 143
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 162
Refined petroleum products—imports: 18,460 bbl/day (2015 est.)
country comparison to the world: 128
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 142
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 155
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 117
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 135
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 143
Carbon dioxide emissions from consumption of energy: 2.794 million
Mt (2017 est.)
country comparison to the world: 149
Electricity access: DOpulation without electricity: 4 million
(2017)
electrification—total population: 19.8% (2016)
electrification—urban areas: 34% (2016)
electrification—rural areas: 1.3% (2016)
Electricity—production: 300 million kWh (2016 est.)
note: according to a 2014 household survey, only 4.5% of
Liberians use Liberia Electricity Corporation (LEC) power,
4.9% use a community generator, 4.4% have their own
generator, 3.9% use vehicle batteries, and 0.8% use other
sources of electricity, and 81.3% have no access to
electricity; LEC accounts for roughly 70 million kWh of
ouput.
country comparison to the world: 184
Electricity—consumption: 279 million kWh (2016 est.)
country comparison to the world: 187
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 159
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 168
Electricity—installed generating capacity: 151,000 kW (2016 est.)
country comparison to the world: 173
Electricity—from fossil fuels: 57% of total installed capacity
(2016 est.)
country comparison to the world: 138
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 128
Electricity—from hydroelectric plants: 43% of total installed
Capacity (2017 est.)
country comparison to the world: 46
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 198
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 163
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 155
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 153
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 158
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 166
Refined petroleum products—consumption: 8,000 bbl/day (2016
est.)
country comparison to the world: 164
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 172
Refined petroleum products—imports: 8,181 bbl/day (2015 est.)
country comparison to the world: 152
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 158
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 168
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 139
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 149
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 159
Carbon dioxide emissions from consumption of energy: 1.163 million
Mt (2017 est.)
country comparison to the world: 164
Electricity access: electrification—total population: 98.5%
(2016) electrification—urban areas: 99.1% (2016)
electrification—rural areas: 96.4% (2016)
Electricity—production: 34.24 billion kWh (2016 est.)
note: persistent electricity shortages have contributed to
the ongoing instability throughout the country country
comparison to the world: 61
Electricity—consumption: 27.3 billion kWh (2016 est.)
country comparison to the world: 65
Electricity—exports: 0 kWh (2015 est.)
country comparison to the world: 160
Electricity—imports: 376 million kWh (2016 est.)
country comparison to the world: 83
Electricity—installed generating capacity: 9.46 million kW (2016
est.)
country comparison to the world: 62
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.) country comparison to the world: 11
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 129
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.) country comparison to the world: 183
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.) country comparison to the world: 199
Crude oil—production: 1.039 million bbl/day (2018 est.)
country comparison to the world: 19
Crude oil—exports: 337,800 bbl/day (2015 est.)
note: Libyan crude oil export values are highly volatile
because of continuing protests and other disruptions across
the country country comparison to the world: 23
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 154
Crude oil—proved reserves: 48.36 billion bbl (1 January 2018
est.)
country comparison to the world: 9
Refined petroleum products—production: 89,620 bbl/day (2015
est.)
country comparison to the world: 69
Refined petroleum products—consumption: 260,000 bbl/day (2016
est.)
country comparison to the world: 49
Refined petroleum products—exports: 16,880 bbl/day (2015 est.)
country comparison to the world: 71
Refined petroleum products—imports: 168,200 bbl/day (2015 est.)
country comparison to the world: 36
Natural gas—production: 9.089 billion cu m (2017 est.)
country comparison to the world: 43
Natural gas—consumption: 4.446 billion cu m (2017 est.)
country comparison to the world: 64
Natural gas—exports: 4.644 billion cu m (2017 est.)
country comparison to the world: 31
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 150
Natural gas—proved reserves: 1.505 trillion cu m (1 January
2018 est.)
country comparison to the world: 21
Carbon dioxide emissions from consumption of energy: 46.48 million
Mt (2017 est.) country comparison to the world: 62
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 68.43 million kWh (2015 est.)
country comparison to the world: 202
Electricity—consumption: 393.6 million kWh (2015 est.)
country comparison to the world: 174
Electricity—exports: 0 kWh (2015 est.) (2015 est.)
country comparison to the world: 161
Electricity—imports: 325.2 million kWh (2015 est.)
country comparison to the world: 88','ec341c1ad71d691bb3d346731d6725ebb4a560cb6070c9b413571a2ad949afdb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff7d8703a51c6fae0384e6c865a6604c8205bc84e68f1c51ec3972cf37478c20',2021,'IE','Ireland','energy',598,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 28.53 billion kWh (2016 est.)
country comparison to the world: 69
Electricity—consumption: 25.68 billion kWh (2016 est.)
country comparison to the world: 68
Electricity—exports: 1.583 billion kWh (2016 est.)
country comparison to the world: 48
Electricity—imports: 871 million kWh (2016 est.)
country comparison to the world: 71
Electricity—installed generating capacity: 9.945 million kW (2016
est.)
country comparison to the world: 61
Electricity—from fossil fuels: 65% of total installed capacity
(2016 est.) country comparison to the world: 117
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 112
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 138
Electricity—from other renewable sources: 33% of total installed
Capacity (2017 est.)
country comparison to the world: 12
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 152
Crude oil—exports: 5,900 bbl/day (2017 est.)
country comparison to the world: 64
Crude oil—imports: 66,210 bbl/day (2017 est.)
country comparison to the world: 50
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 148
Refined petroleum products—production: 64,970 bbl/day (2017
est.)
country comparison to the world: 76
Refined petroleum products—consumption: 153,700 bbl/day (2017
est.)
country comparison to the world: 66
Refined petroleum products—exports: 37,040 bbl/day (2017 est.)
country comparison to the world: 59
Refined petroleum products—imports: 126,600 bbl/day (2017 est.)
country comparison to the world: 47
Natural gas—production: 3.511 billion cu m (2017 est.)
country comparison to the world: 54
Natural gas—consumption: 5.238 billion cu m (2017 est.)
country comparison to the world: 55
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 125
Natural gas—imports: 1.642 billion cu m (2017 est.)
country comparison to the world: 55
Natural gas—proved reserves: 9.911 billion cu m (1 January
2018 est.)
country comparison to the world: 79
Carbon dioxide emissions from consumption of energy: 36.91 million
Mt (2017 est.)
country comparison to the world: 71
Electricity access: electrification—total population: 100%
(2016)','81dce49413efc2ef73d720c0f1d6e50faaad4e990a6f397b9bfb10041a20c143','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bffd02f0dce24ca080a58e2a7efdbd4105f040070807170fc99cf04fcb0676b',2021,'CU','Cuba','energy',611,'Electricity access: electrification—total population: 98.2%
(2016) electrification—urban areas: 100% (2016)
electrification—rural areas: 96% (2016)
Electricity—production: 4.007 billion kWh (2016 est.)
country comparison to the world: 128
Electricity—consumption: 2.847 billion kWh (2016 est.)
country comparison to the world: 137
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 151
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 162
Electricity—installed generating capacity: 1.078 million kW (2016
est.) country comparison to the world: 126
Electricity—from fossil fuels: 83% of total installed capacity
(2016 est.) country comparison to the world: 76
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 115
Electricity—from hydroelectric plants: 3% of total installed
capacity (2017 est.) country comparison to the world: 134
Electricity—from other renewable sources: 15% of total installed
capacity (2017 est.) country comparison to the world: 59
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 153
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 142
Crude oil—imports: 24,360 bbl/day (2015 est.)
country comparison to the world: 61
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 149
Refined petroleum products—production: 24,250 bbl/day (2017
est.)
country comparison to the world: 87
Refined petroleum products—consumption: 55,000 bbl/day (2016
est.)
country comparison to the world: 99
Refined petroleum products—exports: 823 bbl/day (2015 est.)
country comparison to the world: 109
Refined petroleum products—imports: 30,580 bbl/day (2015 est.)
country comparison to the world: 100
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 149
Natural gas—consumption: 198.2 million cu m (2017 est.)
country comparison to the world: 104
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 127
Natural gas—imports: 198.2 million cu m (2017 est.)
country comparison to the world: 71
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 150
Carbon dioxide emissions from consumption of energy: 8.9 million
Mt (2017 est.) country comparison to the world: 112
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 989.3 billion kWh (2016 est.)
country comparison to the world: 5
Electricity—consumption: 943.7 billion kWh (2016 est.)
country comparison to the world: 4
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 152
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 163
Electricity—installed generating capacity: 295.9 million kW (2016
est.) country comparison to the world: 4
Electricity—from fossil fuels: 71% of total installed capacity
(2016 est.) country comparison to the world: 105
Electricity—from nuclear fuels: 1% of total installed capacity
(2017 est.) country comparison to the world: 30
Electricity—from hydroelectric plants: 8% of total installed
capacity (2017 est.) country comparison to the world: 121
Electricity—from other renewable sources: 20% of total installed
capacity (2017 est.) country comparison to the world: 38
Crude oil—production: 3,200 bbl/day (2018 est.)
country comparison to the world: 82
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 143
Crude oil—imports: 3.208 million bbl/day (2017 est.)
country comparison to the world: 4
Crude oil—proved reserves: 44.12 million bbl (1 January 2018
est.)
country comparison to the world: 77
Refined petroleum products—production: 3.467 million bbl/day
(2017 est.) country comparison to the world: 5
Refined petroleum products—consumption: 3.894 million bbl/day
(2017 est.) country comparison to the world: 4
Refined petroleum products—exports: 370,900 bbl/day (2017 est.)
country comparison to the world: 24
Refined petroleum products—imports: 1.1 million bbl/day (2017
est.)
country comparison to the world: 5
Natural gas—production: 3.058 billion cu m (2017 est.)
country comparison to the world: 57
Natural gas—consumption: 127.2 billion cu m (2017 est.)
country comparison to the world: 5
Natural gas—exports: 169.9 million cu m (2017 est.)
country comparison to the world: 47
Natural gas—imports: 116.6 billion cu m (2017 est.)
country comparison to the world: 2
Natural gas—proved reserves: 20.9 billion cu m (1 January 2018
est.)
country comparison to the world: 74
Carbon dioxide emissions from consumption of energy: 1.268 billion
Mt (2017 est.) country comparison to the world: 5
Electricity access: electrification—total population: 100%
(2016) Electricity—production: NA (2017)
Electricity—consumption: 630.1 million kWh (2004 est.)
country comparison to the world: 163
Carbon dioxide emissions from consumption of energy: 450,000 Mt
(2012 est.) country comparison to the world: 185','7b8d392a6b82a9672eca5dc8de8ff206061f588314d9347da330eae9a91e2d4d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6861adb791619a6e5722a7eef4189f86ac7967e186f1de1c2a9dd09944000bab',2021,'JO','Jordan','energy',620,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 18.6 billion kWh (2016 est.)
country comparison to the world: 77
Electricity—consumption: 16.82 billion kWh (2016 est.)
country comparison to the world: 74
Electricity—exports: 50 million kWh (2015 est.)
country comparison to the world: 88
Electricity—imports: 334 million kWh (2016 est.)
country comparison to the world: 86
Electricity—installed generating capacity: 4.764 million kW (2016
est.) country comparison to the world: 82
Electricity—from fossil fuels: 87% of total installed capacity
(2016 est.) country comparison to the world: 62
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 116
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.) country comparison to the world: 180
Electricity—from other renewable sources: 12% of total installed
capacity (2017 est.) country comparison to the world: 74
Crude oil—production: 22 bbl/day (2018 est.)
country comparison to the world: 99
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 144
Crude oil—imports: 67,980 bbl/day (2015 est.)
country comparison to the world: 49
Crude oil—proved reserves: 1 million bbl (1 January 2018 est.)
country comparison to the world: 96
Refined petroleum products—production: 67,240 bbl/day (2015
est.)
country comparison to the world: 73
Refined petroleum products—consumption: 139,000 bbl/day (2016
est.)
country comparison to the world: 69
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 166
Refined petroleum products—imports: 68,460 bbl/day (2015 est.)
country comparison to the world: 68
Natural gas—production: 121.8 million cu m (2017 est.)
country comparison to the world: 80
Natural gas—consumption: 5.238 billion cu m (2017 est.)
country comparison to the world: 56
Natural gas—exports: 1.359 billion cu m (2017 est.)
country comparison to the world: 38
Natural gas—imports: 6.456 billion cu m (2017 est.)
country comparison to the world: 31
Natural gas—proved reserves: 6.031 billion cu m (1 January
2018 est.)
country comparison to the world: 87
Carbon dioxide emissions from consumption of energy: 27.39 million
Mt (2017 est.) country comparison to the world: 76','5e8e9067903a23aaa2f870298c5958cdb4ec000d9c3c3864b107c9879c1d2a3d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cbffa6602e793b3afdb2feaec61b339e5966c3659ad3b6f49259d6eba2b60f5',2021,'KZ','Kazakhstan','energy',629,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 100.8 billion kWh (2016 est.)
country comparison to the world: 35
Electricity—consumption: 94.23 billion kWh (2016 est.)
country comparison to the world: 33
Electricity—exports: 5.1 billion kWh (2017 est.)
country comparison to the world: 37
Electricity—imports: 1.318 billion kWh (2016 est.)
country comparison to the world: 64
Electricity—installed generating capacity: 20.15 million kW (2016
est.)
country comparison to the world: 44
Electricity—from fossil fuels: 86% of total installed capacity
(2016 est.)
country comparison to the world: 66
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 117
Electricity—from hydroelectric plants: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 107
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 155
Crude oil—production: 1.856 million bbl/day (2018 est.)
country comparison to the world: 12
Crude oil—exports: 1.409 million bbl/day (2015 est.)
country comparison to the world: 9
Crude oil—imports: 1,480 bbl/day (2015 est.)
country comparison to the world: 79
Crude oil—proved reserves: 30 billion bbl (1 January 2018 est.)
country comparison to the world: 11
Refined petroleum products—production: 290,700 bbl/day (2015
est.)
country comparison to the world: 44
Refined petroleum products—consumption: 274,000 bbl/day (2016
est.)
country comparison to the world: 46
Refined petroleum products—exports: 105,900 bbl/day (2015 est.)
country comparison to the world: 41
Refined petroleum products—imports: 39,120 bbl/day (2015 est.)
country comparison to the world: 90
Natural gas—production: 22.41 billion cu m (2017 est.)
country comparison to the world: 30
Natural gas—consumption: 15.37 billion cu m (2017 est.)
country comparison to the world: 43
Natural gas—exports: 12.8 billion cu m (2017 est.)
country comparison to the world: 17
Natural gas—imports: 5.748 billion cu m (2017 est.)
country comparison to the world: 34
Natural gas—proved reserves: 2.407 trillion cu m (1 January
2018 est.)
country comparison to the world: 14
Carbon dioxide emissions from consumption of energy: 304.6 million
Mt (2017 est.)
country comparison to the world: 23
Electricity access: Population without electricity: 13 million
(2017)
electrification—total population: 56% (2016)
electrification—urban areas: 77.6% (2016)
electrification—rural areas: 39.3% (2016)
Electricity—production: 9.634 billion kWh (2016 est.)
country comparison to the world: 105
Electricity—consumption: 7.863 billion kWh (2016 est.)
country comparison to the world: 104
Electricity—exports: 39.1 million kWh (2016 est.)
country comparison to the world: 89
Electricity—imports: 184 million kWh (2016 est.)
country comparison to the world: 95
Electricity—installed generating capacity: 2.401 million kW (2016
est.)
country comparison to the world: 109
Electricity—from fossil fuels: 33% of total installed capacity
(2016 est.)
country comparison to the world: 183
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 118
Electricity—from hydroelectric plants: 34% of total installed
capacity (2017 est.)
country comparison to the world: 62
Electricity—from other renewable sources: 33% of total installed
capacity (2017 est.) country comparison to the world: 13
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 154
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 145
Crude oil—imports: 12,550 bbl/day (2015 est.)
country comparison to the world: 71
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 150
Refined petroleum products—production: 13,960 bbl/day (2015
est.)
country comparison to the world: 96
Refined petroleum products—consumption: 109,000 bbl/day (2016
est.)
country comparison to the world: 76
Refined petroleum products—exports: 173 bbl/day (2015 est.)
country comparison to the world: 118
Refined petroleum products—imports: 90,620 bbl/day (2015 est.)
country comparison to the world: 57
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 150
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 161
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 128
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 142
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 151
Carbon dioxide emissions from consumption of energy: 17.98 million
Mt (2017 est.)
country comparison to the world: 88
Electricity access: electrification—total population: 84.9%
(2016) electrification—urban areas: 88.4% (2016)
electrification—rural areas: 82.2% (2016)
Electricity—production: 29 million kWh (2016 est.)
country comparison to the world: 210
Electricity—consumption: 26.97 million kWh (2016 est.)
country comparison to the world: 210
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 153
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 164
Electricity—installed generating capacity: 11,000 kW (2016 est.)
country comparison to the world: 209
Electricity—from fossil fuels: 73% of total installed capacity
(2016 est.)
country comparison to the world: 99
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 119
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.)
country comparison to the world: 181
Electricity—from other renewable sources: 27% of total installed
Capacity (2017 est.) country comparison to the world: 25
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 155
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 146
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 146
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 151
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 160
Refined petroleum products—consumption: 400 bbl/day (2016 est.)
country comparison to the world: 211
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 167
Refined petroleum products—imports: 420 bbl/day (2015 est.)
country comparison to the world: 207
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 151
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 162
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 129
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 143
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 152
Carbon dioxide emissions from consumption of energy: 58,850 Mt
(2017 est.)
country comparison to the world: 209
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 526 billion kWh (2016 est.)
country comparison to the world: 10
Electricity—consumption: 507.6 billion kWh (2016 est.)
country comparison to the world: 9
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 155
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 166
Electricity—installed generating capacity: 111.2 million kW (2016
est.)
country comparison to the world: 11
Electricity—from fossil fuels: 70% of total installed capacity
(2016 est.)
country comparison to the world: 109
Electricity—from nuclear fuels: 21% of total installed capacity
(2017 est.)
country comparison to the world: 7
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.) country comparison to the world: 139
Electricity—from other renewable sources: 8% of total installed
capacity (2017 est.) country comparison to the world: 86
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 157
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 148
Crude oil—imports: 3.057 million bbl/day (2017 est.)
country comparison to the world: 5
Crude oil—proved reserves: NA (1 January 2017 est.)
Refined petroleum products—production: 3.302 million bbl/day
(2017 est.)
country comparison to the world: 6
Refined petroleum products—consumption: 2.584 million bbl/day
(2017 est.)
country comparison to the world: 8
Refined petroleum products—exports: 1.396 million bbl/day (2017
est.)
country comparison to the world: 6
Refined petroleum products—imports: 908,800 bbl/day (2017 est.)
country comparison to the world: 6
Natural gas—production: 339.8 million cu m (2017 est.)
country comparison to the world: 76
Natural gas—consumption: 45.28 billion cu m (2017 est.)
country comparison to the world: 18
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 131
Natural gas—imports: 48.65 billion cu m (2017 est.)
country comparison to the world: 9
Natural gas—proved reserves: 7.079 billion cu m (1 January
2018 est.)
country comparison to the world: 82
Carbon dioxide emissions from consumption of energy: 778.4 million
Mt (2017 est.) country comparison to the world: 7
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 21.18 billion kWh (2016 est.)
country comparison to the world: 74
Electricity—consumption: 15.09 billion kWh (2016 est.)
country comparison to the world: 80
Electricity—exports: 3.201 billion kWh (2015 est.)
country comparison to the world: 41
Electricity—imports: 0 kWh (2016 est.) country comparison to
the world: 212
Electricity—installed generating capacity: 4.001 million kW (2016
est.) country comparison to the world: 88
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.) country comparison to the world: 20
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 200
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.) country comparison to the world: 207
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 210
Crude oil—production: 244,000 bbl/day (2018 est.)
country comparison to the world: 32
Crude oil—exports: 67,790 bbl/day (2015 est.)
country comparison to the world: 38
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 206
Crude oil—proved reserves: 600 million bbl (1 January 2018
est.) country comparison to the world: 43
Refined petroleum products—production: 191,100 bbl/day (2015
est.) country comparison to the world: 52
Refined petroleum products—consumption: 160,000 bbl/day (2016
est.) country comparison to the world: 63
Refined petroleum products—exports: 53,780 bbl/day (2015 est.)
country comparison to the world: 53
Refined petroleum products—imports: 0 bbl/day (2015 est.)
country comparison to the world: 214
Natural gas—production: 77.45 billion cu m (2017 est.)
country comparison to the world: 11
Natural gas—consumption: 39.31 billion cu m (2017 est.)
country comparison to the world: 27
Natural gas—exports: 38.14 billion cum (2017 est.)
country comparison to the world: 10
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 203
Natural gas—proved reserves: 7.504 trillion cu m (1 January
2018 est.) country comparison to the world: 5
Carbon dioxide emissions from consumption of energy: 100.5 million
Mt (2017 est.) country comparison to the world: 44
Electricity access: electrification—total population: 95.7%
(2016) electrification—urban areas: 100% (2016)
electrification—rural areas: 42.7% (2016)
Electricity—production: 235 million kWh (2016 est.)
country comparison to the world: 188
Electricity—consumption: 218.6 million kWh (2016 est.)
country comparison to the world: 191
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 211
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 213
Electricity—installed generating capacity: 82,000 kW (2016 est.)
country comparison to the world: 183
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.) country comparison to the world: 21
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 201
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.) country comparison to the world: 208
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 211
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 209
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 209
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 207
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 207
Refined petroleum products—production: 0 bbli/day (2015 est.)
country comparison to the world: 210
Refined petroleum products—consumption: 1,420 bbl/day (2016
est.) country comparison to the world: 201
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 211
Refined petroleum products—imports: 1,369 bbl/day (2015 est.)
country comparison to the world: 197
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 208
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 208
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 203
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 204
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 202
Carbon dioxide emissions from consumption of energy: 221,800 Mt
(2017 est.) country comparison to the world: 198
Electricity access: electrification—total population: 99.4%
(2016) electrification—urban areas: 100% (2016)
electrification—rural areas: 98.5% (2016)
Electricity—production: 11.8 million kWh (2011 est.)
country comparison to the world: 214
Electricity—exports: 0 kWh (2014 est.)
country comparison to the world: 212
Electricity—imports: 0 kWh (2014 est.)
country comparison to the world: 214
Electricity—installed generating capacity: 5,100 kW (2011 est.)
country comparison to the world: 212
Electricity—from fossil fuels: 96% of total installed capacity
(2015 est.) country comparison to the world: 43
Electricity—from nuclear fuels: 0% of total installed capacity
(2014) country comparison to the world: 202
Electricity—from hydroelectric plants: O% of total installed
capacity (2014) country comparison to the world: 209
Crude oil—production: 0 bbl/day (2014 est.)
country comparison to the world: 210
Crude oil—exports: 0 bbl/day (2014 est.)
country comparison to the world: 210
Crude oil—imports: 0 bbl/day (2014 est.)
country comparison to the world: 208
Crude oil—proved reserves: 0 bbl (2014 est.)
country comparison to the world: 208
Refined petroleum products—production: 0 bbi/day (2014 est.)
country comparison to the world: 211
Refined petroleum products—exports: 0) bbl/day
country comparison to the world: 212
Natural gas—production: 0 cu m (2014 est.)
country comparison to the world: 209
Natural gas—consumption: 0 cu m (2014)
country comparison to the world: 209
Natural gas—exports: 0 cu m (2014 est.)
country comparison to the world: 204
Natural gas—imports: 0 cu m (2014 est.)
country comparison to the world: 205
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 55.55 billion kWh (2016 est.)
country comparison to the world: 52
Electricity—consumption: 49.07 billion kWh (2016 est.)
country comparison to the world: 50
Electricity—exports: 13 billion kWh (2014 est.)
country comparison to the world: 15
Electricity—imports: 10.84 billion kWh (2016 est.)
country comparison to the world: 23
Electricity—installed generating capacity: 12.96 million kW (2016
est.)
country comparison to the world: 54
Electricity—from fossil fuels: 86% of total installed capacity
(2016 est.)
country comparison to the world: 69
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 206
Electricity—from hydroelectric plants: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 109
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 212
Crude oil—production: 41,000 bbl/day (2018 est.)
country comparison to the world: 57
Crude oil—exports: 27,000 bbl/day (2015 est.)
country comparison to the world: 46
Crude oil—imports: 420 bbl/day (2015 est.)
country comparison to the world: 81
Crude oil—proved reserves: 594 million bbl (1 January 2018
est.)
country comparison to the world: 44
Refined petroleum products—production: 61,740 bbl/day (2015
est.)
country comparison to the world: 78
Refined petroleum products—consumption: 60,000 bbl/day (2016
est.)
country comparison to the world: 95
Refined petroleum products—exports: 3,977 bbl/day (2015 est.)
country comparison to the world: 95
Refined petroleum products—imports: 0 bbl/day (2015 est.)
country comparison to the world: 215
Natural gas—production: 52.1 billion cu m (2017 est.)
country comparison to the world: 15
Natural gas—consumption: 43.07 billion cu m (2017 est.)
country comparison to the world: 22
Natural gas—exports: 9.401 billion cu m (2017 est.)
country comparison to the world: 22
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 207
Natural gas—proved reserves: 1.841 trillion cu m (1 January
2018 est.)
country comparison to the world: 18
Carbon dioxide emissions from consumption of energy: 95.58 million
Mt (2017 est.)
country comparison to the world: 46','5292485887df3170166e23c2674f2d52491ee18a306e63943955e97e5367850b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a7d2dbf9603e36362b0305582eb3dac9876e1a8cf9c8aa33fc3d761ffc27185',2021,'RS','Serbia','energy',645,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 5.638 billion kWh (2016 est.)
country comparison to the world: 117
Electricity—consumption: 3.957 billion kWh (2016 est.)
country comparison to the world: 127
Electricity—exports: 885.7 million kWh (2017 est.)
country comparison to the world: 60
Electricity—imports: 557 million kWh (2016 est.)
country comparison to the world: 78
Electricity—installed generating capacity: 1.573 million kW (2016
est.)
country comparison to the world: 121
Electricity—from fossil fuels: 97% of total installed capacity
(2016 est.)
country comparison to the world: 35
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 121
Electricity—from hydroelectric plants: 3% of total installed
Capacity (2017 est.) country comparison to the world: 135
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 156
Crude oil—production: 0 bbl/day (2017 est.)
country comparison to the world: 158
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 149
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 147
Crude oil—proved reserves: 0 bbl NA (2017 est.)
country comparison to the world: 153
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 161
Refined petroleum products—consumption: 14,000 bbl/day (2016
est.)
country comparison to the world: 155
Refined petroleum products—exports: 192 bbl/day (2015 est.)
country comparison to the world: 117
Refined petroleum products—imports: 14,040 bbl/day (2015 est.)
country comparison to the world: 139
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 153
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 164
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 132
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 145
Natural gas—proved reserves: 0 cu m NA (2017 est.)
country comparison to the world: 154
Carbon dioxide emissions from consumption of energy: 10.05 million
Mt (2017 est.) country comparison to the world: 106
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 36.54 billion kWh (2016 est.)
country comparison to the world: 59
Electricity—consumption: 29.81 billion kWh (2016 est.)
country comparison to the world: 62
Electricity—exports: 6.428 billion kWh (2016 est.)
country comparison to the world: 29
Electricity—imports: 5.068 billion kWh (2016 est.)
country comparison to the world: 38
Electricity—installed generating capacity: 7.342 million kW (2016
est.)
country comparison to the world: 73
Electricity—from fossil fuels: 65% of total installed capacity
(2016 est.)
country comparison to the world: 119
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 180
Electricity—from hydroelectric plants: 35% of total installed
Capacity (2017 est.)
country comparison to the world: 61
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 167
Crude oil—production: 17,000 bbl/day (2018 est.)
country comparison to the world: 69
Crude oil—exports: 123 bbl/day (2015 est.)
country comparison to the world: 81
Crude oil—imports: 40,980 bbl/day (2015 est.)
country comparison to the world: 56
Crude oil—proved reserves: 77.5 million bbl (1 January 2018
est.)
country comparison to the world: 73
Refined petroleum products—production: 74,350 bbl/day (2015
est.)
country comparison to the world: 71
Refined petroleum products—consumption: 74,000 bbl/day (2016
est.)
country comparison to the world: 90
Refined petroleum products—exports: 15,750 bbl/day (2015 est.)
country comparison to the world: 73
Refined petroleum products—imports: 18,720 bbl/day (2015 est.)
country comparison to the world: 126
Natural gas—production: 509.7 million cu m (2017 est.)
country comparison to the world: 71
Natural gas—consumption: 2.718 billion cu m (2017 est.)
country comparison to the world: 75
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 181
Natural gas—imports: 2.01 billion cu m (2017 est.)
country comparison to the world: 52
Natural gas—proved reserves: 48.14 billion cu m (1 January
2018 est.)
country comparison to the world: 63
Carbon dioxide emissions from consumption of energy: 50.21 million
Mt (2017 est.)
country comparison to the world: 60','99101a2ba652469e930a47498c3ad2682f17d24736015e3118a85e1c7f01e49b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c10ec9319f8499bab1730436e5a20d00eec3dcaa7b8855e4a04d09760e19d95a',2021,'KW','Kuwait','energy',655,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 65.95 billion kWh (2016 est.)
country comparison to the world: 44
Electricity—consumption: 57.78 billion kWh (2016 est.)
country comparison to the world: 44
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 156
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 167
Electricity—installed generating capacity: 18.89 million kW (2016
est.)
country comparison to the world: 47
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 10
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 122
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 182
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 196
Crude oil—production: 2.807 million bbl/day (2018 est.)
country comparison to the world: 9
Crude oil—exports: 479,700 bbl/day (2015 est.)
country comparison to the world: 21
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 148
Crude oil—proved reserves: 101.5 billion bbl (1 January 2018
est.)
country comparison to the world: 6
Refined petroleum products—production: 915,800 bbl/day (2015
est.)
country comparison to the world: 22
Refined petroleum products—consumption: 446,000 bbl/day (2016
est.)
country comparison to the world: 34
Refined petroleum products—exports: 705,500 bbl/day (2015 est.)
country comparison to the world: 11
Refined petroleum products—imports: 0 bbl/day (2015 est.)
country comparison to the world: 212
Natural gas—production: 17.1 billion cu m (2017 est.)
country comparison to the world: 34
Natural gas—consumption: 21.72 billion cu m (2017 est.)
country comparison to the world: 36
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 133
Natural gas—imports: 5.125 billion cu m (2017 est.)
country comparison to the world: 35
Natural gas—proved reserves: 1.784 trillion cu m (1 January
2018 est.)
country comparison to the world: 19
Carbon dioxide emissions from consumption of energy: 106.5 million
Mt (2017 est.) country comparison to the world: 41
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 13.04 billion kWh (2016 est.)
country comparison to the world: 93
Electricity—consumption: 10.52 billion kWh (2016 est.)
country comparison to the world: 94
Electricity—exports: 184 million kWh (2015 est.)
country comparison to the world: 77
Electricity—imports: 331 million kWh (2016 est.)
country comparison to the world: 87
Electricity—installed generating capacity: 4.046 million kW (2016
est.)
country comparison to the world: 87
Electricity—from fossil fuels: 24% of total installed capacity
(2016 est.)
country comparison to the world: 190
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 123
Electricity—from hydroelectric plants: 76% of total installed
Capacity (2017 est.) country comparison to the world: 13
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 197
Crude oil—production: 1,000 bbl/day (2018 est.)
country comparison to the world: 92
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 150
Crude oil—imports: 4,480 bbl/day (2015 est.)
country comparison to the world: 77
Crude oil—proved reserves: 40 million bbl (1 January 2018 est.)
country comparison to the world: 79
Refined petroleum products—production: 6,996 bbl/day (2015 est.)
country comparison to the world: 102
Refined petroleum products—consumption: 37,000 bbl/day (2016
est.)
country comparison to the world: 114
Refined petroleum products—exports: 2,290 bbl/day (2015 est.)
country comparison to the world: 103
Refined petroleum products—imports: 34,280 bbl/day (2015 est.)
country comparison to the world: 96
Natural gas—production: 28.32 million cu m (2017 est.)
country comparison to the world: 88
Natural gas—consumption: 186.9 million cu m (2017 est.)
country comparison to the world: 106
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 134
Natural gas—imports: 169.9 million cu m (2017 est.)
country comparison to the world: 74
Natural gas—proved reserves: 5.663 billion cu m (1 January
2018 est.)
country comparison to the world: 89
Carbon dioxide emissions from consumption of energy: 10.02 million
Mt (2017 est.) country comparison to the world: 108
Electricity access: electrification—total population: 87.1%
(2016)
electrification—urban areas: 97.4% (2016)
electrification—rural areas: 80.3% (2016)
Electricity—production: 29.74 billion kWh (2016 est.)
country comparison to the world: 66
Electricity—consumption: 5.471 billion kWh (2016 est.)
country comparison to the world: 120
Electricity—exports: 8.469 billion kWh (2015 est.)
country comparison to the world: 24
Electricity—imports: 2.5 billion kWh (2016 est.)
country comparison to the world: 53
Electricity—installed generating capacity: 6.94 million kW (2016
est.)
country comparison to the world: 75
Electricity—from fossil fuels: 28% of total installed capacity
(2016 est.)
country comparison to the world: 186
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 124
Electricity—from hydroelectric plants: 72% of total installed
Capacity (2017 est.)
country comparison to the world: 15
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.)
country comparison to the world: 157
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 159
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 151
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 149
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 154
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 162
Refined petroleum products—consumption: 18,000 bbl/day (2016
est.)
country comparison to the world: 146
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 169
Refined petroleum products—imports: 17,460 bbl/day (2015 est.)
country comparison to the world: 132
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 154
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 165
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 135
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 146
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 155
Carbon dioxide emissions from consumption of energy: 10.42 million
Mt (2017 est.)
country comparison to the world: 105','9df450430b7b7e36a35be2390d98ba9e2e5117a29a127f8d4d8c1f864fec1328','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6bd604cf727100ff4483cb1842517a86e393498e84e79e45ad6128f1fc7a03b',2021,'BY','Belarus','energy',664,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 6.241 billion kWh (2016 est.)
country comparison to the world: 115
Electricity—consumption: 6.798 billion kWh (2016 est.)
country comparison to the world: 109
Electricity—exports: 3.795 billion kWh (2016 est.)
country comparison to the world: 38
Electricity—imports: 4.828 billion kWh (2016 est.)
country comparison to the world: 39
Electricity—installed generating capacity: 2.932 million kW (2016
est.)
country comparison to the world: 98
Electricity—from fossil fuels: 39% of total installed capacity
(2016 est.)
country comparison to the world: 173
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 125
Electricity—from hydroelectric plants: 53% of total installed
Capacity (2017 est.)
country comparison to the world: 33
Electricity—from other renewable sources: 8% of total installed
Capacity (2017 est.)
country comparison to the world: 87
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 160
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 152
Crude oil—imports: 0 bbl/day (2017 est.)
country comparison to the world: 150
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 155
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 163
Refined petroleum products—consumption: 44,600 bbl/day (2017
est.)
country comparison to the world: 111
Refined petroleum products—exports: 16,180 bbl/day (2017 est.)
country comparison to the world: 72
Refined petroleum products—imports: 54,370 bbl/day (2017 est.)
country comparison to the world: 77
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 155
Natural gas—consumption: 1.218 billion cu m (2017 est.)
country comparison to the world: 88
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 136
Natural gas—imports: 1.246 billion cu m (2017 est.)
country comparison to the world: 58
Natural gas—proved reserves: 0 cu m (2014 est.)
country comparison to the world: 156
Carbon dioxide emissions from consumption of energy: 8.632 million
Mt (2017 est.)
country comparison to the world: 114','f5af41cc953f56a8f3ef168845d1580daa458d704309216fbd80c7716c2dcbe8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fb6946ac7ca470b361d5ce0ee8cbf603cf17a7f2fc2e8ee7fcf797918b2a82f',2021,'LB','Lebanon','energy',669,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 17.59 billion kWh (2016 est.)
country comparison to the world: 82
Electricity—consumption: 15.71 billion kWh (2016 est.)
country comparison to the world: 77
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 157
Electricity—imports: 69 million kWh (2016 est.)
country comparison to the world: 104
Electricity—installed generating capacity: 2.346 million kW (2016
est.)
country comparison to the world: 110
Electricity—from fossil fuels: 88% of total installed capacity
(2016 est.)
country comparison to the world: 59
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 126
Electricity—from hydroelectric plants: 11% of total installed
Capacity (2017 est.)
country comparison to the world: 114
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 158
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 161
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 153
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 151
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 156
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 164
Refined petroleum products—consumption: 154,000 bbl/day (2016
est.)
country comparison to the world: 65
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 170
Refined petroleum products—imports: 151,100 bbl/day (2015 est.)
country comparison to the world: 41
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 156
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 166
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 137
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 147
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 157
Carbon dioxide emissions from consumption of energy: 23.36 million
Mt (2017 est.)
country comparison to the world: 83','42b4e9bb116d3286f00e0d6b7aca1e7b243a838bbd8b7fa06aae573173521795','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b996e03b0c66cf75d4a25cee588cc818c2ab67e1616bdc728b2e58bbc6d73c',2021,'LU','Luxembourg','energy',682,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 334.5 million kWh (2016 est.)
country comparison to the world: 178
Electricity—consumption: 6.475 billion kWh (2016 est.)
country comparison to the world: 111
Electricity—exports: 1.42 billion kWh (2016 est.)
country comparison to the world: 51
Electricity—imports: 7.718 billion kWh (2016 est.)
country comparison to the world: 30
Electricity—installed generating capacity: 1.709 million kW (2016
est.)
country comparison to the world: 118
Electricity—from fossil fuels: 25% of total installed capacity
(2016 est.) country comparison to the world: 189
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 131
Electricity—from hydroelectric plants: 8% of total installed
capacity (2017 est.) country comparison to the world: 122
Electricity—from other renewable sources: 67% of total installed
capacity (2017 est.) country comparison to the world: 2
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 164
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 156
Crude oil—imports: 0 bbl/day (2017 est.)
country comparison to the world: 155
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 159
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 167
Refined petroleum products—consumption: 59,850 bbl/day (2017
est.)
country comparison to the world: 96
Refined petroleum products—exports: 0 bbl/day (2017 est.)
country comparison to the world: 173
Refined petroleum products—imports: 59,020 bbl/day (2017 est.)
country comparison to the world: 73
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 160
Natural gas—consumption: 792.8 million cu m (2017 est.)
country comparison to the world: 96
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 141
Natural gas—imports: 792.8 million cu m (2017 est.)
country comparison to the world: 63
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 161
Carbon dioxide emissions from consumption of energy: 10.72 million
Mt (2017 est.) country comparison to the world: 103','b8db556d38087ffe3fc268f841310f75c34a77758fff917288f630e552c1668c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f0b55a6c60bc5c5c225918d75bdf5bb9a88b9d152122ab5e7cc4913466317b4',2021,'MG','Madagascar','energy',690,'Electricity access: DOpUlation without electricity: 20 million
(2017) electrification—total population: 22.9% (2016)
electrification—urban areas: 67.3% (2016)
electrification—rural areas: 17.3% (2016)
Electricity—production: 1.706 billion kWh (2016 est.)
country comparison to the world: 142
Electricity—consumption: 1.587 billion kWh (2016 est.)
country comparison to the world: 147
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 163
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 169
Electricity—installed generating capacity: 675,400 kW (2016 est.)
country comparison to the world: 136
Electricity—from fossil fuels: 74% of total installed capacity
(2016 est.)
country comparison to the world: 97
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 134
Electricity—from hydroelectric plants: 24% of total installed
Capacity (2017 est.)
country comparison to the world: 80
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 141
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 167
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 158
0 bbl/day (2015 est.)
Crude oil—imports: country comparison to the world: 158
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 162
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 170
Refined petroleum products—consumption: 18,000 bbl/day (2016
est.)
country comparison to the world: 147
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 175
Refined petroleum products—imports: 18,880 bbl/day (2015 est.)
country comparison to the world: 125
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 163
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 169
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 144
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 151
Natural gas—proved reserves: 0 Cu m (1 January 2012 est.)
country comparison to the world: 164
Carbon dioxide emissions from consumption of energy: 4.021 million
Mt (2017 est.)
country comparison to the world: 138
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 350 million kWh (2016 est.)
country comparison to the world: 175
Electricity—consumption: 325.5 million kWh (2016 est.)
country comparison to the world: 182
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 196
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 198
Electricity—installed generating capacity: 88,000 kW (2016 est.)
country comparison to the world: 181
Electricity—from fossil fuels: 91% of total installed capacity
(2016 est.)
country comparison to the world: 56
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 181
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 199
Electricity—from other renewable sources: 9% of total installed
Capacity (2017 est.)
country comparison to the world: 83
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 198
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 191
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 193
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 193
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 199
Refined petroleum products—consumption: 7,300 bbl/day (2016
est.)
country comparison to the world: 166
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 200
Refined petroleum products—imports: 7,225 bbl/day (2015 est.)
country comparison to the world: 155
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 194
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 196
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 182
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 187
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 192
Carbon dioxide emissions from consumption of energy: 1.15 million
Mt (2017 est.)
country comparison to the world: 165','c43635e0a67e3b7bb35a414353969c563c317dd43691719ae57f0509c493b0ae','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e29304cbadb9a187cff42d073f93963ba0a63221e74034c09ddc94962671e7c',2021,'MT','Malta','energy',707,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 813 million kWh (2016 est.)
country comparison to the world: 156
Electricity—consumption: 2.122 billion kWh (2016 est.)
country comparison to the world: 142
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 167
Electricity—imports: 1.525 billion kWh (2016 est.)
country comparison to the world: 61
Electricity—installed generating capacity: 575,100 kW (2016 est.)
country comparison to the world: 142
Electricity—from fossil fuels: 81% of total installed capacity
(2016 est.)
country comparison to the world: 80
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 139
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 186
Electricity—from other renewable sources: 19% of total installed
Capacity (2017 est.)
country comparison to the world: 43
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 171
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 162
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 162
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 166
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 174
Refined petroleum products—consumption: 45,000 bbl/day (2016
est.)
country comparison to the world: 110
Refined petroleum products—exports: 10,400 bbl/day (2015 est.)
country comparison to the world: 81
Refined petroleum products—imports: 52,290 bbl/day (2015 est.)
country comparison to the world: 79
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 167
Natural gas—consumption: 283.2 million cu m (2017 est.)
country comparison to the world: 102
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 148
Natural gas—imports: 311.5 million cu m (2017 est.)
country comparison to the world: 69
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 168
Carbon dioxide emissions from consumption of energy: 8.141 million
Mt (2017 est.)
country comparison to the world: 116','8bcbe2b8f658b5de6dd355ab8cd793089290bdbc36052dff7427537a896a2c06','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34bd294d7c9486dd6987175fe3d6c9b6da25dd4db0c2372e0c265d22554a1b09',2021,'MH','Marshall Islands','energy',713,'Electricity access: electrification—total population: 93.1%
(2016)
electrification—urban areas: 94.6% (2016)
electrification—rural areas: 89.1% (2016)
Electricity—production: 650 million kWh (2016 est.)
country comparison to the world: 161
Electricity—consumption: 604.5 million kWh (2016 est.)
country comparison to the world: 167
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 168
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 172
Electricity—installed generating capacity: 52,000 kW (2016 est.)
country comparison to the world: 190
Electricity—from fossil fuels: 81% of total installed capacity
(2016 est.)
country comparison to the world: 81
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 140
Electricity—from hydroelectric plants: 19% of total installed
Capacity (2017 est.)
country comparison to the world: 90
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 201
Crude oil—production: 0 bbl/day (2017 est.)
country comparison to the world: 172
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 163
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 163
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 167
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 175
Refined petroleum products—consumption: 2,000 bbl/day (2016
est.)
country comparison to the world: 195
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 179
Refined petroleum products—imports: 2,060 bbl/day (2015 est.)
country comparison to the world: 190
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 168
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 173
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 149
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 155
Carbon dioxide emissions from consumption of energy: 293,700 Mt
(2017 est.)
country comparison to the world: 192','b0266975222c313fa2f99be107af295b45edb6de2ae6be5677eb3062a342ddcd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7b447bcfcf48841f7335c58a1c5e614b551665799167c0c0e1a3f0708cf9e6d',2021,'SN','Senegal','energy',720,'Electricity access: DOpulation without electricity: 3 million
(2017) electrification—total population: 41.7% (2016)
electrification—urban areas: 81% (2016)
electrification—rural areas: 2.3% (2016)
Electricity—production: 1.139 billion kWh (2016 est.)
country comparison to the world: 147
Electricity—consumption: 1.059 billion kWh (2016 est.)
country comparison to the world: 154
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 169
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 173
Electricity—installed generating capacity: 558,000 kW (2016 est.)
country comparison to the world: 144
Electricity—from fossil fuels: 65% of total installed capacity
(2016 est.)
country comparison to the world: 118
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 141
Electricity—from hydroelectric plants: 16% of total installed
Capacity (2017 est.)
country comparison to the world: 100
Electricity—from other renewable sources: 20% of total installed
Capacity (2017 est.)
country comparison to the world: 39
Crude oil—production: 4,000 bbl/day (2018 est.)
country comparison to the world: 81
Crude oil—exports: 5,333 bbl/day (2015 est.)
country comparison to the world: 65
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 164
Crude oil—proved reserves: 20 million bbl (1 January 2018 est.)
country comparison to the world: 83
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 176
Refined petroleum products—consumption: 17,000 bbl/day (2016
est.)
country comparison to the world: 150
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 180
Refined petroleum products—imports: 17,290 bbl/day (2015 est.)
country comparison to the world: 133
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 169
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 174
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 150
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 156
Natural gas—proved reserves: 28.32 billion cu m (1 January
2018 est.)
country comparison to the world: 70
Carbon dioxide emissions from consumption of energy: 2.615 million
Mt (2017 est.)
country comparison to the world: 152','223c02c856efbc8235a963bb938f19a61a02aab5820e481266182abf37dd37af','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ec4c5a4123402c10c7d5960367765a9fbf8854cd6e6c59163b68ac0a05c7c81',2021,'MU','Mauritius','energy',727,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 2.898 billion kWh (2016 est.)
country comparison to the world: 134
Electricity—consumption: 2.726 billion kWh (2016 est.)
country comparison to the world: 140
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 170
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 174
Electricity—installed generating capacity: 894,000 kW (2016 est.)
country comparison to the world: 132
Electricity—from fossil fuels: 79% of total installed capacity
(2016 est.)
country comparison to the world: 86
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 142
Electricity—from hydroelectric plants: 7% of total installed
Capacity (2017 est.)
country comparison to the world: 126
Electricity—from other renewable sources: 14% of total installed
capacity (2017 est.)
country comparison to the world: 62
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 173
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 164
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 165
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 168
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 177
Refined petroleum products—consumption: 27,000 bbl/day (2016
est.)
country comparison to the world: 123
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 181
Refined petroleum products—imports: 26,960 bbl/day (2015 est.)
country comparison to the world: 102
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 170
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 175
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 151
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 157
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 169
Carbon dioxide emissions from consumption of energy: 6.429 million
Mt (2017 est.)
country comparison to the world: 125','c3e70f6c1c049d69b6fd22fa5bef4bf47657ea611a533e694c47e5f31ff84abe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b5a46ad5316c32a38c83fa871097f0021e6c9b40930aa2b66a911494503c1ff',2021,'MX','Mexico','energy',733,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 302.7 billion kWh (2016 est.)
country comparison to the world: 13
Electricity—consumption: 258.7 billion kWh (2016 est.)
country comparison to the world: 14
Electricity—exports: 7.308 billion kWh (2016 est.)
country comparison to the world: 27
Electricity—imports: 3.532 billion kWh (2016 est.)
country comparison to the world: 47
Electricity—installed generating capacity: 72.56 million kW (2016
est.)
country comparison to the world: 17
Electricity—from fossil fuels: 71% of total installed capacity
(2016 est.)
country comparison to the world: 106
Electricity—from nuclear fuels: 2% of total installed capacity
(2017 est.)
country comparison to the world: 27
Electricity—from hydroelectric plants: 17% of total installed
capacity (2017 est.) country comparison to the world: 96
Electricity—from other renewable sources: 9% of total installed
capacity (2017 est.) country comparison to the world: 82
Crude oil—production: 1.852 million bbl/day (2018 est.)
country comparison to the world: 13
Crude oil—exports: 1.214 million bbl/day (2017 est.)
country comparison to the world: 11
Crude oil—imports: 0 bbl/day (2017 est.)
country comparison to the world: 166
Crude oil—proved reserves: 6.63 billion bbl (1 January 2018
est.)
country comparison to the world: 19
Refined petroleum products—production: 844,600 bbl/day (2017
est.)
country comparison to the world: 23
Refined petroleum products—consumption: 1.984 million bbl/day
(2017 est.)
country comparison to the world: 11
Refined petroleum products—exports: 155,800 bbl/day (2017 est.)
country comparison to the world: 35
Refined petroleum products—imports: 867,500 bbl/day (2017 est.)
country comparison to the world: 10
Natural gas—production: 31.57 billion cu m (2017 est.)
country comparison to the world: 24
Natural gas—consumption: 81.61 billion cu m (2017 est.)
country comparison to the world: 9
Natural gas—exports: 36.81 million cu m (2017 est.)
country comparison to the world: 51
Natural gas—imports: 50.12 billion cu m (2017 est.)
country comparison to the world: 8
Natural gas—proved reserves: 279.8 billion cu m (1 January
2018 est.)
country comparison to the world: 38
Carbon dioxide emissions from consumption of energy: 454.1 million
Mt (2017 est.) country comparison to the world: 14','f91eac2f5373989f8f06c21b5d3808e4fac7259c8a2e97f67d4af3b3ff40ccd1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd5ca0ea3562a3b32c30dfafdc6ec199d946ab3f157ab4e37550b2570e4f64bd',2021,'FM','Micronesia, Federated States of','energy',741,'Electricity access: electrification—total population: 75.4%
(2016) electrification—urban areas: 91.9% (2016)
electrification—rural areas: 70.7% (2016)
Electricity—production: 192 million kWh (2002)
country comparison to the world: 193
Electricity—consumption: 178.6 million kWh (2002)
country comparison to the world: 195
Electricity—exports: 0 kWh (2013 est.)
country comparison to the world: 171
Electricity—imports: 0 KWh (2013 est.)
country comparison to the world: 175
Electricity—installed generating capacity: 18,000 kW (2015 est.)
country comparison to the world: 206
Electricity—from fossil fuels: 96% of total installed capacity
(2015 est.)
country comparison to the world: 41
Electricity—from nuclear fuels: 0% of total installed capacity
(2015 est.)
country comparison to the world: 143
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2013 est.) country comparison to the world: 149
Electricity—from other renewable sources: 3% of total installed
capacity (2013 est.) country comparison to the world: 127
Crude oil—production: 0 bbl/day (2014)
country comparison to the world: 174
Crude oil—exports: 0 bbl/day (2014)
country comparison to the world: 165
Crude oil—imports: 0 bbl/day (2014)
country comparison to the world: 167
Crude oil—proved reserves: 0 bbl (1 January 2014)
country comparison to the world: 169
Refined petroleum products—production: 0 bbl/day (2014)
country comparison to the world: 178
Refined petroleum products—exports: 0) bbl/day
country comparison to the world: 182
Natural gas—production: 0 cu m (2014)
country comparison to the world: 171
Natural gas—proved reserves: 0 cu m
country comparison to the world: 170
Carbon dioxide emissions from consumption of energy: 105 Mt
(2010 est.)
country comparison to the world: 214','82abbf4bfdc9fd6d2e9b460b2f6cf38f64d815a5b6e71bccc921b7ab5e574e0d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dce0986ff93464a42cae8d223a284804614b8c9a3285abddb564fb3d4fde95d',2021,'UA','Ukraine','energy',748,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 5.49 billion kWh (2016 est.)
country comparison to the world: 118
Electricity—consumption: 4.4 billion kWh (2016 est.)
country comparison to the world: 125
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 172
Electricity—imports: 4 million kWh (2016 est.)
country comparison to the world: 116
Electricity—installed generating capacity: 515,000 kW (2016 est.)
note: excludes Transnistria
country comparison to the world: 148
Electricity—from fossil fuels: 86% of total installed capacity
(2016 est.)
country comparison to the world: 67
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 144
Electricity—from hydroelectric plants: 12% of total installed
capacity (2017 est.) country comparison to the world: 112
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.) country comparison to the world: 142
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 175
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 166
Crude oil—imports: 20 bbl/day (2015 est.)
country comparison to the world: 83
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 170
Refined petroleum products—production: 232 bbl/day (2015 est.)
country comparison to the world: 107
Refined petroleum products—consumption: 18,000 bbl/day (2016
est.)
country comparison to the world: 148
Refined petroleum products—exports: 275 bbl/day (2015 est.)
country comparison to the world: 116
Refined petroleum products—imports: 18,160 bbl/day (2015 est.)
country comparison to the world: 130
Natural gas—production: 11.33 million cu m (2017 est.)
country comparison to the world: 92
Natural gas—consumption: 2.52 billion cu m (2017 est.)
note: excludes breakaway Transnistria
country comparison to the world: 78
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 152
Natural gas—imports: 2.52 billion cu m (2017 est.)
note: excludes breakaway Transnistria
country comparison to the world: 46
Natural gas—proved reserves: NA cu m (1 January 2017 est.)
Carbon dioxide emissions from consumption of energy: 7.653 million
Mt (2017 est.) country comparison to the world: 121','5655296aaad263beed4a032e3518aef6a21b1da97cea59c1f3c2085b8050249f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9585123214d35587c08957da6df22ca92ae6afb4d216883b150c894fe3854f41',2021,'MC','Monaco','energy',755,'Electricity access: electrification—total population: 100%
(2016) COMMUNICATIONS
Telephones—fixed lines: total subscriptions: 43,374
subscriptions per 100 inhabitants: 141 (2018 est.)
country comparison to the world: 161
Telephones—mobile cellular: total subscriptions: 32,689
subscriptions per 100 inhabitants: 106 (2018 est.)
country comparison to the world: 208
Telephone system: general assessment: modern automatic
telephone system; the country’s sole fixed-line operator
offers a full range of services to residential and business
customers; competitive mobile telephony market (2018)
domestic: fixed-line 153 per 100 and wmobile-cellular
teledensity exceeds 108 per 100 persons (2018)
international: country code—377; landing points for the
FIG and Italy-Monaco submarine cables connecting
Monaco to Europe, Africa, the Middle East and Asia; no
satellite earth stations; connected by cable into the French
communications system (2019) Broadcast media: TV Monte-
Carlo operates a TV network; cable TV available; Radio
Monte-Carlo has extensive radio networks in France and
Italy with French-language broadcasts to France beginning
in the 1960s and Italian-language broadcasts to Italy
beginning in the 1970s; other radio stations include Riviera
Radio and Radio Monaco Internet country code: .™MC
Internet users: total: 29,116
percent of population: 95.2% (July 2016 est.)
country comparison to the world: 202
Broadband—fixed subscriptions:
total: 19,822
subscriptions per 100 inhabitants: 65 (2018 est.)
country comparison to the world: 152','08f0686bac49007941bb37f0798ae08b10d81e8d26c9113ca94e698af52546bb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d8d3a53389b1b3ea580bae7d1914192558ed82fe7eac7b50de3dd719b47daa7',2021,'MN','Mongolia','energy',761,'Electricity access: electrification—total population: 81.8%
(2016) electrification—urban areas: 95.8% (2016)
electrification—rural areas: 44.2% (2016)
Electricity—production: 5.339 billion kWh (2016 est.)
country comparison to the world: 120
Electricity—consumption: 5.932 billion kWh (2016 est.)
country comparison to the world: 115
Electricity—exports: 51 million kWh (2015 est.)
country comparison to the world: 87
Electricity—imports: 1.446 billion kWh (2016 est.)
country comparison to the world: 62
Electricity—installed generating capacity: 1.134 million kW (2016
est.)
country comparison to the world: 125
Electricity—from fossil fuels: 87% of total installed capacity
(2016 est.)
country comparison to the world: 63
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 145
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.) country comparison to the world: 140
Electricity—from other renewable sources: 11% of total installed
capacity (2017 est.) country comparison to the world: 79
Crude oil—production: 20,000 bbl/day (2018 est.)
country comparison to the world: 66
Crude oil—exports: 14,360 bbl/day (2015 est.)
country comparison to the world: 56
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 168
Crude oil—proved reserves: NA bbl (1 January 2017)
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 179
Refined petroleum products—consumption: 27,000 bbl/day (2016
est.)
country comparison to the world: 124
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 183
Refined petroleum products—imports: 24,190 bbl/day (2015 est.)
country comparison to the world: 109
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 172
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 176
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 153
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 158
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 171
Carbon dioxide emissions from consumption of energy: 19.86 million
Mt (2017 est.) country comparison to the world: 86','e2d343190c168ca1c093596110b667b7e4310c9e35baea137d72c133d0957a86','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e2c4c579b5070ce034251f9a897be9b529bdd7c2331d969fd2492f8afe9076',2021,'AL','Albania','energy',769,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 3.045 billion kWh (2016 est.)
country comparison to the world: 132
Electricity—consumption: 2.808 billion kWh (2016 est.)
country comparison to the world: 138
Electricity—exports: 914 million kWh (2016 est.)
country comparison to the world: 59
Electricity—imports: 1.21 billion kWh (2016 est.)
country comparison to the world: 65
Electricity—installed generating capacity: 890,000 kW (2016 est.)
country comparison to the world: 133
Electricity—from fossil fuels: 23% of total installed capacity
(2016 est.) country comparison to the world: 192
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 146
Electricity—from hydroelectric plants: 69% of total installed
capacity (2017 est.) country comparison to the world: 18
Electricity—from other renewable sources: 8% of total installed
capacity (2017 est.) country comparison to the world: 88
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 176
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 167
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 169
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 171
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 180
Refined petroleum products—consumption: 6,000 bbl/day (2016
est.)
country comparison to the world: 172
Refined petroleum products—exports: 357 bbl/day (2015 est.)
country comparison to the world: 114
Refined petroleum products—imports: 6,448 bbl/day (2015 est.)
country comparison to the world: 163
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 173
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 177
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 154
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 159
Natural gas—proved reserves: 0 cu m (2016 est.)
country comparison to the world: 172
Carbon dioxide emissions from consumption of energy: 2.287 million
Mt (2017 est.) country comparison to the world: 156
Electricity—production: 24 million kWh (2016 est.)
country comparison to the world: 211
Electricity—consumption: 22.32 million kWh (2016 est.)
country comparison to the world: 211
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 173
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 176
Electricity—installed generating capacity: 5,000 kW (2016 est.)
country comparison to the world: 213
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.) country comparison to the world: 13
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 147
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.) country comparison to the world: 187
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 202
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 177
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 168
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 170
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 172
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 181
Refined petroleum products—consumption: 400 bbl/day (2016 est.)
country comparison to the world: 212
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 184
Refined petroleum products—imports: 406 bbl/day (2015 est.)
country comparison to the world: 208
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 174
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 178
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 155
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 160
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 173
Carbon dioxide emissions from consumption of energy: 57,180 Mt
(2017 est.) country comparison to the world: 210','3a5387e3a1fb841811b0f7e9621ff24e83e47d07f0c5a561537595c7c4a6d9b9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('261cd9a7d900c595ded35e9a26cb5fab428014459cb59477f172ce17983598b6',2021,'EH','Western Sahara','energy',777,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 28.75 billion kWh (2016 est.)
country comparison to the world: 68
Electricity—consumption: 28.25 billion kWh (2016 est.)
country comparison to the world: 64
Electricity—exports: 165 million kWh (2015 est.)
country comparison to the world: 79
Electricity—imports: 5.289 billion kWh (2016 est.)
country comparison to the world: 37
Electricity—installed generating capacity: 8.303 million kW (2016
est.)
country comparison to the world: 68
Electricity—from fossil fuels: 68% of total installed capacity
(2016 est.) country comparison to the world: 114
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 148
Electricity—from hydroelectric plants: 16% of total installed
capacity (2017 est.) country comparison to the world: 101
Electricity—from other renewable sources: 15% of total installed
capacity (2017 est.) country comparison to the world: 60
Crude oil—production: 160 bbl/day (2018 est.)
country comparison to the world: 98
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 169
Crude oil—imports: 61,160 bbl/day (2015 est.)
country comparison to the world: 53
Crude oil—proved reserves: 684,000 bbl (1 January 2018 est.)
country comparison to the world: 97
Refined petroleum products—production: 66,230 bbl/day (2017
est.)
country comparison to the world: 74
Refined petroleum products—consumption: 278,000 bbl/day (2016
est.)
country comparison to the world: 44
Refined petroleum products—exports: 9,504 bbl/day (2015 est.)
country comparison to the world: 83
Refined petroleum products—imports: 229,300 bbl/day (2015 est.)
country comparison to the world: 30
Natural gas—production: 87.78 million cu m (2017 est.)
country comparison to the world: 82
Natural gas—consumption: 1.218 billion cu m (2017 est.)
country comparison to the world: 89
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 156
Natural gas—imports: 1.133 billion cu m (2017 est.)
country comparison to the world: 61
Natural gas—proved reserves: 1.444 billion cu m (1 January
2018 est.)
country comparison to the world: 97
Carbon dioxide emissions from consumption of energy: 55.4 million
Mt (2017 est.) country comparison to the world: 56','65b2fcbb5580f129fc88d02f071f10cff73ee82cb01cf2affda2a6919a75120d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('933fc015e35468f07ff61b228ff181080c2782661b30ef13ddd9469c7fda3c1c',2021,'NR','Nauru','energy',787,'Electricity—production: 24 million kWh (2016 est.)
country comparison to the world: 212
Electricity—consumption: 22.32 million kWh (2016 est.)
country comparison to the world: 212
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 174
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 177
Electricity—installed generating capacity: 7,000 kW (2016 est.)
country comparison to the world: 211
Electricity—from fossil fuels: 86% of total installed capacity
(2016 est.)
country comparison to the world: 68
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 151
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 188
Electricity—from other renewable sources: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 63
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 180
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 172
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 173
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 175
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 184
Refined petroleum products—consumption: 470 bbl/day (2016 est.)
country comparison to the world: 210
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 186
Refined petroleum products—imports: 449 bbl/day (2015 est.)
country comparison to the world: 206
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 176
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 180
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 158
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 163
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 174
Carbon dioxide emissions from consumption of energy: 76,040 Mt
(2017 est.)
country comparison to the world: 208','214aa10d6f1335a89133277189b9d1212cdb0b6e77fbe199940f310f45f5648b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6d40ef15f9dc22285ee8b2fd3ffff1c1f0c881c5df6a23622978bc30f3d1e85',2021,'NP','Nepal','energy',793,'Electricity access: DOpulation without electricity: 3 million
(2017)
electrification—total population: 90.7% (2016)
electrification—urban areas: 94.5% (2016)
electrification—rural areas: 85.2% (2016)
Electricity—production: 4.244 billion kWh (2016 est.)
country comparison to the world: 125
Electricity—consumption: 4.983 billion kWh (2016 est.)
country comparison to the world: 124
Electricity—exports: 2.69 million kWh (FY 2017 est.)
country comparison to the world: 94
Electricity—imports: 2.175 billion kWh (2016 est.)
country comparison to the world: 57
Electricity—installed generating capacity: 943,100 kW (2016 est.)
country comparison to the world: 130
Electricity—from fossil fuels: 5% of total installed capacity (2016
est.)
country comparison to the world: 203
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 152
Electricity—from hydroelectric plants: 92% of total installed
Capacity (2017 est.)
country comparison to the world: 10
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 128
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 181
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 173
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 174
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 176
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 185
Refined petroleum products—consumption: 27,000 bbl/day (2016
est.)
country comparison to the world: 126
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 187
Refined petroleum products—imports: 26,120 bbl/day (2015 est.)
country comparison to the world: 106
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 177
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 181
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 159
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 164
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 175
Carbon dioxide emissions from consumption of energy: 8.396 million
Mt (2017 est.)
country comparison to the world: 115','bbca3cb0638b7b717469cbec85c33cbcd63a331464ec466aa046122966fcd836','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7211da1c2431fc57dce6da83791b6c7ff41954556f63761e9381ced588bd45ff',2021,'NL','Netherlands','energy',802,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 109.3 billion kWh (2016 est.)
country comparison to the world: 33
Electricity—consumption: 108.8 billion kWh (2016 est.)
country comparison to the world: 32
Electricity—exports: 19.34 billion kWh (2016 est.)
country comparison to the world: 8
Electricity—imports: 24.26 billion kWh (2016 est.)
country comparison to the world: 7
Electricity—installed generating capacity: 34.17 million kW (2016
est.)
country comparison to the world: 29
Electricity—from fossil fuels: 75% of total installed capacity
(2016 est.)
country comparison to the world: 95
Electricity—from nuclear fuels: 1% of total installed capacity
(2017 est.)
country comparison to the world: 31
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 189
Electricity—from other renewable sources: 23% of total installed
Capacity (2017 est.)
country comparison to the world: 32
Crude oil—production: 18,000 bbl/day (2018 est.)
country comparison to the world: 67
Crude oil—exports: 7,984 bbl/day (2017 est.)
country comparison to the world: 62
Crude oil—imports: 1.094 million bbl/day (2017 est.)
country comparison to the world: 10
Crude oil—proved reserves: 81.13 million bbl (1 January 2018
est.)
country comparison to the world: 72
Refined petroleum products—production: 1.282 million bbl/day
(2017 est.)
country comparison to the world: 17
Refined petroleum products—consumption: 954,500 bbl/day (2017
est.)
country comparison to the world: 23
Refined petroleum products—exports: 2.406 million bbl/day (2017
est.)
country comparison to the world: 3
Refined petroleum products—imports: 2.148 million bbl/day (2017
est.)
country comparison to the world: 3
Natural gas—production: 45.33 billion cu m (2017 est.)
note: the Netherlands has curbed gas production due to
seismic activity in the province of Groningen, largest
source of gas reserves country comparison to the world: 17
Natural gas—consumption: 43.38 billion cu m (2017 est.)
country comparison to the world: 21
Natural gas—exports: 51.25 billion cum (2017 est.)
country comparison to the world: 8
Natural gas—imports: 51 billion cu m (2017 est.)
country comparison to the world: 7
Natural gas—proved reserves: 801.4 billion cu m (1 January
2018 est.)
country comparison to the world: 26
Carbon dioxide emissions from consumption of energy: 250.2 million
Mt (2017 est.)
country comparison to the world: 26','755be75a9c96db81442f095c40e693fd1752ddfd7321ed16bf974a0c316fd537','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4786be87f1531e9f831d54dbfe4cf0035928ba1663ec058e991d91a9cf43ca4b',2021,'AU','Australia','energy',808,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 2.945 billion kWh (2016 est.)
country comparison to the world: 133
Electricity—consumption: 2.739 billion kWh (2016 est.)
country comparison to the world: 139
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 175
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 178
Electricity—installed generating capacity: 996,200 kW (2016 est.)
country comparison to the world: 128
Electricity—from fossil fuels: 87% of total installed capacity
(2016 est.)
country comparison to the world: 64
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 153
Electricity—from hydroelectric plants: 8% of total installed
Capacity (2017 est.)
country comparison to the world: 123
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 101
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 182
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 174
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 175
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 177
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 186
Refined petroleum products—consumption: 20,000 bbl/day (2016
est.)
country comparison to the world: 142
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 188
Refined petroleum products—imports: 19,100 bbl/day (2015 est.)
country comparison to the world: 124
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 178
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 182
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 160
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 165
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 176
Carbon dioxide emissions from consumption of energy: 6.165 million
Mt (2017 est.)
country comparison to the world: 128
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 42.53 billion kWh (2016 est.)
country comparison to the world: 56
Electricity—consumption: 39.5 billion kWh (2016 est.)
country comparison to the world: 55
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 176
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 179
Electricity—installed generating capacity: 9.301 million kW (2016
est.)
country comparison to the world: 63
Electricity—from fossil fuels: 23% of total installed capacity
(2016 est.)
country comparison to the world: 193
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 154
Electricity—from hydroelectric plants: 58% of total installed
Capacity (2017 est.)
country comparison to the world: 29
Electricity—from other renewable sources: 20% of total installed
capacity (2017 est.)
country comparison to the world: 40
Crude oil—production: 24,000 bbl/day (2018 est.)
country comparison to the world: 64
Crude oil—exports: 26,440 bbl/day (2017 est.)
country comparison to the world: 48
Crude oil—imports: 108,900 bbl/day (2017 est.)
country comparison to the world: 43
Crude oil—proved reserves: 51.8 million bbl (1 January 2018
est.)
country comparison to the world: 76
Refined petroleum products—production: 115,100 bbl/day (2017
est.)
country comparison to the world: 65
Refined petroleum products—consumption: 169,100 bbl/day (2017
est.)
country comparison to the world: 61
Refined petroleum products—exports: 1,782 bbl/day (2017 est.)
country comparison to the world: 106
Refined petroleum products—imports: 56,000 bbl/day (2017 est.)
country comparison to the world: 76
Natural gas—production: 5.097 billion cu m (2017 est.)
country comparison to the world: 51
Natural gas—consumption: 5.182 billion cu m (2017 est.)
country comparison to the world: 57
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 161
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 166
Natural gas—proved reserves: 33.7 billion cu m (1 January 2018
est.)
country comparison to the world: 67
Carbon dioxide emissions from consumption of energy: 37.75 million
Mt (2017 est.)
country comparison to the world: 68','6a0cd95d286b3b56d5216ff0b363fea3ffb8d15946ae2e4faf05a518bbf1c586','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f56bf183b561fccc335385f115d5289dccfdac9f381883a7d5963b826ebb947',2021,'CR','Costa Rica','energy',811,'Electricity access: electrification—total population: 81.8%
(2016) electrification—urban areas: 99.2% (2016)
electrification—rural areas: 56.6% (2016)
Electricity—production: 4.454 billion kWh (2016 est.)
country comparison to the world: 124
Electricity—consumption: 3.59 billion kWh (2016 est.)
country comparison to the world: 132
Electricity—exports: 17.87 million kWh (2016 est.)
country comparison to the world: 91
Electricity—imports: 205 million kWh (2016 est.)
country comparison to the world: 93
Electricity—installed generating capacity: 1.551 million kW (2016
est.)
country comparison to the world: 123
Electricity—from fossil fuels: 56% of total installed capacity
(2016 est.)
country comparison to the world: 139
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 155
Electricity—from hydroelectric plants: 9% of total installed
Capacity (2017 est.)
country comparison to the world: 120
Electricity—from other renewable sources: 35% of total installed
Capacity (2017 est.)
country comparison to the world: 9
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 183
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 175
Crude oil—imports: 16,180 bbl/day (2015 est.)
country comparison to the world: 69
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 178
Refined petroleum products—production: 14,720 bbl/day (2015
est.)
country comparison to the world: 95
Refined petroleum products—consumption: 37,000 bbl/day (2016
est.)
country comparison to the world: 115
Refined petroleum products—exports: 460 bbl/day (2015 est.)
country comparison to the world: 111
Refined petroleum products—imports: 20,120 bbl/day (2015 est.)
country comparison to the world: 121
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 179
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 183
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 162
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 167
Natural gas—proved reserves: 0 cu m (1 January 2015 est.)
country comparison to the world: 177
Carbon dioxide emissions from consumption of energy: 5.405 million
Mt (2017 est.)
country comparison to the world: 132','aae7d752a333997dafe58e92f573a727181e7584dfa2c7392a06a25f56e871f2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa213d8b8aa418d988ecb82544923af739ba0e0184d959a9afc4988375e4edc7',2021,'NG','Nigeria','energy',816,'Electricity access: DOpulation without electricity: 19 million
(2017) electrification—total population: 16.2% (2016)
electrification—urban areas: 65.4% (2016)
electrification—rural areas: 4.7% (2016)
Electricity—production: 494.7 million kWh (2016 est.)
country comparison to the world: 167
Electricity—consumption: 1.065 billion kWh (2016 est.)
country comparison to the world: 153
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 177
Electricity—imports: 779 million kWh (2016 est.)
country comparison to the world: 74
Electricity—installed generating capacity: 184,000 kW (2016 est.)
country comparison to the world: 168
Electricity—from fossil fuels: 95% of total installed capacity
(2016 est.)
country comparison to the world: 45
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 156
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 190
Electricity—from other renewable sources: 5% of total installed
capacity (2017 est.) country comparison to the world: 108
Crude oil—production: 9,000 bbl/day (2018 est.)
country comparison to the world: 79
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 176
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 176
Crude oil—proved reserves: 150 million bbl (1 January 2018
est.)
country comparison to the world: 61
Refined petroleum products—production: 15,280 bbl/day (2015
est.)
country comparison to the world: 94
Refined petroleum products—consumption: 14,000 bbl/day (2016
est.)
country comparison to the world: 156
Refined petroleum products—exports: 5,422 bbl/day (2015 est.)
country comparison to the world: 90
Refined petroleum products—imports: 3,799 bbl/day (2015 est.)
country comparison to the world: 180
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 180
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 184
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 163
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 168
Natural gas—proved reserves: 0 cu m (1 January 2016 est.)
country comparison to the world: 178
Carbon dioxide emissions from consumption of energy: 2.534 million
Mt (2017 est.)
country comparison to the world: 154
Electricity access: DOpulation without electricity: 77 million
(2017) electrification—total population: 59.3% (2016)
electrification—urban areas: 86% (2016)
electrification—rural areas: 41.1% (2016)
Electricity—production: 29.35 billion kWh (2016 est.)
country comparison to the world: 67
Electricity—consumption: 24.72 billion kWh (2016 est.)
country comparison to the world: 69
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 178
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 180
Electricity—installed generating capacity: 10.52 million kW (2016
est.) country comparison to the world: 58
Electricity—from fossil fuels: 80% of total installed capacity
(2016 est.)
country comparison to the world: 83
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 157
Electricity—from hydroelectric plants: 19% of total installed
capacity (2017 est.)
country comparison to the world: 91
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.)
country comparison to the world: 203
Crude oil—production: 1.989 million bbl/day (2018 est.)
country comparison to the world: 11
Crude oil—exports: 2.096 million bbl/day (2015 est.)
country comparison to the world: 6
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 177
Crude oil—proved reserves: 37.45 billion bbl (1 January 2018
est.)
country comparison to the world: 10
Refined petroleum products—production: 35,010 bbl/day (2017
est.)
country comparison to the world: 83
Refined petroleum products—consumption: 325,000 bbl/day (2016
est.)
country comparison to the world: 41
Refined petroleum products—exports: 2,332 bbl/day (2015 est.)
country comparison to the world: 102
Refined petroleum products—imports: 223,400 bbl/day (2015 est.)
country comparison to the world: 31
Natural gas—production: 44.48 billion cu m (2017 est.)
country comparison to the world: 18
Natural gas—consumption: 17.24 billion cu m (2017 est.)
country comparison to the world: 41
Natural gas—exports: 27.21 billion cu m (2017 est.)
country comparison to the world: 13
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 169
Natural gas—proved reserves: 5.475 trillion cu m (1 January
2018 est.)
country comparison to the world: 8
Carbon dioxide emissions from consumption of energy: 104 million
Mt (2017 est.)
country comparison to the world: 42','d88b8d06d3e4ea649706e489cbc5ca8d192b8b06608dee90fde4604fa581393b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('104e73a259eb8cd440c2b20773adc47b43f67846fddcac17ecbfeef8fbce3966',2021,'TO','Tonga','energy',823,'Electricity—production: 3 million kWh (2016 est.)
country comparison to the world: 216
Electricity—consumption: 2.79 million kWh (2016 est.)
country comparison to the world: 215
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 179
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 181
Electricity—installed generating capacity: 2,300 kW (2016 est.)
country comparison to the world: 214
Electricity—from fossil fuels: 87% of total installed capacity
(2016 est.)
country comparison to the world: 65
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 158
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 191
Electricity—from other renewable sources: 13% of total installed
Capacity (2017 est.)
country comparison to the world: 68
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 184
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 177
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 178
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 179
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 187
Refined petroleum products—consumption: 50 bbl/day (2016 est.)
country comparison to the world: 215
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 189
Refined petroleum products—imports: 54 bbl/day (2015 est.)
country comparison to the world: 211
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 181
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 185
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 164
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 170
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 179
Carbon dioxide emissions from consumption of energy: 7,252 Mt
(2017 est.)
country comparison to the world: 213','0571ccb31b9d199caa42ab971a213047d084c48f42577247c8a3a40c1769ef54','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a6f3f93234238bae7b60d9286a4efa05b54b9dce854ae9da15c0b732d5b0590',2021,'MP','Northern Mariana Islands','energy',831,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 60,600 kWh (2009)
country comparison to the world: 217
Electricity—consumption: 48,300 kWh (2009)
country comparison to the world: 217
Electricity—exports: 0 kWh (2009 est.)
country comparison to the world: 180
Electricity—imports: 0 kWh (January 2009 est.)
country comparison to the world: 182','7e86ffcd310195f4d1e616751c1e2b649a862c8afaf90152bd7243cf13358c99','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f196681402665cda4fb6677e1ae0ca24f17a81134b5b2a715e8060b9ca08b157',2021,'PA','Panama','energy',840,'Electricity access: electrification—total population: 93.4%
(2016)
electrification—urban areas: 99.4% (2016)
electrification—rural areas: 81.3% (2016)
Electricity—production: 10.6 billion kWh (2016 est.)
country comparison to the world: 101
Electricity—consumption: 8.708 billion kWh (2016 est.)
country comparison to the world: 103
Electricity—exports: 139 million kWh (2015 est.)
country comparison to the world: 80
Electricity—imports: 30 million kWh (2016 est.)
country comparison to the world: 110
Electricity—installed generating capacity: 3.4 million kW (2016
est.)
country comparison to the world: 97
Electricity—from fossil fuels: 36% of total installed capacity
(2016 est.)
country comparison to the world: 175
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 161
Electricity—from hydroelectric plants: 51% of total installed
capacity (2017 est.)
country comparison to the world: 36
Electricity—from other renewable sources: 13% of total installed
Capacity (2017 est.)
country comparison to the world: 69
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 185
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 178
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 180
Crude oil—proved reserves: 0 bbl (1 January 2018)
country comparison to the world: 180
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 188
Refined petroleum products—consumption: 146,000 bbl/day (2016
est.)
country comparison to the world: 67
Refined petroleum products—exports: 66 bbl/day (2015 est.)
country comparison to the world: 121
Refined petroleum products—imports: 129,200 bbl/day (2015 est.)
country comparison to the world: 45
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 182
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 186
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 166
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 171
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 180
Carbon dioxide emissions from consumption of energy: 26.08 million
Mt (2017 est.)
country comparison to the world: 79','a6c43688c22f96bd1884b2dde07f86c9eece4e70f4a319e5d62bd97e69f13429','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18cb4f6c70a2e04337e302ce56c7ecc3dd2f0e5493f165e4e127bc53704e1c7a',2021,'EC','Ecuador','energy',850,'Electricity access: DOpulation without electricity: 2 million
(2017)
electrification—total population: 95% (2017)
electrification—urban areas: 97% (2017)
electrification—rural areas: 89% (2017)
Electricity—production: 50.13 billion kWh (2016 est.)
country comparison to the world: 54
Electricity—consumption: 44.61 billion kWh (2016 est.)
country comparison to the world: 53
Electricity—exports: 55 million kWh (2015 est.)
country comparison to the world: 86
Electricity—imports: 22 million kWh (2016 est.)
country comparison to the world: 112
Electricity—installed generating capacity: 14.73 million kW (2016
est.)
country comparison to the world: 51
Electricity—from fossil fuels: 61% of total installed capacity
(2016 est.)
country comparison to the world: 128
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 164
Electricity—from hydroelectric plants: 35% of total installed
Capacity (2017 est.)
country comparison to the world: 60
Electricity—from other renewable sources: 4% of total installed
Capacity (2017 est.)
country comparison to the world: 116
Crude oil—production: 49,000 bbl/day (2018 est.)
country comparison to the world: 54
Crude oil—exports: 7,995 bbl/day (2015 est.)
country comparison to the world: 61
Crude oil—imports: 86,060 bbl/day (2015 est.)
country comparison to the world: 46
Crude oil—proved reserves: 434.9 million bbl (1 January 2018
est.)
country comparison to the world: 47
Refined petroleum products—production: 166,600 bbl/day (2015
est.)
country comparison to the world: 57
Refined petroleum products—consumption: 250,000 bbl/day (2016
est.)
country comparison to the world: 50
Refined petroleum products—exports: 62,640 bbl/day (2015 est.)
country comparison to the world: 49
Refined petroleum products—imports: 65,400 bbl/day (2015 est.)
country comparison to the world: 71
Natural gas—production: 12.99 billion cu m (2017 est.)
country comparison to the world: 37
Natural gas—consumption: 7.483 billion cu m (2017 est.)
country comparison to the world: 53
Natural gas—exports: 5.505 billion cu m (2017 est.)
country comparison to the world: 28
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 174
Natural gas—proved reserves: 455.9 billion cu m (1 January
2018 est.)
country comparison to the world: 32
Carbon dioxide emissions from consumption of energy: 55.94 million
Mt (2017 est.)
country comparison to the world: 55','b28a0446d727ae7a1dca27040d754cb5f78c49a33aa7a311635e7542b2642712','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e76e950dfe52b73e5eed81892ff410c6665d8ad34fa70f2979978377101a18f',2021,'PH','Philippines','energy',858,'Electricity access: DOpUulation without electricity: 12 million
(2017)
electrification—total population: 88% (2017)
electrification—urban areas: 98% (2017)
electrification—rural areas: 80% (2017)
Electricity—production: 86.59 billion kWh (2016 est.)
country comparison to the world: 36
Electricity—consumption: 78.3 billion kWh (2016 est.)
country comparison to the world: 37
Electricity—exports: KWh (2017 est.)
country comparison to the world: 184
Electricity—imports: kKWh (2016 est.)
country comparison to the world: 186
Electricity—installed generating capacity: 22.13 million kW (2016
est.)
country comparison to the world: 39
Electricity—from fossil fuels: 67% of total installed capacity
(2016 est.)
country comparison to the world: 116
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 165
Electricity—from hydroelectric plants: 17% of total installed
Capacity (2017 est.)
country comparison to the world: 97
Electricity—from other renewable sources: 16% of total installed
capacity (2017 est.) country comparison to the world: 54
Crude oil—production: 13,000 bbl/day (2018 est.)
country comparison to the world: 76
Crude oil—exports: 16,450 bbl/day (2015 est.)
country comparison to the world: 52
Crude oil—imports: 211,400 bbl/day (2015 est.)
country comparison to the world: 30
Crude oil—proved reserves: 138.5 million bbl (1 January 2018
est.)
country comparison to the world: 64
Refined petroleum products—production: 215,500 bbl/day (2015
est.)
country comparison to the world: 50
Refined petroleum products—consumption: 424,000 bbl/day (2016
est.)
country comparison to the world: 36
Refined petroleum products—exports: 26,710 bbl/day (2015 est.)
country comparison to the world: 65
Refined petroleum products—imports: 211,400 bbl/day (2015 est.)
country comparison to the world: 33
Natural gas—production: 3.058 billion cu m (2017 est.)
country comparison to the world: 58
Natural gas—consumption: 3.143 billion cu m (2017 est.)
country comparison to the world: 72
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 168
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 175
Natural gas—proved reserves: 98.54 billion cu m (1 January
2018 est.)
country comparison to the world: 51
Carbon dioxide emissions from consumption of energy: 117.2 million
Mt (2017 est.)
country comparison to the world: 38','7b397333b813debd75a317f97e3f0b30211bbb0fc8b9aeeae28b48058bf429d2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07acc7807ea8e481717b0fc27a82f4f8be164fef3f25aa59b74b2cb0cd83878f',2021,'PL','Poland','energy',870,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 156.9 billion kWh (2016 est.)
country comparison to the world: 25
Electricity—consumption: 149.4 billion kWh (2016 est.)
country comparison to the world: 24
Electricity—exports: 12.02 billion kWh (2016)
country comparison to the world: 17
Electricity—imports: 14.02 billion kWh (2016 est.)
country comparison to the world: 17
Electricity—installed generating capacity: 38.11 million kW (2016
est.)
country comparison to the world: 28
Electricity—from fossil fuels: 79% of total installed capacity
(2016 est.)
country comparison to the world: 87
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 166
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 141
Electricity—from other renewable sources: 19% of total installed
Capacity (2017 est.)
country comparison to the world: 44
Crude oil—production: 21,000 bbl/day (2018 est.)
country comparison to the world: 65
Crude oil—exports: 4,451 bbl/day (2017 est.)
country comparison to the world: 66
Crude oil—imports: 493,100 bbl/day (2017 est.)
country comparison to the world: 19
Crude oil—proved reserves: 126 million bbl (1 January 2018)
country comparison to the world: 66
Refined petroleum products—production: 554,200 bbl/day (2017
est.)
country comparison to the world: 30
Refined petroleum products—consumption: 649,600 bbl/day (2017
est.)
country comparison to the world: 30
Refined petroleum products—exports: 104,800 bbl/day (2017 est.)
country comparison to the world: 43
Refined petroleum products—imports: 222,300 bbl/day (2017 est.)
country comparison to the world: 32
Natural gas—production: 5.748 billion cu m (2017 est.)
country comparison to the world: 49
Natural gas—consumption: 20.1 billion cu m (2017 est.)
country comparison to the world: 38
Natural gas—exports: 1.246 billion cu m (2017 est.)
country comparison to the world: 39
Natural gas—imports: 15.72 billion cu m (2017 est.)
country comparison to the world: 20
Natural gas—proved reserves: 79.79 billion cu m (1 January
2018 est.)
country comparison to the world: 56
Carbon dioxide emissions from consumption of energy: 359 million
Mt (2017 est.)
country comparison to the world: 18
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 56.9 billion kWh (2016 est.)
country comparison to the world: 51
Electricity—consumption: 46.94 billion kWh (2016 est.)
country comparison to the world: 52
Electricity—exports: 9.701 billion kWh (2016 est.)
country comparison to the world: 21
Electricity—imports: 4.616 billion kWh (2016 est.)
country comparison to the world: 40
Electricity—installed generating capacity: 20.56 million kW (2016
est.)
country comparison to the world: 43
Electricity—from fossil fuels: 41% of total installed capacity
(2016 est.)
country comparison to the world: 168
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 167
Electricity—from hydroelectric plants: 25% of total installed
Capacity (2017 est.)
country comparison to the world: 78
Electricity—from other renewable sources: 35% of total installed
Capacity (2017 est.)
country comparison to the world: 10
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 187
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 180
Crude oil—imports: 285,200 bbl/day (2017 est.)
country comparison to the world: 26
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 182
Refined petroleum products—production: 323,000 bbl/day (2017
est.)
country comparison to the world: 39
Refined petroleum products—consumption: 247,200 bbl/day (2017
est.)
country comparison to the world: 51
Refined petroleum products—exports: 143,500 bbl/day (2017 est.)
country comparison to the world: 36
Refined petroleum products—imports: 78,700 bbl/day (2017 est.)
country comparison to the world: 64
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 184
Natural gas—consumption: 6.258 billion cu m (2017 est.)
country comparison to the world: 54
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 169
Natural gas—imports: 6.541 billion cu m (2017 est.)
country comparison to the world: 30
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 182
Carbon dioxide emissions from consumption of energy: 54.97 million
Mt (2017 est.)
country comparison to the world: 57','f2e7c9b34f298e7d1df59cefb7250df147e319e17fe22fed42057559845aa240','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84630bbc94233d1d8b27cb0316f80b9448fa1fae6b07fc24445109c25fa46e06',2021,'BG','Bulgaria','energy',881,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 61.78 billion kWh (2016 est.)
country comparison to the world: 47
Electricity—consumption: 49.64 billion kWh (2016 est.)
country comparison to the world: 49
Electricity—exports: 11.22 billion kWh (2015 est.)
country comparison to the world: 18
Electricity—imports: 4.177 billion kWh (2016 est.)
country comparison to the world: 45
Electricity—installed generating capacity: 23.94 million kW (2016
est.)
country comparison to the world: 38
Electricity—from fossil fuels: 47% of total installed capacity
(2016 est.)
country comparison to the world: 156
Electricity—from nuclear fuels: 6% of total installed capacity
(2017 est.)
country comparison to the world: 20
Electricity—from hydroelectric plants: 29% of total installed
capacity (2017 est.) country comparison to the world: 70
Electricity—from other renewable sources: 19% of total installed
Capacity (2017 est.) country comparison to the world: 45
Crude oil—production: 70,000 bbl/day (2018 est.)
country comparison to the world: 46
Crude oil—exports: 2,076 bbl/day (2015 est.)
country comparison to the world: 70
Crude oil—imports: 145,300 bbl/day (2015 est.)
country comparison to the world: 38
Crude oil—proved reserves: 600 million bbl (1 January 2018
est.)
country comparison to the world: 42
Refined petroleum products—production: 232,600 bbl/day (2015
est.)
country comparison to the world: 47
Refined petroleum products—consumption: 198,000 bbl/day (2016
est.)
country comparison to the world: 58
Refined petroleum products—exports: 103,000 bbl/day (2015 est.)
country comparison to the world: 44
Refined petroleum products—imports: 49,420 bbl/day (2015 est.)
country comparison to the world: 81
Natural gas—production: 10.87 billion cu m (2017 est.)
country comparison to the world: 40
Natural gas—consumption: 11.58 billion cu m (2017 est.)
country comparison to the world: 45
Natural gas—exports: 22.65 million cu m (2017 est.)
country comparison to the world: 53
Natural gas—imports: 1.218 billion cu m (2017 est.)
country comparison to the world: 59
Natural gas—proved reserves: 105.5 billion cu m (1 January
2018 est.)
country comparison to the world: 50
Carbon dioxide emissions from consumption of energy: 72.07 million
Mt (2017 est.) country comparison to the world: 50
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 1.031 trillion kWh (2016 est.)
country comparison to the world: 4
Electricity—consumption: 909.6 billion kWh (2016 est.)
country comparison to the world: 5
Electricity—exports: 13.13 billion kWh (2016 est.)
country comparison to the world: 14
Electricity—imports: 3.194 billion kWh (2016 est.)
country comparison to the world: 48
Electricity—installed generating capacity: 244.9 million kW (2016
est.)
country comparison to the world: 5
Electricity—from fossil fuels: 68% of total installed capacity
(2016 est.)
country comparison to the world: 115
Electricity—from nuclear fuels: 11% of total installed capacity
(2017 est.)
country comparison to the world: 13
Electricity—from hydroelectric plants: 21% of total installed
capacity (2017 est.) country comparison to the world: 86
Electricity—from other renewable sources: 1% of total installed
capacity (2017 est.) country comparison to the world: 164
Crude oil—production: 10.759 million bbl/day (2018 est.)
country comparison to the world: 2
Crude oil—exports: 4.921 million bbl/day (2015 est.)
country comparison to the world: 2
Crude oil—imports: 76,220 bbl/day (2015 est.)
country comparison to the world: 48
Crude oil—proved reserves: 80 billion bbl (1 January 2018 est.)
country comparison to the world: 8
Refined petroleum products—production: 6.076 million bbl/day
(2015 est.)
country comparison to the world: 3
Refined petroleum products—consumption: 3.65 million bbl/day
(2016 est.)
country comparison to the world: 5
Refined petroleum products—exports: 2.671 million bbl/day (2015
est.)
country comparison to the world: 2
Refined petroleum products—imports: 41,920 bbl/day (2015 est.)
country comparison to the world: 88
Natural gas—production: 665.6 billion cu m (2017 est.)
country comparison to the world: 2
Natural gas—consumption: 467.5 billion cu m (2017 est.)
country comparison to the world: 2
Natural gas—exports: 210.2 billion cu m (2017 est.)
country comparison to the world: 1
Natural gas—imports: 15.77 billion cu m (2017 est.)
country comparison to the world: 19
Natural gas—proved reserves: 47.8 trillion cu m (1 January 2018
est.)
country comparison to the world: 1
Carbon dioxide emissions from consumption of energy: 1.847 billion
Mt (2017 est.) country comparison to the world: 4','1c65efde9088e847b395408357515e4f9d857a9d821d8e4a2767705406dd0b8f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33b60d8763e6314ae93bc49a0130cbb5f781e487f15d7b2e91928cb1fe0b117e',2021,'KN','Saint Kitts and Nevis','energy',892,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 208 million kWh (2016 est.)
country comparison to the world: 191
Electricity—consumption: 193.4 million kWh (2016 est.)
country comparison to the world: 193
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 188
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 190
Electricity—installed generating capacity: 64,200 kW (2016 est.)
country comparison to the world: 187
Electricity—from fossil fuels: 94% of total installed capacity
(2016 est.)
country comparison to the world: 48
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 172
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.)
country comparison to the world: 195
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.)
country comparison to the world: 102
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 191
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 184
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 186
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 186
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 193
Refined petroleum products—consumption: 1,700 bbl/day (2016
est.)
country comparison to the world: 196
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 194
Refined petroleum products—imports: 1,743 bbl/day (2015 est.)
country comparison to the world: 192
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 188
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 190
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 173
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 179
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 185
Carbon dioxide emissions from consumption of energy: 248,100 Mt
(2017 est.)
country comparison to the world: 195
Electricity access: electrification—total population: 97.8%
(2016) electrification—urban areas: 94.9% (2016)
electrification—rural areas: 98.4% (2016)
Electricity—production: 369 million kWh (2016 est.)
country comparison to the world: 174
Electricity—consumption: 343.2 million kWh (2016 est.)
country comparison to the world: 181
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 189
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 191
Electricity—installed generating capacity: 89,000 kW (2016 est.)
country comparison to the world: 180
Electricity—from fossil fuels: 99% of total installed capacity
(2016 est.)
country comparison to the world: 25
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 173
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 196
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 165
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 192
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 185
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 187
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 187
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 194
Refined petroleum products—consumption: 3,100 bbl/day (2016
est.)
country comparison to the world: 187
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 195
Refined petroleum products—imports: 3,113 bbl/day (2015 est.)
country comparison to the world: 184
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 189
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 191
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 174
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 180
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 186
Carbon dioxide emissions from consumption of energy: 437,900 Mt
(2017 est.)
country comparison to the world: 186
Electricity access: electrification—total population: 72%
(2016) electrification—urban areas: 89.8% (2016)
Electricity—production: 46 million kWh (2016 est.)
country comparison to the world: 206
Electricity—consumption: 42.78 million kWh (2016 est.)
country comparison to the world: 206
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 190
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 192
Electricity—installed generating capacity: 27,600 kW (2016 est.)
country comparison to the world: 202
Electricity—from fossil fuels: 96% of total installed capacity
(2016 est.)
country comparison to the world: 42
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 174
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 197
Electricity—from other renewable sources: 4% of total installed
Capacity (2017 est.)
country comparison to the world: 118
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 193
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 186
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 188
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 188
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 195
Refined petroleum products—consumption: 660 bbl/day (2016 est.)
country comparison to the world: 208
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 196
Refined petroleum products—imports: 650 bbl/day (2015 est.)
country comparison to the world: 204
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 190
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 192
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 175
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 181
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 187
Carbon dioxide emissions from consumption of energy: 100,200 Mt
(2017 est.)
country comparison to the world: 206
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 157 million kWh (2016 est.)
country comparison to the world: 196
Electricity—consumption: 146 million kWh (2016 est.)
country comparison to the world: 198
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 191
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 193
Electricity—installed generating capacity: 54,000 kW (2016 est.)
country comparison to the world: 189
Electricity—from fossil fuels: 85% of total installed capacity
(2016 est.)
country comparison to the world: 72
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 175
Electricity—from hydroelectric plants: 13% of total installed
Capacity (2017 est.)
country comparison to the world: 110
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.)
country comparison to the world: 143
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 194
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 187
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 189
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 189
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 196
Refined petroleum products—consumption: 1,620 bbl/day (2016
est.)
country comparison to the world: 198
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 197
Refined petroleum products—imports: 1,621 bbl/day (2015 est.)
country comparison to the world: 194
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 191
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 193
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 176
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 182
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 188
Carbon dioxide emissions from consumption of energy: 226,800 Mt
(2017 est.)
country comparison to the world: 197','a386b66c6031229b13c0c90fc20a0d6f4af477eb08bad3730e0b2fe489e0f553','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('861e46edc326ef3c3d9ff26cf1419066301db9fc64483674619bebcb643a237a',2021,'WS','Samoa','energy',900,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 132 million kWh (2016 est.)
country comparison to the world: 197
Electricity—consumption: 122.8 million kWh (2016 est.)
country comparison to the world: 199
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 192
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 194
Electricity—installed generating capacity: 45,000 kW (2016 est.)
country comparison to the world: 194
Electricity—from fossil fuels: 48% of total installed capacity
(2016 est.)
country comparison to the world: 155
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 176
Electricity—from hydroelectric plants: 23% of total installed
Capacity (2017 est.)
country comparison to the world: 85
Electricity—from other renewable sources: 29% of total installed
Capacity (2017 est.)
country comparison to the world: 20
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 195
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 188
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 190
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 190
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 197
Refined petroleum products—consumption: 2,400 bbl/day (2016
est.)
country comparison to the world: 191
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 198
Refined petroleum products—imports: 2,363 bbl/day (2015 est.)
country comparison to the world: 187
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 192
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 194
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 177
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 183
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 189
Carbon dioxide emissions from consumption of energy: 341,100 Mt
(2017 est.)
country comparison to the world: 191','59473e4a11c960cf60d043161b9c0c9bde148da695d30bb234cedb01a02fac02','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da5dc9aebae5500af2df10e680f89270cd4c864d66581fb1f033ae97886cd7d',2021,'ST','Sao Tome and Principe','energy',913,'Electricity access: electrification—total population: 68%
(2017)
electrification—urban areas: 87% (2017)
electrification—rural areas: 22% (2017)
Electricity—production: 66 million kWh (2016 est.)
country comparison to the world: 203
Electricity—consumption: 61.38 million kWh (2016 est.)
country comparison to the world: 203
Electricity—exports: 0 kWh (2016)
country comparison to the world: 193
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 195
Electricity—installed generating capacity: 18,100 kW (2016 est.)
country comparison to the world: 205
Electricity—from fossil fuels: 88% of total installed capacity
(2016 est.)
country comparison to the world: 60
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 177
Electricity—from hydroelectric plants: 11% of total installed
Capacity (2017 est.)
country comparison to the world: 115
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 166
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 196
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 189
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 191
Crude oil—proved reserves: 0 bbl (1 January 2018)
country comparison to the world: 191
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 198
Refined petroleum products—consumption: 1,000 bbl/day (2016
est.)
country comparison to the world: 206
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 199
Refined petroleum products—imports: 1,027 bbl/day (2015 est.)
country comparison to the world: 202
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 193
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 195
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 178
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 184
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 190
Carbon dioxide emissions from consumption of energy: 148,100 Mt
(2017 est.)
country comparison to the world: 204','fb47b6bd788f7aecec4d6f984c7cbe8bb936798d2a34806a1cd8a3a06549763c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09eda8fc4151ad09e8362a4519106c51191181ed130097e0bcf5c35b3ef19963',2021,'ID','Indonesia','energy',918,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 48.66 billion kWh (2016 est.)
country comparison to the world: 55
Electricity—consumption: 47.69 billion kWh (2016 est.)
country comparison to the world: 51
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 198
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 200
Electricity—installed generating capacity: 13.35 million kW (2016
est.)
country comparison to the world: 53
Electricity—from fossil fuels: 98% of total installed capacity
(2016 est.)
country comparison to the world: 29
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 183
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 200
Electricity—from other renewable sources: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 144
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 200
Crude oil—exports: 14,780 bbl/day (2015 est.)
country comparison to the world: 54
Crude oil—imports: 783,300 bbl/day (2015 est.)
country comparison to the world: 15
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 195
Refined petroleum products—production: 755,000 bbl/day (2015
est.)
country comparison to the world: 24
Refined petroleum products—consumption: 1.322 million bbl/day
(2016 est.)
country comparison to the world: 17
Refined petroleum products—exports: 1.82 million bbl/day (2015
est.)
country comparison to the world: 4
Refined petroleum products—imports: 2.335 million bbl/day (2015
est.)
country comparison to the world: 1
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 196
Natural gas—consumption: 12.97 billion cu m (2017 est.)
country comparison to the world: 44
Natural gas—exports: 622.9 million cu m (2017 est.)
country comparison to the world: 41
Natural gas—imports: 13.48 billion cu m (2017 est.)
country comparison to the world: 23
Natural gas—proved reserves: 0 cu m (1 January 2017 est.)
country comparison to the world: 194
Carbon dioxide emissions from consumption of energy: 249.5 million
Mt (2017 est.)
country comparison to the world: 27
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 304.3 million kWh (2008 est.)
country comparison to the world: 181
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 193
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 195
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 201
Refined petroleum products—consumption: 10,600 bbl/day (2016
est.)
country comparison to the world: 161
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 202
Refined petroleum products—imports: 10,440 bbl/day (2015 est.)
country comparison to the world: 148
Electricity access: electrification—total population: 63.4%
(2016)
electrification—urban areas: 91.7% (2016)
electrification—rural areas: 49.2% (2016)
Electricity—production: 0 kWh NA (2016 est.)
country comparison to the world: 219
Electricity—consumption: 0 kWh (2016 est.)
country comparison to the world: 218
Electricity—exports: 0 kWh (2017 est.)
country comparison to the world: 207
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 209
Electricity—installed generating capacity: 6(00 kW NA (2016 est.)
country comparison to the world: 215
Electricity—from fossil fuels: 0% of total installed capacity (2016
est.)
country comparison to the world: 215
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 194
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.)
country comparison to the world: 204
Electricity—from other renewable sources: 100% of total installed
Capacity (2017 est.)
country comparison to the world: 1
Crude oil—production: 33,000 bbl/day (2018 est.)
country comparison to the world: 60
Crude oil—exports: 62,060 bbl/day (2015 est.)
country comparison to the world: 39
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 203
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 203
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 207
Refined petroleum products—consumption: 3,500 bbl/day (2016
est.)
country comparison to the world: 186
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 208
Refined petroleum products—imports: 3,481 bbl/day (2015 est.)
country comparison to the world: 182
Natural gas—production: 5.776 billion cu m (2017 est.)
country comparison to the world: 48
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 205
Natural gas—exports: 5.776 billion cu m (2017 est.)
country comparison to the world: 27
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 199
Natural gas—proved reserves: 200 billion cu m (1 January 2006
est.)
country comparison to the world: 42
Carbon dioxide emissions from consumption of energy: 533,400 Mt
(2017 est.)
country comparison to the world: 184','072622028a7a83a4ad8b206098d7a3cd41bfe66ff0bd780451e0eb644dcc7fc9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bec2966153b8027166fd4c68eab8ff9b1a4d881c06084f5c7336d590d2a83e6c',2021,'SK','Slovakia','energy',925,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 25.32 billion kWh (2016 est.)
country comparison to the world: 72
Electricity—consumption: 26.64 billion kWh (2016 est.)
country comparison to the world: 66
Electricity—exports: 10.6 billion kWh (2016 est.)
country comparison to the world: 19
Electricity—imports: 13.25 billion kWh (2016 est.)
country comparison to the world: 19
Electricity—installed generating capacity: 7.644 million kW (2016
est.)
country comparison to the world: 72
Electricity—from fossil fuels: 36% of total installed capacity
(2016 est.)
country comparison to the world: 176
Electricity—from nuclear fuels: 27% of total installed capacity
(2017 est.)
country comparison to the world: 3
Electricity—from hydroelectric plants: 24% of total installed
Capacity (2017 est.)
country comparison to the world: 81
Electricity—from other renewable sources: 13% of total installed
capacity (2017 est.)
country comparison to the world: 70
Crude oil—production: 200 bbl/day (2018 est.)
country comparison to the world: 95
Crude oil—exports: 1,022 bbl/day (2017 est.)
country comparison to the world: 74
Crude oil—imports: 111,200 bbl/day (2017 est.)
country comparison to the world: 42
Crude oil—proved reserves: 9 million bbl (1 January 2018 est.)
country comparison to the world: 91
Refined petroleum products—production: 131,300 bbl/day (2017
est.)
country comparison to the world: 64
Refined petroleum products—consumption: 85,880 bbl/day (2017
est.)
country comparison to the world: 85
Refined petroleum products—exports: 81,100 bbl/day (2017 est.)
country comparison to the world: 46
Refined petroleum products—imports: 38,340 bbl/day (2017 est.)
country comparison to the world: 91
Natural gas—production: 104.8 million cu m (2017 est.)
country comparison to the world: 81
Natural gas—consumption: 4.672 billion cu m (2017 est.)
country comparison to the world: 62
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 184
Natural gas—imports: 4.984 billion cu m (2017 est.)
country comparison to the world: 37
Natural gas—proved reserves: 14.16 billion cu m (1 January
2018 est.)
country comparison to the world: 75
Carbon dioxide emissions from consumption of energy: 34.86 million
Mt (2017 est.)
country comparison to the world: 73','4e5ec674bccf5a6ad03e98e90c72375213741381763fbd51108608d604ebb22e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcdeff45e78fc89c93ef55de52f2609546331c8e9af0c06ea3b61f4489ba01fa',2021,'SI','Slovenia','energy',931,'Electricity access: electrification—total population: 100%
(2016) Electricity—production: 15.46 billion kWh (2016 est.)
country comparison to the world: 88
Electricity—consumption: 13.4 billion kWh (2016 est.)
country comparison to the world: 84
Electricity—exports: 7.972 billion kWh (2017 est.)
country comparison to the world: 26
Electricity—imports: 8.359 billion kWh (2016 est.)
country comparison to the world: 29
Electricity—installed generating capacity: 3.536 million kW (2016
est.)
country comparison to the world: 95
Electricity—from fossil fuels: 37% of total installed capacity
(2016 est.)
country comparison to the world: 174
Electricity—from nuclear fuels: 20% of total installed capacity
(2017 est.)
country comparison to the world: 9
Electricity—from hydroelectric plants: 34% of total installed
Capacity (2017 est.)
country comparison to the world: 63
Electricity—from other renewable sources: 9% of total installed
Capacity (2017 est.)
country comparison to the world: 84
Crude oil—production: 5 bbl/day (2018 est.)
country comparison to the world: 100
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 194
Crude oil—imports: 0 bbl/day (2017 est.)
country comparison to the world: 196
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 196
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 202
Refined petroleum products—consumption: 52,140 bbl/day (2017
est.)
country comparison to the world: 102
Refined petroleum products—exports: 29,350 bbl/day (2017 est.)
country comparison to the world: 63
Refined petroleum products—imports: 93,060 bbl/day (2017 est.)
country comparison to the world: 56
Natural gas—production: 8 million cu m (2017 est.)
country comparison to the world: 94
Natural gas—consumption: 906.1 million cu m (2017 est.)
country comparison to the world: 94
Natural gas—exports: 2.832 million cu m (2017 est.)
country comparison to the world: 55
Natural gas—imports: 906.1 million cu m (2017 est.)
country comparison to the world: 62
Natural gas—proved reserves: NA cu m (2017 est.)
Carbon dioxide emissions from consumption of energy: 14.37 million
Mt (2017 est.)
country comparison to the world: 94
Electricity access: electrification—total population: 47.9%
(2016) electrification—urban areas: 69.6% (2016)
electrification—rural areas: 41.5% (2016)
Electricity—production: 103 million kWh (2016 est.)
country comparison to the world: 200
Electricity—consumption: 95.79 million kWh (2016 est.)
country comparison to the world: 202
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 199
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 201
Electricity—installed generating capacity: 38,000 kW (2016 est.)
country comparison to the world: 198
Electricity—from fossil fuels: 92% of total installed capacity
(2016 est.)
country comparison to the world: 52
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 184
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 201
Electricity—from other renewable sources: 8% of total installed
Capacity (2017 est.)
country comparison to the world: 90
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 201
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 195
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 197
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 197
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 203
Refined petroleum products—consumption: 1,600 bbl/day (2016
est.)
country comparison to the world: 199
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 203
Refined petroleum products—imports: 1,577 bbl/day (2015 est.)
country comparison to the world: 195
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 197
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 198
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 185
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 189
Natural gas—proved reserves: 0 Cu m (1 January 2014 est.)
country comparison to the world: 195
Carbon dioxide emissions from consumption of energy: 233,500 Mt
(2017 est.)
country comparison to the world: 196','af04a691453ab1a7f2d0caad44abc081e3680264112bb84a6945c5033670c106','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55cc09ee7dffff32e088bb1784eee7a054c2b4e08892134f2c948dae0f50fddd',2021,'SO','Somalia','energy',939,'Electricity access: DOpUulation without electricity: 12 million
(2017)
electrification—total population: 17% (2017)
electrification—urban areas: 35% (2017)
electrification—rural areas: 4% (2017)
Electricity—production: 339 million kWh (2016 est.)
country comparison to the world: 176
Electricity—consumption: 315.3 million kWh (2016 est.)
country comparison to the world: 183
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 200
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 202
Electricity—installed generating capacity: 85,000 kW (2016 est.)
country comparison to the world: 182
Electricity—from fossil fuels: 93% of total installed capacity
(2016 est.)
country comparison to the world: 51
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 185
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 202
Electricity—from other renewable sources: 7% of total installed
Capacity (2017 est.)
country comparison to the world: 97
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 202
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 196
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 198
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 198
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 204
Refined petroleum products—consumption: 5,600 bbl/day (2016
est.)
country comparison to the world: 174
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 204
Refined petroleum products—imports: 5,590 bbl/day (2015 est.)
country comparison to the world: 167
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 198
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 199
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 186
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 190
Natural gas—proved reserves: 5.663 billion cu m (1 January
2018 est.)
country comparison to the world: 90
Carbon dioxide emissions from consumption of energy: 852,500 Mt
(2017 est.)
country comparison to the world: 173
Electricity access: DOpulation without electricity: 9 million
(2017)
electrification—total population: 84.2% (2016)
electrification—urban areas: 92.9% (2016)
electrification—rural areas: 67.9% (2016)
Electricity—production: 234.5 billion kWh (2016 est.)
country comparison to the world: 21
Electricity—consumption: 207.1 billion kWh (2016 est.)
country comparison to the world: 21
Electricity—exports: 16.55 billion kWh (2016 est.)
country comparison to the world: 11
Electricity—imports: 10.56 billion kWh (2016 est.)
country comparison to the world: 24
Electricity—installed generating capacity: 50.02 million kW (2016
est.)
country comparison to the world: 21
Electricity—from fossil fuels: 85% of total installed capacity
(2016 est.)
country comparison to the world: 73
Electricity—from nuclear fuels: 4% of total installed capacity
(2017 est.)
country comparison to the world: 24
Electricity—from hydroelectric plants: 1% of total installed
capacity (2017 est.)
country comparison to the world: 150
Electricity—from other renewable sources: 10% of total installed
Capacity (2017 est.)
country comparison to the world: 81
Crude oil—production: 1,600 bbl/day (2018 est.)
country comparison to the world: 89
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 197
Crude oil—imports: 404,000 bbl/day (2015 est.)
country comparison to the world: 22
Crude oil—proved reserves: 15 million bbl (1 January 2018 est.)
country comparison to the world: 86
Refined petroleum products—production: 487,100 bbl/day (2015
est.)
country comparison to the world: 33
Refined petroleum products—consumption: 621,000 bbl/day (2016
est.)
country comparison to the world: 32
Refined petroleum products—exports: 105,600 bbl/day (2015 est.)
country comparison to the world: 42
Refined petroleum products—imports: 195,200 bbl/day (2015 est.)
country comparison to the world: 34
Natural gas—production: 906.1 million cu m (2017 est.)
country comparison to the world: 70
Natural gas—consumption: 5.069 billion cu m (2017 est.)
country comparison to the world: 60
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 187
Natural gas—imports: 4.162 billion cu m (2017 est.)
country comparison to the world: 39
Natural gas—proved reserves: (0 cu m (1 January 2012 est.)
country comparison to the world: 196
Carbon dioxide emissions from consumption of energy: 572.3 million
Mt (2017 est.)
country comparison to the world: 11','905cfcf9b71c86f1edee01f3d2ff7457824a20cc6578e0cf80fa54f1d473db29','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29a0c47a372dd2da330dff0b8d756de865f735c821476787584ad1a105fa8d50',2021,'SD','Sudan','energy',952,'Electricity access: DOpUulation without electricity: 12 million
(2017)
electrification—total population: 8.9% (2016)
electrification—urban areas: 22% (2016)
electrification—rural areas: 5.9% (2016)
Electricity—production: 412.8 million kWh (2016 est.)
country comparison to the world: 169
Electricity—consumption: 391.8 million kWh (2016 est.)
country comparison to the world: 175
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 201
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 203
Electricity—installed generating capacity: 80,400 kW (2016 est.)
country comparison to the world: 185
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 18
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 186
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 203
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 168
Crude oil—production: 150,200 bbl/day (2017 est.)
country comparison to the world: 39
Crude oil—exports: 147,300 bbl/day (2015 est.)
country comparison to the world: 32
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 199
Crude oil—proved reserves: 3.75 billion bbl (1 January 2017
est.)
country comparison to the world: 26
Refined petroleum products—production: 0 bbl/day (2017 est.)
country comparison to the world: 205
Refined petroleum products—consumption: 8,000 bbl/day (2016
est.)
country comparison to the world: 165
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 205
Refined petroleum products—imports: 7,160 bbl/day (2015 est.)
country comparison to the world: 157
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 199
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 200
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 188
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 191
Natural gas—proved reserves: 63.71 billion cu m (1 January
2016 est.)
country comparison to the world: 59
Carbon dioxide emissions from consumption of energy: 1.224 million
Mt (2017 est.)
country comparison to the world: 163
Electricity access: DOpulation without electricity: 22 million
(2017) electrification—total population: 45% (2017)
electrification—urban areas: 71% (2017)
electrification—rural areas: 31% (2017)
Electricity—production: 13.99 billion kWh (2016 est.)
country comparison to the world: 89
Electricity—consumption: 12.12 billion kWh (2016 est.)
country comparison to the world: 88
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 203
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 205
Electricity—installed generating capacity: 3.437 million kW (2016
est.) country comparison to the world: 96
Electricity—from fossil fuels: 44% of total installed capacity
(2016 est.) country comparison to the world: 162
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 188
Electricity—from hydroelectric plants: 51% of total installed
capacity (2017 est.) country comparison to the world: 39
Electricity—from other renewable sources: 6% of total installed
capacity (2017 est.) country comparison to the world: 104
Crude oil—production: 95,000 bbl/day (2018 est.)
country comparison to the world: 43
Crude oil—exports: 19,540 bbl/day (2015 est.)
country comparison to the world: 50
Crude oil—imports: 9,440 bbl/day (2015 est.)
country comparison to the world: 73
Crude oil—proved reserves: 5 billion bbl (1 January 2018 est.)
country comparison to the world: 22
Refined petroleum products—production: 94,830 bbl/day (2015
est.)
country comparison to the world: 68
Refined petroleum products—consumption: 112,000 bbl/day (2016
est.) country comparison to the world: 75
Refined petroleum products—exports: 8,541 bbl/day (2015 est.)
country comparison to the world: 85
Refined petroleum products—imports: 24,340 bbl/day (2015 est.)
country comparison to the world: 108
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 201
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 202
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 190
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 193
Natural gas—proved reserves: 84.95 billion cu m (1 January
2018 est.) country comparison to the world: 55
Carbon dioxide emissions from consumption of energy: 16.03 million
Mt (2017 est.) country comparison to the world: 92','59fa28a73ac00d5d17c7a35af2894e5f966b81e9f9837943d38879497736a31b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cc9b5859aaf76681171c0ba3b26f9733fa07ec6717b2b3fb5d7cddfe1445746',2021,'LK','Sri Lanka','energy',964,'Electricity access: electrification—total population: 95.6%
(2016) electrification—urban areas: 100% (2016)
electrification—rural areas: 94.6% (2016)
Electricity—production: 13.66 billion kWh (2016 est.)
country comparison to the world: 90
Electricity—consumption: 12.67 billion kWh (2016 est.)
country comparison to the world: 86
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 202
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 204
Electricity—installed generating capacity: 3.998 million kW (2016
est.) country comparison to the world: 89
Electricity—from fossil fuels: 52% of total installed capacity
(2016 est.) country comparison to the world: 146
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 187
Electricity—from hydroelectric plants: 42% of total installed
capacity (2017 est.) country comparison to the world: 49
Electricity—from other renewable sources: 6% of total installed
Capacity (2017 est.) country comparison to the world: 103
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 203
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 199
Crude oil—imports: 33,540 bbl/day (2015 est.)
country comparison to the world: 60
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 199
Refined petroleum products—production: 34,210 bbl/day (2017
est.)
country comparison to the world: 84
Refined petroleum products—consumption: 116,000 bbl/day (2016
est.) country comparison to the world: 74
Refined petroleum products—exports: 3,871 bbl/day (2015 est.)
country comparison to the world: 96
Refined petroleum products—imports: 66,280 bbl/day (2015 est.)
country comparison to the world: 70
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 200
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 201
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 189
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 192
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 197
Carbon dioxide emissions from consumption of energy: 25.19 million
Mt (2017 est.) country comparison to the world: 80','a823f1fd0653ad73f4129677a733403c86f5025d780d389d64fe836064fc2301','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('141c82221b30a1e9dc27ae1304bd5fd974c25b51801602f75980d3ad30260f6f',2021,'NO','Norway','energy',970,'Crude oil—production: 194,300 bbl/day (2014 est.)
country comparison to the world: 36
Crude oil—exports: 16,070 bbl/day (2012 est.)
country comparison to the world: 53
Crude oil—imports: 0 bbl/day (2012 est.)
country comparison to the world: 200
Refined petroleum products—consumption: 80,250 bbl/day (2013
est.)
country comparison to the world: 87
Refined petroleum products—exports: 4,488 bbl/day (2012 est.)
country comparison to the world: 93
Refined petroleum products—imports: 18,600 bbl/day (2012 est.)
country comparison to the world: 127
Natural gas—production: 0 cu m (2013 est.)
country comparison to the world: 203
Natural gas—consumption: 0 cu m (2013 est.)
country comparison to the world: 204
Natural gas—exports: 0 cu m (2013 est.)
country comparison to the world: 192
Natural gas—imports: 0 cu m (2013 est.)
country comparison to the world: 195
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 152.9 billion kWh (2016 est.)
country comparison to the world: 27
Electricity—consumption: 133.5 billion kWh (2016 est.)
country comparison to the world: 27
Electricity—exports: 26.02 billion kWh (2016 est.)
country comparison to the world: 6
Electricity—imports: 14.29 billion kWh (2016 est.)
country comparison to the world: 16
Electricity—installed generating capacity: 40.29 million kW (2016
est.)
country comparison to the world: 26
Electricity—from fossil fuels: 5% of total installed capacity (2016
est.)
country comparison to the world: 204
Electricity—from nuclear fuels: 22% of total installed capacity
(2017 est.)
country comparison to the world: 6
Electricity—from hydroelectric plants: 42% of total installed
Capacity (2017 est.)
country comparison to the world: 50
Electricity—from other renewable sources: 32% of total installed
Capacity (2017 est.)
country comparison to the world: 16
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 204
Crude oil—exports: 14,570 bbl/day (2017 est.)
country comparison to the world: 55
Crude oil—imports: 400,200 bbl/day (2017 est.)
country comparison to the world: 23
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 200
Refined petroleum products—production: 413,200 bbl/day (2017
est.)
country comparison to the world: 36
Refined petroleum products—consumption: 323,100 bbl/day (2017
est.)
country comparison to the world: 42
Refined petroleum products—exports: 371,100 bbl/day (2017 est.)
country comparison to the world: 23
Refined petroleum products—imports: 229,600 bbl/day (2017 est.)
country comparison to the world: 29
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 204
Natural gas—consumption: 764.5 million cu m (2017 est.)
country comparison to the world: 97
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 193
Natural gas—imports: 764.5 million cu m (2017 est.)
country comparison to the world: 64
Natural gas—proved reserves: (0 cu m (1 January 2014 est.)
country comparison to the world: 199
Carbon dioxide emissions from consumption of energy: 52.31 million
Mt (2017 est.)
country comparison to the world: 58','8bde8b083aadee3b097bf081ed27d6f23d3804172487c6ef6d97e167309727d5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec716d6effa9dbe45d3079f2938a69ba14869742a584c1d165a5b3674489e84c',2021,'MY','Malaysia','energy',985,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 181.5 billion kWh (2016 est.)
country comparison to the world: 23
Electricity—consumption: 187.7 billion kWh (2016 est.)
country comparison to the world: 22
Electricity—exports: 2.267 billion kWh (2015 est.)
country comparison to the world: 44
Electricity—imports: 19.83 billion kWh (2016 est.)
country comparison to the world: 11
Electricity—installed generating capacity: 44.89 million kW (2016
est.)
country comparison to the world: 24
Electricity—from fossil fuels: 76% of total installed capacity
(2016 est.)
country comparison to the world: 94
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 193
Electricity—from hydroelectric plants: 8% of total installed
Capacity (2017 est.)
country comparison to the world: 124
Electricity—from other renewable sources: 16% of total installed
Capacity (2017 est.)
country comparison to the world: 55
Crude oil—production: 228,000 bbl/day (2018 est.)
country comparison to the world: 34
Crude oil—exports: 790 bbl/day (2015 est.)
country comparison to the world: 76
Crude oil—imports: 875,400 bbl/day (2015 est.)
country comparison to the world: 12
Crude oil—proved reserves: 349.4 million bbl (1 January 2018
est.)
country comparison to the world: 50
Refined petroleum products—production: 1.328 million bbl/day
(2015 est.)
country comparison to the world: 14
Refined petroleum products—consumption: 1.326 million bbl/day
(2016 est.)
country comparison to the world: 16
Refined petroleum products—exports: 278,300 bbl/day (2015 est.)
country comparison to the world: 29
Refined petroleum products—imports: 134,200 bbl/day (2015 est.)
country comparison to the world: 44
Natural gas—production: 38.59 billion cu m (2017 est.)
country comparison to the world: 22
Natural gas—consumption: 52.64 billion cu m (2017 est.)
country comparison to the world: 16
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 199
Natural gas—imports: 14.41 billion cu m (2017 est.)
country comparison to the world: 21
Natural gas—proved reserves: 193.4 billion cu m (1 January
2018 est.)
country comparison to the world: 43
Carbon dioxide emissions from consumption of energy: 355 million
Mt (2017 est.)
country comparison to the world: 19','c3570404a97f79de1e088298a825078c714b8278b695fd5674020570e2e10f37','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('367a2c8c565bbc171e1957e09901fe0f4cf66680105196107438d081325b6bd8',2021,'TT','Trinidad and Tobago','energy',996,'Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 10.07 billion kWh (2016 est.)
country comparison to the world: 103
Electricity—consumption: 9.867 billion kWh (2016 est.)
country comparison to the world: 97
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 210
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 211
Electricity—installed generating capacity: 2.608 million kW (2016
est.)
country comparison to the world: 104
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 19
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 197
Electricity—from hydroelectric plants: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 206
Electricity—from other renewable sources: 0% of total installed
Capacity (2017 est.)
country comparison to the world: 209
Crude oil—production: 63,000 bbl/day (2018 est.)
country comparison to the world: 48
Crude oil—exports: 31,030 bbl/day (2015 est.)
country comparison to the world: 45
Crude oil—imports: 80,860 bbl/day (2015 est.)
country comparison to the world: 47
Crude oil—proved reserves: 243 million bbl (1 January 2018
est.)
country comparison to the world: 53
Refined petroleum products—production: 134,700 bbl/day (2015
est.)
country comparison to the world: 63
Refined petroleum products—consumption: 51,000 bbl/day (2016
est.)
country comparison to the world: 105
Refined petroleum products—exports: 106,100 bbl/day (2015 est.)
country comparison to the world: 40
Refined petroleum products—imports: 0 bbl/day (2015 est.)
country comparison to the world: 213
Natural gas—production: 36.73 billion cu m (2017 est.)
country comparison to the world: 23
Natural gas—consumption: 21.24 billion cu m (2017 est.)
country comparison to the world: 37
Natural gas—exports: 15.49 billion cu m (2017 est.)
country comparison to the world: 14
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 202
Natural gas—proved reserves: 447.4 billion cu m (1 January
2018 est.)
country comparison to the world: 33
Carbon dioxide emissions from consumption of energy: 48.92 million
Mt (2017 est.)
country comparison to the world: 61
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 18.44 billion kWh (2016 est.)
country comparison to the world: 78
Electricity—consumption: 15.27 billion kWh (2016 est.)
country comparison to the world: 79
Electricity—exports: 500 million kWh (2015 est.)
country comparison to the world: 68
Electricity—imports: 134 million kWh (2016 est.)
country comparison to the world: 96
Electricity—installed generating capacity: 5.768 million kW (2016
est.)
country comparison to the world: 77
Electricity—from fossil fuels: 94% of total installed capacity
(2016 est.)
country comparison to the world: 49
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 198
Electricity—from hydroelectric plants: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 151
Electricity—from other renewable sources: 5% of total installed
capacity (2017 est.)
country comparison to the world: 109
Crude oil—production: 39,000 bbl/day (2018 est.)
country comparison to the world: 59
Crude oil—exports: 39,980 bbl/day (2015 est.)
country comparison to the world: 42
Crude oil—imports: 17,580 bbl/day (2015 est.)
country comparison to the world: 66
Crude oil—proved reserves: 425 million bbl (1 January 2018
est.)
country comparison to the world: 48
Refined petroleum products—production: 27,770 bbl/day (2015
est.)
country comparison to the world: 85
Refined petroleum products—consumption: 102,000 bbl/day (2016
est.)
country comparison to the world: 79
Refined petroleum products—exports: 13,660 bbl/day (2015 est.)
country comparison to the world: 75
Refined petroleum products—imports: 85,340 bbl/day (2015 est.)
country comparison to the world: 58
Natural gas—production: 1.274 billion cu m (2017 est.)
country comparison to the world: 64
Natural gas—consumption: 5.125 billion cu m (2017 est.)
country comparison to the world: 59
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 202
Natural gas—imports: 3.851 billion cu m (2017 est.)
country comparison to the world: 41
Natural gas—proved reserves: 65.13 billion cu m (1 January
2018 est.)
country comparison to the world: 58
Carbon dioxide emissions from consumption of energy: 23.42 million
Mt (2017 est.)
country comparison to the world: 82
Electricity access: electrification—total population: 100%
(2016)
Electricity—production: 261.9 billion kWh (2016 est.)
country comparison to the world: 16
Electricity—consumption: 231.1 billion kWh (2016 est.)
country comparison to the world: 18
Electricity—exports: 1.442 billion kWh (2016 est.)
country comparison to the world: 49
Electricity—imports: 6.33 billion kWh (2016 est.)
country comparison to the world: 31
Electricity—installed generating capacity: 78.5 million kW (2016
est.)
country comparison to the world: 15
Electricity—from fossil fuels: 53% of total installed capacity
(2016 est.)
country comparison to the world: 144
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 199
Electricity—from hydroelectric plants: 33% of total installed
Capacity (2017 est.)
country comparison to the world: 64
Electricity—from other renewable sources: 14% of total installed
Capacity (2017 est.)
country comparison to the world: 64
Crude oil—production: 55,000 bbl/day (2018 est.)
country comparison to the world: 51
Crude oil—exports: 0 bbl/day (2017 est.)
country comparison to the world: 208
Crude oil—imports: 521,500 bbl/day (2017 est.)
country comparison to the world: 17
Crude oil—proved reserves: 341.6 million bbl (1 January 2018
est.)
country comparison to the world: 51
Refined petroleum products—production: 657,900 bbl/day (2017
est.)
country comparison to the world: 27
Refined petroleum products—consumption: 989,900 bbl/day (2017
est.)
country comparison to the world: 21
Refined petroleum products—exports: 141,600 bbl/day (2017 est.)
country comparison to the world: 37
Refined petroleum products—imports: 560,000 bbl/day (2017 est.)
country comparison to the world: 16
Natural gas—production: 368.1 million cu m (2017 est.)
country comparison to the world: 75
Natural gas—consumption: 53.6 billion cu m (2017 est.)
country comparison to the world: 15
Natural gas—exports: 622.9 million cu m (2017 est.)
country comparison to the world: 42
Natural gas—imports: 55.13 billion cu m (2017 est.)
country comparison to the world: 6
Natural gas—proved reserves: 5.097 billion cu m (1 January
2018 est.)
country comparison to the world: 92
Carbon dioxide emissions from consumption of energy: 379.5 million
Mt (2017 est.)
country comparison to the world: 17','32ce8d865b1409b89ff6ab25a7030d77006f682a2737d8511bf9551ea6ea04b0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4040baa2cc3b6bf90a03e6188943801fa4d243436003ea13ef45d9faf9599115',2021,'SS','South Sudan','energy',1002,'Electricity access: DOpulation without electricity: 34 million
(2017) electrification—total population: 20% (2017)
electrification—urban areas: 23% (2017)
electrification—rural areas: 19% (2017)
Electricity—production: 3.463 billion kWh (2016 est.)
country comparison to the world: 130
Electricity—consumption: 3.106 billion kWh (2016 est.)
country comparison to the world: 135
Electricity—exports: 121 million kWh (2015 est.)
country comparison to the world: 81
Electricity—imports: 50 million kWh (2016 est.)
country comparison to the world: 107
Electricity—installed generating capacity: 1.02 million kW (2016
est.)
country comparison to the world: 127
Electricity—from fossil fuels: 19% of total installed capacity
(2016 est.)
country comparison to the world: 195
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 203
Electricity—from hydroelectric plants: 68% of total installed
Capacity (2017 est.)
country comparison to the world: 19
Electricity—from other renewable sources: 12% of total installed
Capacity (2017 est.)
country comparison to the world: 75
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 211
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 211
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 209
Crude oil—proved reserves: 2.5 billion bbl (1 January 2018 est.)
country comparison to the world: 31
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 212
Refined petroleum products—consumption: 32,000 bbl/day (2016
est.)
country comparison to the world: 119
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 213
Refined petroleum products—imports: 31,490 bbl/day (2015 est.)
country comparison to the world: 99
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 210
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 210
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 205
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 206
Natural gas—proved reserves: 14.16 billion cu m (1 January
2018 est.)
country comparison to the world: 76
Carbon dioxide emissions from consumption of energy: 4.703 million
Mt (2017 est.)
country comparison to the world: 135
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 153.6 billion kWh (2016 est.)
country comparison to the world: 26
Electricity—consumption: 133.2 billion kWh (2016 est.)
country comparison to the world: 28
Electricity—exports: 3.591 billion kWh (2015 est.)
country comparison to the world: 39
Electricity—imports: 77 million kWh (2016 est.)
country comparison to the world: 103
Electricity—installed generating capacity: 57.28 million kW (2016
est.)
country comparison to the world: 20
Electricity—from fossil fuels: 65% of total installed capacity
(2016 est.)
country comparison to the world: 120
Electricity—from nuclear fuels: 23% of total installed capacity
(2017 est.)
country comparison to the world: 4
Electricity—from hydroelectric plants: 8% of total installed
Capacity (2017 est.)
country comparison to the world: 125
Electricity—from other renewable sources: 3% of total installed
Capacity (2017 est.)
country comparison to the world: 129
Crude oil—production: 32,000 bbl/day (2018 est.)
country comparison to the world: 61
Crude oil—exports: 413 bbl/day (2015 est.)
country comparison to the world: 79
Crude oil—imports: 4,720 bbl/day (2015 est.)
country comparison to the world: 76
Crude oil—proved reserves: 395 million bbl (1 January 2018
est.)
country comparison to the world: 49
Refined petroleum products—production: 63,670 bbl/day (2017
est.)
country comparison to the world: 77
Refined petroleum products—consumption: 233,000 bbl/day (2016
est.)
country comparison to the world: 53
Refined petroleum products—exports: 1,828 bbl/day (2015 est.)
country comparison to the world: 105
Refined petroleum products—imports: 167,000 bbl/day (2015 est.)
country comparison to the world: 37
Natural gas—production: 19.73 billion cu m (2017 est.)
country comparison to the world: 31
Natural gas—consumption: 30.92 billion cu m (2017 est.)
country comparison to the world: 30
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 206
Natural gas—imports: 12.97 billion cu m (2017 est.)
country comparison to the world: 25
Natural gas—proved reserves: 1.104 trillion cu m (1 January
2018 est.)
country comparison to the world: 24
Carbon dioxide emissions from consumption of energy: 238.9 million
Mt (2017 est.)
country comparison to the world: 28','206cf0cdb0ea9fcfa21e92adbc4a9fb357ba9380a00aac18761fa186f364d599','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a73da7787827af9e96320f0cef92bb6588ed2d13b934ec7b1ecf29a08ba61775',2021,'AE','United Arab Emirates','energy',1010,'Electricity access: electrification—total population: 100%
(2017) Electricity—production: 121.8 billion kWh (2016 est.)
country comparison to the world: 31
Electricity—consumption: 113.2 billion kWh (2016 est.)
country comparison to the world: 31
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 213
Electricity—imports: 1.141 billion kWh (2016 est.)
country comparison to the world: 66
Electricity—installed generating capacity: 28.91 million kW (2016
est.)
country comparison to the world: 33
Electricity—from fossil fuels: 99% of total installed capacity
(2016 est.)
country comparison to the world: 26
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 204
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 210
Electricity—from other renewable sources: 1% of total installed
Capacity (2017 est.)
country comparison to the world: 170
Crude oil—production: 3.216 million bbl/day (2018 est.)
country comparison to the world: 8
Crude oil—exports: 2.552 million bbl/day (2015 est.)
country comparison to the world: 5
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 210
Crude oil—proved reserves: 97.8 billion bbl (1 January 2018
est.)
country comparison to the world: 7
Refined petroleum products—production: 943,500 bbl/day (2017
est.)
country comparison to the world: 19
Refined petroleum products—consumption: 896,000 bbl/day (2016
est.)
country comparison to the world: 24
Refined petroleum products—exports: 817,700 bbl/day (2015 est.)
country comparison to the world: 10
Refined petroleum products—imports: 392,000 bbl/day (2015 est.)
country comparison to the world: 23
Natural gas—production: 62.01 billion cu m (2017 est.)
country comparison to the world: 14
Natural gas—consumption: 74.48 billion cu m (2017 est.)
country comparison to the world: 12
Natural gas—exports: 7.504 billion cum (2017 est.)
country comparison to the world: 25
Natural gas—imports: 20.22 billion cu m (2017 est.)
country comparison to the world: 16
Natural gas—proved reserves: 6.091 trillion cu m (1 January
2018 est.)
country comparison to the world: 6
Carbon dioxide emissions from consumption of energy: 289.4 million
Mt (2017 est.)
country comparison to the world: 24
Electricity access: electrification—total population: 100%
(2016) Electricity—production: 318.2 billion kWh (2016 est.)
country comparison to the world: 12
Electricity—consumption: 309.2 billion kWh (2016 est.)
country comparison to the world: 11
Electricity—exports: 2.153 billion kWh (2016 est.)
country comparison to the world: 45
Electricity—imports: 19.7 billion kWh (2016 est.)
country comparison to the world: 12
Electricity—installed generating capacity: 97.06 million kW (2016
est.)
country comparison to the world: 13
Electricity—from fossil fuels: 50% of total installed capacity
(2016 est.)
country comparison to the world: 152
Electricity—from nuclear fuels: 9% of total installed capacity
(2017 est.)
country comparison to the world: 17
Electricity—from hydroelectric plants: 2% of total installed
Capacity (2017 est.)
country comparison to the world: 143
Electricity—from other renewable sources: 39% of total installed
capacity (2017 est.)
country comparison to the world: 7
Crude oil—production: 1 million bbl/day (2018 est.)
country comparison to the world: 20
Crude oil—exports: 710,600 bbl/day (2017 est.)
country comparison to the world: 20
Crude oil—imports: 907,100 bbl/day (2017 est.)
country comparison to the world: 11
Crude oil—proved reserves: 2.069 billion bbl (1 January 2018
est.)
country comparison to the world: 33
Refined petroleum products—production: 1.29 million bbl/day
(2017 est.)
country comparison to the world: 16
Refined petroleum products—consumption: 1.584 million bbl/day
(2017 est.)
country comparison to the world: 15
Refined petroleum products—exports: 613,800 bbl/day (2017 est.)
country comparison to the world: 14
Refined petroleum products—imports: 907,500 bbl/day (2017 est.)
country comparison to the world: 7
Natural gas—production: 42.11 billion cu m (2017 est.)
country comparison to the world: 19
Natural gas—consumption: 79.17 billion cu m (2017 est.)
country comparison to the world: 10
Natural gas—exports: 11.27 billion cu m (2017 est.)
country comparison to the world: 19
Natural gas—imports: 47 billion cu m (2017 est.)
country comparison to the world: 11
Natural gas—proved reserves: 176 billion cu m (1 January 2018
est.)
country comparison to the world: 46
Carbon dioxide emissions from consumption of energy: 424 million
Mt (2017 est.)
country comparison to the world: 16','a80fc0553d5dc2cde7fa2a7d1e41dd0b5d0d90a2499c693aab4a1eba905b91a6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3991908dc910d1edd9646cb88488ed6cbf7d8b95d5bbe3a9f5ca289a29e32641',2021,'SB','Solomon Islands','energy',1023,'Electricity access: electrification—total population: 57.8%
(2016) electrification—urban areas: 91.4% (2016)
electrification—rural areas: 46.4% (2016)
Electricity—production: 63 million kWh (2016 est.)
country comparison to the world: 204
Electricity—consumption: 58.59 million kWh (2016 est.)
country comparison to the world: 204
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 214
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 215
Electricity—installed generating capacity: 37,000 kW (2016 est.)
country comparison to the world: 199
Electricity—from fossil fuels: 71% of total installed capacity
(2016 est.) country comparison to the world: 107
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 207
Electricity—from hydroelectric plants: 0% of total installed
capacity (2017 est.) country comparison to the world: 211
Electricity—from other renewable sources: 29% of total installed
Capacity (2017 est.) country comparison to the world: 21
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 214
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 213
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 211
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 210
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 213
Refined petroleum products—consumption: 1,100 bbl/day (2016
est.)
country comparison to the world: 205
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 215
Refined petroleum products—imports: 1,073 bbl/day (2015 est.)
country comparison to the world: 201
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 212
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 211
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 208
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 208
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 205
Carbon dioxide emissions from consumption of energy: 164,800 Mt
(2017 est.) country comparison to the world: 203','6531768229c603cbcb35accc0b94197056142b171472b9a442405a79ea8e8aaa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1f120a62784b6e5be6217feba238463b6a54a036454fe317d5dc47928fd595e',2021,'WF','Wallis and Futuna','energy',1034,'Electricity access: electrification—total population: 100%
(2016) note: data for West Bank and Gaza Strip combined
Electricity—production: 1.093 billion kWh (2016 est.)
country comparison to the world: 148
Electricity—consumption: 6.489 billion kWh (2016 est.)
country comparison to the world: 110
Electricity—exports: 0 kWh (2016)
country comparison to the world: 217
Electricity—imports: 5.473 billion kWh (2016 est.)
country comparison to the world: 36
Electricity—installed generating capacity: 170,000 kW (2016 est.)
note: includes Gaza Strip
country comparison to the world: 170
Electricity—from fossil fuels: 78% of total installed capacity
(2016 est.)
country comparison to the world: 91
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 211
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 213
Electricity—from other renewable sources: 22% of total installed
capacity (2017 est.) country comparison to the world: 34
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 217
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 215
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 215
Crude oil—proved reserves: 0 bbl (1 January 2018)
country comparison to the world: 212
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 215
Refined petroleum products—consumption: 24,000 bbl/day (2016
est.)
country comparison to the world: 131
Refined petroleum products—exports: 19 bbl/day (2015 est.)
country comparison to the world: 123
Refined petroleum products—imports: 22,740 bbl/day (2015 est.)
country comparison to the world: 113
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 214
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 213
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 212
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 212
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 207
Carbon dioxide emissions from consumption of energy: 3.113 million
Mt (2017 est.)
country comparison to the world: 146','ad915c115f8c4c9b33c13798deb04d5870da84eae99dc5b2cd499f58e877fd84','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9872d7649fd4d1e9796f74bb967047f45a399ea11db0db0620b1166096cd1b7c',2021,'MA','Morocco','energy',1042,'Electricity—production: 0 kWh NA (2016 est.)
country comparison to the world: 220
Electricity—consumption: 0 kWh (2016 est.)
country comparison to the world: 219
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 218
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 218
Electricity—installed generating capacity: 58,000 kW (2016 est.)
country comparison to the world: 188
Electricity—from fossil fuels: 100% of total installed capacity
(2016 est.)
country comparison to the world: 22
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.)
country comparison to the world: 212
Electricity—from hydroelectric plants: O% of total installed
Capacity (2017 est.)
country comparison to the world: 214
Electricity—from other renewable sources: 0% of total installed
capacity (2017 est.) country comparison to the world: 214
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 218
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 216
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 216
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 213
Refined petroleum products—production: 0 bbl/day (2015 est.)
country comparison to the world: 216
Refined petroleum products—consumption: 1,700 bbl/day (2016
est.)
country comparison to the world: 197
Refined petroleum products—exports: 0 bbl/day (2015 est.)
country comparison to the world: 216
Refined petroleum products—imports: 1,702 bbl/day (2015 est.)
country comparison to the world: 193
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 215
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 214
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 213
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 213
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 208
Carbon dioxide emissions from consumption of energy: 268,400 Mt
(2017 est.)
country comparison to the world: 194','f3f5e38d6b2baa1f610c9b721c42f012053f2af59fa66de74e1eaec4932e0c62','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb6755fe200fa37332eeef4ec2bdb49e19ec394c419691c1140f904de4e7234f',2021,'SA','Saudi Arabia','energy',1049,'Electricity access: DOpUulation without electricity: 15 million
(2017) electrification—total population: 47% (2017)
electrification—urban areas: 72% (2017)
electrification—rural areas: 32% (2017)
Electricity—production: 4.784 billion kWh (2016 est.) country
comparison to the world: 122
Electricity—consumption: 3.681 billion kWh (2016 est.) country
comparison to the world: 130
Electricity—exports: 0 kWh (2016 est.)
country comparison to the world: 219
Electricity—imports: 0 kWh (2016 est.)
country comparison to the world: 219
Electricity—installed generating capacity: 1.819 million kW (2016
est.) country comparison to the world: 116
Electricity—from fossil fuels: 79% of total installed capacity
(2016 est.) country comparison to the world: 89
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 213
Electricity—from hydroelectric plants: O% of total installed
capacity (2017 est.) country comparison to the world: 215
Electricity—from other renewable sources: 21% of total installed
capacity (2017 est.) country comparison to the world: 37
Crude oil—production: 61,000 bbli/day (2018 est.) country
comparison to the world: 49
Crude oil—exports: 8,990 bbi/day (2015 est.) country
comparison to the world: 60
Crude oil—imports: 0 bbl/day (2015 est.)
country comparison to the world: 217
Crude oil—proved reserves: 3 billion bbl (1 January 2018 est.)
country comparison to the world: 29
Refined petroleum products—production: 20,180 bbl/day (2015
est.) country comparison to the world: 89
Refined petroleum products—consumption: 104,000 bbl/day (2016
est.) country comparison to the world: 78
Refined petroleum products—exports: 12,670 bbl/day (2015 est.)
country comparison to the world: 78
Refined petroleum products—imports: 75,940 bbl/day (2015 est.)
country comparison to the world: 65
Natural gas—production: 481.4 million cu m (2017 est.) country
comparison to the world: 72
Natural gas—consumption: 481.4 million cu m (2017 est.)
country comparison to the world: 99
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 214
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 214
Natural gas—proved reserves: 478.5 billion cu m (1 January
2018 est.) country comparison to the world: 31
Carbon dioxide emissions from consumption of energy: 13.68 million
Mt (2017 est.) country comparison to the world: 95','626bbfba519724cdcf9b3b028102bd383b52f64ee536913d02c7893405ad7903','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d42cdebe0dc144c2cd54da6a4e7da7c293403fce6b5f6b30ae6a5514b172dde9',2021,'ZW','Zimbabwe','energy',1055,'Electricity access: DOpulation without electricity: 12 million
(2017) electrification—total population: 33% (2017)
electrification—urban areas: 67% (2017)
electrification—rural areas: 6% (2017)
Electricity—production: 11.55 billion kWh (2016 est.)
country comparison to the world: 98
Electricity—consumption: 11.04 billion kWh (2016 est.)
country comparison to the world: 91
Electricity—exports: 1.176 billion kWh (2015 est.)
country comparison to the world: 56
Electricity—imports: 2.185 billion kWh (2016 est.)
country comparison to the world: 56
Electricity—installed generating capacity: 2.573 million kW (2016
est.) country comparison to the world: 107
Electricity—from fossil fuels: 5% of total installed capacity (2016
est.) country comparison to the world: 205
Electricity—from nuclear fuels: 0% of total installed capacity
(2017 est.) country comparison to the world: 214
Electricity—from hydroelectric plants: 93% of total installed
capacity (2017 est.) country comparison to the world: 9
Electricity—from other renewable sources: 2% of total installed
capacity (2017 est.) country comparison to the world: 147
Crude oil—production: 0 bbl/day (2018 est.)
country comparison to the world: 219
Crude oil—exports: 0 bbl/day (2015 est.)
country comparison to the world: 217
Crude oil—imports: 12,860 bbl/day (2015 est.)
country comparison to the world: 70
Crude oil—proved reserves: 0 bbl (1 January 2018 est.)
country comparison to the world: 214
Refined petroleum products—production: 13,120 bbl/day (2015
est.) country comparison to the world: 98
Refined petroleum products—consumption: 23,000 bbl/day (2016
est.) country comparison to the world: 133
Refined petroleum products—exports: 371 bbl/day (2015 est.)
country comparison to the world: 113
Refined petroleum products—imports: 10,150 bbl/day (2015 est.)
country comparison to the world: 149
Natural gas—production: 0 cu m (2017 est.)
country comparison to the world: 216
Natural gas—consumption: 0 cu m (2017 est.)
country comparison to the world: 215
Natural gas—exports: 0 cu m (2017 est.)
country comparison to the world: 215
Natural gas—imports: 0 cu m (2017 est.)
country comparison to the world: 215
Natural gas—proved reserves: 0 cu m (1 January 2014 est.)
country comparison to the world: 209
Carbon dioxide emissions from consumption of energy: 3.777 million
Mt (2017 est.) country comparison to the world: 140','fe765c90a9d1398f0e2b0e604ccb6e5a55af9ba4c22acceb0ea5ecf7cd4ae8bf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90c604785491b4e0edf5cbec668bd4ab01a8771275bf31008e70147d2465e2c5',2021,'GR','Greece','transnational-issues',72,'Disputes—international: NONe
Refugees and internally displaced persons: stateless
persons: 4,160 (2018)
note: 7,908 estimated refugee and migrant arrivals
(January 2015-December 2019)
Illicit drugs: active transshipment point for Southwest Asian
opiates, hashish, and cannabis transiting the Balkan route
and—to a lesser extent—cocaine from South America
destined for Western Europe; significant source country for
cannabis production; ethnic Albanian narcotrafficking
organizations active and expanding in Europe; vulnerable
to money laundering associated with regional trafficking in
narcotics, arms, contraband, and illegal aliens ALGERIA
Disputes—International: NONe
Refugees and internally displaced persons: refugees (country of
origin): 17,161 (Syria) (2018) stateless persons: 92 (2018)
note: 55,440 estimated refugee and migrant arrivals
(fanuary 2015-January 2020); Bulgaria is predominantly a
transit country and hosts approximately 992 migrants and
asylum seekers as of the end of September 2018; 2,576
migrant arrivals in 2018
Trafficking in persons: Current situation: Bulgaria is a source
and, to a lesser extent, a transit and destination country for
men, women, and children subjected to sex trafficking and
forced labor; Bulgaria is one of the main sources of human
trafficking in the EU; women and children are increasingly
sex trafficked domestically, as well as in Europe, Russia,
the Middle East, and the US; adults and children become
forced laborers in agriculture, construction, and the service
sector in Europe, Israel, and Zambia; Romanian girls are
also subjected to sex trafficking in Bulgaria tier rating: Tier 2
Watch List—Bulgaria does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
authorities prosecuted and convicted fewer traffickers and
issued suspended sentences for the majority of those
convicted; victim protection efforts declined and were
minimal relative to the number of victims identified;
funding for the state’s two NGO-operated shelters was
significantly cut, forcing them to close; specialized services
for child and adult male victims were non-existent; the
government took action to combat trafficking-related
complicity among public officials and police officers (2015)
licit drugs: major European transshipment point for
Southwest Asian heroin and, to a lesser degree, South
American cocaine for the European market; limited
producer of precursor chemicals; vulnerable to money
laundering because of corruption, organized crime; some
money laundering of drug-related proceeds through
financial institutions BURKINA FASO
Ouahigouya
Kaya
(Pédougou PUAGADOUGOU
= Fada
Koudougou ei *N''Gourma
bo- Tenkodogo
Bo
Dioulasso
Tena Kourou
e
Banfora
COTE
D''IVOIRE
Disputes—International: Kosovo and North Macedonia
completed demarcation of their boundary in September
2008
Refugees and internally displaced persons: Stateless persons: 571
(2018) note: 483,474 estimated refugee and migrant
arrivals (January 2015-December 2019); North Macedonia
is predominantly a transit country and hosts fewer than 50
refugees and asylum seekers as of October 2017; 3,132
migrant arrivals in 2018
Illicit drugs: Major transshipment point for Southwest Asian
heroin and hashish; minor transit point for South American
cocaine destined for Europe; although not a financial
center and most criminal activity is thought to be domestic,
money laundering is a problem due to a mostly cash-based
economy and weak enforcement','c0be60c596bf8aabd03a5bbbfdf0778b5a91e31a0b408ab846bb9ea0e431a24f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9d56636d75bbfba92af082a177767a394533f50582e83ebcbad35c3a45a7644',2021,'AS','American Samoa','transnational-issues',85,'Disputes—international: Tokelau included American Samoa’s
Swains Island (Olosega) in its 2006 draft independence
constitution ANDORRA
a
Canillcy
La Massana
* Encamp
*
Escaldes-','36b5526a37647fa1d3fd1c1e06f82cc6b42c41837bf0f345cb883e37a8f8761e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f94c84e416522a54501d307f332edef00f63b20a3f7baa9cc590474857b665b',2021,'ES','Spain','transnational-issues',91,'Disputes—international: NONe
-~Ceuta (
Tangier* s[étouan — adoy
Melilla (SP)
RABAT, Sonia ca,
Casablanca, *Meknés
* Mohammedia
ATLANTIC
IC {Safi
,Marrakech
Jedel
Toubkal, = (Quarzazat
Agadir','90115c398c9f036e4fbcd33d1abf9a5e0ee5eb579971869cec58fd4af0da010f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e90b604512136669a480d1a1b6e0850862d39f2774a76941cc8450dc2ec9c35',2021,'AO','Angola','transnational-issues',92,'. Morro
Lobito, “ Méco
Benguela *yuambo
Lubango Menongue
* ;
Namibe
Q 200 400 km
a
0 200 400 mi
Disputes—International: heads of the Great Lakes states and
UN pledged in 2004 to abate tribal, rebel, and militia
fighting in the region, including northeast Congo, where
the UN Organization Mission in the Democratic Republic of
the Congo (MONUC), organized in 1999, maintains over
16,500 uniformed peacekeepers; members of Uganda’s
Lord’s Resistance Army forces continue to seek refuge in
Congo’s Garamba National Park as peace talks with the
Uganda Government evolve; the location of the boundary in
the broad Congo River with the Republic of the Congo is
indefinite except in the Pool Malebo/Stanley Pool area;
Uganda and DRC dispute Rukwanzi Island in Lake Albert
and other areas on the Semliki River with hydrocarbon
potential; boundary commission continues discussions over
Congolese-administered triangle of land on the right bank
of the Lunkinda River claimed by Zambia near the DRC
village of Pweto; DRC accuses Angola of _ shifting
monuments Refugees and internally displaced persons: refugees
(country of origin): 216,018 (Rwanda), 171,234 (Central
African Republic), 88,717 (South Sudan) (refugees and
asylum seekers), 47,570 (Burundi) (2019) IDPs: 3.1 million
(fighting between government forces and rebels since mid-
1990s; conflict in Kasai region since 2016) (2018) Trafficking
in persons: Current situation: The Democratic Republic of the
Congo is a source, destination, and possibly a transit
country for men, women, and children subjected to forced
labor and sex trafficking; the majority of this trafficking is
internal, and much of it is perpetrated by armed groups
and rogue government forces outside official control in the
country’s unstable eastern provinces; Congolese adults are
subjected to forced labor, including debt bondage, in
unlicensed mines, and women may be forced into
prostitution; Congolese women and girls are subjected to
forced marriages where they are vulnerable to domestic
servitude or sex trafficking, while children are forced to
work in agriculture, mining, mineral smuggling, vending,
portering, and begging; Congolese women and children
migrate to countries in Africa, the Middle East, and Europe
where some are subjected to forced prostitution, domestic
servitude, and forced labor in agriculture and diamond
mining; indigenous and foreign armed groups, including
the Lord’s Resistance Army, abduct and forcibly recruit
Congolese adults and children to serve as laborers, porters,
domestics, combatants, and sex slaves; some elements of
the Congolese national army (FARDC) also forced adults to
carry supplies, equipment, and looted goods, but no cases
of the FARDC recruiting child soldiers were reported in
2014—a significant change tier rating: Tier 2 Watch List—
The Democratic Republic of the Congo does not fully
comply with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; the government took significant steps to hold military
and police officials complicit in human _ trafficking
accountable with convictions for sex slavery and arrests of
armed group commanders for the recruitment and use of
child soldiers; the government appears to have ceased the
recruitment of child soldiers through the implementation of
a UN-backed action plan; little effort was made to address
labor and sex trafficking crimes committed by persons
other than officials, or to identify the victims, or to provide
or refer the victims to care services; awareness of various
forms of trafficking is limited among law enforcement
personnel and training and resources are inadequate to
conduct investigations (2015) Illicit drugs: traffickers exploit
lax shipping controls to transit pseudoephedrine through
the capital; while rampant corruption and inadequate
supervision leave the banking system vulnerable to money
laundering, the lack of a well-developed financial system
limits the country’s utility as a money-laundering center
CONGO, REPUBLIC OF THE
Oshakati®
Popavalle
Tsu meb, (Popa Falls)
Zz Khorixas
a r *Otjiwarongo
oy ‘Onigstemn
en 5 WINDHOEK =
wakopmun . * Gobibis
Walvis Bay °
Rehoboth KALAHARI
TH D
Y .
Mariental
Keetmanshoop
Disputes—International: Concerns from international experts
and local populations over the Okavango Delta ecology in
Botswana and human displacement scuttled Namibian
plans to construct a hydroelectric dam on Popa Falls along
the Angola-Namibia border; the governments of South
Africa and Namibia have not signed or ratified the text of
the 1994 Surveyor’s General agreement placing the
boundary in the middle of the Orange River; Namibia has
supported, and in 2004 Zimbabwe dropped objections to,
plans between Botswana and Zambia to build a bridge over
the Zambezi River, thereby de facto recognizing a short,
but not clearly delimited, Botswana-Zambia boundary in
the river Trafficking in persons: Current situation: Namibia is a
country of origin and destination for children and, to a
lesser extent, women subjected to forced labor and sex
trafficking; victims, lured by promises of legitimate jobs,
are forced to work in urban centers and on commercial
farms; traffickers exploit Namibian children, as well as
children from Angola, Zambia, and Zimbabwe, for forced
labor in agriculture, cattle herding, domestic service,
fishing, and street vending; children are also forced into
prostitution, often catering to tourists from southern Africa
and Europe; San and Zemba children are particularly
vulnerable; foreign adults and Namibian adults and
children are reportedly subjected to forced labor in
Chinese-owned retail, construction, and fishing operations
tier rating: Tier 2 Watch List—Namibia does not fully comply
with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; Namibia was granted a waiver from an otherwise
required downgrade to Tier 3 because its government has a
written plan that, if implemented would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking; in
2015, the Child Care and Protection Bill passed,
criminalizing child trafficking; the government’s first sex
trafficking prosecution remained pending; no new
prosecutions were initiated and no trafficking offenders
have ever been convicted; accusations of forced labor at
Chinese construction and mining companies continue to go
uninvestigated; authorities failed to fully implement victim
identification and referral processes, which led to the
deportation of possible victims (2015) NAURU
phosphate
stockpile
= phosphate
facilities','ac61c03111bea005d1c247f0ff8642181391a0a4dec46e58f026ffa81c1e5dfa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b392e587e483131c1fc0895d41486dad884fa7690a13836a30e3520d348d028d',2021,'NA','Namibia','transnational-issues',101,'Disputes—international: Democratic Republic of Congo accuses
Angola of shifting monuments
Refugees and internally displaced persons: refugees (country of
origin): 6,448 (Cote d’Ivoire), 5,709 (Mauritania) (2017);
23,424 (Democratic Republic of the Congo) (refugees and
asylum seekers) (2019) Illicit drugs: used as a transshipment
point for cocaine destined for Western Europe and other
African states, particularly South Africa ANGUILLA
Blowing Point
* Village
Disputes—international: NONe
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe ANTARCTICA
Victoria
Land
Oo 400 ''800 km
'' een .
Oo 400 800 mi
Disputes—international: the Antarctic Treaty freezes, and most
states do not recognize, the land and maritime territorial
claims made by Argentina, Australia, Chile, France, New
Zealand, Norway, and the UK (some overlapping) for three-
fourths of the continent; the US and Russia reserve the
right to make claims ANTIGUA AND BARBUDA
Codrington
Barbuda
SAINT Antigua
Intemational
JOHN''S, 2
Antigua Booey Peak -
English Harbour®
Town
Disputes—international: NONe
Trafficking in persons: Current situation: Antigua and Barbuda
is a destination and transit country for adults and children
subjected to sex trafficking and forced labor; forced
prostitution has been reported in bars, taverns, and
brothels, while forced labor occurs in domestic service and
the retail sector tier rating: Tier 2 Watch List—Antigua and
Barbuda does not fully comply with the minimum standards
for the elimination of trafficking; however, it is making
significant efforts to do so; the government made no
discernible progress in convicting traffickers in 2014 but
charged two individuals in separate cases; efforts to convict
traffickers have been impeded by a 2014 ruling that found
the 2010 anti-trafficking act was unconstitutional because
jurisdiction rests with the Magistrate’s Court rather than
the High Court; no new prosecutions, convictions, or
punishments were recorded in 2014; credible sources have
raised concerns about trafficking-related complicity among
some off-duty police officers, which could hinder
investigations or victims willingness to report offenses;
prevention efforts were sustained, but progress in
protecting victims was uneven; seven victims were
assisted, which was an increase over 2013 (2015) Illicit
drugs: considered a minor transshipment point for narcotics
bound for the US and Europe; more significant as an
offshore financial center ARCTIC OCEAN
ARCTIC
OCEAN,
North
+ oie
Vv
Molloy
Deep
Kadoma
. .
Hwange ‘ai
utare,
~Gweru
_Bulawayo Masvingo','17a713d5921aaf43a71403a534a79a9e617e87b44292ab123eb750315383f0b8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('432209e245ab8bfeff3c94dd0e70028550e5188cc028578160cbdfb5085582dc',2021,'AM','Armenia','transnational-issues',123,'Disputes—international: the dispute over the break-away
Nagorno-Karabakh region and the Armenian military
occupation of surrounding lands in Azerbaijan remains the
primary focus of regional instability; residents have
evacuated the former Soviet-era small ethnic enclaves in
Armenia and Azerbaijan; Turkish authorities have
complained that blasting from quarries in Armenia might
be damaging the medieval ruins of Ani, on the other side of
the Arpacay valley; in 2009, Swiss mediators facilitated an
accord reestablishing diplomatic ties between Armenia and
Turkey, but neither side has ratified the agreement and the
rapprochement effort has faltered; local border forces
struggle to control the illegal transit of goods and people
across the porous, undemarcated Armenian, Azerbaijani,
and Georgian borders; ethnic Armenian groups in the
Javakheti region of Georgia seek greater autonomy from
the Georgian Government Refugees and internally displaced
persons: refugees (country of origin): 14,701 (Syria—ethnic
Armenians) (2018) stateless persons: 848 (2018)
Illicit drugs: illicit cultivation of small amount of cannabis for
domestic consumption; minor transit point for illicit drugs
—mostly opium and hashish—moving from Southwest Asia
to Russia and to a lesser extent the rest of Europe
ORANJESTAD
* eoanta Cruz
———_Queen Beatrix
International
Alrpor A Cera
Barcadera®. Jamanota
Sint
Sabaneta® Nicolaas
Céru
Colorado
Disputes—international: NONe
Illicit drugs: transit point for US- and Europe-bound narcotics
with some accompanying money-laundering activity;
relatively high percentage of population consumes cocaine
ASHMORE AND CARTIER ISLANDS','10e51ac4f609f5594231580e3e8db46b4516ea398c6b3307e362f8328eaa0964','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ea073acb32530850fe45ec95fb56cc8e76ff9dc884da179f6f0c930dd7d927',2021,'ID','Indonesia','transnational-issues',124,'Map Area
Disputes—International: disputes with Malaysia over territorial
waters, airspace, the price of fresh water delivered to
Singapore from Malaysia, Singapore’s extensive land
reclamation works, bridge construction, and maritime
boundaries in the Johor and Singapore Straits; in 2008, ICJ
awarded sovereignty of Pedra Branca (Pulau Batu
Puteh/Horsburgh Island) to Singapore, and Middle Rocks to
Malaysia, but did not rule on maritime’ regimes,
boundaries, or disposition of South Ledge; Indonesia and
Singapore continue to work on finalization of their 1973
maritime boundary agreement by defining unresolved areas
north of Indonesia’s Batam Island; piracy remains a
problem in the Malacca Strait Refugees and internally displaced
persons: Stateless persons: 1,303 (2018) Illicit drugs: drug
abuse limited because of aggressive law enforcement
efforts, including carrying out death sentences; as a
transportation and financial services hub, Singapore is
vulnerable, despite strict laws and enforcement, as a venue
for money laundering SINT MAARTEN
Saint Martin
Saint-Martin
—e
Koolbaai
jonal
oP HILIPSBU RG
Pulau Atauro
D 1, Baucau
Manatuto
Ermera® Viqueque,
Foho
Liquica, iL
Pante
Makasa ts Tatamaiau
* 4
Suai
Disputes—International: three stretches of land borders with
Indonesia have yet to be delimited, two of which are in the
Oecussi exclave area, and no maritime or Economic
Exclusion Zone boundaries have been established between
the countries; maritime boundaries with Indonesia remain
unresolved; Timor-Leste and Australia reached agreement
on a treaty delimiting a permanent maritime boundary in
March 2018; the treaty will enter into force once ratified by
the two countries’ parliaments Trafficking in persons: current
situation: Timor-Leste is a source and destination country
for men, women, and children subjected to forced labor and
sex trafficking; Timorese women and girls from rural areas
are lured to the capital with promises of legitimate jobs or
education prospects and are then forced into prostitution
or domestic servitude, and other women and girls may be
sent to Indonesia for domestic servitude; Timorese family
members force children into bonded domestic or
agricultural labor to repay debts; foreign migrant women
are vulnerable to sex trafficking in Timor-Leste, while men
and boys from Burma, Cambodia, and Thailand are forced
to work on fishing boats in Timorese waters under
inhumane conditions tier rating: Tier 2 Watch List - Timor-
Leste does not fully comply with the minimum standards
for the elimination of trafficking; however, it is making
significant efforts to do so; in 2014, legislation was drafted
but not finalized or implemented that outlines procedures
for screening potential trafficking victims; law enforcement
made modest progress, including one conviction for sex
trafficking, but efforts are hindered by prosecutors’ and
judges’ lack of expertise in applying anti-trafficking laws
effectively; the government rescued two child victims with
support from an NGO but did not provide protective
services (2015) Illicit drugs: NA','c45605550fe9a729911e8cac8c849cb52ce3a881d528b84fd3f0ba53a89a3dc4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ffe5fcb6f6e67d0612be3ca4c1c230e74e7caefd7d95929f074bc052c080324',2021,'AU','Australia','transnational-issues',125,'0 400 800 km
eae
400 800 mi
Ashmore Reef
East Islet
West ‘
Islet pee
2 reef
Cartier »''©°
Island
Disputes—international: Australia has closed parts of the
Ashmore and Cartier reserve to Indonesian traditional
fishing; Indonesian groups challenge Australia’s claim to
Ashmore Reef ATLANTIC OCEAN
Deep
nga h
ard Pa
=e
+ a a
Canai
Canal
NORTH ¢ \\ Ay;
Milwaukee ATLANTIC ‘Strait of Suez.
OCEAN § Siratar
SOUTH
ATLANTIC
OCEAN
Islet
Bird thet
Cato Island—
Disputes—International: NONe
Disputes—International: Matthew and Hunter Islands east of
New Caledonia claimed by France and Vanuatu NEW
ZEALAND
THREE KINGS
(SLANDS
Whangarei } North
0.
Auckland, Island
Hamilton, Tauranga
Napier,
Palmerston
North,
-, * WELLINGTON
South
Island ;
A eChristchurch
Aoraki-
Mount Cook
Dunedin,
° Invercargill
Stewart BOUNTY
Istand ISLANDS
SNARES
ISLANDS
ANTIPODES
ISLAND
GROUP
AUCKLAND
ISLANDS
9 100 200km
—_——SSESE
0 100 200 mi
Campbell
tsiand
Disputes—International: aSserts a territorial claim in Antarctica
(Ross Dependency)
Illicit drugs: Significant consumer of amphetamines
Disputes—International: NONe','da99e6fc6b6e65a8138ce3bab1fed6f096c8bdd65125f8d2189d4beba1703400','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d3e7bdf2fbca71c36ce97d0f4cb48d6e062bce8cbb711bf75c725dca6aadf9c',2021,'NF','Norfolk Island','transnational-issues',142,'Disputes—international: NONe
Refugees and internally displaced persons: refugees (country of
origin): 49,179 (Syria), 33,103 (Afghanistan), 11,301
(Russia), 8,295 (Iraq), 5,772 (Iran) (2018) stateless
persons: 1,062 (2018)
Illicit drugs: transshipment point for Southwest Asian heroin
and South American cocaine destined for Western Europe;
increasing consumption of European-produced synthetic
drugs AZERBAIJAN
ee o .
Pr) ne Xagmaz
Saki i
Ganca sMingacevir
.
« *Yeviax
Naftalan’ 4
NAGORNO- ~~,
kankandi
Ewe KARABAKH
“ Naxcivan
«(Nakhichevan)
+
Naxgivan ,Lankaran
(Nakhichevan) Astara
. e
0 50 100 km
pt
) 5 100 mi
Disputes—International: disagrees with the US on _ the
alignment of the northern axis of a potential maritime
boundary Illicit drugs: transshipment point for cocaine and
marijuana bound for US and Europe; offshore financial
center BAHRAIN
Al Muharrag sy), Bahrain, ss
MANAMAg #9
Madinat 4Mina"Salman
Se Isa, :
Ar Rite, estan
4
oe Madinat
Na''sin Hamad
ry
Jabal ad
Dukhan
Durrat
al Bahrain
° under
Cascade
. Burnt Pine
*KINGSTON
Nepean
Philip Island','5d5f50e5788287b86d669a6f5cd7b2dc0e378dfbac8e499392b1a0004ec43788','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e0cc2e339a5145250f039e3f22eb63184a11ad15f56a03a0d5599bc1fbb2dc',2021,'IN','India','transnational-issues',149,'Mymensingh
i Sylhet
p<
Comilla
INDIA Nardyanganj
vessore
Khulga Barisal
Mongla
Disputes—International: Bangladesh referred its maritime
boundary claims with Burma and India to the International
Tribunal on the Law of the Sea; Indian Prime Minister
Singh’s September 2011 visit to Bangladesh resulted in the
signing of a Protocol to the 1974 Land Boundary
Agreement between India and Bangladesh, which had
called for the settlement of longstanding boundary disputes
over undemarcated areas and the exchange of territorial
enclaves, but which had never been implemented;
Bangladesh struggles to accommodate 912,000 Rohingya,
Burmese Muslim minority from Rakhine State, living as
refugees in Cox’s Bazar; Burmese border authorities are
constructing a 200 km (124 mi) wire fence designed to
deter illegal cross-border transit and tensions from the
military build-up along border Refugees and internally displaced
persons: refugees (country of origin): 914,998 (Burma)
(2019) (includes an estimated 744,400 Rohingya refugees
who have fled conflict since 25 August 2017) IDPs: 426,000
(conflict, development, human rights violations, religious
persecution, natural disasters) (2018) Illicit drugs: transit
country for illegal drugs produced in neighboring countries','95827e05f267a0b65143c7bbd87e166e5f596ce289e1b512304650024a410343','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5918a8c863204a79860c24bbf3cf3f8443e277a1bc960015a215a281def071b7',2021,'BB','Barbados','transnational-issues',157,'speightstown
Mount
Hillaby,
Bathsheba
A «
*Holetown
PRIDGETOWN The Crane,
Gr y
rantiey Adams
Disputes—International: Barbados and Trinidad and Tobago
abide by the April 2006 Permanent Court of Arbitration
decision delimiting a maritime boundary and _ limiting
catches of flying fish in Trinidad and Tobago’s exclusive
economic zone; joins other Caribbean states to counter
Venezuela’s claim that Aves Island sustains human
habitation, a criterion under the UN Convention on the Law
of the Sea, which permits Venezuela to extend its Economic
Exclusion Zone/continental shelf over a large portion of the
eastern Caribbean Sea Illicit drugs: one of many Caribbean
transshipment points for narcotics bound for Europe and
the US; offshore financial center BELARUS
Polatsk,
Vitsyebsk®
Orsha,
Hara Mahilyow.
4 *MINSK t
® Babruysk,
Baranavichy
Pinsk
9 s« wom UKRAINE
60 100 mi
t)
Disputes—International: boundary demarcated with Latvia and
Lithuania; as a member state that forms part of the EU’s
external border, Poland has implemented strict Schengen
border rules to restrict illegal immigration and trade along
its border with Belarus Refugees and internally displaced persons:
stateless persons: 6,025 (2018) Trafficking in persons: Current
situation: Belarus is a source, transit, and destination
country for women, men, and children subjected to sex
trafficking and forced labor; more victims are exploited
within Belarus than abroad; Belarusians exploited abroad
are primarily trafficked to Germany, Poland, Russian, and
Turkey but also other European countries, the Middle East,
Japan, Kazakhstan, and Mexico; Moldovans, Russians,
Ukrainians, and Vietnamese are exploited in Belarus; state-
sponsored forced labor is a continuing problem; students
are forced to do farm labor without pay and military
conscripts are forced to perform unpaid non-military work;
the government has retained a decree forbidding workers
in state-owned wood processing factories from leaving their
jobs without their employers’ permission tier rating: Tier 3—
Belarus does not fully comply with the minimum standards
for the elimination of trafficking and was placed on Tier 3
after being on the Tier 2 Watch List for two consecutive
years without making progress; government efforts to
repeal state-sponsored forced labor policies and domestic
trafficking were inadequate; no trafficking offenders were
convicted in 2014, and the number of investigations
progressively declined from 2005-14; efforts to protect
trafficking victims remain _ insufficient, with no
identification and referral mechanism in place; care
facilities were not trafficking-specific and were poorly
equipped, leading most victims to seek assistance from
private shelters (2015) Illicit drugs: limited cultivation of
opium poppy and cannabis, mostly for the domestic market;
transshipment point for illicit drugs to and via Russia, and
to the Baltics and Western Europe; a small and lightly
regulated financial center; anti-money-laundering
legislation does not meet international standards and was
weakened further when know-your-customer requirements
were curtailed in 2008; few investigations or prosecutions
of money-laundering activities','69d3666265231345e5280fb541e2aa2826f818eed0bf92c36025f464f49ad7e0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c45ce336bb93948bba267b75502c2aac40df19e90e7d2ab2bfc56e4793bf381',2021,'NL','Netherlands','transnational-issues',166,'“Mechelen
Aalst yw “Leuven
BRUSSELS
Mons i
« Charleroi Karur
WAKLONIA
es, : y
» *Bastogne','83a7d7342a8d2d2e1158e9adf7d25efffdb5bb9d30392ca1a9657501e9a3947d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('681b0917a98417c4355d378b1324f13fba1b1938d0ee40ae1511d518b3c33940',2021,'FR','France','transnational-issues',167,'40 mi
Disputes—International: NONe
Refugees and internally displaced persons: refugees (country of
origin): 9,080 (Syria) (2018) stateless persons: 7,695 (2018)
Illicit drugs: growing producer of synthetic drugs and
cannabis; transit point for US-bound ecstasy; source of
precursor chemicals for South American cocaine
processors; transshipment point for cocaine, heroin,
hashish, and marijuana entering Western Europe; despite a
strengthening of legislation, the country remains
vulnerable to money laundering related to narcotics,
automobiles, alcohol, and tobacco; significant domestic
consumption of ecstasy BELIZE
forange) 7
a *San Pedro
Bélize _-TURNEFFE
ISLANDS
iy
Lsokiut, . ,BELMOPAN, (|
*San Ignacio
Dangriga,
Lighthouse
Reet
Victoria Peak »
Big
Creek :
y *
Doyle''s Delight»
ae
La
Condamine
Gil6n_ Santander
n . F
ill
_Ledn Bilbao PYRE AND
NEE S$
Zaragoza
“aod: ooo
atest: a
Tarragonae
Castellén
de la Plana
Valencia J
2
PUNE Cadiz _»Mélaga
Algeciras, Gibraltar (uk
* Ceuta (sp. ALGERIA
ila (S&)
S_nISLAS CHAFARINAS (SP)
9 100 200km
200 mi
Disputes—International: in 2002, Gibraltar residents voted
overwhelmingly by referendum to reject any “shared
sovereignty” arrangement; the Government of Gibraltar
insists on equal participation in talks between the UK and
Spain; Spain disapproves of UK plans to grant Gibraltar
greater autonomy; after voters in the UK chose to leave the
EU in a June 2016 referendum, Spain again proposed
Shared sovereignty of Gibraltar; UK officials rejected
Spain’s joint sovereignty proposal; Morocco protests
Spain’s control over the coastal enclaves of Ceuta, Melilla,
and the islands of Penon de Velez de la Gomera, Penon de
Alhucemas, and Islas Chafarinas, and surrounding waters;
both countries claim Isla Perejil (Leila Island); Morocco
serves as the primary launching site of illegal migration
into Spain from North Africa; Portugal does not recognize
Spanish sovereignty over the territory of Olivenza based on
a difference of interpretation of the 1815 Congress of
Vienna and the 1801 Treaty of Badajoz Refugees and internally
displaced persons: refugees (country of origin): 13,765 (Syria),
10,555 (Ukraine) (2018) note—estimate represents asylum
applicants since the beginning of the Ukraine crisis in 2014
to November 2018; 58,597 (Venezuela) (economic and
political crisis; includes Venezuelans who have claimed
asylum or have received alternative legal stay), 6,873
(Morocco) (2019) stateless persons: 2,455 (2018)
note: 159,114 estimated refugee and migrant arrivals
(Ianuary 2015-January 2020); 65,325 migrant arrivals in
2018
Illicit drugs: despite rigorous law enforcement efforts, North
African, Latin American, Galician, and other European
traffickers take advantage of Spain’s long coastline to land
large shipments of cocaine and hashish for distribution to
the European market; consumer for Latin American
cocaine and North African hashish; destination and minor
transshipment point for Southwest Asian heroin; money-
laundering site for Colombian narcotics trafficking
organizations and organized crime SPRATLY ISLANDS
Disputes—International: all of the Spratly Islands are claimed
by China (including Taiwan) and Vietnam; parts of them are
claimed by Brunei, Malaysia and the Philippines; despite no
public territorial claim to Louisa Reef, Brunei implicitly lays
claim by including it within the natural prolongation of its
continental shelf and basis for a seabed median with
Vietnam; claimants in November 2002 signed the
“Declaration on the Conduct of Parties in the South China
7
Sea,” which has eased tensions but falls short of a legally
binding “code of conduct”; in March 2005, the national oil
companies of China, the Philippines, and Vietnam signed a
joint accord to conduct marine seismic activities in the
Spratly Islands','565b0271e47a57a876427ca10e63afd1824edea84235a3eab5f1f60e2bde9a27','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9c4523806ea73451995de4669eb8da62475d864ad445b1771a5879d6514c123',2021,'HN','Honduras','transnational-issues',185,'Disputes—International: Guatemala persists in its territorial
claim to approximately half of Belize, but agrees to the Line
of Adjacency to keep Guatemalan squatters out of Belize’s
forested interior; both countries agreed in April 2012 to
hold simultaneous referenda, scheduled for 6 October
2013, to decide whether to refer the dispute to the ICJ for
binding resolution, but this vote was _ suspended
indefinitely; Belize and Mexico are working to solve minor
border demarcation discrepancies arising from
inaccuracies in the 1898 border treaty Trafficking in persons:
current situation: Belize is a source, destination, and
transit country for men, women, and children subjected to
forced labor and sex trafficking; the coerced prostitution of
women and children by family members has not led to
arrests; child sex tourism, involving primarily US citizens,
is on the rise; sex trafficking and forced labor of Belizean
and foreign women and LGBT individuals occurs in bars,
nightclubs, brothels, and domestic service; workers from
Central America, Mexico, and Asia may fall victim to forced
labor in restaurants, shops, agriculture, and fishing tier
rating: Tier 3—Belize does not comply fully with the
minimum standards for the elimination of human
trafficking and is not making significant efforts to do so;
authorities did not initiate any new _ trafficking
investigations of prosecutions, and cases from previous
years remain pending; law enforcement efforts to use
informal means to identify and refer victims were
ineffective and draft procedures for referring victims to
services are still not finalized; trafficking victims were
more commonly arrested, detained, or deported based on
immigration violations than provided with assistance; the
government did not make progress in implementing the
2012-14 anti-trafficking national strategic plan (2015) tlicit
drugs: Major transshipment point for cocaine; small-scale
illicit producer of cannabis, primarily for local
consumption; offshore sector money-laundering activity
related to narcotics trafficking and other crimes BENIN
~
‘
BURKINA q
FASO Malanville,
,Natitingou
~Djougou
Mont Sokbaro
Bohicon ,Cové
.
Abomey
Lokossa PORTO?
" NOVO','ca5d059b46aa2e2b7ac4b91f152646769d0634ce3f07c3157ad4065d50ea384c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28e149114b3ce3b4d22773f830c6b64d33ab01a7bbe4bc37317f23f0fa40ef4a',2021,'ET','Ethiopia','transnational-issues',191,'Disputes—International: talks continue between Benin and
Togo on funding the Adjrala hydroelectric dam on the Mona
River; Benin retains a border dispute with Burkina Faso
near the town of Koualou; location of Benin-Niger-Nigeria
tripoint is unresolved Illicit drugs: transshipment point used
by traffickers for cocaine destined for Western Europe;
vulnerable to money laundering due to poorly enforced
financial regulations BERMUDA
Dockyard,
Somerset Spanish
Point Town Hiv
sland
.somerset if HAMILTON
Main Island
Disputes—International: in 2001, Benin claimed Togo moved
boundary monuments—joint commission continues to
resurvey the boundary; talks continue between Benin and
Togo on funding the Adjrala hydroelectric dam on the Mona
River Refugees and internally displaced persons: refugees
(country of origin): 9,768 (Ghana) (2019) Illicit drugs: transit
hub for Nigerian heroin and cocaine traffickers; money
laundering not a significant problem TOKELAU
Nukunonu
Fakaofo
Disputes—International: Tokelau included American Samoa’s
Swains Island (Olosega) in its 2006 draft independence
constitution TONGA
Nivafo’ou
fahi
Nivatoputapu
Vava’u
Grou
Pp Vava''u
*Neiafu
Kao Island
~
—Pangai
Ha’apai Group
NUKU‘ALOFA
®
Tongatapu
Group Minerva Reef not shown
Disputes—International: Maritime boundary dispute with Fiji','31ab08dcfca54c87fc4e5812db9c9441302c9f208e7d6271ea501c334fbf37f7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2877f742a777244bef9cc0cf34f78dda77d7fe3adfe3b545d971ca7ac2a1fae',2021,'BT','Bhutan','transnational-issues',200,'Disputes—International: lacking any treaty describing the
boundary, Bhutan and China continue negotiations to
establish a common boundary alignment to _ resolve
territorial disputes arising from substantial cartographic
discrepancies, the most contentious of which lie in
Bhutan’s west along China’s Chumbi salient
BOLIVIA','fb2653b24335ddb469d98b720a4a2facc038ec174e6539abffbec8bb57f0f5e8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029e49dd979d6b8388a0a09aae086cb55d28a286a629294a13a443a697644288',2021,'BR','Brazil','transnational-issues',201,'’ ss Cochabamba
~ Oruro
2 e
Disputes—International: | uncontested boundary dispute
between Brazil and Uruguay over Braziliera/Brasiliera
Island in the Quarai/Cuareim River leaves the tripoint with
Argentina in question; smuggling of firearms and narcotics
continues to be an issue along the Uruguay-Brazil border;
Colombian-organized illegal narcotics and paramilitary
activities penetrate Brazil’s border region with Venezuela
Refugees and internally displaced persons: refugees (country of
origin): 224,102 (Venezuela) (economic and political crisis;
includes Venezuelans who have claimed asylum or have
received alternative legal stay) (2019) Illicit drugs: second-
largest consumer of cocaine in the world; illicit producer of
cannabis; trace amounts of coca cultivation in the Amazon
region, used for domestic consumption; government has a
large-scale eradication program to control cannabis;
important transshipment country for Bolivian, Colombian,
and Peruvian cocaine headed for Europe; also used by
traffickers as a way station for narcotics air transshipments
between Peru and Colombia; upsurge in drug-related
violence and weapons smuggling; important market for
Colombian, Bolivian, and Peruvian cocaine; illicit narcotics
proceeds are often laundered through the financial system;
significant illicit financial activity in the Tri-Border Area
Disputes—International: in December 2007, ICJ allocated San
Andres, Providencia, and Santa Catalina islands to
Colombia under 1928 Treaty but did not rule on 82 degrees
W meridian as maritime boundary with Nicaragua;
managed dispute with Venezuela over maritime boundary
and Venezuelan-administered Los Monjes Islands near the
Gulf of Venezuela; Colombian-organized illegal narcotics,
guerrilla, and paramilitary activities penetrate all
neighboring borders and have caused Colombian citizens to
flee mostly into neighboring countries; Colombia,
Honduras, Nicaragua, Jamaica, and the US assert various
claims to Bajo Nuevo and Serranilla Bank Refugees and
internally displaced persons: refugees (country of origin):
647,128 (Venezuela) (economic and political crisis; includes
Venezuelans who have claimed asylum or have received
alternative legal stay) (2019) IDPs: 7,816,472 (conflict
between government and illegal armed groups and drug
traffickers since 1985; about 300,000 new IDPs each year
since 2000) (2019) stateless persons: 11 (2018)
Ilicit drugs: illicit producer of coca, opium poppy, and
cannabis; world’s leading coca cultivator with 188,000
hectares in coca cultivation in 2016, a 18% increase over
2015, producing a potential of 710 mt of pure cocaine; the
world’s largest producer of coca derivatives; supplies
cocaine to nearly all of the US market and the great
majority of other international drug markets; in 2016, the
Colombian government reported manual eradication of
17,642 hectares; Colombia suspended aerial eradication in
October 2015 making 2016 the first full year without aerial
eradication; a significant portion of narcotics proceeds are
either laundered or invested in Colombia through the black
market peso exchange; Colombia probably remains the
second largest supplier of heroin to the US market; opium
poppy cultivation was estimated to be 1,100 hectares in
2015, sufficient to potentially produce three metric tons of
pure heroin COMOROS
Grande Comore
(Ngazidja)
MORONI
aharthala
Anjouan
(Ndzuwani)
Moutsamoudou,
~Fomboni
Tsimbeo
4Domoni
Disputes—International: Claims French-administered Mayotte
and challenges France’s and Madagascar’s claims to Banc
du Geyser, a drying reef in the Mozambique Channel; in
May 2008, African Union forces assisted the Comoros
military recapture Anjouan Island from rebels who seized it
in 2001
Trafficking in persons: Current situation: Comoros is a source
country for children subjected to forced labor and,
reportedly, sex trafficking domestically, and women and
children are subjected to forced labor in Mayotte; it is
possibly a transit and destination country for Malagasy
women and girls and a transit country for East African
women and girls exploited in domestic service in the
Middle East; Comoran children are forced to labor in
domestic service, roadside and street vending, baking,
fishing, and agriculture; some Comoran students at Koranic
schools are exploited for forced agricultural or domestic
labor, sometimes being subjected to physical and sexual
abuse; Comoros may be _ particularly vulnerable to
transnational trafficking because of inadequate border
controls, government corruption, and the presence of
international criminal networks tier rating: Tier 3—Comoros
does not fully comply with the minimum standards for the
elimination of trafficking and was placed on Tier 3 after
being on the Tier 2 Watch List for two consecutive years
without making progress; Parliament passed revisions to
the penal code in 2014, including anti-trafficking provisions
and enforcement guidelines, but these amendments have
not yet been passed approved by the President and put into
effect; a new child labor law was passed in 2015
prohibiting child trafficking, but existing laws do not
criminalize the forced prostitution of adults; authorities did
not investigate, prosecute, or convict alleged trafficking
offenders, including complicit officials; the government
lacked victim identification and care referral procedures,
did not assist any victims during 2014, and provided
minimal support to NGOs offering victims psychosocial
services (2015) CONGO, DEMOCRATIC REPUBLIC OF THE
7% INSHASA «lebo
Kikwit” Kananga, pe
Disputes—International: all of the area west of the Essequibo
River is claimed by Venezuela preventing any discussion of
a maritime boundary; Guyana has expressed its intention to
join Barbados in asserting claims before UN Convention on
the Law of the Sea (UNCLOS) that Trinidad and Tobago’s
maritime boundary with Venezuela extends into their
waters; Suriname claims a triangle of land between the
New and Kutari/Koetari Rivers in a historic dispute over the
headwaters of the Courantyne Trafficking in persons: current
situation: Guyana is a source and destination country for
men, women, and children subjected to sex trafficking and
forced labor—children are particularly vulnerable; women
and girls from Guyana, Venezuela, Suriname, Brazil, and
the Dominican Republic are forced into prostitution in
Guyana’s interior mining communities and urban areas;
forced labor is reported in mining, agriculture, forestry,
domestic service, and shops; Guyanese nationals are also
trafficked to Suriname, Jamaica, and other Caribbean
countries for sexual exploitation and forced labor tier rating:
Tier 2 Watch List—Guyana does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
Guyana was granted a waiver from an otherwise required
downgrade to Tier 3 because its government has a written
plan that, if implemented would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking; the
government released its anti-trafficking action plan in June
2014 but made uneven efforts to implement it; law
enforcement was weak, investigating seven trafficking
cases, prosecuting four alleged traffickers, and convicting
one trafficker—a police officer—who was released on bail
pending appeal; in 2014, as in previous years, Guyanese
courts dismissed the majority of ongoing trafficking
prosecutions; the government referred some victims to
care services, which were provided by NGOs with little or
no government support (2015) Illicit drugs: transshipment
point for narcotics from South America—primarily
Venezuela—to Europe and the US; producer of cannabis;
rising money laundering related to drug trafficking and
human smuggling
lle de la
Tortue
* Cap-
Port-de= Haitien
Paix .
Gonaives
Saint-
»Marc
lle de la *Verrettes
Hinche
.
Gonave
Jérémie
Miragoane”
Les Cayes,
@ 50 190k _
. Durazno
Mercedes °
San Florida Cone
José i Catedral
Colonia * par)
Las ~ Rocha’
ePiedras ,Maldonado
MONTEVIDEO
Disputes—International: in 2010, the ICJ ruled in favor of
Uruguay’s operation of two paper mills on the Uruguay
River, which forms the border with Argentina; the two
countries formed a joint pollution monitoring regime;
uncontested boundary dispute between Brazil and Uruguay
over Braziliera/Brasiliera Island in the Quarai/Cuareim
River leaves the tripoint with Argentina in question;
smuggling of firearms and narcotics continues to be an
issue along the Uruguay-Brazil border Refugees and internally
displaced persons: refugees (country of origin): 13,694
(Venezuela) (economic and_ political crisis; includes
Venezuelans who have claimed asylum or have received
alternative legal stay) (2019) Illicit drugs: small-scale transit
country for drugs mainly bound for Europe, often through
sea-borne containers; law enforcement corruption; money
laundering because of strict banking secrecy laws; weak
border control along’ Brazilian frontier; increasing
consumption of cocaine base and _ synthetic drugs
Disputes—International: Southeast Asian states have enhanced
border surveillance to check the spread of Asian swine
fever; Cambodia and Laos protest Vietnamese squatters
and armed encroachments along border; Cambodia accuses
Vietnam of a wide variety of illicit cross-border activities;
progress on a joint development area with Cambodia is
hampered by an unresolved dispute over sovereignty of
offshore islands; an estimated 300,000 Vietnamese
refugees reside in China; establishment of a maritime
boundary with Cambodia is hampered by unresolved
dispute over the sovereignty of offshore islands; the
decade-long demarcation of the China-Vietnam land
boundary was completed in 2009; China occupies the
Paracel Islands also claimed by Vietnam and Taiwan;
Brunei claims a maritime boundary extending beyond as far
as a median with Vietnam, thus asserting an implicit claim
to Lousia Reef; the 2002 “Declaration on the Conduct of
Parties in the South China Sea” eased tensions but
differences between the parties negotiating the Code of
Conduct continue; Vietnam continues to expand
construction of facilities in the Spratly Islands; in March
2005, the national oil companies of China, the Philippines,
and Vietnam signed a joint accord to conduct marine
seismic activities in the Spratly Islands; Economic
Exclusion Zone negotiations with Indonesia are ongoing,
and the two countries in Fall 2011 agreed to work together
to reduce illegal fishing along their maritime boundary; in
May 2018, Russia’s RosneftVietnam unit started drilling at
a block southeast of Vietnam which is within the area
outlined by China’s nine-dash line and Beijing issued a
warning Refugees and internally displaced persons: Stateless
persons: 34,110 (2018); note—Vietnam’s stateless ethnic
Chinese Cambodian population dates to the 1970s when
thousands of Cambodians fled to Vietnam to escape the
Khmer Rouge and were no longer recognized as
Cambodian citizens; Vietnamese women who gave up their
citizenship to marry foreign men have found themselves
stateless after divorcing and returning home to Vietnam;
the government addressed this problem in 2009, and
Vietnamese women are beginning to reclaim their
citizenship Illicit drugs: minor producer of opium poppy;
probable minor transit point for Southeast Asian heroin;
government continues to face domestic
opium/heroin/methamphetamine addiction problems
despite longstanding crackdowns; enforces the death
penalty for drug trafficking VIRGIN ISLANDS
British Virgih Islands
UK)
Saint Crown
Thomas gifouatain Cruz
CHARLOTTE
AMALIE
Bay
Saint
John
Saint Croix
Christiansted,
Limetree Bay, 0 5 10km
ae ee
° & 10 mi
Disputes—International: NONe
Peale
Island
Wilkes
Island
Wake
airstrip
Disputes—International: Claimed by Marshall Islands','517f97a383226833a8991ba75419c0a1082a8c20b556136f5d1a95743c33ce95','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcf9687ef47f2ee8c002cedab894397ceac8eb334ae4e2583a3c8505b0f4cf8e',2021,'ME','Montenegro','transnational-issues',222,'Disputes—International: Serbia delimited about half of the
boundary with Bosnia and Herzegovina, but sections along
the Drina River remain in dispute Refugees and internally
displaced persons: refugees (country of origin): 5,120
(Croatia) (2018) IDPs: 99,000 (Bosnian Croats, Serbs, and
Bosniaks displaced by inter-ethnic violence, human rights
violations, and armed conflict during the 1992-95 war)
(2018) stateless persons: 90 (2018)
note: 54,403 estimated refugee and migrant arrivals
(January 2015-January 2020)
Illicit drugs: increasingly a transit point for heroin being
trafficked to Western Europe; minor transit point for
marijuana; remains highly vulnerable to money-laundering
activity given a primarily cash-based and unregulated
economy, weak law enforcement, and instances of
corruption BOTSWANA
al
9° 20 40 ken
BOSNIA AND
HERZEGOVINA
erced PODGORICA
af *
oN
Tat *Cetinje
Budva
Bar
Adriatic \\_J ALBANIA MACEDONIA','c1b36517d0a40b1aae548a9f772cf6414d47950f8c6f05d8668d37a7d2f0363a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cc568f83ae7485a203a7dba29255a811f44c849aacc3a379e13159c418f3a3b',2021,'ZW','Zimbabwe','transnational-issues',223,'Francistown?
Selebi-Phikwe,
Serowe
Mamuno x
Mahalapye,
KALAHARI
DESERT
Molepolole,
Disputes—International: in 2004, Zimbabwe dropped objections
to plans between Botswana and Zambia to build a bridge
over the Zambezi River, thereby de facto recognizing a
short, but not clearly delimited, Botswana-Zambia
boundary in the river Refugees and internally displaced persons:
refugees (country of origin): 46,314 (Democratic Republic
of the Congo) (refugees and asylum seekers), 18,179
(Angola), 6,419 (Burundi), 5,849 (Rwanda) (2019) Illicit
drugs: transshipment point for moderate amounts of
methaqualone, small amounts of heroin, and cocaine bound
for southern Africa and possibly Europe; a_ poorly
developed financial infrastructure coupled with a
government commitment to combating money laundering
make it an unattractive venue for money launderers; major
consumer of cannabis ZIMBABWE
ip','a397e90557416be9115dbb6788ce1fcafe72f881b4979cf8535cb648d398f5b1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('963a02089dd1748a2c3e7dbfe1d434711e31f7033569e90ed33c5e678513e253',2021,'ZA','South Africa','transnational-issues',224,'9 50 100km
Jomiecpeho
° 50 100 mi
Disputes—International: NONe
Trafficking in persons: Current situation: Botswana is a source,
transit, and destination country for women and children
subjected to sex trafficking and forced labor; young
Batswana serving as domestic workers, sometimes sent by
their parents, may be denied education and_ basic
necessities or experience confinement and abuse indicative
of forced labor; Batswana girls and women also are forced
into prostitution domestically; adults and children of San
ethnicity were reported to be in forced labor on farms and
at cattle posts in the country’s rural west tier rating: Tier 2
Watch List—Botswana does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; an anti-
trafficking act was passed at the beginning of 2014, but
authorities did not investigate, prosecute, or convict any
offenders or government officials complicit in trafficking or
operationalize victim identification and referral procedures
based on the new law; the government sponsored a radio
Campaign to familiarize the public with the issue of human
trafficking (2015) BOUVET ISLAND
Disputes—International: NONe
1.V:V 418
Bee Sao Luis
*,
Manaus Fortaleza.
Teresina®
Maceid,
, Salvador,
ee
BOLIVIA
Campo Belo
Grande Horizonte tubarao
Fitri
Pau
aulo *
A 4 oo .
Curitiba Sepetiba
j Santos Terminal
—“" Porto
Alegre
ARGENTINA b,
} uru. > 0 300 800km
f $ | aeeeeemeete qenmmemees]
: 0 30 600mi
Disputes—International: South Africa has placed military units
to assist police operations along the border of Lesotho,
Zimbabwe, and Mozambique to control smuggling,
poaching, and illegal migration Trafficking in persons: current
situation: Lesotho is a source, transit, and destination
country for women and children subjected to forced labor
and sex trafficking and for men subjected to forced labor;
in Lesotho and South Africa, Basotho women and children
are subjected to domestic servitude, and Basotho children
increasingly endure commercial sexual exploitation; some
Basotho men who voluntarily migrate to South Africa for
work become victims of forced labor in agriculture and
mining or are coerced into committing crimes; foreign
nationals continue to traffic fellow citizens in Lesotho tier
rating: Tier 2 Watch List—Lesotho does not fully comply
with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; in 2014, Lesotho was granted a waiver from an
otherwise required downgrade to Tier 3 because _ its
government has a written plan that, if implemented would
constitute making significant efforts to bring itself into
compliance with the minimum standards for the elimination
of trafficking; the government failed to initiate any
prosecutions against alleged traffickers and has _ not
convicted any offenders under the 2011 anti-trafficking act,
which remains unimplemented for a fifth year; authorities
did not develop formal victim identification and referral
procedures, did not establish victim care centers, as
required under the 2011 anti-trafficking act, and did not
support NGOs offering victims protective services (2015)','9e9f666fbde351d3517e7a4b1320c42dba1af0c5f6163f07baa6843ca73f5eb8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b155c59775b988e7f1159520a644ca4988e4584d7ee20f2dc78d290150cebca6',2021,'IO','British Indian Ocean Territory','transnational-issues',233,'SALOMON
ISLANDS
Nelsons
Island
EAGLE BROTHERS
ISLANDS
CHAGOS
Danger
island ARCHIPELAGO
EGMONT
ISLANDS
Disputes—International: Mauritius and Seychelles claim the
Chagos Islands; negotiations between 1971 and 1982
resulted in the establishment of a trust fund by the British
Government as compensation for the displaced islanders,
known as Chagossians, who were evicted between 1967-73;
in 2001, the former inhabitants of the archipelago were
granted UK citizenship and the right of return; in 2006 and
2007, British court rulings invalidated the immigration
policies contained in the 2004 BIOT Constitution Order that
had excluded the islanders from the archipelago; in 2008 a
House of Lords’ decision overturned lower court rulings,
once again denying the right of return to Chagossians; in
addition, the UK created the world’s largest marine
protection area around the Chagos islands prohibiting the
extraction of any natural resources therein BRITISH
VIRGIN ISLANDS
Tortola * Agen
Sage','e6a09975fe85b1938496d6ba7b5fc649522c654bcd7b89e585e955751eaacc30','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6576a061d2a179eb589a1845faadd09be62b0bb2a0ac315c8979f7ee569ebc02',2021,'PR','Puerto Rico','transnational-issues',243,'Disputes—International: NONe
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe; large offshore
financial center makes it vulnerable to money laundering
Muara
.
Kampong
Jerudong:
BANDAR SERIx
BEGAWAN
Tutong*
Kampong
Lamunin \\ Limbang
“Sukang
Borgneo
Disputes—International: per Letters of Exchange signed in
2009, Malaysia in 2010 ceded two hydrocarbon concession
blocks to Brunei in exchange for Brunei’s sultan dropping
claims to the Limbang corridor, which divides Brunei;
nonetheless, Brunei claims a maritime boundary extending
as far as a median with Vietnam, thus asserting an implicit
claim to Louisa Reef Refugees and internally displaced
persons: stateless persons: 20,863 (2018); note—thousands
of stateless persons, often ethnic Chinese, are permanent
residents and their families have lived in Brunei for
generations; obtaining citizenship is difficult and requires
individuals to pass rigorous tests on Malay culture,
customs, and language; stateless residents receive an
International Certificate of Identity, which enables them to
travel overseas; the government is considering changing
the law prohibiting non-Bruneians, including stateless
permanent residents, from owning land Illicit drugs: drug
trafficking and illegally importing controlled substances are
serious offenses in Brunei and carry a mandatory death
penalty BULGARIA
Dobrich,
Pleven
Varna,
JOUFIA Sliven
.
Stara Zagora Burgas,
Musala = £
Plovdiv
a
“Blagoevgrad
Kurdzhali,
TURKEY
Disputes—International: increasing numbers of illegal migrants
from the Dominican Republic cross the Mona Passage to
Puerto Rico each year looking for work
Madinat
ash Shamal,
>
BAHRAIN Al Khuwayr
Ras Laffan *
Industrial City
HAWAR
ISLANDS
AHRAIN Al Khawr,
Umm
Salal ‘Ali,
*Dukhan Umm Salal ®
Muhammad
. QDOHA
i Ar Rayyan *
Umm Bab
Al Wakrah
Umm Sa‘id,
SAUDI
ARABIA
The island of Haldl is not shown.','d715f3a287f665514163ed6428560476bb9f8ea076ef84d34b4e3d92bc0a5f96','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9f4eb10db85241b015d463f7d1ab757d94954c598a8cb45592efa9eb79c0839',2021,'MM','Myanmar','transnational-issues',255,'Disputes—International: over half of Burma’s population
consists of diverse ethnic groups who have substantial
numbers of kin in neighboring countries; Bangladesh
struggles to accommodate 912,000 Rohingya, Burmese
Muslim minority from Rakhine State, living as refugees in
Cox’s Bazar; Burmese border authorities are constructing a
200 km (124 mi) wire fence designed to deter illegal cross-
border transit and tensions from the military build-up along
border with Bangladesh in 2010; Bangladesh referred its
maritime boundary claims with Burma and India to the
International Tribunal on the Law of the Sea; Burmese
forces attempting to dig in to the largely autonomous Shan
State to rout local militias tied to the drug trade, prompts
local residents to periodically flee into neighboring Yunnan
Province in China; fencing along the _ India-Burma
international border at Manipur’s Moreh town is in
progress to check illegal drug trafficking and movement of
militants; over 100,000 mostly Karen refugees and asylum
seekers fleeing civil strife, political upheaval, and economic
stagnation in Burma were living in remote camps in
Thailand near the border as of May 2017
Refugees and internally displaced persons: IDPs: 401,000
(government offensives against armed ethnic minority
groups near its borders with China and Thailand, natural
disasters, forced land evictions) (2018) stateless persons:
495,939 (2018); note—Rohingya Muslims, living
predominantly in Rakhine State, are Burma’s main group of
stateless people; the Burmese Government does not
recognize the Rohingya as a “national race” and stripped
them of their citizenship under the 1982 Citizenship Law,
categorizing them as “non-nationals” or “foreign
residents”; under the Rakhine State Action Plan drafted in
October 2014, the Rohingya must demonstrate their family
has lived in Burma for at least 60 years to qualify for a
lesser naturalized citizenship and the classification of
Bengali or be put in detention camps and face deportation;
native-born but non-indigenous people, such as Indians, are
also stateless; the Burmese Government does not grant
citizenship to children born outside of the country to
Burmese parents who left the country illegally or fled
persecution, such as those born in Thailand; the number of
stateless persons has decreased dramatically since late
2017 because hundreds of thousands of Rohingya have fled
to Bangladesh since 25 August 2017 to escape violence
note: estimate does not include stateless IDPs or stateless
persons in IDP-like situations because they are included in
estimates of IDPs (2017) Trafficking in persons: current
situation: Burma is a source country for men, women, and
children trafficked for the purpose of forced labor and for
women and children subjected to sex trafficking; Burmese
adult and child labor migrants travel to East Asia, the
Middle East, South Asia, and the US, where men are forced
to work in the fishing, manufacturing, forestry, and
construction industries and women and girls are forced into
prostitution, domestic servitude, or forced labor in the
garment sector; some Burmese economic migrants and
Rohingya asylum seekers have become forced laborers on
Thai fishing boats; some military personnel and armed
ethnic groups unlawfully conscript child soldiers or coerce
adults and children into forced labor; domestically, adults
and children from ethnic areas are vulnerable to forced
labor on plantations and in mines, while children may also
be subject to forced prostitution, domestic service, and
begging tier rating: Tier 2 Watch List—Burma does not fully
comply with the minimum standards for the elimination of
trafficking, but it is making significant efforts to do so; the
government has a written plan that, if implemented, would
constitute making a significant effort toward meeting the
minimum standard for eliminating human trafficking; in
2014, law enforcement continued to investigate and
prosecute cross-border trafficking offenses but did little to
address domestic trafficking; no civilians or government
officials were prosecuted or convicted for the recruitment
of child soldiers, a serious problem that is hampered by
corruption and the influence of the military; victim referral
and protection services remained inadequate, especially for
men, and left victims vulnerable to being re-trafficked; the
government coordinated anti-trafficking programs as part
of its five-year national action plan (2015) Mlicit drugs:
world’s second largest producer of illicit opium with an
estimated poppy cultivation totaling 41,000 hectares in
2017, a decrease of 25% from the last survey in 2015; Shan
state is the source of 91% of Burma’s poppy cultivation;
lack of government will to take on major narcotrafficking
groups and lack of serious commitment against money
laundering continues to hinder the overall antidrug effort;
Burma is one of the world’s largest producers of
amphetamine-type stimulants, which are __ trafficked
throughout the region, as far afield as Australia and New
Zealand BURUNDI','a64d3cd95da5643584bb37a0d5a872a25405da0beedf833d791bd7c05898709e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c938b28b4e9fd34548f616432fb98594ffa9818b673806fd92d3e57539a086b',2021,'BI','Burundi','transnational-issues',264,'Disputes—International: Burundi and Rwanda dispute two sq
km (0.8 sq mi) of Sabanerwa, a farmed area in the Rukurazi
Valley where the Akanyaru/Kanyaru River shifted its course
southward after heavy rains in 1965; cross-border conflicts
persist among Tutsi, Hutu, other ethnic groups, associated
political rebels, armed gangs, and various government
forces in the Great Lakes region Refugees and _ internally
displaced persons: refugees (country of origin): 86,054
(Democratic Republic of the Congo) (refugees and asylum
seekers) (2019) IDPs: 103,352 (some ethnic Tutsis remain
displaced from intercommunal violence that broke out after
the 1,993 coup and fighting between government forces
and rebel groups; violence since April 2015) (2019)
stateless persons: 974 (2018)
Trafficking in persons: Current situation: Burundi is a source
country for children and possibly women subjected to
forced labor and sex trafficking; business people recruit
Burundian girls for prostitution domestically, as well as in
Rwanda, Kenya, Uganda, and the Middle East, and recruit
boys and girls for forced labor in Burundi and Tanzania;
children and young adults are coerced into forced labor in
farming, mining, informal commerce, fishing, or collecting
river stones for construction; sometimes family, friends,
and neighbors are complicit in exploiting children, at times
luring them in with offers of educational or job
opportunities tier rating: Tier 3—Burundi does not comply
fully with the minimum standards for the elimination of
human trafficking and is not making significant efforts to
do so; corruption, a lack of political will, and limited
resources continue to hamper efforts to combat human
trafficking; in 2014, the government did not inform judicial
and law enforcement officials of the enactment of an anti-
trafficking law or how to implement it and approved—but
did not fund—its national anti-trafficking action plan;
authorities again failed to identify trafficking victims or to
provide them with adequate protective services; the
government has focused on transnational child trafficking
but gave little attention to its domestic child trafficking
problem and adult trafficking victims (2015)','722f080ce53ac0136bdf79b5b0e9a11c6f6f88d044012d24e25f29f12d563349','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a269f535572f38141cc87ea20f5c97e092912e5973b1b2b694b6c5d5a0d5f86',2021,'CV','Cabo Verde','transnational-issues',265,'Santo
Antao
Mindelo
7 Santa Luzia
Sao
Vicente Me
4x 45 Sao Nicolau
20
4R,
“Avey,
ce]
SOTAVENTO
$ Sao
yh A Tarrafal , Tiago
Sao :
Filipe, aos *
Brave Fogo
Disputes—International: NONe
Refugees and internally displaced persons: stateless
persons: 115 (2018)
Illicit drugs: used as a transshipment point for Latin
American cocaine destined for Western Europe, particularly
because of Lusophone links to Brazil, Portugal, and Guinea-
Bissau; has taken steps to deter drug money laundering,
including a 2002 anti-money laundering reform that
criminalizes laundering the proceeds_ of narcotics
trafficking and other crimes and the establishment in 2008
of a Financial Intelligence Unit CAMBODIA','9829eff0c5f6976731bf86d763c6d3e29a118870fab58ade075182b20edfc1fe','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41ea8380b022b5c09c11fff32fee0949a04d79b1053a3fb006f2b99a41598ad2',2021,'TH','Thailand','transnational-issues',273,'siemréab *Staeng Tréng
Batdambang
Pouthisat, Kampong \\Krachéh
(Chhnang
¢Kampong
Cham
VIETNAM
Disputes—International: Cambodia is concerned about Laos’
extensive upstream dam _ construction; Cambodia and
Thailand dispute sections of boundary; in 2011 Thailand
and Cambodia resorted to arms in the dispute over the
location of the boundary on the precipice surmounted by
Preah Vihear Temple ruins, awarded to Cambodia by an
International Court of Justice decision in 1962 and part of a
UN World Heritage site; Cambodia accuses Vietnam of a
wide variety of illicit cross-border activities; progress on a
joint development area with Vietnam is hampered by an
unresolved dispute over sovereignty of offshore islands
Trafficking in persons: Current situation: Cambodia is a source,
transit, and destination country for men, women, and
children subjected to forced labor and sex trafficking;
Cambodian men, women, and children migrate to countries
within the region and, increasingly, the Middle East for
legitimate work but are subjected to sex trafficking,
domestic servitude, or forced labor in fishing, agriculture,
construction, and factories; Cambodian men recruited to
work on Thai-owned fishing vessels are subsequently
subjected to forced labor in international waters and are
kept at sea for years; poor Cambodian children are
vulnerable and, often with the families’ complicity, are
subject to forced labor, including domestic servitude and
forced begging, in Thailand and Vietnam; Cambodian and
ethnic Vietnamese women and girls are trafficked from
rural areas to urban centers and tourist spots for sexual
exploitation; Cambodian men are the main exploiters of
child prostitutes, but men from other Asian countries, and
the West travel to Cambodia for child sex tourism tier rating:
Tier 2 Watch List—Cambodia does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; the
government has a written plan that, if implemented, would
constitute making significant efforts to meet the minimum
standards for the elimination of trafficking; authorities
made modest progress in prosecutions and convictions of
traffickers in 2014 but did not provide comprehensive data;
endemic corruption continued to impede law enforcement
efforts, and no complicit officials were prosecuted or
convicted; the government sustained efforts to identify
victims and refer them to NGOs for care, but victim
protection remained inadequate, particularly for assisting
male victims and victims identified abroad; a new national
action plan was adopted, but guidelines for victim
identification and guidance on undercover investigation
techniques are still pending after several years (2015) Illicit
drugs: narcotics-related corruption reportedly involving
some in the government, military, and police; limited
methamphetamine production; vulnerable to money
laundering due to its cash-based economy and porous
borders CAMEROON
° 100 200km
ed
o 100 200 mi
Chiang
Mai,
a
Doiinthahon «
Lampang
Udon
eThani
,Phitsanulok
hon Kaen
Khorat
Nakhon? Nakhon Plateau
Sawan f
Ratchasima Ubon
Ratchathani','3805fa72c19dc026f0ea7c7643c225a0e079e0ff7476be62a7a0585da3787597','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18993cd2f9c74bb427b37519feba29350dac430037435e36b61fc08871410b03',2021,'NG','Nigeria','transnational-issues',278,'js tec CENTRAL
-Petoussem AFRICAN
eNkongsamba REPUBLIC
Limboh ita , Douala YAOUNDE
erminal
Q 100 200km
wr
0 100 200 mi
Disputes—International: Joint Border Commission’ with
Cameroon reviewed 2002 ICJ ruling on the entire boundary
and bilaterally resolved differences, including June 2006
Greentree Agreement that immediately cedes sovereignty
of the Bakassi Peninsula to Cameroon with a phaseout of
Nigerian control within two years while resolving patriation
issues; the ICJ ruled on an equidistance settlement of
Cameroon-Equatorial Guinea-Nigeria maritime boundary in
the Gulf of Guinea, but imprecisely defined coordinates in
the ICJ decision and a sovereignty dispute between
Equatorial Guinea and Cameroon over an island at the
mouth of the Ntem River all contribute to the delay in
implementation; only Nigeria and Cameroon have heeded
the Lake Chad Commission’s admonition to ratify the
delimitation treaty which also includes the Chad-Niger and
Niger-Nigeria boundaries; location of Benin-Niger-Nigeria
tripoint is unresolved Refugees and internally displaced persons:
refugees (country of origin): 44,524 (Cameroon) (2019)
IDPs: 2,035,232 (northeast Nigeria; Boko Haram attacks
and counterinsurgency efforts in northern Nigeria;
communal violence between Christians and Muslims in the
middle belt region, political violence; flooding; forced
evictions; cattle rustling; competition for resources) (2019)
Illicit drugs: a transit point for heroin and cocaine intended
for European, East Asian, and North American markets;
consumer of amphetamines; safe haven for Nigerian
narcotraffickers operating worldwide; major money-
laundering center; massive corruption and_ criminal
activity; Nigeria has improved some anti-money-laundering
controls, resulting in its removal from the Financial Action
Task Force’s (FATF’s) Noncooperative Countries and
Territories List in June 2006; Nigeria’s anti-money-
laundering regime continues to be monitored by FATF
Z Mutalau,
Hikutavake
Lakepa,
~Avatele','18f083bfe2752e9040c673d21c6aa427bae499618f86a488be9d6143404c79c8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c35beaf8293d0036c2cdca664c14e04143dbdd1c3cac7193407b5062140085',2021,'CM','Cameroon','transnational-issues',291,'Disputes—International: Joint Border Commission with Nigeria
reviewed 2002 ICJ ruling on the entire boundary and
bilaterally resolved differences, including June 2006
Greentree Agreement that immediately ceded sovereignty
of the Bakassi Peninsula to Cameroon with a full phase-out
of Nigerian control and patriation of residents in 2008;
Cameroon and Nigeria agreed on maritime delimitation in
March 2008; sovereignty dispute between Equatorial
Guinea and Cameroon over an island at the mouth of the
Ntem River; only Nigeria and Cameroon have heeded the
Lake Chad Commission’s admonition to ratify the
delimitation treaty, which also includes the Chad-Niger and
Niger-Nigeria boundaries Refugees and internally displaced
persons: refugees (country of origin): 292,787 (Central
African Republic), 110,627 (Nigeria) (2019) IDPs: 950,263
(2019) (includes far north, northwest, and southwest)
PF
.
7
) REP.
f
Disputes—International: the location of the boundary in the
broad Congo River with the Democratic Republic of the
Congo is undefined except in the Pool Malebo/Stanley Pool
area Refugees and internally displaced persons: refugees (country
of origin): 20,658 (Central African Republic), 20,289
(Democratic Republic of the Congo) (refugees and asylum
seekers) (2019) IDPs: 107,000 (multiple civil wars since
1992) (2018)
Trafficking in persons: Current situation: the Republic of the
Congo is a source and destination country for children,
men, and women, subjected to forced labor and sex
trafficking; most trafficking victims are from Benin, the
Democratic Republic of the Congo (DRC), and, to a lesser
extent, other neighboring countries and are subjected to
domestic servitude and market vending by West African
and Congolese nationals; adults and children, the majority
from the DRC, are also sex trafficked in Congo, mainly
Brazzaville; internal trafficking victims, often from rural
areas, are exploited as domestic servants or forced to work
in quarries, bakeries, fishing, and agriculture tier rating: Tier
2 Watch List-the Republic of the Congo does not fully
comply with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; the country drafted an action plan based on anti-
trafficking legislation, which remains pending in the
Supreme Court; the government made minimal anti-
trafficking law enforcement efforts in 2014, failing to
prosecute or convict suspected traffickers from cases
dating back to 2010; serious allegations of official
complicity continue to be reported; the government lacks a
systematic means of identifying victims and relies on NGOs
and international organizations to identify victims and
NGOs and foster families to provide care to victims; the
quality of care varied widely because the foster care system
was allegedly undermined by inadequate security and
official complicity (2015) COOK ISLANDS
Disputes—International: NONe
CORAL SEA ISLANDS
Wie islets
_/ Magdelaine Cays
—Coringa Islets
Herald Cays— Tregrosse Islets
Mackay¢','3ba232515ba0ae846710cda39396c8092a9b4ffda1c3f01b7be7b98017fde760','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb3f6917f548cd10783285918989151afddc79b498e0d7695ad37428f9666061',2021,'CA','Canada','transnational-issues',299,'Disputes—International: Managed maritime boundary disputes
with the US at Dixon Entrance, Beaufort Sea, Strait of Juan
de Fuca, and the Gulf of Maine, including the disputed
Machias Seal Island and North Rock; Canada and the
United States dispute how to divide the Beaufort Sea and
the status of the Northwest Passage but continue to work
cooperatively to survey the Arctic continental shelf; US
works closely with Canada to intensify security measures
for monitoring and controlling legal and illegal movement
of people, transport, and commodities across_ the
international border; sovereignty dispute with Denmark
over Hans Island in the Kennedy Channel between
Ellesmere Island and Greenland; commencing the
collection of technical evidence for submission to the
Commission on the Limits of the Continental Shelf in
support of claims for continental shelf beyond 200 nm from
its declared baselines in the Arctic, as stipulated in Article
76, paragraph 8, of the UN Convention on the Law of the
Sea Refugees and internally displaced persons: refugees (country
of origin): 7,356 (Colombia), 7,192 (China), 7,141 (Haiti),
9,483 (Nigeria), 5,607 (Pakistan) (2018); 9,978 (Venezuela)
(2019) stateless persons: 3,790 (2018)
Ilicit drugs: illicit producer of cannabis for the domestic drug
market and export to US; use of hydroponics technology
permits growers to plant large quantities of high-quality
Marijuana indoors; increasing ecstasy production, some of
which is destined for the US; vulnerable to narcotics money
laundering because of its mature financial services sector','9ecfb01c444c98aa16f36eee84a6c9ed59acf7f9547ae31a1b2d65fffcdaebbd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e98d551f8fbcfdcf62a53a6c1a693e263a1e548e32fcbeb906f4f598359a51',2021,'CG','Congo','transnational-issues',316,'Disputes—International: periodic skirmishes persist over water
and grazing rights among related pastoral populations
along the border with southern Sudan Refugees and
internally displaced persons: IDPs: 600,136 (clashes
between army and rebel groups since 2005; tensions
between ethnic groups) (2019) Trafficking in persons: current
situation: Central African Republic (CAR) is a source,
transit, and destination country for children subjected to
forced labor and sex trafficking, women subjected to forced
prostitution, and adults subjected to forced labor; most
victims appear to be CAR citizens exploited within the
country, with a smaller number transported back and forth
between the CAR and nearby countries; armed groups
operating in the CAR, including those aligned with the
former SELEKA Government and the Lord’s Resistance
Army, continue to recruit and re-recruit children for
military activities and labor; children are also subject to
domestic servitude, commercial sexual exploitation, and
forced labor in agriculture, mines, shops, and _ street
vending; women and girls are subject to domestic
servitude, sexual slavery, commercial sexual exploitation,
and forced marriage tier rating: Tier 3—the Central African
Republic does not fully comply with the minimum standards
for the elimination of trafficking and is not making
significant efforts to do so; the government conducted a
limited number of investigations and prosecutions of cases
of suspected human trafficking in 2014 but did not identify,
provide protection to, or refer to care providers any
trafficking victims; the government did not directly provide
reintegration programs for demobilized child soldiers,
leaving victims vulnerable to further exploitation or
retrafficking by armed groups, including those affiliated
with the government; in 2014, an NGO and the government
began drafting a national action plan against trafficking but
no efforts were reported to establish a policy against child
soldiering or to raise awareness about existing laws
prohibiting the use of children in the armed forces (2015)
yey
e
Voican Ruhengeri .Syumba
Karisimbi
SGisenyi
KIGALI
eKibuye ‘
Gitarama
Butare®
BURUNDI , 2 win
0 20
Disputes—International: NONe','9226e63cec91d90442a163c109252abfd814f38b3a576c201aa985875e598bc0','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c57c1a5ee69df467ef654d1902611a659c09fce83fea41b59e6a45d8ed526818',2021,'TD','Chad','transnational-issues',317,'CENTRAL AFRICAN
REPUBLIC
DEM.REP. OF THE CONGO
Disputes—International: since 2003, ad hoc armed militia
groups and the Sudanese military have driven hundreds of
thousands of Darfur residents into Chad; Chad wishes to be
a helpful mediator in resolving the Darfur conflict, and in
2010 established a joint border monitoring force with
Sudan, which has helped to reduce cross-border banditry
and violence; only Nigeria and Cameroon have heeded the
Lake Chad Commission’s admonition to ratify the
delimitation treaty, which also includes the Chad-Niger and
Niger-Nigeria boundaries Refugees and internally displaced
persons: refugees (country of origin): 330,725 (Sudan),
94,101 (Central African Republic), 12,158 (Nigeria) (2019)
IDPs: 170,278 (majority are in the east) (2019)','6bcab8eafd794ba113247b7ce75e6e2770918bfe16b47d775879b193ffe610a9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d53c07f769af7b8dfbae33dff7273e8adb59596dce79918331194f60eb87cacd',2021,'AQ','Antarctica','transnational-issues',329,'Disputes—International: Chile and Peru rebuff Bolivia’s
reactivated claim to restore the Atacama corridor, ceded to
Chile in 1884, but Chile has offered instead unrestricted
but not sovereign maritime access through Chile to
Bolivian natural gas; Chile rejects Peru’s_ unilateral
legislation to change its latitudinal maritime boundary with
Chile to an equidistance line with a southwestern axis
favoring Peru; in October 2007, Peru took its maritime
complaint with Chile to the ICJ; territorial claim in
Antarctica (Chilean Antarctic Territory) partially overlaps
Argentine and _ British claims; the joint boundary
commission, established by Chile and Argentina in 2001,
has yet to map and demarcate the delimited boundary in
the inhospitable Andean Southern Ice Field (Campo de
Hielo Sur) Refugees and internally displaced persons: refugees
(country of origin): 330,186 (Venezuela) (economic and
political crisis; includes Venezuelans who have claimed
asylum or have received alternative legal stay) (2019) Itlicit
drugs: transshipment country for cocaine destined for
Europe and the region; some money laundering activity,
especially through the Iquique Free Trade Zone; imported
precursors passed on to. Bolivia; domestic cocaine
consumption is rising, making Chile a significant consumer
of cocaine CHINA','c19b4b8f0b0fe2746bd03c8e4d0844886f940f193e236510c2058727e352fb7d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('818141a2929ad3e9312dbb4cd15040fec6965e723808d71aba60079cb7167e0c',2021,'CN','China','transnational-issues',341,'Disputes—International: China and India continue their
security and foreign policy dialogue started in 2005 related
to a number of boundary disputes across the 2,000 mile
shared border; India does not recognize Pakistan’s 1964
ceding to China of the Aksai Chin, a territory designated as
part of the princely state of Kashmir by the British Survey
of India in 1865; China claims most of the Indian state
Arunachal Pradesh to the base of the Himalayas, but The
US recognizes the state of Arunachal Pradesh as Indian
territory; Bhutan and China continue negotiations to
establish a common boundary alignment to _ resolve
territorial disputes arising from substantial cartographic
discrepancies, the most contentious of which lie in
Bhutan’s west along China’s Chumbi salient; Chinese maps
show an international boundary symbol off the coasts of the
littoral states of the South China Sea, where China has
interrupted Vietnamese hydrocarbon exploration; China
asserts sovereignty over Scarborough Reef along with the
Philippines and Taiwan, and over the Spratly Islands
together with Malaysia, the Philippines, Taiwan, Vietnam,
and Brunei; the 2002 Declaration on the Conduct of Parties
in the South China Sea eased tensions in the Spratlys, and
in 2017 China and ASEAN began confidential negotiations
for an updated Code of Conduct for the South China Sea
designed not to settle territorial disputes but establish
rules and norms in the region; this still is not the legally
binding code of conduct sought by some parties; Vietnam
and China continue to expand construction of facilities in
the Spratlys and in early 2018 China deployed advanced
military systems to disputed Spratly outposts; China
occupies some of the Paracel Islands also claimed by
Vietnam and Taiwan; the Japanese-administered Senkaku
Islands are also claimed by China and Taiwan; certain
islands in the Yalu and Tumen Rivers are in dispute with
North Korea; North Korea and China seek to stem illegal
migration to China by North Koreans, fleeing privation and
oppression; China and Russia have demarcated the once
disputed islands at the Amur and Ussuri confluence and in
the Argun River in accordance with their 2004 Agreement;
China and Tajikistan have begun demarcating the revised
boundary agreed to in the delimitation of 2002; the decade-
long demarcation of the China-Vietnam land boundary was
completed in 2009; citing environmental, cultural, and
social concerns, China has reconsidered construction of 13
dams on the Salween River, but energy-starved Burma,
with backing from Thailand, continues to consider building
five hydro-electric dams downstream despite regional and
international protests Refugees and internally displaced persons:
refugees (country of origin): 321,502 (Vietnam),
undetermined (North Korea) (2018) IDPs: undetermined
(2014)
Trafficking in persons: Current situation: China is a source,
transit, and destination country for men, women, and
children subjected to sex trafficking and forced labor;
Chinese adults and children are forced into prostitution and
various forms of forced labor, including begging and
working in brick kilns, coal mines, and factories; women
and children are recruited from rural areas and taken to
urban centers for sexual exploitation, often lured by
criminal syndicates or gangs with fraudulent job offers;
state-sponsored forced labor, where detainees work for up
to four years often with no remuneration, continues to be a
serious concern; Chinese men, women, and children also
may be subjected to conditions of sex trafficking and forced
labor worldwide, particularly in overseas Chinese
communities; women and children are trafficked to China
from neighboring countries, as well as Africa and the
Americas, for forced labor and prostitution tier rating: Tier 2
Watch List—China does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; official data for 2014
states that 194 alleged traffickers were arrested and at
least 35 were convicted, but the government’s conflation of
human trafficking with other crimes makes it difficult to
assess law enforcement efforts to investigate and to
prosecute trafficking offenses according to international
law; despite reports of complicity, no government officials
were investigated, prosecuted, or convicted for their roles
in trafficking offenses; authorities did not adequately
protect victims and did not provide the data needed to
ascertain the number of victims identified or assisted or the
services provided; the National People’s Congress ratified a
decision to abolish “reform through labor” in 2013, but
some continued to operate as_ state-sponsored drug
detention or “custody and education” centers that force
inmates to perform manual labor; some North Korean
refugees continued to be forcibly repatriated as illegal
economic migrants, despite reports that some were
trafficking victims (2015) Illicit drugs: major transshipment
point for heroin produced in the Golden Triangle region of
Southeast Asia; growing domestic consumption of synthetic
drugs, and heroin from Southeast and Southwest Asia;
source country for methamphetamine and heroin chemical
precursors, despite new regulations on its large chemical
industry; more people believed to be convicted and
executed for drug offences than anywhere else in the
world, according to NGOs CHRISTMAS ISLAND
THE SETTLEMENT |
airfield |
Disputes—International: NOnNe
CLIPPERTON ISLAND
Disputes—International: Hong Kong plans to reduce its 2,800-
hectare Frontier Closed Area (FCA) to 400 hectares by
2015; the FCA was established in 1951 as a buffer zone
between Hong Kong and mainland China to prevent illegal
migration from and the smuggling of goods Illicit drugs:
despite strenuous law enforcement efforts, faces difficult
challenges in controlling transit of heroin’ and
methamphetamine to regional and world markets; modern
banking system provides conduit for money laundering;
rising indigenous use of synthetic drugs, especially among
young people HUNGARY
Disputes—International: bilateral government, legal, technical
and economic working group negotiations continue in 2006
with Slovakia over Hungary’s failure to complete its portion
of the Gabcikovo-Nagymaros hydroelectric dam _ project
along the Danube; as a member state that forms part of the
EU’s external border, Hungary has implemented the strict
Schengen border rules Refugees and internally displaced persons:
refugees (country of origin): 5,950 applicants for forms of
legal stay other than asylum (Ukraine) (2015) stateless
persons: 144 (2018)
note: 432,744 estimated refugee and migrant arrivals
(January 2015-December 2018); Hungary is predominantly
a transit country and hosts 137 migrants and asylum
seekers as of the end of June 2018; 1,626 migrant arrivals
in 2017
Illicit drugs: transshipment point for Southwest Asian heroin
and cannabis and for South American cocaine destined for
Western Europe; limited producer of precursor chemicals,
particularly for amphetamine and methamphetamine;
efforts to counter money laundering, related to organized
crime and drug trafficking are improving but remain
vulnerable; significant consumer of ecstasy
i Grimsey
Isafjordur
*Husavik
neakeye Seydisfj6rdur,
Reydarfjérdur,
Grundartangi
Hatnarfjérdur eR EYKJAVIK “HO in
Keflavik” i hndkur a
rannadals:
*Selfoss
Vestmannaeyjar,
Surtsey
9 50 100km
pe
0 A 100 mi
Disputes—International: Indonesia has a stated foreign policy
objective of establishing stable fixed land and maritime
boundaries with all of its neighbors; three stretches of land
borders with Timor-Leste have yet to be delimited, two of
which are in the Oecussi exclave area, and no maritime or
Exclusive Economic Zone (EEZ) boundaries have been
established between the countries; all borders between
Indonesia and Australia have been agreed upon bilaterally,
but a 1997 treaty that would settle the last of their
maritime and EEZ boundary has yet to be ratified by
Indonesia’s legislature; Indonesian groups’ challenge
Australia’s claim to Ashmore Reef; Australia has closed
parts of the Ashmore and Cartier Reserve to Indonesian
traditional fishing and placed restrictions on certain
catches; land and maritime negotiations with Malaysia are
ongoing, and disputed areas include the controversial
Tanjung Datu and Camar Wulan border area in Borneo and
the maritime boundary in the Ambalat oil block in the
Celebes Sea; Indonesia and Singapore continue to work on
finalizing their 1973 maritime boundary agreement by
defining unresolved areas north of Indonesia’s Batam
Island; Indonesian secessionists, squatters, and _ illegal
migrants create repatriation problems for Papua New
Guinea; maritime delimitation talks continue with Palau;
EEZ negotiations with Vietnam are ongoing, and the two
countries in Fall 2011 agreed to work together to reduce
illegal fishing along their maritime boundary Refugees and
internally displaced persons: refugees (country of origin): 6,098
(Afghanistan) (2018) IDPs: 16,000 (inter-communal, inter-
faith, and separatist violence between 1998 and 2004 in
Aceh and Papua; religious attacks and land conflicts in
2012 and 2013; most IDPs in Aceh, Maluku, East Nusa
Tengarra) (2018) Illicit drugs: illicit producer of cannabis
largely for domestic use; producer of methamphetamine
and ecstasy; President WIDODO’s war on drugs has led to
an increase in death sentences and executions, particularly
of foreign drug traffickers IRAN
TURKMENISTAN ’
Now Shahy, Mashhad,
TEHRAN i 4) ihe
20m
* z=
Kermanshah
Birjand,
Dezfol ,&sfahan
S fazd
SAUDI
ARABIA
© 100200 km
va &
0 100 200 mi
Disputes—International: NONe
Illicit drugs: transshipment point for drugs going into
mainland China; consumer of opiates and amphetamines','6466ea469b4c5bb79c0739450e700fc56e85d5cd067813ed8f6adbcf6f6ddc74','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8414e0f62450fa7f5b1868eb1309c1d277fb0c48a945576934edad150294504c',2021,'CO','Colombia','transnational-issues',353,'Proadence. oad San Puerto Bolivare
Andrés oe not shown Santa Marta
ry dl
Barranquilla® Pi
Cartagena? Crisidbal
Colon
eit: > plurbo Cuicuta
Bucaramanga, VENEZUELA
Medellin %
Pereira © A
Dagubeg gBOGOTA
Buenaventura
Cali
*"Esmeraldas
GALAPAGOS ISLANDS Ibarra
.
“*
Santo Domingo 6 . he
delos Colorados, yQuiTO Nueva Lojas
ACotopaxi
Manta, Quevedo &
.
Portoviejo eAmbato
Chimborazo &
Qe,
~ Riobamba
Guayaquil
Disputes—International: Organized illegal narcotics operations
in Colombia penetrate across Ecuador’s shared border
Refugees and internally displaced persons: refugees (country of
origin): 50,532 (Colombia) (2018), 120,587 (Venezuela)
(economic and political crisis; includes Venezuelans who
have claimed asylum or have received alternative legal
stay) (2019) Illicit drugs: significant transit country for
cocaine originating in Colombia and Peru, with much of the
US-bound cocaine passing through Ecuadorian Pacific
waters; importer of precursor chemicals used in production
of illicit narcotics; attractive location for cash-placement by
drug traffickers laundering money because of dollarization
and weak anti-money-laundering regime; increased activity
on the northern frontier by trafficking groups and
Colombian insurgents EGYPT
é W. Ba x
La |
: Gaz
a Alexandria Damietta Fort s
Al °Sharm ash
\\Ghardagah, Shaykh
Asyut Bor®
Safajah
Al Kharijah, SLmor
4 Aswan
Hali''ib =
Triangle.','9777aa5725aa98bdea6218355f5dee500d6f9206f21c827a979c064b919d74bb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64862af881a02b147102cf33a172581bc67f419b0ee8cc626d334770373c8789',2021,'NI','Nicaragua','transnational-issues',368,'—_
Alajuela fav Limén
ve xf S
Caldera’. SAN” *Cartago
JOSE Cerro
aChirrips
Puerto
Puntarenas
*San Isidro
Golfito< PANAMA
Disputes—International: Costa Rica and Nicaragua regularly
file border dispute cases over the delimitations of the San
Juan River and the northern tip of Calero Island to the
International Court of Justice (ICJ); in 2009, the ICJ ruled
that Costa Rican vessels carrying out police activities could
not use the river, but official Costa Rican vessels providing
essential services to riverside inhabitants and Costa Rican
tourists could travel freely on the river; in 2011, the ICJ
provisionally ruled that both countries must remove
personnel from the disputed area; in 2013, the ICJ rejected
Nicaragua’s 2012 suit to halt Costa Rica’s construction of a
highway paralleling the river on the grounds of irreparable
environmental damage; in 2013, the ICJ, regarding the
disputed territory, ordered that Nicaragua should refrain
from dredging or canal construction and refill and repair
damage caused by trenches connecting the river to the
Caribbean and upheld its 2010 ruling that Nicaragua must
remove all personnel; in early 2014, Costa Rica brought
Nicaragua to the ICJ over offshore oil concessions in the
disputed region Refugees and _ internally displaced persons:
refugees (country of origin): 21,628 (Venezuela) (economic
and political crisis; includes Venezuelans who have claimed
asylum or have received alternative legal stay) (2019)
stateless persons: 82 (2018)
Trafficking in persons: Current Situation: Costa Rica is a source,
transit, and destination country for men, women, and
children subjected to sex trafficking and forced labor;
Costa Rican women and children, as well as those from
Nicaragua, the Dominican Republic, and other Latin
American countries, are sex trafficked in Costa Rica; child
sex tourism is a particular problem with offenders coming
from the US and Europe; men and children from Central
America, including indigenous Panamanians, and Asia are
exploited in agriculture, construction, fishing, and
commerce; Nicaraguans transit Costa Rica to reach
Panama, where some are subjected to forced labor or sex
trafficking tier rating: Tier 2 Watch List—Costa Rica does not
fully comply with the minimum standards for the
elimination of trafficking; however, it is making significant
efforts to do so; anti-trafficking law enforcement efforts
declined in 2014, with fewer prosecutions and no
convictions and no actions taken against complicit
government personnel; some officials conflated trafficking
with smuggling, and authorities reported the diversion of
funds to combat smuggling hindered anti-trafficking
efforts; the government identified more victims than the
previous year but did not make progress in ensuring that
victims received adequate protective services; specialized
services were limited and mostly provided by NGOs without
government support, even from a dedicated fund for anti-
trafficking efforts; victims services were virtually non-
existent outside of the capital (2015) Illicit drugs:
transshipment country for cocaine and heroin from South
America; illicit production of cannabis in remote areas;
domestic cocaine consumption, particularly crack cocaine,
is rising; significant consumption of amphetamines;
seizures of smuggled cash in Costa Rica and at the main
border crossing to enter Costa Rica from Nicaragua have
risen in recent years COTE D’IVOIRE
t) 5 100km
&stell
,Matagalpa
\\. Chinandega
a” 66m ISLAS DEL
Corinto\\. * MAIZ
% MANAGUA
Granada’
Rivas)
Bluetielag=! Blutt
st
“~
»','d6c14ee0fffe971c24dd0df20b4ddb9f17b2a58306e02721051775dc51fde2e2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a08665395c2cc052c5cd27459ceebf3f40fefe16bc9f55ac68638aaba95062a',2021,'BF','Burkina Faso','transnational-issues',378,'Odienné
orhog
Touba Séguéla -Katlola Bondoukou
y Bouaké
Dalog SYAMQUSSOUKRO
Abengout0, (ciiana
Sinfra® “Dimbokro
Gagnoa, “SS, Adzopé,
Divo” *Agboville
Daboy Aboisso.
—_- .
= Abidjan
San-
Pédro,
$0 100km
[iene
Q 5 100 mi
Disputes—International: disputed maritime border between
Cote d’Ivoire and Ghana
Refugees and internally displaced persons: [DPs: 302,000 (post-
election conflict in 2010-11, as well as civil war from 2002-
04; land disputes; most pronounced in western and
southwestern regions) (2018) stateless persons: 692,000
(2018); note—many Ivoirians lack documentation proving
their nationality, which prevent them from accessing
education and healthcare; birth on Ivorian soil does not
automatically result in citizenship; disputes over citizenship
and the associated rights of the large population descended
from migrants from neighboring countries is an ongoing
source of tension and contributed to the country’s 2002
civil war; some observers believe the government’s mass
naturalizations of thousands of people over the last couple
of years is intended to boost its electoral support base; the
government in October 2013 acceded to international
conventions on statelessness and in August 2013 reformed
its nationality law, key steps to clarify the nationality of
thousands of residents; since the adoption of the Abidjan
Declaration to eradicate statelessness in West Africa in
February 2015, 6,400 people have received nationality
papers Illicit drugs: illicit producer of cannabis, mostly for
local consumption; utility as a narcotic transshipment point
to Europe reduced by ongoing political instability; while
rampant corruption and inadequate supervision leave the
banking system vulnerable to money laundering, the lack of
a developed financial system limits the country’s utility as a
major money-laundering center CROATIA
BOSNIA AND
HERZEGOVINA','5864f12ae08c0e35cd24b4b5f28115839df8672bb1f7a0ee7468098de37b8333','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae715762c1651415a02cdb11d749b1a03d42807689a9917024af62b2bb0c4210',2021,'HR','Croatia','transnational-issues',390,'Disputes—International: dispute remains with Bosnia and
Herzegovina over several small sections of the boundary
related to maritime access that hinders ratification of the
1999 border agreement; since the breakup of Yugoslavia in
the early 1990s, Croatia and Slovenia have each claimed
sovereignty over Piranski Bay and four villages, and
Slovenia has objected to Croatia’s claim of an exclusive
economic zone in the Adriatic Sea; in 2009, however
Croatia and Slovenia signed a _ binding international
arbitration agreement to define their disputed land and
maritime borders, which led to Slovenia lifting its
objections to Croatia joining the EU; Slovenia continues to
impose a hard border Schengen regime with Croatia, which
joined the EU in 2013 but has not yet fulfilled Schengen
requirements Refugees and internally displaced persons: Stateless
persons: 2,886 (2018) note: 686,414 estimated refugee and
migrant arrivals (January 2015-October 2019); flows slowed
considerably in 2017; Croatia is predominantly a transit
country and hosts about 340 asylum seekers as of the end
of June 2018
licit drugs: primarily a transit country along the Balkan
route for maritime shipments of South American cocaine
bound for Western Europe and other illicit drugs and
chemical precursors to and from Western Europe; no
significant domestic production of illicit drugs
"Novi
BOSNIA
1s AND , Kragujevac,
HERZEGOVINA *Usice
Novi
Pazar,','b01a99b18a90775c96475e745a4fb7f3985d669bb83e0643b1a97515753a1bfb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15dcc67b74c8360bccec4d6a3b584e88f928bc50adf1e18716ae82dff8106854',2021,'CY','Cyprus','transnational-issues',394,'Disputes—International: hostilities in 1974 divided the island
into two de facto autonomous entities, the internationally
recognized Cypriot Government and a Turkish-Cypriot
community (north Cyprus); the 1,000-strong UN
Peacekeeping Force in Cyprus (UNFICYP) has served in
Cyprus since 1964 and maintains the buffer zone between
north and south; on 1 May 2004, Cyprus entered the EU
still divided, with the EU’s body of legislation and
standards (acquis communitaire) suspended in the north;
Turkey protests Cypriot Government creating hydrocarbon
blocks and maritime boundary with Lebanon in March 2007
Refugees and internally displaced persons: refugees (country of
origin): 6,259 (Syria) (2018) IDPs: 228,000 (both Turkish
and Greek Cypriots; many displaced since 1974) (2018)
note: 10,690 estimated refugee and migrant arrivals
(January 2015-November 2019)
Ilicit drugs: Minor transit point for heroin and hashish via air
routes and container traffic to Europe, especially from
Lebanon and Turkey; some cocaine transits as well; despite
a strengthening of anti-money-laundering legislation,
remains vulnerable to money laundering; reporting of
Suspicious transactions in offshore sector remains weak
| ypriot-administe area Famagusta
Ayios Nikolaos,
UN buffer zone
= i
Larnaca','192abbc6893b1d0100a15510255c34cee08fb8c5af82c57f041cdece1185e661','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95446dfc9cce8e61b9e30f934d4bc976ecc18fff7ad8e39d29fec88575c91aa4',2021,'PL','Poland','transnational-issues',395,'Dééiny
Usti rad? P Liverec
a Hradec
m :
PRAGUE, Kralove,
A
Pizen - yh!
ae
Bydgoszcz*
Poznan
e
Lodz,
Wroctaw
*
Czestochowa
. P
CZECH REP.
0 50 100km
0 50 100 mi Rysy
Vinee sagbye.
Disputes—International: aS a Member state that forms part of
the EU’s external border, Poland has implemented the
strict Schengen border rules to restrict illegal immigration
and trade along its eastern borders with Belarus and
Ukraine Refugees and internally displaced persons: refugees
(country of origin): 9,893 (Russia) (2018) stateless persons:
10,825 (2018)
Illicit drugs: despite diligent counternarcotics measures and
international information sharing on cross-border crimes, a
major illicit producer of synthetic drugs for the
international market; minor transshipment point for
Southwest Asian heroin and Latin American cocaine to
Western Europe PORTUGAL
Viana do
Castelo
Braga
Vila Real
,Leixoes
Porto
J LeAveiro viseu
Covilha
oimbra ate
°
=
Foz Castelo
Branco
Leiria °
da nana Ye PAIN
Santarém,
JGR5ON r
“SBareiro Evora
Setubal
Sines, Beja, ¢
Portimao
Faro
Disputes—International: Portugal does not recognize Spanish
sovereignty over the territory of Olivenza based on a
difference of interpretation of the 1815 Congress of Vienna
and the 1801 Treaty of Badajoz Refugees and internally
displaced persons: stateless persons: 14 (2018)
Illicit drugs: seizing record amounts of Latin American
cocaine destined for Europe; a European gateway for
Southwest Asian heroin; transshipment point for hashish
from North Africa to Europe; consumer of Southwest Asian
heroin PUERTO RICO','35dcb4cb640953adb659b845d3a2db42d502761dfe207003678515646ab49d26','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31f4ff7606aa9796ce5bdeb1f20b716e437be0b3b5a06b06105c287860f5dfe8',2021,'DK','Denmark','transnational-issues',413,'Disputes—International: Iceland, the UK, and Ireland dispute
Denmark’s claim that the Faroe Islands’ continental shelf
extends beyond 200 nm; sovereignty dispute with Canada
over Hans Island in the Kennedy Channel between
Ellesmere Island and Greenland; Denmark (Greenland) and
Norway have made submissions to the Commission on the
Limits of the Continental Shelf (CLCS) and Russia is
collecting additional data to augment its 2001 CLCS
submission Refugees and internally displaced persons: refugees
(country of origin): 19,698 (Syria) (2017) stateless persons:
8,236 (2018)
DHEKELIA
Disputes—International: Maritime boundary dispute with Tonga
Disputes—International: managed dispute between Canada and
Denmark over Hans Island in the Kennedy Channel
between Canada’s Ellesmere Island and Greenland;
Denmark (Greenland) and Norway have made submissions
to the Commission on the Limits of the Continental Shelf
(CLCS) and Russia is collecting additional data to augment
its 2001 CLCS submission GRENADA
Sauteurs,
Mount
LU
Saint
Catherine
Gouyave,
Grenville,
SAINT r Grenada
Disputes—International: Norway asserts a territorial claim in
Antarctica (Queen Maud Land and its continental shelf);
Denmark (Greenland) and Norway have made submissions
to the Commission on the Limits of the Continental Shelf
(CLCS) and Russia is collecting additional data to augment
its 2001 CLCS submission; Norway and Russia signed a
comprehensive maritime boundary agreement in 2010
Refugees and internally displaced persons: refugees (country of
origin): 15,246 (Eritrea), 13,914 (Syria), 7,183 (Somalia),
6,065 (Afghanistan) (2018) stateless persons: 2,809 (2018)
Thamarit
.
Disputes—International: boundary agreement reportedly signed
and ratified with UAE in 2003 for entire border, including
Oman’s Musandam Peninsula and Al Madhah exclave, but
details of the alignment have not been made public Refugees
and internally displaced persons: refugees (country of origin):
5,000 (Yemen) (2017)
PACIFIC OCEAN','58b6b9d4d2910150ab1e3cd06da65e9ba8cd3e0d8d11208c015235d1678c5aba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('426ba62d496c0be103b0654a984e31d0a22823e0120ff8966df6d927abad212d',2021,'DJ','Djibouti','transnational-issues',426,'Disputes—International: Dominica is the only Caribbean state
to challenge Venezuela’s sovereignty claim over Aves Island
and joins the other island nations in challenging whether
the feature sustains human habitation, a criterion under
the UN Convention on the Law of the Sea, which permits
Venezuela to extend its EEZ and continental shelf claims
over a large portion of the eastern Caribbean Sea illicit
drugs: transshipment point for narcotics bound for the US
and Europe; minor cannabis producer DOMINICAN
REPUBLIC
H ATLANTIC OCEAN
Puerto
Plata
Santiago, San Francisco
de Macoris
LaVega, °
HAITI Fp.
=] Duarte, Bonao
Comendador °
Hispaniola San Pedro HigGey
San Cristébal, ye Macoris La Romana
ANTO
“Barahona DOMINGO
Pedernalés','4070b65a940db3d090f9511b3c94d7844722534b08391e53a6fc6651b4d04910','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d1b140b4516025d97633dcd16e4ee2089efa07cd18f28022e7baffcc57fd0a',2021,'JE','Jersey','transnational-issues',435,'Disputes—International: Haitian migrants cross the porous
border into the Dominican Republic to find work; illegal
migrants from the Dominican Republic cross the Mona
Passage each year to Puerto Rico to find better work
Refugees and internally displaced persons: refugees (country of
origin): 8,119 (Venezuela) (economic and political crisis;
includes Venezuelans who have claimed asylum or have
received alternative legal stay) (2019) stateless persons:
133,770 (2016); note—a September 2013 Constitutional
Court ruling revoked the citizenship of those born after
1929 to immigrants without proper documentation, even
though the constitution at the time automatically granted
citizenship to children born in the Dominican Republic and
the 2010 constitution provides that _ constitutional
provisions cannot be applied retroactively; the decision
overwhelmingly affected people of Haitian descent whose
relatives had come to the Dominican Republic since the
1890s as a cheap source of labor for sugar plantations; a
May 2014 law passed by the Dominican Congress
regularizes the status of those with birth certificates but
will require those without them to prove they were born in
the Dominican Republic and to apply for naturalization; the
government has issued documents to thousands of
individuals who may claim citizenship under this law, but
no official estimate has been released note: revised
estimate includes only individuals born to parents who
were both born abroad; it does not include individuals born
in the country to one Dominican-born and one foreign-born
parent or subsequent generations of individuals of foreign
descent; the estimate, as such, does not include all
stateless persons (2015) Illicit drugs: transshipment point for
South American drugs destined for the US and Europe; has
become a transshipment point for ecstasy from the
Netherlands and Belgium destined for US and Canada;
substantial money laundering activity in particular by
Colombian narcotics traffickers; significant amphetamine
consumption
Disputes—International: NONe
Refugees and internally displaced persons: refugees (country of
origin): 34,072 (Eritrea), 16,565 (Syria), 12,282
(Afghanistan), 5,744 (Sri Lanka) (2018) stateless persons:
A9 (2018)
Illicit drugs: a Major international financial center vulnerable
to the layering and integration stages of money laundering;
despite significant legislation and reporting requirements,
secrecy rules persist and nonresidents are permitted to
conduct business through offshore entities and various
intermediaries; transit country for and consumer of South
American cocaine, Southwest Asian heroin, and Western
European synthetics; domestic cannabis cultivation and
limited ecstasy production SYRIA
TURKEY
Al Hasakah®
Ar Raqqah
{Latakia
eBaniyas Dayr az”
(JartGs Hamah Zawr
*Homs Jladmur
DAMASCUS
Mount Hermon
‘Al Qunaytirah
J As Suwayda’
) Golan Heights JORDAN
{ (israel occupied)
Disputes—International: involved in complex dispute with
Brunei, China, Malaysia, the Philippines, and Vietnam over
the Spratly Islands, and with China and the Philippines
over Scarborough Reef; the 2002 “Declaration on the
Conduct of Parties in the South China Sea” has eased
tensions but falls short of a legally binding “code of
conduct” desired by several of the disputants; Paracel
Islands are occupied by China, but claimed by Taiwan and
Vietnam; in 2003, China and Taiwan became more vocal in
rejecting both Japan’s claims to the uninhabited islands of
the Senkaku-shoto (Diaoyu Tai) and Japan’s unilaterally
declared exclusive economic zone in the East China Sea
where all parties engage in hydrocarbon prospecting Illicit
drugs: regional transit point for heroin, methamphetamine,
and precursor chemicals; transshipment point for drugs to
Japan; major problem with domestic consumption of
methamphetamine and heroin; rising problems with use of
ketamine and club drugs TAJIKISTAN
Disputes—International: in 2006, China and Tajikistan pledged
to commence demarcation of the revised boundary agreed
to in the delimitation of 2002; talks continue with
Uzbekistan to delimit border and remove minefields;
disputes in Isfara Valley delay delimitation with Kyrgyzstan
Refugees and internally displaced persons: stateless
persons: 4,616 (2018)
Illicit drugs: Tajikistan sits on one of the world’s highest
volume illicit drug trafficking routes, between Afghan
opiate production to the south and the illicit drug markets
of Russia and Eastern Europe to the north; limited illicit
cultivation of opium poppy for domestic consumption;
significant consumer of opiates TANZANIA
Tabora
.
ma enanl
£ Mkoani
(legislative capital), Zanzibar,
Zanzibar
DAR ES®) joss
Iringa, SALAAM) ‘#0
*Sumbawanga N
Mbeya
rs Mtwara®y
ZAMBIA Songea','170b0ea54394c5d7f2cccdead8b242b51e4533e6ca8e4de0ccade000e4599846','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a136ff70206835ecdb79e82b68ed4d700d9ee5d3ac877458c44cff5357034920',2021,'GT','Guatemala','transnational-issues',457,'Disputes—International: International Court of Justice (ICJ)
ruled on the delimitation of “bolsones” (disputed areas)
along the El Salvador- Honduras boundary, in 1992, with
final agreement by the parties in 2006 after an
Organization of American States survey and a further ICJ
ruling in 2003; the 1992 ICJ ruling advised a tripartite
resolution to a maritime boundary in the Gulf of Fonseca
advocating Honduran access to the Pacific; El Salvador
continues to claim tiny Conejo Island, not identified in the
ICJ decision, off Honduras in the Gulf of Fonseca Refugees
and internally displaced persons: IDPs: 71,500 (2018)
Illicit drugs: transshipment point for cocaine; small amounts
of marijuana produced for local consumption; significant
use of cocaine EQUATORIAL GUINEA','74b08c8d3f99d262b9901635bbd4ca86911d26958694448bda514033330037dc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f55ed4e2cc2a07624073352c92206df97daaed5dc015104810e84d458ee4a66b',2021,'GN','Guinea','transnational-issues',465,'Disputes—International: in 2002, ICJ ruled on an equidistance
settlement of Cameroon-Equatorial Guinea-Nigeria
maritime boundary in the Gulf of Guinea, but a dispute
between Equatorial Guinea and Cameroon over an island at
the mouth of the Ntem River and imprecisely defined
maritime coordinates in the ICJ decision delayed final
delimitation; UN urged Equatorial Guinea and Gabon to
resolve the sovereignty dispute over Gabon-occupied
Mbane and lesser islands and to create a maritime
boundary in the hydrocarbon-rich Corisco Bay Trafficking in
persons: current situation: Equatorial Guinea is a source
country for children subjected to sex trafficking and
destination country for men, women, and _ children
subjected to forced labor; Equatorial Guinean girls may be
encouraged by their parents to engage in the sex trade in
urban centers to receive groceries, gifts, housing, and
money; children are also trafficked from nearby countries
for work as domestic servants, market laborers, ambulant
vendors, and launderers; women are _ trafficked to
Equatorial Guinea from Cameroon, Benin, other
neighboring countries, and China for forced labor or
prostitution tier rating: Tier 3—Equatorial Guinea does not
fully comply with the minimum standards on _ the
elimination of trafficking and is not making significant
efforts to do so; in 2014, the government made no efforts to
investigate or prosecute any suspected trafficking
offenders or to identify or protect victims, despite its 2004
law prohibiting all forms of trafficking and mandating the
provision of services to victims; undocumented migrants
continued to be deported without being screened to assess
whether any were trafficking victims; authorities did not
undertake any trafficking awareness campaigns, implement
any programs to address forced child labor, or make any
other efforts to prevent trafficking (2015) ERITREA
SAUDI
ARABIA
DAHLAK
ARCHIPELAGO
Keren,
Ak’ordat. Massawa*
ASMARA*
eMendefera
A Sora
Disputes—International: Eritrea and Ethiopia agreed to abide
by 2002 Ethiopia-Eritrea Boundary Commission’s (EEBC)
delimitation decision, but neither party responded to the
revised line detailed in the November 2006 EEBC
Demarcation Statement; Sudan accuses Eritrea of
supporting eastern Sudanese rebel groups; in 2008,
Eritrean troops moved across the border on Ras Doumera
peninsula and occupied Doumera Island with undefined
sovereignty in the Red Sea Trafficking in persons: Current
situation: Eritrea is a source country for men, women, and
children trafficked for the purposes of forced labor
domestically and, to a lesser extent, sex and labor
trafficking abroad; the country’s national service program
is often abused, with conscripts detained indefinitely and
subjected to forced labor; Eritrean migrants, often fleeing
national service, face strict exit control procedures and
limited access to passports and visas, making them
vulnerable to trafficking; Eritrean secondary school
children are required to take part in public works projects
during their summer breaks and must attend military and
educational camp in their final year to obtain a high school
graduation certificate and to gain access to higher
education and some jobs; some Eritreans living in or near
refugee camps, particularly in Sudan, are kidnapped by
criminal groups and held for ransom in the Sinai Peninsula
and Libya, where they are subjected to forced labor and
abuse tier rating: Tier 3—Eritrea does not fully comply with
the minimum standards for the elimination of trafficking
and is not making significant efforts to do so; the
government failed to investigate or prosecute any
trafficking offenses or to identify or protect any victims;
while the government continued to warn citizens of the
dangers of human trafficking through awareness-raising
events and poster campaigns, authorities lacked an
understanding of the crime, conflating trafficking with
transnational migration; Eritrea is not a party to the 2000
UN TIP Protocol (2015)
Disputes—International: relies on assistance from Australia to
keep out illegal cross-border activities from primarily
Indonesia, including goods smuggling, illegal narcotics
trafficking, and squatters and secessionists Refugees and
internally displaced persons: refugees (country of origin): 9,368
(Indonesia) (2018) IDPs: 12,000 (natural disasters, tribal
conflict, inter-communal violence, development projects)
(2017) Trafficking in persons: current situation: Papua New
Guinea is a source and destination country for men,
women, and children subjected to sex trafficking and
forced labor; foreign and Papua New Guinean women and
children are subjected to sex trafficking, domestic
servitude, forced begging, and street vending; parents may
sell girls into forced marriages to settle debts or as peace
offerings or trade them to another tribe to forge a political
alliance, leaving them vulnerable to forced domestic
service, Or, in urban areas, they may prostitute their
children for income or to pay school fees; Chinese,
Malaysian, and local men are forced to labor in logging and
mining camps through debt bondage schemes; migrant
women from Indonesia, Malaysia, Thailand, China, and the
Philippines are subjected to sex trafficking and domestic
servitude at logging and mining camps, fisheries, and
entertainment sites tier rating: Tier 2 Watch List—Papua
New Guinea does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; the Criminal Code
Amendment of 2013, which prohibits all forms of trafficking
was brought into force in 2014; the government also
formed an anti-trafficking committee, which drafted a
national action plan; despite corruption problems,
trafficking-related crimes were prosecuted in village courts
rather than criminal courts, resulting in restitution to the
victim but no prison time for offenders; the government did
not investigate, prosecute, or convict any officials or law
enforcement personnel complicit in trafficking offenses; the
government made no efforts to proactively identify
trafficking victims, has no formal victim identification and
referral mechanism, and does not provide care facilities to
victims or funding to shelters run by NGOs or international
organizations (2015) Illicit drugs: major consumer of
cannabis
PARACEL ISLANDS
West Sand. Tee Island
AMPHITRITE
GROUP
North island
Rocky island
Woody Island
CRESCENT
Disputes—International: Occupied by China, also claimed by
Taiwan and Vietnam
Nav -UCL ODN
BOLIVIA
[Ses BRAZIL
Mariscal
ESstigarribia
Filadelfia’ ©
©
SN b Concepcion,
Pozo
Colorado
Disputes—International: cross-border trafficking in persons,
timber, wildlife, and cannabis; rebels from the Movement of
Democratic Forces in the Casamance find refuge in Guinea-
Bissau Refugees and _ internally displaced persons: refugees
(country of origin): 14,155 (Mauritania) (2019) IDPs:
18,000 (clashes between government troops’ and
separatists in Casamance region) (2017)
Illicit drugs: transshipment point for Southwest and
Southeast Asian heroin and South American cocaine
moving to Europe and North America; illicit cultivator of
cannabis SERBIA
.
Subotica
.Kabala
Loma
Mansa .
,Kambia
Makeni
Lungi ,Lunsar
ee Papel
FREETOWN
sKenema','b08082eb1a5ed14042f89df2f08a93d8f9596116801ce1f8ea5bf0a471baf131','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bc033e09497fdedb80c6009b7b74c834e5426f0fbff10eb9827c8fb3a6c7a4',2021,'FI','Finland','transnational-issues',470,'Paldiski, se “Muga Kunda ~~~.
*" TALLINN Li by
Narvay
x)
+ Paide
Haapsalu
er arnu
*
Viljandi','db4b2e43c0dd63b145b60558098ed85cd0d1e7e01f0b32a26bb24d22824eea5f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('310c00bb3521d744a9809bbd4c3529755872e9f77a40272a16c6672366053320',2021,'MZ','Mozambique','transnational-issues',491,'Disputes—International: in 2006, Swati king advocated
resorting to ICJ to claim parts of Mpumalanga and
KwaZulu-Natal from South Africa ETHIOPIA
Disputes—International: dispute with Tanzania over the
boundary in Lake Nyasa (Lake Malawi) and the meandering
Songwe River; Malawi contends that the entire lake up to
the Tanzanian shoreline is its territory, while Tanzania
claims the border is in the center of the lake; the conflict
was reignited in 2012 when Malawi awarded a license to a
British company for oil exploration in the lake Refugees and
internally displaced persons: refugees (country of origin):
27,778 (Democratic Republic of the Congo) (refugees and
asylum seekers), 8,752 (Burundi) (refugees and asylum
seekers), 6,606 (Rwanda) (refugees and asylum seekers)
(2019) MALAYSIA
Disputes—International: NONe
Trafficking in persons: current situation: Maldives is a
destination country for men, women, and _ children
subjected to forced labor and sex trafficking and a source
country for women and children subjected to labor and sex
trafficking; primarily Bangladeshi and Indian migrants
working both legally and illegally in the construction and
service sectors face conditions of forced labor, including
fraudulent recruitment, confiscation of identity and travel
documents, nonpayment and withholding of wages, and
debt bondage; a small number of women from Asia, Eastern
Europe, and former Soviet states are trafficked to Maldives
for sexual exploitation; Maldivian women may be subjected
to sex trafficking domestically or in Sri Lanka; some
Maldivian children are transported to the capital for
domestic service, where they may also be victims of sexual
abuse and forced labor tier rating: Tier 2 Watch List—
Maldives does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; the government adopted
a national action plan for 2015-19 and is continuing to
develop victim identification, protection, and_ referral
procedures, but overall its anti-trafficking efforts did not
increase; only five trafficking investigations were
conducted, no new prosecutions were initiated for the
second consecutive year, and no convictions were made,
down from one in 2013; some officials warned businesses
in advance of planned raids for suspected trafficking
offenses; victim protection deteriorated when the state-run
shelter for female victims barred access to victims shortly
after opening in January 2014, in part because of
bureaucratic disputes, which dissuaded victims from
pursuing charges against perpetrators; the government did
not prosecute or hold accountable any employers or
government officials for withholding passports (2015)
° 200 400 km
so Ens Sali any
9 200 400 mi
Disputes—International: South Africa has placed military units
to assist police operations along the border of Lesotho,
Zimbabwe, and Mozambique to control smuggling,
poaching, and illegal migration Refugees and _ internally
displaced persons: refugees (country of origin): 9,903
(Democratic Republic of Congo) (refugees and asylum
seekers), 7,841 (Burundi) (refugees and asylum seekers)
(2019) IDPs: 14,000 (violence between the government and
an opposition group, violence associated with extremists
groups in 2018) (2018) Illicit drugs: southern African transit
point for South Asian hashish and heroin, and South
American cocaine probably destined for the European and
South African markets; producer of cannabis (for local
consumption) and methaqualone (for export to South
Africa); corruption and poor regulatory capability make the
banking system vulnerable to money laundering, but the
lack of a well-developed financial infrastructure limits the
country’s utility as a money-laundering center
Disputes—International: dispute with Tanzania over the
boundary in Lake Nyasa (Lake Malawi) and the meandering
Songwe River; Malawi contends that the entire lake up to
the Tanzanian shoreline is its territory, while Tanzania
claims the border is in the center of the lake; the conflict
was reignited in 2012 when Malawi awarded a license to a
British company for oil exploration in the lake Refugees and
internally displaced persons: refugees (country of origin):
166,978 (Burundi), 75,824 (Democratic Republic of the
Congo) (2019) Trafficking in persons: current situation:
Tanzania is a source, transit, and destination country for
men, women, and children subjected to forced labor and
sex trafficking; the exploitation of young girls in domestic
servitude continues to be ‘Tanzania’s largest human
trafficking problem; Tanzanian boys are subject to forced
labor mainly on farms but also in mines and quarries, in the
informal commercial sector, in factories, in the sex trade,
and possibly on small fishing boats; Tanzanian children and
adults are subjected to domestic servitude, other forms of
forced labor, and sex trafficking in other African countries,
the Middle East, Europe, and the US; internal trafficking is
more prevalent than transnational trafficking and is usually
facilitated by friends, family members, or intermediaries
with false offers of education or legitimate jobs; trafficking
victims from Burundi, Kenya, South Asia, and Yemen are
forced to work in Tanzania’s agricultural, mining, and
domestic service sectors or may be sex trafficked tier rating:
Tier 2 Watch List - Tanzania does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
Tanzania was granted a waiver from an otherwise required
downgrade to Tier 3 because its government has a written
plan that, if implemented, would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking; the
government adopted a three-year national action plan and
implementing regulations for the 2008 anti-trafficking law;
authorities somewhat increased their number of trafficking
investigations and prosecutions and convicted one offender,
but the penalty was a fine in lieu of prison, which was
inadequate given the severity of the crime; the government
did not operate any shelters for victims and relied on NGOs
to provide protective services (2015) Illicit drugs: targeted by
traffickers moving hashish, Afghan heroin, and South
American cocaine transported down the East African
coastline, through airports, or overland through Central
Africa; Zanzibar likely used by traffickers for drug
smuggling; traffickers in the past have recruited Tanzanian
couriers to move drugs through Iran into East Asia
© 50 100km
— i SOUTH AFRICA
° 50 100 mi
Disputes—International: Namibia has supported, and in 2004
Zimbabwe dropped objections to, plans between Botswana
and Zambia to build a bridge over the Zambezi River,
thereby de facto recognizing a short, but not clearly
delimited, Botswana-Zambia boundary in the river; South
Africa has placed military units to assist police operations
along the border of Lesotho, Zimbabwe, and Mozambique
to control smuggling, poaching, and illegal migration
Refugees and internally displaced persons: refugees (country of
origin): 11,100 (Democratic Republic of Congo) (refugees
and asylum seekers), 8,060 (Mozambique) (2019) IDPs:
99,125 (tropical cyclone, 2019) (2019)
stateless persons: 300,000 (2016)
Trafficking in persons: Current situation: Zimbabwe is a source,
transit, and destination country for men, women, and
children subjected to forced labor and sex trafficking;
Zimbabwean women and girls from towns bordering South
Africa, Mozambique, and Zambia are subjected to forced
labor, including domestic servitude, and _ prostitution
catering to long-distance truck drivers; Zimbabwean men,
women, and children experience forced labor in agriculture
and domestic servitude in rural areas; family members may
recruit children and other relatives from rural areas with
promises of work or education in cities and towns where
they end up in domestic servitude and sex trafficking;
Zimbabwean women and men are lured into exploitative
labor situations in South Africa and other neighboring
countries tier rating: Tier 3—Zimbabwe does not fully comply
with the minimum standards for the elimination of
trafficking and is not making significant efforts to do so; the
government passed an anti-trafficking law in 2014 defining
trafficking in persons as a crime of transportation and
failing to capture the key element of the international
definition of human trafficking—the purpose of exploitation
—which prevents the law from being comprehensive or
consistent with the 2000 UN TIP Protocol that Zimbabwe
acceded to in 2013; the government did not report on anti-
trafficking law enforcement efforts during 2014, and
corruption in law enforcement and the judiciary remain a
concern; authorities made minimal efforts to identify and
protect trafficking victims, relying on NGOs to identify and
assist victims; Zimbabwe’s 2014 anti-trafficking law
required the opening of 10 centers for trafficking victims,
but none were established during the year; five existing
shelters for vulnerable children and orphans may have
accommodated child victims; in January 2015, an inter-
ministerial anti-trafficking committee was established, but
it is unclear if the committee ever met or initiated any
activities (2015) Illicit drugs: transit point for cannabis and
South Asian heroin, mandrax, and methamphetamines en
route to South Africa
APPENDIX A
ABBREVIATIONS
ABEDA
ACP Group
ADB
AfDB
AFESD
AG
Air Pollution
Air Pollution-Nitrogen
Oxides
Air Pollution-Persistent
Organic Pollutants
Air Pollution-Sulphur 85
Air Pollution-Sulphur 94
Air Pollution-Volatile
Organic Compounds
AMF
AMISOM
AMU
Arab Bank for Economic Development in Africa
African, Caribbean, and Pacific Group of States
Asian Development Bank
African Development Bank
Arab Fund _=§ for
Development
Economic and _ Social
Australia Group
Convention on Long-Range Transboundary Air
Pollution
Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution
Concerning the Control of Emissions of
Nitrogen Oxides or Their Transboundary
Fluxes
Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on
Persistent Organic Pollutants
Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on the
Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution
Concerning the Control of Emissions of
Volatile Organic Compounds or _ Their
Transboundary Fluxes
Arab Monetary Fund
African Union Mission in Somalia
Arab Maghreb Union
Antarctic Marine Living
Resources
Antarctic Seals
Antarctic-Environmental
Protocol
ANZUS
AOSIS
APEC
Arabsat
ARF
ASEAN
AU
Autodin
BA
bbli/day
BCIE
BDEAC
Benelux
BGN
BIMSTEC
Biodiversity
BIS
BRICS
BSEC
C
c.i.f.
CACM
CAEU
CAN
Caricom
Convention on the Conservation of Antarctic
Marine Living Resources
Convention for the Conservation of Antarctic
Seals
Protocol on Environmental Protection to the
Antarctic Treaty
Australia-New Zealand-United States Security
Treaty
Alliance of Small Island States
Asia-Pacific Economic Cooperation
Arab Satellite Communications Organization
ASEAN Regional Forum
Association of Southeast Asian Nations
African Union
Automatic Digital Network
Baltic Assembly
barrels per day
Central American Bank for Economic
Integration
Central African States Development Bank
Benelux Union
United States Board on Geographic Names
Bay of Bengal Initiative for Multi-sectoral
Technical and Economic Cooperation
Convention on Biological Diversity
Bank for International Settlements
(Brazil, Russia, India, China, and South Africa)
Black Sea Economic Cooperation Zone
Commonwealth
cost, insurance, and freight
Central American Common Market
Council of Arab Economic Unity
Andean Community
Caribbean Community and Common Market
CB
CBSS
CCC
CD
CDB
CE
CEI
CELAC
CEMA
CEMAC
CEPGL
CERN
CIA
CICA
CIS
CITES
Climate Change
Climate Change-Kyoto
Protocol
COCOM
COMESA
Comsat
CP
CPLP
CSN
CSTO
CTBTO
citizen’s band mobile radio communications
Council of the Baltic Sea States
Customs Cooperation Council
Community of Democracies
Caribbean Development Bank
Council of Europe
Central European Initiative
Community of Latin America and Caribbean
States
Council for Mutual Economic Assistance
Economic and Monetary Community of Central
Africa
Economic Community of the Great Lakes
Countries
European Organization for Nuclear Research
Central Intelligence Agency
Conference of Interaction and Confidence-
Building Measures in Asia
Commonwealth of Independent States
see Endangered Species
United Nations Framework Convention on
Climate Change
Kyoto Protocol to the United Nations
Framework Convention on Climate Change
Coordinating Committee on Export Controls
Common Market for Eastern and Southern
Africa
Communications Satellite Corporation
Colombo Plan
Comunidade dos Paises de Lingua Portuguesa
South American Community of Nations became
UNASUL—Union of South American Nations
Collective Security Treaty Organization
Preparatory Commission for the Nuclear-Test-
Ban Treaty Organization
DDT
Desertification
DIA
DSN
DST
DWT
EAC
EADB
EAEC
EAPC
EAS
EBRD
EC
ECA
ECB
ECE
ECLAC
ECO
ECOMIG
ECOSOC
ECOWAS
ECSC
EE
EEC
EEZ
EFTA
calendar year
Developing Eight
developed country
Dichloro-diphenyl-trichloro-ethane
United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in Africa
United States Defense Intelligence Agency
Defense Switched Network
daylight savings time
deadweight ton
East African Community
East African Development Bank
Eurasian Economic Community
Euro-Atlantic Partnership Council
Fast Asia Summit
European Bank for Reconstruction and
Development
European Community or European Commission
Economic Commission for Africa
European Central Bank
Economic Commission for Europe
Economic Commission for Latin America and
the Caribbean
Economic Cooperation Organization
ECOWAS Mission in The Gambia
Economic and Social Council
Economic Community of West African States
European Coal and Steel Community
Eastern Europe
European Economic Community
exclusive economic zone
European Free Trade Association
EIB
EITI
EMU
Endangered Species
Entente
Environmental Modification
ESA
ESCAP
ESCWA
est.
EU
EUFOR
Euratom
Eutelsat
Ex-Im
EUTM
f.o.b.
FAO
FATF
FAX
FLS
FOC
FSU
ft
FttP
European Investment Bank
Extractive Industry Trnsparency Initiative
European Monetary Union
Convention on the International Trade in
Endangered Species of Wild Flora and Fauna
(CITES)
Council of the Entente
Convention on the Prohibition of Military or
Any Other Hostile Use of Environmental
Modification Techniques
European Space Agency
Economic and Social Commission for Asia and
the Pacific
Economic and Social Commission for Western
Asia
estimate
European Union
European Union Force in Bosnia’ and
Herzegovina
European Atomic Energy Community
European Telecommunications Satellite
Organization
Export-Import Bank of the United States
European Union Training Mission
free on board
Food and Agriculture Organization
Financial Action Task Force
facsimile
Front Line States
flags of convenience
former Soviet Union
foot
FttP: Fiber to the Home ( FttP) is a pure fiber-
optic cable connection running from an
FY
FZ
G-10
G-11
G-15
G-20
G-24
G-3
G-5
G-6
G-7
G-77
G-8
G-9
GATT
GCC
GCN
GCTU
GDP
GMT
GNP
GRT
GSM','900d4aa3fb6de02d532fbfcaea792b1f2a244737e6044ab64f9dbcf823c1995d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e1876fa6d22c4b4b48b522c056fe9568bacb8666e448814b18c3d49585e1ee',2021,'YE','Yemen','transnational-issues',502,'Disputes—International: Argentina, which claims the islands in
its constitution and briefly occupied them by force in 1982,
agreed in 1995 to no longer seek settlement by force; UK
continues to reject Argentine requests for sovereignty talks','11448771c82061f004fd449156fa495ba2e5c350e21a7fc57017cd9f79f0dfd2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c48cbd4074f76469c9fa556684dc02f7c7e3435c6946b12709111ec5d89fcdb',2021,'FO','Faroe Islands','transnational-issues',503,'Kalsoy Kunoy <> Vigoy Fi
Streymoy Feta e Sviney
Fuglafyardhur’. Klaksvik
Vestmanna, Boryoy
mee Eysturoy
Vagar *TORSHAVN
Sandoy
Stéra Dimun
Fvoroyrl','d8db8347fe629d68e7381565adf83012f29b9059facd753d41557230b2d82288','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1b9e038bfbef9c09535be5c07c1b868e3687c2b3a153223300e85a0b7f93a7',2021,'PF','French Polynesia','transnational-issues',526,'Disputes—International: NONe
FRENCH SOUTHERN AND ANTARCTIC
LANDS
Disputes—International: French claim to “Adelie Land” in
Antarctica is not recognized by the US; Bassas da India,
Furopa Island, Glorioso Islands, Juan de Nova Island (Iles
Eparses): claimed by Madagascar; the vegetated drying
cays of Banc du Geyser, which were claimed by
Madagascar in 1976, also fall within the EEZ claims of the
Comoros and France (Glorioso Islands); Tromelin Island
(Iles Eparses): claimed by Mauritius
REP. OF
THE CONGO
LIBREVILLE Makokou,
*XOwendo
*Kango
.
Cap Booue
L
opez
*Port-Gentil-~*Lambaréné -astoursville
Koulamoutou,
Moanda
Franceville”
Gam bat Tehibanga
THE CONGO
Lucina sy. 0 50 100km
Terminal g : =
Disputes—International: UN urges Equatorial Guinea and
Gabon to resolve the sovereignty dispute over Gabon-
occupied Mbane Island and lesser islands and to establish a
maritime boundary in hydrocarbon-rich Corisco Bay
Trafficking in persons: Current situation: Gabon is primarily a
destination and transit country for adults and children from
West and Central African countries subjected to forced
labor and sex trafficking; boys are forced to work as street
vendors, mechanics, or in the fishing sector, while girls are
subjected to domestic servitude or forced to work in
markets or roadside restaurants; West African women are
forced into domestic servitude or prostitution; men are
reportedly forced to work on cattle farms; some foreign
adults end up in forced labor in Gabon after initially
seeking the help of human smugglers to help them migrate
clandestinely; traffickers operate in loose, ethnic-based
criminal networks, with female traffickers recruiting and
facilitating the transport of victims from source countries;
in some cases, families turn child victims over to
traffickers, who promise paid jobs in Gabon tier rating: Tier 2
Watch List—Gabon does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; Gabon’s existing laws
do not prohibit all forms of trafficking, and the government
failed to pass a legal amendment drafted in 2013 to
criminalize the trafficking of adults; anti-trafficking law
enforcement decreased in 2014, dropping from 50
investigations to 16, and the only defendant to face
prosecution fled the country; government efforts to identify
and refer victims to protective services declined from 50
child victims in 2013 to just 3 in 2014, none of whom was
referred to a care facility; the government provided support
to four centers offering services to orphans and vulnerable
children—14 child victims identified by an NGO received
government assistance; no adult victims have been
identified since 2009 (2015) GAMBIA, THE
Disputes—International: attempts to stem refugees, cross-
border raids, arms smuggling, and other illegal activities by
separatists from southern Senegal’s Casamance region, as
well as from conflicts in other west African states Trafficking
in persons: Current situation: The Gambia is a source and
destination country for women and children subjected to
forced labor and sex trafficking; Gambian women, girls,
and, to a lesser extent, boys are exploited for prostitution
and domestic servitude; women, girls, and boys from West
African countries are trafficked to The Gambia for
commercial sexual exploitation, particularly by European
sex tourists; boys in some Koranic schools are forced into
street vending or begging; some Gambian children have
been identified as victims of forced labor in neighboring
West African countries tier rating: Tier 3—The Gambia does
not fully comply with the minimum standards for the
elimination of trafficking and is not making significant
efforts to do so; the government demonstrated minimal
anti-trafficking law enforcement efforts, investigating one
trafficking case but not prosecuting or convicting any
offenders in 2014; authorities did not investigate,
prosecute, or convict any government employees complicit
in trafficking, although corruption was a serious problem;
the government identified and repatriated 19 Gambian girls
subjected to domestic servitude in Lebanon but did not
identify or provide protective services to any trafficking
victims in The Gambia; a government program continued to
provide resources and financial support to 12 Koranic
schools on the condition that their students were not forced
to beg (2015) GAZA STRIP','66d258eee68a7847d3e3d493565b51b2a9839f31e1441f940cafdc54d6f6c055','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16b99b652848da437ca0cd08ca0bc1835b0a9d8007276cd1501f6893f2c25502',2021,'IL','Israel','transnational-issues',535,'Disputes—International: the status of the Gaza Strip is a final
status issue to be resolved through negotiations; Israel
removed settlers and military personnel from Gaza Strip in
September 2005
Refugees and internally displaced persons: refugees (country of
origin): 1,421,282 (Palestinian refugees) (2019) IDPs:
238,000 (includes persons displaced within the Gaza Strip
due to the intensification of the Israeli-Palestinian conflict
since June 2014 and other Palestinian IDPs in the Gaza
Strip and West Bank who fled as long ago as 1967,
although confirmed cumulative data do not go back beyond
2006) (2018) GEORGIA
Nahariyya,
“Haifa
Nazarettt
Hadera 7
Netanya;
Z
¢
-Petah Tiqwa
Bat Yamstolon, Wost
Rishon LeZiyyon” \\, Bank
Ashdod, ‘
Tel Aviv-Yafo'',
te
Jerusalem_¢
yA
A s
rn Ashgelon ¢
Gaza ‘. {
-Seersheba
~Dimona','18b3a51a9e35b3d5461f93d86a6edee91a151514feb6ddce01322f11f477ae2e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('647d1c80b551c5329f7d217038d6b12aaab94856a1e404001b7d68933450fb0d',2021,'AT','Austria','transnational-issues',545,'Disputes—International: NONe
Refugees and internally displaced persons: refugees (country of
origin): 532,065 (Syria), 136,463 (Iraq), 126,018
(Afghanistan), 55,334 (Eritrea), 41,150 (Iran), 24,036
(Turkey), 23,581 (Somalia), 9,155 (Serbia and Kosovo),
8,119 (Russia), 7,454 (Pakistan), 6,453 (Nigeria) (2018)
stateless persons: 14,779 (2018)
Illicit drugs: Source of precursor chemicals for South
American cocaine processors; transshipment point for and
consumer of Southwest Asian heroin, Latin American
cocaine, and European-produced synthetic drugs; major
financial center
Bolgatanga .
i
{
*
Jamale
D''IVOIRE Suriyani
.
Kumasi
,Obuasi
Koforidua®
ACCRA,,
Cape * Tema
a | Coast,
Takoradi,
Disputes—International: disputed maritime border between
Ghana and Cote d’Ivoire
Refugees and internally displaced persons: refugees (country of
origin): 6,524 (Cote d''Ivoire) (flight from 2010 post-election
fighting) (2019) IDPs: 5,000 (land disputes between ethnic
communities in the north in 2018) (2018)
Trafficking in persons: Current situation: Ghana is a source,
transit, and destination country for men, women, and
children subjected to forced labor and sex trafficking; the
trafficking of Ghanians, particularly children, internally is
more common than the trafficking of foreign nationals;
Ghanian children are subjected to forced labor in fishing,
domestic service, street hawking, begging, portering,
mining, quarrying, herding, and agriculture, with girls, and
to a lesser extent boys, forced into prostitution; Ghanian
women, sometimes lured with legitimate job offers, and
girls are sex trafficked in West Africa, the Middle East, and
Europe; Ghanian men fraudulently recruited for work in the
Middle East are subjected to forced labor or prostitution,
and a few Ghanian adults have been identified as victims of
false labor in the US; women and girls from Vietnam,
China, and neighboring West African countries are sex
trafficked in Ghana; the country is also a transit point for
sex trafficking from West Africa to Europe tier rating: Tier 2
Watch List—Ghana does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; Ghana continued to
investigate and prosecute trafficking offenses but was
unable to ramp up its anti-trafficking efforts in 2014
because the government failed to provide law enforcement
or protection agencies with operating budgets; victim
protection efforts decreased in 2014, with significantly
fewer victims identified; most child victims were referred to
NGO-run facilities, but care for adults was lacking because
the government did not provide any support to the
country’s Human Trafficking Fund for victim services or its
two shelters; anti-trafficking prevention measures
increased modestly, including reconvening of the Human
Trafficking Management Board, public awareness
campaigns on child labor and _ trafficking, and anti-
trafficking TV and radio programs (2015) Mlicit drugs: illicit
producer of cannabis for the international drug trade;
major transit hub for Southwest and Southeast Asian
heroin and, to a lesser extent, South American cocaine
destined for Europe and the US; widespread crime and
money-laundering problem, but the lack of a_ well-
developed financial infrastructure limits the country’s
utility as a money-laundering center; significant domestic
cocaine and cannabis use GIBRALTAR','fe44f0e6d6d06bd060be49bae602041d1ca88b1d36df236ad91a32fc5cb43be6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b49550cfb9217a3b0d65a3c46bfc144f41e9d943ca3fb880e1bdce52b6f6a448',2021,'GI','Gibraltar','transnational-issues',552,'Disputes—International: in 2002, Gibraltar residents voted
overwhelmingly by referendum to reject any “shared
sovereignty” arrangement; the Government of Gibraltar
insists on equal participation in talks between the UK and
Spain; Spain disapproves of UK plans to grant Gibraltar
even greater autonomy GREECE
Kavala, Alexandroupolis
Thessajoniki “4
Kerhyya doannina
° risa®
igoumenitsa
2, .
Patrat
Piraeus
ifakleion
Crete
Islands of Megisti, Ro, and
Strongylf are not,shown.','fc982f5ba71f00b87cd5986aa7c72b90e9b7d29c80567809383e0df6028f2d16','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34355649f626870ebf0e81b81c37a5ac5efde8e5fabea86a64e451d84e937332',2021,'GD','Grenada','transnational-issues',560,'Disputes—International: NONe
Illicit drugs: Small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
«Tamuning
*HAGATNA
(Agana)
»Merizo
Cocos J
Island
Disputes—International: NONe','4476f0318fad831b94af62c8d01db389dc69c453e2aa05996b59dd24f2e7f248','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b6921c738a22dd713dc31fb23a2c883a1e48d48008979bc1922fbf1048c281d',2021,'MX','Mexico','transnational-issues',563,'Puerto Barlos:
Puerto Santo Tomas
Coban, de Castilla
eHuehuetenango
Volcan
Tajumuico
Quetzaltenango
eCoatepeque UATEMALA
. Cl
a
. Mixcotx
*.
Mazatenango Vill
Disputes—International: abundant rainfall in recent years along
much of the Mexico-US border region has ameliorated
periodically strained water-sharing arrangements; the US
has intensified security measures to monitor and control
legal and illegal personnel, transport, and commodities
across its border with Mexico; Mexico must deal with
thousands of impoverished Guatemalans and other Central
Americans who cross the porous border looking for work in
Mexico and the US; Belize and Mexico are working to solve
minor border demarcation discrepancies arising from
inaccuracies in the 1898 border treaty Refugees and internally
displaced persons: refugees (country of origin): 5,155 (El
Salvador) (2018); 64,053 (Venezuela) (economic and
political crisis; includes Venezuelans who have claimed
asylum or have received alternative legal stay) (2019) IDPs:
338,000 (government’s quashing of Zapatista uprising in
1994 in eastern Chiapas Region; drug cartel violence and
government’s military response since 2007; violence
between and within indigenous groups) (2018) stateless
persons: 13 (2018)
Illicit drugs: Major drug-producing and transit nation; Mexico
is estimated to be the world’s third largest producer of
opium with poppy cultivation in 2015 estimated to be
28,000 hectares yielding a potential production of 475
metric tons of raw opium; government conducts the largest
independent illicit-crop eradication program in the world;
continues as the primary transshipment country for US-
bound cocaine from South America, with an estimated 95%
of annual cocaine movements toward the US stopping in
Mexico; major drug syndicates control the majority of drug
trafficking throughout the country; producer’ and
distributor of ecstasy; significant money-laundering center;
major supplier of heroin and largest foreign supplier of
Marijuana and methamphetamine to the US market','245b0bc5b2438dcba9b42ca1d698c9f0d9743dfc449403df37df726520d8e119','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a4980330e82b42c6f9964d0993b81d2723c588b0b605e87076fd4e19aba2cd',2021,'LR','Liberia','transnational-issues',580,'Disputes—International: Sierra Leone considers Guinea’s
definition of the flood plain limits to define the left bank
boundary of the Makona and Moa Rivers excessive and
protests Guinea’s continued occupation of these lands,
including the hamlet of Yenga, occupied since 1998
Trafficking in persons: Current situation: Guinea is a source,
transit, and, to a lesser extent, a destination country for
men, women, and children subjected to forced labor and
sex trafficking; the majority of trafficking victims are
Guinean children, and trafficking is more prevalent among
Guineans than foreign national migrants; Guinean girls are
subjected to domestic servitude and commercial sexual
exploitation, while boys are forced to beg or to work as
street vendors, shoe shiners, or miners; Guinea is a source
country and transit point for West African children forced
to work as miners in the region; Guinean women and girls
are subjected to domestic servitude and sex trafficking in
West Africa, the Middle East, the US, and increasingly
Europe, while Thai, Chinese, and Vietnamese women are
forced into prostitution and some West Africans are forced
into domestic servitude in Guinea tier rating: Tier 2 Watch
List—Guinea does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; in 2014, Guinea was
granted a waiver from an otherwise required downgrade to
Tier 3 because its government has a written plan that, if
implemented would constitute making significant efforts to
bring itself into compliance with the minimum standards
for the elimination of trafficking; no new investigations
were conducted in 2014, and the one ongoing case led to
the prosecution of four offenders for forced child labor,
three of whom were convicted but given inadequate
sentences for the crime; the government did not identify or
provide protective services to victims and did not support
NGOs that assisted victims but continued to refer child
victims to NGOs on an ad hoc basis; Guinean law does not
prohibit all forms of trafficking, excluding, for example,
debt bondage; the 2014 Ebolavirus outbreak negatively
affected Guinea’s ability to address human trafficking
(2015) GUINEA-BISSAU
THE GAMBIA
. ubmanburg
¢ Robertsport
}, MONROVIA
Disputes—International: aS the UN Mission in Liberia (UNMIL)
continues to drawdown prior to the 1 March 2018 closure
date, the peacekeeping force is being reduced to 434
soldiers and two police units; some Liberian refugees still
remain in Guinea, Cote d''Ivoire, Sierra Leone, and Ghana;
Liberia shelters 8,804 Ivoirian refugees, as of 2019
Refugees and internally displaced persons: refugees (country of
origin): 8,152 (Cote d''Ivoire) (2019) Imlicit drugs:
transshipment point for Southeast and Southwest Asian
heroin and South American cocaine for the European and
US markets; corruption, criminal activity, arms-dealing, and
diamond trade provide significant potential for money
laundering, but the lack of well-developed financial system
limits the country’s utility as a major money-laundering
center
. _RIPOLI Al Bayda’
y Al’ -eMisratah
ums
>
, lobruk
Kh Benghazi
Surt Rast_*Al Buraygah
Lat (Brega)
Lanuf biel
Ghuzayyll
Al Kufrah
Disputes—International: NONe
Illicit drugs: has strengthened money laundering controls, but
money laundering remains a concern due to Liechtenstein’s
sophisticated offshore financial services sector LITHUANIA','764e230ec19da46dbc5a8aaf3ca8e22cfffd686276de9d2fdbcd094837351d8e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cf8e9da09fe067859a2951a81375967f65170753b41f115efdbd6276e0114b3',2021,'SN','Senegal','transnational-issues',581,'“Cached
&
anchungo ,Manséa
BISSAU
Bolamaiy Buba
Disputes—International: Mauritanian claims to Western Sahara
remain dormant
Refugees and internally displaced persons: refugees (country of
origin): 26,001 (Western Saharan Sahrawis) (2018); 56,662
(Mali) (2019) Trafficking in persons: current situation:
Mauritania is a source and destination country for men,
women, and children subjected to forced labor and sex
trafficking; adults and children from traditional slave castes
are subjected to slavery-related practices rooted in
ancestral master-slave relationships; Mauritanian boy
students called talibes are trafficked within the country by
religious teachers for forced begging; Mauritanian girls, as
well as girls from Mali, Senegal, The Gambia, and other
West African countries, are forced into domestic servitude;
Mauritanian women and girls are forced into prostitution
domestically or transported to countries in the Middle East
for the same purpose, sometimes through forced marriages
tier rating: Tier 3—Mauritania does not fully comply with the
minimum standards for the elimination of trafficking and is
not making significant efforts to do so; anti-trafficking law
enforcement efforts were negligible; one slavery case
identified by an NGO was investigated, but no prosecutions
or convictions were made, including among the 4,000 child
labor cases NGOs referred to the police; the 2007 anti-
slavery law remains ineffective because it requires slaves,
most of whom are illiterate, to file their own legal
complaint, and the government agency that can submit
claims on them did not file any in 2014; authorities
arrested, prosecuted, and convicted several anti-slavery
activists; NGOs continued to provide the majority of
protective services to trafficking victims without support
from the government; some steps were taken to raise
public awareness about human _ trafficking (2015)','216c4503596ec7617596b1e73e98df1434713d9fb00600b48e626fc1e63202ed','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01b2879ad6db4734ee42354fb1793313930721eea656bbe3c98c93ca7abb7f54',2021,'IE','Ireland','transnational-issues',601,'Disputes—International: Ireland, Iceland, and the UK dispute
Denmark’s claim that the Faroe Islands’ continental shelf
extends beyond 200 nm Refugees and internally displaced
persons: stateless persons: 99 (2018)
Illicit drugs: transshipment point for and consumer of hashish
from North Africa to the UK and Netherlands and of
European-produced synthetic drugs; increasing
consumption of South American cocaine; minor
transshipment point for heroin and cocaine destined for
Western Europe; despite recent legislation, narcotics-
related money laundering—using bureaux de _ change,
trusts, and shell companies involving the offshore financial
community—remains a concern ISLE OF MAN
"Peel
DOUGLAS,
Castletown
Disputes—International: NONe','a8303db454f0e081f1c25f1b33ea030c90985ac83b7a40c4a69ad427eb374997','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fddd727670d2ffac054cfbadd0594e6a890e7f15c96b31e20b0339817087c2b6',2021,'EG','Egypt','transnational-issues',603,'(Sinai)
Disputes—International: West Bank and Gaza Strip are Israeli-
occupied with current status subject to the _ Israeli-
Palestinian Interim Agreement—permanent status to be
determined through further negotiation; Israel continues
construction of a “seam line” separation barrier along parts
of the Green Line and within the West Bank; Israel
withdrew its settlers and military from the Gaza Strip and
from four settlements in the West Bank in August 2005;
Golan Heights is Israeli-controlled (Lebanon claims the
Shab’a Farms area of Golan Heights); since 1948, about
350 peacekeepers from the UN _ Truce Supervision
Organization headquartered in Jerusalem monitor
ceasefires, supervise armistice agreements, prevent
isolated incidents from escalating, and assist other UN
personnel in the region Refugees and internally displaced persons:
refugees (country of origin): 14,516 (Eritrea) (2018), 7,857
(Ukraine) (2019) stateless persons: 42 (2018)
Illicit drugs: increasingly concerned about ecstasy, cocaine,
and heroin abuse; drugs arrive in country from Lebanon
and, increasingly, from Jordan; money-laundering center','48b0b413b228825ddd34ee7a3f357e69415e0cb3f92e4e1f99eedca059dcd67e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3a420bed523195520925936928d6cea4f06c026b10c97b3b6ea1e3d9c3e9ddb',2021,'HU','Hungary','transnational-issues',607,'A ee
sel; Milan, Verona Triest CROATIA
Turin *Venice
Genoa, Bologna, Ravenna
9 MARINO
Livornc, Florence
Corsica
sie ROME
VAT cat :
Tea Naples ae
a Salerno. : Peay”
a
Cagliari
Messin:
Palermo, °°S*s, Reggio di Calabria
Sicily ‘Catania
AUQUStA® weeny
Panketeria Melilli Oil Terminal
TUNISIA = (eS
100 200 mi
Background: Italy became a nation-state in 1861 when the
regional states of the peninsula, along with Sardinia and
Sicily, were united under King Victor EMMANUEL II. An
era of parliamentary government came to a close in the
early 1920s when Benito MUSSOLINI established a Fascist
dictatorship. His alliance with Nazi Germany led to Italy’s
defeat in World War II. A democratic republic replaced the
monarchy in 1946 and economic revival followed. Italy is a
charter member of NATO and the European Economic
Community (EEC) and its subsequent successors the EC
and the EU. It has been at the forefront of European
economic and political unification, joining the Economic
and Monetary Union in 1999. Persistent problems include
sluggish economic growth, high youth and female
unemployment, organized crime, corruption, and economic
disparities between southern Italy and the more prosperous
north.
Disputes—International: Italy’s long coastline and developed
economy entices tens of thousands of illegal immigrants
from southeastern Europe and northern Africa Refugees and
internally displaced persons: refugees (country of origin):
22,319 (Nigeria), 18,249 (Pakistan), 16,941 (Afghanistan),
15,003 (Mali), 13,373 (Somalia), 12,549 (Gambia), 13,525
(Ukraine), 7,644 (Senegal), 7,174 (Cote d’Ivoire), 6,975
(Eritrea) (2018); note—estimate for Ukraine represents
asylum applicants since the beginning of the Ukraine crisis
in 2014 to July 2018
stateless persons: 732 (2018)
note: 490,358 estimated refugee and migrant arrivals by
sea (January 2015-January 2020); hosts an estimated
108,924 migrants and asylum seekers as of the end of June
2019; 23,370 arrivals in 2018
Illicit drugs: important gateway for and consumer of Latin
American cocaine and Southwest Asian heroin entering the
European market; money laundering by organized crime
and from smuggling','1a0270dfb51470f78b69b03147c48457210790a189324941ce612790f370210b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcc8a1cce334e368dd22da3a7dd6eddb564b9efec2e0bb9bf6cb8b34ce2d4201',2021,'CU','Cuba','transnational-issues',615,'Disputes—International: NONe
Trafficking in persons: Current situation: Jamaica is a source
and destination country for children and adults subjected to
sex trafficking and forced labor; sex trafficking of children
and adults occurs on the street, in night clubs, bars,
massage parlors, and private homes; child sex tourism is a
problem in resort areas; Jamaicans have been subjected to
sexual exploitation or forced labor in the Caribbean,
Canada, the US, and the UK, while foreigners have endured
conditions of forced labor in Jamaica or aboard foreign-
flagged fishing vessels operating in Jamaican waters; a high
number of Jamaican children are reported missing tier
rating: Tier 2 Watch List - Jamaica does not fully comply
with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; in 2014, the government made significant efforts to
raise public awareness of human trafficking, and named a
national trafficking-in-persons rapporteur - the first in the
region; authorities initiated more _ new _ trafficking
investigations than in 2013 and concluded a trafficking
case in the Supreme Court, but chronic delays impeded
prosecutions and no offenders were convicted for the sixth
consecutive year; more adult trafficking victims were
identified than in previous years, but only one child victim
was identified, which was exceptionally low relative to the
number of vulnerable children (2015) Mlicit drugs:
transshipment point for cocaine from South America to
North America and Europe; illicit cultivation and
consumption of cannabis; government has an active manual
cannabis eradication program; corruption is a major
concern; substantial money-laundering activity; Colombian
narcotics traffickers favor Jamaica for illicit financial
transactions JAN MAYEN
a : -
meteorological station
a
Loran-C
station
Disputes—International: NONe
Hiroshima Kobe 4s, joya
“Kitakyushu
Shikoku
Fukuoka
Kagoshima. yusnu','e2b29a14f323ffabb2c7aab37b00f7748424ecf725f3525427f9305da1483ff7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdb9dae0d4c18a8450aede383d2fc6c64918c2945e794713861b1f938d05ee90',2021,'JO','Jordan','transnational-issues',623,'Disputes—International: 2004 Agreement settles border
dispute with Syria pending demarcation Refugees and
internally displaced persons: refugees (country of origin):
2,242,579 (Palestinian refugees), 67,266 (Iraq), 14,730
(Yemen), 6,116 Sudan (2019); 654,692 (Syria) (2020)','cfb7bdd1da10c608dcf302609a5cbf0cbce52cf23629d1635f0f2c11c3e28557','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39cf524fed2ef45a302b693820b70ccaa335d9e118afde910a744b0234907405',2021,'KZ','Kazakhstan','transnational-issues',638,'Disputes—International: Kenya served aS an _ important
mediator in brokering Sudan’s north-south separation in
February 2005; as of March 2019, Kenya provides shelter
to nearly 475,000 refugees and asylum seekers, including
Ugandans who flee across the border periodically to seek
protection from Lord’s Resistance Army rebels; Kenya
works hard to prevent the clan and militia fighting in
Somalia from spreading across the border, which has long
been open to nomadic pastoralists; the boundary that
separates Kenya’s and Sudan’s sovereignty is unclear in the
“Tlemi Triangle,” which Kenya has administered since
colonial times Refugees and internally displaced persons: refugees
(country of origin): 256,408 (Somalia) (refugees and asylum
seekers), 119,799 (South Sudan) (refugees and asylum
seekers), 43,576 (Democratic Republic of the Congo)
(refugees and asylum seekers), 27,989 (Ethiopia) (refugees
and asylum seekers), 14,674 (Burundi) (refugees and
asylum seekers), 10,011 (Sudan) (refugees and asylum
seekers) (2019) IDPs: 162,000 (election-related violence,
intercommunal violence, resource conflicts, al-Shabaab
attacks in 2017 and 2018) (2018) stateless persons: 18,500
(2018); note—the stateless population consists of Nubians,
Kenyan Somalis, and coastal Arabs; the Nubians are
descendants of Sudanese soldiers recruited by the British
to fight for them in East Africa more than a century ago;
Nubians did not receive Kenyan citizenship when the
country became independent in 1963; only recently have
Nubians become a formally recognized tribe and had less
trouble obtaining national IDs; Galjeel and other Somalis
who have lived in Kenya for decades are included with
more recent Somali refugees and denied ID cards Illicit
drugs: widespread harvesting of small plots of marijuana;
transit country for South Asian heroin destined for Europe
and North America; Indian methaqualone also transits on
way to South Africa; significant potential for money-
laundering activity given the country’s status as a regional
financial center; massive corruption, and relatively high
levels of narcotics-associated activities KIRIBATI
Disputes—International: NONe
Disputes—International: prolonged drought and_ cotton
monoculture in Uzbekistan and Turkmenistan created
water-sharing difficulties for Amu Darya river states; field
demarcation of the boundaries with Kazakhstan
commenced in 2004; border delimitation of 130 km of
border with Kyrgyzstan is hampered by serious disputes
around enclaves and other areas Refugees and internally
displaced persons: stateless persons: 79,942 (2018)
Trafficking in persons: Current situation: Uzbekistan is a source
country for men, women, and children subjected to forced
labor and women and children subjected to sex trafficking;
government-compelled forced labor of adults remained
endemic during the 2014 cotton harvest; despite a decree
banning the use of persons under 18, children were
mobilized to harvest cotton by local officials in some
districts; in some regions, local officials forced teachers,
students, private business employees, and others to work in
construction, agriculture, and cleaning parks; Uzbekistani
women and children are victims of sex _ trafficking
domestically and in the Middle East, Eurasia, and Asia;
Uzbekistani men and, to a lesser extent, women are
subjected to forced labor in Kazakhstan, Russia, and
Ukraine in the construction, oil, agriculture, retail, and
food sectors tier rating: Tier 2 Watch List - Uzbekistan does
not fully comply with the minimum standards for the
elimination of trafficking; however, it is making significant
efforts to do so; law enforcement efforts in 2014 were
mixed; the government made efforts to combat sex and
transnational labor trafficking, but government-compelled
forced labor of adults in the cotton harvest went
unaddressed, and the decree prohibiting forced child labor
was not applied universally; official complicity in human
trafficking in the cotton harvest remained prevalent;
authorities made efforts to identify and protect sex and
transnational labor victims, although a systematic process
is still lacking; minimal efforts were made to assist victims
of forced labor in the cotton harvest, as the government
does not openly acknowledge the existence of this forced
labor; the ILO did not have permission or funding to
monitor the 2014 harvest, but the government authorized
the UN’s International Labour Organization to conduct a
survey on recruitment practices and working conditions in
agriculture, particularly the cotton sector, and to monitor
the 2015-17 cotton harvests for child and forced labor in
project areas (2015) Itlicit drugs: transit country for Afghan
narcotics bound for Russian and, to a lesser extent,
Western European markets; limited illicit cultivation of
cannabis and small amounts of opium poppy for domestic
consumption; poppy cultivation almost wiped out by
government crop eradication program; transit point for
heroin precursor chemicals bound for Afghanistan','549b90c4a72c7f4815ee5e9f6ba02b3886da751cb3927154780da8e2a4a43e8f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('153d7bf5549e746cb54a89f717048f493e49e824f3463b6422b45e7d8cff14b5',2021,'RS','Serbia','transnational-issues',648,'Disputes—International: Serbia with several other states
protest the US and other states’ recognition of Kosovo’s
declaration of its status as a sovereign and independent
state in February 2008; ethnic Serbian municipalities along
Kosovo’s northern border challenge final status of Kosovo-
Serbia boundary; NATO-led Kosovo Force peacekeepers
under UN Interim Administration Mission in Kosovo
authority continue to ensure a safe and secure environment
and freedom of movement for all Kosovo citizens; Kosovo
and North Macedonia completed demarcation of their
boundary in September 2008; Kosovo ratified the border
demarcation agreement with Montenegro in March 2018,
but the actual demarcation has not been completed Refugees
and internally displaced persons: IDPs: 16,000 (primarily ethnic
Serbs displaced during the 1998-1999 war fearing reprisals
from the majority ethnic-Albanian population; a smaller
number of ethnic Serbs, Roma, Ashkali, and Egyptians fled
their homes in 2,004 as a result of violence) (2018)
Disputes—International: Serbia with several other states
protest the US and other states’ recognition of Kosovo’s
declaration of its status as a sovereign and independent
state in February 2008; ethnic Serbian municipalities along
Kosovo’s northern border challenge final status of Kosovo-
Serbia boundary; several thousand NATO-led Kosovo Force
peacekeepers under UN Interim Administration Mission in
Kosovo authority continue to keep the peace within Kosovo
between the ethnic Albanian majority and the Serb
minority in Kosovo; Serbia delimited about half of the
boundary with Bosnia and Herzegovina, but sections along
the Drina River remain in dispute Refugees and internally
displaced persons: refugees (country of origin): 18,232
(Croatia), 8,270 (Bosnia and Herzegovina) (2018) IDPs:
199,584 (most are Kosovar Serbs, some are Roma,
Ashkalis, and Egyptian (RAE); some RAE IDPs are
unregistered) (2019) stateless persons: 2,052 (includes
stateless persons in Kosovo) (2018)
note: 711,340 estimated refugee and migrant arrivals
(fanuary 2015-January 2020); Serbia is predominantly a
transit country and hosts an estimated 3,404 migrants and
asylum seekers as of the end of September 2019; 8,827
migrant arrivals in 2018
Illicit drugs: transshipment point for Southwest Asian heroin
moving to Western Europe on the Balkan route; economy
vulnerable to money laundering SEYCHELLES
Oo 6Skm
eo
° S mi
ttorme_ VICTORIA
Seyrhelios Pes
ALDABRA
ISLANDS pion de PROVIDENCE
jolado ATOLL
ATOLL DE
FARQUHAR
0 100 200km
| ey ener |
100
i) 200 mi','8eabe1af6740106c54ffdc9d973014ae5da4b6aeae87ffd88f015b8cdd7a170a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85b5baf9cb21ded77a34702f532fbb6f2939fbc3754d83258b4696efb187ba26',2021,'KW','Kuwait','transnational-issues',649,'Warbah
ra
Ar Rawdatayn,
Babiyan.
KUWAIT.
Ash Shuwaykhor, As Salimiyah
Al Jahra Jalibe Hawalli
ash Shuydkh
Mina’ al Ahmadi,
Mina’*
‘Abd Allah
Qardh
Az Zawr
(Mina’ Sa‘dd)?
SAUDI ARABIA “alWatrah | imal
Umm al
we
Q 20 40 ken
9 20 40m
Disputes—International: Southeast Asian states have enhanced
border surveillance to check the spread of avian flu; talks
continue on completion of demarcation with Thailand but
disputes remain over islands in the Mekong River;
Cambodia and Laos have a _ longstanding border
demarcation dispute; concern among Mekong River
Commission members that China’s construction of eight
dams on the Upper Mekong River and construction of more
dams on its tributaries will affect water levels, sediment
flows, and fisheries; Cambodia and Vietnam are concerned
about Laos’ extensive plans for upstream dam construction
for the same reasons Trafficking in persons: Current situation:
Laos is a source and, to a lesser extent, transit and
destination country for men, women, and _ children
subjected to forced labor and sex trafficking; Lao economic
migrants may encounter conditions of forced labor or
sexual exploitation in destination countries, most often
Thailand; Lao women and girls are exploited in Thailand’s
commercial sex trade, domestic service, factories, and
agriculture; a small, possibly growing, number of Lao
women and girls are sold as brides in China and South
Korea and subsequently sex trafficked; Lao men and boys
are victims of forced labor in the Thai fishing, construction,
and agriculture industries; some Lao children, as well as
Vietnamese and Chinese women and girls, are subjected to
sex trafficking in Laos; other Vietnamese and Chinese, and
possibly Burmese, adults and girls transit Laos for sexual
and labor exploitation in neighboring countries,
particularly Thailand tier rating: Tier 2 Watch List—Laos
does not fully comply with the minimum standards for the
elimination of trafficking; however, it is making significant
efforts to do so; authorities sustained moderate efforts to
investigate, prosecute, and convict trafficking offenders;
the government failed to make progress in proactively
identifying victims exploited within the country or among
those deported from abroad; the government continues to
rely almost entirely on local and international organizations
to provide and fund services to trafficking victims; although
Lao men and boys are trafficked, most protective services
are only available to women and girls, and long-term
support is lacking; modest prevention efforts include the
promotion of anti-trafficking awareness on state-controlled
media (2015) Illicit drugs: estimated opium poppy cultivation
in 2015 was estimated to be 5,700 hectares, compared with
6,200 hectares in 2014; estimated potential production of
between 84 and 176 mt of raw opium; unsubstantiated
reports of domestic methamphetamine production; growing
domestic methamphetamine problem LATVIA','fda33abdc0a4c4012fa0b914d1546d4b4c2f3a215e09471115ac642a467dfeb6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e25089991c2e03df23cd7c93d13bc3b8cf9decccd0eb671ef90a40122b1212d',2021,'BY','Belarus','transnational-issues',660,'0 BW 60km
oO
° w 60 ms
RUSSIA
Disputes—International: Russia demands better Latvian
treatment of ethnic Russians in Latvia; boundary
demarcated with Latvia and Lithuania; the Latvian
parliament has not ratified its 1998 maritime boundary
treaty with Lithuania, primarily due to concerns over oil
exploration rights; as a member state that forms part of the
EU’s external border, Latvia has implemented the strict
Schengen border rules with Russia Refugees and internally
displaced persons: Stateless persons: 224,844 (2018); note—
individuals who were Latvian citizens prior to the 1940
Soviet occupation and their descendants were recognized
as Latvian citizens when the country’s independence was
restored in 1991; citizens of the former Soviet Union
residing in Latvia who have neither Latvian nor other
citizenship are considered non-citizens (officially there is
no statelessness in Latvia) and are entitled to non-citizen
passports; children born after Latvian independence to
stateless parents are entitled to Latvian citizenship upon
their parents’ request; non-citizens cannot vote or hold
certain government jobs and are exempt from military
service but can travel visa-free in the EU under the
Schengen accord like Latvian citizens; non-citizens can
obtain naturalization if they have been permanent residents
of Latvia for at least five years, pass tests in Latvian
language and history, and know the words of the Latvian
national anthem Illicit drugs: transshipment and destination
point for cocaine, synthetic drugs, opiates, and cannabis
from Southwest Asia, Western Europe, Latin America, and
neighboring Baltic countries; despite improved legislation,
vulnerable to money laundering due _ to _ nascent
enforcement capabilities and comparatively weak
regulation of offshore companies and the gaming industry;
CIS organized crime (including counterfeiting, corruption,
extortion, stolen cars, and prostitution) accounts for most
laundered proceeds LEBANON','4d3b556aeceafc26aec1bdba5cef13c3096c2d19c24f511de574ab140177af08','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52af61211204d3f1dd9438f860d6a1abf3e930f637b03e356a2d2baf03709d80',2021,'LV','Latvia','transnational-issues',677,'*Mageikiai
*Bitingé Siauliai
, Klaipéda ,Panevezys
Utena
Kédainiai
vonava
Kaunas* VILNIUS
Marijampolé *
Alytus
RUSSIA
POLAND BELARUS
0 30 =60km
eC ’
0 x) 60 mi
Disputes—International: Lithuania and Russia committed to
demarcating their boundary in 2006 in accordance with the
land and maritime treaty ratified by Russia in May 2003
and by Lithuania in 1999; Lithuania operates a simplified
transit regime for Russian nationals traveling from the
Kaliningrad coastal exclave into Russia, while still
conforming, as a EU member state having an external
border with a non-EU member, to strict Schengen border
rules; boundary demarcated with Latvia and Lithuania; as
of January 2007, ground demarcation of the boundary with
Belarus was complete and mapped with final ratification
documents in preparation Refugees and internally displaced
persons: Stateless persons: 3,039 (2018) Illicit drugs:
transshipment and destination point for cannabis, cocaine,
ecstasy, and opiates from Southwest Asia, Latin America,
Western Europe, and neighboring Baltic countries; growing
production of high-quality amphetamines, but limited
production of cannabis, methamphetamines; susceptible to
money laundering despite changes to banking legislation','a3c3cb1ab366777030382ce0471f2895dd61eb99c4233472073c21ed3df08fd6','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf0842dced9dd6700e956c5dcaa3dbd1e37faf7aaf87794db35fbcfcac6e854b',2021,'LU','Luxembourg','transnational-issues',678,'Pétange
Differdange
Disputes—International: NONe
Refugees and internally displaced persons: stateless persons: 83
(2018)
Hengquin Dao Coloane
1) 1 2km
EE','a98e1e825863eb7aa9c9af8d9ad399db3e0339744ca2132bdb81dab2e6c61cb8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0640ca719a20ede1860fa5b46e7303227245e6eddcdd5ad1bc5483e4ec551fc',2021,'MG','Madagascar','transnational-issues',686,'Glorioso Islands
* (FRANCE
Disputes—International: Claims Bassas da India, Europa Island,
Glorioso Islands, and Juan de Nova Island (all administered
by France); the vegetated drying cays of Banc du Geyser,
which were claimed by Madagascar in 1976, also fall within
the EEZ claims of the Comoros and France (Glorioso
Islands, part of the French Southern and Antarctic Lands)
Ilicit drugs: illicit producer of cannabis (cultivated and wild
varieties) used mostly for domestic consumption;
transshipment point for heroin MALAWI
Nkhotak
oo MOZAMBIQUE
LILONGWE
p *® Chi
Zomba,
MOZAMBIQUE 5
Blantyre
Disputes—International: Mauritius and Seychelles claim the
Chagos Islands (UK-administered British Indian Ocean
Territory)','ef6dd3d20b1257c9e88d9a1cfb0fe9d906ec1d1b95dd913388a46a9708985a4b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb5ee046ddfb031b9ba70048909734251507e10a43e94c86a973f39e55f020f1',2021,'KM','Comoros','transnational-issues',687,': Antsiratiand,.
* Mahajanga
Amparafaravola,
Toamasina J
nosy ) ANTANANARIVO,
BARREN
Antanifotsy
Antsirabe, °
*
Morondava
Mananjary
Fianarantsoa, 9
Manakara / {NDIAN
OCEAN
,Joliara
Ambovo
Paditiedi lt ah “Télaharo','cb9e1275852ee91372f74eed8353d98403428fd0a4f44a1a61e510ab394cc860','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('832ad1bb119f38b2e5ade5f84bf664e1f65c0d19fd1252b0cf17f135bcfba382',2021,'DZ','Algeria','transnational-issues',701,'Disputes—International: demarcation is underway with Burkina
Faso
Refugees and internally displaced persons: refugees (country of
origin): 15,319 (Mauritania), 8,457 (Burkina Faso) (2019)
IDPs: 199,385 (Tuareg rebellion since 2012) (2019)
Trafficking in persons: Current situation: Mali is a source,
transit, and destination country for men, women, and
children subjected to forced labor and sex trafficking;
internal trafficking is more prevalent than transnational
trafficking, but foreign women and girls are forced into
domestic servitude, agricultural labor, and support roles in
gold mines, as well as subjected to sex trafficking; Malian
boys are forced to work in agricultural settings, gold mines,
the informal commercial sector and to beg within Mali and
neighboring countries; Malians and other Africans who
travel through Mali to Mauritania, Algeria, or Libya in
hopes of reaching Europe are particularly at risk of
becoming victims of human trafficking; men and boys,
primarily of Songhai ethnicity, are subjected to debt
bondage in the salt mines of Taoudenni in northern Mali;
some members of Mali’s Tamachek community are
subjected to hereditary slavery-related practices; Malian
women and girls are victims of sex trafficking in Gabon,
Libya, Lebanon, and Tunisia; the recruitment of child
soldiers by armed groups in northern Mali decreased tier
rating: Tier 2 Watch List—Mali does not fully comply with
the minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
Mali was granted a waiver from an otherwise required
downgrade to Tier 3 because its government has a written
plan that, if implemented would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking;
officials failed to distribute the 2012 anti-trafficking law to
judicial and law enforcement personnel, perpetuating a
lack of understanding and awareness of the legislation;
anti-trafficking law enforcement efforts decreased in 2014,
with only one case investigated and no prosecutions or
convictions; fewer victims were identified, and the
government did not support the privately funded NGOs and
international organizations it relied upon to provide victims
with services; the government did not conduct any
awareness-raising campaigns, workshops, or _ training
sessions (2015) MALTA
Gozo
Victoria
Kemmuna
Kemmunett 7.
Melliena
San Pawl
il-Bahar
or VALLETTA
Birkirkara-
Qormi
yy Zabbar
International &
: a Abport °\\ Marsaxiokk
Ta''‘Dmejrek Zurrieq, +
Birzebbuga
Rabat,
Tarfaya
Sebkha Tah','55e6706ee944146313924acded1220567159c0856db8cc213385903033468259','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b296a70d7db44af5bca4dca131ffccf0fc5dc7835aadfa640cc0ffbd4f47fc5',2021,'MT','Malta','transnational-issues',702,'Fitfla
Disputes—International: NONe
Refugees and internally displaced persons: stateless persons: 11
(2018) note: 5,254 estimated refugee and migrant arrivals
by sea (January 2015-January 2020)
Illicit drugs: minor transshipment point for hashish from
North Africa to Western Europe','ed19e27c590916638db7746306f780b48b87aa9d2d4e5cdc7d7f0b540def639c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('424cbd544dd3b7d68e14e2d4db145e513621ef962a570be81ce62b98415cf989',2021,'MU','Mauritius','transnational-issues',723,'Agalega Islands, Cargados
Carajos Shoa nd
Shoals, av
jOGNQUES are NOt Shown,
~Gagdlands
5 mi * Triolet
@ PORT LOUIS
Centre®
de Flacq
, Quatre Bomes
.Curepipe
.
Tamarin
Mahébourg®
Chemin
Grenier
. Souillaé
Disputes—International: Mauritius and Seychelles claim the
Chagos Islands; claims French-administered Tromelin
Island Trafficking in persons: Current situation: Mauritius is a
source, transit, and destination country for men, women,
and children subjected to forced labor and sex trafficking;
Mauritian girls are induced or sold into prostitution, often
by peers, family members, or businessmen offering other
forms of employment; Mauritian adults have been identified
as labor trafficking victims in the UK, Belgium, and
Canada, while Mauritian women from Rodrigues Island are
also subject to domestic servitude in Mauritius; Malagasy
women transit Mauritius en route to the Middle East for
jobs as domestic servants and subsequently are subjected
to forced labor; Cambodian men are victims of forced labor
on foreign fishing vessels in Mauritius’ territorial waters;
other migrant workers from East and South Asia and
Madagascar are also subject to forced labor in Mauritius’
manufacturing and construction sectors tier rating: Tier 2
Watch List—Mauritius does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
the government made modest efforts to address child sex
trafficking but none related to adult forced labor; law
enforcement lacks an understanding of trafficking crimes
outside of child sex trafficking, despite increasing evidence
of other forms of human trafficking; authorities made no
trafficking prosecutions or convictions and made modest
efforts to assist a couple of child sex trafficking victims;
officials sustained an extensive public awareness campaign
to prevent child sex trafficking, but no efforts were made to
raise awareness or reduce demand for forced adult or child
labor (2015) Itlicit drugs: consumer and transshipment point
for heroin from South Asia; small amounts of cannabis
produced and consumed locally; significant offshore
financial industry creates potential for money laundering,
but corruption levels are relatively low and the government
appears generally to be committed to regulating its
banking industry','60cbf983f1781e952541d46c5c349cd9d123513c35104eec256a7363e8811acf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6af6552a707bfc10efeeea6142ee2071c67e561030bca2054950b54cb182db4',2021,'UA','Ukraine','transnational-issues',751,'Disputes—International: Moldova and Ukraine operate joint
customs posts to monitor the transit of people and
commodities through Moldova’s break-away Transnistria
region, which remains under the auspices of an
Organization for Security and Cooperation in Europe-
mandated peacekeeping mission comprised of Moldovan,
Transnistrian, Russian, and Ukrainian troops Refugees and
internally displaced persons: refugees (country of origin): 6,779
applicants for forms of legal stay other than asylum
(Ukraine) (2015) stateless persons: 4,451 (2018)
Ilicit drugs: limited cultivation of opium poppy and cannabis,
mostly for CIS consumption; transshipment point for illicit
drugs from Southwest Asia via Central Asia to Russia,
Western Europe, and possibly the US; widespread crime
and underground economic activity MONACO','c167c163d2a53c9832705911d5f14ba0ceec78a38995de45aca90fd4df31accf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78c0c0ebbc3eb0194d498e4ce3c570187c74e323056353b656b2f5c1868d36a',2021,'MN','Mongolia','transnational-issues',764,'Disputes—International: NONe
Refugees and internally displaced persons: stateless persons: 17
(2018)','a6bb8bd835472c43f8bcb6eae90195f173a40c3ad476af70abb24de17aad001e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16d395da0d45b3872c4c94b3240f57f572b9a95e822deabfe2310c99d9ae7295',2021,'AL','Albania','transnational-issues',765,'Ulcinj*
Disputes—International: NONe
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe MOROCCO','73027dd8a2fabbe44dd9d85d1f09f474ff901698bf4095b22879a0b6b8158c5c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b7fca605a958446c75a2c6a0e5814ceefdde3ca182d468869b704a5b008986a',2021,'EH','Western Sahara','transnational-issues',779,'Disputes—International: Claims and administers Western
Sahara whose sovereignty remains unresolved; Morocco
protests Spain’s control over the coastal enclaves of Ceuta,
Melilla, and Penon de Velez de la Gomera, the islands of
Penon de Alhucemas and Islas Chafarinas, and surrounding
waters; both countries claim Isla Perejil (Leila Island);
discussions have not progressed on a comprehensive
maritime delimitation, setting limits on _ resource
exploration and refugee interdiction, since Morocco’s 2002
rejection of Spain’s unilateral designation of a median line
from the Canary Islands; Morocco serves as one of the
primary launching areas of illegal migration into Spain
from North Africa; Algeria’s border with Morocco remains
an irritant to bilateral relations, each nation accusing the
other of harboring militants and arms smuggling; the
National Liberation Front’s assertions of a claim to Chirac
Pastures in southeastern Morocco is a dormant dispute Illicit
drugs: the world’s largest producer and exporter of
cannabis; total production for 2015-2016 growing season
estimated to be 700 metric tons; shipments of hashish
mostly directed to Western Europe; transit point for
cocaine from South America destined for Western Europe;
significant consumer of cannabis MOZAMBIQUE
TANZANIA
Canary Islands
(SPAIN)','69626c77120ba499ea4230f346e8aefc5f51c60014c1f0a0d3905b8c0f8274e5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61b6c97f3810c98dbaead458a98632e81030be87a045101a4fc682a07645e891',2021,'ZM','Zambia','transnational-issues',780,'PembaJ
Cidade
de Nacala ¢
Nampula®
Vila Eduardo
Mondiane
Inhambane,
MAPUTO
INDIAN
OCEAN
0 100 200km
100 200 mi
Kariba
Chinhoyi
HARARE,
A chitungwiza
inyangani','fef1b3f9fcefcc6580e0e1b0317923162966dc09cdf3666559308fff23c53a8a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d607b2acc993085d13575f6ccf826656e4acff4328b80efd206dce9df76dd3',2021,'NR','Nauru','transnational-issues',784,'International
Airport
a,
Parliament
Hi
louse, in
Yaren District
Disputes—International: NONe
NAVASSA ISLAND
Disputes—International: Claimed by Haiti, source of subsistence
rh
n
=
=)
Ko}','2f6e8d09d4fe5985f97f54117d5162cbfa2f2809653dff7a4a25b98c09fd9390','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ac2af57af66c8a32ed17ac19deb92997e27d0d9bedc1da2995b382c7655d00c',2021,'NP','Nepal','transnational-issues',797,'Disputes—International: joint border commission continues to
work on contested sections of boundary with India,
including the 400 sq km dispute over the source of the
Kalapani River; India has instituted a stricter border
regime to restrict transit of illegal cross-border activities
Refugees and internally displaced persons: refugees (country of
origin): 13,509 (Tibet/China), 6,626 (Bhutan) (2018)
stateless persons: undetermined (2016); note—the UNHCR
is working with the Nepali Government to address the
large number of individuals lacking citizenship certificates
in Nepal; smaller numbers of Bhutanese Hindu refugees of
Nepali origin (the Lhotshampa) who were stripped of
Bhutanese nationality and forced to flee their country in
the late 1980s and early 1990s—and undocumented
Tibetan refugees who arrived in Nepal prior to the 1990s—
are considered stateless Illicit drugs: illicit producer of
cannabis and hashish for the domestic and international
drug markets; transit point for opiates from Southeast Asia
to the West NETHERLANDS
LANOS
«ens :
$
ae
Deltzijl,
roningen
e
Leeuwarden
Den
Helder*
WJmuiden, Zoppated Zwolle
Haarleme ” yo «Pimere*
AMSTERDAM) 22 Apeldoorn
e
The Hague, Utrecht Enschede
jdplaspokter _ Arm!
Uw)
.
Europoon Hotterdam 3 ——~s
Nijmegen
Breda +,
Viissingen o etilburg
*.','20c3ae0486a323d5455ac30c493fc8e4ae63359792b0786a3096037f776b69e3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1bfd72c892717a97e7f0930e96eed326f717a342b44d3692d0840e23cb89608',2021,'CR','Costa Rica','transnational-issues',814,'Disputes—International: the 1992 ICJ ruling for El Salvador and
Honduras advised a tripartite resolution to establish a
maritime boundary in the Gulf of Fonseca, which considers
Honduran access to the Pacific; Nicaragua and Costa Rica
regularly file border dispute cases over the delimitations of
the San Juan River and the northern tip of Calero Island to
the ICJ; there is an ongoing case in the ICJ to determine
Pacific and Atlantic ocean maritime borders as well as land
borders; in 2009, the ICJ ruled that Costa Rican vessels
carrying out police activities could not use the river, but
official Costa Rican vessels providing essential services to
riverside inhabitants and Costa Rican tourists could travel
freely on the river; in 2011, the ICJ provisionally ruled that
both countries must remove personnel from the disputed
area; in 2013, the ICJ rejected Nicaragua’s 2012 suit to halt
Costa Rica’s construction of a highway paralleling the river
on the grounds of irreparable environmental damage; in
2013, the ICJ, regarding the disputed territory, ordered that
Nicaragua should refrain from dredging or _ canal
construction and refill and repair damage caused by
trenches connecting the river to the Caribbean and upheld
its 2010 ruling that Nicaragua must remove all personnel;
in early 2014, Costa Rica brought Nicaragua to the ICJ over
offshore oil concessions in the disputed region; Nicaragua
filed a case against Colombia in 2013 over the delimitation
of the Continental shelf beyond the 200 nautical miles from
the Nicaraguan coast, as well as over the alleged violation
by Colombia of Nicaraguan maritime space in the
Caribbean Sea Illicit drugs: transshipment point for cocaine
destined for the US and transshipment point for arms-for-
drugs dealing NIGER','b89c09ff61d3efd333f2e23eea6c32bf0acbae825b076f7119bbe8e17eae6b68','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('798c8cb8ada981fb875119b0f3ff3b5ca140d8e8127aec2b28f1195b193b0e15',2021,'BG','Bulgaria','transnational-issues',827,'.Kumanovo
_Stip
2 :
Golem Gostivar
Korab
Veles*
Strumica,
~Prilep
Bitola
Disputes—International: Russia remains concerned about the
smuggling of poppy derivatives from Afghanistan through
Central Asian countries; China and _ Russia _ have
demarcated the once disputed islands at the Amur and
Ussuri confluence and in the Argun River in accordance
with the 2004 Agreement, ending their centuries-long
border disputes; the sovereignty dispute over the islands of
Etorofu, Kunashiri, Shikotan, and the Habomai group,
known in Japan as the “Northern Territories” and in Russia
as the “Southern Kurils,” occupied by the Soviet Union in
1945, now administered by Russia, and claimed by Japan,
remains the primary sticking point to signing a peace
treaty formally ending World War II hostilities; Russia’s
military support and subsequent recognition of Abkhazia
and South Ossetia independence in 2008 continue to sour
relations with Georgia; Azerbaijan, Kazakhstan, and Russia
ratified Caspian seabed delimitation treaties based on
equidistance, while Iran continues to insist on a one-fifth
slice of the sea; Norway and Russia signed a
comprehensive maritime boundary agreement in 2010;
various groups in Finland advocate restoration of Karelia
(Kareliya) and other areas ceded to the Soviet Union
following World War II but the Finnish Government asserts
no territorial demands; Russia and Estonia signed a
technical border agreement in May 2005, but Russia
recalled its signature in June 2005 after the Estonian
parliament added to its domestic ratification act a historical
preamble referencing the Soviet occupation and Estonia’s
pre-war borders under the 1920 Treaty of Tartu; Russia
contends that the preamble allows Estonia to make
territorial claims on Russia in the future, while Estonian
officials deny that the preamble has any legal impact on the
treaty text; Russia demands better treatment of the
Russian-speaking population in Estonia and Latvia; Russia
remains involved in the conflict in eastern Ukraine while
also occupying Ukraine’s territory of Crimea; Lithuania and
Russia committed to demarcating their boundary in 2006 in
accordance with the land and maritime treaty ratified by
Russia in May 2003 and by Lithuania in 1999; Lithuania
operates a simplified transit regime for Russian nationals
traveling from the Kaliningrad coastal exclave into Russia,
while still conforming, as an EU member state with an EU
external border, where strict Schengen border rules apply;
preparations for the demarcation delimitation of land
boundary with Ukraine have commenced; the dispute over
the boundary between Russia and Ukraine through the
Kerch Strait and Sea of Azov is suspended due to the
occupation of Crimea by Russia; Kazakhstan and Russia
boundary delimitation was ratified on November 2005 and
field demarcation should commence in 2007; Russian Duma
has not yet ratified 1990 Bering Sea Maritime Boundary
Agreement with the US; Denmark (Greenland) and Norway
have made submissions to the Commission on the Limits of
the Continental Shelf (CLCS) and Russia is collecting
additional data to augment its 2001 CLCS submission
Refugees and internally displaced persons: refugees (country of
origin): 75,941 (Ukraine) (2019) stateless persons: 75,679
(2018); note—Russia’s stateless population consists of
Roma, Meskhetian Turks, and ex-Soviet citizens from the
former republics; between 2003 and 2010 more than
600,000 stateless people were _ naturalized; most
Meskhetian Turks, followers of Islam with origins in
Georgia, fled or were evacuated from Uzbekistan after a
1989 pogrom and have lived in Russia for more than the
required five-year residency period; they continue to be
denied registration for citizenship and basic rights by local
Krasnodar Krai authorities on the grounds that they are
temporary illegal migrants Trafficking in persons: Current
situation: Russia is a source, transit, and destination
country for men, women, and children who are subjected to
forced labor and sex trafficking; with millions of foreign
workers, forced labor is Russia’s predominant human
trafficking problem and sometimes involves organized
crime syndicates; workers from Russia, other European
countries, Central Asia, and East and Southeast Asia,
including North Korea and Vietnam, are subjected to forced
labor in the construction, manufacturing, agricultural,
textile, grocery store, maritime, and domestic service
industries, as well as in forced begging, waste sorting, and
street Sweeping; women and children from Europe,
Southeast Asia, Africa, and Central Asia are subject to sex
trafficking in Russia; Russian women and children are
victims of sex trafficking domestically and in Northeast
Asia, Europe, Central Asia, Africa, the US, and the Middle
East tier rating: Tier 3—Russia does not fully comply with the
minimum standards for the elimination of trafficking and is
not making a significant effort to do so; prosecutions of
trafficking offenders remained low in comparison to the
scope of Russia’s trafficking problem; the government did
not develop or employ a formal system for identifying
trafficking victims or referring them to protective services,
although authorities reportedly assisted a limited number
of victims on an ad hoc basis; foreign victims, the largest
group in Russia, were not entitled to state-provided
rehabilitative services and were routinely detained and
deported; the government has not reported investigating
reports of slave-like conditions among North Korean
workers in Russia; authorities have made no effort to
reduce the demand for forced labor or to develop public
awareness of forced labor or sex trafficking (2015) Mlicit
drugs: limited cultivation of illicit cannabis and opium poppy
and producer of methamphetamine, mostly for domestic
consumption; government has active illicit crop eradication
program; used as transshipment point for Asian opiates,
cannabis, and Latin American cocaine bound for growing
domestic markets, to a lesser extent Western and Central
Europe, and occasionally to the US; major source of heroin
precursor chemicals; corruption and organized crime are
key concerns; major consumer of opiates RWANDA
= UGANDA
OF THE','7280d76c1b75010f315c25690574165f3a29c91c8572da1079ea75d540447a6e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05bacb713d4ad8c4efc87c41b2307cfdfac0398bcfa7e15f84ba217c986feeaf',2021,'NO','Norway','transnational-issues',834,'Svalbard
(NORWAY)
Bjornaya
Nordkapp
Hammerfest,
Tro Ms,
Drammen,
Fredrikstad,
Stavanger,
Kristiansand
Disputes—International: NONe
Refugees and internally displaced persons: refugees (country of
origin): 109,343 (Syria), 27,653 (Eritrea), 28,204
(Afghanistan), 21,032 (Somalia), 12,693 (Iraq), 6,485 (Iran)
(2018) stateless persons: 31,819 (2018); note—the majority
of stateless people are from the Middle East and Somalia','4b6a10d70aeee666d160a46220bf72d1ba26e48c2d3edd7631c9043979027e34','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2be96553a4727b5724737a1180bf7538f0c83c6dd640786ec4dceb70f03d8b45',2021,'PK','Pakistan','transnational-issues',836,'Disputes—International: maritime delineation negotiations
continue with Philippines, Indonesia','d53b9a87e5b196a3aad1c0ee578b9fe93ead7fa8d211533af313fa7000b4f801','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e39d86d37b71dd8cb0ea24bf8983fc5bafbe3fdc01e971baf81f377bb042e3be',2021,'PA','Panama','transnational-issues',844,'Disputes—International: Organized illegal narcotics operations
in Colombia operate within the remote border region with
Panama Refugees and internally displaced persons: refugees
(country of origin): 15,614 (Colombia) (2016), 85,571
(Venezuela) (economic and_ political crisis; includes
Venezuelans who have claimed asylum or have received
alternative legal stay) (2019) Illicit drugs: major cocaine
transshipment point and primary money-laundering center
for narcotics revenue; money-laundering activity is
especially heavy in the Colon Free Zone; offshore financial
center; negligible signs of coca cultivation; monitoring of
financial transactions is improving; official corruption
remains a major problem PAPUA NEW GUINEA','521a822b84f89b8783713c0b56a02162ccb1e58ca1e8dacf495d2a23fc8a4e18','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8fafcdbaec59ee9ab4a0ee1c98a452ae76f184edd663cf609102194606430a',2021,'PH','Philippines','transnational-issues',862,'Disputes—International: Philippines claims sovereignty over
Scarborough Reef (also claimed by China together with
Taiwan) and over certain of the Spratly Islands, known
locally as the Kalayaan (Freedom) Islands, also claimed by
China, Malaysia, Taiwan, and Vietnam; the 2002
“Declaration on the Conduct of Parties in the South China
Sea,” has eased tensions in the Spratly Islands but falls
short of a legally binding “code of conduct” desired by
several of the disputants; in March 2005, the national oil
companies of China, the Philippines, and Vietnam signed a
joint accord to conduct marine seismic activities in the
Spratly Islands; Philippines retains a dormant claim to
Malaysia’s Sabah State in northern Borneo based on the
Sultanate of Sulu’s granting the Philippines Government
power of attorney to pursue a sovereignty claim on his
behalf; maritime delimitation negotiations continue with
Palau Refugees and internally displaced persons: [DPs: 301,000
(government troops fighting the Moro Islamic Liberation
Front, the Abu Sayyaf Group, and the New People’s Army;
clan feuds; natural disasters) (2018) stateless persons:
1,068 (2018); note—stateless persons are descendants of
Indonesian migrants
Illicit drugs: domestic methamphetamine production has been
a growing problem in recent years despite government
crackdowns; major consumer of amphetamines;
longstanding marijuana producer mainly in rural areas
where Manila’s control is limited PITCAIRN ISLANDS
Disputes—International: NONe','d2d370ad104a87447a0ed5f41e76d0508932d3f9e0c14b7ff8f74f882ea373b3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f4e9797ffa21c23cc0329b295623e232ec191d4c72e0ba6d04382a0dc15aed0',2021,'KN','Saint Kitts and Nevis','transnational-issues',886,'Sandy Point
Town 4
* Mot
Lemuiga
BASSETERRE
*
Nevis
Peak
Charlestown),
Nevis
Disputes—International: NONe
SAINT VINCENT AND THE
GRENADINES
La Soufriére
Chateaubelair,
“Georgetown
Saint
Vincent a KINGSTOWN
Boquia Sort Elizabeth
Disputes—International: joins other Caribbean states to counter
Venezuela’s claim that Aves Island sustains human
habitation, a criterion under UN Convention on the Law of
the Sea, which permits Venezuela to extend its
EEZ/continental shelf over a large portion of the eastern
Caribbean Sea Trafficking in persons: Current situation: Saint
Vincent and the Grenadines is a source, transit, and
destination country for men, women, and _ children
subjected to forced labor and sex trafficking; some children
under 18 are pressured to engage in sex acts in exchange
for money or gifts; foreign workers may experience forced
labor and are particularly vulnerable when employed by
small, foreign-owned companies; adults and children are
vulnerable to forced labor domestically, especially in the
agriculture sector tier rating: Tier 2 Watch List—Saint
Vincent and the Grenadines does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; the
government for the first time acknowledged a trafficking
problem, launched an anti-trafficking public awareness
campaign, and conducted anti-trafficking training for law
enforcement, immigration, and labor officials; in 2014,
authorities initiated three trafficking investigations, two of
which were ultimately determined not to be trafficking
cases, and did not prosecute or convict any trafficking
offenders; the government did not identify or refer any
potential trafficking victims to care (2015) Illicit drugs:
transshipment point for South American drugs destined for
the US and Europe; small-scale cannabis cultivation','83e6b45bf0e1a6243261f0d4e095bdce3bbaa632a1907eb27a34554c3ed15d37','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81d1cce9f689287418af77a9cd93393abf742a71aded1103381f3d4d004317ae',2021,'WS','Samoa','transnational-issues',896,'Savai''i
*Matavai
Mount Silisei
Salelologay
Faleasi‘u--Vaitele
+. * “APIA
Manono < Mulifanua
Upolu
Nuusatee
9 10 20 30km
) A A
0 10 20 30 mi
Disputes—International: NOnNe','be6e6a5f47e79d4ab7c987b5b4fbc2916761cff85a081fdad0f2c4b1ce3da0e9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c6218e56f367a2674d55d9d255d219d151d1c1b843311bfe495f394ca59edf1',2021,'SM','San Marino','transnational-issues',904,'a
7” Falgiano
- ae {
Doganaj
25 .
Serravalle |
,Domagnano \\
e Borgo Maggiore
* SAN MARINO
A
Faetano,
Monte
Giardino |
\\ Poggio di
\\ ~ :
} Chiesarova Fiorentino. 7
] 1 2km
ae ee 3
0 1 2 mi
Disputes—International: NONe','96c3a5ebabee5fb22c1eef1e6554bf24ec218eed5a4dc245d6c8e134bee2f1bb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4557cd427a39ddde6f7a55b6443384d3be86e6ddbeabcdc26be49655d7d4fe6a',2021,'SA','Saudi Arabia','transnational-issues',916,'Ir jar,
Ha’, al Batin
se Al Jubayl,
Buraydah, Ad Dammdme BAHnain
Al Hufaf, \\/.
Medina * e
*Yanbu'' al Bahr RIYADH
Jeddah, Mecca
*At Ta’ if
Sal Hudaydah
ebb
*Ta‘izz
“Aden','b26c7edcc205092b68e21e695eb31422918c3b26df2b724601e2921554f24229','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6388418e47b9c8db346293d229877de08b800df39537486091edeb6a113e19d',2021,'SI','Slovenia','transnational-issues',934,'Disputes—International: Since the breakup of Yugoslavia in the
early 1990s, Croatia and Slovenia have each claimed
sovereignty over Piran Bay and four villages, and Slovenia
has objected to Croatia’s claim of an exclusive economic
zone in the Adriatic Sea; in 2009, however Croatia and
Slovenia signed a binding international arbitration
agreement to define their disputed land and maritime
borders, which led Slovenia to lift its objections to Croatia
joining the EU; in June 2017 the arbitration panel issued a
ruling on the border that Croatia has not implemented; as a
member state that forms part of the EU’s external border,
Slovenia has implemented the strict Schengen border rules
to curb illegal migration and commerce’ through
southeastern Europe while encouraging close cross-border
ties with Croatia; Slovenia continues to impose a hard
border Schengen regime with Croatia, which joined the EU
in 2013 but has not yet fulfilled Schengen requirements
Refugees and_ internally displaced persons: mote: 501,708
estimated refugee and migrant arrivals (January 2015-
November 2019); migration through the Western Balkans
has decreased significantly since March 2016; Slovenia is
predominantly a transit country and hosts approximately
300 asylum seekers as of the end of June 2018
Illicit drugs: Minor transit point for cocaine and Southwest
Asian heroin bound for Western Europe, and for precursor
chemicals SOLOMON ISLANDS','962959f5b2501bda20ca7d5bf6a82ee15f2f5f821f4cba080713e6c283eae455','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1834f0e64ac3966eb7412be831f36fa7165ff10ebe5798b74a21ae488e15678',2021,'SO','Somalia','transnational-issues',944,'Disputes—International: South Africa has placed military units
to assist police operations along the border of Lesotho,
Zimbabwe, and Mozambique to control smuggling,
poaching, and illegal migration; the governments of South
Africa and Namibia have not signed or ratified the text of
the 1994 Surveyor’s General agreement placing the
boundary in the middle of the Orange River Refugees and
internally displaced persons: refugees (country of origin):
599,480 (Democratic Republic of the Congo) (refugees and
asylum seekers), 27,113 (Somalia), 17,726 (Ethiopia), 5,273
(Republic of the Congo) (2018), Illicit drugs: transshipment
center for heroin, hashish, and cocaine, as well as a major
cultivator of marijuana in its own right; cocaine and heroin
consumption on the rise; world’s largest market for illicit
methaqualone, usually imported illegally from India
through various east African countries, but increasingly
producing its own _ synthetic drugs for domestic
consumption; attractive venue for money launderers given
the increasing level of organized criminal and narcotics
activity in the region and the size of the South African
economy SOUTH GEORGIA AND SOUTH SANDWICH
ISLANDS
Shag Rocks
are not shown,
South Georgia
/ »Grytviken
Bird
Island
Traversay
Islands
South
Sandwich Saunders |.
Islands Montagu 1.
Bristol |.
Southem
Thule
Disputes—International: Argentina, which claims the islands in
its constitution and briefly occupied them by force in 1982,
agreed in 1995 to no longer seek settlement by force','704a1085fbb775e68fd28a6ec22c36cd3bb41889574bc76ed6f691460c635a43','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce9312099f98aed071e7fe54119ccd1b723c17c01e8c365c3ce47d52df14a1b0',2021,'SS','South Sudan','transnational-issues',945,'DEMOCRATIC REPUBLIC
OF THE CONGO
Mbale,
Fort Portal
Ports Jinja
KAMPALA | 501) ot
Entebbe,
Masaka,
larghenta
Pea
*Mbarara
ora tooxm PANZANIA
RWANDA Oo 50 100 mi
Disputes—International: Uganda is subject to armed fighting
among hostile ethnic groups, rebels, armed gangs, militias,
and various government forces that extend across its
borders; Ugandan refugees as well as members of the
Lord’s Resistance Army (LRA) seek shelter in southern
Sudan and the Democratic Republic of the Congo’s
Garamba National Park; LRA forces have also attacked
Kenyan villages across the border Refugees and _ internally
displaced persons: refugees (country of origin): 861,590
(South Sudan) (refugees and asylum seekers), 397,638
(Democratic Republic of the Congo) (refugees and asylum
seekers), 45,671 (Burundi), 37,960 (Somalia) (refugees and
asylum seekers), 16,272 (Rwanda) (refugees and asylum
seekers), 13,563 (Eritrea) (refugees and asylum seekers)
(2019) IDPs: 32,000 (displaced in northern Uganda because
of fighting between government forces and the Lord’s
Resistance Army; as of 2011, most of the 1.8 million people
displaced to IDP camps at the height of the conflict had
returned home or resettled, but many had not found
durable solutions; intercommunal violence, land disputes,
and cattle raids) (2018) UKRAINE
Disputes—International: 1997 boundary delimitation treaty
with Belarus remains unratified due to unresolved financial
claims, stalling demarcation and reducing border security;
delimitation of land boundary with Russia is complete and
demarcation began in 2012; the dispute over the boundary
between Russia and Ukraine through the Kerch Strait and
Sea of Azov is suspended due to the occupation of Crimea
by Russia; Ukraine and Moldova signed an agreement
officially delimiting their border in 1999, but the border has
not been demarcated due to Moldova’s difficulties with the
break-away region of Transnistria; Moldova and Ukraine
operate joint customs posts to monitor transit of people and
commodities through Moldova’s Transnistria Region, which
remains under the auspices of an Organization for Security
and Cooperation in Europe-mandated peacekeeping
mission comprised of Moldovan, Transnistrian, Russian,
and Ukrainian troops; the ICJ ruled largely in favor of
Romania in its dispute submitted in 2004 over Ukrainian-
administered Zmiyinyy/Serpilor (Snake) Island and Black
Sea maritime boundary delimitation; Romania opposes
Ukraine’s reopening of a navigation canal from the Danube
border through Ukraine to the Black Sea Refugees and
internally displaced persons: JDPs: 1.5 million (Russian-
sponsored separatist violence in Crimea and eastern
Ukraine) (2019) stateless persons: 35,650 (2018); note—
citizens of the former USSR who were permanently
resident in Ukraine were granted citizenship upon
Ukraine’s independence in 1991, but some missed this
window of opportunity; people arriving after 1991, Crimean
Tatars, ethnic Koreans, people with expired Soviet
passports, and people with no documents have difficulty
acquiring Ukrainian citizenship; following the fall of the
Soviet Union in 1989, thousands of Crimean Tatars and
their descendants deported from Ukraine under the
STALIN regime returned to their homeland, some being
stateless and others holding the citizenship of Uzbekistan
or other former Soviet republics; a 1998 _ bilateral
agreement between Ukraine and Uzbekistan simplified the
process of renouncing Uzbek citizenship and obtaining
Ukrainian citizenship Trafficking in persons: current situation:
Ukraine is a source, transit, and destination country for
men, women, and children subjected to forced labor and
sex trafficking; Ukrainian victims are sex trafficked within
Ukraine as well as in Russia, Poland, Irag, Spain, Turkey,
Cyprus, Greece, Seychelles, Portugal, the Czech Republic,
Israel, Italy, South Korea, Moldova, China, the United Arab
Emirates, Montenegro, UK, Kazakhstan, Tunisia, and other
countries; small numbers of foreigners from Moldova,
Russia, Vietnam, Uzbekistan, Pakistan, Cameroon, and
Azerbaijan were victims of labor trafficking in Ukraine;
Ukrainian recruiters most often target Ukrainians from
rural areas with limited job prospects using fraud,
coercion, and debt bondage tier rating: Tier 2 Watch List -
Ukraine does not fully comply with the minimum standards
for the elimination of trafficking; however, it is making
significant efforts to do so; the government’s focus on its
security situation constrained its anti-trafficking
capabilities; law enforcement efforts to pursue trafficking
cases weakened in 2014, continuing a multi-year decline,
and no investigations, prosecutions, or convictions of
government officials were made, despite reports of official
complicity in the sex and labor trafficking of children living
in state-run institutions; fewer victims were identified and
referred to NGOs, which continued to provide and to fund
the majority of victims’ services (2015) Illicit drugs: limited
cultivation of cannabis and opium poppy, mostly for CIS
consumption; some synthetic drug production for export to
the West; limited government eradication program; used as
transshipment point for opiates and other illicit drugs from
Africa, Latin America, and Turkey to Europe and Russia;
Ukraine has improved anti-money-laundering controls,
resulting in its removal from the Financial Action Task
Force’s (FATF’s) Noncooperative Countries and Territories
List in February 2004; Ukraine’s anti-money-laundering
regime continues to be monitored by FATF','abd7674bf5b306558194479248650644713f23239a630abe8e2ed9fabd6e4c8b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d20c057f3d35686e0d632a6ec677feb070981438279659f1e8ed6a1e2110eb4b',2021,'SD','Sudan','transnational-issues',955,'Disputes—International: South Sudan-Sudan boundary
represents 1 January 1956 alignment, final alignment
pending negotiations and demarcation; final sovereignty
status of Abyei Area pending negotiations between South
Sudan and Sudan; periodic violent skirmishes with South
Sudanese residents over water and grazing rights persist
among related pastoral populations along the border with
the Central African Republic; the boundary that separates
Kenya and South Sudan’s sovereignty is unclear in the
“Tlemi Triangle,” which Kenya has administered since
colonial times Refugees and internally displaced persons: refugees
(country of origin): 274,916 (Sudan) (refugees and asylum
seekers), 16,350 (Democratic Republic of the Congo)
(refugees and asylum seekers) (2019) IDPs: 1.47 million
(alleged coup attempt and ethnic conflict beginning in
December 2013; information is lacking on those displaced
in earlier years by: fighting in Abyei between the Sudanese
Armed Forces and the Sudan People’s Liberation Army
(SPLA) in May 2011; clashes between the SPLA and
dissident militia groups in South Sudan; inter-ethnic
conflicts over resources and cattle; attacks from the Lord’s
Resistance Army; floods and drought) (2019) Trafficking in
persons: Current situation: South Sudan is a source and
destination country for men, women, and _ children
subjected to forced labor and sex trafficking; South
Sudanese women and girls, particularly those who are
internally displaced, orphaned, refugees, or from rural
areas, are vulnerable to forced labor and_ sexual
exploitation, often in urban centers; children may be
victims of forced labor in construction, market vending,
shoe shining, car washing, rock breaking, brick making,
delivery cart pulling, and begging; girls are also forced into
marriages and subsequently subjected to sexual slavery or
domestic servitude; women and girls migrate willingly from
Uganda, Kenya, Ethiopia, Eritrea, and the Democratic
Republic of the Congo to South Sudan with the promise of
legitimate jobs and are forced into the sex trade; inter-
ethnic abductions and abductions by criminal groups
continue, with abductees subsequently forced into domestic
servitude, herding, or sex trafficking; in 2014, the
recruitment and use of child soldiers increased significantly
within government security forces and was also prevalent
among opposition forces tier rating: Tier 3—South Sudan
does not fully comply with the minimum standards for the
elimination of trafficking and is not making significant
efforts to do so; despite the government’s formal
recommitment to an action plan to eliminate the
recruitment and use of child soldiers by 2016, the practice
expanded during 2014, and the government did not hold
any officers criminally responsible; government officials
reportedly are complicit in trafficking offenses but these
activities continue to go uninvestigated; authorities
reportedly identified five trafficking victims but did not
transfer them to care facilities; law enforcement continued
to arrest and imprison individuals for prostitution,
including trafficking victims; no known steps were taken to
address the exploitation of South Sudanese nationals
working abroad or foreign workers in South Sudan (2015)
SOUTHERN OCEAN
~.
X soculn |, SOUTHERN 7
Trench OCEAN
* SOUTHERN,
Disputes—International: Antarctic Treaty defers claims (see
Antarctica entry), but Argentina, Australia, Chile, France,
NZ, Norway, and UK assert claims (some overlapping),
including the continental shelf in the Southern Ocean;
several states have expressed an interest in extending
those continental shelf claims under the UN Convention on
the Law of the Sea to include undersea ridges; the US and
most other states do not recognize the land or maritime
claims of other states and have made no claims themselves
(the US and Russia have reserved the right to do so); no
formal claims exist in the waters in the sector between 90
degrees west and 150 degrees west SPAIN
Disputes—International: the effects of Sudan’s ethnic and rebel
militia fighting since the mid-20th century have penetrated
all of the neighboring states; Chad wishes to be a helpful
mediator in resolving the Darfur conflict, and in 2010
established a joint border monitoring force with Sudan,
which has helped to reduce cross-border banditry and
violence; as of early 2019, more than 590,000 Sudanese
refugees are being hosted in the Central African Republic,
Chad, Egypt, Ethiopia, Kenya, and South Sudan; Sudan, in
turn, is hosting more than 975,000 refugees and asylum
seekers, including more than 845,000 from South Sudan;
Sudan accuses South Sudan of supporting Sudanese rebel
groups; Sudan claims but Egypt de facto administers
security and economic development of the Halaib region
north of the 22nd parallel boundary; periodic violent
skirmishes with Sudanese residents over water and grazing
rights persist among related pastoral populations along the
border with the Central African Republic; South Sudan-
Sudan boundary represents 1 January 1956 alignment, final
alignment pending negotiations and demarcation; final
sovereignty status of Abyei Area pending negotiations
between South Sudan and Sudan Refugees and _ internally
displaced persons: refugees (country of origin): 810,917
(South Sudan) (refugees and asylum seekers), 121,156
(Eritrea) (refugees and asylum seekers), 93,502 (Syria)
(refugees and asylum seekers), 14,272 (Ethiopia) (refugees
and asylum seekers), 9,289 (Central African Republic)
(2019) IDPs: 2.072 million (civil war 1983-2005; ongoing
conflict in Darfur region; government and rebel fighting
along South Sudan border; inter-tribal clashes) (2018)
Trafficking in persons: Current situation: Sudan is a source,
transit, and destination country for men, women, and
children who are subjected to forced labor and sex
trafficking; Sudanese women and girls, particularly those
from rural areas or who are internally displaced, or
refugees are vulnerable to domestic servitude in country, as
well as domestic servitude and sex trafficking abroad;
migrants from East and West Africa, South Sudan, Syria,
and Nigeria smuggled into or through Sudan are
vulnerable to exploitation; Ethiopian, Eritrean, and Filipino
women are subjected to domestic servitude in Sudanese
homes, and East African and possibly Thai women are
forced into prostitution in Sudan; Sudanese children
continue to be recruited and used as combatants by
government forces and armed groups tier rating: Tier 2
Watch List—Sudan does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; the government
increased its efforts to publically address and prevent
trafficking, established a national anti-trafficking council,
and began drafting a national action plan against
trafficking; the government acknowledges cross-border
trafficking but still denies the existence of forced labor, sex
trafficking, and the recruitment of child _ soldiers
domestically; law enforcement and _ judicial officials
struggled to apply the national anti-trafficking law, often
relying on other statutes with lesser penalties; authorities
did not use systematic procedure to identify victims or
refer them to care and relied on international organizations
and domestic groups to provide protective services; some
foreign victims were penalized for unlawful acts committed
as a direct result of being trafficked, such as immigration
or prostitution violations (2015) SURINAME
aap: Nieuw
“NiogPARAMARIBO, Amsterdam
uw
Nickerie Moengo
Albina
.
Lelydorp
Apoera
GUYANA Brokopondo,','269c958e67e245107bc4e194b2f34ffa4cdd9c2218339c09475b5c3d48f70175','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6965f3ced0fc96a1008012f0fbc78651426c5989915dbf5f88d16cb4ab1b1b4e',2021,'LK','Sri Lanka','transnational-issues',960,'INDIA Jafina
“Mannar
ylrincomalee
*Anuradhapura
,Puttalam
Polonnaruwa” Batticaloa
°
-Matale
Kalmunai
Kandy 7
Negombo,','e6ad5c6cf556b93cf064e347cfca2d9916cf118b613e94ddf3efb2f8546794b1','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc18afc113b6ffe9b6ef6c2532b3277e30e1eed4a50901fa2edae75808a59531',2021,'MY','Malaysia','transnational-issues',989,'Disputes—International: Separatist violence in ‘Thailand’s
predominantly Malay-Muslim southern provinces prompt
border closures and controls with Malaysia to stem
insurgent activities; Southeast Asian states have enhanced
border surveillance to check the spread of avian flu; talks
continue on completion of demarcation with Laos but
disputes remain over several islands in the Mekong River;
despite continuing border committee talks, Thailand must
deal with Karen and other ethnic rebels, refugees, and
illegal cross-border activities; Cambodia and Thailand
dispute sections of boundary; in 2011, Thailand and
Cambodia resorted to arms in the dispute over the location
of the boundary on the precipice surmounted by Preah
Vihear temple ruins, awarded to Cambodia by ICJ decision
in 1962 and part of a planned UN World Heritage site;
Thailand is studying the feasibility of jointly constructing
the Hatgyi Dam on the Salween river near the border with
Burma; in 2004, international environmentalist pressure
prompted China to halt construction of 13 dams on the
Salween River that flows through China, Burma, and
Thailand; approximately 100,000 mostly Karen refugees
fleeing civil strife, political upheaval and economic
stagnation in Burma live in remote camps in Thailand near
the border Refugees and internally displaced persons: refugees
(country of origin): 97,603 (Burma) (2018) stateless
persons: 478,883 (2018) (estimate represents stateless
persons registered with the Thai Government; actual
number may be as high as 3.5 million); note—about half of
Thailand’s northern hill tribe people do not have citizenship
and make up the bulk of Thailand’s stateless population;
most lack documentation showing they or one of their
parents were born in Thailand; children born to Burmese
refugees are not eligible for Burmese or Thai citizenship
and are stateless; most Chao Lay, maritime nomadic
peoples, who travel from island to island in the Andaman
Sea west of Thailand are also stateless; stateless Rohingya
refugees from Burma are considered illegal migrants by
Thai authorities and are detained in inhumane conditions
or expelled; stateless persons are denied access to voting,
property, education, employment, healthcare, and driving
note: Thai nationality was granted to more than 23,000
stateless persons between 2012 and 2016; in 2016, the
Government of Thailand approved changes to _ its
citizenship laws that could make 80,000 stateless persons
eligible for citizenship, as part of its effort to achieve zero
statelessness by 2024 (2018) Trafficking in persons: Current
situation: Thailand is a source, transit, and destination
country for men, women, and children subjected to forced
labor and sex trafficking; victims from Burma, Cambodia,
Laos, China, Vietnam, Uzbekistan, and India, migrate to
Thailand in search of jobs but are forced, coerced, or
defrauded into labor in commercial fishing, fishing-related
industries, factories, domestic work, street begging, or the
sex trade; some Thai, Burmese, Cambodian, and Indonesian
men forced to work on fishing boats are kept at sea for
years; sex trafficking of adults and children from Thailand,
Laos, Vietnam, and Burma remains a significant problem;
Thailand is a transit country for victims from China,
Vietnam, Bangladesh, and Burma _ subjected to sex
trafficking and forced labor in Malaysia, Indonesia,
Singapore, Russia, South Korea, the US, and countries in
Western Europe; Thai victims are also trafficked in North
America, Europe, Africa, Asia, and the Middle East tier
rating: Tier 2 Watch List—Thailand does not fully comply
with the minimum standards for the elimination of
trafficking, and is not making significant efforts to do so; in
2014, authorities investigated, prosecuted, and convicted
fewer traffickers and identified fewer victims; some cases
of official complicity were investigated and prosecuted, but
trafficking-related corruption continues to hinder progress
in combatting trafficking; authorities’ efforts to screen for
victims among vulnerable populations remained inadequate
due to a poor understanding of trafficking indicators, a
failure to recognize non-physical forms of coercion, and a
shortage of language interpreters; the government passed
new labor laws increasing the minimum age in the fishing
industry to 18 years old, guaranteeing the minimum wage,
and requiring work contracts, but weak law enforcement
and poor coordination among regulatory agencies enabled
exploitive labor practices to continue; the government
increased efforts to raise public awareness to the dangers
of human trafficking and to deny entry to foreign sex
tourists (2015) Ilicit drugs: a minor producer of opium,
heroin, and marijuana; transit point for illicit heroin en
route to the international drug market from Burma and
Laos; eradication efforts have reduced the area of cannabis
cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been reduced by
eradication efforts; also a drug money-laundering center;
minor role in methamphetamine production for regional
consumption; major consumer of methamphetamine since
the 1990s despite a series of government crackdowns','65c3ea41c57b0e9aca490098e2952dc242a4fa63f378fe75e4307ff22592e58e','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93ba73fe3e7a383e9bdb4e86ac0bd7c7b288a9e0b1644573631c4e4983fe00d2',2021,'TT','Trinidad and Tobago','transnational-issues',990,'Tobago
Scarborough;
PORT-OF ~~ éic
SPAI
7erTO
N 4. cel Anpo
Arima
Chaguanas, Sangre”
Point Lisas
Pointe-a-Pierre, Trinidad
Point “San Fernando
Fortin,
Siparia
Disputes—International: Barbados and Trinidad and Tobago
abide by the April 2006 Permanent Court of Arbitration
decision delimiting a maritime boundary and _ limiting
catches of flying fish in Trinidad and Tobago’s EEZ; in
2005, Barbados and Trinidad and ‘Tobago agreed to
compulsory international arbitration under UN Convention
on the Law of the Sea challenging whether the northern
limit of Trinidad and Tobago’s and Venezuela’s maritime
boundary extends into Barbadian waters; Guyana has
expressed its intention to include itself in the arbitration,
as the Trinidad and Tobago-Venezuela maritime boundary
may also extend into its waters Refugees and internally displaced
persons: refugees (country of origin): 13,990 (Venezuela)
(economic and political crisis; includes Venezuelans who
have claimed asylum or have received alternative legal
stay) (2019) Trafficking in persons: current situation: Trinidad
and Tobago is a destination, transit, and possible source
country for adults and children subjected to sex trafficking
and forced labor; women and girls from Venezuela, the
Dominican Republic, Guyana, and Colombia have been
subjected to sex trafficking in Trinidad and ‘Tobago’s
brothels and clubs; some economic migrants from the
Caribbean region and Asia are vulnerable to forced labor in
domestic service and the retail sector; the steady flow of
vessels transiting Trinidad and Tobago’s territorial waters
may also increase opportunities for forced labor for fishing;
international crime organizations are increasingly involved
in trafficking, and boys are coerced to sell drugs and guns;
corruption among police and immigration officials impedes
anti-trafficking efforts tier rating: Tier 2 Watch List -
Trinidad and Tobago does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; anti-
trafficking law enforcement efforts decreased from the
initiation of 12 prosecutions in 2013 to 1 in 2014; the
government has yet to convict anyone under its 2011 anti-
trafficking law, and all prosecutions from previous years
remain pending; the government sustained efforts to
identify victims and to refer them for care at NGO facilities,
which it provided with funding; the government failed to
draft a national action plan as mandated under the 2011
anti-trafficking law and did not launch a sufficiently robust
awareness campaign to educate the public and officials
(2015) illicit drugs: transshipment point for South American
drugs destined for the US and Europe; producer of
cannabis TUNISIA
Bizerte
Cap Bon
Ariana,
La Goulette
Beja, x
TUNIS
*Nabeul
El Kef
Sousse*
\\Mahdia
Chambi
®, 1
Kasserine
Gafsa
. Skhira,
Shaft al
v Gharsah
./ozeur Gabés,
Medenine,
lataouine','e832c2b4214e2b339152b7741b83c652644f68a41c1adaaf50eb09ea8716a884','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebc82b46e20fa9523dc556c500437ede223fbce9038fb7b6990832a92738a565',2021,'AE','United Arab Emirates','transnational-issues',1013,'Disputes—International: boundary agreement was signed and
ratified with Oman in 2003 for entire border, including
Oman’s Musandam Peninsula and Al Madhah enclaves, but
contents of the agreement and detailed maps showing the
alignment have not been published; Iran and UAE dispute
Tunb Islands and Abu Musa Island, which Iran occupies
Illicit drugs: the UAE is a drug transshipment point for
traffickers given its proximity to Southwest Asian drug-
producing countries; the UAE’s position as a major
financial center makes it vulnerable to money laundering;
anti-money-laundering controls improving, but informal
banking remains unregulated UNITED KINGDOM
@ island of Rockall
is not shown.
Suillom Voe
Terminals’ 7
Gag Lerwick
SHETLAND
ISLANDS
ORKNEY
ISLANDS :
“Scapa
Peterhead
; {Aberdeen
. @ Ben News
j Dundee,
‘ a
(Grangemouth
a f De 7 “
BiaageOUah
at Newcastle
Londonderry, upon Tyne,\\,
Northen | :
Belfast Middlesbrough
; Kingston
le of Man
WK) upon Hull,
Manchester i
IRELAND “kiverpool
England
z VW The Fens
28irmingham
Felixstowe,
~ Cardi” LONDON
i “* Bristol Dov en,
Southampton, Portsmouth Vay
Channe!
Plymouth, Tunnel
SFalmouth
A ana IRnRANCE
ty 50 100 mi
Disputes—International: in 2002, Gibraltar residents voted
overwhelmingly by referendum to reject any “shared
sovereignty” arrangement between the UK and Spain; the
Government of Gibraltar insisted on equal participation in
talks between the two countries; Spain disapproved of UK
plans to grant Gibraltar greater autonomy; Mauritius and
Seychelles claim the Chagos Archipelago (British Indian
Ocean Territory); in 2001, the former inhabitants of the
archipelago, evicted 1967—1973, were granted UK
citizenship and the right of return, followed by Orders in
Council in 2004 that banned rehabitation, a High Court
ruling reversed the ban, a Court of Appeal refusal to hear
the case, and a Law Lords’ decision in 2008 denied the
right of return; in addition, the UK created the world’s
largest marine protection area around the Chagos islands
prohibiting the extraction of any natural resources therein;
UK rejects sovereignty talks requested by Argentina, which
still claims the Falkland Islands (Islas Malvinas) and South
Georgia and the South Sandwich Islands; territorial claim
in Antarctica (British Antarctic Territory) overlaps
Argentine claim and partially overlaps Chilean claim;
Iceland, the UK, and Ireland dispute Denmark’s claim that
the Faroe Islands’ continental shelf extends beyond 200 nm
Refugees and internally displaced persons: refugees (country of
origin): 17,231 (Iran), 13,041 (Eritrea), 9,839
(Afghanistan), 9,720 (Syria), 8,959 (Sudan), 7,742
(Pakistan), 6,772 (Zimbabwe), 5,711 (Sr Lanka) (2018)
stateless persons: 125 (2018)
Ilicit drugs: producer of limited amounts of synthetic drugs
and synthetic precursor chemicals; major consumer of
Southwest Asian heroin, Latin American cocaine, and
synthetic drugs; money-laundering center','a5a422bd137d5ff1499a6e4b1e4accb2da212d4bb7f8b6e6d87315eb777d9a18','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dceb5064324d492e9180717a26ff7303ebd865de2edc598c197be48f25217d7a',2021,'US','United States','transnational-issues',1015,'Disputes—International: the US has intensified domestic
security measures and is collaborating closely with its
neighbors, Canada and Mexico, to monitor and control
legal and illegal personnel, transport, and commodities
across the international borders; abundant rainfall in
recent years along much of the Mexico-US border region
has ameliorated periodically strained water-sharing
arrangements; 1990 Maritime Boundary Agreement in the
Bering Sea still awaits Russian Duma ratification; Canada
and the United States dispute how to divide the Beaufort
Sea and the status of the Northwest Passage but continue
to work cooperatively to survey the Arctic continental shelf;
The Bahamas and US have not been able to agree on a
maritime boundary; US Naval Base at Guantanamo Bay is
leased from Cuba and only mutual agreement or US
abandonment of the area can terminate the lease; Haiti
claims US-administered Navassa Island; US has made no
territorial claim in Antarctica (but has reserved the right to
do so) and does not recognize the claims of any other
states; Marshall Islands claims Wake Island; Tokelau
included American Samoa’s Swains Island among the
islands listed in its 2006 draft constitution Refugees and
internally displaced persons: refugees (country of origin): the
US admitted 30,000 refugees during FY2019 including:
12,958 (Democratic Republic of the Congo), 4,932 (Burma),
4,451 (Ukraine), 1,757 (Eritrea), 1,198 (Afghanistan) note:
72,722 Venezuelans have claimed asylum since 2014
because of the economic and political crisis (2018) Illicit
drugs: world’s largest consumer of cocaine (shipped from
Colombia through Mexico and the Caribbean), Colombian
heroin, and Mexican heroin and marijuana; major
consumer of ecstasy and Mexican methamphetamine;
minor consumer of high-quality Southeast Asian heroin;
illicit producer of cannabis, marijuana, depressants,
stimulants, hallucinogens, and methamphetamine; money-
laundering center UNITED STATES PACIFIC ISLAND
WILDLIFE REFUGES
Disputes—International: NONe','5cb758ecaff27882f481c57dbd190c19aa11c0e19ba587c124df3ec0861279b3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33002f1fc9681a1f8e45d7974ac7e0a4e43105b5c5934fdf5b6fe8c165e8f39a',2021,'SB','Solomon Islands','transnational-issues',1018,'TORRES
ISLANDS
Vanua BANKS
Lava ISLANDS
Santa Maria
Espiritu
Santo
Maéwo
Tabwémasana
a
Luganvalé, 4008 (| pontecost
Ambrym
Malakula
SHEPHERD
Ep! + ISLANDS
Z -
mm Efate Forari
2 PORT-VILA
Erromango
Aniwa
Futuna
Tanna
Anatom
New
Caledonia
(FRANCE)
Matthew
Hunter
islands claimed by
VANUATU and FRANCE','ca82cad488935ca29854124b57e74a06815f66e76a317c927dbe82784c8640af','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dacab0afe3c9e3e9bf0af052c7a4cb7cdce391affe8d9bc02291bfe198a5a158',2021,'WF','Wallis and Futuna','transnational-issues',1027,'les
Wallis
MATA-UTU}
lle Uvéa
Iles de Horne
lle Futuna
~Sigave (Leava)
lle Alofi
Disputes—International: NONe
WEST BANK
4 Tulkarm
)
5
Ol he
~
rd
{ Qaiqilyah Nablus
B)
1994 T;
aly Ling
“N28
—_ rma
oO
v
a ‘Agar
Ramallah
fet ew
Jericho
Mount
Scopus
-L
Atri
mt
>
‘-——
un
—_—? Jerusalem
4
Bethlehem
Hebron
q 1949 Armistge
tw 90
(Green Line
Disputes—International: the current status of the West Bank is
subject to the Israeli-Palestinian Interim Agreement—
permanent status to be determined through further
negotiation; Israel continues construction of a “seam line”
separation barrier along parts of the Green Line and within
the West Bank; Israel withdrew from Gaza and four
settlements in the northern West Bank in August 2005;
since 1948, about 350 peacekeepers from the UN Truce
Supervision Organization (UNTSO), headquartered in
Jerusalem, monitor ceasefires, supervise armistice
agreements, prevent isolated incidents from escalating, and
assist other UN personnel in the region Refugees and
internally displaced persons: refugees (country of origin):
846,465 (Palestinian refugees) (2019) JDPs: 238,000
(includes persons displaced within the Gaza strip due to the
intensification of the Israeli-Palestinian conflict since June
2014 and other Palestinian IDPs in the Gaza Strip and West
Bank who fled as long ago as 1967, although confirmed
cumulative data do not go back beyond 2006) (2018)','9633f6ca190bee64fb1a4e2bb79fb6bbd0a7cf5f4f38470a1d7c3265601a9ab2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef128fe62bcb81ed81a57da270aecaca417b3fd66a38f701bba60bd198959c7e',2021,'MA','Morocco','transnational-issues',1036,'al
Bojador,
Guelta
Zemmur,
*
Ad Dakhla
A
(am MAURITANIA
Bir
Gandis Jichla
Disputes—International: stretching over 250,000 km, the
world’s 325 international land boundaries separate 195
independent states and 71 dependencies, areas of special
sovereignty, and other miscellaneous entities; ethnicity,
culture, race, religion, and language have divided states
into separate political entities as much as history, physical
terrain, political fiat, or conquest, resulting in sometimes
arbitrary and imposed boundaries; most maritime states
have claimed limits that include territorial seas and
exclusive economic zones; overlapping limits due _ to
adjacent or opposite coasts create the potential for 430
bilateral maritime boundaries of which 209 have
agreements that include contiguous and non-contiguous
segments; boundary, borderland/resource, and territorial
disputes vary in intensity from managed or dormant to
violent or militarized; undemarcated, indefinite, porous,
and unmanaged boundaries tend to encourage illegal cross-
border activities, uncontrolled migration, and
confrontation; territorial disputes may evolve from
historical and/or cultural claims, or they may be brought on
by resource competition; ethnic and cultural clashes
continue to be responsible for much of the territorial
fragmentation and internal displacement of the estimated
20.8 million people and cross-border displacements of
approximately 12.1 million refugees and asylum seekers
around the world as of mid-2013; over half a million
refugees were repatriated during 2012; other sources of
contention include access to water and mineral (especially
hydrocarbon) resources, fisheries, and arable land; armed
conflict prevails not so much between the uniformed armed
forces of independent states as between stateless armed
entities that detract from the sustenance and welfare of
local populations, leaving the community of nations to cope
with resultant refugees, hunger, disease, impoverishment,
and environmental degradation Refugees and _ internally
displaced persons: the UN High Commissioner for Refugees
(UNHCR) estimated that as of year-end 2018 there were
70.8 million people forcibly displaced worldwide; this
includes 25.9 million refugees, 3.5 million asylum seekers,
and 41.4 million conflict IDPs; the UNHCR estimates there
are currently at least 10 million stateless persons Trafficking
in persons: current situation: the International Labour
Organization conservatively estimated that 20.9 million
people in 2012 were victims of forced labor, representing
the full range of human trafficking (also referred to as
‘modern-day slavery’) for labor and sexual exploitation;
about one-third of reported cases involved crossing
international borders, which is often associated with sexual
exploitation; trafficking in persons is most prevalent in
southeastern Europe, Eurasia, and Africa and_ least
frequent in EU member states, Canada, the US, and other
developed countries (2012) tier rating: (2015)
Tier 2 Watch List: Countries that do not fully comply with the
minimum standards for the elimination of trafficking but
are making significant efforts to do so; (44 countries)
Antigua and Barbuda, Bolivia, Botswana, Bulgaria, Burkina
Faso, Burma, Cambodia, China, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cuba, Djibouti,
Egypt, Gabon, Ghana, Guinea, Guyana, Haiti, Jamaica,
Laos, Lebanon, Lesotho, Malaysia, Maldives, Mali,
Mauritius, Namibia, Pakistan, Papua New Guinea, Qatar,
Saudi Arabia, Saint Vincent and the Grenadines, Solomon
Islands, Sri Lanka, Sudan, Suriname, Tanzania, Timor-
Leste, Trinidad and ‘Tobago, Tunisia, Turkmenistan,
Ukraine, Uzbekistan Tier 3: countries that neither satisfy the
minimum standards for the elimination of trafficking nor
demonstrate a significant effort to do so; (23 countries)
Algeria, Belarus, Belize, Burundi, Central African Republic,
Comoros, Equatorial Guinea, Eritrea, The Gambia, Guinea-
Bissau, Iran, North Korea, Kuwait, Libya, Marshall Islands,
Mauritania, Russia, South Sudan, Syria, Thailand,
Venezuela, Yemen, Zimbabwe illicit drugs: cocaine:
worldwide coca leaf cultivation in 2013 likely amounted to
165,000 hectares, assuming a stable crop in Bolivia;
Colombia produced slightly less than half of the worldwide
crop, followed by Peru and Bolivia; potential pure cocaine
production increased 7% to 640 metric tons in 2013;
Colombia conducts an aggressive coca_ eradication
campaign, Peru has increased its eradication efforts, but
remains hesitant to eradicate coca in key growing areas;
opiates: worldwide illicit opium poppy cultivation increased
in 2013, with potential opium production reaching 6,800
metric tons; Afghanistan is world’s primary opium
producer, accounting for 82% of the global supply;
Southeast Asia was responsible for 12% of global opium;
Pakistan produced 3% of global opium; Latin America
produced 4% of global opium, and most was refined into
heroin destined for the US market (2015)','d87e474e01edb4d8d27ac86a11836706912711fe3d2c017ea46dc97e4f19b2d8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('343a74d12721933b05917e5bd0b465e2d44f3a097862ac026141da9c9ad3e2bd',2021,'GU','Guam','transnational-issues',1060,'GWP
Hazardous Wastes
Internet Service Provider ( ISP) directly to
the user’s home or business
fiscal year
Franc Zone
Group of 10
Group of 11
Group of 15
Group of 20
Group of 24
Group of 3
Group of 5
Group of 6
Group of 7
Group of 77
Group of 8
Group of 9
General Agreement on Tariffs and Trade; now
WTO
Gulf Cooperation Council
Global Caribbean Network
General Confederation of Trade Unions
gross domestic product
Greenwich Mean Time
gross national product
gross register ton
global system for mobile cellular','dc673d393b197a302cae5c29fbb159d09a4bf1321902befb45e5bd78f8d1cf0b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5b58202401f498d882a500a1bdf60e1bb8615df8c7f1ad135a1feb0d229dba4',2021,'PK','Pakistan','terrorism',53,'Terrorist groups—home based: al-Qa’ida (AQ): aim(s): eject
Western influence from the Islamic world, unite the
worldwide Muslim community, overthrow governments
perceived as un-Islamic, and ultimately, establish a pan-
Islamic caliphate under a_e strict Salafi Muslim
interpretation of sharia area(s) of operation: maintains
established networks and a longtime operational presence
in Afghanistan, especially in the south, northwest, and
northeast near the Afghanistan-Pakistan border; continues
to view Afghanistan as a safe haven for its leadership
(2019) Islamic Jihad Union (WU): aim(s): drive NATO forces out
of Afghanistan and destabilize the country; overthrow the
Government of Uzbekistan area(s) of operation: conducts
attacks in collaboration with other extremist groups,
including the Taliban and al-Qa’ida, against NATO and
Afghan forces across the country, especially in the northern
and eastern Paktika, Paktia, and Nangarhar provinces note:
IJU is a splinter movement of the Islamic Movement of
Uzbekistan (IMU); IJU emerged in the early 2000s after
internal splits over goals; IMU is focused on Central Asia,
but the IJU sought a more global focus (2019) Islamic
Movement of Uzbekistan (IMU): aim(s): enhance its networks
and secure territory in Afghanistan to establish a secure
presence from which it can pursue its historic goal of
establishing an Islamic state in the Fergana Valley, a fertile
valley spread across eastern Uzbekistan, southern
Kyrgyzstan, and northern Tajikistan area(s) of operation:
operates mostly in the north along the Afghanistan-Pakistan
border, with its heaviest presence in Badakhshan Province,
where IMU has operated paramilitary training camps and
bases note: the IMU is fractured and mostly supports ISIS-
K although some members have continued working with
the Taliban and al-Qa’ida (2019) Islamic State of Iraq and ash-
Sham-Khorasan (ISIS-K): aim(s): establish an Islamic caliphate
in Afghanistan, Pakistan, and parts of Central Asia; counter
Westerners and Shia Muslims area(s) of operation:
strongholds in Nangarhar and Kunar provinces near the
Afghanistan-Pakistan border and operating in Laghman,
Jowzjan provinces with pockets of support throughout
Afghanistan note: recruits from among the local population,
Central Asian extremists in Afghanistan, and other militant
groups, such as Tehrik-e Taliban Pakistan, the Afghan
Taliban, and the Islamic Movement of Uzbekistan; ISIS-K
and Afghan Taliban forces have fought sometimes over
control of territory or because of political or differences
(2019) Tehrik-e-Taliban Pakistan (TTP): aim(s): drive foreign
troops from Afghanistan; remove Pakistani forces from
Pakistan’s Federally Administered Tribal Areas (FATA) and,
ultimately, overthrow the Pakistan Government to
implement TTP’s strict interpretation of sharia area(s) of
operation: headquartered in several eastern Afghanistan
provinces near the Afghanistan-Pakistan border; operates
primarily along the northeastern Afghanistan-Pakistan
border, especially in Kunar and Paktika provinces, where
TTP has established sanctuaries (2019) Terrorist groups—
foreign based: al-Qa’ida in the Indian Subcontinent (AQIS):
aim(s): unite local jihadist movements in the Indian
subcontinent, pursue the overthrow of local governments,
exacerbate tensions between WHindus and Muslims,
establish an Islamic caliphate in the Indian subcontinent
area(s) of operation: heaviest presence is in Afghanistan,
especially in the eastern and southern regions, where most
of the Afghan-based leaders are located note: targets
primarily Afghan military and security personnel and US
interests (2019)
Haqqani Taliban Network (HQN): aim(s): expel US and Coalition
forces and replace the Afghan Government with an Islamic
state operating according to a_ strict Salafi Muslim
interpretation of sharia under the Afghan Taliban area(s) of
operation: stages attacks from kKurram and North
Waziristan Agency in Pakistan’s Federally Administered
Tribal Areas (FATA) across from Afghanistan’s southeastern
border; operational throughout the country, especially in
Kabul and Paktiya and Khost provinces note: plays a
leading role in planning and executing high-profile attacks
against Afghan personnel, NATO’s Resolute Support
Mission, US and Coalition Forces, and other US and
Western interests; strong ties with al-Qa’ida (2019) Harakat
ul-Mujahidin. (HUM): aim(s): enhance its networks and
paramilitary training in Afghanistan and, ultimately,
incorporate Kashmir into Pakistan; establish an Islamic
state in Kashmir area(s) of operation: maintains
paramilitary training camps in eastern Afghanistan (2019)
Harakat ul-Jihad-i-Islami (HUJI): aim(s): seeks the annexation of
the state of Jammu and Kashmir and the expulsion of
foreign forces from Afghanistan; implement sharia in
Afghanistan area(s) of operation: operations throughout
Afghanistan, targeting primarily Afghan Government
personnel and Coalition forces; has supplied fighters to the
Taliban (2019) Islamic Revolutionary Guard Corps—Qods Force
(IRGC-QF): aim(s): initially supported anti-Taliban initiatives
that complemented US goals in 2001, however, it gradually
adopted an anti-NATO/anti-Afghan government strategy
and began supplying financial assistance, training, and
weapons to the Taliban area(s) of operations: Taliban-
dominated areas of Afghanistan
(2019)
Jaish-e-Mohammed (JEM): aiin(s): annex the state of Jammu and
Kashmir to Pakistan and expel international forces from
Afghanistan.
area(s) of operation: historically operated in Afghanistan’s
eastern provinces (2019)
Jaysh al Adil: aim(s): enhance its operational networks and
capabilities for staging cross-border attacks into Iran
area(s) of operation: operational in the greater Balochistan
area, where fighters stage attacks targeting Iranian
security forces note: formerly known as Jundallah (2019)
Lashkar i Jhangvi (LJ): aim(s): enhance its networks and
paramilitary training in Afghanistan; exterminate Shia
Muslims, rid the Afghanistan-Pakistan region of Western
influence area(s) of operation: headquartered in the east;
operates paramilitary training camps near the Afghanistan-
Pakistan border across from the central area of Pakistan’s
Federally Administered Tribal Areas (FATA) region;
operatives conduct operations mostly against targets in
Pakistan, but also in Afghanistan; ties with al-Qa’ida and
the Taliban (2019) Lashkar-e Tayyiba (LT): aim(s): annex the
Indian state of Jammu and Kashmir to Pakistan and foment
Islamic insurgency in India; attack Western, Indian, and
Afghan interests in Afghanistan; support the Taliban’s
return to power; enhance its recruitment networks and
paramilitary training in Afghanistan, and, ultimately, install
Islamic rule throughout South Asia area(s) of operation:
mostly focused on Indian troops and civilian targets,
particularly in the states of Jammu and Kashmir, but has
also targeted Coalition forces in Afghanistan; maintains
several facilities, such as paramilitary training camps,
medical clinics serving locals, and schools for youths;
targets Pashtun youth for recruitment in the Administered
Tribal Areas (FATA) region (2019) TRANSNATIONAL
ISSUES
Disputes—international: Afghan, Coalition, and Pakistan
military meet periodically to clarify the alignment of the
boundary on the ground and on maps and since 2014 have
met to discuss collaboration on the Taliban insurgency and
counterterrorism efforts; Afghan and Iranian
commissioners have discussed boundary monument
densification and resurvey; Iran protests Afghanistan’s
restricting flow of dammed Helmand River tributaries
during drought; Pakistan has sent troops across and built
fences along some remote tribal areas of its treaty-defined
Durand Line border with Afghanistan which serve as bases
for foreign terrorists and other illegal activities; Russia
remains concerned about the smuggling of poppy
derivatives from Afghanistan through Central Asian
countries Refugees and internally displaced persons: refugees
(country of origin): 72,194 (Pakistan) (2018) IDPs: 2.598
million (mostly Pashtuns and Kuchis displaced in the south
and west due to natural disasters and political instability)
(2018) Illicit drugs: world’s largest producer of opium; poppy
cultivation increased 63 percent, to 328,304 hectares in
2017; while eradication increased slightly, it still remains
well below levels achieved in 2015; the 2017 crop yielded
an estimated 9,000 mt of raw opium, a 88% increase over
2016; the Taliban and other antigovernment groups
participate in and profit from the opiate trade, which is a
key source of revenue for the Taliban inside Afghanistan;
widespread corruption and instability impede counterdrug
efforts; most of the heroin consumed in Europe and Eurasia
is derived from Afghan opium; Afghanistan is also
struggling to respond to a burgeoning domestic opiate
addiction problem; a 2015 national drug use survey found
that roughly 11% of the population tested positive for one
or more illicit drugs; vulnerable to drug money laundering
through informal financial networks; illicit cultivation of
cannabis and regional source of hashish (2018) AKROTIRI
0 3 6km
oS Omi
Terrorist groups—home based:
al-Qa’ida (AQ): aim(s): eject Western influence from the
Islamic world, unite the worldwide Muslim community,
overthrow governments perceived as un-Islamic and,
ultimately, establish a pan-Islamic caliphate under a strict
Salafi Muslim interpretation of sharia area(s) of operation:
presence in Pakistan’s Federally Administered Tribal Areas
(FATA) near the Pakistan-Afghanistan border (2018) al-Qa’ida
in the Indian Subcontinent (AQIS): aim(s): establish an Islamic
caliphate in the Indian subcontinent area(s) of operation:
operational throughout the country, targeting military and
security personnel; responsible for numerous attacks in
Karachi; stages attacks in Afghanistan, India, and
Bangladesh, where the group is the most active (2018)
Haqqani Network (HQN): aim(s): enhance its operational
networks and capabilities for staging cross-border attacks
in Afghanistan; replace the Afghan Government with an
Islamic state operating according to a strict Salafi Muslim
interpretation of sharia area(s) of operation: headquartered
in the Federally Administered Tribal Areas (FATA) region
located across from Afghanistan’s southeastern border;
fighters have staged numerous cross-border operations
from Kurram and North Waziristan Agency in the FATA into
Afghanistan, targeting Afghan, US, and NATO forces and
other Afghan Government personnel and Westerners for
attack or kidnappings for ransom (2018) Harakat ul-Jihad-i-
Islami (HUJI): aimm(s): overthrow the Pakistan Government and
implement sharia throughout the country area(s) of
operation: headquartered in Pakistan, where the group
operates several camps; remains heavily active in the
southern area of Azad Kashmir (2018) Harakat ul-Mujahidin
(HUM): aim(s): annex Kashmir to Pakistan and establish an
Islamic state in Kashmir’ area(s) of operation:
headquartered in Islamabad, with an operational presence
in Muzaffarabad in Azad Kashmir, where operatives stage
attacks against India; maintains training and paramilitary
camps in the country’s Federally Administered Tribal Areas
(FATA) region (2018) Jaish-e-Mohammed (JEM): aim/(s): unite
Kashmir with Pakistan, install sharia in Pakistan, and drive
foreign forces from Afghanistan area(s) of operation:
headquartered in Punjab Province; stages attacks against
Indian forces, primarily in Jammu and Kashmir State (2018)
Jaysh al Adl: aim/(s): seeks greater autonomy for Balochis in
Pakistan and Iran area(s) of operation: headquartered in
Balochistan Province, where operatives stage attacks inside
Iran against Shia Muslims, primarily targets Iranian
soldiers and security personnel note: formerly known as
Jundallah (2018)
Lashkar i Jhangvi (LJ): aim(s): exterminate Shia Muslims, rid
the region of Western influence and, ultimately, establish an
Islamic state in Pakistan under sharia area(s) of operation:
has a growing presence in Karachi, the capital of Sindh
Province; loosely coordinated cells are spread across the
country, primarily in Punjab and Balochistan provinces,
Karachi, and in the Federally Administered Tribal Areas
(FATA) region; majority of attacks are against local and
foreign Shia Muslims and government personnel and
facilities (2018) Lashkar-e Tayyiba (LT): aim/(s): return the
Indian state of Jammu and Kashmir to Pakistan and foment
Islamic insurgency in India; enhance its recruitment
networks and paramilitary training in South Asia; and,
ultimately, implement Islamic rule throughout South Asia
area(s) of operation: headquartered in Lahore, Punjab
Province, with an operational presence throughout the
country; active in both the Pakistan-administered and India-
administered Kashmir regions note: does not conduct
attacks within Pakistan; often operates under the guise of
its charitable affiliates, including Jamaat-ud-Dawa (2018)
Terrorist groups—foreign based:
Indian Mujahedeen (IM): aim(s): stated goal is to carry out
terrorist attacks against Indians for perceived atrocities
against Indian Muslims following the 2002 Gujarat riots
area(s) of operation: Punjab and Sindh Provinces and
Pakistan-controlled Kashmir (2018)
Islamic State of Iraq and ash-Sham-Khorasan (ISIS-K): @1m(S):
establish an Islamic caliphate in the Afghanistan-Pakistan
region; oppose Pakistan Government and Westerners;
oppose Shia Muslim population area(s) of operation:
maintains an operational and recruitment presence
throughout the country, primarily along the Pakistan-
Afghanistan border to stage attacks inside Afghanistan and
Pakistan note: recruits from among the local population
and other militant groups such as Tehrik-e Taliban
Pakistan, the Afghan Taliban, and the Islamic Movement of
Uzbekistan (2018) Tehrik-e-Taliban Pakistan (TTP): aim(s):
remove Pakistani forces from the Federally Administered
Tribal Areas (FATA) region; overthrow the _ Pakistan
Government to implement TTP’s strict interpretation of
sharia area(s) of operation: maintains a large presence in
Karachi, the capital of Sindh Province; trains and deploys
fighters in the tribal belt in the Pashtun areas along the
Pakistan-Afghanistan border, especially in Kunar and
Paktika provinces where TTP has established sanctuaries;
operationally active in the North Waziristan, South
Waziristan, and Balochistan regions; targets Pakistan
Government officials and military, security, and police
personnel, as well as Westerners, pro-government tribal
elders, Shia Muslims, and education figures and advocates
(2018) TRANSNATIONAL ISSUES
Disputes—International: various talks and confidence-building
measures cautiously have begun to defuse tensions over
Kashmir, particularly since the October 2005 earthquake in
the region; Kashmir nevertheless remains the site of the
world’s largest and most militarized territorial dispute with
portions under the de facto administration of China (Aksai
Chin), India Qammu and Kashmir), and Pakistan (Azad
Kashmir and Northern Areas); UN Military Observer Group
in India and Pakistan has maintained a small group of
peacekeepers since 1949; India does not recognize
Pakistan’s ceding historic Kashmir lands to China in 1964;
India and Pakistan have maintained their 2004 cease-fire in
Kashmir and initiated discussions on defusing the armed
standoff in the Siachen glacier region; Pakistan protests
India’s fencing the highly militarized Line of Control and
construction of the Baglihar Dam on the Chenab River in
Jammu and Kashmir, which is part of the larger dispute on
water sharing of the Indus River and its tributaries; to
defuse tensions and prepare for discussions on a maritime
boundary, India and Pakistan seek technical resolution of
the disputed boundary in Sir Creek estuary at the mouth of
the Rann of Kutch in the Arabian Sea; Pakistani maps
continue to show the Junagadh claim in India’s Gujarat
State; since 2002, with UN assistance, Pakistan has
repatriated 3.8 million Afghan refugees, leaving about 2.6
million; Pakistan has sent troops across and built fences
along some remote tribal areas of its treaty-defined Durand
Line border with Afghanistan, which serve as bases for
foreign terrorists and other illegal activities; Afghan,
Coalition, and Pakistan military meet periodically to clarify
the alignment of the boundary on the ground and on maps
Refugees and internally displaced persons: refugees (country of
origin): 2.58-2.68 million (1.4 million registered, 1.18-1.28
million undocumented) (Afghanistan) (2017) IDPs: 119,000
(primarily those who remain displaced by counter-terrorism
and counter-insurgency operations and violent conflict
between armed non-state groups in the _ Federally
Administered Tribal Areas and _ Khyber-Paktunkwa
Province; more than 1 million displaced in northern
Waziristan in 2014; individuals also have been displaced by
repeated monsoon floods) (2018) Trafficking in persons:
current situation: Pakistan is a source, transit, and
destination country for men, women, and _ children
subjected to forced labor and sex trafficking; the largest
human trafficking problem is bonded labor in agriculture,
brickmaking and, to a lesser extent, fishing, mining and
carpet-making; children are bought, sold, rented, and
placed in forced begging rings, domestic service, small
shops, brick-making factories, or prostitution; militant
groups also force children to spy, fight, or die as suicide
bombers, kidnapping the children or getting them from
poor parents through sale or coercion; women and girls are
forced into prostitution or marriages; Pakistani adults
migrate to the Gulf States and African and European states
for low-skilled jobs and sometimes become victims of
forced labor, debt bondage, or prostitution; foreign adults
and children, particularly from Afghanistan, Bangladesh,
and Sri Lanka, may be subject to forced labor, and foreign
women may be sex trafficked in Pakistan, with refugees and
ethnic minorities being most vulnerable tier rating: Tier 2
Watch List—Pakistan does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; the
government lacks political will and capacity to fully address
human trafficking, as evidenced by ineffective law
enforcement efforts, official complicity, penalization of
victims, and the continued conflation of migrant smuggling
and human trafficking by many officials; not all forms of
trafficking are prohibited; an anti-trafficking bill drafted in
2013 to address gaps in existing legislation remains
pending, and a national action plan drafted in 2014 is not
finalized; feudal landlords and brick kiln owners use their
political influence to protect their involvement in bonded
labor, while some police personnel have taken bribes to
ignore prostitution that may have included sex trafficking;
authorities began to use standard procedures for the
identification and referral of trafficking victims, but it is not
clear how widely these methods were practiced; in other
instances, police were reluctant to assist NGOs with
rescues and even punished victims for crimes committed as
a direct result of being trafficked (2015) Illicit drugs:
significant transit area for Afghan drugs, including heroin,
opium, morphine, and hashish, bound for Iran, Western
markets, the Gulf States, Africa, and Asia; financial crimes
related to drug trafficking, terrorism, corruption, and
smuggling remain problems; opium poppy cultivation
estimated to be 930 hectares in 2015; federal and
provincial authorities continue to conduct anti-poppy
campaigns that utilizes forced eradication, fines, and
arrests PALAU
KAYANGEL
ISLANDS
PALAU ISLANDS ©) sung
MELEKEOKAS fr vinsse
CHELBACHES J%K.,
ror
Beliliou
Angaur
SONSORAL
ISLANDS :','a7979ed3ecb76a2520a24e5271195d5b82ebf0857b741ed1a942387d267b4aa5','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464561a1b085b0fc143cdb108caf43b632efddf7b3d41ae81582ebe5e600e01f',2021,'DZ','Algeria','terrorism',78,'Terrorist groups—home based: A/-Qa’ida in the Islamic Maghreb
(AQIM): aim: overthrow various African regimes and
replace them with one ruled by sharia; establish a regional
Islamic caliphate across all of North and West Africa
area(s) of operation: based in southern and eastern Algeria
(including isolated parts of the Kabylie region); also
operates in Burkina Faso, Cote D’Ivoire, Libya, northern
Mali, Niger, and Tunisia note: al-Qa’ida’s affiliate in North
Africa; Tunisia-based branch known as the Ugbah bin Nafi
Battalion; Mali-based cadre merged with allies to form
Jamaat Nusrat al-Islam wal-Muslimin (JNIM) in March
2017, which pledged allegiance to AQIM and al-Qa’ida
(2019) Islamic State of Iraq and ash-Sham (ISIS)-Algeria: aim(S):
replace the Algerian Government with an Islamic state and
implement ISIS’s strict interpretation of sharia; attack
Algerian security services, local government targets, and
Western interests area(s) of operation: maintains an
operational and recruitment presence mostly in the
northeast note: formerly known as Jund al-Khilafa—Algeria
(JAK-A) (2019)
Terrorist groups—foreign based: al-Mulathamun Battalion:
aim(s): expel Westerners from North and West Africa;
create Islamic state area(s) of operation: most active in
Mali, but claimed responsibility for the January 2013 attack
against the Tiguentourine gas facility near In Amenas, in
southeastern Algeria (2018) TRANSNATIONAL ISSUES
Disputes—international: Algeria and many other states reject
Moroccan administration of Western Sahara; the Polisario
Front, exiled in Algeria, represents the “Sahrawi Arab
Democratic Republic” which Algeria recognizes; the
Algerian-Moroccan land border remains closed; dormant
disputes include Libyan claims of about 32,000 sq km of
southeastern Algeria and the National Liberation Front’s
(FLN) assertions of a claim to Chirac Pastures in
southeastern Morocco.
Refugees and internally displaced persons: refugees (country of
origin): more than 100,000 (Western Saharan Sahrawi,
mostly living in Algerian-sponsored camps in_ the
southwestern Algerian town of Tindouf) (2018) Trafficking in
persons: Current situation: Algeria is a transit and, to a
lesser extent, a destination and source country for women
subjected to forced labor and sex trafficking and, to a
lesser extent, men subjected to forced labor; criminal
networks, sometimes extending to Sub-Saharan Africa and
to Europe, are involved in human smuggling and trafficking
in Algeria; Sub-Saharan adults enter Algeria voluntarily but
illegally, often with the aid of smugglers, for onward travel
to Europe, but some of the women are forced into
prostitution, domestic service, and begging; some Sub-
Saharan men, mostly from Mali, are forced into domestic
servitude; some Algerian women and children are also
forced into prostitution domestically tier rating: Tier 3-
Algeria does not fully comply with the minimum standards
for the elimination of trafficking and is not making
significant efforts to do so: some officials denied the
existence of human trafficking, hindering law enforcement
efforts; the government reported its first conviction under
its anti-trafficking law; one potential trafficking case was
investigated in 2014, but no suspected offenders were
arrested; no progress was made in identifying victims
among vulnerable groups or referring them to NGO-run
protection service, which left trafficking victims subject to
arrest and detention; no anti-trafficking public awareness
or educational campaigns were conducted (2015)
Terrorist groups—home based:
al-Mulathamun Battalion: aim(s): implement ISIS’s _ strict
interpretation of Sharia; replace the Malian Government
with an Islamic state area(s) of operation: headquartered in
the north; targets primarily international interests,
especially Westerners and Western entities (2018) al-Qa’ida-
affiliated Jama’at Nusrat al-Islam wal-Muslimin (JNIM): a@im(S):
establish an Islamic state centered in Mali area(s) of
operation: primarily based in northern and central Mali;
targets Western and local interests in West Africa and
Sahel; has claimed responsibility for attacks in Mali, Niger
and Burkina Faso note: pledged allegiance to al-Qa’ida and
AQIM; holds Western hostages; wages attacks against
security and peacekeeping forces in Mali (2018) Islamic State
of Iraq and ash-sham networks in the Greater Sahara (ISGS): aiin(Ss):
replace regional governments with an Islamic state area(s)
of operation: mostly concentrated along the Mali-Niger
border region; targets primarily security forces (2018)','9b7c143d49304fc14c3c4cfedb243df8ccd09367cb3bde5536b124fadad0033d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f31c53daead8ab6cb7a2c6f668940a7ad882d79f0e5452d17e9789d63f150c0',2021,'AQ','Antarctica','terrorism',114,'Terrorist groups—foreign based: Hizballah: aim(s): largely
limited to generating political and financial support from
the Lebanese diaspora area(s) of operation: conducted
operations in the 1990s; maintains a limited presence
(2019) TRANSNATIONAL ISSUES
Disputes—international: Argentina continues to assert its
claims to the UK-administered Falkland Islands (Islas
Malvinas), South Georgia, and the South Sandwich Islands
in its constitution, forcibly occupying the Falklands in 1982,
but in 1995 agreed to no longer seek settlement by force;
UK continues to reject Argentine requests for sovereignty
talks; territorial claim in Antarctica partially overlaps UK
and Chilean claims; uncontested dispute between Brazil
and Uruguay over Braziliera/Brasiliera Island in the
Quarai/Cuareim River leaves the tripoint with Argentina in
question; in 2010, the IC] ruled in favor of Uruguay’s
operation of two paper mills on the Uruguay River, which
forms the border with Argentina; the two countries formed
a joint pollution monitoring regime; the joint boundary
commission, established by Chile and Argentina in 2001
has yet to map and demarcate the delimited boundary in
the inhospitable Andean Southern Ice Field (Campo de
Hielo Sur); contraband smuggling, human trafficking, and
illegal narcotic trafficking are problems in the porous areas
of the border with Bolivia Refugees and internally displaced
persons: refugees (country of origin): 182,942 (Venezuela)
(economic and political crisis; includes Venezuelans who
have claimed asylum or have received alternative legal
stay) (2019) Illicit drugs: a transshipment country for cocaine
headed for Europe, heroin headed for the US, and
ephedrine and pseudoephedrine headed for Mexico; some
money-laundering activity, especially in the Tri-Border
Area; law enforcement corruption; a source for precursor
chemicals; increasing domestic consumption of drugs in
urban centers, especially cocaine base and synthetic drugs','db14254e1623aff6c8d07711cdf27aae919b83b2464fc1ea49f71b0576626026','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e514e5640b32acf0844dff5cf89c4020eb1d187d049a3c39577d721b728afc2',2021,'AM','Armenia','terrorism',115,'Alaverdis
La
ljevan
Gyumri < “*Vanadzor
Arag A :
: *Hrazdan
Ejmiatsin Abovyan
e , ek 4
Armavir YEREVAN <
eArtashat
eVardenis','fbea6d7d0ea0658bfd6e9a1e204465d39e89163f6efb15ab1d567cd50d95fbb8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('194ad529f8647786e1950c37afca8cf30629f2ee57692f0a6198751182a82998',2021,'BH','Bahrain','terrorism',148,'Terrorist groups—foreign based:
Islamic Revolutionary Guard Corps—Qods Force (IRGC-QF): aiin(s):
seeks to overthrow the Sunni al-Khalifa ruling family, and
to expel America’s military presence; supports anti-
government insurgent groups with funding, weapons, and
training area(s) of operation: Bahrain
(2019)','42970f0fdc2a384cde5f910e6ef23bfcc42e54ae0586687425ccd93aa234ffb4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb1d36bd9cda1166811294c922b173f4f706f27dcd0a8badc4fcdf552b6f1081',2021,'IN','India','terrorism',156,'Terrorist groups—home based:
Harakat ul-Jihad-i-Islami/Bangladesh (HUJI-B): aim(s): install an
Islamic state in Bangladesh area(s) of operation:
headquartered in Bangladesh and mostly active in the
southeast; maintains a network of madrassas_ in
Bangladesh; has links with al-Qa’ida and Pakistan-based
terror groups advocating similar objectives, including
Harakat-ul Jihad Islami (HUJI) and Lashkar e-Tayibba (LeT)
(2019) Islamic State of Iraq and ash-Sham (ISIS) networks in
Bangladesh: aim(s): replace the Bangladesh Government with
an Islamic state and implement ISIS’s strict interpretation
of Sharia; ISIS operates in Bangladesh under the name
Islamic State in Bangladesh (ISB) area(s) of operation:
operates primarily in Dhaka
note: targets foreigners, foreign aid workers, university
professors, students, and _ secular’ bloggers for
assassination; core ISIS refers to its Bangladesh branch as
Bengal (2019) Terrorist groups—foreign based: al-Qa’ida (AQ):
aim(s): overthrow the Bangladesh Government and,
ultimately, establish a pan-Islamic caliphate under a strict
Salafi Muslim interpretation of sharia area(s) of operation:
operates in collaboration with its al-Qa’ida in the Indian
Subcontinent affiliate note: also known as Ansar al-Islam in
Bangladesh (2019)
al-Qa’ida in the Indian Subcontinent (AQIS): aim(s): protect
Muslims in Bangladesh from perceived injustices and,
ultimately, establish an Islamic caliphate in the Indian
subcontinent area(s) of operation: active throughout the
country, targeting primarily military and_ security
personnel, but also activists, bloggers, academics, and
religious minorities note: also known as Ansar al-Islam in
Bangladesh (2019)','0ec62dd77a2309a3a643eae8b03d60af526d5bbc21eac361f565d09641281b4c','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddff7cf5e9c6a5d3b71e2032d759e13b3a734960236eae54e6ff4742b965ae5b',2021,'GR','Greece','terrorism',246,'Terrorist groups—home based:
Ansarul Islam: aim(s): to end government control in parts of
the north of the country and enforce sharia in the area of
the ancient Fulani Empire of Djeelgodji area(s) of
operation: targets Burkinabe security forces and civilians
primarily in the country’s northern Sahel Region (along the
border with Mali) (2019) Islamic State of Iraq and ash-sham
networks in the Greater Sahara (ISGS): aim/(Ss): replace regional
governments with an Islamic state area(s) of operation:
mostly concentrated in the Mali-Burkina Faso-Niger tri-
border region; targets primarily security forces (2019)
Terrorist groups—foreign based:
al-Mulathamun Battalion: aim(s): replace several African
governments, including Burkina Faso’s government, with
an Islamic state area(s) of operation: engages in
kidnappings for ransom and violent activities across the
country, including in the capital Ouagadougou (2018)
al-Qa’ida-affiliated Jama’at Nusrat al-Islam wal-Muslimin (JNIM):
aim(s): establish an Islamic state centered in Mali area(s)
of operation: primarily based in northern and central Mali;
targets Western and local interests in West Africa and
Sahel; has claimed responsibility for attacks in Mali, Niger,
and Burkina Faso note: JNIM is an umbrella coalition of al-
Qaeda-aligned groups, including Ansar al-Dine, al-Qa’ida in
the Islamic Maghreb, al-Mouabitoun, and the Macina
Liberation Front; it conducts attacks, assassinations, and
improvised explosive device (IED) attacks on UN, French,
and local security forces (2019) TRANSNATIONAL ISSUES
Disputes—International: adding to illicit cross-border activities,
Burkina Faso has issues concerning unresolved boundary
alignments with its neighbors; demarcation is currently
underway with Mali; the dispute with Niger was referred to
the ICJ in 2010, and a dispute over several villages with
Benin persists; Benin retains a border dispute with Burkina
Faso around the town of Koualou Refugees and _ internally
displaced persons: refugees (country of origin): 25,442 (Mali)
(2019) IDPs: 560,033
(2019)
Trafficking in persons: Current situation: Burkina Faso is a
source, transit, and destination country for women and
children subjected to forced labor and sex trafficking;
Burkinabe children are forced to work as farm hands, gold
panners and washers, street vendors, domestic servants,
and beggars or in the commercial sex trade, with some
transported to nearby countries; to a lesser extent,
Burkinabe women are recruited for legitimate jobs in the
Middle East or Europe and subsequently forced into
prostitution; women from other West African countries are
also lured to Burkina Faso for work and subjected to forced
prostitution, forced labor in restaurants, or domestic
servitude tier rating: Tier 2 Watch List—Burkina Faso does
not fully comply with the minimum standards for the
elimination of trafficking; however, it is making significant
efforts to do so; law enforcement efforts decreased in 2014,
with a significant decline in trafficking prosecutions (none
for forced begging involving Koranic school teachers—a
prevalent form of trafficking) and no convictions, a 2014
law criminalizing the sale of children, child prostitution,
and child pornography is undermined by a provision
allowing offenders to pay a fine in lieu of serving prison
time proportionate to the crime; the government sustained
efforts to identify and protect a large number of child
victims, relying on support from NGOs and international
organizations; nationwide awareness-raising activities were
sustained, but little was done to stop forced begging (2015)
BURMA
Monywa,
"Mandalay','ac1de90a527ac63e1dfc974cbfa834f2317e84c544d9c62a2e5be2709ec2831b','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78fa212b27cda6b2417543bf92340dca7d472ff9778fba1fd34503bf8e16d1ec',2021,'CM','Cameroon','terrorism',290,'Terrorist groups—foreign based:
Boko Haram: aiim(s): establish an Islamic caliphate across
Africa area(s) of operation: conducts attacks, suicide
bombings, targeted killings, kidnappings, and raids for
supplies, especially in the Far North Region along
Cameroon’s border with Nigeria; perpetrates multiple and
indiscriminate killings against’ civilians-Muslim and
Christian alike-but also against government officials and
security forces note: violently opposes any political or
social activity associated with Western society, including
voting, attending secular schools, and wearing Western
dress (2019) Islamic State of Iraq and ash-Sham (ISIS)-West Africa:
aim(s): implement ISIS’s strict interpretation of Sharia;
replace the Nigerian Government with an Islamic state
area(s) of operation: based primarily in Northeast Nigeria
along the border with Niger, with its largest presence in
northeast Nigeria and the Lake Chad region; targets
primarily regional military installations (2019)','11e7692ca3ff993a63a0b3079eaa03758c66608047aa17713549b018bda71fc2','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('685977ea5331e847bcf7f3f63a4c7672e79de06de191bbc08862506d0a4f4d0e',2021,'TD','Chad','terrorism',324,'Terrorist groups—foreign based:
Boko Haram: aim(s): establish an Islamic state under strict
Sharia across northern Nigeria and the Lake Chad Basin
region bordering Cameroon, Chad, and Niger area(s) of
operation: most active in northeastern Nigeria (states of
Yobe and Borno), but also operates in northern Cameroon,
southeast Niger, and areas of Chad along the Nigerian
border, particularly in the Lake Chad Basin; police also
have arrested suspected Boko Haram members in Chad’s
capital, N’Djamena note: Boko Haram conducts attacks,
suicide bombings, targeted killings, kidnappings, and raids
for supplies against both civilians and security forces;
violently opposes any political or social activity associated
with Western society, including voting, attending secular
schools, and wearing Western dress (2019) Islamic State of
Iraq and ash-Sham (ISIS)-West Africa: aim(s): implement ISIS’s
strict interpretation of Sharia; replace regional
governments with an Islamic state area(s) of operation:
based primarily in northeast Nigeria along the border with
Niger and Chad, with its largest presence in northeast
Nigeria and the Lake Chad Basin area _ (2018)','8f8723c9f2c60a86b6d760a6110d6476f84f85ff0dd57f05e350b3f159068fa3','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62fe8bfac1f56a9c4b24d22c98392615b4f0bde0c6300d9276c9ab4becf93fa2',2021,'BR','Brazil','terrorism',354,'Terrorist groups—home based:
National Liberation Army (Ejercito de Liberacion Nacional, ELN):
aim(s): Marxist-Leninist group that seeks to defend
Colombians whom they believed to be victims of social,
political, and economic injustices perpetrated by the
Colombian government area(s) of operation: the nation’s
largest remaining insurgent group operates mainly in the
rural and mountainous areas of northern, northeastern, and
southwestern Colombia as well as border regions with
Venezuela note: the group has a long history of engaging in
narcotics production and trafficking, extortion of foreign
and local companies, and kidnappings for ransom to fund
operations; historically focused on attacking economic
infrastructure, in particular oil and gas pipelines and
electricity pylons (2019) Revolutionary Armed Forces of Colombia
(Fuerzas Armadas Revolucionarias de Colombia, FARC): aim(S):
signed a peace accord with the Colombian Government in
2016 (approved by the Colombian Congress on 30
November 2016) and entered the political arena in
September 2017 as the People’s Alternative Revolutionary
Force (also known as FARC) in order to change Colombia’s
economic model, push an agenda focused on social justice
and development of rural areas; historically, the FARC’s
aim has been to install a Marxist-Leninist regime in
Colombia through a violent revolution area(s) of operation:
NA (2018)
Terrorist groups—foreign based:
National Liberation Army (Ejercito de Liberacion Nacional, ELN):
aim(s): enhance its narcotics trafficking networks in
Venezuela area(s) of operation: maintains a narcotics
trafficking presence, facilitating the transshipment of
narcotics through the country (2018) TRANSNATIONAL
ISSUES
Disputes—International: Claims all of the area west of the
Essequibo River in Guyana, preventing any discussion of a
maritime boundary; Guyana has expressed its intention to
join Barbados in asserting claims before the UN
Convention on the Law of the Sea that Trinidad and
Tobago’s maritime boundary with Venezuela extends into
their waters; dispute with Colombia over maritime
boundary and Venezuelan administered Los Monjes Islands
near the Gulf of Venezuela; Colombian organized illegal
narcotics and paramilitary activities penetrate Venezuela’s
shared border region; US, France, and the Netherlands
recognize Venezuela’s granting full effect to Aves Island,
thereby claiming a Venezuelan Economic’ Exclusion
Zone/continental shelf extending over a large portion of the
eastern Caribbean Sea; Dominica, Saint Kitts and Nevis,
Saint Lucia, and Saint Vincent and the Grenadines protest
Venezuela’s full effect claim Refugees and internally displaced
persons: refugees (country of origin): 67,156 (Colombia)
(2018) Trafficking in persons: Current situation: Venezuela is a
source and destination country for men, women, and
children subjected to sex trafficking and forced labor;
Venezuelan women and girls, sometimes lured from poor
interior regions to urban and tourist areas, are trafficked
for sexual exploitation within the country, as well as in the
Caribbean; Venezuelan children are exploited, frequently
by their families, in domestic servitude; people from South
America, the Caribbean, Asia, and Africa are sex and labor
trafficking victims in Venezuela; thousands of Cuban
citizens, particularly doctors, who work in Venezuela on
government social programs in exchange for the provision
of resources to the Cuban Government experience
conditions of forced labor tier rating: Tier 3—Venezuela does
not fully comply with the minimum standards for the
elimination of trafficking and is not making significant
efforts to do so; in 2014, the government appeared to
increase efforts to hold traffickers criminally accountable,
but a lack of government data made anti-trafficking law
enforcement efforts difficult to assess; publically available
information indicated many cases pursued under anti-
trafficking law involved illegal adoption rather than sex and
labor trafficking; authorities identified a small number of
trafficking victims, and victim referrals to _ limited
government services were made on an ad hoc basis;
because no specialized facilities are available for trafficking
victims, women and child victims accessed centers for
victims of domestic violence or at-risk youth, and services
for men were virtually non-existent; NGOs provided some
services to sex and labor trafficking victims; Venezuela has
no permanent anti-trafficking interagency body, no national
anti-trafficking plan, and still has not passed anti-
trafficking legislation drafted in 2010 (2015) Illicit drugs:
small-scale illicit producer of opium and coca for the
processing of opiates and coca derivatives; however, large
quantities of cocaine, heroin, and marijuana transit the
country from Colombia bound for US and _ Europe;
significant narcotics-related money-laundering activity,
especially along the border with Colombia and on
Margarita Island; active eradication program primarily
targeting opium; increasing signs of drug-related activities
by Colombian insurgents on border VIETNAM
Hong. 2
HANOI Gai f%
* o5 627 »
Haiphong*’> *
” THAILAND
Nha Trang3
Cam Ranh}
"Ne XS :
Dao Phy LONG Xue “SY >
Quoc '' Can ~','43c8319b4d5c006b60095522732c2afde15041c5c86f0a32e24c4cc79f27c2c8','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d22f47298d3400599973d452fa4d3fa4fb350dc5d2974014e2be343fd2f96cc2',2021,'DJ','Djibouti','terrorism',423,'Terrorist groups—foreign based:
al-Shabaab: aim(s): punish Djibouti for participating in the
African Union Mission in Somalia; compel Djibouti to
withdraw troops from Somalia area(s) of operation:
maintains minimal operational presence; last conducted an
attack in Djibouti in 2014 (2019) TRANSNATIONAL
ISSUES
Disputes—international: Djibouti maintains economic ties and
border accords with “Somaliland” leadership while
maintaining some political ties to various factions in
Somalia; Kuwait is chief investor in the 2008 restoration
and upgrade of the Ethiopian-Djibouti rail link; in 2008,
Eritrean troops moved across the border on Ras Doumera
peninsula and occupied Doumera Island with undefined
sovereignty in the Red Sea Refugees and internally displaced
persons: refugees (country of origin): 13,242 (Somalia)
(2019) Trafficking in persons: Current situation: Djibouti is a
transit, source, and destination country for men, women,
and children subjected to forced labor and sex trafficking;
economic migrants from East Africa en route to Yemen and
other Middle East locations are vulnerable to exploitation
in Djibouti; some women and girls may be forced into
domestic servitude or prostitution after reaching Djibouti
City, the Ethiopia-Djibouti trucking corridor, or Obock—the
main crossing point into Yemen; Djiboutian and foreign
children may be forced to beg, to work as domestic
servants, or to commit theft and other petty crimes tier
rating: Tier 2 Watch List—Djibouti does not fully comply
with the minimum standards for the elimination of
trafficking; however, it is making significant efforts to do
so; in 2014, Djibouti was granted a waiver from an
otherwise required downgrade to Tier 3 because _ its
government has a written plan that, if implemented would
constitute making significant efforts to bring itself into
compliance with the minimum standards for the elimination
of trafficking; one forced labor trafficker was convicted in
2014 but received a suspended sentence inadequate to
deter trafficking; authorities did not investigate or
prosecute any other forced labor crimes, any sex trafficking
offenses, or any officials complicit in human trafficking, and
remained limited in their ability to recognize or protect
trafficking victims; official round-ups, detentions, and
deportations of non-Djiboutian residents, including children
without screening for trafficking victims remained routine;
the government did not provide care to victims but
supported local NGOs operating centers that assisted
victims (2015) DOMINICA
* Portsmouth
Marigot,
A
Morne Diablotins
Saint
,Joseph
La Plaine)
yROSEAU
Berekua
*','a05768c179098c1b8b0c0cbc7ab502cc399a17341f0a92d9a42a2494d6599d53','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e79f26935f03ad11530ca3d1a6005ebd1340045e2da37c0917234c0183d96f38',2021,'EG','Egypt','terrorism',449,'Terrorist groups—home based:
Harakat Sawa’d Misr (HASM): aim(s): overthrow the Egyptian
Government area(s) of operation: Cairo, Nile Delta,
Western Desert (2018)
Islamic State of Iraq and ash-Sham (ISIS)-Sinai Province: aim(s):
spread the ISIS caliphate by eliminating the Egyptian
Government, destroying Israel, and establishing an Islamic
emirate in the Sinai area(s) of operation: operations are
based out of the Sinai Peninsula, but its reach extends to
Cairo, the Egyptian Nile Valley, and Gaza; operations
mainly target Egyptian security forces, but also include
attacks on civilians, as well as kidnappings note: formerly
known as Ansar Bayt al-Maqdis; core ISIS refers to Egypt
as its Wilayat Sinai (2018) LIWA AL-THAWRA: AIM(S):
OVERTHROW THE EGYPTIAN GOVERNMENT
area(s) of operation: Cairo, Monofeya, and Qalyubia
governorates (2019)
Terrorist groups—foreign based:
al-Qa’ida (AQ): aim(s): overthrow the Egyptian Government
and, ultimately, establish a pan-Islamic caliphate under a
strict Salafi Muslim interpretation of sharia area(s) of
operation: maintains a longtime operational presence and
established networks (2018) Army of Islam (AOI): aim(s):
disrupt the Egyptian Government’s efforts to provide
security and, ultimately, establish an Islamic caliphate
area(s) of operation: operational mainly in Cairo and the
Sinai Peninsula
note: associated with ISIS-Sinai Province; targets Israeli
Government interests, sometimes in collaboration with the
Mujahidin Shura Council in the Environs of Jerusalem
(2018) TRANSNATIONAL ISSUES
Disputes—International: Sudan claims but Egypt de_ facto
administers security and economic development of Halaib
region north of the 22nd parallel boundary; Egypt no
longer shows its administration of the Bir Tawil trapezoid in
Sudan on its maps; Gazan breaches in the security wall
with Egypt in January 2008 highlight difficulties in
monitoring the Sinai border; Saudi Arabia claims Egyptian-
administered islands of Tiran and Sanafir Refugees and
internally displaced persons: refugees (country of origin):
70,021 (West Bank and Gaza Strip) (2017); 129,210 (Syria)
(refugees and asylum seekers),47,763 (Sudan) (refugees
and asylum seekers),19,013 (South Sudan) (refugees and
asylum seekers),18,232 (Eritrea) (refugees and asylum
seekers),16,256 (Ethiopia) (refugees and asylum
seekers),6,903 (Somalia) (refugees and asylum
seekers),6,752 (Iraq) (refugees and asylum seekers) (2019)
IDPs: 97,000 (2018)
Trafficking in persons: Current situation: Egypt is a source,
transit, and destination country for men, women, and
children subjected to sex trafficking and forced labor;
Egyptian children, including the large population of street
children are vulnerable to forced labor in domestic service,
begging and agriculture or may be victims of sex trafficking
or child sex tourism, which occurs in Cairo, Alexandria, and
Luxor; some Egyptian women and girls are sold into
“temporary” or “summer” marriages with Gulf men,
through the complicity of their parents or marriage
brokers, and are exploited for prostitution or forced labor;
Egyptian men are subject to forced labor in neighboring
countries, while adults from South and Southeast Asia and
East Africa—and increasingly Syrian refugees—are forced
to work in domestic service, construction, cleaning, and
begging in Egypt; women and girls, including migrants and
refugees, from Asia, Sub-Saharan Africa, and the Middle
East are sex trafficked in Egypt; the Egyptian military
cracked down on criminal group’s smuggling, abducting,
trafficking, and extorting African migrants in the Sinai
Peninsula, but the practice has reemerged along Egypt’s
western border with Libya tier rating: Tier 2 Watch List—
Egypt does not fully comply with the minimum standards
for the elimination of trafficking; however, it is making
significant efforts to do so; the government gathered data
nationwide on trafficking cases to better allocate and
prioritize anti-trafficking efforts, but overall it did not
demonstrate increased progress; prosecutions increased in
2014, but no offenders were convicted for the second
consecutive year; fewer trafficking victims were identified
in 2014, which represents a significant and ongoing
decrease from the previous two reporting periods; the
government relied on NGOs and international organizations
to identify and refer victims to protective services, and
focused on Egyptian victims and refused to provide some
services to foreign victims, at times including shelter
(2015) tlicit drugs: transit point for cannabis, heroin, and
opium moving to Europe, Israel, and North Africa; transit
stop for Nigerian drug couriers; concern as money
laundering site due to lax enforcement of financial
regulations EL SALVADOR
Terrorist groups—home based:
Kahane Chai (Kach): aim(s): expel Arabs from Israel’s biblical
lands and, ultimately, restore the biblical state of Israel
area(s) of operation: Israel and West Bank settlements
note: considered to be operationally inactive in recent
years ( 2018)','42649ae8da75a15942e97d89515cd1b1f6f401c5c4383b41defa863cfbcd3307','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d0a9e4677e34dfee15f85746dd54420d1fdb0f9fc2bfeb55f13a6a37e4a180',2021,'GT','Guatemala','terrorism',450,'*Santa
Ana
~Apopa
Sonsonate .* SAN SALVADOR San
Acajutia®
oo Nueva
lvado 3
peebvedor Usulutan ©
: Puerto’
Cutuco','171dfb09ef7b1fc1d01e9600874fc0bbf6fbbabf84e10dba9f9a265afa5bbc96','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21f243e7cbbb796c7bd9a7f1cf70ba8f7814aea9d41e935e6fee65ad278d05df',2021,'IL','Israel','terrorism',534,'Terrorist groups—home based:
Army of Islam (AOI): aim/(s): stage attacks against Israel and
Egypt from the Gaza Strip and, ultimately, establish an
Islamic emirate in the region area(s) of operation:
headquartered in Gaza; heaviest presence and operational
activity is in the Gaza Strip note: operatives have a history
of launching low-impact rockets into Israeli and Egyptian
territory; the Army of Islam (Jaish al-Islam, JAI) in Syria is
unrelated to AOI (2018) HAMAS: aim(s): maintain control
of the Gaza Strip to facilitate Palestinian nationalist aims
area(s) of operation: headquartered in Gaza (2018) Mujahidin
Shura Council in the Environs of Jerusalem (MSC): aim(Ss): bolster its
staging capabilities in the Gaza Strip against Israel and,
ultimately, destroy the state of Israel area(s) of operation:
headquartered in Gaza, although present in Egypt, Libya,
Syria, and Israel (2018) Palestine Islamic Jihad (PIJ): aim/(s):
enhance its staging capabilities in the Gaza Strip to launch
attacks against Israel area(s) of operation: stages rocket
attacks against civilians and military personnel primarily in
southern Israel (2018) Palestine Liberation Front (PLF): aimm(s):
bolster its staging capabilities in the Gaza Strip against
Israel and, ultimately, destroy the state of Israel in order to
establish a secular, Marxist Palestinian state with
Jerusalem as its capital area(s) of operation: based in Gaza;
maintains a recruitment and paramilitary training presence
in most of the refugee camps across the Gaza Strip (2018)
PFLP-General Command (PFLP-GC): aim(s): bolster its staging
capabilities to prepare fighters for deployment to Syria and
to launch occasional attacks inside Israel; ultimately, seeks
to establish a Palestinian state area(s) of operation:
headquartered in Gaza; as a longtime supporter of the
Syrian Government, the group trains and deploys fighters
to Syria to fight on behalf of President Bashar al-ASAD;
stages occasional small-scale attacks inside Israel (2018)
Popular Front for the Liberation of Palestine (PFLP): aim(s): destroy
the state of Israel and, ultimately, establish a secular,
Marxist Palestinian state area(s) of operation:
headquartered in Gaza, recruiting and training fighters;
stages limited attacks against Israel (2018) Terrorist groups—
foreign based:
Abdallah Azzam Brigades (AAB): aim/(s): bolster its staging
capabilities in the Gaza Strip against Israel to continue its
attempts to disrupt Israel’s economy and its efforts to
establish security area(s) of operation: launches homemade
rockets from the Gaza Strip into populated Israeli territory,
primarily the cities of Nahariya and Ashkelon (2018) al-Aqsa
Martyrs Brigade (AAMB): aim(s): bolster its staging capabilities
in the Gaza Strip against Israel and, ultimately, establish a
Palestinian state comprising the West Bank, Gaza Strip, and
Jerusalem area(s) of operation: stages attacks from the
Gaza Strip against Israeli soldiers and civilians inside
Israel, including launching rockets and missiles (2018)
Islamic Revolutionary Guard Corps—Qods Force (IRGC-QF): aiim(s):
supports the destruction of Israel through funding,
training, and weapons area(s) of operation: Gaza Strip
(2019)
Islamic State of Iraq and ash-Sham (ISIS)-Sinai:
aim(s): bolster its staging capabilities in the Gaza Strip
against Israel and, ultimately, establish a regional Islamic
caliphate area(s) of operation: stages attacks against
Egyptian forces along the Gaza Strip-Egypt border and
launches rockets into southern Israel from the border
closest to Israel note: formerly known as Ansar Bayt al-
Magqdis (2018)','66684ec8891b459cd6cb957e17e143d4a4378ef8579a2a06c01ff3c0afcf80a4','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec38f8a16141d4bf14710da5b9184ba8aa765b3faaadc6ebe52e97410c911d5d',2021,'GI','Gibraltar','terrorism',554,'Terrorist groups—home based:
Revolutionary Struggle (RS): aim(s): disrupt the influence of
globalization and international capitalism on Greek society
and, ultimately, overthrow the Greek Government area(s) of
operation: operates exclusively inside Greece, primarily in
Athens
note: largely inactive in recent years, with the exception of
shootouts with police officers trying to arrest members
(2018) TRANSNATIONAL ISSUES
Disputes—International: Greece and ‘Turkey continue
discussions to resolve their complex maritime, air,
territorial, and boundary disputes in the Aegean Sea; the
mass migration of unemployed Albanians still remains a
problem for developed countries, chiefly Greece and Italy
Refugees and internally displaced persons: refugees (country of
origin): 23,931 (Syria), 9,291 (Afghanistan) (2018) stateless
persons: 198 (2018)
note: 1,192,861 estimated refugee and migrant arrivals
(Ianuary 2015-January 2020); as of the end of February
2019, an estimated 80,600 migrants and refugees are
stranded in Greece since 2015-16; 50,215 migrant arrivals
in 2018
Illicit drugs: a gateway to Europe for traffickers smuggling
cannabis and heroin from the Middle East and Southwest
Asia to the West and precursor chemicals to the East; some
South American cocaine transits or is consumed in Greece;
money laundering related to drug trafficking and organized
crime GREENLAND
Scwhapa
Ellesmere Island
oS /itans Island
Qaanaaq
<(Thule)
Ittoqdosttoormitt
(Scorésbysund),
> Ilulissat 5
ui nm
gmobshavn) = io,
#Aasiaat (Egedesminde)
x Sisimiut
dtlolsteinsborg)
.
_-*Kangerlussuaq
&_ (Sondre Stromfjord)
> Maniitso ial
(Sukkertoppen) Fo “Tesiitaq
ee j )
(NUUK ;
wy
er
Qagortoq’ >
(Julianehab) “>
Cape
Farewell','355e91caad6b283483c754cd03cecbb73e00fd454e8d9813597e10208ae893cf','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f829063c98bc1aa93acb234a8675303ff3b39c907e087367fc24dc2c283020c9',2021,'CN','China','terrorism',591,'Terrorist groups—home based:
Hizbul Mujahideen (HM): aimm(s): annex the state of Jammu and
Kashmir to Pakistan area(s) of operation: HM is an
indigenous Kashmiri militant group that operates in Jammu
and Kashmir (2018) Indian Mujahedeen (IM): aim/(s): establish
Islamic rule in India and, ultimately, convert all non-
Muslims to Islam; stated goal is to carry out terrorist
attacks against Indians for perceived atrocities against
Indian Muslims area(s) of operation: formerly based in the
western state of Maharashtra, India’s third-largest and
second-most populous state, and now probably operates
mostly outside India, particularly Nepal (2018) Terrorist
groups—foreign based:
al-Qa’ida (AQ): aim(s): overthrow the Indian Government and,
ultimately, establish a pan-Islamic caliphate under a strict
Salafi Muslim interpretation of sharia area(s) of operation:
maintains an operational presence as al-Qa’ida in the
Indian Subcontinent (2018) al-Qa’ida in the Indian Subcontinent
(AQIS): aim/(s): establish an Islamic caliphate in the Indian
subcontinent area(s) of operation: targets primarily military
and security personnel, especially in the states of Assam,
Gujarat, and Jammu and Kashmir; present in large cities,
including Delhi (2018) Harakat ul-Mujahidin (HUM): aim(s):
enhance its networks and paramilitary training in India
and, ultimately, annex Kashmir into Pakistan and establish
an Islamic state in Kashmir area(s) of operation: conducts
attacks against Indian troops and civilians in Kashmir
(2018) Harakat ul-Jihad-i-islami (HUJI): aim(s): enhance its
networks and operational capabilities in India area(s) of
operation: Maintains an operational presence, especially in
the south, including in Bangalore and Hubli (2018) Harakat
ul-Jihad-i-Islami/Bangladesh (HUJI-B): aim(s): enhance _ its
networks in India and, ultimately, install an Islamic state in
Bangladesh area(s) of operation: maintains a low-profile
presence (2018)
Islamic State of Iraq and ash-Sham-Khorasan (ISIS-K): ai(s): Spread
the ISIS caliphate by eliminating the Indian Government
and, ultimately, unite Kashmir with Pakistan area(s) of
operation: maintains a recruitment presence in major cities
(2018)
Jaish-e-Mohammed (JEM): aiin(s): annex Jammu and Kashmir to
Pakistan area(s) of operation: operates primarily in Jammu
and Kashmir State (2018)
Lashkar-e Tayyiba (LT): aim(s): annex Jammu and Kashmir State
to Pakistan and, ultimately, install Islamic rule throughout
South Asia area(s) of operation: operational throughout
India, especially in the north in Jammu and Kashmir State,
since at least 1993
note: continues to be one of the largest and most deadly of
the anti-India-focused armed groups (2018) Liberation Tigers
of Tamil Eelam (LTTE): aim(s): enhance its networks in India
and, ultimately, revive the movement to establish a Tamil
homeland area(s) of operation: maintains safe havens,
transit routes, human trafficking, and an _ operational
presence in an effort to revive the movement and conduct
attacks (2018) TRANSNATIONAL ISSUES
Disputes—International: Since China and India launched a
security and foreign policy dialogue in 2005, consolidated
discussions related to the dispute over most of their
rugged, militarized boundary, regional nuclear
proliferation, Indian claims that China transferred missiles
to Pakistan, and other matters continue; Kashmir remains
the site of the world’s largest and most militarized
territorial dispute with portions under the de_ facto
administration of China (Aksai Chin), India Jammu and
Kashmir), and Pakistan (Azad Kashmir and Northern
Areas); India and Pakistan resumed bilateral dialogue in
February 2011 after a two-year hiatus, have maintained the
2003 cease-fire in Kashmir, and continue to have disputes
over water sharing of the Indus River and its tributaries;
UN Military Observer Group in India and Pakistan has
maintained a small group of peacekeepers since 1949;
India does not recognize Pakistan’s ceding historic Kashmir
lands to China in 1964; to defuse tensions and prepare for
discussions on a maritime boundary, India and Pakistan
seek technical resolution of the disputed boundary in Sir
Creek estuary at the mouth of the Rann of Kutch in the
Arabian Sea; Pakistani maps continue to show its Junagadh
claim in Indian Gujarat State; Prime Minister Singh’s
September 2011 visit to Bangladesh resulted in the signing
of a Protocol to the 1974 Land Boundary Agreement
between India and Bangladesh, which had called for the
settlement of longstanding boundary disputes’ over
undemarcated areas and the exchange of territorial
enclaves, but which had never been implemented;
Bangladesh referred its maritime boundary claims with
Burma and India to the International Tribunal on the Law
of the Sea; Joint Border Committee with Nepal continues to
examine contested boundary sections, including the 400 sq
km dispute over the source of the Kalapani River; India
maintains a strict border regime to keep out Maoist
insurgents and control illegal cross-border activities from
Nepal Refugees and_ internally displaced persons: refugees
(country of origin): 108,008 (Tibet/China), 60,802 (Sri
Lanka), 18,813 (Burma), 6,984 (Afghanistan) (2018) IDPs:
479,000 (armed conflict and intercommunal violence)
(2018)
Illicit drugs: world’s largest producer of licit opium for the
pharmaceutical trade, but an undetermined quantity of
opium is diverted to illicit international drug markets;
transit point for illicit narcotics produced in neighboring
countries and throughout Southwest Asia; illicit producer
of methaqualone; vulnerable to narcotics money laundering
through the hawala system; licit ketamine and precursor
production INDIAN OCEAN
Ji
Trev
INDIAN
nn
Lomboi
OCEAN Strait
Terrorist groups—home based:
ISIS-associated Jemaah Anshorut Daulah (JAD): aim(s): establish an
Islamic caliphate in Indonesia area(s) of operation: an ISIS-
aligned coalition of cells located throughout the country
(2018) Islamic State of Iraq and ash-Sham (ISIS) network in Indonesia:
aim(s): replace the Indonesian Government with an Islamic
state and implement ISIS’s strict interpretation of sharia
area(s) of operation: maintains a _ covert operational
presence (2018)
Jemaah Islamiyah (jl): aim(s): overthrow the Indonesian
Government and, ultimately, establish a pan-Islamic state
across Southeast Asia area(s) of operation: Indonesia
(2018)
Terrorist groups—home based:
Islamic Revolutionary Guard Corps (IRGC): aim(s): protect Iran’s
Islamic Revolution; spread Shia influence; internal security,
including border control, law enforcement, and suppressing
domestic opposition; controls country’s missiles and
rockets; influence Iran’s politics and economy area of
operation(s): headquartered in Tehran, throughout Iran
(2019)
Islamic Revolutionary Guard Corps—Qods Force (IRGC-QF): aiin(s):
protect Iran’s Islamic Revolution; spread Shia influence;
conduct clandestine overseas operations, often supporting
other terrorist organizations (including Sunni groups like
the Taliban when their goals align) with significant funding,
logistics, training, or weaponry to commit terror attacks,
either directly or through proxies; recruit, train, and equip
foreign Islamic revolutionary groups throughout the Middle
East area(s) of operations: headquartered in Tehran
(2019)
Jaysh al Adil: Note(s): formerly known as Jundallah
Terrorist groups—foreign based:
al-Qa’ida_ (AQ): aim(s): unite the worldwide Muslim
community, overthrow governments perceived as_ un-
Islamic, and, ultimately, establish a pan-Islamic caliphate
under a strict Salafi Muslim interpretation of sharia (2018)
Kurdistan Workers’ Party (PKK): aim(s): advance Kurdish
autonomy, political, and cultural rights in Iran, Turkey, Iraq,
and Syria area(s) of operation: operational in the
northwest; majority of members inside Iran are Iranian
Kurds, along with Kurds from Irag, Syria, and Turkey
(2018) TRANSNATIONAL ISSUES
Disputes—International: Iran protests Afghanistan’s limiting
flow of dammed Helmand River tributaries during drought;
Iraq’s lack of a maritime boundary with Iran prompts
jurisdiction disputes beyond the mouth of the Shatt al Arab
in the Persian Gulf; Iran and UAE dispute Tunb Islands and
Abu Musa Island, which are occupied by Iran; Azerbaijan,
Kazakhstan, and Russia_ ratified Caspian seabed
delimitation treaties based on equidistance, while Iran
continues to insist on a one-fifth slice of the sea; Afghan
and Iranian commissioners have discussed boundary
monument densification and resurvey Refugees and internally
displaced persons: refugees (country of origin): 2.5-3.0 (1
million registered, 1.5-2.0 million undocumented)
(Afghanistan) (2017); 28,268 (Iraq) (2018) Trafficking in
persons: current situation: Iran is a source, transit, and
destination country for men, women, and _ children
subjected to sex trafficking and forced labor; organized
groups sex traffic Iranian women and children in Iran and
to the UAE and Europe; the transport of girls from and
through Iran en route to the Gulf for sexual exploitation or
forced marriages is on the rise; Iranian children are also
forced to work as beggars, street vendors, and in domestic
workshops; Afghan boys forced to work in construction or
agriculture are vulnerable to sexual abuse by their
employers; Pakistani and Afghan migrants being smuggled
to Europe often are subjected to forced labor, including
debt bondage tier rating: Tier 3 - Iran does not comply with
the minimum standards for the elimination of trafficking,
and is not making significant efforts to do so; the
government does not share information on its anti-
trafficking efforts, but publically available information from
NGOs, the media, and international organizations indicates
that Iran is not taking adequate measures to address its
trafficking problems, particularly protecting victims;
Iranian law does not prohibit all forms of human
trafficking; female victims find it extremely difficult to get
justice because Iranian courts accord women’s testimony
half the weight of men’s, and female victims of sexual
abuse, including trafficking, are likely to be prosecuted for
adultery; the government did not identify or provide
protection services to any victims and continued to punish
victims for unlawful acts committed as a direct result of
being trafficked; the government made some effort to
cooperate with neighboring governments and an
international organization to combat human trafficking and
other crimes (2015) Illicit drugs: despite substantial
interdiction efforts and considerable control measures
along the border with Afghanistan, Iran remains one of the
primary transshipment routes for Southwest Asian heroin
to Europe; suffers one of the highest opiate addiction rates
in the world, and has an increasing problem with synthetic
drugs; regularly enforces the death penalty for drug
offences; lacks anti-money laundering laws; has reached
out to neighboring countries to share counter-drug
intelligence
Karbala’ al Kat
An Najaf *
An Nasiriyah*
Al Basgrah ol,
Umm Qasr “y
ARABIA
0 50 100km
aie etait
0 50 100 mi
Terrorist groups—home based:
Ansar al-Islam (AAI): aim(s): expel western interests from Iraq
and, ultimately, establish an independent Iraqi state
operating according to its interpretation of sharia area(s) of
operation: headquartered in northern Iraq with its largest
presence in Kirkuk, Tikrit, and Mosul; active in the western
and central regions of the country note: majority of
members are Iraqi Kurds or Iragi Arabs who are Sunni
Muslim (2018)
Jaysh Rijal al-Tariq al-Naqshabandi (JRTN): aim(S): end external
influence in Iraq and, _ ultimately, overthrow the
Government of Iraq to install a secular Ba’athist state
within the internationally recognized borders of Iraq
area(s) of operation: attacks separatist Kurdish groups,
Iraqi Government military and security forces and facilities,
and foreign military personnel (2018) Kata’ib Hizballah (KH):
aim(s): counter US influence and, ultimately, overthrow the
Iragi Government to install a government based on Shia
Muslim laws and_ precepts area(s) of operation:
headquartered in the Shia Muslim areas of Baghdad, with
fighters active in Ninawa, Al Anbar, and Babil governorates
(2018) Kurdistan Workers’ Party (PKK): aim(s): advance Kurdish
autonomy and security goals in Iraq, Turkey, Iran, and
Syria area(s) of operation: operational in the north and
east, with its stronghold in the Qandil Mountains; majority
of members inside Iraq are Iraqi, Turkish, and Iranian
Kurds, along with Kurds from Syria (2018) Asa’ib Ahl al-Haq
(AAH): aim(s): maintain a Shiite-controlled government in
Iraq; promote Iran’s political and religious influence in
Iraq; expel the remaining US military and diplomatic
presence in the country area(s) of operation: Iraq
note(s): the group is largely funded by Iran and receives
training from the Quds Force of Iran’s Revolutionary Guard
Corps (2020) Terrorist groups—foreign based:
Islamic Revolutionary Guard Corps—Qods Force (IRGC-QF): aiim(s):
back Iraq’s pro-government Shia militias by supplying two
battalions of IRGC forces to jointly engage in combat
against ISIS; provide weapons and munitions to Shia
militants targeting US forces area(s) of operations:
Baghdad, Basrah, Karbala, Mosul, Samarra, Tikrit (2019)
Islamic State of Iraq and ash-Sham (ISIS): aim(s): replace the
world order with a global Islamic state based in Iraq and
Syria; expand its branches and networks in other countries;
rule according to ISIS’s strict interpretation of Islamic law
area(s) of operation: operational in the rural and desert
areas of central and northern Iraq, primarily within and
near Sunni populations, with some presence in major
population areas (2018) TRANSNATIONAL ISSUES
Disputes—International: Iraq’s lack of a maritime boundary
with Iran prompts jurisdiction disputes beyond the mouth
of the Shatt al Arab in the Persian Gulf; Turkey has
expressed concern over the autonomous status of Kurds in
Iraq Refugees and internally displaced persons: refugees (Country
of origin): 15,405 (Turkey), 7,944 (West Bank and Gaza
Strip), 7,026 (Iran) (2018); 245,810 (Syria) (2019) IDPs:
1,414,602 (displacement in central and northern Iraq since
January 2014) (2019)
stateless persons: 47,515 (2018); note—in the 1970s and
1980s under SADDAM Husayn’s regime, thousands of
Iraq’s Faili Kurds, followers of Shia Islam, were stripped of
their Iraqi citizenship, had their property seized by the
government, and many were deported; some Faili Kurds
had their citizenship reinstated under the 2,006 Iraqi
Nationality Law, but others lack the documentation to
prove their Iraqi origins; some Palestinian refugees
persecuted by the SADDAM regime remain stateless note:
estimate revised to reflect the reduction of statelessness in
line with Law 26 of 2006, which allows stateless persons to
apply for nationality in certain circumstances; more
accurate studies of statelessness in Irag are pending (2015)','72588216069695e12c54da2995a595cc92127fd35ba7a7aa2526ac12c3d5adb9','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950776649bf26b3956905a7604286410f5f7db694e18cff14089954a37bef402',2021,'IE','Ireland','terrorism',592,'os
‘ treland:
(U.K)
Sligo, Jlonaghan
“Us
Castlebar
Drogheda,
DUBLIN,
*Tullamore
ARAN Wicklow,
ISLAN Arkiow,
Galway
DS
Shannon
Limerick New
jRoss
: Killarney Waterford
‘Carrauntoohii (Cork
Terrorist groups—foreign based:
Continuity Irish Republican Army (CIRA): aim(s): to bring about a
united Ireland area(s) of operation: maintains an
operational presence (2018)
New Irish Republican Army (NIRA): aim(s): to bring about a
united Ireland area(s) of operation: maintains an
operational presence
note: formerly known as the Real Irish Republican Army
(RIRA) (2018)','d66ac7a17cc47cb408bdb4b27141b9ba7eccdad1b0876064e61b380b68bfb392','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c4fe6a7d7c077673308a29c2437e95f9eea240dad76cddf018e94eabac274ec',2021,'CU','Cuba','terrorism',616,'Terrorist groups—home based:
Aum Shinrikyo (AUM): aim(s): attract new members seeking
religious guidance and exhibiting a_ willingness to
financially support the organization; historically, leaders
sought to overthrow the Japanese Government and to spark
a nuclear war between Japan and the US to create a global
Armageddon, ‘cleansing’ the world so its members could
achieve salvation area(s) of operation: headquartered in the
north in Hokkaido; also operates in Russia note: in
November 2017, Japanese police raided the offices of a
“successor” group to AUM; AUM leader Shoko ASAHARA
was executed in July 2018, (2019) TRANSNATIONAL
ISSUES
Disputes—International: the sovereignty dispute over the
islands of Etorofu, Kunashiri, and Shikotan, and the
Habomai group, known in Japan as the “Northern
Territories” and in Russia as the “Southern Kuril Islands,”
occupied by the Soviet Union in 1945, now administered by
Russia and claimed by Japan, remains the primary sticking
point to signing a peace treaty formally ending World War
II hostilities; Japan and South Korea claim Liancourt Rocks
(Take-shima/Tok-do) occupied by South Korea since 1954;
the Japanese-administered Senkaku Islands are _ also
claimed by China and Taiwan Refugees and internally displaced
persons: Stateless persons: 709 (2018) JERSEY
St. John”
St. Aubin, saint 2%
4 HELIER','dbdfc8ba7ed0ca687ba44207d19d97f2b41cc67d61b4afccdd3a99551444c736','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c03e3cb0b3440ea19849b276d220a89241f65a7a523610cc6e79d52b846eb29a',2021,'KZ','Kazakhstan','terrorism',637,'Terrorist groups—foreign based:
al-Shabaab: aim(s): establish Islamic rule in Kenya’s
northeastern border region and coast; avenge Kenya’s past
intervention in Somalia against al-Shabaab and its ongoing
participation in the African Union mission; compel Kenya to
withdraw troops from Somalia; attract Kenyan recruits to
Support operations in Somalia area(s) of operation:
maintains an operational and recruitment presence, mostly
along the coast and the northeastern border region (2018)
@ Urkmenbasy
Balkanabat
<Gyzylarbat
Turkmenabat”
ASHGABAT Aynbab
Mary, ,Bayramaly','1e5147d6dbbdca2de699cc68dce7c9dc46b28f22787adab6f73b494da4b960fd','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e77af1511acee619a9d3dc7877e5e007c5ba07b4256b3c475e2d21d2b80bf5c',2021,'LB','Lebanon','terrorism',672,'Terrorist groups—home based:
Abdallah Azzam Brigades (AAB): aiim(s): enhance its networks in
Lebanon to combat Shia Muslim influence in the country;
seeks to disrupt Israel’s economy and its efforts to establish
security; attack Western interests in the Middle East
area(s) of operation: headquartered in the Ayn al-Hilwah
Palestinian refugee camp near Sidon in the south (2018)
Asbat al-Ansar (AAA): aim(s): overthrow the Lebanese
Government, rid Lebanon of Western influences, destroy
the state of Israel to seize Jerusalem and, ultimately,
establish an Islamic state in the Levant region area(s) of
operation: headquartered in the Ayn al-Hilwah Palestinian
refugee camp near Sidon in the south (2018) Hizballah:
aim(s): accrue military resources and political power and
defend its position of strength in Lebanon; destroy the state
of Israel; counter the West; provide paramilitary support to
Syrian President Bashar al-ASAD’s regime area(s) of
operation: headquartered in Beirut with a_ significant
presence in the Bekaa Valley and Southern Lebanon note:
remains the most capable armed group in the country,
enjoying support among many Lebanese Shia and some
Christians; receives considerable support from Iran (2018)
Islamic State of Iraq and ash-Sham (ISIS) network in Lebanon: aim(s):
replace the Lebanese Government with an Islamic state
and implement ISIS’s strict interpretation of sharia area(s)
of operation: operational primarily in the east along the
border with Syria; also maintains a presence in Ayn al-
Hilweh refugee camp (2018) Terrorist groups—foreign based:
al-Aqsa Martyrs Brigade (AAMB): aim(s): bolster its recruitment
presence in Lebanon and, ultimately, establish a Palestinian
state comprising the West Bank, Gaza Strip, and Jerusalem
area(s) of operation: recruits youths in Palestinian refugee
camps (2018)
al-Nusrah Front/al-Qa’ida: aim(s): bolster networks in Lebanon
and, ultimately, establish a regional Islamic caliphate
area(s) of operation: in the east in the Bekaa Valley and
along the Lebanon-Syria border; targets Lebanese
Government institutions, security forces, and Lebanese
civilians (2018) Islamic Revolutionary Guard Corps -- Qods Force
(IRGC-QF): aim(s): support Lebanon’s Hezbollah movement to
advance Shia agenda through funding, training, and
weapons area(s) of operations: Beirut, Bekaa Valley,
southern Lebanon (2019)
Palestine Liberation Front (PLF): aizn(s): enhance its networks in
Lebanon and, ultimately, destroy the state of Israel to
establish a secular, Marxist Palestinian state with
Jerusalem as its capital area(s) of operation: maintains a
recruitment and training presence in many refugee camps
(2018) PFLP-General Command (PFLP-GC): aim(s): enhance
recruitment and operational networks in Lebanon area(s) of
operation: recruits young men living in Palestinian refugee
camps, including camps in the Bekaa Valley (2018) Popular
Front for the Liberation of Palestine (PFLP): aim(s): enhance its
recruitment network in Lebanon and, ultimately, establish a
secular, Marxist Palestinian state area(s) of operation:
recruits youths residing in the country’s Palestinian
refugee camps (2018) TRANSNATIONAL ISSUES
Disputes—International: lacking a treaty or other
documentation describing the boundary, portions of the
Lebanon-Syria boundary are unclear with several sections
in dispute; since 2000, Lebanon has claimed Shab’a Farms
area in the Israeli-controlled Golan Heights; the roughly
2,000-strong UN Interim Force in Lebanon has been in
place since 1978
Refugees and internally displaced persons: refugees (country of
origin): 916,248 (Syria), 475,075 (Palestinian refugees)
(2019) IDPs: 11,000 (2007 Lebanese security forces’
destruction of Palestinian refugee camp) (2018) stateless
persons: undetermined (2016); note—tens of thousands of
persons are. stateless in Lebanon, including many
Palestinian refugees and their descendants, Syrian Kurds
denaturalized in Syria in 1962, children born to Lebanese
women married to foreign or stateless men; most babies
born to Syrian refugees, and Lebanese children whose
births are unregistered Trafficking in persons: current
situation: Lebanon is a source and destination country for
women and children subjected to forced labor and sex
trafficking and a transit point for Eastern European women
and children subjected to sex trafficking in other Middle
Eastern countries; women and girls from South and
Southeast Asia and an increasing number from East and
West Africa are recruited by agencies to work in domestic
service but are subject to conditions of forced labor; under
Lebanon’s artiste visa program, women from Eastern
Europe, North Africa, and the Dominican Republic enter
Lebanon to work in the adult entertainment industry but
are often forced into the sex trade; Lebanese children are
reportedly forced into street begging and commercial
sexual exploitation, with small numbers of Lebanese girls
sex trafficked in other Arab countries; Syrian refugees are
vulnerable to forced labor and prostitution tier rating: Tier 2
Watch List—Lebanon does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
Lebanon was granted a waiver from an otherwise required
downgrade to Tier 3 because its government has a written
plan that, if implemented would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking; law
enforcement efforts in 2014 were uneven; the number of
convicted traffickers increased, but judges lack of
familiarity with anti-trafficking law meant that many
offenders were not brought to justice; the government
relied heavily on an NGO to identify and provide service to
trafficking victims; and its lack of thoroughly implemented
victim identification procedures resulted in victims
continuing to be arrested, detained, and deported for
crimes committed as a direct result of being trafficked
(2015) ttlicit drugs: Lebanon is a transit country for hashish,
cocaine, heroin, and fenethylene; fenethylene, cannabis,
hashish, and some opium are produced in the Bekaa Valley;
small amounts of Latin American cocaine and Southwest
Asian heroin transit country on way to European markets
and for Middle Eastern consumption; money laundering of
drug proceeds fuels concern that extremists are benefiting
from drug trafficking LESOTHO','14b6ccd3c447ca57bdc55fa32d02a7ddaad3186f1e3d3eaab20eba1134cb01c7','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c7e55291cdfe8759dad8a7888bd1c1c1c8c2a3a8d525a13e2218270d19e3f7',2021,'LR','Liberia','terrorism',676,'Terrorist groups—home based:
al-Qa’ida in the Islamic Maghreb (AQIM): aim(s): overthrow
various African regimes and replace them with one ruled by
sharia; establish a regional Islamic caliphate across all of
North and West Africa area(s) of operation: leadership
headquartered in Algeria; operates in Tunisia and Libya
(2018) Ansar al-Sharia groups: aim(s): implement sharia in
Libya area(s) of operation: in the east, mostly in Benghazi
and Darnah
note: officially disbanded in June 2017, but fighters and
local elements remain; operated as a member of the
Benghazi Revolutionaries Shura Council and Darnah
Mujahidin Shura Council, a coalition of jihadist groups
combating the Libyan House of Representatives-aligned
forces (2018) Islamic State of Iraq and ash-Sham (ISIS)-Libya:
aim(s): prevent the formation of a reunified Libyan state,
secure control over the country’s critical resources and,
ultimately, establish an Islamic caliphate in Libya area(s) of
operation: based in Libya since circa 2015, with its original
headquarters in Sirte; no longer controls territory in Libya
but does maintain a low-profile presence throughout much
of the country (2018) Terrorist groups—foreign based:
al-Mulathamun Battalion: aim(s): replace several African
governments, including Libya’s transitional government,
with an Islamic state area(s) of operation: maintains an
operational presence; engages in kidnappings for ransom
(2018) TRANSNATIONAL ISSUES
Disputes—International: dormant disputes include Libyan
claims of about 32,000 sq km still reflected on its maps of
southeastern Algeria and the FLN’s assertions of a claim to
Chirac Pastures in southeastern Morocco; various Chadian
rebels from the Aozou region reside in southern Libya
Refugees and internally displaced persons: refugees (country of
origin): 16,820 (Syria) (refugees and asylum seekers),
12,220 (Sudan) (refugees and asylum seekers), 5,899
(Eritrea) (refugees and asylum seekers) (2019) IDPs:
343,180 (conflict between pro-QADHAFI and anti-QADHAFI
forces in 2011; post-QADHAFI tribal clashes 2014) (2019)
Trafficking in persons: Current situation: Libya is a destination
and transit country for men and women from Sub-Saharan
Africa and Asia subjected to forced labor and forced
prostitution; migrants who seek employment in Libya as
laborers and domestic workers or who transit Libya en
route to Europe are vulnerable to forced labor; private
employers also exploit migrants from detention centers as
forced laborers on farms and construction sites, returning
them to detention when they are no longer needed; some
Sub-Saharan women are reportedly forced to work in
Libyan brothels, particularly in the country’s south; since
2013, militia groups and other informal armed groups,
including some affiliated with the government, are reported
to conscript Libyan children under the age of 18; large-
scale violence driven by militias, civil unrest, and increased
lawlessness increased in 2014, making it more difficult to
obtain information on human trafficking tier rating: Tier 3—
the Libyan Government does not fully comply with the
minimum standards for the elimination of trafficking and is
not making significant efforts to do so; in 2014, the
government’s capacity to address human trafficking was
hampered by the ongoing power struggle and violence; the
judicial system was not functioning, preventing any efforts
to investigate, prosecute, or convict traffickers, complicit
detention camp guards or government officials, or militias
or armed groups that used child soldiers; the government
failed to identify or provide protection to trafficking
victims, including child conscripts, and continued to punish
victims for unlawful acts committed as a direct result of
being trafficked; no public anti-trafficking awareness
Campaigns were conducted (2015) LIECHTENSTEIN
| Schaan
pv AbUz
SWITZERLAND \\ ___ iiiesenberg
\\
@tiesen
Balzers Vor','eec2de4c15be2e49b7f87becf0fee68f7c0c945f63027df38c740c4d0280fc1f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c4620968a9bcc3de724bddb014a0a5258d6621e9761722c7b27df81359174ed',2021,'MZ','Mozambique','terrorism',697,'Terrorist groups—foreign based:
Jemaah Islamiyah (Jl): aim(s): enhance networks in Malaysia
and, ultimately, overthrow the secular Malaysian
Government and establish a pan-Islamic state across
Southeast Asia area(s) of operation: maintains a
recruitment and operational presence, primarily in major
cities (2018) TRANSNATIONAL ISSUES
Disputes—International: While the 2002 “Declaration on the
Conduct of Parties in the South China Sea” has eased
tensions over the Spratly Islands, it is not the legally
binding “code of conduct” sought by some parties, which is
currently being negotiated between China and ASEAN;
Malaysia was not party to the March 2005 joint accord
among the national oil companies of China, the Philippines,
and Vietnam on conducting marine seismic activities in the
Spratly Islands; disputes continue over deliveries of fresh
water to Singapore, Singapore’s land reclamation, bridge
construction, and maritime boundaries in the Johor and
Singapore Straits; in 2008, ICJ awarded sovereignty of
Pedra Branca (Pulau Batu Puteh/Horsburgh Island) to
Singapore, and Middle Rocks to Malaysia, but did not rule
on maritime regimes, boundaries, or disposition of South
Ledge; land and maritime negotiations with Indonesia are
ongoing, and disputed areas include the controversial
Tanjung Datu and Camar Wulan border area in Borneo and
the maritime boundary in the Ambalat oil block in the
Celebes Sea; separatist violence in Thailand’s
predominantly Muslim southern provinces’ prompts
measures to close and monitor border with Malaysia to
stem terrorist activities; Philippines retains a dormant
claim to Malaysia’s Sabah State in northern Borneo; per
Letters of Exchange signed in 2009, Malaysia in 2010
ceded two hydrocarbon concession blocks to Brunei in
exchange for Brunei’s sultan dropping claims to the
Limbang corridor, which divides Brunei; piracy remains a
problem in the Malacca Strait Refugees and internally displaced
persons: refugees (country of origin): 114,227 (Burma)
(2018) stateless persons: 9,631 (2018); note—Malaysia’s
stateless population consists of Rohingya refugees from
Burma, ethnic Indians, and the children of Filipino and
Indonesian illegal migrants; Burma stripped the Rohingya
of their nationality in 1982; Filipino and Indonesian
children who have not been registered for birth certificates
by their parents or who received birth certificates stamped
“foreigner” are not eligible to attend government schools;
these children are vulnerable to statelessness should they
not be able to apply to their parents’ country of origin for
passports Trafficking in persons: Current situation: Malaysia is
a destination and, to a lesser extent, a source and transit
country for men, women, and children subjected to forced
labor and women and children subjected to sex trafficking;
Malaysia is mainly a destination country for foreign
workers who migrate willingly from countries, including
Indonesia, Bangladesh, the Philippines, Nepal, Burma, and
other Southeast Asian countries, but subsequently
encounter forced labor or debt bondage in agriculture,
construction, factories, and domestic service at the hands
of employers, employment agents, and labor recruiters;
women from Southeast Asia and, to a much lesser extent,
Africa, are recruited for legal work in restaurants, hotels,
and salons but are forced into prostitution; refugees,
including Rohingya adults and children, are not legally
permitted to work and are vulnerable to trafficking; a small
number of Malaysians are trafficked internally and
subjected to sex trafficking abroad tier rating: Tier 2 Watch
list—Malaysia does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; in 2014, amendments to
strengthen existing anti-trafficking laws, including enabling
victims to move freely and to work and for NGOs to run
protective facilities, were drafted by the government and
are pending approval from Parliament; authorities more
than doubled investigations and prosecutions but convicted
only three traffickers for forced labor and none for sex
trafficking, a decline from 2013 and a disproportionately
small number compared to the scale of the country’s
trafficking problem; NGOs provided the majority of victim
rehabilitation and counseling services with no financial
support from the government (2015) Illicit drugs: drug
trafficking prosecuted vigorously, including enforcement of
the death penalty; heroin still primary drug of abuse, but
synthetic drug demand remains strong; continued ecstasy
and methamphetamine producer for domestic users and, to
a lesser extent, the regional drug market MALDIVES
Male Atoll
SMALE
Addu Atoll
Gan
Terrorist groups—foreign based:
al-Shabaab: aim/(s): attract Tanzanian recruits to support
terrorist operations in Kenya and Somalia area(s) of
operation: maintains minimal clandestine footprint in key
cities (2018)','b536ff6211ac1f485ab5d6e6bb1fb9ce716da9aabdfc8deb661765383fec6e04','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a958321328f6e96157173fa06f6ffb8b33ac30f7cafb1a4dc3f60bb1f4c427c3',2021,'AL','Albania','terrorism',771,'Terrorist groups—foreign based:
Aum Shinrikyo (AUM): aim(s): enhance its networks in
Montenegro for recruitment and fundraising area(s) of
operation: maintains a limited presence; membership
drastically depleted in March 2016 when authorities
expelled 58 foreign members (2018) TRANSNATIONAL
ISSUES
Disputes—International: Kosovo ratified the border
demarcation agreement with Montenegro in March 2018,
but the actual demarcation has not been completed Refugees
and internally displaced persons: Stateless persons: 145 (2018)
note: 14,894 estimated refugee and migrant arrivals
(January 2015-January 2020) MONTSERRAT
Brades
(interim conn. & eralt''s
Plymouth
4} it a
(former capital, shances
ba.
abandoned) Peak','d83d3d294f01520a6cbca84e0a94f28ee5c0e2c7170e9f093dfa3d8e980af0ba','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc24c90ac80d49374df651d28b3529a163a63a98ee07972977f9b4cf5cf31693',2021,'NP','Nepal','terrorism',796,'Terrorist groups—foreign based: Indian Mujahedeen (IM): aim(s):
enhance networks in Nepal to carry out attacks against
Indians in Nepal and India area(s) of operation: maintains
active hubs of small, loosely connected networks (2018)','87280e987fb267ef048137dafa80fad70b005527252c59bfbade4011be969097','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b6d7a5ef28cd4d93e8fb75f393676325b7091ae7fcbcaa55f523345f9421c21',2021,'NG','Nigeria','terrorism',819,'Terrorist groups—home based:
Islamic State of Iraq and ash-sham networks in the Greater Sahara
(ISGS): aim/(s): replace regional governments with an Islamic
state area(s) of operation: mostly concentrated along the
Mali-Niger border region; targets primarily security forces
(2018) Islamic State of Iraq and ash-Sham (ISIS)-West Africa: 2im(S):
implement ISIS’s strict interpretation of Sharia; replace the
Nigerian Government with an Islamic state area(s) of
operation: based primarily in the southeast along the
border with Nigeria, with its largest presence in northeast
Nigeria and the Lake Chad region; targets primarily
regional military’ installations, especially in the
southeastern Diffa region (2018) Terrorist groups—foreign
based:
al-Mulathamun Battalion: aim(s): replace several African
governments, including Niger’s government, with an
Islamic state area(s) of operation: conducts attacks against
Nigerien military and _ security personnel; targets
Westerners for kidnappings for ransom (2018) al-Qa’ida-
affiliated Jama’at Nusrat al-Islam wal-Muslimin (JNIM): a@im(S):
establish an Islamic state centered in Mali area(s) of
operation: primarily based in northern and central Mali;
targets Western and local interests in West Africa and
Sahel; has claimed responsibility for attacks in Mali, Niger,
and Burkina Faso note: pledged allegiance to al-Qa’ida and
AQIM; holds Western hostages; wages attacks against
security and peacekeeping forces in Mali (2018) Boko Haram:
aim(s): establish an Islamic caliphate across Africa area(s)
of operation: conducts’ kidnappings, bombings, and
assaults; responsible for displacing thousands of people
and contributing to food insecurity note: violently opposes
any political or social activity associated with Western
society, including voting, attending secular schools, and
wearing Western dress (2018) TRANSNATIONAL ISSUES
Disputes—International: Libya claims about 25,000 sq km ina
currently dormant dispute in the Tommo region; location of
Benin-Niger-Nigeria tripoint is unresolved; only Nigeria
and Cameroon have heeded the Lake Chad Commission’s
admonition to ratify the delimitation treaty that also
includes the Chad-Niger and Niger-Nigeria boundaries; the
dispute with Burkina Faso was referred to the ICJ in 2010
Refugees and internally displaced persons: refugees (country of
origin): 120,619 (Nigeria), 56,499 (Mali) (2019) IDPs:
187,359 (includes the regions of Diffa, Tillaberi, and
Tahoua; unknown how many of the 11,000 people displaced
by clashes between government forces and the Tuareg
militant group, Niger Movement for Justice, in 2007 are
still displaced; inter-communal violence; Boko Haram
attacks in southern Niger, 2015) (2019) NIGERIA
+,
Sokoto™ “katsina
*Kano
Zaria,
Kaduna,
os
ABUJA
llorin, *
*Ogbomoso,
*Makurdi ery
Enugu
¢ _Oshogbo
Ibadan Benin
oily
‘Lagos
Warr
* MEROON
Calabay L eos
+> Port
Harcourt
Terrorist groups—home based:
Boko Haram: aim(s): replace the Nigerian Government with
an Islamic state under strict sharia and, ultimately,
establish an Islamic caliphate across Africa; avenge military
offenses against the group and destroy any political or
social activity associated with Western society; conducts
attacks against primarily civilian and regional military
targets area(s) of operation: headquartered in the
northeast
note: since 2009, fighters have killed tens of thousands of
Nigerians during hundreds of attacks and disrupted trade
and farming in the northeast, causing a risk of famine and
displacing millions of people; violently opposes any political
or social activity associated with Western society, including
voting, attending secular schools, and wearing Western
dress (2018) Islamic State of Iraq and ash-Sham (ISIS)-West Africa:
aim(s): implement ISIS’s strict interpretation of Sharia;
replace the Nigerian Government with an Islamic state
area(s) of operation: based primarily in the north along the
border with Niger, with its largest presence in the
northeast and the Lake Chad region; targets primarily
regional military installations and _ civilians (2018)','3abdf9c7466d608e80af681cdb24cf29ddae1aaf833fbf04c191f0a204757ffa','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faa58c4cf0433ece156112f63ab84ec4fb2edfc0314892ebbb0fbb15d33e0835',2021,'EC','Ecuador','terrorism',852,'Terrorist groups—home based:
Shining Path (Sendero Luminoso, SL): aim(s): generate revenue
by providing security for narcotics trafficking and growing
coca to produce cocaine; historically, SEs goal has been to
replace Peruvian institutions with a peasant revolutionary
regime area(s) of operation: headquartered in the Valley of
the Apurimac, Ene, and Mantaro River (VRAEM) region
(2018) TRANSNATIONAL ISSUES
Disputes—International: Chile and Ecuador rejected Peru’s
November 2005 unilateral legislation to shift the axis of
their joint treaty-defined maritime boundaries along the
parallels of latitude to equidistance lines which favor Peru;
organized illegal narcotics operations in Colombia have
penetrated Peru’s shared border; Peru rejects Bolivia’s
claim to restore maritime access through a sovereign
corridor through Chile along the Peruvian border Refugees
and internally displaced persons: refugees (country of origin):
946,020 (Venezuela) (economic and political crisis; includes
Venezuelans who have claimed asylum or have received
alternative legal stay) (2019) IDPs: 59,000 (civil war from
1980-2000; most IDPs are indigenous peasants in Andean
and Amazonian regions; as of 2011, no new information on
the situation of these IDPs) (2017) Itlicit drugs: until 1996 the
world’s largest coca leaf producer, Peru is now the world’s
second largest producer of coca leaf, though it lags far
behind Colombia; cultivation of coca in Peru was estimated
at 44,000 hectares in 2016, a decrease of 16 per cent over
2015; second largest producer of cocaine, estimated at 410
metric tons of potential pure cocaine in 2016; finished
cocaine is shipped out from Pacific ports to the
international drug market; increasing amounts of base and
finished cocaine, however, are being moved to Brazil, Chile,
Argentina, and Bolivia for use in the Southern Cone or
transshipment to Europe and Africa; increasing domestic
drug consumption PHILIPPINES
ay
Aparri’
. Baguio
, Luzon
Angeles
, Y mand City
MANILA ~“ :
2
Batangos'' begaspi
Mindoro} wd
~ Samar
anay ff 7)
lldilo,* Bacolod), ‘Leyte
pe - Lebu City
Palawan /; Crome 7 1S Sutigao
*Puerto :
-~ Princesa Negros \\Butuan
any a
Mindanao
Zamboanga, ; ; Davaog, |
*% Mount \\
Jolo:*” Basilan Apo
ae s~ Island
MALAYSIA ~~ ‘','d69df02853c7e1dc5008b93a64389e32e6433069657e0dd21d8a6e28429291ae','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54aecbf249f3ebc71ae194fb87698b2f10e4b9bfa3aa9374f3272ade8338530f',2021,'PH','Philippines','terrorism',861,'Terrorist groups—home based:
Abu Sayyaf Group (ASG): aim(s): establish an Islamic State in
the Philippines’ Mindanao Island and the Sulu Archipelago,
and ultimately, an Islamic caliphate across Southeast Asia
area(s) of operation: southern Philippines in Mindanao and
the Sulu Archipelago region (2018)
Communist Party of the Philippines/New People’s Army (CPP/NPA):
aim(s): destabilize the Philippines’ economy to inspire the
populace to revolt against the government and, ultimately,
overthrow the Philippine Government area(s) of operation:
operates throughout most of the country, primarily in rural
regions, with its strongest presence in the Sierra Madre
Mountains, rural Luzon, Visayas, and parts of northern and
eastern Mindanao; maintains cells in Manila, Davao City,
and other metropolitan areas (2018) Islamic State of Iraq and
ash-Sham (ISIS) network in Philippines: aim(s): replace the
Philippine Government with an Islamic state and implement
ISIS’s strict interpretation of sharia area(s) of operation:
Mindanao and the Sulu Archipelago region (2018)
Terrorist groups—foreign based:
Jemaah Islamiyah (JI): aim(s): enhance its networks in the
Philippines and, ultimately, overthrow the Philippine
Government and establish a pan-Islamic state across
Southeast Asia area(s) of operation: maintains an
operational and recruitment presence, especially in the
south (2018)','5731e5d122be7eb88722859072dca7c28a9921ae3d710249b3f9cdf129cb4830','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c6610b17be40a82335a3992b1ba76b85de63223f7422bbaa6367ccab6459cfe',2021,'PR','Puerto Rico','terrorism',874,'Terrorist groups—foreign based:
HAMAS: aim(s): continue engagement with the Qatari
Government area(s) of operation: maintains a limited office
in Doha (2018) TRANSNATIONAL ISSUES
Disputes—International: NONe
Refugees and internally displaced persons: Stateless persons:
1,200 (2018) Trafficking in persons: Current situation: Qatar is
a destination country for men, women, and children
subjected to forced labor, and, to a much lesser extent,
forced prostitution; the predominantly foreign workforce
migrates to Qatar legally for low- and semi-skilled work but
often experiences situations of forced labor, including debt
bondage, delayed or nonpayment of salaries, confiscation of
passports, abuse, hazardous working conditions, and
squalid living arrangements; foreign female domestic
workers are particularly vulnerable to trafficking because
of their isolation in private homes and lack of protection
under Qatari labor laws; some women who migrate for
work are also forced into prostitution tier rating: Tier 2
Watch List—Qatar does not fully comply with the minimum
standards for the elimination of trafficking; however, it is
making significant efforts to do so; the government
investigated 11 trafficking cases but did not prosecute or
convict any offenders, including exploitative employers and
recruitment agencies; the primary solution for resolving
labor violations was to transfer a worker’s sponsorship to a
new employer with minimal effort to investigate whether a
forced labor violation had occurred; authorities increased
their efforts to protect some trafficking victims, although
many victims of forced labor, particularly domestic
workers, remained unidentified and unprotected and were
sometimes punished for immigration violations or running
away from an employer or sponsor; authorities visited
worksites throughout the country to meet and educate
workers and employers on trafficking regulations, but the
government failed to abolish or reform the sponsorship
system, perpetuating Qatar’s forced labor problem (2015)','2e0b1b79ca6b3176f51d067d3d4ba89c7468d51956cafe5ab817f80a30ef1539','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a24e7d2adcf6cbfab6ce2653cf65595a5d4e11b0e2e0eb40bbd7a85a45778306',2021,'UA','Ukraine','terrorism',875,'Sibiu Brasov
Moldoveanu Ps
TRANSYLVANIAN AL 6
Pitesti, Ploiesti
wacacuia BUCHAREST
*Craiova Constantay
Giurgiu,','c0260445a85a780746de8cd2766c1113b96ae479ddb3564d16835b80b89edb55','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7305c4d8d04b2503415224e4750163951520e42a78bb848f0fcf9958dfa3ce67',2021,'BG','Bulgaria','terrorism',876,'9 50 100km
ok SA
503
Terrorist groups—foreign based:
Aum Shinrikyo (AUM): aim(s): attract new members seeking
religious guidance and exhibiting a_ willingness to
financially support the organization area(s) of operation:
between 1,500 and 30,000 AUM members live across
Russia; recruitment efforts have intensified in recent years
(2018) Islamic State of Iraq and ash-Sham-Caucasus (ISIS-Caucasus):
aim(s): implement its strict interpretation of sharia in
Dagestan, Chechnya, Ingushetia, and Kabardino-Balkariya;
retaliate for Russian involvement in the Syria conflict
area(s) of operation: operational in the Russian North
Caucasus, where the branch is known as Wilayat Kavkaz;
recruits mainly from Central Asian migrant populations
across Russia for domestic operations (2018)','1e7cb2ea0e0bb145b4c563839a8a7190ccac771c99a173e3216b9625a4c617fc','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d404f1896bb01e186ef309e2948e81f2ffc3e5452e420bba805a9fd3790f9ea',2021,'ID','Indonesia','terrorism',921,'Terrorist groups—foreign based:
Islamic State of Iraq and ash-Sham (ISIS) network in Singapore:
aim(s): enhance its networks in Singapore; implement
ISIS’s strict interpretation of sharia area(s) of operation:
attacks in Bangladesh are staged in Singapore; operates
under the name the Islamic State in Bangladesh (2018)
Jemaah Islamiyah (JI): aim(s): enhance its networks in
Singapore and, ultimately, overthrow the Singapore
Government and establish a pan-Islamic state across
Southeast Asia area(s) of operation: maintains a presence
(2018)','9441933ae9eec1cc5bd1b6c2adabe0ed1ab969dfec9c04f7d57b2dafc2f9248a','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b7b47161a50162b73badb54569c2b14e3bddf288a46d28464999e9e1b534a4d',2021,'SO','Somalia','terrorism',941,'Terrorist groups—home based:
al-Shabaab: aim(s): discredit and destabilize the Federal
Government of Somalia and target any countries or entities
that support Somalia’s fight against al-Shabaab; establish
Islamic rule across Somalia area(s) of operation: a core al-
Qa’ida affiliate that maintains strongholds in rural areas in
the south, where it controls a large swathe of the Lower
and Middle Juba and Lower Shabelle regions; responsible
for numerous’ high-profile bombings and_ shootings
throughout Somalia and in the northeast in Puntland State
(2018) Islamic State of Iraq and ash-Sham (ISIS) networks in Somalia:
aim(s): replace the Federal Government of Somalia with an
Islamic state and implement ISIS’s strict interpretation of
Sharia; replace al-Shabaab as the dominant armed
opposition to federal authority in Somalia area(s) of
operation: directs operations, recruitment, and training
from Puntland, the semiautonomous region in_ the
northeast; conducts sporadic attacks against African Union
and Somali Government personnel throughout the country
(2018) TRANSNATIONAL ISSUES
Disputes—International: Ethiopian forces invaded southern
Somalia and routed Islamist Courts from Mogadishu in
January 2007; “Somaliland” secessionists provide port
facilities in Berbera to landlocked Ethiopia and have
established commercial ties with other regional states;
“Puntland” and “Somaliland” “governments” seek
international support in their secessionist aspirations and
overlapping border claims; the undemarcated former
British administrative line has little meaning as a political
separation to rival clans within Ethiopia’s Ogaden and
southern Somalia’s Oromo region; Kenya works hard to
prevent the clan and militia fighting in Somalia from
spreading south across the border, which has long been
open to nomadic pastoralists Refugees and internally displaced
persons: refugees (country of origin): 21,295 (Ethiopia)
(refugees and asylum seekers), 13,153 (Yemen) (refugees
and asylum seekers) (2019) IDPs: 2.65 million (civil war
since 1988, clan-based competition for resources; 2011
famine; insecurity because of fighting between al-Shabaab
and the Transitional Federal Government’s allied forces)
(2019) SOUTH AFRICA
BOTSWANA Messina
Polokwane
PRETORIA
te (TSHWANE)
Johannesburg”
Upington , Richards
ingt Ladysmith, “Gay
Niesuthi ©
Kimberley®
Bloemfontein
De Aar,
~Durban
OCEAN East
» &Saldanha Port London,
sCape Town _ Elizabeth, —
Cape of
Good Hope','080f00096e7770ceebc5fb417d7a159f41e10526b29a29c1eda239c0892a6784','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac9f9a3e42b504239129d80915c6f56573ffeb4199258b0919d5615a3be8a81c',2021,'FR','France','terrorism',958,'Terrorist groups—home based:
Basque Fatherland and Liberty (ETA): aim(S): establish an
independent Basque homeland in northern Spain and
southwestern France based on Marxist principles area(s) of
operation: headquartered in northern Spain, reportedly
disarmed in 2017 (2018)','9c5f7e7a98274477402e1a0421422a42530751b1b6fa5b8439d5f8a4ba814157','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a8d5c95b48bd46adbeeb6b39874b70eee89f078b4cea7a1ff7fdc2bb00e7015',2021,'LK','Sri Lanka','terrorism',967,'Terrorist groups—home based:
Liberation Tigers of Tamil Eelam (LTTE): aim(s): revive the
movement to establish a Tamil homeland area(s) of
operation: presence is primarily in the east where members
occasionally plot attacks (2018) TRANSNATIONAL ISSUES
Disputes—International: NONe
Refugees and internally displaced persons: [DPs: 37,000 (civil war;
more than half displaced prior to 2008; many of the more
than 480,000 IDPs registered as returnees have not
reached durable solutions) (2018) Trafficking in persons:
current situation: Sri Lanka is primarily a source and, to a
lesser extent, a destination country for men, women, and
children subjected to forced labor and sex trafficking; some
Sri Lankan adults and children who migrate willingly to the
Middle East, Southeast Asia, and Afghanistan to work in
the construction, garment, and domestic service sectors
are subsequently subjected to forced labor or debt bondage
(incurred through high recruitment fees or money
advances); some Sri Lankan women are forced into
prostitution in Jordan, Maldives, Malaysia, Singapore, and
other countries; within Sri Lanka, women and children are
subjected to sex trafficking, and children are also forced to
beg and work in the agriculture, fireworks, and fish-drying
industries; a small number of women from Asia, Central
Asia, Europe, and the Middle East have been forced into
prostitution in Sri Lanka in recent years tier rating: Tier 2
Watch List—Sri Lanka does not fully comply with the
minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so; in 2014,
Sri Lanka was granted a waiver from an otherwise required
downgrade to Tier 3 because its government has a written
plan that, if implemented, would constitute making
significant efforts to bring itself into compliance with the
minimum standards for the elimination of trafficking; law
enforcement continues to demonstrate a _ lack of
understanding of trafficking crimes and inadequate
investigations, relying on trafficking cases to be prosecuted
under the procurement statute rather than the trafficking
statute, which carries more stringent penalties; authorities
convicted only one offender under the procurement statute,
a decrease from 2013; the government approved guidelines
for the identification of victims and their referral to
protective services but failed to ensure that victims were
not jailed and charged for crimes committed as a direct
result of being trafficked; no government employees were
investigated or prosecuted, despite allegations of
complicity (2015) SUDAN
Omdurman
EI KHARTOUM
Fasher ledani
+
&, Nyala
Triangle
Ne*
DEM. REP. OF THE CONGO
0 300 km
[A ale iS
0 300 mi','57b0005733c575c4a967a99c814d56efddedb97e73b35715c44473fe48f3e8cb','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23941dd0fb9afdaccef05d528cb695cdba705ef9b44eb2dd0dbca2192581c21a',2021,'JE','Jersey','terrorism',980,'Terrorist groups—home based:
al-Nusrah Front: aii(s): overthrow Syrian President Bashar al-
ASAD’s regime, absorb like-minded Syrian rebel groups,
and ultimately, establish a regional Islamic caliphate
area(s) of operation: headquartered in the northwestern
Idlib Governorate, with a minor presence in Halab
Governorate; operational primarily in northern, western,
and southern Syria; installs Sharia in areas under its
control; targets primarily Syrian regime and pro-regime
forces, some minorities, other Syrian insurgent groups, and
occasionally Western interests (2018) Hay’at Tahrir al-Sham
(HTS): aim(s): an alias of the al-Nusrah Front; overthrow
Syrian President Bashar al-ASAD’s regime, absorb like-
minded Syrian rebel groups, and, ultimately, establish a
regional Islamic caliphate area(s) of operation: Northwest
Syria (2018)
Islamic State of Iraq and ash-Sham (ISIS): aim(s): replace the
world order with a global Islamic state based in Iraq and
Syria; expand its branches and networks in other countries;
rule according to ISIS’s strict interpretation of Islamic law
area(s) of operation: ISIS has lost most of the territory it
once controlled and now its overt territorial control is
limited to pockets of land along the Syria-Iraq border and
in southern Syria (2018) Terrorist groups—foreign based:
Abdallah Azzam Brigades (AAB): aiim(s): disrupt and attack Shia
Muslim and Western interests in Syria area(s) of operation:
remains operational; conducts attacks against primarily
Shia Muslim organizations and individuals, including
Hizballah members, and Westerners and their interests
(2018) al-Qa’ida (AQ): aim/(s): overthrow President Bashar al-
ASAD’s regime; establish a regional Islamic caliphate and
conduct attacks outside of Syria area(s) of operation:
operational primarily in Idlib Governorate and southern
Syria, where it has established networks and operates
paramilitary training camps (2018) Ansar al-Islam (AAI):
aim(s): remove Syrian President Bashar al-ASAD from
power and establish a government operating according to
Sharia area(s) of operation: operationally active in Syria
since 2011; launches attacks on Syrian Government
security forces and pro-Syrian Government militias; some
AAI factions combat ISIS, while others are aligned with
ISIS (2018) Hizballah: aim(s): preserve Syrian President
Bashar al-ASAD’s regime area(s) of operation: operational
activity throughout the country since 2012; centered on
providing paramilitary support to President Bashar al-
ASAD’s regime against armed insurgents (2018) Islamic
Revolutionary Guard Corps—Qods Force (IRGC-QF): aim(s): assist
government forces in suppressing opposition forces and
Islamic State of Iraq and ash-Sham (ISIS) forces; train
Syrian Government troops; conduct strikes against Israel;
funnel arms and money onward to Lebanese Hizballah
area(s) of operations: throughout Syria (2019)
Kata’ib Hizballah (KH): aim(s): preserve Syrian President
Bashar al-ASAD’s regime area(s) of operation: deploys
combatants to Syria to fight alongside Syrian Government
and Lebanese Hizballah forces (2018) Kurdistan Workers’ Party
(PKK): aim(s): advance Kurdish autonomy, political, and
cultural rights in Syria, Turkey, Irag, and Iran area(s) of
operation: operational in the north and east; majority of
members inside Syria are Syrian Kurds, along with Kurds
from Iran, Iraq, and Turkey (2018) Mujahidin Shura Council in
the Environs of Jerusalem (MSC): aim/(s): destroy the state of
Israel; enhance its networks in Syria area(s) of operation:
maintains limited networks for operational planning against
Israel (2018) Palestine Liberation Front (PLF): aim(s): enhances
its networks and, ultimately, destroy the state of Israel and
establish a secular, Marxist Palestinian state with
Jerusalem as its capital area(s) of operation: maintains a
recruitment and training presence in many refugee camps
(2018) PFLP-General Command (PFLP-GC): aim(s): preserve
Syrian President Bashar al-ASAD’s regime area(s) of
operation: maintains a political base in Damascus; fights
with President al-ASAD’s forces and Hizballah in areas
where anti-regime paramilitary groups are active (2018)
Popular Front for the Liberation of Palestine (PFLP): aim(s): enhance
its recruitment networks in Syria area(s) of operation:
maintains a recruitment and limited training presence in
several refugee camps (2018) TRANSNATIONAL ISSUES
Disputes—International: Golan Heights is Israeli-controlled
with an almost 1,000-strong UN Disengagement Observer
Force patrolling a buffer zone since 1964; lacking a treaty
or other documentation describing the boundary, portions
of the Lebanon-Syria boundary are unclear with several
sections in dispute; since 2000, Lebanon has claimed
Shab’a Farms in the Golan Heights; 2004 Agreement and
pending demarcation would settle border dispute with
Jordan Refugees and internally displaced persons: refugees
(country of origin): 15,699 (Iraq) (2018); 560,139
(Palestinian Refugees) (2019) IDPs: 6.2 million (ongoing
civil war since 2011) (2019)
stateless persons: 160,000 (2018); note—Syria’s stateless
population consists of Kurds and Palestinians; stateless
persons are prevented from voting, owning land, holding
certain jobs, receiving food subsidies or public healthcare,
enrolling in public schools, or being legally married to
Syrian citizens; in 1962, some 120,000 Syrian Kurds were
stripped of their Syrian citizenship, rendering them and
their descendants’ stateless; in 2011, the Syrian
Government granted citizenship to thousands of Syrian
Kurds as a means of appeasement; however, resolving the
question of statelessness is not a priority given Syria’s
ongoing civil war note: the ongoing civil war has resulted in
almost 5.7 million registered Syrian refugees—dispersed in
Egypt, Irag, Jordan, Lebanon, and Turkey—as of January
2020
Trafficking in persons: Current situation: as conditions continue
to deteriorate due to Syria’s civil war, human trafficking
has increased; Syrians remaining in the country and those
that are refugees abroad are vulnerable to trafficking;
Syria is a source and destination country for men, women
and children subjected to forced labor and sex trafficking;
Syrian children continue to be forcibly recruited by
government forces, pro-regime militias, armed opposition
groups, and terrorist organizations to serve as soldiers,
human shields, and executioners; ISIL forces Syrian women
and girls and Yazidi women and girls taken from Iraq to
marry its fighters, where they experience domestic
servitude and sexual violence; Syrian refugee women and
girls are forced into exploitive marriages or prostitution in
neighboring countries, while displaced children are forced
into street begging domestically and abroad tier rating: Tier
3—the government does not fully comply with the minimum
standards for the elimination of trafficking and is not
making significant efforts to do so; in 2014, Syria’s violent
conditions enabled human trafficking to flourish; the
government made no effort to investigate, prosecute, or
convict trafficking offenders or complicit government
officials, including those who forcibly recruited child
soldiers; authorities did not identify victims and failed to
ensure victims, including child soldiers, were protected
from arrest, detention, and severe abuse as a result of
being trafficked (2015) Illicit drugs: a transit point for
opiates, hashish, and cocaine bound for regional and
Western markets; weak anti-money-laundering controls and
bank privatization may leave it vulnerable to money
laundering
TAIPEI \\..Keelung
Zhongli, *
“Hsinchu Su’''ao
Quemoy ; Yonaguni-
Taichung jima
jHualien -
PESCADORES
Magong® Chiayi fu shan
Tainan
ad
Taitung, ;
Kaohsiung®
Liugiu Yu
0 30 60km
SERGE
ti) % 60 mi','863eef63cc8fe6dcd9ccd489e523325201d6fd68080598f574d5cc98a5987a1f','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7421d62c9a66edbb0454ea58a31bc3c293ec0fe0cb8be2e205350fb4348ee6fc',2021,'TT','Trinidad and Tobago','terrorism',1000,'Terrorist groups—home based:
Islamic State of Iraq and ash-Sham (ISIS) networks in Turkey: aim(s):
replace the Turkish Government with an Islamic state and
implement ISIS’s strict interpretation of sharia area(s) of
operation: moves fighters and supplies across the Turkey-
Syria border; has periodically conducted attacks against
civilian and government security targets (2018) Revolutionary
People’s Liberation Party/Front (DHKP/C): aim(s): install a Marxist-
Leninist government in Turkey area(s) of operation:
membership centered in Turkey, leadership primarily
spread throughout Europe; in recent years has revived its
attacks against Turkish Government elements, primarily in
Istanbul; outlawed in Turkey (2018) Terrorist groups—foreign
based:
al-Nusrah Front: aii(s): overthrow Syrian President Bashar al-
ASAD’s regime, absorb like-minded Syrian rebel groups,
and ultimately, establish a regional Islamic caliphate
area(s) of operation: some facilitation networks (2018)
al-Qa’ida (AQ): aim(s): radicalize the Turkish populace and
eventually overthrow the Turkish Government as part of a
long-term plan to establish a pan-Islamic caliphate under a
strict Salafi Muslim interpretation of sharia area(s) of
operation: maintains facilitation networks (2018)
Kurdistan Workers’ Party (PKK): aim(s): advance Kurdish
autonomy, political, and cultural rights in Turkey, Iran, Iraq,
and Syria area(s) of operation: operational predominantly
in the southeast; the group’s primary targets include
government, military, and security personnel and facilities;
majority of members inside Turkey are Turkish Kurds,
along with Kurds from Iran, Iraq, and Syria; the group is
outlawed in Turkey (2018) TRANSNATIONAL ISSUES
Disputes—International: Complex maritime, air, and territorial
disputes with Greece in the Aegean Sea; status of north
Cyprus question remains; Turkey has expressed concern
over the status of Kurds in Iraq; in 2009, Swiss mediators
facilitated an accord reestablishing diplomatic ties between
Armenia and Turkey, but neither side has ratified the
agreement and the rapprochement effort has faltered;
Turkish authorities have complained that blasting from
quarries in Armenia might be damaging the medieval ruins
of Ani, on the other side of the Arpacay valley Refugees and
internally displaced persons: refugees (country of origin):
170,000 (Afghanistan), 142,000 (Iraq), 39,000 (Iran), 5,700
(Somalia) (2019); 3,576,659 (Syria) (2020) IDPs: 1.097
million (displaced from 1984-2005 because of fighting
between the Kurdish PKK and Turkish military; most IDPs
are Kurds from eastern and southeastern provinces; no
information available on persons displaced by development
projects) (2018) stateless persons: 117 (2018)
Illicit drugs: key transit route for Southwest Asian heroin to
Western Europe and, to a lesser extent, the US—via air,
land, and sea routes; major Turkish and other international
trafficking organizations operate out of Istanbul;
laboratories to convert imported morphine base into heroin
exist in remote regions of Turkey and near Istanbul;
government maintains strict controls over areas of legal
opium poppy cultivation and over output of poppy straw
concentrate; lax enforcement of money-laundering controls','311fe43016be54a0024e8a725258c4d4e67c34e3626b879c0adb0614b7126c5d','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('433fc2616c23116869640200e49248dd6b8e6453fb2a43670de7f107003268ac',2021,'SS','South Sudan','terrorism',1005,'Terrorist groups—foreign based:
al-Shabaab: aim(s): punish Ugandan Government for
participating in African Union military operations against
al- Shabaab; compel Uganda to withdraw forces from
Somalia area(s) of operation: aspires to renew attacks in
Kampala; no permanent presence (2018)','2300c32f3b1e20508a536b65ba37784cc171370160acb8630fbab05be6f83388','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('552f9230c7dadae2818db4f4e4583dc22e8a6849b29d6031880eb590696ed6e3',2021,'WF','Wallis and Futuna','terrorism',1035,'Terrorist groups—home based:
Kahane Chai (Kach): aim(s): restore the biblical state of Israel;
expel Arabs from Israel’s biblical lands area(s) of operation:
present in West Bank Jewish settlements, especially the
Qiryat Arba’ settlement in Hebron, where operatives have
conducted bombings and shootings against Muslim and
Christian Palestinians; operationally inactive in recent
years (2018) Terrorist groups—foreign based:
HAMAS: aiin(s): grow its political and operational presence
in the West Bank area(s) of operation: mostly political
activity; small cells scattered throughout the West Bank for
militant and _ illicit finance purposes (2018) Islamic
Revolutionary Guard Corps—Qods Force (IRGC-QF): aim/(s): launch
attacks against Israel, reduce Israel’s presence and
influence in the West Bank, and destroy the state of Israel;
works through proxies and allies such as Hamas, Palestine
Islamic Jihad (PIJ), Palestine Liberation Front (PLF), and
Popular Front for the Liberation of Palestine (PFLP) area(s)
of operations: West Bank (2019)
Palestine Islamic Jihad (PI): aim(s): enhance its staging
capabilities in the West Bank to launch attacks against
Israel area(s) of operation: mostly political activity; strives
to maintain an operational presence (2018) Palestine
Liberation Front (PLF): aim(s): enhance its networks in the
West Bank and, ultimately, destroy the state of Israel;
establish a secular, Marxist Palestinian state with
Jerusalem as its capital area(s) of operation: maintains a
recruitment and training presence in some of the West
Bank’s refugee camps (2018) Popular Front for the Liberation of
Palestine (PFLP): aim(s): bolster its recruitment networks in
the West Bank area(s) of operation: mostly political activity,
maintains a recruitment presence targeting youths (2018)','80ccf377a636813923c9448e7d26be33591efb218ae634c9e67b9f23497fad78','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

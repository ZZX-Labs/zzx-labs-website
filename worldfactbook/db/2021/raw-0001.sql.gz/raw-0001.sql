SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4e9789de2f841cf067c54b6eec17267d1f05354938898ef30ad940be8af954',2021,'','','raw',1,'CENTRAL INTELLIGENCE AGENCY
‘WORLD
FACTBOOK
CENTRAL INTELLIGENCE AGENCY
Inlle
WORLD
rACTBOOK
2020-2021
CENTRAL INTELLIGENCE AGENCY
Skyhorse Publishing
Copyright © 2020 by Skyhorse Publishing All rights reserved. No part of this
book may be reproduced in any manner without the express written consent of
the publisher, except in the case of brief excerpts in critical reviews or articles.
All inquiries should be addressed to Skyhorse Publishing, 306 West 37th Street,
11th Floor, New York, NY 10018.
Skyhorse Publishing books may be purchased in bulk at special discounts for
sales promotion, corporate gifts, fund-raising, or educational purposes. Special
editions can also be created to specifications. For details, contact the Special
Sales Department, Skyhorse Publishing, 307 West 36th Street, 11th Floor, New
Skyhorse ® and Skyhorse Publishing ® are registered trademarks of Skyhorse
®
Publishing, Inc.™, a Delaware corporation.
Visit our website at www.skyhorsepublishing.com.
10987654321
Library of Congress Cataloging-in-Publication Data is available on file.
Cover design by Brian Peterson Print ISBN: 978-1-5107-5825-4
Ebook ISBN: 978-1-5107-5826-1
Printed in the United States of America
CONTENTS','db6a345bcc546dd6c07710c784d2865edd4a00f7aa3aa2f05f8d6a9082977386','internet-archive','the-cia-world-factbook-2020-2021','txt','f74e0230c21655bd892121a6b1d93e070fbd61ab2e33213ba2672315528a88e0','https://archive.org/download/the-cia-world-factbook-2020-2021/The_CIA_World_Factbook_2020_2021_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

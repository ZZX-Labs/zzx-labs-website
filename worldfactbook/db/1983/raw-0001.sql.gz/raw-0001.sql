SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f779e5a8bb5e0268729e2e5aa58a0ab9e71964bfecb4e686e9402f66b1e9276',1983,'','','raw',1,'CIA - The World Factbook, ; Caye tule
“Approved for Release: 2022/12/08 C06979323
Central Intelligence Agency
_ The Work of a Nation. The Center of Intelligence
“.) Search’
!
pee rr CPS ee ie en ea
Publication: :. ee-ts wee
‘ Ea ee ey Nba
SUD 2 BS yy? eae bc Be ad os De hia bee eee rat
banca ~ v ar ga :
THE WORLD FACTBOOK
4
ety
% = SELECT A COUNTRY OR LOCATION ---
+ SIEVE TENTLOW SANSVACT a Vi
ABOUT REFERENCES APPENDICES FAQs © CONTACT See nc
preaennovctyamsanaman ater te nn pee
CENTRAL AMERICA AND CARIBBEAN :: EL SALVADOR
PAGE LAST UPDATED ON DECEMBER 5, 2012
i rst
fx -“ vrew 1 PHOTO
b> OF EL SALVADOR
CLICK MAP TO ENLARGE | ''
EXPAND ALL | COLLAPS
intreduction :: EL SALVADOR','b85c68fd6d6530ebbc88f6861d12458aa1e28452082140d6101d8ffe36e8b443','internet-archive','cia-readingroom-document-06979328','txt','2e7c8b567acb97b4e4913dbdb2da073810c419b3e7f5cf81ed6ade91d1c3bd26','https://archive.org/download/cia-readingroom-document-06979328/06979328_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7c2045bfbe70f3c4b245f53636e13af2ffb5efe4f999abf56d79fa16d7cba3d',1983,'','','introduction',2,'EI Salvador achieved independence from Spain in 1821 and from the Central American
Federation in 1839, A 12-year civil war, which cost about 75,000 lives, was brought to a close in
{992 when the government and leftist rebels signed a treaty that provided for military and
politica) reforms.
cecece team pesmecumeremestemenswatennyermessmmtegaremuassmesinmested beguanemms rand masimnresmndcaseroenazeassanacamsstumesemagomensanyegerer—reramere@ tetas ease eeeeS tees centr ewes em sen eerye tae nme Cee emme ro
Geography :: EL SALVADOR
Location:
Central America, bordering the North Pacific Ocean, between Guatemala and Honduras
Geographic coordinates:
13 50 N, 88 55 W
hhtteacedAsrana eta aavilhrard/nnhliieations/the-world-factbook/ceos/es. html 12/17/2012 ‘| a
Approved for Release: 2022/12/08 C06979328
CIA ~- The World Factbook va
Approved for Release: 2022/12/08 C06979328)
=
Map references:
Central America and the Caribbean
Area:
total: 21,041 sq km
country comparison to the world: 153
jJand: 20,721 sq km
water: 320 sq km
Area - comparative:
slightly smaller than Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342 km
Coastline:
307 km
Maritime claims:
territorial sea; 72 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate:
Page 2 of 18
tropical: rainy season (May to October); dry season (November to April); tropical on coast;
tamperate in uplands
Terrain:
mostly mountains with narrow coastal belt and central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources:
hydropower, geothermal power, petroleum, arable land
Land use:
arable land: 31.37%
permanent crops: 11.88%
other: 56.75% (2005)
- Irrigated land:
450 sq km (2003)
Total renewable water resources;
httns://www.ci a.cov/librarv/publications/the-world-factbook/geos/es.html
Approved for Release: 2022/12/08 C06979328
12/17/2012 is
CIA - ‘The World Factbook. x.
eve for Release: 2022/12/08 nS
25.2 cu km (2001)
Freshwater withdrawal (domestic/industrial/agricultural):
total: 1.28 cu km/yr (25%/16%/69%)
per capita: 186 cu m/yr (2000)
Natural hazards:
Page 3 ot 1%
known as the Land of Volcanoes; frequent and sometimes destructive earthquakes and volcanic
activity; extremely susceptible to hurricanes
volcanism: significant volcanic activity; San Salvador (elev. 1,893 m), which fast erupted jn
1917, has the potential to cause major harm to the country''s capital, which lies just below the
volcano''s slopes; San Miguel (elev. 2,130 m), which last erupted in 2002, is one of the most
active volcanoes in the country; other historically active volcanoes include Conchaguita,
Nlopango, lzalco, and Santa Ana
Environment - current issues:
deforestation: soil erosion; water pollution;-contamination of soils from disposal of toxic wastes
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto Protoco!, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography - note:
smallest Central American country and only one without a coastline on Carlbbean Sea
Adame si antaanmm ines nnme tion seb emers ties ss ae ssemb iain s omnes comme omen emess
People and Society :: EL SALVADOR
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups:
mestizo 90%, white 9%, Amerindian 1%
Languages:
Spanish (official), Nahua (among some Amerindlans)
Religions:
wah etme eh Pape PemmenN seme en HEE MELE MEOH MEE Ou pR Om TE mmTE OMEN mHeCerm etme Fe mas,
U9 a9 eames epee wen la nen ene pi v0 amen dante ¢ mo 90 Me 8
Roman Catholic 57.1%, Protestant 21.2%, Jehovah''s Witnesses 1.9%, Mormon 0.7%, other
religions 2.3%, none 16.8% (2003 est.)
Population:
6,090,646 (July 2012 est.)
country comparison to the world: 106
Age structure: :
0-14 years: 29.7% (male 928,41 35/ female 882,159)
Tidteas errr nia aaullthrarcc/nr whlicati on e/the-world-facthook/geos/es. html
Approved for Release: 2022/12/08 C06979328
vam 74
CIA - Lhe World Factbook. aes
Approved for Release: 2022/12/08 C069793285
15-64 years: 63.7% (male 1,829,483/ female 2,049,977)
_65 years and over: 6.6% (male 178,004/ female 221,888) (2012 est.)
Medlan age:
total: 24,7 years
maie: 29.4 years
female: 26.2 years (2012 est.)
Population growth rate:
0.303% (2012 est.)
country comparisan to the world: 166
Birth rate:
17.44 births/1,000 population (2012 est.)
country comparison to the world: 112
Death rate:
5.63 deaths/1,000 population (July 2012 est.)
country comparison to the world: 173
Net migration rate:
-8.78 migrant(s)/1,000 population (2012 est.)
country comparison te the world: 206
Urbanization:
urban population: 64% of total population (2010)
rate of urbanization: 1.4% annual rate of change (2010-15 est.)
Major citles - population:
SAN SALVADOR (capital) 1.534 million (2009) ,
Sex ratio:
at birth: 1.05 male(s)/female
under 18 years: 1.05 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.93 male(s)/female (2011 ast.)
Maternal mortality rate:
81 deaths/100,000 live births (2010)
country comparison to the world: 81
Infant mortality rate:
total: 19.66 deaths/1,000 live births
country comparison to the world: 97
male: 21.73 deaths/1,000 live births
female: 17.5 deaths/1,000 live births (2012 est.) , r
httns://www.cia.sov/librarv/oublications/the-world-factbook/geos/es.html
Approved for Release: 2022/12/08 C06979328
Page 4 of 18
12/17/2012 JH
CIA - The World Factbook. Page 5 of 18
approved for Release: 2022/12/08 C06979328
Life expectancy at birth:
total population: 73,69 years
country comparison to the world: 116
male: 70.41 years
female: 77.12 years (2012 est.)
Total fertility rate:
2.04 children born/woman (2012 est.)
country comparison to the world: 127
Heaith expenditures:
3.9% of GDP (2009)
country comparison to the world: 164
Physicians density:
1.596 physicians/1,000 population (2008)
Hospital bed density:
1.1 beds/1,000 population (2009)
HIVIAIDS - adult prevalence rate:
0.8% (2009 est.)
country comparison to the world: 54
HIV/AIDS - people living with HIV/AIDS:
34,000 (2009 est.)
country comparison to the world: 67
HIV/AIDS - deaths:
1,400 (2009 est.)
country comparison to the world: 61
Major infectlous diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and typhoid fever
yvectorborne diseases: dengue fever
water contact disease: leptospirosis (2009)
Children under the age of 5 years underweight:
6.1% (2003)
country comparison to the world: 77
Education expenditures:
3.6% of GDP (2008)
Se country comparison to the world: 115
Literacy:
htins://www.cia.cov/librarv/nublications/the-world-factbook/geos/es.html 12/17/2012 Wb
Approved for Release: 2022/12/08 C06979328
CIA - The World Factbook. a Page 6 of 18
ee for Release: 2022/12/08 cle
definition: age 15 and over can reed and write
total population: 81.1%
male: 82.8%
female: 79.6% (2007 census)
School life expectancy (primary to tertiary education):
total: 12 years
male: 12 years
female: 12 years (2008)
Unemployment, youth ages 15-24:
total: 11.4%
‘country comparison to the world: 94
malo: 13% ‘
female: 8.3% (2007)
Lem 99 mnn me com seem SFA OAD DI DP RR EPL ITA met ener ssp ene 2s tet iene tO ane OLONOA TOMS SERS TENS NOME Hens 48 sted e ded De Inbt nem ne bones om SA Em ey mee Cee cmET CREE a FLED D EO EY ely sem HEE EE DNRC NE DOME LON Y Heme ene ERE Ane,
Government :: EL SALVADOR
Country name:
conventional long form: Republic of El Salvador
conventional short form: El Salvador
local long form: Republica de E] Salvador
local short form: El Salvador
Government type:
republic
Capital:
name: San Salvador
geographic coordinates; 13 42 N, 89 12 W
time difference: UTC-6 (1 hour behind Washington, DC during Standard Time)
daylight saving time: all year for 2012.
Administrative divisions:
’ 44 departments (departamentos, singular - departamento); Anuachapan, Cabanas,
Chalatenango, Cuscatlen, La Libertad, La Paz, La Union, Morazan, San Miguel, San Salvador,
San Vicente, Santa Ana, Sonsonate, Usulutan
!
Independence:
45 September 1821 (from Spain)
National holiday:
independence Day, 15 September (1821}
httns://www.cia.gov/librarv/publications/the-world-factbook/geos/es.html 12/17/2012 i, /
Approved for Release: 2022/12/08 C06979328
CIA - ‘Lhe World Factbook page / OF 13
woes for Release: 2022/12/08 C06979328)
Constitution:
20 December 1983
Legal system:
civil law system with minor common law influence; judicial review of legislative acts in the
Supreme Court
International law organization participation:
has not submitted an IGJ jurisdiction declaration; non-party state to the ICCt
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Carlos Mauricio FUNES Cartagena (since 1 June 2009); Vice President
Saivador SANCHEZ CEREN (since 1 June 2009); note - the president is both the chief of state
and head of government
head of government: President Carlos Mauricio FUNES Cartagena (since 1 June 2009); Vice
President Salvador SANCHEZ CEREN (since 1 June 2009)
cabinet: Council of Ministers selected by the president
(For more information visit the World Leaders website
elections: president and vice president elected on the same ticket by popular vote for a single
five-year term; election last held on 15 March 2009 {next to be held in March 2014)
election results: Mauricio FUNES Cartagena elected president; percent of vote - Mauricio
FUNES Cartagena 51.3%, Rodrigo AVILA 48.7%
a)
Legislative branch:
unicameral Legislative Assembly or Asamblea Legislativa (84 seats; members elected by direct,
popular vote to serve three-year terms)
elections: last held on 11 March 2012 (next to be held in 2015)
election results: percent of vote by party - NA; seats by party - ARENA 33, FMLN 31, GANA 11,
CN 7, PES 1, PCD 1
Judicial branch: ;
Supreme Court or Corte Suprema (15 judges are selected by the Legislative Assembly; the 15
judges are assigned to four Supreme Court chambers - constitutional, civil, penal, and
administrative conflict)
Political parties and leaders:
Democratic Change (Cambio Democratico) or PCD; Democratic Convergence or CD [Oscar
KATTAN] (formerly United Democratic Center or CDU); Farabundo Marti National Liberation
Front or FMLN [Medardo GONZALEZ]; Great Alliance for National Unity or GANA [Andres
ROVIRA]; National Conciliation or CN [Ciro CRUZ ZEPEDA] (formerly the National Concillation
Party or PCN); Nationalist Republican Alllance or ARENA [Alfredo CRISTIANI]; Party of Hope or
‘PES [Rodolfo PARKER] (formerly the Christian Democratic Party or PDC) 7
Political pressure groups and leaders:
labor organizations - Electrical Industry Union of El Satvador or SIES; Federation of the
Construction Industry, Similar Transport and other activities, or FESINCONTRANS; National
Confederation of Saivadoran Workers or CNTS; National Union of Salvadoran Workers or UNTS;
LutensHhener aia eat Theard/nnbliratiana/the-world.facthank/sens/es. html 12/17/2012 1b
Approved for Release: 2022/12/08 C06979328
CIA - The World Factbook,
Lr age OvULLS
Approved for Release: 2022/12/08 C06979328)
Port Industry Union of El Salvador or. SIPES: Salvadoran Union of Ex-Petrolleros and Peasant
Workers or USEPOC: Salvadoran Workers Central or CTS; Workers Union of Electrical
Corporation or STGEL; business organizations - National Association of Small Enterprise or
ANEP; Salvadoran Assembly Industry Association or ASIC; Salvadoran Industrial Association or
ASI
international organization participation: :
BCIE, CACM, CD, CELAG, FAO, G-11, G-77, IADB, IAEA, IBRD, ICAO, ICC (with national
committees), ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO, Interpol, 1OC, OM, IPU, 180
(correspondent), ITSO, ITU, ITUC, LAES, LAIA (observer), MIGA, MINURSO, NAM (observer),
OAS, OPANAL, OPCW, PCA, SICA, UN, UNCTAD, UNESCO, UNIDO, UNIFIL, Union Latina,
UNMIL, UNMISS, UNWTO, UPU, WCO, WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Francisco Robert ALTSCHUL Fuentes
chancery: Suite 100, 1400 16th Street, Washington, DC 20036
telephone: [1] (202} 265-9671
FAX: [1] (202) 234-3763
consulate(s) general: Brentwood (New York), Boston, Chicago, Goral Gables (Florida), Dallas,
Duluth (Georgia), Elizabeth (New Jersey), Houston, Las Vegas, Los Angeles, Miami, New York,
Nogales (Arizona), Santa Ana (California), San Francisco, Woodbridge (Virginia)
consulate(s); Boston, Elizabeth (New Jarsey)
Diplomatic representation from the US:
chief of mission: Ambassador Sean MURPHY
embassy: Final Boulevard Santa Elena Sur, Antiguo Cuscatlan, La tibertad, San Salvador
mailing address: Unit 3450, APO AA 34023; 3450 San Salvador Place, Washington, DG 20521-
3450
telephone: [503] 2501-2999
FAX; [503] 2501-2150
Flag description:
three equal horizontal bands of blue (top), white, and blue with the national! coat of arms
centered in the white band; the coat of arms features a round emblem encircled by the words
REPUBLICA DE EL SALVADOR EN LA AMERICA CENTRAL; the banner is based on the former
blue-white-blue flag of the Federal Republic of Central America; the blue bands symbolize the
Pacific Ocean and the Caribbean Sea, while the white band represents the land between the two
bodies of water, as well as peace and prosperity
note: simllar to the flag of Nicaragua, which has a different coat of arms centered in the white
band - it features a triangle encircled by the words REPUBLICA DE NICARAGUA on top and
AMERICA CENTRAL on the bottom; also similar to the flag of Honduras, which has five blue
stars arranged in an X pattern centered in the white band
National symbol{s}:
turquoise-browed motmot (bird)
National anthem:
SuRgERRAn- « aie sma i-|
eal etal chattels ei
iopoaranete: Juan Jose CANAS/Juan ABERLE
htine-//xranw cia cav/lihrarv/nublications/the-world-factbook/geos/es.html
Approved for Release: 2022/12/08 C06979328
12/17/2012 4
VLA. - LOG WOT PacwwUuUk
Approved for Release: 2022/12/08 c06979328§
Lae 7 VL Lo
note: officially adapted 1953, in use since 1879; the anthem of El Salvador is one of the world''s
longest
Economy :: EL SALVADOR
Economy - overview: 2
See eerort tT ter titer tire t ence thos etl Stott elt Pree ig
The smallest country in Central America geographically, El Salvador has the third largest
economy In the region, With the global recasston in 2009, real GDP contracted by 3.1%. The
economy began a slow recovery in 2010 on the back of improved export and remittances figures.
Remittances accounted for 17% of GDP in 2011 and were recelved by about a third of all
households. In 2006, E] Salvador was the first country to ratify the Dominican Republic-Central
American Free Trade Agreement (CAFTA-DR), which has bolstered the export of processed
foods, sugar, and ethanol, and supported investment in the apparel sector amid Increased Asian
competition. El Salvador has promoted an open trade and investment environment and has
embarked on a wave of privatizations extending to telecom, electricity distribution, banking, and
pension funds. The Salvadoran Government maintained fiscal discipline during post-war
reconstruction and reconstruction following earthquakes In 2001 and hurricanes in 1998 and
2005. Taxes levied by the government include a value added tax (VAT) of 13%, income tax of
30%, excise taxes on alcohol and cigarettes, and import duties. The VAT accounted for about
51.7% of total tax revenues in 2011. Calculated according to the International Monetary Fund
{IMF) standards, El Salvador''s public external debt in December 2011 was about $12.95 billion
or 57.3% of GDP. El Salvador''s total public debt includes non-financial public sector debt,
financial public sector debt, and central bank debt. In 2006, E/ Salvador and the Millennium
Challenge Corporation (MCC) - a United States Government agency - signed a five-year, $461
million compact to stimulate economic growth and reduce poverty in the country''s northern
region, the primary conflict zone during the civil war, through investments in education, public
services, enterprise development, and transportation Infrastructure. In December 2011, the MCC
approved E! Salvador''s eligibility to develop a proposal for a second compact for consideration.
GDP (purchasing power parity):
$44.58 billion (2011 est.}
country comparison to the world: 96
$43.96 billion (2010 est.)
‘$43.34 billion (2009 est.)
note; data are in 2011 US dollars
GDP (official exchange rate):
$22.4 billion (2011 est.).
GDP - real growth rate:
1.4% (2011 est.)
country comparison to the world: 173
1.4% (2010 est.)
-3.1% (2009 est.)
GDP - per capita (PPP):
$7,500 (2011 est.)
country comparison to the world: 130
$7,500 (2010 est.)
$7,400 (2009 est.)
hHnas/fanirar ea aaw/Whrard/nnhtications/the-world-factbook/geos/es .html
Approved for Release: 2022/12/08 C06979328
12/17/2012 80
CLA - ‘Lhe World Factbook,
Approved for Release: 2022/12/08 C06979326)
nofe: data are in 2011 US dollars
GDP - composition by sector:
agriculture: 10.5%
industry: 29.8% ;
services: 59.7% (2011 est.)
Labor force:
2.581 million (2011 est.)
country comparison to the world: 111
Labor force - by occupation:
agriculture: 21%
industry: 20%
services: 58% (2011 est.)
Unemployment rata:
7% (2011 est.)
country comparison to the world: 78
7.2% (2010 est.) ;
note: data are official rates; but the economy has much underemployment
Population below poverty line:
36.5% (2010 est.)
Household income or consumption by percentage share:
lowest 10%: 1%
highest 10%: 37% (2009 ast.)
Distribution of family income - Gini Index:
46.9 (2007)
country comparison to the world: 32
§2.5 (2001)
Investment (gross fixed):
14.6% of GDP (2011 est.)
country comparison to the world: 137
Budget:
revenues: $4.413 billion
expenditures: $5.319 billion (2011 est.)
Taxes and other revenues:
19.7% of GDP (2011 est.)
country comparison to the world: 165
Budget surplus (+) or deficit (-):
4% of GDP (2017 est.)
Vdd we Me ele nee hima heh inadinanaltha wrel d_facthanl-/aenc/ac html
Approved for Release: 2022/12/08 C06979328
Page 10 of 18
VAT T/D012. 8]
CiA - Loe World Factbook.
_ for Release: 2022/12/08 C06979323
country comparison to the world: 130
Public debt:
57.5% of GDP (2011 est.)
country comparison te the world: 48 >
53.8% af GDP (2010 est.)
Inflation rate (consumer prices):
5.1% (2011 est.)
country comparison to the world: 135
1.2% (2010 est.)
Commercial bank prima lending rate:
5,99% (31 December 2011 est.)
country comparison to the world: 125
7.62% (31 December 2010 ast.)
Stock of narrow money:
$2.561 billion (31 December 2011 est.)
country comparison to the world: 117
$2,627 billion (31 December 2010 est.)
Stock of broad money:
$9.213 billion (31 December 2011 est.)
country comparison to the world: 109
$9.388 billion (31 Dacember 2010 est.)
Stock of domestic credit:
$10.69 billion (31 December 2011 est.)
country comparison to the world: 96
$10,04 billion (31 December 2010 est.)
Market value of publicly traded shares:
$5.474 billion (31 December 2011)
country comparison to the world: 84
$4.227 billion (31 December.2010)
$4.432 billion (31 Decamber 2009)
Agriculture - products:
coffee, sugar, corn, rice, beans, oilseed, cotton, sorghum, beef, dairy products
Industries:
Page 11 of 18
food processing, beverages, petroleum, chemicals, fertilizer, textiles, furniture, light metals
Industrial production growth rate:
1.8% (2011 est.)
country comparison te the world: 126
https://www.cia.gov/library/publications/the-world-factbook/geos/es.btml
Approved for Release: 2022/12/08 C06979328
12/17/2012 62
CIA - The World Factbook. Page 12 of 18
on for Release: 2022/12/08 C06979323 ,
Currant accoinnt balance:
-$1.223 billion (2011 est.)
country comparison to the world: 132
-$657.9 million (2010 est.)
Exports:
$5,402 billion (2011 est.)
country comparison to-the world: 113
$4.77 billion (2010 est.)
Experts - commodities:
offshore assembly exports, coffee, sugar, textiles and apparel, gold, ethanol, chemicals,
electricity, iron and steel manufactures
Exports = partners:
US 45.1%, Guatemala 13.3%, Honduras 8.6%, Nicaragua 5.2%, Germany 4.1% (2011)
Imports:
$9.801 billion (2011 est.)
country comparison to the world: 96
$8.189 billion {2010 est.)
Imports - commodities:
raw materials, consumer goods, capital goods, fuels, foodstuffs, petroleum, electricity
Imports - partners:
US 39%, Guatemala 9.8%, Mexico 7.7%, China 5.2% (2011)
Reserves of foreign exchange and gold:
$2.504 billion (2011 est.)
country comparison to the world: 112
$2.883 billion (2010 est.)
Debt - external:
$12.18 billion (31 December 2011 est.)
country comparison to the world: 88
$11.07 billion (31 December 2010 est.)
Stock of direct foreign investment - at home:
$8.097 billion (31 December 2017 est.)
country comparison to the world: 84
$7.76-billion (31 December 2010 est.)
Stock of direct foreign investment « abroad:
$12.4 million (31 December 2011 est.)
cauntry comparison to the world: 90
$7 million (31 December 2010 est.)
12/17/2012 &3
hitne:-fAaranw cia onv/lihrarv/miblications/the-world-factbook/geos/es.html
Approved for Release: 2022/12/08 C06979328
CIA - The World Factbook. .
Approved for Release: 2022/12/08 ee
Ld
Exchange rates:
Page 13 of 18
note: the US dollar is used as a medium of exchange and circulates freely in the economy
Fiscal year:
calendar year
weg naen astm ee ees ehgd SHADE TUR Renee ee rhe Bare peed ER RELA OL LO SE REAATEPAD Theme ene sma ee pee Aa SE PRE ek) ASMA SEN AL ene Rese ninn Imm nes reg enene nem eaten sete f:
Energy :: EL SALVADOR
Electricity - production:
5.728 billion kWh (2011 est.)
country comparison to the world: 113
Electricity - consumption:
5.756 billion kWh (2011 est.)
country comparison to the world: 109
Electricity - exports:
101.6 million kWh (2011 est.)
country comparison to the world: 75
Electricity - imports:
215.8 million kWh (2011 est.)
country comparison to the world: 85
Electricity - Installed generating capacity:
41.501 million kW (2009 est.)
country comparison to the world: 114
Electricity - from fossil fuels:
53% of total installed capacity (2009 est.)
country comparison to the world: 150
Electricity - from nuclear fuels:
0% of total Installed capacity (2009 est.)
country comparison to the world: 86
Electricity - from hydroelectric plants:
34.4% of total installed capacity (20089 est.)
httne://www.cia.cov/librarv/publications/the-world-factbook/geos/es.html
Approved for Release: 2022/12/08 C06979328
Ati need EA cen cae et on EN NRRL Seem o Oue OG Qe
12/17/2012 BF
LIA - Lhe World Factbook, i Page 14 of 18
, . Approved for Release: 2022/12/08 ©06979320) .
country comparison to the world: 71
Electricity - from other renewable sources:
15.6% of total installed capacity (2009 est.)
‘ country comparison to the world: 14
Crude oil - production:
0 bbi/day (2011 est.)
country comparison to the world: 131
Crude oil - exports:
0 bbi/day (2009 est.)
country comparison to the world: 108
Crude oll - imports:
13,160 bbi/day (2009 est.)
country comparison to the world: 74
Crude oil - proved reserves:
0 bb! (1 January 2012 est.)
country comparison to the world: 130
Refined petroleum products - production:
16,750 bbi/day (2008 est.)
country comparison to the world: 98
Refined petroleum products - consumption:
44,040 bbi/day (2011 est.)
country comparison to the world: 105
Refined petroleum products ~ exports:
2,158 bbi/day (2008 est.)
country comparison to the world: 104
Refined petroleum products - imports:
26,860 bbi/day (2008 est.)
country comparison to the world: $1
Natural gas - production:
0 cu m (2010 est.)
country comparison to the world: 126
Natural gas - consumption:
0 cu m (2010 est.)
country comparison to the world: 141
Natural gas - exports:
httna://www.cia.cov/librarv/publications/the-world-factbook/geos/es.html 12/17/2012 85
Approved for Release: 2022/12/08 C06979328
CIA - The World Factbook Page 15 of 18
Approved for Release: 2022/12/08 C06979328
0 cu m (2010 est.)
country comparison to the warld: 193
Natural gas - imports:
O cu m (2010 est.)
country comparison to t','0cd4883c650541c2818467b54ca367df409bf271f0f3e0a01f3833aad54543c0','internet-archive','cia-readingroom-document-06979328','txt','2e7c8b567acb97b4e4913dbdb2da073810c419b3e7f5cf81ed6ade91d1c3bd26','https://archive.org/download/cia-readingroom-document-06979328/06979328_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f132aa3d996c611a77986789e20c7d02d0eb2be966b7602db8b0a6e496e39931',1983,'','','introduction',3,'he world: 192
Natural gas - proved reserves:.
Ocum (1 January 2012 est:}
country comparison to the world: 135
Carbon dioxide emissions from consumption of energy:
6.484 million Mt (2010 est.)
country comparison to the world: 117
Oe So ot NEM OST UN eerie eeenen Hllae ynwelD HuNEtW lah ORE ES ut DG gets mT e er hed EEHNS EON seme ent Me Erte ranma gemme Leman ae nee nee gen eo Ne Pe A EE OF img Ne Ho Bangg ee b wee ne nau 66 tee Hh ok men Ato AG NEAE ELEY He bgoeE EES
Communications :: EL SALVADOR
Telephones - main lines in use:
950,000 (2011)
country comparison to the world: 81
Telephones - mobile cellular:
7.837 million (2041)
country comparison to the world: 89
Telephone system:
general assessment: multiple mobile-cellular providers are expanding services rapidly and In
2041 taledensity exceeded 125 per 100 persons; growth in fixed-line services has slowed tn the
face of moblle-cellular competition
domestic: nationwide microwave radio relay system
international: country cade - 503; satellite earth station ~ 1 Intelsat (Atlantic Ocean}; connected
to Central American Microwave Systam (2011)
Broadcast media:
multiple privately-owned national terrestrial TV networks, supplemented by cable TV networks
that carry international channels; hundreds of commercial radio broadcast stations and 1
government-owned radio broadcast station (2007)
Internet country code:
SV
Internet hosts:
24,070 (2012)
httne:/fananw.cia.cov/librarv/publications/the-world-factbook/geos/es.html 12/17/2012 AG
Approved for Release: 2022/12/08 C06979328
CIA - ‘Lhe World Factbook.
pproved for Release: 2022/12/08 C06979328
w
country comparison to the world: 113
Internet users:
746,000 (2009)
country comparison to the world: 107
ARNO net Stren dees coe RUMI ot AE mE P eee amy ome COME OSE EEA ED Pere secu ste E TOR HORT sh enn Stand Peed Ret meer ee res arava s Mes Tdens Semen nema eee!
Transportation :: EL SALVADOR
Alrports:
65 (2012)
country comparison to the worid: 77
Airports - with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 1
944 to 1,523 m: 2
under $714 m: 1 (2012)
Airports - with unpaved runways:
total: 60
4,524 to 2,437 m: 1
914 to 1,523 m: 11
under $14 m: 48 (2012)
Heliports:
2 (2012)
Railways:
total: 283 km
country comparison to the world: 121
harrow gauge: 283 km 0.600-m gauge
Page 16 of 18
note: railways have been inoperable since 2005 because of disuse and high costs that led to a
lack of maintenance (2008)
Roadways:
total: 10,886 km
country comparison to the world: 134
paved: 2,827 km (includes 327 km of expressways)
unpaved: 8,059 km (2000)
Waterways:
(Rio Lempa is partially navigable for small craft) (2011)
Ports and terminals: -
Puerto Cutuco
httns:/Awww.cia.cov/librarv/nublications/the-world-factbook/geos/es.html
Approved for Release: 2022/12/08 C06979328
12/17/2012 e) 7
WhO RAS YY UL ELRE 2 Oe Lr awe A re ae
pproved for Release: 2022/12/08 C06979328
~~
oil terminals: Acajutla offshore terminal
deme came none Soameet mat i many mamas) OES PSE EET MAS GtdS bed Coenen deems esmcome taumeas meng mes seme Same SPER EEE EEOUET ROTEE HES tid ratte ecmebsnmh tyne rh mnienmniemesummesunasreaesaasiaamayanDa meno mm chuntsnanseaweriaa sero ns onesie
Military :: EL SALVADOR.
Military branches:
Salvadoran Armed Forces (FAES):.Salvadoran Army (ES), Salvadoran Navy (FNES), Salvadoran
Air Force (Fuerza Aerea Salvadorena, FAS) (2011)
Military service age and obligation:
18 years of age for selective compulsory military service; 16-22 years of age for voluntary male
or female service; service obligation - 12 months, with 11 months for officers and NCOs (2009)
Manpower avallable for military service:
males age 16-49: 1,449,214
females age 16-49: 1,611,248 (2010 est.)
Manpower fit for military service:
males age 16-49: 1,079,038
females age 16-49: 1,373,368 (2010 est.)
Manpower reaching militarily significant age annually:
male: 71,530
female: 68,971 (2010 est.)
Military expenditures:
0.6% of GDP (2009)
country comparison to the world: 157
bib pasds Shwe sanns gamengee shenannendenvedanndemnns hmasa sent pereaEnn anya mes AEte phim rime nanmaanevaekhekinnintas aime nrirararusneumanensaumasamwunemaaredagetdanrsRyes oAisit
Transnational Issues :: EL SALVADOR
Disputes - international:
International Court of Justice {ICJ) ruled on the delimitation of "bolsones" (disputed areas) along
the El Salvador-Honduras boundary, in 1992, with final agreement by the parties In 2006 after an
Organization of American States survey and a further ICJ ruling In 2003; the 1992 ICJ ruling
advised a tripartite resolution to a maritime boundary in the Gulf of Fonseca advocating
Honduran access to the Pacific; El Salvador continues to claim tiny Gonejo Island, not identified
in the [Cd decision, off Honduras in the Gulf of Fonseca
Ilicit drugs:
transshipment point for cocaine; small amounts of marijuana produced for local consumption;
significant use of cocaine
weennnatsueecepomyenitomeannnrermeanmeshe eas: angsmns amet esame ameegcnts eer se toms tam sasmnammmecowsneeetsegen
EXPAND ALL | COLLAP
httne-//urww cia.cavilibrarv/oublications/the-world-factbook/geos/es.html 12/17/2012 Bb
Approved for Release: 2022/12/08 C06979328
- Oe
Wer A Te A dees TE Wate a we —
di,
Gor0ve0 for Release: 2022/12/08 C06979328
Privacy
Copyright
Site Policies
NoPFEAR Act
FOIA
USA.gov
DNI.gov
Contact CIA
Site Map
https://www.cia.gov/library/publications/the-world-factbook/geos/es. html 12/17/2012 SA
Approved for Release: 2022/12/08 C06979328','a0fe2196ca8905c7593691f4126f318cf2556338d86f7d2eeb437d825c48afce','internet-archive','cia-readingroom-document-06979328','txt','2e7c8b567acb97b4e4913dbdb2da073810c419b3e7f5cf81ed6ade91d1c3bd26','https://archive.org/download/cia-readingroom-document-06979328/06979328_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3f13498679d342aee7c7f724c972f07d7c634845e483d86f7907f21cca9f103',2009,'US','United States','transnational-issues',68,'Disputes— international
Refugees and internally displaced persons
refugees
lDPs
Trafficking in persons
current situation
tier rating
Illicit drugs
xxxii
m . . .Hermosslto
Motto* Ch.huahua
Redof>do
V f
Nuevoy
UredsoV ’
.Topolofeampo
Culiacan
1^1:
*
<3ti t cH
NORTH
Sars Luis
Petssl V
* .
AtJamsra
Agu4»«ali<*i
Putoo
‘Guadalajara MEXICO
Morelia* , if Puebla .Veracruz
iCSflCUfl
mviit mmm
Toluca
Acapulco*
€&rfahmn
Sm
o 4mm
o 2m tmvti
Disputes— international: in 2002,
Gibraltar residents voted overwhelm¬
ingly by referendum to reject any “shared
sovereignty” arrangement between the
UK and Spain; the Government of
Gibraltar insists on equal participation in
talks between the two countries; Spain
disapproves of UK plans to grant
Gibraltar greater autonomy; Mauritius
and Seychelles claim the Chagos
Archipelago (British Indian Ocean
Territory), and its former inhabitants
since their eviction in 1965; most
Chagossians reside in Mauritius, and in
2001 were granted UK citizenship, where
some have since resettled; in May 2006,
the High Court of London reversed the
UK Government’s 2004 orders of council
that banned habitation on the islands;
UK rejects sovereignty talks requested by
Argentina, which still claims the
Falkland Islands (Islas Malvinas) and
South Georgia and the South Sandwich
Islands; territorial claim in Antarctica
(British Antarctic Territory) overlaps
Argentine claim and partially overlaps
Chilean claim; Iceland, the UK, and
Ireland dispute Denmark’s claim that the
Faroe Islands’ continental shelf extends
beyond 200 nm
Illicit drugs: producer of limited
amounts of synthetic drugs and synthetic
precursor chemicals; major consumer of
Southwest Asian heroin, Latin
American cocaine, and synthetic drugs;
money-laundering center
D STATES
Disputes— international: the U S. has
intensified domestic security measures
and is collaborating closely with its
neighbors, Canada and Mexico, to mon¬
itor and control legal and illegal per¬
sonnel, transport, and commodities
across the international borders; abun¬
dant rainfall in recent years along much
of the Mexico-US border region has
ameliorated periodically strained water¬
sharing arrangements; 1990 Maritime
Boundary Agreement in the Bering Sea
still awaits Russian Duma ratification;
686
UNITED STATES PACIFIC ISLAND WILDLIFE REFUGES
managed maritime boundary disputes
with Canada at Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca, and
around the disputed Machias Seal Island
and North Rock; The Bahamas and US
have not been able to agree on a man
itime boundary; US Naval Base at
Guantanamo Bay is leased from Cuba
and only mutual agreement or US aban¬
donment of the area can terminate the
lease; Haiti claims US-administered
Navassa Island; US has made no territo¬
rial claim in Antarctica (but has
reserved the right to do so) and does not
recognize the claims of any other states;
Marshall Islands claims Wake Island;
Tokelau included American Samoa’s
Swains Island among the islands listed
in its 2006 draft constitution
Refugees and internally displaced per¬
sons: refugees (country of origin): the US
admitted 62,643 refugees during
FY04/05 including; 10,586 (Somalia);
8,549 (Faos); 6,666 (Russia); 6,479
(Cuba); 3,100 (Haiti); 2,136 (Iran)
(2006)
Illicit drugs: world’s largest consumer of
cocaine, shipped from Colombia through
Mexico and the Caribbean; consumer of
ecstasy and of Mexican heroin, mari¬
juana and methamphetamine; minor
consumer of high-quality Southeast
Asian heroin; illicit producer of
cannabis, marijuana, depressants, stimu¬
lants, hallucinogens, and methampheta-
mine; money-laundering center
UNITED STATES PACIFIC ISLAND WILDLIFE REFUGES
Union of Soviet Socialist Republics (Soviet Union); used for information dated before
25 December 1991
UTC
UV
VHF
VS AT
WADB
WAEMU
WCL
WOO
Wetlands
WEU
WFP
WFTU
Whaling
WHO
WIPO
WMO
WP
WTO
ZC
Coordinated Universal Time
ultra violet
very-high-frequency
very small aperture terminal
West African Development Bank
West African Economic and Monetary Union
World Confederation of Labor
World Customs Organization
Convention on Wetlands of International Importance Especially As Waterfowl Habitat
Western European Union
World Food Program
World Federation of Trade Unions
International Convention for the Regulation of Whaling
World Health Organization
World Intellectual Property Organization
World Meteorological Organization
Warsaw Pact
World Trade Organization
Zangger Committee
740
APPENDIX B
INTERNATIONAL ORGANIZATIONS AND GROUPS
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid industrial development; see newly industrializing
economies (NIEs)
advanced economies
a term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced economies, countries in
transition, and developing countries; it includes the following 28 advanced economies: Australia, Austria, Belgium, Canada,
Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg,
Netherlands, NZ, Norway, Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; note — this group would presum¬
ably also cover the following seven smaller countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein, Monaco, and
San Marino that are included in the more comprehensive group of “developed countries’’
African Development Bank Group (AfDB) note — regional multilateral development finance institution temporarily located in
Tunis, Tunisia; the Bank Group consists of the African Development Bank, the African Development Fund, and the Nigerian
Trust Fund
established — 10 September 1964
aim — to promote economic development and social progress
regional members — (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Djibouti, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar,
Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia,
US
US
USA
840
USA
• US
United States Minor
-
UM
UMI
581
.um
ISO includes Baker Island,
Outlying Islands
65 00 N
153 00 W
Pacific Ocean
58 00 N
145 00 W
Atlantic Ocean
36 00 N
2 30 W
52 55 N
172 57 E
19 45 N
155 45 W
21 00 N
157 45 W
57 49 N
152 23 W
Russia
67 20 N
37 00 E
Federated States of Micronesia
6 58 N
158 13 E
Pacific Ocean
39 00 N
124 00 E
Pacific Ocean
34 00 N
129 00 E
North Korea
40 00 N
127 00 E
South Korea
37 00 N
127 30 E
28 25 N
178 20 W
57 00 N
170 00 W
46 15 N
122 12 W
49 30 N
67 00 W
Atlantic Ocean
49 15 N
67 00 W
Atlantic Ocean
48 00 N
62 00 W
57 11 N
170 16 W
French Southern and
38 43 S
77 29 E
Antarctic Lands
38 53 N
77 02 W
Southern Ocean
72 00 S
45 00 W
''■? «wl life McKinley ~ '' ’ .
(hatidst ptxm m Fairbanks
'' > 4 >U ( <Vi
tjR*. I
5? 4.
^ vy
Kangerlu$«iaq
^ {Sendre Stftsmijtffd)
4 ?
;
^ . %
" Anchorage*., .Dawson
“liiuvik
■; 7
•..4
'' '' 4: .7
: Wm, I WM 44*--,
mKmiB
, Vmarw d /
Island
V- Camhi idge Ray :
MISS*, * tsftflii tfikiil:
Baffin ■
Island
■7v
arsarsuaq
•** strait
(FrederikshabL
77
“Kodiak
Qi)& <>i
a LsG
Valdo 1
llllltt
HH
Repuke Bay,y 4 iq:aiui,
» , „ / *
> 77. e 47 Ccho Bav . - / 4. • l >
| mp
Ycllovvkmtc
1
Echo Rav
■ifrS»#«8 '' " '' ■” ^ NyC-S: I''-t : r »Jft •''wwev''-— ■»» /<
y^i *,3-7 .e* , x \\
, ,-?N, \\ labraticrSea
Rankin inlet ; * Ivujivik ■ :
(4. fHlfcfe \\
’ ''/rf'' W
5 fc/
Dappy Valley-
, Goose Ray tslamtof
Scheffcrviik^ • Newfoundland
■ 1, . w T
“k: , ... , churchfi! 7. -0 •
s<? * '' / . . . . . . .
#Chisasibi
y *«<;* O
Geotge #
Edmonton Moosonee.
Blip ■■ | . .
.Whitehorse '' *J- -
V\\ ”/ \\[J\\ Q;
Watson
*. .lake
luncpf*
IU\\ Rivet*
’
y jjrincc Rupert ^ ■ >■
Scale 1:360,000
0 5 Kilometers
L-H . 1 .
T“ - !
5 Miles
■x .jet/ r/A v ( s
180 ■
North
Pacific
Ocean
Scale 1 : 2 7,o60,000
Albers Equal- Aren Projection
standard parallels 28°30''N and 45 °30''N
0 300 Kilometers if j A
-1 - * — 1 i Hs
300 Miles
Chihuahua','2ed2326159fc0da0eb6ea9772e8fac32d587ba5dbb3f719df5505cd4cb37e18a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fe4feea39ef21517101da0a7034acbe9a9ecb9d39b1578977c27026629de98f',2009,'DZ','Algeria','transnational-issues',81,'Disputes — international: the Albanian
Government calls for the protection of
the rights of ethnic Albanians in neigh¬
boring countries, and the peaceful reso¬
lution of interethnic disputes; some
ethnic Albanian groups in neighboring
countries advocate for a “greater
Albania,” but the idea has little appeal
among Albanian nationals; the mass
emigration of unemployed Albanians
remains a problem for developed coun¬
tries, chiefly Greece and Italy
Illicit drugs: increasingly active trans¬
shipment point for Southwest Asian opi¬
ates, hashish, and cannabis transiting the
Balkan route and — to a lesser extent —
cocaine from South America destined
for Western Europe; limited opium and
growing cannabis production; ethnic
Albanian narcotrafficking organizations
active and expanding in Europe; vulner¬
able to money laundering associated with
regional trafficking in narcotics, arms,
contraband, and illegal aliens
0 HM ij»kw
S 55 $88 m>
Background: In 788, about a century
after the Arab conquest of North Africa,
successive Moorish dynasties began to
rule in Morocco. In the 16th century, the
Sa’adi monarchy, particularly under
Ahmad AL-MANSUR (1578-1603),
repelled foreign invaders and inaugurated
a golden age. In 1860, Spain occupied
northern Morocco and ushered in a half
century of trade rivalry among European
powers that saw Morocco’s sovereignty
steadily erode; in 1912, the French
imposed a protectorate over the country.
A protracted independence struggle with
France ended successfully in 1956. The
internationalized city of Tangier and
most Spanish possessions were turned
over to the new country that same year.
Morocco virtually annexed Western
Sahara during the late 1970s, but final
resolution on the status of the territory
remains unresolved. Gradual political
reforms in the 1990s resulted in the estab¬
lishment of a bicameral legislature, which
first met in 1997. Improvements in
human rights have occurred and there is
a largely free press. Despite the contin¬
uing reforms, ultimate authority remains
in the hands of the monarch.
Location: Northern Africa, bordering
the North Atlantic Ocean and the
Mediterranean Sea, between Algeria and
Disputes — international: stretching
over 250,000 km, the world’s 322 inter¬
national land boundaries separate 194
independent states and 70 dependencies,
areas of special sovereignty, and other
miscellaneous entities; ethnicity, culture,
race, religion, and language have divided
states into separate political entities as
much as history, physical terrain, polit¬
ical fiat, or conquest, resulting in some¬
times arbitrary and imposed boundaries;
most maritime states have claimed limits
that include territorial seas and exclusive
economic zones; overlapping limits due
to adjacent or opposite coasts create the
potential for 430 bilateral maritime
boundaries of which 209 have agree¬
ments that include contiguous and non¬
contiguous segments; boundary,
borderland/resource, and territorial dis¬
putes vary in intensity from managed or
dormant to violent or militarized; unde-
marcated, indefinite, porous, and unman¬
aged boundaries tend to encourage illegal
cross-border activities, uncontrolled
migration, and confrontation; territorial
disputes may evolve from historical
and/or cultural claims, or they may be
brought on by resource competition;
ethnic and cultural clashes continue to
be responsible for much of the territorial
fragmentation and internal displacement
of the estimated 6.6 million people and
cross-border displacements of 8.6 million
refugees around the world as of early
2006; just over one million refugees were
repatriated in the same period; other
sources of contention include access to
water and mineral (especially hydro¬
carbon) resources, fisheries, and arable
land; armed conflict prevails not so much
between the uniformed armed forces of
independent states as between stateless
armed entities that detract from the sus¬
tenance and welfare of local populations,
leaving the community of nations to cope
with resultant refugees, hunger, disease,
impoverishment, and environmental
degradation
Refugees and internally displaced per-
sons: the United Nations High
Commissioner for Refugees (UNHCR)
estimated that in December 2006 there
was a global population of 8.8 million
registered refugees and as many as 24.5
million IDPs in more than 50 countries;
the actual global population of refugees is
probably closer to 10 million given the
estimated 1.5 million Iraqi refugees dis¬
placed throughout the Middle East
(2007)
717
THE CIA WORLD FACTBOOK
TraffiCkinQ in persons: current situation:
about 600,000 to 800,000 people, mostly
women and children, are trafficked
annually across national borders, not
including millions trafficked within their
own countries; at least 80% of the vie-
tims are female; 75% of all victims are
trafficked into commercial sexual
exploitation; roughly two-thirds of the
global victims are trafficked intra-region-
ally within East Asia and the Pacific
(260,000 to 280,000 people) and Europe
and Eurasia (170,000 to 210,000 people)
Tier 2 Watch List: Argentina, Armenia,
Belarus, Burundi, Cambodia, Central
African Republic, Chad, China, Cyprus,
Dijbouti, Dominican Republic, Egypt,
Fiji, The Gambia, Guatemala, Guyana,
Honduras, India, Kazakhstan, Kenya,
Libya, Macau, Mauritania, Mexico,
Moldova, Mozambique, Papua New
Guinea, Russia, South Africa, Sri Lanka,
Ukraine, United Arab Emirates
Tier 3: Algeria, Bahrain, Burma, Cuba,
Equatorial Guinea, Iran, Kuwait, Malaysia,
North Korea, Oman, Qatar, Saudi Arabia,
Sudan, Syria, Uzbekistan, Venezuela
Illicit drugs: cocaine: worldwide coca leaf
cultivation in 2005 amounted to 208,500
hectares; Colombia produced slightly
more than two-thirds of the worldwide
crop, followed by Peru and Bolivia;
potential pure cocaine production rose
to 900 from 645 metric tons in 2005 —
partially due to improved methodologies
used to calculate levels of production;
Colombia conducts aggressive coca erad¬
ication campaign, but both Peruvian and
Bolivian Governments are hesitant to
eradicate coca in key growing areas; 551
metric tons of export-quality cocaine
(85% pure) is documented to have been
seized or destroyed in 2005; US con¬
sumption of export quality cocaine is
estimated to have been in excess of 380
metric tons
opiates: worldwide illicit opium poppy
cultivation reached 208,500 hectares in
2005; potential opium production of
4,990 metric tons was only a 9% decrease
over 2004’s highest total recorded since
estimates began in mid-1980s;
Afghanistan is world’s primary opium
producer, accounting for 90% of the
global supply; Southeast Asia — respon¬
sible for 9% of global opium — saw mar¬
ginal increases in production; Latin
America produced 1% of global opium,
but most was refined into heroin des¬
tined for the US market; if all potential
opium was processed into pure heroin,
the potential global production would be
577 metric tons of heroin in 2005
718
Background: North Yemen became mde-
pendent of the Ottoman Empire in 1918.
The British, who had set up a protec-
torate area around the southern port of
Aden in the 19th century, withdrew in
1967 from what became South Yemen.
Three years later, the southern govern''
ment adopted a Marxist orientation. The
massive exodus of hundreds of thousands
of Yemenis from the south to the north
contributed to two decades of hostility
between the states. The two countries
were formally unified as the Republic of
Yemen in 1990. A southern secessionist
movement in 1994 was quickly subdued.
In 2000, Saudi Arabia and Yemen agreed
to a delimitation of their border.
AG
DZ
DZA
012
DZA
.dz
28 00 N
3 00 E
36 47 N
2 03 E
35 43 N
0 43 W','3cf2d4e663d394212197a1b68e3a8fd7f46216e9bc073b53a124a63d2b85d765','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38438be6e3e38a93d17cb1a9b1c2e4305a89514167d5a6d101aa12c1a0a4ac8d',2009,'AS','American Samoa','transnational-issues',85,''' '' •'' - 0
Disputes — international: Algeria sup-
ports the Polisario Front exiled in
Algeria and who represent the Sahrawi
Arab Democratic Republic; Algeria
rejects Moroccan administration of
Western Sahara; most of the approxi¬
mately 90,000 Western Saharan Sahrawi
refugees are sheltered in camps in
Tindouf, Algeria; Algeria’s border with
Morocco remains an irritant to bilateral
relations, each nation accusing the other
of harboring militants and arms smug¬
gling; Algeria remains concerned about
armed bandits operating throughout the
Sahel who sometimes destabilize
southern Algerian towns; dormant dis¬
putes include Libyan claims of about
32,000 sq km still reflected on its maps of
southeastern Algeria and the FLN’s
assertions of a claim to Chirac Pastures
in southeastern Morocco
Refugees and internally displaced per¬
sons: refugees ( country of origin): 90,000
(Western Saharan Sahrawi, mostly living
in Algerian-sponsored camps in the
southwestern Algerian town of Tindouf)
IDPs: undetermined (civil war during
1990s) (2007)
Trafficking in persons: current situation:
Algeria is a transit and destination
country for men, women, and children
from sub-Saharan Africa and Asia traf¬
ficked for forced labor and sexual
exploitation; many victims willingly
migrate to Algeria en route to European
countries with the help of smugglers,
where they are often forced into prostitu¬
tion, labor, and begging in order to pay
off their smuggling debt; some Algerian
children are reportedly trafficked within
the country for domestic servitude
tier rating: Tier 3 — Algeria does not ade¬
quately identify trafficking victims
among illegal immigrants; the govern¬
ment did not take serious law enforce¬
ment actions to punish traffickers who
force women into commercial sexual
exploitation or men into involuntary
servitude; the government reported no
investigations of trafficking of children
for domestic servitude or improvements
in protection services for victims of traf¬
ficking
AMERICAN
0
i mm
Swains
island
ICO mi
& U
m
South
AT;
Pacific
saj
Ok>saga
\\
•%- Ros?&
Ocean
island
Tutiiita
PAGO PAGO*
/■-A
•: :-;w / '' ;
Aunu''u
.
i
Tutuila
s
o M
20 kirn
Q t)
;> 20 ?r
AQ
AS
ASM
016
ASM
.as
14 20 S
170 00 W
14 13 S
169 35 W
14 16 S
170 42 W
11 03 S
171 15 W
14 18 S
170 42 W
Atlantic Ocean
40 00 N
12 00 E','ad64d0b35c34ac5e37d060b3edcb7be1dd0a776a072cb73e590c6e948db3ca14','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3925041deceed2d8c20fa02cd493f05c569e39cbf9a67ff7ccc02e3e72c26028',2009,'AD','Andorra','transnational-issues',90,'/ ; '' .. -.y • •, _ . ; V •
Disputes — international: Tokelau
included American Samoa’s Swains
Island (Olohega) in its 2006 draft
constitution
AN
AD
AND
020
AND
.ad
42 30 N
1 30 E','c03fb454e5b60f29bebe913ae39a47fc0267407c55b2c5d7232e2b0c47f9a27a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e799f4c2c57228e5c8f5e60b20a3b6ec28dcff9c3dd997f05e35ac9b9c245d40',2009,'AO','Angola','transnational-issues',97,'Disputes — international: none
Disputes— international: many
Cabindan separatists have returned to
the province from exile since the 2006
ceasefire and peace agreement; concerns
from international experts and local pop¬
ulations over the Okavango Delta
ecology in Botswana and human dis¬
placement scuttled Namibian plans to
construct a hydroelectric dam at
Popavalle (Popa Falls) along the
Angola-Namibia border
Refugees and internally displaced per¬
sons: refugees (country of origin): 12,615
(Democratic Republic of Congo)
IDPs: 61,700 (27-year civil war ending
in 2002; 4 million IDPs already have
returned) (2007)
Illicit drugs: used as a transshipment
point for cocaine destined for Western
Europe and other African states, particu¬
larly South Africa
20
Background: Colonized by English set-
tiers from Saint Kitts in 1650, Anguilla
was administered by Great Britain until
the early 19th century, when the
island — against the wishes of the inhabi¬
tants — was incorporated into a single
British dependency, along with Saint
Kitts and Nevis. Several attempts at sep¬
aration failed. In 1971, two years after a
revolt, Anguilla was finally allowed to
secede; this arrangement was formally
recognized in 1980, with Anguilla
becoming a separate British dependency.
Disputes— international: none
Illicit drugs: transshipment point for
South American narcotics destined for
the US and Europe
22
mm
Background: Speculation over the exis¬
tence of a “southern land” was not con¬
firmed until the early 1820s when British
and American commercial operators and
British and Russian national expeditions
began exploring the Antarctic Peninsula
region and other areas south of the
Antarctic Circle. Not until 1840 was it
established that Antarctica was indeed a
continent and not just a group of islands.
Several exploration “firsts” were
achieved in the early 20th century.
Following World War II, there was an
upsurge in scientific research on the con¬
tinent. A number of countries have set
up a range of year-round and seasonal
stations, camps, and refuges to support
scientific research in Antarctica. Seven
have made territorial claims, but not all
countries recognize these claims. In order
to form a legal framework for the activi¬
ties of nations on the continent, an
Antarctic Treaty was negotiated that
neither denies nor gives recognition to
existing territorial claims; signed in
1959, it entered into force in 1961.
Disputes— international: heads of the
Great Lakes states and UN pledge to
abate tribal, rebel, and militia fighting in
the northeastern region of the
Democratic Republic of the Congo
(DROC); in 2006, the UN Organization
Mission in the Democratic Republic of
the Congo (MONUC) maintained over
18,000 uniformed peacekeepers in the
region, first deployed in 1999; despite
significant repatriation efforts by govern¬
ments and international organizations,
in 2006, Angolans, Rwandans,
Sudanese, and residents of other neigh¬
boring states reside as refugees in the
DROC; members of Uganda’s Lords
Resistance Army forces take refuge in
DROC’s Garamba National Park; the
location of the boundary in the broad
Congo River with the Republic of the
Congo is indefinite except in the Pool
Malebo/Stanley Pool area
Refugees and internally displaced per¬
sons: refugees (country of origin): 132,295
(Angola); 37,313 (Rwanda); 17,777
(Burundi); 13,904 (Uganda); 6,181
(Sudan); 5,243 (Republic of Congo)
IDPs: 1.4 million (fighting between gov¬
ernment forces and rebels since mid-
1990s; most IDPs are in eastern
provinces) (2007)
Illicit drugs: one of Africa’s biggest pro¬
ducers of cannabis, but mostly for domestic
consumption; while rampant corruption
and inadequate supervision leaves the
banking system vulnerable to money laun¬
dering, the lack of a well-developed finan¬
cial system limits the country’s utility as a
money-laundering center
CONGO, REPUBLIC OF THE
Geographic coordinates: 15 00 S, 30 00
E
Map references: Africa
Area: total: 752,614 sq km
land: 740,724 sq km
water: 1 1,890 sq km
Area — comparative: slightly larger than
Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1,110 km,
Democratic Republic of the Congo 1 ,930
km, Malawi 837 km, Mozambique 419
km, Namibia 233 km, Tanzania 338 km,
Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; modified by altitude;
rainy season (October to April)
Terrain: mostly high plateau with some
hills and mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: unnamed location in
Mafinga Hills 2,301 m
Natural resources: copper, cobalt, zinc,
lead, coal, emeralds, gold, silver, ura¬
nium, hydropower
Land use: arable land: 6.99%
permanent crops: 0.04%
other: 92.97% (2005)
Irrigated land: 1,560 sq km (2003)
Total renewable water resources: 105.2
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.74 cu
km/yr (17%/7%/76%)
per capita: 149 cu m/yr (2000)
Natural hazards: periodic drought, trop¬
ical storms (November to April)
Environment — current issues: air pollu¬
tion and resulting acid rain in the min¬
eral extraction and refining region;
chemical runoff into watersheds;
poaching seriously threatens rhinoceros,
elephant, antelope, and large cat popula¬
tions; deforestation; soil erosion; deserti¬
fication; lack of adequate water
treatment presents human health risks
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: landlocked; the
Zambezi forms a natural riverine
boundary with Zimbabwe
AO
AO
AGO
024
AGO
.ao
5 33 S
12 12 E
Cape Verde
16 00 N
24 00 W
Atlantic Ocean
47 20 N
59 30 W
8 48 S
13 14 E
Mayotte — v
(admin. by ( ranee,
claimed by Comoros) J,
Kitwc’SJ Lilongw
ZAMBIA . . -
UBalwA — Lc"*
Nacalj
l wba-eo
Ttpmeilo Island
(fftANCP
Namibc
Wan tie Nova l>1
(FRANCE! f.
SL i kkm
(St. Helena)
Harare
* Antananarivo ,*
/ W sTBenteT .
MADAGASCAR Reunion
I . m (t''KANcn
j BOTSWANA •• i
KAt.AHAfll
- ~&emfET y '' ii:
Gaborone ♦ Pretoria
Windhoek !
YValvis Bay^
| NAMIBIA
: &M Maputo
■abSW''7
SWAZILAND
iohatrnesbtirg
SOUTH
AFRICA'' .
Durban
Port Klixabclh
Scale 1 : 3 1 ,400,000
Azimuthal Equal-Area Projection
0 BOO Kilometers
StX) Miles
Boundary representation is
not necessarily authoritative.
817
THE CIA WORLD FACTBOOK
ANTARCTIC REGION
■ Year-round research station
Scale 1:68,000.000
Azimuthal Equal-Area Projection
Port Elizabeth
SOUTH
AFRICA
300
1000 Kilometers
— ! - i
5 o u t h \\ A t ! a n 1 1 c
O ce a ft.
300
1000 Miles
Twenty-one of 28 Antarctic consultative nations have
made no claims to Antarctic territory (although Russia
anti the united States have reserved the right to do so)
and they do not recognize the claims of the other
nations.
Bouvet Island ,
'' (NORWAY) PRINCE EDWARD ISLANDS
(SOUTH AFRICA)
•■’c :
Neumaver
(GERMANY)
Hi Novolazarevskava
...(RUSSIA)
aw
Mai trl
iifiDIA)
Syowa (JAPAri)
m~.y
BMoiodezhnaya
/ PRUSSIA)
f -mlcr by \\)
\\ loud A y''
area of
fceiiSargemei>l
Maud Land
x.V Queen
''A:;!
B Halley (U. A.
Belgrano 11
cddell Sea
It V MIIV II
9 (ARGEDTIfiA)
Pointe r N '' .
\\\\ Loral V.
/hong Shan(CHIPtA)|L
Progress (RUSSIA))
Bpavisf AUSTRALIA)
Ellsworth
Amundsen-Scott
L (u.s.)
(highest point ir. Antarctica. 48S?7 m)
Y''ostok
,{RUSS1A>
( Bentley Subglacial Trench
\\ itomssi pant in Antarctica -2540 m) ''
Cd Marie Bvrd
v ,v \\ M>
C-j Land it
A; ''-m
Concordia
(fRANCE AMD
B -ITALY)
AMcMurdo
scon B* Ails.)
(N.Z.)
C Victoria Land
Falkland islands
tisjas Malvinas) /
(administered bv U.K..
claimed bv AS.CE,\\!-flNA)
South Georgia and Hie
South Sandwich islands
(administered by U.K..
claimed bv ARGENTINA5)''
ARGENTINE
CLAIM
Orcadas
B (AROENTiNA)
BRITISH
CLAIM
/ Southern
Ocean
bCOtiXXS
SOUTH ORKNEY
ISLANDS
NORWEGIAN CLAIM
undefined limit
SOUTH
SHETL.p\\l
ISLANDS
CHILEAN
CLAIM
.. Y • iVlawson
•Ui,v toi’ASi!i'' (Australia)
Lana \\ \\ \\
0.,.-0 / AtnervkeS h<
ILES
crozm
French Southern
and Antarctic Lands
(FRANCE)
ILES
KERGUELEN
Heard island and
McDonald islands
(AUSTRALIA)
S a u tit
P a c i f I c
\\ O c e a n
| \\
Amundsen yjX^
i Mirnyv
T (RUSSIA)
f""T
1 cP t i ■
, stuickk’lsm
« O fee Skdi
: C € A it
X ,0 Case>'' ^
O ^AUSTRALIA) V
^ X ^
/ ^
) &
V
Argentina, Brazil, Chile. China, Fa ’and,
Russia, south Korea, Uruguay enchhuve
a station on King George island. y''Y
.Maiir
YJ Esperanza
;/ ;4-*> J « { \\Xx<
(ARQENTm
Arturo Plat
(Ciili.E)p
A)
mm Maramhio
.Bernardo ^ WROEMTinA)
O'' Higgins
(CHILE) I
(U .
\\ Crahdm
l\\Land
Peninsula p
X) ''?
(tJ.SVjYt. <T
\\ W" Verndds^y''
. , • (UKRAINE)
Antarctic ^ .
H ■.''l-M''-ien •'' ■"
la>. Shelf: ; ;
A Hy /
c-. > / ?. ■ : !{
Southern % ''p\\ sanMidiX
Ocean
(t).K.)|| \\X;* -
. > c\\
mis. ''
■ \\
Scott
''fev-f: Island
BALLENY -■
ISLANDS
tern
iacean
\\ Dumont d''Urville
:e>
FRENCH
CLAIM
''^A/o
CHATHAM ISLANDS
(HEW ZEALAND)
CLAIM
Campbell
Island
(NEW ZEALAND)
Macquarie Island
• t AUSTRALIA)
MEW
ZEALAND
* Christchurch
Wellington
180
AUCKLAND ISLANDS
y (NEW ZKALA''ND)
. * m . ''
* ^SNARES ISLANDS
€ (NEW ZEALAND)
f P'' f
■ Soulh Island
Tasmania
,iiiOl^rt
\\ u?-;
s> -«r «
— . Ma |
''"VjXr''
Adelaide
Melbourne
V
. '' , North Island
\\ ^Canberra
\\ AUSTRALIA
ip
Sydney!
818
REFERENCE MAPS','f12a6e9f6a79c07644e735cf6876e46bdd44bcc6225e981ba73fd57df8ac5373','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f037e07b49097f92eed0964c60ef992ed82d2aff503dce0d6dc863e07ffb9463',2009,'AG','Antigua and Barbuda','transnational-issues',107,'Disputes— international: Antarctic
Treaty freezes claims (see Antarctic
Treaty Summary in Government type
entry); Argentina, Australia, Chile,
France, NZ, Norway, and UK claim land
and maritime sectors (some overlapping)
for a large portion of the continent; the
US and many other states do not recog¬
nize these territorial claims and have
made no claims themselves (the US and
Russia reserve the right to do so); no
claims have been made in the sector
between 90 degrees west and 150 degrees
west
a®?
_
.
Background: The Siboney were the first to
inhabit the islands of Antigua and Barbuda
in 2400 B.C., but Arawak Indians popu¬
lated the islands when COLUMBUS
landed on his second voyage in 1493. Early
settlements by the Spanish and French
were succeeded by the English who formed
a colony in 1667. Slavery, established to
run the sugar plantations on Antigua, was
abolished in 1834. The islands became an
independent state within the British
Commonwealth of Nations in 1981.
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic
Ocean, east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48
W
25
THE CIA WORLD FACTBOOK
10 ’SCftKtd
to
1#'' \\
Codrington
Barbuda
WT
CcvLi/iVi- .
SAINT
JOHN’S .:Arj
•#
An&Cjft/eJ Boggy Bte®fc
Map references: Central America and
the Caribbean
Area:
total: 442.6 sq km (Antigua 280 sq km;
Barbuda 161 sq km)
land: 442.6 sq km
water: 0 sq km
note: includes Redonda, 1.6 sq km
Area — comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical maritime; little sea-
sonal temperature variation
Terrain: mostly lowdying limestone and
coral islands, with some higher volcanic
areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant cli¬
mate fosters tourism
Land use: arable land: 18.18%
permanent crops: 4.55%
other: 77.27% (2005)
Irrigated land: NA
Total renewable water resources: 0 1
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.005 cu
km/yr (60%/20%/20%)
per capita: 63 cu m/yr (1990)
Natural hazards: hurricanes and tropical
storms (July to October); periodic
droughts
Environment — current issues: water
management — a major concern because
of limited natural fresh water resources —
is further hampered by the clearing of
trees to increase crop production,
causing rainfall to run off quickly
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: Antigua has a deeply
indented shoreline with many natural
harbors and beaches; Barbuda has a large
western harbor
Population: 69,842 (July 2008 est.)
Age structure:
0-14 years: 26.9% (male 9,561/female
9,220)
15-64 years: 69.5% (male 24,467/female
24,076)
65 years and over: 3.6% (male 927/female
1,591) (2008 est.)
Median age:
total: 30.5 years
male: 30 years
female: 31.1 years (2008 est.)
Population growth rate: 0.508% (2008
est.)
Birth rate: 16.35 births/1,000 population
(2008 est.)
Death rate: 5.25 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -6.01 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.58 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 17.67 deaths/1,000 live births
male: 21.26 deaths/1,000 live births
female: 13.89 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 72.69 years
male: 70.28 years
female: 15.22 years (2008 est.)
Total fertility rate: 2.22 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black 91%, mixed 4.4%,
white 1.7%, other 2.9% (2001 census)
Religions: Anglican 25.7%, Seventh
Day Adventist 12.3%, Pentecostal
10.6%, Moravian 10.5%, Roman
Catholic 10.4%, Methodist 7.9%,
Baptist 4.9%, Church of God 4-5%,
other Christian 5.4%, other 2%, none or
unspecified 5.8% (2001 census)
Languages: English (official), local
dialects
Literacy:
definition: age 15 and over has completed
five or more years of schooling
total population: 85.8%
male: NA%
female: NA% (2003 est.)
Disputes — international: none
Illicit drugs: considered a minor trans-
shipment point for narcotics bound for
the US and Europe; more significant as
an offshore financial center
ARCTIC OCEAN
Background: The Arctic Ocean is the
smallest of the world’s five oceans (after
the Pacific Ocean, Atlantic Ocean,
Indian Ocean, and the recently delim-
ited Southern Ocean). The Northwest
Passage (US and Canada) and Northern
Sea Route (Norway and Russia) are two
important seasonal waterways. A sparse
network of air, ocean, river, and land
routes circumscribes the Arctic Ocean.
Location: body of water between Europe,
Asia, and North America, mostly north
of the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea,
Beaufort Sea, Chukchi Sea, East
Siberian Sea, Greenland Sea, Hudson
Bay, Hudson Strait, Kara Sea, Laptev
Sea, Northwest Passage, and other tribu-
tary water bodies
Area — comparative: slightly less than
1.5 times the size of the US
Coastline: 45,389 km
Climate: polar climate characterized by
persistent cold and relatively narrow
annual temperature ranges; winters char¬
acterized by continuous darkness, cold
and stable weather conditions, and clear
skies; summers characterized by contin¬
uous daylight, damp and foggy weather,
and weak cyclones with rain or snow
Terrain: central surface covered by a
perennial drifting polar icepack that, on
average, is about 3 meters thick,
although pressure ridges may be three
times that thickness; clockwise drift pat¬
tern in the Beaufort Gyral Stream, but
nearly straight-line movement from the
New Siberian Islands (Russia) to
Denmark Strait (between Greenland
and Iceland); the icepack is surrounded
by open seas during the summer, but
more than doubles in size during the
winter and extends to the encircling
landmasses; the ocean floor is about 50%
continental shelf (highest percentage of
any ocean) with the remainder a central
basin interrupted by three submarine
ridges (Alpha Cordillera, Nansen
Cordillera, and Lomonosov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel
aggregates, placer deposits, polymetallic
nodules, oil and gas fields, fish, marine
mammals (seals and whales)
Natural hazards: ice islands occasionally
break away from northern Ellesmere
Island; icebergs calved from glaciers in
western Greenland and extreme north¬
eastern Canada; permafrost in islands;
virtually ice locked from October to
June; ships subject to superstructure icing
from October to May
Environment— current issues: endan¬
gered marine species include walruses
and whales; fragile ecosystem slow to
change and slow to recover from disrup¬
tions or damage; thinning polar icepack
Geography — note: major chokepoint is
the southern Chukchi Sea (northern
access to the Pacific Ocean via the
Bering Strait); strategic location
between North America and Russia;
shortest marine link between the
extremes of eastern and western Russia;
floating research stations operated by the
US and Russia; maximum snow cover in
March or April about 20 to 50 centime¬
ters over the frozen ocean; snow cover
lasts about 10 months
AC
AG
ATG
028
ATG
•ag
south of 60 degrees south
latitude
14 34 N
90 44 W
17 38 N
61 48 W
16 55 N
62 19 W
17 06 N
61 51 W','06256e35d503411ff78d19e0136792c2cd7172e81e47370538d60e48c8250948','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48fec3bb9def0d124935899c2d4443f3123290c6fb0a6ad6919cda03e4bc015b',2009,'AR','Argentina','transnational-issues',110,'Disputes— international: some mar¬
itime disputes (see littoral states)
.
Disputes — international: Argentina
continues to assert its claims to the UK-
administered Falkland Islands (Islas
Malvinas) and South Georgia and the
South Sandwich Islands in its constitu¬
tion, forcibly occupying the Falklands in
1982, but in 1995 agreed no longer to seek
settlement by force; territorial claim in
Antarctica partially overlaps UK and
Chilean claims (see Antarctic disputes);
unruly region at convergence of
Argentina-Brazil-Paraguay borders is
locus of money laundering, smuggling,
arms and illegal narcotics trafficking, and
fundraising for extremist organizations;
uncontested dispute between Brazil and
Uruguay over Braziliera/Brasiliera Island
in the Quarai/Cuareim River leaves the
tripoint with Argentina in question; in
January 2007, ICJ provisionally ruled
Uruguay may begin construction of two
paper mills on the Uruguay River, which
forms the border with Argentina, while
the court examines further whether
Argentina has the legal right to stop such
construction with potential environ¬
mental implications to both countries;
the joint boundary commission, estab¬
lished by Chile and Argentina in 2001
has yet to map and demarcate the delim¬
ited boundary in the inhospitable Andean
Southern Ice Field (Campo de Hielo Sur)
Trafficking in persons: current situation:
Argentina is primarily a destination
country for women and children traf¬
ficked for sexual and labor exploitation
with most victims trafficked internally,
from rural to urban areas, for exploita¬
tion in prostitution; foreign women and
children trafficked for commercial sexual
exploitation come primarily from
Paraguay, but also from Bolivia, Brazil,
the Dominican Republic, Colombia, and
Chile; Bolivians are trafficked for forced
labor; Argentine women and girls are
also trafficked to neighboring countries
for sexual exploitation
32
A
_
■
AR
AR
ARG
032
ARG
.ar
34 36 S
58 27 W
35 00 S
63 00 W
48 00 S
61 00 W','b18df418a65d13e7bcb52c8fdabd7c73b25d0bf84e1d5095d55216683cc76aa3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eb5a924aa7a7faaeae6fa9da12ab51df747799500359a484097e9412309532a',2009,'AM','Armenia','transnational-issues',114,'tier rating: Tier 2 Watch List — Argentina
failed to show evidence of increasing
efforts to combat trafficking particularly
in the key area of prosecutions
Illicit drugs: used as a transshipment
country for cocaine headed for Europe;
some money-laundering activity, espe¬
cially in the Tri-Border Area; domestic
consumption of drugs in urban centers is
increasing
Disputes— international: Armenia sup¬
ports ethnic Armenian secessionists in
Nagorno-Karabakh and since the early
1990s, has militarily occupied 16% of
Azerbaijan — Organization for Security
and Cooperation in Europe (OSCE)
continues to mediate dispute; over
800,000 mostly ethnic Azerbaijanis were
driven from the occupied lands and
Armenia; about 230,000 ethnic
Armenians were driven from their
homes in Azerbaijan into Armenia;
Azerbaijan seeks transit route through
Armenia to connect to Naxcivan
exclave; border with Turkey remains
closed over Nagorno-Karabakh dispute;
ethnic Armenian groups in Javakheti
region of Georgia seek greater autonomy;
Armenians continue to emigrate, prima¬
rily to Russia, seeking employment
Refugees and internally displaced per¬
sons: refugees (country of origin): 113,295
(Azerbaijan)
IDEs: 8,400 (conflict with Azerbaijan
over Nagorno-Karabakh, majority have
returned home since 1994 ceasefire)
(2007)
Trafficking in persons: current situation:
Armenia is a major source and, to a lesser
extent, a transit and destination country
for women and girls trafficked for sexual
exploitation largely to the UAE and
Turkey; traffickers, many of them
women, route victims directly into Dubai
or through Moscow; profits derived from
the trafficking of Armenian victims
reportedly have increased
tier rating: Tier 2 Watch List — Armenia
has failed to show evidence of increasing
efforts, particularly in the areas of
enforcement, trafficking-related corrup¬
tion, and victim protection
Illicit drugs: illicit cultivation of small
amount of cannabis for domestic con¬
sumption; minor transit point for illicit
drugs — mostly opium and hashish —
moving from Southwest Asia to Russia
and to a lesser extent the rest of Europe
Background: Discovered and claimed for
Spain in 1499, Aruba was acquired by
the Dutch in 1636. The island’s economy
has been dominated by three main indus¬
tries. A 19th century gold rush was fol¬
lowed by prosperity brought on by the
opening in 1924 of an oil refinery. The
last decades of the 20th century saw a
boom in the tourism industry. Aruba
seceded from the Netherlands Antilles in
1986 and became a separate,
autonomous member of the Kingdom of
the Netherlands. Movement toward full
independence was halted at Aruba’s
request in 1990.
AM
AM
ARM
051
ARM
.am
40 00 N
45 00 E
Heard Island and McDonald
53 06 S
73 30 E
Islands
40 11 N
44 30 E','68d57abb3d9a72dee994ca91eb3843a455c50b69ca484c36e1c41acd1fdc7333','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13ba95e2f104f07a5318b30c81fb001bfc67e0922a74c31c383f68bd07afbc1f',2009,'AW','Aruba','transnational-issues',126,'Disputes— international: none
Illicit drugs: transit point for US- and
Europe-bound narcotics with some
accompanying money-laundering
activity; relatively high percentage of
population consumes cocaine
Background: These uninhabited islands
came under Australian authority in
1931; formal administration began two
years later. Ashmore Reef supports a rich
and diverse avian and marine habitat; in
1983, it became a National Nature
Reserve. Cartier Island, a former
bombing range, is now a marine reserve.
Location: Southeastern Asia, islands in
the Indian Ocean, midway between
northwestern Australia and Timor island
Geographic coordinates: 12 14 S, 123
05 E
Map references: Southeast Asia
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West,
Middle, and East Islets) and Cartier
Island
Area— comparative: about eight times
the size of The Mall in Washington, DC
38
ATLANTIC OCEAN
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: tropical
Terrain: low with sand and coral
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (all grass and sand) (2005)
Irrigated land: 0 sq km
Natural hazards: surrounded by shoals
and reefs that can pose maritime hazards
Environment— current issues: NA
Geography — note: Ashmore Reef
National Nature Reserve established in
August 1983
Disputes— international : some mar¬
itime disputes (see littoral states)
AA
AW
ABW
533
ABW
.aw
ISO includes with Australia
Ashmore and
AT
-
-
AUS
-
Cartier Islands
12 33 N
70 06 W
Atlantic Ocean
55 50 N
12 40 E','953f8f87c8e0c8f025db569e275c6f0919207d4e71e29b46ebe4859605578a3b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bb8e41cc0cd7dda76b23c07ca997a17f42a878ab6d498dfe87e1a2b8a532b47',2009,'AU','Australia','transnational-issues',128,'Background: Aboriginal settlers arrived
on the continent from Southeast Asia
about 40,000 years before the first
Europeans began exploration in the 17th
century. No formal territorial claims
were made until 1770, when Capt. James
COOK took possession in the name of
Great Britain. Six colonies were created
in the late 18th and 19th centuries; they
federated and became the Common¬
wealth of Australia in 1901. The new
country took advantage of its natural
resources to rapidly develop agricultural
and manufacturing industries and to
make a major contribution to the British
effort in World Wars I and II. In recent
decades, Australia has transformed itself
into an internationally competitive,
advanced market economy. It boasted
one of the OECD’s fastest growing
economies during the 1990s, a perform¬
ance due in large part to economic
reforms adopted in the 1980s. Long-term
concerns include climate-change issues
such as the depletion of the ozone layer
and more frequent droughts, and man¬
agement and conservation of coastal
areas, especially the Great Barrier Reef.
Geographic coordinates: 9 00 N, 168 00
E
Map references: Oceania
Area:
total: 181.3 sq km
land: 181.3 sq km
water: 0 sq km
note: the archipelago includes 11,673 sq
km of lagoon waters and includes the
atolls of Bikini, Enewetak, Kwajalein,
Majuro, Rongelap, and Utirik
Area — comparative: about the size of
Washington, DC
Land boundaries: 0 km
Coastline: 370.4 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; wet
season May to November; islands border
typhoon belt
Terrain: low coral limestone and sand
islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on
Likiep 10 m
Natural resources: coconut products,
marine products, deep seabed minerals
Land use:
arable land: 11.11%
permanent crops: 44.44%
other: 44.45% (2005)
Irrigated land: 0 sq km
Natural hazards: infrequent typhoons
Environment — current issues: inade¬
quate supplies of potable water; pollution
of Majuro lagoon from household waste
and discharges from fishing vessels
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
417
THE CIA WORLD FACTBOOK
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: the Marshall Islands
Bikini and Enewetak are former US
nuclear test sites; Kwajalein, the famous
World War II battleground, is used as a
US missile test range; island city of
Ebeye is the second largest settlement in
the Marshall Islands, after the capital of
Majuro, and one of the most densely
populated locations in the Pacific
Population: 63,174 (July 2008 est.)
Age structure:
0-14 years: 38.5% (male 12,404/female
11,946)
15-64 years: 58.6% (male 18,937/female
18,095)
65 years and over: 2.8% (male 869/female
923) (2008 est.)
Median age: total: 21 years
male: 21 years
female: 20.9 years (2008 est.)
Population growth rate: 2.142% (2008
est.)
Birth rate: 31.52 births/1,000 population
(2008 est.)
Death rate: 4.57 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: -5.52 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.94 male(s)/female
total population: 1.04 male(s)/female
(2008 est.)
infant mortality rate:
total: 26.36 deaths/1,000 live births
male: 29.58 deaths/1,000 live births
female: 22.98 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 70.9 years
male: 68.88 years
female: 73.03 years (2008 est.)
Total fertility rate: 3.68 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS — deaths: NA
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Protestant 54.8%, Assembly
of God 25.8%, Roman Catholic 8.4%,
Bukot nan Jesus 2.8%, Mormon 2.1%,
other Christian 3.6%, other 1%, none
1.5% (1999 census)
Languages: Marshallese (official) 98.2%,
other languages 1.8% (1999 census)
note: English (official), widely spoken as
a second language
Literacy: definition: age 15 and over can
read and write
total population: 93.7%
male: 93.6%
female: 93.7% (1999)
Disputes— international: none
457
NAVASSA ISLAND
Background: This uninhabited island
was claimed by the US in 1857 for its
guano. Mining took place between 1865
and 1898. The lighthouse, built in 1917,
was shut down in 1996 and administra-
tion of Navassa Island transferred from
the Coast Guard to the Department of
the Interior. A 1998 scientific expedition
to the island described it as a unique pre¬
serve of Caribbean biodiversity; the fol¬
lowing year it became a National
Wildlife Refuge and annual scientific
expeditions have continued.
Disputes— international: claimed by
Haiti, source of subsistence fishing
AS
AU
AUS
036
AUS
.au
ISO includes Ashmore and
10 12 S
142 16 E
27 28 S
153 02 E
Pacific Ocean
57 00 N
160 00 W
Atlantic Ocean
51 18 N
3 30 W
35 17 S
149 08 E
23 15 S
155 32 E
Russia
42 00 N
45 00 E
10 25 S
105 39 E
31 30 S
159 00 E
54 36 S
158 54 E
37 49 S
144 58 E
31 56 S
115 50 E
Taiwan
23 30 N
119 30 E
33 53 S
151 13 E
43 00 S
147 00 E
Pacific Ocean
50 00 N
141 00 E
Russia
76 00 N
104 00 E
820
REFERENCE MAPS
821
THE CIA WORLD FACTBOOK
EUROPE
0 500 Miles
Boundary r*prcscmatton iss not necessarily eutheniratM*.
Names In Vietnam are shown without diacritical marks.
V *Porj Hedland GREAT SANDY
Karratha >
m-
DESERT
—
Mount isa*
W1
829
<*Xx*?ca; -ms •<}:>: so
THE CIA WORLD FACTBOOK
830
REFERENCE MAPS
Prudhoe \\\\
Bay \\
Inti v Ik
RUSSIA
Anadyr
Fairbanks','aebf5226cd29a3a474302645d297e455286b5b455a1d81a782357c2cf2914687','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ec2813a7d36b0822b815209e5465e4e6553b2570ec3bf63d284fe26d284aa84',2009,'AT','Austria','transnational-issues',140,'Disputes— international: in 2006, Aus¬
trian public protests for the Czech Republic
to close the Temelin nuclear power plant
resulted in a parliamentary motion threat¬
ening international legal action
Illicit drugs: transshipment point for
Southwest Asian heroin and South
American cocaine destined for Western
Europe; increasing consumption of
European-produced synthetic drugs
population — was briefly independent
from 1918 to 1920; it regained its inde-
Background: Azerbaijan a nation with pendence after the collapse of the Soviet
a majority-Turkic and majority-Muslim Union in 1991. Despite a 1994 cease¬
fire, Azerbaijan has yet to resolve its con¬
flict with Armenia over the Azerbaijani
Nagorno-Karabakh enclave (largely
Armenian populated). Azerbaijan has
46
AU
AT
AUT
040
AUT
.at
Cartier Islands, Coral Sea
Islands
47 20 N
13 20 E
Ethiopia, Somalia
7 00 N
46 00 E
47 48 N
13 02 E
48 12 N
16 22 E
Laos
17 58 N
102 36 E','b3305a59955157661e4ecbc501ee07b74520a602e88450b6116dd30cdfbc2082','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948f542787744d3b743eff22bf85499e4ef7f7424aaf4b3d231021f54ae50d33',2009,'AZ','Azerbaijan','transnational-issues',141,'lost 16% of its territory and must support
some 600,000 internally displaced per¬
sons as a result of the conflict.
Corruption is ubiquitous, and the gov¬
ernment has been accused of authoritar¬
ianism. Although the poverty rate has
been reduced in recent years, the
promise of widespread wealth from
development of Azerbaijan’s energy
sector remains largely unfulfilled.
Disputes— international: Armenia sup¬
ports ethnic Armenian secessionists in
Nagorno-Karabakh and since the early
1990s has militarily occupied 16% of
Azerbaijan; over 800,000 mostly ethnic
Azerbaijanis were driven from the occu¬
pied lands and Armenia; about 230,000
ethnic Armenians were driven from
their homes in Azerbaijan into Armenia;
Azerbaijan seeks transit route through
Armenia to connect to Naxcivan
exclave; Organization for Security and
Cooperation in Europe (OSCE) con¬
tinues to mediate dispute; Azerbaijan,
Kazakhstan, and Russia have ratified
Caspian seabed delimitation treaties
based on equidistance, while Iran con¬
tinues to insist on an even one-fifth allo¬
cation and challenges Azerbaijan’s
hydrocarbon exploration in disputed
waters; bilateral talks continue with
Turkmenistan on dividing the seabed
and contested oilfields in the middle of
the Caspian; Azerbaijan and Georgia
continue to discuss the alignment of
their boundary at certain crossing areas
Refugees and internally displaced per¬
sons: refugees (country of origin): 2,400
(Russia)
IDPs: 580,000-690,000 (conflict with
Armenia over Nagorno-Karabakh)
(2007)
Illicit drugs: limited illicit cultivation of
cannabis and opium poppy, mostly for
CIS consumption; small government
eradication program; transit point for
Southwest Asian opiates bound for
Russia and to a lesser extent the rest of
Europe
50
Background: Lucayan Indians inhabited
the islands when Christopher
COLUMBUS first set foot in the New
World on San Salvador in 1492. British
settlement of the islands began in 1647;
the islands became a colony in 1783.
Since attaining independence from the
UK in 1973, The Bahamas have pros-
pered through tourism and international
banking and investment management.
Because of its geography, the country is a
major transshipment point for illegal
drugs, particularly shipments to the US
and Europe, and its territory is used for
smuggling illegal migrants into the US.
AJ
AZ
AZE
031
AZE
.az
Bahamas, The
BF
BS
BHS
044
BHS
.bs
40 30 N
47 30 E
40 23 N
49 51 E
Pacific Ocean
7 35 N
117 00 E
40 00 N
46 40 E
39 20 N
45 20 E','68a4ea61af1f02b2d40031e830d9b2d710c337377e8c253b9dd1261befe7caea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07fcf0e3acc21e0e8681f9bac4840fab1f56c416230f2e08ae7ec4691efbbdde',2009,'BH','Bahrain','transnational-issues',150,'Disputes — international: disagrees with
the US on the alignment of a potential
maritime boundary; continues to mon¬
itor and interdict drug dealers and
Haitian refugees in Bahamian waters
Illicit drugs: transshipment point for
cocaine and marijuana bound for US and
Europe; offshore financial center
’ - - "A2
■
_
y&:. v;vc/
A/kv..,
• --S’.-;,:
- - ;
_ _
‘mm :
mmA
>A \\
.. w
7
1
wvv
iMffi
m
Nzzm
MANAMA -WMoljarraq
Jdd
Madmat : *S«ah
isS
Ar Rita1 *
ash Sharqi
AwSli
A
Ouktw*
X r v ;
''V ; Bsfmtm
■
gg f/ 1
SAD Ol
mm\\h
HAWAR
ISLANDS
■ ''
? S lOlvn SAJAft
6 5 *0 fw
Disputes — international: none
Trafficking in persons: current situation:
Bahrain is a destination country for men
and women from South and Southeast
Asia who migrate willingly to work as
laborers or domestic servants, but may be
subjected to conditions of involuntary
servitude when faced with exorbitant
recruitment and transportation fees,
withholding of their passports, restric-
tions on their movement, non-payment
of wages, and physical or sexual abuse;
women from Eastern Europe, Central
Asia, Morocco, and Thailand are also
trafficked to Bahrain for the purpose of
commercial sexual exploitation or forced
labor
tier rating: Tier 3 — Bahrain made no dis-
cernable progress in preventing traf¬
ficking in 2006; the government failed to
enact a comprehensive anti-trafficking
law and did not report any prosecutions
or convictions for trafficking offenses,
despite reports of a substantial problem
of involutary servitude and trafficking for
commercial sexual exploitation
BA
BH
BHR
048
BHR
.bh
ISO includes with the US
Minor Outlying Islands
Baker Island
FQ
-
-
UMI
-
26 00 N
50 33 E
7 00 N
81 00 E
Russia (Big Diomede), United
65 47 N
169 00 W
States (Little Diomede)
25 40 N
50 47 E
26 13 N
50 35 E','9b9d0404514c845e429ada693ba9f1368ed24f3cd45dad25432739a89cad455e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51a2968ea20ec94631945f009e79f72e4c9dd4fe028fd0ffbfd82a0069305a37',2009,'BE','Belgium','transnational-issues',170,'Disputes — international: as of January
2007, ground demarcations of the
boundaries with Latvia and Lithuania
were complete and mapped with final
ratification documentation in prepara¬
tion; 1997 boundary delimitation treaty
with Ukraine remains unratified over
unresolved financial claims, preventing
demarcation and diminishing border
security
Illicit drugs: limited cultivation of
opium poppy and cannabis, mostly for
the domestic market; transshipment
point for illicit drugs to and via Russia,
and to the Baltics and Western Europe; a
small and lightly regulated financial
center; new anti-money-laundering leg¬
islation does not meet international
standards; few investigations or prosecu¬
tions of money-laundering activities
BE
BE
BEL
056
BEL
.be
51 13 N
4 25 E
Macau
22 10N
113 33 E
50 50 N
4 00 E
50 50 N
4 20 E
50 26 N
6 02 E','599224e8740f04daaa93a0bcfefa36f7fa4e4f71d2f11b6c4fbf6a6de48c15e7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('260b5fe276f32fd2707c5b5db0cc559a901f55cf7d25cbd251da46a3f748748f',2009,'FR','France','transnational-issues',175,'Disputes— international: none
Illicit drugs: growing producer of syn¬
thetic drugs and cannabis; transit point
for US-bound ecstasy; source of precursor
chemicals for South American cocaine
processors; transshipment point for
cocaine, heroin, hashish, and marijuana
entering Western Europe; despite a
strengthening of legislation, the country
remains vulnerable to money laundering
related to narcotics, automobiles,
alcohol, and tobacco; significant
domestic consumption of ecstasy
68
Background: Belize was the site of sev-
eral Mayan city states until their decline
at the end of the first millennium A.D.
The British and Spanish disputed the
region in the 17 th and 18th centuries; it
formally became the colony of British
Honduras in 1854. Territorial disputes
between the UK and Guatemala delayed
the independence of Belize until 1981.
Guatemala refused to recognize the new
nation until 1992. Tourism has become
the mainstay of the economy. Current
concerns include an unsustainable for¬
eign debt, high unemployment, growing
involvement in the South American
drug trade, growing urban crime, and
increasing incidences of HIV/AIDS.
Disputes — international: various groups
in Finland advocate restoration of
Karelia and other areas ceded to the
Soviet Union, but the Finnish
Government asserts no territorial
demands
Disputes — international: none
FR
FR
France, Metropolitan
-
FX
ISO 3166
STANAG-
1059
Internet
FJI
242
FJI
•fi
FIN
246
FIN
.fi
FRA
250
FRA
.fr
FXX
249
.fx
48 30 N
7 20 E
Pacific Ocean
28 40 N
129 30 E
44 50 N
0 34 W
Brunei, Indonesia, Malaysia
0 30 N
114 00 E
42 00 N
9 00 E
48 42 N
6 11 E
43 18 N
5 23 E
48 52 N
2 20 E
46 00 N
2 00 E
ITALY Sari
Rome, *’°‘,l
Ponca
Delgado
Cnttekn |
.Jsuwbul','53eeea91436bd97b9fad0568f21d2f4c67b1283a60b218f980488830e37ad268','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950f7b78eca956bf7d7bfe47d607f6932ce55886f144cc4ee877de3116c70531',2009,'BJ','Benin','transnational-issues',182,'Disputes — international: annual minis¬
terial meetings under the OAS-initiated
Agreement on the Framework for
Negotiations and Confidence Building
Measures continue to address
Guatemalan land and maritime claims in
Belize and Caribbean Sea; the Line of
Adjacency created under the 2002
Differendum serves in lieu of the con¬
tiguous international boundary to con¬
trol squatting in the sparsely inhabited
rain forests of Belize’s border region;
Honduras claims Belizean-administered
Sapodilla Cays in its constitution but
agreed to a joint ecological park under
the Differendum
Illicit drugs: transshipment point for
cocaine; small-scale illicit producer of
cannabis, primarily for local consump¬
tion; money-laundering activity related
to narcotics trafficking and offshore
sector
Disputes— international: two villages
remain in dispute along the border with
Burkina Faso; Benin accused Burkina
Faso of moving boundary pillars; much of
Benin-Niger boundary, including tri¬
point with Nigeria, remains undemar¬
cated; in 2005, Nigeria ceded thirteen
villages to Benin, but border relations
remain strained by rival gang clashes;
Benin and Togo announced plans in
2006 to construct a joint hydroelectric
dam on the Mona River at the southern
end of the border
Refugees and internally displaced per¬
sons: refugees (country of origin): 9,444
(Togo) (2007)
Illicit drugs: transshipment point used
by Nigerian traffickers for narcotics des¬
tined for Western Europe; vulnerable to
money laundering due to poorly enforced
financial regulations
BN
BJ
BEN
204
BEN
•bj
.bm
6 21 N
2 26 E
9 30 N
2 15 E
6 29 N
2 37 E','09b83b9ef03a48ec5a76e8af0048dd310f0809454794482a3d0b9bd6e84bb8d1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f18f8dc050cdde95f4a49ced3336330daa7ff13c759656378d6269dcaee9642b',2009,'BT','Bhutan','transnational-issues',194,'_ _
Disputes — international: none
Background: In 1865, Britain and
Bhutan signed the Treaty of Sinchulu,
under which Bhutan would receive an
annual subsidy in exchange for ceding
some border land to British India. Under
British influence, a monarchy was set up
in 1907; three years later, a treaty was
signed whereby the British agreed not to
interfere in Bhutanese internal affairs
and Bhutan allowed Britain to direct its
foreign affairs. This role was assumed by
independent India after 1947. Two years
later, a formal Indo- Bhutanese accord
returned the areas of Bhutan annexed by
the British, formalized the annual subsi¬
dies the country received, and defined
India’s responsibilities in defense and for¬
eign relations. A refugee issue of over
100,000 Bhutanese in Nepal remains
unresolved; 90% of the refugees are
housed in seven United Nations Office
of the High Commissioner for Refugees
(UNHCR) camps. In March 2005, King
Jigme Singye WANGCHUCK unveiled
the government’s draft constitution —
which would introduce major demo¬
cratic reforms — and pledged to hold a
national referendum for its approval. In
December 2006, the King abdicated the
throne to his son, Jigme Khesar Namgyel
WANGCHUCK, in order to give him
experience as head of state before the
democratic transition. In early 2007,
India and Bhutan renegotiated their
treaty to allow Bhutan greater autonomy
in conducting its foreign policy, although
Thimphu continues to coordinate policy
decisions in this area with New Delhi. In
July 2007, seven ministers of Bhutan’s
ten- member cabinet resigned to join the
political process, leaving the remaining
cabinet to act as a caretaker regime until
a new government assumes power fol¬
lowing parliamentary elections. Bhutan
will complete its transition to full
democracy in 2008, when its first fully
democratic elections to a new parlia¬
ment — expected to be completed by
March 2008 — and a concomitant refer¬
endum on the draft constitution will take
place.
Disputes— international: over 100,000
Bhutanese Lhotshampas (Hindus) have
been confined in seven UN Office of the
High Commissioner for Refugees camps
since 1990; Bhutan cooperates with
India to expel Indian Nagaland sepa¬
ratists; lacking any treaty describing the
boundary, Bhutan and China continue
negotiations to establish a boundary
alignment to resolve substantial carto¬
graphic discrepancies, the largest of
which lies in Bhutan’s northwest
79
BT
BT
BTN
064
BTN
.bt
777
THE CIA WORLD FACTBOOK
STANA6-
Entity
FIPS TO
ISO 3166
1059
Internet
Comment
Bolivia
BL
BO
BOL
068
BOL
.bo
Bosnia and
BK
BA
BIH
070
BIH
.ba
Herzegovina
27 30 N
90 30 E
27 28 N
89 39 E','8f44828833268809ab9fcce8addd18ecfffe4bd414e9028128ff498e0b2a785f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('150f9be6676a2808e617b38be584af5b1ddbffe3a114aaf14add79f9897591b4',2009,'BR','Brazil','transnational-issues',200,'A? *LAPAZ
, ^.Cochabamba
■fv ''.°''f 0 Saras-
t*%''. &»% c“
I So * *Potosf
Puerto
Aguirre,
A-iC ,.«t,r<A
Disputes — international: unruly region
at convergence of Argentina-Brazil-
Paraguay borders is locus of money laun-
dering, smuggling, arms and illegal
narcotics trafficking, and fundraising for
extremist organizations; uncontested dis¬
pute with Uruguay over certain islands in
the Quarai/Cuareim and Invernada
boundary streams and the resulting tri-
point with Argentina
Illicit drugs: illicit producer of cannabis;
trace amounts of coca cultivation in the
Amazon region, used for domestic con¬
sumption; government has a large-scale
eradication program to control cannabis;
important transshipment country for
Bolivian, Colombian, and Peruvian
cocaine headed for Europe; also used by
traffickers as a way station for narcotics
air transshipments between Peru and
Colombia; upsurge in drug-related vio¬
lence and weapons smuggling; important
market for Colombian, Bolivian, and
Peruvian cocaine; illicit narcotics pro¬
ceeds earned in Brazil are often laun¬
dered through the financial system;
significant illicit financial activity in the
Tri-Border Area
perns
mmm
ISLANDS
t « © f A M
Ne/ssp, s
f ct •- S i
. .V
mmm
ISLANDS
THREE
BROTHERS
!!!!!§
Hfepi
tetemt
CHAGOS
ARCHIPELAGO
Background: Established as a territory of
the UK in 1965, a number of the British
Indian Ocean Territory (BIOT) islands
were transferred to the Seychelles when it
attained independence in 1976.
Subsequently, BIOT has consisted only of
the six main island groups comprising the
Chagos Archipelago. The largest and
most southerly of the islands, Diego
Garcia, contains a joint UK-US naval
support facility. All of the remaining
islands are uninhabited. Former agricul¬
tural workers, earlier residents in the
islands, were relocated primarily to
Mauritius but also to the Seychelles,
between 1967 and 1973. In 2000, a
British High Court ruling invalidated the
local immigration order that had excluded
them from the archipelago, but upheld
the special military status of Diego Garcia.
Location: archipelago in the Indian
Ocean, south of India, about halfway
between Africa and Indonesia
Geographic coordinates: 6 00 S, 71 30
E; note — Diego Garcia 7 20 S, 72 25 E
Map references: Political Map of the
World
Area:
total: 54,400 sq km
land: 60 sq km; Diego Garcia 44 sq km
water: 54,340 sq km
note: includes the entire Chagos
Archipelago of 55 islands
Area — comparative: land area is about
0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical marine; hot, humid,
moderated by trade winds
Terrain: flat and low (most areas do not
exceed two meters in elevation)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego
Garcia 15 m
Natural resources: coconuts, fish, sugar¬
cane
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Geography — note: archipelago of 55
islands; Diego Garcia, largest and south¬
ernmost island, occupies strategic loca¬
tion in central Indian Ocean; island is
site of joint US-UK military facility
Disputes — international: none
Illicit drugs: transshipment point for
South American narcotics destined for
the US and Europe; large offshore finan¬
cial center makes it vulnerable to money
laundering
BRUNEI
influence peaked between the 15 th and
17th centuries when its control extended
over coastal areas of northwest Borneo
and the southern Philippines. Brunei
subsequently entered a period of decline
brought on by internal strife over royal
succession, colonial expansion of
European powers, and piracy. In 1888,
Brunei became a British protectorate;
independence was achieved in 1984-
The same family has ruled Brunei for
over six centuries. Brunei benefits from
extensive petroleum and natural gas
fields, the source of one of the highest
per capita GDPs in Asia.
BR
BR
BRA
076
BRA
.br
British Indian
IO
IO
IOT
086
IOT
.io
Ocean Territory
British Virgin Islands
VI
VG
VGB
092
VGB
•vg
Brunei
BX
BN
BRN
096
BRN
.bn
15 47 S
47 55 W
3 51 S
32 25 W
20 30 S
28 51 W
22 55 S
43 17 W
3 51 S
33 49 W
0 23 N
29 23 W
Russia
59 55 N
30 15 E
Virgin Islands
18 21 N
64 55 W
Atlantic Ocean
13 30 N
61 00 W
Reunion
20 52 S
55 28 E
23 35 S
46 43 W
0 23 N
29 23 W
Cape Verde
15 05 N
23 40 W
20 31 S
29 20 W
i Natal
M Recife
■Mace id
''CUSCO:-:
Arequipa''a
\\ • |.FrHnld«id \\f,
La Paz x '' X ''XX
* .BOLIVIA [
ft CocWifelrtha-,’ *mtnu Cri|z
MAID (JMOSSO
PLATEAU
Ctnaha
Arica*
Iquique!
Antofagasta
\\
Suck
%
•mm
Sjainpei
Grande
BRAZILIAN
/ Brasilia^ ,:X , |
Goiania.
HIGH LA N D S
:
.. k
mmmKm.
Salvador','ae3f27f77aaa14b00e578aaf95aa28a234214f8e8949006c8982640b57898582','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f473d7354d7b9b572fc70d8da67065922c4d8a2429f3079bd6f6d728cc02fd0d',2009,'BA','Bosnia and Herzegovina','transnational-issues',209,'Disputes— international: Bosnia and
Herzegovina and Serbia have delimited
most of their boundary, but sections
along the Drina River remain in dispute;
discussions continue with Croatia on
several small disputed sections of the
boundary related to maritime access that
hinder final ratification of the 1999
border agreement
Refugees and internally displaced per¬
sons: refugees (country of origin): 7,269
(Croatia)
IDPs: 131,600 (Bosnian Croats, Serbs,
and Muslims displaced in 1992-95 war)
(2007)
Illicit drugs: increasingly a transit point
for heroin being trafficked to Western
Europe; minor transit point for mari¬
juana; remains highly vulnerable to
money-laundering activity given a pri¬
marily cash-based and unregulated
economy, weak law enforcement, and
instances of corruption
86
44 00 N
18 00 E
44 00 N
18 00 E
Atlantic Ocean
41 00 N
29 00 E
Atlantic Ocean
63 00 N
20 00 E
44 00 N
18 00 E
43 52 N
18 25 E','eb09586345a9444ab71d8694a91eff17fb64bfa68f03b837f6d037a8540a5616','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea8f310de654d43cb39f3e274aa3b46cae9efd1664922a3438d28b0aeb70266',2009,'BV','Bouvet Island','transnational-issues',216,'Disputes— international: the alignment
of the boundary with Namibia in the
Kwando/Linyanti/Chobe River,
including the Situngu marshlands, was
resolved amicably in 2003; concerns from
international experts and local popula¬
tions over the ecology of the Okavango
Delta in Botswana and human displace¬
ment scuttled Namibian plans to con¬
struct a hydroelectric dam at Popavalle
(Popa Falls) along the Angola-Namibia
border; Botswana has built electric fences
to stem the thousands of Zimbabweans
who flee to find work and escape political
persecution; Namibia has long supported,
and in 2004 Zimbabwe dropped objec¬
tions to, plans between Botswana and
Zambia to build a bridge over the
Zambezi River, thereby de facto recog¬
nizing the short, but not clearly delim¬
ited, Botswana-Zambia boundary
Disputes— international: none
Background: Following three centuries
under the rule of Portugal, Brazil became
an independent nation in 1822 and a
republic in 1889. By far the largest and
most populous country in South
America, Brazil overcame more than half
a century of military intervention in the
governance of the country when in 1985
the military regime peacefully ceded
power to civilian rulers. Brazil continues
to pursue industrial and agricultural
growth and development of its interior.
Exploiting vast natural resources and a
large labor pool, it is today South
America’s leading economic power and a
regional leader. Highly unequal income
distribution and crime remain pressing
problems.
BV
BV
BVT
074
BVT
.bv','18c282a5f32ad2740f235bf3da6debf3c33e605a3f7bc8c5481105a38f044c58','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6089ad3b95543c68fe3ceb546d28eb9903f3fbd2380aef0fef97ed46b3b52aad',2009,'BF','Burkina Faso','transnational-issues',244,'Disputes — international: two villages
remain in dispute along the border with
Benin; Benin accuses Burkina Faso of
moving boundary pillars; in recent years
citizens and rogue security forces rob and
harass local populations on both sides of
the poorly-defined Burkina Faso-Niger
border; despite the presence of over 9,000
UN forces (UNOCI) in Cote d’Ivoire
since 2004, ethnic conflict continues to
spread into neighboring states who can
no longer send their migrant workers to
work in Ivorian cocoa plantations
BURMA
Background: Britain conquered Burma
over a period of 62 years (1824-1886)
and incorporated it into its Indian
Empire. Burma was administered as a
province of India until 1937 when it
became a separate, self-governing
colony; independence from the
Commonwealth was attained in 1948.
Gen. NE WIN dominated the govern¬
ment from 1962 to 1988, first as military
ruler, then as self-appointed president,
and later as political kingpin. Despite
multiparty legislative elections in 1990
that resulted in the main opposition
party — the National League for
Democracy (NLD) — winning a landslide
victory, the ruling junta refused to hand
over power. NLD leader and Nobel
Peace Prize recipient AUNG SAN SUU
KYI, who was under house arrest from
1989 to 1995 and 2000 to 2002, was
imprisoned in May 2003 and subse¬
quently transferred to house arrest. After
Burma’s ruling junta in August 2007
unexpectedly increased fuel prices, tens
of thousands of Burmese marched in
protest, led by prodemocracy activists
and Buddhist monks. In late September
2007, the government brutally sup¬
pressed the protests, killing at least 13
people and arresting thousands for par¬
ticipating in the demonstrations. Since
then, the regime has continued to raid
homes and monasteries and arrest per¬
sons suspected of participating in the
pro-democracy protests. The junta
appointed Labor Minister AUNG KYI in
October 2007 as liaison to AUNG SAN
SUU KYI, who remains under house
arrest and virtually incommunicado with
her party and supporters.
Disputes — international: over half of
Burma’s population consists of diverse
ethnic groups who have substantial num¬
bers of kin in neighboring countries;
Thailand must deal with Karen and
other ethnic rebels, illegal cross-border
activities, Karen and other refugees, and
asylum seekers from Burma; Thailand is
studying the feasibility of jointly con¬
structing the Hatgyi Dam on the
Salween River near the border with
Burma; in 2004, international environ-
109
THE CIA WORLD FACTBOOK
mentalist pressure prompted China to
halt construction of 13 dams on the
Salween River which flows through
China, Burma, and Thailand; India seeks
cooperation from Burma to keep Indian
Nagaland separatists, such as the United
Liberation Front of Assam, from hiding
in remote Burmese Uplands; Burmese
Rohingya Muslim refugees reside in two
camps in Bangladesh
Refugees and internally displaced per¬
sons: IDPs: 503,000 (government offen¬
sives against ethnic insurgent groups
near the eastern borders; most IDPs are
ethnic Karen, Karenni, Shan, Tavoyan,
and Mon) (2007)
Trafficking in persons: current situation:
Burma is a source country for men,
women, and children trafficked to East
and Southeast Asia for sexual exploita¬
tion, domestic service, and forced com¬
mercial labor; a significant number of
victims are economic migrants who wind
up in forced or bonded labor and forced
prostitution; to a lesser extent, Burma is
a country of transit and destination for
women trafficked from China for sexual
exploitation; internal trafficking of per¬
sons occurs primarily for labor in indus¬
trial zones and agricultural estates;
internal trafficking of women and girls
for sexual exploitation occurs from vil¬
lages to urban centers and other areas;
the military junta’s economic misman¬
agement, human rights abuses, and
policy of using forced labor are driving
factors behind Burma’s large trafficking
problem
tier rating: Tier 3 — Burma does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so
Illicit drugs: remains world’s second
largest producer of illicit opium with an
estimated production in 2005 of 380
metric tons, up 13% from 2004 and cul¬
tivation in 2005 was 40,000 hectares, a
10% increase from 2004; the decline in
opium production in the United Wa
State Army’s areas of greatest control was
more than offset by increases in south
and east Shan state; lack of government
will to take on major narcotrafficking
groups and lack of serious commitment
against money laundering continues to
hinder the overall antidrug effort; major
source of methamphetamine and heroin
for regional consumption; currently
under Financial Action Task Force coun¬
termeasures due to continued failure to
address its inadequate money-laundering
controls (2005)
uv
BF
BFA
854
BFA
.bf
Burma
BM
MM
MMR
104
MMR
.mm
ISO uses the name Myanmar
12 22 N
1 31 W
13 00 N
2 00 W
Kazakhstan, Russia
60 00 N
60 00 E','73e5b5d28a00980b93b9d751f3f1e29cb593fed274e296506b34139556a84f4a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('116fe6ac0ea82c02f385d02cb66765fc0b013119b0d8536b64f25c54fe3830d0',2009,'BI','Burundi','transnational-issues',246,'‘Cibitoke
Bubanza
BUJUMBURA
TANZANIA
Bururi
Background: Burundi’s first democrati¬
cally elected president was assassinated
in October 1993 after only 100 days in
office, triggering widespread ethnic vio¬
lence between Hutu and Tutsi factions.
More than 200,000 Burundians perished
during the conflict that spanned almost a
dozen years. Hundreds of thousands of
Burundians were internally displaced or
became refugees in neighboring coun¬
tries. An internationally brokered power¬
sharing agreement between the
Tutsi-dominated government and the
Hutu rebels in 2003 paved the way for a
transition process that led to an inte¬
grated defense force, established a new
constitution in 2005, and elected a
majority Hutu government in 2005. The
new government, led by President Pierre
NKURUNZIZA, signed a South African
brokered ceasefire with the country’s last
rebel group in September of 2006 but
still faces many challenges.
BY
BI
BDI
108
BDI
.bi
3 23 S
29 22 E
Romania, Ukraine
48 00 N
26 00 E
3 30 S
30 00 E
China, Russia
48 28 N
135 02 E','0ea701ae73f35b81dd98a1c3eb2f9e95392cb53185b08c4ae3cde1fb9cfddc5f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84af7abb5153d7038ab5efcce22b679b25062d6b5c8442e4e72dbf4f457f11c9',2009,'CM','Cameroon','transnational-issues',259,'Disputes— international: Southeast
Asian states must maintain border sur¬
veillance to check the spread of avian
flu; Cambodia and Thailand dispute sec¬
tions of boundary with missing boundary
markers and claims of Thai encroach¬
ments into Cambodian territory; mar¬
itime boundary with Vietnam is
hampered by unresolved dispute over
sovereignty of offshore islands;
Cambodia accuses Thailand of
obstructing access to Preah Vihear
temple ruins awarded to Cambodia by
ICJ decision in 1962
Trafficking in persons: current situation:
Cambodia is a source, destination, and
transit country for men, women, and
children trafficked for the purposes of
sexual exploitation and forced labor; a
significant number of women and chil¬
dren are trafficked to Thailand and
Malaysia for commercial sexual exploita¬
tion and forced labor; men are trafficked
primarily to Thailand for forced labor in
the construction and agricultural sectors,
particularly the fishing industry, while
women and girls are trafficked for factory
and domestic work; children are traf¬
ficked to Vietnam and Thailand for the
purpose of forced begging; Cambodia is a
transit and destination point for women
from Vietnam trafficked for sexual
exploitation; trafficking for sexual
exploitation also occurs within
Cambodia’s borders, from rural areas to
the cities
tier rating: Tier 2 Watch List — Cambodia
does not fully comply with the minimum
standards for the elimination of traf¬
ficking; however, it is committed to
making significant efforts to sustain
progress over the coming year
Illicit drugs: narcotics-related corrup¬
tion reportedly involving some in the
government, military, and police; limited
methamphetamine production; vulner¬
able to money laundering due to its cash-
based economy and porous borders
Background: The former French
Cameroon and part of British Cameroon
merged in 1961 to form the present
country. Cameroon has generally
enjoyed stability, which has permitted
the development of agriculture, roads,
and railways, as well as a petroleum
industry. Despite a slow movement
toward democratic reform, political
power remains firmly in the hands of
President Paul BIYA.
Disputes— international: in 2002, ICJ
ruled on an equidistance settlement of
Cameroon-Equatorial Guinea-N igeria
maritime boundary in the Gulf of
Guinea, but a dispute between
Equatorial Guinea and Cameroon over
an island at the mouth of the Ntem
River and imprecisely defined maritime
coordinates in the ICJ decision delay
final delimitation; UN urges Equatorial
Guinea and Gabon to resolve the sover¬
eignty dispute over Gabon-occupied
Mbane and lesser islands and to create a
maritime boundary in the hydrocarbon-
rich Corisco Bay
Trafficking in persons: current situation:
Equatorial Guinea is mainly a destina¬
tion country for children trafficked for
forced labor, involuntary domestic servi¬
tude, and commercial sexual exploita¬
tion from surrounding countries —
primarily Benin, Nigeria, Gabon, and
Cameroon; victims work in the agricul¬
tural and commercial sectors of Malabo
and Bata, where demand is high due to a
booming oil sector and a flourishing
expatriate business community; children
work as farmhands, street vendors, or
household servants; girls are trafficked
for commercial sexual exploitation
tier rating: Tier 3 — failed to demonstrate
the political commitment to address its
human trafficking problem; despite
efforts to raise awareness of trafficking
problems, in 2006 the government failed
to investigate and prosecute traffickers or
protect victims
Background: Eritrea was awarded to
Ethiopia in 1952 as part of a federation.
Ethiopia’s annexation of Eritrea as a
province 10 years later sparked a 30-year
struggle for independence that ended in
1991 with Eritrean rebels defeating gov¬
ernmental forces; independence was over¬
whelmingly approved in a 1993
referendum. A two-and-a-half-year border
war with Ethiopia that erupted in 1998
ended under UN auspices in December
2000. Eritrea currently hosts a UN peace¬
keeping operation that is monitoring a 25
km-wide Temporary Security Zone (TSZ)
on the border with Ethiopia. An interna¬
tional commission, organized to resolve
the border dispute, posted its findings in
2002. However, both parties have been
unable to reach agreement on imple¬
menting the decision. On 30 November
2007, the Eritrea-Ethiopia Boundary
Commission remotely demarcated the
border by coordinates and dissolved itself,
leaving Ethiopia still occupying several
tracts of disputed territory, including the
town of Badme. Eritrea accepted the
EEBC’s “virtual demarcation” decision
and called on Ethiopia to remove its
troops from the TSZ which it states is
Eritrean territory. Ethiopia has not
accepted the virtual demarcation decision.
208
CM
CM
CMR
120
CMR
.cm
6 00 N
12 00 E
4 03 N
9 42 E
Man, Isle of
54 09 N
4 28 W
Atlantic Ocean
51 00 N
1 30 E
Atlantic Ocean,
60 00 S
60 00 W
Southern Ocean
6 00 N
12 00 E
3 52 N
11 31 E
Federated States of Micronesia
9 30 N
138 00 E
^ , OOuala
Malabo *
icji \\ t-RiA1 (ii is t } Yaounde
Crutl of Crui''twa \\> —
SAD TOME ^
. N1D nine nr. *
S3o Tome
AtttiMn
<m>
Brazzaville
Poin te~ N D(re%z
AttQOLA J^L..
(Cabinda) ‘v
Abi#
Bangui','f06f5e01b9a0736206077c6b4d464162eac22c37121d78921ca1c0a1f0596939','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7daede96908a2a6e8b92cfaf72adcb8c880ef391df4802a4e46ac480f084453',2009,'CA','Canada','transnational-issues',264,'Disputes— international: Joint Border
Commission with Nigeria reviewed 2002
ICJ ruling on the entire boundary and
bilaterally resolved differences, including
June 2006 Greentree Agreement that
immediately cedes sovereignty of the
Bakassi Peninsula to Cameroon with a
phase-out of Nigerian control within two
years while resolving patriation issues;
implementation of the ICJ ruling on the
Cameroon-Equatorial Guinea-N igeria
maritime boundary in the Gulf of Guinea
is pending due to imprecisely defined
coordinates and a sovereignty dispute
between Equatorial Guinea and
Cameroon over an island at the mouth of
the Ntem River; only Nigeria and
Cameroon have heeded the Lake Chad
Commission’s admonition to ratify the
delimitation treaty, which also includes
the Chad-Niger and Niger-Nigeria
boundaries
Refugees and internally displaced per¬
sons: refugees (country of origin):
20,000-30,000 (Chad); 3,000 (Nigeria);
24,000 (Central African Republic)
(2007)
pawsm
tetwrSp
Johns
.Calgary
Quebec
Thunder
Winmi
•fOflStt
Background: A land of vast distances
and rich natural resources, Canada
became a self-governing dominion in
1867 while retaining ties to the British
crown. Economically and technologi¬
cally the nation has developed in parallel
with the US, its neighbor to the south
across an unfortified border. Canada
faces the political challenges of meeting
public demands for quality improvements
in health care and education services, as
well as responding to separatist concerns
in predominantly francophone Quebec.
Canada also aims to develop its diverse
energy resources while maintaining its
commitment to the environment.
Disputes — international: managed mar¬
itime boundary disputes with the US at
Dixon Entrance, Beaufort Sea, Strait of
Juan de Fuca, and around the disputed
Machias Seal Island and North Rock;
US works closely with Canada to inten¬
sify security measures to monitor and
control legal and illegal personnel, trans-
123
THE CIA WORLD FACTBOOK
port, and commodities across the inter¬
national border; sovereignty dispute with
Denmark over Hans Island in the
Kennedy Channel between Ellesmere
Island and Greenland
Illicit drugs: illicit producer of cannabis
for the domestic drug market and export
to US; use of hydroponics technology
permits growers to plant large quantities
of high-quality marijuana indoors;
increasing ecstasy production, some of
which is destined for the US; vulnerable
to narcotics money laundering because of
its mature financial services sector
Miodeio
. • ''
Sao
Vicente
50 km
*Sarrta
oaoweww Marta
* oQ
«n»T« At l T>{
-**0 Boa
S OTAVENTO
NORTH ATLANTIC
OCEAN
O -
° Ta/rafal,
\\Vn * Ttago
Ware
Sao mc *
F.tipe, *
Brava Fogo PRAJA
<x>
i
Disputes— international: none
Illicit drugs: used as a transshipment
point for Latin American cocaine des¬
tined for Western Europe; the lack of a
well-developed financial system limits
the country’s utility as a money-laun¬
dering center
CA
CA
CAN
124
CAN
.ca
Cape Verde
CV
CV
CPV
132
CPV
.CV
79 30 N
90 00 W
68 00 N
70 00 W
75 15 N
121 30 W
51 02 N
114 04 W
Pacific Ocean
28 00 N
112 00W
76 00 N
87 00 W
78 00 N
103 00 W
791
THE CIA WORLD FACTBOOK
Name
Ellesmere Island
Ellice Islands
Ellsworth Land (region)
Elobey, Isles de (island group)
Enderbury Island
Enewetak Atoll (Eniwetok Atoll)
England (region)
English Channel
Eniwetok Atoll (see Enewetak Atoll)
Eolie, (sole (island group)
Epirus, Northern (region)
Episkopi Cantonment (capital)
Ertra (local name for Eritrea)
Espana
Essequibo (region; claimed by Venezuela)
Etorofu (island; also Iturup)
Farquhar Group (island group; also Atoll de Farquhar)
Fergana Valley
Fernando Po (island; see Bioko)
Fernando de Noronha (island group)
Filipinas (local name for the Philippines; also Pilipinas)
Finland, Gulf of
Florence (city)
Flores (island)
Flores Sea
Florida, Straits of
Fongafale (largest island of Funafuti)
Former Soviet Union (FSU)
Formosa (island)
Formosa Strait (see Taiwan Strait)
Foroyar (local name for Faroe Islands)
Fort-de-France (capital)
Frankfurt am Main (city)
Franz Josef Land (island group)
Freetown (capital)
French Cameroon (former name for Cameroon)
French Guinea (former name for Guinea)
French Indochina (former name for French possessions
in southeast Asia)
French Morocco (former name for Morocco)
French Somaliland (former name for Djibouti)
French Sudan (former name for Mali)
French Territory of the Afars and issas
(or FTAI; former name for Djibouti)
French Togoland (former name for Togo)
French West Indies (former name for French possessions
in the West Indies)
Friendly Islands
Frisian Islands
Frunze (city; former name for Bishkek)
Funafuti (capital, atoll)
Fundy, Bay of
Futuna Islands (Hoorn Islands/lles de Horne)
Fyn (island)
Gaborone (capital)
Galapagos Islands (Archipielago de Colon)
Galicia (region)
Galicia (region)
Galilee (region)
Galleons Passage
Entry In
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
81 00 N
80 00 W
44 39 N
63 36 W
54 00 N
62 00 W
Atlantic Ocean
60 00 N
55 00 W
45 31 N
73 34 W
Czech Republic
49 30 N
17 00 E
Czech Republic
49 35 N
17 50 E
52 00 N
56 00 W
72 00 N
90 00 W
45 25 N
75 40 W
46 20 N
63 20 W
76 30 N
119 00 W
46 48 N
71 15 W
53 00 N
132 00 W
801
THE CIA WORLD FACTBOOK
Name
Queen Elizabeth Islands
Queen Maud Land (claimed by Norway)
Quemoy (island)
Quito (capital)
Rabat (capital)
Ralik Chain (island group)
Rangoon (capital; also Yangon)
Rapa Nui (Easter Island)
Ratak Chain (island group)
Red Sea
Redonda (island)
Republica Dominicana (local name for Dominican Republic)
Republique Centrafricain (local name for Central
African Republic)
Republique Francaise (local name for France)
Republique Gabonaise (local name for Gabon)
Republique Rwandaise (local name for Rwanda)
Republique Togolaise (local name for Togo)
Revillagigedo Island
Revillagigedo Islands
Reykjavik (capital)
Rhodes (island)
Rhodesia, Northern (former name for Zambia)
Rhodesia, Southern (former name for Zimbabwe)
Riga (capital)
Riga, Gulf of
Rio Muni (mainland region)
Rio de Janiero (city)
Rio de Oro (region)
Rio de la Plata (gulf)
Riyadh (capital)
Road Town (capital)
Robinson Crusoe Island (Mas a Tierra)
Rocas, Atol das (island)
Rockall (island)
Rodrigues (island)
Rome (capital)
Roncador Cay (island)
Roosevelt Island
Roseau (capital)
Ross Dependency (claimed by New Zealand)
Ross Island
Ross Sea
Rossiya (local name for Russia)
Rota (island)
Rotuma (island)
Ruanda (former name for Rwanda)
Rub al Khali (desert)
Rumelia (region)
Ruthenia (region; former name for Carpatho-Ukraine)
Ryukyu Islands
Saar (region)
Saaremaa (island)
Saba (island)
Sabah (state)
Sable Island
Safety Islands (lies du Salut)
Sahara Occidental (former name for Western Sahara)
Sahel (region)
Saigon (city; former name for Ho Chi Minh City)
Saint Barthelemy (island; also Saint Barfs)
Saint Brandon (Cargados Carajos Shoals)
Saint Christopher (island)
Saint Christopher and Nevis
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
78 00 N
95 00 W
43 55 N
59 50 W
47 12 N
60 09 W
43 40 N
79 23 W
Pacific Ocean
10 25 S
142 10 E
49 16 N
123 08 W
49 45 N
126 00 W
Holy See
41 54 N
12 27 E
71 00 N
110 00 W
49 53 N
97 10W
Russia
71 14 N
179 36 W
SEVERNAYA /
ZEMI.YA \\S
RUSSIA
ELIZABETH
mmMM,
Ranks a inlet
# Norilsk;
• >4
Ellesmere
DikscmA
FRANZ
to$m-
LAND I
Oa mi,''.. q
■ Ihub 1
•sh ’ I
NOVAVA
ZEMI.YA
" Svalbard
(NORWAY)
Long yea rbyep
Qreeniand
(DENMARK)
KangerJtoswuaq
teondre Stramfjordl
B}0rm?ya
{NORWAY)
r Nuuk
(Gotlthabi
utoqqortdormiif
(Scoresbysand)
Murmansk v
Paamiut J
(Iredetiksliab)*
Perm
Jan Mayen
. (morwAi:.
lasiiiaq
Arkhangelsk1
•Boms
Labrador
Nlarsatattaq
sorwegiMi
Denmark Strait
Kazan
Samara
,;L Li ,v-
NORW|i
’ Nizhniy
Novgorod
Reykjavik
kl ’ Saint
’ ,,?Pctersburg
"ms
Moscow
T Hudson?^ \\
.
warn .
v iV.
m ,
0 r I h
a c t r t c
c c a 11
{ TV;
^ ''Vt
Vicuna •'' - ^
*’
.Seattle
7 : ;b ■■■■■■■: ...
■ ■■O
/ .Vt., ■''-• ''■-■V _y “‘7
Portland S * Bly; 7
- “ ty ...XikB ,
0 ■ /
4
.Saskatoon
Regina.
Winnipeg *
Baa
I
IBS
riiiindv
Sun
. *; ,j
/- - y '' Jf % x i
4 / Charktttetov^ |Sydney
rcdericton
t * Half
Saint John
; St. ¥te(t&
and
tTMmZi
. 1 \\ hreaericton ;
Q«lbec . *, •Halitav
■ ^ v.''t'' Saint lohn
- %«®*4 .4 7fcSv«g“
'' ^ y, ,.v <.v _
° ■ T. • '' . p ’-A4 1 H-tfiT • /’ **’
ii''iX UNITE
MontreaiT
ip-. ‘ Ottawa • i
v t & ,< 1 g I «
''^ v; a? M 4;^;^ / i .d
foroiUo ,<# ;
80
^Boston
. - «. ''
1 1,'' :
K\\
0,1
>!
Sacramento % Salt lake City*
San Francisco
fr,
p las
>
:S
. t U - Clevdbnd gl . J.j I ^itimore
: “''Tcu,,^0*! *vv^htagl(m,D.c.
. y..,_. . ■,., . . . „ . ,|oWwi North.
’Denver , .St. touis v / Norfolk >.
.Kansas City ,1
Atlantic
Indianapolis
*''S TATES,. „
y) . . Memphis
Provideniva
Whitehorse v-
*
Valdez
Anchorage
Bethel
Berliv
<
Sea
: * /
Washington
A^h?^fe:||oti5C
Scale 1:37,000,000
''*00 Kilometers
ikS, Caprtol
Virginia V
Pentagon
400 Miles
,xU24-
Edmonton
Vamouwi
Regina
Seattle
Winnipeg
lympia
I VV,x,l/?r
Quebec^
Salem
Ottawa
Helena
Bismarck
J Montpelier''
J'' Alhan|P
New Ittrk L:
ftfejiiii
Toronto
^Concord
aeopton
. Boise
dance
Pierre
Madison
Lansing
Hartford
IgSrfA*
CX''ew York
enton -•"
Detroit/''
cCrrfidyis.irda ■
Philadelphia gy
Harristsurf- f
Chicago,
Cheyenne
Sacramento ^Carson Citv
Salt Lake City
Lies Moines
Lincoln
SC*a*M
Columbus
an Francisco
S^ringiield lndianJf,0,|is;
iinglon, D.C
Denver
Topeka
Richmond
Charleston
Frankfort
jeffoison City
MJastt VSH ■
las Vegas
Raleigh , V’)
Nashville
(Los Angeles
Santa I''e
/Memphis
Columbia
Oklahoma Cftv
Phoenix
Atlanta
l ittle Rock
Mexicali
Montgomery
Dallas
ladkson
«
Baton
Rouge
Austin
Hermosillo
New Orleans
Houston
yy
Miami
of M. exu:','0da562823c8cbe6857ec19375d3d9273541de2e3bbb4d03ad8592f4afde659e8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7317ea5bb4757c70485b51424aa8ac433dd422ffb2bb5df3cccbe8ba091cea5a',2009,'KY','Cayman Islands','transnational-issues',272,'Background: The Cayman Islands were
colonized from Jamaica by the British
during the 18th and 19th centuries, and
were administered by Jamaica after 1863.
In 1959, the islands became a territory
within the Federation of the West Indies,
but when the Federation dissolved in
1962, the Cayman Islands chose to
remain a British dependency.
Location: Caribbean, three-island group
(Grand Cayman, Cayman Brae, Little
Cayman) in Caribbean Sea, 240 km
south of Cuba and 268 km northwest of
Climate: tropical marine; warm, rainy
summers (May to October) and cool, rel¬
atively dry winters (November to April)
Terrain: low-lying limestone base sur¬
rounded by coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff (Cayman Brae)
43 m
Natural resources: fish, climate and
beaches that foster tourism
Land use:
arable land: 3.85%
permanent crops: 0%
other: 96.15% (2005)
Irrigated land: NA
Natural hazards: hurricanes (July to
November)
Environment — current Issues: no nat¬
ural fresh water resources; drinking water
supplies must be met by rainwater catch¬
ments
Geography — note: important location
between Cuba and Central America
Disputes — international: none
Illicit drugs: offshore financial center;
vulnerable to drug transshipment to the
US and Europe
CJ
KY
CYM
136
CYM
•ky
Central African
CT
CF
CAF
140
CAF
xf
Republic
19 20 N
81 23 W
19 20 N
81 20 W','179cb0bf9178cddefc780df340f56b024ea445c566ca08647100d1d79ed52bd6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7c5b47a4c9f5ee46535c46da8e79be27a0f9e1f7318ab3a3fa9bec4486e3abd',2009,'JM','Jamaica','transnational-issues',273,'Geographic coordinates: 19 30 N, 80 30
w
Map references: Central America and
the Caribbean
Area: total: 262 sq km
land: 262 sq km
water: 0 sq km
Area — comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
126
Disputes— international: none
Illicit drugs: transshipment point for
cocaine from South America to North
America and Europe; illicit cultivation
and consumption of cannabis; govern¬
ment has an active manual cannabis
eradication program; corruption is a
major concern; substantial money-laun¬
dering activity; Colombian narcotics
traffickers favor Jamaica for illicit finan¬
cial transactions
Background: This desolate, arctic,
mountainous island was named after a
Dutch whaling captain who indisputably
discovered it in 1614 (earlier claims are
inconclusive). Visited only occasionally
by seal hunters and trappers over the fol¬
lowing centuries, the island came under
Norwegian sovereignty in 1929. The
long dormant Haakon VII
Toppen/Beerenberg volcano resumed
332
JM
JM
GUF
254
GUF
•gf
PYF
258
PYF
•pf
ATF
260
ATF
.tf
GAB
266
GAB
•ga
GMB
270
GMB
•gm
PSE
275
PSE
•PS
GEO
268
GEO
•ge
DEU
276
DEU
.de
GHA
288
GHA
•gh
GIB
292
GIB
•gi
-
''
GRC
300
GRC
•gr
GRL
304
GRL
•gl
GRD
308
GRD
•gd
GLP
312
GLP
•gP
GUM
316
GUM
•gu
GTM
320
GTM
•gt
GGY
831
UK
•gg
GIN
324
GIN
•gn
GNB
624
GNB
•gw
GUY
328
GUY
•gy
HTI
332
HTI
.ht
HMD
334
HMD
.hm
VAT
336
VAT
.va
HND
340
HND
.hn
HKG
344
HKG
.hk
-
UMI
-
HUN
348
HUN
.hu
ISL
352
ISL
.is
IND
356
IND
.in
IDN
360
IDN
.id
IRN
364
IRN
.ir
IRQ
368
IRQ
•iq
IRL
372
IRL
.ie
IMN
833
UK
.im
ISR
376
ISR
.il
ITA
380
ITA
.it
JAM
388
JAM
•jm
Comment
ISO limits to the European
part of France, excluding
French Guiana, French
Polynesia, French Southern
and Antarctic Lands,
Guadeloupe, Martinique,
Mayotte, New Caledonia,
Reunion, Saint Pierre and
Miquelon, Wallis and Futuna
ISO includes Clipperton
Island
FIPS 1 0-4 does not include
the French''daimed portion
of Antarctica (Terre Adelie)
ISO identifies as Occupied
Palestinian Territory
administered as part of
French Southern and
Antarctic Lands; no ISO
codes assigned
ISO includes with the US
Minor Outlying Islands
779
THE CIA WORLD FACTBOOK
STANA6-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
Jan Mayen
JN
SJM
ISO includes with Svalbard
18 00 N
76 48 W
"''Pu^Na
Oaxaca
AcapuUo*
,C BELIZE
■Hr Belmopan
; 04 N. | HONDURAS;
Guatemala Tegucigalpa
GUATEMALA * * J ^IC^RAGUA
Caribbean
\\$ea
San Salvador','108e9c86ef3007747c8a789de558db694a029ab5b8844df6fff02c7f9fa84368','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af58f5675e59367d532be895da3ddad97f75e292b7ff719343d4f067d262e488',2009,'CF','Central African Republic','transnational-issues',280,'- -
Background: The former French colony
of Ubangi-Shari became the Central
African Republic upon independence in
1960. After three tumultuous decades of
misrule — mostly by military govern¬
ments — civilian rule was established in
1993 and lasted for one decade.
President Ange-Felix PATASSE’s
civilian government was plagued by
unrest, and in March 2003 he was
deposed in a military coup led by
General Francois BOZIZE, who estab¬
lished a transitional government.
Though the government has the tacit
support of civil society groups and the
main parties, a wide field of candidates
contested the municipal, legislative, and
presidential elections held in March and
May of 2005 in which General BOZIZE
was affirmed as president. The govern¬
ment still does not fully control the
countryside, where pockets of lawlessness
128
persist. Unrest in neighboring nations,
Chad, Sudan, and the DRC, continues
to affect stability in the Central African
Republic as well.
4 22 N
18 35 E
The Gambia
13 28 N
16 39 W
7 00 N
21 00 E
Pacific Ocean
2 30 S
129 30 E
Czech Republic
49 45 N
15 30 E
Czech Republic, Slovakia
49 00 N
17 30 E
7 00 N
21 00 E
6 38 N
20 33 E','4b3dbb0dd9082939e1272a37715910f2a04191d7bd566fdae572e598492d0116','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093f1bb1e1f699ee42ab85daf50b524bb8e1f0740060c8399b1d93b724a387c8',2009,'TD','Chad','transnational-issues',293,'Disputes— international: since 2003,
Janjawid armed militia and the Sudanese
military have driven hundreds of thou¬
sands of Darfur residents into Chad;
Chad remains an important mediator in
the Sudanese civil conflict, reducing ten¬
sions with Sudan arising from cross-
border banditry; Chadian Aozou rebels
reside in southern Libya; only Nigeria
and Cameroon have heeded the Lake
Chad Commission’s admonition to ratify
the delimitation treaty, which also
includes the Chad-Niger and Niger-
Nigeria boundaries
Refugees and internally displaced per¬
sons: refugees (country of origin): 234,000
(Sudan); 54,200 (Central African
Republic)
IDPs: 178,918 (2007)
CD
TD
TCD
148
TCD
.td
22 00 N
18 00 E
12 07 N
15 03 E
15 00 N
19 00 E','029bd18199d5ca100aeff6279cd22003517d2e5f0e2836a86307adfef0963355','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3871c1c2ec801507fa4f0584dc8e9730245a7b3cfec3225aff8e345cc2c298a9',2009,'CL','Chile','transnational-issues',303,'Disputes— international: Chile rebuffs
Bolivia’s reactivated claim to restore the
Atacama corridor, ceded to Chile in
1884, offering instead unrestricted but
not sovereign maritime access through
Chile to Bolivian gas and other com¬
modities; Chile rejects Peru’s unilateral
137
THE CIA WORLD FACTBOOK
legislation to change its latitudinal mar¬
itime boundary with Chile to an equidis¬
tance line with a southwestern axis
favoring Peru; territorial claim in
Antarctica (Chilean Antarctic
Territory) partially overlaps Argentine
and British claims; the joint boundary
commission, established by Chile and
Argentina in 2001, has yet to map and
demarcate the delimited boundary in the
inhospitable Andean Southern Ice Field
(Campo de Hielo Sur)
Illicit drugs: important transshipment
country for cocaine destined for Europe;
economic prosperity and increasing trade
have made Chile more attractive to traf¬
fickers seeking to launder drug profits,
especially through the Iquique Free
Trade Zone, but a new anti-money-laun¬
dering law improves controls; imported
precursors passed on to Bolivia; domestic
cocaine consumption is rising; signifi¬
cant consumer of cocaine
Cl
CL
CHL
152
CHL
.cl
23 00 S
70 10W
24 30 S
69 15 W
42 50 S
74 00 W
56 30 S
68 43 W
27 07 S
109 22 W
Pacific Ocean
34 00 N
129 00 E
55 59 S
67 16 W
33 00 S
80 00 W
Pacific Ocean
48 18 N
124 00 W
Indian Ocean
27 40 N
33 55 E
Israel, West Bank
31 35 N
35 00 E
Bosnia and Herzegovina,
43 00 N
21 00 E
Croatia, Macedonia,
Montenegro, Serbia, Slovenia
33 38 S
78 52 W
Mauritius, Reunion
21 00 S
57 00 E
27 07 S
109 22 W
Afghanistan, Pakistan
32 00 N
69 00 E
Clipperton Island
10 17 N
109 13 W
27 07 S
109 22 W
33 38 S
78 52 W
26 28 S
105 00 W
26 21 S
79 52 W
26 17 S
80 05 W
33 27 S
70 40 W
Cape Verde
17 05 N
25 10W
\\
ARCHIPELAGO
IUAN FERNANDEZ
Cerro Aconcagua «
(highest point in
Scti^ America, 698$ m) ''■
Porto Alegre,
Valparaiso!
★ m
uCllrdolraP , Santa FC4
# ;* <0 IL’T
.Mendop fq Rosario*
* Sal to','e4e842e4d6fa8d452862d5ed0a42c9c15dc53f90e7a9f8446754253959400bba','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0fe828f53ef8bc92faf4572c432331558ace515e5c7747253bcc231a3dc62eb',2009,'CN','China','transnational-issues',304,'mi siA
CH
CN
CHN
156
CHN
.cn
see also Taiwan
39 56 N
116 24 E
23 06 N
113 16 E
30 43 N
104 04 E
789
THE CIA WORLD FACTBOOK
Name
Chennai (city; also Madras)
Chesterfield Islands (lies Chesterfield)
Chihli, Gulf of (see Bo Hai)
Chiloe (island)
China, People''s Republic of
China, Republic of
Chisinau (capital; also Kishinev)
Choiseul (island)
Choson (local name for North Korea)
Christmas Island (Indian Ocean)
Christmas Island (Pacific Ocean; also Kiritimati)
Chukchi Sea
Chuuk Islands (Truk Islands)
Cilicia (region)
Ciskei (enclave)
Citta del Vaticano (local name for Vatican City)
Cochin China (region)
Coco, Isla del (island)
Cocos Islands
Colombo (capital)
Colon, Archipieiago de (Galapagos Islands)
Commander Islands (Komandorskiye Ostrova)
Comores (local name for Comoros)
Con Son (islands)
Conakry (capital)
Confederatio Helvetica (local name for Switzerland)
Congo (Brazzaville) (former name for Republic of the Congo)
Congo (Leopoldville) (former name for the Democratic
Republic of the Congo)
Constantinople (city; former name for Istanbul)
Cook Strait
Copenhagen (capital)
Coral Sea
Corfu (island)
Corinth (region)
Corisco (island)
Corn Islands (Islas del Maiz)
Corocoro Island
Corsica (island; also Corse)
Cosmoledo Group (island group; also Atoll de Cosmoledo)
Cotonou (former capital)
Cotopaxi (volcano)
Courantyne River
Cozumel (island)
Crete (island)
Crimea (region)
Crimean Peninsula
Crooked Island Passage
Crozet Islands (lies Crozet)
Cyclades (island group)
Cyrenaica (region)
Czechoslovakia (former name for the entity that
subsequently split into the Czech Republic and Slovakia)
D''Entrecasteaux Islands
Dagestan (region)
Dahomey (former name for Benin)
Daito Islands
Dakar (capital)
Dalmatia (region)
Daman (city; also Damao)
Damascus (capital)
Danger Islands (see Pukapuka Atoll)
Danish Straits
Danish West Indies (former name for the Virgin Islands)
Danmark (local name)
Danzig (city; former name for Gdansk)
790
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
35 00 N
105 00 E
Taiwan
23 30 N
121 00 E
Moldova
47 00 N
28 50 E
23 09 N
113 21 E
19 00 N
109 30 E
Vietnam
20 52 N
106 41 E
Egypt (claimed), Sudan
22 30 N
35 00 E
(de facto)
42 00 N
113 00 E
36 00 N
84 00 E
Russia (de facto)
46 10N
152 00 E
22 10N
113 33 E
44 00 N
124 00 E
44 00 N
124 00 E
39 56 N
116 24 E
31 14 N
121 30 E
41 46 N
123 24 E
42 00 N
86 00 E
Netherlands Antilles
17 29 N
62 58 W
Netherlands Antilles
18 04 N
63 04 W
32 00 N
90 00 E
35 00 N
105 00 E
Israel, West Bank
31 46 N
35 14 E
Sea
PHIL Rp tf
4 f . a|J£uib . ^ ''
Samar
" . . y -Ce
’ 3»* , JVmmA* f Bacofotf/e -
NICQMR
SPRATLY
ISLAKPS .
Negtyi
:Wm
■■■ V$\\ ''■■•
- % 1*1 MALAYSIA
«• *ku‘ll‘5 LMmp»r
7 • Melaka '' ''
^mbOC,,lgV Davao*
ft
&i»54®an de Oro
rol
A KEPUIAUAN
w NATUNA
Bandar Seri ,Kdta Knwhaiu
Begawan - S ‘ M i
BRUNEI., ★ ; . <«ri t . . .
■■''■■ ■■e.ee- I (,i if ■
Melekeokj|','fb403bedb1bec94e346457c42e1f8306ab469ecc9ea3ea2d93225175e443b876','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4c48da0e94b93740ad484f07c9e00d39efb3494b001d5dec9b60e983e7630f',2009,'KZ','Kazakhstan','transnational-issues',305,'Harbin
Urumqi
Shenyang
Nans.no
W
«1
timm .
marx ''
''■C’C&M
Oinhuaogdao ./ * .iAPAH
***!85 '' w; „
K- ^ Chengdu Wuhan Nmgbo.
'' 1 " '' | Taipai Pi-iUppim
KZ
KZ
KAZ
398
KAZ
.kz
51 10N
71 30 E
China (de facto), India (claimed) 35 00 N
79 00 E
43 15 N
76 57 E
43 15 N
76 57 E
51 10N
71 30 E
48 00 N
68 00 E
48 00 N
68 00 E
Gaza Strip
31 25 N
34 20 E
. Aqtau
? tAkialij. 4C:fi41i:CS3
Bat''u ml/ Tbilisi. />k ''T tkmui/xmtin
£yrcjpg>, -26 m)
KA2AKiJSTA.fi
,/x.','f77717febbbaf1281e419cfaa58b8dd1ed6c0082627d0ee9e2881e08429415bd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e172b8ab219e5a6383f577f312190a7e929ad24f3dfbe1b957109babf0c68df',2009,'IN','India','transnational-issues',306,'W Guangzhou T«*‘
i&SK iw.i
— . ~ '' ■ **,«L . .
PHIL
Disputes— international : since China
and India launched a security and foreign
policy dialogue in 2005, consolidated
discussions related to the dispute over
most of their rugged, militarized
boundary, regional nuclear proliferation,
Indian claims that China transferred
missiles to Pakistan, and other matters
continue; various talks and confidence¬
building measures have cautiously begun
to defuse tensions over Kashmir, particu¬
larly since the October 2005 earthquake
in the region; Kashmir nevertheless
remains the site of the world’s largest and
most militarized territorial dispute with
portions under the de facto administra¬
tion of China (Aksai Chin), India
(Jammu and Kashmir), and Pakistan
(Azad Kashmir and Northern Areas);
India and Pakistan have maintained the
2004 cease fire in Kashmir and initiated
discussions on defusing the armed stand¬
off in the Siachen glacier region;
Pakistan protests India’s fencing the
highly militarized Line of Control and
construction of the Baglihar Dam on the
Chenab River in Jammu and Kashmir,
which is part of the larger dispute on
water sharing of the Indus River and its
tributaries; UN Military Observer Group
in India and Pakistan (UNMOGIP) has
maintained a small group of peace¬
keepers since 1949; India does not recog¬
nize Pakistan’s ceding historic Kashmir
lands to China in 1964; to defuse ten¬
sions and prepare for discussions on a
maritime boundary, India and Pakistan
seek technical resolution of the disputed
boundary in Sir Creek estuary at the
mouth of the Rann of Kutch in the
Arabian Sea; Pakistani maps continue to
show its Junagadh claim in Indian
Gujarat State; discussions with
Bangladesh remain stalled to delimit a
small section of river boundary, to
exchange territory for 51 Bangladeshi
exclaves in India and 1 1 1 Indian
exclaves in Bangladesh, to allocate
divided villages, and to stop illegal cross-
border trade, migration, violence, and
transit of terrorists through the porous
border; Bangladesh protests India’s
attempts to fence off high-traffic sections
of the border; dispute with Bangladesh
over New Moore/South
Talpatty/Purbasha Island in the Bay of
Bengal deters maritime boundary delimi¬
tation; India seeks cooperation from
Bhutan and Burma to keep Indian
Nagaland and Assam separatists from
hiding in remote areas along the borders;
304
INDIAN OCEAN
Joint Border Committee with Nepal
continues to examine contested
boundary sections, including the 400
square kilometer dispute over the source
of the Kalapani River; India maintains a
strict border regime to keep out Maoist
insurgents and control illegal cross-
border activities from Nepal
Refugees and internally displaced per¬
sons: refugees (country of origin): 77,200
(Tibet/China); 69,609 (Sri Lanka);
9,472 (Afghanistan)
IDPs: at least 600,000 (about half are
Kashmiri Pandits from Jammu and
Kashmir) (2007)
Trafficking in persons: current situation:
India is a source, destination, and transit
country for men, women, and children
trafficked for the purposes of forced or
bonded labor and commercial sexual
exploitation; the large population of
men, women, and children — numbering
in the millions — in debt bondage face
involuntary servitude in brick kilns, rice
mills, and embroidery factories, while
some children endure involuntary servi¬
tude as domestic servants; internal traf¬
ficking of women and girls for the
purposes of commercial sexual exploita¬
tion and forced marriage also occurs; the
government estimates that 90 percent of
India’s sex trafficking is internal; India is
also a destination for women and girls
from Nepal and Bangladesh trafficked for
the purpose of commercial sexual
exploitation; boys from Afghanistan,
Pakistan, and Bangladesh are trafficked
through India to the Gulf states for
involuntary servitude as child camel
jockeys; Indian men and women migrate
willingly to the Persian Gulf region for
work as domestic servants and low-
skilled laborers, but some later find
themselves in situations of involuntary
servitude including extended working
hours, nonpayment of wages, restrictions
on their movement by withholding of
their passports or confinement to the
home, and physical or sexual abuse
tier rating: Tier 2 Watch List — India has
been on the Tier 2 Watch List since 2004
for its failure to show evidence of increasing
efforts to address trafficking in persons
Illicit drugs: world’s largest producer of
licit opium for the pharmaceutical trade,
but an undetermined quantity of opium
is diverted to illicit international drug
markets; transit point for illicit narcotics
produced in neighboring countries; illicit
producer of methaqualone; vulnerable to
narcotics money laundering through the
hawala system; licit ketamine and pre¬
cursor production
INDIAN OCEAN
Background: The Indian Ocean is the
third largest of the world’s five oceans
(after the Pacific Ocean and Atlantic
Ocean, but larger than the Southern
Ocean and Arctic Ocean). Four criti¬
cally important access waterways are the
Suez Canal (Egypt), Bab el Mandeb
(Djibouti-Yemen), Strait of Hormuz
(Iran-Oman), and Strait of Malacca
( Indonesia- Malaysia ) . The decision by
the International Hydrographic
Organization in the spring of 2000 to
delimit a fifth ocean, the Southern
Ocean, removed the portion of the
Indian Ocean south of 60 degrees south
latitude.
Disputes— international: some mar-
itime disputes (see littoral states)
IN
IN
11 30 N
72 30 E
12 00 N
92 45 E
Indian Ocean
10 00 N
95 00 E
20 00 N
77 00 E
23 16 N
77 24 E
18 58 N
72 50 E
Netherlands Antilles
12 10N
68 15 W
Atlantic Ocean
41 01 N
14 00 E
22 32 N
88 21 E
13 04 N
80 16 E
20 10N
73 00 E
Syria
33 30 N
36 18 E
20 42 N
70 59 E
15 20 N
74 00 E
China, Mongolia
42 30 N
107 00 E
32 42 N
74 52 E
India, Pakistan
34 00 N
76 00 E
Pacific Ocean
40 00 N
135 00 E
Laos
19 27 N
103 10 E
10 00 N
73 00 E
Indian Ocean
7 00 N
76 00 E
10 00 N
73 00 E
13 04 N
80 16 E
8 17 N
73 02 E
18 58 N
72 50 E
28 36 N
77 12 E
Indonesia, Papua New Guinea
5 00 S
140 00 E
8 00 N
93 30 E
27 50 N
88 30 E
Czech Republic, Germany,
51 00 N
17 00 E','4bde15cfb6a57ab0bc021ba6f79924dd68ec0e8d39a296b771e02774ab346b2b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f41817f1946a593c8eb69882cdbd0e1600aebf3d8915608c319064322bdbaa0',2009,'CX','Christmas Island','transnational-issues',319,'Disputes— international: none
CLIPPERTON ISLAND
Disputes— international: none
KT
cx
CXR
162
CXR
.cx
Clipperfon Island
IP
''
-
FYP
-
ISO includes with French
Cocos (Keeling)
CK
cc
CCK
166
AUS
.cc
Polynesia
Islands
10 25 S
105 43 E
Russia
79 30 N
98 00 E
Democratic Republic of the
8 00 S
27 00 E','24820d64d3c382328e9de9875a02ba8edeb6b728bb07159651eceda0da492140','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609fd460b8ad0ff4c158a9ec074f0c5a64739b67d055874b2a44db53617f6814',2009,'CC','Cocos (Keeling) Islands','transnational-issues',323,'North Keeling
island
Indian
mi
South
Keeling
Islands
Horsburgh
Island
ft
Direction Island
** **«#&
Home island
\\
West
Island
South Island
''V- ■!
Disputes— international: none
OLOMBIA
12 30 S
96 50 E
12 30 S
96 50 E
French Southern and
49 30 S
69 30 E
Antarctic Lands
12 10 S
96 55 E
Pacific Ocean
34 40 N
129 00 E','dcbe7a25c4620af6cd994d6ce0889123ff1c7ac7a9351eb5bea474b62265763a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1a4e97c31e15c2d9db9e6f489212ac067141dae027512e1de888c7c51adf382',2009,'KM','Comoros','transnational-issues',336,'Disputes — international: memorials and
countermemorials were filed by the par¬
ties in Nicaragua’s 1999 and 2001 pro¬
ceedings against Flonduras and Colombia
at the ICJ over the maritime boundary
and territorial claims in the western
Caribbean Sea — final public hearings are
scheduled for 2007; dispute with
Venezuela over maritime boundary and
Venezuelan-administered Los Monjes
Islands near the Gulf of Venezuela;
Colombian-organized illegal narcotics,
guerrilla, and paramilitary activities pene¬
trate all of its neighbors’ borders and have
caused over 300,000 persons to flee the
country, mostly into neighboring states
Refugees and internally displaced
persons: IDPs: 1.8-3. 5 million (conflict
between government and illegal armed
groups and drug traffickers) (2007)
Illicit drugs: illicit producer of coca,
opium poppy, and cannabis; world’s
leading coca cultivator with 144,000
hectares in coca cultivation in 2005, a
26% increase over 2004, producing a
potential of 545 mt of pure cocaine; the
world’s largest producer of coca deriva¬
tives; supplies cocaine to most of the US
market and the great majority of other
international drug markets; in 2005,
aerial eradication dispensed herbicide to
treat over 130,000 hectares but aggressive
replanting on the part of coca growers
means Colombia remains a key producer;
a significant portion of non-US narcotics
proceeds are either laundered or invested
in Colombia through the black market
peso exchange; important supplier of
heroin to the US market; opium poppy
cultivation fell 50% between 2003 and
2004 to 2,100 hectares yielding a poten¬
tial 3.8 metric tons of pure heroin, mostly
for the US market; no poppy estimate was
conducted in 2005
0
30 60 fen
0
30 Wm
MORONI
* Grande Comore
'' . \\) (N/viMja)
!
Moutsamoudou^
MoMU .FOfftoS
(Mwah) ''
Anjouan
(Nzwarti)
"Dcmoni
Disputes — international: claims
French-administered Mayotte
151
_
_ _
CONGO, DEMOCRATIC REPUBLIC OF THE
CN
KM
COM
174
COM
.km
Congo, Democratic
CG
CD
COD
180
COD
.cd
formerly Zaire
Republic of the
Congo, Republic
CF
CG
COG
178
COG
.cs
of the
12 15 S
44 25 E
Turkey
39 56 N
32 52 E
12 10 S
44 15 E
Vietnam
8 43 N
106 36 E
11 41 S
43 16 E
Federated States of Micronesia
5 30 N
153 40 E
Russia
55 45 N
37 35 E
Moroni
lubumhd!sbi
.Glories# (sl^mts
, < fRAflCEii
St. Helena
(U.K.)','fe18c4eefc18aa58629bc6cb209d7ba74f5b873cfabd30999efa885dd626eb81','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('049cabef5cb37ec22be690e54b27c5fa39a082ec147f6de912a989dfe424cc4c',2009,'YT','Mayotte','transnational-issues',337,'f"h
by
e \\yf cmmm.
MF
YT
MYT
175
FRA
.yt
12 47 S
45 14 E
N icaragua
12 09 N
86 17 W','0966d8126ebc8431862945774806e8d520e5b3bd41c0f62791079e140b1f8743','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d5c256c295b47abf7c6a8e41cf78726f9d5e15019274d932d715685f9eac97e',2009,'CG','Congo','transnational-issues',348,'Disputes— international: Congo hosts
about 63,000 refugees from neighboring
states, primarily from the Pool border
area of the Democratic Republic of the
Congo; the location of the boundary in
the broad Congo River with the
Democratic Republic of the Congo is
indefinite except in the Pool
Malebo/Stanley Pool area
Refugees and internally displaced per¬
sons: refugees (country of origin): 46,341
(Democratic Republic of Congo); 6,564
(Rwanda)
IDPs: 48,000 (multiple civil wars since
1992; most IDPs are ethnic Lari) (2007)
■
tHV :7i
"
Mputegil
Kasama,
nm
Mufuiira»\\
Klvsw* %
Ndoto-
Kapirl Mposhi,
Cftipata,
Kabwi
LUSAKA
,Mngst<
iWliAntt-
» i«? aeokm
Heard Island and McDonald
53 00 S
72 30 E
Islands
South Georgia and the South
53 33 S
42 02 W
Sandwich Islands
iAMDA''
Mogadishu
/ GABON-pOHOp BASIN K
DEM. REP. fc,
OF THE CONGO
i Kilimanjaro
0hf>st point fo
trtca. 5895 m)
VIombasa
Victoria
sj>.aii7.)lw
rjDar es
4 Salaam','eb9116af8c1e517d8bbe72c5857fce1566748f638e6842c169084f0d7fba3145','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6a3be1bb14213ab5ff6d3d2762f27f0e52fd851376f10fd6863eae5f89b8270',2009,'CK','Cook Islands','transnational-issues',349,'Rakahanga ^ enrhyn
Pukapvka Mmibiki
Nassau
Island
Suwarrow
Sooth Paciffh Ooojn
Palmerston
Aitutak)
mamae
Takutea Mitiaro
Atiu Mauke
Background: Named after Captain
COOK, who sighted them in 1770, the
islands became a British protectorate in
1888. By 1900, administrative control
was transferred to New Zealand; in 1965,
residents chose self-government in free
association with New Zealand. The emi¬
gration of skilled workers to New
Zealand and government deficits are
continuing problems.
Location: Oceania, group of islands in
the South Pacific Ocean, about half way
between Hawaii and New Zealand
Geographic coordinates: 21 14 S, 159
46 W
Map references: Oceania
Area:
total: 236.7 sq km
land: 236.7 sq km
water: 0 sq km
Area— comparative: 1.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical oceanic; moderated by
trade winds; a dry season from April to
November and a more humid season
from December to March
Terrain: low coral atolls in north; vol¬
canic, hilly islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use:
arable land: 16.67%
permanent crops: 8.33%
other: 75% (2005)
Irrigated land: NA
Natural hazards: typhoons (November
to March)
Environment — current issues: NA
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the
selected agreements
Geography — note: the northern Cook
Islands are seven low-lying, sparsely pop¬
ulated, coral atolls; the southern Cook
Islands, where most of the population
lives, consist of eight elevated, fertile,
volcanic isles, including the largest,
Rarotonga, at 67 sq km
Disputes— international: none
CORAL SEA ISLANDS
Background: Scattered over more than
three-quarters of a million square kilo¬
meters of ocean, the Coral Sea Islands
were declared a territory of Australia in
1969. They are uninhabited except for a
small meteorological staff on the Willis
Islets. Automated weather stations, bea¬
cons, and a lighthouse occupy many
other islands and reefs.
cw
CK
COK
184
COK
.ck
Coral Sea Islands
CR
''
-
AUS
*
ISO includes with Australia
21 12 S
159 46 W
10 53 S
165 49 W
Atlantic Ocean
58 00 N
11 00 E
Virgin Islands
18 20 N
64 50 W
21 14 S
159 46 W
Turkey
36 30 N
36 15 E
10 53 S
165 49 W
India, Pakistan
30 50 N
73 30 E','a59323447f64ed051031350f2f4c32bc0208aaa08f5eb467e88cb00226e1bd85','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('594f94e11d71e951d364f6377c1094091a7da9fae7ed778bfad471d7d2accea5',2009,'CR','Costa Rica','transnational-issues',362,'Disputes— international: none
Background: Although explored by the
Spanish early in the 16th century, initial
attempts at colonizing Costa Rica proved
unsuccessful due to a combination of fac¬
tors, including: disease from mosquito-
infested swamps, brutal heat, resistance
by natives, and pirate raids. It was not
until 1563 that a permanent settlement
of Cartago was established in the cooler,
fertile central highlands. The area
remained a colony for some two and a
half centuries. In 1821, Costa Rica
became one of several Central American
provinces that jointly declared their
independence from Spain. Two years
later it joined the United Provinces of
Central America, but this federation dis¬
integrated in 1838, at which time Costa
Rica proclaimed its sovereignty and
independence. Since the late 19th cen¬
tury, only two brief periods of violence
have marred the country’s democratic
development. Although it still maintains
a targe agricultural sector, Costa Rica has
expanded its economy to include strong
technology and tourism industries. The
standard of living is relatively high. Land
ownership is widespread.
Disputes— international: in September
2005, Costa Rica took its case before the
ICJ to advocate the navigation, security,
and commercial rights of Costa Rican
vessels using the Rio San Juan over
which Nicaragua retains sovereignty
Refugees and internally displaced per¬
sons: refugees (country of origin):
9,699-11,500 (Colombia) (2007)
Illicit drugs: transshipment country for
cocaine and heroin from South America;
illicit production of cannabis in remote
areas; domestic cocaine consumption,
particularly crack cocaine, is rising; sig¬
nificant consumption of amphetamines
COTE D’IVOIRE
_
'') KatWa
taxfoufcou
Bouak6
Dabou Abo>Sso
San.
P&drct
. . , Syamoussouki
. * Abengotfo,
v Sfnfra Dtmbokro
Gagnoa, Adzopd.
Diva* ’AgboviOe
Background: Close ties to France since
independence in 1960, the development
of cocoa production for export, and for¬
eign investment made Cote d’Ivoire one
of the most prosperous of the West
African states, but did not protect it from
political turmoil. In December 1999, a
military coup — the first ever in Cote
d’Ivoire’s history — overthrew the gov¬
ernment. Junta leader Robert GUEI bla¬
tantly rigged elections held in late 2000
and declared himself the winner. Popular
protest forced him to step aside and
brought Laurent G BAG BO into power.
Ivorian dissidents and disaffected mem¬
bers of the military launched a failed
coup attempt in September 2002. Rebel
forces claimed the northern half of the
country, and in January 2003 were
granted ministerial positions in a unity
government under the auspices of the
Linas-Marcoussis Peace Accord.
President GBAGBO and rebel forces
resumed implementation of the peace
accord in December 2003 after a three-
month stalemate, but issues that sparked
the civil war, such as land reform and
grounds for citizenship, remained unre¬
solved. In March 2007 President
GBAGBO and former New Force rebel
leader Guillaume SORO signed the
Ouagadougou Political Agreement. As a
result of the agreement, SORO joined
GBAGBO’s government as Prime
Minister and the two agreed to reunite
the country by dismantling the zone of
confidence separating North from South,
integrate rebel forces into the national
armed forces, and hold elections. Several
thousand French and UN troops remain
in Cote d’Ivoire to help the parties
implement their commitments and to
support the peace process.
cs
CR
CRI
188
CRI
.cr
Cote d''Ivoire
IV
Cl
CIV
384
CIV
.ci
5 32 N
87 04 W
9 56 N
84 05 W','81f6408e116f9c6ed58ae6bdd357047a68b168f48467ae82373d9e794bd59140','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e64dbabd50d4274620e3c64ed01b445956f930d6c4c08a47531760793236cd6',2009,'HR','Croatia','transnational-issues',370,'Disputes — international: despite the
presence of over 9,000 UN forces
(UNOCI) in Cote d’Ivoire since 2004,
ethnic conflict there has displaced hun¬
dreds of thousands of Ivorians in and out
of the country as well as driven out
migrants from neighboring states who
worked in Ivorian cocoa plantations;
Ivorian rebels reportedly hide along the
borders of neighboring states
Refugees and internally displaced per¬
sons: refugees (country of origin): 25,615
(Liberia)
IDPs: 709,000 (2002 coup; most IDPs are
in western regions) (2007)
Illicit drugs: illicit producer of cannabis,
mostly for local consumption; utility as a
narcotic transshipment point to Europe
reduced by ongoing political instability;
while rampant corruption and inade¬
quate supervision leave the banking
system vulnerable to money laundering,
the lack of a developed financial system
limits the country’s utility as a major
money-laundering center
Hi
HR
HR
HRV
191
HRV
.hr
43 00 N
17 00 E
45 10N
15 30 E
Arctic Ocean
60 00 N
86 00 W
Arctic Ocean
62 00 N
71 00 W
New Caledonia, Vanuatu
22 24 S
172 06 E
Portugal, Spain
40 00 N
5 00 W
Arctic Ocean
68 00 N
20 00 W
42 24 N
1831 E
45 27 N
18 00 E
45 48 N
15 58 E
Democratic Republic of
the Congo 15 00 S
30 00 E
Pacific Ocean
54 00 N
142 00 E
Pacific Ocean
60 00 N
157 30 E','e324848e88a48dcaebba612aa5297366d3fb7fa62071597d9ef8f87bf635dd12','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e581de0fb9b4936058649d461ed0086590db2ad445f093155a86dccf45e5b192',2009,'CU','Cuba','transnational-issues',382,'Dispufes— international: US Naval
Base at Guantanamo Bay is leased to US
and only mutual agreement or US aban¬
donment of the area can terminate the
lease
Trafficking in persons: current situation:
Cuba is a source country for women and
children trafficked for the purposes of
sexual exploitation and forced child
labor; Cuba is a major destination for sex
tourism, which largely caters to
European, Canadian, and Latin
American tourists and involves large
numbers of minors; there are reports that
Cuban women have been trafficked to
Mexico for sexual exploitation; forced
labor victims also include children
coerced into working in commercial agri¬
culture
tier rating: Tier 3 — Cuba does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so
Illicit drugs: territorial waters and air
space serve as transshipment zone for
US- and European-bound drugs; estab¬
lished the death penalty for certain drug-
related crimes in 1999
'' ''.''''■ ■■ / ,V... ''
f , -
CU
CU
CUB
192
CUB
• CU
20 00 N
75 08 W
23 08 N
82 22 W
21 40 N
82 50 W
Russia
43 30 N
43 30 E
21 40 N
82 50 W
21 40 N
82 50 W
Atlantic Ocean
21 45 N
85 45 W','073c6c2a7645203646dc8cd26fe05057850cd523a12ed08a2faf6c118094cbda','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf1d04acddbd6f55cebb74e9fe7562125c6471912fff0f03db84749f428bb93',2009,'CY','Cyprus','transnational-issues',383,'Background: A former British colony,
Cyprus became independent in 1960 fol¬
lowing years of resistance to British rule.
Tensions between the Greek Cypriot
majority and Turkish Cypriot minority
came to a head in December 1963, when
violence broke out in the capital of
Nicosia. Despite the deployment of UN
peacekeepers in 1964, sporadic inter-
communal violence continued forcing
most Turkish Cypriots into enclaves
throughout the island. In 1974, a Greek
Government-sponsored attempt to seize
control of Cyprus was met by military
intervention from Turkey, which soon
controlled more than a third of the
island. In 1983, the Turkish-held area
declared itself the “Turkish Republic of
Northern Cyprus” (TRNC), but it is rec¬
ognized only by Turkey. The latest two-
year round of UN -brokered
talks — between the leaders of the Greek
Cypriot and Turkish Cypriot communi¬
ties to reach an agreement to reunite the
divided island — ended when the Greek
Cypriots rejected the UN settlement
plan in an April 2004 referendum. The
entire island entered the EU on 1 May
2004, although the EU acquis — the body
of common rights and obligations —
applies only to the areas under direct
government control, and is suspended in
174
the areas administered by Turkish
Cypriots. However, individual Turkish
Cypriots able to document their eligi¬
bility for Republic of Cyprus citizenship
legally enjoy the same rights accorded to
other citizens of European Union states.
The election of a new Cypriot president
in 2008 served as the impetus for the UN
to encourage both the Turkish and
Cypriot Governments to reopen unifica¬
tion negotiations.
Disputes— international: hostilities in
1974 divided the island into two de facto
autonomous entities, the internationally
recognized Cypriot Government and a
Turkish-Cypriot community (north
Cyprus); the 1,000-strong UN
Peacekeeping Force in Cyprus
(UNFICYP) has served in Cyprus since
1964 and maintains the buffer zone
between north and south; on 1 May
2004, Cyprus entered the European
Union still divided, with the EU’s body
of legislation and standards (acquis com-
munitaire) suspended in the north
Refugees and internally displaced per¬
sons: IDPs: 210,000 (both Turkish and
Greek Cypriots; many displaced for over
30 years) (2007)
Trafficking in persons: current situation:
Cyprus is primarily a destination country
for a large number of women trafficked
from Eastern and Central Europe, the
Philippines, and the Dominican
Republic for the purpose of sexual
exploitation; traffickers continued to
fraudulently recruit victims for work as
dancers in cabarets and nightclubs on
short-term “artiste” visas, for work in
178
CZECH REPUBLIC
pubs and bars on employment visas, or
for illegal work on tourist or student
visas; there were credible reports of
female domestic workers from India, Sri
Lanka, and the Philippines forced to
work excessively long hours and denied
proper compensation
tier rating: Tier 2 Watch List — Cyprus
does not fully comply with the minimum
standards for the elimination of traf¬
ficking and failed to show evidence of
increasing efforts to address its serious
trafficking for sexual exploitation
problem; however, it is making signifi¬
cant efforts to do so
Illicit drugs: minor transit point for
heroin and hashish via air routes and
container traffic to Europe, especially
from Lebanon and Turkey; some cocaine
transits as well; despite a strengthening
of anti-money-laundering legislation,
remains vulnerable to money laundering;
reporting of suspicious transactions in
offshore sector remains weak
CZECH REPUBLIC
Background: Following the First World
War, the closely related Czechs and
Slovaks of the former Austro-Hungarian
Empire merged to form Czechoslovakia.
During the interwar years, the new
country’s leaders were frequently preoc¬
cupied with meeting the demands of
other ethnic minorities within the
republic, most notably the Sudeten
Germans and the Ruthenians
(Ukrainians). After World War II, a
truncated Czechoslovakia fell within the
Soviet sphere of influence. In 1968, an
invasion by Warsaw Pact troops ended
the efforts of the country’s leaders to lib¬
eralize Communist party rule and create
“socialism with a human face.” Anti-
Soviet demonstrations the following year
ushered in a period of harsh repression.
With the collapse of Soviet authority in
1989, Czechoslovakia regained its
freedom through a peaceful “Velvet
Revolution.” On 1 January 1993, the
country underwent a “velvet divorce
into its two national components, the
Czech Republic and Slovakia. The
Czech Republic joined NATO in 1999
and the European Union in 2004-
CY
CY
CYP
196
CYP
.cy
Czech Republic
EZ
CZ
CZE
203
CZE
• CZ
35 00 N
33 00 E
Atlantic Ocean
53 53 N
9 08 E
35 00 N
33 00 E
35 10N
33 22 E
796
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Leipzig (city)
Lemnos (island)
Leningrad (city; former name for Saint Petersburg)
Lesser Sunda islands
Lesvos (island)
Leyte (island)
Liancourt Rocks (claimed by Japan)
Liaodong Wan (gulf)
Liban (local name for Lebanon)
Libreville (capital)
Lietuva (local name for Lithuania)
Ligurian Sea
Lilongwe (capital)
Lima (capital)
Lincoln Sea
Line Islands
Lion, Gulf of
Lisbon (capital)
Little Belt (strait; also Lille Baelt)
Ljubljana (capital)
Llanos (region)
Lobamba (city)
Lombok (island)
Lombok Strait
Lome (capital)
London (capital)
Longyearbyen (capital)
Lord Howe Island
Lorraine (region)
Louisiade Archipelago
Lourenco Marques (city; former name for Maputo)
Loyalty Islands (lies Loyaute)
Luanda (capital)
Lubnan (local name for Lebanon)
Lubumbashi (city)
Lusaka (capital)
Luxembourg (capital)
Luzon (island)
Luzon Strait
Lyakhov Islands
35 10N
33 22 E
Saint Helena
37 25 S
12 30 W
35 15 N
33 44 E
Albania, Greece
40 00 N
20 30 E
Saint Vincent and the
12 45 N
61 15 W
Grenadines
Beirut
LEBANON *
I laifa/r,
ISRAEL |
Port Jerusalem ft
■'' Said
•& iSr4; *
h; -
Isfahan
sosm
Tabuk
Ai Jubayl-,
Ad Dammam. Manama
Dhuhrnn * *
bahkavC .QATAR
Doha*
Buravdah
Luxor
jf ’■ f>MArt
, Dubai
Abu *
Dhabi.
Riyadh
Muscat
Aswan
SAUDI
UNITED ARAB
EMIRATES
Yanbu''
ai Baju
BuatKtarv
Jidda Ir,
Port Sudan
Salatah
ERITREA Massawa
* -S''.,
Asmara * d
Sanaa
\\l
Hudaydah
I Al Mttkalia
DJiBOMi
tk Djibouti
''
&! XT Atrxsi IBS m}
I linn
MIDDLE EAST
TURKEY , .
* - , - _v4
* t/ ''.■/ .OiyarbaSn. .Tabnz
'' '' Antalya *<> ’ 7-’ \\
* «° Adana Qiziantep :/./ A
UKR. Krasnodar
RUSSIA
Gora Elbrus
po&Np
Slack. Sea','a332863f556fd4f3a098a129bde77edece8e4d48dfef513e3aefe0e9db70451a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcb33bb7eed39f30ebcc9f74bf8e8943a72ffcfbd99a615c7dee5bcbd5ad76f2',2009,'DE','Germany','transnational-issues',397,'Disputes— international: in 2006,
Austrian public protests for the Czech
Republic to close the Temelin nuclear
power plant resulted in an Austrian par¬
liamentary motion threatening interna¬
tional legal action
Illicit drugs: transshipment point for
Southwest Asian heroin and minor
transit point for Fatin American cocaine
to Western Europe; producer of synthetic
drugs for local and regional markets; sus¬
ceptible to money laundering related to
drug trafficking, organized crime; signifi¬
cant consumer of ecstasy
182
Background: Once the seat of Viking
raiders and later a major north European
power, Denmark has evolved into a
modern, prosperous nation that is partic-
ipating in the general political and eco-
nomic integration of Europe. It joined
NATO in 1949 and the EEC (now the
EU) in 1973. However, the country has
opted out of certain elements of the
European Union’s Maastricht Treaty,
including the European Economic and
Monetary Union (EMU), European
defense cooperation, and issues con¬
cerning certain justice and home affairs.
Disputes — international: none
Illicit drugs: source of precursor chemi¬
cals for South American cocaine proces¬
sors; transshipment point for and
consumer of Southwest Asian heroin,
Latin American cocaine, and European-
produced synthetic drugs; major finan¬
cial center
Winterthur
Sankt
Gallon
ZOrich
TRIA
Lucerne
BERN
Frtbowg
, tausanne
Land boundaries:
total: 1,852 km
border countries: Austria 164 km, France
573 km, Italy 740 km, Liechtenstein 41
km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, but varies with alti¬
tude; cold, cloudy, rainy/snowy winters;
cool to warm, cloudy, humid summers
with occasional showers
Terrain: mostly mountains (Alps in
south, Jura in northwest) with a central
plateau of rolling hills, plains, and large
lakes
Elevation extremes:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower poten¬
tial, timber, salt
Land use:
arable land: 9.91%
permanent crops: 0.58%
other: 89.51% (2005)
Irrigated land: 250 sq-km (2003)
Total renewable water resources: 53.3
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.52 cu
km/yr (24%/74%/2%)
per capita: 348 cu m/yr (2002)
Natural hazards: avalanches, landslides,
flash floods
Environment — current issues: air pollu¬
tion from vehicle emissions and open-air
burning; acid rain; water pollution from
increased use of agricultural fertilizers;
loss of biodiversity
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Law of the Sea
Geography — note: landlocked; cross¬
roads of northern and southern Europe;
along with southeastern France,
northern Italy, and southwestern
Austria, has the highest elevations in the
Alps
Population: 7,581,520 (July 2008 est.)
Age structure:
0-14 years: 15.8% (male 623,213/female
577,430)
15-64 years: 68.2% (male
2,605,044/female 2,562,354)
65 years and over: 16% (male
501,699/female 711,780) (2008 est.)
Median age:
total: 40.7 years
male: 39.6 years
female: 41.7 years (2008 est.)
Population growth rate: 0.329% (2008
est.)
Birth rate: 9.62 births/1,000 population
(2008 est.)
Death rate: 8.54 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 2.21 migrants )/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.97 male(s)/female
(2008 est.)
Infant mortality rate:
total: 4-23 deaths/1,000 live births
male: 4.71 deaths/1,000 live births
female: 3.73 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 80.74 years
male: 77.91 years
female: 83.71 years (2008 est.)
Total fertility rate: 1.44 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.4%
(2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 13,000 (2001 est.)
HIV/AIDS — deaths: fewer than 100
(2003 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French
18%, Italian 10%, Romansch 1%, other
6%
Religions: Roman Catholic 41.8%,
Protestant 35.3%, Muslim 4.3%,
Orthodox 1.8%, other Christian 0.4%,
other 1%, unspecified 4.3%, none 11.1%
(2000 census)
Languages: German (official) 63.7%,
French (official) 20.4%, Italian (official)
6.5%, Serbo-Croatian 1.5%, Albanian
1.3%, Portuguese 1.2%, Spanish 1.1%,
English 1%, Romansch (official) 0.5%,
other 2.8% (2000 census)
note: German, French, Italian, and
Romansch are all national and official
languages
Literacy:
definition: age 15 and over can read and
write
total population: 99%
male: 99%
female: 99% (2003 est.)
GM
DE
48 30 N
11 30 E
Atlantic Ocean
54 53 S
68 10 W
Svalbard
74 26 N
19 05 E
Arctic Ocean
73 00 N
140 00 W
52 31 N
13 24 E
52 30 N
13 33 E
52 30 N
13 20 E
787
THE CIA WORLD FACTBOOK
Name
Bern (capital)
Bessarabia (region)
Bharat (local name for India)
Bhopal (city)
Biafra (region)
Big Diomede Island
Bijagos, Arquipelago dos (island group)
Bikini Afoii
Bilbao (city)
Bioko (island)
Biscay, Bay of
Bishkek (capital)
Bishop Rock
Bismarck Archipelago (island group)
Bismarck Sea
Bissau (capital)
Bjornoya (Bear Island)
Black Forest (region)
Black Rock (island)
Black Sea
Bloemfontein (judicial capital)
Bo Hai (gulf)
Boa Vista (island)
Bogota (capital)
Bohemia (region)
Bombay (city; see Mumbai)
Bonaire (island)
Bonifacio, Strait of
Bonin Islands
Bonn (former capital)
Bophuthatswana (region; enclave)
Bora-Bora (island)
Bordeaux (city)
Borneo (island)
Bornholm (island)
Bosna i Hercegovina (local name for Bosnia
and Herzegovina)
Bosnia (political region)
Bosporus (strait)
Bothnia, Gulf of
Bougainville (island)
Bougainville Strait
Bounty Islands
Bourbon Island (former name of Reunion)
Brasilia (capital)
Bratislava (capital)
Brazzaville (capital)
Bridgetown (capital)
Brisbane (city)
Bristol Bay
Bristol Channel
Britain (see Great Britain)
British Bechuanaland (region; former name
for northwest South Africa)
British Central African Protectorate
(former name of Nyasaland)
British East Africa (former name for British possessions
in eastern Africa)
British Guiana (former name for Guyana)
British Honduras (former name for Belize)
British Solomon Islands (former name for Solomon Islands)
British Somaliland (former name for northern Somalia)
Brussels (capital)
Bubiyan (island)
Bucharest (capital)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
48 00 N
8 15 E
South Georgia and the
53 39 S
41 48 W
South Sandwich Islands
Atlantic Ocean
43 00 N
35 00 E
50 44 N
7 05 E
51 00 N
9 00 E
51 13 N
6 47 E
53 44 N
7 25 E
52 00 N
13 00 E
Pacific Ocean
34 00 N
129 00 E
50 07 N
8 41 E
Russia
81 00 N
55 00 E
52 00 N
13 00 E
51 00 N
9 00 E
53 34 N
9 59 E
51 21 N
12 23 E
48 08 N
11 35 E
49 25 N
7 00 E
51 00 N
13 00 E
54 31 N
9 33 E
803
THE CIA WORLD FACTBOOK
Name
Schweiz (local German name for Switzerland)
Scopus, Mount
Scotia Sea
Scotland (region)
Scott Island
Senegambia (region; former name of confederation
of Senegal and The Gambia)
Senyavin Islands
Seoul (capital)
Serendib (former name for Sri Lanka)
Serrana Bank (shoal)
Serranilla Bank (shoal)
Settlement, The (capital)
Severnaya Zemlya (island group; also Northland)
Shaba (region)
Shag Island
Shag Rocks
Shanghai (city)
Shenyang (city; also Mukden)
Shetland Islands
Shikoku (island)
Shikotan (island)
Shqiperia (local name for Albania)
Siam (former name for Thailand)
Siberia (region)
Sibufu Passage
Sicily (island)
Sicily, Strait of
Sidra, Gulf of
Sikkim (state)
Siiesia (region)
Sinai Peninsula
Singapore (capital)
Singapore Strait
Sinkiang (autonomous region; also Xinjiang)
Sint Eustatius (island)
Sint Maarten (island; also Saint-Martin)
Sjaelland (island)
Skagerrak (strait)
Skopje (capital)
Slavonia (region)
Slovenija (local name for Slovenia)
Slovensko (local name for Slovakia)
Smyrna (region; former name for Izmir)
Society Islands (lies de la Societe)
Socotra (island)
Sofia (capital)
Solomon Islands, northern
Solomon Islands, southern
Solomon Sea
Somaliland (region)
Somers Islands (former name for Bermuda)
Songkhla (city)
Sound, The (strait; also Oresund)
South Atlantic Ocean
South China Sea
South Georgia (island)
South Island
South Korea
South Orkney Islands
South Ossetia (region)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
48 46 N
9 11 E
Bolivia
19 02 S
65 17 W
51 00 N
11 00 E
53 22 N
5 20 E','58431e067ce20af6df842f965f84a950d06b0079dcfc8db839b616c59a475b31','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acc8417113060be5dc24cb47d9664c39ee348531bc298c7c254c33d1f2d27d5d',2009,'DK','Denmark','transnational-issues',404,'Disputes — international: Iceland, the
UK, and Ireland dispute Denmark’s
claim that the Faroe Islands’ continental
shelf extends beyond 200 nm; Faroese
continue to study proposals for full inde¬
pendence; sovereignty dispute with
Canada over Hans Island in the Kennedy
Channel between Ellesmere Island and
DA
DK
DNK
208
DNK
.dk
55 10N
15 00 E
55 40 N
12 35 E
Pacific Ocean
15 00 S
150 00 E
56 00 N
10 00 E
55 20 N
10 25 E
56 00 N
9 15 E
55 30 N
12 00 E
Atlantic Ocean
57 45 N
9 00 E
Macedonia
41 59 N
21 26 E','50836d10c38f5abd46a835f2fc608eeb1dffe706df7841d65f36bd34a09b1adb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b0dd0994485c62f4755257edc7162b7558c4b6c04205c8f43804a76e33fabbf',2009,'GL','Greenland','transnational-issues',405,'DHEKELIA
GL
GL
64 11 N
51 44 W
Syria
33 00 N
35 45 E
72 00 N
40 00 W
Botswana, Namibia
24 30 S
21 00 E
64 11 N
51 44 W
A#J tOENMAKKf ;
Jan Mayen
(NORWAY! ,
/
/
trreeribmi
/ Sea
so
1 im m
1 lammcrfetab £
4W1
v-i j
Reykjavik
* ICELAND f
i '' .f
Wf~
Mo-rwegm i Sea
!
l— Araun
Barents
Stilt
em
w
**'' **
^ w.
4 f ^Murmansk
mb»
s r
, "yf.i
*r.
• '' !
gg
Kir unaS . ,;;/.
^ •
'' ''iffy**.','d04d6932f7775ca55a58f47cbbd875737be5016029a038327ac616029c2d3235','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0a3abb52fc68af35ecf8558038c8a5482cfad9e24f00c37bd234f4aa08d6e04',2009,'DM','Dominica','transnational-issues',414,'Disputes — international: Djibouti
maintains economic ties and border
accords with “Somaliland” leadership
while maintaining some political ties to
various factions in Somalia; thousands of
Somali refugees await repatriation in
UNHCR camps in Djibouti
Refugees and infernally displaced per¬
sons: refugees (country of origin): 8,642
(Somalia) (2007)
Trafficking in persons: current situation:
Djibouti is a source, transit, and destina¬
tion country for women and children
trafficked for the purposes of sexual
exploitation and possibly forced labor;
small numbers are trafficked from
Ethiopia and Somalia for sexual
exploitation; economic migrants from
these countries also fall victim to traf¬
ficking upon reaching Djibouti City or
the Ethiopia-Djibouti trucking corridor;
women and children from neighboring
countries reportedly transit Djibouti to
Arab countries and Somalia for ultimate
use in forced labor or sexual exploitation
tier rating: Tier 2 Watch List — Djibouti
does not fully comply with the minimum
standards for the elimination of traf¬
ficking; however, it is making significant
efforts to do so based partly on the gov¬
ernment’s commitments to undertake
future action
Disputes — international: Dominica is
the only Caribbean state to challenge
Venezuela’s sovereignty claim over Aves
Island and joins the other island nations
in challenging whether the feature sus¬
tains human habitation, a criterion
under the UN Convention on the Law of
the Sea (UNCLOS), which permits
Venezuela to extend its Exclusive
Economic Zone (EEZ) and continental
shelf claims over a large portion of the
eastern Caribbean Sea
Illicit drugs: transshipment point for
narcotics bound for the US and Europe;
minor cannabis producer; anti-money-
laundering enforcement is weak, making
the country particularly vulnerable to
money laundering
DO
DM
DMA
212
DMA
.dm
15 18 N
61 24 W','5537094bb3fae11848960bce7b62513e62f8ebc014935412a6e3fef062d75199','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d119c2bcfdb96157ffde4b52aa1cf557b051cd4cbd38d91efa86ac0e79f32e',2009,'DO','Dominican Republic','transnational-issues',419,'Background: Explored and claimed by
Christopher COLUMBUS on his first
voyage in 1492, the island of Hispaniola
became a springboard for Spanish con¬
quest of the Caribbean and the
American mainland. In 1697, Spain rec¬
ognized French dominion over the
western third of the island, which in
1804 became Haiti. The remainder of
the island, by then known as Santo
Domingo, sought to gain its own inde¬
pendence in 1821, but was conquered
and ruled by the Haitians for 22 years; it
finally attained independence as the
Dominican Republic in 1844. In 1861,
the Dominicans voluntarily returned to
the Spanish Empire, but two years later
they launched a war that restored inde¬
pendence in 1865. A legacy of unsettled,
mostly non-representative rule followed,
capped by the dictatorship of Rafael
Leonidas TRUJILLO from 1930-61.
Juan BOSCH was elected president in
1962, but was deposed in a military coup
in 1963. In 1965, the United States led
an intervention in the midst of a civil
war sparked by an uprising to restore
BOSCH. In 1966, Joaquin BALAGUER
defeated BOSCH in an election to
become president. BALAGUER main¬
tained a tight grip on power for most of
the next 30 years when international
reaction to flawed elections forced him
to curtail his term in 1996. Since then,
regular competitive elections have been
held in which opposition candidates
have won the presidency. Former
President (1996-2000) Leonel FER¬
NANDEZ Reyna won election to a
second term in 2004 following a consti¬
tutional amendment allowing presidents
to serve more than one term.
Disputes — international: Haitian
migrants cross the porous border into the
Dominican Republic to find work; illegal
migrants from the Dominican Republic
cross the Mona Passage each year to
Puerto Rico to find better work
Illicit drugs: transshipment point for
South American drugs destined for the
US and Europe; has become a transship¬
ment point for ecstasy from the
Netherlands and Belgium destined for
US and Canada; substantial money laun¬
dering activity; Colombian narcotics
traffickers favor the Dominican Republic
for illicit financial transactions; signifi¬
cant amphetamine consumption
195
DR
DO
DOM
214
DOM
.do
19 00 N
70 40 W
18 28 N
69 54 W','b7fc647e90cb965c9580c733a7af529d0625ac50e48e93f703a9b0d797fbeca9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9ca707dd742da0faa1951b493c8f8156954075829d56140f98760aaf0b1d163',2009,'EG','Egypt','transnational-issues',439,'Disputes— international: while Sudan
retains claim to the Hala’ib Triangle
north of the 1899 Treaty boundary along
the 22nd Parallel, both states withdrew
their military presence in the 1990s and
Egypt has invested in and effectively
administers the area; Egypt vigilantly
monitors the Sinai and borders with
Israel and the Gaza Strip to deter ter¬
rorist, smuggling, and other illegal activ¬
ities; Egypt does not extend domestic
asylum to some 70,000 persons who
identify themselves as Palestinians but
who largely lack UNRWA assistance
and, until recently, UNHCR recognition
as refugees
Refugees and internally displaced per¬
sons: refugees ( country of origin):
60,000— 80,000 (Iraq); 70,198
(Palestinian Territories); 12,157 (Sudan)
(2007)
Trafficking in persons: current situation:
Egypt is a transit country for women traf¬
ficked from Eastern Europe to Israel for
the purpose of sexual exploitation; these
women generally arrive as tourists and
are subsequently trafficked through the
Sinai Desert by Bedouin tribes; men and
women from sub-Saharan Africa and
Asia are believed to be trafficked
through the Sinai Desert to Israel and
Europe for labor exploitation; some
Egyptian children from rural areas are
trafficked within the country to work as
domestic servants or laborers in the agri¬
culture industry
tier rating: Tier 2 Watch List — Egypt is
placed on the Tier 2 Watch List for its
failure to show evidence of increasing
efforts to address trafficking over the past
year, particularly in the area of law
enforcement
Illicit drugs: transit point for cannabis,
heroin, and opium moving to Europe,
Israel, and North Africa; transit stop for
Nigerian drug couriers; concern as
money laundering site due to lax
enforcement of financial regulations
202
Background: El Salvador achieved inde-
pendence from Spain in 1821 and from
the Central American Federation in
1839. A 12''year civil war, which cost
about 75,000 lives, was brought to a close
in 1992 when the government and leftist
rebels signed a treaty that provided for
military and political reforms.
EG
EG
EGY
818
EGY
•eg
31 12 N
29 54 E
30 03 N
31 15 E
30 13 N
33 09 E
30 20 N
32 23 E
27 00 N
30 00 E
30 02 N
32 54 E
29 30 N
34 00 E
29 55 N
32 33 E
Indian Ocean
28 10N
33 27 E','4e79140b217c54245a916c856501a72f84cc449552fd16ea926b0e561832b141','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed4ad4ac22da6207e0496450a3b77f58578c567afadcdbb1aa673e0dc372bb68',2009,'SV','El Salvador','transnational-issues',443,'Disputes — international: International
Court of Justice (ICJ) ruled on the
delimitation of “bolsones” (disputed
areas) along the El Salvador-Honduras
boundary, in 1992, with final agreement
by the parties in 2006 after an
Organization of American States (OAS)
survey and a further ICJ ruling in 2003;
the 1992 ICJ ruling advised a tripartite
resolution to a maritime boundary in the
Gulf of Fonseca advocating Honduran
access to the Pacific; El Salvador con¬
tinues to claim tiny Conejo Island, not
identified in the ICJ decision, off
Honduras in the Gulf of Fonseca
Illicit drugs: transshipment point for
cocaine; small amounts of marijuana pro¬
duced for local consumption; significant
use of cocaine
205
ES
SV
SLV
222
SLV
.sv
13 42 N
89 12 W
824
REFERENCE MAPS
ri.INi
■HR
''
mmm
mmm;.
mmm
y yy
Wi
< : >..
WS0M
■ . '' ''
wmm
,.>Ky m
" : ■ ■
wMM.
■ "<•■ -V- ''• S?A i
mmmmm
:
WmSmm*
■''
OCEANIA
825
THE CIA WORLD FACTBOOK
PHYSICAL MAP OF THE WORLD
■ A'' . k‘v ■"
|f|gPf
WMB '':
:; * ;
■ illijlf
■ '' ■ .
SMsMirsi
■■ W: aa
i 1 1
* r % 7.
Ill t fi!
■< || , m wm f & I ,y^ I * is.KtMi v&p, v ,; w- , ** - /, ?• &
■sp
\\j*
lliflliil
AT
IS
A
.; - . ■:•• .{. _ ;.'' ;
.'',4V<''^^ ''j>Xy M
ll
) u
'' -
1
MlMl
It
mmrnMmmm.
■
:!m; ■
l:|!^:''!l|y|:
. ■ A ‘ '' '' V '' ''
till®
, - t
lill
i
yyy
:>''L: ■ : ■
5& ■ .. ''■
A
II
■HI
Illllliiiiill . I
• X
mmmm yy
■ptfi
BH
11111111
;
%
:
;y »
■
I: :
-Si
IP;
. P-™ ,
% :
iffe
«8fP
%
S:!u;;5» ;
Mi l-li :
h * >!
1§ !
H|
I
: :f. ; -
*1
?
1 f-H | w - m . N i 1#
V-, '' A , ?; V. 1 A ~ -''
r •■. v. ■*.*:, *|
■ ;! |HB mk m m 1 MMBI
k$''*M |8 IMH
■lyi’ 1 1
■ V .. ''
ili *
-
■A f-
? ... ■•■■• ■
^A.-;,-.- > *. . .w •■ .* ,- - . J
Ip
■
yj
V ■: !
1 1 .■''*•.<» •!
.. ■
pA ■§> ■" X'' , r<- '' V '' y '' ^
:.:.'' -■■■:. :y
£ : ?&■:>■ ■” ’ ■■■: ~ '':;•:> •■■: :■.
■-
A . .
s •{? ■■
!lll
1
; y §pl J ■ ^| t
WmmmMmM w pJHB p*# «
5 xxSm#\\ y, V •4j|^ ,s^x ^VJi|s
./ '' '' A-
Jr ■
■ Br
^ , . -. .v
Mgap|S|^o >v= 1
■
- -■ • ■ '' 5
"'' «%. . ,''XV'' *■ §A Pp
'' " , ypy y :
. ''*> % -
w
;
1
;
/
'' a .^1
■Ml
, ..
y
826
Physical Map of the World
REFERENCE MAPS
POLITICAL MAP OF THE WORLD
827
Political Map of the World
THE CIA WORLD FACTBOOK
SOUTH AMERICA
msJK* m Panama > ri\\ .
L-n,T. ip*\\ „ ‘-tteuta G> Ciudad "
^“-‘VEPlteUElSr* ! ^“,g"°P™a™,r1b.
I^sr/V7jS '' : GUYANA "7,..
V G u ) A ^ / ^Cayenne
? *. # * << . - */i:. ''SURINAME''- Prcncrf)
^ r-M « Zf .
Martinique (TRANCE)^'' go
Caribbean Sea st. lucia 4 j
, , | , , , Mififlands st. V®CCHT Afl© « | bakbaous
IsIqUc . Aruba Antlifes THE GRENADINES j
/V/ i f - ; Smi Andres <«fci«-U ''.mew !
'' JlJA (COLOMBIA) {\\ v '' ORCNADA
ua „ ... s'' A ’J '' , r-ir-wKs gj*U4of-Spain
Barranquilta . ^raca^. ..A*™**;
Cartagena* 7
. T
40
in fose
Caracas
- ... , r”" J3BT J!§ TRINIDAD AMD
* Valencia'' tobago
Barqalsinioto V, a
'' Medeilfft X
K I , V* I" L
|\\ O f if!
A 1 1 a ?i 1 1 c
ucfia ft
fsfc? tie Mnlpelo
{COLOMBIA)
* COLOMBIA
4 *4
Boa Vista.
Guiana
j (FRANCE)
£qus®C
t Quito
"''*yr
; ECi§DOR
''{ ’// .
V I) i
XC ? > yzj '' df >'' %
ur|.>: -. ; % / -
t (AmW'' i
Trujillo*
! :
i ■
AMAZON
:.M JH(d J;
■ XA
lquitos.,
1SB
BASIN
Manaus
■IfeM o
Bekm *>
— o
; ''Santaremv
C Sac Luis
.Fortaleza
lire -ant
5 o u t h \\
Fad 1 1 c \\
O c e a m
Huanuco','4ff8cd388dc09a80475eeda128ac01b45f6f64f94e537f5a4350dd8644612215','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f9e657af0dc66814272299641b08ca414df63c22e11958c1880d478c893ae9',2009,'ER','Eritrea','transnational-issues',457,'Disputes— international: Eritrea and
Ethiopia agreed to abide by 2002
Ethiopia-Eritrea Boundary Commission’s
(EEBC) delimitation decision but, nei¬
ther party responded to the revised line
detailed in the November 2006 EEBC
Demarcation Statement; UN
Peacekeeping Mission to Ethiopia and
Eritrea (UNMEE), which has monitored
the 25-km-wide Temporary Security
Zone in Eritrea since 2000, is extended
for six months in 2007 despite Eritrean
restrictions on its operations and reduced
force of 17,000; Sudan accuses Eritrea of
supporting eastern Sudanese rebel groups
Refugees and internally displaced per¬
sons: IDPs: 32,000 (border war with
Ethiopia from 1998— 2000; most IDPs are
near the central border region) (2007)
211
ER
ER
ERI
232
ERI
.er
15 20 N
38 53 E
15 00 N
39 00 E','4329233dc7fd4fed4c2d05edff9ccbd256cfa9a6c08784c47a034602adc029e8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('603f0730cee982d7558a810045d2adc98b3f34e78f5b81a0269d49d6f7010344',2009,'EE','Estonia','transnational-issues',463,'Disputes— international: Russia
recalled its signature to the 1996 tech-
214
EN
EE
EST
233
EST
.ee
59 00 N
26 00 E
58 50 N
22 30 E
Dominican Republic, Haiti
18 45 N
71 00 W
Vietnam
10 45 N
106 40 E
58 25 N
22 30 E
Netherlands Antilles
17 38 N
63 10W
59 25 N
24 45 E
805
THE CIA WORLD FACTBOOK
Entry in Latitude Longitude
Name _ The World Factbook (deg min) (deg min)
Tanganyika (former name for the mainland portion of Tanzania) Tanzania 6 00 S 35 00 E
Tangier (city)
Tannu-Tuva (region)
Tarawa (island)
Tartary, Gulf of
Tashkent (capital)
Tasman Sea
Tasmania (island)
Tatar Strait
Taymyr Peninsula (Poluostrov Taymyr)
Tchad (local name for Chad)
Tegucigalpa (capital)
Tehran (capital)
Tel Aviv (capital, de facto)
Teluk Bone (gulf)
Teluk Tomini (gulf)
Terre Adelie (claimed by France; also Adelie Land)
Terres Australes et Antarctiques Francoises (local name
for the French Southern and Antarctic Lands)
Thailand, Gulf of
The Former Yugoslav Republic of Macedonia
Thessaloniki (city; also Salonika)
Thimphu (capital)
Thuringia (region)
Thurston Island
Tiberias, Lake
Tibet (autonomous region; also Xizang)
Tibilisi (see Tbilisi)
Tien Shan (mountains)
Tierra del Fuego (island, island group)
Timor (island)
Timor Lorosa''e (local name for Timor-Leste)
Timor Sea
Tinian (island)
Tiran, Strait of
Tirana, Tirane (capital)
Tirol, Tyrol (region)
Tobago (island)
Tokyo (capital)
Tonkin, Gulf of
Toronto (city)
Torres Strait
Torshavn (capital)
Toshkent (see Tashkent)
Transcarpathia (region; alternate name for Carpatho-Ukraine)
Transjordan (former name for Jordan)
Transkei (enclave)
Transvaal (region; former name for northeastern South Africa)
Transylvania (region)
Trindade, liha de (island)
Trinidad (island)
Tripoli (capita!)
Tripoli (city)
Tripolitania (region)
Tristan da Cunha Group (island group)
Trobriand Islands
Trucial Coast (former name for the United Arab Emirates)
Trucial Oman (former name for the United Arab Emirates)
Trucial States (former name for the United Arab Emirates)
Truk Islands (former name for the Chuuk Islands)
Tsugaru Strait
Tuamotu Islands (lies Tuamotu)
Tubuai Islands (lies Tubuai)
Tunb al Kubra (island)
Tunb as Sughra (island)
Tunis (capital)','13b1aee2d23d5636cc09b738bb446049a98f49c2a1c2134202e08d4672f4413f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91777fec3e23844b7087088ace01dbc38bec7eedcad6eb518940dba1dc9034fc',2009,'ET','Ethiopia','transnational-issues',464,'nical border agreement with Estonia in
2005, rather than concede to Estonia’s
appending prepared a unilateral declara¬
tion referencing Soviet occupation and
territorial losses; Russia demands better
accommodation of Russian-speaking
population in Estonia; Estonian citizen
groups continue to press for realignment
of the boundary based on the 1920 Tartu
Peace Treaty that would bring the now
divided ethnic Setu people and parts of
the Narva region within Estonia; as a
member state that forms part of the EU’s
external border, Estonia must implement
the strict Schengen border rules with
Russia
Illicit drugs: growing producer of syn¬
thetic drugs; increasingly important
transshipment zone for cannabis,
cocaine, opiates, and synthetic drugs
since joining the European Union and
the Schengen Accord; potential money
laundering related to organized crime
and drug trafficking is a concern, as is
possible use of the gambling sector to
launder funds; major use of opiates and
ecstasy
Background: Unique among African
countries, the ancient Ethiopian
monarchy maintained its freedom from
colonial rule with the exception of the
1936-41 Italian occupation during
World War II. In 1974, a military junta,
the Derg, deposed Emperor Haile
SELASSIE (who had ruled since 1930)
and established a socialist state. Tom by
bloody coups, uprisings, wide-scale
drought, and massive refugee problems,
the regime was finally toppled in 1991 by
a coalition of rebel forces, the Ethiopian
People’s Revolutionary Democratic
Front (EPRDF). A constitution was
adopted in 1994, and Ethiopia’s first mul¬
tiparty elections were held in 1995. A
border war with Eritrea late in the 1990s
ended with a peace treaty in December
2000. The Eritrea-Ethiopia Border
Commission in November 2007
remotely demarcated the border by geo¬
graphical coordinates, but final demarca¬
tion of the boundary on the ground is
currently on hold because of Ethiopian
objections to an international commis¬
sion’s finding requiring it to surrender
territory considered sensitive to
Ethiopia.
Disputes— international: Eritrea and
Ethiopia agreed to abide by the 2002
Eritrea-Ethiopia Boundary Commission’s
(EEBC) delimitation decision, but nei¬
ther party responded to the revised line
detailed in the November 2006 EEBC
Demarcation Statement; UN
Peacekeeping Mission to Ethiopia and
Eritrea (UNMEE), which has monitored
the 25-km-wide Temporary Security
Zone in Eritrea since 2000, is extended
for six months in 2007 despite Eritrean
restrictions on its operations and reduced
force of 17,000; the undemarcated former
British administrative line has little
meaning as a political separation to rival
clans within Ethiopia’s Ogaden and
southern Somalia’s Oromo region;
Ethiopian forces invaded southern
Somalia and routed Islamist Courts from
Mogadishu in January 2007;
“Somaliland” secessionists provide port
facilities in Berbera and trade ties to land¬
locked Ethiopia; civil unrest in eastern
Sudan has hampered efforts to demarcate
the porous boundary with Ethiopia
Refugees and infernally displaced per¬
sons: refugees (country of origin): 66,980
(Sudan); 16,576 (Somalia); 13,078
(Eritrea)
IDPs: 200,000 (border war with Eritrea
from 1998-2000, ethnic clashes in
Gambela, and ongoing Ethiopian mili¬
tary counterinsurgency in Somali region;
most IDPs are in Tigray and Gambela
Provinces) (2007)
Illicit drugs: transit hub for heroin origi¬
nating in Southwest and Southeast Asia
and destined for Europe, as well as
cocaine destined for markets in southern
Africa; cultivates qat (khat) for local use
and regional export, principally to
Djibouti and Somalia (legal in all three
countries); the lack of a well-developed
financial system limits the country’s
utility as a money laundering center
218
Background: Although first sighted by
an English navigator in 1592, the first
landing (English) did not occur until
almost a century later in 1690, and the
first settlement (French) was not estab-
lished until 1764. The colony was turned
over to Spain two years later and the
islands have since been the subject of a
territorial dispute, first between Britain
and Spain, then between Britain and
Argentina. The UK asserted its claim to
the islands by establishing a naval gar-
rison there in 1833. Argentina invaded
the islands on 2 April 1982. The British
responded with an expeditionary force
that landed seven weeks later and after
fierce fighting forced an Argentine sun
render on 14 June 1982.
Disputes— international: Argentina,
which claims the islands in its constitu¬
tion and briefly occupied them by force
in 1982, agreed in 1995 to no longer seek
settlement by force; UK continues to
reject Argentine requests for sovereignty
talks
220
t&n,
TnzngtO
lodwar
Moyate
Marsabrt
NAIROBI
Machafcos
MaSindO
mmm
OCEAN
rmzm\\k
M>m
W8jir
/ v KENYA
J Bciorel ^ Meru
I • >N8kufu* HIGHLANDS
Garissa
ET
ET
ETH
231
ETH
xt
Europa Island
EU
-
-
-
-
administered as part of
Falkland Islands
FK
FK
FLK
238
FLK
.fk
French Southern and
Antarctic Lands; no ISO
codes assigned
(Islas Malvinas)
8 00 N
38 00 E
9 02 N
38 42 E
8 00 N
38 00 E
Cote d’Ivoire
8 00 N
5 00 W
8 00 N
38 00 E
China, North Korea
39 55 N
124 20 E
Cote d’Ivoire
6 49 N
5 17 W
Burma
16 47 N
96 10 E','80fed60074784541a048d9a89f2ee6a3b181508742f109dfe72d42b14f7a0ceb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f839e62a46a7356130de8f540551b3a77d172785695f7eb3345428f35a7c555f',2009,'PF','French Polynesia','transnational-issues',497,'Disputes — international: Madagascar
claims the French territories of Bassas da
India, Europa Island, Glorioso Islands,
and Juan de Nova Island; Comoros
claims Mayotte; Mauritius claims
Tromelin Island; territorial dispute
between Suriname and the French over¬
seas department of French Guiana;
France asserts a territorial claim in
Antarctica (Adelie Land); France and
Vanuatu claim Matthew and Hunter
Islands, east of New Caledonia
illicit drugs: metropolitan France: trans¬
shipment point for South American
cocaine, Southwest Asian heroin, and
European synthetics
French Guiana: small amount of mari¬
juana grown for local consumption;
minor transshipment point to Europe
Martinique: transshipment point for
cocaine and marijuana bound for the US
and Europe
Background: The French annexed var¬
ious Polynesian island groups during the
19th century. In September 1995, France
stirred up widespread protests by resuming
nuclear testing on the Mururoa atoll after
a three-year moratorium. The tests were
suspended in January 1996. In recent
years, French Polynesia’s autonomy has
been considerably expanded.
Disputes — international: none
235
FRENCH SOUTHERN AND ANTARCTIC LANDS
Disputes— international: French claim
to “Adelie Land” in Antarctica is not
recognized by the US
Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island (lies Eparses):
claimed by Madagascar
Tromelin Island (lies Eparses): claimed by
FP
PF
French Southern
and Antarctic
Lands
FS
TF
23 20 S
151 00 W
16 30 S
151 45 W
23 09 S
134 58 W
Pacific Ocean
3 00 S
107 00 E
9 00 S
139 30 W
17 32 S
149 34 W
15 00 S
140 00 W
Germany, Poland
53 40 N
15 35 E
Federated States of Micronesia
6 55 N
158 15 E
17 00 S
150 00 W
17 37 S
149 27 W
Taiwan
25 03 N
121 30 E
Pacific Ocean
24 00 N
119 00 E
19 00 S
142 00 W
23 00 S
150 00 W
Iran
26 14 N
55 19 E
Iran
26 14 N
55 09 E','3c61f23cfd984583b022219527a655aae97cb01de403fb06caf1bc7cf66139b5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a5755263d610812c271a569934f2731775e30815aa4c551870018fc61583219',2009,'MU','Mauritius','transnational-issues',504,'238
i
■■
Ms
*8itam /
EGUATGBiAi.
atmzA
*Qyem X
m® of
ThH CONGO
s%
LIBREVILLE
T>0wendo
O'' *Kar$gp
WafeotoL
Cap
1 ''umbar** ^stoursv^e
Koularooutou^
Mm
Ibom# Moanda#
Mouila FiancevMef
A
Gamba* Tchibangaf Qf
south mmnc r TMF rn{yr.0
OC©** IHfc LUNW
Ludna _ » 4 « «P
T#rrren8?
, Cargsc&s
Caraps SMsh,
m r»t sfom
0 2S S km
0f
Triole*
.Goodianas
>&**■
a, PORT LOUIS
'' f
. ns
Aj.
T amafin
s%r*
r V>
m
Centre*
de Flaoq
, Qoatre Barnes
.Curepipe
c7
« i /''
Ai
Uwun
Grenier
%:A., *
.SouTac
4 to
Mahebourg* .
‘ ■ :r '' #«&»
with regular free elections and a positive
human rights record, the country has
attracted considerable foreign invest¬
ment and has earned one of Africa’s
highest per capita incomes. Recent poor
weather, declining sugar prices, and
declining textile and apparel production,
have slowed economic growth, leading
to some protests over standards of living
in the Creole community.
MP
MU
MUS
480
MUS
.mu
10 25 S
56 40 E
16 25 S
59 38 E
Atlantic Ocean
15 00 N
73 00 W
Federated States of
7 30 N
148 00 E
Micronesia, Palau
20 10 S
57 30 E
19 42 S
63 25 E
16 25 S
59 38 E','20ea4d6432dc3a57ed92fdde66949bfb4f2db18051cd1d85e97a465c28cb82d7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1cbbf921015e8cb9845ad5b219395bdf85f54bcd3ae2c76cccb6ad63abe2d30',2009,'GA','Gabon','transnational-issues',514,'Disputes — international: UN urges
Equatorial Guinea and Gabon to resolve
the sovereignty dispute over Gabon-
occupied Mbane Island and lesser islands
and to establish a maritime boundary in
hydrocarbon-rich Corisco Bay
Refugees and internally displaced per¬
sons: refugees (country of origin): 7,178
(Republic of Congo) (2007)
241
GB
GA
Gambia, The
GA
GM
Gaza Strip
GZ
PS
0 23 N
9 27 E
1 00 S
11 45 E','fb538c65118e8803d3ba2751acee7928dd0cf626b36ac4637289529d2fddb989','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75f0d4478c1e005c54d7498f69b78b295c2452d14ee8aeae81cf460d524dfeea',2009,'GM','Gambia','transnational-issues',519,'Disputes— infernational: attempts to
stem refugees, cross-border raids, arms
smuggling, and other illegal activities by
separatists from southern Senegal’s
Casamance region, as well as from con¬
flicts in other west African states
Refugees and infernally displaced per¬
sons: refugees ( country of origin): 5,955
(Sierra Leone) (2007)
GAZA STRIP','bf82def144a590e86af93c1f5b3bcd1dbcdf3e95bf1b3848fa7ff1f63327458e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d854813161477ff51ffda468f454f768dcee3c20de9f062c33e1f1cb2fbafa3',2009,'IL','Israel','transnational-issues',528,'Disputes— international: West Bank
and Gaza Strip are Israeli-occupied with
current status subject to the Israeli-
Palestinian Interim Agreement — perma¬
nent status to be determined through
further negotiation; Israel removed set¬
tlers and military personnel from the
Gaza Strip in August 2005
Refugees and internally displaced per¬
sons: refugees (country of origin): 1.017
million (Palestinian Refugees
(UNRWA)) (2007)
Background: The region of present-day
Georgia contained the ancient kingdoms
of Colchis and Kartli-Iberia. The area
came under Roman influence in the first
centuries A.D. and Christianity became
the state religion in the 330s.
Domination by Persians, Arabs, and
Turks was followed by a Georgian golden
age (11th- 13th centuries) that was cut
short by the Mongol invasion of 1236.
Subsequently, the Ottoman and Persian
empires competed for influence in the
region. Georgia was absorbed into the
246
OLMERT became prime minister in
March 2006; following an Israeli military
operation in Gaza in June-July 2006 and
a 34''day conflict with Hizballah in
Lebanon in June-August 2006, he
shelved plans to unilaterally evacuate
from most of the West Bank. OLMERT
in June 2007 resumed talks with the PA
after HAMAS seized control of the Gaza
Strip and PA President Mahmoud
ABBAS formed a new government
without HAMAS.
IS
IL
32 54 N
35 20 E
Atlantic Ocean
11 00 N
60 55 W
792
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name _ _
Gambier islands (lies Gambier)
Gaspar Strait
Gdansk (city; formerly Danzig)
Geneva (city)
Genoa (city)
George Town (capital)
George Town (city)
George Town (city)
Georgetown (capital)
Georgetown (city)
German Democratic Republic (East Germany; former name
for eastern portion of Germany)
German Southwest Africa (former name for Namibia)
Germany, Federal Republic of
Gibraltar (city, peninsula)
Gibraltar, Strait of
Gidi Pass
Gilbert Islands
Goa (state)
Gobi (desert)
Godthab (capital; also Nuuk)
Golan Heights (region)
Gold Coast (former name for Ghana)
Golfo San Jorge (gulf)
Golfo San Mafias (gulf)
Good Hope, Cape of
Goteborg (city)
Gotland (island)
Gough Island
Graham Land (region)
Gran Chaco (region)
Grand Bahama (island)
Grand Banks (fishing ground)
Grand Cayman (island)
Grand Turk (capital; also Cockburn Town)
Great Australian Bight
Great Belt (strait; also Store Baelt)
Great Bitter Lake
Great Britain (island)
Great Channel
Great Inagua (island)
Great Rift Valley
Greater Sunda Islands
Green Islands
Greenland Sea
Grenadines, Northern (island group)
Grenadines, Southern (island group)
Grytviken (town; on South Georgia)
Guadalahara (city)
Guadalcanal (island)
Guadalupe, Isla de (island)
Guangzhou (city; also Canton)
Guantanamo Bay (US Naval Base)
Guatemala (capital)
Guine-Bissau (local name for Guinea-Bissau)
Guinea Ecuatorial (local name for Equatorial Guinea)
Guinea, Gulf of
Guinee (local name for Guinea)
Gustavia (capital)
Guyane Francaise (local name for French Guiana)
Ha''apai Group (island group)
Habomai Islands
Hadhramaut (region)
Hagatna (capital; formerly Agana)
Hague, The (seat of government)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
32 50 N
35 00 E
30 30 N
34 55 E
32 05 N
34 48 E
Pacific Ocean
4 00 S
120 45 E
Pacific Ocean
0 30 S
121 00 E
32 48 N
35 35 E
31 30 N
34 45 E','6ee4b6ec06ba1647a1fe758984c101e0ccdc691b5ae970a793eee1dcd2627b67','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af15ba4ccb7425c4199618dc8f099897451c6f66701896c39af063781a9336e2',2009,'GE','Georgia','transnational-issues',529,'Russian Empire in the 19th century.
Independent for three years
(1918-1921) following the Russian revo¬
lution, it was forcibly incorporated into
the USSR until the Soviet Union dis¬
solved in 1991. An attempt by the
incumbent Georgian government to
manipulate national legislative elections
in November 2003 touched off wide¬
spread protests that led to the resignation
of Eduard SHEVARDNADZE, president
since 1995. New elections in early 2004
swept Mikheil SAAKASHVILI into
power along with his National
Movement party. Progress on market
reforms and democratization has been
made in the years since independence,
but this progress has been complicated by
two ethnic conflicts in the breakaway
regions of Abkhazia and South Ossetia.
These two territories remain outside the
control of the central government and
are ruled by de facto, unrecognized gov¬
ernments, supported by Russia. Russian-
led peacekeeping operations continue in
both regions.
Disputes— international: Russia and
Georgia agree on delimiting 80% of their
common border, leaving certain small,
strategic segments and the maritime
boundary unresolved; OSCE observers
monitor volatile areas such as the Pankisi
Gorge in the Akhmeti region and the
Argun Gorge in Abkhazia; UN Observer
Mission in Georgia has maintained a
peacekeeping force in Georgia since
1993; Meshkheti Turks scattered
throughout the former Soviet Union
seek to return to Georgia; boundary with
Armenia remains undemarcated; ethnic
Armenian groups in Javakheti region of
Georgia seek greater autonomy from the
Georgian government; Azerbaijan and
Georgia continue to discuss the align¬
ment of their boundary at certain
crossing areas
Refugees and internally displaced per¬
sons: refugees (country of origin): 1,100
(Russia)
IDPs: 220,000-240,000 (displaced from
Abkhazia and South Ossetia) (2007)
Illicit drugs: limited cultivation of
cannabis and opium poppy, mostly for
domestic consumption; used as trans¬
shipment point for opiates via Central
Asia to Western Europe and Russia
_ GERMANY
GG
GE
43 00 N
41 00 E
41 45 N
42 10 E
42 30 N
41 52 E
42 00 N
43 30 E
Russia
51 00 N
143 00 E
42 20 N
44 00 E
804
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name _ _
South Pacific Ocean
South Sandwich Islands
South Shetland Islands
South Tyrol (region)
South Vietnam (former name for the southern portion
of Vietnam)
South Yemen (People''s Democratic Republic of Yemen;
now part of Yemen)
South-West Africa (former name for Namibia)
Southern Grenadines (island group)
Southern Rhodesia (former name for Zimbabwe)
Soviet Union (former name of a large Eurasian empire,
roughly coequal with the former Russian Empire)
Spanish Guinea (former name for Equatorial Guinea)
Spanish Morocco (former name for northern Morocco)
Spanish North Africa (exclaves)
Spanish Sahara (former name)
Spanish West Africa (former name for Ifni and Spanish Sahara)
Spice Islands (Moluccas)
Spitsbergen (island)
Srbija (local name for Serbia)
St. John''s (city)
Stanley (capital)
Stockholm (capital)
Strasbourg (city)
Stuttgart (city)
Sucre (constitutional capital)
Suez Canal
Suez, Gulf of
Suisse (local French name for Switzerland)
Sulawesi (island; Celebes)
Sulawesi Sea
Sulu Archipelago (island group)
Sulu Sea
Sumatra (island)
Sumba (island)
Sumba Strait
Sumbawa (island)
Sunda Islands (Soenda Isles)
Sunda Strait
Suomi (local name for Finland)
Surabaya (city)
Surigao Strait
Surinam (former name for Suriname)
Suriyah (local name for Syria)
Surtsey (volcanic island)
Suva (capital)
Sverdlovsk (city; also Yekaterinburg)
Sverige (local name for Sweden)
Svizzera (local Italian name for Switzerland)
Swains Island
Swan Islands
Sydney (city)
Tbilisi (capital)
Tadzhikistan (former name for Tajikistan)
Tahiti (island)
Taipei (capital)
Taiwan Strait
Tallinn (capital)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Pacific Ocean
30 00 S
130 00 W
South Georgia and the South
57 45 S
26 30 W
Sandwich Islands
41 43 N
44 49 E
41 43 N
44 49 E
China, Kyrgyzstan
42 00 N
80 00 E
Argentina, Chile
54 00 S
69 00 W
Timor-Leste, Indonesia
9 00 S
125 00 E','587a2c95312a2aaaf9d0b0070abc3cc1cb8b39c2f6b3a4321f5ae5d9bfbbc7bc','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65c4354de7b04412647030b98024f3c3a91bc0065a5816fc76b6167c9c58919',2009,'GH','Ghana','transnational-issues',537,'Tamale
GH
GH
5 33 N
0 13 W
Pitcairn Islands
25 04 S
130 05 W
8 00 N
2 00 W
Atlantic Ocean
46 00 S
66 00 W
Atlantic Ocean
41 30 S
64 00 W','6586991485a18d2a24edea22972350d48d94d58aea8008ab5e4c2db28684d5a5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe61801f2c8e8d5a9fc7de7e44099976a37c597f9a4dba4718e7d3d3b39fce59',2009,'TG','Togo','transnational-issues',538,'Surtyani
.Kumasi
Koforidua''
ACCRA
Coasl
February 2005, the military installed the
president’s son, Faure GNASSINGBE,
and then engineered his formal election
two months later. Democratic gains since
then allowed Togo to hold its first rela¬
tively free and fair legislative elections in
October 2007. After years of political
unrest and fire from international organ¬
izations for human rights abuses, Togo is
finally being re-welcomed into the inter¬
national community.
TO
TG
TGO
768
TGO
•tg
8 00 N
1 10 E
Guadeloupe, Martinique
16 30 N
62 00 W
6 08 N
1 13 E
8 00 N
1 10 E
United States (Alaska)
55 35 N
131 06 W','4824f0a3ef943191ebf60c4a4e84a56c42a5efd85f82a96c39c970062e7d55be','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aa8919b466de85e97d2116bb024ff6d64e24486cf5981abf5c3e3d2cdda13ff',2009,'GR','Greece','transnational-issues',548,'Disputes — international: in 2002,
Gibraltar residents voted overwhelm¬
ingly by referendum to reject any “shared
sovereignty” arrangement; the govern¬
ment of Gibraltar insists on equal partic¬
ipation in talks between the UK and
Spain; Spain disapproves of UK plans to
grant Gibraltar even greater autonomy
Disputes— international: Greece and
Turkey continue discussions to resolve
their complex maritime, air, territorial,
and boundary disputes in the Aegean
Sea; Cyprus question with Turkey;
Greece rejects the use of the name
Macedonia or Republic of Macedonia;
the mass migration of unemployed
Albanians still remains a problem for
developed countries, chiefly Greece and
GR
GR
38 00 N
25 00 E
Atlantic Ocean
38 30 N
25 00 E
37 45 N
24 42 E
The Bahamas
24 26 N
77 57 W
Atlantic Ocean
18 30 N
63 40 W
37 59 N
23 44 E
39 40 N
19 45 E
37 56 N
22 56 E
35 15 N
24 45 E
37 00 N
25 10 E
36 00 N
27 05 E
Tanzania
6 11 S
35 45 E
39 00 N
22 00 E
38 30 N
20 30 E
Atlantic Ocean
38 30 N
18 00 E
38 22 N
26 04 E
39 54 N
25 21 E
Russia
59 55 N
30 15 E
39 15 N
26 15 E
37 05 N
25 30 E
37 30 N
22 25 E
Tanzania
5 20 S
39 45 E
36 10N
28 00 E
37 48 N
26 44 E
40 38 N
22 57 E','92cdba0abebc0afeb9c2a061329d47fee9049c925532f997ddc6454b1bcd9d72','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2f3fb2ff4031c7793afafb7ddb3fc0b14056adfb9feb596132255e15a996fed',2009,'IT','Italy','transnational-issues',552,'Illicit drugs: a gateway to Europe for traf¬
fickers smuggling cannabis and heroin
from the Middle East and Southwest
Asia to the West and precursor chemi¬
cals to the East; some South American
cocaine transits or is consumed in
Greece; money laundering related to
drug trafficking and organized crime
Background: Greenland, the world’s
largest island, is about 81% ice-capped.
Vikings reached the island in the 10th
century from Iceland; Danish coloniza¬
tion began in the 18th century, and
Greenland was made an integral part of
Denmark in 1953. It joined the
European Community (now the EU)
with Denmark in 1973, but withdrew in
1985 over a dispute centered on strin¬
gent fishing quotas. Greenland was
granted self-government in 1979 by the
Danish parliament; the law went into
effect the following year. Denmark con¬
tinues to exercise control of Greenland’s
foreign affairs in consultation with
Greenland’s Home Rule Government.
Disputes — international: Italy’s long
coastline and developed economy
entices tens of thousands of illegal immi¬
grants from southeastern Europe and
northern Africa
Illicit drugs: important gateway for and
consumer of Latin American cocaine
and Southwest Asian heroin entering
the European market; money laundering
by organized crime and from smuggling
329
IT
IT
42 46 N
10 17 E
Ethiopia (claimed), Kenya
5 00 N
35 30 E
(de facto), Sudan (claimed)
38 30 N
15 00 E
Albania, Greece
40 00 N
20 30 E
Akrotiri, Dhekelia
34 40 N
32 51 E
43 46 N
11 16 E
44 25 N
8 57 E
42 50 N
12 50 E
Eritrea, Ethiopia, Somalia
8 00 N
38 00 E
794
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Italian Somaliland (former name for southern Somalia)
Ittihad al-lmarat al-Arabiyah (local name for the
United Arab Emirates)
Iturup (island; see Etorofu)
Ityop''iya (local name for Ethiopia)
Ivory Coast (former name for Cote d''Ivoire)
Iwo Jima (island)
Izmir (region)
Jakarta (capital)
James Bay
Jamestown (capital)
Jammu (city)
Jammu and Kashmir (region)
Japan, Sea of
Jars, Plain of
Java (island)
Java Sea
Jerusalem (capital, proclaimed)
Jiddah, Jeddah (city)
Johannesburg (city)
Joseph Bonaparte Gulf
Juan Fernandez, Islas de (island group)
Juan de Fuca, Strait of
Jubal, Strait of
Judaea (region)
Jugoslavia, Jugoslavia (local names for Yugoslavia,
a former Balkan federation)
Jutland (region)
Juventud, Isla de la (Isle of Youth)
Kabardino-Balkaria (region)
Kabul (capital)
Kaduna (city)
Kailas Range
Kalaallit Nunaat (local name for Greenland)
Kalahari (desert)
Kalimantan (region)
Kaliningrad (region; formerly part of East Prussia)
Kamaran (island)
Kamchatka Peninsula (Poluostrov Kamchatka)
Kampala (capital)
Kampuchea (former name for Cambodia)
Kane Basin (portion of channel)
Kanton Island
Kara Sea
Karachevo-Cherkessia (region)
Karachi (city)
Karafuto (island; former name for southern Sakhalin Island)
Karakoram Pass
Karelia, Kareliya (region)
Karelian Isthmus
Karimata Strait
Kashmir (region)
Katanga (region)
Kathmandu (capital)
Kattegat (strait)
Kauai Channel
Kazakstan (former name for Kazakhstan)
Keeling islands
Kerguelen, lies (island group)
Kermadec Islands
Kerulen River
Khabarovsk (city)
Khanka, Lake
Khartoum (capital)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
41 13 N
09 24 E
45 28 N
9 11 E
Atlantic Ocean
19 55 N
65 27 W
40 51 N
14 15 E
The Bahamas
25 05 N
77 21 W
38 07 N
13 21 E
Israel, West Bank
32 00 N
35 15 E
Federated States of Micronesia
6 55 N
158 08 E
Indian Ocean
10 00 N
79 45 E
China, Tajikistan
38 00 N
73 00 E
36 47 N
12 00 E
35 40 N
12 40 E
41 54 N
12 29 E
40 00 N
9 00 E
Atlantic Ocean
30 00 N
55 00 W
37 30 N
14 00 E
Atlantic Ocean
37 20 N
11 20 E
Atlantic Ocean
31 30 N
18 00 E
46 30 N
10 30 E
Vietnam
12 00 N
108 00 E
45 04 N
7 40 E
Atlantic Ocean
40 40 N
28 00 E
Turkey
39 00 N
35 00 E
43 25 N
11 00 E','3547560395506d462dcb0ae32b10902d89fd8b44199653d190de91dbe451eeda','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a030a1b123ddc46ec0a6c0655fdc96895b5fe0ecb6afcf33ebe38dd28fc1f65c',2009,'GU','Guam','transnational-issues',560,'Disputes — international: none
Illicit drugs: small-scale cannabis culti¬
vation; lesser transshipment point for
marijuana and cocaine to US
Franc Zone
Group of 2
Group of 3
Group of 5
Group of 6
Group of 7
Group of 8
Group of 9
Group of 10
Group of 15
Group of 1 1
Group of 24
Group of 77
General Agreement on Tariffs and Trade; now WTO
Gulf Cooperation Council
General Confederation of Trade Unions
gross domestic product
Greenwich Mean Time
gross national product
gross register ton
global system for mobile cellular communications
Organization for Democracy and Economic Development; acronym for member states-
Georgia, Ukraine, Azerbaijan, Moldova
GWP
Hazardous Wastes
gross world product
Basel Convention on the Control of Transboundary Movements of Hazardous Wastes
and Their Disposal
HF
HIV/AIDS
IADB
IAEA
IANA
IBRD
ICAO
ICC
ICCt
ICJ
ICRC
ICRM
ICSID
ICTR
ICTY
IDA
IDB
IDP
IEA
IFAD
IFC
IFRCS
IGAD
IHO
ILO
IMF
IMO
IMSO
Inmarsat
InOC
INSTRAW
Intelsat
Interpol
high-frequency
human immunodeficiency virus/acquired immune deficiency syndrome
Inter- American Development Bank
International Atomic Energy Agency
Internet Assigned Numbers Authority
International Bank for Reconstruction and Development (World Bank)
International Civil Aviation Organization
International Chamber of Commerce
International Criminal Court
International Court of Justice (World Court)
International Committee of the Red Cross
International Red Cross and Red Crescent Movement
International Center for Secretariat of Investment Disputes
International Criminal Tribunal for Rwanda
International Criminal Tribunal for the former Yugoslavia
International Development Association
Islamic Development Bank
Internally Displaced Person
International Energy Agency
International Fund for Agricultural Development
International Finance Corporation
International Federation of Red Cross and Red Crescent Societies
Inter-Governmental Authority on Development
International Hydrographic Organization
International Labor Organization
International Monetary Fund
International Maritime Organization
International Mobile Satellite Organization
International Maritime Satellite Organization
Indian Ocean Commission
International Research and Training Institute for the Advancement of Women
International Telecommunications Satellite Organization
International Criminal Police Organization
737
THE CIA WORLD FACTBOOK
Intersputnik
IOC
IOM
IPU
ISO
ISP
ITSO
ITU
ITUC
kHz
km
kW
kWh
LAES
LAIA
LAS
Law of the Sea
LDC
LLDC
London Convention
LOS
m
Marecs
Marine Dumping
Marine Life Conservation
MARPOL
Medarabtel
Mercosur
MHz
MICAH
MINURSO
MIGA
MINUSTAH
MONUC
NA
NAFTA
NAM
NATO
NC
NEA
NEGL
NGA
NIB
NIC
NIE
NIS
nm
NMT
NSG
Nuclear Test Ban
NZ
OAPEC
OAS
OAU
ODA
OECD
International Organization of Space Communications
International Olympic Committee
International Organization for Migration
Interparliamentary Union
International Organization for Standardization
Internet Service Provider
International Telecommunications Satellites Organization
International Telecommunication Union
International Trade Union Confederation, the successor to ICFTU (International
Confederation of Free Trade Unions) and the WCL (World Confederation of Labor)
kilohertz
kilometer
kilowatt
kilowatt-hour
Latin American Economic System
Latin American Integration Association
League of Arab States
United Nations Convention on the Law of the Sea (LOS)
less developed country
least developed country
see Marine Dumping
see Law of the Sea
meter
Maritime European Communications Satellite
Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter
Convention on Fishing and Conservation of Living Resources of the High Seas
see Ship Pollution
Middle East Telecommunications Project of the International Telecommunications Union
Southern Cone Common Market
megahertz
International Civilian Support Mission in Haiti
United Nations Mission for the Referendum in Western Sahara
Multilateral Investment Geographic Agency
United Nations Stabilization Mission in Haiti
United Nations Organization Mission in the Democratic Republic of the Congo
not available
North American Free Trade Agreement
Nonaligned Movement
North Atlantic Treaty Organization
Nordic Council
Nuclear Energy Agency
negligible
National Geospatial-Intelligence Agency
Nordic Investment Bank
newly industrializing country
newly industrializing economy
new independent states
nautical mile
Nordic Mobile Telephone
Nuclear Suppliers Group
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space,
and Under Water
GQ
GU
13 28 N
144 45 E
France (Corsica)
41 55 N
8 44 E
13 28 N
144 45 E','8b58eca237516aa95f0a06aa7aba470b6bcc8ea86c66a402539a2d061dd553e3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb0187847618ee13ae02efc89c54143f9020fcd294444a4ddce3f44d3c4249b',2009,'GT','Guatemala','transnational-issues',567,'Disputes— international: annual minis¬
terial meetings under the OAS-initiated
Agreement on the Framework for
Negotiations and Confidence Building
Measures continue to address
Guatemalan land and maritime claims in
Belize and the Caribbean Sea; the Line
of Adjacency created under the 2002
Differendum serves in lieu of the con¬
tiguous international boundary to con¬
trol squatting in the sparsely inhabited
rain forests of Belize’s border region;
Mexico must deal with thousands of
impoverished Guatemalans and other
Central Americans who cross the porous
border looking for work in Mexico and
the United States
Refugees and internally displaced per¬
sons: IDPs: undetermined (the UN does
not estimate there are any IDPs,
although some NGOs estimate over
200,000 IDPs as a result of over three
decades of internal conflict that ended in
1996) (2007)
Illicit drugs: major transit country for
cocaine and heroin; in 2005, cultivated
100 hectares of opium poppy after
reemerging as a potential source of
opium in 2004; potential production of
less than 1 metric ton of pure heroin;
marijuana cultivation for mostly
domestic consumption; proximity to
Mexico makes Guatemala a major
staging area for drugs (particularly for
cocaine); money laundering is a serious
problem; corruption is a major problem
Background: Guernsey and the other
Channel Islands represent the last rem¬
nants of the medieval Dukedom of
Normandy, which held sway in both
France and England. The islands were
the only British soil occupied by German
troops in World War II. Guernsey is a
British crown dependency, but is not part
of the UK. However, the UK
Government is constitutionally respon-
272
GT
GT
14 38 N
90 31 W','d324843ec3f00612d50cce40f7620a214b1fce564c806ec2684e86f52726f68c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a029af303fea5b5ccf4ec22e9a4ded9440c376bbc70ee17728e4377369db2760',2009,'GG','Guernsey','transnational-issues',568,'O 3.S 5 km
Swrfwu
. .
S!. Anne*
Atdemey
English
-v- .
Ubau
**** *
ST. PETER
PORT
\\ . —
JSt Sampson
Herm
Jethou Sark
Brecbou
i t
Little Sark
sible for its defense and international
representation.
Location: Western Europe, islands in the
English Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35
w
Map references: Europe
Area:
total : 78 sq km
land: 78 sq km
water: 0 sq km
note: includes Alderney, Guernsey,
Herm, Sark, and some other smaller
islands
Area — comparative: about one-half the
size of Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 12 nm
Climate: temperate with mild winters
and cool summers; about 50% of days are
overcast
Terrain: mostly level with low hills in
southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark
114m
Natural resources: cropland
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Natural hazards: NA
Environment — current issues: NA
Geography — note: large, deepwater
harbor at Saint Peter Port
Disputes— international: none
. -W- - ... A
•,iC
GK
GG
49 43 N
2 12 W
United States (Alaska)
52 00 N
176 00 W
United States (Alaska)
57 00 N
134 00 W
49 27 N
2 32 W
49 26 N
2 21 W','4e1ae22713cdf3375169ab80342bedc602a5a0e73d653fd312f7d00135c82ad6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf4f1e68f37842aea11210a8f71dd8308fd8c9fe50718c6896ba78c2127648ee',2009,'GN','Guinea','transnational-issues',572,'Background: Guinea has had only two
presidents since gaining its independ¬
ence from France in 1958. Lansana
CONTE came to power in 1984 when
the military seized the government after
the death of the first president, Sekou
TOURE. Guinea did not hold demo¬
cratic elections until 1993 when Gen.
CONTE (head of the military govern¬
ment) was elected president of the
civilian government. He was reelected in
1998 and again in 2003, though all the
polls have been marred by irregularities.
Guinea has maintained its internal sta¬
bility despite spillover effects from con¬
flict in Sierra Leone and Liberia. As
those countries have rebuilt, Guinea’s
own vulnerability to political and eco¬
nomic crisis has increased. Declining
economic conditions and popular dissat¬
isfaction with corruption and bad gover¬
nance prompted two massive strikes in
2006; a third nationwide strike in early
2007 sparked violent protests in many
Guinean cities and prompted two weeks
of martial law. To appease the unions and
end the unrest, CONTE named a new
prime minister in March 2007.
ttb&j dm Cabms
Nsves,
SAO TOM£ Llha de .
Sao Tome
‘Santa Cruz
Hh&j das R&fm
40 mt
Background: Discovered and claimed by
Portugal in the late 15th century, the
islands’ sugar-based economy gave way to
coffee and cocoa in the 19th century —
all grown with plantation slave labor, a
form of which lingered into the 20th
century. While independence was
achieved in 1975, democratic reforms
were not instituted until the late 1980s.
The country held its first free elections in
1991, but frequent internal wrangling
between the various political parties pre¬
cipitated repeated changes in leadership
and two failed coup attempts in 1995 and
2003. The recent discovery of oil in the
Gulf of Guinea promises to attract
increased attention to the small island
nation.
Disputes — international: none
566
GV
GN
931 N
13 43 W
11 00 N
10 00 W
Cambodia, Laos, Vietnam
15 00 N
107 00 E
11 00 N
10 00 w
Saint Barthelemy
17 53 N
62 51 W','e3a9383bf05435851fa747949e5f6340f36b7187327099321ed9b5e5ee1c4585','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07217f48ace62ecfc03060cb242d0a7a8e94223289a9d3c88eef6049621afbd1',2009,'GY','Guyana','transnational-issues',587,'Disputes— international: all of the area
west of the Essequibo River is claimed by
Venezuela preventing any discussion of a
maritime boundary; Guyana has
expressed its intention to join Barbados
in asserting claims before UNCLOS that
Trinidad and Tobago’s maritime
boundary with Venezuela extends into
their waters; Suriname claims a triangle
of land between the New and
Kutari/Koetari rivers in a historic dispute
over the headwaters of the Courantyne;
Guyana seeks arbitration under provi¬
sions of the UN Convention on the Law
of the Sea (UNCLOS) to resolve the
long-standing dispute with Suriname
over the axis of the territorial sea
boundary in potentially oil-rich waters
Illicit drugs: transshipment point for
narcotics from South America — prima¬
rily Venezuela — to Europe and the US;
producer of cannabis; rising money laun¬
dering related to drug trafficking and
human smuggling
282
Disputes— international: in April 2006,
the Permanent Court of Arbitration
issued a decision that delimited a mar¬
itime boundary with Trinidad and
Tobago and compelled Barbados to enter
a fishing agreement that limited
Barbadian fishermen’s catches of flying
fish in Trinidad and Tobago’s exclusive
economic zone; in 2005, Barbados and
Trinidad and Tobago agreed to compul¬
sory international arbitration under
UNCLOS challenging whether the
northern limit of Trinidad and Tobago’s
and Venezuela’s maritime boundary
extends into Barbadian waters; Guyana
has also expressed its intention to
include itself in the arbitration as the
Trinidad and Tobago-Venezuela mar¬
itime boundary may extend into its
waters as well
Illicit drugs: transshipment point for
South American drugs destined for the
US and Europe; producer of cannabis
Disputes— international: claims all of
the area west of the Essequibo River in
Guyana, preventing any discussion of a
maritime boundary; Guyana has
expressed its intention to join Barbados
in asserting claims before the United
Nations Convention on the Law of the
Sea (UNCLOS) that Trinidad and
Tobago’s maritime boundary with
Venezuela extends into their waters; dis¬
pute with Colombia over maritime
boundary and Venezuelan-administered
Los Monjes islands near the Gulf of
Venezuela; Colombian-organized illegal
narcotics and paramilitary activities pen¬
etrate Venezuela’s shared border region;
in 2006, an estimated 139,000
Colombians sought protection in 150
communities along the border in
Venezuela; US, France, and the
Netherlands recognize Venezuela’s
granting full effect to Aves Island,
thereby claiming a Venezuelan
EEZ/continental shelf extending over a
large portion of the eastern Caribbean
Sea; Dominica, Saint Kitts and Nevis,
Saint Lucia, and Saint Vincent and the
Grenadines protest Venezuela’s full effect
claim
Trafficking in persons: current situation:
Venezuela is a source, transit, and desti¬
nation country for women and children
trafficked for the purposes of sexual
exploitation and forced labor; women
and children from Colombia, China,
Peru, Ecuador, and the Dominican
Republic are trafficked to and through
Venezuela and subjected to commercial
sexual exploitation or forced labor;
Venezuelans are trafficked internally and
to Western Europe, particularly Spain
and the Netherlands, and to countries in
the Caribbean region for commercial
sexual exploitation; Venezuela is a
transit country for illegal migrants from
other countries in the region and for
Asian nationals, some of whom are
believed to be trafficking victims
tier rating: Tier 3 — Venezuela does not
fully comply with the minimum stan¬
dards for the elimination of trafficking
and is not making significant efforts to
do so
Illicit drugs: small-scale illicit producer
of opium and coca for the processing of
opiates and coca derivatives; however,
large quantities of cocaine, heroin, and
marijuana transit the country from
Colombia bound for US and Europe; sig¬
nificant narcotics-related money-laun¬
dering activity, especially along the
border with Colombia and on Margarita
Island; active eradication program pri¬
marily targeting opium; increasing signs
of drug-related activities by Colombian
insurgents on border
701
y INTRODUCTION
Background: The conquest of Vietnam
by France began in 1858 and was com¬
pleted by 1884- It became part of French
Indochina in 1887. Vietnam declared
independence after World War II, but
France continued to rule until its 1954
defeat by Communist forces under Ho
Chi MINH. Under the Geneva Accords
of 1954, Vietnam was divided into the
Communist North and anti-Communist
South. US economic and military aid to
South Vietnam grew through the 1960s
in an attempt to bolster the government,
but US armed forces were withdrawn fol¬
lowing a cease-fire agreement in 1973.
Two years later, North Vietnamese forces
overran the South reuniting the country
under Communist rule. Despite the
return of peace, for over a decade the
country experienced little economic
growth because of conservative leader¬
ship policies. However, since the enact¬
ment of Vietnam’s “doi moi”
(renovation) policy in 1986, Vietnamese
authorities have committed to increased
economic liberalization and enacted
structural reforms needed to modernize
the economy and to produce more com¬
petitive, export-driven industries. The
country continues to experience protests
from various groups — such as the
Protestant Montagnard ethnic minority
population of the Central Highlands and
the Hoa Hao Buddhists in southern
Vietnam over religious persecution.
Montagnard grievances also include the
loss of land to Vietnamese settlers.
Disputes— international: southeast
Asian states have enhanced border sur¬
veillance to check the spread of avian
flu; Cambodia and Laos protest
Vietnamese squatters and armed
encroachments along border; an esti¬
mated 300,000 Vietnamese refugees
reside in China; establishment of a mar¬
itime boundary with Cambodia is ham¬
pered by unresolved dispute over the
sovereignty of offshore islands; demarca¬
tion of the China-Vietnam boundary
proceeds slowly and although the mar¬
itime boundary delimitation and fish¬
eries agreements were ratified in June
2004, implementation has been delayed;
China occupies the Paracel Islands also
claimed by Vietnam and Taiwan;
involved in complex dispute with China,
Malaysia, Philippines, Taiwan, and pos¬
sibly Brunei over the Spratly Islands; the
2002 “Declaration on the Conduct of
Parties in the South China Sea” has
eased tensions but falls short of a legally
binding “code of conduct” desired by
several of the disputants; Vietnam con¬
tinues to expand construction of facili¬
ties in the Spratly Islands; in March
2005, the national oil companies of
China, the Philippines, and Vietnam
signed a joint accord to conduct marine
seismic activities in the Spratly Islands
Illicit drugs: minor producer of opium
poppy; probable minor transit point for
Southeast Asian heroin; government
continues to face domestic
opium/heroin/methamphetamine addic¬
tion problems despite longstanding
crackdowns
VIRGIN ISLANDS
Disputes — international: none
707
Disputes— international: claimed by
GY
GY
5 00 N
59 00 W
6 59 N
58 23 W
Russia (de facto)
44 55 N
147 40 E
6 48 N
58 10W
The Gambia
13 30 N
14 47 W','50e9dcce10bce3e7f1206fa8223a00ad3117a7cd424e93ee59414a1a4ea18e57','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e38d2f223088b2130ed1c8d66c0a9f8c1ae1482e4467929e7c56dac6f1dce57',2009,'HT','Haiti','transnational-issues',592,'Disputes— international: since 2004,
about 8,000 peacekeepers from the UN
Stabilization Mission in Haiti
(MINUSTAH) maintain civil order in
Haiti; despite efforts to control illegal
migration, Haitians cross into the
Dominican Republic and sail to neigh¬
boring countries; Haiti claims US-
administered Navassa Island
Illicit drugs: Caribbean transshipment
point for cocaine en route to the US and
Europe; substantial bulk cash smuggling
activity; Colombian narcotics traffickers
favor Haiti for illicit financial transac¬
tions; pervasive corruption; significant
consumer of cannabis
i
HA
HT
Heard Island and
HM
HM
McDonald Islands
Holy See
VT
VA
(Vatican City)
18 32 N
72 20 W','8726d2448ab62fd65081f0790499cb2c81bfa646eb8f4b94b6823c0a49c301d3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd88d02d58f50d6f833ae0722356a2000604fd3e19a2b56f6b4ee381301413a6',2009,'HM','Heard Island and McDonald Islands','transnational-issues',593,'Background: These uninhabited, barren,
sub-Antarctic islands were transferred
from the UK to Australia in 1947.
Populated by large numbers of seal and
bird species, the islands have been desig¬
nated a nature preserve.
Disputes— international: none
286
Disputes — international: none
V’-''DA:
;','7acea3ed85fd92acd9c7ab2dabd2cfe33c0cb578d94724a3e5d81a01a9bc82cf','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f0e017ccb2cc27c46643b159a4db4e454ffddc845a9de18e458a5fbdd6a66f',2009,'HN','Honduras','transnational-issues',601,'Bum
GUAT. yf
Sants Rosa
cfe Cop&n
pomayagua *
TEGUCIGALPA
C&ro
Lm ft&m*
San ''iSU.y
.cremo \\
k*> .Chgiuteca
HO
HN
17 25 S
83 56 W
14 06 N
87 13 W
Iran
35 40 N
51 26 E','0232b59be3b18868ebb3544b719e6e6c2048652344a8f773da385a5ba96fdbd7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eb1ac543c649af033e68a683db7bcb364b6af4931010a1a5a3870c71df6e8f4',2009,'NI','Nicaragua','transnational-issues',602,'v ‘ -
OCMAH
j
Background: Once part of Spain’s vast
empire in the New World, Honduras
became an independent nation in 1821.
After two and a half decades of mostly
military rule, a freely elected civilian
government came to power in 1982.
During the 1980s, Honduras proved a
haven for anti-Sandinista contras
fighting the Marxist Nicaraguan
Government and an ally to Salvadoran
Government forces fighting leftist guer¬
rillas. The country was devastated by
Hurricane Mitch in 1998, which killed
about 5,600 people and caused approxi¬
mately $2 billion in damage.
Background: The Pacific coast of
Nicaragua was settled as a Spanish
colony from Panama in the early 16th
century. Independence from Spain was
declared in 1821 and the country became
an independent republic in 1838. Britain
occupied the Caribbean Coast in the first
half of the 19th century, but gradually
ceded control of the region in subsequent
decades. Violent opposition to govern¬
mental manipulation and corruption
spread to all classes by 1978 and resulted
in a short-lived civil war that brought
the Marxist Sandinista guerrillas to
power in 1979. Nicaraguan aid to leftist
rebels in El Salvador caused the US to
472
sponsor anti-Sandinista contra guerrillas
through much of the 1980s. Free elec¬
tions in 1990, 1996, and 2001, saw the
Sandinistas defeated, but voting in 2006
announced the return of former
Sandinista President Daniel ORTEGA
Saavedra. Nicaragua’s infrastructure and
economy — hard hit by the earlier civil
war and by Hurricane Mitch in 1998 —
are slowly being rebuilt.
NU
NI
NIC
558
NIC
.ni
12 15 N
83 00 W
Guyana, Venezuela
3 38 N
66 50 W
12 15 N
83 00 W','9ef12e770c27507ec91ac605cf3e0e30251c60a63e087a72144419f24d0981d2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('959e728416220ea28528f13cac1dc2a421b7a70a553a33178e7c15ffb9b3e777',2009,'HK','Hong Kong','transnational-issues',614,'Disputes— international: none
Illicit drugs: despite strenuous law
enforcement efforts, faces difficult chal¬
lenges in controlling transit of heroin
and methamphetamine to regional and
world markets; modern banking system
provides conduit for money laundering;
rising indigenous use of synthetic drugs,
especially among young people
Miskolc
Nfyfregyhfea
Dotxecea
BUDAPEST
.Srorebatfteiy
K£cskerm>!s
• ■ . ■ > : -
HK
HK
Howland Island
HQ
22 15 N
114 10E
22 18 N
114 10E
Burma, Thailand
10 20 N
99 00 E
22 15 N
113 55 E
Laos
18 00 N
105 00 E
Arctic Ocean
76 00 N
126 00 E
Spain (Canary Islands)
28 06 N
15 24 W
Syria
36 00 N
35 50 E
22 15 N
114 10 E','856778e06eb86c9f00a5f07c14d9848182c68a862f15c84e9279823d54bc67b6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb6eea2c56e6c73e504dfc7c8b222af47d090e9c104e045b9641d23e79ce07d9',2009,'UA','Ukraine','transnational-issues',615,'HA
111 %
SU*A*»A
4ad "''^1
Vwaa Wum§ .
.Umisoara Siibtu _ ( j
^4/
H ^AfiSvxVAASAN Brail a, V,
:|| PitesfC /’lotefti
BUCHAREST
* Constant^
Walachia
''Craiova
Giurgi''
»»»«
H«na
Disputes — international: Uganda is sub¬
ject to armed fighting among hostile
ethnic groups, rebels, armed gangs, mili¬
tias, and various government forces that
extend across its borders; Uganda hosts
209,860 Sudanese, 27,560 Congolese,
and 19,710 Rwandan refugees, while
Ugandan refugees as well as members of
the Lord’s Resistance Army (LRA) seek
shelter in southern Sudan and the
Democratic Republic of the Congo’s
Garamba National Park; LRA forces
have also attacked Kenyan villages across
the border
Refugees and internally displaced per¬
sons: refugees (country of origin): 215,700
(Sudan); 28,880 (Democratic Republic
of Congo); 24,900 (Rwanda)
IDPs: 1.27 million (350,000 IDPs
returned in 2006 following ongoing
peace talks between the Lord’s
Resistance Army (LRA) and the
Government of Uganda) (2007)
state in Europe. Weakened by
internecine quarrels and Mongol inva¬
sions, Kyivan Rus was incorporated into
671
THE CIA WORLD FACTBOOK
the Grand Duchy of Lithuania and even¬
tually into the Polish-Lithuanian
Commonwealth. The cultural and reli¬
gious legacy of Kyivan Rus laid the
foundation for Ukrainian nationalism
through subsequent centuries. A new
Ukrainian state, the Cossack
Hetmanate, was established during the
mid- 17th century after an uprising
against the Poles. Despite continuous
Muscovite pressure, the Hetmanate
managed to remain autonomous for
well over 100 years. During the latter
part of the 18th century, most
Ukrainian ethnographic territory was
absorbed by the Russian Empire.
Following the collapse of czarist Russia
in 1917, Ukraine was able to bring
about a short-lived period of independ¬
ence (1917-20), but was reconquered
and forced to endure a brutal Soviet
rule that engineered two artificial
famines (1921-22 and 1932-33) in
which over 8 million died. In World
War II, German and Soviet armies were
responsible for some 7 to 8 million
more deaths. Although final independ¬
ence for Ukraine was achieved in 1991
with the dissolution of the USSR,
democracy remained elusive as the
legacy of state control and endemic
corruption stalled efforts at economic
reform, privatization, and civil liberties.
A peaceful mass protest “Orange
Revolution” in the closing months of
2004 forced the authorities to overturn
a rigged presidential election and to
allow a new internationally monitored
vote that swept into power a reformist
slate under Viktor YUSHCHENKO.
Subsequent internal squabbles in the
YUSHCHENKO camp allowed his
rival Viktor YANUKOVYCH to stage a
comeback in parliamentary elections
and become prime minister in August
of 2006. An early legislative election,
brought on by a political crisis in the
spring of 2007, saw Yuliya
TYMOSHENKO, as head of an
“Orange” coalition, installed as a new
prime minister in December 2007.
UP
UA
UKR
804
UKR
.ua
48 22 N
23 32 E
Pacific Ocean
MOOS
139 00 E
45 00 N
34 00 E
45 00 N
34 00 E
Atlantic Ocean
22 55 N
74 35 W
French Southern and
46 30 S
51 00 E
Antarctic Lands
50 26 N
30 31 E
50 26 N
30 31 E
48 22 N
23 32 E
48 22 N
23 32 E
49 00 N
32 00 E
Berlin','b0518c35338139688d9b6258a3792d742f37989d5c8ff1cc7bbf539f74c789f8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cb553fbdeaa28d0b1ea62f3144291630fd16f13ccbc50c8e5fe2d58d64fe0df',2009,'RO','Romania','transnational-issues',616,'o 2? tOkm
20
Background: Hungary became a
Christian kingdom in A.D. 1000 and for
many centuries served as a bulwark
against Ottoman Turkish expansion in
Europe. The kingdom eventually became
part of the polyglot Austro-Hungarian
Empire, which collapsed during World
War I. The country fell under
Communist rule following World War II.
In 1956, a revolt and an announced
withdrawal from the Warsaw Pact were
met with a massive military intervention
by Moscow. Under the leadership of
Janos KADAR in 1968, Hungary began
liberalizing its economy, introducing so-
called “Goulash Communism.” Hungary
held its first multiparty elections in 1990
and initiated a free market economy. It
joined NATO in 1999 and the EU in
2004.
Disputes— international: Moldova and
Ukraine operate joint customs posts to
monitor the transit of people and com¬
modities through Moldova’s break-away
Transnistria region, which remains under
OSCE supervision
Illicit drugs: limited cultivation of
opium poppy and cannabis, mostly for
CIS consumption; transshipment point
for illicit drugs from Southwest Asia via
Central Asia to Russia, Western Europe,
and possibly the US; widespread crime
and underground economic activity
m
Disputes — international: China and
Russia have demarcated the once dis-
541
THE CIA WORLD FACTBOOK
puted islands at the Amur and Ussuri
confluence and in the Argun River in
accordance with the 2004 Agreement,
ending their centuriesdong border dis¬
putes; the sovereignty dispute over the
islands of Etorofu, Kunashiri, Shikotan,
and the Habomai group, known in Japan
as the “Northern Territories” and in
Russia as the “Southern Kurils,” occu¬
pied by the Soviet Union in 1945, now
administered by Russia, and claimed by
Japan, remains the primary sticking
point to signing a peace treaty formally
ending World War II hostilities; Russia
and Georgia agree on delimiting all but
small, strategic segments of the land
boundary and the maritime boundary;
OSCE observers monitor volatile areas
such as the Pankisi Gorge in the
Akhmeti region and the Kodori Gorge in
Abkhazia; Azerbaijan, Kazakhstan, and
Russia signed equidistance boundaries in
the Caspian seabed but the littoral states
have no consensus on dividing the water
column; Russia and Norway dispute their
maritime limits in the Barents Sea and
Russia’s fishing rights beyond Svalbard’s
territorial limits within the Svalbard
Treaty zone; various groups in Finland
advocate restoration of Karelia
(Kareliya) and other areas ceded to the
Soviet Union following the Second
World War but the Finnish Government
asserts no territorial demands; in May
2005, Russia recalled its signatures to the
1996 border agreements with Estonia
(1996) and Latvia (1997), when the two
Baltic states announced issuance of uni¬
lateral declarations referencing Soviet
occupation and ensuing territorial losses;
Russia demands better treatment of
ethnic Russians in Estonia and Latvia;
Estonian citizen groups continue to press
for realignment of the boundary based on
the 1920 Tartu Peace Treaty that would
bring the now divided ethnic Setu
people and parts of the Narva region
within Estonia; Lithuania and Russia
committed to demarcating their
boundary in 2006 in accordance with the
land and maritime treaty ratified by
Russia in May 2003 and by Lithuania in
1999; Lithuania operates a simplified
transit regime for Russian nationals trav¬
eling from the Kaliningrad coastal
exclave into Russia, while still con¬
forming, as an EU member state with an
EU external border, where strict
Schengen border rules apply; prepara¬
tions for the demarcation delimitation of
land boundary with Ukraine have com¬
menced; the dispute over the boundary
between Russia and Ukraine through the
Kerch Strait and Sea of Azov remains
unresolved despite a December 2003
framework agreement and on-going
expert-level discussions; Kazakhstan and
Russia boundary delimitation was rati¬
fied on November 2005 and field demar¬
cation should commence in 2007;
Russian Duma has not yet ratified 1990
Bering Sea Maritime Boundary
Agreement with the US
Refugees and infernally displaced per¬
sons: IDPs: 18,000-160,000 (displace¬
ment from Chechnya and North
Ossetia) (2007)
Trafficking in persons: current situation:
Russia is a source, transit, and destina¬
tion country for men, women, and chil¬
dren trafficked for various purposes; it
remains a significant source of women
trafficked to over 50 countries for com¬
mercial sexual exploitation; Russia is also
a transit and destination country for men
and women trafficked from Central Asia,
Eastern Europe, and North Korea to
Central and Western Europe and the
Middle East for purposes of forced labor
and sexual exploitation; internal traf¬
ficking remains a problem in Russia with
women trafficked from rural areas to
urban centers for commercial sexual
exploitation, and men trafficked inter¬
nally and from Central Asia for forced
labor in the construction and agricultural
industries; debt bondage is common
among trafficking victims, and child sex
tourism remains a concern
tier rating: Tier 2 Watch List — Russia is
placed on the Tier 2 Watch List for a
third consecutive year for its continued
failure to show evidence of increasing
efforts to combat trafficking, particularly
in the area of victim protection and assis¬
tance
illicit drugs: limited cultivation of illicit
cannabis and opium poppy and producer
of methamphetamine, mostly for
domestic consumption; government has
active illicit crop eradication program;
used as transshipment point for Asian
opiates, cannabis, and Latin American
cocaine bound for growing domestic
markets, to a lesser extent Western and
Central Europe, and occasionally to the
US; major source of heroin precursor
chemicals; corruption and organized
crime are key concerns; major consumer
of opiates
RO
RO
ROU
642
ROU
.ro
Russia
RS
RU
RUS
643
RUS
.ru
44 26 N
26 06 E
788
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Nome _ _
Budapest (capital)
Buenos Aires (capital)
Bujumbura (capital)
Bukovina (region)
Byelarus (local name for Belarus)
Byelorussia (former name for Belarus)
Cabinda (province)
Cabo Verde (local name for Cape Verde)
Cabot Strait
Caicos Islands
Cairo (capital)
Calcutta (city)
Calgary (city)
California, Gulf of
Cameroun (local name for Cameroon)
Campbell Island
Campeche, Bay of
Canal Zone (former name for US possessions in Panama)
Canarias Sea
Canary Islands
Canberra (capital)
Cancun (city)
Canton (city; now Guangzhou)
Canton Island (Kanton Island)
Cape Juby (region; former name for Southern Morocco)
Cape Province (region; former name for Northern,
Western, and Eastern Cape Provinces of South Africa)
Cape Town (legislative capital)
Cape of Good Hope (cape; also alternate name for
Cape Province of South Africa)
Caracas (capital)
Cargados Carajos Shoals
Caribbean Sea
Caroline Islands
Carpatho-Ukraine (region; former name for
Zakarpats''ka oblast*)
Carpentaria, Gulf of
Casablanca (city)
Castries (capital)
Catalonia (region)
Cato Island
Caucasus (region)
Cayenne (capital)
Celebes (island)
Celebes Sea
Celtic Sea
Central African Empire (former name for Central
African Republic)
Ceram (Seram) Sea
Ceska Republika (local name for Czech Republic)
Ceskoslovensko (former local name for Czechoslovakia)
Cetinje (capital city)
Ceuta (city)
Ceylon (former name for Sri Lanka)
Chafarinas, Islas (island)
Chagos Archipelago (Oil Islands)
Challenger Deep (Mariana Trench)
Channel Islands
Charlotte Amalie (capital)
Chatham Islands
Chechnya (region; also Chechnla)
Cheju Strait
Cheju-do (island)
Chengdu (city)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
46 30 N
24 00 E
44 45 N
26 05 E','c3fcd05fcb6a1c415e4c82628c60a6498633d2b1a99b73e4510f1cbc0010979e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c987e88b92f6c1877be472e2a6172f3eacea2edfb0cf49dff19974758eb6bf03',2009,'IE','Ireland','transnational-issues',645,'Disputes — international: Ireland,
Iceland, and the UK dispute Denmark’s
claim that the Faroe Islands’ continental
shelf extends beyond 200 nm
Illicit drugs: transshipment point for and
consumer of hashish from North Africa
to the UK and Netherlands and of
European-produced synthetic drugs;
increasing consumption of South
American cocaine; minor transshipment
point for heroin and cocaine destined for
Western Europe; despite recent legisla¬
tion, narcotics-related money laun¬
dering — using bureaux de change, trusts,
and shell companies involving the off¬
shore financial community — remains a
concern
El
IE
53 20 N
6 15 W
53 00 N
8 00 W
.
■
iiii
IB
.ivvrpoof
KINGDOM
“ Cardiff *8irmi^ham ! Amsterdam 1
I''ftivi Jam *
* i r '' rM
London
; ■,-suA
Guernsey ulk. > v„
*
Moscow
A*''-'' * LATVIA
• |j y • r R|8a , ''br%&7. "\\ £
4s W ; uthuawa v,tsyBhsk Smo,cnRk
\\ IB Vilnius, ( Mahiivow '' ~T ,
% J78? 3 kc-ssm t boa ■*• '' ~BV - -
Bornholm
Gdansk itxtmu
>-: _ - S HomyeL ";
\\ ) '' ^
^Pozaah Warsaw ^Brest..
* “POLAND
.• BELARUS x , ,
Mtod,,J •• w ■ •
1
I Od/
Rtvtte
1^^ UiP"*g* '' \\ «. Wroclaw ) )
,.''iv ^ i n> UKKA1ME
Jcr^yd -R o
■ i ''■■ ■
l
L
Names''
tftSv AW Si* ^
<-
4 ff''/y s
f '' '' :: :. ■
. I’orto
I
-■■■, ;
ORTUQAL
/ • — *<ry£!L ''**
/ 4^- , l , ,J ''y% -
# Li short
4*-"
Bisc&Y
Ni
Bilbao
.
i
4" ,9 Frankfurt v''a* vr •,’''''Ae,v*Kriikdw s''
s * inxcmhou^”-''" CZECH RCFUBL1C .
, Paris • 1 1 * ! * '' - Bmo*,''-,,
.sruttgart. •- . -r_/ ; sBratistava-'' v
."Munich
* CA Vienna ; v,,_>iB«aa|3 est
mm
W- i
''y|!
64
V-Jc iVIvkofavtv
:y '' Chisinau
8$&
''!• -*HVtiecn r- 4 Wp^y 5
-vVOdes«i
N''apoca ’** HOLDOVA, y "*
j
ap
1 /.FRANCE
«W ''l,«. .“>»vo„,cJ''OV''"''A% *Za8r"’
ROMANIA^
#
" r l ^
^ **
■ :. IP: ,.::: .■■:</■ B.
.Toulouse nom^ rjf
Andorra .
Marseiile"~ya^
CBOa
\\ ffr> SOSNiA AM)/
^s<ss
I
'' B''"'' ''
^ Belgrade; rK
>isEKWA .- \\
r. "LrlA"1"*.’ *5
Bucharest ) /Constanta
Black
7 Vamaf‘ XM
W x -SERBIA s''
7 ,7 ; . f,#
npw 4 < •vv''t5f>\\x\\ - t tf< i. •wAv. /»TIs<r I «««»■< w — •xSSS''ts '' ^ A„.
;y
,4
Barcelona
§m
" SPAIN x*ioiku ''*
; SeVilia
s
4?
BALEARIC
ISLANDS
Curskti > i\\
41
41
4 .--11
L
Sardinia 1 4
jot cnee
IT AT V - Nm Istanbul
UALY Podgorica* -i'' * Skopje 8 *
Rome* W,M '' ^-rntvttt • .
Tirana* Thessaloniki
, f ALII ■
Napic^P*^,^^ * ...
v\\^tf <■ ,
VAnt Art^ii ''
ti ® si
is
w '' i
tl.iJialUl) . ,
- (!.,«,«: *
,-s4 Ceuta
,'' \\ ismsr-!
<r> A
. . ★
'' * Casablanca
Rabat
ilastca','72a4bb8a0cdb87c9a26004519fc2f58f506884d96dfc0caba20012f6f7c65b18','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01a09531b91d8e27736aa211a2b30787ff060fbbdf0cc988923bb212132615a6',2009,'IM','Isle of Man','transnational-issues',646,'Background: Part of the Norwegian
Kingdom of the Hebrides until the
13th century when it was ceded to
Scotland, the isle came under the
British crown in 1765. Current con¬
cerns include reviving the almost
extinct Manx Gaelic language. Isle of
Man is a British crown dependency but
is not part of the UK. However, the UK
Government remains constitutionally
responsible for its defense and interna¬
tional representation.
Disputes — international: none
Background: Following World War II,
the British withdrew from their mandate
of Palestine, and the UN partitioned the
area into Arab and Jewish states, an
arrangement rejected by the Arabs.
Subsequently, the Israelis defeated the
Arabs in a series of wars without ending
the deep tensions between the two sides.
The territories Israel occupied since the
1967 war are not included in the Israel
country profile, unless otherwise noted.
On 25 April 1982, Israel withdrew from
the Sinai pursuant to the 1979 Israel-
Egypt Peace Treaty. In keeping with the
framework established at the Madrid
Conference in October 1991, bilateral
negotiations were conducted between
Israel and Palestinian representatives
and Syria to achieve a permanent settle¬
ment. Israel and Palestinian officials
signed on 13 September 1993 a
Declaration of Principles (also known as
the “Oslo Accords”) guiding an interim
period of Palestinian self-rule.
Outstanding territorial and other dis¬
putes with Jordan were resolved in the 26
October 1994 Israel-Jordan Treaty of
Peace. In addition, on 25 May 2000,
Israel withdrew unilaterally from
southern Lebanon, which it had occu¬
pied since 1982. In April 2003, US
President BUSH, working in conjunc¬
tion with the EU, UN, and Russia — the
“Quartet” — took the lead in laying out a
roadmap to a final settlement of the con¬
flict by 2005, based on reciprocal steps by
the two parties leading to two states,
Israel and a democratic Palestine.
However, progress toward a permanent
status agreement was undermined by
Israeli-Palestinian violence between
September 2003 and February 2005. An
Israeli-Palestinian agreement reached at
Sharm al-Sheikh in February 2005, along
with an internally-brokered Palestinian
ceasefire, significantly reduced the vio¬
lence. In the summer of 2005, Israel uni¬
laterally disengaged from the Gaza Strip,
evacuating settlers and its military while
retaining control over most points of
entry into the Gaza Strip. The election
of HAMAS in January 2006 to head the
Palestinian Legislative Council froze
relations between Israel and the
Palestinian Authority (PA). Ehud
322
IM
IM','41841fc461df3cd4a4842ae1f5fadeeeebbfba5642cb47773aa04ae4cfb78ce5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c96337be366a534d889d54d5d17eab2ea2c86297a252fae9655bc236f8beb84c',2009,'JP','Japan','transnational-issues',670,'activity in 1970; the most recent erup¬
tion occurred in 1985. It is the northern¬
most active volcano on earth.
Disputes — international: none
Disputes— international: the sover¬
eignty dispute over the islands of
Etorofu, Kunashiri, and Shikotan, and
the Habomai group, known in Japan as
the “Northern Territories” and in Russia
as the “Southern Kuril Islands,” occupied
by the Soviet Union in 1945, now
administered by Russia and claimed by
Japan, remains the primary sticking
point to signing a peace treaty formally
ending World War II hostilities; Japan
and South Korea claim Liancourt Rocks
(Take-shima/Tok-do) occupied by South
Korea since 1954; China and Taiwan dis¬
pute both Japan’s claims to the uninhab¬
ited islands of the Senkaku-shoto
(Diaoyu Tai) and Japan’s unilaterally
declared exclusive economic zone in the
East China Sea, the site of intensive
hydrocarbon prospecting
336
JA
JP
JPN
392
JPN
•jp
Jarvis island
DQ
-
''
UMI
ISO includes with the US
Minor Outlying Islands
27 00 N
142 10 E
43 00 N
17 00 E
44 00 N
143 00 E
36 00 N
138 00 E
Indian Ocean
26 34 N
56 15 E
Djibouti, Eritrea, Ethiopia,
8 00 N
48 00 E
34 20 N
133 30 E
24 47 N
141 20 E
Turkey
38 25 N
27 10 E
34 41 N
135 10 E
33 00 N
131 00 E
Bolivia
16 30 S
68 09 W
Pacific Ocean
45 45 N
142 00 E
24 16 N
154 00 E
Venezuela
10 00 N
64 00 W
Guam, Northern Mariana Islands 16 00 N
145 30 E
24 16 N
154 00 E
30 00 N
140 00 E
Federated States of Micronesia
6 85 N
158 35 E
36 00 N
138 00 E
Federated States of Micronesia
5 30 N
153 40 E
26 30 N
128 00 E
34 42 N
135 30 E
20 20 N
136 00 E
26 30 N
128 00 E
24 30 N
124 00 E
43 04 N
141 20 E
Pacific Ocean
7 05 S
114 10E
33 45 N
133 30 E
Russia (de facto)
43 47 N
146 45 E
35 42 N
139 46 E
Pacific Ocean
20 00 N
108 00 E
25 00 N
141 00 E
35 26 N
139 37 E
'' occupkN* by ih/Sovipl Un.iin in !''Hy
aChnimstered b/ Kussa, da;me-J by ‘ajrar:.
Petropavlovsk
K^chatskiy ;
Sakhalin
5e<x of
Okhotsk
Khabarovsk
Kodiak
Bethel
Magadan
Okhotsk
Juneau
Oymyakoti
Whitehorse*
/> - Cherskjv
Pevek;
Yakutsk
Barrow
Prudhoe
Bay
Verkhoyansk
lniwtk
Beaufort
teho Bay
Yellowknife
■ mi tv
SIBERIAN’
ISLANDS
Banks
''tslgtmt
Laptev
h ;
Cambridge
Lz C € 3. n
quWm','fbb7aa4a208353f6d12d6aa58ef66b6ea23eb1859d1a232f3e589ca84315acae','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e166786aca73437f9a651a19bf5ba58d5832fa563ebcf0df12b185bd2f6ec5',2009,'JE','Jersey','transnational-issues',679,'Channel Islands represent the last rem¬
nants of the medieval Dukedom of
Normandy that held sway in both France
and England. These islands were the
only British soil occupied by German
troops in World War II. Jersey is a British
crown dependency but is not part of the
UK. However, the UK Government is
constitutionally responsible for its
defense and international representa¬
tion.
Disputes— international: none
JE
JE
JEY
832
UK
.je
Johnston Atoll
JQ
UMI
ISO includes with the US
Minor Outlying Islands
49 12 N
2 07 W
Canada (New Brunswick)
45 16 N
66 04 W','2abbdf514f9b1805cb66fc6da57ee2da1e32a5853a616e93de6cd6957f045c8c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b62d33ca97a4a08019cc251382e9361db544e7a606b548e7fb1b94009dcb72c5',2009,'JO','Jordan','transnational-issues',686,'Background: Following World War I and
the dissolution of the Ottoman Empire,
the UK received a mandate to govern
much of the Middle East. Britain sepa¬
rated out a semi-autonomous region of
Transjordan from Palestine in the early
1920s, and the area gained its independ¬
ence in 1946; it adopted the name of
Jordan in 1950. The country’s long-time
ruler was King HUSSEIN (1953-99). A
pragmatic leader, he successfully navi¬
gated competing pressures from the
major powers (US, USSR, and UK), var¬
ious Arab states, Israel, and a large
internal Palestinian population, despite
several wars and coup attempts. In 1989
he reinstituted parliamentary elections
and gradual political liberalization; in
1994 he signed a peace treaty with Israel.
King ABDALLAH II, the son of King
HUSSEIN, assumed the throne fol¬
lowing his father’s death in February
1999. Since then, he has consolidated
his power and undertaken an aggressive
economic reform program. Jordan
acceded to the World Trade
Organization in 2000, and began to par¬
ticipate in the European Free Trade
Association in 2001. Municipal elections
were held in July 2007 under a system in
which 20% of seats in all municipal
councils were reserved by quota for
women. Parliamentary elections were
held in November 2007 and saw inde¬
pendent pro-government candidates win
the vast majority of seats. In November
2007, King Abdallah instructed his new
338
prime minister to focus on socioeco-
nomic reform, developing a healthcare
and housing network for civilians and
military personnel, and improving the
educational system.
Disputes — international: approximately
two million Iraqis have fled the conflict
in Iraq, with the majority taking refuge
in Syria and Jordan; 2004 Agreement
settles border dispute with Syria pending
demarcation
Refugees and infernally displaced per¬
sons: refugees (country of origin):
1,835,704 (Palestinian Refugees
(UNRWA)); 500,000 (Iraq)
IDPs: 160,000 (1967 Arab-Israeli War)
(2007)
341
Refugees and internally displaced per¬
sons: refugees (country of origin): 1-1.4
million (Iraq); 522,100 (Palestinian
Refugees (UNRWA))
IDPs: 305,000 (most displaced from
Golan Heights during 1967 Arab-Israeli
War) (2007)
Trafficking in persons: current situation:
Syria is a destination country for women
from South and Southeast Asia and
Africa for domestic servitude and from
Eastern Europe and Iraq for sexual
exploitation; women are recruited for
work in Syria as domestic servants, but
some face conditions of exploitation and
involuntary servitude including long
hours, non-payment of wages, with¬
holding of passports and other restric¬
tions on movement, and physical and
sexual abuse; Eastern European women
recruited for work in Syria as cabaret
dancers are not permitted to leave their
work premises without permission and
have their passports withheld; some dis¬
placed Iraqi women and children are
reportedly forced into sexual exploita¬
tion
tier rating: Tier 3 — Syria does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so
Illicit drugs: a transit point for opiates,
hashish, and cocaine bound for regional
and Western markets; weak anti-money-
laundering controls and bank privatiza¬
tion may leave it vulnerable to money
laundering
631
Background: The Tajik people came
under Russian rule in the 1860s and
1870s, but Russia’s hold on Central Asia
weakened following the Revolution of
1917. Bolshevik control of the area was
fiercely contested and not fully reestab¬
lished until 1925. Much of present-day
Sughd province was transferred from the
Uzbekistan SSR to newly formed
Tajikistan SSR in 1929. Ethnic Uzbeks
form a substantial minority in Sughd
province. Tajikistan became inde¬
pendent in 1991 following the breakup
of the Soviet Union, and it is now in the
process of strengthening its democracy
and transitioning to a free market
economy after its 1992-97 civil war.
There have been no major security inci¬
dents in recent years, although the
country remains the poorest in the
former Soviet sphere. Attention by the
international community in the wake of
the war in Afghanistan has brought
increased economic development and
security assistance, which could create
jobs and increase stability in the long
term. Tajikistan is in the early stages of
seeking World Trade Organization mem¬
bership and has joined NATO’s
Partnership for Peace.
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00
E
Map references: Asia
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area— comparative: slightly smaller
than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km,
China 414 km, Kyrgyzstan 870 km,
Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: midlatitude continental, hot
summers, mild winters; semiarid to polar
in Pamir Mountains
Terrain: Pamir and Alay Mountains
dominate landscape; western Fergana
Valley in north, Kofarnihon and Vakhsh
Valleys in southwest
Elevation extremes:
lowest point: Syr Darya (Sirdaryo) 300 m
highest point: Qullai Ismoili Somoni
7,495 m
Natural resources: hydropower, some
petroleum, uranium, mercury, brown
coal, lead, zinc, antimony, tungsten,
silver, gold
Land use:
arable land: 6.52%
permanent crops: 0.89%
other: 92.59% (2005)
Irrigated land: 7,220 sq km (2003)
Total renewable water resources: 99.7
cu km ( 1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 11.96 cu
km/yr (4%/5%/92%)
per capita: 1,837 cu m/yr (2000)
Natural hazards: earthquakes and floods
Environment— current issues: inade¬
quate sanitation facilities; increasing
levels of soil salinity; industrial pollu¬
tion; excessive pesticides
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Environmental
Modification, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; moun¬
tainous region dominated by the Trans-
Alay Range in the north and the Pamirs
in the southeast; highest point, Qullai
Ismoili Somoni (formerly Communism
Peak), was the tallest mountain in the
former USSR
JO
JO
JOR
400
JOR
.jo
Juan de Nova Island
JU
administered as part of
French Southern and
Antarctic Lands; no ISO
codes assigned
31 00 N
36 00 E
31 57 N
35 56 E
31 00 N
36 00 E
31 00 N
36 00 E','a256caf5cbe611d7f5eb1c2a5de3887d577e60fde827507d58f139e54fffc085','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b643b84603cff9eb337c70ddc15f09ead7fc326938d8f6bc429f034df170fa0b',2009,'KE','Kenya','transnational-issues',702,'Disputes— international: Kyrgyzstan has
yet to ratify the 2001 boundary delimita¬
tion with Kazakhstan; field demarcation
of the boundaries with Turkmenistan
commenced in 2005, and with
Uzbekistan in 2004; demarcation is
scheduled to get underway with Russia in
2007; demarcation with China was com¬
pleted in 2002; creation of a seabed
boundary with Turkmenistan in the
Caspian Sea remains under discussion;
equidistant seabed treaties have been rat¬
ified with Azerbaijan and Russia in the
Caspian Sea, but no resolution has been
made on dividing the water column
among any of the littoral states
Refugees and internally displaced per¬
sons: refugees (country of origin): 3,700
(Russia); 508 (Afghanistan) (2007)
Illicit drugs: significant illicit cultiva¬
tion of cannabis for CIS markets, as well
as limited cultivation of opium poppy
and ephedra (for the drug ephedrine);
limited government eradication of illicit
crops; transit point for Southwest Asian
narcotics bound for Russia and the rest of
Europe; significant consumer of opiates
Disputes — international: Kenya served
as an important mediator in brokering
Sudan’s north-south separation in
February 2005; Kenya provides shelter to
almost a quarter of a million refugees,
including Ugandans who flee across the
border periodically to seek protection
from Lord’s Resistance Army (LRA)
rebels; Kenya works hard to prevent the
clan and militia fighting in Somalia from
spreading across the border, which has
long been open to nomadic pastoralists;
the boundary that separates Kenya’s and
Sudan’s sovereignty is unclear in the
“Ilemi Triangle,” which Kenya has
administered since colonial times
Refugees end internally displaced per¬
sons: refugees (country of origin): 173,702
(Somalia); 73,004 (Sudan); 16,428
(Ethiopia)
lDPs: 250,000-400,000 (2007 post-elec¬
tion violence; KANU attacks on opposi¬
tion tribal groups in 1990s) (2007)
348
KE
KE
KEN
404
KEN
.ke
Kingman Reef
KQ
-
UMI
-
ISO includes with the US
Minor Outlying Islands
4 03 S
39 40 E
Atlantic Ocean
18 30 N
67 45 W
1 17 S
36 49 E','557dc5902933e31e444bd89e7ecc176819f306c15581dd5a2492b662e748a6bd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdd9968db8f90257319a3bb02ab5031744889106dd2643edcde6a40c7b4d1a1a',2009,'KI','Kiribati','transnational-issues',703,'Trafficking in persons: current situation:
Kenya is a source, transit, and destina¬
tion country for men, women, and chil¬
dren trafficked for forced labor and
sexual exploitation; children are traf¬
ficked within the country for domestic
servitude, street vending, agricultural
labor, and sexual exploitation; men,
women, and girls are trafficked to the
Middle East, other African nations,
Western Europe, and North America for
domestic servitude, enslavement in mas¬
sage parlors and brothels, and manual
labor; Chinese women trafficked for
sexual exploitation reportedly transit
Nairobi and Bangladeshis may transit
Kenya for forced labor in other countries
tier rating: Tier 2 Watch List — Kenya is
placed on the Tier 2 Watch List due to a
lack of evidence of increasing efforts to
combat severe forms of trafficking
Illicit drugs: widespread harvesting of
small plots of marijuana; transit country for
South Asian heroin destined for Europe
and North America; Indian methaqualone
also transits on way to South Africa; signif¬
icant potential for money-laundering
activity given the country''s status as a
regional financial center; massive corrup¬
tion, and relatively high levels of narcotics-
associated activities
S 400 aOOKm
o 400 aoomi
STATES T
* MimtM Atoll
Horn Pacific 0emn
♦ <>
* * %>
^■TARAWA Howland !. ,
n* Sak«j *. fy s I Ktritimmi
. % •* Kmtmb iarvisi. (Christmas I.)
Rawtki a! S4
Islands) __ * ''(Phoenix %.
T«VAtV . Islands) . 9
tesoteo south Pacific Occsc %
Cook H- ■■■ ,
, <HJt ) ■
, SAMOA
Pi weft .
SSCOM0N
ISUN0S
VANUATU r . S***»t»*i
> mn -
an ■
''S <;
, rmm.
H.’m-ih.
w,
Disputes— international: none
KOREA, NORTH
Disputes— international: risking arrest,
imprisonment, and deportation, tens of
thousands of North Koreans cross into
China to escape famine, economic priva¬
tion, and political oppression; North
Korea and China dispute the sovereignty
of certain islands in Yalu and Tumen
rivers; Military Demarcation Line within
the 4-km wide Demilitarized Zone has
separated North from South Korea since
1953; periodic incidents in the Yellow
Sea with South Korea which claims the
Northern Limiting Line as a maritime
boundary; North Korea supports South
Korea in rejecting Japan’s claim to
Liancourt Rocks (Tok-do/Take-shima)
Refugees and internally displaced per¬
sons: IDPs: undetermined (flooding in
mid-2007 and famine during mid-1990s)
(2007)
Trafficking in persons: current situation:
North Korea is a source country for men,
women, and children trafficked for the
purposes of forced labor and sexual
exploitation; North Korea’s own system of
political repression includes forced labor
in a network of prison camps where an
estimated 150,000 to 200,000 persons are
incarcerated; the illegal status of North
Koreans in China and other countries
increases their vulnerability to trafficking
schemes and sexual and physical abuse;
North Koreans forcibly returned from
China may be subject to hard labor in
prison camps operated by the government
tier rating: Tier 3 — North Korea does not
fully comply with minimum standards for
the elimination of trafficking and is not
making significant efforts to do so
Illicit drugs: for years, from the 1970s
into the 2000s, citizens of the
Democratic People’s Republic of (North)
Korea (DPRK), many of them diplo¬
matic employees of the government,
were apprehended abroad while traf¬
ficking in narcotics, including two in
Turkey in December 2004; police inves¬
tigations in Taiwan and Japan in recent
years have linked North Korea to large
illicit shipments of heroin and metham-
phetamine, including an attempt by the
North Korean merchant ship Pong Su to
deliver 150 kg of heroin to Australia in
April 2003
354
: NORTH KOREA ••
$ m
S’ m ihm
SEOUL *ffgS «*-
!nch*6n* . .Wdnju
'' 1»uw6r»
K f
H< ■■
/*
U&S&Stott
fkKM
Po haot?
Taegu. *
*Chdnfu Ulsar^
80S:
Of
Mm
•Kwangju * *p
Mokpo PuSan
Vi*
Ch&ju^fo
■■"'' A
Hv
*<A . >Mb
» .,,A
J}0 ,
: * Mm®
% ;
Disputes — international: Military
Demarcation Line within the 4-km wide
Demilitarized Zone has separated North
from South Korea since 1953; periodic
incidents with North Korea in the
Yellow Sea over the Northern Limiting
Line, which South Korea claims as a
maritime boundary; South Korea and
Japan claim Liancourt Rocks (Tok-
do/Take-shima), occupied by South
Korea since 1954
Disputes— international: Serbia with
several other states protest the US and
other states’ recognition of Kosovo’s
declaring itself as a sovereign and inde¬
pendent state in February 2008; ethnic
Serbian municipalities along Kosovo’s
northern border challenge final status of
Kosovo-Serbia boundary; several thou¬
sand NATO-led KFOR peacekeepers
under UNMIK authority continue to
keep the peace within Kosovo between
the ethnic Albanian majority and the
Serb minority in Kosovo; Kosovo author¬
ities object to alignment of the Kosovo
boundary with Macedonia in accordance
with the 2000 Macedonia-Serbia and
Montenegro delimitation agreement
Refugees and internally displaced per¬
sons: IDP’s: 21,000 (2007)
Background: Britain oversaw foreign
relations and defense for the ruling
Kuwaiti AL-SABAH dynasty from 1899
until independence in 1961. Kuwait was
attacked and overrun by Iraq on 2
August 1990. Following several weeks of
aerial bombardment, a US-led, UN
coalition began a ground assault on 23
February 1991 that liberated Kuwait in
four days. Kuwait spent more than $5 bil-
360
KR
KI
KIR
296
KIR
.ki
Korea, North
KN
KP
PRK
408
PRK
.kp
Korea, South
KS
KR
KOR
410
KOR
.kr
Kosovo
KV
-
''
-
-
ISO codes have not been
designated
0 52 S
169 35 E
Hungary, Romania, Serbia
45 30 N
21 00 E
Pacific Ocean
5 00 S
128 00 E
Brunei
4 53 N
114 56 E
2 49 S
171 40 W
1 52 N
157 20 W
Arctic Ocean
69 00 N
171 00 W
Federated States of Micronesia
7 25 N
151 47 W
Turkey
36 50 N
34 30 E
3 08 S
171 05 W
1 25 N
173 00 E
2 49 S
171 40 W
Arctic Ocean
76 00 N
80 00 E
Russia
43 40 N
41 50 E
1 52 N
157 20 W
Moldova
47 00 N
28 50 E
Atlantic Ocean
36 00 N
23 00 E
0 52 S
169 35 E
3 30 S
172 00 W
1 25 N
173 00 E
Pacific Ocean
50 00 N
141 00 E
10 06 S
152 23 W
Wake Island
19 17 N
166 39 E','c378dc34861fe2f73bfb36a216cb3af877772929d5884093bfc60df04c75ea01','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10dd3504754f5ea15ce15052d4aaad8d150cec84d49893a5e14d1b94a9f81dd',2009,'KW','Kuwait','transnational-issues',711,'lion to repair oil infrastructure damaged
during 1990-91. The AL-SABAH
family has ruled since returning to power
in 1991 and reestablished an elected leg¬
islature that in recent years has become
increasingly assertive.
Location: Middle East, bordering the
Persian Gulf, between Iraq and Saudi
Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area: total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
Area — comparative: slightly smaller
than New Jersey
Land boundaries:
total: 462 km
border countries: Iraq 240 km, Saudi
Arabia 222 km
Coastline: 499 km
Maritime claims: territorial sea: 12 nm
Climate: dry desert; intensely hot sum¬
mers; short, cool winters
Terrain: flat to slightly undulating desert
plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish,
shrimp, natural gas
Land use:
arable land: 0.84%
permanent crops: 0.17%
other: 98.99% (2005)
Irrigated land: 130 sq km (2003)
Total renewable water resources: 0.02
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.44 cu
km/yr (45%/2%/52%)
per capita: 164 cu m/yr (2000)
Natural hazards: sudden cloudbursts are
common from October to April and
bring heavy rain, which can damage
roads and houses; sandstorms and dust
storms occur throughout the year but are
most common between March and
August
Environment — current issues: limited
natural fresh water resources; some of
world’s largest and most sophisticated
desalination facilities provide much of
the water; air and water pollution; deser¬
tification
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: Marine Dumping
Geography — note: strategic location at
head of Persian Gulf
Population: 2,596,799
note: includes 1,291,354 non-nationals
(July 2008 est.)
Age structure:
0-14 years: 26.6% (male 351,057/female
338,634)
15-64 years: 70.6% (male
1,172,460/female 659,927)
65 years and over: 2.9% (male
46,770/female 27,951) (2008 est.)
Median age:
total: 26.1 years
male: 28 years
female: 22.6 years (2008 est.)
Population growth rate: 3.591%
note: this rate reflects a return to pre-
Gulf crisis immigration of expatriates
(2008 est.)
Birth rate: 21.9 births/1,000 population
(2008 est.)
Death rate: 2.37 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 16.39 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.78 male(s)/female
65 years and over: 1.67 male(s)/female
total population: 1.53 male(s)/female
(2008 est.)
infant mortality rate:
total: 9.22 deaths/1,000 live births
male: 10.2 deaths/ 1,000 live births
female: 8.21 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 77.53 years
male: 76.38 years
female: 78.73 years (2008 est.)
Total fertility rate: 2.81 children
bom/woman (2008 est.)
HIV/AIDS— adult prevalence rate:
0.12% (2001 est.)
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab
35%, South Asian 9%, Iranian 4%, other
7%
Religions: Muslim 85% (Sunni 70%,
Shi’a 30%), other (includes Christian,
Hindu, Parsi) 15%
Languages: Arabic (official), English
widely spoken
Literacy: definition: age 15 and over can
read and write
total population: 93.3%
male: 94-4%
female: 91% (2005 census)
Country name:
conventional long form: State of Kuwait
conventional short form: Kuwait
local long form: Dawlat al Kuwayt
local short form: Al Kuwayt
Government type: constitutional emirate
Capital: name: Kuwait
geographic coordinates: 29 22 N, 47 58 E
time difference: UTC+3 (8 hours ahead of
Washington, DC during Standard Time)
Administrative divisions: 6 gover-
norates (muhafazat, singular —
muhafazah); Al Ahmadi, Al ‘Asimah, Al
Farwaniyah, Al Jahra’, Hawalli, Mubarak
Al Kabir
Independence: 19 June 1961 (from UK)
National holiday: National Day, 25
February (1950)
Constitution: approved and promulgated
1 1 November 1962
Legal system: civil law system with
Islamic law significant in personal mat¬
ters; has not accepted compulsory ICJ
jurisdiction
Suffrage: NA years of age; universal
(adult); note — males in the military or
police are not allowed to vote; adult
females were allowed to vote as of 16
May 2005; all voters must have been cit¬
izens for 20 years
Executive branch:
chief of state: Amir SABAH al- Ahmad
al-Jabir al-Sabah (since 29 January
2006); Crown Prince NAWAF al-
Ahmad al-Jabir al-Sabah
head of government: Prime Minister
NASIR MUHAMMAD al-Ahmad al-
Sabah (since 3 April 2007); First Deputy
Prime Minister JABIR Mubarak al-
Hamad al-Sabah (since 9 February
2006); Deputy Prime Ministers
MUHAMMAD al-Sabah al-Salim al-
Sabah (since 9 February 2006) and
Faysal al-HAJJI (since 5 April 2007)
cabinet: Council of Ministers appointed
by the prime minister and approved by
the Amir
elections: none; the amir is hereditary;
the amir appoints the prime minister and
deputy prime ministers
Legislative branch: unicameral
National Assembly or Majlis al-Umma
(50 seats; members elected by popular
361
THE CIA WORLD FACTBOOK
vote to serve four-year terms; all cabinet
ministers are also ex officio voting mem¬
bers of the National Assembly)
elections: last held 17 May 2008 (next
election to be held in 2012)
election results: percent of vote by bloc —
NA; seats by bloc — Sunni 21, Islamic
Salafi Alliance 10, Liberals 7, Shiites 5,
Popular Action Bloc 4, Islamic
Constitutional Movement 3
Judicial branch; High Court of Appeal
Political parties and leaders: none; for¬
mation of political parties is in practice
illegal but is not forbidden by law
Political pressure groups and leaders:
a number of political groups act as de
facto parties; several legislative blocs
operate in the National Assembly: tribal
groups, merchants, Shia activists,
Islamists, secular liberals and pro-govern¬
ment deputies; in mid-2006, a coalition
of Islamists, liberals, and Shia cam¬
paigned successfully for electoral reform
to reduce corruption
International organization participa¬
tion: ABEDA, AfDB, AFESD, AMF,
BDEAC, CAEU, FAO, G-77, GCC,
IAEA, IBRD, ICAO, ICC, ICCt (signa¬
tory), ICRM, IDA, IDB, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, IMSO,
Interpol, IOC, IPU, ISO, ITSO, ITU,
ITUC, LAS, MIGA, NAM, OAPEC,
OIC, OPCW, OPEC, PCA, UN,
UNCTAD, UNESCO, UNIDO,
UNITAR, UNWTO, UPU, WCO,
WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador SALIM al-
Abdallah al-Jabir al-Sabah
chancery: 2940 Tilden Street NW,
Washington, DC 20008
telephone: [1] (202) 966-0702
FAX: [1] (202) 966-0517
Diplomatic representation from the US:
chief of mission: Ambassador Deborah K.
JONES
embassy: Bayan 36302, Area 14, Al-
Masjed Al-Aqsa Street (near the Bayan
palace), Kuwait City
mailing address: P. O. Box 77 Safat 13001
Kuwait; or PSC 1280 APO AE 09880-
9000
telephone: [965] 259-1001
FAX: [965] 538-0282
Flag description: three equal horizontal
bands of green (top), white, and red with
a black trapezoid based on the hoist side;
design, which dates to 1961, based on
the Arab revolt flag of World War I
KU
KW
KWT
414
KWT
.kw
29 30 N
45 45 E
29 47 N
48 10 E
29 20 N
47 59 E
Russia
54 00 N
86 00 E','e72c0e5edff4c1dbb485e048135608f79525ca9d8bd9f98dfa85461577642ced','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea1e36833498ec0f85879bc48d8acdb30b8f8bba68df861b7ed20f5bfe4e54e',2009,'KG','Kyrgyzstan','transnational-issues',717,'_
Disputes — international: Kuwait and
Saudi Arabia continue negotiating a
joint maritime boundary with Iran; no
maritime boundary exists with Iraq in
the Persian Gulf
Trafficking in persons: current situation:
Kuwait is a destination country for men
and women who migrate legally from
South and Southeast Asia for domestic
or low-skilled labor, but are subjected to
conditions of involuntary servitude by
employers in Kuwait including condi¬
tions of physical and sexual abuse, non¬
payment of wages, confinement to the
home, and withholding of passports to
restrict their freedom of movement;
Kuwait is reportedly a transit point for
South and East Asian workers recruited
for low-skilled work in Iraq; some of
these workers are deceived as to the true
location and nature of this work, and
others are subjected to conditions of
involuntary servitude in Iraq; in past
years, Kuwait was also a destination
country for children exploited as camel
jockeys, but this form of trafficking
appears to have ceased
tier rating: Tier 3 — insufficient efforts in
2006 to prosecute and punish abusive
employers and those who traffic women
for sexual exploitation; the government
failed for the third year in a row to live
up to promises to provide shelter and
protective services for victims of invol¬
untary domestic servitude and other
forms of trafficking
Disputes — international: Kyrgyzstan has
yet to ratify the 2001 boundary delimita¬
tion with Kazakhstan; disputes in Isfara
Valley delay completion of delimitation
with Tajikistan; delimitation of 130 km
of border with Uzbekistan is hampered
by serious disputes around enclaves and
other areas
Illicit drugs: limited illicit cultivation of
cannabis and opium poppy for CIS mar¬
kets; limited government eradication of
illicit crops; transit point for Southwest
Asian narcotics bound for Russia and the
rest of Europe; major consumer of opiates
366
KG
KG
KGZ
417
KGZ
•kg
Laos
LA
LA
LAO
418
LAO
.la
42 54 N
74 36 E
42 54 N
74 36 E
41 00 N
75 00 E
41 00 N
75 00 E','b7b20838dd3acb8f531761c15676013bb2b39fe6e466c942c6694cbd9f8f2ba2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaf271ee3f1f5e901d36e780bb0942c2b6013a3d94a8738eaf23b1d3a34d59fb',2009,'LV','Latvia','transnational-issues',723,'Disputes — international: Southeast
Asian states have enhanced border sur¬
veillance to check the spread of avian
flu; talks continue on completion of
demarcation with Thailand but disputes
remain over islands in the Mekong
River; concern among Mekong
Commission members that China’s con¬
struction of dams on the Mekong River
will affect water levels
Illicit drugs: estimated opium poppy cul¬
tivation in 2005 was 5,600 hectares,
about a 45% decrease from 2004; esti¬
mated potential opium production in
2005 was 28 metric tons, a significant
decrease from 200 metric tons in 2003;
unsubstantiated reports of domestic
methamphetamine production; growing
domestic methamphetamine problem
f
LG
LV
LVA
428
LVA
.lv
57 00 N
25 00 E
56 57 N
24 06 E
Atlantic Ocean
57 30 N
23 30 E','7d21192fa98c6f4b8b0b36b7c289b01621657608b9f2902cbb0c1fe020df6734','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3423f0e32932a79c0d539832385e627355c5703c9b7ce38dc3652582033a4cbd',2009,'SE','Sweden','transnational-issues',731,'Disputes— international: Russia refuses
to sign the 1997 boundary treaty due to
Latvian insistence on a unilateral clarifi-
catory declaration referencing Soviet
occupation of Latvia and territorial
losses; Russia demands better Latvian
treatment of ethnic Russians in Latvia;
as of January 2007, ground demarcation
of the boundary with Belarus was com¬
plete and mapped with final ratification
documentation in preparation; the
Latvian parliament has not ratified its
1998 maritime boundary treaty with
Lithuania, primarily due to concerns
over oil exploration rights; as a member
state that forms part of the EU’s external
border, Latvia has implemented the strict
Schengen border rules with Russia
Illicit drugs: transshipment and destina¬
tion point for cocaine, synthetic drugs,
opiates, and cannabis from Southwest
Asia, Western Europe, Latin America,
and neighboring Balkan countries;
despite improved legislation, vulnerable
to money laundering due to nascent
enforcement capabilities and compara¬
tively weak regulation of offshore compa¬
nies and the gaming industry; CIS
organized crime (including counter¬
feiting, corruption, extortion, stolen
cars, and prostitution) accounts for most
laundered proceeds
372
Background: Following the capture of
Syria from the Ottoman Empire by
Anglo-French forces in 1918, France
received a mandate over this territory
and separated out the region of Lebanon
in 1920. France granted this area inde¬
pendence in 1943. A lengthy civil war
(1975-1990) devastated the country, but
Lebanon has since made progress toward
rebuilding its political institutions.
Under the Ta’if Accord — the blueprint
for national reconciliation — the
Lebanese established a more equitable
political system, particularly by giving
Muslims a greater voice in the political
process while institutionalizing sectarian
divisions in the government. Since the
end of the war, Lebanon has conducted
several successful elections. Most militias
have been disbanded, and the Lebanese
Armed Lorces (LAL) have extended
authority over about two-thirds of the
country. Flizballah, a radical Shi’a organ¬
ization listed by the US State
Department as a Loreign Terrorist
Organization, retains its weapons.
During Lebanon’s civil war, the Arab
League legitimized in the Ta’if Accord
Syria’s troop deployment, numbering
about 16,000 based mainly east of Beirut
and in the Bekaa Valley. Israel’s with¬
drawal from southern Lebanon in May
2000 and the passage in October 2004 of
UNSCR 1559 — a resolution calling for
Syria to withdraw from Lebanon and end
its interference in Lebanese affairs —
encouraged some Lebanese groups to
demand that Syria withdraw its forces as
well. The assassination of former Prime
Minister Rafiq F1ARIRI and 20 others in
February 2005 led to massive demonstra¬
tions in Beirut against the Syrian pres¬
ence (“the Cedar Revolution”), and
Syria withdrew the remainder of its mili¬
tary forces in April 2005. In May-June
2005, Lebanon held its first legislative
elections since the end of the civil war
free of foreign interference, handing a
majority to the bloc led by Saad
HARIRI, the slain prime minister’s son.
Lebanon continues to be plagued by vio¬
lence — Hizballah kidnapped two Israeli
soldiers in July 2006 leading to a 34-day
conflict with Israel. The LAF in May-
September 2007 battled Sunni extremist
group Fatah al-Islam in the Nahr al-
Barid Palestinian refugee camp; and the
country has witnessed a string of politi¬
cally motivated assassinations since the
death of Rafiq HARIRI. Lebanese politi¬
cians in November 2007 were unable to
agree on a successor to Emile LAHUD
when he stepped down as president, cre¬
ating a political vacuum.
Location: Middle East, bordering the
Mediterranean Sea, between Israel and
Syria
Geographic coordinates: 33 50 N, 35 50
E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area — comparative: about 0.7 times the
size of Connecticut
Land boundaries: total: 454 km
border countries: Israel 79 km, Syria 375
km
Coastline: 225 km
Maritime claims: territorial sea: 12 nm
Climate: Mediterranean; mild to cool,
wet winters with hot, dry summers;
Lebanon mountains experience heavy
winter snows
Terrain: narrow coastal plain; El Beqaa
(Bekaa Valley) separates Lebanon and
Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda’ 3,088 m
Natural resources: limestone, iron ore,
salt, water-surplus state in a water-deficit
region, arable land
Land use: arable land: 16.35%
permanent crops : 13.75%
other: 69.9% (2005)
Irrigated land: 1,040 sq km (2003)
Total renewable water resources: 4 8
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.38 cu
km/yr (33%/l%/67%)
per capita: 385 cu m/yr (2000)
Natural hazards: dust storms, sand¬
storms
Environment — current issues: defor¬
estation; soil erosion; desertification; air
pollution in Beirut from vehicular traffic
and the burning of industrial wastes; pol¬
lution of coastal waters from raw sewage
and oil spills
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental
Modification, Marine Life Conservation
Geography — note: Nahr el Litani is the
only major river in Near East not
crossing an international boundary;
rugged terrain historically helped isolate,
protect, and develop numerous factional
groups based on religion, clan, and eth¬
nicity
Disputes — international: in 2006, Swazi
king advocates resort to ICJ to claim
parts of Mpumalanga and KwaZulu-
Natal from South Africa
Disputes— international: none
sw
SE
SWE
752
SWE
.se
57 43 N
11 58 E
57 30 N
18 33 E
Saint Helena
40 20 S
9 55 W
56 45 N
16 40 E
Indian Ocean
24 30 N
58 30 E
Pacific Ocean
8 30 S
125 00 E
59 20 N
18 03 E
Prance
48 35 N
7 44 E
62 00 N
15 00 E
Saratov
Volgograd
Minsk
Kharkty
Copenhagen^
DLfimKK ,','4fbcc8dfbb91ba4b4e37782be9a4d51ff6c92187582634f76ef1fb8a0e75c330','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89746a66441d7ff797fa71c84728cef07695167f8378bbe8a6871419aaa0bb3d',2009,'LB','Lebanon','transnational-issues',736,'Disputes— international: lacking a
treaty or other documentation describing
the boundary, portions of the Lebanon-
Syria boundary are unclear with several
sections in dispute; since 2000, Lebanon
has claimed Shab’a Farms area in the
Israeli-occupied Golan Heights; the
roughly 2, 000-strong UN Interim Force
in Lebanon (UNIFIL) has been in place
since 1978
Refugees and internally displaced per¬
sons: refugees (country of origin ): 405,425
(Palestinian Refugees (UNRWA));
50,000-60,000 (Iraq)
IDPs: 17,000 (1975-90 civil war, Israeli
invasions); 200,000 (July-August 2006
war) (2007)
Illicit drugs: cannabis cultivation dra¬
matically reduced to 2,500 hectares in
2002 despite continued significant
cannabis consumption; opium poppy cul¬
tivation minimal; small amounts of Latin
American cocaine and Southwest Asian
heroin transit country on way to
European markets and for Middle
Eastern consumption; money laundering
of drug proceeds fuels concern that
extremists are benefiting from drug traf¬
ficking
LE
LB
LBN
422
LBN
.lb
33 53 N
35 30 E
34 00 N
36 05 E
33 50 N
36 50 E
33 50 N
36 50 E
Democratic Republic of
11 40 S
27 28 E
the Congo
34 26 N
35 51 E','d26132041725eeb4d4f83c35935cf2d5dbc9d657fd74aed2c32cc5ccb53037f2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f309492ce764b72f6dcfcd2014be60c4ea1ef6f192aa88542db0b1534f9f001',2009,'LR','Liberia','transnational-issues',744,'Disputes — international: none
Disputes — international: although civil
unrest continues to abate with the assis¬
tance of 18,000 UN Mission in Liberia
(UNMIL) peacekeepers, as of January
2007, Liberian refugees still remain in
Guinea, Cote d’Ivoire, Sierra Leone, and
Ghana; Liberia, in turn, shelters refugees
fleeing turmoil in Cote d’Ivoire; despite
the presence of over 9,000 UN forces
(UNOCI) in Cote d’Ivoire since 2004,
ethnic conflict continues to spread into
neighboring states who can no longer send
their migrant workers to Ivorian cocoa
plantations; UN sanctions ban Liberia
from exporting diamonds and timber
Refugees and internally displaced per¬
sons: refugees (country of origin): 12,600
(Cote d’Ivoire)
IDPs: 13,000 (civil war from 1990-2004;
IDP resettlement began in November
2004) (2007)
Illicit drugs: transshipment point for
Southeast and Southwest Asian heroin
and South American cocaine for the
European and US markets; corruption,
criminal activity, arms-dealing, and dia¬
mond trade provide significant potential
for money laundering, but the lack of
well-developed financial system limits
the country’s utility as a major money-
laundering center
LI
LR
LBR
430
LBR
.lr
6 18 N
10 47 W','45b58cc0044b3eef496de4607e3d45da35ad1f00ef783d722eb1a1f46aced107','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f35abc0c98cf50fe2cf7a287d88482ed1a23ba7267572417267c753637c68e4',2009,'LY','Libya','transnational-issues',749,'_
Background: The Italians supplanted the
Ottoman Turks in the area around
Tripoli in 1911 and did not relinquish
their hold until 1943 when defeated in
World War II. Libya then passed to UN
administration and achieved independ¬
ence in 1951. Following a 1969 military
coup, Col. Muammar Abu Minyar al-
QADHAFI began to espouse his own
political system, the Third Universal
Theory. The system is a combination of
socialism and Islam derived in part from
tribal practices and is supposed to be
implemented by the Libyan people
themselves in a unique form of “direct
democracy.” QADHAFI has always seen
himself as a revolutionary and visionary
leader. He used oil funds during the
1970s and 1980s to promote his ideology
outside Libya, supporting subversives and
terrorists abroad to hasten the end of
Marxism and capitalism. In addition,
beginning in 1973, he engaged in mili¬
tary operations in northern Chad’s
Aozou Strip — -to gain access to minerals
and to use as a base of influence in
Chadian politics— but was forced to
retreat in 1987. UN sanctions in 1992
isolated QADHAFI politically following
the downing of Pan AM Flight 103 over
Lockerbie, Scotland. During the 1990s,
QADHAFI began to rebuild his relation¬
ships with Europe. UN sanctions were
suspended in April 1999 and finally
lifted in September 2003 after Libya
accepted responsibility for the Lockerbie
bombing. In December 2003, Libya
announced that it had agreed to reveal
and end its programs to develop weapons
of mass destruction and to renounce ter¬
rorism. QADHAFI has made significant
strides in normalizing relations with
Western nations since then. He has
received various Western European
leaders as well as many working-level
and commercial delegations, and made
his first trip to Western Europe in 15
years when he traveled to Brussels in
April 2004- Libya has responded in good
faith to legal cases brought against it in
US courts for terrorist acts that predate
its renunciation of violence. Claims for
compensation in the Lockerbie bombing,
LaBelle disco bombing, and UTA 772
bombing cases are ongoing. The US
rescinded Libya’s designation as a state
sponsor of terrorism in June 2006. In late
2007, Libya was elected by the General
Assembly to a nonpermanent seat on the
United Nations Security Council for the
2008-09 term.
LY
LY
LBY
434
LBY
•ly
,U
31 00 N
22 00 E
Czech Republic, Slovakia
49 00 N
18 00 E
32 54 N
13 11 E
31 00 N
14 00 E
Saint Helena
37 15 S
12 30 W','a51d418e722f97533649e3dc33698febfb5b4b0d8b0740e24222185cc1202626','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a8bc464543c92156fe4596a1818f758015e4d4284c2b259df871a01fb622e85',2009,'LI','Liechtenstein','transnational-issues',756,'Disputes — international: Libya has
claimed more than 32,000 sq km in
southeastern Algeria and about 25,000
sq km in the Tommo region of N iger in a
currently dormant dispute; various
Chadian rebels from the Aozou region
reside in southern Libya
Refugees and internally displaced per¬
sons: refugees (country of origin): 8,000
(Palestinian Territories) (2007)
Trafficking in persons: current situation:
Libya is a transit and destination country
for men, women, and children from sub-
Saharan Africa and Asia trafficked for
forced labor and sexual exploitation;
many victims willingly migrate to Libya
en route to Europe with the help of smug¬
glers, but may be forced into prostitution
or work as laborers and beggars to pay off
their $800-$ 1,200 smuggling debt;
laborers from Egypt, Sudan, and Ethiopia
are reportedly trafficked to Libya for the
purpose of labor exploitation
tier rating: Tier 2 Watch List — Libya is
placed on the Tier 2 Watch List for its
lack of evidence of increasing efforts to
address trafficking since 2004
Background: The Principality of
Liechtenstein was established within the
Holy Roman Empire in 1719. Occupied
by both French and Russian troops
during the Napoleanic wars, it became a
sovereign state in 1806 and joined the
Germanic Confederation in 1815.
Liechtenstein became fully independent
in 1866 when the Confederation dis¬
solved. Until the end of World War I, it
was closely tied to Austria, but the eco¬
nomic devastation caused by that con¬
flict forced Liechtenstein to enter into a
customs and monetary union with
Switzerland. Since World War II (in
which Liechtenstein remained neutral),
the country’s low taxes have spurred out¬
standing economic growth. In 2000,
shortcomings in banking regulatory
oversight resulted in concerns about the
use of financial institutions for money
laundering. However, Liechtenstein
implemented anti-money-laundering
legislation and a Mutual Legal
Assistance Treaty with the US went into
effect in 2003.
LS
LI
LIE
438
LIE
47 09 N
931 E','0df7f4c72593203f8683e32dce59d8a32f2acfe2b405bd7cfc9ac6cf3bf9ae9f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b271e6812fa35507742c76aa7a816f9cdd3ee20ae76640ba490a3c8baa275132',2009,'LT','Lithuania','transnational-issues',763,'Disputes — international: none
Illicit drugs: has strengthened money
laundering controls, but money laun¬
dering remains a concern due to
Liechtenstein’s sophisticated offshore
financial services sector
Background: Lithuanian lands were
united under MINDAUGAS in 1236;
over the next century, through alliances
and conquest, Lithuania extended its ter¬
ritory to include most of present-day
Belarus and Ukraine. By the end of the
14th century Lithuania was the largest
state in Europe. An alliance with Poland
in 1386 led the two countries into a
union through the person of a common
ruler. In 1569, Lithuania and Poland for¬
mally united into a single dual state, the
Polish-Lithuanian Commonwealth. This
entity survived until 1795, when its rem¬
nants were partitioned by surrounding
countries. Lithuania regained its inde¬
pendence following World War I but was
annexed by the USSR in 1940 — an
action never recognized by the US and
many other countries. On 1 1 March
1990, Lithuania became the first of the
Soviet republics to declare its independ¬
ence, but Moscow did not recognize this
proclamation until September of 1991
(following the abortive coup in
Moscow). The last Russian troops with¬
drew in 1993. Lithuania subsequently
restructured its economy for integration
into Western European institutions; it
joined both NATO and the EU in the
spring of 2004-
Location: Eastern Europe, bordering the
Baltic Sea, between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00
E
Map references: Europe
Area: total: 65,200 sq km
land: NA sq km
water: NA sq km
Area — comparative: slightly larger than
West Virginia
Land boundaries:
total: 1,613 km
387
THE CIA WORLD FACTBOOK
border countries: Belarus 653.5 km, Latvia
588 km, Poland 103.7 km, Russia
(Kaliningrad) 267.8 km
Coastline: 99 km
Maritime claims: territorial sea: 12 nm
Climate: transitional, between maritime
and continental; wet, moderate winters
and summers
Terrain: lowland, many scattered small
lakes, fertile soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines Kalnas 293.6 m
Natural resources: peat, arable land,
amber
Land use:
arable land: 44-81%
permanent crops: 0.9%
other: 54.29% (2005)
Irrigated land: 70 sq km (2003)
Total renewable water resources: 24 5
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.33 cu
km/yr (78%/15%/7%)
per capita: 971 cu m/yr (2003)
Natural hazards: NA
Environment— current issues: contami¬
nation of soil and groundwater with
petroleum products and chemicals at
military bases
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: fertile central plains
are separated by hilly uplands that are
ancient glacial deposits
Disputes— international: Lithuania and
Russia committed to demarcating their
boundary in 2006 in accordance with the
land and maritime treaty ratified by
Russia in May 2003 and by Lithuania in
1999; Lithuania operates a simplified
transit regime for Russian nationals trav¬
eling from the Kaliningrad coastal
exclave into Russia, while still con¬
forming, as a EU member state having an
external border with a non-EU member,
to strict Schengen border rules; the
Latvian parliament has not ratified its
1998 maritime boundary treaty with
Lithuania, primarily due to concerns
over potential hydrocarbons; as of
January 2007, ground demarcation of the
boundary with Belarus was complete and
mapped with final ratification docu¬
ments in preparation
Illicit drugs: transshipment and destina¬
tion point for cannabis, cocaine, ecstasy,
and opiates from Southwest Asia, Latin
America, Western Europe, and neigh¬
boring Baltic countries; growing produc¬
tion of high-quality amphetamines, but
limited production of cannabis, metham-
phetamines; susceptible to money laun¬
dering despite changes to banking
legislation
LH
LT
LTU
440
LTU
.it
56 00 N
24 00 E
Atlantic Ocean
43 30 N
9 00 E
55 43 N
21 30 E
54 41 N
25 19 E','6cf3182439818e178a199a9d65be18205b6d0bc5892fd68a0d7906afa0b79130','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df2f4a445589231ba4eda20817c13bbd500e3ec9cc5fb5d367ba69f7cf051c75',2009,'LU','Luxembourg','transnational-issues',765,'Background: Founded in 963,
Luxembourg became a grand duchy in
1815 and an independent state under the
Netherlands. It lost more than half of its
territory to Belgium in 1839, but gained
a larger measure of autonomy. Full inde¬
pendence was attained in 1867. Overrun
by Germany in both World Wars, it
ended its neutrality in 1948 when it
entered into the Benelux Customs
Union and when it joined NATO the
following year. In 1957, Luxembourg
became one of the six founding countries
of the European Economic Community
(later the European Union), and in 1999
it joined the euro currency area.
Disputes— international: none
393
Disputes— international: none
Trafficking in persons: current situation:
Macau is a transit and destination terri¬
tory for women trafficked for the purpose
of commercial sexual exploitation; most
females in Macau’s sizeable sex industry
come from the interior regions of China
or Mongolia, though a significant
number also come from Russia, Eastern
Europe, Thailand, and Vietnam; the
majority of women in Macau’s prostitu¬
tion trade appear to have entered Macau
and the sex trade voluntarily, though
there is evidence that some are deceived
or coerced into sexual servitude, often
through the use of debt bondage; organ¬
ized criminal syndicates are reportedly
involved in bringing women to Macau,
and fear of reprisals from these groups
may prevent some women from seeking
help
tier rating: Tier 2 Watch List — Macau is
placed on the Tier 2 Watch List for
failing to show evidence of increasing
efforts to address trafficking since 2004
Illicit drugs: transshipment point for
drugs going into mainland China; con¬
sumer of opiates and amphetamines
_
TiC A 9
MACEDONIA
LU
LU
LUX
442
LUX
.lu
Macau
MC
MO
MAC
446
MAC
.mo
Macedonia
MK
MK
MKD
807
FYR
.mk
49 45 N
6 10 E','6e2415b79f4f9b4447dce5f386f2a05e4f04f4d4048f8b2ee182565a00be574e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c37ba342ae627946ffee4dd5142f5f7ec52d59a80edafdd316a8dd6c8bf1885d',2009,'RS','Serbia','transnational-issues',772,'KOSOVO
,!,S
bums aria
8 S3 iQ0k)«
Igfj
f h<&&
0 tmm
Disputes — international: Serbia with
several other states protest the U.S. and
other states’ recognition of Kosovo’s
declaring itself as a sovereign and inde¬
pendent state in February 2008; ethnic
Serbian municipalities along Kosovo’s
northern border challenge final status of
Kosovo-Serbia boundary; several thou¬
sand NATO-led KFOR peacekeepers
under UNMIK authority continue to
keep the peace within Kosovo between
the ethnic Albanian majority and the
Serb minority in Kosovo; Serbia delim¬
ited about half of the boundary with
Bosnia and Herzegovina, but sections
along the Drina River remain in dispute
Refugees and infernally displaced per¬
sons: refugees (country of origin): 71,111
(Croatia); 27,414 (Bosnia and
Herzegovina); 206,000 (Kosovo), note —
mostly ethnic Serbs and Roma who fled
Kosovo in 1999 (2007)
Illicit drugs: transshipment point for
Southwest Asian heroin moving to
Western Europe on the Balkan route;
economy vulnerable to money laundering
Background: A lengthy struggle between
France and Great Britain for the islands
ended in 1814, when they were ceded to
the latter. Independence came in 1976.
Socialist rule was brought to a close with
a new constitution and free elections in
1993. President France-Albert RENE,
who had served since 1977, was re¬
elected in 2001, but stepped down in
2004. Vice President James MICHEL
took over the presidency and in July
2006 was elected to a new five-year term.
RI
RS
SRB
688
.rs
44 50 N
20 30 E
42 30 N
21 00 E
Federated States of Micronesia
5 20 N
163 00 E
44 00 N
21 00 E
Canada (Newfoundland)
47 34 N
52 43 W
Lalkland Islands (Islas Malvinas) 51 42 S
57 41 W
45 35 N
20 00 E','643e455e1fd3c2700d8574ac8036096330d7b0e102d3b137bdcfe6d5aa1ffc3c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03b9ee63fd52ea1477ed4e8131db4ad7abb299d3d2512f25d490eb114450ac2b',2009,'BG','Bulgaria','transnational-issues',773,'Kumanovo
SKOPJE
Kifevo
Strtimica
Bt-toia
INTRODUCTIO
Background: Macedonia gained its inde¬
pendence peacefully from Yugoslavia in
1991, but Greece’s objection to the new
state’s use of what it considered a
Hellenic name and symbols delayed
international recognition, which
occurred under the provisional designa¬
tion of “the Former Yugoslav Republic of
Macedonia.” In 1995, Greece lifted a 20-
month trade embargo and the two coun¬
tries agreed to normalize relations. The
United States began referring to
Macedonia by its constitutional name,
Republic of Macedonia, in 2004 and
negotiations continue between Greece
and Macedonia to resolve the name
issue. Some ethnic Albanians, angered
by perceived political and economic
inequities, launched an insurgency in
2001 that eventually won the support of
the majority of Macedonia’s Albanian
population and led to the internation¬
ally-brokered Framework Agreement,
which ended the fighting by establishing
a set of new laws enhancing the rights of
minorities. Fully implementating the
Framework Agreement and stimulating
economic growth and development con¬
tinue to be challenges for Macedonia,
although progress has been made on both
fronts over the past several years.
BU
BG
BGR
100
BGR
.bg
42 41 N
23 19 E
Oasogtr/’;
The*sak»mkt
Istanbul
Samsttn
Surwjayit
Si||. Trabzon*
a4GLABl
AKMOMA AZEKUAUAPi *
;Et2«ru% ^-Yerevan Bak u
. <X- ‘S.
, Ankara
. * .,/m,r :
■ a DenisEti
konva
Ku*>-e
Dars»3Ptf::
Qazvln''
Mosul
Nicosia
>
SYRIA
1 ■ '' v/
Kirkuk','a451446671b58c5477be150262898de92444b57b4ec30e54284b9057b6d4ca82','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128b0682f58d4158aac6ce7a645db89539d3c3a4b36c51e10de7fe7a3bdedd83',2009,'MG','Madagascar','transnational-issues',777,'Disputes — international: ethnic
Albanians in Kosovo object to demarca¬
tion of the boundary with Serbia in
accordance with the 2000 Macedonia-
Serbia and Montenegro delimitation
agreement; Greece continues to reject
the use of the name Macedonia or
Republic of Macedonia
Refugees and internally displaced per¬
sons: IDPs: fewer than 1,000 (ethnic
conflict in 2001) (2007)
Illicit drugs: major transshipment point
for Southwest Asian heroin and hashish;
minor transit point for South American
cocaine destined for Europe; although
not a financial center and most criminal
activity is thought to be domestic,
money laundering is a problem due to a
mostly cash-based economy and weak
enforcement
Disputes — international: claims Bassas
da India, Europa Island, Glorioso Islands,
and Juan de Nova Island (all adminis¬
tered by France)
Illicit drugs: illicit producer of cannabis
(cultivated and wild varieties) used
mostly for domestic consumption; trans¬
shipment point for heroin
MA
MG
MDG
450
MDG
.mg
18 52 S
47 30 E
20 00 S
47 00 E
20 00 S
47 00 E
Brunei, Indonesia, Malaysia, 2 30 N
Papua New Guinea, Philippines
120 00 E
797
THE CIA WORLD FACTBOOK
Name _
Malay Peninsula
Male (capital)
Mallorca, Isla de (island; also Majorca)
Malmady (region)
Malpelo, Isla de (island)
Malta Channel
Malvinas, Islas (island group)
Mamoutzou (capital)
Managua (capital)
Manama (capital)
Manchukuo (former state)
Manchuria (region)
Manila (capital)
Manipa Strait
Mannar, Gulf of
Manua Islands
Maputo (capital)
Marcus Island (Minami-tori-shima)
Margarita, Isla (island)
Mariana Islands
Marie Byrd Land (region)
Marigot (capital)
Marion Island
Marmara, Sea of
Marquesas Islands (lies Marquises)
Marseille (city)
Martin Vaz, llhas (island group)
Mas a Tierra (Robinson Crusoe Island)
Mascarene Islands
Maseru (capital)
Mata-Utu (capital)
Matsu (island)
Matthew Island
Mauritanie (local name for Mauritania)
Mazatlan (city)
Mbabane (capital)
McDonald Islands
Mecca (city)
Mediterranean Sea
Melbourne (city)
Melilla (exclave)
Memel (region)
Mesopotamia (region)
Messina, Strait of
Mexico City (capital)
Mexico, Gulf of
Middle Congo (former name for Republic of the Congo)
Milan (city)
Milwaukee Deep (Puerto Rico Trench)
Minami-tori-shima (Marcus Island)
Mindanao (island)
Mindanao Sea
Mindoro (island)
Mindoro Strait
Mingrelia (region)
Minicoy Island
Minorca Island (Isla de Menorca)
Minsk (capital)
Misr (local name for Egypt)
Mitla Pass
Mocambique (local name for Mozambique)
Mogadishu (capital)
Moldavia (region)
Molucca Sea
Moluccas (Spice Islands)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Malaysia, Thailand
7 ION
100 35 E','28797d6bd90ed90ea5bc981a752e29b0f78d8d45fda1aa122245ad49890afb86','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42fc700c48527263659dee55a61217e36cd2214e1b1bd0d063b6594ea5f9fb2e',2009,'MY','Malaysia','transnational-issues',790,'Disputes — international: disputes with
Tanzania over the boundary in Lake
Nyasa (Lake Malawi) and the mean¬
dering Songwe River remain dormant
MY
MY
MYS
458
MYS
.my
5 26 N
100 16 E
The Bahamas
23 30 N
75 46 W
3 10N
101 42 E
Russia (de facto)
44 20 N
146 00 E
5 23 N
100 15 E
Atlantic Ocean
58 44 N
3 13 W
5 20 N
117 10E
2 30 N
113 30 E','081876a1bfac596499dff0e1b4f07decc8c49336f4d7695aeba7d5927cadbb3e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0292ceca3c787193cb14e394701f249b3af1e1818471012f97100cfff59fd151',2009,'MV','Maldives','transnational-issues',797,'Disputes — international: Malaysia has
asserted sovereignty over the Spratly
Islands together with China, Philippines,
Taiwan, Vietnam, and possibly Brunei;
while the 2002 “Declaration on the
Conduct of Parties in the South China
Sea” has eased tensions over the Spratly
Islands, it is not the legally binding “code
of conduct” sought by some parties;
Malaysia was not party to the March
2005 joint accord among the national oil
companies of China, the Philippines,
and Vietnam on conducting marine
seismic activities in the Spratly Islands;
disputes continue over deliveries of fresh
water to Singapore, Singapore’s land
reclamation, bridge construction, and
maritime boundaries in the Johor and
Singapore Straits; in November 2007,
the ICJ will hold public hearings in
response to the Memorials and
Countermemorials filed by the parties in
2003 and 2005 over sovereignty of Pedra
Branca Island/Pulau Batu Puteh, Middle
Rocks and South Ledge; ICJ awarded
Ligitan and Sipadan islands, also claimed
by Indonesia and Philippines, to
Malaysia but left maritime boundary and
sovereignty of Unarang rock in the
hydrocarbon-rich Celebes Sea in dispute;
separatist violence in Thailand’s pre¬
dominantly Muslim southern provinces
prompts measures to close and monitor
border with Malaysia to stem terrorist
activities; Philippines retains a dormant
claim to Malaysia’s Sabah State in
northern Borneo; Brunei and Malaysia
are still considering international adjudi¬
cation over their disputed offshore and
deepwater seabeds, where hydrocarbon
exploration was terminated in 2003;
Malaysia’s land boundary with Brunei
around Limbang is in dispute; piracy
remains a problem in the Malacca Strait
Refugees and internally displaced per¬
sons: refugees (country of origin): 15,174
(Indonesia); 21,544 (Burma) (2007)
Trafficking in persons: current situation:
Malaysia is a destination and, to a lesser
extent, a source and transit country for
women and children trafficked for the
purposes of sexual exploitation; foreign
victims, mostly women and girls from
Burma, Cambodia, China, Indonesia,
the Philippines, Thailand, and Vietnam,
are trafficked to Malaysia for commercial
sexual exploitation; economic migrants
from countries in the region who work as
domestic servants or laborers in the con¬
struction and agricultural sectors face
exploitative conditions in Malaysia that
meet the definition of involuntary servi¬
tude; some Malaysian women, primarily
of Chinese ethnicity, are trafficked
abroad for sexual exploitation
tier rating: Tier 3 — lack of satisfactory
progress in combating trafficking in
2006; the government failed to prosecute
traffickers arrested and detained under
existing law and failed to provide ade¬
quate shelters and services to victims of
trafficking
Illicit drugs: drug trafficking prosecuted
vigorously and carries severe penalties;
heroin still primary drug of abuse, but
synthetic drug demand remains strong;
continued ecstasy and methampheta-
mine producer for domestic users and, to
a lesser extent, the regional drug market
Disputes— international : none
Refugees and internally displaced per¬
sons: IDPs: 1,000-10,000 (December
2004 tsunami victims) (2007)
MV
MV
MDV
462
MDV
.mv
3 15 N
73 00 E
4 ION
73 31 E','0678777db0ea7ded3b6c9d855cf7b59187e3e50fc89571f2a8de5c26e021abf9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a611c7b5b67a166f7c4591b68f546463dac06b74ab06142038585a2dda6b7521',2009,'ML','Mali','transnational-issues',810,'Disputes— international: none
Refugees and internally displaced per¬
sons: refugees (country of origin): 6,300
(Mauritania) (2007)
414
Background: Great Britain formally
acquired possession of Malta in 1814-
The island staunchly supported the UK
through both World Wars and remained
in the Commonwealth when it became
independent in 1964- A decade later
Malta became a republic. Since about
the mid- 1980s, the island has trans-
formed itself into a freight transshipment
point, a financial center, and a tourist
destination. Malta became an EU
member in May 2004 and began to use
the euro as currency in 2008.
ML
ML
MLI
466
MLI
.ml
12 39 N
8 00 W
17 00 N
4 00 W','c8ca6e167b15c9e839c87e50a9fc1972daf72e538ecf5eeafe816d501605f535','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe1fba5d3e2cd4a0126a741ab57cd6b422bb00a50a1e0a9b055699f68da1fda3',2009,'MH','Marshall Islands','transnational-issues',816,'Disputes — international: none
Illicit drugs: minor transshipment point
for hashish from North Africa to
Western Europe
Background: After almost four decades
under US administration as the eastern¬
most part of the UN Trust Territory of
the Pacific Islands, the Marshall Islands
attained independence in 1986 under a
Compact of Free Association.
Compensation claims continue as a
result of US nuclear testing on some of
the atolls between 1947 and 1962. The
Marshall Islands hosts the US Army
Kwajalein Atoll (USAKA) Reagan
Missile Test Site, a key installation in the
US missile defense network.
Location: Oceania, two archipelagic
island chains of 29 atolls, each made up
of many small islets, and five single
islands in the North Pacific Ocean,
about half way between Hawaii and
Disputes — international: claims US ter¬
ritory of Wake Island
419
• .• ■!'' ■■ T-’
% :,-’U •
_ _
_ _
••
V''''>
RM
MH
MHL
584
MHL
.mh
11 35 N
165 23 E
11 30 N
162 15 E
11 30 N
162 15 E
9 05 N
167 20 E
7 05 N
171 08 E
Pacific Ocean
2 00 S
117 30 E
Macedonia
41 50 N
22 00 E
8 00 N
167 00 E
Burma
16 47 N
96 10 E
9 00 N
171 00 E
Indian Ocean
20 00 N
38 00 E','e21268a4cdeae1117dab41b326dffcc1439b521729e3a8a5677dd8f96668372e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f55f9ddd417e658df94386b608dc012b715f68c537369e53cc0e87cb2a94130',2009,'MR','Mauritania','transnational-issues',818,'. • • •. '' A- '' :■
o''-
Disputes— international: Mauritanian
claims to Western Sahara remain dor¬
mant
Trafficking in persons: current situation:
Mauritania is a source and destination
country for children trafficked for the
purpose of forced labor, begging, and
domestic servitude; adults and children
are subjected to slavery-related practices
rooted in ancestral master-slave relation¬
ships in isolated parts of the country
where a barter economy exists
tier rating: Tier 2 Watch List — Mauritania
is placed on the Tier 2 Watch List for its
failure to show evidence of increased
efforts to combat trafficking, particularly
in the area of law enforcement
Background: Although known to Arab
and Malay sailors as early as the 10th
century, Mauritius was first explored by
the Portuguese in 1505; it was subse¬
quently held by the Dutch, French, and
British before independence was
attained in 1968. A stable democracy
422
MR
MR
MRT
478
MRT
.mr
20 00 N
12 00 W
20 00 N
12 00 W
Oman, United Arab Emirates
26 18 N
56 24 E
18 06 N
15 57 W','cce3fa61dbbf718a323f5d05ac802b5e8c1e5f359827ee08010042c5f05e4f11','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ff278f4fa0c65c370e413530ab0b0160290b7a4ca08fb0636ae78848ce6149c',2009,'MX','Mexico','transnational-issues',836,'Disputes — international: claimed by
MX
MX
MEX
484
MEX
.mx
Micronesia,
Federated States of
FM
FM
FSM
583
FSM
.fm
Midway Islands
MQ
-
-
UMI
-
ISO includes with the US
Minor Outlying Islands
Moldova
MD
MD
MDA
498
MDA
.md
16 51 N
99 55 W
21 10N
86 50 W
20 30 N
86 55 W
20 40 N
103 24 W
29 11 N
118 17 W
23 13 N
106 25 W
Swaziland
26 18 S
31 06 E
Heard Island and McDonald
53 06 S
73 30 E
Islands
19 24 N
99 09 W
Atlantic Ocean
25 00 N
90 00 W
Republic of the Congo
1 00 S
15 00 E
25 40 N
100 19 W
19 00 N
112 45 W
19 30 N
89 00 W
Montenegro, Serbia
43 00 N
21 00 E
Bosnia and Herzegovina,
43 00 N
19 00 E
Croatia, Macedonia,
Montenegro, Serbia, Slovenia
Bosnia and Herzegovina,
43 00 N
19 00 E
Croatia, Macedonia,
Montenegro, Serbia, Slovenia
North.
At Untie
Ocean
Monterrey
'' 100
|
THE'' BAHAMAS
,
i. } Nassau a
*% - V
0*02420
Hawaii
Midway /
lilands
lu.S.) 40
North Pacific Ocean
140
Scale 1:34,000,000
0 400 Kilometers
„ ! - 1 - 1 — U - } , . . .
;
. ''^A>0 /y*
a ~ -ww
Kauai
po, Honolulu
Oahu » muj
J c . noo r
- . . 28-
0 400 Miles
1 180 1?
0 1
■ \\^J> Hawaii
0
IR024IQ)
Perkiomen Valley Library at Schwenksviue
A Branch of JV1C-IMPL -
831
Reference
$12.95 (CAN $14.95)
A COMPREHENSIVE COUNTRY-BY-COUNTRY LOOK AT OUR WORLD
Full of up-to-date information on countries from Afghanistan to Zim¬
babwe, The CIA World Factbook 2009 is a fascinating, practical,
and one-of-a-kind reference book. Originally intended for use by
U.S. government officials working at home and overseas, The CIA
World Factbook 2009 includes detailed information on the geography,
population, military, and government of each of the world’s nations.
THE CIA
■
WORLD FACTBOOK 2003
INCLUDES:
SIS
Useful maps with new geographical data
Details on prominent political parties, and contact
information for diplomatic consultation
A full description of the population, with information on
literacy rates, HIV prevalence, and age structure
A complete economic overview from household income
to gross domestic product
Information on transportation and communication
infrastructure
Updated military expenditures and capabilities
And much more!
This unique catalog of information is a must-have resource for
students, travelers, journalists, and business people who want to
be more familiar with their world.
Skyhorse Publishing, Inc.
555 Eighth Avenue, Suite 903
New York, NY 10018
www.skyhorsepublishing.com
Cover design by Eric Clark
Printed in the United States of America
-60239-282-X
9781602392823
05/01/2017 11:32-3','b69c554908803f6057ecaac7c2c84a5d7c97ae2ecf8f2d2da1597b80a4fecd2a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79b75a4663c2939d36b2320e71f68aa40668c4900a3621f6836e2308525223ae',2009,'FM','Micronesia, Federated States of','transnational-issues',839,'Disputes — international: abundant
rainfall in recent years along much of the
Mexico-US border region has amelio-
rated periodically strained water-sharing
arrangements; the US has intensified
security measures to monitor and control
legal and illegal personnel, transport, and
commodities across its border with
Mexico; Mexico must deal with thou¬
sands of impoverished Guatemalans and
other Central Americans who cross the
porous border looking for work in
Mexico and the United States
Refugees and internally displaced per¬
sons: IDPs: 5,500-10,000 (government’s
quashing of Zapatista uprising in 1994 in
eastern Chiapas Region) (2007)
Trafficking in persons: current situation:
Mexico is a source, transit, and destina¬
tion country for persons trafficked for
sexual exploitation and labor; while the
vast majority of victims are Central
Americans trafficked along Mexico’s
southern border, other source regions
include South America, the Caribbean,
Eastern Europe, Africa, and Asia; women
and children are trafficked from rural
regions to urban centers and tourist areas
for sexual exploitation, often through
fraudulent offers of employment or
through threats of physical violence; the
Mexican trafficking problem is often
conflated with alien smuggling, and fre¬
quently the same criminal networks are
involved; pervasive corruption among
state and local law enforcement often
impedes investigations
tier rating: Tier 2 Watch List — Mexico
remains on the Tier 2 Watch List for the
third consecutive year based on future
commitments to undertake additional
efforts in prosecution, protection, and
prevention of trafficking in persons, and
the failure of the government to provide
critical law enforcement data
Illicit drugs: major drug-producing
nation; cultivation of opium poppy in
2005 amounted to 3,300 hectares
yielding a potential production of 8
metric tons of pure heroin, or 17 metric
tons of “black tar” heroin, the dominant
form of Mexican heroin in the western
United States; marijuana cultivation
decreased 3% to 5,600 hectares in
2005 — just two years after a decade-high
cultivation peak in 2003 — and yielded a
potential production of 10,100 metric
tons; government conducts the largest
independent illicit-crop eradication pro¬
gram in the world; continues as the pri¬
mary transshipment country for
US-bound cocaine from South America,
with an estimated 90% of annual cocaine
movements towards the US stopping in
Mexico; major drug syndicates control
majority of drug trafficking throughout
the country; producer and distributor of
ecstasy; significant money-laundering
center; major supplier of heroin and
largest foreign supplier of marijuana and
methamphetamine to the US market
PrsiB§0 ii
See
Northern
350 700 m
350
700 mi
Marima q
Islands
Guam rti.ST, Qmm
Yap
Islands Hall
'' ■■ , ISlfdS PAUKIft
"''''''.Islands ® .\\Pofmpe)
Caroline
TrukS’ ..
Islands
(Chuuk)
Kosrae''
Kapingamarangi
South PocMc
Ocmo
, ; 7
Gs
\\
. JS1AW5
Disputes — international: none
Illicit drugs: major consumer of cannabis
MOLDOVA','597afa5aa940c89ca0134069378544abc1e504fc5ba2d9792ca5a8eb0bda2e61','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82e30e394ba3b725769afa7bb6229ec898dae6681590ef1a5de4e99151c2f378',2009,'MN','Mongolia','transnational-issues',854,'Background: The Mongols gained fame
in the 13th century when under Chinggis
KHAN they conquered a huge Eurasian
empire. After his death the empire was
divided into several powerful Mongol
states, but these broke apart in the 14th
century. The Mongols eventually retired
to their original steppe homelands and in
the late 17th century came under
Chinese rule. Mongolia won its inde¬
pendence in 1921 with Soviet backing. A
Communist regime was installed in 1924.
Following a peaceful democratic revolu¬
tion, the ex-communist Mongolian
People’s Revolutionary Party (MPRP)
won elections in 1990 and 1992, but was
defeated by the Democratic Union
Coalition (DUC) in the 1996 parliamen¬
tary election. Since then, parliamentary
elections returned the MPRP over¬
whelmingly to power in 2000, but 2004
elections reduced MPRP representation
and, therefore, its authority.
438
MG
MN
MNG
496
MNG
.mn
46 00 N
105 00 E
46 00 N
105 00 E
North Korea
39 01 N
125 45 E
Marshall Islands, Federated
10 00 N
155 00 E
States of Micronesia, Northern
Mariana Islands, Palau
47 55 N
106 53 E
South Korea
37 29 N
130 52 E
Ireland, United Kingdom
54 35 N
7 00 W','a6d15313105e4aece3a0981b60bae1806400d23405ea87d27c0d6cd82058d0f2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4ca192fbb618c42a75cb11b84e2721addce14ee0d857166cb32e5f29ea3f16c',2009,'ME','Montenegro','transnational-issues',863,'Disputes — international: none
Disputes— international: none
Refugees and internally displaced per¬
sons: refugees (country of origin): 7,000
(Kosovo); note — mostly ethnic Serbs
and Roma who fled Kosovo in 1999
IDPs: 16,192 (ethnic conflict in 1999
and riots in 2004) (2007)
443
0 1 ?*m
0 1 ?.m
Davy Hitt. FZ
* Sain!
John''s
m,,TO
tkxtihwnZam
\\
#Satem
AN
/ Q\\
/ . •• ^ t
s/m Znm i
/ . "
V, Zone
PLYMOUTH
1
•tr&batviomtt)
- K''A
Peak
\\ \\
V
,,, . .
Hills
Background: English and Irish colonists
from St. Kitts first settled on Montserrat
in 1632; the first African slaves arrived
three decades later. The British and
French fought for possession of the island
for most of the 18th century, but it finally
was confirmed as a British possession in
1783. The island’s sugar plantation
economy was converted to small farm
landholdings in the mid 19th century.
Much of this island was devastated and
two-thirds of the population fled abroad
because of the eruption of the Soufriere
Hills Volcano that began on 18 July
1995. Montserrat has endured volcanic
activity since, with the last eruption
occurring in July 2003.
Location: Caribbean, island in the
Caribbean Sea, southeast of Puerto Rico
Geographic coordinates: 16 45 N, 62 12
w
Map references: Central America and
the Caribbean
Area:
total: 102 sq km
land: 102 sq km
water: 0 sq km
Area— comparative: about 0.6 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; little daily or seasonal
temperature variation
Terrain: volcanic island, mostly moun¬
tainous, with small coastal lowland
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: lava dome in English’s
Crater (in the Soufriere Hills volcanic
complex) estimated at over 930 m
(2006)
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 0%
other: 80% (2005)
Irrigated land: NA
Natural hazards: severe hurricanes
(June to November); volcanic eruptions
(Soufriere Hills volcano has erupted
continuously since 1995)
Environment — current issues: land ero¬
sion occurs on slopes that have been
cleared for cultivation
Geography — note: the island is entirely
volcanic in origin and comprised of three
major volcanic centers of differing ages
Population: 9,638
note: an estimated 8,000 refugees left the
island following the resumption of vol¬
canic activity in July 1995; some have
returned (July 2008 est.)
Age structure:
0-14 years: 23.5% (male 1,159/female
1,108)
15-64 years: 65.9% (male 3,027/female
3,323)
65 years and over: 10.6% (male
521/female 500) (2008 est.)
Median age:
total: 29.7 years
male: 29.3 years
female: 30.2 years (2008 est.)
Population growth rate: 1.038% (2008
est.)
Birth rate: 17.33 births/1,000 population
(2008 est.)
Death rate: 6.95 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 1.04 male(s)/female
total population: 0.95 male(s)/female
(2008 est.)
Infant mortality rate:
total: 6.86 deaths/1,000 live births
male: 7.95 deaths/1,000 live births
female: 5.71 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 79.15 years
male: 76.93 years
female: 81.47 years (2008 est.)
Total fertility rate: 1.76 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman
Catholic, Pentecostal, Seventh-Day
Adventist, other Christian denomina¬
tions
Languages: English
Literacy:
definition: age 15 and over has ever
attended school
total population: 97%
male: 97%
female: 97% (1970 est.)
MJ
ME
MNE
499
,
.me
42 24 N
18 55 E
42 26 N
19 16 E','ff2dc93f8af90ea1ef5bec1dacc01908660e463c3c479b5c97b7a2628da1f937','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('659f58499cff72a6b587889abd207ba330181c51e8456623fa1621a213b2a4a6',2009,'MS','Montserrat','transnational-issues',871,'Disputes— international: none
Illicit drugs: transshipment point for
South American narcotics destined for
the US and Europe
MH
MS
MSR
500
MSR
.ms
16 44 N
62 14 W','82b597023ac07fd866e52b18674f00886846741599817c3eb0c156e862339343','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4237957249aabbaa23f6543532efbfbd868732c135ddb621ad756669b28e3117',2009,'MA','Morocco','transnational-issues',872,'mmM
MZAM7K7
.wfe{4 SPAIN
*''*''***'' V •''
i. :
. Ceuta ;!.;p
Tangier* .Tetouan Nackjr
Meiiia{S»*A ^
RABAT »Ken(traiPes *****
Casablanca . * *Meknds
* Mohammedia gQ(>
Arfa,
Marrakech
“a pauamm
■
W
Wm%mn SMwn*
MO
MA
MAR
504
MAR
,ma
32 00 N
5 00 W
27 53 N
12 58 W
33 35 N
7 34 W
32 00 N
5 00 W
29 22 N
10 09 W
Saint Helena
37 17 S
12 40 W
Cambodia, Laos, Vietnam
15 00 N
107 00 E
Russia
43 15 N
45 00 E
32 00 N
5 00 W
34 02 N
6 51 W
32 00 N
7 00 W
Spain (Ceuta, Islas Chafarinas,
35 15 N
4 00 W
Melilla, Penon de Alhucemas,
Penon de Velez de la Gomera)
35 48 N
5 45 W
Russia
51 25 N
94 45 E
a
Mellila ■
« #V " 41 ■
Ateciiterririejit $e
, ««. .4
y - #yt
V/cagliari
I
Algiers
x# V
^vv7 . X''-''ak,
4::£ss /;«'' ;:v Yanis
■ . Of.. ,
Sea
Palermo
sySib^.
,
W w
tA GREECE *^wk
, . C 5ca |d
4 . . . 4 5ws 77
~ N <J-> # * ; ^
fW ^ ''* * * Rhodesi
Scale I: 19,500.000 <
sea \\ ^
ALGERIA tumisia
Lambert Conformal Conic Projection,
Valletta* Standard parallels 40 ''N and 56’N
MALTA f
300 KHometors
300 Miles
Hotf sxlary is rsot
I tece ss,ar ily a ttlLitri {a it -vV
822
REFERENCE MAPS
Bucharest*
Consfartla
Varna
''''V- »<)■ vs s , ..
" ■■ 4^^,Gro7nvr
■• 9 v?
*m,S
'' GEORGIA 4','1b01f42764fdbc7bac26f5203079785b65cb11b4664c7edaf02e168e81472317','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4a55a5f9318a5159c117d456ac4d8b55542028aeaf068e363e85988ef1d80c',2009,'EH','Western Sahara','transnational-issues',873,'Geographic coordinates: 32 00 N, 5 00
w
Map references: Africa
Area:
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
Area — comparative: slightly larger than
California
Land boundaries:
total: 2,017.9 km
border countries: Algeria 1,559 km,
Western Sahara 443 km, Spain (Ceuta)
6.3 km, Spain (Melilla) 9.6 km
Coastline: 1,835 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: northern coast and interior are
mountainous with large areas of bor¬
dering plateaus, intermontane valleys,
and rich coastal plains
Elevation extremes:
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use:
arable land: 19%
permanent crops : 2%
other: 79% (2005)
Irrigated land: 14,450 sq km (2003)
Total renewable water resources: 29 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 12.6 cu
km/yr (10%/3%/87%)
per capita: 400 cu m/yr (2000)
Natural hazards: northern mountains
geologically unstable and subject to
earthquakes; periodic droughts
Environment— current issues: land
degradation/desertification (soil erosion
resulting from farming of marginal areas,
overgrazing, destruction of vegetation);
water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollu¬
tion of coastal waters
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Environmental
Modification
Geography — note: strategic location
along Strait of Gibraltar
■
1979, following Mauritania’s withdrawal.
A guerrilla war with the Polisario Front
contesting Rabat’s sovereignty ended in a
1991 UN-brokered cease-fire; a UN-
organized referendum on final status has
been repeatedly postponed. In April
2007, Morocco presented an autonomy
plan for the territory to the UN, which
the U.S. considers serious and credible.
The Polisario also presented a plan to the
UN in 2007. Since August 2007, repre¬
sentatives from the Government of
712
Morocco and the Polisario Front have
met three times to negotiate the status of
Western Sahara, with a fourth round of
negotiations planned for March 2008.
Disputes— international: Morocco
claims and administers Western Sahara,
whose sovereignty remains unresolved;
UN-administered cease-fire has
remained in effect since September
1991, administered by the UN Mission
for the Referendum in Western Sahara
(MINURSO), but attempts to hold a ref¬
erendum have failed and parties thus far
have rejected all brokered proposals; sev¬
eral states have extended diplomatic
relations to the “Sahrawi Arab
Democratic Republic” represented by
the Polisario Front in exile in Algeria,
while others recognize Moroccan sover¬
eignty over Western Sahara; most of the
approximately 102,000 Sahrawi refugees
are sheltered in camps in Tindouf,
WI
EH
ESH
732
ESH
.eh
Palestinian Territory
Western Samoa
World
23 45 N
15 45 W
Atlantic Ocean
35 00 S
59 00 W
24 30 N
13 00 W
Burkina Faso, Chad, The
15 00 N
8 00 W
Gambia, Guinea- Bissau, Mali,
Mauritania, Niger, Senegal
Vietnam
10 45 N
106 40 E
24 30 N
13 00 W
Morocco, Western Sahara
25 00 N
13 00 W','8e39c758245a57a9f2e4c2a7605b2fb16337cd16c1247124bb0ff9e0c1493811','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8442e2aa329e677721d7a52c0930cbf29ceec3e98e6c5b2b0272b96546d0b5a7',2009,'MZ','Mozambique','transnational-issues',881,'Disputes — international: claims and
administers Western Sahara whose sov¬
ereignty remains unresolved — UN-
administered cease-fire has remained in
effect since September 1991, but
attempts to hold a referendum have
failed and parties thus far have rejected
all brokered proposals; Morocco protests
Spain’s control over the coastal enclaves
of Ceuta, Melilla, and Penon de Velez de
la Gomera, the islands of Penon de
Alhucemas and Islas Chafarinas, and sur¬
rounding waters; discussions have not
progressed on a comprehensive maritime
delimitation, setting limits on resource
exploration and refugee interdiction,
since Morocco’s 2002 rejection of Spain’s
unilateral designation of a median line
from the Canary Islands; Morocco serves
as one of the primary launching areas of
illegal migration into Spain from North
Africa
Illicit drugs: one of the world’s largest
producers of illicit hashish; shipments of
hashish mostly directed to Western
Europe; transit point for cocaine from
South America destined for Western
Europe; significant consumer of cannabis
Disputes— international: none
Illicit drugs: southern African transit
point for South Asian hashish and
heroin, and South American cocaine
probably destined for the European and
South African markets; producer of
cannabis (for local consumption) and
methaqualone (for export to South
Africa); corruption and poor regulator/
capability makes the banking system vul¬
nerable to money laundering, but the
lack of a well-developed financial infra¬
structure limits the country’s utility as a
money-laundering center
452
Oshakati
Tsumeb.
1- Khorixas
V * *OSjwarongo
WINDHOEK
Swakopmund * Gob|bl
Rehoboth K
ATCANTtC % Man«ntai
< a
“* Keetmanshoop
Luderitz*
OranjemufKi
22 30 S
34 30 E
25 56 S
32 34 E
25 58 S
32 35 E
18 15 S
35 00 E
13 30 S
37 00 E
United States (Hawaii)
21 30 N
158 00 W
18 15 S
35 00 E
16 00 S
37 00 E
Tanzania
6 10 S
39 11 E','9470406759fe30de92b2e677b1d8e247fc348690db92bd5ade46e3fb81437a35','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7cf14c7ddeb596593fbdcb42087e884b70560159e22dbf441f8e64a2d21fddd',2009,'NR','Nauru','transnational-issues',892,'Disputes — international: concerns from
international experts and local popula¬
tions over the Okavango Delta ecology
in Botswana and human displacement
scuttled Namibian plans to construct a
hydroelectric dam on Popa Falls along
the Angola-Namibia border; managed
dispute with South Africa over the loca¬
tion of the boundary in the Orange
River; Namibia has supported, and in
2004 Zimbabwe dropped objections to,
plans between Botswana and Zambia to
build a bridge over the Zambezi River,
thereby de facto recognizing a short, but
not clearly delimited, Botswana-Zambia
boundary in the river
Refugees and internally displaced per¬
sons: refugees (country of origin): 4,700
(Angola) (2007)
NR
NR
NRU
520
NRU
.nr
Navassa Island
BQ
-
-
US
ISO includes with the US
Minor Outlying Islands
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
STANA6-
Entity
FIPS 10
ISO 3166
1059
Internet
0 32 S
166 55 E
0 32 S
166 55 E
Russia
56 50 N
60 39 E
Pacific Ocean
36 00 N
123 00 E','5713a411ee4f332267adcdbb2110f16681c6427657ce2ed148fff174ab197ba0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa3c634e42209dffcec4ac9bb2d33458c011054efce6fdd285781ba38514d7a3',2009,'NL','Netherlands','transnational-issues',905,'Disputes — international: joint border
commission continues to work on con¬
tested sections of boundary with India,
including the 400 square kilometer dis¬
pute over the source of the Kalapani
River; India has instituted a stricter
border regime to restrict transit of Maoist
insurgents and illegal cross-border activ¬
ities; approximately 106,000 Bhutanese
Lhotshampas (Hindus) have been con¬
fined in refugee camps in southeastern
Nepal since 1990
Refugees and internally displaced per¬
sons: refugees (country of origin): 107,803
(Bhutan); 20,153 (Tibet/China)
IDPs: 50,000-70,000 (remaining from
ten-year Maoist insurgency that officially
ended in 2006; displacement spread
across the country) (2007)
Illicit drugs: illicit producer of cannabis
and hashish for the domestic and inter¬
national drug markets; transit point for
opiates from Southeast Asia to the West
Disputes— international: none
Illicit drugs: major European producer of
synthetic drugs, including ecstasy, and
cannabis cultivator; important gateway
for cocaine, heroin, and hashish entering
Europe; major source of US-bound
ecstasy; large financial sector vulnerable
to money laundering; significant con¬
sumer of ecstasy
464
NETHERLANDS ANTILLES
NL
NL
NLD
528
NLD
.nl
Netherlands Antilles
NT
AN
ANT
530
ANT
.an
52 23 N
4 54 E
French Southern and
Antarctic Lands
37 52 S
77 32 E
785
THE CIA WORLD FACTBOOK
Name
Amundsen Sea
Amur River
Amurskiy Liman (strait)
Anadyrskiy Zaiiv (gulf)
Anatolia (region)
Andaman Islands
Andaman Sea
Andorra la Vella (capital)
Andros (island)
Andros Island
Anegada Passage
Angkor Wat (ruins)
Anglo-Egyptian Sudan (former name for Sudan)
Anjouan (island)
Ankara (capital)
Annobon (island)
Antananarivo (capital)
Antigua (island)
Antipodes Islands
Antwerp (city)
Aomen (local Chinese short-form name for Macau)
Aozou Strip (region)
Apia (capital)
Aqaba, Gulf of
Arab, Shatt al (river)
Arabian Sea
Arafura Sea
Aral Sea
Argun River
Aru Sea
As-Sudan (local name for Sudan)
Ascension Island
Ashgabat, Ashkhabad (capital)
Asmara, Asmera (capital)
Assumption Island
Astana (capital; formerly Akmola)
Asuncion (capital)
Asuncion Island
Atacama (desert)
Atacama (region)
Athens (capital)
Attu Island
Auckland (city)
Auckland Islands
Australes, lies (island group; also lies Tubuai)
Avarua (capital)
Axel Heiberg Island
Azad Kashmir (region)
Azarbaycan, Azerbaidzhan (local name for Azerbaijan)
Azores (islands)
Azov, Sea of
Bab el Mandeb (strait)
Babuyan Channel
Babuyan Islands
Baffin Bay
Baffin Island
Baghdad (capital)
Baku (capital; also Baki, Baky)
Balabac Strait
Balearic Islands
Balearic Sea (Iberian Sea)
Bali (island)
Bali Sea
Balintang Channel
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Southern Ocean
72 30 S
112 00 W
China, Russia
52 56 N
141 10 E
Pacific Ocean
53 00 N
141 30 E
Pacific Ocean
64 00 N
177 00 E
Turkey
39 00 N
35 00 E
52 05 N
4 18 E
793
THE CIA WORLD FACTBOOK
Name
Haifa (city)
Hainan Dao (island)
Haiphong (city)
Hala''ib Triangle (region)
Halifax (city)
Halmahera (island)
Halmahera Sea
Hamburg (city)
Hamilton (capital)
Han-guk (local name for South Korea
Hanoi (capital)
Harare (capital)
Harvey Islands (former name for Cook Islands)
Hatay (province)
Havana (capital)
Hawaii (island)
Hawaiian Islands
Hawar (island)
Hayastan (local name for Armenia)
Heard Island
Hejaz (region)
Helsinki (capital)
Herzegovina (political region)
Hiiumaa (island)
Hispaniola (island)
Ho Chi Minh City (formerly Saigon)
Hokkaido (island)
Holland (region)
Hong Kong (special administrative region)
Honiara (capital)
Honshu (island)
Hormuz, Strait of
Horn of Africa (region)
Horn, Cape (Cabo de Hornos)
Horne, lies de (island group)
Hrvatska (local name for Croatia)
Hudson Bay
Hudson Strait
Hunter Island
Iberian Peninsula
Iceland Sea
Ifni (region; former name of part of Spanish West Africa)
Inaccessible Island
Indochina (region)
Ingushetia (region)
Inhambane (region)
inini (former name for French Guiana)
Inland Sea
Inner Hebrides (islands)
Inner Mongolia (region; also Nei Mongol)
Ionian Islands
Ionian Sea
Irian Jaya (province)
Irish Sea
Iron Gate (river gorge)
Iskenderun (region; formerly Alexandretta)
Islamabad (capital)
Island (local name for Iceland)
Islas Malvinas (island group)
Istanbul (city)
Istrian Peninsula
Italia (local name for Italy)
Italian East Africa (former name for Italian possessions
in eastern Africa)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
52 30 N
5 45 E
52 30 N
5 45 E
Netherlands Antilles
12 15 N
68 45 W
53 26 N
5 30 E','fb591bba86c9b9cebe18b0b0674b57a023fa0ecde338629a2a1c1c7b11cfc3c7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aecdb36ffd86951a7ba367fcb31a7da1e7574ba378dddf4663b66b6e5c3c9a9',2009,'NC','New Caledonia','transnational-issues',912,'Disputes — international: none
Illicit drugs: transshipment point for
South American drugs bound for the US
and Europe; money-laundering center
0
50 tWkm
Sfatd
i
103 mi
p
Disputes— international: none
Disputes— international: West Bank
and Gaza Strip are Israeli-occupied with
current status subject to the Israeli-
Palestinian Interim Agreement — perma¬
nent status to be determined through
further negotiation; Israel continues con¬
struction of a “seam line” separation bar¬
rier along parts of the Green Line and
within the West Bank; Israel withdrew
from four settlements in the northern
West Bank in August 2005; since 1948,
about 350 peacekeepers from the UN
Truce Supervision Organization
(UNTSO), headquartered in Jerusalem,
monitor ceasefires, supervise armistice
agreements, prevent isolated incidents
from escalating, and assist other UN per¬
sonnel in the region
Refugees and internaiiy displaced per¬
sons: refugees (country of origin): 722,000
(Palestinian Refugees (UNRWA))
(2007)
Background: Morocco virtually annexed
the northern two-thirds of Western
Sahara (formerly Spanish Sahara) in
1976, and the rest of the territory in
NC
NC
NCL
540
NCL
.nc
19 45 S
163 40 E
19 52 S
158 15 E
Pacific Ocean
38 30 N
120 00 E
21 00 S
167 00 E
22 16 S
166 27 E
21 30 S
165 30 E','aa8fc08ffe941f0981f71bd385510a1025cfce83436daaf578503ca07787b0fb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f874b1263b56f9fc536f3e4f5dee3bdc39b44331546e6b2f3961ed6abadc3950',2009,'VU','Vanuatu','transnational-issues',913,'ft
■
A
\\
Erromango
V
Coral Sea
fiWf.,
%
■
/A ''/
''"''4,
lies
* Poh idimie
We* Loyaut4
Mueo*
>
South
New
TOq.
SJ PmSSc
Caledonia
* t Ocean
NOUMEA*
\\
he dm Pins
y
Cor at Si
lie wm mi C&esterMd
m |st % iumt.
Disputes — international: Matthew and
Hunter Islands east of New Caledonia
claimed by Vanuatu and France
VENEZUELA
■
Ciudad
/ Puerto
■Ayacucho
COLORISIA
, Amuiy '' :s _ ,
Valencia J: * *
,->.Maraeay
v&s&icfsi
Fernando . *,
Cristobal
San
Background: Venezuela was one of three
countries that emerged from the collapse
of Gran Colombia in 1830 (the others
being Ecuador and New Granada, which
became Colombia). For most of the first
half of the 20th century, Venezuela was
ruled by generally benevolent military
strongmen, who promoted the oil
industry and allowed for some social
reforms. Democratically elected govern¬
ments have held sway since 1959. Hugo
CHAVEZ, president since 1999, seeks to
implement his “21st Century Socialism,”
which purports to alleviate social ills
while at the same time attacking global¬
ization and undermining regional sta¬
bility. Current concerns include: a
weakening of democratic institutions,
political polarization, a politicized mili¬
tary, drug-related violence along the
Colombian border, increasing internal
drug consumption, overdependence on
the petroleum industry with its price
fluctuations, and irresponsible mining
operations that are endangering the rain
forest and indigenous peoples.
NH
vu
VUT
548
VUT
.vu
Venezuela
VE
VE
VEN
862
VEN
.ve
Vietnam
VM
VN
VNM
704
VNM
.vn
Virgin Islands
VQ
VI
VIR
850
VIR
.vi
Virgin Islands (UK)
Virgin Islands (US)
Wake Island
WQ
-
-
UMI
•vg
.vi
see British Virgin Islands
see Virgin Islands
ISO includes with the US
MOOS
167 30 E
16 00 S
167 00 E
16 00 S
167 00 E
Russia
74 00 N
57 00 E
Egypt, Sudan
20 30 N
33 00 E
17 44 S
168 19 E','e964334b94f6e75fcd5efaf218fdd91d06e12347ca72f82b96187b58aaa28b81','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f804112f2248bf3e20fd205efe4d36c4b6368fd26b395842721af39b30fc004a',2009,'NZ','New Zealand','transnational-issues',920,'Disputes — international: Matthew and
Hunter Islands east of New Caledonia
claimed by France and Vanuatu
Diplomatic representation from the US:
none (overseas territory of France)
Flag description: the flag of France is
used
Disputes— international: none
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity; see African Union
official development assistance
Organization for Economic Cooperation and Development
738
ABBREVIATIONS
OECS
OHCHR
OIC
OIF
ONUB
OOF
OPANAL
OPCW
OPEC
OSCE
Ozone Layer Protection
PCA
PFP
PIF
PPP
Ramsar
RG
SAARC
SACU
SACEP
SADC
SCO
SAFE
SECI
SHF
Ship Pollution
Sparteca
SPC
SPF
sq km
sq mi
TAT
TEU
Tropical Timber 83
Tropical Timber 94
UAE
UDEAC
UHF
UK
UN
UNAMSIL
UNCLOS
UNCTAD
UNDCP
UNDOF
UNDP
UNEP
UNESCO
UNFICYP
UNFPA
UNHCR
UNICEF
UNICRI
UNIDIR
UNIDO
UNIFIL
UNITAR
UNMEE
Organization of Eastern Caribbean States
Office of the United Nations High Commissioner for Human Rights
Organization of the Islamic Conference
International Organization of the French-speaking World
United Nations Operation in Burundi
other official flows
Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean
Organization for the Prohibition of Chemical Weapons
Organization of Petroleum Exporting Countries
Organization for Security and Cooperation in Europe
Montreal Protocol on Substances That Deplete the Ozone Layer
Permanent Court of Arbitration
Partnership for Peace
Pacific Islands Forum
purchasing power parity
see Wetlands
Rio Group
South Asian Association for Regional Cooperation
Southern African Customs Union
South Asia Co-opeative Environment Programme
Southern African Development Community
Shanghai Cooperation Organization
South African Far East Cable
Southeast European Cooperative Initiative
super-high-frequency
Protocol of 1978 Relating to the International Convention for the Prevention of
Pollution From Ships, 1973 (MARPOL)
South Pacific Regional Trade and Economic Cooperation Agreement
Secretariat of the Pacific Communities
South Pacific Forum
square kilometer
square mile
Trans-Atlantic Telephone
Twenty-Foot Equivalent Unit
International Tropical Timber Agreement, 1983
International Tropical Timber Agreement, 1994
NZ
NZ
NZL
554
NZL
.nz
49 41 S
178 43 E
36 52 S
174 46 E
51 00 S
166 30 E
47 43 S
174 00 E
Reunion
21 06 S
55 36 E
52 33 S
169 09 E
Atlantic Ocean
20 00 N
94 00 W
44 00 S
176 30 W
Russia
43 15 N
45 40 E
Pacific Ocean
34 00 N
126 30 E
Korea, South
33 20 N
126 30 E
29 50 S
178 15 W
China, Mongolia
48 48 N
117 00 E
Russia
48 27 N
135 06 E
China, Russia
45 00 N
132 24 E
39 00 S
176 00 E
Russia
43 00 N
44 10 E
Pacific Ocean
30 00 N
165 00 W
799
THE CIA WORLD FACTBOOK
Name _ _
North Sea
North Vietnam (former name for northern portion of Vietnam)
North Yemen (Yemen Arab Republic; now part of Yemen)
Northeast Providence Channel
Northern Areas
Northern Cyprus (region)
Northern Epirus (region)
Northern Grenadines (political region)
Northern Ireland
Northern Rhodesia (former name for Zambia)
Northwest Passages
Norwegian Sea
Nouakchott (capital)
Noumea (capital)
Nouvelie-Caledonie (local name for New Caledonia)
Nouveiles Hebrides (former name for Vanuatu)
Novaya Zemlya (islands)
Nubia (region)
Nukualofa (capital)
Nunavut (region)
Nuuk (capital; also Godthab)
Nyasaland (former name for Malawi)
Nyassa (region)
Oahu (island)
Ocean Island (Banaba)
Ocean Island (Kure Island)
Oesterreich (local name for Austria)
Ogaden (region)
Oil Islands (Chagos Archipelago)
Okhotsk, Sea of
Okinawa (island group)
Oland (island)
Oman, Gulf of
Ombai Strait
Oran (city)
Orange River Colony (region; former name of Free
State Province of South Africa)
Oranjestad (capital)
Oresund (The Sound) (strait)
Orkney Islands
Osaka (city)
Oslo (capital)
Osumi Strait (Van Diemen Strait)
Otranto, Strait of
Ottawa (capital)
Ouagadougou (capital)
Outer Hebrides (islands)
Outer Mongolia (region)
Pyongyang (capital)
Pacific Islands, Trust Territory of the (former name of a
large area of the western North Pacific Ocean)
Pagan (island)
Pago Pago (capital)
Palawan (island)
Palermo (city)
Palestine (region)
Palikir (capital)
Pclk Strait
Pamirs (mountains)
Pampas (region)
Panama (capital)
Panama Canal
Panama, Gulf of
Panay (island)
800
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Atlantic Ocean
56 00 N
4 00 E
Vietnam
23 00 N
106 00 E
43 00 S
171 00 E
South Korea
37 00 N
127 30 E
41 28 S
174 51 E','83db65edbaeb802efcda1ed000aa3040be51d221bea00ce5817eaeffbf482b8f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68fc27df8ba60015006148d990a5cc7d22c641f026ec8540fb50458f01bcbca5',2009,'TK','Tokelau','transnational-issues',927,'Disputes— international: asserts a terri¬
torial claim in Antarctica (Ross
Dependency)
Illicit drugs: significant consumer of
amphetamines
1
Disputes — international: m 2001,
Benin claimed Togo moved boundary
monuments — joint commission con¬
tinues to resurvey the boundary; in 2006
14,000 Togolese refugees remain in
Benin and Ghana out of the 40,000 who
fled there in 2005
Refugees and internally displaced per¬
sons: refugees (country of origin ): 5,000
(Ghana)
IDPs: 1,500 (2007)
Illicit drugs: transit hub for Nigerian
heroin and cocaine traffickers; money
laundering not a significant problem
TL
TK
TKL
772
TKL
.tk','08c0ab9042cf53cc1db3fcd32f8a4fbf4132eac6590f11bff1171bd396518719','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5afa09edba040b43533a4db3d95269ef30b56e7b714fcf3e2a4b26b47f019545',2009,'NE','Niger','transnational-issues',933,'Disputes — international: memorials and
countermemorials were filed by the par¬
ties in Nicaragua’s 1999 and 2001 pro¬
ceedings against Honduras and
Colombia at the ICJ over the maritime
boundary and territorial claims in the
western Caribbean Sea, final public
hearings are scheduled for 2007; the
1992 ICJ ruling for El Salvador and
Honduras advised a tripartite resolution
to establish a maritime boundary in the
Gulf of Fonseca, which considers
Honduran access to the Pacific; legal dis¬
pute over navigational rights of San Juan
River on border with Costa Rica
Illicit drugs: transshipment point for
cocaine destined for the US and trans¬
shipment point for arms-for-drugs
dealing
public pressure to allow multiparty elec¬
tions, which resulted in a democratic
government in 1993. Political infighting
475
THE CIA WORLD FACTBOOK
brought the government to a standstill
and in 1996 led to a coup by Col.
Ibrahim BARE, in 1999 BARE was
killed in a coup by military officers who
promptly restored democratic rule and
held elections that brought Mamadou
TANDJA to power in December of that
year. TANDJA was reelected in 2004.
Niger is one of the poorest countries in
the world with minimal government
services and insufficient funds to develop
its resource base. The largely agrarian
and subsistence-based economy is fre¬
quently disrupted by extended droughts
common to the Sahel region of Africa. A
predominately Tuareg ethnic group
emerged in February 2007, the Niger ien
Movement for Justice (MNJ), and
attacked several military targets in
Niger’s northern region throughout
2007. Events have since evolved into a
budding insurrection.
Disputes— international: Libya claims
about 25,000 sq km in a currently dor¬
mant dispute in the Tommo region;
much of Benin-Niger boundary,
including tripoint with Nigeria, remains
undemarcated; only Nigeria and
Cameroon have heeded the Lake Chad
Commission’s admonition to ratify the
delimitation treaty which also includes
the Chad-Niger and Niger-Nigeria
boundaries
:<
Sokoto;
Katsibi
Maidugun
Zara,
Kadurta,
8 mm
ABUJA
llorin
♦
*Ogbomo&6:
, ‘Osbogbo
Ibadan Ber,;r
.City \\
Mafeurdi
tmikm
1 Calabar / ^CAMEROON
* * y-PomsuSa
Port
Harcourt
'' . . ©193 SDOksi
9 too m
NG
NE
NER
562
NER
.ne
13 31 N
2 07 E','70c641e99fc0cff51f04366a8e40cb1811f53fbf10c5b7550bb67bb17a2d134f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28527fcd64238ea3a8dbf91999d13a38bfb2450429dc7fdd5608a3525d32f2ae',2009,'NG','Nigeria','transnational-issues',939,'Disputes — International: Joint Border
Commission with Cameroon reviewed
2002 ICJ ruling on the entire boundary
481
THE CIA WORLD FACTBOOK
and bilaterally resolved differences,
including June 2006 Greentree
Agreement that immediately cedes sov¬
ereignty of the Bakassi Peninsula to
Cameroon with a phase-out of Nigerian
control within two years while resolving
patriation issues; the ICJ ruled on an
equidistance settlement of Cameroon-
Equatorial Guinea-Nigeria maritime
boundary in the Gulf of Guinea, but
imprecisely defined coordinates in the
ICJ decision and a sovereignty dispute
between Equatorial Guinea and
Cameroon over an island at the mouth of
the Ntem River all contribute to the
delay in implementation; only Nigeria
and Cameroon have heeded the Lake
Chad Commission’s admonition to ratify
the delimitation treaty which also
includes the Chad-Niger and Niger-
Nigeria boundaries
Refugees and internally displaced persons:
refugees (country of origin): 5,778 (Liberia)
IDPs: undetermined (communal vio¬
lence between Christians and Muslims
since President OBASANJO’s election
in 1999; displacement is mostly short¬
term) (2007)
Illicit drugs: a transit point for heroin and
cocaine intended for European, East Asian,
and North American markets; consumer of
amphetamines; safe haven for Nigerian
narcotraffickers operating worldwide;
major money-laundering center; massive
corruption and criminal activity; Nigeria
has improved some anti-money-laundering
controls, resulting in its removal from the
Financial Action Task Forces (FATF’s)
Noncooperative Countries and Territories
List in June 2006; Nigeria’s anti-money-
laundering regime continues to be moni¬
tored by FATF
Background: Niue’s remoteness, as well
as cultural and linguistic differences
between its Polynesian inhabitants and
those of the rest of the Cook Islands,
have caused it to be separately adminis¬
tered. The population of the island con¬
tinues to drop (from a peak of 5,200 in
1966 to an estimated 1,444 in 2008),
with substantial emigration to New
Zealand, 2,400 km to the southwest.
NI
NG
NGA
566
NGA
•ng
9 12 N
7 11 E
5 30 N
7 30 E
Russia
65 46 N
169 06 W
10 33 N
7 27 E
China, India
30 00 N
82 00 E
6 27 N
3 24 E','8078a7e3d61a4ac846b5613389153640bbe1a9674cdfd01389e6a4df3a45b97b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea12c166295fc1179e3343dfbab98cdc48f82dc1aed6930128a07b5b7af22bb0',2009,'NF','Norfolk Island','transnational-issues',943,'Background: Two British attempts at
establishing the island as a penal colony
(1788-1814 and 1825-55) were ulti¬
mately abandoned. In 1856, the island
was resettled by Pitcairn Islanders,
descendants of the Bounty mutineers and
their Tahitian companions.
NF
NF
NFK
574
NFK
.nf
Northern Mariana
CQ
MP
MNP
580
MNP
.mp
Islands
29 03 S
167 58 E
Saint Vincent and the
13 09 N
61 14 W
Grenadines
Democratic Republic
4 18 S
15 18 E
of the Congo
29 08 S
167 57 E
Pacific Ocean
20 00 N
134 00 E','b316025f0a8c1cb9400ceb1ef9b4082386051424cd6f6cb37871082a70c9ddc8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22d033c21e0d995fa1c73fd699dec3461e207bab6fc0e7367441a01ebc9ad704',2009,'MP','Northern Mariana Islands','transnational-issues',950,'Disputes — international: none
19 40 N
145 24 E
18 08 N
145 47 E
14 10N
145 12 E
15 12 N
145 45 E
15 00 N
145 38 E
Indian Ocean
28 00 N
34 27 E','9d9e6c145e0f636d4a97c53701ce8b332128c860c886e1c1a698b96850279a1e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78cac1715f0cf17e296ac70323193298f837a43939ae722ccd52f1f8368d2dfc',2009,'NO','Norway','transnational-issues',956,'Disputes — international: none
_
Disputes — international: Norway
asserts a territorial claim in Antarctica
(Queen Maud Land and its continental
shelf); despite dialogue, Russia and
Norway continue to dispute their mar¬
itime limits in the Barents Sea and
Russia’s fishing rights beyond Svalbard’s
territorial limits within the Svalbard
Treaty zone
491
NO
NO
NOR
578
NOR
.no
62 00 N
10 00 E
Guernsey, Jersey
49 20 N
2 20 W
Atlantic Ocean
30 00 N
45 00 W
Atlantic Ocean
55 10N
5 40 W
Denmark, Germany
54 50 N
8 12 E
Arctic Ocean
78 00 N
5 00 W
59 55 N
10 45 E
Pacific Ocean
31 00 N
131 00 E
Atlantic Ocean
40 00 N
19 00 E
"-a
Torshavru,
>o','cdae3877a1e89297b0d3d0c3630ed4f03d8aeec1c07e38db6717bea4290ce71d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98f4a064c9106893a34d3b6c9d3315c98b5571422a14cc295dcead16f6f6a03e',2009,'OM','Oman','transnational-issues',966,'Disputes— international: boundary
agreement reportedly signed and ratified
with UAE in 2003 for entire border,
including Oman’s Musandam Peninsula
and A1 Madhah exclave, but details of
the alignment have not been made
public
Trafficking in persons: current situation:
Oman is a destination country for men
and women primarily from Bangladesh,
India, Sri Lanka, and Pakistan who
migrate willingly, some of whom become
victims of trafficking when subjected to
conditions of involuntary servitude as
domestic workers and laborers, including
non-payment of wages, restrictions on
movement and withholding of passports,
threats, and physical or sexual abuse;
Oman may also be a destination country
for women from Asia, Eastern Europe,
and North Africa for commercial sexual
exploitation
tier rating: Tier 3 — Oman was down¬
graded to Tier 3 in the 2007 report
because it did not report any law enforce¬
ment efforts to prosecute and punish traf¬
ficking offenses in 2006 and continues to
lack victim protection services or a sys¬
tematic procedure to identify victims of
trafficking
494
MU
OM
OMN
512
OMN
.om
17 00 N
54 10 E
17 30 N
56 00 E
Afghanistan, Pakistan
34 05 N
71 10 E
23 37 N
58 35 E
21 00 N
57 00 E
Burma
22 00 N
98 00 E
21 00 N
57 00 E
Pacific Ocean
54 20 N
164 50 W
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine,','c3e643f07317935bae2ceb8289458a26651c366e8a48d7c4ae0bd91d4a33f805','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f179516ab7b62bb803b7f7b7a079c991ee0759a4299ebf655a2e873b868cbd7',2009,'PW','Palau','transnational-issues',974,'Disputes — international: various talks
and confidence-building measures cau¬
tiously have begun to defuse tensions
over Kashmir, particularly since the
October 2005 earthquake in the region;
Kashmir nevertheless remains the site of
the world’s largest and most militarized
territorial dispute with portions under
the de facto administration of China
(Aksai Chin), India (Jammu and
Kashmir), and Pakistan (Azad Kashmir
and Northern Areas); UN Military
Observer Group in India and Pakistan
(UNMOGIP) has maintained a small
group of peacekeepers since 1949; India
does not recognize Pakistan’s ceding his¬
toric Kashmir lands to China in 1964;
India and Pakistan have maintained
their 2004 cease fire in Kashmir and ini¬
tiated discussions on defusing the armed
stand-off in the Siachen glacier region;
Pakistan protests India’s fencing the
highly militarized Line of Control and
construction of the Baglihar Dam on the
Chenab River in Jammu and Kashmir,
which is part of the larger dispute on
water sharing of the Indus River and its
tributaries; to defuse tensions and pre¬
pare for discussions on a maritime
boundary, India and Pakistan seek tech¬
nical resolution of the disputed boundary
in Sir Creek estuary at the mouth of the
Rann of Kutch in the Arabian Sea;
Pakistani maps continue to show the
Junagadh claim in India’s Gujarat State;
by 2005, Pakistan, with UN assistance,
repatriated 2.3 million Afghan refugees
leaving slightly more than a million,
many of whom remain at their own
choosing; Pakistan has proposed and
Afghanistan protests construction of a
fence and laying of mines along portions
of their porous border; Pakistan has sent
troops into remote tribal areas to mon¬
itor and control the border with
Afghanistan and to stem terrorist or
other illegal activities
Refugees and internally displaced per¬
sons: refugees (country of origin ):
1,043,984 (Afghanistan)
IDPs: undetermined (government strikes
on Islamic militants in South
Waziristan); 34,000 (October 2005
earthquake; most of those displaced
returned to their home villages in the
spring of 2006) (2007)
Illicit drugs: opium poppy cultivation
estimated to be 800 hectares in 2005
yielding a potential production of 4
metric tons of pure heroin; federal and
provincial authorities continue to con¬
duct anti-poppy campaigns that force
eradication — fines and arrests will take
place if the ban on poppy cultivation is
not observed; key transit point for
Afghan drugs, including heroin, opium,
morphine, and hashish, bound for
Western markets, the Gulf States, and
Africa; financial crimes related to drug
trafficking, terrorism, corruption, and
smuggling remain problems
Disputes — international: maritime
delineation negotiations continue with
Philippines, Indonesia
501
PS
PW
PLW
585
PLW
.pw
Palmyra Atoll
LQ
-
-
UMI
7 30 N
134 30 E
7 20 N
134 29 E
7 01 N
134 15 E
PCD. STATES or
MICROISESIA
PttlM! Simaihti- ''fc , '' w .
* ■- m
, V
‘AVSIA ■
1x..J<i#Eing Borneo "X ''
j.Sr''%
•*t'' C Mkmhtra
aiiii.vj ,k?«jL Equator
North
Pacific
Occa ii
liSfll:
Cocos
(Keeling)
Islands
IADSTKAUA!
TanjungkarangS
TeluRfetuna j
j«ivi Sea
r-M
Makassar/ J A
^ I Ti D O PftE’^J A e;
.Sc.f^O
•x sT7\\ /
* A R L x. * »
■
Fkxes
Bandtmg, , '' '' Id® , fSX&baya i.omhok
”"—4 J. " A -- tb ,Y ,
Denpaseir « j
, . Suttiiuwii rj''4, rfr%r east timor
Christmas Island ’’ ^ KuPan^ .
(AUSTRALIA) * J ^
BdfiCU
It
i\\ KEPWAUAN \\
w*
ARU
1 (sip
j PAPfiA’
/ mxs
SttliSKA
isy ^
Time
>0^ i
Ashmore and
Cartier Islands
[AUSTRAUA!
A rmiYA
Sea
VC* e",
s a„-, -f ■■ '' " V" ->^5Vt
t^r" . n
Mcraukexj .j
naia n
|
CrLllfrti Y,
Scale 1:32,000,000 at 5°N
Mercator Projection
aX
X
\\ rd
i''nrpmtma |j
j
■''€0
v_
J
''4.^-
500 Kilometers
. - - -','2403fa25652f86dca66687eecb4518c3052bcd9dc7ca13a31cfa3f0ca5e7aef2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d19f3b0d357cba7311bf9f358aa6db605b366982c0be1defa07a411d3da5e504',2009,'PG','Papua New Guinea','transnational-issues',983,'Disputes— international: organized
illegal narcotics operations in Colombia
operate within the remote border region
with Panama
Illicit drugs: major cocaine transship¬
ment point and primary money-laun¬
dering center for narcotics revenue;
money-laundering activity is especially
heavy in the Colon Free Zone; offshore
financial center; negligible signs of coca
cultivation; monitoring of financial
transactions is improving; official corrup¬
tion remains a major problem
Disputes— international: relies on assis¬
tance from Australia to keep out illegal
cross-border activities from primarily
Indonesia, including goods smuggling,
illegal narcotics trafficking, and squatters
and secessionists
Refugees and internally displaced per¬
sons: refugees (country of origin): 10,177
(Indonesia) (2007)
Illicit drugs: major consumer of cannabis
PARACEL ISLANDS
_
South Chins Sea
West Sand
Pam mnd
island
Robert island , Island
Money island
Amphitrite
Tree /stand Group
Rocky Island
Lincoln
Cresc&nt
Group
Triton
Island
Kmb
0 30- W te**
0 30 ms
PP
PG
PNG
598
PNG
•Pg
Paracel Islands
PF
-
-
2 10 S
147 00 E
Atlantic Ocean
42 30 N
16 00 E
Russia
44 30 N
40 10 E
5 00 S
150 00 E
Pacific Ocean
4 00 S
148 00 E
6 00 S
155 00 E
Pacific Ocean
6 40 S
156 10 E
9 30 S
150 40 E
Russia
43 00 N
47 00 E
4 30 S
154 10 E
Arctic Ocean
79 00 N
5 00 W
Saint Vincent and the
13 15 N
61 12 W
Grenadines
11 00 S
153 00 E
6 00 S
150 00 E
3 20 N
152 00 E
Russia
75 00 N
142 00 E
Fiong Kong
22 24 N
114 10 E
9 30 S
147 10 E
6 00 S
155 00 E
8 38 S
151 04 E','90255e5a44de74cd0fbc35bb38d647a5900229a2912ca7ad9d33d4727106c5bc','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('601c3af077ceb343f752075c0c750f75b0c931ded3e0f37e0f1d609ba3631cbe',2009,'PH','Philippines','transnational-issues',993,'Disputes — international: occupied by
China, also claimed by Taiwan and
Vietnam
Disputes— international: Chile and
Ecuador rejected Peru’s November 2005
unilateral legislation to shift the axis of
their joint treaty-defined maritime
boundaries along the parallels of latitude
to equidistance lines which favor Peru;
organized illegal narcotics operations in
Colombia have penetrated Peru’s shared
border; Peru rejects Bolivia’s claim to
restore maritime access through a sover¬
eign corridor through Chile along the
Peruvian border
Refugees and infernally displaced per¬
sons: IDPs: 60,000-150,000 (civil war
from 1980-2000; most IDPs are indige¬
nous peasants in Andean and
Amazonian regions) (2007)
Illicit drugs: until 1996 the world’s
largest coca leaf producer, Peru is now
the world’s second largest producer of
coca leaf, though it lags far behind
Colombia; cultivation of coca in Peru
rose 25% to 34,000 hectares in 2005;
much of the cocaine base is shipped to
neighboring Colombia for processing
into cocaine, while finished cocaine is
shipped out from Pacific ports to the
international drug market; increasing
amounts of base and finished cocaine,
however, are being moved to Brazil and
Bolivia for use in the Southern Cone or
transshipped to Europe and Africa
Background: The Philippine Islands
became a Spanish colony during the
16th century; they were ceded to the US
in 1898 following the Spanish- American
War. In 1935 the Philippines became a
self-governing commonwealth. Manuel
QUEZON was elected president and was
tasked with preparing the country for
independence after a 10-year transition.
In 1942 the islands fell under Japanese
occupation during World War II, and US
forces and Filipinos fought together
during 1944-45 to regain control. On 4
July 1946 the Republic of the Philippines
attained its independence. The 20-year
rule of Ferdinand MARCOS ended in
1986, when a “people power” movement
in Manila (“EDS A 1”) forced him into
exile and installed Corazon AQUINO as
president. Her presidency was hampered
by several coup attempts, which pre¬
vented a return to full political stability
and economic development. Fidel
RAMOS was elected president in 1992
and his administration was marked by
greater stability and progress on eco¬
nomic reforms. In 1992, the US closed
its last military bases on the islands.
Joseph ESTRADA was elected president
in 1998, but was succeeded by his vice-
president, Gloria MACAPAGAL-
ARROYO, in January 2001 after
ESTRADA’s stormy impeachment trial
on corruption charges broke down and
another “people power” movement
(“EDSA 2”) demanded his resignation.
MACAPAGAL- ARROYO was elected
to a six-year term as president in May
2004- The Philippine Government faces
threats from three terrorist groups on the
US Government’s Foreign Terrorist
Organization list, but in 2006 and 2007
scored some major successes in capturing
or killing key wanted terrorists. Decades
of Muslim insurgency in the southern
Philippines have led to a peace accord
with one group and an ongoing cease-fire
and peace talks with another.
Disputes — international: Philippines
claims sovereignty over certain of the
Spratly Islands, known locally as the
Kalayaan (Freedom) Islands, also
claimed by China, Malaysia, Taiwan, and
Vietnam; the 2002 “Declaration on the
Conduct of Parties in the South China
Sea,” has eased tensions in the Spratly
Islands but falls short of a legally binding
“code of conduct” desired by several of
the disputants; in March 2005, the
national oil companies of China, the
Philippines, and Vietnam signed a joint
accord to conduct marine seismic activi¬
ties in the Spratly Islands; Philippines
retains a dormant claim to Malaysia’s
Sabah State in northern Borneo based
on the Sultanate of Sulu’s granting the
Philippines Government power of
attorney to pursue a sovereignty claim on
his behalf; maritime delimitation negoti¬
ations continue with Palau
Refugees and internally displaced per¬
sons: IDPs: 300,000 (fighting between
government troops and MILF and Abu
Sayyaf groups) (2007)
Illicit drugs: domestic methampheta-
mine production has been a growing
problem in recent years despite govern¬
ment crackdowns; major consumer of
amphetamines; longstanding marijuana
producer mainly in rural areas where
Manila’s control is limited
PITCAIRN ISLANDS
Background: Pitcairn Island was discov¬
ered in 1767 by the British and settled in
1790 by the Bounty mutineers and their
Tahitian companions. Pitcairn was the
first Pacific island to become a British
colony (in 1838) and today remains the
last vestige of that empire in the South
Pacific. Outmigration, primarily to New
Zealand, has thinned the population
from a peak of 233 in 1937 to less than
50 today.
Disputes— international: none
LAND
Background: Poland is an ancient nation
that was conceived near the middle of
the 10th century. Its golden age occurred
in the 16th century. During the fol¬
lowing century, the strengthening of the
gentry and internal disorders weakened
the nation. In a series of agreements
between 1772 and 1795, Russia, Prussia,
and Austria partitioned Poland amongst
themselves. Poland regained its inde¬
pendence in 1918 only to be overrun by
Germany and the Soviet Union in
World War II. It became a Soviet satel¬
lite state following the war, but its gov¬
ernment was comparatively tolerant and
progressive. Labor turmoil in 1980 led to
the formation of the independent trade
union “Solidarity” that over time
became a political force and by 1990 had
swept parliamentary elections and the
presidency. A “shock therapy” program
during the early 1990s enabled the
520
Disputes— international: all of the
Spratly Islands are claimed by China,
Taiwan, and Vietnam; parts of them are
claimed by Malaysia and the Philippines;
in 1984, Brunei established an exclusive
fishing zone that encompasses Louisa
Reef in the southern Spratly Islands but
has not publicly claimed the reef;
claimants in November 2002 signed the
“Declaration on the Conduct of Parties
in the South China Sea,” which has
eased tensions but falls short of a legally
binding “code of conduct”; in March
2005, the national oil companies of
China, the Philippines, and Vietnam
signed a joint accord to conduct marine
seismic activities in the Spratly Islands
A
Jaffm "A:
C * ■ S \\>AV
At
Qf
■BmgM
Mann at
''f
M
Jrincemalee
‘Anuradhapurt
.Puttasam
PoSonnaruwa* ^BatMcaloa
.Matale .Kalrnunat
Negombo^ .Kandy
COLOMBO murutmgm
. Badulla
Sn AMofatuwa
Jayawarctenepura1 *Hatnapura
Kotts *Beruwaia
<3a!S©
a x wm »
# m
RP
PH
PHL
608
PHL
•ph
Pitcairn Islands
PC
PN
PCN
612
PCN
•pn
19 10N
121 40 E
Arctic Ocean
73 00 N
66 00 W
19 55 N
122 10 E
Albania, Bosnia and
42 00 N
23 00 E
Herzegovina, Bulgaria,
Croatia, Greece, Macedonia,
Montenegro, Romania, Serbia,
Slovenia, Turkey (European
part)
20 30 N
121 50 E
13 00 N
122 00 E
Atlantic Ocean
60 00 N
27 00 E
10 50 N
124 50 E
South Korea
37 15 N
131 50 E
Pacific Ocean
40 30 N
121 20 E
16 00 N
121 00 E
Pacific Ocean
20 30 N
121 00 E
Russia
73 45 N
138 00 E
Macau
22 10N
113 33 E
14 35 N
121 00 E
Pacific Ocean
3 20 S
127 23 E
Indian Ocean
8 30 N
79 00 E
8 00 N
125 00 E
Pacific Ocean
9 15 N
124 30 E
12 50 N
121 05 E
Pacific Ocean
12 20 N
120 40 E
15 08 N
120 21 E
Indian Ocean
19 00 S
41 00 E
10 00 N
123 00 E
9 30 N
118 30 E
11 15 N
122 30 E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name _
Pantelleria, Isold di (island)
Papeete (capital)
Paramaribo (capital)
Parece Vela (island)
Paris (capital)
Pascua, Isla de (Easter Island)
Pashtunistan (region)
Passion, lie de la (Island)
Patagonia (region)
Peking (see Beijing)
Pelagian Islands (Isole Pelagie)
Peleliu (Beliliou) (island)
Peloponnese (peninsula)
Pemba Island
Penang Island
Pentland Firth (channel)
Perim (island)
Perouse Strait, La
Persia (former name for Iran)
Persian Gulf
Perth (city)
Pescadores (islands)
Peshawar (city)
Peter I Island
Petrograd (city; former name for Saint Petersburg)
Philip Island
Philippine Sea
Phnom Penh (capital)
Phoenix Islands
Pinatubo, Mount (volcano)
Pines, Isle of (island; former name for Isla de la Juventud)
Pleasant Island
Plymouth (capital)
Podgorica (administrative capital)
Polska (local name)
Polynesie Francaise (local name for French Polynesia)
Pomerania (region)
Ponape (Pohnpei) (island)
Port Louis (capital)
Port Moresby (capital)
Port-Vila (capital)
Port-au-Prince (capital)
Port-of-Spain (capital)
Porto-Novo (capital)
Portuguese East Africa (former name for Mozambique)
Portuguese Guinea (former name for Guinea-Bissau)
Portuguese Timor (former name for Timor-Leste)
Poznan (city)
Prague (capital)
Praia (capital)
Prathet Thai (local name for Thailand)
Pretoria (administrative capital)
Prevlaka peninsula
Pribilof Islands
Prince Edward Island
Prince Edward Islands
Prince Patrick Island
Principe (island)
Prussia (region)
Pukapuka Atoll
Punjab (region)
Puntland (region)
Qazaqstan (local name for Kazakhstan)
Qita Ghazzah (local name Gaza Strip)
Quebec (city)
Queen Charlotte Islands
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
15 08 N
120 21 E
12 00 N
125 00 E
West Bank
32 15 N
35 10 E
American Samoa, Samoa
MOOS
171 00 W
6 00 N
121 00 E
Pacific Ocean
8 00 N
120 00 E','4177d566bcefb2ab9764fc00af9576d794853cc864580f07e73b458bb8664f54','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d33b72a7f84e2a68b994911193f56de8ca4db561c64ab68b39d1df637dcf1b55',2009,'PY','Paraguay','transnational-issues',994,'Background: In the disastrous War of the
Triple Alliance (1865-70) — between
Paraguay and Argentina, Brazil, and
Uruguay — Paraguay lost two-thirds of all
adult males and much of its territory. It
stagnated economically for the next half
century. In the Chaco War of 1932-35,
Paraguay won large, economically impor¬
tant areas from Bolivia. The 3 5 -year mil¬
itary dictatorship of Alfredo
STROESSNER ended in 1989, and,
despite a marked increase in political
infighting in recent years, Paraguay has
held relatively free and regular presiden¬
tial elections since then.
PA
PY
PRY
600
PRY
•py
25 16 S
57 40 W
Asimcioni
S4o Paulo *4
; Rio de faneirt^
VltdriA*
I
IBs
.**-■ .
Santos
In Miguel
Tucumai
. is/« Sur; Ambrosia
Ma San l-elix '' (CHILE)
{CHILE)
Tucuman
Reslstencia*i
Curitiba,
<|f
Morianopolls
• * . i','f599ef8d3e0b063f6e8fc9c6ebbc736b3da94e02591b54073f0cd20bd09facd0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba6bc07d4497f862bcf1b5178ec6a89ed958fad3eb33a294ce34fa8a7f7b1b2',2009,'PE','Peru','transnational-issues',998,'Disputes — international: unruly region
at convergence of Argentina-Brazil-
Paraguay borders is locus of money laun¬
dering, smuggling, arms and illegal
narcotics trafficking, and fundraising for
extremist organizations
Illicit drugs: major illicit producer of
cannabis, most or all of which is con¬
sumed in Brazil, Argentina, and Chile;
transshipment country for Andean
cocaine headed for Brazil, other
Southern Cone markets, and Europe;
corruption and some money-laundering
activity, especially in the Tri-Border
Area; weak anti-money-laundering laws
and enforcement
PE
PE
PER
604
PER
•pe
12 03 S
77 03 W
Arctic Ocean
83 00 N
56 00 W
Jarvis Island, Kingman Reef,
0 05 N
157 00 W
Kiribati, Palmyra Atoll
Atlantic Ocean
43 20 N
4 00 E
Lima X|X
-f
Rio
Branco
Porto
Veiho','b742985ec50a1cdc1c216112ae72a9741f5647d1e173ac32b3dd04c0e0ceb006','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f0d2e266551ef2ef115ea374855ea143d62d862a01e211cc8588b4f8af2685f',2009,'PL','Poland','transnational-issues',1002,'country to transform its economy into
one of the most robust in Central
Europe, but Poland still faces the lin-
gering challenges of high unemploy¬
ment, underdeveloped and dilapidated
infrastructure, and a poor rural under¬
class. Solidarity suffered a major defeat in
the 2001 parliamentary elections when it
failed to elect a single deputy to the
lower house of Parliament, and the new
leaders of the Solidarity Trade Union
subsequently pledged to reduce the Trade
Union’s political role. Poland joined
NATO in 1999 and the European Union
in 2004- With its transformation to a
democratic, market-oriented country
largely completed, Poland is an increas¬
ingly active member of Euro-Atlantic
organizations.
Disputes— international: as a member
state that forms part of the EU’s external
border, Poland has implemented the
strict Schengen border rules to restrict
illegal immigration and trade along its
eastern borders with Belarus and Ukraine
Illicit drugs: despite diligent counternar¬
cotics measures and international infor¬
mation sharing on cross-border crimes, a
major illicit producer of synthetic drugs
for the international market; minor
transshipment point for Southwest
Asian heroin and Latin American
cocaine to Western Europe
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area: total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Area— comparative: about twice the size
of New Hampshire
Land boundaries: total: 1,524 km
border countries: Austria 91 km, Czech
Republic 215 km, Hungary 677 km,
Poland 444 km, Ukraine 97 km
584
PL
PL
POL
616
POL
.pi
54 23 N
18 40 E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Dao Bach Long Vi (island)
Dar es Salaam (capital)
Dardanelles (strait)
Davis Strait
Dead Sea
Deception island
Denmark Strait
Desolation islands (Isles Kerguelen)
Deutschland (local name for Germany)
Devils island (lie du Diable)
Devon Island
Dhaka (capital)
Dhivehi Raajje (local name for Maldives)
Dhofar (region)
Diego Garcia (island)
Diego Ramirez (islands)
Dili (capital)
Dilmun (former name for Bahrain)
Diomede Islands
Diu (region)
Djibouti (capital)
Dnieper (river)
Dniester (river)
Dobruja (region)
Dodecanese (island group)
Dodoma (city)
Doha (capital)
Donets Basin
Douala (city)
Douglas (capital)
Dover, Strait of
Drake Passage
Druk Yul (local name for Bhutan)
Dubai, Dubayy (city)
Dublin (capital)
Duesseldorf (city)
Durban (city)
Dushanbe (capital)
Dutch Antilles (former name for the Netherlands Antilles)
Dutch East Indies (former name for Indonesia)
Dutch Guiana (former name for Suriname)
Dutch West Indies (former name for the Netherlands Antille
Dzungarian Gate (valley)
East China Sea
East Frisian Islands
East Germany (German Democratic Republic; former name
for eastern portion of Germany)
East Korea Strait (Eastern Channel or Tsushima Strait)
East Pakistan (former name for Bangladesh)
East Siberian Sea
Easter Island (Isla de Pascua)
Eastern Channel (East Korea Strait or Tsushima Strait)
Eastern Samoa (former name for American Samoa)
Edinburgh (city)
Eesti (local name for Estonia)
Eire (local name for Ireland)
Elba (island)
Elemi Triangle (region)
Ellada, Ellas (local name for Greece)
Ellef Ringnes Island
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Vietnam
20 08 N
107 44 E
Tanzania
6 48 S
39 17 E
Atlantic Ocean
40 15 N
26 25 E
Atlantic Ocean
67 00 N
57 00 W
Israel, Jordan, West Bank
32 30 N
35 30 E
54 23 N
18 40 E
50 03 N
19 56 E
52 00 N
20 00 E
52 25 N
16 55 E
Czech Republic
50 05 N
14 28 E
Cape Verde
14 55 N
23 31 W
52 15 N
21 00 E
.,Ai (iCKMAPiY*
ARCTIC REGION
e*< ''* fo y
. -f’\\ V< \\ ! Providenivif- Anadyr''
vUikj fi<?5 .* : ■''% * !
4 V’ Anchorage >f Nome , '' J \\
Valdez | , <v V.. -V,--
S\\ UNITED STATUS
\\ Pairbanks h
/
ami
Wat.soh
Lake
Faroe
Torshavm. islands
W loettHAKK)
Scale 1:39,000,000
Azimuthal Equal-Area Projection
Rosto\\
819
THE CIA WORLD FACTBOOK
ASIA
J Minsk,
★
P LA
Ky,v- w *
6ec
> ><i>rWXipA?i
\\
Svalbard
momm
,20""
X / }
i I
m
f W
x
■ISO
t K i40
t ''
NViiR
t v
■ . Oslo . . - ■ / ?,;
l
ir^\\ ,'' ’''on JCUm '' ■;: ■ i X : y''
VOWM
" 4^
■Oslo " v''^*!
swipUV,''''- Tx§l
,. k ... ,
OWLAN0 MurAaiw^/
_
Irkhangcl sk
^ , '') /'', /
X /f>0 SO 100 520 \\
SkaK/IOSIX/ j j \\
ww/ Ar» tk Xoan \\ \\
HHB |
Wnirtgcl ,X'' h /''Providcniva
€/
Si
m
«KR,
<■
.
■
Kh.ukiv* .
, .Vorone/it
Kazan
j*
a0
11
Perm
1,0Mis''fc , *■«•»*.'',
. V,,W«,h1 Sam4ra *> .UK-lv.Hnsk .
c \\ K 1
'' •'' , } " '' . ■ X .V > H
X '' ''“''''Tv'' L AtytalS . , ,. J '' - x \\
j ■■■ X . jfe _ ; ^
S / B E B ''
■
. „ R U S S I A
Ufa * * Tf . w . V ..... .. •" .,/
wm
Omsk
! ''.
g!
■
/.
. . Cc
/fafniH, v, ~s %''
★
handy
UOK.iv/jtuG* f
_ KAZARHsmri
■\\ >
V '' * • / - f- S.. / * ''4
\\ . • — -■^•.yx'''' v« 5<
^ . : ■ -j 71 ■ i
/
; //A T t Jh- #
l,.:''\\ ,''j ''<f ;y;V
, \\ : ''V . ,;4 \\ V/^-r#/- y / - A ! ?l a *
f
LA. • i S |
w-'',. , .... i/ ^ 2 § ; h
\\ \\ Owupied lyy tht- Ntr/i<?{ Union m HHfT
a4mlni$tefgd by
2 -f ^ !^f °''Al* WSiiMmUh
Khabarovsk'''' T ''., ''>T’''
i.Sapt''oro
- B § « r_
m l , '' 1 lv . . i ''4 5 W4:>''i % X
^ MONGOLIA
W. '' J , s “''v 2 '' '' ^ , <
ft ?*p / '' -
rti a
Vladivostok ,-''A Vt
T.
i . - -^ v lacuvosiOK - v ;
4- ■t.rr ir; . ";#
Pypngya
kyo
i / “^ . *
"gy^ng Yokoh
bjotou -. ,_<ar } s v „ ^m~
m i Datum Him:
Tianjin*
* ^J^goy''a
'''' #Q&afc*
s>*
/4 ! ♦ 38 # «g.^vy -v- ^ wiao ctaUtf : : ,.
/jL^^ **«>>&■ >
,. . ■« / r 1/ Lahore^'' omzmsGAimm _
■ ^Abii Ohabi '' - v’ Dl,i5£ ''/'' ’ ^ WJ.gvoresff
•■-„^r / ,3 p/wjspfi / .
“Muscat - -''New Delhi «< X ,,
-^) ’ * 49 * ’
\\ Miput XI 1 "4 5 ''"/*/
.. Karichf / ludm^. X- if ■*■,/> BHiTAW
'' •" • V Kg«fUS< KathtJUr ^ThiSpbu''
>-5^ "XAbmadita J A-rA,v
''
,K<Wns<nkvKv.vf^
. ■ ."" '':'';,,,4:./ '' ,: . . . .
Xin
z™ >* " 1 ''
KanpuA* KathmaivdW •
. \\ . ft I N D'' I A llCT,U1^
"s««i y| , Kolkata. / X./LA r’l:
alt ~~~ • . -v.., *>#gp«f V
f .Pune
0-j
Arabian
.Sea
LAKSHADWEEP
mm
Mumbai^ "^"-••^c,
,* DECCAN;
; ^Hyderabad
m :
* .
x/(-''-\\ >/ "<x 5^K'' iv|is^8^ i ^;J I"''
«« v, ^ s ... _ ^
I ''»■»«••. Lica
tdfc
Ctengqing *
C z _ 1 1
,1 illuoka
Ea.a . .is
a’Y
i;t.u.''i « v ..
If £•
• ''/••< /
O Naomi f A 4
A''*’ " ." X 4A-
i- f.,\\ 2
;j|pe| i ttox-'' v
i|l
140
■ ''S
Ra"»Hife.KK* ^.5
y. .. C.Cutya*^
S4 V .vX''.''/T . ’'' ^ ■ T f Taiwan
F . Philippine
.,lfg ‘*^1 ■ xa
yx
| rtf:
/A ■
. ® Rencalurti
V .L * ’ '' 1m
'',.«> y Chennai
Jay of .
AmtJi
Cochin
^ '' y i Jaffna
MALDIVES/
^ l J.i mitre:
|.
Colombo k
> SRI LAMKA
* I-
Male
ANDAMAN §
ISLANDS f ajf L-
(HDIAt , -v . •. famsrs 4//
$«a ri
StCOHMt
ISLANDS
IhDIA)
/ • yTc
* . . . ''//?/ Chin,
/ f«M. ■-; X v*™AM
'' :f A.TT i «... .
HfartlW#'' ■?/ ISLANDS
Peili^cX-^Mi Chi Mint)
4,„y.f fir a.v ■ .. .
Bandar Ser
Begawan
PHiumnes
>n\\u ac<i |
1
..r
Scale 1 :48,000,000
Azimuthal Equal-Area Projection
0 SOD Kilometers
800 Miles
_ ; _ Tqoator
} n d i a n
O c e a. n
V
Dv,~4._ Jy| | MALAYSIA
"''•"% & H<> Jilngdpore f.
\\Sj \\ l . y&^YlItjATOKC '',
— 1 Ypr ~ .
4 IX
•!
““T f r^''V k-v-
k i i V /,/ .- ::i >. , ''/ .
•* X Kuala l umpur MALAYSIA . *'' ., USaEfe^..
edsiii", ★ .L • '' A f . . . .-iX , F :/"'''' @s"''" c
''''4 iLx^a^Ingapore / ;s/;r .
>#
/C«
■''.I''m 1 N D O
XX
R’ “■ 1.ik.issar'' .
E*f
1 wx
il
SI A
''''■•"/ % i lakarta
•’ } j- . . . -^Surabaya
Bani# xxliiil.
lava
S™ TIMOR-LESTE
’ Timor
./
Ttrfter Se.«
Boundary representation is
not necessarily authoritative.
;>
m
100
1215','f07cdc8a2d2f11ca86f174d824a78d1d64a7d4f71ce0422faf36e9782cdc622f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('521d88cd4e9ae719e0bdf83a0f7b8d3ce1a1dd473bc56ee86bfb6ea06be6a6ef',2009,'PR','Puerto Rico','transnational-issues',1013,'Disputes — international: Portugal does
not recognize Spanish sovereignty over
the territory of Olivenza based on a dif¬
ference of interpretation of the 1815
Congress of Vienna and the 1801 Treaty
of Badajoz
Illicit drugs: seizing record amounts of
Latin American cocaine destined for
Europe; a European gateway for
Southwest Asian heroin; transshipment
point for hashish from North Africa to
Europe; consumer of Southwest Asian
heroin
Disputes— international: increasing
numbers of illegal migrants from the
Dominican Republic cross the Mona
Passage to Puerto Rico each year looking
for work
530
Background: Ruled by the al-Thani
family since the mid'' 1800s, Qatar trans-
formed itself from a poor British protec''
torate noted mainly for pearling into an
independent state with significant oil
and natural gas revenues. During the late
1980s and early 1990s, the Qatari
economy was crippled by a continuous
siphoning off of petroleum revenues by
the Amir, who had ruled the country
since 1972. His son, the current Amir
HAMAD bin Khalifa al-Thani, over¬
threw him in a bloodless coup in 1995.
In 2001, Qatar resolved its longstanding
border disputes with both Bahrain and
Saudi Arabia. Oil and natural gas rev¬
enues enable Qatar to have one of the
highest per capita incomes in the world.
RQ
PR
PRI
630
PRI
.pr
18 28 N
66 07 W','933410907e9c7b30c9f38aa47e4f85d5eb6bcf616fb3d6a16f6064ebc935f7dd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4590b9acbefa57290372e96cce7c361558606648b8c300885de5bd7b808c5f0',2009,'QA','Qatar','transnational-issues',1020,'Disputes — international: none
Trafficking in persons: current situation:
Qatar is a destination country for men
and women from South and Southeast
Asia who migrate willingly, but are sub¬
sequently trafficked into involuntary
servitude as domestic workers and
laborers, and, to a lesser extent, commer¬
cial sexual exploitation; the most
common offense was forcing workers to
accept worse contract terms than those
under which they were recruited; other
conditions include bonded labor, with¬
holding of pay, restrictions on move¬
ment, arbitrary detention, and physical,
mental, and sexual abuse
tier rating: Tier 3 — Qatar’s rating was down¬
graded to Tier 3 in the 2007 report for con¬
tinuing to detain and deport victims rather
than providing them protection; the gov¬
ernment also failed to increase prosecu¬
tions for trafficking in a meaningful way in
2006; workers complaining of working
conditions or non-payment of wages were
sometimes prosecuted under false charges
in retaliation
533
QA
QA
QAT
634
QAT
•qa
Reunion
RE
RE
REU
638
REU
.re
25 17 N
51 32 E
Russia, Ukraine
48 15 N
38 30 E','f80f97f72a969380939cc78481f9fe09277213f05163743a87a0221bedcdbe8c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1de1de3e3c10c9300246382ea34aba1816ba23ae4abd7eec088103eab019f1ad',2009,'RW','Rwanda','transnational-issues',1024,'mm. isp,
OF THE
coma
fwLsr. Suhengen .Syumba
Gisenyi
KIGALI
Ktbuye
Gtlarama
Kibungo f
Cyc-hom
,Cyartgugu
Busare''
T AU7
iOfSUND!
ad te toi :
Background: In 1959, three years before
independence from Belgium, the
majority ethnic group, the Hutus, over¬
threw the ruling Tutsi king. Over the
next several years, thousands of Tutsis
were killed, and some 150,000 driven
into exile in neighboring countries. The
children of these exiles later formed a
rebel group, the Rwandan Patriotic Front
(RPF), and began a civil war in 1990.
The war, along with several political and
economic upheavals, exacerbated ethnic
tensions, culminating in April 1994 in
the genocide of roughly 800,000 Tutsis
and moderate Hutus. The Tutsi rebels
defeated the Hutu regime and ended the
killing in July 1994, but approximately 2
million Hutu refugees — many fearing
Tutsi retribution — fled to neighboring
Burundi, Tanzania, Uganda, and Zaire.
Since then, most of the refugees have
returned to Rwanda, but several thou¬
sand remained in the neighboring
Democratic Republic of the Congo
(DRC; the former Zaire) and formed an
extremist insurgency bent on retaking
Rwanda, much as the RPF tried in 1990.
Despite substantial international assis¬
tance and political reforms — including
Rwanda’s first local elections in March
1999 and its first post-genocide presiden¬
tial and legislative elections in August
and September 2003 — the country con¬
tinues to struggle to boost investment
and agricultural output, and ethnic rec¬
onciliation is complicated by the real
and perceived Tutsi political dominance.
Kigali’s increasing centralization and
intolerance of dissent, the nagging Hutu
extremist insurgency across the border,
and Rwandan involvement in two wars
in recent years in the neighboring DRC
continue to hinder Rwanda’s efforts to
escape its bloody legacy.
542
RW
RW
RWA
646
RWA
.rw
Saint Barthelemy
TB
BL
BLM
652
-
.bl
used
Saint Helena
SH
SH
SHN
654
SHN
.sh
1 57 S
30 04 E
2 00 S
30 00 E
2 00S
30 00 E','483910a3c905aafafd0b9184a5b70fe8605d484bd44a879e854827f695175934','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa591d8a648e90d0551bf261d2dba1656f40a0fc3ba3ee9b46c5ca3d8f169df1',2009,'KN','Saint Kitts and Nevis','transnational-issues',1040,'Disputes — international: none
SC
KN
KNA
659
KNA
.kn
17 18 N
62 43 W
France (Corsica)
42 42 N
9 27 E
17 09 N
62 35 W
17 20 N
62 45 W
17 20 N
62 45 W
802
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Nome _
Saint Eustatius (island)
Saint George''s (capital)
Saint George''s Channel
Saint Helena Island
Saint Helens, Mount (volcano)
Saint Helier (capital)
Saint John (city)
Saint John''s (capital)
Saint Lawrence Island
Saint Lawrence Seaway
Saint Lawrence, Gulf of
Saint Paul Island
Saint Paul Island
Saint Paul Island (lie Saint-Paul)
Saint Peter Port (capital)
Saint Peter and Saint Paul Rocks
(Penedos de Sao Pedro e Sao Paulo)
Saint Petersburg (city; former capital)
Saint Thomas (island)
Saint Vincent Passage
Saint-Denis (capital)
Saint-Martin (island; also Sint Maarten)
Saint-Pierre (capital)
Saipan (island)
Sak''arfvelo (local name for Georgia)
Sakhalin Island (Ostrov Sakhalin)
Sakishima Islands
Sala y Gomez, Isla (island)
Salisbury (city; former name for Harare)
Salzburg (city)
Samar (island)
Samaria (region)
Samoa Islands
Samos (island)
San Ambrosio, Isla (island)
San Andres y Providencia, Archipielago (island group)
San Bernardino Strait
San Felix, Isla (island)
San Jose (capital)
San Juan (capital)
San Marino (capital)
San Salvador (capital)
Sanaa (capital)
Sandzak (region)
Santa Cruz (city)
Santa Cruz Islands
Santa Sede (local name for the Holy See)
Santiago (capital)
Santo Antao (island)
Santo Domingo (capital)
Sao Paulo (city)
Sao Pedro e Sao Paulo, Penedos de (rocks)
Sao Tiago (island)
Sao Tome (island)
Sapporo (city)
Sapudi Strait
Sarajevo (capital)
Sarawak (state)
Sardinia (island)
Sargasso Sea (region)
Sark (island)
Savage Island (former name for Niue)
Savu Sea
Saxony (region)
Schleswig-Holstein (region)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Netherlands Antilles
17 30 N
63 00 W','6aec1d2734e0465700e4ca21514e864e3f2a5337501e612a1628997c1b9b01cd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afb1af4bb2a2e57e62d713c8bdffec64b0b5da9d230787e5ee506212d5714978',2009,'LC','Saint Lucia','transnational-issues',1045,'Disputes — international: joins other
Caribbean states to counter Venezuela’s
claim that Aves Island sustains human
habitation, a criterion under UNCLOS,
which permits Venezuela to extend its
EEZ/continental shelf over a large por¬
tion of the eastern Caribbean Sea
Illicit drugs: transshipment point for
South American drugs destined for the
US and Europe; some money- laundering
activity
_
si '' WA
ST
LC
LCA
662
LCA
.lc
Saint Martin
RN
MF
MAF
663
-
.mf
used _ „ .
Saint Pierre and
SB
PM
SPM
666
SPM
.pm
Miquelon
Saint Vincent and
VC
VC
VCT
670
VC1
.VC
the Grenadines
14 01 N
61 00 W','a697c1b8f4c4e41dc660e821f3a65f1522f6dfb3f1af6c8c622430b88d0d8500','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d9d13c23ca583122238f337422e0997828f4f4b75bfa80744d31cebef3bbb0e',2009,'BB','Barbados','transnational-issues',1049,'Disputes— international: joins other
Caribbean states to counter Venezuela’s
claim that Aves Island sustains human
habitation, a criterion under UNCLOS,
which permits Venezuela to extend its
EEZ/continental shelf over a large por¬
tion of the eastern Caribbean Sea
Illicit drugs: transit point for South
American drugs destined for the US and
Europe
SAINT MARTIN
BB
BB
BRB
052
BRB
.bb
administered as part of
Bassas da India
BS
-
-
-
-
13 06 N
59 37 W','76e739a82b43202c6b93adeb4e6f1bef7f4615419cd6aacfeea63b6dee5da14c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9abb127ab783d9a0010db84459ed090b45ef45f4f36a4be27b5721cde20b54e0',2009,'VC','Saint Vincent and the Grenadines','transnational-issues',1055,'Background: Resistance by native Caribs
prevented colonization on St. Vincent
until 1719. Disputed between France and
the United Kingdom for most of the 18th
century, the island was ceded to the
latter in 1783. Between 1960 and 1962,
Saint Vincent and the Grenadines was a
separate administrative unit of the
Federation of the West Indies.
Autonomy was granted in 1969 and
independence in 1979.
Location: Caribbean, islands between
the Caribbean Sea and North Atlantic
Ocean, north of Trinidad and Tobago
Geographic coordinates: 13 15 N, 61 12
w
Map references: Central America and
the Caribbean
Area:
total: 389 sq km (Saint Vincent 344 sq
km)
land: 389 sq km
water: 0 sq km
Area — comparative: twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; little seasonal temper¬
ature variation; rainy season (May to
November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: La Soufriere 1,234 m
Natural resources: hydropower, crop¬
land
Land use:
arable land: 17.95%
permanent crops : 17.95%
other: 64-1% (2005)
Irrigated land: 10 sq km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.01
per capita: 83 cu m/yr (1995)
Natural hazards: hurricanes; Soufriere
volcano on the island of Saint Vincent is
a constant threat
Environment — current issues: pollution
of coastal waters and shorelines from dis-
557
THE CIA WORLD FACTBOOK
charges by pleasure yachts and other
effluents; in some areas, pollution is
severe enough to make swimming pro¬
hibitive
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: the administration of
the islands of the Grenadines group is
divided between Saint Vincent and the
Grenadines and Grenada; Saint Vincent
and the Grenadines is comprised of 32
islands and cays','1d41cf513d41a601371753280b990e05e69d9054ba66a3c7de33f684471c7de5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11c24039e057d7e252b1ca62ef0045a535ac8270bcbe7c1b47e734a3eafe6d4f',2009,'WS','Samoa','transnational-issues',1066,'Disputes— international: none
ws
WS
WSM
882
WSM
.ws
13 50 S
171 44 W
Indian Ocean
29 00 N
34 30 E
Iran, Iraq
29 57 N
48 34 E
Indian Ocean
15 00 N
65 00 E
Pacific Ocean
9 00 S
133 00 E
Kazakhstan, Uzbekistan
45 00 N
60 00 E
China, Russia
53 20 N
121 28 E
Pacific Ocean
6 15 S
135 00 E
13 35 S
172 20 W
Pacific Ocean
8 20 S
126 30 E
Arctic Ocean
65 30 N
38 00 E','ba8c015743676ccbaaa6f03da29b19040e33ee8c1749ff022281a0bc4f9bd985','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fc04336f6dff88cc18c6e02a4d4e4e35db48893ad0f65de186e783eeae376ec',2009,'SM','San Marino','transnational-issues',1072,'Disputes— international: none
SM
SM
SMR
674
SMR
.sm
Sao Tome and
TP
ST
STP
678
STP
.St
Principe
43 56 N
12 25 E','7f8cd10ad36f67d7aef2c06b40f5359164c63c138ffae4d10c5f62c230b0d5fa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaa7f2e813dc0c133e5aff5a12a7cd04e6585999a2fba1562f5eacc1709c59a8',2009,'ST','Sao Tome and Principe','transnational-issues',1073,'JtMu Bombom
tiha do Principe -sanlo Antonio
Tirthosa P&qmrm .
flMu Carcfcpo
Tinbosa Grande
Gulf of
1 38 N
7 25 E
Germany, Poland, Russia
53 00 N
14 00 E
0 12N
6 39 E','7d18c892a90d73f20a5c57b2ae6773efeb05405894485ba95d22ad2ece0a0c26','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4baa2c1a0c55c767117cb56d734a66caa01fe875e74787c65ebaa8ae2f5d7d5e',2009,'SL','Sierra Leone','transnational-issues',1098,'Disputes — international: together with
Mauritius, Seychelles claims the Chagos
Archipelago (UK-administered British
Indian Ocean Territory)
Background: Democracy is slowly being
reestablished after the civil war from
1991 to 2002 that resulted in tens of
thousands of deaths and the displace¬
ment of more than 2 million people
(about one-third of the population). The
military, which took over full responsi¬
bility for security following the departure
of UN peacekeepers at the end of 2005,
is increasingly developing as a guarantor
of the country’s stability. The armed
forces remained on the sideline during
the 2007 presidential election, but still
look to the UN Integrated Office in
Sierra Leone (UNIOS1L) — a civilian
UN mission — to support efforts to con¬
solidate peace. The new government’s
priorities include furthering develop¬
ment, creating jobs, and stamping out
endemic corruption.
SL
SL
SLE
694
SLE
.si
8 30 N
13 15 W','8bd0d3e73e5400a4818f42e262ffb08fa60dfacb2c32291c98fd09548c4acf55','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('594d9cf2c26e86330f6a0406d8a8da8b2eabf95cbde63dd49b14c633aa6c278c',2009,'SG','Singapore','transnational-issues',1106,'Disputes — international: as domestic
fighting among disparate ethnic groups,
rebel groups, warlords, and youth gangs
in Cote d’Ivoire, Guinea, Liberia, and
Sierra Leone gradually abate, the number
of refugees in border areas has begun to
slowly dwindle; UN Mission in Sierra
Leone (UNAMSIL) has maintained
over 4,000 peacekeepers in Sierra Leone
since 1999; Sierra Leone considers exces¬
sive Guinea’s definition of the flood
plain limits to define the left bank
boundary of the Makona and Moa rivers
and protests Guinea’s continued occupa¬
tion of these lands including the hamlet
of Yenga occupied since 1998
Refugees and internally displaced per¬
sons: refugees (country of origin): 27,311
(Liberia) (2007)
Disputes— international: disputes per¬
sist with Malaysia over deliveries of fresh
water to Singapore, Singapore’s exten¬
sive land reclamation works, bridge con¬
struction, and maritime boundaries in
the Johor and Singapore Straits; in
November 2007, the ICJ will hold public
hearings as a consequence of the
Memorials and Countermemorials filed
by the parties in 2003 and 2005 over sov¬
ereignty of Pedra Branca Island/Pulau
Batu Puteh, Middle Rocks and South
Ledge; Indonesia and Singapore con¬
tinue to work on finalization of their
1973 maritime boundary agreement by
defining unresolved areas north of
Indonesia’s Batam Island; piracy remains
a problem in the Malacca Strait
Illicit drugs: drug abuse limited because
of aggressive law enforcement efforts; as
a transportation and financial services
hub, Singapore is vulnerable, despite
strict laws and enforcement, as a venue
for money laundering
Background: The dissolution of the
Austro-Hungarian Empire at the close of
World War I allowed the Slovaks to join
the closely related Czechs to form
Czechoslovakia. Following the chaos of
World War II, Czechoslovakia became a
Communist nation within Soviet-domi¬
nated Eastern Europe. Soviet influence
collapsed in 1989 and Czechoslovakia
once more became free. The Slovaks and
the Czechs agreed to separate peacefully
on 1 January 1993. Slovakia joined both
NATO and the EU in the spring of 2004.
Location: Central Europe, south of
SN
SG
SGP
702
SGP
•sg
1 17 N
103 51 E
Pacific Ocean
1 15 N
104 00 E','56363d6ce0390eb38dadad465c3187f06e0d72e7f16b1cd2d3b1c65d00378fc6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d5ef3dd115063848c3421d6bd698facefb9c797502960a49b37448eea2ef2cc',2009,'SK','Slovakia','transnational-issues',1111,'Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: rugged mountains in the central
and northern part and lowlands in the
south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovsky Stit 2,655 m
Natural resources: brown coal and lig¬
nite; small amounts of iron ore, copper
and manganese ore; salt; arable land
Land use:
arable land: 29.23%
permanent crops: 2.67%
other: 68.1% (2005)
Irrigated land: 1,830 sq km (2003)
Total renewable water resources: 50.1
cu km ( 2003 )
Freshwater withdrawal (domestic/
industrial/agricultural): total 1.04
per capita: 193 cu m/yr (2003)
Natural hazards: NA
Environment — current issues: air pollu¬
tion from metallurgical plants presents
human health risks; acid rain damaging
forests
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; most of
the country is rugged and mountainous;
the Tatra Mountains in the north are
interspersed with many scenic lakes and
valleys
LO
SK
SVK
703
SVK
.sk
48 09 N
17 07 E
Republic of the Congo
4 16 S
15 17 E
48 40 N
19 30 E
Turkey
38 25 N
27 10 E','23d7789ccfaf8afc3cc438b515b9c4535d9ebccbf441b9137498bd1a0be0f605','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02835ee509ecc3715e93d31ef4b75df7c031551f865220f870e97d0018dd674',2009,'SO','Somalia','transnational-issues',1130,'Disputes — international: since 2003,
the Regional Assistance Mission to the
Solomon Islands (RAMSI), consisting of
police, military, and civilian advisors
drawn from 15 countries, has assisted in
reestablishing and maintaining civil and
political order while reinforcing regional
stability and security
Refugees and internally displaced per¬
sons: lDPs: 5,400 (displaced by tsunami
on 2 April 2007) (2007)
Disputes— international: Ethiopian
forces invaded southern Somalia and
routed Islamist Courts from Mogadishu
in January 2007; “Somaliland” secession¬
ists provide port facilities in Berbera to
landlocked Ethiopia and have estab¬
lished commercial ties with other
regional states; “Puntland” and
“Somaliland” “governments” seek inter¬
national support in their secessionist
aspirations and overlapping border
claims; the undemarcated former British
administrative line has little meaning as
a political separation to rival clans
within Ethiopia''s Ogaden and southern
Somalia’s Oromo region; Kenya works
hard to prevent the clan and militia
fighting in Somalia from spreading south
across the border, which has long been
open to nomadic pastoralists
Refugees and internally displaced per¬
sons: IDPs: 1.1 million (civil war since
1988, clan-based competition for
resources) (2007)
596
SO
SO
SOM
706
SOM
.so
4 00 N
46 00 E
Indian Ocean
15 00 N
90 00 E
Pacific Ocean
2 30 S
132 30 E
Russia
55 00 N
166 30 E
Pacific Ocean
60 00 N
175 00 W
Pacific Ocean
65 30 N
169 00 W
10 00 N
49 00 E
10 00 N
49 00 E
2 04 N
45 22 E
Moldova, Romania
47 00 N
29 00 E
Pacific Ocean
2 00 N
127 00 E
8 21 N
49 08 E
9 30 N
46 00 E','27811de4b4507166ce84156e6806bdfc702d2e319e48d59b67e5de3a8dd83c26','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b11d3c843c23f0391d6acad78e0eef9ceee408be1aeda12bedc39b37f6ee7fe',2009,'ZA','South Africa','transnational-issues',1132,'A V.''A ^
.
_
’ vt* r - ''-A-vi ■ ■.«•''!
''i • ''
_ _
Disputes — international: South Africa
has placed military along the border to
apprehend the thousands of
Zimbabweans fleeing economic dysfunc¬
tion and political persecution; as of
January 2007, South Africa also supports
large numbers of refugees and asylum
seekers from the Democratic Republic of
the Congo (33,000), Somalia (20,000),
Burundi (6,500), and other states in
Africa (26,000); managed dispute with
Namibia over the location of the
boundary in the Orange River; in 2006,
Swazi king advocates resort to ICJ to
claim parts of Mpumalanga and
KwaZulu-Natal from South Africa
Refugees and internally displaced per¬
sons: refugees (country of origin): 10,772
(Democratic Republic of Congo); 7,818
(Somalia); 5,759 (Angola) (2007)
Trafficking in persons: current situation:
South Africa is a source, transit, and des¬
tination country for men, women, and
children trafficked for forced labor and
sexual exploitation; women and girls are
trafficked internally — and occasionally
to European and Asian countries — for
sexual exploitation; women from other
African countries are trafficked to South
Africa and, less frequently, onward to
Europe for sexual exploitation; men and
boys are trafficked from neighboring
countries for forced agricultural labor;
Asian and Eastern European women are
trafficked to South Africa for debt-
bonded sexual exploitation
tier rating: Tier 2 Watch List — South
Africa is placed on the Tier 2 Watch List
for its failure to show increasing efforts to
address trafficking in 2005
Illicit drugs: transshipment center for
heroin, hashish, and cocaine, as well as a
major cultivator of marijuana in its own
right; cocaine and heroin consumption
on the rise; world’s largest market for
illicit methaqualone, usually imported
illegally from India through various east
African countries, but increasingly pro¬
ducing its own synthetic drugs for
domestic consumption; attractive venue
for money launderers given the
increasing level of organized criminal
and narcotics activity in the region and
the size of the South African economy
SF
ZA
ZAF
710
ZAF
.za
South Georgia and
SX
GS
SGS
239
SGS
•gs
the Islands
29 12 S
26 07 E
Pacific Ocean
38 00 N
120 00 E
Cape Verde
16 05 N
22 50 W
26 30 S
25 30 E
27 30 S
23 30 E
31 30 S
22 30 E
33 57 S
18 25 E
34 15 S
18 20 E
Venezuela
10 30 N
66 56 W
33 00 S
27 00 E
Holy See
41 54 N
12 27 E
Vietnam
11 00 N
107 00 E
29 51 S
31 02 E
34 24 S
18 30 E
26 15 S
28 00 E
Pacific Ocean
MOOS
128 45 E
46 51 S
37 52 E
Atlantic Ocean
40 40 N
28 15 E
29 00 S
30 25 E
28 20 S
26 40 E
25 42 S
28 13 E
46 35 S
38 00 E
32 15 S
28 15 E
25 10 S
29 25 E
23 00 S
31 00 E
Pacific Ocean
13 34 N
120 51 E','5825c5e0635992032aa02d9fa100d983a308234d6e926d97f5deccb4cd12c032','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9fa27cb71019504daa1ddad58ad1d2a0a3bd137db4a0c1411ac25fdfd100d19',2009,'GS','South Georgia and the South Sandwich Islands','transnational-issues',1135,'fexks
^ aro not
0 ICO 200 km
0 100 m> mi
South Georgia
! .Grytviken
Bid
Island
South
A Smile Ocmn
Clerke
Rocks
Traversay
Islands
South
Sm
Sandwich Saunders 1.
islands .. , ,
Montagu t.
Bristol I.
AdmirMerod by UM .
cjtornm by MZmnm,
Southern
Thule
Background: The islands, which have
large bird and seal populations, lie
approximately 1,000 km east of the
Falkland Islands and have been under
British administration since 1908 —
except for a brief period in 1982 when
Argentina occupied them. Grytviken, on
South Georgia, was a 19th and early
20th century whaling station. Famed
explorer Ernest SHACKLETON stopped
there in 1914 en route to his ill-fated
attempt to cross Antarctica on foot. He
returned some 20 months later with a
few companions in a small boat and
arranged a successful rescue for the rest of
his crew, stranded off the Antarctic
Peninsula. He died in 1922 on a subse¬
quent expedition and is buried in
Grytviken. Today, the station houses sci¬
entists from the British Antarctic
Survey. Recognizing the importance of
preserving the marine stocks in adjacent
waters, the UK, in 1993, extended the
exclusive fishing zone from 12 nm to 200
nm around each island.
Location: Southern South America,
islands in the South Atlantic Ocean,
east of the tip of South America
Geographic coordinates: 54 30 S, 37 00
w
Map references: Antarctic Region
Area:
total: 3,903 sq km
land: 3,903 sq km
water: 0 sq km
note: includes Shag Rocks, Black Rock,
Clerke Rocks, South Georgia Island,
Bird Island, and the South Sandwich
Islands, which consist of 1 1 islands
Area— comparative: slightly larger than
Rhode Island
Land boundaries: 0 km
Coastline: NA km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: variable, with mostly westerly
winds throughout the year interspersed
600
SOUTHERN OCEAN
with periods of calm; nearly all precipita¬
tion falls as snow
Terrain: most of the islands, rising
steeply from the sea, are rugged and
mountainous; South Georgia is largely
barren and has steep, glacier-covered
mountains; the South Sandwich Islands
are of volcanic origin with some active
volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget (South
Georgia) 2,934 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (largely covered by perma¬
nent ice and snow with some sparse veg¬
etation consisting of grass, moss, and
lichen) (2005)
Irrigated land: 0 sq km
Natural hazards: the South Sandwich
Islands have prevailing weather condi¬
tions that generally make them difficult
to approach by ship; they are also subject
to active volcanism
Environment— current issues: NA
Geography — note: the north coast of
South Georgia has several large bays,
which provide good anchorage; reindeer,
introduced early in the 20th century, live
on South Georgia
Disputes— international: Argentina,
which claims the islands in its constitu¬
tion and briefly occupied them by force
in 1982, agreed in 1995 to no longer seek
settlement by force
SOUTHERN OCEAN','bbf4c33fb8dd0dac33d5172f886c7f2f2a49e6ab3d76031ad542101072ad0f18','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b33828441b5654fe5fed33ab3d55d0716f3bcf81a9f2241bedc8617947e698a5',2009,'ES','Spain','transnational-issues',1144,'Disputes— international: Antarctic
Treaty defers claims (see Antarctica
entry), but Argentina, Australia, Chile,
France, NZ, Norway, and UK assert
claims (some overlapping), including the
continental shelf in the Southern
Ocean; several states have expressed an
interest in extending those continental
shelf claims under the United Nations
Convention on the Law of the Sea
(UNCLOS) to include undersea ridges;
the US and most other states do not rec-
ognize the land or maritime claims of
other states and have made no claims
themselves (the US and Russia have
reserved the right to do so); no formal
claims exist in the waters in the sector
between 90 degrees west and 150 degrees
west
Disputes — international: in 2002,
Gibraltar residents voted overwhelm¬
ingly by referendum to remain a British
colony and against a “total shared sover¬
eignty” arrangement while demanding
participation in talks between the UK
and Spain; Spain disapproves of UK
plans to grant Gibraltar greater
autonomy; Morocco protests Spain’s
control over the coastal enclaves of
Ceuta, Melilla, and the islands of Penon
de Velez de la Gomera, Penon de
Alhucemas and Islas Chafarinas, and sur¬
rounding waters; Morocco serves as the
primary launching site of illegal migra¬
tion into Spain from North Africa;
Portugal does not recognize Spanish sov¬
ereignty over the territory of Olivenza
based on a difference of interpretation of
the 1815 Congress of Vienna and the
1801 Treaty of Badajoz
Illicit drugs: despite rigorous law enforce¬
ment efforts, North African, Latin
American, Galician, and other European
traffickers take advantage of Spain’s long
coastline to land large shipments of
cocaine and hashish for distribution to
the European market; consumer for Latin
American cocaine and North African
hashish; destination and minor transship¬
ment point for Southwest Asian heroin;
money-laundering site for Colombian
narcotics trafficking organizations and
organized crime
Background: The Spratly Islands consist of
more than 100 small islands or reefs. They
are surrounded by rich fishing grounds and
potentially by gas and oil deposits. They
are claimed in their entirety by China,
Taiwan, and Vietnam, while portions are
claimed by Malaysia and the Philippines.
About 45 islands are occupied by relatively
small numbers of military forces from
China, Malaysia, the Philippines, Taiwan,
and Vietnam. Brunei has established a
fishing zone that overlaps a southern reef
but has not made any formal claim.
606
SP
ES
ESP
724
ESP
.es
Comment
ISO includes with the US
Minor Outlying Islands
ccTLD .fr and .gp may also be
ccTLD .fr and .gp may also be
781
THE CIA WORLD FACTBOOK
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
Spratly Islands
35 13 N
3 53 W
39 30 N
3 00 E
Atlantic Ocean
40 30 N
2 00 E
41 25 N
2 13 E
Arctic Ocean
74 00 N
36 00 E
43 00 N
2 30 W
Pacific Ocean
39 20 S
145 30 E
43 15 N
2 58 W
28 00 N
15 30 W
42 00 N
2 00 E
35 53 N
5 19 W
35 12 N
2 26 W
40 00 N
4 00 W
42 45 N
8 10 E
40 24 N
3 41 W
Atlantic Ocean
54 00 S
71 00 W
Algeria, Libya, Mauritania,
34 00 N
3 00 E
Morocco, Tunisia
39 30 N
3 00 E
39 30 N
3 00 E
35 19 N
2 58 W
40 00 N
4 00 E
35 11 N
4 18 W
Ankara .
At
TURKEY
Adana
. ; f ?r
AZORES
<FOKTtXjAU
i Naples''*
Kmttttia
Lisbon
_ Mashhad
* Tehran
Oran
MAliwMA ISLANDS
/PORTUGAL}
/ Funchal
*. Valletta
MALfA
.'' (It*. r
Nivosl
CYPRUS5
Constantine
m . . f
Rabat /
Casablanca,*# •
/ MOROCCO
< MarnrteeU* J
f ;.fahan
(RAM
Beirut*,*
jSweut ’*Amman
X&A( .iordan
.SltJrai
Alexandria
Iripoli
CANARY ISLANDS
, (SFAim
KUW v
Western
★ QATAR • i:a e
\\-ivan,
SAUDI
ARABIA
Nouadhtbou
* Nouakchott
CAPE VERpE
lombouctou
MALI*
BURKINA Niamev','d452114000b8b868f84a5ee956a5a78bca55e282e4a20ee0b8ad7edf313b84fa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cd09e3fef5c1a44190a9b71aaf42a8b8f8c2bd5e4b286459854626a4e4a04c3',2009,'LK','Sri Lanka','transnational-issues',1149,'Nortlwasi Cay
Southwest Cay
H''esf Yofk
Island
Fiat
Scat
- rttitu law
Loatta
Cbv
island
Sand Cay^Lmtta Island
Itu Aha Island^- ,''£tdadRmf
\\
Namtwn
island
§ «
t§wm
Sin :
Mischtaf
FSaty Cross
island ‘
Rmf
f
Rmf
Pigeon Reef
Half ^
<t» *
Spratiy
Island
Altson
Rauf
Moon
Shoal
*
/
\\
Amboyna
Cay
& » 0
m 1« km
SO
100 rei
Disputes— international: none
Refugees and internally displaced per¬
sons: IDPs: 460,000 (both Tamils and
non-Tamils displaced due to long-term
civil war between the government and
the separatist Liberation Tigers of Tamil
Eelam (LTTE)) (2007)
Background: Military regimes favoring
610
Islamic-oriented governments have
dominated national politics since inde¬
pendence from the UK in 1956. Sudan
was embroiled in two prolonged civil
wars during most of the remainder of the
20th century. These conflicts were
PG
CE
LK
LKA
144
LKA
.Ik
7 00 N
81 00 E
6 56 N
79 51 E
7 00 N
81 00 E','0084da5f78e022d0ee626a6158ad29fa00ebfb53d354e4aaf57c67eb29fbecf0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b688ab2f1336acef0641deb777c412ac564b508e36e7f1107252331a9b73e26',2009,'SD','Sudan','transnational-issues',1156,'EGYPT Y
Port ''
.Aibara
Omdiirman.
KHARTOUM*
Ai Fashir Wad Ma{ia
AiUbayyaJ* Kiistt''
_W6 w
o€M w o* n* wmo NW
* . ^ r s\\ ^
rooted in northern economic, political,
and social domination of largely non-
Muslim, non-Arab southern Sudanese.
The first civil war ended in 1972 but
broke out again in 1983. The second war
and famine-related effects resulted in
more than four million people displaced
and, according to rebel estimates, more
than two million deaths over a period of
two decades. Peace talks gained
momentum in 2002-04 with the signing
of several accords. The final
North/South Comprehensive Peace
Agreement (CPA), signed in January
2005, granted the southern rebels
autonomy for six years. After which, a
referendum for independence is sched¬
uled to be held. A separate conflict,
which broke out in the western region of
Darfur in 2003, has displaced nearly two
million people and caused an estimated
200,000 to 400,000 deaths. The UN
took command of the Darfur peace¬
keeping operation from the African
Union on 31 December 2007. As of early
2008, peacekeeping troops were strug¬
gling to stabilize the situation, which has
become increasingly regional in scope,
and has brought instability to eastern
Chad, and Sudanese incursions into the
Central African Republic. Sudan also
has faced large refugee influxes from
neighboring countries, primarily
Ethiopia and Chad. Armed conflict,
poor transport infrastructure, and lack of
government support have chronically
obstructed the provision of humanitarian
assistance to affected populations.
Disputes— international: the effects of
Sudan’s almost constant ethnic and rebel
militia fighting since the mid-20th cen¬
tury have penetrated all of the neigh¬
boring states; as of 2006, Chad, Ethiopia,
Kenya, Central African Republic,
Democratic Republic of the Congo, and
Uganda provided shelter for over half a
million Sudanese refugees, which
includes 240,000 Darfur residents driven
from their homes by Janjawid armed
militia and the Sudanese military forces;
Sudan, in turn, hosted about 116,000
Eritreans, 20,000 Chadians, and smaller
numbers of Ethiopians, Ugandans,
Central Africans, and Congolese as
refugees; in February 2006, Sudan and
DROC signed an agreement to repatriate
13,300 Sudanese and 6,800 Congolese;
Sudan accuses Eritrea of supporting
Sudanese rebel groups; efforts to demar¬
cate the porous boundary with Ethiopia
proceed slowly due to civil and ethnic
fighting in eastern Sudan; the boundary
that separates Kenya and Sudan’s sover¬
eignty is unclear in the “Ilemi Triangle,”
which Kenya has administered since
colonial times; while Sudan claims to
administer the Hala’ib Triangle north of
the 1899 Treaty boundary along the
22nd Parallel; both states withdrew their
military presence in the 1990s, and Egypt
has invested in and effectively adminis¬
ters the area; periodic violent skirmishes
with Sudanese residents over water and
grazing rights persist among related pas¬
toral populations along the border with
the Central African Republic
Refugees and internally displaced per¬
sons: refugees (country of origin): 157,220
(Eritrea); 25,023 (Chad); 11,009
(Ethiopia); 7,895 (Uganda); 5,023
(Central African Republic)
IDPs: 5.3 — 6.2 million (civil war
1983-2005; ongoing conflict in Darfur
region) (2007)
Trafficking in persons: current situation:
Sudan is a source country for men,
women, and children trafficked for the
purposes of forced labor and sexual
exploitation; Sudan may also be a transit
and destination country for Ethiopian
women trafficked for domestic servitude;
boys are trafficked to the Middle East,
particularly Qatar and the United Arab
Emirates, for use as camel jockeys; small
numbers of girls are reportedly trafficked
within Sudan for domestic servitude as
well as for commercial sexual exploita¬
tion in small brothels in internally dis¬
placed persons (IDP) camps; the terrorist
rebel organization “Lord’s Resistance
Army” (LRA) continues to abduct and
forcibly conscript small numbers of chil¬
dren in Southern Sudan for use as cooks,
porters, and combatants in its ongoing
war against Uganda; some of these chil¬
dren are then trafficked across borders
into Uganda or possibly the Democratic
Republic of the Congo; children are uti¬
lized by rebel groups and the Sudanese
Armed Forces and associated militias in
the ongoing conflict in Darfur; during
the decades of civil war, thousands of
Dinka women and children were
enslaved by members of Baggara tribes
and subjected to various forms of forced
labor without remuneration as well as
physical and sexual abuse; with the ces¬
sation of the North-South conflict and
the ongoing peace process, there were no
known new abductions of Dinka by
Baggara tribes during 2005; however,
inter-tribal abductions of a different
nature continue in Southern Sudan and
warrant further investigation
tier rating: Tier 3— Sudan does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so
Background: First explored by the
Spaniards in the 16th century and then
settled by the English in the mid- 17th
century, Suriname became a Dutch
colony in 1667. With the abolition of
slavery in 1863, workers were brought in
from India and Java. Independence from
the Netherlands was granted in 1975.
Five years later the civilian government
was replaced by a military regime that
soon declared a socialist republic. It con¬
tinued to exert control through a succes¬
sion of nominally civilian administrations
until 1987, when international pressure
finally forced a democratic election. In
1990, the military overthrew the civilian
leadership, but a democratically elected
government — a four-party New Front
coalition— returned to power in 1991 and
has ruled since, expanding to eight parties
in 2005.
SU
SD
SDN
736
SDN
.sd
15 00 N
30 00 E
15 00 N
30 00 E
Saint Helena
7 57 S
14 22 W
15 36 N
32 32 E
795
THE CIA WORLD FACTBOOK
Name _
Khios (island)
Khmer Republic (former name for Cambodia)
Khuriya Muriya Islands (Kuria Muria Islands)
Khyber Pass
Kibris (Turkish local name for Cyprus)
Kiel Canal (Nord-Ostsee Kanal)
Kiev (city; former name for Kyiv)
Kigali (capital)
Kingston (capital)
Kingston (capital)
Kingstown (capital)
Kinshasa (capital)
Kipros (Greek local name for Cyprus)
Kirghiziya, Kirgizia (former name for Kyrgyzstan)
Kirguizstan (local name for Kyrgyzstan)
Kiritimati (Christmas Island)
Kishinev (see Chisinau)
Kithira Strait
Kobe (city)
Kodiak Island
Kola Peninsula (Kol''skiy Poluostrov)
Kolonia (town; former capital; changed to Palikir)
Korea Bay
Korea Strait
Omdurman . .
\\ Khartoum
Scale 1:21,000,000
Lambert Conformal Conk Projection,
standard parallels i 2°N ami 38''N Addfe Afcaba
■''"<! isikwnHers
300 Mites
\\
Boundary representation is t
; not necessarily aothoritattvo \\
Smalm
(Ymtn)
• * i Li rgcysa SOMALIA
Golan Heights Is Israeli- occupied Syria
/ ETHIOPIA
U«c *
* v > /
''/ f West Bank en-J Gazs Strip arc Israeli -''Occupied with current
X status subject to the Isra^iisPalcstinlan Intertiti Agreement • ■•
\\ permanent status to he determined through further negutiatiem. <
Israel .proclaimed Jerusalem as iu eapKal in 1 950, but the US, like ;
x nearly ell uther countries, rneimains, Us Embassy in ''lei Aviv. /.
823
THE CIA WORLD FACTBOOK
NORTH AMERICA
Cherniy ^\\\\n
RUSSIA Vevek
A r c l i. c O c c ;i it
51
,0x0
V'' '' Alert''
ggl If
•'' I :
Cfrmnimxi
Ah
e
IHoqtjtirWnfflit*
Jan Mayen
4- (NORWAY)
Anadyr*
Provfdeniva .
Q''j^''VV''\\
■ : lOlLAHl)
Agp
CflUKv''ti
W/W Qifii''wq
•tl::.:. T/",, X'' ''ft
Barrow
>•
%ome ''
Bering
Prudffee . Beaulorf
* Bav
-■> '' / SCI
f QUEEN ELfZABtm,
ISLANDS
“ l ''''%W ■ J .Jk SyiNtn Bay
'' f
Resolute*
Qree aland
(DEFIMAKft)
*
Reykjavik
■'' Jt Denmark
Tastily
Tk Strwt
«?<f','46ff31b768e3ca95e96454f08aa51b78aafefa6e8e9ded0bae455e6e5744c185','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c266155cc854175bb005907b2c7201b1781ad2131ae5c57e3c75865e543eb1c',2009,'SR','Suriname','transnational-issues',1167,'Disputes — international: area claimed
by French Guiana between Riviere
Litani and Riviere Marouini (both head¬
waters of the Lawa); Suriname claims a
triangle of land between the New and
Kutari/Koetari. rivers in a historic dispute
over the headwaters of the Courantyne;
Guyana seeks United Nations
Convention on the Law of the Sea
(UNCLOS) arbitration to resolve the
long-standing dispute with Suriname
over the axis of the territorial sea
boundary in potentially oil-rich waters
Illicit drugs: growing transshipment
point for South American drugs destined
for Europe via the Netherlands and
Brazil; transshipment point for arms-for-
drugs dealing
, :
ci/AIRADD
9 V ALDMKft/
Disputes— international: despite recent
discussions, Russia and Norway dispute
their maritime limits in the Barents Sea
and Russia’s fishing rights beyond
Svalbard’s territorial limits within the
Svalbard Treaty zone
618
Background: Autonomy for the Swazis of
southern Africa was guaranteed by the
British in the late 19th century; inde-
pendence was granted in 1968. Student
and labor unrest during the 1990s pres¬
sured King MSWATI III, the world’s last
absolute monarch, to grudgingly allow
political reform and greater democracy,
although he has backslid on these prom¬
ises in recent years. A constitution came
into effect in 2006, but political parties
remain banned. The African United
Democratic Party tried unsuccessfully to
register as an official political party in
mid 2006. Talks over the constitution
broke down between the government
and progressive groups in 2007.
Swaziland recently surpassed Botswana
as the country with the world’s highest
known HIV/AIDS prevalence rate.
NS
SR
SUR
740
SUR
.sr
Svalbard
SV
SJ
SJM
744
SJM
•sj
ISO includes Jan Mayen
Swaziland
wz
SZ
SWZ
748
SWZ
.sz
4 00 N
56 00 W
) Netherlands Antilles
China, Kazakhstan
12 10N
68 30 W
45 25 N
82 25 E
Pacific Ocean
30 00 N
126 00 E
4 00 N
56 00 W
5 50 N
55 10W
4 00 N
56 00 W
Syria
35 00 N
38 00 E','662844177549c9ba18f793122343f5a713451bf80faeaf41722acaaaa3cf4fa2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63ce895cbcb55661a2eb34280e73ef46099310e3b3daba48c9cff47f4a7f8983',2009,'CH','Switzerland','transnational-issues',1171,'■.A''Av
• U ’ A’ -#jr • v •< i ''A>
? A*- • A
Background: The Swiss Confederation
was founded in 1291 as a defensive
alliance among three cantons. In suc¬
ceeding years, other localities joined the
original three. The Swiss Confederation
secured its independence from the Holy
Roman Empire in 1499. A constitution of
1848, subsequently modified in 1874,
replaced the confederation with a central¬
ized federal government. Switzerland’s
sovereignty and neutrality have long been
honored by the major European powers,
and the country was not involved in
either of the two World Wars. The polit¬
ical and economic integration of Europe
over the past half century, as well as
Switzerland’s role in many UN and inter¬
national organizations, has strengthened
Switzerland’s ties with its neighbors.
However, the country did not officially
become a UN member until 2002.
Switzerland remains active in many UN
and international organizations but
retains a strong commitment to neutrality.
Location: Central Europe, east of France,
north of Italy
Geographic coordinates: 47 00 N, 8 00
E
Map references: Europe
Area:
total: 41,290 sq km
land: 39,770 sq km
water: 1,520 sq km
Area comparative: slightly less than
twice the size of New Jersey
624
Disputes — international: none
Illicit drugs: a major international finan¬
cial center vulnerable to the layering and
integration stages of money laundering;
despite significant legislation and
reporting requirements, secrecy rules per¬
sist and nonresidents are permitted to
conduct business through offshore enti¬
ties and various intermediaries; transit
country for and consumer of South
American cocaine, Southwest Asian
heroin, and Western European syn¬
thetics; domestic cannabis cultivation
and limited ecstasy production
627
Ai Masakah''
(Ar Raqqafi
AJeppo
Tadmur
Hsms
S .DAMASCUS
jg *
*TUovrsf Hwrmn
*$M Ounay^irah
As Suwayda1 /
_
Disputes — international: Golan
Heights is Israeli-occupied with the
almost 1, 000-strong UN Disengagement
Observer Force (UNDOF) patrolling a
buffer zone since 1964; lacking a treaty
or other documentation describing the
boundary, portions of the Lebanon-Syria
boundary are unclear with several sec¬
tions in dispute; since 2000, Lebanon has
claimed Shaba’a farms in the Golan
Heights; 2004 Agreement and pending
demarcation settles border dispute with
Jordan; approximately two million Iraqis
have fled the conflict in Iraq with the
majority taking refuge in Syria and
sz
CH
CHE
756
CHE
.ch
Syria
SY
SY
SYR
760
SYR
•sy
Taiwan
TW
TW
TWN
158
TWN
.tw
46 57 N
7 26 E
Moldova, Romania, Ukraine
47 00 N
28 30 E
47 00 N
8 00 E
i Republic of the Congo
1 00 S
15 00 E
Democratic Republic
0 00 N
25 00 E
of the Congo
Turkey
41 01 N
28 58 E
Pacific Ocean
41 15 S
174 30 E
46 12 N
6 10 E
47 00 N
8 00 E
Israel, West Bank
31 48 N
35 14 E
Atlantic Ocean, Southern Ocean 56 00 S
40 00 W
47 00 N
8 00 E
47 00 N
8 00 E
47 23 N
8 32 E
Yugoslavia, Socialist Federal Republic of
(former name for a Balkan federation)
Zagreb (capital)
Zaire (former name for the Democratic
Republic of the Congo)
Zakhalinskiy Zaliv (bay)
Zaiiv Shelikhova (bay)
Zambezia (region)
Zanzibar (island)
Zhong Guo, Zhonghua (local name for China)
Zion, Mount (locale in Jerusalem)
Zurich (city)
808
APPENDIX G
■
WEIGHTS
» AND MEASURES
Note: At this time, only three countries — Burma, Liberia, and the US — have not adopted the International System of Units (SI,
or metric system) as their official system of weights and measures. Although use of the metric system has been sanctioned by law
in the US since 1866, it has been slow in displacing the American adaptation of the British Imperial System known as the US
Customary System. The US is the only industrialized nation that does not mainly use the metric system in its commercial and
standards activities, but there is increasing acceptance in science, medicine, government, and many sectors of industry.
Mathematical Notation
Mathematical Power
1018 or 1,000,000,000,000,000,000
1015 or 1,000,000,000,000,000
1012 or 1,000,000,000,000
109 or 1,000,000,000
106 or 1,000,000
103 or 1,000
102 or 100
101 or 10
10° or 1
101 or 0.1
10''2 or 0.01
lO''3 or 0.001
10''6 or 0.000 001
10''9 or 0.000 000 001
10''12 or 0.000 000 000 001
10''15 or 0.000 000 000 000 001
10''18 or 0.000 000 000 000 000 001
Name
one quintillion
one quadrillion
one trillion
one billion
one million
one thousand
one hundred
ten
one
one-tenth
one -hundredth
one -thousandth
one-millionth
one-billionth
one-trillionth
one-quadrillionth
one-quintillionth
Metric Interrelationships
Prefix
Symbol
Length, weight, or capacity
yotta
Y
1024
zetta
Z
1021
exa
E
1018
peta
P
1015
tera
T
1012
giga
G
109
mega
M
106
kilo
k
103
hecto
h
102
deka
da
10‘
basic unit
-
1 meter, 1 gram, 1 liter
deci
d
10''1
centi
c
10''2
milli
m
10-3
micro
u
10-6
nano
n
10-9
pico
P
10-12
femto
f
10''15
atto
a
10-18
zepto
z
10-21
yocto
y
10-24
Conversion Factors
To Convert From
TO
Multiply By
acres
ares
40.468 564 224
acres
hectares
0.404 685 642 24
acres
square feet
43,560
acres
square kilometers
0.004 046 856 422 4
acres
square meters
4,046.856 422 4
acres
square miles (statute)
0.001 562 50
acres
square yards
4,840
ares
square meters
100
ares
square yards
119.599
barrels, US beer
gallons
31
barrels, US beer
liters
117.347 77
barrels, US petroleum
gallons (British)
34.97
809
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From
barrels, US petroleum
barrels, US petroleum
barrels, US proof spirits
barrels, US proof spirits
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
cables
cables
cables
carat
centimeters
centimeters
centimeters
centimeters
centimeters, cubic
centimeters, square
centimeters, square
centimeters, square
centimeters, square
chains, square surveyor’s
chains, square surveyor’s
chains, surveyor’s
chains, surveyor’s
chains, surveyor’s
cords of wood
cords of wood
cords of wood
cups
cups
degrees Celsius
degrees Fahrenheit
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
drams, avoirdupois
drams, avoirdupois
drams, avoirdupois
drams, troy
drams, troy
drams, troy
drams, troy
drams, liquid (US)
drams, liquid (US)
drams, liquid (US)
drams, liquid (US)
drams, liquid (US)
fathoms
fathoms
feet
feet
feet
feet
feet
feet
To
gallons (US)
liters
gallons
liters
bushels (British)
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
liters
pecks
fathoms
meters
yards
milligrams
feet
inches
meters
yards
cubic inches
square feet
square inches
square meters
square yards
ares
square feet
feet
meters
rods
cubic feet
cubic meters
cubic yards
liquid ounces (US)
liters
degrees Fahrenheit
degrees Celsius
bushels
cubic feet
cubic inches
dry pints
dry quarts
liters
pecks
avoirdupois ounces
grains
grams
grains
grams
scruples
troy ounces
cubic inches
liquid drams (British)
liquid ounces
milliliters
minims
feet
meters
centimeters
inches
kilometers
meters
statute miles
yards
Multiply By
42
158.987 29
40
151.416 47
0.968 9
1.244 456
2,150.42
0.035 239 07
0.046 090 96
3.523 907
64
32
35.239 070 17
4
120
219.456
240
200
0.032 808 40
0.393 700 8
0.01
0.010 936 13
0.061 023 744
0.001 076 39
0.155 000 31
0.000 1
0.000 119 599
4.046 86
4,356
66
20.116 8
4
128
3.624 556
4.740 7
8
0.236 588 2
multiply by 1.8 and add 32
subtract 32 and divide by 1.8
0.283 775 9
0.353 146 7
610.237 4
18.161 66
9.080 829 8
10
1.135 104
0.062 55
27.344
1.771 845 2
60
3.887 934 6
3
0.125
0.226
1.041
0.125
3.696 69
60
6
1.828 8
30.48
12
0.000 304 8
0.304 8
0.000 189 39
0.333 333 3
810
WEIGHTS AND MEASURES
Conversion Factors
To Convert From
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, square
feet, square
feet, square
feet, square
feet, square
feet, square
furlongs
furlongs
furlongs
furlongs
furlongs
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
grains
grains
grains
grains
grains
grains
grains
grains
grains
grains
grains
grams
grams
grams
grams
grams
grams
grams
To
bushels
cubic decimeters
cubic inches
cubic meters
cubic yards
dry pints
dry quarts
gallons
gills
liquid ounces
liquid pints
liquid quarts
liters
pecks
acres
square centimeters
square decimeters
square inches
square meters
square yards
feet
inches
meters
statute miles
yards
cubic feet
cubic inches
cubic meters
cubic yards
gills (US)
liquid gallons (British)
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims
centiliters
cubic feet
cubic inches
gallons
gills (British)
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grams
kilograms
milligrams
pennyweights
scruples
troy drams
troy ounces
troy pounds
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
kilograms
milligrams
troy ounces
Multiply By
0.803 563 95
28.316 847
I, 728
0.028 316 846 592
0.037 037 04
51.428 09
25.714 05
7.480 519
239.376 6
957.506 5
59.844 16
29.922 08
28.316 846 592
3.214 256
0.000 022 956 8
929.030 4
9.290 304
144
0.092 903 04
0.111 111 1
660
7.920
201.168
0.125
220
0.133 680 6
231
0.003 785 411 784
0.004 951 13
32
0.832 67
128
8
4
3.785 411 784
3,785.411 784
61,440
II. 829 4
0.004 177 517
7.218 75
0.031 25
0.832 67
4
0.25
0.125
0.118 294 118 25
118.294 118 25
1.920
0.036 571 43
0.002 285 71
0.000 142 86
0.064 798 91
0.000 064 798 91
64.798 910
0.042
0.05
0.016 6
0.002 083 33
0.000 173 61
0.564 383 39
0.035 273 961
0.002 204 622 6
15.432 361
0.001
1,000
0.032 150 746 6
811
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From
grams
hands (height of horse)
hands (height of horse)
hectares
hectares
hectares
hectares
hectares
hectares
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, short
hundredweights, short
hundredweights, short
hundredweights, short
hundredweights, short
inches
inches
inches
inches
inches
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, square
inches, square
inches, square
inches, square
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilometers
kilometers
kilometers, square
kilometers, square
kilometers, square
kilometers, square
knots (nautical mi/hr)
knots (nautical mi/hr)
leagues, nautical
leagues, nautical
leagues, statute
To
troy pounds
centimeters
inches
acres
square feet
square kilometers
square meters
square miles
square yards
avoirdupois pounds
kilograms
long tons
metric tons
short tons
avoirdupois pounds
kilograms
long tons
metric tons
short tons
centimeters
feet
meters
millimeters
yards
bushels
cubic centimeters
cubic feet
cubic meters
cubic yards
dry pints
dry quarts
gallons
gills
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims (US)
pecks
square centimeters
square feet
square meters
square yards
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
grams
long tons
metric tons
short hundredweight:
short tons
troy ounces
troy pounds
meters
statute miles
acres
hectares
square meters
statute miles
kilometers/hour
statute miles/hour
kilometers
nautical miles
kilometers
Multiply By
0.002 679 23
10.16
4
2.471 053 8
107,639.1
0.01
10,000
0.003 861 02
11,959.90
112
50.802 345
0.05
0.050 802 345
0.056
100
45.359 237
0.044 642 86
0.045 359 237
0.05
2.54
0.083 333 33
0.025 4
25.4
0.027 777 78
0.000 465 025
16.387 064
0.000 578 703 7
0.000 016 387 064
0.000 021 433 47
0.029 761 6
0.014 880 8
0.004 329 0
0.138 528 1
0.554 112 6
0.034 632 03
0.017 316 02
0.016 387 064
16.387 064
265.974 0
0.001 860 10
6.451 600
0.006 944 44
0.000 645 16
0.000 771 605
564.383 4
35.273 962
2.204 622 622
15,432.36
1,000
0.000 984 2
0.001
0.022 046 23
0.001 102 31
32.150 75
2.679 229
1,000
0.621 371 192
247.105 38
100
1,000,000
0.386 102 16
1.852
1.151
5.556
3
4.828 032
812
Conversion Factors
To Convert From
leagues, statute
links, square surveyor’s
links, square surveyor’s
links, surveyor’s
links, surveyor’s
links, surveyor’s
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
meters
meters
meters
meters
meters
meters
meters
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, square
meters, square
meters, square
meters, square
meters, square
meters, square
microns
microns
mils
mils
miles, nautical
miles, nautical
miles, statute centimeters 160,934.4
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, square nautical
miles, square nautical
miles, square statute
miles, square statute
miles, square statute
miles, square statute
miles, square statute
miles, square statute
milligrams
milliliters
milliliters
WEIGHTS AND MEASURES
To
statute miles
square centimeters
square inches
centimeters
chains
inches
bushels
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
gallons
gills (US)
liquid ounces
liquid pints
liquid quarts
milliliters
pecks
centimeters
feet
inches
kilometers
millimeters
statute miles
yards
bushels
cubic feet
cubic inches
cubic yards
gallons
liters
pecks
acres
hectares
square centimeters
square feet
square inches
square yards
meters
inches
inches
millimeters
kilometers
statute miles
feet
furlongs
inches
kilometers
meters
rods
yards
square kilometers
square statute miles
acres
hectares
sections
square kilometers
square nautical miles
square rods
grains
cubic inches
gallons
Multiply By
3
404.686
62.726 4
20.116 8
0.01
7.92
0.028 377 59
0.035 314 67
61.023 74
0.001
0.001 307 95
0.1
1.816 166
0.908 082 98
0.264 172 052
8.453 506
33.814 02
2.113 376
1.056 688 2
1,000
0.113 5104
100
3.280 839 895
39.370 079
0.001
1,000
0.000 621 371
1.093 613 298
28.377 59
35.314 666 7
61,023.744
1.307 950 619
264.172 05
1,000
113.510 4
0.000 247 105 38
0.000 1
10,000
10.763 910 4
1,550.003 1
1.195 990 046
0.000 001
0.000 039 4
0.001
0.025 4
1.852 0
1.150 779 4
5.280
8
63,360
1.609 344
1,609.344
320
1,760
3.429 904
1.325
640
258.998 811 033 6
1
2.589 988 110 336
0.755 miles
102,400
0.015 432 358 35
0.061 023 744
0.000 264 17
813
THE CIA WORLD FACTBOOK
To Convert From
To
Multiply By
milliliters
gills (US)
0.008 453 5
milliliters
liquid ounces
0.033 814 02
milliliters
liquid pints
0.002 113 4
milliliters
liquid quarts
0.001 056 7
milliliters
liters
0.001
milliliters
minims
16.230 73
millimeters inches 0.039 370 078 7
minims (US)
cubic inches
0.003 759 77
minims (US)
gills (US)
0.000 520 83
minims (US)
liquid ounces
0.002 083 33
minims (US)
milliliters
0.061 611 52
minims (US)
minims (British)
1.041
ounces, avoirdupois
avoirdupois drams
16
ounces, avoirdupois
avoirdupois pounds
0.062 5
ounces, avoirdupois
grains
437.5
ounces, avoirdupois
grams
28.349 523 125
ounces, avoirdupois
kilograms
0.028 349 523 125
ounces, avoirdupois
troy ounces
0.911 458 3
ounces, avoirdupois
troy pounds
0.075 954 86
ounces, liquid (US)
cubic feet
0.001 044 38
ounces, liquid (US)
centiliters
2.957 35
ounces, liquid (US)
cubic inches
1.804 687 5
ounces, liquid (US)
gallons
0.007 812 5
ounces, liquid (US)
gills (US)
0.25
ounces, liquid (US)
liquid drams
8
ounces, liquid (US)
liquid ounces (British)
1.041
ounces, liquid (US)
liquid pints
0.062 5
ounces, liquid (US)
liquid quarts
0.031 25
ounces, liquid (US)
liters
0.029 573 53
ounces, liquid (US)
milliliters
29.573 529 6
ounces, liquid (US)
minims
480
ounces, troy
avoirdupois drams
17.554 29
ounces, troy
avoirdupois ounces
1.097 143
ounces, troy
avoirdupois pounds
0.068 571 43
ounces, troy
grains
480
ounces, troy
grams
31.103 476 8
ounces, troy
pennyweights
20
ounces, troy
troy drams
8
ounces, troy
troy pounds
0.083 333 3
paces (US)
centimeters
76.2
paces (US)
inches
30
pecks (US)
bushels
0.25
pecks (US)
cubic feet
0.311 114
pecks (US)
cubic inches
537.605
pecks (US)
cubic meters
0.008 809 77
pecks (US)
cubic yards
0.011 522 74
pecks (US)
dekaliters
0.880 976 75
pecks (US)
dry pints
16
pecks (US)
dry quarts
8
pecks (US)
liters
8.809 767 5
pecks (US)
pecks (British)
0.968 9
pennyweights
grains
24
pennyweights
grams
1.555 173 84
pennyweights
troy ounces
0.05
pints, dry (US)
bushels
0.015 625
pints, dry (US)
cubic feet
0.019 444 63
pints, dry (US)
cubic inches
33.600 312 5
pints, dry (US)
dekaliters
0.055 061 05
pints, dry (US)
dry pints (British)
0.968 9
pints, dry (US)
dry quarts
0.5
pints, dry (US)
liters
0.550 610 47
pints, liquid (US)
cubic feet
0.016 710 07
pints, liquid (US)
cubic inches
28.875
pints, liquid (US)
deciliters
4.731 76
pints, liquid (US)
gallons
0.125
pints, liquid (US)
gills (US)
4
814
WEIGHTS AND MEASURES
Conversion Factors
To Convert From
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
points (typographical)
points (typographical)
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quintals
quintals
quintals
rods
rods
rods
rods, square
rods, square
rods, square
scruples
scruples
scruples
sections (US)
sections (US)
spans
spans
steres
steres
tablespoons
To
liquid ounces
liquid pints (British)
liquid quarts
liters
milliliters
minims
inches
millimeters
avoirdupois drams
avoirdupois ounces
grains
grams
kilograms
long tons
metric tons
quintals
short tons
troy ounces
troy pounds
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
grams
kilograms
pennyweights
troy ounces
bushels
cubic feet
cubic inches
dekaliters
dry pints
dry quarts (British)
liters
pecks
pints, dry (US)
cubic feet
cubic inches
deciliters
gallons
gills (US)
liquid ounces
liquid pints (US)
liquid quarts (British)
liters
milliliters
minims
avoirdupois pounds
kilograms
metric tons
feet
meters
yards
acres
square meters
square yards
grains
grams
troy drams
square kilometers
square statute miles
centimeters
inches
cubic meters
cubic yards
milliliters
Multiply By
16
0.832 67
0.5
0.473 176 473
473.176 473
7,680
0.013 837
0.351 459 8
256
16
7,000
453.592 37
0.453 592 37
0.000 446 428 6
0.000 453 592 37
0.004 535 92
0.000 5
14.583 33
1.215 278
210.651 4
13.165 71
0.822 857 1
5,760
373.241 721 6
0.373 241 721 6
240
12
0.031 25
0.038 889 25
67.200 625
0.110 122 1
2
0.968 9
1.101 221
0.125
2
0.033 420 14
57.75
9.463 53
0.25
8
32
2
0.832 67
0.946 352 946
946.352 946
15,360
220.462 26
100
0.1
16.5
5.029 2
5.5
0.006 25
25.292 85
30.25
20
1.295 978 2
0.333
2.589 988 1
1
22.86
9
1
1.307 95
14.786 76
815
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From
TO
Multiply By
tablespoons
teaspoons
3
teaspoons
milliliters
4.928 922
teaspoons
tablespoons
0.333 333
ton-miles, long
metric ton-kilometers
1.635 169
ton-miles, short
metric ton-kilometers
1.459 972
tons, gross register
cubic feet of permanently enclosed space
100
tons, gross register
cubic meters of permanently enclosed space
2.831 684 7
tons, long (deadweight)
avoirdupois ounces
35,840
tons, long (deadweight)
avoirdupois pounds
2,240
tons, long (deadweight)
kilograms
1,016.046 909 8
tons, long (deadweight)
long hundredweights
20
tons, long (deadweight)
metric tons
1.016 046 908 8
tons, long (deadweight)
short hundredweights
22.4
tons, long (deadweight)
short tons
1.12
tons, metric
avoirdupois pounds
2,204.623
tons, metric
kilograms
1,000
tons, metric
long hundredweights
19.684 130 3
tons, metric
long tons
0.984 206 5
tons, metric
quintals
10
tons, metric
short hundredweights
22.046 23
tons, metric
short tons
1.102 311 3
tons, metric
troy ounces
32,150.75
tons, net register
cubic feet of permanently enclosed space
for cargo and passengers
100
tons, net register
cubic meters of permanently enclosed space
tons, shipping
for cargo and passengers
2.831 684 7
cubic feet of permanently enclosed
tons, shipping
cargo space
42
cubic meters of permanently enclosed
tons, short
cargo space
1.189 307 574
avoirdupois pounds
2,000
tons, short
kilograms
907.184 74
tons, short
long hundredweights
17.857 14
tons, short
long tons
0.892 857 1
tons, short
metric tons
0.907 184 74
tons, short
short hundredweights
20
townships (US)
sections
36
townships (US)
square kilometers
93.239 572
townships (US)
square statute miles
36
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
square feet
27,878,400
miles, square statute
square meters
2,589,988.110 336
miles, square statute
square yards
3,097,600
yards
centimeters
91.44
yards
feet
3
yards
inches
36
yards
meters
0.914 4
yards
miles
0.000 568 18
yards, cubic
bushels
21.696 227
yards, cubic
cubic feet
27
yards, cubic
cubic inches
46,656
yards, cubic
cubic meters
0.764 554 857 984
yards, cubic
gallons
201.974 0
yards, cubic
liters
764.554 857 984
yards, cubic
pecks
86.784 91
yards, square
acres
0.000 206 611 6
yards, square
hectares
0.000 083 612 736
yards, square
square centimeters
8,361.273 6
yards, square
square feet
9
yards, square
square inches
1,296
yards, square
square meters
0.836 127 36
yards, square
square miles
0.000 000 322 830
816
REFERENCE MAPS
AFRICA
■Minsk
*? 8crB\\l Warsaw*
’ GERMANY .j, POLAND
tUf Prague* jA''K''t''','d4dcef547ff8ab971a3b5248402c1f9fb3587d18d4be2c7bdb09e9e01c299e0f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3387b17065864a6d7786e0f16418b54dace9c791965c9ceb9c2146522bd01910',2009,'TJ','Tajikistan','transnational-issues',1184,'Disputes— international: in 2006,
China and Tajikistan pledged to com¬
mence demarcation of the revised
boundary agreed to in the delimitation of
2002; talks continue with Uzbekistan to
delimit border and remove minefields;
disputes in Isfara Valley delay delimita¬
tion with Kyrgyzstan
Illicit drugs: major transit country for
Afghan narcotics bound for Russian and,
to a lesser extent, Western European
markets; limited illicit cultivation of
opium poppy for domestic consumption;
Tajikistan seizes roughly 80% of all drugs
captured in Central Asia and stands
third worldwide in seizures of opiates
(heroin and raw opium); significant con¬
sumer of opiates
634
Background: Shortly after achieving
independence from Britain in the early
1960s, Tanganyika and Zanzibar merged
to form the nation of Tanzania in 1 964.
One-party rule came to an end in 1995
with the first democratic elections held
in the country since the 1970s. Zanzibar’s
semi-autonomous status and popular
opposition have led to two contentious
elections since 1995, which the ruling
party won despite international
observers’ claims of voting irregularities.
TI
TJ
TJK
762
TJK
•tj
Tanzania
TZ
TZ
TZA
834
TZA
.tz
38 35 N
68 48 E
Netherlands Antilles
12 10N
68 30 W
39 00 N
71 00 E','4c992c0a608702e80ea73e684df5b5258e9ec71453bca4f93972478958481d26','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ceb6206e596201a458070eb4683bac6b8747791e9b4091de26ff46e338afd88',2009,'TL','Timor-Leste','transnational-issues',1192,'Disputes — international: separatist vio¬
lence in Thailand’s predominantly
Muslim southern provinces prompt
border closures and controls with
Malaysia to stem terrorist activities;
Southeast Asian states have enhanced
border surveillance to check the spread
of avian flu; talks continue on comple¬
tion of demarcation with Laos but dis¬
putes remain over several islands in the
Mekong River; despite continuing
border committee talks, Thailand must
deal with Karen and other ethnic rebels,
refugees, and illegal cross-border activi¬
ties, and as of 2006, over 116,000 Karen,
Hmong, and other refugees and asylum
seekers from Burma; Cambodia and
Thailand dispute sections of historic
boundary with missing boundary
markers; Cambodia claims Thai
encroachments into Cambodian terri¬
tory and obstructing access to Preah
Vihear temple ruins awarded to
Cambodia by ICJ decision in 1962;
Thailand is studying the feasibility of
jointly constructing the Hatgyi Dam on
the Salween river near the border with
Burma; in 2004, international environ¬
mentalist pressure prompted China to
halt construction of 13 dams on the
Salween River that flows through China,
Burma, and Thailand
Refugees and internally displaced per¬
sons: refugees (country of origin): 132,241
(Burma) (2007)
Illicit drugs: a minor producer of opium,
heroin, and marijuana; transit point for
illicit heroin en route to the interna¬
tional drug market from Burma and Laos;
eradication efforts have reduced the area
of cannabis cultivation and shifted some
production to neighboring countries;
opium poppy cultivation has been
reduced by eradication efforts; also a drug
money-laundering center; minor role in
methamphetamine production for
regional consumption; major consumer
of methamphetamine since the 1990s
despite a series of government crack¬
downs
TT
TL
TLS
626
TLS
.tl
8 35 S
125 36 E
9 00 S
126 00 E
9 00 N
126 00 E
Pacific Ocean
11 00 S
128 00 E','48431d3d216ab6b050805568d8c874a5cc8bbf6b3c748e2568f5900926b32f41','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8281e166866c27047fd1302a6cb5da05cec7bac13337e39574c87c1da481f235',2009,'ID','Indonesia','transnational-issues',1197,'Disputes— international: Timor-Leste-
Indonesia Boundary Committee has
resolved all but a small portion of the
land boundary, but discussions on mar¬
itime boundaries are stalemated over
sovereignty of the uninhabited coral
island of Pulau Batek/Fatu Sinai in the
north and alignment with Australian
claims in the south; many refugees who
left Timor-Leste in 2003 still reside in
Indonesia and refuse repatriation;
Australia and Timor-Leste agreed in
2005 to defer the disputed portion of the
boundary for 50 years and to split hydro¬
carbon revenues evenly outside the Joint
Petroleum Development Area covered
by the 2002 Timor Sea Treaty
Refugees and internally displaced per¬
sons: IDPs: 100,000 (2007)
Illicit drugs: NA
Background: French Togoland became
Togo in 1960. Gen. Gnassingbe
EYADEMA, installed as military ruler in
1967, ruled Togo with a heavy hand for
almost four decades. Despite the facade
of multiparty elections instituted in the
early 1990s, the government was largely
dominated by President EYADEMA,
whose Rally of the Togolese People
(RPT) party has maintained power
almost continually since 1967 and main¬
tains a majority of seats in today’s legisla¬
ture. Upon EYADEMA’s death in
644
ID
ID
Iran
IR
IR
8 20 S
115 00 E
Indian Ocean
7 45 S
115 30 E
Pacific Ocean
19 49 N
121 40 E
786
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name _
. Balintang Islands
Balkan Peninsula
Balleny Islands
Balochistan (region)
Baltic Sea
Bamako (capital)
Banaba (Ocean Island)
Banat (region)
Banda Sea
Bandar Seri Begawan (capital)
Bangka (island)
Bangkok (capital)
Bangui (capital)
Banjul (capital)
Banks Island
Banks Island
Banks Islands (lies Banks)
Barbuda (island)
Barcelona (city)
Barents Sea
Barranquilla (city)
Bashi Channel
Basilan Strait
Basque Provinces
Bass Strait
Basse-Terre (capital)
Basseterre (capital)
Bastia (city)
Basutoland (former name for Lesotho)
Baton Islands
Bavaria (region; also Bayern)
Beagle Channel
Bear Island (see Bjornoya)
Beaufort Sea
Bechuanaland (former name for Botswana)
Beijing (capital)
Beirut (capital)
Bekaa Valley
Belau (Palau Islands)
Belep Islands (lies Belep)
Belfast (city)
Belgian Congo (former name for Democratic
Republic of the Congo)
Belgie, Belgique (local name for Belgium)
Belgrade (capital)
Belize City
Belle Isle, Strait of
Bellingshausen Sea
Belmopan (capital)
Belorussia (former name for Belarus)
Benadir (region; former name of Italian Somaliland)
Bengal, Bay of
Berau, Gulf of
Bering Island
Bering Sea
Bering Strait
Berkner Island
Berlin (capital)
Berlin, East (former name for eastern sector of Berlin)
Berlin, West (former name for western sector of Berlin)
Entry in Latitude Longitude
The World Factbook (deg min) (deg min)
2 30 S
106 00 E
2 00 S
121 00 E
Pacific Ocean
3 00 N
122 00 E
Atlantic Ocean
51 00 N
6 30 W
5 00 S
120 00 E
8 45 S
121 00 E
Pacific Ocean
7 40 S
119 45 E
Atlantic Ocean
25 00 N
79 45 W
1 00 N
128 00 E
Pacific Ocean
0 30 S
129 00 E
5 00 S
138 00 E
Atlantic Ocean
53 30 N
5 20 W
Romania, Serbia
44 41 N
22 31 E
Turkey
36 34 N
36 08 E
6 10 S
106 48 E
Arctic Ocean
54 00 N
80 00 W
Saint Helena
15 56 S
5 44 W
7 30 S
110 00 E
Pacific Ocean
5 00 S
110 00 E
Israel, West Bank
31 47 N
35 14 E
0 00 N
115 00 E
Russia
54 30 N
21 00 E
6 07 S
105 24 E
9 00 S
120 00 E
8 28 S
116 40 E
Indian Ocean
8 30 S
115 50 E
2 00 S
128 00 E
798
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Mombasa (city)
Mona Passage
Monaco (capital)
Mongol Uls (local name for Mongolia)
Monrovia (capital)
Monterrey (city)
Montevideo (capital)
Montreal (city)
Moravia (region)
Moravian Gate (pass)
Moroni (capital)
Mortlock Islands (Nomoi Islands)
Moscow (capital)
Mount Pinatubo (volcano)
Mozambique Channel
Mumbai (city; also Bombay)
Munich, Muenchen (city)
Murifaniyah (local name for Mauritania)
Musandam Peninsula
Muscat (capital)
Muscat and Oman (former name for Oman)
Myanma, Myanmar
N''Djamena (capital)
Nagorno-Karabakh (region)
Nairobi (capital)
Namib (desert)
Nampo-shoto (island group)
Nan Madol (ruins)
Naples (city)
Nassau (capital)
Natal (region)
Natuna Besar Islands
Natuna Sea
Naxcivan (region)
Naxos (island)
Nederland (local name for the Netherlands)
Nederlandse Antillen (local name for the Netherlands Antilles)
Negev (region)
Negros (island)
Nejd (region)
Netherlands East Indies (former name for Indonesia)
Netherlands Guiana (former name for Suriname)
Nevis (island)
New Britain (island)
New Delhi (capital)
New Guinea (island)
New Hebrides (island group)
New Ireland (island)
New Siberian islands
New Territories (mainland region)
Newfoundland (island, with mainland area, and a province)
Niamey (capital)
Nicobar Islands
Nicosia (capital; also Lefkosia)
Nightingale Island
Nihon, Nippon (local name for Japan)
Nomoi Islands (Mortlock Islands)
Norge (local name for Norway)
Norman Isles (Channel Islands)
North Atlantic Ocean
North Channel
North Frisian Islands
North Greenland Sea
North Island
North Ossetia (region)
North Pacific Ocean
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
3 30 N
102 30 E
Pacific Ocean
3 30 N
108 00 E
5 00 S
120 00 E
2 00 S
28 00 E
Svalbard
78 00 N
20 00 E
2 00 S
121 00 E
Pacific Ocean
3 00 N
122 00 E
0 00 N
102 00 E
10 00S
120 00 E
Pacific Ocean
9 10 S
120 00 E
8 30 S
118 00 E
Indonesia, Malaysia
2 00 S
110 00 E
Indian Ocean
6 00 S
105 45 E
7 13 S
112 45 E
Pacific Ocean
10 15 N
125 23 E','ca1676b8abc3240d5845d9c1b21e622b4bc51dc4557e1950410fac7f4401f16e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a62eb1d9de68b72ff296feeb0df00df0fdf19bd2ae8508501d07e009ebb637',2009,'TO','Tonga','transnational-issues',1205,'Disputes — international: Tokelau inclu¬
ded American Samoa’s Swains Island
(Olohega) in its 2006 draft constitution
TN
TO
TON
776
TON
.to
20 00 S
175 00 W
Denmark, Germany, Netherlands 53 35 N
6 40 E
19 42 S
174 29 W
Russia (de facto)
43 30 N
146 10 E
21 08 S
175 12 W','03f2dad2e8a4a3fab3899c1fba9b0043bc0b03c357898583af03be001393dc20','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e21b4c931f0daf5a95d4ecdcb24075b1ef9d12a44def8e2d59854ff9b14584c8',2009,'TT','Trinidad and Tobago','transnational-issues',1213,'Disputes — international: none
o w mk&
& n
Caribbean
Tobago
Scarborough
PORT-O F- il On: TO
SPAIN **»**>
Anma
*
M
Chaguanas |art9£e
w * Grande
^PO*F(1 USSS
PoMe-a-Pierre, Trinidad
Point
Fortin.
iy-o-h
\\/iw
San Fernando
.Sipana
-■''.Mm.
"D~v
M0M''.
YfLA/m
W0\\
TD
TT
TTO
780
TTO
•tt
Tromelin Island
TE
-
-
-
-
-
administered as part of
10 39 N
61 31 W
11 15 N
60 40 W
10 22 N
61 15 W','720bc0525fed26dd9e278b497537bd65dd2dd57e64ffd642c2a487de52842125','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73f79f5910bd1c6949dc2aca2dacbcd6ee010204f7d79e3e9b438f13054878ff',2009,'TN','Tunisia','transnational-issues',1224,'_ _ _
Disputes — international: none
TURKEY
TS
TN
TUN
788
TUN
.tn
French Southern and
Antarctic Lands; no ISO
codes assigned
Turkey
TU
TR
TUR
792
TUR
.tr
36 48 N
10 11 E
806
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name _
Turin (city)
Turkish Straits (see Bosporus and Dardenelies)
Turkiye (local name for Turkey)
Turkmenia, Turkmeniya (former name for Turkmenistan)
Turks Island Passage
Tuscany (region)
Tutuiia (island)
Tyrrhenian Sea
Ubangi-Shari (former name for the Central African Republic
Ukrayina (local name for Ukraine)
Ulaanbaatar (capital)
Ullung-do (island)
Ulster (region)
Uman (local name for Oman)
Unimak Pass (strait)
Union of Soviet Socialist Republics or USSR (former name
of a large Eurasian empire, roughly coequal with the
former Russian Empire)
United Arab Republic or UAR (former name for a
federation between Egypt and Syria)
Upper Volta (former name for Burkina Faso)
Ural Mountains
Urdunn (local name for Jordan)
Urundi (former name for Burundi)
Ussuri River
Vaduz (capital)
Vakhan (Wakhan Corridor)
Valletta (capital)
Valley, The (capital)
Van Diemen Strait (Osumi Strait)
Vancouver (city)
Vancouver Island
Vatican City (capital)
Velez de la Gomera, Penon de (island)
Venda (enclave)
Verde Island Passage
Victoria (capital)
Victoria (island)
Victoria Land (region)
Vienna (capital)
Vientiane (capital)
Vilnius (capital)
Viti Levu (isiand)
Vladivostok (city)
Vojvodina (region)
Volcano Islands
Vostok Island
Wake Atoll
Wakhan Corridor (see Vakhan)
Walachia (region)
Wales (region)
Wallis Islands
Walvis Bay (city; former exclave)
Warsaw (capital)
Washington, DC (capital)
Weddell Sea
Wellington (capital)
West Frisian Islands
West Germany (Federal Republic of Germany;
former name for western portion of Germany)
West Island (capital)
West Korea Strait (Western Channel)
West Pakistan (former name for present-day Pakistan)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)','1fc5109c739ab16235d147b54e34623835e18c93774407421450feb14fd244ad','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3303bb8a338d8d110b898108af11114f0f8be53a25d276e0704a4c43a420b51',2009,'TM','Turkmenistan','transnational-issues',1230,'Disputes — international: complex mar¬
itime, air, and territorial disputes with
Greece in the Aegean Sea; status of
north Cyprus question remains; Syria
and Iraq protest Turkish hydrological
projects to control upper Euphrates
waters; Turkey has expressed concern
over the status of Kurds in Iraq; border
with Armenia remains closed over
Nagorno-Karabakh
Refugees and internally displaced per¬
sons: IDPs: 1-1.2 million (fighting
1984-99 between Kurdish PKK and
Turkish military; most IDPs in south¬
eastern provinces) (2007)
Illicit drugs: key transit route for
Southwest Asian heroin to Western
Europe and, to a lesser extent, the US —
via air, land, and sea routes; major
Turkish and other international traf¬
ficking organizations operate out of
Istanbul; laboratories to convert
imported morphine base into heroin
exist in remote regions of Turkey and
near Istanbul; government maintains
strict controls over areas of legal opium
poppy cultivation and over output of
poppy straw concentrate; lax enforce¬
ment of money-laundering controls
Disputes— international: cotton mono¬
culture in Uzbekistan and Turkmenistan
creates water-sharing difficulties for Amu
Darya river states; field demarcation of
the boundaries with Kazakhstan com¬
menced in 2005, but Caspian seabed
delimitation remains stalled with
Azerbaijan, Iran, and Kazakhstan due to
Turkmenistan’s indecision over how to
allocate the sea’s waters and seabed
Refugees and internally displaced per¬
sons: refugees (country of origin): 11,173
(Tajikistan); less than 1,000
(Afghanistan) (2007)
Illicit drugs: transit country for Afghan
narcotics bound for Russian and Western
European markets; transit point for
heroin precursor chemicals bound for
TX
TM
TKM
795
TKM
.tm
Turks and Caicos
TK
TC
TCA
796
TCA
.tc
Islands
37 57 N
58 23 E
40 00 N
60 00 E
Atlantic Ocean
21 40 N
71 00 W','082efed6734b57cf05d4a8362333a73ee6d3ef7b25a439d49b1f1b7cfd95a53a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a38722a695359e25a3f8851efd2ff8e0fbdad78bfb84381cddb17e44edbda54',2009,'TC','Turks and Caicos Islands','transnational-issues',1237,'Background: The islands were part of the
UK’s Jamaican colony until 1962, when
they assumed the status of a separate
crown colony upon Jamaica’s independ¬
ence. The governor of The Bahamas
oversaw affairs from 1965 to 1973. With
Bahamian independence, the islands
received a separate governor in 1973.
Although independence was agreed
upon for 1982, the policy was reversed
and the islands remain a British overseas
territory.
Disputes— international: have received
Haitians fleeing economic and civil dis¬
order
Illicit drugs: transshipment point for
South American narcotics destined for
the US and Europe
21 56 N
71 58 W
21 28 N
71 08 W
Indian Ocean
35 00 S
130 00 E
Atlantic Ocean
55 30 N
11 00 E','55225abcd5319b2f0512de6eb3945831720459d06aca272d9edbcb148a669ab6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6b3ba24cec45b9c9c4ee6116287c31c32010754877a3d40c8683c51275f951a',2009,'TV','Tuvalu','transnational-issues',1250,'Disputes— international: none
668
Background: The colonial boundaries
created by Britain to delimit Uganda
grouped together a wide range of ethnic
groups with different political systems
and cultures. These differences pre¬
vented the establishment of a working
political community after independence
was achieved in 1962. The dictatorial
regime of Idi AMIN (1971-79) was
responsible for the deaths of some
300,000 opponents; guerrilla war and
human rights abuses under Milton
OBOTE (1980-85) claimed at least
another 100,000 lives. The rule of
Yoweri MUSEVENI since 1986 has
brought relative stability and economic
growth to Uganda. During the 1990s, the
government promulgated non-party
presidential and legislative elections.
750
INTERNATIONAL ORGANIZATIONS AND GROUPS
International Chamber of Commerce (ICC)
es tablis hed — 1919
aim — to promote free trade and private enterprise and to represent business interests at national and international levels
members — (91 national committees) Algeria, Argentina, Australia, Austria, Bahrain, Bangladesh, Belgium, Brazil, Bulgaria,
Burkina Faso, Cameroon, Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Finland, France, Georgia, Germany, Ghana, Greece, Guatemala,
Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait, Lebanon,
Lithuania, Luxembourg, Madagascar, Malaysia, Mexico, Monaco, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan,
Panama, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tunisia, Turkey, Ukraine, UAE,
UK, US, Uruguay, Venezuela; note — Peru is restructuring
International Civil Aviation Organization (ICAO)
established — 7 December 1944; effective — 4 April 1947
aim — to promote international cooperation in civil aviation; a UN specialized agency
members — (190) includes all UN member countries except Dominica, Liechtenstein, and Tuvalu (189 total); plus Cook Islands
International Civilian Support Mission in Haiti (MICAH)
established 17 December 1999 to promote respect for human rights; members included Argentina, Benin, Canada, France, India,
Mali, Niger, Senegal, Togo, Tunisia, US; closed 2001
International Committee of the Red Cross (ICRC)
established — 17 February 1863
aim — to provide humanitarian aid in wartime
members — (15-25 individuals) all Swiss nationals
International Court of Justice (ICJ) note — also known as the World Court
established — 3 February 1946 superseded Permanent Court of International Justice
aim — primary judicial organ of the UN
members _ ( 1 5 judges) elected by the UN General Assembly and Security Council to represent all principal legal systems
International Criminal Court (ICCt)
established — 11 April 2002 , ,
am— to hold all individuals and countries accountable to international laws of conduct; to specify international standards ot
conduct; to provide an important mechanism for implementing these standards; to ensure that perpetrators are brought to justice
members (countries that have ratified the treaty) — (105) Afghanistan, Albania, Andorra, Antigua and Barbuda, Argentina,
Australia, Austria, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burundi, Cambodia, Canada, Central African Republic, Chad, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Croatia, Cyprus, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Estonia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guinea, Guyana, Honduras, Hungary, Iceland,
Ireland, Italy, Japan, Jordan, Kenya, South Korea, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malawi Mali, Malta, Marshall Islands, Mauritius, Mexico, Mongolia, Montenegro, Namibia, Nauru, Netherlands, NZ, Niger,
Nigeria, Norway, Panama, Paraguay, Peru, Poland, Portugal, Romania, Saint Vincent and the Grenadines, Saint Kitts and Nevis,
Samoa, San Marino, Senegal, Serbia, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Tajikistan,
Tanzania, Timor-Leste, Trinidad and Tobago, Uganda, UK, Uruguay, Venezuela, Zambia
signatory states ( countries that have signed, but not ratified, the treaty)— ( 41) Algeria, Angola, Armenia, The Bahamas, Bahrain,
Bangladesh, Cameroon, Cape Verde, Chile, Cote d’Ivoire, Czech Republic, Egypt, Eritrea, Guinea-Bissau, Haiti, Iran, Israel,
Jamaica, Kuwait, Kyrgyzstan, Madagascar, Moldova, Monaco, Morocco, Mozambique, Oman, Philippines, Russia, Saint Lucia,
Sao Tome and Principe, Seychelles, Solomon Islands, Sudan, Syria, Thailand, Ukraine, UAE, US, Uzbekistan, Yemen,
Zimbabwe; note — Israel and US have declared they will not ratify the agreement
International Criminal Police Organization (Interpol)
established— September 1923 set up as the International Criminal Police Commission; 13 June 1956 constitution modified and
present name adopted
aim — to promote international cooperation among police authorities in fighting crime
members — (186) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba Australia,
Austria Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
751
THE CIA WORLD FACTBOOK
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus — ( 1 1 ) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Hong Kong, Macau,
Montserrat, Puerto Rico, Turks and Caicos Islands
International Development Association (IDA)
established — 26 January 1960; effective — 24 September 1960
— to provide economic loans for low-income countries; UN specialized agency and IBRD affiliate
members — (179) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Austria, Azerbaijan, Bangladesh, Barbados,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia, Morocco,
Mozambique, Nepal, Netherlands, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uzbekistan,
Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
International Energy Agency (IEA)
established — 15 November 1974
aim to promote cooperation on energy matters, especially emergency oil sharing and relations between oil consumers and oil
producers; established by the OECD
members (27) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal, Slovakia, Spain, Sweden, Switzerland,
Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies (IFRCS) note— formerly known as League of Red Cross and
Red Crescent Societies (LORCS)
established — 5 May 1919
aim to organize, coordinate, and direct international relief actions; to promote humanitarian activities; to represent and
encourage the development of National Societies; to bring help to victims of armed conflicts, refugees, and displaced people; to
reduce the vulnerability of people through development programs
members— (185 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium,
Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-
Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
observers — (2) Eritrea and Tuvalu
International Finance Corporation (IFC)
established — 25 May 1955; effective — 24 July 1956
aim to support private enterprise in international economic development; a UN specialized agency and IBRD affiliate
members— (179) includes all UN member countries except Andorra, Brunei, Cuba, North Korea, Liechtenstein, Monaco, Nauru,
Qatar, Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe, Suriname, Tuvalu
International Fund for Agricultural Development (IFAD)
established — November 1974
aim — to promote agricultural development; a UN specialized agency
752
INTERNATIONAL ORGANIZATIONS AND GROUPS
members — (164)
Category I — (23 industrialized aid contributors) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece,
Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, UK, US
Category II — (12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar,
Saudi Arabia, UAE, Venezuela
Category III — (130 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Azerbaijan,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Flerzegovina, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Fionduras, India, Israel, Jamaica, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Niue, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Serbia (suspended since 1992),
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tajikistan,
Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam, Yemen,
Zambia, Zimbabwe
International Hydrographic Organization (IHO) note — name changed from International Hydrographic Bureau on 22 September 1970
established — June 1919; effective — June 1921
aim — to train hydrographic surveyors and nautical cartographers to achieve standardization in nautical charts and electronic
chart displays; to provide advice on nautical cartography and hydrography; to develop the sciences in the field of hydrography
and techniques used for descriptive oceanograrphy
members — (80) Algeria, Argentina, Australia, Bahrain, Bangladesh, Belgium, Brazil, Burma, Canada, Chile, China (including
Hong Kong and Macau), Colombia, Democratic Republic of the Congo (suspended), Croatia, Cuba, Cyprus, Denmark,
Dominican Republic (suspended), Ecuador, Egypt, Estonia, Fiji, Finland, France, Germany, Greece, Guatemala, Iceland, India,
Indonesia, Iran, Ireland, Italy, Jamaica, Japan, North Korea, South Korea, Kuwait, Latvia, Malaysia, Mauritius, Mexico, Monaco,
Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Papua New Guinea, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saudi Arabia, Serbia, Singapore, Slovenia, South Africa, Spain, Sri Lanka, Suriname (sus¬
pended), Sweden, Syria, Thailand, Tonga, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela
International Labor Organization (ILO) ,
established— 28 June 1919 set up as part of Treaty of Versailles; 11 April 1919 became operative; 14 December 1946 affiliated
with the UN
aim — to deal with world labor issues; a UN specialized agency
members— (181) includes all UN member countries except Andorra, Bhutan, North Korea, Liechtenstein, Maldives, Federated
States of Micronesia, Monaco, Nauru, Palau, Tonga, and Tuvalu; note— includes the following dependencies; Netherlands
(Netherlands Antilles and Aruba)
International Maritime Organization (IMO) note — name changed from Intergovernmental Maritime Consultative Organization
(IMCO) on 22 May 1982
established— 6 March 1948 set up as the Inter-Governmental Maritime Consultative Organization; effective— 17 March 19D8
aim — to deal with international maritime affairs; a UN specialized agency
members— (167) includes all UN member countries except Afghanistan, Andorra, Armenia, Belarus, Bhutan, Botswana, Burkina
Faso, Burundi, Central African Republic, Chad, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Mali, Federated States of Micronesia,
Nauru, Niger, Palau, Rwanda, Tajikistan, Uganda, Uzbekistan, Zambia
associate members — (3) Faroe Islands, Hong Kong, Macau
International Monetary Fund (IMF)
established— 22 July 1944; effective— 27 December 1945
aim — to promote world monetary stability and economic development; a UN specialized agency
members — (185) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco, Nauru, Tuvalu;
note — includes the following dependencies or areas of special interest: China (Hong Kong and Macau), Netherlands
(Netherlands Antilles and Aruba)
International Mobile Satellite Organization (IMSO)
established — 15 April 1999 . ,
aim — acts as watchdog over Inmarsat (International Maritime Satellite Organization), a private company, to make sure it follows
ICAO standards and recommended practices; plays an active role in the development of international telecommunications po icies
members _ (88) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Bosnia and Herzegovina,
Brazil, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic
Denmark, Egypt, Finland, France, Gabon, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Israel, Italy,
Japan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya, Malaysia, Malta, Marshall Islands, Maurtius, Mexico,
Monaco, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden,
Switzerland, Tanzania, Thailand, Timor-Leste, Tunisia, Turkey, Ukraine, UAE, UK, US, Vietnam
753
THE CIA WORLD FACTBOOK
International Olympic Committee (IOC)
established — 23 June 1894
aim — to promote the Olympic ideals and administer the Olympic games: 2006 Winter Olympics in Turin, Italy; 2008 Summer
Olympics in Beijing, China; 2010 Winter Olympics in Vancouver, Canada; 2012 Summer Olympics in London, UK
National Olympic Committees — (204 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria, American
Samoa, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Cayman Islands, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
international Organization for Migration (I0M) note — established as Provisional Intergovernmental Committee for the
Movement of Migrants from Europe; renamed Intergovernmental Committee for European Migration (ICEM) on 15 November
1952; renamed Intergovernmental Committee for Migration (ICM) in November 1980; current name adopted 14 November
1989
established — 5 December 1951
aim — to facilitate orderly international emigration and immigration
members (122) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti,
Honduras, Hungary, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia,
Liberia, Libya, Lithuania, Luxembourg, Madagascar, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Montenegro,
Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Rwanda, Senegal, Serbia, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden,
Switzerland, Tajixistan, Tanzania, Thailand, Togo, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
observers (18) Bahrain, Bhutan, China, Cuba, Ethiopia, Guyana, Holy See, India, Indonesia, Macedonia, Mozambique,
Namibia, Papua New Guinea, Russia, San Marino, Sao Tome and Principe, Somalia, Turkmenistan
International Organization for Standardization (ISO)
established — February 1947
aim_to promote the development of international standards with a view to facilitating international exchange of goods and
services and to developing cooperation in the sphere of intellectual, scientific, technological and economic activity
members ( 105 national standards organizations) Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bu','4143a9292ba843ad231e6226c6d5f7b2c81be73b51b3d844714f1266cecd87ac','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab5e159b5c56fd6c5c3438d7950b66d3bc56f54ab905b7916604a33c6a8663e',2009,'TV','Tuvalu','transnational-issues',1251,'lgaria, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador,
Egypt, Ethiopia, Fiji, Finland, France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Lebanon, Libya, Lithuania, Luxembourg,
Macedonia, Malaysia, Malta, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan,
Panama, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Lucia, Saudi Arabia, Serbia, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia,
Turkey, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Zimbabwe
correspondent members— ( 41 plus the Palestine Liberation Organization) Afghanistan, Albania, Angola, Benin, Bhutan, Bolivia,
Brunei, Burkina Faso, Burma, Cameroon, Dominican Republic, El Salvador, Eritrea, Estonia, Gabon, Georgia, Guatemala, Hong
ong, Kyrgyzstan, Latvia, Macau, Madagascar, Malawi, Moldova, Montenegro, Mozambique, Namibia, Nepal, Nicaragua, Papua
New Guinea, Paraguay, Rwanda, Senegal, Seychelles, Swaziland, Tajikistan, Togo, Turkmenistan, Uganda, Yemen, Zambia,
Palestine Liberation Organization
subscriber members (10) Antigua and Barbuda, Burundi, Cambodia, Dominica, Guyana, Honduras, Laos, Lesotho, Saint
Vincent and the Grenadines, Suriname
754
NTERNATIONAL ORGANIZATIONS AND GROUPS
International Organization Of the French-speaking World (OIF) note — name changed from Agency of Cultural and Technical
Cooperation (ACCT) in 1997; also known as Organisation Internationale de la Francophonie
established — 20 March 1970
aim — founded around a common language to promote and spread the cultures of its members and to reinforce cultural and tech-
nical cooperation between them
members — (55) Albania, Andorra, Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Canada
New Brunswick, Canada — Quebec, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of Congo,
Republic of Congo, Cote d’Ivoire, Cyprus, Djibouti, Dominica, Egypt, Equatorial Guinea, France, French Community of
Belgium, Gabon, Ghana, Greece, Guinea, Guinea-Bissau, Haiti, Laos, Lebanon, Luxembourg, Macedonia, Madagascar, Mali,
Mauritania, Mauritius, Moldova, Monaco, Morocco, Niger, Romania, Rwanda, Saint Lucia, Sao Tome and Principe, Senegal,
Seychelles, Switzerland, Togo, Tunisia, Vanuatu, Vietnam
observers — (13) Armenia, Austria, Croatia, Czech Republic, Georgia, Hungary, Lithuania, Mozambique, Poland, Serbia,
Slovakia, Slovenia, Ukraine
International Red Cross and Red Crescent Movement (ICRM)
established — 1928
aim — to promote worldwide humanitarian aid through the International Committee of the Red Cross (ICRC) in wartime, and
International Federation of Red Cross and Red Crescent Societies (IFRCS; formerly League of Red Cross and Red Crescent
Societies or LORCS) in peacetime
National Societies — (185 countries and the Palestine Liberation Organization); note same as membership for International
Federation of Red Cross and Red Crescent Societies (IFRCS)
International Telecommunications Satellites Organization (ITSO)
established — August 1964
aim — to act as a watchdog over Intelsat, Ltd., a private company, to make sure it provides on a global and non-discriminatory
basis public telecommunication services
members — (148) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan,
Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, the
Federated States of Micronesia, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saudi Arabia, Senegal, Serbia, Singapore, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Telecommunication Union (ITU)
established — 17 May 1865 set up as the International Telegraph Union; 9 December 1932 adopted present name; effective 1
January 1934; affiliated with the UN — 15 November 1947
aim — to deal with world telecommunications issues; a UN specialized agency
members — (191) includes all UN member countries except Palau, Timor-Leste (190 total); plus Holy See
International Trade Union Confederation (ITUC) note — its predecessors were the Confederation of Free Trade Unions (ICFTU)
and the World Confederation of Labor (WCL)
established — 3 November 2006
aim — to promote the trade union movement
members — (311 affiliated organizations in the following 154 countries and the Palestine Liberation Organization as of December
2007) Albania, Algeria, Angola, Antigua and Barbuda, Aruba, Argentina, Australia, Austria, Azerbaijan, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bonaire, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burundi, Cameroon, Canada, Cape Verde, Central African Republic, Comoros, Chad, Chile, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Curacao, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
French Polynesia, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau
Guyana, Haiti, Holy See, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Japan, Jordan, Kenya,
Kiribati, South Korea, Kosovo, Kuwait, Latvia, Liberia, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Mali, Malta, Mauritania, Mauritius, Mexico, Mongolia, Montenegro, Morocco, Mozambique, Nepal, Netherlands, New
Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto
Rico, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden,
Switzerland, Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US,
Vanuatu, Venezuela, Yemen, Zambia, Zimbabwe, and the Palestine Liberation Organization
755
THE CIA WORLD FACTBOOK
Islamic Development Bank (IDB)
established — 15 December 1973 by declaration of intent; effective — 12 August 1974
aim — to promote Islamic economic aid and social development
members — (55 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain, Bangladesh,
Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Cote d’Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-
Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania,
Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname,
Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
Latin American Economic System (LAES) note — also known as Sistema Economico Latinoamericana (SELA)
established — 17 October 1975
aim — to promote economic and social development through regional cooperation
members — (26) Argentina, the Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican
Republic, Ecuador, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Suriname,
Trinidad and Tobago, Uruguay, Venezuela
Latin American integration Association (LAIA) note — also known as Asociacion Latinoamericana de Integracion (ALADI)
established — 12 August 1980; effective — 18 March 1981
aim — to promote freer regional trade
members — (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers — (26) China, Corporacion Andina de Fomento, Costa Rica, Dominican Republic, EC, El Salvador, Guatemala,
Honduras, Inter- American Development Bank, Inter- American Institute for Cooperation on Agriculture, Italy, Japan, South
Korea, Latin America Economic System, Nicaragua, Organization of American States, Panama, Pan-American Health
Organization, Portugal, Romania, Russia, Spain, Switzerland, Ukraine, United Nations Development Program, United Nations
Economic Commission for Latin America and the Caribbean
League of Arab States (LAS) note — also known as Arab League (AL)
established — 22 March 1945
aim — aim — to promote economic, social, political, and military cooperation
members — (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
observers — (3) Eritrea, India, Venezuela
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as having no sig¬
nificant economic growth, per capita GDPs normally less than $1,000, and low literacy rates; also known as the undeveloped
countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana, Burkina Faso, Burma, Burundi, Cape Verde,
Central African Republic, Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau,
Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali, Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, Sao Tome and
Principe, Sierra Leone, Somalia, Sudan, Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed counfries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less
developed countries (LDCs); mainly countries and dependent areas with low levels of output, living standards, and technology;
per capita GDPs are generally below $5,000 and often less than $1,500; however, the group also includes a number of countries
with high per capita incomes, areas of advanced technology, and rapid rates of growth; includes the advanced developing coun¬
tries, developing countries, Four Dragons (Four Tigers), least developed countries (LLDCs), low-income countries, middle-
income countries, newly industrializing economies (NIEs), the South, Third World, underdeveloped countries, undeveloped
countries; the 172 LDCs are: Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina,
Aruba, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands,
Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Cayman Islands, Central African Republic, Chad,
Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Costa Rica, Cote d I voire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana, French Polynesia, Gabon, The Gambia, Gaza Strip,
Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Isle of Man, Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands,
Martinique, Mauritania, Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern
Mariana Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto Rico,
Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands,
Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga, Trinidad and
Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis
and Futuna, West Bank, Western Sahara, Yemen, Zambia, Zimbabwe; note — similar to the new International Monetary Fund
(IMF) term developing countries which adds Malta, Mexico, South Africa, and Turkey but omits in its recently published sta-
756
INTERNATIONAL ORGANIZATIONS AND GROUPS
tistics American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands,
Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue,
Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and
Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
iow-income countries
another term for those less developed countries with below-average per capita GDPs; see less developed countries (LDCs)
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries (LDCs)
Multilateral Investment Guarantee Agency (MIGA)
established. — 12 April 1988
aivn — encourages flow of foreign direct investment among member countries by offering investment insurance, consultation, and
negotiation on conditions for foreign investment and technical assistance; a UN specialized agency
members — (171) includes all UN member countries except Andorra, Bhutan, Brunei, Burma, Comoros, Cuba, Iraq, Kiribati,
North Korea, Liechtenstein, Marshall Islands, Mexico, Monaco, Nauru, NZ, Niger, San Marino, Sao Tome and Principe,
Somalia, Tonga, Tuvalu
Near Abroad
Russian term for the 14 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in which
Moscow has expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
new independent states (NIS)
a term referring to all the countries of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their economies,
formerly known as the newly industrializing countries (NICs); also known as advanced developing countries; usually includes the
Four Dragons (Hong Kong, South Korea, Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM)
established — 1-6 September 1961
aim — to establish political and military cooperation apart from the traditional East or West blocs
members — (117 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Mauritania, Mauritius, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Timor-Leste, Togo, Trinidad and
Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine
Liberation Organization . .
observers — (15) Armenia, Azerbaijan, Bosnia and Herzegovina, Brazil, China, Costa Rica, Croatia, El Salvadore, Kazakhstan,
Kyrgyzstan, Mexico, Paraguay, Serbia, Ukraine, Uruguay
guests — (24) Australia, Austria, Bulgaria, Canada, Cyprus, Czech Republic, Finland, Germany, Greece, Holy See, Hungary, ta y,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland
Nordic Council (NC)
established— 16 March 1952; effective— 12 February 1953
aim — to promote regional economic, cultural, and environmental cooperation
members — (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland, Norway, Sweden
observers— (3) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
established — 4 December 1975; effective — 1 June 1976
aim — to promote economic cooperation and development
members — (8) Denmark (including Faroe Islands and Greenland), Estonia, Finland (including Aland Islands), Iceland, Latvia,
Lithuania, Norway, Sweden
a popular term for the rich industrialized countries generally located in the northern portion of the Northern Hemisphere; the
counterpart of the South; see developed countries (DCs)
757
THE CIA WORLD FACTBOOK
North American Free Trade Agreement (NAFTA)
established — 17 December 1992
aim — to eliminate trade barriers, promote fair competition, increase investment opportunities, provide protection of intellectual
property rights, and create procedures to settle disputes
members — (3) Canada, Mexico, US
North Atlantic Treaty Organization (NATO)
established — 4 April 1949
aim — to promote mutual defense and cooperation
members — (26) Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, France, Germany, Greece, Hungary, Iceland,
Italy, Latvia, Lithuania, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA) note — also known as OECD Nuclear Energy Agency
established — 1 February 1958
aim — to promote the peaceful uses of nuclear energy; associated with OECD
members — (28) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Portugal, Slovakia, Spain, Sweden,
Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG) note — also known as the London Suppliers Group or the London Group
established — 1974; effective — 1975
aim — to establish guidelines for exports of nuclear materials, processing equipment for uranium enrichment, and technical infor-
mation to countries of proliferation concern and regions of conflict and instability
members — (45) Argentina, Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, China, Croatia, Cyprus, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, Kazakhstan, South Korea, Latvia,
Lithuania, Luxembourg, Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, South Africa,
Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observer — (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and Development (OECD)
established — 14 December 1960; effective — 30 September 1961
aim — to promote economic cooperation and development
members — (30) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway, Poland, Portugal, Slovakia, Spain,
Sweden, Switzerland, Turkey, UK, US
special member — ( 1 ) EC
Organization for Security and Cooperation in Europe (OSCE) note — formerly the Conference on Security and Cooperation in
Europe (CSCE) established 3 July 1975
established — 1 January 1995
aim — to foster the implementation of human rights, fundamental freedoms, democracy, and the rule of law; to act as an instru¬
ment of early warning, conflict prevention, and crisis management; and to serve as a framework for conventional arms control
and confidence building measures
members— ( 56) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada,
Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Holy See, Hungary, Iceland,
Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco,
Montenegro, Netherlands, Norway, Poland, Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
partners for cooperation— ( 1 1 ) Afghanistan, Algeria, Egypt, Israel, Japan, Jordan, South Korea, Mongolia, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW)
established — 29 April 1997
aim— to enforce the Convention on the Prohibition of the Development, Production, Stockpiling, and Use of Chemical
Weapons and on Their Destruction; to provide a forum for consultation and cooperation among the signatories of the
Convention
members (countries that have ratified the Convention)— ( 183) Afghanistan, Albania, Algeria, Andorra, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbadoes, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Cook Islands, Costa Rica, Cote d Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Djibouti,
Ecuador, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lesotho, Liberia, L','d9795b0a66b3d1da48c4ba32554d98abbf2e6e1b54499d24b75ca8953463b8e3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ff74e44192d50c8af1ebaf9210a1bc88230e94483604159088c0060e3bc403f',2009,'TV','Tuvalu','transnational-issues',1252,'ibya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,''
Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
758
INTERNATIONAL ORGANIZATIONS AND GROUPS
Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
signatory states (countries that have signed, but not ratified, the Convention) — (5) The Bahamas, Burma, Dominican Republic,
Guinea-Bissau, Israel
Organization of African Unity (OAU)
see African Union
Organization of American States (OAS)
established — 14 April 1890 as the International Union of American Republics; 30 April 1948 adopted present charter; effec¬
tive — 13 December 1951
aim — to promote regional peace and security as well as economic and social development
members — (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile, Colombia,
Costa Rica, Cuba (excluded from formal participation since 1962), Dominica, Dominican Republic, Ecuador, El Salvador,
Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers — (60) Algeria, Angola, Armenia, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria, China, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU, Finland, France, Georgia, Germany, Ghana, Greece,
Holy See, Hungary, India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia, Lebanon, Luxembourg, Morocco,
Netherlands, Nigeria, Norway, Pakistan, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Serbia, Slovakia,
Slovenia, Spain, Sri Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, Yemen
Organization of Arab Petroleum Exporting Countries (OAPEC)
established — 9 January 1968
aim — to promote cooperation in the petroleum industry
members — (11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, Tunisia (suspended), UAE
Organization of Eastern Caribbean States (OECS)
established — 18 June 1981; effective — 4 July 1981
aim — to promote political, economic, and defense cooperation
members — (9) Anguilla, Antigua and Barbuda, British Virgin Islands, Dominica, Grenada, Montserrat, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines
Organization of Petroleum Exporting Countries (OPEC)
established — 14 September 1960
aim — to coordinate petroleum policies
members— (13) Algeria, Angola, Ecuador, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
Organization of the Islamic Conference (010)
established — 22-25 September 1969
aim — to promote Islamic solidarity in economic, social, cultural, and political affairs
members— (56 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain, Bangladesh,
Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Cote d’Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-
Bissau, Guyana, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali,
Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia,
Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine
Liberation Organization
observers — ( 14) AU, Bosnia and Herzegovina, Central African Republic, ECO, Islamic Conference Youth Forum for Dialogue
and Cooperation, LAS, Moro National Liberation Front, NAM, OAU, Parliamentary Union of the OIC Member States, Russia,
Thailand, Turkish Muslim Community of Kibris, UN
Pacific Community (SPC)
local name of the Secretariat of the Pacific Community
Pacific Islands Forum (PIF) note — formerly known as South Pacific Forum (SPF)
established — 5 August 1971
aim — to promote regional cooperation in political matters
members — (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau,
Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
associate members — (2) French Polynesia, New Caledonia
observers — (4) Asia Development Bank, The Commonwealth, Timor-Leste, Tokelau
Paris Club
established — 1956
dim — to provide a forum for debtor countries to negotiate rescheduling of debt service payments or loans extended by govern¬
ments or official agencies of participating countries; to help restore normal trade and project finance to debtor countries
members — ( 19) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Japan, Netherlands,
Norway, Russia, Spain, Sweden, Switzerland, UK, US
759
THE CIA WORLD FACTBOOK
Partnership for Peace (PFP)
established — 10-11 January 1994
aim — to expand and intensify political and military cooperation throughout Europe, increase stability, diminish threats to peace,
and build relationships by promoting the spirit of practical cooperation and commitment to democratic principles that underpin
NATO; program under the auspices of NATO
members — (23) Albania, Armenia, Austria, Azerbaijan, Belarus, Bosnia and Herzegovina, Croatia, Finland, Georgia, Ireland,
Kazakhstan, Kyrgyzstan, Macedonia, Moldova, Montenegro, Russia, Serbia, Sweden, Switzerland, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan; note — a nation that becomes a member of NATO is no longer a member of PFP
Permanent Court of Arbitration (PCA)
established — 29 July 1899
aim — to facilitate the settlement of international disputes
members — (107) Argentina, Australia, Austria, Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria, Burkina Faso,
Cambodia, Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Germany, Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Ireland, Israel, Italy, Japan,
Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Malaysia, Malta, Mauritius, Mexico, Montenegro, Morocco, Netherlands, NZ, Nicaragua, Nigeria, Norway,
Pakistan, Panama, Paraguay, Peru, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Thailand, Togo, Turkey, Uganda,
Ukraine, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
RiO Group (RG) note — formerly known as Grupo de los Ocho, established NA December 1986; composed of the Contadora
Group and the Lima Group
es tablished — 1988
aim — to consult on regional Latin American issues
members — (20) Argentina, Bolivia, Brazil, CARICOM, Chile, Colombia, Costa Rica, Dominican Republic, Ecuador, El
Salvador, Guatemala, Guyana, Honduras, Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay, Venezuela
Schengen Convention
established — signed June 1990; effective March 1995
aim — to allow free movement within an area without internal border controls
members — (24) Austria, Belgium, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Iceland, Italy,
Latvia, Lithuania, Luxembourg, Malta, Netherlands, Norway, Poland, Portugal, Slovakia, Slovenia, Spain, Sweden; note — UK
and Ireland have not joined; Switzerland is set to join in the Fall of 2008
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian governments and
command economies based on the Soviet model; the term is fading from use; see centrally planned economies
Secretariat of the Pacific Community (SPC)
established — 6 February 1947; effective 29 July 1948
aim — to serve island development in 22 Pacific countries; to develop technical assistance and professional, scientific, and
research support; to build planning and management capability
members — (26) America Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, New Caledonia, Niue, Northern Mariana Islands, NZ, Palau, Papua New Guinea,
Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu, Vanuatu, US, Wallis and Futuna
Shanghai Cooperation Organization (SCO)
established — 15 June 2001
aim — to combat terrorism, extremism, and separatism; to safeguard regional security through mutual trust, disarmament, and
cooperative security; and to increase cooperation in political, trade, economic, scientific and technological, cultural, and educa-
tional fields
members — (6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
observer — (4) India, Iran, Mongolia, Pakistan
socialist counfries
in general, countries in which the government owns and plans the use of the major factors of production; note — the term is
sometimes used incorrectly as a synonym for Communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the counterpart of
the North; see less developed countries (LDCs)
South American Community of Nations (CSN)
established — 9 December 2004
a*m to coordinate common policies regarding multilateral organizations, to integrate physical infrastructure, and to consolidate
the merger of CAN and Mercosur
members (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Surinam, Uruguay, Venezuela
observers — (2) Mexico, Panama
700
INTERNATIONAL ORGANIZATIONS AND GROUPS
South Asian Association for Regional Cooperation (SAARC)
established — 8 December 1985
aim — to promote economic, social, and cultural cooperation
members — (8) Afghanistan. Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
observers — (6) China, EU, Iran, Japan, South Korea, US
South Asia Co-operative Environment Program (SACEP)
established — January 1983
aim — to promote regional cooperation in South Asia in the field of environment, both natural and human, and on issues of eco¬
nomic and social development; to support conservation and management of natural resources of the region
members — (8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
South Pacific Forum (SPF) note— see Pacific Island Forum South Pacific Regional Trade and Economic Cooperation
Agreement (Sparteca)
established — 1981
aim — to redress unequal trade relationships of Australia and New Zealand with small island economies in the Pacific region
members — (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau,
Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
Southeast European Cooperative Initiative (SECI)
established — 6 December 1996
aim — to encourage cooperation among participating states and to facilitate their integration into European structures
members — (12) Albania, Bosnia and Herzegovina, Bulgaria, Croatia, Greece, Hungary, Macedonia, Moldova, Romania, Serbia,
Slovenia, Turkey
observers — (18) Austria, Azerbaijan, Belgium, Canada, France, Georgia, Germany, Israel, Italy, Japan, Netherlands, Poland,
Portugal, Slovakia, Spain, Ukraine, UK, US
Southeast European Cooperative Initiative (SECI)
established — 6 December 1996
aim — to encourage cooperation among participating states and to facilitate their integration into European structures
members — (12) Albania, Bosnia and Herzegovina, Bulgaria, Croatia, Greece, Hungary, Macedonia, Moldova, Romania, Serbia,
Slovenia, Turkey
observers — (15) Austria, Azerbaijan, Belgium, Canada, France, Georgia, Germany, Italy, Japan, Netherlands, Portugal, Spain,
Ukraine, UK, US
Southern African Customs Union (SACU)
established — 11 December 1969
aim — to promote free trade and cooperation in customs matters
members — (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC) note — evolved from the Southern African Development Coordination
Conference (SADCC)
established — 17 August 1992
aim — to promote regional economic development and integration
members — (14) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Madagascar, Malawi, Mauritius, Mozambique,
Namibia, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market note — also known as Mercado Comun del Cono
Sur (Mercosur)
established — 26 March 1991
aim — to increase regional economic cooperation
members — (4) Argentina, Brazil, Paraguay, Uruguay
associate members — (5) Bolivia, Chile, Colombia, Ecuador, Peru, Venezuela
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
African Union/United Nations Hybrid Operation in Darfur (UNAMID)
established — 31 July 2007
aim — to contribute to the restoration of security conditions which will allow safe humanitarian assistance throughout Darfur, to
contribute to the protection of civilian populations under imminent threat of physical attack, to monitor, observe compliance
with, and verify the implementation of various ceasefire agreements
members — (18) Bangladesh, Burkina Faso, China, Egypt, Ethiopia, The Gambia, Ghana, Kenya, Malawi, Mali, Nepal,
Netherlands, Nigeria, Pakistan, Rwanda, Senegal, South Africa, Thailand
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed countries
(LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least developed
countries (LLDCs)
761
THE CIA WORLD FACTBOOK
Union Latina
established — 15 May 1954; became functional 1983
aim — to project, protect, and promote the common heritage and unifying idenitites of the Latin, and Latin-influenced, world
members — (37) Andorra, Angola, Bolivia, Brazil, Cape Verde, Chile, Colombia, Cote d Ivoire, Costa Rica, Cuba, Dominican
Republic, Ecuador, El Salvador, France, Guatemala, Guinea-Bissau, Haiti, Honduras, Italy, Mexico, Moldova, Monaco,
Mozambique, Nicaragua, Panama, Paraguay, Peru, Philippines, Portugal, Romania, San Marino, Sao Tome and Principe, Senegal,
Spain, Timor-Leste, Uruguay, Venezuela
observers — (3) Argentina, Holy See, Order of Malta
United Nations (UN)
established — 26 June 1945; effective — 24 October 1945
aim — to maintain international peace and security and to promote cooperation involving economic, social, cultural, and human¬
itarian problems
constituent organizations — the UN is composed of six principal organs and numerous subordinate agencies and bodies as follows.
1 ) Secretariat
2) General Assembly: Joint United Nations Program on HIV/AIDS (UN-AIDS), International Research and Training Institute
for the Advancement of Women (INSTRAW), Office of the United Nations High Commissioner for Human Rights (OHCHR),
Organization for the Prohibition of Chemical Weapons (OPCW), Preparation Commission for the Nuclear- Ban-Treaty
Operation (CTBTU), United Nations Center for Human Settlements (UN-Habitat), United Nations Children’s Fund
(UNICEF), United Nations Conference on Trade and Development (UNCTAD), United Nations Democracy Fund (UNDEF),
United Nations Development Program (UNDP), United Nations Drug Control Program (UNDCP), United Nations
Environment Program (UNEP), United Nations Fund for International Partnerships (UNFIP), United Nations High
Commissioner for Refugees (UNHCR), United Nations Institute for Disarmament Research (UNIDIR), United Nations
Institute for Training and Research (UNITAR), United Nations Interregional Crime and Justice Research Institute (UNICRI),
United Nations Population Fund (UNFPA), United Nations Office of Project Services (UNOPS), United Nations Relief and
Works Agency for Palestine Refugees in the Near East (UNRWA), United Nations Research Institute for Social Development
(UNRISD), United Nations System Staff College (UNSSC), United Nations University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former Yugoslavia (ICTY), International Criminal Tribunal for
Rwanda (ICTR), United Nations Compensation Commission, United Nations Disengagement Observer Force (UNDOF),
African Union/United Nations Hybrid Operation in Darfur (UNAMID), United Nations Integrated Mission in Timor-Leste
(UNMIT), United Nations Interim Administration Mission in Kosovo (UNMIK), United Nations Interim Force in Lebanon
(UNIFIL), United Nations Mission in Liberia (UNMIL), United Nations Military Observer Group in India and Pakistan
(UNMOGIP), United Nations Operation in Cote d’Ivoire (UNOCI), United Nations Mission for the Referendum in Western
Sahara (MINURSO), United Nations Mission in the Central African Republic and Chad (MINURCAT), United Nations
Mission in Ethiopia and Eritrea (UNMEE), United Nations Mission in the Sudan (UNMIS), United Nations Observer Mission
in Georgia (UNOMIG), United Nations Organization Mission in the Democratic Republic of the Congo (MONUC), United
Nations Peace-Keeping Force in Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti (MINUSTAH), and United
Nations Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social Development, Commission on Crime Prevention and
Criminal Justice, Commission on Narcotics Drugs, Commission on Population and Development, Commission on Science and
Technology for Development, Commission on Sustainable Development, Commission on the Status of Women, Economic and
Social Commission for Asia and the Pacific (ESCAP), Economic and Social Commission for Western Asia (ESCWA),
Economic Commission for Africa (ECA), Economic Commission for Europe (ECE), Economic Commission for Latin America
and the Caribbean (ECLAC), Food and Agriculture Organization of the United Nations (FAO), International Atomic Energy
Agency (IAEA), International Bank for Reconstruction and Development (IBRD), International Center for Secretariat of
Investment Disputes (ICSID), International Civil Aviation Organization (ICAO), International Development Association
(IDA), International Finance Corporation (IFC), International Fund for Agricultural Development (IFAD), International Labor
Organization (ILO), International Maritime Organization (IMO), International Monetary Fund (IMF), International
Telecommunication Union (ITU), Multilateral Investment Geographic Agency (MIGA), Statistical Commission, United
Nations Educational, Scientific, and Cultural Organization (UNESCO), United Nations Forum on Forests, United Nations
Industrial Development Organization (UNIDO), Universal Postal Union (UPU), World Health Organization (WHO), World
Intellectual Property Organization (WIPO), World Meteorological Organization (WMO), World Tourism Organization
(UNWTO), and World Trade Organization (WTO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
United Nations Children''s Fund (UNICEF) note— acronym retained from the predecessor organization, UN International
Children’s Emergency Fund
established — 11 December 1946
aim — to help establish child health and welfare services
members — (36) selected on a rotating basis from all regions
United Nations Conference on Trade and Development (UNCTAD)
established — 30 December 1964
aim — to promote international trade
members — (193) all UN members plus Holy See
762
INTERNATIONAL ORGANIZATIONS AND GROUPS
United Nations Development Program (UNDP)
established — 22 November 1965
aim — to provide technical assistance to stimulate economic and social development
members (executive board) — (36) selected on a rotating basis from all regions
United Nations Disengagement Observer Force (UNDOF)
established — 31 May 1974
aim — to observe the 1973 Arab-Israeli cease-fire; established by the UN Security Council
members — (6) Austria, Canada, India, Japan, Poland, Slovakia
United Nations Educational, Scientific, and Cultural Organization (UNESCO)
established — 16 November 1945; effective — 4 November 1946
aim — to promote cooperation in education, science, and culture
members — (193) includes all UN member countries except Liechtenstein (191 total); plus Cook Islands and Niue
associate members — (6) Aruba, British Virgin Islands, Cayman Islands, Macau, Netherlands Antilles, Tokelau
United Nations Environment Program (UNEP)
established — 15 December 1972
aim — to promote international cooperation on all environmental matters
members — (58) selected on a rotating basis from all regions
United Nations General Assembly
established — 26 June 1945; effective — 24 October 1945
aim — to function as the primary deliberative organ of the UN
members — (192) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR)
established — 3 December 1949; effective — 1 January 1951
aim — to ensure the humanitarian treatment of refugees and find permanent solutions to refugee problems
members (executive committee) — (72) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada, Chile, China,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Cyprus, Denmark, Ecuador, Egypt, Estonia, Ethiopia,
Finland, France, Germany, Ghana, Greece, Guinea, Holy See, Hungary, India, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya,
South Korea, Lebanon, Lesotho, Madagascar, Mexico, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Nigeria,
Norway, Pakistan, Philippines, Poland, Portugal, Romania, Russia, Serbia, Somalia, South Africa, Spain, Sudan, Sweden,
Switzerland, Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yemen, Zambia
United Nations Industrial Development Organization (UNIDO)
established — 17 November 1966; effective — 1 January 1967
aim — UN specialized agency that promotes industrial development especially among the members
members — (172) includes all UN member countries except Andorra, Antigua and Barbuda, Australia, Brunei, Canada, Estonia,
Iceland, Kiribati, Latvia, Liechtenstein, Marshall Islands, Federated States of Micronesia, Nauru, Palau, Samoa, San Marino,
Singapore, Solomon Islands, Tuvalu, US
United Nations Institute for Training and Research (UNITAR)
established — 11 December 1963 adoption of the resolution establishing the Institute; effective— 24 March 1965
aim — to help the UN become more effective through training and research
members (Board of Trustees)— (16) Brazil, Burkino Faso, Egypt, Estonia, France, Ghana, Japan, Kuwait, Mexico, Morocco,
Nigeria, Russia, South Africa, Switzerland, Thailand, US; note — the UN Secretary General can appoint up to 30 members
United Nations Integrated Mission in Timor-Leste (UNMIT)
established — 25 August 2006
aim — to support the Government, to support the electoral process, to ensure the restoration and maintenance of public security
members — (12) Australia, Bangladesh, Brazil, China, Fiji, Malaysia, NZ, Pakistan, Philippines, Portugal, Sierra Leone, Singapore
United Nations Interim Administration Mission in Kosovo (UNMIK)
established — 10 June 1999
aim —','40837f56968d6181dfa4cfab58406a9a02229d8dbc37bd434c345fb8adb16ea5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('667cc4d7e95d2d9089b48c651c355d3afbc3735ba4fa5f730773b2f09219719e',2009,'TV','Tuvalu','transnational-issues',1253,'to promote the establishment of substantial autonomy and self-government in Kosovo; to perform basic civilian adminis¬
trative functions; to support the reconstruction of key infrastructure and humanitarian and disaster relief
note — gives civilian support only; works closely with NATO Kosovo Force (KFOR)
United Nations Interim Force in Lebanon (UNIFIL)
established — 19 March 1978
aim — to confirm the withdrawal of Israeli forces, and assist in reestablishing Lebanese authority in southern Lebanon; established
by the UN Security Council
members — (26) Belgium, China, Croatia, Cyprus, Finland, France, Germany, Ghana, Greece, Guatemala, India, Indonesia,
Ireland, Italy, South Korea, Luxembourg, Macedonia, Malaysia, Nepal, Netherlands, Poland, Portugal, Qatar, Spain, Tanzania,
Turkey
United Nations Military Observer Group in India and Pakistan (UNMOGIP)
established — 24 January 1949
aim — to observe the 1949 India-Pakistan cease-fire; established by the UN Security Council
members — (8) Chile, Croatia, Denmark, Finland, Italy, South Korea, Sweden, Uruguay
763
THE CIA WORLD FACTBOOK
United Nations Mission for the Referendum in Western Sahara (MINURSO)
established — 29 April 1991
aim — to supervise the ceasefire and conduct a referendum in Western Sahara; established by the UN Security Council
members — (27) Argentina, Austria, Bangladesh, Brazil, China, Croatia, Djibouti, Egypt, El Slavador, France, Ghana, Greece,
Guinea, Honduras, Hungary, Ireland, Italy, Kenya, Malaysia, Mongolia, Nigeria, Pakistan, Poland, Russia, Sri Lanka, Uruguay,
TV
TV
TUV
798
TUV
.tv
8 00 S
178 00 E
8 30 S
179 12 E
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine,
8 30 S
179 12 E
Atlantic Ocean
45 00 N
66 00 W','0706e922e57665b0b301e68d97506346b0c423603a161902bf37452e7e4bbe7b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eb6315ba9c4d46c77772d0233209d7fd2b41eef165c0535d62c98bde258eb67',2009,'AE','United Arab Emirates','transnational-issues',1264,'Disputes— international: 1997
boundary delimitation treaty with
Belarus remains un-ratified due to unre¬
solved financial claims, stalling demarca¬
tion and reducing border security;
delimitation of land boundary with
Russia is complete with preparations for
demarcation underway; the dispute over
the boundary between Russia and
Ukraine through the Kerch Strait and
Sea of Azov remains unresolved despite a
December 2003 framework agreement
and ongoing expert-level discussions;
Moldova and Ukraine operate joint cus¬
toms posts to monitor transit of people
and commodities through Moldova’s
break-away Transnistria Region, which
remains under OSCE supervision; the
ICJ gave Ukraine until December 2006
to reply, and Romania until June 2007 to
rejoin, in their dispute submitted in 2004
over Ukrainian-administered
Zmiyinyy/Serpilor (Snake) Island and
Black Sea maritime boundary; Romania
opposes Ukraine’s reopening of a naviga¬
tion canal from the Danube border
through Ukraine to the Black Sea
Illicit drugs: limited cultivation of
cannabis and opium poppy, mostly for
CIS consumption; some synthetic drug
production for export to the West; lim¬
ited government eradication program;
used as transshipment point for opiates
and other illicit drugs from Africa, Latin
America, and Turkey to Europe and
Russia; Ukraine has improved anti-
money-laundering controls, resulting in
its removal from the Financial Action
Task Force’s (FATF’s) Noncooperative
Countries and Territories List in
February 2004; Ukraine’s anti-money-
laundering regime continues to be moni¬
tored by FATF
Disputes— international: boundary
agreement was signed and ratified with
Oman in 2003 for entire border,
including Oman’s Musandam Peninsula
and Al Madhah enclaves, but contents
of the agreement and detailed maps
showing the alignment have not been
published; Iran and UAE dispute Tunb
Islands and Abu Musa Island, which Iran
occupies
Trafficking in persons: current situation:
the United Arab Emirates is a destina¬
tion country for men, women, and chil¬
dren trafficked from South and East
Asia, Eastern Europe, Africa, and the
Middle East for involuntary servitude
and for sexual exploitation; an estimated
10,000 women from sub-Saharan Africa,
Eastern Europe, South and East Asia,
Iraq, Iran, and Morocco may be victims
of sex trafficking in the UAE; women
also migrate from Africa, and South and
Southeast Asia to work as domestic ser¬
vants, but may have their passports con¬
fiscated, be denied permission to leave
the place of employment in the home, or
face sexual or physical abuse by their
employers; men from South Asia come
to the UAE to work in the construction
industry, but may be subjected to condi¬
tions of involuntary servitude as they are
coerced to pay off recruitment and travel
costs, sometimes having their wages
denied for months at a time; victims of
child camel jockey trafficking may still
remain in the UAE, despite a July 2005
law banning the practice; while all iden¬
tified victims were repatriated at the gov¬
ernment’s expense to their home
countries, questions persist as to the
effectiveness of the ban and the true
number of victims
tier rating: Tier 2 Watch List — UAE is
placed on the Tier 2 Watch List for its
failure to show increased efforts to
combat trafficking in 2005, particularly
in its efforts to address the large-scale
trafficking of foreign girls and women for
commercial sexual exploitation
Illicit drugs: the UAE is a drug trans¬
shipment point for traffickers given its
proximity to Southwest Asian drug-pro¬
ducing countries; the UAE’s position as a
major financial center makes it vulner¬
able to money laundering; anti-money¬
laundering controls improving, but
informal banking remains unregulated
678
Background: As the dominant industrial
and maritime power of the 19th century,
the United Kingdom of Great Britain
and Ireland played a leading role in
developing parliamentary democracy
and in advancing literature and science.
At its zenith, the British Empire
stretched over one-fourth of the earth’s
surface. The first half of the 20th century
saw the UK’s strength seriously depleted
in two World Wars and the Irish republic
withdraw from the union. The second
half witnessed the dismantling of the
Empire and the UK rebuilding itself into
a modern and prosperous European
nation. As one of five permanent mem¬
bers of the UN Security Council, a
founding member of NATO, and of the
Commonwealth, the UK pursues a global
approach to foreign policy; it currently is
weighing the degree of its integration
with continental Europe. A member of
the EU, it chose to remain outside the
Economic and Monetary Union for the
time being. Constitutional reform is also
a significant issue in the UK. The
Scottish Parliament, the National
Assembly for Wales, and the Northern
Ireland Assembly were established in
1999, but the latter was suspended until
May 2007 due to wrangling over the
peace process.
Location: Western Europe, islands
including the northern one-sixth of the
island of Ireland between the North
Atlantic Ocean and the North Sea,
northwest of France
Geographic coordinates: 54 00 N, 2 00
w
Map references: Europe
Area:
total: 244,820 sq km
land: 241,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland
Islands
Area — comparative: slightly smaller
than Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
continental shelf: as defined in conti¬
nental shelf orders or in accordance with
agreed upon boundaries
Climate: temperate; moderated by pre¬
vailing southwest winds over the North
Atlantic Current; more than one-half of
the days are overcast
Terrain: mostly rugged hills and low
mountains; level to rolling plains in east
and southeast
Elevation extremes:
lowest point: The Fens -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum, nat¬
ural gas, iron ore, lead, zinc, gold, tin,
limestone, salt, clay, chalk, gypsum,
potash, silica sand, slate, arable land
Land use:
arable land: 23.23%
permanent crops: 0.2%
other: 76.57% (2005)
Irrigated land: 1,700 sq km (2003)
Total renewable water resources: 160.6
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 11.75 cu
km/yr (22%/75%/3%)
per capita: 197 cu m/yr (1994)
Natural hazards: winter windstorms;
floods
Environment — current issues: con¬
tinues to reduce greenhouse gas emis¬
sions (has met Kyoto Protocol target of a
12.5% reduction from 1990 levels and
intends to meet the legally binding target
and move toward a domestic goal of a
20% cut in emissions by 2010); by 2005
the government reduced the amount of
industrial and commercial waste dis¬
posed of in landfill sites to 85% of 1998
levels and recycled or composted at least
25% of household waste, increasing to
33% by 2015
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds,
Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: lies near vital North
Atlantic sea lanes; only 35 km from
France and linked by tunnel under the
English Channel; because of heavily
indented coastline, no location is more
than 1 25 km from tidal waters
Population: 60,943,912 (July 2008 est.)
Age structure:
0-14 years: 16.9% (male
5,287,590/female 5,036,881)
15-64 years: 67.1% (male
20,698,645/female 20,185,040)
65 years and over: 16% (male
4,186,561/female 5,549,195) (2008 est.)
Median age: total: 39.9 years
male: 38.8 years
female: 41 years (2008 est.)
Population growth rate: 0.276% (2008
est.)
Birth rate: 10.65 births/1,000 population
(2008 est.)
Death rate: 10.05 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 2.17 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.98 male(s)/female
(2008 est.)
Infant mortality rate:
total: 4.93 deaths/1,000 live births
male: 5.49 deaths/1,000 live births
female: 4.34 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 78.85 years
679
THE CIA WORLD FACTBOOK
male: 76.37 years
female: 81.46 years (2008 est.)
Total fertility rate: 1.66 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.2%
(2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 51,000 (2001 est.)
HIV/AIDS — deaths: fewer than 500
(2003 est.)
Nationality: noun: Briton(s), British
(collective plural)
adjective: British
Ethnic groups: white (of which English
83.6%, Scottish 8.6%, Welsh 4.9%,
Northern Irish 2.9%) 92.1%, black 2%,
Indian 1.8%, Pakistani 1.3%, mixed
1.2%, other 1.6% (2001 census)
Religions: Christian (Anglican, Roman
Catholic, Presbyterian, Methodist)
71.6%, Muslim 2.7%, Hindu 1%, other
1.6%, unspecified or none 23.1% (2001
census)
Languages: English, Welsh (about 26%
of the population of Wales), Scottish
form of Gaelic (about 60,000 in
Scotland)
Literacy:
definition: age 15 and over has completed
five or more years of schooling
total population: 99%
male: 99%
female: 99% (2003 est.)
Country name:
conventional long form: United Kingdom
of Great Britain and Northern Ireland;
note — Great Britain includes England,
Scotland, and Wales
conventional short form: United Kingdom
abbreviation: UK
Government type: constitutional
monarchy
Capital: name: London
geographic coordinates: 5130N, 0 10W
time difference: UTC 0 (5 hours ahead of
Washington, DC during Standard Time)
daylight saving time: +lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: England: 34
two-tier counties, 32 London boroughs
and 1 City of London or Greater
London, 36 metropolitan counties, 46
unitary authorities
two''tier counties: Bedfordshire,
Buckinghamshire, Cambridgeshire,
Cheshire, Cornwall and Isles of Scilly,
Cumbria, Derbyshire, Devon, Dorset,
Durham, East Sussex, Essex,
Gloucestershire, Hampshire,
Hertfordshire, Kent, Lancashire,
Leicestershire, Lincolnshire, Norfolk,
North Yorkshire, Northamptonshire,
Northumberland, Nottinghamshire,
Oxfordshire, Shropshire, Somerset,
Staffordshire, Suffolk, Surrey,
Warwickshire, West Sussex, Wiltshire,
Worcestershire
London boroughs and City of London or
Greater London: Barking and Dagenham,
Barnet, Bexley, Brent, Bromley, Camden,
Croydon, Ealing, Enfield, Greenwich,
Hackney, Hammersmith and Fulham,
Haringey, Harrow, Havering, Hillingdon,
Hounslow, Islington, Kensington and
Chelsea, Kingston upon Thames,
Lambeth, Lewisham, City of London,
Merton, Newham, Redbridge, Richmond
upon Thames, Southwark, Sutton,
Tower Hamlets, Waltham Forest,
Wandsworth, Westminster
metropolitan counties: Barnsley,
Birmingham, Bolton, Bradford, Bury,
Calderdale, Coventry, Doncaster,
Dudley, Gateshead, Kirklees, Knowlsey,
Leeds, Liverpool, Manchester, Newcastle
upon Tyne, North Tyneside, Oldham,
Rochdale, Rotherham, Salford,
Sandwell, Sefton, Sheffield, Solihull,
South Tyneside, St. Helens, Stockport,
Sunderland, Tameside, Trafford,
Wakefield, Walsall, Wigan, Wirral,
Wolverhampton
unitary authorities: Bath and North East
Somerset, Blackburn with Darwen,
Blackpool, Bournemouth, Bracknell
Forest, Brighton and Hove, City of
Bristol, Darlington, Derby, East Riding of
Yorkshire, Halton, Hartlepool, County
of Herefordshire, Isle of Wight, City of
Kingston upon Hull, Leicester, Luton,
Medway, Middlesbrough, Milton Keynes,
North East Lincolnshire, North
Lincolnshire, North Somerset,
Nottingham, Peterborough, Plymouth,
Poole, Portsmouth, Reading, Redcar and
Cleveland, Rutland, Slough, South
Gloucestershire, Southampton,
Southend-on-Sea, Stockton-on-Tees,
Stoke-on-Trent, Swindon, Telford and
Wrekin, Thurrock, Torbay, Warrington,
West Berkshire, Windsor and
Maidenhead, Wokingham, York
Northern Ireland: 26 district council areas
district council areas: Antrim, Ards,
Armagh, Ballymena, Ballymoney,
Banbridge, Belfast, Carrickfergus,
Castlereagh, Coleraine, Cookstown,
Craigavon, Derry, Down, Dungannon,
Fermanagh, Larne, Limavady, Lisburn,
Magherafelt, Moyle, Newry and Moume,
Newtownabbey, North Down, Omagh,
Strabane
Scotland: 32 unitary authorities
unitary authorities: Aberdeen City,
Aberdeenshire, Angus, Argyll and Bute,
Clackmannanshire, Dumfries and
Galloway, Dundee City, East Ayrshire,
East Dunbartonshire, East Lothian, East
Renfrewshire, City of Edinburgh, Eilean
Siar (Western Isles), Falkirk, Fife,
Glasgow City, Highland, Inverclyde,
Midlothian, Moray, North Ayrshire,
North Lanarkshire, Orkney Islands,
Perth and Kinross, Renfrewshire,
Shetland Islands, South Ayrshire, South
Lanarkshire, Stirling, The Scottish
Borders, West Dunbartonshire, West
Lothian
Wales: 22 unitary authorities
unitary authorities: Blaenau Gwent;
Bridgend; Caerphilly; Cardiff;
Carmarthenshire; Ceredigion; Conwy;
Denbighshire; Flintshire; Gwynedd; Isle
of Anglesey; Merthyr Tydfil;
Monmouthshire; Neath Port Talbot;
Newport; Pembrokeshire; Powys;
Rhondda, Cynon, Taff; Swansea; The
Vale of Glamorgan; Torfaen; Wrexham
Dependent areas: Anguilla, Bermuda,
British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Falkland
Islands, Gibraltar, Montserrat, Pitcairn
Islands, Saint Helena, South Georgia
and the South Sandwich Islands, Turks
and Caicos Islands
Independence: England has existed as a
unified entity since the 10th century; the
union between England and Wales,
begun in 1284 with the Statute of
Rhuddlan, was not formalized until 1536
with an Act of Union; in another Act of
Union in 1707, England and Scotland
agreed to permanently join as Great
Britain; the legislative union of Great
Britain and Ireland was implemented in
1801, with the adoption of the name the
United Kingdom of Great Britain and
Ireland; the Anglo-Irish treaty of 1921
formalized a partition of Ireland; six
northern Irish counties remained part of
the United Kingdom as Northern
Ireland and the current name of the
country, the United Kingdom of Great
Britain and Northern Ireland, was
adopted in 1927
National holiday: the UK does not cele¬
brate one particular national holiday
Constitution: unwritten; partly statutes,
partly common law and practice
Legal system: based on common law
tradition with early Roman and modern
continental influences; has nonbinding
judicial review of Acts of Parliament
under the Human Rights Act of 1998;
accepts compulsory ICJ jurisdiction, with
reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); Heir Apparent
Prince CHARLES (son of the queen,
bom 14 November 1948)
head of government: Prime Minister
Gordon BROWN (since 27 June 2007)
cabinet: Cabinet of Ministers appointed
by the prime minister
elections: the monarchy is hereditary; fol¬
lowing legislative elections, the leader of
the majority party or the leader of the
majority coalition is usually the prime
minister
680
Central African Customs and Economic Union
ultra-high-frequency
AE
AE
ARE
784
ARE
.ae
24 28 N
54 22 E
Iran
25 52 N
55 03 E
24 00 N
54 00 E
25 18 N
55 18 E
24 00 N
54 00 E
Russia (de facto)
44 55 N
147 40 E
24 00 N
54 00 E
24 00 N
54 00 E
24 00 N
54 00 E
Federated States of Micronesia
7 25 N
151 47 E
Pacific Ocean
41 35 N
141 00 E','0c3f695fdc1cdc0e56910711b6d49a90e0409ac7b896b0be9a6d2f8d8cad8a9d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44d48493fc3d13188d677e1ef677b9ccb32fe067b480bfe68dec4185ee8c6b8d',2009,'GB','United Kingdom','transnational-issues',1269,'Legislative branch: bicameral Parliament
consists of House of Lords (618 seats; con¬
sisting of approximately 500 life peers, 92
hereditary peers, and 26 clergy) and
House of Commons (646 seats since 2005
elections; members are elected by popular
vote to serve five-year terms unless the
House is dissolved earlier)
elections: House of Lords — no elections
(note — in 1999, as provided by the
House of Lords Act, elections were held
in the House of Lords to determine the
92 hereditary peers who would remain
there; elections are held only as vacan¬
cies in the hereditary peerage arise);
House of Commons — last held 5 May
2005 (next to be held by May 2010)
election results: House of Commons —
percent of vote by party — Labor 35.2%,
Conservative 32.3%, Liberal Democrats
22%, other 10.5%; seats by party — Labor
355, Conservative 198, Liberal
Democrat 62, other 31; seats by party in
the House of Commons as of 4 June
2008 — Labor 351, Conservative 192,
Liberal Democrat 63, Scottish National
Party/Plaid Cymru 9, Democratic
Unionist 9, Sinn Fein 5, other 17
note: in 1998 elections were held for a
Northern Ireland Assembly (because of
unresolved disputes among existing par¬
ties, the transfer of power from London
to Northern Ireland came only at the
end of 1999 and has been suspended four
times, the latest occurring in October
2002 and lasting until 8 May 2007); in
1999, the UK held the first elections for
a Scottish Parliament and a Welsh
Assembly, the most recent of which were
held in May 2007
Judicial branch: House of Lords
(highest court of appeal; several Lords of
Appeal in Ordinary are appointed by the
monarch for life); Supreme Courts of
England, Wales, and Northern Ireland
(comprising the Courts of Appeal, the
High Courts of Justice, and the Crown
Courts); Scotland’s Court of Session and
Court of the Justiciary
Political parties and leaders:
Conservative [David CAMERON];
Democratic Unionist Party (Northern
Ireland) [Peter ROBINSON]; Labor
Party [Gordon BROWN]; Liberal
Democrats [Nick CLEGG]; Party of
Wales (Plaid Cymru) [leuan Wyn
JONES]; Scottish National Party or SNP
[Alex SALMOND]; Sinn Fein
(Northern Ireland) [Gerry ADAMS];
Social Democratic and Labor Party or
SDLP (Northern Ireland) [Mark
DURKAN]; Ulster Unionist Party
(Northern Ireland) [Sir Reg EMPEY]
Political pressure groups and leaders:
Campaign for Nuclear Disarmament;
Confederation of British Industry;
National Farmers’ Union; Trades Union
Congress
International organization participa¬
tion: ADB (nonregional members),
AfDB, Arctic Council (observer),
Australia Group, BIS, C, CBSS
(observer), CDB, CE, CERN, EAPC,
EBRD, EIB, ESA, EU, FAO, G-5, G-7,
G-8, G-10, IADB, IAEA, IBRD, ICAO,
ICC, ICCt, ICRM, IDA, IEA, IFAD,
IFC, 1FRCS, IHO, ILO, IMF, IMO,
IMSO, Interpol, IOC, IOM, IPU, ISO,
ITSO, ITU, MIGA, NATO, NEA,
NSG, OAS (observer), OECD, OPCW,
OSCE, Paris Club, PCA, PIF (partner),
SECI (observer), UN, UN Security
Council, UNCTAD, UNESCO,
UNFICYP, UNHCR, UNIDO, UNMIL,
UNMIS, UNOMIG, UNRWA,
UNWTO, UPU, WCO, WEU, WHO,
WIPO, WMO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Sir Nigel E.
SHEINWALD
chancery: 3100 Massachusetts Avenue
NW, Washington, DC 20008
telephone: [1] (202) 588-6500
FAX: [1] (202) 588-7870
consulate(s) general: Atlanta, Boston,
Chicago, Houston, Los Angeles, Miami,
New York, San Francisco
consulate(s) : Denver, Orlando
Diplomatic representation from the US:
chief of mission: Ambassador Robert
Holmes TUTTLE
embassy: 24 Grosvenor Square, London,
W1A 1AE
mailing address: PSC 801, Box 40, FPO
AE 09498-4040
telephone: [44] (0) 20 7499-9 000
FAX: [44] (0) 20 7629-9124
consulate(s) general: Belfast, Edinburgh
Flag description: blue field with the red
cross of Saint George (patron saint of
England) edged in white superimposed
on the diagonal red cross of Saint Patrick
(patron saint of Ireland), which is super¬
imposed on the diagonal white cross of
Saint Andrew (patron saint of
Scotland); properly known as the Union
Flag, but commonly called the Union
Jack; the design and colors (especially
the Blue Ensign) have been the basis for
a number of other flags including other
Commonwealth countries and their con¬
stituent states or provinces, and British
overseas territories
Economy — overview: The UK, a leading
trading power and financial center, is
one of the quintet of trillion dollar
economies of Western Europe. Over the
past two decades, the government has
greatly reduced public ownership and
contained the growth of social welfare
programs. Agriculture is intensive,
highly mechanized, and efficient by
European standards, producing about
60% of food needs with less than 2% of
the labor force. The UK has large coal,
natural gas, and oil reserves; primary
energy production accounts for 10% of
GDP, one of the highest shares of any
industrial nation. Services, particularly
banking, insurance, and business serv¬
ices, account by far for the largest pro¬
portion of GDP while industry continues
to decline in importance. Since
emerging from recession in 1992,
Britain’s economy has enjoyed the
longest period of expansion on record;
growth has remained in the 2-3% range
since 2004, outpacing most of Europe.
The economy’s strength has complicated
the Labor government’s efforts to make a
case for Britain to join the European
Economic and Monetary Union (EMU).
Critics point out that the economy is
doing well outside of EMU, and public
opinion polls show a majority of Britons
are o pposed to the euro. The BROWN
government has been speeding up the
improvement of education, health serv¬
ices, and affordable housing at a cost in
higher taxes and a widening public
deficit.
GDP (purchasing power parity): $2,137
trillion (2007 est.)
GDP (official exchange rate): $2,773
trillion (2007 est.)
GDP — real growth rate: 3.1% (2007
est.)
GDP— per capita (PPP): $35,100 (2007
est.)
GDP — composition by sector:
agriculture: 0.9%
industry: 23.4%
services: 75.7% (2007 est.)
Labor force: 30.87 million (2007 est.)
Labor force — by occupation: agriculture:
1.4%
industry: 18.2%
services : 80.4% (2006 est.)
Unemployment rate: 5.4% (2007 est.)
Population below poverty line: 14%
(2006 est.)
Household income or consumption by
percentage share:
lowest 10%: 2.1%
highest 10%: 28.5% (1999)
Distribution of family income— Gini
index: 34 (2005)
Inflation rate (consumer prices): 2.3%
(2007 est.)
Investment (gross fixed): 18.5% of
GDP (2007 est.)
Budget:
revenues: $1,155 trillion
expenditures: $1,236 trillion (2007 est.)
Public debt: 43% of GDP (2007 est.)
Agriculture — products: cereals, oilseed,
potatoes, vegetables; cattle, sheep,
poultry; fish
Industries: machine tools, electric power
equipment, automation equipment, rail¬
road equipment, shipbuilding, aircraft,
motor vehicles and parts, electronics and
681
THE CIA WORLD FACTBOOK
communications equipment, metals,
chemicals, coal, petroleum, paper and
paper products, food processing, textiles,
clothing, other consumer goods
Industrial production growth rate: 0.5%
(2007 est.)
Electricity— production: 372.6 billion
kWh (2005)
Electricity — production by source:
fossil fuel: 73.8%
hydro: 0.9%
nuclear: 23.7%
other: 1.6% (2001)
Electricity— consumption: 348.7 billion
kWh (2005)
Electricity— exports: 2.839 billion kWh
(2005)
Electricity— imports: 11.16 billion kWh
(2005)
Oil— production: 1.861 million bbl/day
(2005 est.)
Oil— consumption: 1.82 million bbl/day
(2005 est.)
Oil — exports: 1.956 million bbl/day
(2004)
Oil — imports: 1.654 million bbl/day
(2004)
Oil— proved reserves: 4.029 billion bbl
(1 January 2006 est.)
Natural gas— production: 84.16 billion
cu m (2005 est.)
Natural gas— consumption: 91.16 bil¬
lion cu m (2005 est.)
Natural gas— exports: 8.843 billion cu
m (2005 est.)
Natural gas— imports: 15.84 billion cu
m (2005)
Natural gas— proved reserves: 509.2
billion cu m (1 January 2006 est.)
Current account balance: $136.2 bil¬
lion (2007 est.)
Exports: $441.4 billion f.o.b. (2007 est.)
Exports — Commodities: manufactured
goods, fuels, chemicals; food, beverages,
tobacco
Exports— partners: us 13.9%,
Germany 10.9%, France 10.4%, Ireland
7.1%, Netherlands 6.3%, Belgium 5.2%,
Spain 4.5% (2006)
Imports: $616.8 billion f.o.b. (2007 est.)
Imports Commodities: manufactured
goods, machinery, fuels; foodstuffs
Imports— partners: Germany 12.8%,
US 8.9%, France 6.9%, Netherlands
6.6%, China 5.3%, Norway 4.9%,
Belgium 4.5% (2006)
Economic aid— donor: ODA, $12.46
billion (2006)
Reserves of foreign exchange and
gold: $57.3 billion (31 December 2007
est.)
Debt— external: $10.45 trillion (30 June
2007)
Stock of direct foreign investment— at
home: $1,324 trillion (2007 est.)
Stock of direct foreign investment —
abroad: $1,741 trillion (2007 est.)
Market value of publicly traded shares:
$3,058 trillion (2005)
Currency (code): British pound (GBP)
Currency code: GBP
Exchange rates: British pounds per US
dollar— 0.4993 (2007), 0.5418 (2006),
0.5493 (2005), 0.5462 (2004), 0.6125
(2003)
Fiscal year: 6 April — 5 April
United Nations
United Nations Mission in Sierra Leone
United Nations Convention on the Law of the Sea, also know as LOS
United Nations Conference on Trade and Development
United Nations Drug Control Program
United Nations Disengagement Observer Force
United Nations Development Program
United Nations Environment Program
United Nations Educational, Scientific, and Cultural Organization
United Nations Peace-keeping Force in Cyprus
United Nations Population Fund
United Nations High Commissioner for Refugees
United Nations Children’s Fund
United Nations Interregional Crime and Justice Research Institute
United Nations Institute for Disarmament Research
United Nations Industrial Development Organization
United Nations Interim Force in Lebanon
United Nations Institute for Training and Research
United Nations Mission in Ethiopia and Eritrea
739
THE CIA WORLD FACTBOOK
UNMIK
UNMIL
UNMIT
UNM06IP
UNMOVIC
UNOCI
UNOMIG
UNOPS
UNRISD
UNRWA
UNSC
UNSSC
UNTSO
UNU
UNWTO
UPU
US
USSR
United Nations Interim Administration Mission in Kosovo
United Nations Mission in Liberia
United Nations Integrated Mission in Timor-Leste
United Nations Military Observer Group in India and Pakistan
United Nations Monitoring, Verification, and Inspection Commission
United Nations Operation in Cote d’Ivoire
United Nations Observer Mission in Georgia
United Nations Office of Project Services
United Nations Research Institute for Social Development
United Nations Relief and Works Agency for Palestine Refugees in the Near East
United Nations Security Council
Untied Nations System Staff College
United Nations Truce Supervision Organization
United Nations University
World Tourism Organization
Universal Postal Union
UK
GB
GBR
826
GBR
.uk
54 36 N
5 55 W
Democratic Republic
0 00 N
25 00 E
of the Congo
49 52 N
6 27 W
54 00 N
2 00 W
55 57 N
3 11 W
52 30 N
1 30 W
Atlantic Ocean
50 20 N
1 00 W
54 00 N
2 00 W
Indian Ocean
6 25 N
94 20 E
The Bahamas
21 00 N
73 20 W
Ethiopia, Kenya
0 30 N
36 00 E
Brunei, Indonesia, Malaysia
2 00 S
110 00 E
56 30 N
6 20 W
51 30 N
0 10 w
Svalbard
78 13 N
15 33 E
54 40 N
6 45 W
59 00 N
3 00 W
57 45 N
7 00 W
57 35 N
13 48 W
57 00 N
4 00 W
60 30 N
1 30 W
52 30 N
3 30 W','92ba23df8019b4813567e720497b93448e5d15554866b315fbb9286c9c139804','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf3193f58438f90cb9e86a5c5b515d6311be35ea8dd448efec6f87b3f115592',2009,'UY','Uruguay','transnational-issues',1277,'Disputes — international: none
Background: Montevideo, founded by
the Spanish in 1726 as a military strong¬
hold, soon took advantage of its natural
harbor to become an important commer¬
cial center. Claimed by Argentina but
annexed by Brazil in 1821, Uruguay
declared its independence four years later
and secured its freedom in 1828 after a
three-year struggle. The administrations
of President Jose BATLLE in the early
20th century established widespread
political, social, and economic reforms
that established a statist tradition. A vio¬
lent Marxist urban guerrilla movement
named the Tupamaros, launched in the
late 1960s, led Uruguay’s president to
cede control of the government to the
military in 1973. By yearend, the rebels
had been crushed, but the military con¬
tinued to expand its hold over the gov¬
ernment. Civilian rule was not restored
until 1985. In 2004, the left-of-center
Frente Amplio Coalition won national
elections that effectively ended 170 years
of political control previously held by the
Colorado and Blanco parties. Uruguay’s
political and labor conditions are among
the freest on the continent.
Disputes — international: in Jan 2007,
ICJ provisionally ruled Uruguay may
begin construction of two paper mills on
the Uruguay River, which forms the
border with Argentina, while the court
examines further whether Argentina has
the legal right to stop such construction
with potential environmental implica-
tions to both countries; uncontested dis¬
pute with Brazil over certain islands in
the Quarai/Cuareim and Invernada
streams and the resulting tripoint with
UY
UY
URY
858
URY
.uv
Howland Island, Jarvis
Island, Johnston Atoll,
Kingman Reef, Midway
Islands, Navassa Island,
Palmyra Atoll, Wake Island
34 53 S
56 11 W
{CHILE)
l
Concepcion^ ARGENTIHA
Bahia Bianca,
Puerto Monti
AO"
\\
Scale 1:35,000,000
Azimuthal Equal-Area Projection
500 Kilometers
I - - - L.
0
"1 1
?00 Miles
\\ Boundary representation is
not necessarily authoritative.
ISO
^ Buenos Aires * ^ ^ . •
La Platd Montevideo
W^J
Mar del Plata
5 0. m | h
A. t Id n 1 1
Q c e a n
. "T
i
Comodoro Rivaddvia
Lagum del Carfidf!
’{lowest pant m Soum Armria) and
the Western Hemisphere -WS ml
i
/
!
j
/
"40
Strait of
■Median
Stanley
Falkland Islands
(Islas Malvinas)
(administered by U.K.,
claimed by AROEHTIHA)
South Georgia and the
South Sandwich islands
(administered by U.h..
4 claimed by AHUCrtHHA)
60
40
SO
828
REFERENCE MAPS
SOUTHEAST ASIA
Hefei.
T , ‘
\\ * fengdu Wuhav
r '' thonM*^ : **
?l«< N*«*$*g>
C H i n A . ''
v; , ; a ., /; Changsha
.ihang
hai
last
Chiiu
Sii
%J JAPAN
i
140
Wei
7 >*•
IP"'' - SsHil ''t***
: f-W; m f I* ■?■? :* if, \\» I - t rs< ,
rn1! f f4#P-rr .- — v ^
h b I - x, < s ’
,4 , BURMA *9™*
^>''abi. ; Il4 • , ,AAe'' X * ttaiphon;
SH . ■■
Manning. '' C
BURMA V :
1C4 aP/t ■ *§ "
ipffc ..-■
. ® r«si
Jaipei
/
Pi
t r'' * Kao-hsiung, ¥ Taiwan
.V fjr “ HOW Konq S..A.R. i Sf
*3# Macau
Okinawa ^
Naha*’ g O- ''
H C
4-
. 0
Miro
SiroTft
, iaAfAfij
heesc oi Canoe
> VS
- ~ I BONIN'' .
o BLANK.
VOLCANO
ISLANDS
S.A.R.
Path el
O.''co CkASWxt''?
^ ANDAMAN
n
r:>T\\;,,e. ''7^7 .
. - '' Hatnrn
. - Dm>
Okine-iari-
slitma
(JAPArij •
: %”4^s .v,r„„c .v„, Xa
| -7, .Hue % PARACEL
UAlLAMD V* \\ \\c* Nang 4‘ , ISiMl1S
Nakhon i :!-
.Ratchasima % VIETNAM
mgkok , - x7S''-f- South
j CAMBODIA Nha ;
'' •"''• nL. 4.. „ . JTf%r
LA I ;Lv> Ho ChiMinh
■I f . Jp*4cRy
• ''if Cg
nwfc>«» Nuy-
* ° BABUYAN ISLANDS
nil p p i n e
5 e a
Jj •■ tn
f''K
i,\\ ‘
Y ''fmT Phukct \\ tsongkhla','52c1da28be1cead37f35b4aef7fb4e642e0bbf89e81f4dfc1f1be0c4c5c25b91','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a77fd81d5badee2ca574e7b11566c2f387415715cea3cfc0668017288bd4e447',2009,'UZ','Uzbekistan','transnational-issues',1282,'Background: Russia conquered
Uzbekistan in the late 19th century. Stiff
resistance to the Red Army after World
War I was eventually suppressed and a
socialist republic set up in 1924- During
the Soviet era, intensive production of
“white gold” (cotton) and grain led to
overuse of agrochemicals and the deple¬
tion of water supplies, which have left
the land poisoned and the Aral Sea and
certain rivers half dry. Independent since
1991, the country seeks to gradually
lessen its dependence on agriculture
while developing its mineral and petro¬
leum reserves. Current concerns include
terrorism by Islamic militants, economic
stagnation, and the curtailment of
human rights and democratization.
Disputes — international: prolonged
drought and cotton monoculture in
Uzbekistan and Turkmenistan creates
water-sharing difficulties for Amu Darya
river states; field demarcation of the
boundaries with Kazakhstan commenced
in 2004; border delimitation of 130 km
of border with Kyrgyzstan is hampered by
serious disputes around enclaves and
other areas
Refugees and internally displaced per¬
sons: refugees (country of origin): 39,202
(Tajikistan); 1,060 (Afghanistan)
IDPs: 3,400 (forced population transfers
by government from villages near
Tajikistan border) (2007)
Trafficking in persons: current situation:
Uzbekistan is a source and, to a lesser
extent, a transit country for women traf¬
ficked to Asia and the Middle East for
the purpose of sexual exploitation;
women from other Central Asian coun¬
tries and China are trafficked through
Uzbekistan; men are trafficked for pur¬
poses of forced labor in the construction
and agricultural industries to Ukraine,
Russia, Kazakhstan, and Kyrgyzstan; men
and women are also trafficked within the
country
tier rating: Tier 3 — Uzbekistan is placed
on Tier 3 because it failed to fulfill com¬
mitments by the country to take addi¬
tional steps during 2005, including the
adoption of comprehensive anti-traf-
ficking legislation, criminal code amend¬
ments to raise trafficking penalties,
support to the country’s first trafficking
shelter, and approval of a national action
plan
Illicit drugs: transit country for Afghan
narcotics bound for Russian and, to a
lesser extent, Western European mar¬
kets; limited illicit cultivation of
cannabis and small amounts of opium
poppy for domestic consumption; poppy
cultivation almost wiped out by govern¬
ment crop eradication program; transit
point for heroin precursor chemicals
bound for Afghanistan
695
Background: Multiple waves of colo¬
nizers, each speaking a distinct language,
migrated to the New Hebrides in the
millennia preceding European explo¬
ration in the 18th century. This settle¬
ment pattern accounts for the complex
linguistic diversity found on the archi¬
pelago to this day. The British and
French, who settled the New Hebrides in
the 19th century, agreed in 1906 to an
Anglo-French Condominium, which
administered the islands until independ¬
ence in 1980, when the new name of
Vanuatu was adopted.
European Bank for Reconstruction and Development (EBRD)
established — 8-9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim — to facilitate the transition of seven centrally planned economies in Europe (Bulgaria, former Czechoslovakia, Hungary,
Poland, Romania, former USSR, and former Yugoslavia) to market economies by committing 60% of its loans to privatization
members — (63) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada,
Croatia, Cyprus, Czech Republic, Denmark, Egypt, EC, European Investment Bank (EIB), Estonia, Finland, France, Georgia,
Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Kyrgyzstan, Latvia, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Malta, Mexico, Moldova, Mongolia, Montenegro, Morocco, Netherlands, NZ, Norway,
Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan,
Ukraine, UK, US, Uzbekistan
European Community (or European Communities, EC)
established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal and Steel
Community (ECSC), the European Economic Community (EEC or Common Market), and to establish a completely integrated
common market and an eventual federation of Europe; merged into the European Union (EU) on 7 February 1992, member
states at the time of merger were Belgium, Denmark, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands,
Portugal, Spain, UK
European Free Trade Association (EFTA)
established — 4 January 1960; effective — 3 May 1960
aim — to promote expansion of free trade
members — (4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB)
established — 25 March 1957; effective — 1 January 1958
aim — to promote economic development of the EU and its predecessors, the EEC and the EC
members— (275) Austria, Belgium, Bulgaria, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia,
Spain, Sweden, UK
European Organization for Nuclear Research (CERN) note — acronym retained from the predecessor organization Conseil
Europeenne pour la Recherche Nucleaire
established — 1 July 1953; effective — 29 September 1954
aim — to foster nuclear research for peaceful purposes only
members — (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Italy,
Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers — (8) EC, India, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific, and Cultural Organization
(UNESCO), US
European Space Agency (ESA)
established — 31 May 1975
aim — to promote peaceful cooperation in space research and technology
members _ (17) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands,
Norway, Portugal, Spain, Sweden, Switzerland, UK
cooperating states — (5) Canada, Czech Republic, Hungary, Poland, Romania
747
THE CIA WORLD FACTBOOK
European Union (EU) note — see European Union entry at the end of the “country” listings First World
another term for countries with advanced, industrialized economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO)
established — 16 October 1945
aim — to raise living standards and increase availability of agricultural products; a UN specialized agency
members — (191) includes all UN member countries except Brunei, Liechtenstein, and Singapore (189 total); plus Cook Islands,
EC, and Niue
former Soviet Union (FSU)
former term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of 15 countries con¬
sists of: Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less
developed countries (LDCs); these countries are in political and economic transition and may well be grouped differently in the
near future; this group of 27 countries consists of: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria,
Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Poland,
Romania, Russia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia; this group is identical to the
IMF group “countries in transition” except for the IMF’s inclusion of Mongolia
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also known as
the Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are included in the IMF’s
“advanced economies” group
Franc Zone (FZ) note — also known as Conference des Ministres des Finances des Pays de la Zone Franc
established — 1964
aim — to form a monetary union among countries whose currencies were linked to the French franc
members — (16) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo, Cote
d’Ivoire, Equatorial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members included Angola, Botswana,
Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT)
see the World Trade Organization (WTO)
General Confederation of Trade Unions (GCTU)
established — 16 April 1992
aim — to consolidate trade union actions to protect citizens’ social and labor rights and interests, to help secure trade unions’
rights and guarantees, and to strengthen international trade union solidarity
members — (11) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan, Ukraine,
Group of 2 (G-2)
informal term that came into use about 1986; to facilitate bilateral economic cooperation between the two most powerful eco¬
nomic giants; members were Japan, US
Group of 3 (G-3)
established — September 1990
aim — mechanism for policy coordination
members — (2) Colombia, Mexico; note — Panama shows interest in joining
Group of 5 (G-5)
established — 22 September 1985
aim — to coordinate the economic policies of five major noncommunist economic powers
members — (5) France, Germany, Japan, UK, US
Group of 6 (G-6)
also known as Groupe des Six Sur le Desarmement (not to be confused with the Big Six) was established in 22 May 1984 with
the aim of achieving nuclear disarmament; its members were Argentina, Greece, India, Mexico, Sweden, Tanzania
Group Of 7 (G-7) note — membership is the same as the Big Seven
established — 22 September 1985
aim to facilitate economic cooperation among the seven major noncommunist economic powers
members — (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
748
INTERNATIONAL ORGANIZATIONS AND GROUPS
Group of 8 (G-8)
established — October 1975
aim — to facilitate economic cooperation among the developed countries (DCs) that participated in the Conference on
International Economic Cooperation (CIEC), held in several sessions between December 1975 and 3 June 1977
members — (8) Canada, France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9)
established — NA
aim — to discuss matters of mutual interest on an informal basis
members — (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Serbia, Sweden
Group Of 10 (G-10) note — also known as the Paris Club; includes the wealthiest members of the IMF who provide most of the
money to be loaned and act as the informal steering committee; name persists despite increased membership
established — October 1962
aim — to coordinate credit policy
members— (11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
observers — (4) BIS, EU, IMF, OECD
Group of 11 (G-ll) note — also known as the Cartagena Group
established in 21-22 June 1984, in Cartagena, Colombia, aim was to provide a forum for largest debtor nations in Latin
America; members were: Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay,
Venezuela
Group Of 15 (G-15) note — byproduct of the Nonaligned Movement; name persists despite increased membership
established — September 1989
aim — to promote economic cooperation among developing nations; to act as the main political organ for the Nonaligned
Movement
members — (17) Algeria, Argentina, Brazil, Chile, Egypt, India, Indonesia, Jamaica, Kenya, Malaysia, Mexico, Nigeria, Peru,
Senegal, Sri Lanka, Venezuela, Zimbabwe
Group of 24 (G-24)
established — 1 August 1989
aim — to promote the interests of developing countries in Africa, Asia, and Latin America within the IMF
members — (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d’Ivoire, Egypt, Ethiopia, Gabon,
Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, South Africa, Sri Lanka, Syria, Trinidad
and Tobago, Venezuela
observers — (1) China
Group of 77 (G-77)
established— 15 Junel964; October 1967 first ministerial meeting
aim — to promote economic cooperation among developing countries; name persists in spite of increased membership
members — ( 1 29 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina,
The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d Ivoire, Cuba, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia,
Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan,
Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall
Islands, Mauritania, Mauritius, Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uruguay, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
Gulf Cooperation Council (GCC) note — also known as the Cooperation Council for the Arab States of the Gulf
established — 25 May 1981
aim — to promote regional cooperation in economic, social, political, and military affairs
members — (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
Organization for Democracy and Economic Development (GUAM) note-acronym standing for the member countries, Georgia,
Ukraine, Azerbaijan, Moldova; formerly known as GUUAM before Uzbekistan withdrew in 5 May 2005
established — 7 June 2001
aim _ commits the countries to cooperation and assistance in social and economic development, the strengthening and broad¬
ening of trade and economic relations, and the development and effective use of transport and communications, highways, and
related infrastructure crossing the boundaries of the member states
members — (4) Azerbaijan, Georgia, Moldova, Ukraine
749
THE CIA WORLD FACTBOOK
high income countries
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC)
established — 21 December 1982
aim — to organize and promote regional cooperation in all sectors, especially economic
members — (5) Comoros, France (for Reunion and Mayotte), Madagascar, Mauritius, Seychelles
industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (IADB) note — also known as Banco Interamericano de Desarrollo (BID)
established — 8 April 1959; effective — 30 December 1959
aim — to promote economic and social development in Latin America
members — (47) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa
Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany, Guatemala, Guyana, Haiti,
Honduras, Israel, Italy, Jamaica, Japan, South Korea, Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru,
Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US, Uruguay, Venezuela
Inter-Govemmental Authority on Development (IGAD) note — formerly known as Inter-Governmental Authority on Drought
and Development (IGADD)
established — 15-16 January 1986 as the Inter-Governmental Authority on Drought and Development; revitalized — 21 March
1996 as the Inter-Govemmental Authority on Development
aim — to promote a social, economic, and scientific community among its members
members — (6) Djibouti, Ethiopia, Kenya, Somalia, Sudan, Uganda; note — Eritrea declared its suspension in 2007
Inter-Parliamentary Union (IPU)
established — 1889
aim — fosters contacts among parliamentarians, considers and expresses views of international interest and concern with the pur¬
pose of bringing about action by parliaments and parliamentarians, contributes to the defense and promotion of human rights,
contributes to better knowledge of representative institutions
members — (146) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain,
Bangladesh, Belarus, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kazahstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Liberia, Libya, Lichtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia,
Maldives, Mali, Malta, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Somalia, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tanzania, Tajikistan, Thailand, Togo, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, Uruguay, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
associate members (7) Andean Parliament, Central American Parliament, Community Parliament of the Economic Community
of West African States, East African Legislative Assembly, European Parliament, Latin American Parliament, Parliamentary
Assembly of the Council of Europe
International Atomic Energy Agency (IAEA)
established — 26 October 1956; effective — 29 July 1957
aim — to promote peaceful uses of atomic energy
members — (144) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Cameroon,
Canada, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia,
Ethiopia, Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan,
Latvia, Lebanon, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note — Montenegro’s membership pending on completion
of procedures required to become an IAEA Member State
International Bank for Reconstruction and Development (IBRD) note— also known as the World Bank
established — 22 July 1944; effective — 27 December 1945
to provide economic development loans; a UN specialized agency
members (185) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco, Nauru, and
uz
UZ
UZB
860
UZB
.uz
Taiwan
23 30 N
121 00 E
Pacific Ocean
24 00 N
119 00 E
41 20 N
69 18 E
Pacific Ocean
4 30 S
168 00 E
41 20 N
69 18 E
Egypt, Syria
Nukus
!’>U\\OIO
<34 RA &WM
Ashgabat jyiary
*
Crete
M emter nnem : Sea
Herat
AEG.
, . >
i \\ / .Ah vaz -7 r
AnNasiriyah"— 40Ahf^„; Kerm'',n''
Ai Basrah ../ zafteaan \\
‘Shiraz PAK''
... ★ Kuwait BOshchr HHI
• ''WWAIT * . .
• : v, i i ^ b
MNI
S /','34e19ebf5e74ea25635950ea7dada890469ad45bf853e420f836d0b0d290f3af','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea7ea84a4390b81b950ab83987962d5e61c3084c961bfd9576968a664e9f6f3',2009,'YE','Yemen','transnational-issues',1308,'Disputes — international: Saudi Arabia
has reinforced its concrete-filled security
barrier along sections of the fully demar¬
cated border with Yemen to stem illegal
cross-border activities
Refugees and internally displaced per¬
sons: refugees (country of origin): 91,587
(Somalia) (2007)
721
TANZANIA
DEMOCRATIC :
REPUBLIC OF THE
United Nations Mission in the Central African Republic and Chad (MINURCAT)
established — 25 September 2007
aim — to create the security and conditions which will to contribute to the protection of refugees, displaced persons, and citizens
in danger, to facilitate the provision of humanitarian assistance in eastern Chad and the northeastern Central African Republic,
to create favorable conditions for the recontruction and economic and social development of these areas
members — (3) France, Senegal, Sweden
United Nations Mission in Ethiopia and Eritrea (UNMEE)
established — 31 July 2000
aim — to monitor the cessation of hostilities
members — (44) Algeria, Austria, Bangladesh, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, China, Croatia, Czech Republic,
Denmark, Finland, France, The Gambia, Germany, Ghana, Greece, Guatemala, India, Iran, Jordan, Kenya, Kyrgyzstan,
Malaysia, Namibia, Nepal, Nigeria, Norway, Pakistan, Paraguay, Peru, Poland, Romania, Russia, South Africa, Spain, Sri Lanka,
Sweden, Tanzania, Tunisia, Ukraine, US, Uruguay, Zambia
United Nations Mission in Liberia (UNMIL)
established — 19 September 2003
aim — to support the cease-fire agreement and peace process, protect UN facilities and people, support humanitarian activities,
and assist in national security reform
note — helps train and organize national police force
United Nations Mission in Sierra Leone (UNAMSIL)
established on 22 October 1999; aim was to to cooperate with the Government of Sierra Leone and the other parties to the
Peace Agreement in the implementation of the agreement; to monitor the military and security situation in Sierra Leone; to
monitor the disarmament and demobilization of combatants and members of the Civil Defense Forces (CFD); to assist in moni¬
toring respect for international humanitarian law; mandate ended 31 December 2005; members were Bangladesh, Bolivia,
China, Croatia, Czech Republic, Egypt, The Gambia, Germany, Ghana, Guinea, Indonesia, Jordan, Kenya, Kyrgyzstan,
Malaysia, Nepal, Nigeria, Pakistan, Russia, Slovakia, Sweden, Tanzania, Thailand, Ukraine, UK, Uruguay, Zambia
United Nations Mission in the Sudan (UNMIS)
established — March 2005
aim — to support implementation of the comprehensive Peace Agreement by Monitoring and verifying the implementation of
the Cease Fire Agreement, by observing and monitoring movements of armed groups, and by helping disarm, demobilizing and
reintegrating armed bands
members — (59) Australia, Bangladesh, Benin, Bolivia, Botswana, Brazil, Burkina Faso, Cambodia, Canada, China, Croatia,
Denmark, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon, Germany, Greece, Guatemala, Guinea, India, Indonesia, Jordan,
Kenya, South Korea, Kyrgyzstan, Malawi, Malaysia, Mali, Moldova, Mongolia, Mozambique, Namibia, Nepal, Netherland, NZ,
Nigeria, Norway, Pakistan, Paraguay, Peru, Philippines, Poland, Romania, Russia, Rwanda, Sri Lanka, Sweden, Tanzania,
Thailand, Turkey, Uganda, Ukraine, UK, Yemen, Zambia, Zimbabwe
United Nations Mission of Support in East Timor (UNMISET)
established on 17 May 2002 to provide assistance to structures critical to public security and to assist in the development of law
enforcement agencies; to contribute to extenal security; members were Australia, Bangladesh, Bolivia, Brazil, Denmark, Fiji,
Jordan, Malaysia, Mozambique, Nepal, NZ, Pakistan, Philippines, Portugal, Russia, Sweden; completed its mandate 20 May 2005
United Nations Monitoring, Verification, and Inspection Commission (UNMOVIC)
formerly known as United Nations Special Commission for the Elimination of Iraq’s Weapons of Mass Destruction (UNSCOM);
established December 1999 with the aim to identify, account for, and eliminate Iraq’s weapons of mass destruction and the
capacity to produce them; commissioners were from Argentina, Brazil, Canada, China, UN Department for Disarmament
Affairs, France, Germany, India, Japan, Mexico, Nigeria, Russia, Senegal, Ukraine, UK, US; finished operations 29 June 2007
United Nations Observer Mission in Georgia (UNOMIG)
established — 24 August 1993
aim — to verify compliance with the cease-fire agreement, to monitor weapons exclusion zone, and to supervise CIS peacekeeping
force for Abkhazia; established by the UN Security Council
members — (32) Albania, Austria, Bangladesh, Croatia, Czech Republic, Denmark, Egypt, France, Germany, Ghana, Greece,
Hungary, India, Indonesia, Jordan, South Korea, Lithuania, Moldova, Mongolia, Nepal, Nigeria, Pakistan, Poland, Romania,
Russia, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay, Yemen
United Nations Operation in Burundi (ONUB)
was established 21 May 2004 to support and help implement the efforts undertaken by Burundians to restore lasting peace and
bring about national reconciliation; members were Algeria, Bangladesh, Belgium, Benin, Bolivia, Burkina Faso, Chad, China,
764
INTERNATIONAL ORGANIZATIONS AND GROUPS
Egypt, Ethiopia, Gabon, The Gambia, Ghana, Guatemala, Guinea, India, Jordan, Kenya, South Korea, Kyrgyzstan, Malawi,
Malaysia, Mali, Mozambique, Nambia, Nepal, Netherlands, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines, Portugal,
Romania, Russia, Senegal, Serbia, South Africa, Spain, Sri Lanka, Thailand, Togo, Tunisia, Uruguay, Yemen, Zambia; mandate
was completed 3 1 December 2006
United Nations Organization Mission in the Democratic Republic of the Congo (MONUC)
established — 30 November 1999
aim — to establish contacts with the signatories to the cease-fire agreement and to plan for the observation of the cease-fire and
disengagement of forces
members — (18) Bangladesh, Benin, Bolivia, China, Ghana, Guatemala, India, Indonesia, Jordan, Malawi, Morocco, Nepal,
Pakistan, Senegal, Serbia, South Africa, Tunisia, Uruguay
United Nations Operation in Cote d''Ivoire (UNOCI)
established — 27 February 2004
aim — to facilitate the implementation by the Ivorian parties of the peace agreement signed by them in January 2003
members — (43) Bangladesh, Benin, Bolivia, Brazil, Chad, China, Croatia, Dominican Republic, Ecuador, El Salvador, Ethiopia,
France, The Gambia, Ghana, Guatemala, Guinea, India, Ireland, Jordan, Kenya, Moldova, Morocco, Namibia, Nepal, Niger,
Nigeria, Pakistan, Paraguay, Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia, Tanzania, Togo, Turkey, Uganda,
Uruguay, Yemen, Zambia, Zimbabwe
United Nations Peace-keeping Force in Cyprus (UNFICYP)
established — 4 March 1964
aim — to serve as a peacekeeping force between Greek Cypriots and Turkish Cypriots in Cyprus; established by the UN Security
Council
members — (16) Argentina, Australia, Austria, Bolivia, Brazil, Canada, Chile, Finland, Hungary, Ireland, South Korea, Paraguay,
Peru, Slovakia, UK, Uruguay
United Nations Population Fund (UNFPA) note — acronym retained from predecessor organization UN Fund for Population
Activities
established — July 1967
aim — to assist both developed and developing countries to deal with their population problems
members (executive board) — (36) selected on a rotating basis from all regions
United Nations Relief and Works Agency for Palestine Refugees in the Near East (UNRWA)
established — 8 December 1949
aim — to provide assistance to Palestinian refugees
members (advisory commission) — (22) Australia, Belgium, Canada, Denmark, EC, Egypt, France, Germany, Italy, Japan, Jordan,
Lebanon, Netherlands, Norway, Saudi Arabia, Spain, Sweden, Switzerland, Syria, Turkey, UK, US
United Nations Research institute for Social Development (UNRISD)
established — 1963
aim — to conduct research into the problems of economic development during different phases of economic growth
members — no country members, but a Board of Directors consisting of a chairman appointed by the UN secretary general and 10
individual members
United Nations Secretariat
established — 26 June 1945; effective — 24 October 1945
aim — to serve as the primary administrative organ of the UN; a Secretary General is appointed for a five-year term by the
General Assembly on the recommendation of the Security Council
members — the UN Secretary General and staff
United Nations Security Council (UNSC)
established — 26 June 1945; effective — 24 October 1945
aim — to maintain international peace and security
permanent members — (5) China, France, Russia, UK, US
nonpermanent members — (10) elected for two-year terms by the UN General Assembly; Belgium (2007-08), Burkina Faso
(2008-09), Costa Rica (2008-09), Croatia (2008-09), Indonesia (2007-08), Italy (2007-08), Libya (2008-09), Panama
(2007-08), South Africa (2007-08), Vietnam (2008-09)
United Nations Stabilization Mission in Haiti (MINUSTAH)
established — 30 April 2004
aim — to stabilize Haiti in many areas for at least six months
members — (17) Argentina, Bolivia, Brazil, Canada, Chile, Croatia, Ecuador, France, Guatemala, Jordan, Nepal, Pakistan, Peru,
Philippines, Sri Lanka, US, Uruguay
United Nations Truce Supervision Organization (UNTSO)
established — June 1948
aim — to supervise the 1948 Arab-Israeli cease-fire; currently supports timely deployment of reinforcements to other peace¬
keeping operations in the region as needed; initially established by the UN Security Council
765
THE CIA WORLD FACTBOOK
members — (23) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France, Ireland, Italy,
Nepal, Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 11 UN trust territories; mem¬
bers were China, France, Russia, UK, US; it formally suspended operations 1 November 1995 after the Trust Territory of the
Pacific Islands (Palau) became the Republic of Palau, a constitutional government in free association with the US; the
Trusteeship Council was not dissolved
United Nations University (UNU)
established — 3 December 1973
aim — to conduct research in development, welfare, and human survival and to train scholars
members — (24 members of UNU Council and the Rector are appointed by the Secretary General of the United Nations and the
Director General of UNESCO)
Universal Postal Union (UPU)
established — 9 October 1874, affiliated with the UN 15 November 1947; effective — 1 July 1948
aim — to promote international postal cooperation; a UN specialized agency
members — (191) includes all UN member countries except Andorra, Marshall Islands, Federated States of Micronesia, and Palau
(189 total); plus Holy See and Overseas Territories of the UK; note — includes the following dependencies or areas of special
interest: Australia (Norfolk Island), China (Hong Kong, Macau), Denmark (Faroe Islands, Greenland), France (French
Polynesia, French Southern and Antarctic Lands, Mayotte, New Caledonia, Saint Barthelemy, Saint Martin, Saint Pierre and
Miquelon, Wallis and Futuna), Netherlands (Aruba, Netherlands Antilles), NZ (Cook Island, Niue, Tokelau), UK (Guernsey,
Isle of Man, Jersey; Anguilla, Bermuda, British Indian Ocean Territory, British Virgin Islands, Cayman Islands, Falkland Islands,
Gibraltar, Montserrat, Pitcairn Islands, Saint Helena, South Georgia and South Sandwich Islands, Turks and Caicos), US
(American Samoa, Guam, Northern Mariana Islands, Puerto Rico, Virgin Islands)
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member states at the
time of dissolution were: Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier members included
German Democratic Republic (GDR) and Albania
West African Development Bank (WADB) note — also known as Banque Ouest-Africaine de Developpement (BOAD); is a
financial institution of WAEMU
established — 14 November 1973
aim — to promote regional economic development and integration
regional members — (9) Central Bank of West African States, Benin, Burkina Faso, Cote d’Ivoire, Guinea-Bissau, Mali, Niger,
Senegal, Togo
intemational/nonregional members — (6) African Development Bank, Belgium, European Investment Bank, France, Germany,
People’s Bank of China
West African Economic and Monetary Union (WAEMU) note — also known as Union Economique et Monetaire Ouest Africaine
(UEMOA)
established — 1 August 1994
aim — to increase competitiveness of members’ economic markets; to create a common market
members — (8) Benin, Burkina Faso, Cote d’Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
Western European Union (WEU)
established — 23 October 1954; effective — 6 May 1955
aim — to provide mutual defense and to move toward political unification
members — (10) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members — (6) Czech Republic, Hungary, Iceland, Norway, Poland, Turkey
associate partners — (7) Bulgaria, Estonia, Latvia, Lithuania, Romania, Slovakia, Slovenia
observers — (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association (IDA),
International Finance Corporation (IFC), and Multilateral Investment Guarantee Agency (MIGA)
World Confederation of Labor (WCL)
established — 19 June 1920 as the International Federation of Christian Trade Unions (IFCTU), renamed 4 October 1968
aim — to promote the trade union movement
members — (105 national organizations) Antigua and Barbuda, Argentina, Aruba, Austria, Bangladesh, Belgium, Belize, Benin,
Bolivia, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic, Chad, Chile, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Dominican Republic, Ecuador, El Salvador, France, French Guiana, Gabon, The Gambia, Ghana, Guadeloupe, Guatemala,
Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia, Iran, Italy, Japan, Kazakhstan, South Korea, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Malta, Martinique, Mauritania,
Mauritius, Mexico, Morocco, Namibia, Nepal, Netherlands, Netherlands Antilles, Nicaragua, Niger, Pakistan, Panama,
766
INTERNATIONAL ORGANIZATIONS AND GROUPS
Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Lucia, Saint Vincent and the Grenadines,
Sao Tome and Principe, Senegal, Serbia, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname,
Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam, Zambia, Zimbabwe
World Customs Organization (WCO) note — began as the Customs Cooperation Council (CCC)
established — 15 December 1950
aim — to promote international cooperation in customs matters
members — (172) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Benin, Bermuda, Bhutan, Bolivia, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, EC, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Lucia, Samoa, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
World Federation of Trade Unions (WFTU)
established — 3 October 1945
aim — to promote the trade union movement
members — (125 and the Palestine Liberation Organization) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Cambodia, Cameroon, Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d’Ivoire, Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea,
Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana, Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea, Kuwait,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico,
Mozambique, Nepal, New Caledonia, NZ, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines,
Poland, Portugal, Puerto Rico, Reunion, Romania, Russia, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden,
Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP)
established — 24 November 1961
aim — to provide food aid in support of economic development or disaster relief; an ECOSOC organization
members — (36) selected on a rotating basis from all regions
World Health Organization (WHO)
established — 22 July 1946; effective — 7 April 1948
aim — to deal with health matters worldwide; a UN specialized agency
members — (193) includes all UN member countries except Liechtenstein (191 total); plus Cook Islands and Niue
World Intellectual Property Organization (WIPO)
established — 14 July 1967; effective — 26 April 1970
aim — to furnish protection for literary, artistic, and scientific works; a UN specialized agency
members — (184) includes all UN member countries except Kiribati, Marshall Islands, Federated States of Micronesia, Nauru,
Palau, Solomon Islands, Timor-Leste, Tuvalu, Vanuatu (182 total); plus Holy See
World Meteorological Organization (WMO)
established — 11 October 1947; effective — 4 April 1951
aim — to sponsor meteorological cooperation; a UN specialized agency
members — (188) includes all UN member countries except Andorra, Equatorial Guinea, Grenada, Liechtenstein, Marshall
Islands, Nauru, Palau, Saint Kitts and Nevis, Saint Vincent and the Grenadines, San Marino, Tuvalu (181 total); plus Aruba
and the Netherlands Antilles, Cook Islands, French Polynesia, Hong Kong, Macau, New Caledonia, and Niue
World Tourism Organization (UNWTO)
established — 2 January 1975
aim — to promote tourism as a means of contributing to economic development, international understanding, and peace
members — (153) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Belarus, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
767
THE CIA WORLD FACTBOOK
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Iraq, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Libya, Lithuania, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members— ( 7) Aruba, Flanders, Hong Kong, Macau, Madeira Islands, Netherlands Antilles, Puerto Rico
observers — (1 plus Palestine Liberation Organization) Holy See, Palestine Liberation Organization
World Trade Organization (WTO) note — succeeded General Agreement on Tariff and Trade (GATT)
established — 15 April 1994; effective — 1 January 1995
aim — to provide a forum to resolve trade conflicts between members and to carry on negotiations with the goal of further low¬
ering and/or eliminating tariffs and other trade barriers
members — (151) Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, EC, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho, Liechtenstein,
Lithuania, Luxembourg, Macau, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Venezuela, Vietnam, Zambia,
YM
YE
YEM
887
YEM
.ws
.ye
.zm
see Samoa
the Factbook uses the W dan
code from DIAM 65-18
Geopolitical Data Elements
and Related Features, Data
Standard No. 3, December
1994, published by the
Defense Intelligence Agency
Zaire
12 46 N
45 01 E
Indian Ocean
12 30 N
48 00 E
United States (Alaska)
57 44 N
134 20 W
15 00 N
48 00 E
15 00 N
50 00 E
15 21 N
42 34 E
Russia
56 00 N
160 00 E
15 00 N
44 00 E
Atlantic Ocean
25 40 N
77 09 W
1','2190cbc0fc57740682fd10ffee58425867dfa79c4fce7f2be560d8ec52c7f309','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b43fb1e5bbd65a60127da7315e81d24e214e4297500c5eb982cc722f7d012af',2009,'YE','Yemen','transnational-issues',1309,'2 39 N
43 25 E
Pacific Ocean
44 45 N
142 00 E
Iran
32 00 N
53 00 E
Indian Ocean
27 00 N
51 00 E
15 21 N
44 12 E
Montenegro, Serbia
43 05 N
19 45 E
Bolivia
17 48 S
63 10W
12 30 N
54 00 E
MOON
48 00 E
15 00 N
44 00 E
MOON
46 00 E
Sanaa , ■
Omtiurman,
Khartoum i
.Praia i fMAglS
P afeaW srtrti
Banjul J LjiCx
the Gambia
Bissau# S
CtUIN EA Rl SSAI * ,
f Conakry^.
Freetown *
SIERRA LEO
Agarics''
A ramrt
/i inter
Socotra
tYWtEfl)
Kano,
MKiLKI \\
* Abuja mou
COTt
D''IVOIRE
CENTKAI MKK..\\>
REPUBLIC.
IMALIA
Monrovia #,
Portc-
N’ovo','ddf8f632dafbe04ac7eb849e7c658182776fe95ab2a53fc2c9f3b5e1aee65b78','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34381fd069d9bbdabc1995827afdb413be8649a2f045913554dc56a0b1d9005a',2009,'BW','Botswana','transnational-issues',1310,'A NO Cl LA I SfllWK
$ 5 H
Background: The territory of Northern
Rhodesia was administered by the
[British] South Africa Company from
1891 until it was taken over by the UK
in 1923. During the 1920s and 1930s,
advances in mining spurred development
and immigration. The name was
changed to Zambia upon independence
in 1964. In the 1980s and 1990s,
declining copper prices and a prolonged
drought hurt the economy. Elections in
1991 brought an end to one-party rule,
but the subsequent vote in 1996 saw bla¬
tant harassment of opposition parties.
The election in 2001 was marked by
administrative problems with three par¬
ties filing a legal petition challenging the
election of ruling party candidate Levy
MWANAWASA. The new president
launched an anticorruption investiga¬
tion in 2002 to probe high-level corrup¬
tion during the previous administration.
In 2006-07, this task force successfully
prosecuted four cases, including a land¬
mark civil case in the UK in which
former President CHILUBA and
numerous others were found liable for
USD 41 million. MWANAWASA was
reelected in 2006 in an election that was
deemed free and fair.
Location: Southern Africa, east of
BC
BW
BWA
072
BWA
.bw
22 00 S
24 00 E
24 45 S
25 55 E','23d29107a838fac17093592ce262e4dba7526f26a0b49e2d4008fcde0e866d1e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4c795f18c658720aa0c6779f6643803e8d07a47dea5d6ab52233142a3e2ef59',2009,'ZM','Zambia','transnational-issues',1315,'Disputes— international: in 2004,
Zimbabwe dropped objections to plans
between Botswana and Zambia to build a
bridge over the Zambezi River, thereby
de facto recognizing a short, but not
clearly delimited, Botswana-Zambia
boundary in the river; 42,250 Congolese
refugees in Zambia are offered voluntary
repatriation in November 2006, most of
whom are expected to return in the next
two years; Angolan refugees too have
been repatriating but 26,450 still remain
with 90,000 others from other neigh¬
boring states in 2006
Refugees and internally displaced per¬
sons: refugees (country of origin): 42,565
(Angola); 60,874 (Democratic Republic
of the Congo); 4,100 (Rwanda) (2007)
Illicit drugs: transshipment point for
moderate amounts of methaqualone,
small amounts of heroin, and cocaine
bound for southern Africa and possibly
Europe; a poorly developed financial
infrastructure coupled with a govern¬
ment commitment to combating money
laundering make it an unattractive
venue for money launderers; major con¬
sumer of cannabis
Convention on the Conservation of Antarctic Marine Living Resources
note — abbreviated as Antarctic-Marine Living Resources
opened for signature— 5 May 1980
entered into force — 7 April 1982
objective — to safeguard the environment and protect the integrity of the ecosystem of the seas surrounding Antarctica, and to
conserve Antarctic marine living resources
parties — (31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, EU, Finland, France, Germany, Greece, India, Italy,
Japan, South Korea, Mauritius, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain, Sweden,
Ukraine, UK, US, Uruguay, Vanuatu
Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
note — abbreviated as Endangered Species
opened for signature — 3 March 1973
entered into force — 1 July 1975
objective — to protect certain endangered species from overexploitation by means of a system of import/export permits
parties — (168) Afghanistan, Albania, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
South Korea, Kuwait, Laos, Latvia, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Palau, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
note — abbreviated as Marine Dumping
opened for signature — 29 December 1972
entered into force — 30 August 1975
objective — to control pollution of the sea by dumping and to encourage regional agreements supplementary to the Convention;
the London Convention came into force in 1996
parties — (88) Afghanistan, Angola, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados, Belarus, Belgium, Bolivia,
Brazil, Bulgaria, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Equatorial Guinea, Finland, France, Gabon, Germany, Greece,
Guatemala, Haiti, Honduras, Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan,
Kenya, Kiribati, South Korea, Libya, Luxembourg, Malta, Mexico, Monaco, Montenegro, Morocco, Nauru, Netherlands, NZ,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Serbia, Seychelles, Slovenia, Solomon Islands, South
Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Trinidad and Tobago, Tunisia, Ukraine, UAE, UK, US, Vanuatu
associate members to the London Convention — (2) Faroe Islands, Macau countries that have signed, but not yet ratified (3) Chad,
Kuwait, Uruguay
771
THE CIA WORLD FACTBOOK
Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
note — abbreviated as Environmental Modification
opened for signature — 10 December 1976
entered into force — 5 October 1978
objective — to prohibit the military or other hostile use of environmental modification techniques in order to further world peace
and trust among nations
parties — (68) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Bangladesh, Belarus, Belgium, Benin,
Brazil, Brunei, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Egypt,
Finland, Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea, South Korea, Kuwait, Laos,
Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway, Pakistan, Papua New Guinea, Poland, Romania, Russia, Saint
Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden,
Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified — (17) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran,
Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria, Turkey, Uganda
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/or
Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling
note — abbreviated as Whaling
opened for signature — 2 December 1946
entered into force — 10 November 1948
objective — to protect all species of whales from overhunting; to establish a system of international regulation for the whale fish¬
eries to ensure proper conservation and development of whale stocks; and to safeguard for future generations the great natural
resources represented by whale stocks
parties — (72) Antigua and Barbuda, Argentina, Australia, Austria, Belgium, Belize, Benin, Brazil, Cambodia, Cameroon, Chile,
China, Costa Rica, Cote D’Ivoire, Croatia, Czech Republic, Denmark, Dominica, Finland, France, Gabon, The Gambia,
Germany, Grenada, Guatemala, Guinea, Hungary, Iceland, India, Ireland, Israel, Italy, Japan, Kenya, Kiribati, South Korea, Mali,
Marshall Islands, Mauritania, Mexico, Monaco, Mongolia, Morocco, Nauru, Netherlands, NZ, Nicaragua, Norway, Oman, Palau,
Panama, Peru, Philippines, Portugal, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino,
Senegal, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Togo, Tuvalu, UK, US
International Tropical Timber Agreement, 1983
note — abbreviated as Tropical Timber 83
opened for signature — 18 November 1983
entered into force — 1 April 1985; this agreement expired when the International Tropical Timber Agreement, 1994, went into force
objective — to provide an effective framework for cooperation between tropical timber producers and consumers and to encourage
the development of national policies aimed at sustainable utilization and conservation of tropical forests and their genetic
resources
parties — (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany,
Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal,
Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal, Russia, Spain, Sweden, Switzerland,
Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement, 1994 note — abbreviated as Tropical Timber 94
opened for signature — 26 January 1994
entered into force — 1 January 1997
objective — to ensure that by the year 2000 exports of tropical timber originate from sustainably managed sources; to establish a
fund to assist tropical timber producers in obtaining the resources necessary to reach this objective
parties — (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African Republic,
China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji,
Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea,
Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Uruguay, Vanuatu, Venezuela
772
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Kyoto Protocol to the United Nations Framework Convention on Climate Change
note — abbreviated as Climate Change-Kyoto Protocol
opened for signature — 16 March 1998
entered into force — 23 February 2005
objective — to further reduce greenhouse gas emissions by enhancing the national programs of developed countries aimed at this
goal and by establishing percentage reduction targets for the developed countries
parties — (181) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cental African Republic, Chile,
China, Colombia, Comoros, Cote d’Ivoire, Democratic Republic of the Congo, Republic of the Congo, Cook Island, Costa Rica,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified — (4) Kazakhstan, US
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer note — abbreviated as Ozone Layer Protection
opened for signature — 16 September 1987
entered into force — 1 January 1989
objective — to protect the ozone layer by controlling emissions of substances that deplete it
parties — (189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
note — abbreviated as Ship Pollution
opened for signature — 17 February 1978
entered into force — 2 October 1983
773
THE CIA WORLD FACTBOOK
objective — to preserve the marine environment through the complete elimination of pollution by oil and other harmful sub¬
stances and the minimization of accidental discharge of such substances
parties — (139) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Cape Verde, Chile,
China, Colombia, Comoros, Republic of Congo, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, Equatorial Guinea, Estonia, Faroe Islands, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia,
Lithuania, Luxembourg, Libya, Macau, Madagascar, Malawi, Malaysia, Maldives, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Netherlands, NZ, Nicaragua, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Qatar Romania, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam
Protocol on Environmental Protection to the Antarctic Treaty note — abbreviated as Antarctic-Environmental Protocol
opened for signature — 4 October 1991
entered into force — 14 January 1998
objective — to provide for comprehensive protection of the Antarctic environment and dependent and associated ecosystems;
applies to the area covered by the Antarctic Treaty
consultative parties — (31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, China, Czech Republic, Ecuador,
Finland, France, Germany, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Romania, Russia, South
Africa, Spain, Sweden, Ukraine, UK, US, Uruguay
non consultative parties — (12) Austria, Colombia, Cuba, Denmark, Greece, Guatemala, Hungary, North Korea, Papua New
Guinea, Slovakia, Switzerland, Turkey
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of
Nitrogen Oxides Or Their TransbOUndary Fluxes note— abbreviated as Air Pollution-Nitrogen Oxides
opened for signature — 31 October 1988
entered into force — 14 February 1991
objective — to provide for the control or reduction of nitrogen oxides and their transboundary fluxes
parties — (31) Austria, Belarus, Belgium, Bulgaria, Canada, Cyprus, Czech Republic, Denmark, Estonia, EU, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Liechtenstein, Lithuania, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified — ( 1 ) Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of
Volatile Organic Compounds or Their Transboundary Fluxes note — abbreviated as Air Pollution- Volatile Organic Compounds
opened for signature — 18 November 1991
entered into force — 29 September 1997
objective — to provide for the control and reduction of emissions of volatile organic compounds in order to reduce their trans¬
boundary fluxes so as to protect human health and the environment from adverse effects
parties — (21) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified — (6) Canada, EU, Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur Emissions
note — abbreviated as Air Pollution-Sulphur 94
opened for signature — 14 June 1994
entered into force — 5 August 1998
objective — to provide for a further reduction in sulfur emissions or transboundary fluxes
parties — (27) Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, EU, Finland, France, Germany,
Greece, Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified — (3) Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
note — abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature — 24 June 1998
entered into force — 23 October 2003
objective — to provide for the control and reduction of emissions of persistent organic pollutants in order to reduce their trans¬
boundary fluxes so as to protect human health and the environment from adverse effects
parties — (27) Austria, Belgium, Bulgaria, Canada, Cyprus, Czech Republic, Denmark, Estonia, EU, Finland, France, Germany,
Hungary, Iceland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg, Moldova, Netherlands, Norway, Romania, Slovakia,
Sweden, Switzerland, UK
countries that have signed, but not yet ratified — (10) Armenia, Croatia, Greece, Ireland, Philippines Poland, Portugal, Spain,
Ukraine, US
774
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur Emissions or
Their Transboundary Fluxes by at Least 30% note — abbreviated as Air Pollution-Sulphur 85
opened for signature — 8 July 1985
entered into force — 2 September 1987
objective — to provide for a 30% reduction in sulfur emissions or transboundary fluxes by 1993
parties — (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland, France, Germany,
Hungary, Italy, Fiechtenstein, Fuxembourg, Netherlands, Norway, Russia, Slovakia, Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space, and Under Water
note — abbreviated as Nuclear Test Ban
opened for signature — 5 August 1963
entered into force — 10 October 1963
objective — to obtain an agreement on general and complete disarmament under strict international control in accordance with
the objectives of the United Nations; to put an end to the armaments race and eliminate incentives for the production and
testing of all kinds of weapons, including nuclear weapons
parties — (113) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas, Bangladesh, Belgium,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma, Canada, Central African Republic, Chad,
China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cyprus, Czech Republic, Denmark,
Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Liberia, Luxembourg, Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Poland, Romania,
Russia, Rwanda, Samoa, San Marino, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, UK, US, Venezuela, Zambia
countries that have signed, but not yet ratified — (17) Algeria, Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya,
Mali, Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam, Yemen
Tropical Timbe','14b02d51634a8a5d2e1936b6f8c2fa8e6f528d7350ac496462d8c404425d2f6c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fceae7f37381f1fee515f5db0de981e897668aabb42dbef6566e51667a6ba51',2009,'ZM','Zambia','transnational-issues',1316,'r 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS) note — abbreviated as Law of the Sea
opened for signature — 10 December 1982
entered into force — 16 November 1994
objective — to set up a comprehensive new legal regime for the sea and oceans; to include rules concerning environmental stan-
dards as well as enforcement provisions dealing with pollution of the marine environment
parties— ( 155) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Cameroon, Canada, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Egypt, Equatorial
Guinea, Estonia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan,
Kenya, Kiribati, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Lithuania, Luxembourg, Macedonia, Madagascar,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria, Niue,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, Ukraine, UK, Uruguay,
Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified — (27) Afghanistan, Bangladesh, Bhutan, Burundi, Cambodia, Central African
Republic, Chad, Colombia, Republic of the Congo, Dominican Republic, El Salvador, Ethiopia, Iran, North Korea, Lesotho,
Liberia, Libya, Liechtenstein, Madagascar, Malawi, Morocco, Niger, Rwanda, Swaziland, Switzerland, Thailand, UAE
United Nations Convention to Combat Desertification in Those Countries Experiencing Serious Drought and/or
Desertification, Particularly in Africa note — abbreviated as Desertification
opened for signature — 14 October 1994
entered into force — 26 December 1996
objective — to combat desertification and mitigate the effects of drought through national action programs that incorporate long¬
term strategies supported by international cooperation and partnership arrangements
775
THE CIA WORLD FACTBOOK
parties — (185) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Thailand, Tajikistan, Tanzania, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
United Nations Framework Convention on Climate Change
note — abbreviated as Climate Change
opened for signature — 9 May 1992
entered into force — 21 March 1994
objective — to achieve stabilization of greenhouse gas concentrations in the atmosphere at a low enough level to prevent dan¬
gerous anthropogenic interference with the climate system
parties — (195) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iraq, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
Wetlands
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
776
APPENDIX D
FIPS 10: Countries, Dependencies, Areas of Special Sovereignty, and Their Principal Administrative Divisions (FIPS 10) is maintained
by the Office of Targeting and Transnational Issues, National Geospatial-Intelligence Agency, and published by the National
Institute of Standards and Technology (Department of Commerce). FIPS 10 codes are intended for general use throughout the
US Government, especially in activities associated with the mission of the Department of State and national defense programs.
ISO 31 66:Codes for the Representation of Names of Countries (ISO 3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with international organizations that have adopted that standard. Except for the
numeric codes, ISO 3166 codes have been adopted in the US as FIPS 104-1: American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of Special Sovereignty for Information Interchange.
STANAG 1059: Letter Codes for Geographical Entities (8th edition, 2004) is a Standardization Agreement (STANAG) established
and maintained by the North Atlantic Treaty Organization (NATO/OTAN) for the purpose of providing a common set of geo¬
spatial identifiers for countries, territories, and possessions. The 8th edition established trigraph codes for each country based
upon the ISO 3166-1 alpha-3 character sets. These codes are used throughout NATO.
Internet: The Internet country code is the two-letter digraph maintained by the International Organization for Standardization
(ISO) in the ISO 3166 Alphas list and used by the Internet Assigned Numbers Authority (IAN A) to establish country-coded
top-level domains (ccTLDs).
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
ZA
ZM
ZMB
894
ZMB
see Democratic Republic of
the Congo
15 25 S
28 17 E
15 00 S
30 00 E
Arctic Ocean
74 40 N
100 00 W
Atlantic Ocean
66 00 N
6 00 E
15 00 S
30 00 E','bd413553cba36fd357f715d74c52c23eacd9c9f5ea54c2e7e2ca2968547afb21','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79808827fb55ab883da6d712e4e96067c5c47cdd290f9f6ead4112a0abe30fc7',2009,'ZW','Zimbabwe','transnational-issues',1317,'Background: The UK annexed Southern
Rhodesia from the [British] South Africa
Company in 1923. A 1961 constitution
was formulated that favored whites in
power. In 1965 the government unilater¬
ally declared its independence, but the
UK did not recognize the act and
demanded more complete voting rights
for the black African majority in the
country (then called Rhodesia). UN
sanctions and a guerrilla uprising finally
led to free elections in 1979 and inde¬
pendence (as Zimbabwe) in 1980.
Robert MUGABE, the nation’s first
prime minister, has been the country’s
only ruler (as president since 1987) and
has dominated the country’s political
system since independence. His chaotic
land redistribution campaign, which
began in 2000, caused an exodus of white
farmers, crippled the economy, and ush¬
ered in widespread shortages of basic
724
commodities. Ignoring international
condemnation, MUGABE rigged the
2002 presidential election to ensure his
reelection. The ruling ZANU-PF party
used fraud and intimidation to win a
twO''thirds majority in the March 2005
parliamentary election, allowing it to
amend the constitution at will and
recreate the Senate, which had been
abolished in the late 1980s. In April
2005, Harare embarked on Operation
Restore Order, ostensibly an urban
rationalization program, which resulted
in the destruction of the homes or busi¬
nesses of 700,000 mostly poor supporters
of the opposition, according to UN esti¬
mates. President MUGABE in June 2007
instituted price controls on all basic
commodities causing panic buying and
leaving store shelves empty for months.
In October 2007, Constitutional
Amendment 18 came into effect
allowing for harmonized presidential and
parliamentary elections, shortening the
length of the presidential term to five
years, and moving up the date for parlia¬
mentary elections. General elections are
expected in March 2008.
Disputes — international: Botswana
built electric fences and South Africa has
placed military along the border to stem
the flow of thousands of Zimbabweans
fleeing to find work and escape political
persecution; Namibia has supported, and
in 2004 Zimbabwe dropped objections
to, plans between Botswana and Zambia
to build a bridge over the Zambezi River,
thereby de facto recognizing a short, but
not clearly delimited, Botswana-Zambia
boundary in the river
Refugees and internally displaced per¬
sons: refugees ( country of origin): 2,500
(Democratic Republic of Congo)
IDPs: 569,685 (MUGABE-led political
violence, human rights violations, land
reform, and economic collapse) (2007)
Illicit drugs: transit point for cannabis
and South Asian heroin, mandrax, and
methamphetamines en route to South
Africa
727
Disputes— international: involved in
complex dispute with China, Malaysia,
Philippines, Vietnam, and possibly
Brunei over the Spratly Islands; the 2002
“Declaration on the Conduct of Parties
in the South China Sea” has eased ten¬
sions but falls short of a legally binding
“code of conduct” desired by several of
the disputants; Paracel Islands are occu¬
pied by China, but claimed by Taiwan
and Vietnam; in 2003, China and
Taiwan became more vocal in rejecting
both Japan’s claims to the uninhabited
islands of the Senkaku-shoto (Diaoyu
Tai) and Japan’s unilaterally declared
exclusive economic zone in the East
China Sea where all parties engage in
hydrocarbon prospecting
Illicit drugs: regional transit point for
heroin, methamphetamine, and pre¬
cursor chemicals; transshipment point
for drugs to Japan; major problem with
domestic consumption of methampheta¬
mine and heroin; rising problems with
use of ketamine and club drugs
730
Preliminary statement: The evolution of
the European Union (EU) from a
regional economic agreement among six
neighboring states in 1951 to today’s
supranational organization of 27 coma-
tries across the European continent
stands as an unprecedented phenom-
enon in the annals of history. Dynastic
unions for territorial consolidation were
long the norm in Europe. On a few occa¬
sions even country-level unions were
arranged — the Polish-Lithuanian Com¬
monwealth and the Austro-Hungarian
Empire were examples — but for such a
large number of nation-states to cede
some of their sovereignty to an overar¬
ching entity is truly unique. Although
the EU is not a federation in the strict
sense, it is far more than a free-trade
association such as ASEAN, NAFTA, or
Mercosur, and it has many of the attrib¬
utes associated with independent
nations: its own flag, anthem, founding
date, and currency, as well as an incip¬
ient common foreign and security policy
in its dealings with other nations. In the
future, many of these nation-like charac¬
teristics are likely to be expanded. Thus,
inclusion of basic intelligence on the EU
has been deemed appropriate as a new,
separate entity in The World Factbook.
However, because of the EU’s special
status, this description is placed after the
regular country entries.
Background: Following the two devas¬
tating World Wars of the first half of the
20th century, a number of European
leaders in the late 1940s became con¬
vinced that the only way to establish a
lasting peace was to unite the two chief
belligerent nations — France and
Germany — both economically and polit¬
ically. In 1950, the French Foreign
Minister Robert SCHUMAN proposed
an eventual union of all Europe, the first
step of which would be the integration of
the coal and steel industries of Western
Europe. The following year the European
Coal and Steel Community (ECSC) was
set up when six members, Belgium,
France, West Germany, Italy,
Luxembourg, and the Netherlands,
signed the Treaty of Paris. The ECSC
was so successful that within a few years
the decision was made to integrate other
parts of the countries’ economies. In
1957, the Treaties of Rome created the
European Economic Community (EEC)
and the European Atomic Energy
Community (Euratom), and the six
member states undertook to eliminate
trade barriers among themselves by
forming a common market. In 1967, the
institutions of all three communities
were formally merged into the European
Community (EC), creating a single
Commission, a single Council of
Ministers, and the European Parliament.
Members of the European Parliament
were initially selected by national parlia¬
ments, but in 1979 the first direct elec¬
tions were undertaken and they have
been held every five years since. In 1973,
the first enlargement of the EC took
place with the addition of Denmark,
Ireland, and the United Kingdom. The
1980s saw further membership expansion
with Greece joining in 1981 and Spain
and Portugal in 1986. The 1992 Treaty of
Maastricht laid the basis for further forms
of cooperation in foreign and defense
policy, in judicial and internal affairs,
and in the creation of an economic and
monetary union — including a common
currency. This further integration cre¬
ated the European Union (EU). In 1995,
Austria, Finland, and Sweden joined the
EU, raising the membership total to 15.
A new currency, the euro, was launched
in world money markets on 1 January
1999; it became the unit of exchange for
all of the EU states except the United
Kingdom, Sweden, and Denmark. In
2002, citizens of the 12 euro-area coun¬
tries began using the euro banknotes and
coins. Ten new countries joined the EU
in 2004 — Cyprus, the Czech Republic,
Estonia, Hungary, Latvia, Lithuania,
Malta, Poland, Slovakia, and Slovenia —
and in 2007 Bulgaria and Romania
joined, bringing the current membership
to 27. In order to ensure that the EU can
continue to function efficiently with an
expanded membership, the Treaty of
Nice (in force as of 1 February 2003) set
forth rules streamlining the size and pro¬
cedures of EU institutions. An effort to
establish an EU constitution, begun in
October 2004, failed to attain unani¬
mous ratification. A new effort, under¬
taken in June 2007, calls for the creation
of an Intergovernmental Conference to
form a political agreement, known as the
Reform Treaty, which is to serve as a con¬
stitution. Unlike the constitution, how¬
ever, the Reform Treaty would amend
existing treaties rather than replace
them.
Disputes — international: as a political
union, the EU has no border disputes
with neighboring countries, but Estonia
has no land boundary agreements with
Russia, Slovenia disputes its land and
maritime boundaries with Croatia, and
Spain has territorial and maritime dis¬
putes with Morocco and with the UK
over Gibraltar; the EU has set up a
Schengen area — consisting of 22 EU
member states that have signed the con¬
vention implementing the Schengen
agreements or “acquis” (1985 and 1990)
on the free movement of persons and the
harmonization of border controls in
Europe; these agreements became incor¬
porated into EU law with the implemen¬
tation of the 1997 Treaty of Amsterdam
on 1 May 1999; in addition, non-EU
states Iceland and Norway (as part of the
Nordic Union) have been included in
the Schengen area since 1996 (full mem¬
bers in 2001), bringing the total current
membership to 24; the UK (since 2000)
and Ireland (since 2002) take part in
only some aspects of the Schengen area,
especially with respect to police and
criminal matters; nine of the 12 new
member states that joined the EU in
2004 joined Schengen on 21 December
2007; of the three remaining EU states,
Cyprus is expected to join by 2009, while
Romania and Bulgaria continue to
enhance their border security systems
734
APPENDIX A
ABEDA
Arab Bank for Economic Development in Africa
ACCT
Agency for the French-Speaking Community (see International Organization of the
French-speaking World)
ACP Group
African, Caribbean, and Pacific Group of States
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Nitrogen Oxides or Their Transboundary
Fluxes
Air Pollution-Persistent
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Organic Pollutants
Persistent Organic Pollutants
Air Pollution-Sulphur 85
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the
Reduction of Sulphur Emissions or Their Transboundary Fluxes by at Least 30%
Air Pollution-Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Air Pollution-Volatile
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Organic Compounds
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
Antarctic-Environmental Protocol
Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Marine Living Resources
Convention on the Conservation of Antarctic Marine Living Resources
Antarctic Seals
Convention for the Conservation of Antarctic Seals
ANZUS
Australia-New Zealand-United States Security Treaty
APEC
Asia-Pacific Economic Cooperation
Arabsat
Arab Satellite Communications Organization
ARF
ASEAN Regional Forum
ADB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
AU
African Union
Autodin
Automatic Digital Network
BA
Baltic Assembly
bbl/day
barrels per day
BCIE
Central American Bank for Economic Integration
BDEAC
Central African States Development Bank
Benelux
Benelux Economic Union
BIMSTEC
Bay of Bengal Initiative for Multisectoral Technical and Economic Cooperation
Biodiversity
Convention on Biological Diversity
BGN
United States Board on Geographic Names
BIS
Bank for International Settlements
BSEC
Black Sea Economic Cooperation Zone
C
Commonwealth
c.i.f.
cost, insurance, and freight
CACM
Central American Common Market
CAEU
Council of Arab Economic Unity
CAN
Andean Community of Nations
Caricom
Caribbean Community and Common Market
CB
citizen’s band mobile radio communications
CBSS
Council of the Baltic Sea States
CCC
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEI
Central European Initiative
CEMAC
Economic and Monetary Community of Central Africa
CEPGL
Economic Community of the Great Lakes Countries
CERN
European Organization for Nuclear Research
735
THE CIA WORLD FACTBOOK
CEPT
CIS
CITES
Climate Change
Climate Change-Kyoto Protocol
COCOM
Comsat
COMESA
CP
CPLP
CSTO
CTBTO
CY
DC
DDT
Desertification
Conference Europeanne des Poste et Telecommunications
Commonwealth of Independent States
see Endangered Species
United Nations Framework Convention on Climate Change
Kyoto Protocol to the United Nations Framework Convention on Climate Change
Coordinating Committee on Export Controls
Communications Satellite Corporation
Common Market for Eastern and Southern Africa
Colombo Plan
Comunidade dos Paises de Lingua Portuguesa
Collective Security Treaty Organization
Preparation commission for the Nuclear-Ban-Treaty Operation
calendar year
developed country
dichloro-diphenyl-trichloro-ethane
United Nations Convention to Combat Desertification in Those Countries Experiencing
Serious Drought and/or Desertification, Particularly in Africa
DIA
DSN
DST
DWT
EAC
EADB
EAEC
EAPC
EBRD
EC
ECA
ECE
ECLAC
ECO
ECOSOC
ECOWAS
ECSC
EEC
EFTA
EEZ
EIB
EMU
Endangered Species
United States Defense Intelligence Agency
Defense Switched Network
daylight savings time
deadweight ton
East African Community
East African Development Bank
Eurasian Economic Community
Euro-Atlantic Partnership Council
European Bank for Reconstruction and Development
European Community
Economic Commission for Africa
Economic Commission for Europe
Economic Commission for Latin America and the Caribbean
Economic Cooperation Organization
Economic and Social Council
Economic Community of West African States
European Coal and Steel Community
European Economic Community
European Free Trade Association
exclusive economic zone
European Investment Bank
European Monetary Union
Convention on the International Trade in Endangered Species of Wild Flora and Fauna
(CITES)
Entente
Environmental Modification
Council of the Entente
Convention on the Prohibition of Military or Any Other Hostile Use of Environmental
Modification Techniques
ESA
ESCAP
ESCWA
est.
EU
Euratom
Eutelsat
Ex-lm
f.o.b.
FAO
FAX
FLS
FOC
FSU
FY
European Space Agency
Economic and Social Commission for Asia and the Pacific
Economic and Social Commission for Western Asia
estimate
European Union
European Atomic Energy Community
European Telecommunications Satellite Organization
Export-Import Bank of the United States
free on board
Food and Agriculture Organization
facsimile
Front Line States
flags of convenience
former Soviet Union
fiscal year
736
ABBREVIATIONS
FZ
6-2
G-3
6-5
6-6
6-7
6-8
6-9
6-10
6-15
G-ll
6-24
G-77
GATT
GCC
GCTU
GDP
GMT
GNP
GRT
GSM
nonregional members — (24) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France, Germany, India,
Italy, Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden, Switzerland, UK, US
African Union (AU) note — replaces Organization of African Unity (OAU)
established — 8 July 2001
aim — to achieve greater unity among African States; to defend states’ integrity and independence; to accelerate political, social,
and economic integration; to encourage international cooperation; to promote democratic principles and institutions
members — (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African Republic,
Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Djibouti, Egypt, Equatorial Guinea,
Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi,
Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic (Western
Sahara), Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo,
Tunisia, Uganda, Zambia, Zimbabwe
African, Caribbean, and Pacific Group of States (ACP Group)
established — 6 June 1975
aim — to manage their preferential economic and aid relationship with the EU
members — (79) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon,
The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar,
Malawi, Mali, Marshall Islands, Mauritania, Mauritius, Federated States of Micronesia, Mozambique, Namibia, Nauru, Niger,
Nigeria, Niue, Palau, Papua New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sudan, Suriname,
Swaziland, Tanzania, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean (OPANAL) note — acronym from
Organismo para la Proscripcion de las Armas Nucleares en la America Latina y el Caribe (OPANAL)
established — 14 February 1967 under the Treaty of Tlatelolco; effective — 25 April 1969 on the 11th ratification
aim — to encourage the peaceful uses of atomic energy and prohibit nuclear weapons
members — (33) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica,
Cuba, Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad
and Tobago, Uruguay, Venezuela
Andean Community Of Nations (CAN) note — formerly known as the Andean Group (AG), the Andean Parliament, and most
recently as the Andean Common Market (Ancom)
established — 26 May 1969; present name established 1 October 1992; effective — 16 October 1969
aim — to promote harmonious development through economic integration
members — (4) Bolivia, Colombia, Ecuador, Peru
associate members — (5) Argentina, Brazil, Chile, Paraguay, Uruguay
observers — (2) Mexico, Panama
741
THE CIA WORLD FACTBOOK
Arab Bank for Economic Development in Africa (ABEDA) note— also known as Banque Arabe de Developpement Economique
en Afrique (BADE A)
established — 18 February 1974; effective — 16 September 1974
aim — to promote economic development
members — (17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation Organization; note — these
are all the members of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Fund for Economic and Social Development (AFESD)
established — 16 May 1968
aim — to promote economic and social development
members — (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq (suspended 1993), Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia (suspended 1993), Sudan, Syria, Tunisia,
UAE, Yemen, Palestine Liberation Organization
Arab Maghreb Union (AMU)
established — 17 February 1989
aim — to promote cooperation and integration among the Arab states of northern Africa
members — (5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF)
established — 27 April 1976; effective — 2 February 1977
aim — to promote Arab cooperation, development, and integration in monetary and economic affairs
members — (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
Arctic Council
established — 18 September 1996
aim — to address the common concerns and challenges faced by Arctic governments and the people of the Arctic; to protect the
Arctic environment
members — (8) Canada, Denmark (Greenland, Faroe Islands), Finland, Iceland, Norway, Russia, Sweden, US
permanent participants — (6) Aleut International Association, Arctic Athabaskan Council, Gurch’in Council International, Inuit
Circumpolar Conference, Russian Association of Indigenous People of the North, Saami Council
observers — (7) China, France, Germany, Italy, Netherlands, Poland, UK
ASEAN Regional Forum (ARF)
established — 25 July 1994
aim — to foster constructive dialogue and consultation on political and security issues of common interest and concern
members — (26) Australia, Bangladesh, Brunei, Burma, Cambodia, Canada, China, EU, India, Indonesia, Japan, North Korea,
South Korea, Laos, Malaysia, Mongolia, NZ, Pakistan, Papua New Guinea, Philippines, Russia, Singapore, Thailand, Timor-
Leste, US, Vietnam
Asian Development Bank (ADB)
established — 19 December 1966
aim — to promote regional economic cooperation
members — (48) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma, Cambodia, China, Cook
Islands, Fiji, Georgia, Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia,
Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Palau, Papua New Guinea,
Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan, Thailand, Timor-Leste, Tonga, Turkmenistan,
Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members — (19) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Luxembourg,
Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
Asia-Pacific Economic Cooperation (APEC)
established — 7 November 1989
aim — to promote trade and investment in the Pacific basin
members — (21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia, Mexico, NZ,
Papua New Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers — (3) Association of Southeast Asian Nations, Pacific Economic Cooperation Council, Pacific Islands Forum
Secretariat
Association of Southeast Asian Nations (ASEAN)
established— 8 August 1967
aim — to encourage regional economic, social, and cultural cooperation among the non-Communist countries of Southeast Asia
members — (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
dialogue partners — (11) Australia, Canada, China, EU, India, Japan, South Korea* NZ, Russia, US, UNDP; note — ASEAN pro¬
motes cooperation with Pakistan in some areas of mutual interest
observers — (1) Papua New Guinea
742
INTERNATIONAL ORGANIZATIONS AND GROUPS
Australia Group
established — June 1985
aim — to consult on and coordinate export controls related to chemical and biological weapons
members — (41) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia,
European Commission, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Latvia,
Lithuania, Luxembourg, Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US
Australia-New Zealand-United States Security Treaty (ANZUS)
established — 1 September 1951; effective — 29 April 1952
aim — to implement a trilateral mutual security agreement, although the US suspended security obligations to NZ on 1 1 August
1986; Australia and the US continue to hold annual meetings
members — (3) Australia, NZ, US
Baltic Assembly (BA)
established — 12 May 1990
aim — to thoroughly discuss various cooperation issues between Baltic states
members — (3) Estonia, Latvia, Lithuania
Bay of Bengal Initiative f','e055acdbf70926957eb7fa7265c238b135892f4d91c658690cea24f9737828e5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cdc9c5041961c06dd1a6d95257883a2e8a58fc3abd09144a408588096926115',2009,'ZW','Zimbabwe','transnational-issues',1318,'or Multisectoral Technical and Economic Coopertion (BIMSTEC)
established — June 1997
aim — to foster socio-economic cooperation among members
members — (7) Bangladesh, Bhutan, Burma, India, Nepal, Sri Lanka, Thailand
Bank for International Settlements (BIS)
established — 20 January 1930; effective — 17 March 1930
aim — to promote cooperation among central banks in international financial settlements
members — (54) Algeria, Argentina, Australia, Austria, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada, Chile, China,
Croatia, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hong Kong, Hungary, Iceland, India, Indonesia,
Ireland, Israel, Italy, Japan, South Korea, Latvia, Lithuania, Macedonia, Malaysia, Mexico, Netherlands, NZ, Norway,
Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Thailand, Turkey, UK, US; note — Serbia and Montenegro have separate central banks; their links with BIS are cur¬
rently under review
Benelux Economic Union (Benelux) note — acronym from Belgium, Netherlands, and Luxembourg
established — 3 February 1958; effective — 1 November 1960
aim — to develop closer economic cooperation and integration
members — (3) Belgium, Luxembourg, Netherlands
Big Seven note — membership is the same as the Group of 7
established — 1975
aim — to discuss and coordinate major economic policies
members — (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
Black Sea Economic Cooperation Zone (BSEC)
established — 25 June 1992
aim — to enhance regional stability through economic cooperation
members — (12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Serbia, Turkey, Ukraine;
note — Macedonia is in the process of joining
observers — (17) Austria, Belarus, Black Sea Commission, Commission of the EC, Croatia, Czech Republic, Egypt, Energy
Charter Secretariat, France, Germany, International Black Sea Club, Israel, Italy, Poland, Slovakia, Tunisia, US; note Bosnia
and Herzegovina and Slovenia have applied for observer status
Caribbean Community and Common Market (Caricom)
established — 4 July 1973; effective — 1 August 1973
aim — to promote economic integration and development, especially among the less developed countries
members — (15) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members — (5) Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Turks and Caicos Islands
observers — (7) Aruba, Colombia, Dominican Republic, Mexico, Netherlands Antilles, Puerto Rico, Venezuela
Caribbean Development Bank (CDB)
established — 18 October 1969; effective — 26 January 1970
aim — to promote economic development and cooperation
regional members — (21) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands, Cayman Islands,
Colombia, Dominica, Grenada, Guyana, Haiti, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members — (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC)
see Monetary and Economic Community of Central Africa (CEMAC)
743
THE CIA WORLD FACTBOOK
Central African States Development Bank (BDEAC) note — acronym from Banque de Developpement des Etats de l’Afrique
Centrale
established — 3 December 1975
aim — to provide loans for economic development
members — (10) African Development Bank (AfDB), Cameroon, Central African States Bank (BEAC), Central African
Republic, Chad, Republic of the Congo, Equatorial Guinea, France, Gabon, Kuwait
Central American Bank for Economic Integration (BCIE) note — acronym from Banco Centroamericano de Integracion
Economico
established — 13 December 1960 signature of Articles of Agreement; 31 May 1961 began operations
aim — to promote economic integration and development
members — (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members — (6) Argentina, Colombia, Mexico, Panama, Spain, Taiwan
Central American Common Market (CACM)
established — 13 December 1960, collapsed in 1969, reinstated in 1991
aim — to promote establishment of a Central American Common Market
members — (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua; note — Panama, although not a member, pursues full
regional cooperation
Central European Initiative (CEI) note — evolved from the Quadrilateral Initiative and the Hexagonal Initiative
established — 11 November 1989 as the Quadrilateral Initiative, 27 July 1991 became the Hexagonal Initiative, July 1992 its
present name was adopted
aim — to form an economic and political cooperation group for the region between the Adriatic and the Baltic Seas
members — (18) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary, Italy,
Macedonia, Moldova, Montenegro, Poland, Romania, Serbia, Slovakia, Slovenia, Ukraine
centrally planned economies
a term applied mainly to the traditionally Communist states that looked to the former USSR for leadership; most are now
evolving toward more democratic and market-oriented systems; also known formerly as the Second World or as as the
Communist countries; through the 1980s, this group included Albania, Bulgaria, Cambodia, China, Cuba, Czechoslovakia,
German Democratic Republic, Hungary, North Korea, Laos, Mongolia, Montenegro, Poland, Romania, Serbia, USSR, Vietnam
Collective Security Treaty Organization (CSTO)
established — 7 October 2002
aim — to coordinate military and political cooperation, to develop multilateral structures and mechanisms of cooperation for
ensuring national security of the member states
members — Armenia, Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
Colombo Plan (CP)
established — May 1950 proposal was adopted; 1 July 1951 commenced full operations
aim — -to promote economic and social development in Asia and the Pacific
members — (25) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos,
Malaysia, Maldives, Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Singapore, Sri Lanka, Thailand, US,
Vietnam
Common Market for Eastern and Southern Africa (COMESA) note — formerly known as Preferential Trade Area for Eastern and
Southern Africa (PTA)
established — 5 November 1993
aim — recognizing, promoting and protecting fundamental human rights, commitment to the principles of liberty and rule of law,
maintaining peace and stability through the promotion and strengthening of good neighborliness, commitment to peaceful set¬
tlement of disputes among member states
members — (19) Burundi, Comoros, Democratic Republic of the Congo, Djibouti, Egypt, Eritrea, Ethiopia, Kenya, Libya,
Madagascar, Malawi, Mauritius, Rwanda, Seychelles, Sudan, Swaziland, Uganda, Zambia, Zimbabwe
Commonwealth (C) note — also known as Commonwealth of Nations
established — 31 December 1931
aim — to foster multinational cooperation and assistance, as a voluntary association that evolved from the British Empire
members — (53) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei, Cameroon,
Canada, Cyprus, Dominica, Fiji (suspended), The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya, Kiribati, Lesotho,
Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (suspended), Papua New
Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Seychelles, Sierra Leone, Singapore,
Solomon Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad and Tobago, Tuvalu, Uganda, UK, Vanuatu,
Zambia; note — on 7 December 2003 Zimbabwe withdrew its membership from the Commonwealth
Commonwealth of Independent States (CIS)
established — 8 December 1991; effective — 21 December 1991
aim — to coordinate intercommonwealth relations and to provide a mechanism for the orderly dissolution of the USSR
members — (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
744
INTERNATIONAL ORGANIZATIONS AND GROUPS
Communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the Soviet model;
most of the original and the successor states are no longer Communist; see centrally planned economies
Comuinidade dos Poises de Lingua Portuguese (CPLP)
established — 1996
aim — to establish a forum for friendship among Portuguese-speaking nations where Portuguese is an official language
members — (8) Angola, Brazil, Cape Verde, Guinea-Bissau, Mozambique, Portugal, Sao Tome and Principe, Timor-Leste
associate observers — (2) Equatorial Guinea, Mauritius
Coordinating Committee on Export Controls (COCOM)
established in 1949 to control the export of strategic products and technical data from member countries to proscribed destina¬
tions; members were: Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan, Luxembourg, Netherlands,
Norway, Portugal, Spain, Turkey, UK, US; abolished 31 March 1994; COCOM members established a new organization, the
Wassenaar Arrangement, with expanded membership on 12 July 1996 that focuses on nonproliferation export controls as
opposed to East-West control of advanced technology
Council for Mutual Economic Assistance (CEMA) note — also known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist economies and abolished 1 January 1991; members
included Afghanistan (observer), Albania (had not participated since 1961 break with USSR), Angola (observer), Bulgaria,
Cuba, Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer), Nicaragua
(observer), Poland, Romania, USSR, Vietnam, Yemen (observer), Yugoslavia (associate)
Council of Arab Economic Unity (CAEU)
established — 3 June 1957; effective — 30 May 1964
aim — to promote economic integration among Arab nations
members — (10 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria,
Yemen, Palestine Liberation Organization
Council of Europe (CE)
established — 5 May 1949; effective — 3 August 1949
aim — to promote increased unity and quality of life in Europe
members — (47) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Montenegro, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK
observers — (5) Canada, Holy See, Japan, Mexico, US
Council of the Baltic Sea States (CBSS)
established — 6 March 1992
aim — to promote cooperation among the Baltic Sea states in the areas of aid to new democratic institutions, economic develop¬
ment, humanitarian aid, energy and the environment, cultural programs and education, and transportation and communication
members— ( 12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia, Lithuania, Norway, Poland, Russia, Sweden
observers — (7) France, Italy, Netherlands, Slovakia, Ukraine, UK, US
Council of the Entente (Entente)
established — 29 May 1959
aim — to promote economic, social, and political coordination
members — (5) Benin, Burkina Faso, Cote d’Ivoire, Niger, Togo
countries in transition
a term used by the International Monetary Fund (IMF) for the middle group in its hierarchy of advanced economies, countries
in transition, and developing countries; IMF statistics include the following 28 countries in transition: Albania, Armenia,
Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Mongolia, Montenegro, Poland, Romania, Russia, Serbia, Slovakia,
Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note— this group is identical to the group traditionally referred to as
the “former USSR/Eastern Europe” except for the addition of Mongolia
Customs Cooperation Council (CCC) note — see World Customs Organization (WCO)
developed countries (DCs)
the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less devel¬
oped countries (LDCs); includes the market-oriented economies of the mainly democratic nations in the Organization for
Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and the European ministates; also known as
the First World, high-income countries, the North, industrial countries; generally have a per capita GDP in excess of $10,000
although four OECD countries and South Africa have figures well under $10,000 and two of the excluded OPEC countries have
figures of more than $10,000; the 34 DCs are: Andorra, Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands,
Finland, France, Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Monaco,
Netherlands, NZ, Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note similar to
the new International Monetary Fund (IMF) term “advanced economies that adds Hong Kong, South Korea, Singapore, and
Taiwan but drops Malta, Mexico, South Africa, and Turkey
745
THE CIA WORLD FACTBOOK
developing countries
a term used by the International Monetary Fund (IMF) for the bottom group in its hierarchy of advanced economies, countries
in transition, and developing countries; IMF statistics include the following 126 developing countries: Afghanistan, Algeria,
Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Cyprus,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia,
Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan,
Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique, Namibia, Nepal, Netherlands
Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
Zimbabwe; note — this category would presumably also cover the following 46 other countries that are traditionally included in
the more comprehensive group of “less developed countries”: American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman
Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza
Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau, Martinique,
Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto
Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands,
Wallis and Futuna, West Bank, Western Sahara
East African Community (EAC) note — originally established in 1967, it was disbanded in 1977
established — January 2001
aim — to establish a political and economic union among the countries
members — (5) Burundi, Kenya, Rwanda, Tanzania, Uganda
East African Development Bank (EADB)
established — 6 June 1967; effective — 1 December 1967
aim — to promote economic development
members — (3) Kenya, Tanzania, Uganda
East Asia Summit (EAS)
established — 14 December 2005
aim — to promote cooperation in political and security issues; to promote development, financial stability, energy security, eco¬
nomic integration and growth; to eradicate poverty and narrow the development gap in East Asia, and to promote deeper cul¬
tural understanding
members — (16) Australia, Brunei, Burma, Cambodia, China, India, Indonesia, Japan, South Korea, Laos, Malaysia, NZ,
Philippines, Singapore, Thailand, Vietnam
Economic and Monetary Community of Central Africa (CEMAC) note — was formerly the Central African Customs and
Economic Union (UDEAC)
established — 8 December 1964; effective — 1 January 1966
aim — to promote the establishment of a Central African Common Market
members — (6) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, Gabon
Economic and Monetary Union (EMU) note — an integral part of the European Union; also known as the European Economic
and Monetary Union
established — 1-2 December 1969 (proposed at summit conference of heads of government; 7 February 1992 (Maastricht Treaty signed)
aim — to promote a single market by creating a single currency, the euro; timetable — 2 May 1998: European exchange rates fixed
for 1 January 1999; 1 January 1999: all banks and stock exchanges begin using euros; 1 January 2002: the euro goes into circula¬
tion; 1 July 2002 local currencies no longer accepted
members — (15) Austria, Belgium, Cyprus, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Malta, Netherlands,
Portugal, Slovenia, Spain
Economic and Social Council (ECOSOC)
established — 26 June 1945; effective — 24 October 1945
dim — to coordinate the economic and social work of the UN; includes five regional commissions (Economic Commission for
Africa, Economic Commission for Europe, Economic Commission for Latin America and the Caribbean, Economic and Social
Commission for Asia and the Pacific, Economic and Social Commission for Western Asia) and nine functional commissions
(Commission for Social Development, Commission on Human Rights, Commission on Narcotic Drugs, Commission on the Status
of Women, Commission on Population and Development, Statistical Commission, Commission on Science and Technology for
Development, Commission on Sustainable Development, and Commission on Crime Prevention and Criminal Justice)
members — (54) selected on a rotating basis from all regions
Economic Community Of the Great Lakes Countries (CEPGL) note — acronym from Communaute Economique des Pays des
Grands Lacs
established — 20 September 1976
aim — to promote regional economic cooperation and integration
members — (3) Burundi, Democratic Republic of the Congo, Rwanda; note — organization collapsed because of fighting in 1998;
reactivated in 2006
746
INTERNATIONAL ORGANIZATIONS AND GROUPS
Economic Community of West African States (ECOWAS)
established — 28 May 1975
aim — to promote regional economic cooperation
members — (15) Benin, Burkina Faso, Cape Verde, Cote d’Ivoire, The Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali,
Niger, Nigeria, Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO)
established — 27-29 January 1985
aim — to promote regional cooperation in trade, transportation, communications, tourism, cultural affairs, and economic development
members — (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
Eurasian Economic Community (EAEC or EurasEC) note — merged with Central Asian Cooperation Organization (CACO) in 2005
established — May 2001
aim — to create a common economic and energy policy
members — (6) Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
observers — (3) Armenia, Moldova, Ukraine
Euro-Atlantic Partnership Council (EAPC) note - — began as the North Atlantic Cooperation Council (NACC); an extension of NATO
established — 8 November 1991; effective — 20 December 1991
aim — to discuss cooperation on mutual political and security issues
members — (49) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Luxembourg, Macedonia, Moldova, Montenegro, Netherlands, Norway, Poland, Portugal,
Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US,
observers — (31) Afghanistan, Algeria, Andorra, Azerbaijan, The Bahamas, Belarus, Bhutan, Bosnia and Herzegovina, Cape
Verde, Comoros, Equatorial Guinea, Ethiopia, Holy See, Iran, Iraq, Kazakhstan, Laos, Lebanon, Libya, Montenegro, Russia,
Samoa, Sao Tome and Principe, Serbia, Seychelles, Sudan, Tajikistan, Ukraine, Uzbekistan, Vanuatu, Yemen; note — with the
exception of the Holy See, an observer must start accession negotiations within five years of becoming observers
Zangger Committee (ZC)
established — early 1970s
aim — to establish guidelines for the export control provisions of the Nonproliferation of Nuclear Weapons Treaty (NPT)
members — (36) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, China, Croatia, Czech Republic, Denmark, Finland,
France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observers — (1) EC
768
APPENDIX C
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of
Nitrogen Oxides or Their Transboundary Fluxes
Air Poilution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur Emissions or
Their Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of
Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic— Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature — 1 December 1959
entered into force — 23 June 1961
objective — to ensure that Antarctica is used for peaceful purposes only (such as international cooperation in scientific research);
to defer the question of territorial claims asserted by some nations and not recognized by others; to provide an international
forum for management of the region; applies to land and ice shelves south of 60 degrees south latitude
parties — (45) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy, Japan, North Korea, South
Korea, Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia, South Africa, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US, Uruguay, V','50edea3cf87f89da1f7816f212535b6bd0b109cea1b2716039202ec4092ea357','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0ba9b0bd8f27f57387dc2be8f07932151a18540adeeceec2ba88ad9db81672',2009,'ZW','Zimbabwe','transnational-issues',1319,'enezuela
Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
note — abbreviated as Hazardous Wastes
opened for signature — 22 March 1989
entered into force — 5 May 1992
objective — to reduce transboundary movements of wastes subject to the Convention to a minimum consistent with the environ¬
mentally sound and efficient management of such wastes; to minimize the amount and toxicity of wastes generated and ensure
their environmentally sound management as closely as possible to the source of generation; and to assist LDCs in environmen¬
tally sound management of the hazardous and other wastes they generate
parties — (167) Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote d Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, EU, Finland, France, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia,
Senegal, Serbia, Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden,
Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified — (3) Afghanistan, Haiti, US
Biodiversity
see Convention on Biological Diversity
769
THE CIA WORLD FACTBOOK
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyofo Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
Convention for the Conservation of Antarctic Seals note — abbreviated as Antarctic Seals
opened for signature — 1 June 1972
entered into force — 11 March 1978
objective — to promote and achieve the protection, scientific study, and rational use of Antarctic seals, and to maintain a satisfac¬
tory balance within the ecological system of Antarctica
parties — (16) Argentina, Australia, Belgium, Brazil, Canada, Chile, France, Germany, Italy, Japan, Norway, Poland, Russia,
South Africa, UK, US
countries that have signed, but not yet ratified — (1) NZ
Convention on Biological Diversity note — abbreviated as Biodiversity
opened for signature — 5 June 1992
entered into force — 29 December 1993
objective — to develop national strategies for the conservation and sustainable use of biological diversity
parties — (186) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified — (1) US
Convention on Fishing and Conservation of Living Resources of the High Seas
note — abbreviated as Marine Life Conservation
opened for signature — 29 April 1958
entered into force — 20 March 1966
objective — to solve through international cooperation the problems involved in the conservation of living resources of the high
seas, considering that because of the development of modern technology some of these resources are in danger of being overex¬
ploited
parties — (38) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark, Dominican Republic,
Fiji, Finland, France, Haiti, Indonesia, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia, Mauritius, Mexico, Netherlands,
Nigeria, Portugal, Senegal, Serbia, Sierra Leone, Solomon Islands, South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad
and Tobago, Uganda, UK, US, Venezuela
countries that have signed, but not yet ratified — (20) Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland,
Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka, Tunisia, Uruguay
Convention on Long-Range Transboundary Air Pollution note — abbreviated as Air Pollution
opened for signature — 13 November 1979
entered into force — 16 March 1983
objective — to protect the human environment against air pollution and to gradually reduce and prevent air pollution, including
long-range transboundary air pollution
parties — (49) Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Netherlands,
Norway, Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
countries that have signed, but not yet ratified — (2) Holy See, San Marino
Convention on Wetlands of Internafionai Importance Especially as Waterfowl Habitat (Ramsar)
note — abbreviated as Wetlands
770
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
opened for signature — 2 February 1971
entered into force — 21 December 1975
objective — to stem the progressive encroachment on and loss of wetlands now and in the future, recognizing the fundamental
ecological functions of wetlands and their economic, cultural, scientific, and recreational value
parties — (153) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Romania, Russia, Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Senegal, Serbia, Seychelles, Sierra
Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania, Tajikistan,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
ZI
ZW
ZWE
716
ZWE
.ZW
782
APPENDIX E
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986, published by the International
Hydrographic Bureau of the International Hydrographic Organization; note— this document has not yet been ratified and only
the 3rd Edition (1953) remains in force
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1953, published by the International Hydrographic
Organization
ACIC M 49-1 : Chart of Limits of Seas and Oceans, revised January 1958, published by the Aeronautical Chart and Information
Center (ACIC), United States Air Force; note— ACIC is now part of the National Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data Standard No. 4, Defense Intelligence Agency Manual 65-18,
December 1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal Information Processing
Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always direcny compare e
because of differences in the customers, needs, and requirements of the individual organizations. Even the number of pnncipa
water bodies varies from organization to organization. Factbook users, for example, find the Atlantic Ocean and Pacific Ocean
entries useful, but none of the following standards include those oceans in their entirety. Nor is there any provision for com¬
bining codes or overcodes to aggregate water bodies. The recently delimited Southern Ocean is not included.
Principal Oceans and Seas of the World With Hydrographic Codes by Institution
Arctic Ocean
Atlantic Ocean
Baltic Sea
Eastern Mediterranean
Indian Ocean
Mediterranean Sea
North Atlantic Ocean
North Pacific Ocean
Pacific Ocean
South Atlantic Ocean
South China and Eastern Archipelagic Seas
South Pacific Ocean
Western Mediterranean
23-4th
IHO 23-3rd*
ACIC M 49-1
DIAM 65-18
9
17
A
5A
2
1
B26
7B
3.1.2
28 B
-
8E
5
45
F
6A
3.1
28
Bll
-
1
23
B
1A
7
57
D
3A
4
32
C
2A
6
49, 48
D18 plus others
3U plus others
8
61
E
4A
3.1.1
28 A
-
8W
*The letters after the numbers are subdivisions, not footnotes.
783
Name
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Abidjan (capital)
Abkhazia (region)
Abu Dhabi (capital)
Abu Musa (island)
Abuja (capital)
Abyssinia (former name for Ethiopia)
Acapulco (city)
Accra (capital)
Adamstown (capital)
Addis Ababa (capital)
Adelie Land (claimed by France; also Terre Adelie)
Aden (city)
Aden, Gulf of
Admiralty Island
Admiralty Islands
Adriatic Sea
Adygey (region)
Aegean Islands
Aegean Sea
Afars and Issas, French Territory of the
(or FTAI; former name for Djibouti)
Afghanestan (local name for Afghanistan)
Agalega Islands
Agana (city; former name for Hagatna)
Ajaccio (city)
Ajaria (region)
Akmola (city; former name for Astana)
Aksai Chin (region)
Ai Arabiyah as Suudiyah (local name for Saudi Arabia)
Al Bahrayn (local name for Bahrain)
AI Imarat al Arabiyah al Muttahidah
(local name for the United Arab Emirates)
Al Iraq (local name for Iraq)
Al Jaza''ir (local name for Algeria)
Al Kuwayt (local name for Kuwait)
Al Maghrib (local name for Morocco)
Al Urdun (local name for Jordan)
Al Yaman (local name for Yemen)
Aland Islands
Alaska (state)
Alaska, Gulf of
Alboran Sea
Aldabra Islands (Groupe d''Aldabra)
Alderney (island)
Aleutian Islands
Alexander Archipelago (island group)
Alexander Island
Alexandretta (region; former name for Iskenderun)
Alexandria (city)
Algiers (capital)
Alhucemas, Penon de (island group)
Alma-Ata (city; former name for Almaty)
Almaty (former capital)
Alofl (capital)
Alphonse Island
Alsace (region)
Amami Strait
Amindivi Islands (former name for Laccadive Islands)
Amirante Isles (island group; also Les Amlrantes)
Amman (capital)
Amsterdam (capital)
Amsterdam Island (lie Amsterdam)
Cote d’Ivoire
5 19 N
4 02 W
17 50 S
31 03 E
20 00 S
30 00 E
17 50 S
105 00 W
20 00 S
30 00 E
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine,','96817fea146556beea5141fef3c61c4aa4f35f83fcc002208e711b70092e9b25','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ad05b69d61963d7700b922b75ab524653749e137b826ca117b0eb26bb3bafd8',2009,'AF','Afghanistan','transnational-issues',1327,'AF
AF
AFG
004
AFG
.af
33 00 N
65 00 E
34 31 N
69 12 E
37 00 N
73 00 E
37 00 N
73 00 E','1337da3126733d064a17a0d4b0a1d6cba31d574878302e2de9173f2a3311e597','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('526010e6682d6d497d05daef608d0e70377b9cffad1c5017430cce543e75c8fc',2009,'AL','Albania','transnational-issues',1328,'AL
AL
ALB
008
ALB
.al
41 00 N
20 00 E
41 20 N
19 50 E
Austria, Italy
47 00 N
11 00 E','75510fdada948eea9e1713d1d80fd9c9fb57df9ab6c7c806264f5fc1929628ce','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa5acfadad5d2475a78fe34a6bfd2212579873bd6cb0e723bd1afb320a9d2d66',2009,'AI','Anguilla','transnational-issues',1329,'AV
AI
AIA
660
AIA
.ai
ISO defines as the territory
18 13 N
63 04 W
Pacific Ocean
31 00 N
131 00 E','e1a57c72c09a6c44c4302e5ed7b501bb8673ec675900c373faf7e9e286d0e542','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c994b162076f2129885a396ffd35a767ad0711da6080627708f8c140c5d6a36',2009,'AQ','Antarctica','transnational-issues',1330,'AY
AQ
ATA
010
ATA
•aq
66 30 S
139 00 E
71 00 S
70 00 W
Turkey
36 34 N
36 08 E
67 00 S
163 00 E
79 30 S
49 30 W
62 56 S
60 34 W
Atlantic Ocean
67 00 N
24 00 W
French Southern and
49 30 S
69 30 E
Antarctic Lands
75 00 S
92 00 W
65 00 S
64 00 W
Argentina, Paraguay
24 00 S
60 00 W
The Bahamas
26 40 N
78 35 W
Atlantic Ocean
47 06 N
55 48 W
77 00 S
130 00 W
Saint Martin
18 04 N
63 05 W
''68 48 S
90 35 W
Russia
59 55 N
30 15 E
73 30 S
12 00 E
Taiwan
24 27 N
118 23 E
79 30 S
162 00 W
80 00 S
180 00 E
81 30 S
175 00 W
Antarctica, Southern Ocean
76 00 S
175 00 W
Russia
60 00 N
100 00 E
67 24 S
179 55 W
The Gambia, Senegal
13 50 N
15 25 W
Federated States of Micronesia
6 55 N
158 00 E
South Korea
37 34 N
127 00 E
61 00 S
45 00 W
62 00 S
59 00 W
66 30 S
139 00 E
French Southern and
43 00 S
67 00 E
Antarctic Lands
Pacific Ocean
10 00 N
101 00 E
Macedonia
41 50 N
22 00 E
72 20 S
99 00 W
72 00 S
155 00 E
71 00 S
120 00 E
Netherlands Antilles
12 06 N
68 56 W','9c43a050b2e353301bf7ae01aa2cd513c4464302eff4eaf980729fb233bae03a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('320c0523b413d8e0b2cd9d5f9d3d48b86aa7900e0cbd058edfd06a6a49675550',2009,'BD','Bangladesh','transnational-issues',1331,'BG
BD
BGD
050
BGD
.bd
23 43 N
90 25 E
24 00 N
90 00 E
Arctic Ocean
74 00 N
166 00 E','b004f694b870e935d8c4b7b1273b0af9fb2db96e23d0488e8c24d2ac94cdba18','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81b0baed902367d9d22dd63f35f629024f9854baa35c509a67ec3da793abce89',2009,'BY','Belarus','transnational-issues',1332,'BO
BY
BLR
112
BLR
•by
French Southern and
Antarctic Lands; no ISO
codes assigned
53 00 N
28 00 E
53 00 N
28 00 E
53 00 N
28 00 E
53 54 N
27 34 E
Warsaw','f49a379b545a29b306baade002426f97123fb2397eebae4e477c3313a991a2e2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a8b678fc0f59f58c8d7e5a78314b43598289b837a2520d13f3f7b82d3587e76',2009,'BZ','Belize','transnational-issues',1333,'BH
BZ
BLZ
084
BLZ
.bz
17 30 N
88 12 W
Atlantic Ocean
51 35 N
56 30 W
Southern Ocean
71 00 S
85 00 W
17 15 N
88 46 W
17 15 N
88 45 W','85e876256eb32bc4c979ba0e695f94844af2290ee5fe796abf2ef641c32fca04','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3c1f6f446164aab2a15dca83553357cbde016aca87b723c42943e7cc4c96a47',2009,'BM','Bermuda','transnational-issues',1334,'BD
BM
BMU
060
BMU
32 17 N
64 46 W
South Korea
37 00 N
127 30 E
Vietnam
21 02 N
105 51 E
32 20 N
64 45 W
iU.K.)
Illlllll*i^Bi|
NonxAawses. -mms j >''
Los Angeles* .
»W. ;»*<«»
‘f ijuana* *
Mexicali
El Paso
.*
Ciudad N New Orleans
Judrez •''7.-''- San Houston . *
Oklahoma Citv.
PallasJ
Atlanta *chariesfon
0 c e a n
^Hermo^illo V*
|V«ip
^hiNu^itra ''
''* xV
La Pat
ivtonicrrcy v ^
Ndrreon 1 ^ ?Matamoros
¥ - '' - . . s
.,ul Q Mexico
THE BAHAMAS
Mlami^ ^Nfssau
w\\ %, ^ v ; *.
Havana
IH
Scale: 1:38,700,000
Lambert Can farm a I Conk Projection,
standard parallels 3 7 °/v and 65 °N
0 300 600 KiitHTieiers
i — l | — — - —)
a .too 600 Mites
Boundary represemation is
not necessarily authoritative.
ISIAS
lit V ILIAC, ice VO
iMLXlCO)
■ . A MFXirn ''
M.izatfan !A* L«/\\tV.V/
y»;_ ^Tampico
, , t eon
Guadalajara »
• . ... ... '' * :.*.''. .;..'' c. . . . cawsperhc
Mexico* * .Veracruz
Cartcun*
% ic '' \\%
Merida
:,r
,.y.C T BjXv •■■>&.
; : -T
| HAITI
w. .; y."- -s ■: ^
Port-aw-
Prince
Kingston
■ •*''','ae1193259d9b38cdd6338301285329dfe805bc9dbfe988c61bf0a1c27eaa509b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08ab87dc409f094af59b24fcfacb1466838dea240057a2c2216d73f4173ec3cd',2009,'KH','Cambodia','transnational-issues',1335,'CB
KH
KHM
116
KHM
.kh
13 26 N
103 50 E
MOON
105 00 E
Arctic Ocean
79 30 N
68 00 W
13 00 N
105 00 E
11 33 N
104 55 E','6f66018d2e6c47a04e9a6f42274b262f1e6ab587f07a2d4d807ddc45738083ec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b85238882072dfe7b8b140671cb8a5ac8c02b4d5a9b24295a4e90bc7751a3d2e',2009,'CO','Colombia','transnational-issues',1336,'CO
CO
COL
170
COL
• CO
10 59 N
74 48 W
Pacific Ocean
22 00 N
121 00 E
Pacific Ocean
6 49 N
122 05 E
4 36 N
74 05 W
Czech Republic
50 00 N
14 30 E
4 00 N
90 30 W
Atlantic Ocean
56 44 N
26 53 E
Falkland Islands (Islas Malvinas) 51 45 S
59 00 W
13 32 N
80 03 W
13 00 N
81 30 W
Pacific Ocean
12 32 N
124 10 E
14 25 N
80 16 W
15 51 N
79 46 W','3369734d9624fee7e251a9023400b45962cde3841efbde92a0dea79c948b9222','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04d7f82652ae1986be9aeea68278695876da0218b8cafaddc379e2a20d64e353',2009,'DJ','Djibouti','transnational-issues',1337,'DJ
DJ
DJI
262
DJI
•dj
11 30 N
43 00 E
11 30 N
43 15 E
Belarus, Russia, Ukraine
46 30 N
32 18 E
(Dnyapro, Dnepr, Dnipro)
Moldova, Ukraine
46 18 N
30 17 E
(Nistru, Dnister)
Bulgaria, Romania
43 30 N
28 00 E
11 30 N
43 00 E
11 30 N
43 00 E','4de00eb0b8f2a4db48645de260f038e99637bfc62af5ecf6591211dcd786579e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddc96ee9795af9e6a0de9fcbc9c91fff903e15b7459c66e5b93c253e6261653f',2009,'EC','Ecuador','transnational-issues',1338,'EC
EC
ECU
218
ECU
.ec
0 00 N
90 30 W
Russia
55 00 N
167 00 E
0 39 S
78 26 W
Guyana, Suriname
5 57 N
57 06 W
0 00 N
90 30 W
Poland, Ukraine
49 30 N
23 00 E
0 13 S
78 30 W','2f64fdd023072d4bcc7051c17eb8420750262f2d0e3eb71885bc66523194f1c3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afecfbd039bd1538d5701b94c690515a8fbce2815f447e8a431a270114ad54fb',2009,'GQ','Equatorial Guinea','transnational-issues',1339,'EK
GQ
GNQ
226
GNQ
•gq
1 25 S
5 36 E
3 30 N
8 42 E
Atlantic Ocean
44 00 N
4 00 W
0 55 N
9 19 E
0 59 N
9 33 E
3 30 N
8 42 E
2 00 N
10 00 E
Atlantic Ocean
3 00 N
2 30 E
3 45 N
8 47 E
Indian Ocean
2 30 N
101 20 E
1 30 N
10 00 E
2 00 N
10 00 E','b192093964a9f4adaa7ac6ad927d3368c9653d48048b3dfae57bc1ded7894135','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44bc3555f2cfd40c2e669fef73d9ea9b002744573613ad3ae1a72f833e7ae23a',2009,'FO','Faroe Islands','transnational-issues',1340,'FO
FO
FRO
234
FRO
.fo
778
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
Entity FIPS 10
62 00 N
7 00 W
62 01 N
6 46 W
(Df''riMARKI
SHETLAND
ISLANDS . |
^jr a
,,-tf SWEDE
. Ml ...
*• ,
LI me A
8FA ,-i -# f";$
B^ESSSi 11
5» -''v','bbd556bb6bb1570dea3130194168b17db0be0181fe9430ca5ce1e8ef5973566a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72cb13658b06cbc0e3e03679c8b0006f71dc406025983d6a4018e0184f4eeb7d',2009,'FJ','Fiji','transnational-issues',1341,'FJ
FJ
18 20 S
178 30 E
12 30 S
177 05 E
18 08 S
178 25 E
Russia
56 50 N
60 39 E
18 00 S
178 00 E
Russia
43 10N
131 56 E','69294e28cbc0ef5dc10bf06d1e10d331f92cd4651bc4e861edab0d2a03cc6b14','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c545331c7c211cb863a503d56ba710792678ccde367b3347ae5af2ddfe12b91',2009,'FI','Finland','transnational-issues',1342,'FI
FI
60 15 N
20 00 E
60 10N
24 58 E
64 00 N
26 00 E
f ■ ■■ ■ .
uut -a
;>? v Janipere
C/deffc I’eU''rdmrg
Rue kali
iL.K.>
N o r I ft
A 1 1 a rt t Ic
O c e a n
ORKNEY
ISLANDS v
f ;
x I
, * ?■ e y 1 Jpmburgfj
- Belfast • UJilTED I
w S'' •?, V''/xL-cs. e ?
0uh!i”* u,as
^ - -4% '' tester
U''
.
* Stockholm ifWMS Tallinn RbSSIA
* ESTONIA
Stavanger*
fi
nENMARy,
c:
* ,y '' 4 ^ >l3lmo','775e0639c3b46e26dea1d19160e45fa3f25a4db3193b62dff0204ab83fd0cac9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f263066c69549653fa6b8c417160b857fec42932f2776012d23cecb373053bac',2009,'GF','French Guiana','transnational-issues',1343,'FG
GF
4 56 N
52 20 W
5 17 N
52 35 W
4 00 N
53 00 W
4 00 N
53 00 W
5 20 N
52 37 W','ed410390b89a539b4da90a169519883b3628e461f75d22cfd06febd61d0d9167','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12d15e2693db527b82eec2ab9bb597d8e325865f5a5c0d244a181c833d90fc4f',2009,'GD','Grenada','transnational-issues',1344,'GJ
GD
12 07 N
61 40 W
South Georgia and the
54 15 S
36 45 W
South Sandwich Islands
12 03 N
61 45 W
Atlantic Ocean
52 00 N
6 00 W
Saint Helena
15 57 S
5 42 W
12 20 N
61 30 W','89f8ba31f3b92df4b9309f92fc00aa0a72f3877ff62d414a86a0ae42417fbb68','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ae417cad1fcc3a5f098f604ac40dce7e423ab1d9fe21650f57fbd3ee69c48f9',2009,'GW','Guinea-Bissau','transnational-issues',1345,'PU
GW
11 25 N
16 20 W
11 51 N
15 35 W
Svalbard
74 26 N
19 05 E
12 00 N
15 00 W
12 00 N
15 00 W','4ea8633336b87913a1207c05cce6765a92cff70940eb8666b0d9772436e37e73','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e609130ed0f95765bd5c275c3405592d2f3fb3ec5f5796774798d1ee0523133',2009,'IS','Iceland','transnational-issues',1346,'IC
IS
65 00 N
18 00 W
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Turkey
41 01 N
28 58 E
Croatia, Slovenia
45 00 N
14 00 E
64 09 N
21 57 W
63 17 N
20 40 W','e51aab4000294c4255dc64c16677fef1d92a96902ec28a9e09b16a899662175e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70d2049970c57fab68c98a9bd0efe220dc0ac795ac4ad0acfb84e2e3e0527a14',2009,'IQ','Iraq','transnational-issues',1347,'IZ
IQ
33 00 N
44 00 E
33 21 N
44 25 E
33 00 N
44 00 E
Atlantic Ocean
38 15 N
15 35 E','8e3bdef3730d960562fb101b361060b78cef1a9075a52b6576b4ec8ef16c9c2a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('782b54a5f019135453a437ead024d8dd040277691e8d937493a196e86e1cd3bf',2009,'MW','Malawi','transnational-issues',1348,'MI
MW
MWI
454
MWI
.mw
13 30 S
34 00 E
Kenya, Tanzania, Uganda
1 00 N
38 00 E
13 59 S
33 44 E
13 30 S
34 00 E','4ee0d9eed223eff99480b50a100026a3b848cdb228a68f96dec20e692482097e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('316c973868890703727dbcfc618efd8a2457b5fbf89ee29a9e8deb550da761c4',2009,'NA','Namibia','transnational-issues',1349,'WA
NA
NAM
516
NAM
.na
22 00 S
17 00 E
24 00 S
15 00 E
22 00 S
17 00 E
22 59 S
14 31 E
22 34 S
17 06 E
Atlantic Ocean
20 00 N
73 50 W','4cf30b06e7c82c821687769a74850271c52bfbaf942e1945bf97e3bee57d117e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('041fd981ad580cf742805c7eedae699f95d37f42c3a6b76b0ae03c052034292d',2009,'NP','Nepal','transnational-issues',1350,'NP
NP
NPL
524
NPL
•np
27 43 N
85 19 E
Atlantic Ocean
57 00 N
11 00 E
Pacific Ocean
21 45 N
158 50 W','d79c9964d038142faa5e85d9080b41fd630f7bc84cf08b9d22e1a0ddc97c0a39','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac221a148d11bec296966dbe90ed84506180fd26adbc513e5af91cdc9ab71ea6',2009,'NU','Niue','transnational-issues',1351,'NE
NU
NIU
570
NIU
.nu
19 01 S
169 55 W
19 02 S
169 52 W
Pacific Ocean
9 30 S
122 00 E','32f0001ce85c3fc8532a42d64ca49b30a355b4ffe49b5f3138f081af6ef35716','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2860b87787cd81184c9ad5bb13de0e1d54c0d2c9ccde52853598c039d3ca84',2009,'PK','Pakistan','transnational-issues',1352,'PK
PK
PAK
586
PAK
.pk
34 30 N
74 00 E
28 00 N
63 00 E
Atlantic Ocean
57 00 N
19 00 E
33 42 N
73 10 E
24 51 N
67 03 E
Russia
50 00 N
143 00 E
China, India
35 30 N
77 50 E
Finland, Russia
63 15 N
30 48 E
Russia
60 25 N
30 00 E
Pacific Ocean
2 05 S
108 40 E
India, Pakistan
34 00 N
76 00 E
Democratic Republic
10 00S
26 00 E
of the Congo
31 33 N
74 23 E
Atlantic Ocean
42 30 N
81 00 W
Atlantic Ocean
45 00 N
83 00 W
Atlantic Ocean
43 30 N
87 30 W
Atlantic Ocean
43 30 N
78 00 W
Atlantic Ocean
48 00 N
88 00 W
36 ON
75 0 E
34 01 N
71 40 E
30 00 N
70 00 E
807
THE CIA WORLD FACTBOOK
Name _
West Siberian Plain
Western Channel (West Korea Strait)
Western Samoa (former name for Samoa)
Wetar Strait
White Sea
Wilkes Land (region)
Willemstad (capital)
Windhoek (capital)
Windward Passage
Winnipeg (city)
Wrangel Island (Ostrov Vrangelya)
Xianggang (local name for Hong Kong)
Y''israel (local name for Israel)
Yaifopya (local name for Ethiopia)
Yalu River
Yamoussoukro (capital)
Yangon (see Rangoon)
Yaounde (capital)
Yap Islands
Yaren (governmental center)
Yekaterinburg (city; formerly Sverdlovsk)
Yellow Sea
Yemen Arab Republic (also Yemen (Sanaa);
former name for northern portion of Yemen)
Yemen, People''s Democratic Republic of (also Yemen
(Aden); former name for southern portion of Yemen)
Yerevan (capital)
Yokohama (city)
Youth, Isle of (Isla de la Juvenfud)
Yucatan Channel
Yucatan Peninsula
Yugoslavia (former name for a federation of Serbia
and Montenegro)
Yugoslavia, Kingdom of (former name for a Balkan federation)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Russia
60 00 N
75 00 E
Pacific Ocean
34 40 N
129 00 E','6eab50180f1552c9c4fa5546a97c2633a0357d38d7df6bb2689b1aa9ccf7303d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43be85c645e5be1edf7dc2671486fbd16e743f3d8b09fcb5b8c76072ec4eacc2',2009,'PA','Panama','transnational-issues',1353,'PM
PA
PAN
591
PAN
.pa
9 00 N
79 45 W
Atlantic Ocean
28 00 N
16 00 W
8 58 N
79 32 W
9 00 N
79 45 W
Pacific Ocean
8 00 N
79 30 W','0e1a0c3799895a48f5714edc5ebab3dc9fb371782bd00837249b4a6f1ab3a222','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f9d086c28f6e3afeb1cc108b1e92f4f620533448f3208d510fa1aa84bdd949c',2009,'PT','Portugal','transnational-issues',1354,'PO
PT
PRT
620
PRT
•Pt
38 30 N
28 00 W
Atlantic Ocean
49 00 N
36 00 E
Indian Ocean
12 40 N
43 20 E
Pacific Ocean
18 44 N
121 40 E
38 43 N
9 08 W
Atlantic Ocean
55 05 N
9 55 E
32 40 N
16 45 W
£ Madt','a27a47bac1092205b104e405575e17426cf7edd08be5ecbaefcb0d81a07e29dd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ff1a13e353a50bee5d4be8599b540a752b6e77b19f2f8182a976b35862ed30',2009,'SA','Saudi Arabia','transnational-issues',1355,'SA
SA
SAU
682
SAU
.sa
25 00 N
45 00 E
24 30 N
38 30 E
21 30 N
39 12 E
21 27 N
39 49 E
Atlantic Ocean
36 00 N
15 00 E
24 05 N
45 15 E
24 38 N
46 43 E
British Virgin Islands
18 27 N
64 37 W
19 30 N
49 00 E
Albania, Bulgaria, Macedonia
42 00 N
22 30 E','5aaee2ff52c5a2f98f749e9cb4da84505da95694601e407ee0af9367f1bba1af','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a035dc01597766d315849fcf2a39e0f9b31170d8848ff9f4a82b8ccdacb9a2bc',2009,'SC','Seychelles','transnational-issues',1356,'SE
SC
SYC
690
SYC
.sc
9 25 S
46 22 E
7 01 S
52 45 E
6 00 S
53 10 E
9 46 S
46 34 E
9 43 S
47 35 E
10 10 S
51 10 E
Kyrgyzstan, Tajikistan,
41 00 N
72 00 E
4 41 S
55 30 E
4 38 S
55 27 E
Asceitftoi
$ (St. lltdeTtfb
tu<anda','f73b970819d3f28ff43d5b1b9a15356838a3f61b65c562984d9b5d423ca16622','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf27d41c19a19930416dfb40aecd1bc8678302dd372858db3fb39fdbfd2f47b7',2009,'SI','Slovenia','transnational-issues',1357,'SI
SI
SVN
705
SVN
.si
46 03 N
1431 E
Venezuela
8 00 N
68 00 W
Swaziland
26 27 S
31 12 E
46 00 N
15 00 E','a949d8cbe89ebf11bae1f107ecc89de16a1273a44fbe49b7efac65e8f44867f3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6386cf22aa38072c068c1c1b9e7f968f2155d6b5bae3f3549ed9f87843408ef1',2009,'SB','Solomon Islands','transnational-issues',1358,'BP
SB
SLB
090
SLB
.sb
8 00 S
159 00 E
7 05 S
121 00 E
North Korea
40 00 N
127 00 E
9 32 S
160 12 E
9 26 S
159 57 E
11 00 S
166 15 E
Holy See
41 54 N
12 27 E
8 00 S
159 00 E
Pacific Ocean
8 00 S
153 00 E','7982b34713981c0feaa53f2a767079330478b6454a612de14f51a27a5504b819','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d20d6f86bdaa74859f3799841fd0192204297f0492bb6cef627338a2d730b9',2009,'TH','Thailand','transnational-issues',1359,'TH
TH
THA
764
THA
.th
13 45 N
100 31 E
15 00 N
100 00 E
15 00 N
100 00 E
Russia
60 00 N
100 00 E
Pacific Ocean
4 50 N
119 35 E
7 12 N
100 36 E
Atlantic Ocean
55 50 N
12 40 E
Atlantic Ocean
30 00 S
15 00 W
Pacific Ocean
10 00 N
113 00 E
South Georgia and the South
54 15 S
36 45 W
Sandwich Islands','44aa4da889e09231a4b05cc0df6cfe02673fce4cb9c78d64f3a1c23ae0227f79','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73059a54332c4a927554d9879d50b4b7f189b6c3cf0df8a11f45ed3033893cad',2009,'WF','Wallis and Futuna','transnational-issues',1360,'WF
WF
WLF
876
WLF
.wf
Minor Outlying Islands
West Bank
WE
PS
PSE
275
PSE
.ps
ISO identifies as Occupied
14 19 S
178 05 W
14 19 S
178 05 W
13 57 S
171 56 W
Taiwan
26 13 N
119 56 E
New Caledonia, Vanuatu
22 20 S
171 20 E
13 17 S
176 10W','816614e80ed736ee242e4f64eda17d8e5543851b5437a0fd8e353c2001a40f2d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b481e43a81896c49225e5e09298e53683d9a28a7cf402fd35f55dcedfe89f4d0',2009,'IO','British Indian Ocean Territory','transnational-issues',1361,'6 00 S
71 30 E
Pacific Ocean
11 22 N
142 36 E
Guernsey, Jersey
49 20 N
2 20 W
Virgin Islands
18 21 N
64 56 W
7 20 S
72 25 E
6 00 S
71 30 E
Pacific Ocean
53 00 N
150 00 E','b0629df5196c475a9ffd49f39bf48fe9cbd86489d26d331baf46dde859bcae4f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09a58cc9056f1ccb8d7a663b9e785075919c3ac7cec958008adf24bccf7a412e',2009,'KR','Korea, Republic of','transnational-issues',1362,'Koror (capital)
Kosovo (region)
Kosrae (island)
Kowloon (city)
Kra, Isthmus of
Krakatoa (volcano)
Krakow (city)
Kuala Lumpur (capital)
Kunashiri (island; also Kunashir)
Kunlun Mountains
Kuril Islands
Kuwait (capital)
Kuznetsk Basin
Kwajalein Atoll
Kyiv (capital)
Kyushu (island)
La Paz (administrative capital)
La Perouse Strait
Labrador (peninsula, region)
Labrador Sea
Laccadive Islands
Laccadive Sea
Lagos (former capital)
Lahore (city)
Lake Erie
Lake Huron
Lake Michigan
Lake Ontario
Lake Superior
Lakshadweep (Laccadive Islands)
Lantau Island
Lao (local name for Laos)
Laptev Sea
Las Palmas (city)
Latakia (region)
Latvija (local name for Latvia)
Lau Group (island group)
Lefkosa (see Nicosia)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)','dea605ea5526952913bff4a16a37b8cc4355bed3ee468c5ed53869f259e99035','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da06009ff03114c7ecab85a5c7303e1df77fce5b4073bbfa45a9f750be1b41d',2009,'MO','Macao','transnational-issues',1363,'Macau (special administrative region)
Macquarie Island
Madagasikara (local name for Madagascar)
Maddalena, Isola
Madeira Islands
Madras (city; see Chennai)
Madrid (capital)
Magellan, Strait of
Maghreb (region)
Magreb (local name for Morocco)
Magyarorszag (local name for Hungary)
Mahe Island
Maiz, Islas del (Corn Islands)
Majorca Island (Isla de Mallorca)
Majuro (capital)
Makassar Strait
Makedonija (local name for Macedonia)
Malabo (capital)
Malacca, Strait of
Malagasy Republic
Malay Archipelago
Entry in Latitude Longitude
The World Factbook (deg min) (deg min)','31e4500515bca990771da0312066693ec6f365b26edf46656bfcd19234d01936','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ce8b5c0b8281ffea3f3e5a35a714c6899f42d28019de2cc8b3f9ab879eda5fe',2009,'','','transnational-issues',9,'Disputes - international:
Refugees and internally displaced persons:
refugees
IDPs
Trafficking in persons:
current situation
tier rating
Illicit drugs:
======================================================================
The World Factbook (2009) - Country Listing
[Transcriber''s note: To search on a country in this file, prefix the
country''s name with "@", e.g. "@Afghanistan". "Afghanistan" will find
all occurrences; prefixing it with "@" will find the correct location.]
World
A','fbadcbaedff538a10657a8dcdb2f17023165a2937670304d51b15004ff6cb62c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a14e7a6f98509cffba7ceb7e7392d6a3004cd0580b5364e6b75eb097ae9ff217',2009,'ZW','Zimbabwe','transnational-issues',10,'T
Taiwan
E
European Union
Field Listings
[Transcriber''s note: To search on a field code in this file, prefix
the code number with "@", e.g. "@2001". "2001" will find all
occurrences; prefixing it with "@" will find the correct location.]
Code Field Description
2001 GDP (purchasing power parity)
2002 Population growth rate
2003 GDP - real growth rate
2004 GDP - per capita (PPP)
2005 Affiliation
2006 Dependency status
2007 Diplomatic representation from the US
2008 Transportation - note
2010 Age structure
2011 Geographic coordinates
2012 GDP - composition by sector
2013 Radio broadcast stations
2014 Radios
2015 Television broadcast stations
2016 Televisions
2018 Sex ratio
2019 Heliports
2020 Elevation extremes
2021 Natural hazards
2022 People - note
2023 Area - comparative
2024 Military service age and obligation
2025 Manpower fit for military service
2026 Manpower reaching militarily significant age
2028 Background
2030 Airports - with paved runways
2031 Airports - with unpaved runways
2032 Environment - current issues
2033 Environment - international agreements
2034 Military expenditures
2038 Electricity - production
2042 Electricity - consumption
2043 Electricity - imports
2044 Electricity - exports
2045 Electricity - production by source
2046 Population below poverty line
2047 Household income or consumption by percentage share
2048 Labor force - by occupation
2049 Exports - commodities
2050 Exports - partners
2051 Administrative divisions
2052 Agriculture - products
2053 Airports
2054 Birth rate
2055 Military branches
2056 Budget
2057 Capital
2058 Imports - commodities
2059 Climate
2060 Coastline
2061 Imports - partners
2062 Economic aid - donor
2063 Constitution
2064 Economic aid - recipient
2065 Currency (code)
2066 Death rate
2068 Dependent areas
2070 Disputes - international
2075 Ethnic groups
2076 Exchange rates
2077 Executive branch
2078 Exports
2079 Debt - external
2080 Fiscal year
2081 Flag description
2085 Roadways
2086 Illicit drugs
2087 Imports
2088 Independence
2089 Industrial production growth rate
2090 Industries
2091 Infant mortality rate
2092 Inflation rate (consumer prices)
2093 Waterways
2094 Judicial branch
2095 Labor force
2096 Land boundaries
2097 Land use
2098 Languages
2100 Legal system
2101 Legislative branch
2102 Life expectancy at birth
2103 Literacy
2105 Manpower available for military service
2106 Maritime claims
2107 International organization participation
2108 Merchant marine
2109 National holiday
2110 Nationality
2111 Natural resources
2112 Net migration rate
2113 Geography - note
2115 Political pressure groups and leaders
2116 Economy - overview
2117 Pipelines
2118 Political parties and leaders
2119 Population
2120 Ports and terminals
2121 Railways
2122 Religions
2123 Suffrage
2124 Telephone system
2125 Terrain
2127 Total fertility rate
2128 Government type
2129 Unemployment rate
2137 Military - note
2138 Communications - note
2140 Government - note
2141 Group
2142 Country name
2144 Location
2145 Map references
2146 Irrigated land
2147 Area
2149 Diplomatic representation in the US
2150 Telephones - main lines in use
2151 Telephones - mobile cellular
2152 Internet Service Providers (ISPs)
2153 Internet users
2154 Internet country code
2155 HIV/AIDS - adult prevalence rate
2156 HIV/AIDS - people living with HIV/AIDS
2157 HIV/AIDS - deaths
2158 Currency code
2172 Distribution of family income - Gini index
2173 Oil - production
2174 Oil - consumption
2175 Oil - imports
2176 Oil - exports
2177 Median age
2178 Oil - proved reserves
2179 Natural gas - proved reserves
2180 Natural gas - production
2181 Natural gas - consumption
2182 Natural gas - imports
2183 Natural gas - exports
2184 Internet hosts
2185 Investment (gross fixed)
2186 Public debt
2187 Current account balance
2188 Reserves of foreign exchange and gold
2189 Union name
2190 Political structure
2191 Member states
2192 Preliminary statement
2193 Major infectious diseases
2194 Refugees and internally displaced persons
2195 GDP (official exchange rate)
2196 Trafficking in persons
2198 Stock of direct foreign investment - at home
2199 Stock of direct foreign investment - abroad
2200 Market value of publicly traded shares
2201 Total renewable water resources
2202 Freshwater withdrawal
2203 Geographic overview
2204 Economy of the area administered by Turkish Cypriots
2205 School life expectancy (primary to tertiary
2206 Education expenditures
2207 Central bank discount rate
2208 Commercial bank prime lending rate
2209 Stock of money
2210 Stock of quasi money
2211 Stock of domestic credit
2212 Urbanization
======================================================================
References :: Guide to Country Comparisons
[Transcriber''s note: To search on a rank order in this file, prefix
the rank''s name with "@", e.g. "@Population". "Population" will find
all occurrences; prefixing it with "@" will find the correct location.]
Country Comparison pages are presorted lists of data from selected
Factbook data fields. Country Comparison pages are generally given
in descending order - highest to lowest - such as Population and
Area. The two exceptions are Unemployment Rate and Inflation Rate,
which are in ascending - lowest to highest - order. Country
Comparison pages are available for the following 58 fields in six of
the nine Factbook categories.','d0181232c907fe5eb331024585489d929a35ac4e3d32a357396592a9653de43c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95c29f491066f32f84de3f92b167a77704bb3fff40912a13aca41b3b10ebeecb',2009,'TC','Turks and Caicos Islands','transnational-issues',30,'This category includes four entries - Disputes - international,
Refugees and internally displaced persons, Trafficking in persons,
and Illicit drugs - that deal with current issues going beyond
national boundaries.','89418a796b4285152b71e5f5bd753c4443456c4e6f9d7deec68e012a1d5041f8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

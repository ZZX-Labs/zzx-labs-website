SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c8d42b81a10dc8fdb42e5babd6cbbc51a389b81164d1df2a8e06328106f1cbe',2009,'GL','Greenland','terrorism',96,'Geography ::Djibouti
Location:
Eastern Africa, bordering the Gulf of Aden and the Red Sea, between
Eritrea and Somalia
Geographic coordinates:
11 30 N, 43 00 E
Map references:
Africa
Area:
total: 23,200 sq km
country comparison to the world: 150
land: 23,180 sq km
water: 20 sq km
Area - comparative:
slightly smaller than Massachusetts
Land boundaries:
total: 516 km
border countries: Eritrea 109 km, Ethiopia 349 km, Somalia 58 km
Coastline:
314 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate:
desert; torrid, dry
Terrain:
coastal plain and plateau separated by central mountains
Elevation extremes:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources:
geothermal areas, gold, clay, granite, limestone, marble, salt,
diatomite, gypsum, pumice, petroleum
Land use:
arable land: 0.04%
permanent crops: 0%
other: 99.96% (2005)
Irrigated land:
10 sq km (2003)
Total renewable water resources:
0.3 cu km (1997)
Freshwater withdrawal (domestic/industrial/agricultural):
total: 0.02 cu km/yr (84%/0%/16%)
per capita: 25 cu m/yr (2000)
Natural hazards:
earthquakes; droughts; occasional cyclonic disturbances from the
Indian Ocean bring heavy rains and flash floods
Environment - current issues:
inadequate supplies of potable water; limited arable land;
desertification; endangered species
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Geography - note:
strategic location near world''s busiest shipping lanes and close to
Arabian oilfields; terminus of rail traffic into Ethiopia; mostly
wasteland; Lac Assal (Lake Assal) is the lowest point in Africa
People ::Djibouti
Population:
516,055 (July 2009 est.)
country comparison to the world: 168
Age structure:
0-14 years: 43.3% (male 112,135/female 111,343)
15-64 years: 53% (male 141,298/female 132,360)
65 years and over: 3.7% (male 9,502/female 9,417) (2009 est.)
Median age:
total: 18.1 years
male: 18.5 years
female: 17.8 years (2009 est.)
Population growth rate:
1.903% (2009 est.)
country comparison to the world: 66
Birth rate:
38.13 births/1,000 population (2009 est.)
country comparison to the world: 24
Death rate:
19.1 deaths/1,000 population (July 2009 est.)
country comparison to the world: 9
Net migration rate:
NA (2009 est.)
Urbanization:
urban population: 87% of total population (2008)
rate of urbanization: 2.2% annual rate of change (2005-10 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1.01 male(s)/female
total population: 1.04 male(s)/female (2009 est.)
Infant mortality rate:
total: 97.51 deaths/1,000 live births
country comparison to the world: 12
male: 104.98 deaths/1,000 live births
female: 89.82 deaths/1,000 live births (2009 est.)
Life expectancy at birth:
total population: 43.37 years
country comparison to the world: 217
male: 41.89 years
female: 44.89 years (2009 est.)
Total fertility rate:
5.06 children born/woman (2009 est.)
country comparison to the world: 28
HIV/AIDS - adult prevalence rate:
3.1% (2007 est.)
country comparison to the world: 22
HIV/AIDS - people living with HIV/AIDS:
16,000 (2007 est.)
country comparison to the world: 83
HIV/AIDS - deaths:
1,100 (2007 est.)
country comparison to the world: 71
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A and E, and typhoid fever
vectorborne disease: malaria
note: highly pathogenic H5N1 avian influenza has been identified in
this country; it poses a negligible risk with extremely rare cases
possible among US citizens who have close contact with birds (2009)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups:
Somali 60%, Afar 35%, other 5% (includes French, Arab, Ethiopian,
and Italian)
Religions:
Muslim 94%, Christian 6%
Languages:
French (official), Arabic (official), Somali, Afar
Literacy:
definition: age 15 and over can read and write
total population: 67.9%
male: 78%
female: 58.4% (2003 est.)
School life expectancy (primary to tertiary education):
total: 4 years
male: 5 years
female: 4 years (2006)
Education expenditures:
8.4% of GDP (2006)
country comparison to the world: 11
Government ::Djibouti
Country name:
conventional long form: Republic of Djibouti
conventional short form: Djibouti
local long form: Republique de Djibouti/Jumhuriyat Jibuti
local short form: Djibouti/Jibuti
former: French Territory of the Afars and Issas, French Somaliland
Government type:
republic
Capital:
name: Djibouti
geographic coordinates: 11 35 N, 43 09 E
time difference: UTC+3 (8 hours ahead of Washington, DC during
Standard Time)
Administrative divisions:
6 districts (cercles, singular - cercle); Ali Sabieh, Arta, Dikhil,
Djibouti, Obock, Tadjourah
Independence:
27 June 1977 (from France)
National holiday:
Independence Day, 27 June (1977)
Constitution:
approved by referendum 4 September 1992; note - constitution allows
for multiparties
Legal system:
based on French civil law system, traditional practices, and Islamic
law; accepts ICJ jurisdiction with reservations
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Ismail Omar GUELLEH (since 8 May 1999)
head of government: Prime Minister Mohamed Dileita DILEITA (since 4
March 2001)
cabinet: Council of Ministers responsible to the president
elections: president elected by popular vote for a six-year term
(eligible for a second term); election last held 8 April 2005 (next
to be held by April 2011); prime minister appointed by the president
election results: Ismail Omar GUELLEH reelected president; percent
of vote - Ismail Omar GUELLEH 100%
Legislative branch:
unicameral Chamber of Deputies or Chambre des Deputes (65 seats;
members elected by popular vote for five-year terms)
elections: last held 8 February 2008 (next to be held 2013)
election results: percent of vote by party - NA; seats - UMP
(coalition of parties associated with President Ismail Omar GUELLAH)
65
Judicial branch:
Supreme Court or Cour Supreme
Political parties and leaders:
Democratic National Party or PND [ADEN Robleh Awaleh]; Democratic
Renewal Party or PRD [Abdillahi HAMARITEH]; Djibouti Development
Party or PDD [Mohamed Daoud CHEHEM]; Front pour la Restauration de
l''Unite Democratique or FRUD [Ali Mohamed DAOUD]; People''s Progress
Assembly or RPP [Ismail Omar GUELLEH] (governing party); Peoples
Social Democratic Party or PPSD [Moumin Bahdon FARAH]; Republican
Alliance for Democracy or ARD [Ahmed YOUSSOUF]; Union for a
Presidential Majority or UMP (a coalition of parties including RPP,
FRUD, PND, and PPSD) [Mohamed Dileita DILEITA]; Union for Democracy
and Justice or UDJ
Political pressure groups and leaders:
Union for Presidential Majority UMP (coalition includes RPP, FRUD,
PPSD and PND); Union for Democratic Changeover or UAD (opposition
coalition includes ARD, MRDD, and UDJ)
International organization participation:
ACCT, ACP, AfDB, AFESD, AMF, AU, COMESA, FAO, G-77, IBRD, ICAO,
ICCt, ICRM, IDA, IDB, IFAD, IFC, IFRCS, IGAD, ILO, IMF, IMO,
Interpol, IOC, ITU, ITUC, LAS, MIGA, MINURSO, NAM, OIC, OIF, OPCW,
UN, UNCTAD, UNESCO, UNIDO, UNWTO, UPU, WCO, WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Roble OLHAYE Oudine
chancery: Suite 515, 1156 15th Street NW, Washington, DC 20005
telephone: [1] (202) 331-0270
FAX: [1] (202) 331-0302
Diplomatic representation from the US:
chief of mission: Ambassador James C. SWAN
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40
Flag description:
two equal horizontal bands of light blue (top) and light green with
a white isosceles triangle based on the hoist side bearing a red
five-pointed star in the center
Economy ::Djibouti
Economy - overview:
The economy is based on service activities connected with the
country''s strategic location and status as a free trade zone in the
Horn of Africa. Two-thirds of Djibouti''s inhabitants live in the
capital city; the remainder are mostly nomadic herders. Scanty
rainfall limits crop production to fruits and vegetables, and most
food must be imported. Djibouti provides services as both a transit
port for the region and an international transshipment and refueling
center. Imports and exports from landlocked neighbor Ethiopia
represent 85% of port activity at Djibouti''s container terminal.
Djibouti has few natural resources and little industry. The nation
is, therefore, heavily dependent on foreign assistance to help
support its balance of payments and to finance development projects.
An unemployment rate of nearly 60% in urban areas continues to be a
major problem. While inflation is not a concern, due to the fixed
tie of the Djiboutian franc to the US dollar, the artificially high
value of the Djiboutian franc adversely affects Djibouti''s balance
of payments. Per capita consumption dropped an estimated 35% between
1999 and 2006 because of recession, civil war, and a high population
growth rate (including immigrants and refugees). Faced with a
multitude of economic difficulties, the government has fallen in
arrears on long-term external debt and has been struggling to meet
the stipulations of foreign aid donors.
GDP (purchasing power parity):
$1.891 billion (2008 est.)
country comparison to the world: 184
$1.786 billion (2007 est.)
$1.696 billion (2006 est.)
note: data are in 2008 US dollars
GDP (official exchange rate):
$982 million (2008 est.)
GDP - real growth rate:
5.9% (2008 est.)
country comparison to the world: 64
5.3% (2007 est.)
4.8% (2006 est.)
GDP - per capita (PPP):
$2,700 (2008 est.)
country comparison to the world: 170
$2,600 (2007 est.)
$2,500 (2006 est.)
note: data are in 2008 US dollars
GDP - composition by sector:
agriculture: 3.2%
industry: 14.9%
services: 81.9% (2006 est.)
Labor force:
351,700 (2007)
country comparison to the world: 156
Labor force - by occupation:
agriculture: NA%
industry: NA%
services: NA%
Unemployment rate:
59% (2007 est.)
country comparison to the world: 194
note: data are for urban areas, 83% in rural areas
Population below poverty line:
42% (2007 est.)
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Budget:
revenues: $135 million
expenditures: $182 million (1999 est.)
Inflation rate (consumer prices):
5% (2007 est.)
country comparison to the world: 85
Commercial bank prime lending rate:
NA
Stock of money:
$462.7 million (31 December 2008)
country comparison to the world: 97
$380 million (31 December 2007)
Stock of quasi money:
$338 million (31 December 2008)
country comparison to the world: 112
$284.1 million (31 December 2007)
Stock of domestic credit:
$269.9 million (31 December 2008)
country comparison to the world: 121
$224.7 million (31 December 2007)
Agriculture - products:
fruits, vegetables; goats, sheep, camels, animal hides
Industries:
construction, agricultural processing
Electricity - production:
280 million kWh (2007 est.)
country comparison to the world: 168
Electricity - consumption:
260.4 million kWh (2007 est.)
country comparison to the world: 170
Electricity - exports:
0 kWh (2008 est.)
Electricity - imports:
0 kWh (2008 est.)
Oil - production:
0 bbl/day (2008 est.)
country comparison to the world: 183
Oil - consumption:
13,000 bbl/day (2008 est.)
country comparison to the world: 141
Oil - exports:
19.18 bbl/day (2007 est.)
country comparison to the world: 137
Oil - imports:
8,476 bbl/day (2007 est.)
country comparison to the world: 142
Oil - proved reserves:
0 bbl (1 January 2009 est.)
country comparison to the world: 181
Natural gas - production:
0 cu m (2008 est.)
country comparison to the world: 190
Natural gas - consumption:
0 cu m (2008 est.)
country comparison to the world: 191
Natural gas - exports:
0 cu m (2008)
country comparison to the world: 190
Natural gas - imports:
0 cu m (2008 est.)
country comparison to the world: 191
Natural gas - proved reserves:
0 cu m (1 January 2009 est.)
country comparison to the world: 188
Current account balance:
-$212 million (2007 est.)
country comparison to the world: 90
Exports:
$340 million (2006)
country comparison to the world: 170
Exports - commodities:
reexports, hides and skins, coffee (in transit)
Exports - partners:
Somalia 79.9%, UAE 4.1%, Yemen 4.1% (2008)
Imports:
$1.555 billion (2006)
country comparison to the world: 159
Imports - commodities:
foods, beverages, transport equipment, chemicals, petroleum products
Imports - partners:
Saudi Arabia 20.5%, India 20.5%, China 10.6%, US 6%, Malaysia 6%
(2008)
Debt - external:
$428 million (2006)
country comparison to the world: 167
Exchange rates:
Djiboutian francs (DJF) per US dollar - 177.71 (2007), 174.75
(2006), 177.72 (2005), 177.72 (2004), 177.72 (2003)
Communications ::Djibouti
Telephones - main lines in use:
10,800 (2008)
country comparison to the world: 201
Telephones - mobile cellular:
44,100 (2005)
country comparison to the world: 196
Telephone system:
general assessment: telephone facilities in the city of Djibouti are
adequate, as are the microwave radio relay connections to outlying
areas of the country
domestic: microwave radio relay network; mobile cellular coverage is
primarily limited to the area in and around Djibouti city
international: country code - 253; landing point for the SEA-ME-WE-3
optical telecommunications submarine cable with links to Asia, the
Middle East, and Europe; satellite earth stations - 2 (1 Intelsat -
Indian Ocean and 1 Arabsat); Medarabtel regional microwave radio
relay telephone network (2007)
Radio broadcast stations:
AM 1, FM 2, shortwave 0 (2001)
Television broadcast stations:
1 (2001)
Internet country code:
.dj
Internet hosts:
199 (2009)
country comparison to the world: 188
Internet users:
13,000 (2008)
country comparison to the world: 197
Transportation ::Djibouti
Airports:
13 (2009)
country comparison to the world: 152
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2009)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2009)
Railways:
total: 100 km (Djibouti segment of the 781 km Addis Ababa-Djibouti
railway)
country comparison to the world: 127
narrow gauge: 100 km 1.000-m gauge
note: railway is under joint control of Djibouti and Ethiopia but is
largely inoperable (2008)
Roadways:
total: 3,065 km
country comparison to the world: 165
paved: 1,226 km
unpaved: 1,839 km (2000)
Ports and terminals:','27ad52fc2ef1172f847f06fef1daa9f671830fd8987a986654da533fc7e2d1c1','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17ea56776bd7152d549f9c7df3b85da565c5900f33d65a775cc3a95b7696a14e',2009,'DJ','Djibouti','terrorism',97,'Transportation - note:
the International Maritime Bureau reports offshore waters in the
Gulf of Aden are high risk for piracy; numerous vessels, including
commercial shipping and pleasure craft, have been attacked and
hijacked both at anchor and while underway; crew, passengers, and
cargo are held for ransom
Military ::Djibouti
Military branches:
Djibouti National Army (includes Navy and Air Force)
Military service age and obligation:
18 years of age for voluntary military service; 16-25 years of age
for voluntary military training; no conscription (2008)
Manpower available for military service:
males age 16-49: 111,274
females age 16-49: 105,168 (2008 est.)
Manpower fit for military service:
males age 16-49: 55,173
females age 16-49: 52,825 (2009 est.)
Manpower reaching militarily significant age annually:
male: 5,778
female: 5,771 (2009 est.)
Military expenditures:
3.8% of GDP (2006)
country comparison to the world: 33
Transnational Issues ::Djibouti
Disputes - international:
Djibouti maintains economic ties and border accords with
"Somaliland" leadership while maintaining some political ties to
various factions in Somalia; Kuwait is chief investor in the 2008
restoration and upgrade of the Ethiopian-Djibouti rail link
Refugees and internally displaced persons:
refugees (country of origin): 8,642 (Somalia) (2007)
page last updated on November 11, 2009
======================================================================
@Dominica (Central America and Caribbean)
Introduction ::Dominica','cdce6e744b58902a2129547d782a509931f701a52d418ab70f3e913844c6d9e9','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99f3522ff816d1c6fb54d733f6015b8ee01bcabd2af250dfaaa04a31f71e7db4',2009,'AM','Armenia','energy',118,'Exports— partners: Germany 18.3%,
Netherlands 14-1%, Belgium 13.3%,
Russia 13.1%, Israel 7%, US 6.1%,
Georgia 5.1%, Iran 4.9% (2006)
Imports: $2,714 billion f.o.b. (2007 est.)
Imports— commodities: natural gas,
petroleum, tobacco products, foodstuffs,
diamonds
Imports— partners: Russia 21.8%,
Ukraine 7.8%, Belgium 7.6%,
Turkmenistan 7.1%, Italy 6.1%,
Germany 5.7%, Iran 5.7%, Israel 4.8%,
US 4.5%, Georgia 4.1% (2006)
Economic aid— recipient: ODA, $180
million (2007)
Reserves of foreign exchange and gold:
$1,646 billion (December 2007 est.)
Debt— external: $1,372 billion (31
December 2007 est.)
Market value of publicly traded shares:
$42.8 million (2005)
Currency (code): dram (AMD)
Currency code: AMD
Exchange rates: drams per US dollar—
344.06 (2007), 414.69 (2006), 457.69
(2005), 533.45 (2004), 578.76 (2003)
Fiscal year: calendar year
Telephones— main lines in use:
594,400 (2005)
Telephones— mobile cellular: 318,000
(2005)
Telephone system:
general assessment: telecommunications
investments have made major inroads in
modernizing and upgrading the outdated
telecommunications network inherited
from the Soviet era; now 100% privately
owned and undergoing modernization
and expansion; mobile-cellular services
monopoly terminated in late 2004 and a
second provider began operations in
mid-2005
domestic: reliable modern landline and
mobile-cellular services are available
across Yerevan in major cities and towns;
significant but ever-shrinking gaps
remain in mobile-cellular coverage in
rural areas
international: country code — 374;
Yerevan is connected to the Trans-Asia-
Europe fiber-optic cable through Iran;
additional international service is avail¬
able by microwave radio relay and land¬
line connections to the other countries
of the Commonwealth of Independent
States, through the Moscow interna¬
tional switch, and by satellite to the rest
of the world; satellite earth stations — 3
(2007)
Radio broadcast stations: AM 9, FM
16, shortwave 1 (2006)
Radios: 850,000 (1997)
Television broadcast stations: 48 (pri¬
vate television stations alongside 2
public networks; major Russian channels
widely available) (2006)
Televisions: 825,000 (1997)
Internet country code : .am
Internet hosts: 8,270 (2007)
Internet Service Providers (ISPs): 9
(2001)
Internet users: 172,800 (2006)
35
THE CIA WORLD FACTBOOK
Airports: 12 (2007)
Airports— with paved runways:
total: 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 4
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 2
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Pipelines: gas 2,036 km (2007)
Railways:
total: 839 km
broad gauge: 839 km 1.520-m gauge (828
km electrified)
note: some lines are out of service (2006)
Roadways:
total: 7,700 km
paved: 7,700 km (includes 1,561 km of
expressways) (2006)','736ac5b1a1fe66919ceb5f9d44ec07c6f8aa6b1d38b66086d17e49d4f9276043','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

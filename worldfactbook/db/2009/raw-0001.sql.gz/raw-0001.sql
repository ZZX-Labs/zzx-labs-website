SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e15d2cc9d871252f7a68dc218ce5cace93f9e671fa970d05165da832ebdd2f0a',2009,'','','raw',1,'wsm
%
CENTRAL INTELLIGENCE AGENCY
Digitized by the Internet Archive
in 2018 with funding from
Kahle/Austin Foundation
https://archive.org/details/ciaworldfactbook0000unit_t5b5
SCH
R910 U58c
United States. Central
Intelligence Agency.
CIA World Factbook 2009
THE CIA
WORLD
FACTBOO K
2009
FOR REFERENCE
Do Not Take From This Room
CENTRAL INTELLIGENCE AGENCY
Perkiomen Valley Library at Schwenksviile
A Branch of MC-NPL
Skyhorse Publishing
Copyright © 2008 by Skyhorse Publishing, Inc.
All Rights Reserved. No part of this book may be reproduced in any manner without the
express written consent of the publisher, except in the case of brief excerpts in critical reviews
or articles. All inquiries should be addressed to Skyhorse Publishing, 555 Eighth Avenue,
Suite 903, New York, NY 10018.
Skyhorse Publishing books may be purchased in bulk at special discounts for sales promotion,
corporate gifts, fund-raising, or educational purposes. Special editions can also be created
to specifications. For details, contact the Special Sales Department, Skyhorse Publishing,
555 Eighth Avenue, Suite 903, New York, NY 10018 or info@skyhorsepublishing.com.
www.skyhorsepublishing.com
ISBN: 978-1-60239-282-3
10 987654321
In general, information available as of June 2008 was used in the preparation of this edition.
Printed in the United States of America','e24bd9744684f1a9faaf009ec86ad97830ccce012b8a09ef0205f69f7e208845','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70278adf2a1e888e02bf60c822e9ccdbc939bad4182b7198e5fab0524a308434',2009,'','','raw',1,'The Project Gutenberg EBook of The 2009 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2009 CIA World Factbook
Author: United States. Central Intelligence Agency.
Release Date: April 11, 2011 [EBook #35829]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2009 CIA WORLD FACTBOOK ***
Produced by Al Haines
THE CIA WORLD FACTBOOK 2009
CONTENTS
What''s New?
Did You Know?
Guide to Country Profiles
Countries and Locations
Field Listings
Rank Orders
Appendixes
Notes and Definitions
History of the CIA Factbook
Contributors and Copyright Information
Frequently Asked Questions (FAQs)
THE WORLD FACTBOOK :: WHAT''S NEW
November 13, 2009
Recent elections and governmental changes recorded for
Afghanistan, Aruba, Fiji, Germany, Haiti, Marshall Islands,
Mongolia, Tunisia, and Uruguay. In the Economy category, some
20 macro-economic fields have been updated with the latest
data. New NASA space photos added for the Atlantic, Indian,
and Pacific Oceans, as well as for Montserrat and the World;
new ground photos added for Cambodia and France.
October 30, 2009
In the Economy category, all the energy-related fields have
been updated with the latest data; new photos added for
Norway and Poland.
October 14, 2009
In addition to regular informational updates, new photos have
been added for Denmark, Estonia, Finland, Russia, and Sweden.
October 02, 2009
In the Transportation category, updates have been made to the
"Airports" and "Heliports" fields; new photos added for
Libya, Turkey, and the United Kingdom.
September 17, 2009
NASA images taken from space have been introduced to enhance
various country photo presentations. Significant numbers of
high altitude photos appear under China, Egypt, Spain,
Australia, and New Zealand, but can also be found scattered
among other country entries. In the Economy category,
statistics for "Distribution of family income - Gini index,"
"Public debt," and "Debt - external" now include two year''s
worth of data.
September 03, 2009
In the Economy category, statistics for "Current Account
Balance," "Exports," "Imports," "Reserves of foreign exchange
and gold," "Stock of direct foreign investment - at home,"
and "Stock of direct foreign investment - abroad" now include
two year''s worth of data; statistics for "Market value of
publicly traded shares" now include three year''s worth of
data. New photos added for Austria, France, Monaco,
Netherlands, and Netherlands Antilles.
August 17, 2009
Various rail gauge line lengths have been updated for all
countries in the Railways entry; selected economic and
political entries also updated.
July 31, 2009
In the Economy category, statistics for "Central bank
discount rate," "Commercial bank prime lending rate," "Stock
of money," "Stock of quasi money," and "Stock of domestic
credit" now include two year''s worth of data.
July 20, 2009
Latest updates include changes to the chief of state or head
of government in Bosnia and Herzegovina, Croatia, Lithuania,
and Panama. New photographs have been added for Spain,
Portugal, Gibraltar, and South Africa.
July 01, 2009
With the launch of the new Web site, the former "Rank Order"
function was renamed "Country Comparisons." The link to
Country Comparisons may be found under the References tab. In
addition, many of the regional reference maps now incorporate
both elevation and vegetation on landmasses, and bathymetry
for ocean areas. Statistics for "Unemployment rate" and
"Inflation rate (consumer prices)" now include two year''s
worth of data.
June 08, 2009
Completely redesigned website - presenting a cleaner look,
improved navigation, and a host of added features - launched
on the World Wide Web. Among the major enhancements are
downloadable and printable photos for nearly 100 countries, a
"Did You Know?" section explaining the impact of the Factbook
around the world, and built-in world rankings for many of the
Factbook information fields. Government sections reflect the
results of recent parliamentary elections in Kuwait - where
women were elected for the first time - and India, as well as
presidential elections in Lithuania, Mongolia, Panama, and
South Africa.
April 27, 2009
Significant updates made to the People and Economy
categories; statistics for "GDP - real growth rate" and "GDP
- per capita" (at purchasing power parity) now include three
year''s worth of data, in 2008 dollars. The Urbanization entry
under People expanded to include all countries.
April 03, 2009
In addition to regular country updates, statistics for "GDP
(purchasing power parity)" now include three year''s worth of
data, in 2008 dollars.
March 20, 2009
Recent major leadership changes in Guinea-Bissau, Latvia, and
Madagascar included in the Government sections of those
countries.
March 02, 2009
Latest US Census Bureau figures - updating basic demographic
data for all countries - entered into the database. Entries
on religions, languages, ethnic groups, and literacy also
updated.
February 06, 2009
Country information updated across all categories. Economic
data now includes 2008 estimates where available.
November 05, 2008
In order to provide more information on the nature and global
dimensions of the current financial crisis, five additional
fields appended to the Economy category: "Central bank
discount rate," "Commercial bank prime lending rate," "Stock
of money," "Stock of quasi money," and "Stock of domestic
credit."
August 06, 2008
In the People category, two new fields provide information on
education in terms of opportunity and resources: "School Life
Expectancy" and "Education expenditures."
November 06, 2007
In the Geography category, two new fields focus on the vital
resource of water: "Total renewable water resources" and
"Freshwater withdrawal."
October 31, 2007
Three new fields added to the Economy category: "Stock of
direct foreign investment - abroad," "Stock of direct foreign
investment - at home," "Market value of publicly traded
shares."
Ongoing
Revision of some individual country maps, first introduced in
the 2001 edition, continues. Several regional maps have been
updated to reflect boundary changes and place name spelling
changes.
======================================================================
About :: DID YOU KNOW?
The World Factbook is one of the US Government''s most accessed
publications.
The World Factbook, produced for US policymakers and coordinated
throughout the US Intelligence Community, presents the basic realities
about the world in which we live. We share these facts with the people
of all nations in the belief that knowledge of the truth underpins the
functioning of free societies.
Who uses The World Factbook?
A wide variety of folks including US Government officials, researchers,
news organizations, corporations, geographers, teachers, professors,
librarians, and students. In short, anyone looking for an expansive
body of international data on a recently updated Web site.
The World Factbook is a one-stop reference site.
Although many of the facts presented in The Factbook may be found in
various other publications, they are conveniently gathered together
in one place only at The World Factbook Web site.
The World Factbook is a unique reference in that it is updated
continuously - on average, every two weeks.
Information in The Factbook is collected from - and coordinated with -
a wide variety of US Government agencies, as well as from hundreds of
published sources.
======================================================================
References :: Guide to Country Profiles
These are the Categories, Fields, and subfields of information
generally recorded for each country. Links are to the Definitions
and Notes about each entry.','baf06344c439a2e26591727e6f3f1c85bffbad0ee84ff89dda7550869b04baac','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46ce2984ee4b7b22228db5f18f4a69774ff04c8cba699532e66d3e8d8fbd95b6',2009,'US','United States','military-and-security',67,'Military branches
Military service age and obligation
Manpower available for military service
males age 15-49
females age 1 5-49
Manpower fit for military service
males age 1 5-49
females age 1 5-49
Manpower reaching military age annually
males
females
Military expenditures— percent of GDP
Military— note
Military expenditures— percent of
GDP: 2.4% (2005 est.)
Military branches: US Army, US Navy
(includes Marine Corps), US Air Force,
US Coast Guard; note — Coast Guard
administered in peacetime by the
Department of Homeland Security, but
in wartime reports to the Department of
the Navy (2008)
Military service age and obligation: 18
years of age; 17 years of age with written
parental consent (2006)
Manpower available for military
service:
males age 1 6^49: 72,715,332
females age 16-49: 71,638,785 (2008
est.)
Manpower fit for military service:
males age 16^9: 59,413,358
females age 16-49: 59,187,183 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 2,186,440
females age 16-4 9: 2,079,688 (2008 est.)
Military expenditures— percent of
GDP: 4.06% (2005 est.)','68cad447aaa3e47b6b920d553d2beab18bebc80f84672321ee64f646cbf92042','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a75530ac5b71f28ad58317a5068d098acfca575878ccfd7be9cc2cf990f77465',2009,'AF','Afghanistan','military-and-security',72,'Military branches: Afghan Armed
Forces: Afghan National Army (ANA,
includes Afghan National Army Air
Corps) (2008)
Military service age and obligation: 22
years of age; inductees are contracted
into service for a 4-year term (2005)
Manpower available for military
service:
males age 16-49: 7,431,147
females age 16-49: 7,004,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,234,180
females age 16-49: 3,946,685 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 1 6—49 : 371,451
females age 16-49: 351,295 (2008 est.)
Military expenditures— percent of
GDP: 1.9% (2006 est.)
Disputes— international : — interna¬
tional: Pakistan, with UN and other
international assistance, repatriated 2.3
million Afghan refugees with less than a
million still remaining, many at their
own choosing; Pakistan has proposed
and Afghanistan protests construction of
a fence and laying of mines along por¬
tions of their border; Coalition and
Pakistani forces continue to monitor
remote tribal areas to control the border
with Afghanistan and stem terrorist and
other illegal activities
Refugees and internaily displaced per¬
sons: internally displaced persons: IDPs:
132,246 (mostly Pashtuns and Kuchis
displaced in south and west due to
drought and instability) (2007)
Illicit drugs: world’s largest producer of
opium; cultivation dropped 48% to
107,400 hectares in 2005; better weather
and lack of widespread disease returned
opium yields to normal levels, meaning
potential opium production declined by
only 10% to 4,475 metric tons; if the
entire poppy crop were processed, it is
estimated that 526 metric tons of heroin
could be processed; many narcotics-pro-
cessing labs throughout the country; drug
trade is a source of instability and some
antigovernment groups profit from the
trade; significant domestic use of opiates;
80-90% of the heroin consumed in
Europe comes from Afghan opium; vul¬
nerable to narcotics money laundering
through informal financial networks;
source of hashish
Mediterranean Sea
}
J 6 mi
- i <
CYPRUS ■
Art* . <
{Gtwk Cypnot area)
api&nM
any
Akrolin
Cape
/evgttti
Military— note: Akrotiri has a full RAF
base, Headquarters for British Forces on
Cyprus, and Episkopi Support Unit
Background: Albania declared its inde¬
pendence from the Ottoman Empire in
1912, but was conquered by Italy in 1939.
Communist partisans took over the
country in 1944- Albania allied itself first
with the USSR (until 1960), and then
with China (to 1978). In the early 1990s,
Albania ended 46 years of xenophobic
Communist rule and established a multi¬
party democracy. The transition has
proven challenging as successive govern¬
ments have tried to deal with high unem¬
ployment, widespread corruption, a
dilapidated physical infrastructure, pow¬
erful organized crime networks, and com¬
bative political opponents. Albania has
made progress in its democratic develop¬
ment since first holding multiparty elec¬
tions in 1991, but deficiencies remain.
International observers judged elections
to be largely free and fair since the restora¬
tion of political stability following the col¬
lapse of pyramid schemes in 1997. In the
2005 general elections, the Democratic
Party and its allies won a decisive victory
on pledges of reducing crime and corrup¬
tion, promoting economic growth, and
decreasing the size of government. The
election, and particularly the orderly tran¬
sition of power, was considered an impor¬
tant step forward. Although Albania’s
economy continues to grow, the country is
still one of the poorest in Europe, ham¬
pered by a large informal economy and an
inadequate energy and transportation
infrastructure. Albania has played a
largely helpful role in managing inter¬
ethnic tensions in southeastern Europe,
and is continuing to work toward joining
NATO and the EU. Albania, with troops
in Iraq and Afghanistan, has been a strong
supporter of the global war on terrorism.
Location: Southeastern Europe, bor¬
dering the Adriatic Sea and Ionian Sea,
between Greece in the south and
Montenegro and Kosovo to the north
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total: 28,748 sq km
land: 27,398 sq km
water: 1,350 sq km
Area — comparative: slightly smaller
than Maryland
Land boundaries:
total: 717 km
border countries: Greece 282 km,
Macedonia 151 km, Montenegro 172
km, Kosovo 112 km
Coastline: 362 km
Maritime claims:
territorial sea: 12 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: mild temperate; cool, cloudy,
wet winters; hot, clear, dry summers;
interior is cooler and wetter
Terrain: mostly mountains and hills;
small plains along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem
Korab) 2,764 m
Natural resources: petroleum, natural
gas, coal, bauxite, chromite, copper, iron
ore, nickel, salt, timber, hydropower
6','51b8aadfeb46023ea11cf9b59cfedd502e7e64597afccb31aea77275fb3de2c4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ada5e1d9833ea105f4b546bbb4c7c046abd0de6f135d3ce20410e843b29cbda',2009,'AL','Albania','military-and-security',75,'Land use:
arable land: 20.1%
permanent crops: 4-21%
other: 75.69% (2005)
Irrigated land: 3,530 sq km (2003)
Total renewable water resources: 41.7
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.71 cu
km/yr (27%/ll%/62%)
per capita: 546 cu m/yr (2000)
Natural hazards: destructive earth''
quakes; tsunamis occur along south¬
western coast; floods; drought
Environment— current issues: defor¬
estation; soil erosion; water pollution
from industrial and domestic effluents
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location
along Strait of Otranto (links Adriatic Sea
to Ionian Sea and Mediterranean Sea)','753a4ed5c9c5b2d7977995e79c800b705f7c65a571e818cc78913f288a84dc75','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e024a0b6e57b7ed554be2a416911a52dcd814e68c3ec1d595fab196d6eda875d',2009,'DZ','Algeria','military-and-security',84,'Military branches: National Popular
Army (ANP; includes Land Forces),
Algerian National Navy (MRA), Air
Force (QJJ), Territorial Air Defense
Force (2005)
Military service age and obligation:
19-30 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 18 months (6 months basic
training, 12 months civil projects)
(2006)
Manpower available for military
service:
males age 16-49: 9,736,757
females age 16-49: 9,590,978 (2008 est.)
Manpower fit for military service:
males age 1 6-49 : 8 , 1 4 1 , 864
females age 16-49: 8,215,895 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 374,365
females age i 6 — 49 : 360,942 (2008 est.)
12','ebff54acfc0bab6f056549ee7c18d54affea6bcdf305f4a3ec53cc24e06b6b57','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c67ed275397da83942dc3ec0eb667dafea340753216be8733085e6594639b6d6',2009,'AO','Angola','military-and-security',96,'Military branches: no regular military
forces, Police Service of Andorra
Manpower available for military
service:
males age 16-49: 18,685 (2008 est.)
Manpower fit for military service:
males age 16—49: 14,976 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 372 (2008 est.)
Military — note: defense is the responsi¬
bility of France and Spain
Military branches: Angolan Armed
Forces (FAA): Army, Navy (Marinha de
Guerra, MdG), Angolan National Air
Force (FANA) (2007)
Military service age and obligation: 17
years of age for compulsory military
service; conscript service obligation — 2
years plus time for training (2001)
Manpower available for military
service:
males age 16-49: 2,856,492
females age i 6 — 49; 2,755,864 (2008 est.)
Manpower fit for military service:
males age 16-49: 1 ,430,658
females age 16-49: 1,371,689 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 142,791
females age 16-4 9: 139,539 (2008 est.)
Military expenditures— percent of
GDP: 5.7% (2006)
Manpower available for military
service:
males age 16-49: 3,538 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,929 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 103 (2008 est.)
Military — note: defense is the responsi¬
bility of the UK','8530c2f7c98903d8e6692ff997ae3b07cddacb75b4427c0cc900f923aa1ffa5b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('083ccbd90c05c32160a6ad02a8974b27df251bd275ca6d8e954cb90a6be9c3d9',2009,'AG','Antigua and Barbuda','military-and-security',106,'Military — note: the Antarctic Treaty
prohibits any measures of a military
nature, such as the establishment of mil¬
itary bases and fortifications, the carrying
out of military maneuvers, or the testing
of any type of weapon; it permits the use
of military personnel or equipment for
scientific research or for any other
peaceful purposes
Military branches: Royal Antigua and
Barbuda Defense Force (2007)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 19,560
females age 16—49 : 18,977 (2008 est.)
Manpower fit for military service:
males age 1 6—49: 15,591
females age 16—49: 15,542 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 627
females age 16—49: 609 (2008 est.)
Military expenditures— percent of
GDP: NA','68212ac906f4fa4d1c81871d16fec8c8f3fee33b22038306a8cc2fb3c46361b2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e3ecfb1da0330aeb0e91a1dc4ce91ec72121ac6feab380d2611a35c2db32870',2009,'AR','Argentina','military-and-security',113,'Military branches: Argentine Army
(Ejercito Argentino), Navy of the
Argentine Republic (Armada Republica;
includes naval aviation and naval
infantry), Argentine Air Force (Fuerza
Aerea Argentina, FAA) (2008)
Military service age and obligation:
18-24 years of age for voluntary military
service (18-21 requires parental permis¬
sion); no conscription (2001)
Manpower available for military
service:
males age 16-49: 10,029,488
females age 16-49: 9,889,002 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,352,147
females age 16-49: 8,366,781 (2008 est.)
Manpower reaching militariiy signifi¬
cant age annually:
males age 16—4 9: 350,040
females age 16—49: 334,830 (2008 est.)
Military expenditures— percent of
GDP: 1.3% (2005 est.)
Military — note: the Argentine military
is a well-organized force constrained by
the country’s prolonged economic hard¬
ship; the country has recently experi¬
enced a strong recovery, and the military
is implementing a modernization plan
aimed at making the ground forces
lighter and more responsive (2008)','e01e0f31a3f1d9de575025be562a0a8fd74914de77599c80fc5ffd1af478be98','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba096da619804d41f2781baa3709d0ba4c4101f114bca9c95811b42fab2768dc',2009,'AM','Armenia','military-and-security',119,'Military branches: Armed Forces:
Ground Forces, Nagorno-Karabakh Self
Defense Force (NKSDF), Air Force and
Air Defense (2008)
Military service age and obligation:
18-27 years of age for compulsory mili¬
tary service; 18 years of age for voluntary
military service; 2-year conscript service
obligation (2006)
Manpower available for military
service:
males age 16-49: 809,576
females age 16-49: 870,864 (2008 est.)
Manpower fit for military service:
males age 16-49: 637,776
females age 16-49: 729,846 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 30,548
females age 16-49: 29,170 (2008 est.)
Military expenditures— percent of
GDP: 6.5% (FY01)','21adfd33aee3388b0663215c12c43315ed62c09f6cfd90fc285c39b774208878','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6097e7675e5dc6871f64429eec400e8583bc215af4b0092a76be57a040fd0907',2009,'AW','Aruba','military-and-security',125,'Military branches: no regular indigenous
military forces; the Netherlands main¬
tains a detachment of marines, a frigate,
and an amphibious combat detachment
in the neighboring Netherlands Antilles
(2008)
Manpower available for military
service:
males age 16-49: 24,585
females age 16—49: 25,742 (2008 est.)
Manpower fit for military service:
males age 1 6—49 : 20,173
females age 16-49: 21,062 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 705
females age 16-49: 719 (2008 est.)
Military — note: defense is the responsi¬
bility of the Kingdom of the Netherlands','bd2c398fbb9d87dae869bb256e618a74f908d028f8c06a63355b3dd310932cce','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ace049b331d125b5762eae48e7650d912b59ee2d501866dbbe3e607d3e53a44c',2009,'AT','Austria','military-and-security',135,'Military branches: Australian Defense
Force (ADF): Australian Army, Royal
Australian Navy, Royal Australian Air
Force, Special Operations Command
(2006)
Military service age and obligation: 17
years of age for voluntary military service
(with parental consent); no conscrip¬
tion; women allowed to serve in Army
combat units in non-combat support
roles (2008)
Manpower available for military
service:
males age 16-49: 4,999,988
females age i 6 — 49 : 4,870,043 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,137,176
females age 16-49: 4,022,588 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 146,248
females age 16-4 9: 139,697 (2008 est.)
Military expenditures— percent of
GDP: 2.4% (2006)
Disputes — international: Timor-Feste
and Australia agreed in 2005 to defer the
disputed portion of the boundary for fifty
years and to split hydrocarbon revenues
evenly outside the Joint Petroleum
Development Area covered by the 2002
Timor Sea Treaty; East Timor dispute
hampers creation of a revised maritime
boundary with Indonesia in the Timor
Sea; Indonesian groups challenge
Australia’s claim to Ashmore and Cartier
Islands; Australia closed parts of the
Ashmore and Cartier Reserve to
Indonesian traditional fishing and placed
restrictions on certain catch; regional
states continue to express concern over
Australia’s 2004 declaration of a 1,000-
nautical mile-wide maritime identifica¬
tion zone; Australia asserts land and
maritime claims to Antarctica (see
Antarctica); in 2004 Australia submitted
its claims to UN Commission on the
Fimits of the Continental Shelf (CFCS)
to extend its continental margins cov¬
ering over 3.37 million square kilometers
or roughly thirty percent of its claimed
exclusive economic zone; since 2003,
Australian Defense Force leads the
Regional Assistance Mission to the
Solomon Islands (RAMSI) to maintain
civil and political order and reinforce
regional security
Illicit drugs: Tasmania is one of the
world’s major suppliers of licit opiate
products; government maintains strict
controls over areas of opium poppy culti¬
vation and output of poppy straw con¬
centrate; major consumer of cocaine and
amphetamines
Military branches: Land Forces
(KdoLdSK), Air Forces (KdoLuSK)
Military service age and obligation:
18-35 years of age for compulsory mili¬
tary service; 16 years of age for male or
female voluntary service; service obliga¬
tion 7 months of training, followed by an
8-year reserve obligation (2006)
Manpower available for military
service:
males age i 6 — 49 : 1,986,411
females age 16-49: 1,944,834 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,617,385
females age 16-49: 1,583,886 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 50,869
females age 16-49: 48,246 (2008 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)','bc1e3ca037e954865be2cf170ba2fa721c580f3630e727ad579a712d1fee5405','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('771e1fdff2472dadee565854d6fdfab8e4c9932eb55ead8d2aad701482b5c53a',2009,'BH','Bahrain','military-and-security',153,'Military branches: Bahrain Defense
Forces (BDF): Ground Force (includes
Air Defense), Naval Force, Air Force,
National Guard
Military service age and obligation: 17
years of age for voluntary military
service; 15 years of age for NCOs, tech-
nicians, and cadets; no conscription
(2008)
Manpower available for military
service:
males age 16-49: 210,938
females age 16-49: 170,471 (2008 est.)
Manpower fit for military service:
males age 16-49: 171,536
females age 16-49: 142,714 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 6,543
females age 16-49: 6,429 (2008 est.)
Military expenditures — percent of
GDP: 4.5% (2006)','1995462817fdd77b6f1595c3e9cadf3b4b7c8d9f3255c599b587671753943373','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aad4695e664a00325f497e21944900efb2da4e70b67e1a9131ab36d27fea57a',2009,'FR','France','military-and-security',174,'Military branches: Belgian Armed
Forces: Land Operations Command,
Naval Operations Command, Air
Operations Command (2008)
Military service age and obligation: 18
years of age for voluntary military
service; conscription suspended (2008)
Manpower available for military
Service: males age 16—49: 2,407,128
females age 16—49: 2,340,039 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,973,167
females age 16—49: 1,915,990 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 64,659
females age 16—49: 61,881 (2008 est.)
Military expenditures— percent of
GDP: 1.3% (2005 est.)
Military branches: Finnish Defense
Forces (FDF): Army, Navy (includes
Coastal Defense Forces), Air Force
(Suomen Ilmavoimat) (2007)
Military service age and obligation: 18
years of age for male voluntary and com¬
pulsory national military and nonmili-
tary service; service obligation 6-12
months (2007)
Manpower available for military
service:
males age 16-49: 1,169,910
females age 16-49: 1,121,187 (2008 est.)
Manpower fit for military service:
males age 16-49: 965,131
females age 16—49: 923,224 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-4 9: 34,152
females age 16-4-9: 32,870 (2008 est.)
Military expenditures— percent of
GDP: 2% (2005 est.)
Military— note: defense is the responsi¬
bility of France','8377ad09ca2613d6036d6f119fd63bc61e1bd1b8c0c9a6062402ce03723246d7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a3659ced43822b76ce3ac9800b88f7f8077688eb1dd46775ea0c6516a17e7c2',2009,'BJ','Benin','military-and-security',188,'Military branches: Benin Armed Forces
(FAB): Army (I’Arme de Terre), Benin
Navy (Forces Navales Beninois, FNB),
Benin People’s Air Force (Force
Aerienne Populaire de Benin, FAPB)
(2008)
Military service age and obligation: 21
years of age for compulsory and voluntary
military service; in practice, volunteers
may be taken at the age of 18; both sexes
are eligible for military service; conscript
tour of duty — 18 months (2006)
Manpower available for military
service:
males age 16-49: 1,908,457
females age 16-49: 1,882,421 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,173,742
females age 1 6 — 49: 1,162,113 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 96,230
females age J 6 — 49: 94,436 (2008 est.)
Military expenditures— percent of
GDP: 1.7% (2006)','2949d14bd9677f2621731434d8ba869c8978d457899a03960a1b28722157d2e6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0de02c875eac1a6dbef0dc06c7e14b8dfacb77ef4c48d9c22df4175f1336fe18',2009,'BM','Bermuda','military-and-security',192,'Military branches: Bermuda Regiment
(2008)
Military service age and obligation:
18-23 years of age; eligible men required
to register for conscription as needed
into the Bermuda Regiment, which is
largely voluntary; term of service 39
months (2007)
Manpower available for military service:
males age 16-49: 15,623 (2008 est.)
Manpower fit for military service:
males age 16-49: 12,682 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 426 (2008 est.)
76','712a068c5253fda7173daf78a2323bdd6e2bf3a63ec13e61fc09d1cda32f71ba','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb210050e7d2b03e362c6aee2dc55cf8c12f5ce2131f4946c4fac4b95af2fd9',2009,'BT','Bhutan','military-and-security',193,'Military expenditures— percent of
GDP: 0.11% (2005 est.)
Military — note: defense is the responsi-
bility of the UK','85bb825eb9519f0829bdd355d4805c9238dd6329a65db6e18135c51dfb1a3648','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92af16f07887763e519978fecebc16577b93905f02a831840455d1879a41ded2',2009,'PE','Peru','military-and-security',206,'Military branches: Bolivian Armed
Forces: Bolivian Army (Ejercito
Boliviano), Bolivian Navy (Armada
Boliviana; includes marines), Bolivian
Air Force (Fuerza Aerea Boliviana, FAB)
(2008)
Military service age and obligation: 18
years of age for 12-month compulsory
military service; when annual number of
volunteers falls short of goal, compulsory
82
Military branches: Army, National
Navy (Armada Nacional, includes Naval
Aviation, Marine Corps, General Naval
Prefecture), Air Force (Fuerza Aerea
Paraguay, FAP) (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 12 months for Army, 24 months
for Navy (2006)
Manpower available for military
service:
males age 16-49: 1,589,873
females age 16-49: 1,585,573 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,327,730
females age 16-49: 1,356,989 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—4 9: 72,109
females age 16-49: 70,509 (2008 est.)
Military expenditures— percent of
GDP: 1% (2006 est.)
Military branches: Peruvian Army
(Ejercito Peruano), Peruvian Navy
(Marina de Guerra del Peru, MGP
(includes naval air, naval infantry, and
coast guard)), Peruvian Air Force
(Fuerza Aerea del Peru, FAP) (2008)
Military service age and obligation:
18-30 years of age for voluntary male
and female military service; no conscrip¬
tion (2008)
Manpower available for military
service:
males age 16-49: 7,653,898
females age 16-49: 7,531,329 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,796,449
females age 16-49: 6,217,524 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 306,260
females age 16-49: 296,819 (2008 est.)
514','9703f76c340db768d9db6ea96fe08e876fbba5cd069bfd34033983234b191bb9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3ae61720a7b407a5dd71b40b60df40d009a6938aefbf0456d28d3766f39e635',2009,'BA','Bosnia and Herzegovina','military-and-security',207,'recruitment is effected, including con¬
scription of boys as young as 14; 15-19
years of age for voluntary premilitary
service, provides exemption from further
military service (2008)
Manpower available for military
service:
males age 16-49: 2,295,746
females age 16-49: 2,366,828 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,600,219
females age 16—49: 1,815,514 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 107,051
females age 16—49: 103,620 (2008 est.)
Military expenditures— percent of
GDP: 1.9% (2006)
Disputes — international: Chile rebuffs
Bolivia’s reactivated claim to restore the
Atacama corridor, ceded to Chile in
1884, offering instead unrestricted but
not sovereign maritime access through
Chile for Bolivian natural gas and other
commodities
Illicit drugs: world’s third-largest culti¬
vator of coca (after Colombia and Peru)
with an estimated 26,500 hectares under
cultivation in August 2005, an 8%
increase from 2004; transit country for
Peruvian and Colombian cocaine des¬
tined for Brazil, Argentina, Chile,
Paraguay, and Europe; cultivation steadily
increasing despite eradication and alter¬
native crop programs; money-laundering
activity related to narcotics trade, espe¬
cially along the borders with Brazil and
Paraguay; major cocaine consumption
Background: Bosnia and Herzegovina’s
declaration of sovereignty in October
1991 was followed by a declaration of
independence from the former
Yugoslavia on 3 March 1992 after a refer¬
endum boycotted by ethnic Serbs. The
Bosnian Serbs — supported by neigh¬
boring Serbia and Montenegro —
responded with armed resistance aimed
at partitioning the republic along ethnic
lines and joining Serb-held areas to form
a “Greater Serbia.” In March 1994,
Bosniaks and Croats reduced the number
of warring factions from three to two by
signing an agreement creating a joint
Bosniak/Croat Federation of Bosnia and
Herzegovina. On 21 November 1995, in
Dayton, Ohio, the warring parties ini¬
tialed a peace agreement that brought to
a halt three years of interethnic civil
strife (the final agreement was signed in
Paris on 14 December 1995). The
Dayton Peace Accords retained Bosnia
and Herzegovina’s international bound¬
aries and created a joint multi-ethnic
and democratic government charged
with conducting foreign, diplomatic, and
fiscal policy. Also recognized was a
second tier of government comprised of
two entities roughly equal in size: the
Bosniak/Croat Federation of Bosnia and
Herzegovina and the Bosnian Serb- led
Republika Srpska (RS). The Federation
and RS governments were charged with
overseeing most government functions.
The Office of the High Representative
(OHR) was established to oversee the
implementation of the civilian aspects of
the agreement. In 1995-96, a NATO-led
international peacekeeping force (IFOR)
of 60,000 troops served in Bosnia to
implement and monitor the military
aspects of the agreement. IFOR was suc¬
ceeded by a smaller, NATO-led
Stabilization Force (SFOR) whose mis¬
sion was to deter renewed hostilities.
European Union peacekeeping troops
(EUFOR) replaced SFOR in December
2004; their mission is to maintain peace
and stability throughout the country.
EUFOR’s mission changed from peace¬
keeping to civil policing in October
2007, with its presence reduced from
nearly 7,000 to 2,500 troops.
Location: Southeastern Europe, bor¬
dering the Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Europe
Area:
total: 51,129 sq km
land: 51,129 sq km
water: 0 sq km
Area — comparative: slightly smaller
than West Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km,
Montenegro 225 km, Serbia 302 km
Coastline: 20 km
Maritime claims: no data available
Climate: hot summers and cold winters;
areas of high elevation have short, cool
summers and long, severe winters; mild,
rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron ore,
bauxite, copper, lead, zinc, chromite,
cobalt, manganese, nickel, clay, gypsum,
salt, sand, forests, hydropower
Land use:
arable land: 19.61%
permanent crops : 1.89%
other: 78.5% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 37.5
cu km (2003)
Natural hazards: destructive earth¬
quakes
Environment — current issues: air pollu¬
tion from metallurgical plants; sites for
disposing of urban waste are limited;
water shortages and destruction of infra¬
structure because of the 1992—95 civil
strife; deforestation
Environment— international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: within Bosnia and
Herzegovina’s recognized borders, the
country is divided into a joint
Bosniak/Croat Federation (about 51% of
the territory) and the Bosnian Serb-led
Republika Srpska or RS (about 49% of
the territory); the region called
Herzegovina is contiguous to Croatia
and Montenegro, and traditionally has
been settled by an ethnic Croat majority
in the west and an ethnic Serb majority
in the east
83
THE CIA WORLD FACTBOOK
Population: 4,590,310 (July 2008 est.)
Age structure:
0-14 years: 14-7% (male 347,679/female
326,091)
15-64 years: 70.6% (male
1,634,053/female 1,606,341)
65 years and over: 14.7% (male
277,504/female 398,642) (2008 est.)
Median age:
total: 39.4 years
male: 38.2 years
female: 40.5 years (2008 est.)
Population growth rate: 0.666% (2008
est.)
Bilth rate: 8.82 births/1,000 population
(2008 est.)
Death rate: 8.54 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 6.38 migrant(s)/
1,000 population (2008 est.)
Sex ratio: at birth: 1.07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.97 male(s)/female
(2008 est.)
Infant mortality rate:
total: 9.34 deaths/1,000 live births
male: 10.71 deaths/1,000 live births
female: 7.87 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 78.33 years
male: 74.74 years
female: 82.19 years (2008 est.)
Total fertility rate: 1.24 children
bom/woman (2008 est.)
HIV/AIDS — adult prevalence rate: less
than 0.1% (2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 900 (2003 est.)
HIV/AIDS— deaths: 100 (2001 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Bosniak 48%, Serb
37.1%, Croat 14.3%, other 0.6% (2000)
note: Bosniak has replaced Muslim as an
ethnic term in part to avoid confusion
with the religious term Muslim — an
adherent of Islam
Religions: Muslim 40%, Orthodox 31%,
Roman Catholic 15%, other 14%
Languages: Bosnian, Croatian, Serbian
Literacy: definition: age 15 and over can
read and write
total population: 96.7%
male: 99%
female: 94.4% (2000 est.)
Country name:
conventional long form: none
conventional short form: Bosnia and
Herzegovina
local long form: none
local short form: Bosna i Hercegovina
former: People’s Republic of Bosnia and
Herzegovina, Socialist Republic of
Government type: emerging federal
democratic republic
Capital: name: Sarajevo
geographic coordinates: 43 52 N, 18 25 E
time difference: UTC+1 (6 hours ahead of
Washington, DC during Standard Time)
daylight saving time: + lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: 2 first-order
administrative divisions and 1 interna¬
tionally supervised district* — Brcko dis¬
trict (Brcko Distrikt)*, the
Bosniak/Croat Federation of Bosnia and
Herzegovina (Federacija Bosna i
Hercegovina) and the Bosnian Serb-led
Republika Srpska; note — Brcko district
is in northeastern Bosnia and is an
administrative unit under the sover¬
eignty of Bosnia and Herzegovina; the
district remains under international
supervision
Independence: 1 March 1992 (from
Yugoslavia; referendum for independ¬
ence completed 1 March 1992; inde¬
pendence declared 3 March 1992)
National holiday: National Day, 25
November (1943)
Constitution: the Dayton Agreement,
signed 14 December 1995 in Paris,
included a new constitution now in
force; note — each of the entities also has
its own constitution
Legal system: based on civil law system;
has not accepted compulsory ICJ juris¬
diction
Suffrage: 18 years of age, universal
Executive branch:
chief of state: Chairman of the Presidency
Haris SILAJDZIC (chairman since 6
March 2008; presidency member since 1
October 2006 — Bosniak); other mem¬
bers of the three-member presidency
rotating (every eight months): Nebojsa
RADMANOVIC (presidency member
since 1 October 2006 — Serb); and Zeljko
KOMSIC (presidency member since 1
October 2006 — Croat)
head of government: Chairman of the
Council of Ministers Nikola SPIRIC
(since 11 January 2007)
cabinet: Council of Ministers nominated
by the council chairman; approved by
the National House of Representatives
elections: the three members of the presi¬
dency (one Bosniak, one Croat, one
Serb) are elected by popular vote for a
four-year term (eligible for a second
term, but then ineligible for four years);
the chairmanship rotates every eight
months and resumes where it left off fol¬
lowing each national election; election
last held 1 October 2006 (next to be held
in 2010); the chairman of the Council of
Ministers is appointed by the presidency
and confirmed by the National House of
Representatives
election results: percent of vote — Nebojsa
RADMANOVIC with 53.3% of the
votes for the Serb seat; Zeljko KOMSIC
received 39.6% of the votes for the Croat
seat; Haris SIFAJDZIC received 62.8%
of the votes for the Bosniak seat
note: President of the Federation of
Bosnia and Herzegovina: Borjana
KRISTO (since 21 February 2007); Vice
Presidents Spomenka MICIC (since NA
2007) and Mirsad KEBO (since NA
2007); President of the Republika
Srpska: Rajko KUSMANOVIC (since
28 December 2007)
Legislative branch: bicameral
Parliamentary Assembly or Skupstina
consists of the national House of
Representatives or Predstavnicki Dom
(42 seats, 28 seats allocated for the
Federation of Bosnia and Herzegovina
and 14 seats for the Republika Srpska;
members elected by popular vote on the
basis of proportional representation, to
serve four-year terms); and the House of
Peoples or Dom Naroda (15 seats, 5
Bosniak, 5 Croat, 5 Serb; members
elected by the Bosniak/Croat
Federation’s House of Representatives
and the Republika Srpska''s National
Assembly to serve four-year terms);
note — Bosnia’s election law specifies
four-year terms for the state and first-
order administrative division entity leg¬
islatures
elections: national House of
Representatives — elections last held 1
October 2006 (next to be held in 2010);
House of Peoples — last constituted in
January 2003 (next to be constituted in
2007)
election results: national House of
Representatives — percent of vote by
party/coalition — NA; seats by
party/coalition — SDA 9, SBH 8, SNSD
7, SDP 5, SDS 3, HDZ-BH 3, HDZ1990
2, other 5; House of Peoples — percent of
vote by party/coalition — NA; seats by
party/coalition — NA
note: the Bosniak/Croat Federation has a
bicameral legislature that consists of a
House of Representatives (98 seats;
members elected by popular vote to serve
four-year terms); elections last held 1
October 2006 (next to be held in
October 2010); percent of vote by
party — NA; seats by party/coalition —
84
SDA 28, SBH 24, SDP 17, HDZ-BH 8,
HDZ100 7, other 14; and a House of
Peoples (58 seats — 17 Bosniak, 17 Croat,
17 Serb, 7 other); last constituted
December 2002; the Republika Srpska
has a National Assembly (83 seats; mem¬
bers elected by popular vote to serve
four-year terms); elections last held 1
October 2006 (next to be held in the fall
of 2010); percent of vote by party — NA;
seats by party/coalition — SNSD 41, SDS
17, PDP 8, DNS 4, SBH 4, SPRS 3, SDA
3, other 3; as a result of the 2002 consti¬
tutional reform process, a 28-member
Republika Srpska Council of Peoples
(COP) was established in the Republika
Srpska National Assembly including
eight Croats, eight Bosniaks, eight Serbs,
and four members of the smaller commu¬
nities
Judicial branch: BH Constitutional
Court (consists of nine members: four
members are selected by the
Bosniak/Croat Federation’s House of
Representatives, two members by the
Republika Srpska’s National Assembly,
and three non-Bosnian members by the
president of the European Court of
Human Rights); BH State Court (con¬
sists of nine judges and three divisions —
Administrative, Appellate and
Criminal — having jurisdiction over cases
related to state-level law and appellate
jurisdiction over cases initiated in the
entities); a War Crimes Chamber opened
in March 2005
note: the entities each have a Supreme
Court; each entity also has a number of
lower courts; there are 10 cantonal
courts in the Federation, plus a number
of municipal courts; the Republika
Srpska has five municipal courts
Political parties and leaders: Alliance
of Independent Social Democrats or
SNSD [Milorad DODIK]; Bosnian Party
or BOSS [Mimes AJANOVIC]; Civic
Democratic Party or GDS [Ibrahim
SPAHIC]; Croat Christian Democratic
Union of Bosnia and Herzegovina or
HKDU [Marin TOPIC]; Croat Party of
Rights or HSP [Zvonko JURISIC]; Croat
Peasants Party or HSS [Marko TADIC];
Croatian Democratic Union of Bosnia
and Herzegovina or HDZ-BH [Dragan
COVIC]; Croatian Democratic Union
1990 or HDZ1990 [Bozo LJUBIC];
Croatian Democratic Union 100 or
HDZ100; Croatian Peoples Union
[Milenko BRKIC]; Democratic National
Union or DNZ [Rifet DOLIC];
Democratic Peoples Alliance or DNS
[Marko PAVIC]; Liberal Democratic
Party or LDS [Rasim KADIC]; New
Croat Initiative or NHI [Kresimir
ZUBAK]; Party for Bosnia and
Herzegovina or SBH [Haris SILA-
JDZIC]; Party for Democratic Action or
SDA [Sulejman TIHIC]; Party of
Democratic Progress or PDP [Mladen
IVANIC]; Serb Democratic Party or SDS
[Mladen BOSIC]; Serb Radical Party of
the Republika Srpska or SRS-RS
[Milanko MIHAJLICA]; Serb Radical
Party-Dr. Vojislav Seselj or SRS-VS
[Radislav KANJERIC]; Social
Democratic Party of BIH or SDP [Zlatko
LAGUMDZIJA]; Social Democratic
Union or SDU [Sejfudin TOKIC];
Socialist Party of Republika Srpska or
SPRS [Petar DJOKIC]
Political pressure groups and leaders:
NA
International organization participa¬
tion: BIS, CE, CEI, EAPC, EBRD, FAO,
G-77, IAEA, IBRD, ICAO, ICCt,
ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, IMO, IMSO, Interpol, IOC, IOM,
IPU, ISO, ITSO, ITU, ITUC, MIGA,
NAM (observer), OAS (observer), OIC
(observer), OPCW, OSCE, PFP, SECI,
UN, UNCTAD, UNESCO, UNIDO,
UNMEE, UNWTO, UPU, WHO,
WIPO, WMO, WTO (observer)
Diplomatic representation in the US:
chief of mission: Ambassador Bisera
TURKOVIC
chancery: 2109 E Street NW,
Washington, DC 20037
telephone: [1] (202) 337-1500
FAX: [1] (202) 337-1502
consulate(s) general: Chicago, New York
Diplomatic representation from the US:
chief of mission: Ambassador Charles L.
ENGLISH
embassy: Alipasina 43, 71000 Sarajevo
mailing address: use embassy street address
telephone: [387] (33) 445-700
FAX: [387] (33) 659-722
branch office(s): Banja Luka, Mostar
Flag description: a wide medium blue
vertical band on the fly side with a
yellow isosceles triangle abutting the
band and the top of the flag; the
remainder of the flag is medium blue
with seven full five-pointed white stars
and two half stars top and bottom along
the hypotenuse of the triangle
Military branches: Bosnia and
Herzegovina Armed Forces (OSBiH):
Army of Bosnia and Herzegovina, Air
and Air Defense Forces of Bosnia and
Herzegovina (Zrakoplovstvo i
Protuzracna Obrana, ZPO) (2007)
Military service age and obligation: 17
years of age for voluntary military service
in the Federation and in the Republika
Srpska; conscription abolished January
2006; 4-month service obligation (2006)
Manpower available for military
Service: males age 16—49: 1,212,007
females age 16-49: 1,170,645 (2008 est.)
Manpower fit for military service:
males age 16-49: 996,225
females age 16-49: 962,927 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 30,246
females age 16-49: 28,189 (2008 est.)
Military expenditures— percent of
GDP: 4.5% (2005 est.)','ef621831554aa6ca57456973ce5d163629a5a0a38c92e57402b39a1ef6bb704f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('023a8fdbc7a5f0a045785a446b81cff3789c85f535f0985c47568220de359687',2009,'BR','Brazil','military-and-security',226,'Military branches: Brazilian Army,
Brazilian Navy (Marinha do Brasil (MB),
includes Naval Air and Marine Corps
(Corpo de Fuzileiros Navais)), Brazilian
Air Force (Forca Aerea Brasileira, FAB)
(2008)
Military service age and obligation:
21-45 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 9 to 12 months; 17-45 years of age
for voluntary service; an increasing per¬
centage of the ranks are “long-service”
volunteer professionals; women were
allowed to serve in the armed forces
beginning in early 1980s when the
Brazilian Army became the first army in
South America to accept women into
career ranks; women serve in Navy and
Air Force only in Women’s Reserve
Corps (2001 )
93
THE CIA WORLD FACTBOOK
Manpower available for military
service:
males age 16-49: 52,449,957
females age 16—49: 52,375,921 (2008
est.)
Manpower fit for military service:
males age 16—49: 39,263,710
females age 16—49: 44,109,056 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 1,668,722
females age 16-49: 1,609,437 (2008 est.)
Military expenditures— percent of
GDP: 2.6% (2006 est.)
Electricity— consumption: NA kWh
Currency (code): both the British
Pound (GBP) and the US Dollar (USD)
are accepted
Manpower available for military
service:
males age 16-49: 7,101 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,921 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 185 (2008 est.)
Military — note: defense is the responsi¬
bility of the UK','dd9a6056ea0a9fe6d539865fcb6ac608cb1c2cdb63cd54412863b21e998b5c8a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7bf07501a06bf7a0bfba03f7b27ff5c26dba3b1339a4d3d6a481de58787764f',2009,'BF','Burkina Faso','military-and-security',243,'Military branches: Army, Air Force of
Burkina Faso (Force Aerienne de
Burkina Faso, FABF), National
Gendarmerie (2008)
Military service age and obligation: 18
years of age for compulsory military
service; 20 years of age for voluntary mil¬
itary service (2001)
Manpower available for military
service:
males age 16-49: 3,364,288 (2008 est.)
Manpower fit for military service:
males age 16^19: 2,115,948 (2008 est.)
Military expenditures— percent of
GDP: 1.2% (2006)
Military branches: Myanmar Armed
Forces (Tatmadaw): Army, Navy, Air
Force (Tatmadaw Lay) (2008)
Military service age and obligation: 18
years of age for voluntary military service
for both sexes; forced conscription of
children, although officially prohibited,
reportedly continues (2007)
Manpower available for military
service:
males age 16-49: 13,402,788
females age 16-49: 13,437,042 (2008
est.)
Manpower fit for military service:
males age 16—49: 9,031,046
females age 16-49: 9,396,547 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 423,809
females age 16—49: 415,843 (2008 est.)
Military expenditures— percent of
GDP: 2.1% (2005 est.)','891c579d5d725eed44d9958f11a54ca0fd7df7d163ae0d94cb3721a71a737b7a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e71f6e3e7e96dafe5bcab14c52158f32eeea369b23334ac13f01a391a535f852',2009,'BI','Burundi','military-and-security',252,'Military branches: National Defense
Force (Forces de Defense Nationales,
FDN): Army (includes Naval
Detachment and Air Wing),
Gendarmerie (2008)
Military service age and obligation: 16
years of age for compulsory and voluntary
military service; children as young as 10
years of age have been conscripted into
the armed forces; the enrollment of chil¬
dren is still not prohibited (2007)
Manpower available for military
service:
males age 16-49: 1,878,544
females age 16—49: 1,851,676 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,083,899
females age 16—49: 1,062,488 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 98,105
females age 16—49: 98,533 (2008 est.)
Military expenditures— percent of
GDP: 5.9% (2006 est.)
Disputes — international: conflicts
among Tutsi, Hutu, other ethnic groups,
associated political rebels, armed gangs,
and various government forces have
abated somewhat in the Great Lakes
region; UN Operation in Burundi
(ONUB) completed its mandate in
December 2006 after a three-year peace¬
keeping mission
Refugees and internally displaced per¬
sons: refugees (country of origin): 9,849
(Democratic Republic of the Congo)
IDPs: 100,000 (armed conflict between
government and rebels; most IDPs in
northern and western Burundi) (2007)
113
• A.v-
THAltAND
Sisophon
Stem^ab
SatdSmbang
Pouthisat
.KricMi
.Kgmpong
Pfrtnm A-arai
JK§mp6nQ
Cham ■
PHNOM
PENH
vmrnm
Kampot
Kimponq"
Sadro
Background: Most Cambodians consider
themselves to be Khmers, descendants of
the Angkor Empire that extended over
much of Southeast Asia and reached its
zenith between the 10th and 13th cen¬
turies. Attacks by the Thai and Cham
(from present-day Vietnam) weakened
the empire, ushering in a long period of
decline. The king placed the country
under French protection in 1863 and it
became part of French Indochina in
1887. Following Japanese occupation in
World War II, Cambodia gained full
independence from France in 1953. In
April 1975, after a five-year struggle,
Communist Khmer Rouge forces cap¬
tured Phnom Penh and evacuated all
cities and towns. At least 1.5 million
Cambodians died from execution, forced
hardships, or starvation during the
Khmer Rouge regime under POL POT. A
December 1978 Vietnamese invasion
drove the Khmer Rouge into the coun¬
tryside, began a 10-year Vietnamese
occupation, and touched off almost 13
years of civil war. The 1991 Paris Peace
Accords mandated democratic elections
and a ceasefire, which was not fully
respected by the Khmer Rouge. UN-
sponsored elections in 1993 helped
restore some semblance of normalcy
under a coalition government. Factional
fighting in 1997 ended the first coalition
government, but a second round of
national elections in 1998 led to the for¬
mation of another coalition government
and renewed political stability. The
remaining elements of the Khmer Rouge
surrendered in early 1999. Some of the
remaining Khmer Rouge leaders are
awaiting trial by a UN -sponsored tri¬
bunal for crimes against humanity.
Elections in July 2003 were relatively
peaceful, but it took one year of negotia¬
tions between contending political par¬
ties before a coalition government was
formed. In October 2004, King
SIHANOUK abdicated the throne due
to illness and his son, Prince Norodom
SIHAMONI, was selected to succeed
him. Local elections were held in
Cambodia in April 2007, and there was
little in the way of pre-election violence
that preceded prior elections. National
elections are scheduled for July 2008.','8dccfa02947a6f24a7755379e38c53f02680d3c392bebb197e1e0f8cc95b1712','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca2a469df50949a6c135e0a48eda2bef6e401a6179bd6f494db342bf6fd929cc',2009,'CM','Cameroon','military-and-security',258,'Military branches: Royal Cambodian
Armed Forces: Royal Cambodian Army,
Royal Khmer Navy, Royal Cambodian
Air Force (2008)
Military service age and obligation:
conscription law of October 2006
requires all males between 18-30 to reg¬
ister for military service; 18-month
service obligation (2006)
Manpower available for military
service:
males age 16-49: 3,759,034
females age 16-49: 3,784,333 (2008 est.)
Manpower fit for military service:
males age 16—49: 2,581,045
females age 16—49: 2,676,075 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 185,959
females age 16-49: 182,558 (2008 est.)
Military expenditures— percent of
GDP: 3% (2005 est.)
Military branches: Cameroon Armed
Forces: Army, Navy (includes naval
infantry), Air Force (Armee de l’Air du
Cameroun, AAC) (2008)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription; the government makes
periodic calls for volunteers (2006)
Manpower available for military
service:
Military branches: National Guard
(Guardia Nacional (Army), with Coast
Guard (Navy) and Air Wing) (2008)
Military service age and obligation: 18
years of age (est.) for compulsory military
service (2008)
Manpower available for military
service:
males age 16-49: 136,725
females age 16-49: 138,018 (2008 est.)
Manpower fit for military service:
males age 16-49: 101,712
females age 16-49: 104,381 (2008 est.)
Military expenditures — percent of
GDP: 0.1% (2006 est.)','f571935ab401a78508dd04afcec12a5d0ab3a3572c38f2123eb0414792e07350','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41e59d449b24000c3c9955932f1bb71123b53108479e0978a2997689d438a43',2009,'CA','Canada','military-and-security',263,'males age 16-49: 4,321,175
females age 16-4 9: 4,228,625 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,567,428
females age 16-49: 2,498,990 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 212,205
females age 16-49: 207,545 (2008 est.)
Military expenditures— percent of
GDP: 1.3% (2006)
Military branches: Canadian Forces:
Land Forces Command (LFC), Maritime
Command (MARCOM), Air Command
(AIRCOM), Canada Command (home¬
land security) (2008)
Military service age and obligation:
16-34 years of age for voluntary military
service; women comprise approximately
11% of Canada’s armed forces (2006)
Manpower available for military
service:
males age 16-49: 8,072,010
females age 16-49: 7,813,462 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,646,281
females age 16-49: 6,417,924 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 227,435
females age 16-4 9: 215,556 (2008 est.)
Military expenditures — percent of
GDP: 1.1% (2005 est.)
Military branches: People’s
Revolutionary Armed Forces (FARP):
Army, Coast Guard (includes maritime
air wing) (2007)
Military service age and obligation: 18
years of age (est.) for selective compul¬
sory military service; 14-month conscript
service obligation (2006)
Manpower available for military
service:
males age 16-49: 103,650
females age 16—49: 103,553 (2008 est.)
Manpower fit for military service:
males age 16—49: 83,082
females age 16-49: 88,832 (2008 est.)
Military expenditures— percent of
GDP: 0.7% (2005)','d0e943b86b3f94dd43c35b3fca2138fb30536cfd1dccdb31c5027438b0922311','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('509f69f663a3153a796ce8bdc10b7dcc88a4c56023ceca8f766221c96ed50ee1',2009,'KY','Cayman Islands','military-and-security',279,'Military branches: no regular military
forces; Royal Cayman Islands Police
Force (2007)
Manpower available for military
service:
males age 7 6 — 49; 11,790 (2008 est.)
Manpower fit for military service:
males age J 6 — 49 : 9,577 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 1 6 — 49: 336 (2008 est.)
Military — note: defense is the responsi¬
bility of the UK','41284c3ba653cafd937465f1108014e5410706b2419ca784ae1018cdbcdf9ab0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d50e666a52062d2a999c4389ca00b060dd414bf9cef278779e6e6f6a3b22661e',2009,'TD','Chad','military-and-security',288,'_
Military branches: Central African
Armed Forces (Forces Armees
Centrafricaines, FACA): Ground Forces,
General Directorate of Gendarmerie
Inspection (DGIG), Military Air
Service, National Police (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; 2-year conscript service
obligation (2006)
Manpower available for military
service: males age 16-49: 1,032,828
females age 16-49: 999,330 (2008 est.)
Manpower fit for military service:
males age 16-49: 534,141
females age 16-49: 495,303 (2008 est.)
Military expenditures— percent of
GDP: 1.1% (2006 est.)
Disputes — international: periodic skir¬
mishes over water and grazing rights
among related pastoral populations along
the border with southern Sudan persist
Refugees and internally displaced per¬
sons: refugees (country of origin): 7,900
(Sudan); 3,700 (Democratic Republic of
the Congo); note — UNHCR resumed
repatriation of Southern Sudanese
refugees in 2006
IDPs: 197,000 (ongoing unrest following
coup in 2003) (2007)
Trafficking in persons: current situation:
Central African Republic is a source and
destination country for children traf¬
ficked for domestic servitude, sexual
exploitation, and forced labor in shops
and commercial labor activities; while
the majority of child victims are traf¬
ficked within the country, some are also
trafficked to and from Cameroon and
Military branches: Armed Forces:
Chadian National Army (Armee
Nationale du Tchad, ANT), Chadian
Air Force (Force Aerienne Tchadienne,
FAT), Gendarmerie (2008)
Military service age and obligation: 20
years of age for conscripts, with 3 -year
service obligation; 18 years of age for vol¬
unteers; no minimum age restriction for
volunteers with consent from a guardian;
women are subject to 1 year of compul¬
sory military or civic service at age of 21
(2004)
Manpower available for military
service:
males age 16—49: 1,906,545
females age 16—49: 2,258,758 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,066,565
females age 16—49: 1,279,318 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 116,824
females age 16—49: 117,831 (2008 est.)
Military expenditures— percent of
GDP: 4.2% (2006)','f34f85a8b35bb3bd51d16265f34f796c40a05f3e343bbd3d0fa8c0df1dedfb43','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60bc6055ec10efeaf460b1ac7a6ccc2e94f238103a925b9df500148aa8498ed4',2009,'NG','Nigeria','military-and-security',289,'tier rating: Tier 2 Watch List — the
Central African Republic failed to pro¬
vide evidence of increasing efforts to
combat trafficking in persons during
2005, specifically its inadequate law
enforcement response to trafficking
crimes
Military branches: Nigerian Armed
Forces: Army, Navy, Air Force (2008)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military
service:
males age 16-49: 31,929,204
females age 16—49: 30,638,979 (2008
est.)
Manpower fit for military service:
males age 16—49: 18,556,755
females age 16—49: 17,288,225 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 1,533,974
females age 16—49: 1,509,619 (2008 est.)
Military expenditures— percent of
GDP: 1.5% (2006)','6fc4c3afaca2fccbe4fc0eb4ff177ed8dd5828240deeff4b52b153cf25907b18','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20f2dab8a8219351b61d51686442a2eaee6dd1dd076470a3da77ac5c18485cb4',2009,'CN','China','military-and-security',313,'Military branches: People’s Liberation
Army (PLA): Ground Forces, Navy
(includes marines and naval aviation),
Air Force (includes airborne forces), and
Second Artillery Corps (strategic missile
force); People’s Armed Police (PAP);
Reserve and Militia Forces (2008)
Military service age and obligation:
18-22 years of age for selective compul¬
sory military service, with 24-month
service obligation; no minimum age for
voluntary service (all officers are volun¬
teers); 18-19 years of age for women
high school graduates who meet require¬
ments for specific military jobs (2007)
Manpower available for military
service:
males age 16-49: 375,009,345
females age 16-49: 354,314,328 (2008
est.)
141
THE CIA WORLD FACTBOOK
Manpower fit for military service:
males age 16-49: 313,321,639
females age 16-49: 295,951,438 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 10,760,380
females age 16-49: 9,710,032 (2008 est.)
Military expenditures— percent of
GDP: 4.3% (2006)
Disputes— international: based on prin-
ciples drafted in 2005, China and India
continue discussions to resolve all
aspects of their extensive boundary and
territorial disputes together with a secu¬
rity and foreign policy dialogue to con¬
solidate discussions related to the
boundary, regional nuclear proliferation,
and other matters; recent talks and con¬
fidence-building measures have begun to
defuse tensions over Kashmir, site of the
world’s largest and most militarized terri¬
torial dispute with portions under the de
facto administration of China (Aksai
Chin), India (Jammu and Kashmir), and
Pakistan (Azad Kashmir and Northern
Areas); India does not recognize
Pakistan’s ceding historic Kashmir lands
to China in 1964; lacking any treaty
describing the boundary, Bhutan and
China continue negotiations to establish
a boundary alignment to resolve substan¬
tial cartographic discrepancies, the
largest of which lies in Bhutan’s north¬
west; China asserts sovereignty over the
Spratly Islands together with Malaysia,
Philippines, Taiwan, Vietnam, and pos¬
sibly Brunei; the 2002 “Declaration on
the Conduct of Parties in the South
China Sea” eased tensions in the
Spratly’s but is not the legally binding
“code of conduct” sought by some par¬
ties; Vietnam and China continue to
expand construction of facilities in the
Spratly’s and in March 2005, the
national oil companies of China, the
Philippines, and Vietnam signed a joint
accord on marine seismic activities in
the Spratly Islands; China occupies some
of the Paracel Islands also claimed by
Vietnam and Taiwan; China and Taiwan
continue to reject both Japan’s claims to
the uninhabited islands of Senkaku-
shoto (Diaoyu Tai) and Japan’s unilater¬
ally declared equidistance line in the
East China Sea, the site of intensive
hydrocarbon prospecting; certain islands
in the Yalu and Tumen rivers are in dis¬
pute with North Korea; China seeks to
stem illegal migration of North Koreans;
China and Russia have demarcated the
once disputed islands at the Amur and
Ussuri confluence and in the Argun
River in accordance with their 2004
Agreement; in 2006, China and
Tajikistan pledged to commence demar¬
cation of the revised boundary agreed to
in the delimitation of 2002; demarcation
of the China-Vietnam land boundary
proceeds slowly and although the mar¬
itime boundary delimitation and fish¬
eries agreements were ratified in June
2004, implementation remains stalled; in
2004, international environmentalist
and political pressure from Burma and
Thailand prompted China to halt con¬
struction of 13 dams on the Salween
River
Refugees and internally displaced per¬
sons: refugees (country of origin): 300,897
(Vietnam); estimated 30,000-50,000
(North Korea)
lDPs: 90,000 (2007)
Trafficking in persons: current situation:
China is a source, transit, and destina¬
tion country for women, men, and chil¬
dren trafficked for purposes of sexual
exploitation and forced labor; the
majority of trafficking in China is
internal, but there is also international
trafficking of Chinese citizens; women
are lured through false promises of legiti¬
mate employment into commercial
sexual exploitation in Taiwan, Thailand,
Malaysia, and Japan; Chinese men and
women are smuggled to countries
throughout the world at enormous per¬
sonal expense and then forced into com¬
mercial sexual exploitation or
exploitative labor to repay debts to traf¬
fickers; women and children are traf¬
ficked into China from Mongolia,
Burma, North Korea, Russia, and
Vietnam for forced labor, marriage, and
sexual slavery; most North Koreans enter
northeastern China voluntarily, but
others reportedly are trafficked into
China from North Korea; domestic traf¬
ficking remains the most significant
problem in China, with an estimated
minimum of 10,000-20,000 victims traf¬
ficked each year; the actual number of
victims could be much greater; some
experts believe that the serious and pro¬
longed imbalance in the male-female
birth ratio may now be contributing to
Chinese and foreign girls and women
being trafficked as potential brides
tier rating: Tier 2 Watch List — China
failed to show evidence of increasing
efforts to address transnational traf¬
ficking; while the government provides
reasonable protection to internal victims
of trafficking, protection for Chinese and
foreign victims of transnational traf¬
ficking remain inadequate
Illicit drugs: major transshipment point
for heroin produced in the Golden
Triangle region of Southeast Asia;
growing domestic drug abuse problem;
source country for chemical precursors,
despite new regulations on its large
chemical industry
0 2 4 km
■ • . ■ hit* Qtxmn ■
0 2
4 m?
THE SETTLEMENT ^
.
j V
1
airfield t
!
-"''K
-
; A&fe
Background: Named in 1643 for the day
of its discovery, the island was annexed
and settlement began by the UK in 1888.
Phosphate mining began in the 1890s.
The UK transferred sovereignty to
Australia in 1958. Almost two-thirds of
the island has been declared a national
park.
Location: Southeastern Asia, island in
the Indian Ocean, south of Indonesia
Geographic coordinates: 10 30 s, 105
40 E
Map references: Southeast Asia
Area:
total: 135 sq km
land: 135 sq km
water: 0 sq km
Area — comparative: about three-quar¬
ters the size of Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical with a wet season
142','b9ed573fdb8547d599501c3a8c4e6edb893ac4314bdb8598cc1615b2262adff7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6365b2574fc9ec1f68250f84057b3d94f017f86485528d4eac64edffc1ad4c44',2009,'CX','Christmas Island','military-and-security',314,'(December to April) and dry season;
heat and humidity moderated by trade
winds
Terrain: steep cliffs along coast rise
abruptly to central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate, beaches
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (mainly tropical rainforest;
63% of the island is a national park)
(2005)
Irrigated land: NA
Natural hazards: the narrow fringing
reef surrounding the island can be a mar-
itime hazard
Environment — current issues: loss of
rainforest; impact of phosphate mining
Geography — note: located along major
sea lanes of Indian Ocean
Military — note: defense is the responsi¬
bility of Australia
Military — note: defense is the responsi¬
bility of France','3fcbbdcaee7891216ead7f749bfcdac600aaeb7276c1682499d22c8830705919','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22d1a3fecf936fb06b76f02a9785870a540a6ca43b319fb5e56e105b059e4a1',2009,'KM','Comoros','military-and-security',335,'Military branches: National Army
(Ejercito Nacional), National Navy
(Armada Nacional, includes Naval
Aviation, Naval Infantry (Infanteria de
Marina, Colmar), and Coast Guard),
Colombian Air Force (Fuerza Aerea de
Colombia, FAC) (2008)
Military service age and obligation:
18-24 years of age for compulsory and
voluntary military service; service obliga¬
tion — 18 months (2004)
Manpower available for military
Service: males age 1 6 — 49; 11,478,109
females age 16—49: 11,809,279 (2008 est.)
Manpower fit for military service:
males age 16-4 9: 8,056,336
females age 16—49: 9,919,952 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 442,403
females age 16—49: 433,192 (2008 est.)
Military expenditures— percent of
GDP: 3.4% (2005 est.)
Military branches: National
Development Army (AND): Comoran
Security Force; Comoran Federal Police
(2008)
Manpower available for military
service:
males age 16-49: 167,850
females age 16-49: 167,362 (2008 est.)
Manpower fit for military service:
males age 16-49: 121,550
females age 16-49: 131,015 (2008 est.)
Military expenditures — percent of
GDP: 2.8% (2006)
-U: . . : ."','dc46e35f764f0f0df0fd67f535a5284bbc7f099b2cd9e5ca6902de2afeee24af','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a164e44f243be7db22b500dd5421c4e95173a3c2a68f856f49417230e6e0c763',2009,'CG','Congo','military-and-security',347,'Military branches: Congolese Armed
Forces (Forces Armees Congolaises,
FAC): Army, Navy, Congolese Air Force
(Armee de l’Air Congolaise),
Gendarmerie, Special Presidential
Security Guard (GSSP) (2008)
Military service age and obligation: 18
years of age for voluntary military
service; women allowed to serve (2007)
Manpower available for military
service: males age 16-49: 842,771
females age 16-49: 833,624 (2008 est.)
Manpower fit for military service:
males age 16-49: 519,296
females age 16-4 9: 509,564 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—4 9: 45,671
females age 16—49: 45,248 (2008 est.)
Military expenditures — percent of
GDP: 3.1% (2006)','5231d62ca656f8647f996d1684e77ede655ac75e21bb1815982617d3e396a713','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('445f67cd2706eb84e1e4ce72d63102f34e38586667e126d29b2c679642c18d3a',2009,'CK','Cook Islands','military-and-security',354,'Military branches: no regular military
forces; National Police Department
(2007)
Military — note: defense is the responsi¬
bility of New Zealand, in consultation
with the Cook Islands and at its request','ccb5baf68ea022e5c35b27291921ac859dca59442733f5d1ecfbf20958206cd9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('081fb8b4e574d5b53146ac36716abce054447889131631abca5ffbf671306097',2009,'CR','Costa Rica','military-and-security',361,'Military — note: defense is the responsi¬
bility of Australia
Military branches: no regular military
forces; Ministry of Public Security,
Government, and Police (2008)
Manpower available for military
service: males age 16-49: 1,134,205
females age 16-49: 1,095,763 (2008 est.)
Manpower fit for military service:
males age 16—49: 958,013
females age 16—49: 925,727 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 40,767
females age 16-49: 38,899 (2008 est.)
Military expenditures— percent of
GDP: 0.4% (2006)','313d81b1b128c82f81c274e437640abf487d4669b3651464849fdd7ec28e2e6f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56ccfd123134fc3011612e0a7373ae168b6cf19c883fa7b20c8262432d3f646e',2009,'HR','Croatia','military-and-security',369,'_ _ _ _
Military branches: Cote d’Ivoire
Defense and Security Forces (FDSC):
Army, Navy, Air Force (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service (2008)
Manpower available for military
service:
males age 16-49: 4,369,735
females age 16-49: 4,287,042 (2008 est.)
Manpower fit for military service:
males age 16—49: 2,393,104
females age 16—49: 2,381,607 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 202,545
females age 16—49: 211,601 (2008 est.)
Military expenditures— percent of
GDP: 1.6% (2005 est)
Military branches: Armed Forces of the
Republic of Croatia (Oruzane Snage
Republike Hrvatske, OSRH), consists of
five major commands directly subordi¬
nate to a General Staff: Ground Forces
(Hrvatska Kopnena Vojska, HKoV),
Naval Forces (Hrvatska Ratna
Mornarica, HRM), Air Force, Joint
Education and Training Command,
Logistics Command; Military Police
Force supports each of the three
Croatian military forces (2007)
Military service age and obligation:
18-27 years of age for compulsory mili¬
tary service; 16 years of age with consent
for voluntary service; 6-month conscript
service obligation; full conversion to pro¬
fessional military service by 2010 (2006)
Manpower available for military
service:
males age 16-4 9: 1,035,712
females age 16-49: 1,037,896 (2008 est.)
Manpower fit for military service:
males age 16-49: 771,323
females age 16-49: 855,937 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 27,500
females age 16-49: 25,893 (2008 est.)
Military expenditures— percent of
GDP: 2.39% (2005 est.)
Disputes— international: dispute
remains with Bosnia and Herzegovina
over several small disputed sections of
170','8e14e90a7950cf15c378a72d2e808b2593a54de8907182c8dab4b5dfd0134f04','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19350ebfeb4d7ed788c5d8047d816304ba96bfeae8354be189eaecf2a82b2dfb',2009,'CU','Cuba','military-and-security',375,'the boundary related to maritime access
that hinders ratification of the 1999
border agreement; the Croatia-Slovenia
land and maritime boundary agreement,
which would have ceded most of Pirin
Bay and maritime access to Slovenia and
several villages to Croatia, remains un-
ratified and in dispute; Slovenia also
protests Croatia’s 2003 claim to an exclu¬
sive economic zone in the Adriatic; as a
European Union peripheral state, neigh¬
boring Slovenia must conform to the
strict Schengen border rules to curb
illegal migration and commerce through
southeastern Europe while encouraging
close cross-border ties with Croatia
Refugees and internally displaced per¬
sons: IDPs: 2,900-7,000 (Croats and
Serbs displaced in 1992-95 war) (2007)
Illicit drugs: transit point along the
Balkan route for Southwest Asian heroin
to Western Europe; has been used as a
transit point for maritime shipments of
South American cocaine bound for
Western Europe
''mm- m
¥
; . % ••• -hv
\\
w
^HAVANA
J ^ H ,
>$******
Santa
Ctera.
TME
Military branches: Revolutionary
Armed Forces (Fuerzas Armadas
Revolucionarias, FAR): Revolutionary
Army (ER; includes Territorial Militia
Troops, MTT), Revolutionary Navy
(Marina de Guerra Revolucionaria,
MGR; includes Marine Corps),
Revolutionary Air and Air Defense
Force (DAAFAR), Youth Labor Army
(EJT) (2008)
Military service age and obligation:
1 7-28 years of age for compulsory mili-
tary service; 2-year service obligation;
both sexes subject to military service
(2006)
Manpower available for military
service: males age 16-49: 3,094,388
females age 16-49: 3,024,876 (2008 est.)
Manpower fit for military service:
males age i 6 — 49: 2,543,044
females age 16-49: 2,481,823 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 79,945
females age 16-49: 76,014 (2008 est.)
Military expenditures— percent of
GDP: 3.8% (2006 est.)
Military — note: the collapse of the
Soviet Union deprived the Cuban Army
of its major economic and logistic sup¬
port, and had a significant impact on
equipment numbers and serviceability;
the army remains well trained and pro¬
fessional in nature; while the lack of
replacement parts for its existing equip¬
ment and the current severe shortage of
fuel have increasingly affected opera¬
tional capabilities, Cuba remains able to
offer considerable resistance to any
regional power (2008)','14b36cf740d06c7d6a41a52f8ceca10e96cfe2e7a1fd58d76fecc9a1e51b4cc6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('966d723ef284f767a5e237da09e750720a3855bfdd0fb803dbea44dd69b76d32',2009,'BS','Bahamas','military-and-security',376,'f
NORTH ATLANTIC
Niievitas OCEAN
CamagQey *
"''A — ■>
Jumntud
Caribbean
las Tu*ias#
Holguin "Nr ..
,
0
OMU
0 50 ISO*
H*
m \\mm\\
• ■* M.
^*uba CsM-tS.-- >"m
HAlTi
■','24a3a1c86ba20aabd78a77b953a3cb8ff02a42fe183a383111516f39f6a12c1c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('732ebf8865f22bf657a66738d2bdfffa081af02880d4a5a9d50f94878fce718b',2009,'CY','Cyprus','military-and-security',390,'Military branches: Republic of Cyprus:
Greek Cypriot National Guard (Ethniki
Forea, EF; includes air and naval ele¬
ments); northern Cyprus: Turkish
Cypriot Security Force (GKK) (2007)
Military service age and obligation:
Greek Cypriot National Guard
(GCNG): 18-50 years of age for compul¬
sory military service for all Greek
Cypriot males; 1 7 years of age for volun¬
tary service; females are not conscripted;
age of military eligibility 1 7 to 50; length
of normal service is 25 months with a
minimum of 3 months (2006)
Manpower available for military
Service: Greek Cypriot National Guard
(GCNG): males age 16-49: 199,767
females age 16-49: 190,665 (2008 est.)
Manpower fit for military service:
Greek Cypriot National Guard (GCNG):
males age 16-A9: 165,042
females age 16-49: 158,869 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
Greek Cypriot National Guard (GCNG):
males age 16-49: 6,482
females age 16-49: 6,208 (2008 est.)
Military expenditures— percent of
GDP: 3.8% (2005 est.)','8cb3c1d87d9a1d502f083f745ae401db45e7811f323af4710ad9033723795dd9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d33732f942a6e8c99adc6fe7f904b76e505ca25540fa70149ae0aa261ee31101',2009,'DM','Dominica','military-and-security',413,'Military branches: Djibouti National
Army (includes Navy and Air Force)
Military service age and obligation: 18
years of age for voluntary military
service; 16-25 years of age for voluntary
military training; no conscription (2008)
Manpower available for military
service:
males age 16-49: 111,274
females age 16-49: 105,168 (2008 est.)
Manpower fit for military service:
males age 16-49: 54,460
females age 16-49: 51,684 (2008 est.)
Military expenditures— percent of
GDP: 3.8% (2006)
Military branches: no regular military
forces; Commonwealth of Dominica Police
Porce (includes Coast Guard) (2008)
Manpower available for military
service:
males age 16-49: 18,584 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,648 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 756 (2008 est.)
Military expenditures— percent of
GDP: NA (2006)','d26af4ec760e005ca0712e89c8e15aa9e7ce12eb007a52a01e77f9c0c72d7abe','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a899db11418bfab354098ac296c19ea1015e6585273c1a782647ce6e9be90e84',2009,'DO','Dominican Republic','military-and-security',426,'Military branches: Army, Navy, Air
Force (Fuerza Aerea Dominicana, FAD)
(2007)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military
service: males age 16-49: 2,440,203
females age 16-49: 2,326,694 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,020,490
females age 16—49: 1,883,875 (2008 est.)
Manpower reaching miiitarily signifi¬
cant age annually:
males age 16-49: 96,971
females age 16—49: 93,116 (2008 est.)
Military expenditures— percent of
GDP: 0.8% (2006)','7d417443b70df235cf895b67dd77107f2278b45e633611430d571a7cf026a710','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a1d3cd5e7f5b21f98872d2920b3cfc51afc29befe03595eb5ff87c4b48c3014',2009,'EG','Egypt','military-and-security',432,'Military branches: Army, Navy
(includes Naval Infantry, Naval
Aviation, Coast Guard), Air Force
(Fuerza Aerea Ecuatoriana, FAE) (2007)
Military service age and obligation: 20
years of age for selective conscript mili¬
tary service; 12-month service obligation
(2006)
Manpower available for military
service:
males age 16—49: 3,536,602
females age 16—49: 3,559,188 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,030,664
females age 16—49: 3,037,892 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-4 9: 144,821
females age 16—49: 139,091 (2008 est.)
Military expenditures— percent of
GDP: 2.8% (2006)
Disputes— international: organized
illegal narcotics operations in Colombia
penetrate across Ecuador’s shared border,
which thousands of Colombians also
cross to escape the violence in their
home country
Refugees and internally displaced per¬
sons: refugees (country of origin): 11,526
(Colombia); note — UNHCR estimates
as many as 250,000 Columbians are
seeking asylum in Ecuador, many of
whom do not register as refugees for fear
of deportation (2007)
Illicit drugs: significant transit country
for cocaine originating in Colombia and
Peru, with over half of the US-bound
cocaine passing through Ecuadorian
Pacific waters; importer of precursor
chemicals used in production of illicit
narcotics; attractive location for cash-
placement by drug traffickers laundering
money because of dollarization and weak
anti-money-laundering regime; increased
activity on the northern frontier by traf¬
ficking groups and Colombian insurgents','ed584fc355e471b42432a9a7628c7a0690e7c6784f655bb00915917b81e3998a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3209d3965926c60396f5d45505babf4f1a4dda2f5b0798182e6ef4f17f49ef3',2009,'EE','Estonia','military-and-security',462,'Military branches: Estonian Defense
Forces: Land Force, Navy, Air Force
(Eesti Ohuvagi), Volunteer Defense
League (Kaitseliit, KL) (2008)
Military service age and obligation:
compulsory military service for men
between 19 and 28; conscription lasts 11
months for junior NCOs and reserve pla¬
toon leaders; reserve officers and desig¬
nated specialists have a different
conscript service obligation; Estonia has
committed to retaining conscription for
men up to 2010 and, unlike Latvia and
Lithuania, has no plan to transition to a
contract armed forces; 17 years of age for
volunteers; reserve commitment up to
the age of 60 (2006)
Manpower available for military
service: males age 16-49: 306,273
females age 16-49: 317,852 (2008 est.)
Manpower fit for military service:
males age 16-49: 218,448 (in 2004, 51%
of the young men called up for service
were determined to be unfit; main obsta¬
cles to conscription were psychiatric and
behavioral)
females age 16-49: 264,187 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 8,322
females age 16-49: 7,846 (2008 est.)
Military expenditures— percent of
GDP: 2% (2005 est.)','00af1b287c0ea4dc90562e61b73b0eae6c6781022cb58fa621c9c92fa4385c63','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('002e022404c754cc7c742cce6084f7eab90619d7d45f3248959a4f9e9c9e1962',2009,'ET','Ethiopia','military-and-security',472,'Military branches: no regular military
forces
Military expenditures — percent of
GDP: NA
Military — note: defense is the responsi¬
bility of the UK','73606303787b3ef6897c27f7d7e95f94ea4849b2ee9ee1953407564c79877bbd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9c77a380ba3676214b72554399b583c32b6bf6fbb839102686c8c90c8cb822a',2009,'FJ','Fiji','military-and-security',478,'Military branches: no regular military
forces
Manpower available for military service:
males age 16-49: 11,725 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,735 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 400 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi-
bility of Denmark
Disputes— international: because antic¬
ipated offshore hydrocarbon resources
have not been realized, earlier Faroese
proposals for full independence have
been deferred; Iceland, the UK, and
Ireland dispute Denmark’s claim that the
Faroe Islands’ continental shelf extends
beyond 200 nm
Background: Fiji became independent in
1970, after nearly a century as a British
colony. Democratic rule was interrupted
by two military coups in 1987, caused by
concern over a government perceived as
dominated by the Indian community
(descendants of contract laborers
brought to the islands by the British in
the 19th century). The coups and a 1990
constitution that cemented native
Melanesian control of Fiji, led to heavy
Indian emigration; the population loss
resulted in economic difficulties, but
ensured that Melanesians became the
majority. A new constitution enacted in
1997 was more equitable. Free and
peaceful elections in 1999 resulted in a
government led by an Indo-Fijian, but a
civilian-led coup in May 2000 ushered in
a prolonged period of political turmoil.
Parliamentary elections held in August
2001 provided Fiji with a democratically
elected government led by Prime
Minister Laisenia QARASE. Re-elected
in May 2006, QARASE was ousted in a
December 2006 military coup led by
Commodore Voreqe BAINIMARAMA,
who initially appointed himself acting
president. In January 2007, BAINI-
MARAMA was appointed interim prime
minister.
Military branches: Republic of Fiji
Military Forces (RFMF): Land Forces,
Naval Forces (2008)
Military service age and obligation: 18
years of age for voluntary military
service; reserve obligation to age 45
(2006)
Manpower available for military
service: males age 16-49: 242,567
females age 16-49: 238,556 (2008 est.)
225
THE CIA WORLD FACTBOOK
Manpower fit for military service:
males age 16-49: 189,282
females age 16-49: 202,350 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually: males age 16-49: GDP: 2.2% (2005 est.)
9,077
females age 16—49: 8,728 (2008 est.)
Military expenditures — percent of Disputes — international: none
Rovaniami
Kuopto*
p S£i tOO ten
'' Ai ''
6 m
100 f!ii
Sm
■
,:Mf i
MTA .
i fW
,? '' - l
J
'' NORWAY y
\\ >va„
(f
i
Ivalo* (
mm
''','ca32434f4615f1d62b3bb20e0329182b9ea248bbfd6d78fefb8e46bfb4aa8d13','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1973647f4a04cd00d78c2d52c18e746809639d2a020d2c901fd2a82a849c1d1',2009,'SE','Sweden','military-and-security',484,'.?
flRH
■ Vaasa
RUSSIA
Jyvaskyia, Varkau
.Pori Tampere
»
sRaurna
z, . . Lahti
fJusikaupurtta • a
:,#Turku LoUt
'' > Espoo . Kotka
^HELSINKI
ALAMO
ISLANDS
. ‘ .A,
fei^ , '' f
wsiomA
Military branches: Umbutfo Swaziland
Defense Force (USDF): Ground Force
(includes air wing) (2008)
Military service age and obligation:
18-30 years of age for male and female
voluntary military service; no conscrip¬
tion (2008)
Manpower available for military
service:
males age 16—49: 266,311 (2008 est.)
Manpower fit for military service:
males age 16—49: 122,260 (2008 est.)
Military expenditures— percent of
GDP: 4.7% (2006)','bb4c8f1fdd4e60dfc543e940a2a4c62bf9b64c57c09b8d662154335df983df32','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92887bdb3f2147625a39ab83f9eed35cef0979a7db20fdfcaeb8882da71f2a5f',2009,'PF','French Polynesia','military-and-security',496,'Military branches: Army (includes
Marines, Foreign Legion, Army Light
Aviation), Navy (Marine Nationale,
includes Naval Air), Air Force (Armee
de l’Air, includes air defense), National
Gendarmerie (2008)
Military service age and obligation:
17-40 years of age for male or female vol¬
untary military service); no conscription;
12-month service obligation; women
serve in noncombat military posts
(2005)
Manpower available for military
service:
males age 16-49: 14,646,427
females age 16-49: 14,379,630 (2008
est.)
Manpower fit for military service:
males age 16-49: 12,110,718
females age 16-49: 11,849,988 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 401,379
females age 16-49: 382,409 (2008 est.)
Military expenditures— percent of
GDP: 2.6% (2005 est.)
Military branches: no regular military
forces; Gendarmerie and National Police
Force (2007)
Manpower available for military
service:
males age 16—49: 79,540 (2008 est.)
Manpower fit for military service:
males age 16—49: 64,287 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 2,699 (2008 est.)
Military— note: defense is the responsi¬
bility of France
Military — note: defense is the responsi¬
bility of France','d5f8e18c55729c09664e670c9e613cd1ab07c1ba3b21f569a4c85967475d64b0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06a5fb55f965b087abcb8a48ec0f73bec234a2a341846c633892de1597b23c4d',2009,'GA','Gabon','military-and-security',513,'Military branches: Army, Navy, Air
Force, National Gendarmerie, National
Police
Military service age and obligation: 20
years of age for compulsory and voluntary
military service (2007)
Manpower available for military
service:
males age 16-49: 331,181
females age 16—49: 332,498 (2008 est.)
Manpower fit for military service:
males age 16—49: 192,717
females age 16—49: 188,539 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-4 9: 16,558
females age 16—49: 16,577 (2008 est.)
Military expenditures— percent of
GDP: 3.4% (2005 est.)','995dbf1ac8a36fe7c6724c1667d250e25df20afb1140c015fd60f3a5145ef7f4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('877825a5d405f11f0164ce78f0a55296d48a4f34677b738cc100bf6f63ccc84f',2009,'GM','Gambia','military-and-security',518,'Military branches: Office of the Chief of
Defense: Gambian National Army
(National Guard, GNA), Gambian
Navy (GN) (2008)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 379,668
females age 16-49: 384,438 (2008 est.)
Manpower fit for milifary service:
males age 16-49: 230,202
females age 16^49: 244,480 (2008 est.)
Military expenditures — percent of
GDP: 0.5% (2006)','d9ce084d6c47f03754025f34fe2f860620ef666638d978e5d0f858128cb8cbfc','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7dd7f2700f68531da88735db953d65a1844cd2065bf06001e03a4a1f84de8f5',2009,'IL','Israel','military-and-security',527,'Military branches: in accordance with
the peace agreement, the Palestinian
Authority is not permitted conventional
military forces; there are, however,
public security forces (2008)
Manpower available for military
service:
males age 16-49: 337,670 (2008 est.)
Manpower fit for military service:
males age 16^49: 291,467 (2008 est.)
Manpower
reaching militarily significant age annu¬
ally: males age 16^49: 19,567 (2008 est.)
Military expenditures— percent of
GDP: NA
Military branches: Israel Defense Forces
(IDF), Israel Naval Forces (INF), Israel
Air Force (IAF) (2007)
Military service age and obligation: 18
years of age for compulsory (Jews,
Druzes) and voluntary (Christians,
Muslims, Circassians) military service;
both sexes are obligated to military
service; conscript service obligation— 36
months for enlisted men, 21 months for
325
THE CIA WORLD FACTBOOK
enlisted women, 48 months for officers;
reserve obligation to age 41-51 (men),
24 (women) (2008)
Manpower available for military
service:
males age 16-49: 1,717,362
females age 16-49: 1,636,574 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,452,926
females age 16-49: 1,383,796 (2008 est.)
Manpower reaching militariiy signifi¬
cant age annually:
males age 16-49: 60,602
females age 16—49: 57,532 (2008 est.)
Military expenditures— percent of
GDP: 7.3% (2006)
Disputes— international: West Bank
and Gaza Strip are Israeli-occupied with
current status subject to the Israeli-
Palestinian Interim Agreement — perma¬
nent status to be determined through
further negotiation; Israel continues con¬
struction of a “seam line” separation bar¬
rier along parts of the Green Line and
within the West Bank; Israel withdrew
its settlers and military from the Gaza
Strip and from four settlements in the
West Bank in August 2005; Golan
Heights is Israeli-occupied (Lebanon
claims the Shab’a Farms area of Golan
Heights); since 1948, about 350 peace¬
keepers from the UN Truce Supervision
Organization (UNTSO) headquartered
in Jerusalem monitor ceasefires, super¬
vise armistice agreements, prevent iso¬
lated incidents from escalating, and assist
other UN personnel in the region
Refugees and internally displaced per¬
sons: IDPs: 150,000-420,000 (Arab vil¬
lagers displaced from homes in northern
Israel) (2007)
Illicit drugs: increasingly concerned
about ecstasy, cocaine, and heroin abuse;
drugs arrive in country from Lebanon
and, increasingly, from Jordan; money¬
laundering center
Verona
Livorno*
CUfSicS
m.) }■ 1
: Vi
jCigiiari
Paleiimo, cssn \\ Reggio di Calabria
SWy
M&WSi Oil Terminal
* 0 1Q0
PHMiZr 9 *00 mi','e4917ed05bba1c416f744fcbf46acb57e0808ffa20322932162f8bf8016964b7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5558f9dfd9a9acbe7cfce1c56a6112f6364edfb605b1d80d10073587ce14abff',2009,'GE','Georgia','military-and-security',534,'Military branches: Georgian Armed
Forces: Land Forces, Navy, Air and Air
Defense Forces, National Guard (2008)
Military service age and obligation: 18
to 34 years of age for compulsory and vol¬
untary active duty military service; con¬
script service obligation — 18 months
(2005)
Manpower available for military
service: males age 16-49: 1,113,251
females age 16-49: 1,168,021 (2008 est.)
Manpower fit for military service:
males age 16-49: 910,720
females age i 6 — 49: 967,566 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 1 6—49 : 35,917
females age 16-49: 34,566 (2008 est.)
Military expenditures— percent of
GDP: 0.59% (2005 est.)
Military — note: a CIS peacekeeping
force of Russian troops is deployed in the
Abkhazia region of Georgia together
with a UN military observer group; a
Russian peacekeeping battalion is
deployed in South Ossetia','89be2d4193d72c8dae7e90fe0e7b0c45b6117c78cd092ab9fdce382da8849aaa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49fa0d753013b0da83251b06e3e306b616add851d0de0d3d61eaf568c642a98d',2009,'DE','Germany','military-and-security',536,'v. I.
Military branches: Federal Armed
Forces (Bundeswehr): Army (Heer),
253
THE CIA WORLD FACTBOOK
Navy (Deutsche Marine, includes naval
air arm), Air Force (Luftwaffe), Joint
Service Support Command
(Streitkraeftebasis), Central Medical
Service (Zentraler Sanitaetsdienst)
(2006)
Military service age and obligation: 18
years of age (conscripts serve a 9-month
tour of compulsory military service)
(2004)
Manpower available for military
service:
males age 16—49: 19,594,118
females age 16—49: 18,543,955 (2008
est.)
Manpower fit for military service:
males age 16—49: 15,906,930
females age 16—4 9: 15,051,183 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 442,972
females age 16—49: 420,801 (2008 est.)
Military expenditures — percent of
GDP: 1.5% (2005 est.)','afb29ab9349e8a864a8358c240f04fed2ad01d5df6dd05fee46a5257c4b3cb07','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d56770525750fd30d535fa308f21643f863641189f8888f1ca33c12efacba94e',2009,'GI','Gibraltar','military-and-security',542,'Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service: males age 16-49: 5,802,096
females age 16-49: 5,729,939 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,737,481
females age 16-49: 3,729,699 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 273,265
females age 16-49: 267,204 (2008 est.)
Military expenditures— percent of
GDP: 0.8% (2006 est.)
Disputes — international: Ghana strug-
gles to accommodate returning nationals
who worked in the cocoa plantations and
escaped fighting in Cote d’Ivoire
Refugees and internally displaced per¬
sons: refugees (country of origin): 35,653
(Liberia); 8,517 (Togo) (2007)
Illicit drugs: illicit producer of cannabis
for the international drug trade; major
transit hub for Southwest and Southeast
Asian heroin and, to a lesser extent,
South American cocaine destined for
Europe and the US; widespread crime
and money laundering problem, but the
lack of a well developed financial infra-
structure limits the country’s utility as a
money laundering center; significant
domestic cocaine and cannabis use
Background: Strategically important,
Gibraltar was reluctantly ceded to Great
Britain by Spain in the 1713 Treaty of
Utrecht; the British garrison was for¬
mally declared a colony in 1830. In a ref¬
erendum held in 1967, Gibraltarians
voted overwhelmingly to remain a
British dependency. The subsequent
granting of autonomy in 1969 by the UK
led to Spain closing the border and sev¬
ering all communication links. A series
of talks were held by the UK and Spain
between 1997 and 2002 on establishing
temporary joint sovereignty over
Gibraltar. In response to these talks, the
Gibraltar Government called a refer¬
endum in late 2002 in which the
majority of citizens voted overwhelm¬
ingly against any sharing of sovereignty
with Spain. Since the referendum, tri¬
partite talks on other issues have been
held with Spain, the UK, and Gibraltar,
and in September 2006 a three-way
agreement was signed. Spain agreed to
remove restrictions on air movements, to
speed up customs procedures, to imple¬
ment international telephone dialing,
and to allow mobile roaming agreements.
Britain agreed to pay increased pensions
to Spaniards who had been employed in
Gibraltar before the border closed. Spain
will be allowed to open a cultural insti¬
tute from which the Spanish flag will fly.
A new noncolonial constitution came
into effect in 2007, but the UK retains
responsibility for defense, foreign rela¬
tions, internal security, and financial
stability.','34a38d1e5957c5d1ca9a22c2952e9bf8d85c359c5da8793e32bc5d4f38f4f23d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('987cf0f3201b8db1f0963230e0a8327153efba9e4e705f6a77437faa2989d775',2009,'GR','Greece','military-and-security',551,'Military branches: Hellenic Army
(Ellinikos Stratos, ES), Hellenic Navy
(Ellinikos Polemiko Navtiko, EPN),
Hellenic Air Force (Elliniki Polimiki
Aeroporia, EPA) (2007)
Military service age and obligation: 18
years of age for compulsory military
service; during wartime the law allows
for recruitment beginning January of the
year of inductee’s 18th birthday, thus
including 17 year olds; 17 years of age for
volunteers; conscript service obliga¬
tion— 12 months for the Army, Air
Force; 15 months for Navy; women are
eligible for voluntary military service
(2007)
Manpower available for military
service:
males age 1 6 — 49: 2,535,174
females age 16-49: 2,517,273 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,084,469
females age 16-49: 2,065,956 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 53,858
females age 16-49: 50,488 (2008 est.)
Military expenditures— percent of
GDP: 4.3% (2005 est.)','a27ee92c874f576139f6e3ac92f3846162d4dc1ac11f1383e57e3613c126295d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc06225ae68ad5d6fdf37fd07a81c9850b4f1655545cd1a62c7fec753666ed75',2009,'GW','Guinea-Bissau','military-and-security',575,'Military branches: Armed Forces: Army,
Navy (Marine Guineenne, includes
Marines), Air Force, Presidential Guard
(2008)
Military service age and obligation: 18
years of age for compulsory military
service; 2-year conscript service obliga¬
tion (2006)
Manpower available for military
service:
males age 16-49: 2,230,049
females age 16—49: 2,193,236 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,268,193
females age 16-4 9: 1,259,913 (2008 est.)
Military expenditures— percent of
GDP: 1.7% (2006)
Disputes — international: conflicts
among rebel groups, warlords, and youth
gangs in neighboring states have spilled
over into Guinea, resulting in domestic
instability; Sierra Leone considers
Guinea’s definition of the flood plain
limits to define the left bank boundary of
the Makona and Moa rivers excessive
and protests Guinea’s continued occupa¬
tion of these lands, including the hamlet
of Yenga, occupied since 1998
Refugees and internally displaced per¬
sons: refugees (country of origin): 21,856
(Liberia); 5,259 (Sierra Leone); 3,900
(Cote d’Ivoire)
IDPs: 19,000 (cross-border incursions
from Cote d’Ivoire, Liberia, Sierra
Leone) (2007)
Sliilll,
Fartm
Batata
^BISSAU
Buba
Bolami','3f3931316347d99a58d6b9f796fc55cfab7e918051149987aa1f6b5ed2668dbb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f64ec400a5bc78fd0ec9005a1337e46a33cb4481298c582d37015ba3aa0e94',2009,'GN','Guinea','military-and-security',576,'nonm atiahtk ccsah
40 Mkm
Military branches: Armed Forces of Sao
Tome and Principe (FASTP): Army,
Coast Guard of Sao Tome e Principe
(Guarda Costeira de Sao Tome e
Principe, GCSTP), Presidential Guard
(2007)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military
service:
males age 16-49: 42,340
females age 16^49: 43,781 (2008 est.)
Manpower fit for military service:
males age 16-49: 33,735
females age 16-49: 36,779 (2008 est.)
Military expenditures— percent of
GDP: 0.8% (2006)
Military — note: Sao Tome and Principe’s
army is a tiny force with almost no
resources at its disposal and would be
wholly ineffective operating unilaterally;
infantry equipment is considered simple
to operate and maintain but may require
refurbishment or replacement after 25
years in tropical climates; poor pay,
working conditions, and alleged nepo¬
tism in the promotion of officers have
been problems in the past, as reflected in
the 1995 and 2003 coups; these issues are
being addressed with foreign assistance
aimed at improving the army and its
focus on realistic security concerns; com¬
mand is exercised from the president,
through the Minister of Defense, to the
Chief of the Armed Forces staff (2005)','dc659774736ed2a439470c0028390b354bac7d4a77f00614f2f5e7984e95b8b5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c829ab38dbd51595f74d6ebf487989585f3e78adc8fd98b96bc8a04ba69fa7',2009,'GY','Guyana','military-and-security',586,'Military branches: Guyana Defense
Force: Army (includes Coast Guard, Air
Corps) (2007)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 220,797 (2008 est.)
Manpower fit for military service:
males age 16-49: 150,623 (2008 est.)
Military expenditures — percent of
GDP: 1.8% (2006)
Military branches: Trinidad and Tobago
Defense Force: Ground Force, Coast
Guard (includes air wing) (2004)
Military service age and obligation: 18
years of age for voluntary military service
(16 years of age with parental consent);
no conscription (2008)
Manpower available for military
service:
males age 16-49: 301,561
females age 16-49: 264,225 (2008 est.)
Manpower fit for military service:
males age 16-49: 215,310
females age 16-A9: 180,526 (2008 est.)
Military expenditures— percent of
GDP: 0.3% (2006)
Military branches: National Armed
Forces (Fuerza Armada Nacionale,
FAN): Ground Forces or Army (Fuerzas
Terrestres or Ejercito), Naval Forces
(Fuerzas Navales or Armada; includes
Marines, Coast Guard), Air Force
(Fuerzas Aereas or Aviacion), Armed
Forces of Cooperation or National Guard
(Fuerzas Armadas de Cooperacion or
Guardia Nacionai)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 30 months; all citizens of military
service age (between 18 and 50 years
old) are obligated to register for military
service (2007)
Manpower available for military
service:
males age 16-49: 6,647,124
females age i 6 — 49: 6,801,133 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,280,974
females age 16-49: 5,768,814 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 275,323
females age 16-49: 274,106 (2008 est.)
Military expenditures— percent of
GDP: 1.2% (2005 est.)
Military branches: People’s Armed
Forces: People’s Army of Vietnam
(PAVN) (includes People’s Navy
Command (with naval infantry, coast
guard), Air and Air Defense Force (Kon
Quan Nhan Dan), Border Defense
Command), People’s Public Security
Forces, Militia Force, Self-Defense
Forces (2005)
Military service age and obligation: 18
years of age (male) for compulsory mili¬
tary service; females may volunteer for
active duty military service; conscript
service obligation — 2 years (3 to 4 years
in the navy); 18-45 years of age (male)
or 18-40 years of age (female) for Militia
Force or Self Defense Forces (2006)
Manpower available for military
service: males age 16-49: 24,586,328
females age 16-4 9: 24,335,132 (2008
est.)
Manpower fit for military service:
males age 16-49: 18,849,274
females age 16-49: 20,575,884 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 903,734
females age 16-49: 845,306 (2008 est.)
Military expenditures— percent of
GDP: 2.5% (2005 est.)
Military — note: defense is the responsi¬
bility of the US
Military — note: defense is the responsi¬
bility of the US; the US Air Force is
responsible for overall administration
and operation of the island; the launch
support facility is administered by the US
Missile Defense Agency (MDA)','0db49c80417d836c172f058015856bfa09794a5096ab4886fddaafa565b3b9f7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2911972baa83e7a179f6f66bfa4e7d89444aaaffd031c790638f321c94db72b',2009,'HM','Heard Island and McDonald Islands','military-and-security',599,'Military — note: defense is the responsi¬
bility of Australia; Australia conducts
fisheries patrols','22e82d64b060d8926e9951f8708ff713088beb41ff9472749b27e157e477343c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7de1324b929eac11448c513b5ac8b04768ed66d65d911442e97df798e744ea8',2009,'HK','Hong Kong','military-and-security',610,'Military branches: Army, Navy
(includes Naval Infantry), Honduran Air
Force (Fuerza Aerea Hondurena, FAH)
(2008)
Military service age and obligation: 18
years of age for voluntary 2 to 3 -year mil¬
itary service (2004)
Manpower available for military
service:
males age 16-49: 1,868,940
females age 16-49: 1,825,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,359,406
females age 16-49: 1,371,418 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 90,876
females age 16-49: 87,292 (2008 est.)
Military expenditures— percent of
GDP: 0.6% (2006 est.)
Disputes — international: International
Court of Justice (ICJ) ruled on the
delimitation of “bolsones” (disputed
areas) along the El Salvador- Honduras
border in 1992 with final settlement by
the parties in 2006 after an Organization
of American States (OAS) survey and a
further ICJ ruling in 2003; the 1992 ICJ
ruling advised a tripartite resolution to a
maritime boundary in the Gulf of
Fonseca with consideration of Honduran
access to the Pacific; El Salvador con¬
tinues to claim tiny Conejo Island, not
mentioned in the ICJ ruling, off
Honduras in the Gulf of Fonseca;
Honduras claims the Belizean-adminis¬
tered Sapodilla Cays off the coast of
Belize in its constitution, but agreed to a
joint ecological park around the cays
should Guatemala consent to a maritime
corridor in the Caribbean under the
OAS-sponsored 2002 Belize-Guatemala
Differendum; memorials and counter¬
memorials were filed by the parties in
Nicaragua’s 1999 and 2001 proceedings
against Honduras and Colombia at the
ICJ over the maritime boundary and ter¬
ritorial claims in the western Caribbean
Sea — final public hearings are scheduled
for 2007
Illicit drugs: transshipment point for
drugs and narcotics; illicit producer of
cannabis, cultivated on small plots and
used principally for local consumption;
corruption is a major problem; some
money-laundering activity
Military branches: no regular indigenous
military forces; Hong Kong garrison of
China’s People’s Liberation Army (PLA)
includes elements of the PLA Ground
Forces, PLA Navy, and PLA Air Force;
these forces are under the direct leader¬
ship of the Central Military Commission
in Beijing and under administrative con¬
trol of the adjacent Guangzhou Military
Region (2007)
Manpower available for military
service:
males age 16-4 9: 1,772,820
females age 16-49: 1,941,448 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,438,165
females age 7 6 — 49: 1,561,252 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 42,173
females age 16-49: 38,753 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of China','e315f45a1dc7c2a087285d218a262f1e59a4d312a21ad616510f6be64ba71e23','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54ae1dfaa38fa4abd75aa4fdfe836c49e05c0cdbaf97693368424dc58a968f30',2009,'IS','Iceland','military-and-security',626,'Military branches: no regular military
forces; Icelandic National Police (2008)
Manpower available for military
service:
males age 16-49: 74,896 (2008 est.)
Manpower fit for military service:
males age i 6—49: 62,342 (2008 est.)
Military expenditures— percent of
GDP: 0% (2005 est.)
Military — note: Iceland has no standing
military force; under a 1951 bilateral
agreement— still valid — its defense was
provided by the US-manned Icelandic
Defense Force (IDF) headquartered at
Keflavik; however, all US military forces
in Iceland were withdrawn as of October
2006; although wartime defense of
Iceland remains a NATO commitment,
in April 2007, Iceland and Norway
signed a bilateral agreement providing
for Norwegian aerial surveillance and
defense of Icelandic airspace (2008)
Disputes— international: Iceland, the
UK, and Ireland dispute Denmark’s
claim that the Faroe Islands’ continental
shelf extends beyond 200 nm','743e4b00bcb67ec2f37e1f95861358a757d28b99580d0eb3279e6d4954022e5e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61bc904e3a55d67ceebe21b2e1739a02a497782d5f0f76c28dc2647fb69a3fd7',2009,'IN','India','military-and-security',631,'Military branches: Army, Navy
(includes naval air arm), Air Force,
Coast Guard (2008)
Military service age and obligation: 16
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 301,094,084
females age 16^\\9: 283,047,141 (2008
est.)
Manpower fit for military service:
males age 16-49: 231,161,111
females age 16^9: 236,633,962 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 11,592,516
females age 16-49: 10,636,857 (2008
est.)
Military expenditures— percent of
GDP: 2.5% (2006)','305996d5234bfa3ff486667fc36a7e014002f016428a64b580ec92237708b1f1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78332c355fc36dd03674b94b29fb83d2daeec57b68fd4737890b542a645cf961',2009,'IT','Italy','military-and-security',662,'Military branches: Italian Army
(Esercito Italiano, El), Italian Navy
(Marina Militare Italiana, MMI), Italian
Air Force (Aeronautica Militare
Italiana, AMI), Carabinieri Corps
(Arma dei Carabinieri, CC) (2008)
Military service age and obligation:
18-27 year of age for voluntary military
service; conscription abolished January
2005; women may serve in any military
branch; 10-month service obligation,
with a reserve obligation to age 45
(Army and Air Force) or 39 (Navy)
(2006)
Manpower available for military
service:
males age 16-49: 13,884,079
females age 16-49: 13,158,378 (2008
est.)
Manpower fit for military service:
males age 1 6 — 49 : 11,285,488
females age 16-49: 10,680,672 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 290,740
females age 16-49: 273,569 (2008 est.)
Military expenditures— percent of
GDP: 1.8% (2005 est.)','75c208e86afec7f5e9fee9cb3525209b2e1b2106f3e84fc24d73a5180936a1e3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ff5419e1b059ffaf8683b22b02d883ea4a314455ea612d8589e079562040b1e',2009,'JM','Jamaica','military-and-security',669,'Military branches: Jamaica Defense
Force: Ground Forces, Coast Guard, Air
Wing (2007)
Military service age and obligation: 18
years of age for voluntary military
service; younger recruits may be con¬
scripted with parental consent (2001)
Manpower available for military
service:
males age 16—4 9: 688,480
females age 16-49: 709,548 (2008 est.)
Manpower fit for military service:
males age 16-49: 566,477
females age 16-49: 583,075 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 32,000
females age 16-49: 31,428 (2008 est.)
Military expenditures— percent of
GDP: 0.6% (2006 est.)','47ab44d4a815377f35f400ccccd4c3926d3b9fef5915994b8de259f8b9475bd5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c00d365e0c1ebe489f98145def0a85adc5c18e8dd2034c25670fde621670538',2009,'JP','Japan','military-and-security',677,'_
Military — note: defense is the responsi¬
bility of Norway
Military branches: Japanese Ministry of
Defense (MOD): Ground Self-Defense
Force (Rikujou Jietai, GSDF), Maritime
Self-Defense Force (Kaijou Jietai,
MSDF), Air Self-Defense Force (Koku
Jieitai, ASDF) (2008)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military
service:
males age 16-49: 27,819,804
females age 16-49: 26,863,794 (2008
est.)
Manpower fit for military service:
males age 16-49: 22.963 million
females age 16-49: 22,134,127 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 622,168
females age 16-49: 590,153 (2008 est.)
Military expenditures— percent of
GDP: 0.8% (2006)','aa43283076158946385e7e4f65962d385714ac46289abc41118e97b70019d924','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40bc09e7b8ed3c4ce8204a33137f1a94a1901fe3f524e9d637ad54aba8d4ec11',2009,'JO','Jordan','military-and-security',693,'Military branches: Jordanian Armed
Forces (JAF): Royal Jordanian Land
Force, Royal Jordanian Navy, Royal
Jordanian Air Force (Al-Quwwat al-
Jawwiya al-Malakiya al-Urduniya),
Special Operations Command (Socom);
Public Security Directorate (normally
falls under Ministry of Interior, but
comes under JAF in wartime or crisis sit¬
uations) (2006)
Military service age and obligation: 17
years of age for voluntary military
service; conscription at age 18 was sus¬
pended in 1999, although all males
under age 37 are required to register;
women not subject to conscription, but
can volunteer to serve in non-combat
military positions (2004)
Manpower available for military
service:
males age 16-49: 1,812,551
females age 16—49: 1,559,155 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,546,766
females age 16-49: 1,339,366 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 68,067
females age 16—49: 65,512 (2008 est.)
Military expenditures— percent of
GDP: 8.6% (2006)','b1da99c9349f6b64529aac202d8ca037051595602dfbd5b7a894f645d9dfbe10','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f30be31af465269cd7d7d27268e54b0890a5b1d7d147f63cc51572c8bb44ea21',2009,'KE','Kenya','military-and-security',701,'Military branches: Ground Forces,
Naval Force, Air and Air Defense Forces,
Republican Guard
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 2
years; minimum age for volunteers NA
(2004)
Manpower available for military
service:
males age 16-49: 4,176,731
females age 16—49: 4,219,636 (2008 est.)
Manpower fit for military service:
males age 16—49: 2,871,205
females age 16—49: 3,551,032 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 145,495
females age 16—49: 140,149 (2008 est.)
Military expenditures— percent of
GDP: 0.9% (Ministry of Defense expen¬
ditures) (FY02)
Military branches: Kenyan Army,
Kenyan Navy, Kenyan Air Force (2007)
Military service age and obligation: 18
years of age (est.) for voluntary service,
with a 9-year obligation (2007)
Manpower available for military
service:
males age 16-49: 9,044,685
females age 16-49: 8,805,736 (2008 est.)
Manpower fit for military service:
males age 16—49: 5,688,259
females age 16—49: 5,396,166 (2008 est.)
Military expenditures— percent of
GDP: 2.8% (2006)','c98175caa66a144e5d9379092e0ea7328d1a0ef81c0cc0bf2afbd7cd96e3d09e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e60113b96f462adc5ee1bab9d5c1ed575be97f14bcbb7592431133e478fa050a',2009,'KG','Kyrgyzstan','military-and-security',716,'Military branches: Land Forces, Kuwaiti
Navy, Kuwaiti Air Force (Al-Quwwat al-
Jawwiya al-Kuwaitiya), National Guard
(2007)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; reserve obligation to age
40 with 1 month annual training;
women have served in police forces since
1999 (2006)
Manpower available for military
service:
males age 16—4 9: 1,032,408
females age 16—49: 568,657 (2008 est.)
Manpower fit for military service:
males age 16—49: 892,816
females age 16-49: 500,540 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 17,737
females age 16—49: 18,519 (2008 est.)
Military expenditures— percent of
GDP: 5.3% (2006)
Military branches: Army, Air Force,
National Guard (2005)
Military service age and obligation: 18
years of age for compulsory military
service (2001)
Manpower available for military
service:
males age 16-49: 1,398,878
females age 16-49: 1,419,374 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,061,942
females age 16-49: 1,211,249 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 60,706
females age 16-49: 58,721 (2008 est.)
Military expenditures— percent of
GDP: 1.4% (2005 est.)','4c31d84076215def134a8b82121b0f918350103d21ff2bcd8a12ab2ec7c675c2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26084b1eaaae4bc273ad69c6b70d530e54ae8e93a61f692f93f418633b36176d',2009,'LB','Lebanon','military-and-security',735,'Military branches: Lebanese Armed
Forces (LAF): Army (includes Navy),
Air Force (2008)
Military service age and obligation:
18-30 years of age for voluntary military
service; no conscription (2007)
Manpower available for military
service:
males age 16-49: 1,106,879
females age 16-49: 1,122,595 (2008 est.)
Manpower fit for military service:
males age 16-49: 934,828
females age 16-49: 948,327 (2008 est.)
Military expenditures— percent of
GDP: 3.1% (2005 est.)','7cabe31540015224c14c6713129b2608e08ba41cc9ed12184c9642c0f22204c7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b89d8c87acb61a0079420b39bb44befb5fda283ee9d00240e51bc5743fa456',2009,'LR','Liberia','military-and-security',743,'Military branches: Lesotho Defense
Force (LDF): Army (includes Air Wing)
(2008)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service: males age 16-49: 525,203
females age 16-49: 522,485 (2008 est.)
Manpower fit for military service:
males age 16-49: 262,101
females age 16-49: 238,350 (2008 est.)
Military expenditures— percent of
GDP: 2.6% (2006)
Military — note: Lesotho’s declared
policy is maintenance of its independent
sovereignty and preservation of internal
security; in practice, external security is
guaranteed by South Africa; restruc-
turing of the Lesotho Defense Force
(LDF) and Ministry of Defense and
Public Service over the past five years
has focused on subordinating the defense
apparatus to civilian control and
restoring the LDF’s cohesion; the restruc-
turing has considerably improved capa¬
bilities and professionalism, but the LDF
is disproportionately large for a small,
poor country; the government has out¬
lined a reduction to a planned 1,500-
man strength, but these plans have met
with vociferous resistance from the polit¬
ical opposition and from inside the LDF
(2008)','4fc1e71412183016a2d19f6f219ccc86b4e08d404c628aa6f31cc617761f4e29','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b57fb97915860bb5c0d776e732be9a22cc1489255a1db107608c4eee0b9845',2009,'LT','Lithuania','military-and-security',764,'Military branches: Ground Forces,
Naval Force, Lithuanian Military Air
Forces, National Defense Volunteer
Forces (2005)
Military service age and obligation:
19-45 years of age for compulsory mili¬
tary service; 18 years of age for volun¬
teers; 12-month conscript service obliga¬
tion (2006)
Manpower available for military
Service: males age 16-49: 915,187
females age 16-49: 906,097 (2008 est.)
Manpower fit for military service:
males age 16-49: 678,434
females age 2 6 — 49 : 749,483 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 25,907
females age 16-49: 24,735 (2008 est.)
Military expenditures — percent of
GDP: 1.2% (2006; 1.23% 2007 est.)','67ff3c0b20fce725afbef08d44b78f31896d5e84dd51a83652a58c8181a7b5b8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30258aced4eb21089df950ccc45960ffc36da11a44a4a86e54040405e5ac70a2',2009,'MG','Madagascar','military-and-security',781,'Military branches: People’s Armed
Forces: Intervention Force,
Development Force, and Aeronaval
Force (navy and air); National
Gendarmerie
Military service age and obligation:
18-50 years of age for compulsory mili¬
tary service; 18-month conscript service
obligation (either military or equivalent
civil service) (2006)
Manpower available for military
service:
males age 16-49: 4,443,341
females age 16^9: 4,441,124 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,034,600
females age i 6—49: 3,271,732 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 230,088
females age 16^\\9: 229,932 (2008 est.)
Military expenditures — percent of
GDP: 1% (2006)','7583f03496607ac9e0ae6a2a3bae2e1c51434102c36fbeb0354e9647ca485af7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fae5309d3abd3efee072726d8461f24e30ecdee28733ed6f87b8e8d54aafcaa',2009,'MY','Malaysia','military-and-security',789,'Military branches: Malawi Armed
Forces: Army (includes Air Wing and
Naval Detachment) (2007)
Military service age and obligation: 18
years of age for voluntary military
service; standard obligation is 2 years of
active duty and 5 years of reserve service
(2007)
Manpower available for military
service:
males age 16-49: 3,050,444 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,676,117 (2008 est.)
Military expenditures— percent of
GDP: 1.3% (2006)','c00af2d61b68c739785d7df5c82a69ab1797a450f51bf9c2957da1fa0bce679f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e9fea200b36613109dc510367b26f89f7a8977181ea3a5824cdf5eae74302e7',2009,'MV','Maldives','military-and-security',796,'Military branches: Malaysian Armed
Forces (Angkatan Tentera Malaysia,
ATM): Malaysian Army (Tentera Darat
Malaysia), Royal Malaysian Navy
(Tentera Laut Diraja Malaysia, TLDM),
Royal Malaysian Air Force (Tentera
Udara Diraja Malaysia, TUDM) (2008)
Military service age and obligation: 18
years of age for voluntary military service
(2005)
Manpower available for military
service: males age 16-49: 6,440,338
females age 16—49: 6,280,826 (2008 est.)
Manpower fit for military service:
males age 16—49: 5,374,006
females age 16—49: 5,316,865 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 260,725
females age 16—49: 247,309 (2008 est.)
Military expenditures— percent of
GDP: 2.03% (2005 est.)','499da1634ad458d7365dfcc4949099e0e6b193f88b5426298c5639e3b39a034b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd891e95dadd35e420ac033d0f6d1dd8e4daf6a0efb74d2fdf84ae002c5ec78b',2009,'ML','Mali','military-and-security',809,'Military branches: Mahan Armed
Forces: Army, Republic of Mali Air Force
(Force Aerienne de la Republique du
Mali, FARM), National Guard (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 2 years (2008)
Manpower available for military
service:
males age 16—49: 2,603,700
females age 16-49: 2,441,776 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,594,184
females age 16-49: 1,529,871 (2008 est.)
Military expenditures— percent of
GDP: 1.9% (2006)','f04351aeed5b64d632e4ad422f3f2cc83f377ac6e9a2e2791c4bc0b587842391','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e13d7019bc8a27bc43a8cc1a99716aa34edaf232f83193a72fc677326a638eca',2009,'MH','Marshall Islands','military-and-security',815,'Military branches: Armed Forces of
Malta (AFM; includes air and maritime
elements) (2007)
Military service age and obligation: 17
years 6 months of age for voluntary mili¬
tary service; no conscription (2008)
Manpower available for military
service:
males age i 6 — 49: 96,309
females age 16-49: 92,242 (2008 est.)
Manpower fit for military service:
males age 16-49: 80,227
females age 16-49: 76,623 (2008 est.)
Military expenditures— percent of
GDP: 0.7% (2006 est.)
Military branches: no regular military
forces; under the 1983 Compact of Free
Association, the US has full authority
and responsibility for security and
defense of the Marshall Islands; Marshall
Islands Police (2008)
Manpower available for military
service:
males age 16—49: 15,708 (2008 est.)
Manpower fit for military service:
males age 16—49: 12,864 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 512 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of the US','97713c8ad16352954e01ba6520393e4cea518078e763ab32d61e0d92ac0fd507','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edb12c358dfd086a18e4f76ea4ce96a96b7786f85f02b8eb2e7ee341268327ec',2009,'MR','Mauritania','military-and-security',825,'Military branches: Mauritanian Armed
Forces: Army, Mauritanian Navy
(Marine Mauritanienne; includes naval
infantry), Air Force (Force Aerienne
Islamique de Mauritanie, FAIM) (2008)
Military service age and obligation: 18
years of age (est.); conscript service obli¬
gation — 2 years; majority of servicemen
believed to be volunteers; service in Air
Force and Navy is voluntary (2006)
Manpower available for military
service:
males age 16-49: 740,675
females age 16-49: 744,709 (2008 est.)
Manpower fit for military service:
males age 16-49: 463,305
females age 16-49: 484,777 (2008 est.)
Military expenditures — percent of
GDP: 5.5% (2006)','8057c4708cb59cdd90c7b1ba61b9de89e870e89b0bc997b0a691b641e0d19dd2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e48c3e621008f10a33aaf5a78c1b28c1c66ebabc167eb9b65f4d67e1224d8d2f',2009,'MX','Mexico','military-and-security',835,'Military— note: defense is the responsi¬
bility of France; a small contingent of
French forces is stationed on the island
Military branches: Secretariat of
National Defense (Secretaria de Defensa
Nacional, Sedena): Army (Ejercito,
includes Mexican Air Force (Fuerza
Aerea Mexicana, FAM)); Secretariat of
the Navy (Secretaria de Marina, Semar):
Mexican Navy (Armada de Mexico,
ARM, includes Naval Air Force (FAN)
and naval infantry) (2008)
Military service age and obligation: 18
years of age for compulsory military
service, conscript service obligation — 12
months; 16 years of age with consent for
voluntary enlistment; conscripts serve
only in the Army; Navy and Air Force
service is all voluntary; women are eli¬
gible for voluntary military service
(2007)
Manpower available for military
service: males age 16-49: 27,774,688
females age 16-49: 29,376,791 (2008 est.)','8b9411a13fc6aa27c8c6dd17c32c031bc20e685d0b80333c102d49c0a4177ee5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3128b418300a4fd67e2fae1c7bc313d11fdad1c9a263c2d9fd23bd3302839e2d',2009,'FM','Micronesia, Federated States of','military-and-security',838,'Manpower fit for military service:
males age J 6 — 49 : 22,188,284
females age 16—49: 24,884,614 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-4 9: 1,110,544
females age 16-49: 1,073,223 (2008 est.)
Military expenditures— percent of
GDP: 0.5% (2006 est.)
Military branches: no regular military
forces
Manpower available for military
service:
males age 16—49: 26,686 (2008 est.)
Manpower fit for military service:
males age 16—49: 21,748 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 1,310 (2008 est.)
Military— note: defense is the responsi¬
bility of the US','50e43df841c462a31438ed263e649586d69681766da71551d7b56c065eab9c8a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88c631c9a80cdc473cc69b15fef84598f26515b3b2e7eaf6ecaa0bd12ebcb77c',2009,'RO','Romania','military-and-security',846,'Military branches: National Army:
Ground Forces, Rapid Reaction Forces,
Air and Air Defense Forces (2008)
Military service age and obligation: 18
years of age for compulsory military
service; 12-month service obligation
(2006)
Manpower available for military
service: males age i 6 — 49; 1,161,924
females age i 6 — 49: 1,187,771 (2008 est.)
Manpower fit for military service:
males age 16-49: 877,070
females age 16-49: 994,091 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 33,053
females age 16-49: 31,712 (2008 est.)
Military expenditures— percent of
GDP: 0.4% (2005 est.)
Military branches: Land Forces, Naval
Forces, Romanian Air Force (Fortele
Aeriene Romane, FAR), Special
Operations (2008)
Military service age and obligation: 18
years of age for voluntary military
service; conscription officially ended
October 2006; all military inductees
(including women) contract for an ini-
tial 5 -year term of service; subsequent
voluntary service contracts are for suc¬
cessive 3 -year terms until the age of 36
(2006)
Manpower available for military
service:
males age 16-49: 5,682,299
females age 16-4 9: 5,557,098 (2008 est.)
Manpower fit for military service:
males age 16—49: 4,572,017
females age 16-49: 4,644,474 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—4 9: 127,706
females age 16—49: 121,852 (2008 est.)
Military expenditures— percent of
GDP: 1.9% (2007 est.)
Disputes— international: the ICJ gave
Ukraine until December 2006 to reply,
and Romania until June 2007 to issue a
rejoinder, in their dispute submitted in
2004 over Ukrainian-administered
Zmiyinyy/Serpilor (Snake) Island and
Black Sea maritime boundary delimita¬
tion; Romania also opposes Ukraine’s
reopening of a navigation canal from the
Danube border through Ukraine to the
Black Sea
Illicit drugs: major transshipment point
for Southwest Asian heroin transiting
the Balkan route and small amounts of
Latin American cocaine bound for
Western Europe; although not a signifi¬
cant financial center, role as a narcotics
conduit leaves it vulnerable to laun¬
dering, which occurs via the banking
system, currency exchange houses, and
casinos
RUSSIA
M fic''nc &ci
Noni''sk
★MOSCOW
/ *
Novgorod Vs
''Vorens* k™, aR
•P6rm’
Saratov ,
* . Rostov *
Krasnodar
Wline*
Khabarovsl
•Omsk
Novosibirsk
Military branches: Ground Forces (SV),
Navy (VMF), Air Forces (Voyenno-
Vozdushniye Sily, VVS); Airborne
Troops (VDV), Strategic Rocket Troops
(RVSN), and Space Troops (KV) are
independent “combat arms,” not subor¬
dinate to any of the three branches;
Russian Ground Forces include the fol¬
lowing combat arms: motorized-rifle
troops, tank troops, missile and artillery
troops, air defense of ground troops
(2007)
Military service age and obligation:
18-27 years of age for compulsory or vol¬
untary military service; males are regis¬
tered for the draft at 17 years of age;
service obligation — 1 year; reserve obli¬
gation to age 50; foreign citizens and
dual-nationality Russians are precluded
from contract military service (2008)
Manpower available for military
service:
males age 1 6 — 49 : 36,219,908
females age 16—49: 37,019,853 (2008
est.)
Manpower fit for military service:
males age 16-49: 21,488,878
females age 16—49: 28,760,976 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 1 6—49 : 82 1 , 1 03
females age 16-49: 781,570 (2008 est.)
Military expenditures— percent of
GDP: 3.9% (2005)','f2712cc2445111b1d280043ae11f971c534745153099a47a7e6c7e16a0faaf8b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbcb457975cc2e8daa611c04846d8e223d091175e85cdd03fab9e5080d0c465e',2009,'MC','Monaco','military-and-security',853,'Military branches: no regular military
forces; the Palace Guard performs cere¬
monial duties
Manpower available for military
service:
males age 16-49: 6,687 (2008 est.)
Manpower fit for military service:
males age 16^\\9: 5,376 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 191 (2008 est.)
Military — note: defense is the responsi¬
bility of France','1ae5d794958847f8cebd7337230ecd2176bcab1981567b80dc4c2863b11ec8d3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bbaad47af7a9485bcd93769c2438ee6cf432c308a5c061aef679e5b3762d4b4',2009,'ME','Montenegro','military-and-security',862,'Military branches: Mongolian Armed
Forces: Mongolian Army, Mongolian Air
Force; there is no navy (2008)
Military service age and obligation:
18-25 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 12 months in land or air defense
forces or police; a small portion of
Mongolian land forces (2.5 percent) is
comprised of contract soldiers; women
cannot be deployed overseas for military
operations (2006)
Manpower available for military
service:
males age 16-49: 865,425
females age 16-49: 860,669 (2008 est.)
Manpower fit for military service:
males age 16-49: 696,652
females age 16-49: 731,480 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 29,990
females age 16-49: 29,256 (2008 est.)
Military expenditures— percent of
GDP: 1.4% (2006)
Military service age and obligation:
compulsory national military service
abolished August 2006
Military — note: Montenegrin plans call
for the establishment of a fully profes¬
sional armed forces','cfeca33d562a85d98e7810461a2c8a7d762155e8b007b7f4c5e6129d3e039f5e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85496796d18beef4780a77f13ab53943b05db673894f2b9660a1bdf0dc64c878',2009,'MZ','Mozambique','military-and-security',880,'Military branches: Royal Armed Forces
(Forces Armees Royales, FAR): Royal
Moroccan Army (includes Air Defense),
Navy (includes Marines), Royal
Moroccan Air Force (A1 Quwwat al
Jawyiya al Malakiya Marakishiya; Force
Aerienne Royale Marocaine) (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 18 months (2004)
Manpower available for military
service:
males age 16-49: 9,152,580
females age 16-49: 9,080,830 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,627,988
females age 16-49: 7,754,873 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 355,479
females age 16-49: 343,016 (2008 est.)
Military expenditures— percent of
GDP: 5% (2003 est.)
Military branches: Mozambique Armed
Defense Forces (FADM): Mozambique
Army, Mozambique Navy (Marinha
Mocambique, MM), Mozambique Air
Force (Forca Aerea de Mocambique,
FAM) (2006)
Military service age and obligation:
18-30 years of age for compulsory mili¬
tary service; 2-year service obligation
(2006)
Manpower available for military
service: males age 16-49: 4,545,975
(2008 est.)
Manpower fit for military service:
males age 16-49: 2,287,526 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 257,261 (2008 est.)
Military expenditures— percent of
GDP: 0.8% (2006)','aa3c18146cf7ac722b459a63fc884b80ed73ec1a94f0cce70dd84d87dfc1b4f6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2082fe96920f0b308d228beb4b6becb1cdcccbbd2b8de184b91f701809ad15f',2009,'NR','Nauru','military-and-security',895,'Military branches: no regular military
forces; Nauru Police Force (2008)
Manpower available for military
service:
males age 16-49: 3,470 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: Nauru maintains no
defense forces; under an informal agree¬
ment, defense is the responsibility of','f77f8d3cddab5500e3dbbb27d451815033e3db00e796ed05eb6a9b4decb47bc3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e97aa6f0be4b26302b58bd7eb7945a85c562ef77587783c0137f59632f9f3bcc',2009,'NL','Netherlands','military-and-security',907,'Military branches: Royal Netherlands
Army, Royal Netherlands Navy
(includes Naval Air Service and Marine
Corps), Royal Netherlands Air Force
(Koninklijke Luchtmacht, KLu), Royal
Military Police (2008)
Military service age and obligation: 20
years of age for an all-volunteer force
(2004)
Manpower available for military
service: males age 16-4 9: 3,950,825
females age 16-49: 3,850,800 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,233,773
females age 16^19: 3,150,790 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 105,735
females age 16^19: 100,747 (2008 est.)
Military expenditures— percent of
GDP: 1.6% (2005 est.)','157167b57f75d278315e063b0cdf43e3bd790ffeed36ad023e395d8ed45464ec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('650e4e8fbd3c45fbc009ee5efe9f47ab915748bde7503bd052b434e1d0167685',2009,'NZ','New Zealand','military-and-security',919,'Military branches: no regular indigenous
military forces; French Armed Forces
(includes Army, Navy, Air Force,
Gendarmerie); Police Force
Manpower available for military
service:
males age 16—49: 57,738 (2008 est.)
Manpower fit for military service:
males age 16—49: 47,342 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 2,202 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of France
Military branches: no regular indigenous
military forces; Police Force
Military — note: defense is the responsi¬
bility of New Zealand','2d308826fefd64abae3e88f9850e83120bcca8627ff0cba9ce7e8a09a037b9ae','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54d8710bb231c19fde0282ba4ba5e71d6c1c70b6db586c4c3ad11ff0c00923cc',2009,'TK','Tokelau','military-and-security',926,'Military branches: New Zealand
Defense Force (NZDF): New Zealand
Army, Royal New Zealand Navy, Royal
New Zealand Air Force (2008)
Military service age and obligation: 17
years of age for voluntary military
service; soldiers cannot be deployed until
the age of 18; no conscription (2008)
Manpower available for military
service:
males age 16-49: 1,009,298
females age 16-49: 997,134 (2008 est.)
Manpower fit for military service:
males age 16-49: 833,073
females age 16-49: 822,807 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 31,834
females age 16-49: 30,243 (2008 est.)
Military expenditures— percent of
GDP: 1% (2005 est.)','b101540da14cf077fc487dfbb259365f3b05bd15e1958d663361d2e5b653c268','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4354a905e198128d97b027ccf3867d7fd9f6ba730cf1b2487c7c43736881f274',2009,'NE','Niger','military-and-security',932,'Military branches: National Army of
Nicaragua (ENN; includes Navy, Air
Force) (2008)
Military service age and obligation: 17
years of age for voluntary military
service; tour of duty 18-36 months
(2008)
Manpower available for military
service:
males age 1 6 — 49: 1,513,312
females age 16-49: 1,507,999 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,235,400
females age 16—49: 1,302,318 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 72,689
females age 16-49: 70,452 (2008 est.)
Military expenditures— percent of
GDP: 0.6% (2006)
Military branches: Nigerien Armed
Forces (Forces Armees Nigeriennes,
FAN): Army, Niger Air Force (2008)
Military service age and obligation: 18
years of age for compulsory military
service; 2-year conscript service obliga¬
tion (2006)
Manpower available for military
service:
males age 16-49: 2,871,868
females age 16—49: 2,696,966 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,665,108
females age 16-49: 1,548,965 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 150,728
females age 16—49: 143,379 (2008 est.)
Military expenditures— percent of
GDP: 1.3% (2006)','da774ec549d1ada882482dbad5a1ec8fab6548962b74d5ae8b42cdfe0d5c524c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ac221015ec2c0d518c715785fb49452a55d5f0f1ba333cfaff5aba3516b38ec',2009,'NO','Norway','military-and-security',959,'Military branches: Norwegian Army
(Haeren), Royal Norwegian Navy
(Kongelige Norske Sjoeforsvaret, RNoN;
includes Coastal Rangers and Coast
Guard (Kystvakt)), Royal Norwegian
Air Force (Kongelige Norske
Luftforsvaret, RNoAF), Home Guard
(Heimevemet, HV) (2007)
Military service age and obligation:
18-44 years of age for male compulsory
military service; 16 years of age in
wartime; 17 years of age for male volun¬
teers; 18 years of age for women; 12-
month service obligation, in practice
shortened to 8 to 9 months; although all
males between ages of 18 and 44 are
liable for service, in practice they are
seldom called to duty after age 30;
reserve obligation to age 35—60; 16 years
of age for volunteers to the Home Guard,
who serve 6-month duty tours (2006)
Manpower available for military
service:
males age 1 6-49 : 1,078,181
females age 16-49: 1,046,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 888,101
females age 16—49: 862,159 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 32,185
females age 16—49: 30,683 (2008 est.)
Military expenditures— percent of
GDP: 1.9% (2005 est.)','d742b69842e1a76bc02a9e033ce7f314c870c3049b9dc781c3b3579cf1e1c1f4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79d6e2a041910dcb3dabda0148573ae81521ee586048cc509cba9deb8ec78a24',2009,'OM','Oman','military-and-security',965,'Military branches: Sultan’s Armed
Forces (SAF): Royal Army of Oman,
Royal Navy of Oman, Royal Air Force of
Oman (2008)
Military service age and obligation:
18-30 years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 802,455
females age 16-49: 626,841 (2008 est.)
Manpower fit for military service:
males age / 6 — 49: 663,881
females age 16-49: 543,410 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 34,238
females age 16-4 9: 33,139 (2008 est.)
Military expenditures— percent of
GDP: 11.4% (2005 est.)','50344978af1a3d280a0283fb1a179978b20a152d19dab8bcd49f5d29e585f9f3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d456c6f7e9d30ab81c7446a41735d56f09f40238134bdd8e14b9c68efec5bba7',2009,'PW','Palau','military-and-security',977,'Military branches: no regular military
forces; Palau National Police (2008)
Manpower available for military
service:
males age 16—49: 5,973 (2008 est.)
Manpower fit for military service:
males age 16—49: 4,397 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 179 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of the US; under a Compact of Free
Association between Palau and the US,
the US military is granted access to the
islands for 50 years, but it has not sta¬
tioned any military forces there (2008)','19150c632d323a6d91347980e05e2b6c704eaa831f12f24ae5598c8080365efb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b167d4eb699d1a2b5a5a5b2fa545ffb658fd05338b9c84d2332780468fc3709d',2009,'PG','Papua New Guinea','military-and-security',987,'Military branches: Papua New Guinea
Defense Force (PNGDF; includes
Maritime Operations Element, Air
Operations Element) (2008)
Military service age and obligation: 16
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service: males age 16-49: 1,481,417
females age 16-49: 1,385,040 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,080,466
females age 16-49: 1,092,040 (2008 est.)
Military expenditures — percent of
GDP: 1.4% (2005 est.)','09b343dd1c60c44d0dd06a7f562cc4607e70f755c96914b2f6866c4b1a35897d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36073e777eac1d9bdaa84f717dd64559eefdac19eeb8e2ead7d72c7d76d08c49',2009,'PH','Philippines','military-and-security',992,'Military — note: occupied by China
Military expenditures— percent of
GDP: 1.5% (2006)
Military branches: Armed Forces of the
Philippines (AFP): Army, Navy
(includes Marine Corps and Coast
Guard), Air Force (2008)
518
PITCAIRN ISLANDS
Military service age and obligation:
18-25 years of age (officers 21-29) for
compulsory and voluntary military
service; applicants must be single male or
female Philippine citizens (2007)
Manpower available for military
service:
nudes age 16-49: 23,547,252
females age 16-49: 23,177,487 (2008
est.)
Manpower fit for military service:
males age 16-49: 18,232,050
females age 16-49: 19,827,538 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 1,003,836
females age 16-49: 968,845 (2008 est.)
Military expenditures— percent of
6DF: 0.9% (2005 est.)
Military — note: defense is the responsi¬
bility of the UK','f858a9397bb26f20995e20766f0dcd87633b1e82627b247df1631a008cf87669','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cafd57d0a44b9b92dae2151c84d89a356d0c01673066d02b133ced1c1eb2471c',2009,'PL','Poland','military-and-security',1006,'Military branches: Polish Armed Forces:
Land Forces (includes Navy (Marynarka
Wojenna, MW)), Polish Air Force (Sily
Powietrzne Rzeczypospolitej Polskiej,
SPRP) (2008)
Military service age and obligation: 17
years of age for male compulsory military
service after January 1st of the year of
18th birthday; 17 years of age for volun¬
tary military service; conscript service
obligation shortened from 12 to 9
months in 2005; by 2008, plans call for at
least 60% of military personnel to be vol¬
unteers; only soldiers who have com¬
pleted their conscript service are allowed
to volunteer for professional service; as of
April 2004, women are only allowed to
serve as officers and noncommissioned
officers (2006)
Manpower available for military
service:
males age 16-49: 9,741,508
females age 16-49: 9,514,843 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,937,840
females age 16-49: 7,949,677 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 257,605
females age 16-49: 245,832 (2008 est.)
Military expenditures— percent of
GDP: 1.71% (2005 est.)','558ac927e5533e7a2c1d0ab9ab9e3e2c0749b4ccf66a155d8b8345a9764391e0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36cafec538f3706f3852f74fc9391b248335b428658f875050a0607265a109b4',2009,'PR','Puerto Rico','military-and-security',1012,'Military branches: Portuguese Army
(Exercito Portugues), Portuguese Navy
(Marinha Portuguesa; includes Marine
Corps), Portuguese Air Force (Forca
Aerea Portuguesa, FAP) (2008)
Military service age and obligation: 18
years of age for voluntary military
service; compulsory military service
ended in 2004; women serve in the
armed forces, on naval ships since 1993,
but are prohibited from serving in some
combatant specialties (2005)
Manpower available for military
service:
males age 1 6-A9 : 2,573,913
females age 16—49: 2,498,262 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,099,647
females age 16-49: 2,060,559 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 64,910
females age 16-49: 58,599 (2008 est.)
Military expenditures— percent of
GDP: 2.3% (2005 est.)
Military branches: no regular indigenous
military forces; paramilitary National
Guard, Police Force
Military — note: defense is the responsi¬
bility of the US','bbf8f5f4b03422dc7165f4d6f5270f0b058b2b8cf67e9b5d4b93ca7e3522292f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1e0abb41fe2a5bc1903e803000e1e655584b55f607876fb31c0fffccb37dbc0',2009,'VC','Saint Vincent and the Grenadines','military-and-security',1059,'Military branches: no regular military
forces; Royal Saint Vincent and the
Grenadines Police Force, Coast Guard
(2007)
Manpower available for military
service:
males age 16-49: 34,373 (2008 est.)
Manpower fit for military service:
males age 16-4 9: 28,518 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 1,224 (2008 est.)
Military expenditures— percent of
GDP: NA
Disputes — international: joins other
Caribbean states to counter Venezuela’s
claim that Aves Island sustains human
habitation, a criterion under UNCLOS,
which permits Venezuela to extend its
EEZ/continental shelf over a large por¬
tion of the eastern Caribbean Sea
Illicit drugs: transshipment point for
South American drugs destined for the
US and Europe; small-scale cannabis
cultivation
559
Background: New Zealand occupied the
German protectorate of Western Samoa
at the outbreak of World War I in 1914.
It continued to administer the islands as
a mandate and then as a trust territory
until 1962, when the islands became the
first Polynesian nation to reestablish
independence in the 20th century. The
country dropped the “Western” from its
name in 1997.','9b582996df92003e4a9546396e85594ff6b9ec81d1669f813b439273cb72963a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce6fb015f69915c04b86d0de411ed0bd3c39d0bc3f178897d7276c43b51d7bd7',2009,'WS','Samoa','military-and-security',1065,'Military branches: no regular military
forces; Samoa Police Force (2008)
Manpower available for military
service:
males age 16-49: 53,417 (2008 est.)
Manpower fit for military service:
males age 16-49: 42,359 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 2,571 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: Samoa has no formal
defense structure or regular armed forces;
informal defense ties exist with NZ,
which is required to consider any
Samoan request for assistance under the
1962 Treaty of Friendship','669c88be5a884ea47f9c69983f4705c6ef4a21e5f8ae25f4918e3e18071177da','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f3f45103101c2f17b5a888fda581e6b476dcfbd2e73dc7148e39cc2a39ee6b4',2009,'SM','San Marino','military-and-security',1071,'Military branches: no regular military
forces; Voluntary Military Force (Corpi
Militari Voluntar) performs ceremonial
duties and limited police functions
(2006)
Military service age and obligation:
16-55 for voluntary service in Voluntary
Military Force (2006)
Manpower available for military
service:
males age 16-49: 6,613 (2008 est.)
Manpower fit for military service:
males age 16^19: 5,345 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 156 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: defense is the responsi¬
bility of Italy','550868f3f40db9faf62f18d2fa3e11e3f055a1d3363bdb058c36108351f0fd6a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac1345e4bb886a20ca9814a87be255fee8e43e91b81f35a185d79d8fcb86e4fe',2009,'SG','Singapore','military-and-security',1105,'Military branches: Republic of Sierra
Leone Armed Forces (RSLAF): Army
(includes Navy (Maritime Wing), Air
Wing) (2008)
Military service age and obligation: 17
years 6 months of age for voluntary mili¬
tary service (younger with parental con¬
sent); no conscription (2008)
Manpower available for military
service:
males age 16—49: 1,315,561 (2008 est.)
Manpower fit for military service:
males age 16-49: 671,418 (2008 est.)
Military expenditures— percent of
GDP: 2.3% (2006)
Military branches: Singapore Armed
Forces: Army, Navy, Air Force (includes
Air Defense) (2008)
Military service age and obligation: 18
years of age for male compulsory military
service; 16 years of age for volunteers; 2-
year conscript service obligation, with a
reserve obligation to age 40 (enlisted) or
age 50 (officers) (2008)
Manpower available for military
service:
males age 16-49: 1,277,862 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,038,603 (2008 est.)
Military expenditures— percent of
GDP: 4.9% (2005 est.)','5629517718f4e3332604438751655686981ae6d1b0c4696d31ccb055da0e7a3b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9afc0a3629f384c4c2b2514280d5d84f8028092750f294af8398cb868a1974eb',2009,'SK','Slovakia','military-and-security',1117,'Military branches: Armed Forces of the
Slovak Republic (Ozbrojene Sily
Slovenskej Republiky): Land Forces
(Pozemne Sily), Air Forces (Vzdusne
Sily) (2005)
Military service age and obligation:
17-30 years of age for voluntary military
service; conscription abolished in 2006;
women are eligible to serve (2007)
Manpower available for military
service:
males age 16-49: 1,420,966
females age 16-49: 1,386,259 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,166,833
females age 16—49: 1,156,874 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 38,183
females age 16^9: 36,388 (2008 est.)
Military expenditures — percent of
GDP: 1.87% (2005 est.)
Disputes — international: bilateral gov¬
ernment, legal, technical and economic
working group negotiations continued in
2006 between Slovakia and Hungary
over Hungary’s completion of its portion
of the Gabcikovo-Nagymaros hydroelec¬
tric dam project along the Danube; as a
member state that forms part of the EU’s
external border, Slovakia has imple¬
mented the strict Schengen border rules
Illicit drugs: transshipment point for
Southwest Asian heroin bound for Western
Europe; producer of synthetic drugs for
regional market; consumer of ecstasy
587','809639ed999b21284706e8b0b4366f3e32cd8284664cbd3ed6a0ce553bedfd1d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a75edb6c2581d07213a0bff87b11ad7e399f3289011f361803e53331eea6539',2009,'SO','Somalia','military-and-security',1129,'_ _
Military branches: no regular military
forces; Solomon Islands Police Force
(2008)
Manpower available for military
service:
males age 16—49: 141,051 (2008 est.)
Manpower fit for military service:
males age 16—49: 116,891 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 6,924 (2008 est.)
Military expenditures— percent of
GDP: 3% (2006)
Military branches: no national-level
armed forces (2008)
Manpower available for military
service:
males age 16-49: 2,181,050
females age 16-49: 2,125,558 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,274,783
females age 16^\\9: 1,317,991 (2008 est.)
Military expenditures — percent of
GDP: 0.9% (2005 est.)','f56e7d83c50272e1b094320c1e4c3f70648b90444e663a99b36d36327ce39eea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8fca439e98800e44ebb5c6e54303ad46601d19b7118b8f1736c4d0b5ff5c26f',2009,'ES','Spain','military-and-security',1148,'Military branches: Spanish Armed
Forces: Army (Ejercito de Tierra),
Spanish Navy (Armada Espanola, AE;
includes Marine Corps), Spanish Air
Force (Ejercito del Aire Espanola, EdA)
(2007)
Military service age and obligation: 20
years of age (2004)
Manpower available for military
service:
males age 16-49: 10,033,069
females age 16—49: 9,764,937 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,228,426
females age 16—49: 7,990,678 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-4 9: 203,650
females age 16—49: 191,352 (2008 est.)
Military expenditures— percent of
6DP: 1.2% (2005 est.)','e61dc32d852abd0ea709885fb3d542320ff1d73d100ff19291b9299e7add362d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dea51ac5f531f453d1674a4ece96b064dea1aa39e5566bc78889f62dbdc8879b',2009,'LK','Sri Lanka','military-and-security',1155,'Military branches: Sri Lanka Army, Sri
Lanka Navy, Sri Lanka Air Force (2008)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military
service:
males age 16-49: 5,458,720
females age 16-49: 5,594,006 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,477,437
females age 16-4 9: 4,683,716 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 174,065
females age 16-49: 168,593 (2008 est.)
Military expenditures— percent of
GDP: 2.6% (2006)','2fcc851c70c5f8ecaaf1ca6ea3dd53476904c1b2cf0c7f06bfb91325b94d81ab','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9572d67f253f1886a52bca6f9de97f93f3d104fa1b30c84032cd34f2fcb54abb',2009,'SR','Suriname','military-and-security',1166,'Military branches: National Army
(Nationaal Leger, NL; includes Naval
Wing, Air Wing) (2007)
Military service age and obligation: 18
years of age (est.); no conscription
Manpower available for military
service:
males age 16-49: 130,534
females age 16—49: 130,243 (2008 est.)
Manpower fit for military service:
males age 16—49: 105,770
females age 16-49: 109,666 (2008 est.)
Military expenditures— percent of
GDP: 0.6% (2006 est.)
Military branches: no regular military
forces
Military — note: Svalbard is a territory of
Norway, demilitarized by treaty on 9
February 1920','cd172426f0ee119bc35b43df57ab821c902ea4751de5616dfb4f52c1c83d5d50','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ecce1c06943ae226b2b4e3b9005da9fd8ba3f84f3e11c32037f711ace58059',2009,'CH','Switzerland','military-and-security',1175,'Military branches: Swiss Armed Forces:
Land Forces, Swiss Air Force (Schweizer
Luftwaffe) (2007)
Military service age and obligation: 19
years of age for male compulsory military
service; 18 years of age for voluntary
male and female military service; the
Swiss Constitution states that “every
Swiss male is obliged to do military
service”; every Swiss male has to serve at
least 260 days in the armed forces; con¬
scripts receive 18 weeks of mandatory
training, followed by seven 3 -week inter¬
mittent recalls for training during the
next 10 years (2008)
Manpower available for military
service:
males age 16-49: 1,852,580
females age 16-49: 1,807,667 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,513,984
females age 16-4 9: 1,478,761 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-4 9: 49,205
females age 16—49: 45,220 (2008 est.)
Military expenditures— percent of
GDP: 1% (2005 est.)
Military branches: Syrian Armed
Forces: Syrian Arab Army (includes
Syrian Arab Navy), Syrian Arab Air and
Air Defense Force (includes Air Defense
Command) (2008)
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 30
months (18 months in the Syrian Arab
Navy); women are not conscripted but
may volunteer to serve (2004)
Manpower available for military
service:
males age 1 6 — 49 : 5,251,875
females age 16—4 9: 4,966,367 (2008 est.)
Manpower fit for military service:
males age 16-4 9: 4,242,401
females age 16—49: 4,218,648 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 215,734
females age 16—49: 203,106 (2008 est.)
Military expenditures— percent of
GDP: 5.9% (2005 est.)','0bf5742c77e7d3368a88e02145245b301d6e38838a7df7549f65d501e69f7c81','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d84e28a50a04b80b2d2f84154a91b1d6535409ccc08a0c625d1f367bc13716cc',2009,'TJ','Tajikistan','military-and-security',1183,'Military branches: Ground Forces, Air
and Air Defense Forces, Mobile Force
(2008)
Military service age and obligation: 18
years of age for compulsory military
service; 2-year conscript service obliga¬
tion (2006)
Manpower available for military
service: males age 16—49: 1,897,356
females age 16-49: 1,911,594 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,391,287
females age 16-49: 1,561,826 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 84,137
females age 16-49: 81,777 (2008 est.)
Military expenditures— percent of
GDP: 3.9% (2005 est.)','b4ecd35ad1557da611c3b9d155a94c06ac5685d33f85a47b631312d71fe2c0ef','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85dc464a3e1b3e2feec1639c67032b91e87946088fe4a1f82286b4d21a974571',2009,'TL','Timor-Leste','military-and-security',1191,'Military branches: Royal Thai Army
(RTA), Royal Thai Navy (RTN,
includes Royal Thai Marine Corps),
Royal Thai Air Force (Knogtap Agard
Thai, RTAF) (2008)
Military service age and obligation: 21
years of age for compulsory military
service; 18 years of age for voluntary mil¬
itary service; males are registered at 18
years of age; 2 -year conscript service
obligation (2006)
Manpower available for military
service:
males age 16—49: 17,553,410
females age 16—4 9: 17,751,268 (2008
est.)
Manpower fit for military service:
males age 16-49: 12,968,674
females age 16—49: 14,058,779 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 531,315
females age 16-49: 511,288 (2008 est.)
Military expenditures— percent of
GDP: 1.8% (2005 est.)','894bd07a4694bc662c2b69928b5ff4ab985fdc840de4349cee2caf3b698f5101','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c71d60d0e8760f69115128dd8c05bfd9cb11d56e9322ffd4a3f1a76e88d50f48',2009,'ID','Indonesia','military-and-security',1196,'Military branches: Timor-Leste Defense
Force (Forcas de Defesa de Timor- L’este,
Falintil (FDTL)): Army, Navy (Armada)
(2008)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 284,903
females age 16-49: 272,212 (2008 est.)
Manpower fit for military service:
males age 16-4 9: 224,096
females age 16-49: 231,901 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16^\\9: 13,045
females age 16-49: 12,670 (2008 est.)
Military expenditures— percent of
GDP: NA','5fe05c5f660ce5cf7fcccb774d863c2427d27a7cd2f86d16214c283ddc0c0fd8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9f65475d6e7ca799f9f3cba648b4af0ce38963b36dc64c7db66025fe2b6667',2009,'TT','Trinidad and Tobago','military-and-security',1212,'Military branches: Tonga Defense
Services (TDS): Land Force (Royal
Guard), Naval Force (includes Royal
Marines, Air Wing) (2008)
Military service age and obligation: 18
years of age (est.); no conscription
(2008)
Manpower available for military
service:
males age 16-49: 32,053
females age 16-4 9: 30,981 (2008 est.)
Manpower fit for military service:
males age 16—49: 25,520
females age 16-49: 26,893 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 1,464
females age 16—49: 1,412 (2008 est.)
Military expenditures— percent of
GDP: 0.9% (2006 est.)','33d353153feca0fb64d2a904c82d771eb1ea01f160fcee8d606e790e0cf66539','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fedf43b669907ef97939169b749a8c3499c558f63cbb4277a553f73e8a31b8c',2009,'TM','Turkmenistan','military-and-security',1229,'Military branches: Turkish Armed
Forces (TSK): Turkish Land Forces (Turk
Kara Kuvvetleri, TKK), Turkish Naval
Forces (Turk Deniz Kuvvetleri, TDK;
includes naval air and naval infantry),
Turkish Air Force (Turk Hava
Kuvvetleri, THK) (2008)
Military service age and obligation: 20
years of age (2004)
Manpower available for military
service:
males age 16-49: 20,213,205
females age 16—49: 19,432,688 (2008
est.)
Manpower fit for military service:
males age 16-49: 17,011,635
females age 16-49: 16,433,364 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 660,452
females age 16-49: 638,527 (2008 est.)
Military expenditures— percent of
GDP: 5.3% (2005 est.)
Military — note: a “National Security
Policy Document” adopted in October
2005 increases the Turkish Armed Forces
(TSK) role in internal security, aug¬
menting the General Directorate of
Security and Gendarmerie General
Command (Jandarma); the TSK leader¬
ship continues to play a key role in poli¬
tics and considers itself guardian of
Turkey’s secular state; in April 2007, it
warned the ruling party about any pro-
Islamic appointments; despite on-going
negotiations on EU accession since
October 2005, progress has been limited
in establishing required civilian
supremacy over the military; primary
domestic threats are listed as fundamen¬
talism (with the definition in some dis¬
pute with the civilian government),
separatism (the Kurdish problem), and
the extreme left wing; Ankara strongly
opposed establishment of an autonomous
Kurdish region; an overhaul of the
Turkish Land Forces Command (TLFC)
taking place under the “Force 2014” pro¬
gram is to produce 20-30% smaller, more
highly trained forces characterized by
greater mobility and firepower and
capable of joint and combined opera¬
tions; the TLFC has taken on increasing
international peacekeeping responsibili¬
ties, and took charge of a NATO
International Security Assistance Force
(ISAF) command in Afghanistan in
April 2007; the Turkish Navy is a
regional naval power that wants to
develop the capability to project power
beyond Turkey’s coastal waters; the Navy
is heavily involved in NATO, multina¬
tional, and UN operations; its roles
include control of territorial waters and
security for sea lines of communications;
the Turkish Air Force adopted an
“Aerospace and Missile Defense
Concept” in 2002 and has initiated
project work on an integrated missile
defense system; Air Force priorities
include attaining a modern deployable,
survivable, and sustainable force struc¬
ture, and establishing a sustainable com¬
mand and control system (2008)
Military branches: Ground Forces,
Navy, Air and Air Defense Forces (2007)
Military service age and obligation:
18-30 years of age for compulsory mili¬
tary service; 2-year conscript service
obligation (2006)
Manpower available for military
service:
males age 16-49: 1,316,698
females age 16-49: 1,331,005 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,064,965
females age 16-49: 1,136,553 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 57,615
females age 16-49: 55,426 (2008 est.)
Military expenditures— percent of
GDP: 3.4% (2005 est.)','7a14bcb3e723b2719ff04064b86ac128dcc565a1d255a846fd2d3963095bf62b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc8c05b5ec96014b68a0bc11d37c4356e74824cad701e76b92b7ecbfe5e67d71',2009,'TV','Tuvalu','military-and-security',1249,'Military branches: no regular military
forces; Tuvalu Police Force (2008)
Military expenditures— percent of
GDP: NA','5fb4e3cbd3c0e1a17d73f3ed557cd8f254ffc4cb234d3d071a073c772e5e803d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e65490ab979648af4d7de3b463635fc5969a578cd519e7f1b854d14e837dcaf',2009,'UA','Ukraine','military-and-security',1259,'Military branches: Uganda Peoples
Defense Force (UPDF): Army (includes
Marine Unit), Air Force (2007)
Military service age and obligation:
18-26 years of age for compulsory and
voluntary military duty; 18-30 years of
age for professionals; 9-year service obli¬
gation; the government has stated that
recruitment below 18 years of age could
occur with proper consent and that “no
person under the apparent age of 13 years
shall be enrolled in the armed forces”
(2007)
Manpower available for military
service:
males age 16-4 9: 6,532,894
females age 16-49: 6,352,416 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,856,365
females age 16-49: 3,769,120 (2008 est.)
Military expenditures — percent of
GDP: 2.2% (2006)','bf80d0342b6d7b23f12c45c98e4483067586df42ed8d374f0e7872c0af26b01c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e934eaaa813a2581677946de08264129b8e3bdae2314006e8f2dc5317701400',2009,'AE','United Arab Emirates','military-and-security',1263,'Military branches: Ground Forces,
Naval Forces, Air Forces (Viyskovo-
Povitryani Syly), Air Defense Forces
(2002)
Military service age and obligation:
18-25 years of age for compulsory and
voluntary military service; conscript
service obligation — 18 months for Army
and Air Force, 24 months for Navy
(2004)
Manpower available for military
service: males age 16-A9: 11,457,562
females age 16-49: 11,767,357 (2008
est.)
Manpower fit for military service:
males age 16^\\9: 7,141,814
females age 16-A9: 9,428,876 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 288,605
females age 16—49: 276,324 (2008 est.)
Military expenditures— percent of
GDP: 1.4% (2005 est.)
V '' • '' TV v< r '' Y . TuT’','744c679f0aa03c2cccf32825321ec01de30b69f31f0a46c38d5628fd243cd319','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30f6d8858f16582126819abebf45f25b0d9be8b1eb3e27e3af1d1b01c8319e8b',2009,'GB','United Kingdom','military-and-security',1272,'Military branches: Army, Royal Navy
(includes Royal Marines), Royal Air
Force
Military service age and obligation:
16-33 years of age (officers 17-28) for
voluntary military service (with parental
consent under 18); women serve in mili¬
tary services, but are excluded from
ground combat positions and some naval
postings; must be citizen of the UK,
Commonwealth, or Republic of Ireland;
reservists serve a minimum of 3 years, to
age 45 or 55; 16 years of age for voluntary
military service by Nepalese citizens in
the Brigade of the Gurkhas; 16-34 years
of age for voluntary military service by
Papua New Guinean citizens (2008)
Manpower available for military
service: males age 16-49: 14,729,500
females age 16^9: 14,125,600 (2008
est.)
Manpower fit for military service:
males age J 6—49: 12,121,602
females age 16-49: 11,616,582 (2008
est.)
682','2938efb7c498fbdc8ff3f8616adb2706ccaa0e3149fbc1e9e22dabd11a89b588','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a98b491a50907acf3faf52623a580419731d168fa489848e40c82950b658936f',2009,'UY','Uruguay','military-and-security',1276,'Military— note: defense is the responsi¬
bility of the US
Military branches: Uruguayan Armed
Forces: Army, Navy (includes naval air
arm, Marines, Maritime Prefecture in
wartime), Air Force (Fuerza Aerea
Uruguaya, FAU) (2008)
Military service age and obligation: 18
years of age for voluntary and compulsory
military service; enlistment is voluntary
in peacetime, but the government has
the authority to conscript in emergencies
(2007)
Manpower available for military
service:
males age 16—49: 837,252
females age 16—4 9: 824,096 (2008 est.)
Manpower fit for military service:
males age 16-49: 703,955
females age 16-49: 690,296 (2008 est.)
Military expenditures— percent of
GDP: 1.6% (2006)','a15a3c2365ff0be2c13fffc628d606943ef08b4604be677ba2fd930d231db362','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b4eb12ffc4867d7c546e0123e0710b87bb2bc4648216c3f22dedd30dee1fe62',2009,'UZ','Uzbekistan','military-and-security',1288,'Military branches: Army, Air and Air
Defense Forces, National Guard
Military service age and obligation: 18
years of age for compulsory military
service; conscript service obligation — 12
months (2004)
Manpower available for military
service:
males age 16-49: 7,480,484
females age 16-49: 7,542,017 (2008 est.)
Manpower fit for military service:
males age 16—49: 5,684,540
females age 16—49: 6,432,976 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 1 6 — 49 : 3 1 1 ,668
females age 16—49: 301,994 (2008 est.)
Military expenditures— percent of
GDP: 2% (2005 est.)','44b99c41cd43763231b7335ab0a22172ed1d174ac46a1f01fa1afeb3429b5dcb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cbbd10f454fdeae4d3b55ae8fa88d79bd1a1f19aa1d8c3c5a6084626c040095',2009,'VU','Vanuatu','military-and-security',1291,'Military branches: no regular military
forces; Vanuatu Police Force (VPF),
Vanuatu Mobile Force (VMF; includes
Police Maritime Wing (PMW)) (2008)
Manpower available for military
service:
males age 16-49: 58,900 (2008 est.)
Manpower fit for military service:
males age 16-49: 40,577 (2008 est.)
Military expenditures — percent of
GDP: NA','d5c1630f2f3a72bef466b34930f6ed86a250429b6efdc055c53fc12d0e6cbebf','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e33beec0c5f1a0a1b8a54680a6193b07ccaaff40ed8c0d62c88b7349e3bbb431',2009,'NC','New Caledonia','military-and-security',1297,'Military — note: defense is the responsi¬
bility of France
Military expenditures— percent of
GDP: NA','f1d706f787aa465ee27b45a2ff87601c467ee17b1189573762539b3270bff345','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aa6d497cf913388a6d2f97c42c66326e46de1a65629896ff5e0bc0fd20e3cf3',2009,'YE','Yemen','military-and-security',1307,'Military branches: Army (includes
Republican Guard), Navy (includes
Marines), Yemen Air Force (A1 Quwwat
al Jawwiya al Jamahiriya al Yemeniya;
includes Air Defense Force) (2008)
Military service age and obligation:
voluntary military service program
authorized in 2001; 2-year service obliga¬
tion (2006)
Manpower available for military
service:
males age 16-49: 5,080,038
females age 16-49: 4,852,555 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,585,947
females age 16-49: 3,619,195 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 268,468
females age 16-49: 258,196 (2008 est.)
Military expenditures— percent of
GDP: 6.6% (2006)
Military— note: a Coast Guard was
established in 2002','c489fe72f6de07547a423548d3244b2de3a807fa341081791ffc78816584254f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('899b5f5859451778517695e173a3397c778bc70de02a083690d0106d4072e6df',2009,'ZM','Zambia','military-and-security',1314,'Military branches: Zambian National
Defense Force (ZNDF): Zambian Army,
Zambian Air Force, National Service
(2008)
Military service age and obligation: 18
years of age for voluntary military service
(16 years of age with parental consent);
no conscription (2008)
Manpower available for military
service: males age 16-4 9: 2,678,668
females age 16-49: 2,567,433 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,329,343
females age 16-49: 1,218,114 (2008 est.)
Military expenditures— percent of
GDP: 1.8% (2005 est.)','4e6d22c58594d98656d22c0639e3e4d8c9f5a841adcce651c06bb7b9a32a555d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0f0234c899209f63574cc4dfb2f35880c55fa2614848d7a015303815714b74c',2009,'ZW','Zimbabwe','military-and-security',1326,'Military branches: Zimbabwe Defense
Forces (ZDF): Zimbabwe National Army,
Air Force of Zimbabwe (AFZ),
Zimbabwe Republic Police (2005)
Military service age and obligation:
18-24 years of age for compulsory mili¬
tary service; women are eligible to serve
(2007)
Manpower available for military
service:
males age 16-49: 3,264,258
females age 16—49: 3,048,049 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,643,036
females age 16—49: 1,404,663 (2008 est.)
Military expenditures— percent of
GDP: 3.8% (2006)
Military branches: Army, Navy
(includes Marine Corps), Air Force,
Coast Guard Administration, Armed
Forces Reserve Command, Combined
Service Forces Command, Armed Forces
Police Command
Military service age and obligation:
19-35 years of age for male compulsory
military service; service obligation 16
months (to be shortened to 14 months as
of July 2007 and to 12 months in 2008);
women may enlist; women in Air Force
service are restricted to noncombat roles;
reserve obligation to age 30 (2007)
Manpower available for military
service:
males age i 6 — 4 9 : 6,283,134
females age 16-49: 6,098,599 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,112,737
females age 16-49: 5,036,346 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 164,883
females age 16-49: 152,085 (2008 est.)
Military expenditures— percent of
GDP: 2.2% (2006)
Military — note: the five-nation
Eurocorps — created in 1992 by France,
Germany, Belgium, Spain, and
Luxembourg — has deployed troops and
police on peacekeeping missions to
Bosnia-Herzegovina, Macedonia, and
the Democratic Republic of the Congo
and assumed command of the ISAF in
Afghanistan in August 2004; Eurocorps
directly commands the 5, 000-man
Franco-German Brigade, the
Multinational Command Support
Brigade, and EUFOR in Bosnia and
Herzegovina; in November 2004, the EU
Council of Ministers formally committed
to creating 13 1, 500-man battle groups
by the end of 2007, to respond to inter¬
national crises on a rotating basis; 22 of
the EU’s 25 nations have agreed to
supply troops; France, Italy, and the UK
formed the first of three battle groups in
2005; Norway, Sweden, Estonia, and
Finland established the Nordic Battle
Group effective 1 January 2008; nine
other groups are to be formed; a rapid-
reaction naval EU Maritime Task Group
was stood up in March 2007 (2007)','e00014c7a31aef570f012f3828cdb548a84b918932c3382d9964fe171014d79f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94439814a0070aeafcc95518897027456de23aadad1cebe75f6462cd74ad7952',2009,'','','military-and-security',8,'Military branches:
Military service age and obligation :
Manpower available for military service :
males age 16-49
females age 16-49
Manpower fit for military service:
males age 16-49
females age 16-49
Manpower reaching military age annually:
males
females
Military expenditures - percent of GDP:
Military - note:','512566e3b5c64d31ac1633f85fe2f7c4edece547c972ee13dddc33ad3895f651','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('706932170eb30d8891173a6c8fc7c4ab843a981c889ea3432aeb9bb7681ca0d8',2009,'ZW','Zimbabwe','military-and-security',15,'Military expenditures - percent of GDP:
Not all Country Comparisons include the same number of entries
because information for a particular field is not available for all
countries. In addition, not all data fields are suitable for
displaying as Country Comparisons, such as those containing textual
information. Textual information is more readily viewed by clicking
on the Field Listing icon next to the Data field title.
All of the Country Comparisons'' pages can be downloaded as
tab-delimited data files and can be opened in other applications
such as spreadsheets and databases. To save a Country Comparisons
page in a spreadsheet, first click on the ''Download Datafile'' choice
above the Country Comparisons page you selected; then, at the top of
your browser window, click on ''File'' and ''Save As''. After saving the
file, open the spreadsheet, find the saved file, and ''Open'' it.
======================================================================
Appendixes
Appendix A - Abbreviations
Appendix B - International Organizations and Groups
Appendix C - Selected International Environmental Agreements
Appendix D - Cross-Reference list of Country Data Codes
Appendix E - Cross-Reference List of Hydrographic Data Codes
Appendix F - Cross-Reference List of Geographic Names
Appendix G - Weights and Measures
======================================================================
References :: Definitions and Notes
A
Abbreviations
This information is included in Appendix A: Abbreviations, which
includes all abbreviations and acronyms used in the Factbook, with
their expansions.
Acronyms
An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up
solely from the first letter of the major words in the expanded form
is rendered in all capital letters (NATO from North Atlantic Treaty
Organization; an exception would be ASEAN for Association of
Southeast Asian Nations). In general, an acronym made up of more
than the first letter of the major words in the expanded form is
rendered with only an initial capital letter (Comsat from
Communications Satellite Corporation; an exception would be NAM from
Nonaligned Movement). Hybrid forms are sometimes used to distinguish
between initially identical terms (ICC for International Chamber of
Commerce and ICCt for International Criminal Court).
Administrative divisions
This entry generally gives the numbers, designatory terms, and
first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet
acted on by the BGN are noted.
Age structure
This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64
years, 65 years and over). The age structure of a population affects
a nation''s key socioeconomic issues. Countries with young
populations (high percentage under age 15) need to invest more in
schools, while countries with older populations (high percentage
ages 65 and over) need to invest more in the health sector. The age
structure can also be used to help predict potential political
issues. For example, the rapid growth of a young adult population
unable to find employment can lead to unrest.
Agriculture - products
This entry is an ordered listing of major crops and products
starting with the most important.
Airports
This entry gives the total number of airports or airfields
recognizable from the air. The runway(s) may be paved (concrete or
asphalt surfaces) or unpaved (grass, earth, sand, or gravel
surfaces) and may include closed or abandoned installations.
Airports or airfields that are no longer recognizable (overgrown, no
facilities, etc.) are not included. Note that not all airports have
accommodations for refueling, maintenance, or air traffic control.
Airports - with paved runways
This entry gives the total number of airports with paved runways
(concrete or asphalt surfaces) by length. For airports with more
than one runway, only the longest runway is included according to
the following five groups - (1) over 3,047 m (over 10,000 ft), (2)
2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000
to 8,000 ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5) under
914 m (under 3,000 ft). Only airports with usable runways are
included in this listing. Not all airports have facilities for
refueling, maintenance, or air traffic control. The type aircraft
capable of operating from a runway of a given length is dependent
upon a number of factors including elevation of the runway, runway
gradient, average maximum daily temperature at the airport, engine
types, flap settings, and take-off weight of the aircraft.
Airports - with unpaved runways
This entry gives the total number of airports with unpaved runways
(grass, dirt, sand, or gravel surfaces) by length. For airports with
more than one runway, only the longest runway is included according
to the following five groups - (1) over 3,047 m (over 10,000 ft),
(2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m
(5,000 to 8,000 ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5)
under 914 m (under 3,000 ft). Only airports with usable runways are
included in this listing. Not all airports have facilities for
refueling, maintenance, or air traffic control. The type aircraft
capable of operating from a runway of a given length is dependent
upon a number of factors including elevation of the runway, runway
gradient, average maximum daily temperature at the airport, engine
types, flap settings, and take-off weight of the aircraft.
Appendixes
This section includes Factbook-related material by topic.
Area
This entry includes three subfields. Total area is the sum of all
land and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of the
surfaces of all inland water bodies, such as lakes, reservoirs, or
rivers, as delimited by international boundaries and/or coastlines.
Area - comparative
This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of
the 50 states based on area measurements (1990 revised) provided by
the US Bureau of the Census. The smaller entities are compared with
Washington, DC (178 sq km, 69 sq mi) or The Mall in Washington, DC
(0.59 sq km, 0.23 sq mi, 146 acres).
B','c04f13b47bf9df9182b3da96f8714760cb80e008d1ba3176b6dfce650e4663e9','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95ab946bb63de8a115fca794652eab1b3e560a0b6b7e7c3665d86990e3d8ce3d',2009,'TC','Turks and Caicos Islands','military-and-security',27,'This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military - note
This entry includes miscellaneous military information of
significance not included elsewhere.
Military branches
This entry lists the service branches subordinate to defense
ministries or the equivalent (typically ground, naval, air, and
marine forces).
Military expenditures
This entry gives spending on defense programs for the most recent
year available as a percent of gross domestic product (GDP); the GDP
is calculated on an exchange rate basis, i.e., not in terms of
purchasing power parity (PPP).
Military service age and obligation
This entry gives the required ages for voluntary or conscript
military service and the length of service obligation.
Money figures
All money figures are expressed in contemporaneous US dollars unless
otherwise indicated.
N
National holiday
This entry gives the primary national day of celebration - usually
independence day.
Nationality
This entry provides the identifying terms for citizens - noun and
adjective.
Natural gas - consumption
This entry is the total natural gas consumed in cubic meters (cu m).
The discrepancy between the amount of natural gas produced and/or
imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
Natural gas - exports
This entry is the total natural gas exported in cubic meters (cu m).
Natural gas - imports
This entry is the total natural gas imported in cubic meters (cu m).
Natural gas - production
This entry is the total natural gas produced in cubic meters (cu m).
The discrepancy between the amount of natural gas produced and/or
imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
Natural gas - proved reserves
This entry is the stock of proved reserves of natural gas in cubic
meters (cu m). Proved reserves are those quantities of natural gas,
which, by analysis of geological and engineering data, can be
estimated with a high degree of confidence to be commercially
recoverable from a given date forward, from known reservoirs and
under current economic conditions.
Natural hazards
This entry lists potential natural disasters.
Natural resources
This entry lists a country''s mineral, petroleum, hydropower, and
other resources of commercial importance.
Net migration rate
This entry includes the figure for the difference between the number
of persons entering and leaving a country during the year per 1,000
persons (based on midyear population). An excess of persons entering
the country is referred to as net immigration (e.g., 3.56
migrants/1,000 population); an excess of persons leaving the country
as net emigration (e.g., -9.26 migrants/1,000 population). The net
migration rate indicates the contribution of migration to the
overall level of population change. High levels of migration can
cause problems such as increasing unemployment and potential ethnic
strife (if people are coming in) or a reduction in the labor force,
perhaps in certain key sectors (if people are leaving).
O
Oil - consumption
This entry is the total oil consumed in barrels per day (bbl/day).
The discrepancy between the amount of oil produced and/or imported
and the amount consumed and/or exported is due to the omission of
stock changes, refinery gains, and other complicating factors.
Oil - exports
This entry is the total oil exported in barrels per day (bbl/day),
including both crude oil and oil products.
Oil - imports
This entry is the total oil imported in barrels per day (bbl/day),
including both crude oil and oil products.
Oil - production
This entry is the total oil produced in barrels per day (bbl/day).
The discrepancy between the amount of oil produced and/or imported
and the amount consumed and/or exported is due to the omission of
stock changes, refinery gains, and other complicating factors.
Oil - proved reserves
This entry is the stock of proved reserves of crude oil in barrels
(bbl). Proved reserves are those quantities of petroleum which, by
analysis of geological and engineering data, can be estimated with a
high degree of confidence to be commercially recoverable from a
given date forward, from known reservoirs and under current economic
conditions.
P','e4d8a6285f61fb7dc65e9a97b77e5ca26796d1c2512eb5100c8db3b36aa935e5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

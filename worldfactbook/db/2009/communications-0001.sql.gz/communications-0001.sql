SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d21b9f789960fdd096d38527ed793d9d6b3f3a7e9778f6e323224fe4ce3da90',2009,'US','United States','communications',65,'Telephones— main lines in use
Telephones— mobile cellular
Telephone system
general assessment
domestic
international
Radio broadcast stations
Television broadcast stations
Internet country code
Internet hosts
Internet users
Communications— note','55210817df3665aa289aa54b70cd4ec11b0e6940a716e6e1899111a01a51de8a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c65ac6a77bcb54e3cfb862b13a31c17666ae8c68013bc5de00ada52d1f4aca2',2009,'AF','Afghanistan','communications',70,'Telephones— main lines in use:
280,000 (2005)
Telephones — mobile cellular: 2.52 mil¬
lion (2006)
Telephone system:
4
AKROTIRI
general assessment: limited landline tele-
phone service; an increasing number of
Afghans utilize mobile-cellular phone
networks in major cities
domestic: aided by the presence of muh
tiple providers, mobile-cellular tele¬
phone service is improving rapidly
international: country code — 93; five
VSAT’s installed in Kabul, Herat, Mazar-
e-Sharif, Kandahar, and Jalalabad pro¬
vide international and domestic voice
and data connectivity (2007)
Radio broadcast stations: AM 21, FM
5, shortwave 1 (broadcasts in Pashto,
Dari (Afghan Persian), Urdu, and
English) (2006)
Radios: 167,000 (1999)
Television broadcast stations: at least 7
(1 government-run central television
station in Kabul and regional stations in
6 of the 34 provinces) (2006)
Televisions: 100,000 (1999)
Internet country code: af
Internet hosts: 21 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 535,000 (2006)
Communications — note: Internet access
is growing through Internet cafes as well
as public “telekiosks” in Kabul (2005)
Radio broadcast stations: AM NA, FM
1, shortwave NA (British Forces
Broadcasting Service (BFBS) provides
Radio 1 and Radio 2 service to Akrotiri,
Dhekelia, and Nicosia) (2006)
Television broadcast stations: 0 (British
Forces Broadcasting Service (BFBS) pro¬
vides multi-channel satellite service to
Akrotiri, Dhekelia, and Nicosia) (2006)','990dcc1b631f96693ff615b101afd97ee7cfa941972cebfd60648bfd9ae1b8c3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc9b8a38d2998b98a2859c7c7f628c1b316ddcf6d9a4fdc16769904e311c7c13',2009,'AL','Albania','communications',78,'Telephones— main lines in use:
353,600 (2005)
Telephones— mobile cellular: 1.53 mil¬
lion (2005)
Telephone system:
general assessment: despite new invest¬
ment in fixed lines, the density of main
lines remains low with roughly 10 lines
per 100 people; cellular telephone use is
8','e1139da18cf98ea6963f6adb4485c075501e1729ffd8f14aae3627bb79ccb75d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45e8d6937e8ebd4ba7bba4342bfa5ff6472791189de08cb78b371396a3c6abb4',2009,'DZ','Algeria','communications',79,'widespread and generally effective; com-
bined fixed line and mobile telephone
density is approximately 60 telephones
per 100 persons
domestic: offsetting the shortage of fixed
line capacity, mobile phone service has
been available since 1996; by 2003 two
companies were providing mobile serv-
ices at a greater density than some of
Albania’s neighbors; Internet broadband
services initiated in 2005; internet cafes
are popular in Tirana and have started to
spread outside the capital
international: country code — 355; subma¬
rine cable provides connectivity to Italy,
Croatia, and Greece; the Trans-Balkan
Line, a combination submarine cable and
land fiber-optic system, provides additional
connectivity to Bulgaria, Macedonia, and
Turkey; international traffic carried by
fiber-optic cable and, when necessary, by
microwave radio relay from the Tirana
exchange to Italy and Greece (2007)
Radio broadcast stations: AM 13, FM
46, shortwave 1 (2005)
Radios: 1 million (2001)
Television broadcast stations: 65 (3
national, 62 local); 2 cable networks
(2005)
Televisions: 700,000 (2001)
Internet country code: al
Internet hosts: 852 (2007)
Internet Service Providers (ISPs): 10
(2001)
Internet users: 471,200 (2006)
Telephones — main lines in use: 2.841
million (2006)
Telephones— mobile cellular: 20.998
million (2006)
Telephone system:
general assessment: a weak network of
fixed-main lines, which remains low at
less than 10 telephones per 100 persons,
is partially offset by the rapid increase in
mobile cellular subscribership; in 2006,
combined fixed-line and mobile tele¬
phone density surpassed 70 telephones
per 100 persons
domestic: privatization of Algeria’s
telecommunications sector began in
2000; three mobile cellular licenses have
been issued and, in 2005, a consortium
led by Egypt’s Orascom Telecom won a
15-year license to build and operate a
fixed-line network in Algeria; the license
will allow Orascom to develop high¬
speed data and other specialized services
and contribute to meeting the large
unfulfilled demand for basic residential
telephony; internet broadband services
began in 2003 with approximately
200,000 subscribers in 2006
international: country code — 213;
landing point for the SEA-ME''WE-4
fiber- optic submarine cable system that
provides links to Europe, the Middle
East, and Asia; microwave radio relay to
Italy, France, Spain, Morocco, and
Tunisia; coaxial cable to Morocco and
Tunisia; participant in Medarabtel; satel¬
lite earth stations — 51 (Intelsat,
Intersputnik, and Arabsat) (2007)
Radio broadcasf sfafions: AM 25, FM
1, shortwave 8 (1999)
RadiOS: 7.1 million (1997)
Television broadcast stations: 46 (plus
216 repeaters) (1995)
Televisions: 3.1 million (1997)
Internet country code: dz
Internet hosts: 2,077 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 2.46 million (2006)
Telephones — main lines in use:
1.263.367.600 (2005)
Telephones — mobile cellular:
2.168.433.600 (2005)
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM
NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Internet Service Providers (ISPs):
10,350 (2000 est.)
Internet users: 1,018,057,389 (2005)','0f1cbcf41e2984c9baeb0cd32c8add1bc83b22f21baae01f1ef911a7b2578eb4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c515ad385c3e3ee1daab6b121814743c476a9f26ce6eb3a052be12934191450',2009,'AO','Angola','communications',94,'- '' • I. ■ • „Vr I''
Telephones — main lines in use: 35,400
(2005)
Telephones — mobile cellular: 64,600
(2005)
Telephone system:
general assessment: NA
domestic: modern system with microwave
radio relay connections between
exchanges
international: country code — 376; land-
line circuits to France and Spain
Radio broadcast stations: AM 0, FM
15, shortwave 0 (1998)
Radios: 16,000 (1997)
Television broadcast stations: 0 (1997)
Televisions: 27,000 (1997)
Internet country code: ad
Internet hosts: 15,486 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 23,200 (2006)
Telephones— main lines in use: 98,200
(2006)
Telephones— mobile cellular: 2.264
million (2006)
Telephone system:
general assessment: system inadequate;
fewer than one fixed-line per 100 per¬
sons; combined fixed line and mobile
telephone density approached 20 tele¬
phones per 100 persons in 2006
domestic: state-owned telecom had
monopoly for fixed-lines until 2005;
demand outstripped capacity, prices were
high, and services poor; Telecom
Namibia, through an Angolan company,
became the first private licensed operator
in Angola’s fixed-line telephone net¬
work; Angola Telecom established
mobile-cellular service in Luanda in
1993 and the network has been extended
to larger towns; a privately-owned,
mobile-cellular service provider began
operations in 2001
international: country code — 244;
landing point for the SAT-3/WASC
fiber-optic submarine cable that provides
connectivity to Europe and Asia; satel¬
lite earth stations — 29 (2007)
Radio broadcast stations: AM 21, FM
6, shortwave 7 (2001)
Radios: 815,000 (2000)
Television broadcast stations: 6 (2000)
Televisions: 196,000 (2000)
Internet country code: ao
Internet hosts: 3,337 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 85,000 (2005)
Telephones— main lines in use: 6,200
(2002)
Telephones— mobile cellular: 1,800
(2002)
Telephone system:
general assessment: NA
domestic: modern internal telephone
system
international: country code — 1-264;
landing point for the East Caribbean
Fiber System (ECFS) submarine cable
with links to 13 other islands in the
eastern Caribbean extending from the
British Virgin Islands to Trinidad;
microwave radio relay to island of Saint
Martin (Guadeloupe and Netherlands
Antilles) (2007)
Radio broadcast stations: AM 2, FM 7,
shortwave 0 (2004)
Radios: 3,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000 (1997)
Internet country code: .ai
Internet hosts: 319 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 3,000 (2002)
Telephones— main lines in use: 9,700
(2006)
Telephones— mobile cellular: 4 415
million (2006)
Telephone system:
general assessment: inadequate; state-
owned fixed-line operator has been
unable to expand fixed-line connections
and there are now fewer than 10,000
connections; given the backdrop of a
wholly inadequate fixed-line infrastruc¬
ture, the use of cellular services has
surged and subscribership now exceeds 4
million — roughly 7 per 100 persons
domestic: barely adequate wire and
microwave radio relay service in and
between urban areas; domestic satellite
system with 14 earth stations
international: country code — 243; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 3, FM
11, shortwave 2 (2001)
Radios: 18.03 million (1997)
Television broadcast stations: 4 (2001)
Televisions: 6.478 million (1997)
Internet country code: cd
154
CONGO, REPUBLIC OF THE
Internet hosts: 2,209 (2007)
Internet Service Providers (ISPs): l
(2001)
Internet users: 180,000 (2006)','751fb747fdc1c4947449f5a09176530b029484d48e73af688b360c9bafc80a05','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('130e0a3c902a5d1e7651c06bbb18e2d27227fcbc2cf0b1ab7070c71ce77404b6',2009,'AG','Antigua and Barbuda','communications',104,'Telephones— main lines in use: 0;
note — information for US bases only
(2001)
Telephone system:
general assessment: local systems at some
research stations
domestic: commercial cellular networks
operating in a small number of locations
international: country code — none allo¬
cated; via satellite (including mobile
Inmarsat and Iridium systems) to and
from all research stations, ships, aircraft,
and most field parties (2007)
Radio broadcast stations: FM 2, short¬
wave 1 (information for US bases only);
note— many research stations have a
local FM radio station (2007)
Radios: NA
Television broadcast stations: 1 (cable
system with 6 channels; American
Forces Antarctic Network-McMurdo —
information for US bases only) (2002)
Televisions: several hundred at
McMurdo Station (US)
note: information for US bases only
(2001)
Internet country code: aq
Internet hosts: 7,744 (2007)
Internet Service Providers (ISPs): NA
Telephones — main lines in use: 40,000
(2006)
Telephones— mobile cellular: 102,000
(2006)
Telephone system:
general assessment: NA
domestic: good automatic telephone
system
international: country code — 1-268;
landing point for the East Caribbean
Fiber System (ECFS) submarine cable
with links to 13 other islands in the
eastern Caribbean extending from the
British Virgin Islands to Trinidad; satel¬
lite earth stations — 2; tropospheric
scatter to Saba (Netherlands Antilles)
27
THE CIA WORLD FACTBOOK
and Guadeloupe (2007)
Radio broadcast stations: AM 4, FM 2,
shortwave 0 (1998)
Radios: 36,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 31,000 (1997)
Internet country code: ag
Internet hosts: 2,133 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 32,000 (2006)
Airports: 3 (2007)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (2007)
Roadways:
total: 1,165 km
paved: 384 km
unpaved: 781 km (2002)
Merchant marine:
total: 1,059 ships (1000 GRT or over)
8,158,597 GRT/10,757,767 DWT
by type: bulk carrier 46, cargo 612, carrier
4, chemical tanker 6, container 350, liq-
uefied gas 11, petroleum tanker 1 , refrig''
erated cargo 9, roll on/roll off 20
foreign-owned: 1,021 (Australia 1,
Colombia 1, Cyprus 2, Denmark 15,
Estonia 15, France 1, Germany 891,
Greece 3, Iceland 9, Latvia 9, Lebanon 1,
Lithuania 6, Netherlands 19, Norway 7,
NZ 2, Poland 2, Russia 5, Slovenia 6,
Sweden 1, Switzerland 5, Turkey 7, UK
4, US 8, Vietnam 1) (2007)
Ports and terminals: Saint John’s','ba8dcf3fea63a5d4fb7d38811b9c82e02343d487e1fa495de44125b7b89aadec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('965b9f32700ae72835249710c41de1ffa0c1e1a4a09ae1cb33ded046041ec6b9',2009,'AW','Aruba','communications',123,'Telephones — main lines in use: 38,300
(2005)
Telephones— mobile cellular: 108,200
(2005)
Telephone system:
general assessment: modern fully auto¬
matic telecommunications system
domestic: increased competition through
privatization; 3 wireless service providers
are now licensed
international: country code — 297;
landing site for the PAN -AM submarine
telecommunications cable system that
extends from the US Virgin Islands
through Aruba to Venezuela, Colombia,
Panama, and the west coast of South
America; extensive interisland
microwave radio relay links (2007)
Radio broadcast stations: AM 2, FM
16, shortwave 0 (2004)
Radios: 50,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 20,000 (1997)
Internet country code: .aw
Internet hosts: 16,914 (2007)
Internet Service Providers (ISPs): NA
Internet users: 24,000 (2005)','4346e7cb5e33ac60eaa2561406e5f3f115d92ac56941bad58399e9c639018253','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b48f5a732f872a4c864a45ca1e2e0408980f88963992e5b11bacaf125d194d0b',2009,'AU','Australia','communications',132,'Telephones— main lines in use: 9.94
million (2006)
Telephones— mobile cellular: 19.76
million (2006)
Telephone system:
general assessment: excellent domestic
and international service
domestic: domestic satellite system; sig¬
nificant use of radiotelephone in areas of
low population density; rapid growth of
mobile cellular telephones
international: country code — 61; landing
point for the SEA-ME''WE-3 optical
42','f2854e47a67148a573189d14a50a7a81280b33078a783b6588f74e6d9fdd15d1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9137899a4a1dadb3107cfee4e79bffd4fc30a21b25679bf170299b846251e958',2009,'AT','Austria','communications',133,'telecommunications submarine cable
with links to Asia, the Middle East, and
Europe; the Southern Cross fiber optic
submarine cable provides links to New
Zealand and the United States; satellite
earth stations — 19 (10 Intelsat — 4
Indian Ocean and 6 Pacific Ocean, 2
Inmarsat — Indian and Pacific Ocean
regions, 2 Globalstar, 5 other) (2007)
Radio broadcast stations: AM 262, FM
345, shortwave 1 (1998)
Radios: 25.5 million (1997)
Television broadcast stations: 104 (1997)
Televisions: 10.15 million (1997)
Internet country code: au
Internet hosts: 9.458 million (2007)
Internet Service Providers (ISPs): 571
(2002)
Internet users: 15.3 million (2006)
Telephones— main lines in use: 3.564
million (2006)
Telephones— mobile cellular: 9.255
million (2006)
Telephone system:
general assessment: highly developed and
efficient
domestic: fixed-line subscribership has
been in decline since the mid-1990s with
mobile-cellular subscribership elipsing it
by the late 1990s; the fiber-optic net is
very extensive; all telephone applica¬
tions and Internet services are available
international: country code — 43; satellite
earth stations — 15; in addition, there are
about 600 VSATs (very small aperture
terminals) (2007)
Radio broadcast stations: AM 2, FM 65
(plus several hundred repeaters), short¬
wave 1 (2001)
Radios: 6.08 million (1997)
Television broadcast stations: 10 (plus
more than 1,000 repeaters) (2001)
Televisions: 4.25 million (1997)
Internet country code: at
Internet hosts: 2.427 million (2007)
Internet Service Providers (ISPs): 37
(2000)
Internet users: 4.2 million (2006)
Airports: 55 (2007)
Airports — with paved runways:
total: 25
over 3,047 m: 1
2,438 to 3,047 m: 5
1 ,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 15 (2007)
Airports— with unpaved runways:
total: 30
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 26 (2007)
Heliports: 1 (2007)
Pipelines: gas 2,722 km; oil 663 km;
refined products 157 km (2007)
Railways:
total: 6,383 km
standard gauge: 5,924 km 1.435-m gauge
(3,772 km electrified)
narrow gauge : 371 km 1.000-m gauge; 88
km 0.760-m gauge (25 km electrified)
(2006)
Roadways:
total: 133,910 km
paved: 133,910 km (includes 2,050 km of
expressways) (2003)
Waterways: 358 km (2007)
Merchant marine:
total: 7 ships (1000 GRT or over) 31,705
GRT/40,627 DWT
by type: cargo 5, container 2
foreign''Owned: 2 (Netherlands 2)
registered in other countries: 4 (Cyprus 1,
Malta 1, St Vincent and The Grenadines
2) (2007)
Ports and terminals: Enns, Krems, Linz,
Vienna','7e8eb84d439db16c2f2467eafdc5722fd5ad4a4a30682facb30b6d6275bf16f8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c65cf3e91a02bef2c51368636ba3ee53c4e9e915c6d24edb34e3cdf85afeae5',2009,'AZ','Azerbaijan','communications',145,'Telephones— main lines in use: 1.189
million (2006)
Telephones — mobile cellular: 3.324
million (2006)
Telephone system:
general assessment: inadequate; requires
considerable expansion and moderniza¬
tion; teledensity of 15 main lines per 100
persons is low; mobile-cellular penetra¬
tion is increasing and is currently about
40 telephones per 100 persons
domestic: fixed-line telephony and a
broad range of other telecom services are
controlled by a state-owned telecommu¬
nications monopoly and growth has been
stagnant; more competition exists in the
mobile-cellular market with three
providers in 2006; satellite service con¬
nects Baku to a modern switch in its
exclave of Naxcivan
international: country code — 994; the old
Soviet system of cable and microwave is
still serviceable; satellite earth stations —
2 (2007)
Radio broadcast stations: AM 10, FM
17, shortwave 1 (1998)
Radios: 175,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 170,000 (1997)
Internet country code: az
Internet hosts: 3,067 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 829,100 (2006)','0f26337c3527e80a4dbe86cfb58c9fc6847863a3f235547f178056b044dd010e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61963180406219e2ffa95b6a093bdc602f3f872c0bf1e06ea75a6282e1d639c6',2009,'BH','Bahrain','communications',148,'Telephones— main lines in use:
133,100 (2005)
Telephones — mobile cellular: 227,800
(2005)
Telephone system:
general assessment: modern facilities
domestic: totally automatic system;
highly developed; the Bahamas
Domestic Submarine Network links 14
of the islands and is designed to satisfy
increasing demand for voice and broad¬
band internet services
international: country code — 1-242;
landing point for the Americas Region
Caribbean Ring System (ARCOS-1)
fiber-optic submarine cable that provides
links to South and Central America,
parts of the Caribbean, and the US;
satellite earth stations — 2 (2007)
Radio broadcast stations: AM 3, FM 5,
shortwave 0 (2006)
Radios: 215,000 (1997)
Television broadcast stations: 2 (2006)
Televisions: 67,000 (1997)
Internet country code: bs
Internet hosts: 248 (2007)
Internet Service Providers (ISPs): 19
(2000)
Internet users: 103,000 (2005)','f2ab813509ec2004bb90a0b85f1ce8a5130a87fd10948a638b3f072bf6c8cfe8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('707a6f439828c0e957e0bd7554406193948020ccac8e4b422ddf140fcb230cae',2009,'BD','Bangladesh','communications',156,'Telephones— main lines in use: 1.134
million (2006)
Telephones— mobile cellular: 19.131
million (2006)
Telephone system:
general assessment: totally inadequate for
a modern country; fixed-line telephone
density of less than 1 per 100 persons;
mobile-cellular telephone density of 13
per 100 persons
domestic: modernizing; introducing dig¬
ital systems; trunk systems include VHF
58','c1d4164c392e29b8d3a1fc32c08a271a1788badf220b603452d36541013285f4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('782ce3029f7eda9b19039493a3e3c6632d348877a1285ee3f9662bd75fe63204',2009,'BB','Barbados','communications',157,'and UHF microwave radio relay links,
and some fiber-optic cable in cities
international: country code — 880;
landing point for the SEA-ME-WE-4
fiber-optic submarine cable system that
provides links to Europe, the Middle East
and Asia; satellite earth stations — 6;
international radiotelephone communi¬
cations and landline service to neigh¬
boring countries (2007)
Radio broadcast stations: AM 15, FM
13, shortwave 2 (2006)
Radios: 6.15 million (1997)
Television broadcast stations: 15
(1999)
Televisions: 770,000 (1997)
Internet country code: bd
Internet hosts: 376 (2007)
Internet Service Providers (ISPs): 10
(2000)
Internet users: 450,000 (2006)
Telephones — main lines in use:
134,900 (2005)
Telephones— mobile cellular: 206,200
(2005)
Telephone system:
general assessment: fixed-line teledensity
of roughly 50 per 100 persons; mobile-
cellular telephone density of 75 per 100
persons
domestic: island-wide automatic tele¬
phone system
international: country code — 1-246;
landing point for the East Caribbean
Fiber System (ECFS) submarine cable
with links to 13 other islands in the
eastern Caribbean extending from the
British Virgin Islands to Trinidad; satel¬
lite earth stations — 1 (Intelsat -Atlantic
Ocean); tropospheric scatter to Trinidad
and Saint Lucia (2007)
Radio broadcast stations: AM 2, FM 6,
shortwave 0 (2004)
Radios: 237,000 (1997)
Television broadcast stations: 1 (plus 2
cable channels) (2004)
Televisions: 76,000 (1997)
Internet country code: hb
Internet hosts: 104 (2007)
Internet Service Providers (ISPs): 19
(2000)
Internet users: 160,000 (2005)
Airports: 1 (2007)
Airports — with paved runways:
total: 1
over 3,047 m: 1 (2007)
Roadways:
total: 1,600 km
paved: 1,600 km (2004)
Merchant marine:
total: 71 ships (1000 GRT or over)
539,579 GRT/793,899 DWT
by type: bulk carrier 13, cargo 39, chem¬
ical tanker 6, passenger 1, pas-
senger/cargo 1, petroleum tanker 3,
refrigerated cargo 5, roll on/roll off 2,
specialized tanker 1
foreign- owned: 67 (Bahamas, The 1,
Canada 9, Greece 11, India 1, Lebanon 1,
Monaco 1, Norway 35, Sweden 5, UK 3)
registered in other countries: 1 (St Vincent
and The Grenadines 1) (2007)
Ports and terminals: Bridgetown
Military branches: Royal Barbados
Defense Force: Troops Command,
Barbados Coast Guard (2007)
Military service age and obligation: 18
years of age for voluntary military service
(younger requires parental consent); no
conscription (2008)
Manpower available for military
service:
males age 16-49: 75,265
females age 16-49: 75,389 (2008 est.)
Manpower fit for military service:
males age 16—49: 58,556
females age 16-49: 58,143 (2008 est.)
Military expenditures — percent of
GDP: 0.5% (2006 est.)
61
THE CIA WORLD FACTBOOK
Military — note: the Royal Barbados
Defense Force includes a land-based
Troop Command and a small Coast
Guard; the primary role of the land ele¬
ment is to defend the island against
external aggression; the Command con¬
sists of a single, part-time battalion with
a small regular cadre that is deployed
throughout the island; it increasingly
supports the police in patrolling the
coastline to prevent smuggling and other
illicit activities (2007)
Disputes— international: in April 2006,
the Permanent Court of Arbitration
issued a decision that delimited a mar¬
itime boundary with Trinidad and
Tobago and compelled Barbados to enter
a fishing agreement limiting Barbadian
fishermen’s catches of flying fish in
Trinidad and Tobago''s exclusive eco¬
nomic zone; in 2005, Barbados and
Trinidad and Tobago agreed to compul¬
sory international arbitration under
UNCLOS challenging whether the
northern limit of Trinidad and Tobago’s
and Venezuela’s maritime boundary
extends into Barbadian waters; joins
other Caribbean states to counter
Venezuela’s claim that Aves Island sus¬
tains human habitation, a criterion
under the UN Convention on the Law of
the Sea (UNCLOS), which permits
Venezuela to extend its EEZ/continental
shelf over a large portion of the eastern
Caribbean Sea
Illicit drugs: one of many Caribbean
transshipment points for narcotics bound
for Europe and the US; offshore financial
center
jr * ^ r*.1 ■ 3 y . : l f 2", <** a
:-C ''A''"','87bb614dbe6159444253667def36f4e12622baa78ade5479174cbc1e9da5fb0f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('075245516b5ca88dbeb7d1acfe476a7d971e81becc8a718aea1e48382512c7a6',2009,'LV','Latvia','communications',161,'Polotsk
RUSSIA
Vrtsyftbsk
Mahiiyow^
MINSK
Babruysk
Honvyei’
Telephones — main lines in use: 90,067
(2006)
Telephones — mobile cellular: 638,200
(2006)
Telephone system:
general assessment: service to general
public is poor but improving; the govern¬
ment relies on a radiotelephone network
to communicate with remote areas
domestic: multiple service providers;
combined fixed-line and mobile-cellular
subscribership about 10 per 100 persons
international: country code — 856; satel¬
lite earth station — 1 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 7, FM
14, shortwave 2 (2006)
Radios: 730,000 (1997)
Television broadcast stations: 7
(includes 1 station relaying Vietnam
Television from Hanoi) (2006)
Televisions: 52,000 (1997)
Internet country code: la
internet hosts: 935 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 25,000 (2005)
Airports: 42 (2007)
Airports— with paved runways:
total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 3 (2007)
Airports— with unpaved runways:
total: 33
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 9
under 914 m: 23 (2007)
Pipelines: refined products 540 km
(2007)
Roadways:
total: 31,210 km
paved: 4,494 km
unpaved: 26,716 km (2003)
Waterways: 4,600 km
note: primarily Mekong and tributaries;
2,900 additional km are intermittently
navigable by craft drawing less than 0.5
m (2007)
Merchant marine:
total: 1 ship (1000 GRT or over) 2,370
GRT/3,110 DWT
by type: cargo 1 (2007)
Military branches: Lao People’s Armed
Forces (LPAF): Lao People’s Army (LPA;
includes Riverine Force), Air Force
(2008)
Military service age and obligation: 15
years of age for compulsory military
service; minimum 18-month conscript
service obligation (2006)
Manpower available for military
service: males age 16-49: 1,549,774
females age 1 6 — 49 : 1,570,702 (2008 est.)
Manpower fit for military service:
males age 16—49: 993,162
females age 16—49: 1,052,053 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 73,973
females age 16—49: 72,758 (2008 est.)
Military expenditures— percent of
GDP: 0.5% (2006)
Military — note: serving one of the
world’s least developed countries, the
Lao People’s Armed Forces (LPAF) is
small, poorly funded, and ineffectively
resourced; its mission focus is border and
internal security, primarily in countering
ethnic Hmong insurgent groups;
together with the Lao People’s
Revolutionary Party and the govern¬
ment, the Lao People’s Army (LPA) is
the third pillar of state machinery, and as
such is expected to suppress political and
civil unrest and similar national emer¬
gencies, but the LPA also has upgraded
skills to respond to avian influenza out¬
breaks; there is no perceived external
threat to the state and the LPA main¬
tains strong ties with the neighboring
Vietnamese military (2008)','2216cfb056e1e6885fc3030a327cb83e9648a0c7374ab725c3e625c4b9855bb5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('225a9f4079b4b69777700cb4e33a72824dc6fa7e0f3164e069aa072089af0d7f',2009,'UA','Ukraine','communications',162,'i n mmm
) "-V
S’O!
o so too m
Background: After seven decades as a
constituent republic of the USSR,
Belarus attained its independence in
1991. It has retained closer political and
economic ties to Russia than any of the
other former Soviet republics. Belarus
and Russia signed a treaty on a two-state
union on 8 December 1999 envisioning
greater political and economic integra¬
tion. Although Belarus agreed to a
framework to carry out the accord,
serious implementation has yet to take
place. Since his election in July 1994 as
the country’s first president, Alexandr
LUKASHENKO has steadily consoli¬
dated his power through authoritarian
means. Government restrictions on
freedom of speech and the press, peaceful
assembly, and religion continue.
Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00
E
Map references: Europe
Area:
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area — comparative: slightly smaller
than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km,
Lithuania 502 km, Poland 605 km,
Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: cold winters, cool and moist
summers; transitional between conti¬
nental and maritime
Terrain: generally flat and contains much
marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits,
small quantities of oil and natural gas,
granite, dolomitic limestone, marl,
chalk, sand, gravel, clay
Land use:
arable land: 26.77%
permanent crops: 0.6%
other: 72.63% (2005)
Irrigated land: 1,310 sq km (2003)
Total renewable water resources: 58 cu
km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.79 cu
km/yr (23%/47%/30%)
per capita: 286 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: soil pol¬
lution from pesticide use; southern part
of the country contaminated with fallout
from 1986 nuclear reactor accident at
Chornobyl’ in northern Ukraine
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, O zone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; glacial
scouring accounts for the flatness of
Belarusian terrain and for its 11,000
lakes
Telephones— main lines in use:
108,100 (2006)
Telephones— mobile cellular: 2.009
million (2006)
Telephone system:
general assessment: seriously inadequate;
mobile cellular service is increasing rap¬
idly, but the number of main lines is still
deficient; e-mail and Internet services
are available
domestic: intercity traffic by wire,
microwave radio relay, and radiotele¬
phone communication stations, fixed
and mobile-cellular systems for short-
range traffic
international: country code — 256; satel¬
lite earth stations — 1 Intelsat (Atlantic
Ocean) and 1 Inmarsat; analog links to
Kenya and Tanzania
Radio broadcast stations: AM 7, FM
33, shortwave 2 (2001)
Radios: 5 million (2001)
Television broadcast stations: 8 (plus 1
repeater) (2001)
Televisions: 500,000 (2001)
Internet country code: ug
Internet hosts: 546 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 750,000 (2006)
Telephones— main lines in use: 12.341
million (2006)
674','31f89b9e33354fd549a134144bb9cea8ee0e0b169eee8a01e8e1bb3e22f8af77','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebfb4a3d9ae2711ab93acca66c1fda985496c9889cf02c4c57c4d50357980794',2009,'BE','Belgium','communications',168,'Telephones— main lines in use: 3.368
million (2006)
Telephones— mobile cellular: 5.96 mil¬
lion (2006)
Telephone system:
general assessment: Belarus lags behind its
neighbors in upgrading telecommunica¬
tions infrastructure; state-owned
Beltelcom is the sole provider of fixed-
line local and long distance service;
fixed-line teledensity of 33 per 100 per¬
sons; mobile-cellular telephone density
of 58 per 100 persons; modernization of
the network progressing with roughly
two-thirds of switching equipment now
digital
domestic: fixed-line penetration is
improving although rural areas continue
to be underserved; 4 GSM wireless net¬
works are experiencing rapid growth;
strict government controls on telecom¬
munications technologies
international: country code — 375; Belarus
is a member of the Trans-European Line
(TEL), Trans- Asia-Europe (TAE) fiber¬
optic line, and has access to the Trans-
Siberia Line (TSL); 3 fiber-optic
segments provide connectivity to Latvia,
Poland, Russia, and Ukraine; worldwide
service is available to Belarus through
this infrastructure; additional analog
lines to Russia; Intelsat, Eutelsat, and
Intersputnik earth stations (2007)
Radio broadcast stations: AM 28, FM
37, shortwave 11 (1998)
Radios: 3.02 million (1997)
Television broadcast stations: 47 (plus
27 repeaters) (1995)
Televisions: 2.52 million (1997)
Internet country code: by
Internet hosts: 20,685 (2007)
Internet Service Providers (ISPs): 23
(2002)
Internet users: 5.478 million (2006)','9cb59527edbcf783c3860bcb9327250ae8e641a8744b21efd9d9d6c2c7822ec2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd550f7ca6fb90b9a39f872ce0e700be52873ff141c395ffa914daf6140ee5bc',2009,'FR','France','communications',172,'Telephones — main lines in use: 4.7 19
million (2006)
Telephones — mobile cellular: 9.66 mil¬
lion (2006)
Telephone system:
general assessment: highly developed,
technologically advanced, and com¬
pletely automated domestic and interna¬
tional telephone and telegraph facilities
domestic: nationwide cellular telephone
system; extensive cable network; limited
microwave radio relay network
international: country code — 32; landing
point for a number of submarine cables
that provide links to Europe, the Middle
East, and Asia; satellite earth stations —
7 (Intelsat— 3) (2007)
Radio broadcast stations: AM 7, FM
79, shortwave 1 (1998)
Radios: 8.075 million (1997)
Television broadcast stations: 25 (plus
10 repeaters) (1997)
Televisions: 4.72 million (1997)
Internet country code: be
Internet hosts: 3.195 million (2007)
Internet Service Providers (ISPs): 61
(2000)
Internet users: 4.8 million (2005)
Telephones— main lines in use: 34 63
million; 33.897 million (metropolitan
France) (2006)
Telephones— mobile cellular: 53.023
million; 51.662 million (metropolitan
France) (2006)
Telephone system:
general assessment: highly developed
domestic: extensive cable and microwave
radio relay; extensive introduction of
fiber-optic cable; domestic satellite system
international: country code — 33;
numerous submarine cables provide links
throughout Europe, Asia, Australia, the
Middle East, and US; satellite earth sta¬
tions — more than 3 (2 Intelsat (with
total of 5 antennas — 2 for Indian Ocean
and 3 for Atlantic Ocean), NA Eutelsat,
1 Inmarsat — Atlantic Ocean region); HF
radiotelephone communications with
more than 20 countries
overseas departments: country codes:
French Guiana — 594; Guadeloupe —
590; Martinique — 596; Reunion — 262
232
Telephones— main lines in use: 4,800
(2002)
Telephone system:
general assessment: adequate
domestic: NA
international: country code — 508;
radiotelephone communication with
most countries in the world; satellite
earth station — 1 in French domestic
satellite system
Radio broadcast stations: AM l, FM 4,
shortwave 0 (1998)
Radios: 4,000 (1997)
Television broadcast stations: 0 (2
repeaters rebroadcast programs from
France, Canada, and the US) (1997)
Televisions: 4,000 (1997)
Internet country code: pm
Internet hosts: 0 (2007)
Internet Service Providers (ISPs): 1
(2000)
internet users: NA','a15a0f4f6860105a0682e7f6e98d15a7d57b938ba4e64196612a5946d27f5341','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b309d6d28b7cc26299533fd21a98d7d2e669104bee69524dbd82fb6a5eaddfba',2009,'BJ','Benin','communications',180,'Telephones— main lines in use: 33,900
(2006)
Telephones— mobile cellular: 118,300
(2006)
Telephone system:
general assessment: above -average system;
fixed-line teledensity of 12 per 100 per¬
sons; mobile-cellular telephone density
of about 40 per 100 persons
domestic: trunk network depends prima¬
rily on microwave radio relay
international: country code — 501;
landing point for the Americas Region
Caribbean Ring System (ARCOS-1)
fiber-optic telecommunications subma¬
rine cable that provides links to South
and Central America, parts of the
Caribbean, and the US; satellite earth
station — 8 (Intelsat — 2, unknown- — 6)
(2007)
Radio broadcast stations: AM 1, FM
16, shortwave 0 (2006)
Radios: 133,000 (1997)
Television broadcast stations: 5 (2006)
Televisions: 41,000 (1997)
Internet country code: bz
Internet hosts: 1,942 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 34,000 (2006)','2328db8f7a9a1725ba63049fe8863fa3a03ec0df4704058d731562f3dc033154','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10cab561c2d17a60c7573e770140d39923acf3f0406c791ceb2888d05e1d83f0',2009,'BT','Bhutan','communications',199,'Telephones— main lines in use: 31,500
(2006)
Telephones — mobile cellular: 82,100
(2006)
Telephone system:
general assessment: urban towns and dis¬
trict headquarters have telecommunica¬
tions services
domestic: very low teledensity; domestic
service is very poor especially in rural
areas; wireless service available since
2003
international: country code — 975; inter¬
national telephone and telegraph service
via landline and microwave relay
through India; satellite earth station — 1
Intelsat (2007)
Radio broadcast stations: AM 0, FM 9,
shortwave 1 (2007)
Radios: 37,000 (1997)
Television broadcast stations: 1 (2007)
Televisions: 11,000 (1997)
Internet country code: bt
Internet hosts: 9,180 (2007)
Internet Service Providers (ISPs): NA
Internet users: 30,000 (2006)
Airports: 2 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (2007)
Roadways:
total: 8,050 km
paved: 4,991 km
unpaved: 3,059 km (2003)
Military branches: Royal Bhutan Army
(includes Royal Bodyguard and Royal
Bhutan Police) (2008)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 190,104
females age 16-49: 167,289 (2008 est.)
Manpower fit for military service:
males age 16—49: 146,063
females age 16-49: 131,193 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 7,847
females age 16—49: 7,530 (2008 est.)
Military expenditures— percent of
GDP: 1% (2005 est.)','ba8efd197fafb5cabdcaf48e86c63e278679f5d358ac869bb95958f66f441b78','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c70081218e0eff95dc80f38a2cf0de9636c97c0fe097598a009967c29d8cebb',2009,'PE','Peru','communications',204,'Telephones— main lines in use:
646,300 (2005)
Telephones— mobile cellular: 2.421
million (2005)
Telephone system:
general assessment: privatization begin¬
ning in 1995; reliability has steadily
improved; new subscribers face bureau¬
cratic difficulties; most telephones are
concentrated in La Paz and other cities;
mobile-cellular telephone use expanding
rapidly; fixed-line teledensity of 7 per
100 persons; mobile-cellular telephone
density of 27 per 100 persons
domestic: primary trunk system, which is
being expanded, employs digital
microwave radio relay; some areas are
served by fiber-optic cable; mobile cel¬
lular systems are being expanded
international: country code — 591; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) (2007)
Radio broadcasf slalions: AM 171, FM
73, shortwave 77 (1999)
Radios: 5.25 million (1997)
Television broadcast stations: 48
(1997)
Televisions: 900,000 (1997)
Internet country code: bo
Internet hosts: 24,363 (2007)
Internet Service Providers (ISPs): 9
(2000)
Internet users: 580,000 (2006)
Telephones— main lines in use:
331,100 (2006)
Telephones— mobile cellular: 3.233
million (2006)
Telephone system:
general assessment: meager telephone
service; principal switching center is in
Asuncion
domestic: the fixed-line market is a state
monopoly; deficiencies in provision of
fixed-line service have resulted in a rapid
expansion of mobile-cellular services fos¬
tered by competition among multiple
providers
international: country code — 595; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 41, FM
121, shortwave 6 (3 inactive) (2006)
Radios: 925,000 (1997)
Television broadcast stations: 5 (2007)
Televisions: 990,000 (2001)
Internet country code: py
Internet hosts: 12,497 (2007)
Internet Service Providers (ISPs): 4
(2000)
Internet users: 260,000 (2006)
Telephones— main lines in use: 2.332
million (2006)
Telephones— mobile cellular: 8.5 mil¬
lion (2006)
Telephone system:
general assessment: adequate for most
requirements
domestic: fixed-line teledensity is only
about 8 per 100 persons; mobile-cellular
teledensity, spurred by competition
among multiple providers, has increased
to about 30 telephones per 100 persons;
nationwide microwave radio relay system
and a domestic satellite system with 12
earth stations
international: country code — 51; the
South America- 1 (SAM-1) and Pan
American (PAN -AM) submarine cable
systems provide links to parts of Central
and South America, the Caribbean, and
US; satellite earth stations — 2 Intelsat
(Atlantic Ocean)
Radio broadcasf sfafions: AM 472, FM
198, shortwave 189 (1999)
Radios: 6.65 million (1997)
Television broadcasf sfafions: 13 (plus
112 repeaters) (1997)
Televisions: 3.06 million (1997)
Infernet counfry code: pe
Internet hosts: 270,193 (2007)
Internet Service Providers (ISPs): 10
(2000)
Internet users: 6.1 million (2006)
Airports: 237 (2007)
Airports— with paved runways:
total: 54
over 3,047 m: 6
2,438 to 3,047 m: 20
1,524 to 2,437 m: 14
914 to 1,523 m: 11
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 183
2,438 to 3,047 m: 2
1,524 to 2,437 m: 24
914 to 1,523 m: 40
under 914 m: 117 (2007)
Heliports: 1 (2007)
Pipelines: gas 1,181 km; gas/liquid
petroleum gas 61 km; liquid natural gas
106 km; liquid petroleum gas 517 km; oil
1,749 km; refined products 13 km (2007)
Railways: total: 1,989 km
standard gauge: 1,726 km 1.435-m gauge
narrow gauge: 263 km 0.914-m gauge
(2006)
Roadways: total: 78,829 km
paved: 11,351 km (includes 276 km of
expressways)
unpaved: 67,478 km (2004)
Waterways: 8,808 km
note: 8,600 km of navigable tributaries of
Amazon system and 208 km of Lago
Titicaca (2007)
Merchant marine:
total: 6 ships (1000 GRT or over) 76,220
GRT/1 19,615 DWT
by type: cargo 3, petroleum tanker 3
foreign'' owned: 1 (US 1)
registered in other countries: 16 (Belize 1,
Panama 15) (2007)
Ports and terminals: Callao, Iqmtos,
Matarani, Paita, Pucallpa, Yurimaguas;
note — Iquitos, Pucallpa, and Yurimaguas
are on the upper reaches of the Amazon
and its tributaries','7725278a176a29b0c67877c5965772058b1897bf5a7ae7bda8958aa30fa99aa2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('105392c80bec37076cf55e8f42b9f97cde7ba60feb01de296c5c702a4c90c5d1',2009,'BV','Bouvet Island','communications',214,'Telephones— main lines in use:
136,900 (2006)
Telephones— mobile cellular: 979,800
(2006)
Telephone system:
general assessment: the system is
expanding with the growth of mobile-
cellular service and participation in
regional development; system is fully dig¬
ital with fiber-optic cables linking the
major population centers in the east;
fixed-line connections declined in
recent years and now stand at 8 per 100
persons; mobile-cellular telephone den¬
sity currently is about 60 per 100 persons
domestic: small system of open-wire lines,
microwave radio relay links, and a few
radiotelephone communication stations;
mobile-cellular service is growing fast
international: country code — 267; inter¬
national calls are made via satellite,
using international direct dialing; 2
international exchanges; digital
microwave radio relay links to Namibia,
Zambia, Zimbabwe, and South Africa;
satellite earth station — 1 Intelsat
(Indian Ocean) (2007)
Radio broadcast stations: AM 8, FM
13, shortwave 4 (2001)
Radios: 252,720 (2000)
Television broadcast stations: 2 (1
state-owned, 1 private)
Televisions: 31,000 (1997)
Internet country code: bw
Internet hosts: 5,820 (2007)
Internet Service Providers (ISPs): 11
(2001)
Internet users: 60,000 (2005)
Internet country code: bv
Internet hosts: 6 (2007)
Communications — note: automatic
meteorological station','6f01da4d1128925d8c32c1da300159b6094c311cc8d459da1eed805c3e587e2b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98d4fd1e04f1eec7c9e04fa6cb6652813d69e9cd373aece679f5091a42f0ea02',2009,'BR','Brazil','communications',224,'Telephones— main lines in use: 38.8
million (2006)
Telephones— mobile cellular: 99.919
million (2006)
Telephone system:
general assessment: good working system;
fixed-line connections have remained
relatively stable in recent years and stand
at about 20 per 100 persons; mobile-cel¬
lular telephone density has risen to
nearly 55 per 100 persons
domestic: extensive microwave radio
relay system and a domestic satellite
system with 64 earth stations; mobile-
cellular usage has more than tripled in
the past 5 years
international: country code — 55; landing
point for a number of submarine cables
that provide direct links to South and
Central America, the Caribbean, the
US, Africa, and Europe; satellite earth
stations — 3 Intelsat (Atlantic Ocean), 1
Inmarsat (Atlantic Ocean region east),
connected by microwave relay system to
Mercosur Brazilsat B3 satellite earth sta¬
tion (2007)
Radio broadcast stations: AM 1,365,
FM 296, shortwave 161 (of which 91 are
collocated with AM stations) (1999)
Radios: 71 million (1997)
Television broadcast stations: 138
(1997)
Televisions: 36.5 million (1997)
Internet country code: br
Internet hosts: 8.265 million (2007)
Internet Service Providers (ISPs): 50
(2000)
Internet users: 42.6 million (2006)
Telephones— main lines in use: NA
Telephone system:
general assessment: separate facilities for
military and public needs are available
domestic: all commercial telephone serv¬
ices are available, including connection
to the Internet
international: country code (Diego
Garcia) — 246; international telephone
service is carried by satellite (2000)
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: l (1997)
Televisions: NA
Internet country code: io
Internet hosts: 61 (2007)
Internet Service Providers (ISPs): 1
(2000)
Airports: 1 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Roadways:
note: short section of paved road between
port and airfield on Diego Garcia
Ports and terminals: Diego Garcia
Military— note: defense is the responsi¬
bility of the UK; the US lease on Diego
Garcia expires in 2016
Disputes— international: Mauritius and
Seychelles claim the Chagos
Archipelago including Diego Garcia; in
2001, the former inhabitants of the
Chagos Archipelago, evicted in 1967
and 1973 and now residing chiefly in
Mauritius, were granted UK citizenship
and the right to repatriation; in May
2006, the High Court of London
reversed U.K. Government’s 2004 orders
of council that banned habitation on the
islands; a small group of Chagossians vis¬
ited Diego Garcia in April 2006; repatri¬
ation is complicated by the exclusive US
military lease of Diego Garcia that
restricts access to the largest viable island
in the chain
BRITISH VIRGIN ISLANDS
''
mm
piS
Telephones— main lines in use: 11,700
(2002)
Telephones— mobile cellular: 8,000
(2002)
Telephone system:
general assessment: worldwide telephone
service
domestic: NA
international: country code — 1-284; con¬
nected via submarine cable to Bermuda;
the East Caribbean Fiber System (ECFS)
submarine cable provides connectivity to
13 other islands in the eastern Caribbean
(2007)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (2004)
Radios: 9,000 (1997)
Television broadcast stations: 1 (plus l
cable company) (1997)
Televisions: 4,000 (1997)
Internet country code: vg
Internet hosts: 490 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 4,000 (2002)
Airports: 3 (2007)
Airports— with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (2007)
Roadways:
total: 177 km
paved: 177 km (2002)
Ports and terminals: Road Town
HOhTH ATLANTIC
QCSAN
Background: Originally a Dutch colony
in the 17th century, by 1815 Guyana had
become a British possession. The aboli¬
tion of slavery led to black settlement of
urban areas and the importation of
indentured servants from India to work
the sugar plantations. This ethnocultural
divide has persisted and has led to turbu¬
lent politics. Guyana achieved inde¬
pendence from the UK in 1966, and
since then it has been ruled mostly by
socialist-oriented governments. In 1992,
Cheddi JAGAN was elected president in
what is considered the country’s first free
and fair election since independence.
After his death five years later, his wife,
Janet JAGAN, became president but
resigned in 1999 due to poor health. Fler
successor, Bharrat JAGDEO, was
reelected in 2001 and again in 2006.
Location: Northern South America, bor¬
dering the North Atlantic Ocean,
between Suriname and Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area: total: 214,970 sq km
land: 196,850 sq km
water: 18,120 sq km
Area— comparative: slightly smaller
than Idaho
Land boundaries: total: 2,949 km
border countries: Brazil 1,606 km,
Suriname 600 km, Venezuela 743 km
Coastline: 459 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the outer
edge of the continental margin
Climate: tropical; hot, humid, moderated
by northeast trade winds; two rainy seasons
(May to August, November to January)
Terrain: mostly rolling highlands; low
coastal plain; savanna in south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, dia¬
monds, hardwood timber, shrimp, fish
Land use: arable land: 2.23%
permanent crops: 0.14%
other: 97.63% (2005)
Irrigated land: 1,500 sq km (2003)
Total renewable water resources: 241
cu km (2000)
Freshwater withdrawal (domestic
/industrial/agricultural): total: 1.64 cu
km/yr (2%/l%/98%)
per capita: 2,187 cu m/yr (2000)
Natural hazards: flash floods are a con¬
stant threat during rainy seasons
Environment— current issues: water
pollution from sewage and agricultural
and industrial chemicals; deforestation
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the
selected agreements
Geography— note: the third-smallest
country in South America after Suriname
and Uruguay; substantial portions of its
western and eastern territories are claimed
by Venezuela and Suriname respectively','bc71956dbf7fb0bc84491ca0a12bd41e189a39889ad524a2b47ed7914b680845','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('466456754f7efefca83edbda242fc009e0f7298dc1b509ecea28742f2d8ec738',2009,'ID','Indonesia','communications',229,'_
Telephones— main lines in use: 80,200
(2006)
Telephones— mobile cellular: 254,000
(2006)
Telephone system:
general assessment: service throughout
the country is excellent; international
service is good to Southeast Asia, Middle
East, Western Europe, and the US
domestic: every service available
international: country code— 673;
landing point for the SEA-ME-WE-3
optical telecommunications submarine
cable that provides links to Asia, the
Middle East, and Europe; the Asia-
America Gateway submarine cable net¬
work, scheduled for completion by late
2008, will provide new links to Asia and
the US; satellite earth stations — 2
Intelsat (1 Indian Ocean and 1 Pacific
Ocean) (2007)
Radio broadcast stations: AM 1, FM 2
(transmitting on 18 different frequen¬
cies), shortwave 0 (British Forces
Broadcasting Service (BFBS) station
transmits two FM signals with English
and Nepali service) (2006)
Radios: 329,000 (1998)
Television broadcast stations: 4
(includes 2 UHF stations broadcasting a
subscription service) (2006)
Televisions: 201,900 (1998)
Internet country code: bn
Internet hosts: 15,347 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 165,600 (2006)
Airports: 2 (2007)
Airports— with paved runways: total: 1
over 3,047 m: 1 (2007)
Airports— with unpaved runways:
total: 1
9 14 to 1,523 m: 1 (2007)
Heliports: 3 (2007)
Pipelines: gas 672 km; oil 463 km
(2007)
Roadways:
total: 3,650 km
paved: 2,819 km
unpaved: 831 km (2005)
Waterways: 209 km (navigable by craft
drawing less than 1.2 m) (2007)
Merchant marine:
total: 8 ships (1000 GRT or over)
465,937 GRT/413,393 DWT
by type: liquefied gas 8
foreign''owned: 8 (UK 8) (2007)
Ports and terminals: Lumut, Muara,
Seria
Military branches: Royal Brunei Armed
Forces (RBAF): Royal Brunei Land
Forces, Royal Brunei Navy, Royal Brunei
Air Force (Tentera Udara Diraja Brunei)
(2008)
Military service age and obligation: 18
years of age (est.) for voluntary military
service; non-Malays are ineligible to
serve (2007)
99
THE CIA WORLD FACTBOOK
Manpower available for military
service:
males age 16-49: 108,356
females age 16-49: 110,153 (2008 est.)
Manpower fit for military service:
males age 16-49: 91,297
females age 16-49: 93,228 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 3,223
females age 16-49: 3,182 (2008 est.)
Military expenditures— percent of
GDP: 4.5% (2006)
Disputes— international: Brunei and
Malaysia are still considering interna¬
tional adjudication over their disputed
offshore and deepwater seabeds, where
hydrocarbon exploration was terminated
in 2003 international legal adjudication;
Malaysia’s land boundary with Brunei
around Limbang is in dispute; Brunei
established an exclusive economic
fishing zone encompassing Louisa Reef
in the southern Spratly Islands in 1984,
but makes no public territorial claim to
the offshore reefs; the 2002 “Declaration
on the Conduct of Parties in the South
China Sea” has eased tensions in the
Spratly Islands but falls short of a legally
binding “code of conduct” desired by
several of the disputants
Illicit drugs: drug trafficking and ille¬
gally importing controlled substances are
serious offenses in Brunei and carry a
mandatory death penalty
Telephones— main lines in use: 14 821
million (2006)
Telephones — mobile cellular: 63.803
million (2006)
Telephone system:
general assessment: domestic service fair,
international service good
domestic: interisland microwave system
and HF radio police net; domestic satel¬
lite communications system; coverage
provided by existing network has been
expanded by use of over 200,000 tele¬
phone kiosks many located in remote
areas
international: country code — 62; landing
point for both the SEA-ME-WE-3 AND
SEA-ME-WE-4 submarine cable net¬
works that provide links throughout
Asia, the Middle East, and Europe; satel¬
lite earth stations — 2 Intelsat (1 Indian
Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 678, FM
43, shortwave 82 (1998)
Radios: 31.5 million (1997)
Television broadcast stations: 54 local
TV stations (11 national TV networks;
each with its group of local transmitters)
(2006)
Televisions: 13.75 million (1997)
Internet country code: id
Internet hosts: 559,359 (2007)
Internet Service Providers (ISPs): 24
(2000)
Internet users: 16 million (2005)
Telephones— main lines in use: 21.981
million (2006)
Telephones— mobile cellular: 13.659
million (2006)
Telephone system:
general assessment: currently being mod¬
ernized and expanded with the goal of
not only improving the efficiency and
increasing the volume of the urban
service but also bringing telephone
service to several thousand villages, not
presently connected
domestic: the addition of new fiber cables
and modern switching and exchange sys¬
tems installed by Iran’s state-owned
telecom company have improved and
expanded the main line network greatly;
main line availability has more than dou¬
bled to 22 million lines since 2000; addi¬
tionally, mobile service has increased
dramatically serving nearly 13.7 million
subscribers in 2006
international: country code — 98; subma¬
rine fiber-optic cable to UAE with access
to Fiber-Optic Link Around the Globe
(FLAG); Trans-Asia-Europe (TAE)
fiber-optic line runs from Azerbaijan
through the northern portion of Iran to
Turkmenistan with expansion to Georgia
and Azerbaijan; HF radio and microwave
radio relay to Turkey, Azerbaijan,
Pakistan, Afghanistan, Turkmenistan,
Syria, Kuwait, Tajikistan, and
Uzbekistan; satellite earth stations — 13
(9 Intelsat and 4 Inmarsat) (2006)
Radio broadcast stations: AM 72, FM
5, shortwave 5 (1998)
Radios: 17 million (1997)
Television broadcast stations: 28 (plus
450 repeaters) (1997)
Televisions: 4.61 million (1997)
Internet country code: ir
Internet hosts: 6,111 (2007)
Internet Service Providers (ISPs): 100
(2002)
Internet users: 18 million (2006)
Telephones— main lines in use: 2,500
(2006)
Telephones— mobile cellular: 49,100
(2006)
Telephone system:
general assessment: rudimentary service
limited to urban areas
domestic: system suffered significant
damage during the violence associated
with independence; extremely limited
fixed-line services; mobile-cellular serv¬
ices and coverage limited primarily to
urban areas
international: country code — 670; inter¬
national service is available in major
urban centers
Radio broadcast stations: at least 21
(Timor-Leste has one national public
broadcaster and 20 community and
church radio stations — frequency type
NA)
Radios: NA
Television broadcast stations: 1
(Timor-Leste has one national public
broadcaster)
Televisions: NA
Internet country code: tl
Internet hosts: 94 (2007)
Internet Service Providers (ISPs): NA
Internet users: 1,000 (2004)','0c4905923eb9f75cc2402d05e7c6062cd387ee97b068a59c91df695685b9e489','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da1e0b0eb08563f625fb3132ff8c2f471fb622f440535794cb038b793df3b779',2009,'BG','Bulgaria','communications',234,'Telephones— main lines in use: 2.399
million (2006)
Telephones— mobile cellular: 8.253
million (2006)
Telephone system:
general assessment: an extensive but anti¬
quated telecommunications network
inherited from the Soviet era; quality has
improved; the Bulgaria Telecom¬
munications Company’s fixed-line
monopoly terminated in 2005 when
alternative fixed-line operators were
given access to its network; a drop in
fixed-line connections in recent years
has been offset by a sharp increase in
mobile-cellular telephone use fostered by
multiple service providers
domestic: a fairly modem digital cable
trunk line now connects switching cen¬
ters in most of the regions; the others are
connected by digital microwave radio
relay
international: country code — 359; subma¬
rine cable provides connectivity to
Ukraine and Russia; a combination sub¬
marine cable and land fiber-optic system
provides connectivity to Italy, Albania,
and Macedonia; satellite earth stations —
3 ( 1 Intersputnik in the Atlantic Ocean
region, 2 Intelsat in the Atlantic and
Indian Ocean regions) (2007)
Radio broadcast stations: AM 31, FM
63, shortwave 2 (2001)
Radios: 4.51 million (1997)
Television broadcast stations: 39 (plus
1,242 repeaters) (2001)
Televisions: 3.31 million (1997)
Internet country code: bg
Internet hosts: 298,781 (2007)
Internet Service Providers (ISPs): 200
(2001)
Internet users: 1.87 million (2006)','3d0da3580982489f69f2693b1643258dbff41c2e20e54e469618abce844a9ae8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2dc8cfea83ebd19edfe473dd8fac0ef9e6dca6a62dff9aac1f8add3bb33414d',2009,'BF','Burkina Faso','communications',242,'_ _
Telephones — main lines in use: 94,800
(2006)
105
THE CIA WORLD FACTBOOK
Telephones— mobile cellular: 1.017
million (2006)
Telephone system:
general assessment: services only fair; in
2006 the government sold a 51 percent
stake in the national telephone company
and ultimately plans to retain only a 23
percent stake in the company; fixed-line
connections stand at less than 1 per 100
persons; mobile-cellular usage, fostered
by multiple providers, is increasing rap¬
idly from a low base
domestic: microwave radio relay, open-
wire, and radiotelephone communica¬
tion stations
international: country code — 226; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 2, FM
26, shortwave 3
Radios: 394,020 (2000)
Television broadcast stations: 3 (1
national, 2 private)
Televisions: 131,340 (2002)
Internet country code: bf
Internet hosts: 193 (2007)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 80,000 (2006)
Airports: 33 (2007)
Airports— with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2007)
Airports — with unpaved runways:
total: 31
1,524 to 2,437 m: 3
914 to 1 ,523 m: 1 1
under 914 m: 17 (2007)
Railways:
total: 622 km
narrow gauge: 622 km 1.000-m gauge
note: another 660 km of this railway
extends into Cote D’Ivoire (2006)
Roadways:
total: 92,495 km
paved: 3,857 km
unpaved: 88,638 km (2004)
Telephones— main lines in use:
503,900 (2005)
Telephones — mobile cellular: 214,200
(2006)
Telephone system:
general assessment: meets minimum
requirements for local and intercity
service for business and government;
international service is good
domestic: system capable of providing
basic service; cellular mobile phone
system functions more efficiently than
traditional lines
international: country code — 95; landing
point for the SEA-ME-WE-3 optical
telecommunications submarine cable
that provides links to Asia, the Middle
East, and Europe; satellite earth sta¬
tions — 2, Intelsat (Indian Ocean), and
ShinSat (2007)
Radio broadcast stations: AM 1, FM 2,
shortwave 3 (2007)
Radios: 4.2 million (1997)
Television broadcast stations: 4 (2008)
Televisions: 320,000 (2000)
Internet country code: mm
Internet hosts: 101 (2007)
Internet Service Providers (ISPs): 1
note: as of September 2000, Internet
connections were legal only for the gov¬
ernment, tourist offices, and a few large
businesses (2000)
Internet users: 31,500 (2005)','3b735ea98b11de9c240b2b185ae36e4c4242fea52dfd2b136c5c7f5292850353','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1991bc8cc70e28576f8ed666dc8b7909e175bde8376e6321f315d20df6bd8315',2009,'BI','Burundi','communications',250,'Telephones— main lines in use: 31,100
(2005)
Telephones— mobile cellular: 153,000
(2005)
Telephone system:
general assessment: primitive system; tele¬
phone density one of the lowest in the
world; fixed-line connections stand at
well less than 1 per 100 persons; mobile-
cellular usage is increasing but remains at
a meager 2 per 100 persons
domestic: sparse system of open- wire,
radiotelephone communications, and
low-capacity microwave radio relay
112
international: country code — 257; satel¬
lite earth station — 1 Intelsat (Indian
Ocean) (2007)
Radio broadcast stations: AM 0, FM 4,
shortwave 1 (2001)
Radios: 440,000 (2001)
Television broadcast stations: 1 (2001)
Televisions: 25,000 (1997)
Internet country code: bi
Internet hosts: 163 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 60,000 (2006)','49813c101b53260c3a837b7f3d2d6c100fbab7456196da428164ee1c1716be8a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37ec192e1874c9be07fdd517d0f0aecf1b0313c4d5cc37f9753e612aef2e9335',2009,'KH','Cambodia','communications',256,'Telephones— main lines in use: 32,800
(2006)
Telephones— mobile cellular: 1.14 mil¬
lion (2006)
Telephone system:
general assessment: mobile-phone systems
are widely used in urban areas to bypass
deficiencies in the fixed-line network;
fixed-line connections stand at well less
than 1 per 100 persons; mobile-cellular
usage, aided by increasing competition
among service providers, is increasing
and stands at about 8 per 100 persons
domestic: adequate landline and/or cel¬
lular service in Phnom Penh and other
provincial cities; mobile-phone coverage
is rapidly expanding in rural areas
international: country code — 855; ade¬
quate but expensive landline and cellular
service available to all countries from
Phnom Penh and major provincial cities;
satellite earth station — 1 Intersputnik
(Indian Ocean region) (2007)
Radio broadcast stations: AM 2, FM
17, shortwave NA (2003)
Radios: 1.34 million (1997)
Television broadcast stations: 9
(including 2 TV relay stations with
French and Vietnamese broadcasts);
excludes 18 regional relay stations
(2006)
Televisions: 94,000 (1997)
Internet country code: kh
Internet hosts: 941 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 44,000 (2005)
116','273d0bd419ef52a53ee2e7041a9e961f8079f2925cd3905b8263b4ea02cd3c8c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5862fc65a26ecf4054d96a6b2f8e15cf1e8d0d0e865795df18745e0f34c0e32f',2009,'CA','Canada','communications',271,'Telephones— main lines in use: 71,600
(2006)
Telephones — mobile cellular: 108,900
(2006)
Telephone system:
general assessment: effective system,
extensive modernization from
1996-2000 following partial privatiza¬
tion in 1995
domestic: major service provider is Cabo
Verde Telecom (CVT); fiber-optic ring,
completed in 2001, links all islands pro¬
viding Internet access and ISDN serv¬
ices; cellular service introduced in 1998;
broadband services launched in 2004
international: country code — 238;
landing point for the Atlantis-2 fiber¬
optic transatlantic telephone cable that
provides links to South America,
Senegal, and Europe; HF radiotelephone
to Senegal and Guinea-Bissau; satellite
earth station — 1 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 0, FM 22
(plus 12 repeaters), shortwave 0 (2001)
Radios: 100,000 (2002 est.)
Television broadcast stations: 1 (plus 7
repeaters) (2001)
Televisions: 15,000 (2002 est.)
Internet country code: cv
Internet hosts: 344 (2007)
Internet Service Providers (ISPs): l
(2002)
Internet users: 29,000 (2005)','7b813c707842f26d45ab1c4342c59b00f7d5e4d58c9c689684823865ad3c4bb7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb64d240f42fccf8ea376209eb24b1752171a4a786759474efa8ab43d3ff13c',2009,'KY','Cayman Islands','communications',277,'Telephones — main lines in use: 38,000
(2002)
Telephones— mobile cellular: 17,000
(2002)
Telephone system:
general assessment: reasonably good
system
domestic: liberalization of telecom
market in 2003; introduction of competi¬
tion in the mobile-cellular market in
2004
international: country code — 1-345;
landing point for the MAYA-1 subma¬
rine telephone cable network that pro¬
vides links to the US and parts of
Central and South America; submarine
cable provides connectivity to Jamaica;
satellite earth station— 1 Intelsat
(Atlantic Ocean) (2007)
Radio broadcast stations: AM l, FM 4,
shortwave 0 (2004)
Radios: 36,000 (1997)
Television broadcast stations: 4 with
cable system (2004)
Televisions: 7,000 (1997)
Internet country code: ky
Internet hosts: 4,888 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 9,909 (2003)','d26c4792a20689f052bac0006d79981e5aa10044a3b5c332763ab5948ea377d9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81d6b9d417327fdd6e4fc768c56a4d699319585f0821364ba7df16521e940e92',2009,'TD','Chad','communications',286,'Telephones— main lines in use: 12,000
(2006)
Telephones— mobile cellular: 110,000
(2006)
Telephone system:
general assessment: limited telephone
service; fixed-line connections for well
less than 1 per 100 persons coupled with
mobile-cellular usage of only about 3 per
100 persons
domestic: network consists principally of
microwave radio relay and low-capacity,
low-powered radiotelephone communi¬
cation
international: country code — 236; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM l, FM 5,
shortwave 1 (2001)
Radios: 283,000 (1997)
Television broadcast stations: l (2001)
Televisions: 18,000 (1997)
Internet country code: cf
Internet hosts: 15 (2007)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 13,000 (2006)
Telephones — main lines in use: 13,000
(2006)
Telephones — mobile cellular: 466,100
(2006)
Telephone system:
general assessment: primitive system with
high costs and low telephone density
domestic: fair system of radiotelephone
communication stations
international: country code — 235; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 2, FM 4,
shortwave 5 (2001)
Radios: 1.67 million (1997)
Television broadcast stations: l (2001)
Televisions: 10,000 (1997)
Internet country code: td
Internet hosts: 72 (2007)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 60,000 (2006)
Airports: 55 (2007)
Airports— with paved runways: total: 7
over 3,047 m: 2
2,438 to 3,047 m; 3
1 ,524 to 2,437 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways: total: 48
1 ,524 to 2,437 m: 16
9 14 to 1 ,523 m: 21
under 914 m: 11 (2007)
Pipelines: oil 250 km (2007)
Roadways:
total: 33,400 km
paved: 267 km
unpaved: 33,133 km (2000)
Waterways: Chari and Legone rivers are
navigable only in wet season (2006)','85c9be4dd47691797ac8581b5bcc465057953d0b376a0aa0db9fdce67cb29d81','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9f0e3598974553dc4cba9eddf459248f81d571c50f32791b2ba81b74b5d921f',2009,'CL','Chile','communications',301,'Telephones — main lines in use: 3.326
million (2006)
Telephones — mobile cellular: 12.451
million (2006)
Telephone system:
general assessment: privatization began in
1988; advanced telecommunications
infrastructure; modern system based on
extensive microwave radio relay facilities;
fixed-line connections have dropped in
recent years as mobile-cellular usage con¬
tinues to increase, reaching a level of 75
telephones per 100 persons
domestic: extensive microwave radio
relay links; domestic satellite system with
3 earth stations
international: country code — 56; subma¬
rine cables provide links to the US and
to Central and South America; satellite
earth stations — 2 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 180 (8
inactive), FM 64, shortwave 17 (1 inac¬
tive) (1998)
Radios: 5.18 million (1997)
Television broadcast stations: 63 (plus
121 repeaters) (1997)
Televisions: 3.15 million (1997)
Internet country code: cl
Internet hosts: 745,375 (2007)
Internet Service Providers (ISPs): 7
(2000)
Internet users: 4.156 million (2006)','e526fdfb36c12c39f91014efdec80eae93be9a158b47ad1f101e81cca88fab8f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52c6159b2025f913302f9fee42d11febdeb0f4c280454b1aa51e5756afc145cb',2009,'CN','China','communications',311,'Telephones — main lines in use: 368
million (2006)
Telephones — mobile cellular: 461.1
million (2006)
Telephone system:
general assessment: domestic and interna¬
tional services are increasingly available
for private use; unevenly distributed
domestic system serves principal cities,
industrial centers, and many towns;
China continues to develop its telecom¬
munications infrastructure, and is part¬
nering with foreign providers to expand
its global reach; 3 of China’s 6 major
telecommunications operators are part of
an international consortium which, in
December 2006, signed an agreement
with Verizon Business to build the first
next-generation fiber optic submarine
cable system directly linking the US
mainland and China
domestic: interprovincial fiber-optic
trunk lines and cellular telephone sys¬
tems have been installed; mobile-cellular
subscribership is increasing rapidly; the
number of internet users reached 162
million in 2007; a domestic satellite
system with 55 earth stations is in place
international: country code — 86; a
number of submarine cables provide con¬
nectivity to Asia, the Middle East,
Europe, and the US; satellite earth sta¬
tions — 7 (5 Intelsat — 4 Pacific Ocean
and 1 Indian Ocean, 1 Intersputnik —
Indian Ocean region, and 1 Inmarsat —
Pacific and Indian Ocean regions)
(2007)
Radio broadcast stations: AM 369, FM
259, shortwave 45 (1998)
Radios: 417 million (1997)
Television broadcast stations: 3,240 (of
which 209 are operated by China
Central Television, 3 1 are provincial TV
stations, and nearly 3,000 are local city
stations) (1997)
Televisions: 400 million (1997)
Internet country code: cn
Internet hosts: 10.637 million (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 162 million (2007)','567ff0bedfd53ac94eb40b530191257b4d3a2facaa71a5129448e4f5783658db','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4258c59e45d929f0e136d35946a53d7ed495bbc0fb40188723b12186e190c7d',2009,'CX','Christmas Island','communications',317,'_ _
Telephones — main lines in use: NA
Telephone system:
general assessment: service provided by
the Australian network
domestic: GSM mobile telephone service
replaced older analog system in February
2005
international: country code — 61-8; satel¬
lite earth station — 1 (Intelsat provides
telephone and telex service) (2005)
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (2006)
Radios: 1,000 (1997)
Television broadcast stations: 0 (TV
broadcasts received via satellite from
mainland Australia) (2006)
Televisions: 600 (1997)
Internet country code: ex
143
THE CIA WORLD FACTBOOK
Internet hosts: 1,826 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 464 (2001)','0158c57b14488140f730b82e6a04381c7882bb0a3d2643d093401f86e523754a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6972c119484518a4ac03000e18b3dde2bdac6bad2adedd5ab542145de4ee6ad',2009,'CC','Cocos (Keeling) Islands','communications',329,'Telephones— main lines in use: 287
(1992)
Telephone system:
general assessment: connected within Aus¬
tralia’s telecommunication system; a local
mobile-cellular network is in operation
domestic: NA
international: country code — 61; tele¬
phone, telex, and facsimile communica¬
tions with Australia and elsewhere via
satellite; satellite earth station — 1
(Intelsat) (2001)
Radio broadcast stations: AM l, FM 2,
shortwave 0 (2004)
Radios: 300 (1992)
Television broadcast stations: 4 (2007)
Televisions: NA
Internet country code: cc
Internet Service Providers (ISPs): 2
(2000)
Internet users: NA
Airports: 1 (2007)
145
THE CIA WORLD FACTBOOK
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways: total: 22 km
paved: 10 km
unpaved: 12 km (2006)
Ports and terminals: Port Refuge
Military — note: defense is the responsi-
bility of Australia; the territory has a
five-person police force','472b0561c3d6fdc6fb930a234effade855bae5f233b4e90af0cc7f5b01ad80a7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f395d6255b7536d0bf99b7b62d40511c1e7bad21b8a310d10d7f497d171db0b3',2009,'CO','Colombia','communications',332,'Telephones — main lines in use: 7.865
million (2006)
Telephones — mobile cellular: 29.763
million (2006)
Telephone system:
general assessment: modern system in
many respects; telecommunications
sector liberalized during the 1990s; mul¬
tiple providers of both fixed-line and
mobile-cellular services; fixed-line con¬
nections stand at about 18 per 100 per¬
sons; mobile cellular usage is about 70
per 100 persons
domestic: nationwide microwave radio
relay system; domestic satellite system
with 41 earth stations; fiber-optic net¬
work linking 50 cities
international: country code — 57; subma¬
rine cables provide links to the US, parts
of the Caribbean, and Central and South
America; satellite earth stations — 10 (6
Intelsat, 1 Inmarsat, 3 fully digitalized
international switching centers) (2007)
Radio broadcast stations: AM 454, FM
34, shortwave 27 (1999)
Radios: 21 million (1997)
Television broadcast stations: 60 (1997)
Televisions: 4.59 million (1997)
Internet country code: co
Internet hosts: 1.014 million (2007)
Internet Service Providers (ISPs): 18
(2000)
Internet users: 6.705 million (2006)','db5abd2bd1960691e6b7489e31333858bceedb9781bb6bbbac77c4e02cb97e6d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95328b3334dcc6384b6a044a505de72ba9f6fcabd302b6e6897e34a0d2a401a9',2009,'CG','Congo','communications',346,'Telephones— main lines in use: 15,900
(2005)
Telephones — mobile cellular: 490,000
(2005)
Telephone system:
general assessment: services barely ade¬
quate for government use; key exchanges
are in Brazzaville, Pointe-Noire, and
Loubomo; intercity lines frequently out
of order; fixed-line infrastructure inade¬
quate providing less than 1 connection
per 100 persons; mobile-cellular sub-
scribership has surged reaching 16 per
100 persons
domestic: primary network consists of
microwave radio relay and coaxial cable
international: country code — 242; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean)
157
THE CIA WORLD FACTBOOK
Radio broadcast stations: AM 1, FM 5,
shortwave 3 (2001)
Radios: 341,000 (1997)
Television broadcast stations: 1 (2001)
Televisions: 33,000 (1997)
Internet country code: eg
Internet hosts: 3 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 70,000 (2006)
Airports: 31 (2007)
Airports — with paved runways:
total: 5
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2007)
Airports— with unpaved runways:
total: 26
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 9 (2007)
Pipelines: gas 89 km; liquid petroleum
gas 4 km; oil 758 km (2007)
Railways:
total: 894 km
narrow gauge: 894 km 1.067''m gauge
(2006)
Roadways:
total: 17,289 km
paved: 864 km
unpaved: 16,425 km (2004)
Waterways: 1,125 km (commercially
navigable on Congo and Oubanqui
rivers) (2006)
Merchant marine:
registered in other countries: 1 (Congo,
Democratic Republic of the 1) (2007)
Ports and terminals: Brazzaville, Djeno,
Impfondo, Ouesso, Oyo, Pointe-Noire','b202aadf94f2922a6e3bd3ae1900d7277e1d382cb4ccdb48522e8b20ed97fe48','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22d8d8124e6d9192617c5ad3153877348e96843ba5e3809bddfacb2c74d46e6',2009,'CK','Cook Islands','communications',352,'Telephones — main lines in use: 6,200
(2002)
Telephones— mobile cellular: 1,500
(2002)
Telephone system:
general assessment: Telecom Cook Islands
offers international direct dialing,
Internet, email, fax, and Telex
domestic: individual islands are con¬
nected by a combination of satellite
earth stations, microwave systems, and
VHF and HF radiotelephone; within the
islands, service is provided by small
exchanges connected to subscribers by
open-wire, cable, and fiber-optic cable
international: country code — 682; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (2004)
Radios: 14,000 (1997)
Television broadcast stations: l (outer
islands receive satellite broadcasts)
(2004)
Televisions: 4,000 (1997)
Internet country code: ck
Internet hosts: 1,479 (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 3,600 (2002)','4acb8bae95d66686466df1fb4168c24f1707057bfc46f4efbc8f5d5d961ee59c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2aac068c4b560da1b8d8d90bc9ca124c0c3a5c4aa83727da034fa7bb2843ab2',2009,'CR','Costa Rica','communications',365,'Telephones — main lines in use: 1.351
million (2006)
Telephones — mobile cellular: 1.444
million (2006)
163
THE CIA WORLD FACTBOOK
Telephone system:
general assessment: good domestic tele¬
phone service in terms of breadth of cov¬
erage; restricted cellular telephone
service; state-run monopoly provider is
struggling with the demand for new
lines, resulting in long waiting times
domestic: point-to-point and point-to-
multi-point microwave, fiber-optic, and
coaxial cable link rural areas; Internet
service is available
international: country code — 506;
landing point for the Americas Region
Caribbean Ring System (ARCOS-1)
fiber-optic telecommunications subma¬
rine cable and the MAYA-1 submarine
cable that provide links to South and
Central America, parts of the Caribbean,
and the US; connected to Central
American Microwave System; satellite
earth stations — 2 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 65, FM
51, shortwave 19 (2002)
Radios: 980,000 (1997)
Television broadcast stations: 20 (plus
43 repeaters) (2002)
Televisions: 525,000 (1997)
Internet country code: cr
Internet hosts: 13,792 (2007)
internet Service Providers (ISPs): 3 (of
which only one is legal) (2000)
Internet users: 1.214 million (2006)','03ceb13c77b360e3399b69547da72aee678dd381b362d19219eb459129b09a0d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('704ca076cbfcb15d144e70746401ca5bfd88c5cd753274f4008c32c40895e12b',2009,'HR','Croatia','communications',367,'Telephones— main lines in use:
260,900 (2006)
Telephones — mobile cellular: 4.065
million (2006)
Telephone system:
general assessment: well developed by
African standards; telecommunications
sector privatized in late 1990s; mobile
cellular usage has increased to 23 per 100
persons; fixed-line connections stand at
about 2 per 100 persons
domestic: open-wire lines and microwave
radio relay; 90% digitalized
international: country code — 225;
landing point for the SAT-3/WASC
fiber-optic submarine cable that provides
connectivity to Europe and Asia; satel¬
lite earth stations — 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean) (2007)
Radio broadcast stations: AM 2, FM 9,
shortwave 3 (1998)
Radios: 2.26 million (1997)
Television broadcast stations: 14
(1998)
Televisions: 1.09 million (2000)
Internet country code: .d
Internet hosts: 1,373 (2007)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 300,000 (2006)
Telephones— main lines in use: 1.832
million (2006)
Telephones— mobile cellular: 4 47 mil¬
lion (2006)
Telephone system:
general assessment: the telecommunica¬
tions network has improved steadily
since the mid-1990s; the number of fixed
telephone lines has increased to about 40
per 100 persons; virtually 100 mobile cel¬
lular telephones per 100 persons
domestic: more than 90 percent of local
lines are digital
international: country code — 385; digital
international service is provided through
the main switch in Zagreb; Croatia par¬
ticipates in the Trans-Asia-Europe
(TEL) fiber-optic project, which consists
of 2 fiber-optic trunk connections with
Slovenia and a fiber-optic trunk line
from Rijeka to Split and Dubrovnik; the
ADRIA-1 submarine cable provides con¬
nectivity to Albania and Greece (2007)
Radio broadcasf sfafions: AM 16, FM
98, shortwave 5 (1999)
Radios: 1.51 million (1997)
Television broadcasf sfafions: 36 (plus
321 repeaters) (1995)
Televisions: 1.22 million (1997)
Intemef counfry code: hr
Infernef hosts: 261,954 (2007)
Internet Service Providers (ISPs): 9
(2000)
Internet users: 1.576 million (2006)','5f84e74e6b696b2fd80b0a8c12d2f197b8ab87309aba53adf15b8ffb09f667a7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e2c2da7d5d21b369a4ccf08cdc9835a736716173c66f0f7f84b16ae5452c93e',2009,'CU','Cuba','communications',381,'Telephones— main lines in use:
972,900 (2006)
Telephones — mobile cellular: 152,700
(2006)
Telephone system:
general assessment: greater investment
beginning in 1 994 and the establishment
of a new Ministry of Information
Technology and Communications in
2000 has resulted in improvements in
the system; wireless service is expensive
and must be paid in convertible pesos
which effectively limits mobile cellular
subscribership
domestic: national fiber-optic system
under development; 95% of switches dig¬
itized by end of 2006; fixed telephone
line density remains low, at less than 10
per 100 inhabitants; domestic cellular
service expanding but remains at only
about 2 per 100 persons
international: country code — 53; fiber¬
optic cable laid to but not linked to US
network; satellite earth station 1
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 169, FM
55, shortwave 1 (1998)
Radios: 3.9 million (1997)
Television broadcast stations: 58
(1997)
Televisions: 2.64 million (1997)
Internet country code: cu
Internet hosts: 3,388 (2007)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 240,000
note: private citizens are prohibited from
buying computers or accessing the
Internet without special authorization;
foreigners may access the Internet in
large hotels but are subject to firewalls;
some Cubans buy illegal passwords on
the black market or take advantage of
173
THE CIA WORLD FACTBOOK
public outlets to access limited email and
the government-controlled “intranet”
(2006)
Airports: 165 (2007)
Airports — with paved runways:
total: 70
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m: 18
914 to 1,523 m: 5
under 914 m: 31 (2007)
Airports— with unpaved runways:
total: 95
1 ,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 71 (2007)
Pipelines: gas 49 km; oil 230 km (2007)
Railways:
total: 4,226 km
standard gauge: 4,226 km 1.435-m gauge
( 140 km electrified)
note: an additional 7,742 km of track is
used by sugar plantations; about 65% of
this track is standard gauge; the rest is
narrow gauge (2006)
Roadways:
total: 60,858 km
paved: 29,820 km (includes 638 km of
expressway)
unpaved: 31,038 km (2000)
Waterways: 240 km (2007)
Merchant marine:
total: 12 ships (1000 GRT or over)
35,030 GRT/5 1,388 DWT
by type: bulk carrier 2, cargo 3, chemical
tanker 1, passenger 1, petroleum tanker
3, refrigerated cargo 2
foreign''owned: 1 (Spain 1)
registered in other countries: 16 (Bahamas
1, Cyprus 2, Netherlands Antilles 1,
Panama 11, Spain 1) (2007)
Ports and terminals: Cienfuegos,
Havana, Matanzas','e1b0e2721ca1dca951be4693391442f6c63dae4ff847f6626a03af1c78da8e1d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c44100829f318e2b1ff1409de3b438ba9cdd5accc17eddae16b1c964ea79ccd',2009,'CY','Cyprus','communications',388,'Telephones— main lines in use: area
under government control: 408,300
(2006); area administered by Turkish
Cypriots: 86,228 (2002)
Telephones— mobile cellular: area
under government control: 777,500
(2006); area administered by Turkish
Cypriots: 143,178 (2002)
Telephone system:
general assessment: excellent in both area
under government control and area
administered by Turkish Cypriots
domestic: open-wire, fiber-optic cable,
and microwave radio relay
international: country code — 357 (area
administered by Turkish Cypriots uses
the country code of Turkey — 90); a
number of submarine cables, including
the SEA-ME-WE-3, combine to provide
connectivity to Western Europe, the
Middle East, and Asia; tropospheric
scatter; satellite earth stations — 8 (3
Intelsat — 1 Atlantic Ocean and 2 Indian
Ocean, 2 Eutelsat, 2 Intersputnik, and 1
Arabsat)
Radio broadcast stations: area under
government control: AM 5, FM 76, short¬
wave 0
area administered by Turkish Cypriots: AM
1, FM 20, shortwave 1 (2004)
Radios: Greek Cypriot
Area: 310,000 (1997); Turkish Cypriot
Area: 56,450 (1994)
Television broadcast stations: area
under government control: 8
area administered by Turkish Cypriots: 2
(plus 4 relay) (2004)
Televisions: Greek Cypriot Area:
248,000 (1997); Turkish Cypriot Area:
52,300 (1994)
Internet country code: cy
Internet hosts: 36,964 (2007)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 356,600 (2006)','5b1d90f613b2b9727a6ef116c0d51ac0ab3556353842e256c20491a8cd503a7e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d8ee26c0ee5fa183122671f6c686b6373265e077977e8b514669ebf5685fbd',2009,'DE','Germany','communications',395,'Telephones— main lines in use: 2.888
million (2006)
Telephones — mobile cellular: 12.408
million (2006)
Telephone system:
general assessment: privatization and
modernization of the Czech telecommu¬
nication system got a late start but is
advancing steadily; access to the fixed-
line telephone network expanded
throughout the 1990s; mobile telephone
usage increased sharply beginning in the
mid-1990s and there are now about 120
mobile telephones per 100 persons
domestic: 93% of exchanges now digital;
existing copper subscriber systems
enhanced with Asymmetric Digital
Subscriber Line (ADSL) equipment to
accommodate Internet and other digital
signals; trunk systems include fiber-optic
cable and microwave radio relay
international: country code — 420; satel¬
lite earth stations — 6 (2 Intersputnik —
Atlantic and Indian Ocean regions, 1
Intelsat, 1 Eutelsat, 1 Inmarsat, 1
Globalstar) (2007)
Radio broadcast stations: AM 31, FM
304, shortwave 17 (2000)
Radios: 3,159,134 (December 2000)
Television broadcast stations: 150 (plus
1,434 repeaters) (2000)
Televisions: 3,405,834 (December
2000)
Internet country code: cz
Internet hosts: 1.668 million (2007)
Internet Service Providers (ISPs): more
than 300 (2000)
Internet users: 3.541 million (2006)
Telephones— main lines in use: 54.2
million (2006)
Telephones— mobile cellular: 84.3 mil¬
lion (2006)
Telephone system:
general assessment: Germany has one of
the world’s most technologically
advanced telecommunications systems;
as a result of intensive capital expendi¬
tures since reunification, the formerly
backward system of the eastern part of
the country, dating back to World War
II, has been modernized and integrated
with that of the western part
domestic: Germany is served by an exten¬
sive system of automatic telephone
exchanges connected by modern net¬
works of fiber-optic cable, coaxial cable,
microwave radio relay, and a domestic
satellite system; cellular telephone
service is widely available, expanding
rapidly, and includes roaming service to
many foreign countries
international: country code — 49;
Germany’s international service is excel¬
lent worldwide, consisting of extensive
land and undersea cable facilities as well
as earth stations in the Inmarsat,
Intelsat, Eutelsat, and Intersputnik satel¬
lite systems (2001)
Radio broadcast stations: AM 51, FM
787, shortwave 4 (1998)
Radios: 77.8 million (1997)
Television broadcast stations: 373 (plus
8,042 repeaters) (1995)
Televisions: 51.4 million (1998)
Internet country code: de
Internet hosts: 16.494 million (2007)
Internet Service Providers (ISPs): 200
(2001)
Internet users: 38.6 million (2006)','9b9e8a2dcf25582e6a1056dd0f801ac4516c40e6bd03b20fc94f7229c46e29c6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c933d538a02ee75e41d5f59c9767d191b557b47794fb6135cd7b7b462170abe',2009,'DK','Denmark','communications',403,'Telephones — main lines in use: 3.098
million (2006)
Telephones— mobile cellular: 5.841
million (2006)
Telephone system:
general assessment: excellent telephone
and telegraph services
domestic: buried and submarine cables
and microwave radio relay form trunk
network, 4 cellular mobile communica¬
tions systems
international: country code — 45; a series
of fiber-optic submarine cables link
Denmark with Canada, Faroe Islands,
Germany, Iceland, Netherlands, Norway,
Poland, Russia, Sweden, and UK; satel¬
lite earth stations — 18 (6 Intelsat, 10
Eutelsat, 1 Orion, 1 Inmarsat (Blaavand-
Atlantic-East)); note — the Nordic coun¬
tries (Denmark, Finland, Iceland,
Norway, and Sweden) share the Danish
earth station and the Eik, Norway, sta¬
tion for worldwide Inmarsat access
Radio broadcast stations: AM 2, FM
355, shortwave 0 (1998)
Radios: 6.02 million (1997)
Television broadcast stations: 26 (plus
51 repeaters) (1998)
Televisions: 3.121 million (1997)
Internet country code: dk
Internet hosts: 3.114 million (2007)
Internet Service Providers (ISPs): 13
(2000)
Internet users: 3.171 million (2006)
Airports: 91 (2007)
Airports— with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047m: 7
1 ,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 63
914 to 1,523 m: 3
under 914 m: 60 (2007)
Pipelines: condensate 11 km; gas 4,073
km; oil 617 km; oil/gas/water 2 km
(2007)
Railways:
total: 2,644 km
standard gauge: 2,644 km 1.435-m gauge
(636 km electrified) (2007)
Roadways:
total: 72,362 km
paved: 72,362 km (includes 1,032 km of
expressways) (2006)
Waterways: 400 km (2007)
Merchant marine:
total: 299 ships (1000 GRT or over)
8,767,265 GRT/1 0,604,081 DWT
by type: bulk carrier 7, cargo 64, chemical
tanker 57, container 84, liquefied gas 2,
livestock carrier 2, passenger 1, pas¬
senger/cargo 41, petroleum tanker 22,
refrigerated cargo 7, roll on/roll off 8,
specialized tanker 4
foreign''Otuned: 25 (Canada 1, Germany
13, Greece 4, Greenland 1, Norway 1,
Sweden 4, UK 1 )
registered in other countries: 468 (Antigua
and Barbuda 15, Bahamas 66, Belgium 3,
Brazil 2, Cayman Islands 3, Cyprus 1,
Egypt 1, Estonia 2, France 3, Gibraltar 9,
Hong Kong 12, Isle of Man 41, Italy 2,
Jamaica 1, Liberia 12, Lithuania 9, Malta
10, Marshall Islands 9, Mexico 2,
Netherlands 19, Netherlands Antilles 1,
Norway 26, Panama 32, Portugal 3,
Singapore 68, South Africa 1, Spain 2,
St Vincent and The Grenadines 16,
Sweden 4, UK 61, US 29, Venezuela 3)
(2007)
Ports and terminals: Aalborg, Aarhus,
Copenhagen, Ensted, Esbjerg, Fredericia,
Kalundborg
185
THE CIA WORLD FACTBOOK
Military branches: Defense Command:
Army Operational Command, Admiral
Danish Fleet, Island Command
Greenland, Tactical Air Command,
Home Guard (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscripts serve an ini''
tial training period that varies from 4 to
12 months according to specialization;
reservists are assigned to mobilization
units following completion of their con¬
script service; women eligible to volun¬
teer for military service (2004)
Manpower available for military
service:
males age 16-49: 1,235,067
females age 16-49: 1,215,418 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,012,716
females age 16-49: 996,436 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 36,561
females age 16—49: 34,603 (2008 est.)
Military expenditures— percent of
GDP: 1.5% (2006; 1.28% 2007 est.)','7dbe76c1d626b276be9e1fceb4e27d4d558c89fb8d5daa2df032c8ba549c21b7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e2377cf61702065ff0afbdf94ad16bb2103d57337caad3c451b92ffe850f4d',2009,'GL','Greenland','communications',407,'Radio broadcast stations: AM NA, FM
1 (located in Akrotiri), shortwave NA
(British Forces Broadcasting Service
(BFBS) provides Radio 1 and Radio 2
service to Akrotiri, Dhekelia, and
Nicosia) (2006)
Television broadcast stations: 0 (British
Forces Broadcasting Service (BFBS) pro¬
vides multi-channel satellite service to
Akrotiri, Dhekelia, and Nicosia) (2006)
Military — note: includes Dhekelia
Garrison and Ayios Nikolaos Station
connected by a roadway
186
Background: The French Territory of the
Afars and the Issas became Djibouti in
1977. Hassan Gouled APTIDON
installed an authoritarian one-party state
and proceeded to serve as president until
1999. Unrest among the Afars minority
during the 1990s led to a civil war that
ended in 2001 following the conclusion
of a peace accord between Afar rebels
and the Issa-dominated government. In
1999, Djibouti’s first multi-party presi¬
dential elections resulted in the election
of Ismail Omar GUELLEH; he was re¬
elected to a second and final term in
2005. Djibouti occupies a strategic geo¬
graphic location at the mouth of the Red
Sea and serves as an important transship¬
ment location for goods entering and
leaving the east African highlands. The
present leadership favors close ties to
France, which maintains a significant
military presence in the country, but also
has strong ties with the US. Djibouti
hosts the only US military base in sub-
Saharan Africa and is a front-line state
in the global war on terrorism.
Telephones— main lines in use: 25,300
(2002)
Telephones— mobile cellular: 32,200
(2004)
Telephone system:
general assessment: adequate domestic
and international service provided by
satellite, cables and microwave radio
relay; totally digitalized in 1995
domestic: microwave radio relay and
satellite
international: country code — 299; satel¬
lite earth stations — 15 (12 Intelsat, 1
Eutelsat, 2 Americom GE-2 (all Atlantic
Ocean)) (2000)
Radio broadcast stations: AM 5, FM
12, shortwave 0 (1998)
Radios: 30,000 (1998 est.)
Television broadcast stations: l (plus
some local low-power stations, and 3
Armed Forces Radio and Television
Service (AFRTS) stations (1997)
Televisions: 30,000 (1998 est.)
Internet country code: gl
Internet hosts: 15,329 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 38,000 (2005)
264','f1906a68656076daf16b414c984866244d8ad2eb9fef4e0683b3d1489fb61d9d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d936da05277275f44516e332c86b9cbabafd33e9181e27d8756ad3732a20d2',2009,'DM','Dominica','communications',411,'Telephones— main lines in use: 10,800
(2005)
Telephones — mobile cellular: 44,100
(2005)
Telephone system:
general assessment: telephone facilities in
the city of Djibouti are adequate, as are
the microwave radio relay connections
to outlying areas of the country
domestic: microwave radio relay network;
mobile cellular coverage is limited to the
area in and around Djibouti city
international: country code — 253;
landing point for the SEA-ME-WE-3
optical telecommunications submarine
cable with links to Asia, the Middle East,
and Europe; satellite earth stations — 2 ( 1
Intelsat — Indian Ocean and 1 Arabsat);
Medarabtel regional microwave radio
relay telephone network
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (2001)
Radios: 52,000 (1997)
Television broadcast stations: 1 (2001)
Televisions: 28,000 (1997)
Internet country code: dj
Internet hosts: 168 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: li.ooo (2006)
Telephones— main lines in use: 21,000
(2004)
Telephones— mobile cellular: 41,800
(2004)
Telephone system:
general assessment: NA
domestic: fully automatic network
international: country code — 1-767;
landing point for the East Caribbean
Fiber Optic System (ECFS) submarine
cable with links to 13 other islands in the
eastern Caribbean extending from the
British Virgin Islands to Trinidad;
microwave radio relay and SHF
radiotelephone links to Martinique and
Guadeloupe; VHF and UHF radiotele¬
phone links to Saint Lucia
Radio broadcast stations: AM 2, FM 4,
shortwave 0 (2003)
Radios: 46,000 (1997)
Television broadcast stations: 1 (2004)
Televisions: 6,000 (1997)
Internet country code: dm
Internet hosts: 257 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 26,000 (2005)','8abb859271c9b2826668352025dab6a8cb6623572897140a9e90f831df141b50','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5f948026c394212db5bf9d4d7cbb902aa48dfba64e866333113488f9411f8b1',2009,'DO','Dominican Republic','communications',424,'Telephones — main lines in use:
897,000 (2006)
Telephones— mobile cellular: 4 606
million (2006)
Telephone system:
general assessment: relatively efficient
system based on island-wide microwave
radio relay network
domestic: fixed telephone line density is
about 10 per 100 persons; multiple
providers of mobile cellular service with
a subscribership of roughly 50 per 100
persons
international: country code — 1-809;
landing point for the Americas Region
Caribbean Ring System (ARCOS-1)
fiber-optic telecommunications subma-
194
rine cable that provides links to South
and Central America, parts of the
Caribbean, and US; satellite earth sta¬
tion — 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM
56, shortwave 4 (1998)
Radios: 1.44 million (1997)
Television broadcast stations: 25
(2003)
Televisions: 770,000 (1997)
internet country code: do
Internet hosts: 81,218 (2007)
Internet Service Providers (ISPs): 24
(2000)
Internet users: 1.232 million (2006)','901b97b41ac2698bdb920704dcafacfede148472e0c65dd500f006c29a9f0e41','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f18f4ebe5402d499eb0640deac23a5ac90d8d03b225bfe47b1ebe3991491408',2009,'EC','Ecuador','communications',430,'Telephones— main lines in use: 1.754
million (2006)
Telephones— mobile cellular: 8 485
million (2006)
Telephone system:
general assessment: generally elementary
but being expanded
domestic: fixed-line services provided by
three state-owned enterprises; plans to
transfer the state-owned operators to pri¬
vate ownership have repeatedly failed;
fixed-line density stands at about 13 per
100 persons; mobile cellular use has
surged and has a subscribership of nearly
65 per 100 persons
international: country code — 593;
landing point for the PAN -AM subma¬
rine telecommunications cable that pro¬
vides links to the west coast of South
America, Panama, Colombia, Venezuela,
and extending onward to Aruba and the
US Virgin Islands in the Caribbean;
satellite earth station — 1 Intelsat
(Atlantic Ocean) (2007)
Radio broadcasf sfations: AM 392, FM
35, shortwave 29 (2001)
Radios: 5 million (2001)
Television broadcasf sfafions: 7 (plus
14 repeaters) (2000)
Televisions: 2.5 million (2001)
Infernet counfry code: ec
Interne! hosts: 28,420 (2007)
Internet Service Providers (ISPs): 31
(2001)
Internet users: 1.549 million (2006)','66f995677a8a4c0a56f14811dc5463737a4bcac6ec37be499e3f0610e1b5774a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14ec8b2071696481531813a70848d0fb03707fb1a3d415cbc53d964410b619c2',2009,'EG','Egypt','communications',437,'Telephones— main lines in use: 10.808
million (2006)
Telephones— mobile cellular: 18.001
million (2006)
Telephone system:
general assessment: large system; under¬
went extensive upgrading during 1990s
and is reasonably modern; Telecom
Egypt, the landline monopoly, has been
increasing service availability and in
2006 fixed-line density stood at 14 per
100 persons; as of 2007 there were three
mobile-cellular networks and service is
expanding rapidly
domestic: principal centers at Alexandria,
Cairo, A1 Mansurah, Ismailia, Suez, and
Tanta are connected by coaxial cable and
microwave radio relay
international: country code — 20; landing
point for both the SEA-ME-WE-3 AND
SEA-ME-WE-4 submarine cable net¬
works; linked to the international sub¬
marine cable FLAG (Fiber-Optic Link
Around the Globe); satellite earth sta¬
tions — 4 (2 Intelsat — Atlantic Ocean
and Indian Ocean, 1 Arabsat, and 1
Inmarsat); tropospheric scatter to Sudan;
microwave radio relay to Israel; a partic¬
ipant in Medarabtel
Radio broadcast stations: AM 42 (plus
15 repeaters), FM 14, shortwave 3
(1999)
Radios: 20.5 million (1997)
Television broadcast stations: 98
(September 1995)
Televisions: 7.7 million (1997)
Internet country code: eg
Internet hosts: 5,363 (2007)
Internet Service Providers (ISPs): 50
(2000)
Internet users: 6 million (2006)','953197e5c2f378daa67d3f4012605983a00b2c42c6e554d2cfd6875f3b8f3cb7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a8f8369bd345fd205a638ac2b4f73c54d118b7f44ea21af11b3c6d3814dc2b1',2009,'SV','El Salvador','communications',441,'Telephones — main lines in use: 1.037
million (2006)
Telephones — mobile cellular: 3.852
million (2006)
Telephone system:
general assessment: the four mobile-cel¬
lular service providers are expanding
services rapidly and in 2006 mobile-cel¬
lular density stood at roughly 55 per 100
persons; growth in fixed-line services has
slowed in the face of mobile-cellular
competition
domestic: nationwide microwave radio
relay system
international: country code — 503; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 52, FM
144, shortwave 0 (2005)
Radios: 2.75 million (1997)
Television broadcast stations: 5 (1997)
Televisions: 600,000 (1990)
Internet country code: sv
Internet hosts: 12,519 (2007)
Internet Service Providers (ISPs): 4
(2000)
Internet users: 637,000 (2005)','9b34dc95632ca71d5c51e6328e7ec4e7754b6a86263045fa8e7f3121d7822e84','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71754258d85c65415cf6e7d2ad12650340f44855ac87f9f6d2eb6dad5d420d6f',2009,'ER','Eritrea','communications',455,'Telephones — main lines in use: 37,700
(2006)
Telephones — mobile cellular: 62,000
(2006)
Telephone system:
general assessment: inadequate
domestic: inadequate; most telephones
are in Asmara; government is seeking
international tenders to improve the
system (2002)
international: country code — 291; note —
international connections exist
Radio broadcast stations: AM 2, FM
NA, shortwave 2 (2000)
Radios: 345,000 (1997)
Television broadcast stations: 2 (2006)
Televisions: 1,000 (1997)
Internet country code: .er
Internet hosts: 1,446 (2007)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 100,000 (2006)','38c4cdc6e370401265193662c87ac70d71fec3629f330a560f398f0ee1fb8123','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4a1fd78bae38770e24992c331290e89372d44f251f40082f8137a7cfc82e87d',2009,'EE','Estonia','communications',460,'Telephones— main lines in use:
541,900 (2006)
Telephones— mobile cellular: 1.659
million (2006)
Telephone system:
general assessment: foreign investment in
the form of joint business ventures
greatly improved telephone service; sub¬
stantial fiber-optic cable systems carry
telephone, TV, and radio traffic in the
digital mode; Internet services are widely
available; schools and libraries are con¬
nected to the Internet, a large per¬
centage of the population files
income-tax returns online, and online
voting was used for the first time in the
2005 local elections
domestic: a wide range of high quality
voice, data, and Internet services is avail¬
able throughout the country
international: country code — 372; fiber¬
optic cables to Finland, Sweden, Latvia,
and Russia provide worldwide packet-
switched service; 2 international
switches are located in Tallinn (2001)
Radio broadcast stations: AM 0, FM
98, shortwave 0 (2001)
Radios: 1.01 million (1997)
Television broadcast stations: 3 (2001)
Televisions: 605,000 (1997)
Internet country code: ee
Internet hosts: 387,336 (2007)
Internet Service Providers (ISPs): 38
(2001)
Internet users: 760,000 (2006)','75014fe73a407bd03087e7ddf3fa737d1dac333c45f17627ff3e4f031801d804','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10a8f049cbf25926c88931208fb56e5570f8c5b901ed74f5232713d2e70d1697',2009,'ET','Ethiopia','communications',469,'Telephones— main lines in use:
725,000 (2006)
Telephones — mobile cellular: 866,700
(2006)
Telephone system:
general assessment: inadequate telephone
system; the number of fixed lines and
mobile telephones is increasing from a
very small base; combined fixed and
mobile-cellular teledensity is only about
2 per 1 00 persons
domestic: open-wire; microwave radio
relay; radio communication in the HF,
VHF, and UHF frequencies; 2 domestic
satellites provide the national trunk
service
international: country code — 251; open-
wire to Sudan and Djibouti; microwave
radio relay to Kenya and Djibouti; satel¬
lite earth stations — 3 Intelsat ( 1 Atlantic
Ocean and 2 Pacific Ocean)
Radio broadcast stations: AM 8, FM 0,
shortwave 1 (2001)
Radios: 15.2 million (2002)
Television broadcast stations: 1 (plus
24 repeaters) (2001)
Televisions: 682,000 (2002)
Internet country code: et
Internet hosts: 89 (2007)
217
THE CIA WORLD FACTBOOK
Internet Service Providers (ISPs): 1
(2002)
Internet users: 164,000 (2005)
Telephones — main lines in use: 2,400
(2002)
Telephones — mobile cellular: 0 (2001)
Telephone system:
general assessment: NA
domestic: government-operated radio¬
telephone and private VHF/CB radio¬
telephone networks provide effective
service to almost all points on both islands
international: country code — 500; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) with links through London to
other countries
Radio broadcast stations: AM 1, FM 7,
shortwave 0 (British Forces Broadcasting
Service (BFBS) provides Radio 1 and
Radio 2 service) (2006)
Radios: 1,000 (1997)
Television broadcast stations: 2 (British
Forces Broadcasting Service (BFBS) pro¬
vides multi-channel satellite service to
members of UK Forces as well as
islanders); cable television is available in
Stanley (2006)
Televisions: 1,000 (1997)
Internet country code: fk
Internet hosts: 104 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 1,900 (2002)','c6fbaface1551c71b31c9a4990d915dd64ea18a55747f65f146723d2f036e489','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48ecbfea63138709114feee59d87bd4ede32449bb8511db2a0a3bdb8a73bbc76',2009,'FO','Faroe Islands','communications',475,'Telephones— main lines in use: 23,000
(2006)
Telephones— mobile cellular: 50,000
(2006)
Telephone system:
general assessment: good international
communications; good domestic facili¬
ties
domestic: digitalization was completed in
1998; both NMT (analog) and GSM
(digital) mobile telephone systems are
installed
international: country code — 298; satel¬
lite earth stations — 1 Orion; 1 fiber-optic
submarine cable to the Shetland Islands,
linking the Faroe Islands with Denmark
and Iceland; fiber-optic submarine cable
connection to Canada-Europe cable
Radio broadcasf sfafions: AM l, FM
13, shortwave 0 (1998)
Radios: 26,000 (1997)
Television broadcasf sfafions: 3 (plus
43 repeaters) (September 1995)
Televisions: 15,000 (1997)
Internet country code: fo
Internet hosts: 8,490 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 34,000 (2006)','1950b63bf3c95a5051f2e969dbc2d7e68b7f4d56275f6d1a0cee149aef641abf','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef6a08fc3c17d1d206a6a11bd6fb6f96bffbd9fbdf307d92b086d5dc5919f935',2009,'FJ','Fiji','communications',483,'Telephones— main lines in use:
112,500 (2005)
Telephones— mobile cellular: 205,000
(2005)
Telephone system:
general assessment: modern local, interis-
land, and international (wire/radio inte¬
grated) public and special-purpose
telephone, telegraph, and teleprinter
facilities; regional radio communications
center
domestic: telephone or radio telephone
links to almost all inhabited islands;
most towns and large villages have auto¬
matic telephone exchanges and direct
dialing; combined fixed and mobile-cel¬
lular density is about 35 per 100 persons
international: country code — 679; access
to important cable links between US and
Canada as well as between NZ and
Australia; satellite earth stations — 2
Inmarsat (Pacific Ocean)
Radio broadcast stations: AM 13, FM
40, shortwave 0 (1998)
Radios: 541,476 (1999)
Television broadcast stations: NA
Televisions: 88,110 (1999)
Internet country code: fj
Internet hosts: 12,137 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 80,000 (2006)','a68e7dbd18f4c3bd3436c34967dca803c3c7e4fc902ccd1806e00ddc07be5b71','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d79f31713b324b166af546106a460085d65109ee623bcb3c8f9bfbf4a7273e6d',2009,'FI','Finland','communications',490,'Telephones— main lines in use: 1.92
million (2006)
Telephones— mobile cellular: 5.67 mil¬
lion (2006)
Telephone system:
general assessment: modern system with
excellent service
domestic: digital fiber-optic fixed-line
network and an extensive cellular net¬
work provide domestic needs
international: country code — 358; subma¬
rine cables provide links to Estonia and
Sweden; satellite earth stations — access
to Intelsat transmission service via a
Swedish satellite earth station, 1
Inmarsat (Atlantic and Indian Ocean
regions); note — Finland shares the
Inmarsat earth station with the other
Nordic countries (Denmark, Iceland,
Norway, and Sweden)
Radio broadcast stations: AM 2, FM
186, shortwave 1 (1998)
Radios: 7.7 million (1997)
Television broadcast stations: 120 (plus
431 repeaters) (1999); note — On 1
September 2007, Finland became one of
the first countries in the world to broad¬
cast all television signals digitally
Televisions: 3.2 million (1997)
Internet country code: fi; note— Aland
Islands assigned .ax
Internet hosts: 2.323 million (2007)
Internet Service Providers (ISPs): 3
(2002)
Internet users: 2.925 million (2006)','ff0c945d4a071e4130187ccf4cebd2ff0033a3bb3df884cf756385019eaa5c6d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa47b13a42c5da4db640e89696b1ef5c8f6e5d407dd151a0f096b0ec71a517c',2009,'PF','French Polynesia','communications',494,'Radio broadcast stations: AM 41, FM
about 3,500 (this figure is an approxima¬
tion and includes many repeaters), short¬
wave 2 (1998)
Radios: 55.3 million (1997)
Television broadcast stations: 584 (plus
9,676 repeaters) (1995)
Televisions: 34.8 million (1997)
Internet country code: metropolitan
France — .fr; French Guiana — .gf;
Guadeloupe — .gp; Martinique — .mq;
Reunion — .re
Internet hosts: 12.556 million;
12,555,000 (metropolitan France)
(2007)
Internet Service Providers (ISPs): 62
(2000)
Internet users: 31.295 million; 30.838
million (metropolitan France) (2007)
Telephones— main lines in use: 53,600
(2006)
Telephones — mobile cellular: 152,000
(2006)
Telephone system:
general assessment: NA
domestic: NA
international: country code — 689; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM
14, shortwave 2 (1998)
Radios: 128,000 (1997)
Television broadcast stations: 7 (plus
17 repeaters) (1997)
Televisions: 40,000 (1997)
Internet country code: pf
Internet hosts: 14,059 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 65,000 (2006)
Internet country code: tf
Internet hosts: 33 (2007)
Communications — note: one or more
meteorological stations on each posses¬
sion; note — meteorological station on
Tromelin Island (lies Eparses) is impor¬
tant for forecasting cyclones
Airports: 4 (one each on Europa Island,
Glorioso Islands, Juan de Nova Island,
and Tromelin Island in the lies Eparses
district) (2006)
Ports and terminals: none; offshore
anchorage only
Transportation— note: aids to naviga''
tion — lighthouses: Europa Island 18m;
Juan de Nova Island (W side) 37m;
Tromelin Island (NW point) 11m (all in
the lies Eparses district)','0bb59758c0bf7058f3e6a10d9084edad0700e7f066a21d15e4d6dabc0263befa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bce429688e24888801fc79bc9392a4858caefdaf5dd0ec3abe58006ab4555f86',2009,'GA','Gabon','communications',511,'Telephones— main lines in use: 36,500
(2006)
Telephones — mobile cellular: 764,700
(2006)
Telephone system:
general assessment: adequate service by
African standards and improving with
the help of a growing mobile cell net¬
work system with three providers;
mobile-cellular subscribership exceeded
50 per 100 persons in 2006
domestic: adequate system of cable,
microwave radio relay, tropospheric
scatter, radiotelephone communication
stations, and a domestic satellite system
with 12 earth stations
international: country code — 241;
landing point for the SAT-3/WASC
fiber-optic submarine cable that provides
connectivity to Europe and Asia; satel¬
lite earth stations — 3 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 6, FM 7
(plus 11 repeaters), shortwave 4 (2001)
Radios: 208,000 (1997)
Television broadcast stations: 4 (plus 4
repeaters) (2001)
Televisions: 63,000 (1997)
Internet country code: ga
Internet hosts: 288 (2007)
Internet Service Providers (ISPs): 1
(2001)
Internet users: 81,000 (2006)','c141d21f6a44890913f535cf7e12b7889075a23a20fb4cfd0a7503b1ad130d85','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47fc2e615b0b731d1f88c6c03c3f2e1675e811ee3c8aca17ad93789a1ee4748b',2009,'IL','Israel','communications',525,'Telephones — main lines in use:
349,000 (includes West Bank) (2005)
Telephones— mobile cellular: 1.095
million (includes West Bank) (2005)
Telephone system:
general assessment: NA
domestic: Israeli company BEZEK and
the Palestinian company PALTEL are
responsible for fixed line services; the
Palestinian JAWAL company provides
cellular services
international: country code — 970 (2004)
Radio broadcast stations: AM 0, FM
10, shortwave 0 (2008)
Radios: NA; note — most Palestinian
households have radios (1999)
Television broadcast stations: 1 (2008)
Televisions: NA; note— most
Palestinian households have televisions
(1997)
Internet country code: .ps; note — same
as West Bank
Internet Service Providers (ISPs): 3
(1999)
Internet users: 243,000 (includes West
Bank) (2005)
Telephones — main lines in use: 3.005
million (2006)
Telephones— mobile cellular: 8.404
million (2006)
Telephone system:
general assessment: most highly devel¬
oped system in the Middle East although
not the largest
domestic: good system of coaxial cable
and microwave radio relay; all systems are
digital; four privately-owned mobile-cel¬
lular service providers with countrywide
coverage; mobile-cellular teledensity is
more than 130 per 100 persons
international: country code — 972; subma¬
rine cables provide links to Europe,
Cyprus, and parts of the Middle East;
satellite earth stations — 3 Intelsat (2
Atlantic Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 23, FM
15, shortwave 2 (1998)
Radios: 3.07 million (1997)
Television broadcast stations: 17 (plus
36 repeaters) (1995)
Televisions: 1.69 million (1997)
Internet country code: il
Internet hosts: 671,030 (2007)
Internet Service Providers (ISPs): 21
(2000)
Internet users: 1.899 million (2006)','62bdb53b4776f975a54ce0967a51c8e0e1cb21ecd99e75b5da3e02c6aef11158','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c7e871f01c52d1408464818702bec7d5f51c0872f033dcb2ff9a2b5d508fc10',2009,'GR','Greece','communications',546,'Telephones— main lines in use: 24,512
(2002)
Telephones— mobile cellular: 9,797
(2002)
Telephone system:
general assessment: adequate, automatic
domestic system and adequate interna¬
tional facilities
domestic: automatic exchange facilities
international: country code — 350;
radiotelephone; microwave radio relay;
satellite earth station — 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (1998)
Radios: 37,000 (1997)
Television broadcast stations: l (plus 3
repeaters) (1997)
Televisions: 10,000 (1997)
Internet country code: gi
Internet hosts: 380 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 6,200 (2002)','5fac4242e3b2cad0ad1f8c7bb227f76b3d03d8fde5d3b6f30c65a2f8b34047bf','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489b85573d2210d2c73a637de76380fbee52c31887f61ba0c348f5913eb2f80b',2009,'GU','Guam','communications',558,'Telephones — main lines in use: 27,700
(2006)
Telephones— mobile cellular: 46,200
(2006)
Telephone system:
general assessment: automatic, islandwide
telephone system
domestic: interisland VHF and UHF
radiotelephone links
international: country code — 1-473;
landing point for the East Caribbean
Fiber Optic System (ECFS) submarine
cable with links to 13 other islands in the
eastern Caribbean extending from the
British Virgin Islands to Trinidad; SHF
radiotelephone links to Trinidad and
Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad
Radio broadcast stations: AM 2, FM
13, shortwave 0 (1998)
Radios: 57,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 33,000 (1997)
Internet country code: gd
Internet hosts: 7 (2007)
Internet Service Providers (ISPs): 14
(2000)
Internet users: 19,000 (2003)','1452821aae445c4bec8b7334e76129c26c64b464bd5590596c344e670b090b2c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8914209c19415aed6be315ab04510cd7d6a5ec1ca0d742248d6ae7d422553ad',2009,'GT','Guatemala','communications',564,'Telephones — main lines in use: 80,000
(2001)
Telephones — mobile cellular: 98,000
(2004)
Telephone system:
general assessment: modern system, inte¬
grated with US facilities for direct
dialing, including free use of 800 num¬
bers
domestic: modern digital system,
including cellular mobile service and
local access to the Internet
international: country code — 1-671;
major landing point for submarine cables
between Asia and the US (Guam is a
trans-Pacific communications hub for
major carriers linking the US and Asia);
satellite earth stations — 2 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 3, FM
11, shortwave 2 (2005)
Radios: 221,000 (1997)
Television broadcast stations: 3 (2006)
Televisions: 106,000 (1997)
Internet country code: gu
Internet hosts: 36 (2007)
Internet Service Providers (ISPs): 20
(2000)
Internet users: 65,000 (2005)
Airports: 5 (2007)
Airports— with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1 ,523 m: 1 (2007)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (2007)
Roadways:
total: 977 km (2004)
Ports and terminals: Apra Harbor
Military — note: defense is the responsi¬
bility of the US
Disputes — international: none
Background: The Mayan civilization
flourished in Guatemala and surrounding
regions during the first millennium A.D.
After almost three centuries as a Spanish
colony, Guatemala won its independ¬
ence in 1821. During the second half of
the 20th century, it experienced a variety
of military and civilian governments, as
well as a 36-year guerrilla war. In 1996,
the government signed a peace agree¬
ment formally ending the conflict, which
had left more than 100,000 people dead
and had created, by some estimates, some
1 million refugees.
Telephones— main lines in use: 1.355
million (2006)
Telephones— mobile cellular: 7.179
million (2006)
Telephone system:
general assessment: fairly modern network
centered in the city of Guatemala
domestic: state-owned telecommunica¬
tions company privatized in the late
1990s opening the way for competition;
fixed-line teledensity 11 per 100 persons;
mobile-cellular teledensity approaching
60 per 100 persons
international: country code — 502;
landing point for both the Americas
Region Caribbean Ring System
(ARCOS-1) and the SAM-1 fiber optic
submarine cable system that together
provide connectivity to South and
Central America, parts of the Caribbean,
and the US; connected to Central
American Microwave System; satellite
earth station — 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 130, FM
487, shortwave 15 (2000)
Radios: 835,000 (1997)
Television broadcast stations: 26 (plus
27 repeaters) (1997)
Televisions: 1.323 million (1997)
Internet country code: gt
Internet hosts: 40,927 (2007)
Internet Service Providers (ISPs): 5
(2000)
Internet users: 1.32 million (2006)','3f1bd7f90b50914c7200b03a23b2c2e4b6a660ec85b8341114e436b9bb94657d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec69823951a07db59dce55e44fedac8c5158a248aa9c47f0cd57bb3314df29eb',2009,'GG','Guernsey','communications',570,'Telephones— main lines in use: 45,100
(2005)
Telephones— mobile cellular: 43,800
(2004)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM l, FM 1,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Internet country code: gg
Internet hosts: 2,734 (2007)
Internet Service Providers (ISPs): NA
Internet users: 36,000 (2005)','ad199f0ac938c1c8f187a750bc01765f39b9ccf1dd695e46779b81ece32858b6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fc0e1a7a8b415a73da8b84838b393cf3d49afff89b330c9dbc470a43cb601bf',2009,'GW','Guinea-Bissau','communications',578,'Telephones— main lines in use: 10,200
(2005)
Telephones — mobile cellular: 95,000
(2005)
Telephone system:
general assessment: small system
domestic: combination of microwave
radio relay, open-wire lines, radiotele¬
phone, and cellular communications;
fixed-line teledensity less than 1 per 100
persons; mobile-cellular teledensity
reached 7 per 100 in 2005
international: country code — 245
Radio broadcast stations: AM 1 (trans¬
mitter out of service), FM 4, shortwave 0
(2001)
Radios: 49,000 (1997)
Television broadcast stations: NA
(2005)
Televisions: NA
Internet country code: gw
Internet hosts: 0 (2007)
Internet Service Providers (ISPs): 2
(2002)
Internet users: 37,000 (2006)
279
THE CIA WORLD FACTBOOK
Airports: 27 (2007)
Airports— with paved runways: total: 3
over 3,047 m: 1
l ,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Airports — with unpaved runways:
total: 24
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 4
under 914 m: 19 (2007)
Roadways:
total: 3,455 km
paved: 965 km
unpaved: 2,490 km (2002)
Waterways: rivers are navigable for some
distance; many inlets and creeks give
shallow-water access to much of interior
(2007)
Ports and terminals: Bissau, Buba,
Cacheu, Farim
Military branches: People’s Revo¬
lutionary Armed Force (FARP): Army,
Navy, Air Force; paramilitary force
Military service age and obligation: 18
years of age for selective compulsory mil¬
itary service (2006)
Manpower available for military
service:
males age 16-49: 344,087
females age 16-49: 347,886 (2008 est.)
Manpower fit for military service:
males age 16-49: 188,605
females age 16-49: 195,429 (2008 est.)
Military expenditures— percent of
GDP: 3.1% (2005 est.)
Disputes— international: in 2006, polit¬
ical instability within Senegal’s
Casamance region resulted in thousands
of Senegalese refugees, cross-border
raids, and arms smuggling into Guinea-
Bissau
Refugees and internally displaced per¬
sons: refugees (country of origin): 7,454
(Senegal) (2007)
Illicit drugs: increasingly important
transit country for South American
cocaine enroute to Europe; enabling
environment for trafficker operations
thanks to pervasive corruption; archi¬
pelago-like geography around the capital
facilitates drug smuggling
x & :','a55e47ef6835186b03ca51cebfb4c0471f16160994889ad355f19fadc9f9f0ec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c0163cddb5ade03eea8b3dc500e970af5afefd318fcf9659f2e6ede3da0029b',2009,'GY','Guyana','communications',579,'GEORGETOWN
^New Amsterdam
Bwamsa
Telephones — main lines in use:
110,100 (2005)
Telephones— mobile cellular: 281,400
(2005)
Telephone system:
general assessment: fair system, for long¬
distance service
domestic: microwave radio relay network
for trunk lines; fixed-line teledensity is
about 15 per 100 persons; many areas
still lack fixed-line telephone services;
mobile-cellular teledensity reached 37
per 100 persons in 2005
international: country code — 592; tropos¬
pheric scatter to Trinidad; satellite earth
station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3,
shortwave 1 (1998)
Radios: 420,000 (1997)
Television broadcast stations: 3 (1
public station; 2 private stations which
relay US satellite services) (1997)
Televisions: 46,000 (1997)
Internet country code: gy
Internet hosts: 3,000 (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 160,000 (2005)
Radio broadcast stations: AM 4, FM
18, shortwave 0 (2001)
Radios: 680,000 (1997)
Television broadcast stations: 6 (2005)
Televisions: 425,000 (1997)
Internet country code: tt
Internet hosts: 24,681 (2007)
Internet Service Providers (ISPs): 17
(2000)
Internet users: 163,000 (2005)
Airports: 6 (2007)
Airports— with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2007)
Pipelines: condensate 245 km; gas 1,320
km; oil 563 km (2007)
Roadways:
total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1999)
Merchant marine:
total: 9 ships ( 1000 GRT or over) 27,599
GRT/8,081 DWT
by type: passenger 2, passenger/cargo 5,
petroleum tanker 2
foreign^ owned: 1 (US 1)
registered in other countries : 1 (Bahamas 1,
unknown 1) (2007)
Ports and terminals: Point Fortin, Point
Lisas, Port-of-Spain
Telephones— main lines in use: 4.217
million (2006)
Telephones— mobile cellular: 18.79
million (2006)
Telephone system:
general assessment: modern and
expanding
domestic: domestic satellite system with 3
earth stations; recent substantial
improvement in telephone service in
rural areas; substantial increase in digi¬
talization of exchanges and trunk lines;
installation of a national interurban
fiber-optic network capable of digital
multimedia services; fixed-line teleden¬
sity is 16 per 100 persons; mobile-cellular
subscribership jumped 50 percent in
2006
international: country code — 58; subma¬
rine cable systems provide connectivity
to the Caribbean, Central and South
America, and US; satellite earth sta¬
tions — 1 Intelsat (Atlantic Ocean) and 1
PanAmSat; participating with
Colombia, Ecuador, Peru, and Bolivia in
the construction of an international
fiber-optic network
Radio broadcast stations: AM 201, FM
NA (20 in Caracas), shortwave 11
(1998)
Radios: 10.75 million (1997)
Television broadcast stations: 66 (plus
45 repeaters) (1997)
Televisions: 4.1 million (1997)
Internet country code: ve
Internet hosts: 126,500 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 4.14 million (2006)
i’lr.'' ... -•
Telephones— main lines in use: 10.8
million (2007)
Telephones— mobile cellular: 33.2 mil¬
lion (2007)
Telephone system:
general assessment: Vietnam is putting
considerable effort into modernization
and expansion of its telecommunication
system, but its performance continues to
lag behind that of its more modern
neighbors
domestic: all provincial exchanges are
digitalized and connected to Hanoi, Da
Nang, and Ho Chi Minh City by fiber¬
optic cable or microwave radio relay net¬
works; main lines have been
substantially increased, and the use of
mobile telephones is growing rapidly
international: country code— 84; a
landing point for the SEA-ME-WE-3,
the C2C, and Thailand-Vietnam-Hong
Kong submarine cable systems; the Asia-
America Gateway submarine cable
system, scheduled for completion by the
704
VIRGIN ISLANDS
end of 2008, will provide new access
links to Asia and the US; satellite earth
stations — 2 Intersputnik (Indian Ocean
region)
Radio broadcast stations: AM 65, FM
7, shortwave 29 (1999)
Radios: 8.2 million (1997)
Television broadcast stations: 67
(includes 61 relay, provincial, and city
TV stations) (2006)
Televisions: 3.57 million (1997)
Internet country code: vn
Internet hosts: 106,772 (2007)
Internet Service Providers (ISPs): 5
(2000)
Internet users: 17.87 million (2007)
Telephone system:
general assessment: satellite communica¬
tions; 2 DSN circuits off the Overseas
Telephone System (OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM 0,
shortwave 0 (Armed Forces
Radio/Television Service (AFRTS) radio
service provided by satellite (2005)
Television broadcast stations: 0 (2005)','3c88f37a99705a9cf467996053b275de559c0da69acc8086fbf424a823404272','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb0141f38dc6085d0ffcae538c9f9c06784debcf5b478b431d6e11c63c7c7c38',2009,'SR','Suriname','communications',580,'lethem
» too tea
Telephones— main lines in use: NA
Telephone system:
general assessment: probably adequate
domestic: local telephone service
international: country code — 47-790;
satellite earth station — 1 of unknown
type (for communication with
Norwegian mainland only)
Radio broadcast stations: AM l, FM l
(plus 2 repeaters), shortwave 0 (1998)
Radios: NA
Television broadcast stations: NA
Televisions: NA
Internet country code: sj
Internet Service Providers (ISPs): 13
(Svalbard and Jan Mayen) (2000)
Internet users: NA','f0c8972559c492247b11d012ac9f4fbae872b40fc302cd79d5f2ce6b2592a4bb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02ceb7606eaf6bbb47bf0cfc0daed8367d7bcb3e5c44c97e6a141a42a216eb8b',2009,'HT','Haiti','communications',591,'Telephones— main lines in use:
145,300 (2005)
Telephones — mobile cellular: 500,200
(2005)
Telephone system:
general assessment: domestic facilities
barely adequate; international facilities
slightly better; telephone density in
Haiti remains the lowest in the Latin
American and Caribbean region
domestic: coaxial cable and microwave
radio relay trunk service; combined fixed
and mobile-cellular teledensity is about 8
per 100 persons
international: country code — 509; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 41, FM
26, shortwave 0 (1999)
Radios: 415,000 (1997)
Television broadcast stations: 2 (plus a
cable TV service) (1997)
Televisions: 38,000 (1997)
Internet country code: ht
Internet hosts: 7 (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 650,000 (2006)
Airports: 14 (2007)
Airports— with paved runways: total: 4
285
THE CIA WORLD FACTBOOK
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2007)
Airports— with unpaved runways:
total: 10
9 14 to 1,523 m: 1
under 914 m: 9 (2007)
Roadways:
total: 4,160 km
paved: 1,011 km
unpaved: 3,149 km (2000)
Ports and terminals: Cap-Haitien
Military branches: no regular military
forces — small Coast Guard; the regular
Haitian Armed Forces (FAdH) — Army,
Navy, and Air Force — have been demo¬
bilized but still exist on paper unless they
are constitutionally abolished (2007)
Manpower available for military
service: males age 16-49: 2,047,083
females age 16—49: 2,047,953 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,303,743
females age 16—49: 1,332,316 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 105,655
females age 16—49: 104,376 (2008 est.)
Military expenditures— percent of
GDP: 0.4% (2006)','f344d6333af7470e615638eb82fcbb58f0a225b0f97235293b756378604c48b8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aafa6a4ad1f874327e1b86ec758a60c2d81313cfd6b5e2d9f03f44e6f7dbe72',2009,'HM','Heard Island and McDonald Islands','communications',598,'internet country code: hm
Telephones — main lines in use: 5,120
(2005)
Telephone system:
general assessment: automatic digital
exchange
domestic: connected via fiber optic cable
to Telecom Italia network
international: country code — 39; uses
Italian system
Radio broadcast stations: AM 4, FM 3,
shortwave 2 (2004)
Radios: NA
Television broadcast stations: l (2005)
Televisions: NA
Internet country code: va
Internet hosts: 20 (2007)
Internet Service Providers (ISPs): NA
Internet users: 93 (2000)
Military branches: Pontifical Swiss
Guard (Corpo della Guardia Svizzera
Pontificia) (2007)
Military — note: defense is the responsi¬
bility of Italy; ceremonial and limited
security duties performed by Pontifical
Swiss Guard','81aa864476d9104ad1ac14a99bea89a85a5da0dc3edaf9b65a2f4341d0533b5c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a9181eb18b90b3a42190062bdfa4dd485c78ce2975e920121e8419108fa277e',2009,'HK','Hong Kong','communications',608,'Telephones— main lines in use:
708,400 (2006)
Telephones — mobile cellular: 2.241
million (2006)
Telephone system:
general assessment: inadequate system
domestic: beginning in 2003, private sub-
operators allowed to provide fixed-lines
in order to expand telephone coverage;
fixed-line teledensity has increased to
about 10 per 100 persons; mobile-cellular
telephone service has been increasing
rapidly and subscribership in 2006
exceeded 30 per 100 persons
international: country code — 504;
landing point for both the Americas
Region Caribbean Ring System
(ARCOS-1) and the MAYA-1 fiber
optic submarine cable system that
together provide connectivity to South
and Central America, parts of the
Caribbean, and the US; satellite earth
stations — 2 Intelsat (Atlantic Ocean);
connected to Central American
Microwave System
Radio broadcast stations: AM 241, FM
53, shortwave 12 (1998)
Radios: 2.45 million (1997)
Television broadcast stations: ll (plus
17 repeaters) (1997)
Televisions: 570,000 (1997)
Internet country code: hn
Internet hosts: 4,672 (2007)
Internet Service Providers (ISPs): 8
(2000)
Internet users: 337,300 (2006)
Telephones— main lines in use: 3.87
million (2007)
Telephones— mobile cellular: 9.913
million (2007)
Telephone system:
general assessment: modern facilities pro¬
vide excellent domestic and interna¬
tional services
domestic: microwave radio relay links and
extensive fiber-optic network
international: country code — 852; mul¬
tiple international submarine cables pro¬
vide connections to Asia, US, Australia,
the Middle East, and Western Europe;
satellite earth stations — 3 Intelsat (1
Pacific Ocean and 2 Indian Ocean);
coaxial cable to Guangzhou, China
Radio broadcast stations: AM 5, FM 9,
shortwave 0 (2004)
Radios: 4.45 million (1997)
Television broadcast stations: 55 (2 TV
networks, each broadcasting on 2 chan¬
nels) (2007)
Televisions: 1.84 million (1997)
Internet country code: hk
Internet hosts: 812,137 (2007)
Internet Service Providers (ISPs): 17
(2000)
Internet users: 3.77 million (2006)','6af4c8294d3ad206da6cf35c148cef87b63a9e68877f1745a5e7ee44e881cc3d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cb27f872725d2cfb10278a7396e817ff984e8f9418543ae9d6f7b7224caecfd',2009,'HU','Hungary','communications',620,'Telephones — main lines in use: 3.35
million (2006)
Telephones — mobile cellular: 9.965
million (2006)
Telephone system:
general assessment: the telephone system
has been modernized and is capable of
satisfying all requests for telecommunica¬
tion service
domestic: the system is digitalized and
highly automated; trunk services are car¬
ried by fiber-optic cable and digital
microwave radio relay; a program for
fiber-optic subscriber connections was
initiated in 1996; competition among
mobile-cellular service providers has led
to a sharp increase in the use of mobile
cellular phones since 2000 and a
decrease in the number of fixed-line con¬
nections
international: country code — 36; Hungary
has fiber-optic cable connections with all
neighboring countries; the international
switch is in Budapest; satellite earth sta¬
tions — 2 Intelsat (Atlantic Ocean and
Indian Ocean regions), 1 Inmarsat, 1
very small aperture terminal (VSAT)
system of ground terminals
Radio broadcast stations: AM 17, FM
57, shortwave 3 (1998)
Radios: 7.01 million (1997)
Television broadcast stations: 35 (plus
161 repeaters) (1995)
Televisions: 4.42 million (1997)
internet country code: hu
Internet hosts: 2.313 million (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 3.5 million (2006)
Airports: 46 (2007)
Airports— with paved runways:
total: 20
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 26
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 3
914 to 1,523 m: 11
under 914 m: 10 (2007)
Heliports: 5 (2007)
Pipelines: gas 4,397 km; oil 990 km;
refined products 335 km (2007)
Railways:
total: 8,057 km
broad gauge: 36 km 1.524-m gauge
standard gauge: 7,802 km 1.435-m gauge
(2,628 km electrified)
narrow gauge: 219 km 0.760-m gauge
(2006)
Roadways:
total: 159,568 km
paved: 70,050 km (30,874 km of
interurban roads including 626 km of
expressways)
unpaved: 89,518 km (2005)
Waterways: 1,622 km (most on Danube
River) (2007)
Ports and terminals: Budapest,
Dunaujvaros, Gyor-Gonyu, Csepel, Baja,
Mohacs (2003)
Military branches: Ground Forces,
Hungarian Air Force (Magyar Legiero,
ML) (2008)
Military service age and obligation: 18
years of age for voluntary military
service; conscription abolished in June
2004; 6-month service obligation, with
reserve obligation to age 50 (2006)
Manpower available for military
service:
males age 16-49: 2,391,400
females age 16-49: 2,337,24 0 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,890,105
females age 16—4 9: 1,943,422 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 62,197
females age 16—49: 59,267 (2008 est.)
Military expenditures— percent of
GDP: 1.75% (2005 est.)
Disputes — international: bilateral gov¬
ernment, legal, technical and economic
working group negotiations continue in
2006 with Slovakia over Hungary’s
failure to complete its portion of the
Gabcikovo-Nagymaros hydroelectric
dam project along the Danube; as a
member state that forms part of the EU’s
external border, Hungary has imple¬
mented the strict Schengen border rules
Illicit drugs: transshipment point for
Southwest Asian heroin and cannabis
and for South American cocaine des¬
tined for Western Europe; limited pro¬
ducer of precursor chemicals, particularly
for amphetamine and methampheta-
mine; efforts to counter money laun¬
dering, related to organized crime and
drug trafficking, are improving, but
remain vulnerable; significant consumer
of ecstasy
297','370ecbafd368e06f9522f9f7ce47cb8909338d9d6e9de83705a39895d7641504','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68fa1870b3fb2a6910274fa27af61cb8dec89d5d0a4d51161321b659c7618956',2009,'IS','Iceland','communications',621,'cV
o ,,4^ %
&f®&r;4wx$ Sm
X N- ■ •
.
Husavik
• : 3S
A<ik V
sk
<£C T
J^rundartangi
HalBaf^dr^ur^HEYKJAVI K
lo .t.l* ~ HVW
* Setioss
SeySHsljorflui;
Reydarfjdfftut*
item n/e^as
Kefiavi''k
''\\ ''$$$&&&&&*& k
VesSmarmaeyiar,
Srntm *>*»**
0 5C 100 ton
north Afimrtc
OCEAN
so w m
Background: Settled by Norwegian and
Celtic (Scottish and Irish) immigrants
during the late 9th and 10th centuries
A.D., Iceland boasts the world’s oldest
functioning legislative assembly, the
Althing, established in 930. Inde¬
pendent for over 300 years, Iceland was
subsequently ruled by Norway and
Denmark. Fallout from the Askja vol¬
cano of 1875 devastated the Icelandic
economy and caused widespread famine.
Over the next quarter century, 20% of
the island’s population emigrated, mostly
to Canada and the US. Limited home
rule from Denmark was granted in 1874
and complete independence attained in
1944. Literacy, longevity, income, and
social cohesion are first-rate by world
standards.
Location: Northern Europe, island
between the Greenland Sea and the
North Atlantic Ocean, northwest of the
UK
Geographic coordinates: 65 00 N, 18 00
W
Map references: Arctic Region
Area: total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Area— comparative: slightly smaller
than Kentucky
Land boundaries: 0 km
Coastline: 4,970 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: temperate; moderated by North
Atlantic Current; mild, windy winters;
damp, cool summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields; coast deeply
indented by bays and fiords
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,110 m
(at Vatnajokull glacier)
Natural resources: fish, hydropower,
geothermal power, diatomite
Land use:
arable land: 0.07%
permanent crops: 0%
other: 99.93% (2005)
Irrigated land: NA
Total renewable water resources: 170
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.17 cu
km/yr (34%/66%/0%)
per capita: 567 cu m/yr (2003)
Natural hazards: earthquakes and vol¬
canic activity
Environment— current issues: water
pollution from fertilizer runoff; inade¬
quate wastewater treatment
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Persistent Organic Pollutants,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Kyoto Protocol, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Transboundary Air Pollution,
Wetlands, Whaling
signed, but not ratified: Environmental
Modification, Marine Life Conservation
Geography — note: strategic location
between Greenland and Europe; west¬
ernmost European country; Reykjavik is
the northernmost national capital in the
world; more land covered by glaciers
than in all of continental Europe
Telephones — main lines in use:
193,700 (2006)
Telephones— mobile cellular: 328,500
(2006)
Telephone system:
general assessment: telecommunications
infrastructure is modern and fully digi¬
tized, with satellite-earth stations, fiber¬
optic cables, and an extensive broadband
network
domestic: liberalization of the telecom¬
munications sector beginning in the late
1990s has led to increased competition
especially in the mobile services segment
of the market
international: country code — 354; the
CANTATA and FARICE-1 submarine
cable systems provide connectivity to
Canada, the Faroe Islands, UK,
Denmark, and Germany; a planned new
section of the Hibemia-Atlantic subma¬
rine cable will provide additional con¬
nectivity to Canada, US, and Ireland;
satellite earth stations — 2 Intelsat
(Atlantic Ocean), 1 Inmarsat (Atlantic
and Indian Ocean regions); note —
Iceland shares the Inmarsat earth station
with the other Nordic countries
(Denmark, Finland, Norway, and
Sweden)
Radio broadcast stations: AM 3, FM
about 70 (including repeaters), short¬
wave 1 (1998)
Radios: 260,000 (1997)
Television broadcast stations: 14 (plus
156 repeaters) (1997)
Televisions: 98,000 (1997)
Internet country code: is
Internet hosts: 270,942 (2007)
Internet Service Providers (ISPs): 20
(2001)
Internet users: 194,000 (2006)','2357e884e24885359eb7a7fc71c30eb300f7ebd1d5f1f2a3ca7e26d63bf4b2ed','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24cfd73c250b8f86a33b5152e60416270f5e36020a666eb79ccd18f017cfa76',2009,'IN','India','communications',630,'Telephones— main lines in use: 49.75
million (2005)
Telephones — mobile cellular: 166.1
million (2006)
Telephone system:
general assessment: recent deregulation
and liberalization of telecommunications
laws and policies have prompted rapid
growth; local and long distance service
provided throughout all regions of the
country, with services primarily concen¬
trated in the urban areas; steady
improvement is taking place with the
recent admission of private and private-
public investors, but combined fixed and
mobile telephone density remains low at
about 20 for each 100 persons nation¬
wide and much lower for persons in rural
303
THE CIA WORLD FACTBOOK
areas; fastest growth is in cellular service
with modest growth in fixed lines
domestic: mobile cellular service intro¬
duced in 1994 and organized nationwide
into four metropolitan areas and 19
telecom circles each with about three
private service providers and one state-
owned service provider; in recent years
significant trunk capacity added in the
form of fiber-optic cable and one of the
world’s largest domestic satellite systems,
the Indian National Satellite system
(INSAT), with 6 satellites supporting
33,000 very small aperture terminals
(VSAT)
international: country code — 91; a
number of major international subma¬
rine cable systems, including Sea-Me-
We-3 with landing sites at Cochin and
Mumbai (Bombay), Sea-Me-We-4 with a
landing site at Chennai, Fiber-Optic
Link Around the Globe (FLAG) with a
landing site at Mumbai (Bombay), South
Africa — Far East (SAFE) with a landing
site at Cochin, the i2i cable network
linking to Singapore with landing sites at
Mumbai (Bombay) and Chennai
(Madras), and Tata Indicom linking
Singapore and Chennai (Madras), pro¬
vide a significant increase in the band¬
width available for both voice and data
traffic; satellite earth stations — 8 Intelsat
(Indian Ocean) and 1 Inmarsat (Indian
Ocean region); 9 gateway exchanges
operating from Mumbai (Bombay), New
Delhi, Kolkata (Calcutta), Chennai
(Madras), Jalandhar, Kanpur,
Gandhinagar, Flyderabad, and
Ernakulam
Radio broadcast stations: AM 153, FM
91, shortwave 68 (1998)
Radios: 116 million (1997)
Television broadcast stations: 562
(1997)
Televisions: 63 million (1997)
Internet country code: in
Internet hosts: 2.306 million (2007)
Internet Service Providers (ISPs): 43
(2000)
Internet users: 60 million (2005)
Airports: 346 (2007)
Airports — with paved runways:
total: 250
over 3,047 m: 18
2,438 to 3,047 m: 52
1,524 to 2,437 m: 75
914 to 1 ,523 m: 84
under 914 m: 21 (2007)
Airports— with unpaved runways:
total: 96
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1 ,523 m: 40
under 914 m: 47 (2007)
Heliports: 30 (2007)
Pipelines: condensate/gas 9 km; gas
7,488 km; liquid petroleum gas 1,861 km;
oil 7,883 km; refined products 6,422 km
(2007)
Railways:
total: 63,221 km
broad gauge: 46,807 km 1.676-m gauge
( 1 7,343 km electrified)
narrow gauge: 13,290 km 1.000-m gauge
(165 km electrified); 3,124 km 0.762-m
gauge and 0.610-m gauge (2006)
Roadways:
total: 3,383,344 km
paved: 1,603,705 km
unpaved: 1,779,639 km (2002)
Waterways: 14,500 km
note: 5,200 km on major rivers and 485
km on canals suitable for mechanized
vessels (2006)
Merchant marine:
total: 477 ships (1000 GRT or over)
8,350,093 GRT/14,339,440 DWT
by type: bulk carrier 101, cargo 220,
chemical tanker 18, combination ore/oil
1, container 9, liquefied gas 19, passenger
3, passenger/cargo 10, petroleum tanker
95, roll on/roll off 1
foreign''owned: 5 (China 1, Hong Kong 1,
UAE 2, UK 1)
registered in other countries: 54 (Barbados
1, Comoros 2, Cyprus 1, Dominica 2,
North Korea 1, Liberia 2, Malta 3,
Mauritius 2, Panama 25, Singapore 9, St
Kitts and Nevis 1, St Vincent and The
Grenadines 5, unknown 2) (2007)
Ports and terminals: Chennai, Haldia,
Jawaharal Nehru, Kandla, Kolkata
(Calcutta), Mormugao, Mumbai
(Bombay), New Mangalore,
V ishakhapatnam','7577c6a9f376bccca296819f12076555c2377ab7f239794d49dee19cc90c80ce','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36409ed0ef432429b35fc9734da821ede1a558cc453fe66c4a294d4d1ce686ab',2009,'IQ','Iraq','communications',640,'Telephones— main lines in use: 1.547
million (2005)
Telephones — mobile cellular: 10.9 mil¬
lion (2007)
Telephone system:
general assessment: the 2003 liberation of
Iraq severely disrupted telecommunica¬
tions throughout Iraq including interna¬
tional connections; widespread
government efforts to rebuild domestic
and international communications
through fiber optic links are in progress;
the mobile cellular market has expanded
rapidly with an estimated 10.9 million
current users
316','91331f547a28ae190c65a8d31e3a077efd6831471f4e5e32e01dc56027df1955','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c5efdec2dbd6ac7f3b73232404685adc47fe55948f4be799844c50c2cd4025',2009,'IE','Ireland','communications',641,'domestic: repairs to switches and lines
destroyed during 2003 continue; addi¬
tional switching capacity is improving
access; cellular service is available and
centered on 3 GSM networks which are
being expanded beyond their regional
roots, improving country-wide connec¬
tivity; wireless local loop licences have
been issued with the hope of overcoming
the lack of fixed-line infrastructure
international: country code — 964; satel¬
lite earth stations — 4 (2 Intelsat — 1
Atlantic Ocean and 1 Indian Ocean, 1
Intersputnik — Atlantic Ocean region,
and 1 Arabsat (inoperative)); local
microwave radio relay connects border
regions to Jordan, Kuwait, Syria, and
Turkey; planned international fiber-optic
connections to Iran (terrestrial) with a
link to the Fiber-Optic Link Around the
Globe (FLAG) submarine fiber-optic
cable (2007)
Radio broadcast stations: after 17
months of unregulated media growth,
there are approximately 80 radio stations
(types NA) on the air inside Iraq (2004)
Radios: 4.85 million (1997)
Television broadcast stations: 21
(2004)
Televisions: 1.75 million (1997)
internet country code: .iq
Internet hosts: 3 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 36,000 (2004)','0a1e9109919a39a4d0e54c9ff882c6dbf3ee474bed847d1440bd0bd8071eaabb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cb1dc974c3157f413a20b1be31430b7c4db6e28f0456e686e970d3f770a3e3a',2009,'IM','Isle of Man','communications',652,'Telephones— main lines in use: 51,000
(1999)
Telephone system:
general assessment: NA
domestic: landline, telefax, mobile cel¬
lular telephone system
international: fiber-optic cable,
microwave radio relay, satellite earth sta¬
tion, submarine cable
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 0
(receives broadcasts from the UK and
satellite) (1999)
Televisions: 27,490 (1999)
Internet country code: im
Internet hosts: 159 (2007)
Internet Service Providers (ISPs): NA
Internet users: NA','8e243081180e38cd4cc36e793edf8f68d0d2a16fb83c7674e121fd2eadf0ebcc','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dceb73720986ae386d2ce869362f97a91d6bd5469fcfa87cb2cf550db39bc74',2009,'IT','Italy','communications',660,'Telephones — main lines in use: 25.049
million (2005)
Telephones— mobile cellular: 71.5 mib
lion (2005)
Telephone system:
general assessment: modern, well devel¬
oped, fast; fully automated telephone,
telex, and data services
domestic: high-capacity cable and
microwave radio relay trunks
international: country code — 39; a series
of submarine cables provide links to
Asia, Middle East, Europe, North Africa,
and US; satellite earth stations — 3
Intelsat (with a total of 5 antennas — 3
for Atlantic Ocean and 2 for Indian
Ocean), 1 Inmarsat (Atlantic Ocean
region), and NA Eutelsat
Radio broadcast stations: AM about
100, FM about 4,600, shortwave 9
(1998)
Radios: 50.5 million (1997)
Television broadcast stations: 358 (plus
4,728 repeaters) (1995)
Televisions: 30.3 million (1997)
Internet country code: it
Internet hosts: 4.117 million (2007)
Internet Service Providers (ISPs): 93
(Italy and Holy See) (2000)
Internet users: 28.855 million (2006)','7d628c3d6556ab706694b9b6309393f7089923441482ca10e35ad65b1524733c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a05e3a25d334e041b799e3f934e804050f88ac52632f1ca3363cd88399e889a',2009,'JM','Jamaica','communications',667,'Telephones — main lines in use:
319,000 (2005)
Telephones— mobile cellular: 2.804
million (2005)
Telephone system:
general assessment: fully automatic
domestic telephone network
domestic: the 1999 agreement to open
the market for telecommunications serv¬
ices resulted in rapid growth in mobile-
cellular telephone usage; mobile-cellular
teledensity now exceeds 100 per 100 per¬
sons; the number of fixed-lines in use has
been declining
international: country code — 1-876; the
Fibralink submarine cable network pro¬
vides enhanced delivery of business and
broadband traffic and is linked to the
Americas Region Caribbean Ring
System (ARCOS-1) submarine cable in
the Dominican Republic; the link to
ARCOS-1 provides seamless connec¬
tivity to US, parts of the Caribbean,
Central America, and South America;
satellite earth stations — 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 10, FM
13, shortwave 0 (1998)
Radios: 1.215 million (1997)
Television broadcast stations: 7 (1997)
Televisions: 460,000 (1997)
Internet country code: jm
Internet hosts: 1,213 (2007)
Internet Service Providers (ISPs): 21
(2000)
Internet users: 1.232 million (2005)','05d0f575174635462e26ade85039c2ba12449c94b24e58a9a1b067ff08e5dc20','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc0aa7cfeeb97c86f2d978fa451fc8bc1ea2643bc5d8453274744efa8317522a',2009,'JP','Japan','communications',675,'Radio broadcast stations: NA; note —
there is one radio and meteorological sta¬
tion (1998)
Internet Service Providers (ISPs): 13
(Jan Mayen and Svalbard) (2000)','791c21cb95e00ef02f6332e662653a0b7dfd432a4dc8240c4f09797667d6fc69','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6552e8a94c2055f0c4759c705c19d7c08ce12b7f7c653c87fe19bb20561efd24',2009,'JE','Jersey','communications',684,'Telephones— main lines in use: 73,900
(2001)
Telephones— mobile cellular: 83,900
(2004)
Telephone system:
general assessment: NA
domestic: NA
international: submarine cable connec¬
tivity to Guernsey and UK
Radio broadcast stations: AM NA, FM
1, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: NA
Internet country code: je
Internet hosts: 2,219 (2007)
Internet Service Providers (ISPs): NA
Internet users: 27,000 (2005)','585be1f47740787b9fb70f136643722c661cbbebc54dd56f5593495e30baae96','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093538acb27b7febe99051dfa7efecb9a0ae306acc70ba680e8c20d9246af035',2009,'JO','Jordan','communications',691,'Telephones— main lines in use:
614,000 (2006)
Telephones — mobile cellular: 4.343
million (2006)
Telephone system:
general assessment: service has improved
recently with increased use of digital
switching equipment; microwave radio
relay transmission and coaxial and fiber¬
optic cable are employed on trunk lines;
growing mobile-cellular usage in both
urban and rural areas is reducing use of
fixed-line services; Internet penetration
remains modest and slow-growing
domestic: 1995 telecommunications law
opened all non-fixed-line services to pri¬
vate competition; in 2005, monopoly
over fixed-line services terminated and
the entire telecommunications sector
was opened to competition; mobile-cel¬
lular usage is increasing rapidly and tele¬
density is approaching 75 per 100
persons
international: country code — 962;
landing point for the Fiber-Optic Link
Around the Globe (FLAG) submarine
cable network that provides links to
Asia, Middle East, Europe; satellite earth
stations — 33 (3 Intelsat, 1 Arabsat, and
29 land and maritime Inmarsat termi¬
nals); fiber-optic cable to Saudi Arabia
and microwave radio relay link with
Egypt and Syria; participant in
Medarabtel
Radio broadcast stations: FM 31 (2007)
Radios: 1.66 million (1997)
Television broadcast stations: 22
(2007)
Televisions: 500,000 (1997)
internet country code: jo
Internet hosts: 2,500 (2007)
Internet Service Providers (ISPs): 5
(2000)
Internet users: 796,900 (2006)','a049cd754f116ccbde30910af1f6ce2c1bdd3b014979268652dd6329e358e79b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c384f505767241e07060d9d5f2915c687f7adf364ed82561246f224b61e3d3dd',2009,'KE','Kenya','communications',699,'Telephones— main lines in use: 2.928
million (2006)
Telephones— mobile cellular: 7.83 mil¬
lion (2006)
Telephone system:
general assessment: inherited an outdated
telecommunications network from the
Soviet era requiring modernization
domestic: intercity by landline and
microwave radio relay; number of fixed-
line connections is gradually increasing
and fixed-line teledensity is about 20 per
100 persons; mobile-cellular usage is
increasing rapidly and subscriptions now
exceed 50 per 100 persons
international: country code — 7; interna¬
tional traffic with other former Soviet
republics and China carried by landline
and microwave radio relay and with
other countries by satellite and by the
Trans-Asia-Europe (TAE) fiber-optic
cable; satellite earth stations — 2 Intelsat
Radio broadcast stations: AM 60, FM
17, shortwave 9 (1998)
Radios: 6.47 million (1997)
Television broadcast stations: 12 (plus
9 repeaters) (1998)
Televisions: 3.88 million (1997)
Internet country code: kz
Internet hosts: 33,217 (2007)
Internet Service Providers (ISPs): 10
(with their own international channels)
(2001)
Internet users: 1.247 million (2006)
Telephones— main lines in use:
293,400 (2006)
Telephones— mobile cellular: 6.485
million (2006)
Telephone system:
general assessment: inadequate; fixed-line
telephone system is small and inefficient;
trunks are primarily microwave radio
relay; business data commonly trans¬
ferred by a very small aperture terminal
(VS AT) system
domestic: no recent growth in fixed-line
infrastructure and the sole provider,
Telkom Kenya, is slated for privatization;
multiple providers in the mobile-cellular
segment of the market fostering a boom
in mobile-cellular telephone usage
international: country code — 254; satel¬
lite earth stations — 4 Intelsat
Radio broadcast stations: AM 24, FM
18, shortwave 6 (2001)
Radios: 3.07 million (1997)
Television broadcast stations: 8 (2001)
Televisions: 730,000 (1997)
Internet country code: ke
Internet hosts: 2,120 (2007)
Internet Service Providers (ISPs): 65
(2001)
Internet users: 2.77 million (2006)','b79f307260c9cad4f51923d28ee53aec25466df2ac51bac4f6d24e027bc479f5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd89b49065bd82adcd44e9c68e5803a5673192280f4af4ff92bd67acd70b4fa1',2009,'KI','Kiribati','communications',708,'Telephones— main lines in use: 4,500
(2002)
Telephones— mobile cellular: 600
(2004)
Telephone system:
general assessment: generally good quality
national and international service
domestic: wire line service available on
Tarawa and Kiritimati (Christmas
Island); connections to outer islands by
HF/VHF radiotelephone; wireless service
available in Tarawa since 1999
international: country code — 686;
Kiribati is being linked to the Pacific
Ocean Cooperative Telecommun¬
ications Network, which should improve
telephone service; satellite earth sta¬
tion — 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM l, FM 2,
shortwave 1 (may be inactive) (2002)
Radios: 17,000 (1997)
Television broadcast stations: l (pos¬
sibly inactive) (2002)
Televisions: 1,000 (1997)
Internet country code: ki
Internet hosts: 41 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 2,000 (2006)
Telephones— main lines in use:
980,000 (2003)
Telephone system:
general assessment: NA
domestic: NA
international: country code — 850; satel¬
lite earth stations — 2 (1 Intelsat —
Indian Ocean, 1 Russian — Indian Ocean
region); other international connections
through Moscow and Beijing
Radio broadcast stations: AM 17
(including 11 stations of Korean Central
Broadcasting Station; North Korea has a
“national intercom” cable radio station
wired throughout the country that is a
significant source of information for the
average North Korean citizen; it is wired
into most residences and workplaces and
carries news and commentary), FM 14,
shortwave 14 (2006)
Radios: 3.36 million (1997)
Television broadcast stations: 4
(includes Korean Central Television,
Mansudae Television, Korean
Educational and Cultural Network, and
Kaesong Television targeting South
Korea) (2003)
Televisions: 1.2 million (1997)
Internet country code: kp
Internet Service Providers (ISPs): 1
(2000)
Internet users: NA
Telephones — main lines in use:
106,300 (2006)
Telephones— mobile cellular: 562,000
(2006)','eb88cabbea1499c22721c5674bb471df57618b71a176cdb6556057e97c98a691','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('024f9e55c79a7af83374ceb31313ec9af083db01f3791bf298c1d4591ffe2cb6',2009,'KW','Kuwait','communications',713,'Telephones— main lines in use:
510,300 (2005)
Telephones— mobile cellular: 2.536
million (2006)
Telephone system:
general assessment: the quality of service
is excellent
domestic: new telephone exchanges pro¬
vide a large capacity for new subscribers;
trunk traffic is carried by microwave
362','054857a2a3d35fa32983e911e9b3e445d426d2b2d5aed234410031b77e51ccec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1ac06319b05dd19ccd73ea85d1def1450f05dd0d271080f5bb73fb10fd98d8',2009,'KG','Kyrgyzstan','communications',714,'radio relay, coaxial cable, and open-wire
and fiber-optic cable; a cellular tele¬
phone system operates throughout
Kuwait, and the country is well supplied
with pay telephones
international: country code — 965; linked
to international submarine cable Fiber-
Optic Link Around the Globe (FLAG);
linked to Bahrain, Qatar, UAE via the
Fiber-Optic Gulf (FOG) cable; coaxial
cable and microwave radio relay to Saudi
Arabia; satellite earth stations — 6 (3
Intelsat — 1 Atlantic Ocean and 2 Indian
Ocean, 1 Inmarsat — Atlantic Ocean,
and 2 Arabsat)
Radio broadcast stations: AM 6, FM
11, shortwave 1 (1998)
Radios: 1.175 million (1997)
Television broadcast stations: 13 (plus
several satellite channels) (1997)
Televisions: 875,000 (1997)
Internet country code: ,kw
Internet hosts: 2,013 (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 816,700 (2006)
Telephones— main lines in use:
458,900 (2006)
Telephones— mobile cellular:
1,261,800 (2006)
Telephone system:
general assessment: telecommunications
infrastructure is growing; fixed line pen¬
etration remains low and concentrated
in urban areas
domestic: 4 mobile cellular service
providers with growing coverage
international: country code — 996; con¬
nections with other CIS countries by
landline or microwave radio relay and
with other countries by leased connec¬
tions with Moscow international
gateway switch and by satellite; satellite
earth stations — 2 (1 Intersputnik, 1
Intelsat); connected internationally by
the Trans-Asia-Europe (TAE) fiber-optic
line (2006)
Radio broadcasf stations: AM 3 (plus
10 repeater stations), FM 23, shortwave
NA (2007)
Radios: 520,000 (1997)
Television broadcast stations: 8 (2
countrywide and 6 regional stations;
state-owned); note — there are about 20
private TV stations, most of which
rebroadcast other channels (2007)
Televisions: 210,000 (1997)
Internet country code: kg
Internet hosts: 80,990 (2007)
Internet Service Providers (ISPs): NA
Internet users: 298,100 (2006)','070317128165a261673556e5acff47c9d758a8c6e1186e7098ea55c3c803af14','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf1302fbe4bf920fffc555beab6517d9ceb66b705d0c52e47cd30569e295d454',2009,'LB','Lebanon','communications',733,'Telephones— main lines in use:
681,400 (2006)
Telephones — mobile cellular: 1.103
million (2006)
Telephone system:
general assessment: repair of the telecom¬
munications system, severely damaged
during the civil war, now complete
domestic: two wireless networks provide
good service; political instability ham¬
pers privatization and deployment of
new technologies; combined fixed-line
and mobile-cellular subscribership
approaching 50 per 100 persons
international: country code — 961; subma¬
rine cable link to Cyprus; satellite earth
stations — 2 Intelsat ( 1 Indian Ocean and
1 Atlantic Ocean); coaxial cable to Syria
Radio broadcast stations: AM 20, FM
22, shortwave 4 (1998)
Radios: 2.85 million (1997)
Television broadcast stations: 15 (plus
5 repeaters) (1995)
Televisions: 1.18 million (1997)
Internet country code: lb
Internet hosts: 5,635 (2007)
Internet Service Providers (ISPs): 22
(2000)
Internet users: 950,000 (2006)','148d7b53d0daceee2ebd21a28f38e75b8548c8722f9f66f2a34c68d6c1f20281','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b312b8acaaeb1f05be201ba25c081e97da361debee4d30bcfe45de31d774b518',2009,'ZA','South Africa','communications',741,'Telephones— main lines in use: 48,000
(2005)
Telephones— mobile cellular: 249,800
(2005)
Telephone system:
general assessment: rudimentary system
consisting of a modest but growing
number of landlines, a small microwave
radio relay system, and a small radiotele¬
phone communication system; mobile-
cellular telephone system is expanding
domestic: privatized in 2001, Telecom
Lesotho tasked with providing an addi¬
tional 50,000 fixed-line connections
within five years, a target not met;
mobile-cellular service is expanding with
a subscribership approaching 15 per 100
persons; rural services are scant
international: country code — 266; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean)
Radio broadcasf stafions: AM 1, FM 2,
shortwave 1 (1998)
Radios: NA (2002)
Television broadcast stations: 1 (2000)
Televisions: NA
Internet country code: Is
Internet hosts: 66 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 51,500 (2005)','136ead0c4bfc82e838ef7089ec01d5fc9e3e5d6a31f76d52591125354ddbd2ba','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('923ccfca612d0b2c3766757b67e18913dcf42daba9c3570bb0effacb74fc33c3',2009,'LR','Liberia','communications',748,'Telephones— main lines in use: 6,900
(2002)
Telephones— mobile cellular: 160,000
(2005)
Telephone system:
general assessment: the limited services
available are found almost exclusively in
the capital Monrovia; coverage extended
to a number of other towns and rural
areas by four mobile-cellular network
operators
domestic: combined fixed and mobile-
cellular teledensity only about 5 per 1 00
persons
international: country code — 231; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 0, FM
10, shortwave 2 (2007)
Radios: 790,000 (1997)
Television broadcast stations: 4 (plus 4
repeaters) (2007)
Televisions: 70,000 (1997)
Internet country code: .lr
Internet hosts: 38 (2007)
Internet Service Providers (ISPs): 2
(2001)
Internet users: 1,000 (2002)
Airports: 53 (2007)
Airports— with paved runways:
total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 51
I, 524 to 2,437 m: 5
914 to 1 ,523 m: 8
under 914 m: 38 (2007)
Railways:
total: 490 km
standard gauge: 345 km 1.435-m gauge
narrow gauge: 145 km 1.067-m gauge
note: sections of railway are inoperable
because of damage suffered during the
civil war (2008)
Roadways: total: 10,600 km
paved: 657 km
unpaved: 9,943 km (1999)
Merchant marine:
total: 1,948 ships (1000 GRT or over)
71,387,243 GRT/109,450,945 DWT
by type: barge carrier 3, bulk carrier 338,
cargo 91, chemical tanker 211, combina¬
tion ore/oil 9, container 614, liquefied
gas 81, passenger 2, passenger/cargo 1,
petroleum tanker 455, refrigerated cargo
91, roll on/roll off 6, specialized tanker
II, vehicle carrier 35
foreign''Owned: 1,904 (Argentina 3,
Australia 2, Belgium 1, Brazil 3, Canada
3, China 32, Croatia 5, Cyprus 5,
Denmark 12, Estonia 1, France 5,
Germany 728, Gibraltar 7, Greece 311,
Hong Kong 21, India 2, Indonesia 1,
Israel 9, Italy 31, Japan 111, South Korea
4, Kuwait 1, Latvia 15, Lebanon 2,
Mexico 1, Monaco 8, Netherlands 28,
Norway 42, Poland 14, Qatar 2, Russia
87, Saudi Arabia 24, Singapore 42,
Slovenia 1, Sweden 11, Switzerland 11,
Taiwan 82, Turkey 7, Ukraine 24, UAE
22, UK 74, US 103, Uruguay 3, Vietnam
3) (2007)
Ports and terminals: Buchanan,
Monrovia
Military branches: Armed Forces of
Liberia (AFL): Army, Navy, Air Force
Military service age and obligation: 16
years of age for voluntary military
service; no conscription (2008)
381
THE CIA WORLD FACTBOOK
Manpower available for military
service: males age i 6 — 49: 729,813
females age 16-49: 741,223 (2008 est.)
Manpower fit for military service:
males age 16—49: 371,287
females age 16-49: 373,265 (2008 est.)
Military expenditures — percent of
GDP: 1.3% (2006 est.)','fac7a8bfd2a577f61562e1058a3ce7492cbdeabfdd4c31aa9a4c8323f46aa604','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('239f71c2445a3de6d88d681030640b5a20aa550d126e04b56c7dc69da237f775',2009,'LT','Lithuania','communications',761,'Telephones— main lines in use: 20,000
(2005)
Telephones— mobile cellular: 27,500
(2005)
Telephone system:
general assessment: automatic telephone
system
domestic: NA
international: country code — 423; linked
to Swiss networks by cable and
microwave radio relay
Radio broadcast stations: AM 0, FM 4,
shortwave 0 (1998)
Radios: 21,000 (1997)
Television broadcast stations: NA
(linked to Swiss networks) (1997)
Televisions: 12,000 (1997)
Internet country code: li
Internet hosts: 4,753 (2007)
Internet Service Providers (ISPs): 44
(Fiechtenstein and Switzerland) (2000)
Internet users: 22,000 (2006)','483ee230c014d1fd70e33ff5ec847866591e4bbdf7bf662aef051649e914db36','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('580650dc53b3e5f510f3f809cc5f059f7e3ea826e64a4b5d517ff1966b847c35',2009,'LU','Luxembourg','communications',769,'Telephones— main lines in use:
246,700 (2006)
Telephones— mobile cellular: 713,800
(2006)
Telephone system:
general assessment: highly developed,
completely automated and efficient
system, mainly buried cables
domestic: nationwide cellular telephone
system; market for mobile-cellular
phones is virtually saturated with roughly
150 cellular phones per 100 persons
international: country code — 352
Radio broadcast stations: AM 2, FM 9,
shortwave 2 (1999)
Radios: 285,000 (1997)
Television broadcast stations: 5 (1999)
Televisions: 285,000 (1998 est.)
Internet country code: lu
Internet hosts: 132,090 (2007)
Internet Service Providers (ISPs): 8
(2000)
Internet users: 339,000 (2006)
Telephones— main lines in use:
178,013 (2007)
Telephones— mobile cellular: 794,323
(2007)
Telephone system:
general assessment: fairly modern commu¬
nication facilities maintained for
domestic and international services
domestic: termination of monopoly over
mobile-cellular telephone services in
2001 spurred sharp increase in subscrip¬
tions with mobile-cellular teledensity
approaching 140 per 100 persons in
2006; fixed-line teledensity about 40 per
100 persons
international: country code — 853;
landing point for the SEA-ME-WE-3
submarine cable network that provides
links to Asia, the Middle East, and
Europe; HF radiotelephone communica¬
tion facility; satellite earth station — 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 2,
shortwave 0 (1998)
Radios: 160,000 (1997)
Television broadcast stations: l (2006)
Televisions: 49,000 (1997)
Internet country code: mo
Internet hosts: 232 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 300,000 (2007)','71a397b91293be75a10f876b59161266a4892f3954c0e73d3ec4649958d2a84d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e45c723ad73c4e4d79c68817a8323de6cfe4de1c47877cb4fcd51fe94535d13c',2009,'MG','Madagascar','communications',780,'Telephones — main lines in use:
129,800 (2006)
Telephones— mobile cellular: 1.046
million (2006)
Telephone system:
general assessment: system is above average
for the region; Antananarivo’s main tele¬
phone exchange modernized, but the rest
of the analogue-based telephone system is
poorly developed; planning to add 50,000
new private-subscriber fixed lines begin¬
ning in 2005
domestic: combined fixed-line and
mobile telephone density only about 7
per 100 persons
international: country code — 261; subma¬
rine cable to Bahrain; satellite earth sta¬
tions — 2 (1 Intelsat — Indian Ocean, 1
Intersputnik — Atlantic Ocean region)
Radio broadcasf stafions: AM 2 (plus a
number of repeater stations), FM 9,
shortwave 6 (2001)
Radios: 3.05 million (1997)
Television broadcast stations: 1 (plus
36 repeaters) (2001)
Televisions: 325,000 (1997)
Internet country code: mg
Internet hosts: 9,734 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 110,000 (2006)','45b7e6c7834e82776fa631d19617536b55a42575c7621d7e43e3490f2bad6cd7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec8e549e6f4aea944f0f5247c5b2e0ab51056c047836b2d9eb7f13178addd05',2009,'MY','Malaysia','communications',787,'Telephones — main lines in use:
102,700 (2005)
Telephones— mobile cellular: 429,300
(2005)
Telephone system:
general assessment: rudimentary
domestic: fixed-line subscribership
remains less than 1 per 100 persons; pri¬
vatization of Malawi
Telecommunications (MTL), a necessary
step in bringing improvement to
telecommunications services, completed
in 2006; mobile-cellular services are
expanding but cellular network coverage
is limited and is based around the main
urban areas
international: country code — 265; satel¬
lite earth stations — 2 Intelsat (1 Indian
Ocean, 1 Atlantic Ocean)
Radio broadcast stations: AM 9, FM 5
(plus 15 repeater stations), shortwave 2
(plus one shortwave station on standby)
(2001)
Radios: 2.6 million (1997)
Television broadcast stations: 1 (2001)
Televisions: NA
Internet country code: mw
Internet hosts: 347 (2007)
Internet Service Providers (ISPs): 3
(2002)
Internet users: 59,700 (2006)
Telephones— main lines in use: 4 342
million (2006)
Telephones— mobile cellular: 19.464
million (2006)
Telephone system:
general assessment: modern system; inter¬
national service excellent
domestic: good intercity service provided
on Peninsular Malaysia mainly by
microwave radio relay; adequate inter¬
city microwave radio relay network
between Sabah and Sarawak via Brunei;
domestic satellite system with 2 earth
stations; combined fixed-line and mobile
cellular teledensity approaching 100 per
100 persons
international: country code — 60; landing
point for several major international sub¬
marine cable networks that provide con¬
nectivity to Asia, Middle East, and
Europe; satellite earth stations — 2
Intelsat (1 Indian Ocean, 1 Pacific
Ocean) (2001)
Radio broadcast stations: AM 35, FM
391, shortwave 15 (2001)
Radios: 10.9 million (1999)
Television broadcast stations: 88
(mainland Malaysia 51, Sabah 16, and
Sarawak 21) (2006)
Televisions: 10.8 million (1999)
Internet country code: .my
Internet hosts: 337,674 (2007)
Internet Service Providers (ISPs): 7
(2000)
Internet users: 11.292 million (2006)','201adfd2ab31af725e9f3d1a62aa14cf947fe7f17eb840cf3aab89fc180ceb40','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('932ae97807859aa1a2e85a83690e418455c5077ac762af1ed81593e5de7d1979',2009,'MV','Maldives','communications',801,'Telephones— main lines in use: 32,500
(2006)
Telephones— mobile cellular: 262,600
(2006)
Telephone system:
general assessment: telephone services
have improved; each island now has at
least 1 public telephone, and there are
mobile cellular networks with rapidly
expanding subscribership
domestic: interatoll communication
through microwave links; all inhabited
islands and resorts are connected with
telephone and fax service
international: country code — 960; linked
to international submarine cable Fiber-
Optic Link Around the Globe (FLAG);
satellite earth station — 3 Intelsat
(Indian Ocean)
Radio broadcast stations: AM 1, FM l,
shortwave 1 (1998)
Radios: 35,000 (1999)
Television broadcast stations: 1 (2006)
Televisions: 10,000 (1999)
Internet country code: mv
Internet hosts: 1,082 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 20,100 (2005)','1aba92c49a9719db668efbbe2e72278ad89dd23754382942322477bd99bf16f9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d046de421bd8439644b1c5a41fcc66522254983e12361b06d97f38d3512d5cb',2009,'ML','Mali','communications',807,'Telephones— main lines in use: 82,500
(2006)
Telephones— mobile cellular: 1.513
million (2006)
Telephone system:
general assessment: domestic system unre¬
liable but improving; provides only min¬
imal service
domestic: fixed-line availability is gradu¬
ally increasing, but subscribership
remains less than 1 per 100 persons;
mobile-cellular subscribership has
increased sharply to 13 per 100 persons
international: country code — 223; satel¬
lite earth stations — 2 Intelsat ( 1 Atlantic
Ocean, 1 Indian Ocean)
Radio broadcast stations: AM 1, FM
230 (27 regional and government sta¬
tions, and 203 private stations), short¬
wave 1 (2001)
Radios: 570,000 (1997)
Television broadcast stations: 2 (plus
repeaters) (2007)
Televisions: 45,000 (1997)
Internet country code: ml
Internet hosts: 28 (2007)
Internet Service Providers (ISPs): 13
(2001)
Internet users: 70,000 (2006)','5a465cb92e706f6ad35cbf5c70e464b595064620de70d353eb7c95b2e3531d35','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('238580d8fc6ee4c8b280e310581e7544735609d1034999472b46526ac605b1cc',2009,'MH','Marshall Islands','communications',813,'Telephones— main lines in use:
202,300 (2006)
Telephones— mobile cellular: 346,800
(2006)
Telephone system:
general assessment: automatic system sat¬
isfies normal requirements; fixed-line
teledensity 50 per 100 persons; mobile-
cellular teledensity about 90 per 100 per¬
sons
domestic: submarine cable and
microwave radio relay between islands
international: country code — 356; subma¬
rine cable connects to Italy; satellite
earth station — 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 1, FM
18, shortwave 6 (1999)
Radios: 255,000 (1997)
Television broadcast stations: 5 (2006)
Televisions: 280,000 (1997)
Internet country code: .mt
Internet hosts: 21,386 (2007)
Internet Service Providers (ISPs): 6
(2002)
Internet users: 127,200 (2005)
Telephones— main lines in use: 4,500
(2004)
Telephones — mobile cellular: 600
(2004)
Telephone system:
general assessment: digital switching
equipment; modern services include
telex, cellular, Internet, international
calling, caller ID, and leased data circuits
domestic: Majuro Atoll and Ebeye and
Kwajalein islands have regular, seven-
digit, direct-dial telephones; other
islands interconnected by high frequency
radiotelephone (used mostly for govern¬
ment purposes) and mini-satellite tele¬
phones
international: country code— 692; satel¬
lite earth stations — 2 Intelsat (Pacific
Ocean); US Government satellite com¬
munications system on Kwajalein (2001 )
Radio broadcast stations: AM l, FM 3,
shortwave 0 (additionally, the US
Armed Forces Radio and Television
Services (Central Pacific Network)
operate one FM and one AM station on
Kwajalein) (2005)
Radios: NA
Television broadcast stations: 2 (both
are US military stations; Marshalls
Broadcasting Service, a cable company,
operates on Majuro) (2005)
Televisions: NA
Internet country code: mh
Internet hosts: 3 (2007)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 2,200 (2006)','9dffe28a986824d28029037f79fe8fc9dfd3a332e27c20e7bd0db5d3e4e149ce','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0e87933376b17def3fbffaeb8f6bae5c24bda9601f806883450d7989b6ea640',2009,'MR','Mauritania','communications',823,'Telephones— main lines in use: 34,900
(2006)
Telephones— mobile cellular: 1.06 mil¬
lion (2006)
Telephone system:
general assessment: limited system of
cable and open-wire lines, minor
microwave radio relay links, and
radiotelephone communications sta¬
tions; mobile-cellular services expanding
rapidly
domestic: Mauritel, the national telecom¬
munications company, was privatized in
2001 but remains the monopoly provider
of fixed-line services; fixed-line teleden¬
sity 1 per 100 persons; mobile-cellular
network coverage extends mainly to
urban areas with a teledensity
approaching 35 per 100 persons; mostly
cable and open-wire lines; a domestic
satellite telecommunications system
links Nouakchott with regional capitals
international: country code — 222; satel¬
lite earth stations — 3 (1 Intelsat —
Atlantic Ocean, 2 Arabsat)
Radio broadcast stations: AM 1, FM
14, shortwave 1 (2001)
Radios: 410,000 (2001)
Television broadcast stations: l (2002)
Televisions: 98,000 (2001)
Internet country code: mr
Internet hosts: 14 (2007)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 100,000 (2006)','9d76cbd07fa2266d88814158c3c09d9c07f4b9b95e3b279ee085f16497f7817d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dae307ef0c64b4a0dbe8cd049c14c67890cb35c137cebef77a1faabae64d706',2009,'YT','Mayotte','communications',830,'Telephones— main lines in use:
357,300 (2006)
Telephones — mobile cellular: 772,400
(2006)
Telephone system:
general assessment: small system with
good service
domestic: monopoly over fixed-line serv¬
ices terminated in 2005; fixed-line tele¬
density roughly 30 per 100 persons;
mobile-cellular services launched in
1989 with teledensity in 2006 exceeding
60 per 100 persons
international: country code — 230;
landing point for the SAFE submarine
cable that provides links to Asia and
South Africa where it connects to the
SAT-3/WASC submarine cable that pro¬
vides further links to parts of East Africa,
and Europe; satellite earth station — 1
Intelsat (Indian Ocean); new microwave
link to Reunion; HF radiotelephone
links to several countries
Radio broadcast stations: AM 4, FM 9,
shortwave 0 (2001)
Radios: 420,000 (1997)
Television broadcast stations: 2 (plus
several repeaters) (1997)
Televisions: 258,000 (1997)
Internet country code: mu
Internet hosts: 9,792 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 182,000 (2006)','58861f1688a9c2f9161f967ef1ee66bbc44e071ef53924f9bdf34fa7aba1fed4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b21e1e336aa247ece5335a4fd3f8b9eded287fcd3d6f7369516622e2f06a7b9',2009,'MX','Mexico','communications',833,'Telephones— main lines in use: 10,000
(2002)
Telephones— mobile cellular: 48,100
(2005)
Telephone system:
general assessment: small system adminis¬
tered by French Department of Posts and
Telecommunications
domestic: NA
international: country code — 262;
microwave radio relay and FIF radiotele¬
phone communications to Comoros
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (2001)
Radios: NA
Television broadcast stations: 3 (2001)
Televisions: 3,500 (1994)
Internet country code: yt
Internet hosts: 1 (2007)
Internet Service Providers (ISPs): NA
Internet users: NA','7417d0426b99eada6cc80231bc7629655196af0ac6ca258e6b6c4e0ce5c0dec8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fc002f8bd64641db1723e0d53c1ad2c23db1fd97264a7e5b99de66c0e376b86',2009,'RO','Romania','communications',844,'Telephones— main lines in use: 1.018
million (2006)
Telephones— mobile cellular: 1.358
million (2006)
Telephone system:
general assessment: inadequate, out¬
moded, poor service outside Chisinau;
some modernization is under way
domestic: depending on location, new
subscribers may face long wait for
service; multiple private operators of
GSM mobile-cellular telephone service
are operating; GPRS system is being
introduced; a CDMA mobile telephone
network began operations in 2007
international: country code — 373; service
through Romania and Russia via land¬
line; satellite earth stations — at least 3
(Intelsat, Eutelsat, and Intersputnik)
(2006)
Radio broadcasf stations: AM 2, FM
29, shortwave NA (2006)
Radios: 3.22 million (1997)
Television broadcast stations: 40
(2006)
Televisions: 1.26 million (1997)
Internet country code: .md
Internet hosts: 112,026 (2007)
Internet Service Providers (ISPs): 2
(1999)
Internet users: 727,700 (2006)
Telephones — main lines in use: 4.231
million (2006)
Telephones— mobile cellular: 17.4 mil¬
lion (2006)
Telephone system:
general assessment: rapidly improving
domestic and international service, espe¬
cially in wireless telephony
domestic: more than 90 percent of tele¬
phone network is automatic; liberaliza¬
tion in 2003 is transforming
telecommunications; fixed-line teleden-
sity is roughly 20 telephones per 100 per¬
sons; mobile-cellular teledensity is
approaching 80 telephones per 100 per¬
sons
international: country code — 40; the
Black Sea Fiber Optic System provides
connectivity to Bulgaria and Turkey;
satellite earth stations — 10; digital,
international, direct-dial exchanges
operate in Bucharest (2005)
Radio broadcast stations: 698 (fre¬
quency type NA) (2006)
Radios: 7.2 million (1997)
Television broadcast stations: 623 (plus
200 repeaters) (2006)
Televisions: 5.25 million (1997)
Internet country code: ro
Internet hosts: 1.406 million (2007)
Internet Service Providers (ISPs): 38
(2000)
Internet users: 5.063 million (2006)
Telephones — main lines in use: 40.1
million (2005)
Telephones — mobile cellular: 150 mil¬
lion (2006)
Telephone system:
general assessment: the telephone system
is experiencing significant changes; there
are more than 1,000 companies licensed
to offer communication services; access
to digital lines has improved, particularly
in urban centers; Internet and e-mail
services are improving; Russia has made
progress toward building the telecommu¬
nications infrastructure necessary for a
market economy; the estimated number
of mobile subscribers jumped from fewer
than 1 million in 1998 to 150 million in
2006; a large demand for main line
service remains unsatisfied, but fixed-
line operators continue to grow their
services
domestic: cross-country digital trunk lines
run from Saint Petersburg to
Khabarovsk, and from Moscow to
Novorossiysk; the telephone systems in
60 regional capitals have modem digital
infrastructures; cellular services, both
analog and digital, are available in many
areas; in rural areas, the telephone serv¬
ices are still outdated, inadequate, and
low density
international: country code — 7; Russia is
connected internationally by undersea
fiber optic cables; digital switches in sev¬
eral cities provide more than 50,000
lines for international calls; satellite
earth stations provide access to Intelsat,
Intersputnik, Eutelsat, Inmarsat, and
Orbita systems
Radio broadcast stations: AM 323, FM
1,500 est., shortwave 62 (2004)
Radios: 61.5 million (1997)
Television broadcast stations: 7,306
(1998)
Televisions: 60.5 million (1997)
Internet country code: .ru; note — Russia
also has responsibility for a legacy
domain “.su” that was allocated to the
Soviet Union and is being phased out
Internet hosts: 2.844 million (2007)
Internet Service Providers (ISPs): 300
(June 2000)
Internet users: 25.689 million (2006)','7f3d8044c1b47d2510334bd72016b4c23099acd148e0f784c981f7fc6e08b0bf','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8347c822cf1066969cfcc9df7f88f4b1681e21b43c3d18221aa835595827984',2009,'MC','Monaco','communications',851,'Telephones— main lines in use: 34,000
(2005)
Telephones— mobile cellular: 17,200
(2005)
Telephone system:
general assessment: modern automatic
telephone system
domestic: NA
international: country code — 377; no
satellite earth stations; connected by
cable into the French communications
system
Radio broadcast stations: AM 1, FM
NA, shortwave 8 (1998)
Radios: 34,000 (1997)
Television broadcast stations: 5 (1998)
Televisions: 25,000 (1997)
Internet country code: me
Internet hosts: 14,520 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 20,000 (2006)','3109ad50e56184941eb3e249d4cb6a19222975adfe6dd4e4d1dcfcf9c362390c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('548ad7d6872011e525878dc13f65f8222bdfd7cb7ffb8c811d947ad85c302e5f',2009,'ME','Montenegro','communications',860,'Telephones— main lines in use:
158,900 (2006)
Telephones— mobile cellular: 775,300
(2006)
Telephone system:
general assessment: network is improving
with international direct dialing avail¬
able in many areas
domestic: very low fixed-line density;
there are multiple mobile cellular service
providers and subscribership is increasing
rapidly; a fiber-optic network is also
being installed that will improve broad¬
band and communication services
between major urban centers
international: country code — 976; satel¬
lite earth stations — 7
Radio broadcast stations: AM 7, FM
115 (includes 20 National radio broad¬
caster repeaters), shortwave 4 (2006)
Radios: 155,900 (1999)
Television broadcast stations: 456
(including provincial and low-power
repeaters) (2006)
Televisions: 168,800 (1999)
Internet country code: mn
Internet hosts: 298 (2007)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 268,300 (2005)
Telephones— main tines in use:
353,300 (2006)
Telephones— mobile cellular: 821,800
(2006)
Telephone system:
general assessment: modern telecommuni¬
cations system with access to European
satellites
domestic: GSM wireless service, available
through 2 providers with national cov¬
erage, is growing rapidly
international: country code — 382; 2 inter¬
national switches connect the national
system
Radio broadcast stations: 31 (station
types NA) (2004)
Television broadcast stations: 13
(2004)
Internet country code: me
Internet users: 266,000 (2006)','9c7bd82856680c31676ccaf7ce042fb2c9dc38416b70fce8445d7993ab87e001','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a37c08c3b2be2a415566cb413a77316b46e940f275986a3dce87b21f219c86b',2009,'MS','Montserrat','communications',869,'Telephones— main lines in use: NA
Telephones— mobile cellular: NA
Telephone system:
general assessment: modern and fully dig¬
italized
domestic: NA
international: country code — 1-664;
landing point for the East Caribbean
Fiber System (ECFS) optic submarine
cable with links to 13 other islands in the
eastern Caribbean extending from the
British Virgin Islands to Trinidad
Radio broadcast stations: AM l, FM 2,
shortwave 0 (1998)
Radios: 7,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 3,000 (1997)
Internet country code: ms
Internet hosts: 367 (2007)
Internet Service Providers (ISPs): 17
(2000)
Internet users: NA','6f79d7c5b25fb709218c343c7715e2200e003426007414d0064d62613ace65c7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55c6ed3a333301f05e30a4e465f312b41d387bb9b2ce1cfc578bc2afff5046cd',2009,'MA','Morocco','communications',877,'Telephones— main lines in use: 1.266
million (2006)
Telephones— mobile cellular: 16.005
million (2006)
Telephone system:
general assessment: modem system with
all important capabilities; however, den¬
sity is low with only 4 fixed lines avail¬
able for each 100 persons;
mobile-cellular subscribership is
approaching 50 per 100 persons
domestic: good system composed of open-
wire lines, cables, and microwave radio
relay links; Internet available but expen¬
sive; principal switching centers are
Casablanca and Rabat; national network
nearly 100% digital using fiber-optic
links; improved rural service employs
microwave radio relay
448','ef6bed3d215f60da5d3ebc74cb06ddba12d71061bb3096ddf0027c402262f524','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e8799b333e0903d58b5ab685ed39de780925f73fcdf05079271ea3797cdc214',2009,'MZ','Mozambique','communications',878,'international: country code — 212;
landing point for the SEA-ME-WE-3
optical telecommunications submarine
cable that provides connectivity to Asia,
the Middle East, and Europe; satellite
earth stations — 2 Intelsat (Atlantic
Ocean) and 1 Arabsat; microwave radio
relay to Gibraltar, Spain, and Western
Sahara; coaxial cable and microwave
radio relay to Algeria; participant in
Medarabtel; fiber-optic cable link from
Agadir to Algeria and Tunisia
Radio broadcast stations: AM 27, FM
25, shortwave 6 (1998)
Radios: 6.64 million (1997)
Television broadcast stations: 35 (plus
66 repeaters) (1995)
Televisions: 3.1 million (1997)
Internet country code: ma
Internet hosts: 137,187 (2007)
Internet Service Providers (ISPs): 8
(2000)
Internet users: 6.1 million (2006)
Telephones — main lines in use: 67,000
(2006)
Telephones — mobile cellular: 2.339
million (2006)
Telephone system:
general assessment: fair system with an
extremely low density of less than 1 fixed
line per 100 persons
domestic: the telecommunications sector
is shackled with a heavy state presence,
lack of competition, and high operating
costs and charges; stagnation in the
fixed-line network contrasts with rapid
growth in the mobile-cellular network;
mobile-cellular coverage now includes
all the main cities and key roads,
including those from Maputo to the
South African and Swaziland borders,
the national highway through Gaza and
Inhambane provinces, the Beira corridor,
and from Nampula to Nacala
international: country code— 258; satel¬
lite earth stations — 5 Intelsat (2 Atlantic
Ocean and 3 Indian Ocean)
Radio broadcast stations: AM 13, FM
17, shortwave 11 (2001)
Radios: 730,000 (1997)
Television broadcast stations: l (2000)
Televisions: 67,600 (2000)
Internet country code: mz
Internet hosts: 15,231 (2007)
Internet Service Providers (ISPs): 11
(2002)
Internet users: 178,000 (2005)
Telephones— main lines in use:
169,135 (2007)
Telephones— mobile cellular: 6.72 mil¬
lion (2007)
Telephone system:
general assessment: telecommunications
services are inadequate; system operating
below capacity and being modernized for
better service; small aperture terminal
(VSAT) system under construction
domestic: fixed-line telephone network
inadequate with less than 1 connection
per 100 persons; mobile-cellular service,
aided by multiple providers, is increasing;
trunk service provided by open-wire,
microwave radio relay, tropospheric
scatter, and fiber-optic cable; some links
being made digital
international: country code — 255; satel¬
lite earth stations — 2 Intelsat (1 Indian
Ocean, 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM
11, shortwave 2 (1998)
Radios: 8.8 million (1997)
Television broadcast stations: 3 (1999)
Televisions: 103,000 (1997)
Internet country code: tz
Internet hosts: 20,757 (2007)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 384,300 (2005)','59ffab7d07556680a4c9dc33708816ba62856eef097e06ff8b11bbe516d6a378','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bb0c865963a438a6a899d3d3d28bc76487b1ed76c39424691a8efe0ba552ccd',2009,'NR','Nauru','communications',890,'Telephones — main lines in use:
138,900 (2005)
Telephones — mobile cellular: 495,000
(2005)
Telephone system:
general assessment: good system with a
combined fixeddine and mobile-cellular
teledensity of about 30 per 100 persons
domestic: core fiber-optic network links
most centers and connections are now
digital; Namibia’s first mobile-cellular
network, launched in 1994, provides
coverage to 86 percent of Namibia by
area
international: country code — 264; fiber¬
optic cable to South Africa, microwave
radio relay link to Botswana, direct links
to other neighboring countries; con¬
nected to the South African Far East
(SAFE) submarine cable through South
Africa; satellite earth stations — 4
Intelsat
Radio broadcast stations: AM 2, FM
39, shortwave 4 (2001)
Radios: 232,000 (1997)
Television broadcast stations: 2 (2007)
Televisions: 60,000 (1997)
Internet country code: .na
Internet hosts: 3,717 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 80,600 (2005)
Telephones — main lines in use: 1,900
(2002)
Telephones — mobile cellular: 1,500
(2002)
Telephone system:
general assessment: adequate local and
international radiotelephone communi¬
cation provided via Australian facilities
domestic: NA
international: country code — 674; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM l, FM 0,
shortwave 0 (1998)
Radios: 7,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 500 (1997)
Internet country code: nr
Internet hosts: 53 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 300 (2002)','3f529b6c017359571fb6d2ac41d62c2f012019aee96873913d8577645898e904','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60fc241ec235a30556df4859e706552796b855c30f319f22fd4c3da2ec0f2ee1',2009,'NL','Netherlands','communications',903,'Telephones— main lines in use:
595,800 (2006)
Telephones — mobile cellular: 1.042
million (2006)
Telephone system:
general assessment: poor telephone and
telegraph service; fair radiotelephone
communication service and mobile-cel¬
lular telephone network
domestic: NA
international: country code — 977; radio¬
telephone communications; microwave
landline to India; satellite earth sta¬
tion — 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 6, FM 5,
shortwave 1 (2000)
Radios: 840,000 (1997)
Television broadcast stations: 1 (plus 9
repeaters) (1998)
Televisions: 130,000 (1997)
Internet country code: np
Internet hosts: 18,733 (2007)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 249,400 (2006)
Telephones— main lines in use: 7.6
million (2005)
Telephones— mobile cellular: 15.834
million (2005)
Telephone system:
general assessment: highly developed and
well maintained
domestic: extensive fixed-line fiber-optic
network; cellular telephone system is one
of the largest in Europe with 5 major net¬
work operators utilizing the third genera¬
tion of the Global System for Mobile
Communications (GSM)
international: country code — 31; subma¬
rine cables provide links to the US and
Europe; satellite earth stations — 5 (3
Intelsat — 1 Indian Ocean and 2 Atlantic
Ocean, 1 Eutelsat, and 1 Inmarsat (2004)
Radio broadcasf sfafions: AM 4, FM
246, shortwave 3 (2004)
Radios: 15.3 million (1996)
Television broadcasf sfafions: 21 (plus
26 repeaters) (1995)
Televisions: 8.1 million (1997)
Internef country code: nl
Internet hosts: 11.17 million (2007)
Internet Service Providers (ISPs): 52
(2000)
Internet users: 14.544 million (2006)','a101119356f9b7bb7f08a44d05412e1169b55764cd60c4be8c04fdb37ba853ec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6620d47b00d0ecddfbc4034c027a964b71b38ade17530e87aadbaa13c58c004b',2009,'NZ','New Zealand','communications',917,'Telephones — main lines in use: 55,300
(2005)
Telephones— mobile cellular: 134,300
(2005)
Telephone system:
general assessment: NA
domestic: a submarine cable network con¬
nection between New Caledonia and
Australia, scheduled for completion in
2008, will improve high-speed connec¬
tivity and access to international networks
international: country code — 687; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM l, FM 5,
shortwave 0 (1998)
Radios: 107,000 (1997)
Television broadcast stations: 6 (plus
25 repeaters) (1997)
Televisions: 52,000 (1997)
Internet country code: nc
Internet hosts: 14,252 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 80,000 (2006)
Telephones— main lines in use: 1,100
(2002 est.)
Telephones— mobile cellular: 400
(2002)
Telephone system:
domestic: single-line telephone system
connects all villages on island
international: country code — 683 (2001)
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (1998)
Radios: 1,000 (1997)
Television broadcast stations: l (1997)
Televisions: NA
Internet country code: nu
Internet Service Providers (ISPs): 1
(2000)
Internet users: 900 (2002)','24038e8db8fe946db53411ee25a2d8de3b933e3347fe4d54bb687b4410583621','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b9ddc94e8431236c5bfd9f74696eb788eafdfbc43d7ca3660e262d662c3d2bb',2009,'TK','Tokelau','communications',925,'_
Telephones— main lines in use: 1.729
million (2005)
Telephones— mobile cellular: 3.53 mil¬
lion (2005)
Telephone system:
general assessment: excellent domestic
and international systems
domestic: NA
international: country code — 64; the
Southern Cross submarine cable system
provides links to Australia, Fiji, and the
US; satellite earth stations — 8 (1
Inmarsat — Pacific Ocean, 7 other)
Radio broadcast stations: AM 124, FM
290, shortwave 4 (1998)
Radios: 3.75 million (1997)
Television broadcast stations: 41 (plus
about 700 repeaters) (1997)
Televisions: 1.926 million (1997)
Internet country code: nz
Internet hosts: 1.433 million (2007)
Internet Service Providers (ISPs): 36
(2000)
Internet users: 3.2 million (2006)
Airports: 121 (2007)
Airports— with paved runways:
total: 41
over 3,047 m: 2
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1 1
914 to 1,523 m: 26
under 914 m: 1 (2007)
Airports — with unpaved runways:
total: 80
1,524 to 2,437 m: 3
914 to 1,523 m: 31
under 914 m: 46 (2007)
Pipelines: condensate 331 km; gas 1,896
km; liquid petroleum gas 172 km; oil 288
km; refined products 260 km (2007)
Railways:
total: 4,128 km
narrow gauge: 4,128 km 1.067-m gauge
(506 km electrified) (2006)
Roadways:
total: 92,931 km
paved: 59,783 km (includes 171 km of
expressways)
unpaved: 33,148 km (2003)
Merchant marine:
total: 11 ships (1000 GRT or over)
108,667 GRT/89,458 DWT
by type: bulk carrier 3, cargo 1, pas¬
senger/cargo 4, petroleum tanker 1, roll
on/roll off 2
foreign- owned: 1 (Germany 1)
registered in other countries: 8 (Antigua
and Barbuda 2, Cook Islands 1,
Dominica 3, France 1, UK 1) (2007)
Ports and terminals: Auckland,
Lyttelton, Marsden Point, Tauranga,
Wellington, Whangarei
'' •
Telephones — main lines in use: 82,100
(2006)
Telephones — mobile cellular: 708,000
(2006)
Telephone system:
general assessment: fair system based on a
network of microwave radio relay routes
supplemented by open-wire lines and a
mobile-cellular system
domestic: microwave radio relay and
open-wire lines for conventional system;
combined fixed-line and mobile-cellular
teledensity roughly 15 telephones per
100 persons
international: country code — 228; satel¬
lite earth stations — 1 Intelsat (Atlantic
Ocean), 1 Symphonie
Radio broadcast stations: AM 2, FM 9,
shortwave 4 (1998)
Radios: 940,000 (1997)
Television broadcast stations: 3 (plus 2
repeaters) (1997)
Televisions: 73,000 (1997)
Internet country code: tg
Internet hosts: 702 (2007)
Internet Service Providers (ISPs): 3
(2001)
Internet users: 320,000 (2006)','5ec210b1f2f997f97e12a48eb963cab2ddac7c8cc1f60452c30a14e5cc8e119b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd27122b3c2b16b5fee3f62e3f52f8633f1277f1ec91b4e3beda0afaebfedb6',2009,'NE','Niger','communications',930,'Telephones— main lines in use:
247,900 (2006)
Telephones— mobile cellular: 1.83 mil¬
lion (2006)
Telephone system:
general assessment: system being upgraded
by foreign investment; nearly all
installed telecommunications capacity
now uses digital technology, owing to
investments since privatization of the
formerly state-owned telecommunica¬
tions company
domestic: since privatization, access to
fixed-line and mobile-cellular services
has improved but teledensity still lags
behind other Central American coun¬
tries; connected to Central American
Microwave System
international: country code — 505; the
Americas Region Caribbean Ring
System (ARCOS-1) fiber optic subma¬
rine cable provides connectivity to
South and Central America, parts of the
Caribbean, and the US; satellite earth
stations — 1 Intersputnik (Atlantic
Ocean region) and 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 63, FM
32, shortwave 1 (1998)
Radios: 1.24 million (1997)
Television broadcast stations: 3 (plus 7
repeaters) (1997)
Televisions: 320,000 (1997)
Internet country code: ni
Internet hosts: 27,941 (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 155,000 (2006)
Telephones — main lines in use: 24,000
(2005)
Telephones — mobile cellular: 323,900
(2005)
Telephone system:
general assessment: inadequate; small
system of wire, radio telephone commu¬
nications, and microwave radio relay
links concentrated in the southwestern
area of Niger
domestic: combined fixed-line and
mobile-cellular teledensity is less than 3
per 100 persons; domestic satellite
system with 3 earth stations and 1
planned
international: country code — 227; satel¬
lite earth stations — 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 5, FM 6,
shortwave 4 (2001)
Radios: 680,000 (1997)
Television broadcast stations: 5 (2007)
Televisions: 125,000 (1997)
Internet country code: ne
Internet hosts: 200 (2007)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 40,000 (2006)','4d754651135d09e995ae0c5d6c1b87926116e06ca3d50706e05d6b7c92b924c4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c9a542555b60b27891379c01802fbef9989e731f94c17f5ea554f1de9dbc5f6',2009,'NG','Nigeria','communications',938,'Telephones— main lines in use: 1.688
million (2006)
Telephones— mobile cellular: 32.322
million (2006)
Telephone system:
general assessment: further expansion and
modernization of the fixed-line tele¬
phone network is needed
domestic: the addition of a second fixed-
line provider in 2002 resulted in faster
growth of this service with fixed-line
subscribership nearly tripling over the
past five years; wireless telephony has
grown rapidly, in part responding to the
shortcomings of the fixed-line network;
multiple service providers operate
nationally; combined fixed-line and
mobile-cellular teledensity reached 25
per 100 persons in 2006
international: country code — 234;
landing point for the SAT-3/WASC
fiber-optic submarine cable that provides
connectivity to Europe and Asia; satel¬
lite earth stations — 3 Intelsat (2 Atlantic
Ocean and 1 Indian Ocean)
Radio broadcasf sfafions: AM 83, FM
36, shortwave 11 (2001)
Radios: 23.5 million (1997)
Television broadcast stations: 3 (the
government controls 2 of the broad¬
casting stations and 15 repeater stations)
(2001)
Televisions: 6.9 million (1997)
Internet country code: ng
Internet hosts: 1,968 (2007)
Internet Service Providers (ISPs): 11
(2000)
Internet users: 8 million (2006)
Airports: 70 (2007)
Airports— with paved runways:
total: 36
over 3,047 m: 6
2,438 to 3,047 m: 12
1,524 to 2,437 m: 10
914 to 1 ,523 m: 6
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 34
1 ,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 19 (2007)
Heliports: 2 (2007)
Pipelines: condensate 124 km; gas 3,071
km; liquid petroleum gas 156 km; oil
4,347 km; refined products 3,949 km
(2007)
Railways:
total: 3,505 km
narrow gauge: 3,505 km 1.067-m gauge
(2006)
Roadways:
total: 194,394 km
paved: 60,068 km
unpaved: 134,326 km (1999)
Waterways: 8,600 km (Niger and Benue
rivers and smaller rivers and creeks)
(2007)
Merchant marine:
total: 55 ships (1000 GRT or over)
284,400 GRT/483,316 DWT
by type: cargo 5, chemical tanker 8, com¬
bination ore/oil 1, liquefied gas 1, pas-
senger/cargo 1, petroleum tanker 37,
specialized tanker 2
foreign'' owned: 3 (Norway 1, Singapore 1,
Spain 1)
registered in other countries: 23 (Bahamas
2, Bermuda 11, Cambodia 2, Panama 6,
Poland 1, Seychelles 1, unknown 2)
(2007)
Ports and terminals: Bonny Inshore
Terminal, Calabar, Lagos','c076dbac962408796a77a322138d88d5fd39507c12bf7e83da8dbe24c2d84c81','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab7902d5e6e3a722eeb65bb5cb2a779c7076bccb3f362dca14ca634f9735bf05',2009,'MP','Northern Mariana Islands','communications',948,'Telephones— main lines in use: 2,532;
note — a mix of analog (2500) and digital
(32) circuits (2004)
Telephones — mobile cellular: 0, note-
proposed cellular service disallowed in
August 2002 island referendum (2002)
Telephone system:
general assessment: adequate
domestic: free local calls
international: country code — 672;
undersea coaxial cable links with
Australia and New Zealand; satellite
earth station — 1
Radio broadcast stations: AM 1, FM 3,
shortwave 0 (2005)
Radios: 2,500 (1996)
Television broadcast stations: l (local
programming station plus 2 repeaters
that air Australian programs by satellite)
(2005)
Televisions: 1,200 (1996)
Internet country code: nf
Internet hosts: 96 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 700 (2002 est.)','9830ae66da3e1aa2f48edc4c5dde9a44e40988a8b0e1e4d1ed09af28a372c933','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('019bcce2a020af8190fdd4aa63d2379123273c87b46a0e6d871e476f6799b362',2009,'NO','Norway','communications',954,'Telephones— main lines in use: 21,000
(2000)
Telephones — mobile cellular: 20,500
(2004)
Telephone system:
general assessment: NA
domestic: NA
international: country code — 1-670; satel¬
lite earth stations — 2 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM l, FM 6,
shortwave 1 (2005)
Radios: NA
Television broadcast stations: 1 (on
Saipan; in addition, 2 cable services on
Saipan provide varied programming from
satellite networks) (2006)
Televisions: NA
Internet country code: mp
Internet hosts: 5 (2007)
Internet Service Providers (ISPs): 1
(2001)
Internet users: 10,000 (2003)
Telephones— main lines in use: 2.055
million (2006)
Telephones— mobile cellular: 5.041
million (2006)
Telephone system:
general assessment: modern in all respects;
one of the most advanced telecommuni¬
cations networks in Europe
domestic: Norway has a domestic satel¬
lite system; moreover, the prevalence of
rural areas encourages the wide use of
cellular-mobile systems instead of fixed-
wire systems
international: country code — 47; 2 buried
coaxial cable systems; submarine cables
provide links to other Nordic countries
and Europe; satellite earth stations — NA
Eutelsat, NA Intelsat (Atlantic Ocean),
and 1 Inmarsat (Atlantic and Indian
Ocean regions); note — Norway shares
the Inmarsat earth station with the other
Nordic countries (Denmark, Finland,
Iceland, and Sweden) (1999)
Radio broadcasf sfations: AM 5, FM at
least 650, shortwave 1 (1998)
Radios: 4.03 million (1997)
Television broadcasf sfafions: 360 (plus
2,729 repeaters) (1995)
Televisions: 2.03 million (1997)
Internet country code: no
Internet hosts: 2.084 million (2007)
Internet Service Providers (ISPs): 13
(2000)
Internet users: 4.074 million (2006)','a00482e1d5ec10ac3d434f552fc7500b6579227502141618fb135cf509e48e9a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('776e47a2d7044a4cdda576e6090c204e878f2343ed0693d2749a7c9ccab74481',2009,'OM','Oman','communications',963,'Telephones— main lines in use:
278,300 (2006)
Telephones— mobile cellular: 1.818
million (2006)
Telephone system:
general assessment: modern system con¬
sisting of open-wire, microwave, and
radiotelephone communication stations;
limited coaxial cable
domestic: fixed-line and mobile-cellular
subscribership both increasing; open-
wire, microwave, radiotelephone com¬
munications, and a domestic satellite
system with 8 earth stations
international: country code — 968; the
Fiber-Optic Link Around the Globe
(FLAG) and the SEA-ME-WE-3 subma¬
rine cable provide connectivity to Asia,
the Middle East, and Europe; satellite
earth stations — 2 Intelsat (Indian
Ocean), 1 Arabsat
Radio broadcast stations: AM 3, FM 9,
shortwave 2 (1999)
Radios: 1.4 million (1997)
Television broadcast stations: 13 (plus
25 repeaters) (1999)
Televisions: 1.6 million (1997)
Internet country code: om
Internet hosts: 3,763 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 319,200 (2006)','8a17ca4285faefedacfaacd5284a6a78652774ec5ac0cbe283ade0b3b1df4f75','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969ce233e263addf06f591e1844ebff6a7350be483a2794e1097a5be4e2fc074',2009,'PK','Pakistan','communications',971,'Telephones — main lines in use: 5.24
million (2006)
Telephones— mobile cellular: 63.16
million (2007)
Telephone system:
general assessment: the telecommunica¬
tions infrastructure is improving dramat¬
ically with foreign and domestic
investments into fixed-line and mobile
networks; mobile-cellular subscribership
has skyrocketed, reaching some 63 mil¬
lion in mid-2007, up from only about
300,000 in 2000; fiber systems are being
constructed throughout the country to
aid in network growth; main line avail¬
ability has risen only marginally over the
498','74d0949b2aab9463fe624662383f0d70103ccecac1d25546b1f5ae93e8936ce5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d672eaddb7ab2aa66e3f3b9ddbd413282d399e643037c9f0166edcd64e1b804',2009,'PW','Palau','communications',972,'same period and there are still difficulties
getting main line service to rural areas
domestic: microwave radio relay, coaxial
cable, fiber-optic cable, cellular, and
satellite networks
international: country code — 92; landing
point for the SEA-ME-WE-3 and SEA-
ME-WE-4 submarine cable systems that
provide links to Asia, the Middle East,
and Europe; satellite earth stations — 3
Intelsat ( 1 Atlantic Ocean and 2 Indian
Ocean); 3 operational international
gateway exchanges ( 1 at Karachi and 2 at
Islamabad); microwave radio relay to
neighboring countries (2006)
Radio broadcast stations: AM 31, FM
68, shortwave NA (2006)
Radios: 13.5 million (1997)
Television broadcast stations: 20 (5
state-run channels and 15 privately-
owned satellite channels) (2006)
Televisions: 3.1 million (1997)
Internet country code: pk
Internet hosts: 164,067 (2007)
Internet Service Providers (ISPs): 30
(2000)
Internet users: 12 million (2006)
Telephones — main lines in use: 6,700
(2002)
Telephones — mobile cellular: 1,000
(2002)
Telephone system:
general assessment: NA
domestic: NA
international: country code — 680; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 1, FM 4,
shortwave 1 (2001)
Radios: 12,000 (1997)
Television broadcast stations: l (cable)
(2005)
Televisions: 11,000 (1997)
Internet country code: pw
Internet hosts: 1 (2007)
Internet Service Providers (ISPs): l
(2002)','fb12774409f8bcc5391d3955376a76d04893e4945da5800b3032ff8454665099','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c87abd0fdd130f4a12cdad013c907ec38536682a27c8a98c81ea24ecbd4ba7',2009,'PA','Panama','communications',980,'Telephones— main lines in use:
432,900 (2006)
Telephones— mobile cellular: 1.694
million (2005)
Telephone system:
general assessment: domestic and interna¬
tional facilities well developed
domestic: combined fixed-line and
mobile-cellular teledensity is
approaching 70 per 100 persons
international: country code — 507;
landing point for the Americas Region
Caribbean Ring System (ARCOS-1),
the MAYA-1, and PAN -AM submarine
cable systems that together provide links
to the US, and parts of the Caribbean,
Central America, and South America;
satellite earth stations — 2 Intelsat
(Atlantic Ocean); connected to the
Central American Microwave System
Radio broadcast stations: AM 101, FM
134, shortwave 0 (1998)
Radios: 815,000 (1997)
Television broadcast stations: 38
(including repeaters) (1998)
Televisions: 510,000 (1997)
Internet country code: pa
Internet hosts: 7,078 (2007)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 220,000 (2006)','804cd3228e02a7c572437ff64c6881b1f4ecfa05ef6e0a5459c08752257b2d9f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab2bb9f4f9c8838e9ecb434e149034557723e36217029b331fc8049b0d96d401',2009,'PG','Papua New Guinea','communications',986,'Telephones— main lines in use: 63,700
(2005)
Telephones— mobile cellular: 75,000
(2005)
Telephone system:
general assessment: services are minimal;
facilities provide radiotelephone and
telegraph, coastal radio, aeronautical
radio, and international radio communi¬
cation services
domestic: access to telephone services is
not widely available; combined fixed-
line and mobile-cellular teledensity is
less than 3 per 100 persons
international: country code— 675; subma¬
rine cables to Australia and Guam; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean); international radio communica¬
tion service
Radio broadcast stations: AM 8, FM
19, shortwave 28 (1998)
Radios: 410,000 (1997)
Television broadcast stations: 3 (all in
the Port Moresby area; stations at Mt.
Hagen, Goroka, Lae, and Rabaul are
planned) (2004)
Televisions: 59,841 (1999)
Internet country code: pg
Internet hosts: 2,436 (2007)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 110,000 (2006)','8d2d00c38b802c7a6f29efbaad92262c4a377162650e32c80b70bed84b4028f9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('628ceaa2fcf6c9ff80ce522a97352f53a36101e6dbb7c42e42f22b863baf0b83',2009,'PH','Philippines','communications',1001,'Telephones— main lines in use: 3.633
million (2006)
Telephones— mobile cellular: 42.869
million (2006)
Telephone system:
general assessment: good international
radiotelephone and submarine cable
services; domestic and interisland service
adequate
domestic: domestic satellite system with
11 earth stations; cellular communica¬
tions now dominate the industry; com¬
bined fixed-line and mobile-cellular
telephone density exceeds 50 telephones
per 100 persons with more than 10
mobile cellular subscribers for every
fixed-line subscriber
international: country code — 63; a series
of submarine cables together provide
connectivity to Asia, US, the Middle
East, and Europe; multiple international
gateways (2006)
Radio broadcasf sfafions: AM 381, FM
628, shortwave 4 (each shortwave sta¬
tion operates on multiple frequencies in
the language of the target audience)
(2007)
Radios: 11.5 million (1997)
Television broadcasf stations: 250 (plus
1,501 CATV networks) (2007)
Televisions: 3.7 million (1997)
Internet country code: ph
Internet hosts: 271,609 (2007)
Internet Service Providers (ISPs): 33
(2000)
Internet users: 4.615 million (2005)
Telephones — main lines in use: l
(there are 17 telephones on one party
line); (2004)
Telephone system:
general assessment: satellite phone serv¬
ices
domestic: domestic communication via
radio (CB)
international: country code — 872; satel¬
lite earth station — 1 (Inmarsat)
Radio broadcast stations: AM l, FM 0,
shortwave 0 (15 Ham radio operators
(VP6)) (2004)
Radios: NA
Televisions: NA
Internet country code: pn
Internet hosts: 9 (2007)
Internet Service Providers (ISPs): NA
Internet users: NA','240aa28998bd2b5996c4648176ca0497a59cce232ea2dafab787db46e05b3348','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83d0e7804da4eca58bb3c5d4bc4e694f67e88a30ed4e1c2e1de42a9baf592f18',2009,'PL','Poland','communications',1005,'Telephones— main lines in use: 11.475
million (2006)
Telephones— mobile cellular: 36.746
million (2006)
Telephone system:
general assessment: modernization of the
telecommunications network has accel¬
erated with market based competition
finalized in 2003; fixed-line service,
dominated by the former state-owned
company, is dwarfed by the growth in
wireless telephony
domestic: mobile-cellular service avail¬
able since 1993 and provided by three
nation-wide networks with a fourth
provider beginning operations in late
2006; cellular coverage is generally good
with some gaps in the east; fixed-line
service is growing slowly and still lags in
rural areas
international: country code — 48; interna¬
tional direct dialing with automated
exchanges; satellite earth station — 1
with access to Intelsat, Eutelsat,
Inmarsat, and Intersputnik
Radio broadcast stations: AM 14, FM
777, shortwave 1 (1998)
Radios: 20.2 million (1997)
Television broadcast stations: 40
(2006)
Televisions: 13.05 million (1997)
Internet country code: pi
Internet hosts: 5.681 million (2007)
Internet Service Providers (ISPs): 19
(2000)
Internet users: 11 million (2006)
Airports: 123 (2007)
Airports— with paved runways:
total: 83
over 3,047 m: 4
523
THE CIA WORLD FACTBOOK
2,438 to 3,047 m: 30
1,524 to 2,437 m: 39
914 to 1,523 m: 7
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 40
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 13
under 914 m: 22 (2007)
Heliports: 7 (2007)
Pipelines: gas 13,552 km; oil 1,384 km;
refined products 777 km (2007)
Railways: total: 23,072 km
broad gauge: 629 km 1.524-m gauge
standard gauge: 22,443 km 1.435-m gauge
(20,555 km operational; 11,910 km elec¬
trified) (2006)
Roadways: total: 423,997 km
paved: 295,356 km (includes 484 km of
expressways)
unpaved: 128,641 km (2004)
Waterways: 3,997 km (navigable rivers
and canals) (2006)
Merchant marine:
total: 11 ships (1000 GRT or over)
55,701 GRT/45,082 DWT
by type: cargo 6, chemical tanker 2, pas-
senger/cargo 1, roll on/roll off 1, vehicle
carrier 1
foreign''Owned: 1 (Nigeria 1)
registered in other countries: 102 (Antigua
and Barbuda 2, Bahamas 15, Cyprus 18,
Liberia 14, Malta 25, Norway 3, Panama
15, Slovakia 2, St Vincent and The
Grenadines 1, Vanuatu 7) (2007)
Ports and terminals: Gdansk, Gdynia,
Swinoujscie, Szczecin','a8d004a08be82eaa71864dca3c9c6c1352800604acb74cdffe634552bd564661','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54633bb8bdb336b39f431028c0b1c2648566ace6bf2ea3b08196f28b4c1c0dbd',2009,'PR','Puerto Rico','communications',1010,'Telephones— main lines in use: 4.231
million (2006)
Telephones— mobile cellular: 12.226
million (2006)
Telephone system:
general assessment: Portugal’s telephone
system has achieved a state-of-the-art
network with broadband, high-speed
capabilities
domestic: integrated network of coaxial
cables, open-wire, microwave radio relay,
and domestic satellite earth stations
international: country code — 351; a com¬
bination of submarine cables provide
connectivity to Europe, North and East
Africa, South Africa, the Middle East,
Asia, and the US; satellite earth sta¬
tions— 3 Intelsat (2 Atlantic Ocean and
1 Indian Ocean), NA Eutelsat; tropos¬
pheric scatter to Azores (1998)
Radio broadcast stations: AM 47, FM
172 (many are repeaters), shortwave 2
(1998)
Radios: 3.02 million (1997)
Television broadcast stations: 62 (plus
166 repeaters; includes Azores and
Madeira Islands) (1995)
Televisions: 3.31 million (1997)
Internet country code: pt
Internet hosts: 836,616 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 3.213 million (2006)','ce21a661068522529b8b166bf94ac87d11a8ab5d7a5c941373a1d9fec7f0af34','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82524a918146c719f8388f38c8d65d1090661dd760e164ca32b6a8e20cd5caaf',2009,'QA','Qatar','communications',1018,'Telephones— main lines in use:
228,300 (2006)
Telephones— mobile cellular: 919,800
(2006)
Telephone system:
general assessment: modern system cen¬
tered in Doha
domestic: combined fixed-line and
mobile-cellular telephone density is
roughly 130 telephones per 100 persons
international: country code — 974;
landing point for the Fiber-Optic Link
Around the Globe (FLAG) submarine
cable network that provides links to
Asia, Middle East, Europe, and the US;
tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
and the UAE; satellite earth stations — 2
Intelsat ( 1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 6, FM 5,
shortwave 1 (1998)
Radios: 256,000 (1997)
Television broadcast stations: l (plus 3
repeaters) (2001)
Televisions: 230,000 (1997)
Internet country code: qa
Internet hosts: 19 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 289,900 (2006)','84536c962d211006388ca51b3ed67425015942df955f08c9481c27c06880fd16','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22f418889a895c253e0380ca49df21f0e4753ab7771f4fadcac6139ad8e5afa7',2009,'RW','Rwanda','communications',1030,'Telephone system:
general assessment: fully integrated access
domestic: direct dial capability with both
fixed and wireless systems
international: country code — 590;
undersea fiber-optic cable provides voice
and data connectivity to Puerto Rico and','a6a8ad7330e5cffd371a71bbe3fcd9acd3455cc0274260fb5dcca4e5c957caec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('625e7214894d82d2ff35032a722a6b06d7504609875e5093319b9234bf3bb585',2009,'GP','Guadeloupe','communications',1031,'Internet country code: bl; note— gp,
the ccTLD for Guadeloupe, and .fr, the
ccTLD for France, might also be
encountered
546
SAINT HELENA','281cc529d9d5163b8b064d56ec382cd315e8b5b81b6b7518626dffe31b2aaf2b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e0a9f8a3c1a3ed6dc99c58f6664008f52fc04cdc6f45e3ab7e5b77bd925330b',2009,'KN','Saint Kitts and Nevis','communications',1039,'Telephones— main lines in use: 2,200
(2002)
Telephone system:
general assessment: can communicate
worldwide
domestic: automatic digital network
international: country code (Saint
Helena) — 290, (Ascension Island) —
247; international direct dialing; satellite
voice and data communications; satellite
earth stations — 5 (Ascension Island — 4,
Saint Helena — 1 )
Radio broadcast stations: Saint Helena:
AM 1, FM 1, shortwave 0
Ascension: AM 1, FM 1, shortwave 1
(2005)
Radios: 3,000 (1997)
Television broadcast stations: 0 (3 tele¬
vision channels are received via satellite
and distributed by UHF) (2005)
Televisions: 2,000 (1997)
Internet country code: sh; note—
Ascension Island assigned .ac
Internet hosts: 283 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 1,000; note — includes
Ascension Island (2003)
Communications — note: South Africa
maintains a meteorological station on
Gough Island
Airports: 1 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Roadways:
total: 198 km (Saint Helena 138 km,
Ascension 40 km, Tristan da Cunha 20
km)
paved: 168 km (Saint Helena 118 km,
Ascension 40 km, Tristan da Cunha 10
km)
unpaved: 30 km (Saint Helena 20 km,
Ascension 0 km, Tristan da Cunha 10
km) (2002)
Ports and terminals: Saint Helena:
Jamestown
Ascension Island: Georgetown
Tristan da Cunha: Calshot Harbor
Transportation — note: there is no air
connection to Saint Helena or Tristan da
Cunha; an international airport for Saint
Helena is in development for 2010','bbf139ed6d7a98a2a7996bd41b43be2867b32a598ea57280d85f7bf299f5069e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb0982a3632008e1e38d3d2aba832484bd5668a7b6717e5081b7c6a51a0f8c9e',2009,'LC','Saint Lucia','communications',1043,'Telephones — main lines in use: 25,000
(2004)
Telephones — mobile cellular: 10,000
(2004)
Telephone system:
general assessment: good interisland and
international connections
domestic: interisland links via Eastern
Caribbean Fiber Optic cable; construe-
tion of enhanced wireless infrastructure
launched in November 2004
international: country code — 1-869; con¬
nected internationally by the East
Caribbean Fiber Optic System (ECFS)
and Southern Caribbean fiber optic
system (SCF) submarine cables
Radio broadcast stations: AM 3, FM 3,
shortwave 0 (2003)
Radios: 28,000 (1997)
Television broadcast stations: l (plus 3
repeaters) (2003)
Televisions: 10,000 (1997)
Internet country code: kn
Internet hosts: 45 (2007)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 10,000 (2002)','f692e888dd082252d00c84b2f5385b6a3268b67a0195775b8de5e3b255126831','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8ec7f8089bd91d236964560fdf747c716e3782a21fd3bb7276335cd08452cc1',2009,'VC','Saint Vincent and the Grenadines','communications',1057,'Telephones— main lines in use: 22,600
(2006)
Telephones — mobile cellular: 87,600
(2006)
Telephone system:
general assessment: adequate system
domestic: islandwide, fully automatic
telephone system; VHF/UHF radiotele¬
phone from Saint Vincent to the other
islands of the Grenadines; mobile-cel¬
lular teledensity about 75 telephones per
100 persons
international: country code — 1-784; the
East Caribbean Fiber Optic System
(ECFS) and Southern Caribbean fiber
optic system (SCF) submarine cables
carry international calls; connectivity
also provided by VFIF/UHF radiotele¬
phone from Saint Vincent to Barbados;
SHF radiotelephone to Grenada and
Saint Lucia; access to Intelsat earth sta¬
tion in Martinique through Saint Lucia
Radio broadcast stations: AM l, FM 6,
shortwave 0 (2004)
Radios: 77,000 (1997)
Television broadcast stations: l (plus 3
repeaters) (2004)
Televisions: 18,000 (1997)
Internet country code: vc
Internet hosts: 97 (2007)
Internet Service Providers (ISPs): 15
(2000)
Internet users: 10,000 (2005)','a19208c52d69b19a4af4284262c81c05c31b276f7b2e59141e802a04eb9e0cd6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b3a6d64251f65c9861837af8a428ac2a018054a5343f3010badd404252b2760',2009,'WS','Samoa','communications',1063,'Telephones— main lines in use: 19,500
(2005)
Telephones— mobile cellular: 24,000
(2005)
Telephone system:
general assessment: adequate
domestic: NA
international: country code — 685; sateh
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 5,
shortwave 0 (2004)
Radios: 174,849 (1997)
Television broadcast stations: 2 (2002)
Televisions: 8,634 (1999)
Internet country code: ws
Internet hosts: 10,156 (2007)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 8,000 (2006)','768e471c6322b964f80b089dbccc80badeb587734afa24c841b569d52db7ef1d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7ee519d93e07d1802c40b94d20849a332bc38cf242f986f9a5ab37277d0f2b',2009,'SA','Saudi Arabia','communications',1079,'Telephones— main lines in use: 4.5
million (2006)
Telephones— mobile cellular: 19.663
million (2006)
Telephone system:
general assessment: modem system
domestic: extensive microwave radio
relay, coaxial cable, and fiber-optic cable
systems; mobile-cellular subscribership
has been increasing rapidly
international: country code — 966;
landing point for the international sub¬
marine cable Fiber-Optic Link Around
the Globe (FLAG) and for both the
SEA-ME-WE-3 and SEA-ME-WE-4
submarine cable networks providing
connectivity to Asia, Middle East,
Europe, and US; microwave radio relay
to Bahrain, Jordan, Kuwait, Qatar, UAE,
Yemen, and Sudan; coaxial cable to
Kuwait and Jordan; satellite earth sta¬
tions — 5 Intelsat (3 Atlantic Ocean and
2 Indian Ocean), 1 Arabsat, and 1
Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 43, FM
31, shortwave 2 (1998)
Radios: 6.25 million (1997)
Television broadcast stations: 117
(1997)
Televisions: 5.1 million (1997)
Internet country code: sa
Internet hosts: 18,369 (2007)
Internet Service Providers (ISPs): 22
(2003)
Internet users: 4.7 million (2006)','d910b3e8b9694279507401b4322cba4711b2e4e8ac1b46a98bbd18095270324c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8cbe00d4365065865a0277dada816b693a7be86d47b4f080a24d4908c942d9',2009,'SN','Senegal','communications',1085,'Telephones— main lines in use:
282,600 (2006)
Telephones— mobile cellular: 2.983
million (2006)
Telephone system:
general assessment: good system
domestic: above-average urban system;
more than half of all fixed-line connec¬
tions are in Dakar with expansion of
fixed-line services in rural areas needed;
mobile-cellular service is expanding rap¬
idly; microwave radio relay, coaxial cable
and fiber-optic cable in trunk system
international: country code — 221; the
572','251faae128c9294d50f8c06f443da131b9de9bf434c02455ba192b7ad30f9929','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18302626aff27fe15cda5ad7bebfe1bf3be2cf186d4a08b95506acddf50ed90',2009,'RS','Serbia','communications',1086,'SAT-3/WASC fiber optic cable provides
connectivity to Europe and Asia while
AtlantiS''2 provides connectivity to
South America; satellite earth station —
1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM
20, shortwave 1 (2001)
Radios: 1.24 million (1997)
Television broadcast stations: 4 (2007)
Televisions: 361,000 (1997)
internet country code: .sn
Internet hosts: 199 (2007)
internet Service Providers (ISPs): l
(2002)
Internet users: 650,000 (2006)
Telephones— main lines in use: 2.719
million (2006)
Telephones— mobile cellular: 6.644
million (2006)
Telephone system:
general assessment: modernization of the
telecommunications network has been
slow as a result of damage stemming from
the 1999 war and transition to a compet¬
itive market-based system; network was
only 65% digitalized in 2005
domestic: teledensity remains below the
average for neighboring states; GSM
wireless service, available through mul¬
tiple providers with national coverage, is
growing very rapidly; best telecommuni¬
cations service limited to urban centers
international: country code — 381
Radio broadcast stations: 153 (station
types NA) (2001)
Internet country code: rs
Internet hosts: NA
Internet users: 1.4 million (2006)','3fa69913bf0bc4293c3f038f9b5d4e45db71f35d30fdb112e287d7d802ccd48c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f012ce6e3f0eea1ee1652889df0daf4ee2f385e3469f50ade30c14a370f8ece6',2009,'SC','Seychelles','communications',1095,'Telephones— main lines in use: 20,700
(2006)
Telephones— mobile cellular: 70,300
(2006)
Telephone system:
general assessment: effective system
domestic: combined fixed-line and
mobile-cellular teledensity is roughly
110 telephones per 100 persons;
radiotelephone communications
between islands in the archipelago
international: country code — 248; direct
radiotelephone communications with
adjacent island countries and African
coastal countries; satellite earth sta¬
tion — 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM l, FM l,
shortwave 2 (2001)
Radios: 42,000 (1997)
Television broadcast stations: 2 (plus 9
repeaters) (1997)
Televisions: 11,000 (1997)
Internet country code: sc
Internet hosts: 187 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 29,000 (2006)','1c93670c37acb470d6ae51b48a39c4c89c50b38b5ee901b75244f00f8dedb73c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb2fd80c7bc08d9d43e1548f3296bf16fd5e34572ad696d72c4b0c01a304a198',2009,'SG','Singapore','communications',1103,'Telephones— main lines in use: 24,000
(2002)
Telephones — mobile cellular: 113,200
(2003)
Telephone system:
general assessment: marginal telephone
service
domestic: the national microwave radio
relay trunk system connects Freetown to
Bo and Kenema
international: country code — 232; satel¬
lite earth station — 1 Intelsat (Atlantic
Ocean) (2000)
Radio broadcast stations: AM 1, FM 9,
shortwave 1 (2001)
Radios: 1.12 million (1997)
Television broadcast stations: 2 (1999)
Televisions: 53,000 (1997)
Internet country code: si
Internet hosts: 46 (2007)
Internet Service Providers (ISPs): 1
(2001)
Internet users: 10,000 (2005)
Telephones— main lines in use: 1.854
million (2006)
Telephones— mobile cellular: 4 789
million (2006)
Telephone system:
general assessment: excellent service
domestic: excellent domestic facilities;
launched 3G wireless service in February
2005; combined fixeddine and mobile-
cellular teledensity is about 150 tele¬
phones per 100 persons
international: country code — 65;
numerous submarine cables provide links
throughout Asia, Australia, the Middle
East, Europe, and US; satellite earth sta¬
tions -4; supplemented by VSAT cov¬
erage (2003)
Radio broadcast stations: AM 0, FM
17, shortwave 2 (2003)
Radios: 2.6 million (2000)
Television broadcast stations: 1 (broad¬
casting on six channels); additional
reception of numerous UFIF and VHF
signals originating in Malaysia and
Indonesia (2006)
Televisions: 1.33 million (1997)
Internet country code: sg
Internet hosts: 954,475 (2007)
Internet Service Providers (ISPs): 9
(2000)
Internet users: 1.717 million (2006)','5a3439f4da4416efaa127d6c57cdbc2b9803fb964997154ed36010ea39c6ca47','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20a6522ece3f30b5055ea91997fee3b6defe0d449d5c2eca635ee97f732c62d5',2009,'SK','Slovakia','communications',1115,'Telephones— main lines in use: 1.167
million (2006)
Telephones — mobile cellular: 4. 893
million (2006)
Telephone system:
general assessment: Slovakia has a
modern telecommunications system that
has expanded dramatically in recent
years with the growth in cellular services
domestic: analog system is now receiving
digital equipment and is being enlarged
with fiber-optic cable, especially in the
larger cities; 3 companies provide
nationwide cellular services
international: country code — 421; 3 inter¬
national exchanges (1 in Bratislava and
2 in Banska Bystrica) are available;
Slovakia is participating in several inter¬
national telecommunications projects
that will increase the availability of
external services
Radio broadcast stations: AM 15, FM
78, shortwave 2 (1998)
Radios: 3.12 million (1997)
Television broadcast stations: 80
(national broadcasting 6, regional 7,
local 67) (2004)
Televisions: 2.62 million (1997)
Internet country code: sk
Internet hosts: 821,816 (2007)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 2.256 million (2006)','a6c04db9e641e124f64fac2e2258808072753fbe06e75bf39efcdf935d622e6e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c819555a59bd8c4e0fac84a503b1df8f0c492681bb67489891044ed7e35c4151',2009,'SI','Slovenia','communications',1121,'Telephones — main lines in use:
837,500 (2006)
Telephones— mobile cellular: 1.82 mil¬
lion (2006)
Telephone system:
general assessment: well-developed
telecommunications infrastructure
domestic: combined fixed-line and
mobile-cellular teledensity exceeds 130
telephones per 100 persons
international: country code — 386
Radio broadcast stations: AM 10, FM
230, shortwave 0 (2006)
Radios: 805,000 (1997)
Television broadcast stations: 31
(2006)
Televisions: 710,000 (1997)
Internet country code: si
Internet hosts: 134,266 (2007)
Internet Service Providers (ISPs): ll
(2000)
Internet users: 1.251 million (2006)','3987387e75dbb3ad75fdaccaa25cefcf835f0503d99cbb7807b4c664838879b1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3fa41ca28d3bfce3ea50331ab77f68f339b7b0e2d4cc7acd0110220db219e59',2009,'SO','Somalia','communications',1127,'Telephones— main lines in use: 7,400
(2005)
Telephones— mobile cellular: 6,000
(2005)
Telephone system:
general assessment: NA
domestic: NA
international: country code — 677; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 1, FM l,
shortwave 1 (2004)
Radios: 57,000 (1997)
Televisions: 3,000 (1997)
Internet country code: sb
Internet hosts: 3,414 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 8,000 (2006)
Telephones— main lines in use:
100,000 (2005)
Telephones— mobile cellular: 500,000
(2005)
Telephone system: ngeneral assessment:
the public telecommunications system
was almost completely destroyed or dis¬
mantled during the civil war; private
wireless companies offer service in most
major cities and charge the lowest inter¬
national rates on the continent
domestic: local cellular telephone systems
have been established in Mogadishu and
in several other population centers
international: country code — 252; inter¬
national connections are available from
Mogadishu by satellite (2001)
Radio broadcast stations: AM o, FM 1 1
(also 1 station each in Puntland and
Somaliland), shortwave 1 (in
Mogadishu) (2001)
Radios: 470,000 (1997)
Television broadcast stations: 4 (2 in
Mogadishu and 2 in Hargeisa) (2001)
Televisions: 135,000 (1997)
Internet country code: so
Internet hosts: 0 (2007)
Internet Service Providers (ISPs): 3
(one each in Boosaaso, Hargeisa, and
Mogadishu) (2000)
Internet users: 94,000 (2006)','35ac90c4b401b8d0bd4ac3fa0a7a9ff9c804d97834563635664772a9481bc3e8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbdf847896cba397d128a00cc82736817e18294903b014e58c4c641a217348ba',2009,'GS','South Georgia and the South Sandwich Islands','communications',1139,'Telephone system:
general assessment: NA
domestic: NA
international: coastal radiotelephone sta¬
tion at Grytviken
Radio broadcast stations: 0 (2003)
Television broadcast stations: 0 (2003)
Internet country code: gs
Internet hosts: 193 (2007)
Ports and terminals: Grytviken
Military — note: defense is the responsi¬
bility of the UK','fd1e2a0d444a9351c36049f525353a0ba1d30be85b3bd05bca3a57514336796f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b858dc67c23bf95b5939c0d2eb16bce28862819823f6c9fc7a9facdc3f041672',2009,'LK','Sri Lanka','communications',1153,'.
Telephones— main lines in use: 2.742
million (2007)
Telephones— mobile cellular: 7.983
million (2007)
Telephone system:
general assessment: telephone services
have improved significantly and are
available in most parts of the country
domestic: national trunk network consists
mostly of digital microwave radio relay;
fiber-optic links now in use in Colombo
area and 2 fixed wireless local loops have
been installed; competition is strong in
mobile cellular systems and mobile cel¬
lular subscribership is increasing; com¬
bined fixed-line and mobile-cellular
teledensity is about 50 per 100 persons
international: country code — 94; the
SEA-ME-WE-3 and SEA-ME-WE-4
submarine cables provide connectivity to
Asia, Australia, Middle East, Europe,
US; satellite earth stations — 2 Intelsat
(Indian Ocean)
Radio broadcast stations: AM 15, FM
52, shortwave 4 (2007)
Radios: 3.85 million (1997)
Television broadcast stations: 14
(2006)
Televisions: 1.53 million (1997)
Internet country code: Ik
Internet hosts: 6,198 (2007)
Internet Service Providers (ISPs): 5
(2000)
Internet users: 428,000 (2006)','d6ca84cd0b0ea59e8acfcfc101d7cabec21c45b60a32ec59cba56df6b28471e7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b196110e6740c26de97144047e9c428b812837ad24b1c86b856fed6145a3250',2009,'CH','Switzerland','communications',1173,'Telephones— main lines in use: 5.04
million (2006)
Telephones — mobile cellular: 7.418
million (2006)
Telephone system:
general assessment: highly developed
telecommunications infrastructure with
excellent domestic and international
services
domestic: ranked among leading coun¬
tries for fixed-line teledensity and infra¬
structure; mobile-cellular subscribership
roughly 100 per 100 persons; extensive
cable and microwave radio relay net¬
works
international: country code — 41; satellite
earth stations — 2 Intelsat (Atlantic
Ocean and Indian Ocean)
Radio broadcast stations: AM 4, FM
113 (plus many low-power stations),
shortwave 2 (1998)
Radios: 7.1 million (1997)
Television broadcast stations: 115 (plus
1,919 repeaters) (1995)
Televisions: 3.31 million (1997)
Internet country code: ch
Internet hosts: 1.405 million (2007)
Internet Service Providers (ISPs): 44
(Switzerland and Liechtenstein) (2000)
Internet users: 4.36 million (2006)
Telephones— main lines in use: 3.243
million (2006)
Telephones— mobile cellular: 4 675
million (2006)
Telephone system:
general assessment: fair system currently
undergoing significant improvement and
digital upgrades, including fiber-optic
technology
domestic: the number of fixed-line con¬
nections has increased markedly since
2000; mobile-cellular service growing
rapidly and teledensity has reached 25
wireless telephones per 100 persons;
coaxial cable and microwave radio relay
network
international: country code — 963; subma¬
rine cable connection to Cyprus; satellite
earth stations — 1 Intelsat (Indian
Ocean) and 1 Intersputnik (Atlantic
Ocean region); coaxial cable and
microwave radio relay to Iraq, Jordan,
Lebanon, and Turkey; participant in
Medarabtel
Radio broadcast stations: AM 14, FM
2, shortwave 1 (1998)
Radios: 4.15 million (1997)
Television broadcast stations: 44 (plus
17 repeaters) (1995)
Televisions: 1.05 million (1997)
Internet country code: sy
Internet hosts: 119 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 1.5 million (2006)','d868e6a91fdbe2f48c37d8dbb7de90b508f1b6a916f569c81e37e6ba25e014fc','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8e91e764f961080a61e20d3938134fad9c7eae6053eecba66567f475e26c24a',2009,'TJ','Tajikistan','communications',1181,'Telephones— main lines in use:
280,200 (2005)
Telephones— mobile cellular: 265,000
(2005)
Telephone system:
general assessment: poorly developed and
not well maintained; many towns are not
linked to the national network
domestic: the domestic telecommunica¬
tions network has historically been under
funded and poorly maintained; main line
availability has not changed significantly
since 1998; cellular telephone use is
growing but geographic coverage
remains limited
international: country code — 992; linked
by cable and microwave radio relay to
other CIS republics and by leased con¬
nections to the Moscow international
gateway switch; Dushanbe linked by
Intelsat to international gateway switch
in Ankara (Turkey); satellite earth sta¬
tions — 3 (2 Intelsat and 1 Orbita)
(2006)
Radio broadcast stations: AM 8, FM
10, shortwave 2 (2002)
Radios: 1.291 million (1991)
Television broadcast stations: 6 (2006)
Televisions: 820,000 (1997)
Internet country code: tj
Internet hosts: 2,050 (2007)
Internet Service Providers (ISPs): 4
(2002)
Internet users: 19,500 (2005)','c013461c390094c5af32c9c563bbc41a71eb5b21b4e9408ae6f25b66ca0d9aeb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f9f02399d8f1594aee0653f98aaa0a14540bee7914d1f7de64174d1bbc0cb84',2009,'TH','Thailand','communications',1188,'Telephones— main lines in use: 7.073
million (2006)
Telephones— mobile cellular: 40.816
million (2006)
Telephone system:
640','efdde01bed8115eb3cbb12f8c8a035d0d7eb857c20cccede533544d0385d0ba7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cdfa40bdbb5591ead131a76deb99bdcc47253ec6caddb720c55f21d0ee5c235',2009,'TL','Timor-Leste','communications',1189,'general assessment: high quality system,
especially in urban areas like Bangkok
domestic: fixed line system provided by
both a government owned and commer¬
cial provider; wireless service expanding
rapidly and outpacing fixed lines
international: country code — 66; con¬
nected to major submarine cable systems
providing links throughout Asia,
Australia, Middle East, Europe, and US;
satellite earth stations — 2 Intelsat (1
Indian Ocean, 1 Pacific Ocean)
Radio broadcast stations: AM 238, FM
351, shortwave 6 (2007)
Radios: 13.96 million (1997)
Television broadcast stations: ill
(2006)
Televisions: 15.19 million (1997)
Internet country code: th
Internet hosts: 973,941 (2007)
Internet Service Providers (ISPs): 15
(2000)
Internet users: 8.466 million (2006)','2bf30f151eaf93890e8def8ed68635e4ec5589988f2bcc6e2d44527d4890a208','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a101be17c11bf62831eb6b3c0b08a8065bb90fedd377c4265a5ec864a6ffb14',2009,'TO','Tonga','communications',1204,'Telephones— main lines in use: 300
(2002)
Telephone system:
general assessment: modern satellite-
based communications system
domestic: radiotelephone service between
islands
international: country code — 690;
radiotelephone service to Samoa; gov¬
ernment-regulated telephone service
(TeleTok); satellite earth stations — 3
Radio broadcast stations: AM NA, FM
NA, shortwave NA (one radio station
provides service to all islands) (2002)
Radios: 1,000 (1997)
Internet country code: tk
Internet hosts: 249 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: NA','5ac0e3513a86e309d7efbfe480a06a9d62148a06757c6adbe6e2341e0d0ccf66','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a536373a4f59512e7578b0426c787816dc0e891039c4e3d916e57cfa43b780b0',2009,'ES','Spain','communications',1219,'Telephones— main lines in use:
325,500 (2006)
653
THE CIA WORLD FACTBOOK
Telephones— mobile cellular: 1.655
million (2006)
Telephone system:
general assessment: excellent interna-
tional service; good local service
domestic: mobile-cellular teledensity
exceeds 150 telephones per 100 persons
international: country code— 1-868; sub¬
marine cable systems provide connec¬
tivity to US and parts of the Caribbean
and South America; satellite earth sta¬
tion — 1 Intelsat (Atlantic Ocean); tro¬
pospheric scatter to Barbados and','c917795b149cf48dc8ad8993b15bab82d727a88500e4b6dccc644b5106f9f6a1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76783e27e08f3dbba80e016b6e293b91c93467b844f0a89f0df05141e03bab57',2009,'TN','Tunisia','communications',1227,'Telephones— main lines in use: 18.978
million (2005)
Telephones— mobile cellular: 52.663
million (2006)
Telephone system:
general assessment: undergoing rapid
modernization and expansion especially
with cellular telephones
domestic: additional digital exchanges are
permitting a rapid increase in sub¬
scribers; the construction of a network of
technologically advanced intercity trunk
lines, using both fiber-optic cable and
digital microwave radio relay, is facili¬
tating communication between urban
centers; remote areas are reached by a
domestic satellite system; the number of
subscribers to mobile-cellular telephone
service is growing rapidly
international: country code — 90; interna¬
tional service is provided by the SEA-
ME-WE-3 submarine cable and by
submarine fiber-optic cables in the
Mediterranean and Black Seas that iink
Turkey with Italy, Greece, Israel,
Bulgaria, Romania, and Russia; satellite
earth stations — 12 Intelsat; mobile satel¬
lite terminals — 328 in the Inmarsat and
Eutelsat systems (2002)
Radio broadcast stations: AM 16, FM
107, shortwave 6 (2001)
Radios: 11.3 million (1997)
Television broadcast stations: 635 (plus
2,934 repeaters) (1995)
Televisions: 20.9 million (1997)
Internet country code: tr
Internet hosts: 217,887 (2007)
Internet Service Providers (ISPs): 50
(2001)
Internet users: 12.284 million (2006)','2581dade1f31dfd5011808630bb94e3a1a469522f656a9860f617260ca5c48c8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cc08aa6a45bd7adcfe51ad778c586d0a7ed4fe0846a647110735244db2b30e3',2009,'TM','Turkmenistan','communications',1236,'Telephones— main lines in use:
495,000 (2006)
Telephones— mobile cellular: 216,900
(2006)
Telephone system:
general assessment: poorly developed
domestic: Turkmentelekom, in coopera¬
tion with foreign investors, is planning
to upgrade the country’s telephone
exchanges and install a new digital
switching system; mobile-cellular useage
remains limited
international: country code — 993; linked
by cable and microwave radio relay to
other CIS republics and to other coun¬
tries by leased connections to the
Moscow international gateway switch; a
new telephone link from Ashgabat to
Iran has been established; a new
exchange in Ashgabat switches interna¬
tional traffic through Turkey via Intelsat;
satellite earth stations — 1 Orbita and 1
Intelsat (2006)
Radio broadcast stations: AM 16, FM
8, shortwave 2 (1998)
Radios: 1.225 million (1997)
Television broadcast stations: 4 (gov¬
ernment-owned and programmed)
(2004)
Televisions: 820,000 (1997)
Internet country code: tm
Internet hosts: 97 (2007)
Internet Service Providers (ISPs): l
Internet users: 64,800 (2006)','5d3043bef70d00d76459e690016325f179d7262ab44ec9846e40faf8c2b6d69a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51dd5c280c7933c55ae2537cd7839ca5878b98c798c8ec03d0a98291585faf9a',2009,'TC','Turks and Caicos Islands','communications',1241,'Telephones— main lines in use: 5,700
(2002)
Telephones— mobile cellular: 1,700
(1999)
Telephone system:
general assessment: fully digital system
with international direct dialing
domestic: full range of services available;
GSM wireless service available
international: country code — 1-649; the
Americas Region Caribbean Ring
System (ARCOS-1) fiber optic telecom¬
munications submarine cable provides
connectivity to South and Central
America, parts of the Caribbean, and the
US; satellite earth station — 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 7,
shortwave 0 (2003)
Radios: 8,000 (1997)
Television broadcast stations: 0 (broad¬
casts received from The Bahamas; 2
cable television networks) (2003)
Televisions: NA
Internet country code: tc
Internet hosts: 2,310 (2007)
Internet Service Providers (ISPs): 14
(2000)
Internet users: NA','bdd3e6751716b1fd719874e9a5614c39563f70435c048a194a9a5e37e2f62635','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d96f2f8531bc133859dbc529e7f5822ec9fdf3d1f32715bcba70c44cea89b112',2009,'TV','Tuvalu','communications',1247,'Telephones— main lines in use: 900
(2005)
Telephones— mobile cellular: 1,300
(2005)
Telephone system:
general assessment: serves particular needs
for internal communications
domestic: radiotelephone communica¬
tions between islands
international: country code — 688; inter¬
national calls can be made by satellite
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (2004)
Radios: 4,000 (1997)
Television broadcast stations: 0 (2004)
Televisions: 800
Internet country code: tv
Internet hosts: 30,200 (2007)
Internet Service Providers (ISPs): l
(2000)
Internet users: 1,300 (2002)','8043a8a95ba692623a639b56d5dc1f078635ddfe08e690895eeea1b0f84471e5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('747fd4d13c11a96ebf59dba6a3810c42e2cf0074610d8bd249c961b79ac1f94a',2009,'AE','United Arab Emirates','communications',1261,'Telephones — mobile cellular: 49.076
million (2006)
Telephone system:
general assessment: Ukraine’s telecommu¬
nication development plan emphasizes
improving domestic trunk lines, interna¬
tional connections, and the mobile-cel¬
lular system
domestic: at independence in December
1991, Ukraine inherited a telephone
system that was antiquated, inefficient,
and in disrepair; more than 3.5 million
applications for telephones could not be
satisfied; telephone density is rising and
the domestic trunk system is being
improved; about one-third of Ukraine’s
networks are digital and a majority of
regional centers now have digital
switching stations; improvements in
local networks and local exchanges con¬
tinue to lag; the mobile-cellular tele¬
phone system is expanding rapidly
international: country code — 380; 2 new
domestic trunk lines are a part of the
fiber-optic Trans-Asia-Europe (TAE)
system and 3 Ukrainian links have been
installed in the fiber-optic Trans-
European Lines (TEL) project that con¬
nects 18 countries; additional
international service is provided by the
Italy-Turkey-Ukraine-Russia (1TUR)
fiber-optic submarine cable and by an
unknown number of earth stations in the
Intelsat, Inmarsat, and Intersputnik
satellite systems
Radio broadcast stations: 524 (station
types NA) (2006)
Radios: 45.05 million (1997)
Television broadcast stations: 647
(2006)
Televisions: 18.05 million (1997)
Internet country code: ua
Internet hosts: 234,349 (2007)
Internet Service Providers (ISPs): 260
(2001)
Internet users: 5.545 million (2006)
Telephones— main lines in use: 1.31
million (2006)
Telephones— mobile cellular: 5.519
million (2006)
Telephone system:
general assessment: modern fiber-optic
integrated services; digital network with
rapidly growing use of mobile-cellular
telephones; key centers are Abu Dhabi
and Dubai
domestic: microwave radio relay, fiber
optic and coaxial cable
international: country code — 971; linked
to the international submarine cable
FLAG (Fiber-Optic Link Around the
Globe); landing point for both the SEA-
ME-WE-3 AND SEA-ME-WE-4 subma¬
rine cable networks; satellite earth
stations — 3 Intelsat (1 Atlantic Ocean
and 2 Indian Ocean) and 1 Arabsat; tro¬
pospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 13, FM
8, shortwave 2 (2004)
Radios: 820,000 (1997)
Television broadcast stations: 15
(2004)
Televisions: 310,000 (1997)
Internet country code: ae
Internet hosts: 6,001 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 1.709 million (2006)','f4e9de88730af04c53c6569a7f55fb927040847a3e3e43dd1422021a6ec82668','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bb6632aabf1aa35e8ac9638992df24e948d00e7f57c81cefedfc00affbe88dc',2009,'GB','United Kingdom','communications',1270,'Telephones— main lines in use: 33.602
million (2006)
Telephones— mobile cellular: 69.657
million (2006)
Telephone system:
general assessment: technologically
advanced domestic and international
system
domestic: equal mix of buried cables,
microwave radio relay, and fiber-optic
systems
international: country code — 44;
numerous submarine cables provide links
throughout Europe, Asia, Australia, the
Middle East, and US; satellite earth sta¬
tions — 10 Intelsat (7 Atlantic Ocean
and 3 Indian Ocean), 1 Inmarsat
(Atlantic Ocean region), and 1 Eutelsat;
at least 8 large international switching
centers
Radio broadcasf stations: AM 219, FM
431, shortwave 3 (1998)
Radios: 84.5 million (1997)
Television broadcasf stations: 228 (plus
3,523 repeaters) (1995)
Televisions: 30.5 million (1997)
Internet country code: uk
Internet hosts: 5.118 million (2007)
Internet Service Providers (ISPs): more
than 400 (2000)
Internet users: 33.534 million (2006)','dacb4547f096a1a703594e14ceb090aa31506c73479bcb80690b3610233279b8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2219488380f08d33c3405ea8b5f4678d45c4c00fc72e707606ca1db410fb50',2009,'UY','Uruguay','communications',1280,'Telephones — main lines in use:
987,000 (2006)
Telephones — mobile cellular: 2.333
million (2006)
Telephone system:
general assessment: fully digitalized
domestic: most modern facilities concen¬
trated in Montevideo; new nationwide
microwave radio relay network; overall
fixed-line and mobile-cellular teleden-
sity is approaching 100 telephones per
100 persons
international: country code — 598; the
UNISOR submarine cable system pro¬
vides direct connectivity to Brazil and
Argentina; satellite earth stations — 2
Intelsat (Atlantic Ocean) (2002)
Radio broadcast stations: AM 93, FM
191, shortwave 7 (2005)
Radios: 1.97 million (1997)
Television broadcast stations: 62
(2005)
Televisions: 782,000 (1997)
Internet country code: uy
Internet hosts: 279,114 (2007)
Internet Service Providers (ISPs): 14
(2001)
Internet users: 756,000 (2006)
691
THE CIA WORLD FACTBOOK','03f4876f135cb82c408ffbd13ca7eedc67a69d6f8dd15d78c30fed1ca9dcaca9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9dcd33a4a879f3123df4ef3bf507de788b254b2a0258f20b361e32505fe10cc',2009,'UZ','Uzbekistan','communications',1286,'Telephones— main lines in use: 1.793
million (2005)
Telephones— mobile cellular: 5.8 mil¬
lion (2007)
Telephone system:
general assessment: antiquated and inade-
694
quate; in serious need of modernization
domestic: the main line telecommunica¬
tions system is dilapidated and telephone
density is low; the state-owned telecom¬
munications company, Uzbektelecom, is
working on improving main line serv¬
ices; mobile services are growing swiftly,
with the subscriber base more than dou¬
bling in 2007 to 5.8 million
international: country code — 998; linked
by landline or microwave radio relay
with CIS member states and to other
countries by leased connection via the
Moscow international gateway switch;
after the completion of the Uzbek link to
the Trans-Asia-Europe (TAE) fiber-optic
cable, Uzbekistan will be independent of
Russian facilities for international com¬
munications (2006)
Radio broadcast stations: AM 4, FM 6,
shortwave 3 (2006)
Radios: 10.8 million (1997)
Television broadcast stations: 28
(includes 1 cable rebroadcaster in
Tashkent and approximately 20 stations
in regional capitals) (2006)
Televisions: 6.4 million (1997)
Internet country code: uz
Internet hosts: 11,832 (2007)
Internet Service Providers (ISPs): 42
(2000)
Internet users: 1.7 million (2006)','4c4f3c81fa02f6e623ade79d0ec4960e53f333bdac3b2703f623bcbe159ac43f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('515c5eb861b159e6d32bfbed27117e88aaf629548f9c74a24767f46acf472950',2009,'VU','Vanuatu','communications',1289,'Telephones— main lines in use: 7,000
(2005)
Telephones— mobile cellular: 12,700
(2005)
Telephone system:
general assessment: NA
domestic: NA
international: country code — 678; satel¬
lite earth station — 1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 4,
shortwave 1 (2001)
Radios: 67,000 (1997)
Television broadcast stations: 1 (2004)
Televisions: 2,300 (1999)
Internet country code: vu
Internet hosts: 1,010 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 7,500 (2004)','5d5b24f1fff18be3d2cd1fd4ac452e5c694cb98cf50fe2a85e64065e17b8bf10','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3cc5eda7fa600111646846320502add36939fa617e0e88ec0542c7e053bcb73',2009,'NC','New Caledonia','communications',1296,'Telephones— main lines in use: 1,900
(2002)
Telephones— mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: country code — 681
Radio broadcast stations: AM l, FM 0,
shortwave 0 (2000)
Radios: NA
Television broadcast stations: 2 (2000)
Televisions: NA
Internet country code: .wf
Internet hosts: 1 (2007)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 900 (2002)
Telephones— main lines in use:
349,000 (includes Gaza Strip) (2005)
Telephones— mobile cellular: 1.095
million (includes Gaza Strip) (2005)
Telephone system:
general assessment: NA
domestic: Israeli company BEZEK and
the Palestinian company PALTEL are
responsible for fixed line services; the
Palestinian JAWAL company provides
cellular services
international: country code — 970 (2004)
Radio broadcast stations: AM 0, FM
25, shortwave 0 (2008)
Radios: NA; note — most Palestinian
households have radios (1999)
Television broadcast stations: 30
(2008)
Televisions: NA; note — many
Palestinian households have televisions
(1999)
Internet country code: ps; note— same
as Gaza Strip
Internet Service Providers (ISPs): 8
(1999)
Internet users: 243,000 (includes Gaza
Strip) (2005)','21462d0850882ad845c9b3b9dab47301021d21d78520820f365028a1c07dea11','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd3281af0f7ea594cabebf7fde395538b52e99da87675f54958058e58f1143e',2009,'EH','Western Sahara','communications',1304,'Telephones— main lines in use: about
2,000 (1999 est.)
Telephones— mobile cellular: 0 (1999)
Telephone system:
general assessment: sparse and limited
system
domestic: NA
international: country code — 212; tied
into Morocco’s system by microwave
radio relay, tropospheric scatter, and
satellite; satellite earth stations — 2
Intelsat (Atlantic Ocean) linked to
Rabat, Morocco
Radio broadcast stations: AM 2, FM 0,
shortwave 0 (1998)
Radios: 56,000 (1997)
Television broadcast stations: NA
Televisions: 6,000 (1997)
Internet country code: eh
Internet Service Providers (ISPs): 1
(2000)
Internet users: NA','62a2d679682d1ad4bd0797cd05b537ea50e0aed9494f1bd5a296d3239fa50a68','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42b72ef39eced73e93591cf0e28fb99db8e57d1c6e790d56296482b120dd3946',2009,'ZM','Zambia','communications',1312,'Telephones— main lines in use: 93,400
(2006)
Telephones— mobile cellular:
1,663,300 (2006)
Telephone system:
general assessment: facilities are aging but
still among the best in Sub-Saharan
Africa
domestic: high-capacity microwave radio
relay connects most larger towns and
cities; several cellular telephone services
in operation and network coverage is
improving; Internet service is widely
available; very small aperture terminal
(VSAT) networks are operated by pri¬
vate firms
international: country code — 260; satel¬
lite earth stations — 2 Intelsat (1 Indian
Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 19, FM
5, shortwave 4 (2001)
Radios: 1.2 million (2001)
Television broadcast stations: 9 (2001)
Televisions: 277,000 (1997)
Internet country code: zm
Internet hosts: 7,423 (2007)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 334,800 (2005)','d0a33feac5a9791ba2c2835ad5aeea104a1c0a8cf32c438cc471207d8ae555f3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7130ea7b9270099c58dc14ed20acbd14fe8021eff298cce0cf7b050982ab7cae',2009,'ZW','Zimbabwe','communications',1324,'Telephones— main lines in use:
331,700 (2006)
Telephones — mobile cellular: 832,500
(2006)
Telephone system:
general assessment: system was once one
of the best in Africa, but now suffers from
poor maintenance; more than 100,000
outstanding requests for connection
despite an equally large number of
installed but unused main lines
domestic: consists of microwave radio
relay links, open-wire lines, radiotele¬
phone communication stations, fixed
wireless local loop installations, and a
substantial mobile-cellular network;
Internet connection is available in
Harare and planned for all major towns
and for some of the smaller ones
international: country code — 263; satel¬
lite earth stations — 2 Intelsat; 2 interna¬
tional digital gateway exchanges (in
Harare and Gweru)
Radio broadcasf sfafions: AM 7, FM 20
(plus 17 repeater stations), shortwave 1
(1998)
Radios: 1.14 million (1997)
Television broadcast stations: 16
(1997)
Televisions: 370,000 (1997)
Internet country code: zw
Internet hosts: 15,507 (2007)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 1.22 million (2006)
Telephones— main lines in use: 14 497
million (2006)
Telephones — mobile cellular: 23.249
million (2006)
Telephone system:
general assessment: provides telecommu¬
nications service for every business and
private need
domestic: thoroughly modern; completely
digitalized
international: country code — -886;
numerous submarine cables provide links
throughout Asia, Australia, the Middle
East, Europe, and the US; satellite earth
stations — 2
Radio broadcast stations: AM 140, FM
229, shortwave 49
Radios: 16 million (1994)
Television broadcast stations: 76 (46
digital and 30 analog) (2007)
Televisions: 8.8 million (1998)
Internet country code: .tw
Internet hosts: 5.111 million (2007)
Internet Service Providers (ISPs): 8
(2000)
Internet users: 13.21 million (2005)
Telephones— main lines in use: 238
million (2005)
Telephones— mobile cellular: 466 mil¬
lion (2005)
Telephone system: note — see individual
country entries of member states
Radio broadcast stations: AM 930, FM
13,655, shortwave 71 (1998); note — sum
of individual country radio broadcast sta¬
tions; there is also a European-wide sta¬
tion (Euroradio)
Television broadcast stations: 2,700
(1995); note — sum of individual country
television broadcast stations excluding
repeaters; there is also a European-wide
station (Eurovision)
Internet country code: .eu (effective
2005); note — see country entries of
member states for individual country
codes
Internet hosts: 50.5 million (2005);
note — sum of individual country
Internet hosts
Internet users: 247 million (2006)','d26ec03097607e6b31e26379bd6d34c666f4f4869f2894a6d70ab1070d429e5e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48716ef148597f2975e9e1561d8fa5af71b412f90330f3b9d9097c00938aafd2',2009,'','','communications',6,'Telephones - main lines in use:
Telephones - mobile cellular:
Telephone system:
general assessment
domestic
international
Radio broadcast stations:
Television broadcast stations:
Internet country code:
Internet hosts :
Internet users:
Communications - note:','b2778f50484268aff33a3fab0af92d49c4f371ce94283512cff884a478d1c1b5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d349d2205ac27183c719c482b797151328cdb3690cda6532b7f683d0507e200',2009,'ZW','Zimbabwe','communications',14,'Telephones - main lines in use:
Telephones - mobile cellular:
Internet hosts:
Internet users:
This category deals with the means of exchanging information and
includes the telephone, radio, television, and Internet host entries.
Communications - note
This entry includes miscellaneous communications information of
significance not included elsewhere.
Constitution
This entry includes the dates of adoption, revisions, and major
amendments.
Coordinated Universal Time (UTC)
UTC is the international atomic time scale that serves as the basis
of timekeeping for most of the world. The hours, minutes, and
seconds expressed by UTC represent the time of day at the Prime
Meridian (0 deg. longitude) located near Greenwich, England as reckoned
from midnight. UTC is calculated by the Bureau International des
Poids et Measures (BIPM) in Sevres, France. The BIPM averages data
collected from more than 200 atomic time and frequency standards
located at about 50 laboratories worldwide. UTC is the basis for all
civil time with the Earth divided into time zones expressed as
positive or negative differences from UTC. UTC is also referred to
as "Zulu time." See the Standard Time Zones of the World map
included with the Reference Maps.
Country data codes
See Data codes.
Country map
Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time
of preparation. Names and/or boundaries may have changed
subsequently.
Country name
This entry includes all forms of the country''s name approved by the
US Board on Geographic Names (Italy is used as an example):
conventional long form (Italian Republic), conventional short form
(Italy), local long form (Repubblica Italiana), local short form
(Italia), former (Kingdom of Italy), as well as the abbreviation.
Also see the Terminology note.
Crude oil
See entry for oil.
Current account balance
This entry records a country''s net trade in goods and services, plus
net earnings from rents, interest, profits, and dividends, and net
transfer payments (such as pension funds and worker remittances) to
and from the rest of the world during the period specified. These
figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
D
Data codes
This information is presented in This information is presented in <a
href = "../appendix/appendix-d.html"Appendix D: Cross-Reference List
of Country Data Codes and and <a href =
"../appendix/appendix-e.html" Appendix E: Cross-Reference List of
Hydrographic Data Codes.
Date of information
In general, information available as of 1 January 2007 was used in
the preparation of this edition.
Daylight Saving Time (DST)
This entry is included for those entities that have adopted a policy
of adjusting the official local time forward, usually one hour, from
Standard Time during summer months. Such policies are most common in
mid-latitude regions.
Death rate
This entry gives the average annual number of deaths during a year
per 1,000 population at midyear; also known as crude death rate. The
death rate, while only a rough indicator of the mortality situation
in a country, accurately indicates the current mortality impact on
population growth. This indicator is significantly affected by age
distribution, and most countries will eventually show a rise in the
overall death rate, in spite of continued decline in mortality at
all ages, as declining fertility results in an aging population.
Debt - external
This entry gives the total public and private debt owed to
nonresidents repayable in foreign currency, goods, or services.
These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
Dependency status
This entry describes the formal relationship between a particular
nonindependent entity and an independent state.
Dependent areas
This entry contains an alphabetical listing of all nonindependent
entities associated in some way with a particular independent state.
Diplomatic representation
The US Government has diplomatic relations with 189 independent
states, including 187 of the 192 UN members (excluded UN members are
Bhutan, Cuba, Iran, North Korea, and the US itself). In addition,
the US has diplomatic relations with 2 independent states that are
not in the UN, the Holy See and Kosovo, as well as with the EU.
Diplomatic representation from the US
This entry includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office locations,
consulate general locations, and consulate locations.
Diplomatic representation in the US
This entry includes the chief of mission, chancery, telephone, FAX,
consulate general locations, and consulate locations.
Disputes - international
This entry includes a wide variety of situations that range from
traditional bilateral boundary disputes to unilateral claims of one
sort or another. Information regarding disputes over international
terrestrial and maritime boundaries has been reviewed by the US
Department of State. References to other situations involving
borders or frontiers may also be included, such as resource
disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or
recognition by the US Government.
Distribution of family income - Gini index
This index measures the degree of inequality in the distribution of
family income in a country. The index is calculated from the Lorenz
curve, in which cumulative family income is plotted against the
number of families arranged from the poorest to the richest. The
index is the ratio of (a) the area between a country''s Lorenz curve
and the 45 degree helping line to (b) the entire triangular area
under the 45 degree line. The more nearly equal a country''s income
distribution, the closer its Lorenz curve to the 45 degree line and
the lower its Gini index, e.g., a Scandinavian country with an index
of 25. The more unequal a country''s income distribution, the farther
its Lorenz curve from the 45 degree line and the higher its Gini
index, e.g., a Sub-Saharan country with an index of 50. If income
were distributed with perfect equality, the Lorenz curve would
coincide with the 45 degree line and the index would be zero; if
income were distributed with perfect inequality, the Lorenz curve
would coincide with the horizontal axis and the right vertical axis
and the index would be 100.
E
general assessment: system was once one of the best in
Africa, but now suffers from poor maintenance; more than 100,000
outstanding requests for connection despite an equally large number
of installed but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile-cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; 2 international digital gateway exchanges (in Harare and
Gweru)
======================================================================
@2125
Field Listing :: Terrain
This entry contains a brief description of the topography.
Country
Terrain
mostly high plateau with higher central plateau (high
veld); mountains in east
======================================================================
@2127
Field Listing :: Total fertility rate
This entry gives a figure for the average number of children that
would be born per woman if all women lived to the end of their
childbearing years and bore children according to a given fertility
rate at each age. The total fertility rate (TFR) is a more direct
measure of the level of fertility than the crude birth rate, since
it refers to births per woman. This indicator shows the potential
for population change in the country. A rate of two children per
woman is considered the replacement rate for a population, resulting
in relative stability in terms of total numbers. Rates above two
children indicate populations growing in size and whose median age
is declining. Higher rates may also indicate difficulties for
families, in some situations, to feed and educate their children and
for women to enter the labor force. Rates below two children
indicate populations decreasing in size and growing older. Global
fertility rates are in general decline and this trend is most
pronounced in industrialized countries, especially Western Europe,
where populations are projected to decline dramatically over the
next 50 years.
Country Comparison to the World
Country
Total fertility rate(children born/woman)
3.69 children born/woman (2009 est.)
======================================================================
@2128
Field Listing :: Government type
This entry gives the basic form of government. Definitions of the
major governmental terms are as follows. (Note that for some
countries more than one definition applies.):
Absolute monarchy - a form of government where the monarch rules
unhindered, i.e., without any laws, constitution, or legally
organized opposition.
Anarchy - a condition of lawlessness or political disorder brought
about by the absence of governmental authority.
Authoritarian - a form of government in which state authority is
imposed onto many aspects of citizens'' lives.
Commonwealth - a nation, state, or other political entity founded on
law and united by a compact of the people for the common good.
Communist - a system of government in which the state plans and
controls the economy and a single - often authoritarian - party
holds power; state controls are imposed with the elimination of
private ownership of property or capital while claiming to make
progress toward a higher social order in which all goods are equally
shared by the people (i.e., a classless society).
Confederacy (Confederation) - a union by compact or treaty between
states, provinces, or territories, that creates a central government
with limited powers; the constituent entities retain supreme
authority over all matters except those delegated to the central','1fe85f7e89a9abf4bc6d8f29f7129ef0dd898c2d2dc0a851b85ad4ffe858c2a6','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e71245f507627061bf7f599f8dc568fe6638d0f671a4c6e73138b582d059435b',2009,'ET','Ethiopia','communications',257,'domestic: radiotelephone communications between islands
international: country code - 688; international calls can be made
by satellite
Radio broadcast stations:
AM 1, FM 1, shortwave 0 (2004)
Television broadcast stations:
0 (2004)
Internet country code:
.tv
Internet hosts:
103,041 (2009)
country comparison to the world: 73
Internet users:
4,200 (2008)
country comparison to the world: 205
Transportation ::Tuvalu
Airports:
1 (2009)
country comparison to the world: 214
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2009)
Roadways:
total: 8 km
country comparison to the world: 219
paved: 8 km (2002)
Merchant marine:
total: 80
country comparison to the world: 55
by type: bulk carrier 7, cargo 30, chemical tanker 14, container 2,
passenger 2, passenger/cargo 1, petroleum tanker 22, refrigerated
cargo 1, specialized tanker 1
foreign-owned: 63 (China 16, Hong Kong 7, Kenya 1, South Korea 1,
Malaysia 1, Maldives 1, Norway 1, Russia 2, Singapore 23, Thailand
1, Turkey 2, Ukraine 1, US 1, Vietnam 5) (2008)
Ports and terminals:
Funafuti
Military ::Tuvalu
Military branches:
no regular military forces; Tuvalu Police Force (2008)
Manpower fit for military service:
males age 16-49: 2,462
females age 16-49: 2,631 (2009 est.)
Manpower reaching militarily significant age annually:
male: 125
female: 121 (2009 est.)
Military expenditures:
NA
Transnational Issues ::Tuvalu
Disputes - international:
none
page last updated on October 28, 2009
======================================================================
@Uganda (Africa)
Introduction ::Uganda
high plateau with central mountain range divided by Great
Rift Valley
European Union
fairly flat along the Baltic and Atlantic coast;
mountainous in the central and southern areas
Falkland Islands (Islas Malvinas)
rocky, hilly, mountainous with
some boggy, undulating plains
6.12 children born/woman (2009 est.)
European Union
1.51 children born/woman (2009 est.)
Falkland Islands (Islas Malvinas)
NA','a0f4adbc92adb4294fe1f62edf359b2c1abd040232e9d1b644811580a3e4c94c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca04403a5024daeec184dd858a37562b1f84fb746198946dc710403531be8e83',2009,'TV','Tuvalu','communications',1137,'domestic: radiotelephone communications between islands
international: country code - 688; international calls can be made
by satellite
low-lying and narrow coral atolls
2.91 children born/woman (2009 est.)','4021d960f62acdec74a9ae1f5c80d80035e1d7cbe4c5f9ce56b3297a27a51470','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('466ac9e3354e916738f7f81d58a377d446b354c567e9f0cb46bcb0672c57681e',2009,'UG','Uganda','communications',1138,'general assessment: seriously inadequate; mobile cellular
service is increasing rapidly, but the number of main lines is still
deficient; e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio relay, and
radiotelephone communication stations, fixed and mobile-cellular
systems for short-range traffic
international: country code - 256; satellite earth stations - 1
Intelsat (Atlantic Ocean) and 1 Inmarsat; analog links to Kenya and
Tanzania
mostly plateau with rim of mountains
6.77 children born/woman (2009 est.)','97cfa6c778e65cf87f7628d4db5710f7c6630b464873ce2004becfde70e2ceb8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d334cc1c236602d55daafd24439ae8c74e69ea424affca0a43cd89872fa2c59c',2009,'UA','Ukraine','communications',1139,'general assessment: Ukraine''s telecommunication development
plan emphasizes improving domestic trunk lines, international
connections, and the mobile-cellular system
domestic: at independence in December 1991, Ukraine inherited a
telephone system that was antiquated, inefficient, and in disrepair;
more than 3.5 million applications for telephones could not be
satisfied; telephone density is rising and the domestic trunk system
is being improved; about one-third of Ukraine''s networks are digital
and a majority of regional centers now have digital switching
stations; improvements in local networks and local exchanges
continue to lag; the mobile-cellular telephone system''s expansion
has slowed, largely due to saturation of the market which had
reached 120 mobile phones per 100 people by 2008
international: country code - 380; 2 new domestic trunk lines are a
part of the fiber-optic Trans-Asia-Europe (TAE) system and 3
Ukrainian links have been installed in the fiber-optic
Trans-European Lines (TEL) project that connects 18 countries;
additional international service is provided by the
Italy-Turkey-Ukraine-Russia (ITUR) fiber-optic submarine cable and
by an unknown number of earth stations in the Intelsat, Inmarsat,
and Intersputnik satellite systems
most of Ukraine consists of fertile plains (steppes) and
plateaus, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
1.26 children born/woman (2009 est.)','7be4aefedca5c7e7ae39e8b423f85b411566a6b2ff47bf456b697048d1f50b21','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89d51f847846aac9abdd88753b72da663a17152037d825669a6c045a90a9feee',2009,'AE','United Arab Emirates','communications',1140,'general assessment: modern fiber-optic
integrated services; digital network with rapidly growing use of
mobile-cellular telephones; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay, fiber optic and coaxial cable
international: country code - 971; linked to the international
submarine cable FLAG (Fiber-Optic Link Around the Globe); landing
point for both the SEA-ME-WE-3 and SEA-ME-WE-4 submarine cable
networks; satellite earth stations - 3 Intelsat (1 Atlantic Ocean
and 2 Indian Ocean) and 1 Arabsat; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in east
2.42 children born/woman (2009 est.)','13aeeeabbc4bfe143b8d5831d4f387b9e970d1441ea9329ce46058c77c5da319','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9061ce5a4e020ab74df3a818ed6a2ea363378502f3c5af50c7bf24215ebc00f',2009,'GB','United Kingdom','communications',1141,'general assessment: technologically advanced domestic
and international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: country code - 44; numerous submarine cables provide
links throughout Europe, Asia, Australia, the Middle East, and US;
satellite earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 Inmarsat (Atlantic Ocean region), and 1 Eutelsat;
at least 8 large international switching centers
mostly rugged hills and low mountains; level to
rolling plains in east and southeast
1.66 children born/woman (2009 est.)','e62cd361972617b4871402b678984878bf29f497411a25f4add0dd0a4188cb2c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec7bba1a242e24b46deb6af4481ab1a359f3691103973c12f6b9a221d492e0b',2009,'US','United States','communications',1142,'general assessment: a large, technologically advanced,
multipurpose communications system
domestic: a large system of fiber-optic cable, microwave radio
relay, coaxial cable, and domestic satellites carries every form of
telephone traffic; a rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: country code - 1; multiple ocean cable systems
provide international connectivity; satellite earth stations - 61
Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5 Intersputnik
(Atlantic Ocean region), and 4 Inmarsat (Pacific and Atlantic Ocean
regions) (2000)
vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
United States Pacific Island Wildlife Refuges
low and nearly level
sandy coral islands with narrow fringing reefs that have developed
at the top of submerged volcanic mountains, which in most cases rise
steeply from the ocean floor
2.05 children born/woman (2009 est.)','8b0809e2d260c7003572c93eb59ac3346225d690cb27087f3689d9129e721fdb','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a7234394ff4990c3360f50e46b4dc2b13ddb406632b50ab7bdcd8594570b0b3',2009,'UY','Uruguay','communications',1143,'general assessment: fully digitalized
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network; overall fixed-line and
mobile-cellular teledensity is 130 telephones per 100 persons
international: country code - 598; the UNISOR submarine cable system
provides direct connectivity to Brazil and Argentina; satellite
earth stations - 2 Intelsat (Atlantic Ocean) (2002)
mostly rolling plains and low hills; fertile coastal lowland
1.92 children born/woman (2009 est.)','a4f946153593640abda92984fcb052bf1f4d8d46818da4f77171e60acd8a9447','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('670e035cc65d638f0ad56ac86fa94c5a79703f7bf622cd2d41a7c601cbfee24e',2009,'UZ','Uzbekistan','communications',1144,'general assessment: antiquated and inadequate; in serious
need of modernization
domestic: the main line telecommunications system is dilapidated and
telephone density is low; the state-owned telecommunications
company, Uzbektelecom, is using loans from the Japanese government
and the China Development Bank to improve mainline services;
completion of conversion to digital exchanges planned for 2010;
mobile services are growing rapidly, with the subscriber base
reaching 12.7 million in 2008
international: country code - 998; linked by fiber-optic cable or
microwave radio relay with CIS member states and to other countries
by leased connection via the Moscow international gateway switch;
after the completion of the Uzbek link to the Trans-Asia-Europe
(TAE) fiber-optic cable, Uzbekistan plans to establish a fiber-optic
connection to Afghanistan (2008)
mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya,
Syr Darya (Sirdaryo), and Zarafshon; Fergana Valley in east
surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral
Sea in west
1.95 children born/woman (2009 est.)','033a69858434d8d1f177b35f983ce28713450821c2e07f62fc22a3d63bf231dc','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de055f99f58aacd05c5acd8b7dcff5567ace5e58727c052131dd1bba9763bd84',2009,'VU','Vanuatu','communications',1145,'general assessment: NA
domestic: NA
international: country code - 678; satellite earth station - 1
Intelsat (Pacific Ocean)
Venezuela
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth stations; recent
substantial improvement in telephone service in rural areas;
substantial increase in digitalization of exchanges and trunk lines;
installation of a national interurban fiber-optic network capable of
digital multimedia services; combined fixed and mobile-cellular
telephone subscribership 125 per 100 persons
international: country code - 58; submarine cable systems provide
connectivity to the Caribbean, Central and South America, and US;
satellite earth stations - 1 Intelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador, Peru, and Bolivia in
the construction of an international fiber-optic network (2007)
Vietnam
general assessment: Vietnam is putting considerable effort
into modernization and expansion of its telecommunication system
domestic: all provincial exchanges are digitalized and connected to
Hanoi, Da Nang, and Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; main lines have been substantially
increased, and the use of mobile telephones is growing rapidly
international: country code - 84; a landing point for the
SEA-ME-WE-3, the C2C, and Thailand-Vietnam-Hong Kong submarine cable
systems; the Asia-America Gateway submarine cable system, scheduled
for completion by the end of 2008, will provide new access links to
Asia and the US; satellite earth stations - 2 Intersputnik (Indian
Ocean region)
Virgin Islands
general assessment: modern system with total digital
switching, uses fiber-optic cable and microwave radio relay
domestic: full range of services available
international: country code - 1-340; submarine cable connections to
US, the Caribbean, Central and South America; satellite earth
stations - NA
Wake Island
general assessment: satellite communications; 2 DSN
circuits off the Overseas Telephone System (OTS)
domestic: NA
international: NA
mostly mountainous islands of volcanic origin; narrow
coastal plains
Venezuela
Andes Mountains and Maracaibo Lowlands in northwest;
central plains (llanos); Guiana Highlands in southeast
Vietnam
low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
Virgin Islands
mostly hilly to rugged and mountainous with little
level land
Wake Island
atoll of three low coral islands, Peale, Wake, and
Wilkes, built up on an underwater volcano; central lagoon is former
crater, islands are part of the rim
2.5 children born/woman (2009 est.)
Venezuela
2.48 children born/woman (2009 est.)
Vietnam
1.83 children born/woman (2009 est.)
Virgin Islands
1.85 children born/woman (2009 est.)','81a66572768d0ab47a40f229e356efb23f9623f737018319114c2a1131ab2e69','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e432d4c0d70adac3f3f5a6f66eba4e4d36844f995ef333a14e0984abbcf31d3',2009,'WF','Wallis and Futuna','communications',1146,'general assessment: NA
domestic: NA
international: country code - 681
West Bank
general assessment: NA
domestic: Israeli company BEZEK and the Palestinian company PALTEL
are responsible for fixed line services; the Palestinian JAWAL
company provides cellular services
international: country code - 970 (2004)
volcanic origin; low hills
West Bank
mostly rugged dissected upland, some vegetation in west,
but barren in east
1.87 children born/woman (2009 est.)
West Bank
3.22 children born/woman (2009 est.)','936f6a46be740fafb35b2edc32697c34b1e4429e7a6514ca32d52cf67741f471','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90c3e7cca0bab7103396b93e99cfb800f0c8fc20b3ce249d59aa62aeb7c2b912',2009,'EH','Western Sahara','communications',1147,'general assessment: sparse and limited system
domestic: NA
international: country code - 212; tied into Morocco''s system by
microwave radio relay, tropospheric scatter, and satellite;
satellite earth stations - 2 Intelsat (Atlantic Ocean) linked to
Rabat, Morocco
World
general assessment: NA
domestic: NA
international: NA
mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
World
the greatest ocean depth is the Mariana Trench at 10,924 m in
the Pacific Ocean
NA 5.61 children born/woman (2009 est.)
World
2.58 children born/woman (2009 est.)','7f4ffb506b70e0bf42e4d99f1278029e040358b2d32b8583e7fe56fa071a8e98','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b13ed49f96fe321c91fa17ddf05263f945bacc3b5aeade0fc0b929d23359a3f',2009,'YE','Yemen','communications',1148,'general assessment: since unification in 1990, efforts have
been made to create a national telecommunications network
domestic: the national network consists of microwave radio relay,
cable, tropospheric scatter, GSM and CDMA mobile-cellular telephone
systems; fixed-line and mobile-cellular teledensity remains low by
regional standards
international: country code - 967; landing point for the
international submarine cable Fiber-Optic Link Around the Globe
(FLAG); satellite earth stations - 3 Intelsat (2 Indian Ocean and 1
Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region), and 2
Arabsat; microwave radio relay to Saudi Arabia and Djibouti
narrow coastal plain backed by flat-topped hills and rugged
mountains; dissected upland desert plains in center slope into the
desert interior of the Arabian Peninsula
6.32 children born/woman (2009 est.)','539489c212d9bf29e3007fa015e9f43a95a8a1a6d72f63c2e0454dac9088fc32','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79d95a4eb93db302cee5d85b3955ad1f80436e89b5f9b0cd2e4efad00c15fdfc',2009,'ZM','Zambia','communications',1149,'general assessment: facilities are aging but still among the
best in Sub-Saharan Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities; several cellular telephone services in operation
and network coverage is improving; Internet service is widely
available; very small aperture terminal (VSAT) networks are operated
by private firms
international: country code - 260; satellite earth stations - 2
Intelsat (1 Indian Ocean and 1 Atlantic Ocean)
mostly high plateau with some hills and mountains
5.15 children born/woman (2009 est.)','6db769c9ccba121fe8d09b15b032a9b86321d865234572e0b7af62a2885110f2','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('180e5baee008e8b88d84754b524616975f2cebb0eb9499310b30d1a9ba2b1431',2009,'AF','Afghanistan','communications',1150,'mostly rugged mountains; plains in north and southwest
6.53 children born/woman (2009 est.)','9e3a35b1891be2b81978f6cc2a0aaa3b9787e8f7bc9bb673e2be78ef03041083','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2867a7373ef7a5fe49a48bb8a72dacb0124ea26eef88848e7a7bc3dd31733e32',2009,'AL','Albania','communications',1151,'mostly mountains and hills; small plains along coast
2.01 children born/woman (2009 est.)','091a6433e36cf0b7368b1728c01bc13d7e5ecb3e4ff805d0e1567ea89ee7b8b5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68cff21c8b430be0b5980e300c52186a23598437bfbc15c17ecbca752f260944',2009,'DZ','Algeria','communications',1152,'mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
1.79 children born/woman (2009 est.)','f9492f6f44cad5787076270b9be49ab2cf90d4385e2c8af1bd59f05ea1f94325','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef27c64bdd2423b71e3fdc301e2b5b36a2f56fdcfb9d7347792c4303adcbd87',2009,'AS','American Samoa','communications',1153,'five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
3.29 children born/woman (2009 est.)','92beeb19d54e60c9d154fc08cb4e46f762b79829451482a60d22083bea2cc031','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea9e293cea952184627e673cd28d566ea2b5338cd4213baf08ac5e04aea20cbc',2009,'AD','Andorra','communications',1154,'rugged mountains dissected by narrow valleys
1.33 children born/woman (2009 est.)','ef62f06318e99893db5d0fa91c4d3facaa011f64f3f69761b8515d7e13994084','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a375030a850e411463a803f38c78f31c8dc06b3cb61a9d96aa2c3d3bdc58fd0',2009,'AO','Angola','communications',1155,'narrow coastal plain rises abruptly to vast interior plateau
6.12 children born/woman (2009 est.)','24684565bd5def905d02501375d96e638a79a8febe7838e5ca427f02e86cb9a1','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65869cacf0b93e380e7d486b00cafdd5117cbf6dcaa1318311a57bfeaf3a16a7',2009,'AI','Anguilla','communications',1156,'flat and low-lying island of coral and limestone
1.75 children born/woman (2009 est.)','b32143f05de8a489b1a5034ccc8f0bd40e260a5cc91c0ae37600255ec889db7a','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96e69e81f0a98fb1ec9b11ed3619973fec7f5b3a74c5d0cad50fc71877166a3e',2009,'AQ','Antarctica','communications',1157,'about 98% thick continental ice sheet and 2% barren rock,
with average elevations between 2,000 and 4,000 meters; mountain
ranges up to nearly 5,000 meters; ice-free coastal areas include
parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent','7eb85f57b812692abdb6fea991f259c9799890e2192d3aeb68071391ae0c18b0','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b94e521f45c1f3ded083783037a3ab60a141c6af2aa4b16c9aeef7779114915',2009,'AG','Antigua and Barbuda','communications',1158,'mostly low-lying limestone and coral islands,
with some higher volcanic areas
Arctic Ocean
central surface covered by a perennial drifting polar
icepack that, on average, is about 3 meters thick, although pressure
ridges may be three times that thickness; clockwise drift pattern in
the Beaufort Gyral Stream, but nearly straight-line movement from
the New Siberian Islands (Russia) to Denmark Strait (between
Greenland and Iceland); the icepack is surrounded by open seas
during the summer, but more than doubles in size during the winter
and extends to the encircling landmasses; the ocean floor is about
50% continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonosov Ridge)
2.07 children born/woman (2009 est.)','d2e0ef02bed2942727ec11dff8664d9c37c0f7fee8c767fb18d6e816ea341f71','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('984a8c043d0e337df89e1ee7d7b824633eeef78c06a95c08e23cb84dbf60efde',2009,'AR','Argentina','communications',1159,'rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
2.35 children born/woman (2009 est.)','69ff51112f3331d738e263813b31496ad52f532597eddc8e49f426701e374704','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5610ca31fa8496c15a192b1b193eb2f101275e99e012b2c9fda97e434949fecd',2009,'AM','Armenia','communications',1160,'Armenian Highland with mountains; little forest land; fast
flowing rivers; good soil in Aras River valley
1.36 children born/woman (2009 est.)','5554c7eafc23ec43178545346c3f60c8991bfa2d7946c55c467969dbe2859147','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fafc4dab42a0bd4c13fb373f3063906b2fb77582dd44d04344686c03a6a943bf',2009,'AW','Aruba','communications',1161,'flat with a few hills; scant vegetation
Ashmore and Cartier Islands
low with sand and coral
Atlantic Ocean
surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and coastal portions of the Baltic Sea from October
to June; clockwise warm-water gyre (broad, circular system of
currents) in the northern Atlantic, counterclockwise warm-water gyre
in the southern Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline for the entire
Atlantic basin
1.85 children born/woman (2009 est.)','1ef3c0c35195e12c4a01d64b9374ff1308347717d8c0819f0d60a27238352c31','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b48eed473e9218c9839a95762cf65395d3e91b53b93a104a7ebf7d08081185f9',2009,'AU','Australia','communications',1162,'mostly low plateau with deserts; fertile plain in southeast
1.78 children born/woman (2009 est.)','63db922fd04f3e085ca315bf5e6c3997c5552f46847d79bd2d14b3bf36a0e3a4','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f81c9a3b1c2fde6351a2656e86a6a3562eedab2520817b399e64d402589a269c',2009,'AT','Austria','communications',1163,'in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
1.39 children born/woman (2009 est.)','4a851cc031190bd04420af31c52d6970897c5f41296b08571edf0eb93eeb9d58','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e68575c6bc82d576ed06ff971b813b8644bf15099e130a2140067cfd62e046',2009,'AZ','Azerbaijan','communications',1164,'large, flat Kur-Araz Ovaligi (Kura-Araks Lowland) (much
of it below sea level) with Great Caucasus Mountains to the north,
Qarabag Yaylasi (Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Bahamas, The
long, flat coral formations with some low rounded hills
2.04 children born/woman (2009 est.)
Bahamas, The
2.1 children born/woman (2009 est.)','52c6923e6a8f87b13921a8180bc2534f2bc1f6bdc43c51415e1458e64adde4a9','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e546b07385ae872bf29a89284cd6cad62f6a90864684bea67a880fd02a637989',2009,'BH','Bahrain','communications',1165,'mostly low desert plain rising gently to low central
escarpment
2.5 children born/woman (2009 est.)','2828b0945a5a82ff9c030e6ef7a37dd9712e2ec95bd8bb0894dd0ef647e34a5a','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26c8da0885206fb7706cfca383d03735ad6413755a5c0b73bd353459a7425a52',2009,'BD','Bangladesh','communications',1166,'mostly flat alluvial plain; hilly in southeast
2.74 children born/woman (2009 est.)','7c39e63daf084676ccac3197394ed354b434d4f0ee6a5c1112a94f188250fa40','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b82039703d5f11526aecbc747d2ebbaf7c61167245384207ac2270acc5058343',2009,'BB','Barbados','communications',1167,'relatively flat; rises gently to central highland region
1.68 children born/woman (2009 est.)','cbddbdb401df03a679254adb63b7680515c0a70365f67a0e0c94f7954bc2b0e1','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c00ca4f2aca0a737722a6cd604e6e08b025f2ea4736d1ca72ad42434277d1e0b',2009,'BE','Belgium','communications',1168,'flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
1.65 children born/woman (2009 est.)','13ec5800071c836d165f7a8d159a0cf321237c9ff919a0378296883f93fd2d05','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dc02e7b3afde05edc647873fb10d2061c7c508f23338214b106ab7820dd837d',2009,'BZ','Belize','communications',1169,'flat, swampy coastal plain; low mountains in south
3.36 children born/woman (2009 est.)','75827049e3d0fe04adf2b1057f15b051762efd37a55d19d217ef89c31780763b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c529847180b9a36ea7ebc38b32f12132526e634453cde764ad63eb2f0545a6ab',2009,'BJ','Benin','communications',1170,'mostly flat to undulating plain; some hills and low mountains
5.49 children born/woman (2009 est.)','001ce530dda36f6dfc0a396cf68fc064e871b41ef454214a388d9b41a261c85d','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dbddee0900781938b6d9b3e0123c3bd81bdaa056ed63a21f877a6641ed782c8',2009,'BT','Bhutan','communications',1171,'mostly mountainous with some fertile valleys and savanna
Bolivia
rugged Andes Mountains with a highland plateau (Altiplano),
hills, lowland plains of the Amazon Basin
2.38 children born/woman (2009 est.)
Bolivia
3.17 children born/woman (2009 est.)','a0eb92e447963b4ae479fdfac2238adce9e3a2328896b31cecf4538bcb3f9ada','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86f6078fd28adf9be347537a28eb5bc29528b9a0a2afa90b62235dfbe20a78d6',2009,'BW','Botswana','communications',1172,'predominantly flat to gently rolling tableland; Kalahari
Desert in southwest
2.6 children born/woman (2009 est.)','ea7134c8aa4840220171220c0bb77abfa0bcd659eb9f2220e6108b2f0fea7fcd','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc5a4148d1bdfc8fe63e2784f71be802cee9fd92a919221fe5543181dc3f0046',2009,'BR','Brazil','communications',1173,'mostly flat to rolling lowlands in north; some plains, hills,
mountains, and narrow coastal belt
2.21 children born/woman (2009 est.)
British Virgin Islands
1.71 children born/woman (2009 est.)
Brunei
1.91 children born/woman (2009 est.)','8f78790c9ada32a4a29befb43a58d1f2e8dc2808995eb2082713130e51ad1629','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04bd5d14846b29009531328a850628bb9bac41271e1ece48e16fb58e098cd500',2009,'IO','British Indian Ocean Territory','communications',1174,'flat and low (most areas do not
exceed two meters in elevation)
British Virgin Islands
coral islands relatively flat; volcanic
islands steep, hilly
Brunei
flat coastal plain rises to mountains in east; hilly lowland
in west','3bee8daba069d82f1d764222691f66ab7e16cf1ed99bfea710ac331670e3949b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b00d23754bdf4f5653d2fb02c7e4101e2abed7b4d4d808c694d961595ccc81',2009,'BG','Bulgaria','communications',1175,'mostly mountains with lowlands in north and southeast
1.41 children born/woman (2009 est.)','5f081913f92237c4e768d932c354549ba24457589137250fd505f4d91994eb14','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6640010c1a2a0b764fdea370a03c6b1d253d222eb28ff605b33b466abcd7a601',2009,'BF','Burkina Faso','communications',1176,'mostly flat to dissected, undulating plains; hills in
west and southeast
Burma
central lowlands ringed by steep, rugged highlands
6.28 children born/woman (2009 est.)
Burma
1.89 children born/woman (2009 est.)','6670919ac17a53d346dc008341a825a9d5f5e3bae4f0f3b0b2337a3ae861ee67','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0b1150a66dc652804200dba53409d3a84a0554a53b4d350a1b7794d3cabb6c',2009,'BI','Burundi','communications',1177,'hilly and mountainous, dropping to a plateau in east, some
plains
6.33 children born/woman (2009 est.)','cfa6b3342708acf071ca56383a4b9402f42abc0eb4757ecee112beee3809afe6','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e14730d6cb5044a14f7e4bbb278edc073de9913458d15a48b4e04c69f26b012',2009,'KH','Cambodia','communications',1178,'mostly low, flat plains; mountains in southwest and north
3.04 children born/woman (2009 est.)','64d28696030cb40b617bc09cb4e31573ac9c228e55435392fc38f889eacba06c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9f62cb680396b6287645e41644823daabfdcb3b6b3af03a33c56d47c0080f42',2009,'CM','Cameroon','communications',1179,'diverse, with coastal plain in southwest, dissected plateau
in center, mountains in west, plains in north
4.33 children born/woman (2009 est.)','a70c6dcbda23cda40e09cc1f49397fcb011486fae9334b6b3c7f47b74b22b5a0','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('822d296930b0991c2edd0342131ed639de69233e075056889b24e428123fac25',2009,'CA','Canada','communications',1180,'mostly plains with mountains in west and lowlands in southeast
Cape Verde
steep, rugged, rocky, volcanic
1.58 children born/woman (2009 est.)
Cape Verde
3.07 children born/woman (2009 est.)','85921803da789aa11cd6dd62e54099dbee7ecdff5981897316efb73297692630','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e3db0cb10a3ab985b237ae06610b1daa5a51c3870a6591038eca9093e23b199',2009,'KY','Cayman Islands','communications',1181,'low-lying limestone base surrounded by coral reefs
1.88 children born/woman (2009 est.)','4f90e6741b76c39d201fe4aaaecd9dcdb9958dd14e94aef7394612f83490324d','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ad15ad512dd15f948169779099b0067daa69b7bf129f355a7b523daaa92fec8',2009,'CF','Central African Republic','communications',1182,'vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
4.14 children born/woman (2009 est.)','96f7e2025727da2cab3014e527b36e83246c0bf261473fec0070dca092d43def','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('709d2df4d9e71a4979ec5c13cc8c298b12bc0526d8c488658d406960469f6d15',2009,'TD','Chad','communications',1183,'broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
5.31 children born/woman (2009 est.)','387e3c54f73fbe9e7a424eb1547dad76b56c69ba711bcf872ffc1a9173fde35c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c8e63ad5e9bfaa815d8f1faf934cf3ca6c3c25283731f2905c90415e9104f6b',2009,'CL','Chile','communications',1184,'low coastal mountains; fertile central valley; rugged Andes in
east
1.92 children born/woman (2009 est.)','d595fbd10b99efca34340ded00c6755bcfa83a4d57e90050138ec104b9444e61','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc891d35e4a47501d21148c676a90e7829f91b117b7b04da874a84fdf93f9769',2009,'CN','China','communications',1185,'mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
1.79 children born/woman (2009 est.)','d9f473d9e886e498605a32d1f783517888227526e5a4b5e32c2e0b76b5e79057','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5502562b2cbff8cbc3a11234858b544bde702762a38c179eee14688491b00b',2009,'CX','Christmas Island','communications',1186,'steep cliffs along coast rise abruptly to central
plateau
Clipperton Island
coral atoll
NA','57e2e6015417b17b7915b5175143c4a034360dd14ceab8cf8eb621d98ebd39f4','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f5f75c2643093565baeb47bb1a576ac7bc84aa2e87bc486a87f42a51a750d86',2009,'CO','Colombia','communications',1187,'flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
2.46 children born/woman (2009 est.)','9b43e7bf24e8b4dc14c8070791a7ac721fb4da0e16352034fa83f02a74fabbf2','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3b166515d554cb420416884508e0c5d4b28dfc5cdb5c42d1cbbd53dc098b64f',2009,'KM','Comoros','communications',1188,'volcanic islands, interiors vary from steep mountains to low
hills
Congo, Democratic Republic of the
vast central basin is a low-lying
plateau; mountains in east
Congo, Republic of the
coastal plain, southern basin, central
plateau, northern basin
4.84 children born/woman (2009 est.)
Congo, Democratic Republic of the
6.2 children born/woman (2009 est.)
Congo, Republic of the
5.84 children born/woman (2009 est.)','7ce836ee8f053f2be8caac8ce607b50db25e07c093fa9a67a1c01746f89a5cf5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca7924c4f66c788ad6bba7fff05cb962c412cad7ffecedfc13ae0de17700f56e',2009,'CK','Cook Islands','communications',1189,'low coral atolls in north; volcanic, hilly islands in
south
Coral Sea Islands
sand and coral reefs and islands (or cays)
2.49 children born/woman (2009 est.)','37936f7e529c6d5de068f58a98cd48fdc3c2be8541107687ce28356368c52fe7','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('997263021aed18f7e18a2c8859e2d18564c643e83eb443918f42042da44ab52e',2009,'CR','Costa Rica','communications',1190,'coastal plains separated by rugged mountains including
over 100 volcanic cones, of which several are major volcanoes
Cote d''Ivoire
mostly flat to undulating plains; mountains in
northwest
2.14 children born/woman (2009 est.)
Cote d''Ivoire
4.12 children born/woman (2009 est.)','9a3d661dd92f561b2f36c1a0a9b6e8ceadeb76c090b21e953ac792a8716ba89a','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a330fba409427c976344bfed066e4845b087b4952df9a7237e38cae13f183c51',2009,'HR','Croatia','communications',1191,'geographically diverse; flat plains along Hungarian border,
low mountains and highlands near Adriatic coastline and islands
1.42 children born/woman (2009 est.)','e17b4c096b5cce1aedb3fdad681127475dffd530bb8b937c0aa330b2a91c5ee8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('923345611755d07d5ef0dfd0c7b7f7b1cff7e35020c471298595b9a4b66a15b6',2009,'CU','Cuba','communications',1192,'mostly flat to rolling plains, with rugged hills and mountains
in the southeast
1.61 children born/woman (2009 est.)','56f99124cd94e3f6b5e3b93c9ab0df59ae3123f9bfd44d500769402175f181bd','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c6d1df4571dcc5bfc14e63bc7207468da48e716ac69b77c843fe76a51c5d783',2009,'CY','Cyprus','communications',1193,'central plain with mountains to north and south; scattered
but significant plains along southern coast
Czech Republic
Bohemia in the west consists of rolling plains,
hills, and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
1.77 children born/woman (2009 est.)
Czech Republic
1.24 children born/woman (2009 est.)','81c62b9f496cc8e77214e6b66edddb4ff3ba572669fe956a2548571b36c789b8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77206b439b95b89d1f6ab5294b9e99ec1d01817e5f84c9f3166879b2b28322d6',2009,'DJ','Djibouti','communications',1194,'coastal plain and plateau separated by central mountains
5.06 children born/woman (2009 est.)','bdc8282295855c994ad62e2959d7c345d3902852ee50add4f80c1426e75c950e','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0aafafcdbbb6260a825e8f007af6a7cfccb47c67535c8c1eb89b1c8544255253',2009,'DO','Dominican Republic','communications',1195,'rugged highlands and mountains with fertile
valleys interspersed
2.76 children born/woman (2009 est.)','c3ea01681d888d9fc0af7974f552753e6cad68279bddd958368350c93b6357a9','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('979d2c0f6d564c7f2da11ddf46af52ee411fe23b52259745557ad2d90b833a3a',2009,'EC','Ecuador','communications',1196,'coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
2.51 children born/woman (2009 est.)','853378d83338d4553c3f7aa3f832d8cc8bc7894d7ef3b4589dd7ba6e0ad847e1','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c2459cdb7d53d094b87800b2070dd2eb5915a8986414c94d0c858888335d276',2009,'EG','Egypt','communications',1197,'vast desert plateau interrupted by Nile valley and delta
2.66 children born/woman (2009 est.)','22c7d023e7380120c1523c663b979eae43430b9bfeada406fb1b74c171dc1313','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('794453c72d196d042105de9a181447c3144a0045591931126dec7ae7ed75d253',2009,'SV','El Salvador','communications',1198,'mostly mountains with narrow coastal belt and central
plateau
3 children born/woman (2009 est.)','fde3582b5177b88e497a460fee946fd97c2ee05efdeaca5cf189fb16552ffaac','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0a8cd6a66ce093096f7fe1823902f83888c4f11b1200b91847fabae5dc5c188',2009,'GQ','Equatorial Guinea','communications',1199,'coastal plains rise to interior hills; islands are
volcanic
5.08 children born/woman (2009 est.)','571db5cc952b39d3bf99487af267ecb4152256f554f6067cf8853da6e53fbc53','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d4008cf6721c79929ee4a84f167baef4b009be73776a82d131934870342345c',2009,'ER','Eritrea','communications',1200,'dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
4.72 children born/woman (2009 est.)','be5023f0373b0391e4e120089b1edd1f192530b2b3627d8bbaa3708ff74ec6eb','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8100c73197a04b7d17040c4ccdb8858421e9e817f03961b0f8f97da636b5a00',2009,'EE','Estonia','communications',1201,'marshy, lowlands; flat in the north, hilly in the south
1.42 children born/woman (2009 est.)','b9d3cf5cf001ce327e0810254fc9e2c3899396ec6c7d8e519bdb4e386755a804','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f0fdb39ba0d70806e1e014e595b85c10b2c508400c99ee98deed19bb7018f4',2009,'FO','Faroe Islands','communications',1202,'rugged, rocky, some low peaks; cliffs along most of
coast
2.44 children born/woman (2009 est.)','64abc73cb21f837b981a75391fee59d6b2a4f80362cca4553c35bf5526045520','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d6283ecf0ea682939b424dc8068781c69f788f041bd3bcdedd598d75767ff85',2009,'FI','Finland','communications',1203,'mostly low, flat to rolling plains interspersed with lakes
and low hills
1.73 children born/woman (2009 est.)','76ab39db5bd89836d5e56d3379678698a40afd4b23d036b494501fcb7803ad1f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a08300bffbc5ce6e101fb017e1c72e259612bbd4eae20badf9e3238fee061e29',2009,'FR','France','communications',1204,'metropolitan France: mostly flat plains or gently rolling
hills in north and west; remainder is mountainous, especially
Pyrenees in south, Alps in east
French Guiana: low-lying coastal plains rising to hills and small
mountains
Guadeloupe: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation; most of the
seven other islands are volcanic in origin
Martinique: mountainous with indented coastline; dormant volcano
Reunion: mostly rugged and mountainous; fertile lowlands along coast
1.98 children born/woman (2009 est.)','bc0a62af9e68c3941b05412254f61fa59cbb970fc6e1c57668e87d780dc67e37','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef9dc9c6e95e9873c0e6aa30db21385dde81667f5fcf8a2bebc40fe2d56e78b7',2009,'PF','French Polynesia','communications',1205,'mixture of rugged high islands and low islands with
reefs
French Southern and Antarctic Lands
Ile Amsterdam (Ile Amsterdam et
Ile Saint-Paul): a volcanic island with steep coastal cliffs; the
center floor of the volcano is a large plateau
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul): triangular in
shape, the island is the top of a volcano, rocky with steep cliffs
on the eastern side; has active thermal springs
Iles Crozet: a large archipelago formed from the Crozet Plateau is
divided into two groups of islands
Iles Kerguelen: the interior of the large island of Ile Kerguelen is
composed of rugged terrain of high mountains, hills, valleys, and
plains with a number of peninsulas stretching off its coasts
Bassas da India (Iles Eparses): atoll, awash at high tide; shallow
(15 m) lagoon
Europa Island, Glorioso Islands, Juan de Nova Island: low, flat, and
sandy
Tromelin Island (Iles Eparses): low, flat, sandy; likely volcanic
seamount
1.92 children born/woman (2009 est.)','ed0ff67bbe6d33723e730127a5ec2ffbabaa2387827bb06398325fbd055f99bc','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be09616767e6b1b62c9dd4f97cfbd48626a5b05f60170af403bcb66a42621d6a',2009,'GA','Gabon','communications',1206,'narrow coastal plain; hilly interior; savanna in east and south
Gambia, The
flood plain of the Gambia River flanked by some low hills
Gaza Strip
flat to rolling, sand- and dune-covered coastal plain
4.65 children born/woman (2009 est.)
Gambia, The
5.04 children born/woman (2009 est.)
Gaza Strip
5.03 children born/woman (2009 est.)','d3c61998e1f9e6f089b0184082ff5ed55ab3f201beed8f1ed7681fd93d992163','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f3dfdfdd9d7fb944889478b9214899c12d675fa90a7e216d9064c63987528e2',2009,'GE','Georgia','communications',1207,'largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhet''is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River
Basin in the east; good soils in river valley flood plains,
foothills of Kolkhida Lowland
1.44 children born/woman (2009 est.)','a75348050bad0019ed33e56106f3464cecad10d361b1679950cd1d6970827839','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddb0832014bb75703dcca369b8c5fd64c4b216ea6f333eb0eedf29b9ff379501',2009,'DE','Germany','communications',1208,'lowlands in north, uplands in center, Bavarian Alps in south
1.41 children born/woman (2009 est.)','49b289e281ffa1c22b87c2876c8482ea92141d4688889cd47c8f3a337d266ca8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a0a1562ab636cbcecc2fe3081ad4cb8bdd47941864371ee4dd118730f1b9b02',2009,'GH','Ghana','communications',1209,'mostly low plains with dissected plateau in south-central area
3.68 children born/woman (2009 est.)','65805675970cd7b262483efad9aeb601b5263833965deeddec638858632a803a','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46a849bdad947f09f8b0d6067e2153116442ca98c4017dc327d55700ce650db5',2009,'GI','Gibraltar','communications',1210,'a narrow coastal lowland borders the Rock of Gibraltar
1.65 children born/woman (2009 est.)','7618e0b1f1fc2330e6448d439e13e424d4721d9334dcfd3de756fa1638732c8b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d528c75f58f2fe20eeb2904ec5225c395b78789e9a9fd92a90f42dc2b61748ae',2009,'GR','Greece','communications',1211,'mostly mountains with ranges extending into the sea as
peninsulas or chains of islands
1.37 children born/woman (2009 est.)','0eb435b24bd2609da2deaea5e69044ff4280c2b3c5b46123448be251622b7e84','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c486116c76eecba6d3cf387aa095d014e47f792aadf444d84b6414b93cefd8e',2009,'GL','Greenland','communications',1212,'flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
2.19 children born/woman (2009 est.)','00a51851be9e48f3d15e36d167f263d1b33fd3f3c63bb72e5c97f18d222aa5bb','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('519773b4d782696b7916599f78dc73906e1845245b8d0101fb028fd90d176048',2009,'GU','Guam','communications',1213,'volcanic origin, surrounded by coral reefs; relatively flat
coralline limestone plateau (source of most fresh water), with steep
coastal cliffs and narrow coastal plains in north, low hills in
center, mountains in south
2.54 children born/woman (2009 est.)','7bb66dfc7739f056ffcf07788f1fe1bbc7ff8140866f43718a68939f3b732679','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b98bac53fec3717656c6ddfaed44284de1b54eb81321a3e2e1801df22b5c07',2009,'GT','Guatemala','communications',1214,'mostly mountains with narrow coastal plains and rolling
limestone plateau
3.47 children born/woman (2009 est.)','5b71b4a24ac5194ab6b68861a3f7efd918a4e9d326773cef78816eb84d0d981c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba703d019c303d89ce31f4f360023f2471dc3711ea0b0566effb7bc57fff58f',2009,'GN','Guinea','communications',1215,'generally flat coastal plain, hilly to mountainous interior
5.2 children born/woman (2009 est.)','50b7a46082ce0b152b4fc170ae121167257bec32de8ff6eabf252b62d344384c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4190a58f0f00be3f7feb684b3070ef52fa8cc5dd71d3b417b7dab5abf5780ed9',2009,'GW','Guinea-Bissau','communications',1216,'mostly low coastal plain rising to savanna in east
4.65 children born/woman (2009 est.)','ed96ee54d8fff65cbf668140aeb5a8d85863a4e54b567bd9b26edeb4e3991f2f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8438e084e2e1e12deb86b065317d5b82909eec14070ee65b1b475cd182ab125',2009,'GY','Guyana','communications',1217,'mostly rolling highlands; low coastal plain; savanna in south
2.03 children born/woman (2009 est.)','89ded22e7363bbd5f2c0b22924899bbf253ba3957f093e61844d45eb811ef6c2','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0aeadb560be8eb8c707b9ec30bffd8e5ac889fb5104b65d195ee8088a7f815b8',2009,'HM','Heard Island and McDonald Islands','communications',1218,'Heard Island - 80% ice-covered,
bleak and mountainous, dominated by a large massif (Big Ben) and an
active volcano (Mawson Peak); McDonald Islands - small and rocky
Holy See (Vatican City)
urban; low hill','b78d3d0211fb87858cf4fd42f566034bc6c27fa382f881365ebb5b83d82ff96d','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d4b3dc3b9a4d35a2ac78c9657f03f415f92b453dba65744285758f34dbcbf68',2009,'HN','Honduras','communications',1219,'mostly mountains in interior, narrow coastal plains
3.27 children born/woman (2009 est.)','57baf2241aedbc2a7a029c2135d1f8aa188481203e9757197172982e5930609b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f15112a5a18927fc898da45c3900b9d46297adcef07e0cc42ee96d8a257ef150',2009,'HK','Hong Kong','communications',1220,'hilly to mountainous with steep slopes; lowlands in north
1.02 children born/woman (2009 est.)','ec51c75ec8ea161c5f77abd7b58e4477ca0d502d0e4c5a8fe80bacad8d4c7a74','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ed54f6e6a94cb592ab275158d050ca973e05ad1997f6e077611dc16f8f56041',2009,'HU','Hungary','communications',1221,'mostly flat to rolling plains; hills and low mountains on
the Slovakian border
1.35 children born/woman (2009 est.)','d9b9f359956c043bfe48f800987fe93bc306b6420f8a72a536d791461ff592be','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99b51b590ea1555d326e53eead3c607cea1313659a065619aca92e75ccbeca88',2009,'IS','Iceland','communications',1222,'mostly plateau interspersed with mountain peaks, icefields;
coast deeply indented by bays and fiords
1.9 children born/woman (2009 est.)','1cd376f5944b49dee9c0cae9870db57aa2ed5214eecef963b16d1a959dd2bf1e','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd44aa2a66435f572ad7584115c80e0d0bd52f9684c31ae49e47448958c07c9d',2009,'IN','India','communications',1223,'upland plain (Deccan Plateau) in south, flat to rolling plain
along the Ganges, deserts in west, Himalayas in north
Indian Ocean
surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninetyeast Ridge
2.72 children born/woman (2009 est.)','36c083eee317af1c84f422a03c143d10843f74b1420b76cc3a0d912ad5fed804','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94a31e7f5c9e21e020de6534712edef458f975bcbb4f8035e0203ddd57f73c5e',2009,'ID','Indonesia','communications',1224,'mostly coastal lowlands; larger islands have interior
mountains
Iran
rugged, mountainous rim; high, central basin with deserts,
mountains; small, discontinuous plains along both coasts
2.31 children born/woman (2009 est.)
Iran
1.71 children born/woman (2009 est.)','6165d9189250ba0ad16ccd274fbdca2fd527f8d0953053c380a67242b848eb3e','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efa98a610584d43bbd5211d602923287c4f66832f8e85e4843e1b98fc4e7fc32',2009,'IQ','Iraq','communications',1225,'mostly broad plains; reedy marshes along Iranian border in
south with large flooded areas; mountains along borders with Iran
and Turkey
3.86 children born/woman (2009 est.)','46c159cb7bea52ecec0598d94e7e7bc60a8da026b07926d78eea6f5dca2f2209','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4396de5ae37e5e9110d07db12704aad68e6081ac494d49c3f01e3df9df5aef3',2009,'IE','Ireland','communications',1226,'mostly level to rolling interior plain surrounded by rugged
hills and low mountains; sea cliffs on west coast
1.85 children born/woman (2009 est.)','38f838d2fbea671c42e738e105cf964cee2502fc22766b145e8fda07e3070799','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('859da9fa56ae97ba9df7c7e41ad27b93e6561ae342d04a7fb643e93125b1e744',2009,'IM','Isle of Man','communications',1227,'hills in north and south bisected by central valley
1.65 children born/woman (2009 est.)','70e67324ce9d1b16e3a7dd50c16d9b92c8b360063ff83b4b51618fe3e40763b4','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e96ed103a1dc1a44786ed2f337114cee97072905d397485e36e3aff57340b5',2009,'IL','Israel','communications',1228,'Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
2.75 children born/woman (2009 est.)','ec56831fb58dfce6ed208a3791e0adf829aa1b7f82c9f22e347a5aaf0f6bffe6','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aea786117a66f491da7786d2f9ac6cb595089cb8f51f824b73d79105d53611c6',2009,'IT','Italy','communications',1229,'mostly rugged and mountainous; some plains, coastal lowlands
1.31 children born/woman (2009 est.)','075d4c824eb3011af7bf85bc9be662ad9c2882a12369af9518db83f2b8a56a44','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdc2ef9c12eff8f764e6547f5a7ddcd8550a7b912855b766237e764ed263edad',2009,'JM','Jamaica','communications',1230,'mostly mountains, with narrow, discontinuous coastal plain
Jan Mayen
volcanic island, partly covered by glaciers
2.25 children born/woman (2009 est.)','499ffbce79a92596aad3723d07df58c8125ed39299323fde7ef2c1b814273464','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91134989a47f8b74a475eff15bac9c9792e7fa280802c4f9d4444c3e745905f3',2009,'JE','Jersey','communications',1231,'gently rolling plain with low, rugged hills along north coast
1.57 children born/woman (2009 est.)','8535e0a22b437c1b2c2e8582e37b30d45130730d70155b9db9bb56c8af414e54','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9f6bd5a65247039d1d8bc61af8ce353076ca3a689238def97725766bf0dd1cd',2009,'JO','Jordan','communications',1232,'mostly desert plateau in east, highland area in west; Great
Rift Valley separates East and West Banks of the Jordan River
2.39 children born/woman (2009 est.)','d81ac4231b31e1603933a48fafd0f2eb3394e5b889d9f66bd7079b033afcb876','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a32f4049aee1285893a0bf823a4049401396e128b146f005dc8b7d158ebe51fb',2009,'KZ','Kazakhstan','communications',1233,'vast flat steppe extending from the Volga in the west to
the Altai Mountains in the east and from the plains of western
Siberia in the north to oases and deserts of Central Asia in the
south
1.88 children born/woman (2009 est.)','4496a563fb051758abd944f7965cd4d28bef84b1587749591f6a9b386d0c8bab','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58fa4389ae7d59ab429b11746ebb01b50f0086a8df1c9dfac92dad5baa973dc1',2009,'KE','Kenya','communications',1234,'low plains rise to central highlands bisected by Great Rift
Valley; fertile plateau in west
4.56 children born/woman (2009 est.)','d5a2c5281099fc8ae397930925a77e2371b3500795921b9a7c1dbfb01a407ea4','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be1b0e4087b936455aabe0f660b39ff395f0d4166793e938020ddf939cd507bf',2009,'KI','Kiribati','communications',1235,'mostly low-lying coral atolls surrounded by extensive reefs
Korea, North
mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
Korea, South
mostly hills and mountains; wide coastal plains in west
and south
Kosovo
flat fluvial basin with an elevation of 400-700 m above sea
level surrounded by several high mountain ranges with elevations of
2,000 to 2,500 m
4.04 children born/woman (2009 est.)
Korea, North
1.96 children born/woman (2009 est.)
Korea, South
1.21 children born/woman (2009 est.)','6c53cc51cac320601692c2b7cdd520cf12e3e991fd5354344200d5e8376f1163','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e88218e376f59132b6b9277c6dccdfab3d0dae8b5447c5644936adb73e80e3a1',2009,'KG','Kyrgyzstan','communications',1236,'peaks of Tien Shan and associated valleys and basins
encompass entire nation
Laos
mostly rugged mountains; some plains and plateaus
2.65 children born/woman (2009 est.)
Laos
4.41 children born/woman (2009 est.)','f2c8193896e71517b901616c838806921929696e7052b24d8af11df22a28f45d','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ebbe2feef0d4d5889876725763e8fd41a94547cd54cb9188eaf92251601352c',2009,'LB','Lebanon','communications',1237,'narrow coastal plain; El Beqaa (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
1.85 children born/woman (2009 est.)','bd857dcb1b1c4cb5c5a0e6db1264db08be7b85371b62a56d92ef03410847c805','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('913ff6fa2a7664efa9396da9a62903b0d2dd8ea9c3aaa850c1a4d99d2275da32',2009,'LS','Lesotho','communications',1238,'mostly highland with plateaus, hills, and mountains
3.06 children born/woman (2009 est.)','4e4a532a19b25fcc558f8c9f6fda69c4e8e8906985c84e27e5d6ccd9aec48bee','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64c4f89ed458691586786f2f623378c609babd2bf38623de18ca04c87c2b9b25',2009,'LR','Liberia','communications',1239,'mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
5.79 children born/woman (2009 est.)','ba5be599e7af56368aadee862a851d32a52f3666fc9dde29742cb5e1f7342147','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33e9a5f099368b5e95de3d633f2358645923fce849544b9e28e830336c7df157',2009,'LY','Libya','communications',1240,'mostly barren, flat to undulating plains, plateaus, depressions
3.08 children born/woman (2009 est.)','7203c8d300328d53ccf98a6c1a2770ce525da4747e941498a5752ff1ff368941','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d17ca28827a8e2bf399eec4644caabbd0afe8e2d68f8c43eced821c3f8524d81',2009,'LI','Liechtenstein','communications',1241,'mostly mountainous (Alps) with Rhine Valley in western
third
1.52 children born/woman (2009 est.)','1f53f18a5383136ec2cecd6c62642677f4729a5d813923752403e53ba2edad79','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d96330809fb17ca85b229586b601842fe94feb72c40f8b9816b28629faffa336',2009,'LT','Lithuania','communications',1242,'lowland, many scattered small lakes, fertile soil
1.23 children born/woman (2009 est.)','bda1e47afe05a3407d7cadf05025d7c07e17e7c19f7c9a289cc23d6c91d53b21','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bccd909bd2281cd0e42ddf872dcb93bc134555eefa29071da4b31bb80757794d',2009,'LU','Luxembourg','communications',1243,'mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle flood plain in the southeast
Macau
generally flat
Macedonia
mountainous territory covered with deep basins and
valleys; three large lakes, each divided by a frontier line; country
bisected by the Vardar River
1.78 children born/woman (2009 est.)
Macau
0.91 children born/woman (2009 est.)
Macedonia
1.58 children born/woman (2009 est.)','75b5b9b8f8795a60f2efd2783b9ab67f95ab104e7a15ce4b026eb60e33e8923f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e86e1e62df54dfd7ae0ca4d4db2a1c6b31b4b1e91d8a08d9b4a766dd5824bca3',2009,'MG','Madagascar','communications',1244,'narrow coastal plain, high plateau and mountains in center
5.14 children born/woman (2009 est.)','0fec6c22d6838c82133bb2f19bf9c7ba3536e3d9396542f4c1f43b501f85d4dd','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c4756354b396b4aef779265e05071e684c300ff068d33277c8a39341c1b7a81',2009,'MW','Malawi','communications',1245,'narrow elongated plateau with rolling plains, rounded hills,
some mountains
5.59 children born/woman (2009 est.)','96ba153aa7480e1727d6702552904c84d9d884722450968edd35257a0e1e6ba9','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d72e501116be38e3be65ac58d05c0d9bc24a9fd5939de9222a54199c5045aba',2009,'MY','Malaysia','communications',1246,'coastal plains rising to hills and mountains
2.95 children born/woman (2009 est.)','809f10c0e6ad71d9f15d749f7f54e5c76ec9b166350dcedd757f85bfc23ef475','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bb36fcbcd0138239800c2fb1c1cb283e3c935e992cbf47b555211c333c09378',2009,'ML','Mali','communications',1247,'mostly flat to rolling northern plains covered by sand; savanna
in south, rugged hills in northeast
7.29 children born/woman (2009 est.)','1316b04a2f8eb1b534e55783031ca5fde047923a4c30dbb289e9ef45878cf9d1','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15463d170f80fd0ce4ce2a28f06b75bd3d35b2df40037883d283550b92545a8f',2009,'MT','Malta','communications',1248,'mostly low, rocky, flat to dissected plains; many coastal
cliffs
1.51 children born/woman (2009 est.)','71cfba132df8cd1d6f6c9592d8e8bef69ab5968e3ea61e574af955f325f8ccfa','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b629fe0e85885ccec6b6c624084265247ecc5dbecf224a295df459c55a3eaf64',2009,'MR','Mauritania','communications',1249,'mostly barren, flat plains of the Sahara; some central
hills
4.45 children born/woman (2009 est.)','4b0b516fec786e46c2a246e86dfcc861da2f70235a3aef06739219282e841e64','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37750a4d49d4ede920e5e90bb51103dc67beef9c9da9423bd8579f5f7a8c0d37',2009,'MU','Mauritius','communications',1250,'small coastal plain rising to discontinuous mountains
encircling central plateau
1.81 children born/woman (2009 est.)','58df8bfee784ba39403a55ad40bb6ecb9d963eec5bba2e76bc155af8813dff4d','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa616a766213167beb3424045c8c1438adac1a30f3232b1a753fca8ae9596a8c',2009,'YT','Mayotte','communications',1251,'generally undulating, with deep ravines and ancient volcanic
peaks
5.5 children born/woman (2009 est.)','092e50a97e812a4963ee57796a35336e1a04ddb5425ad9edcfbbe48152c1546b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17c44e8f33a810cf8a409c40a368b9ca354f16833bea1faa55f605d679152e54',2009,'MX','Mexico','communications',1252,'high, rugged mountains; low coastal plains; high plateaus;
desert
2.34 children born/woman (2009 est.)','4b0ddfe6d0004449ec329c24b9c700204e07cb3c0778799336262c7bc74a24fe','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b345036f6cbc4a383cbb4d4ff82beaa8931379aa03925101334d2e93d6de315d',2009,'FM','Micronesia, Federated States of','communications',1253,'islands vary geologically from high
mountainous islands to low, coral atolls; volcanic outcroppings on
Pohnpei, Kosrae, and Chuuk
Moldova
rolling steppe, gradual slope south to Black Sea
2.89 children born/woman (2009 est.)
Moldova
1.27 children born/woman (2009 est.)','287a30dbfdf00d9ee3b31fa1b412b89f1d3c204905ed77c0a16cc542bf559038','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b5b3c4bfc84127375413df1e8c578ae0c7d28b8b5aeea747715f38fd4b2e95f',2009,'MN','Mongolia','communications',1254,'vast semidesert and desert plains, grassy steppe, mountains
in west and southwest; Gobi Desert in south-central
2.23 children born/woman (2009 est.)','94227bd457ec13632de8e50ed8c378bc417cab49c9dc18b90709bf67c5287d6f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f992433e98962cc429c08e3216743603cd235f3599554238bbb51f80cce786c1',2009,'ME','Montenegro','communications',1255,'highly indented coastline with narrow coastal plain
backed by rugged high limestone mountains and plateaus','0c1dd50e28101a4206dc207079ba08659ecfddd001b9c61343af6c180af218c4','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea23d99c5f9c60d123348e27708da41416af974ccfdcccb7c5b5dfe8217a994',2009,'MS','Montserrat','communications',1256,'volcanic island, mostly mountainous, with small coastal
lowland
1.23 children born/woman (2009 est.)','5bee36ba4d5ffe93e2fb02e60e8d9db5668ba502b0e354528ac324e7ddae22ff','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d40223f6f1f60f1727650e5e3296bb893ec4d2454b09ddb655b33fc4bcd8b79',2009,'MA','Morocco','communications',1257,'northern coast and interior are mountainous with large areas
of bordering plateaus, intermontane valleys, and rich coastal plains
2.51 children born/woman (2009 est.)','e8aef25aa4bd477e75ce49634859d4cf35d56378fb3da3d867a55fbaa6e0c808','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd98e6e840822668aa05ce910d2de0d5a0243dc6def7d3d9575010a5a4a8de61',2009,'MZ','Mozambique','communications',1258,'mostly coastal lowlands, uplands in center, high plateaus
in northwest, mountains in west
5.18 children born/woman (2009 est.)','ab362f4e160f66986fa4303083afef639a650a906276c725b87c0ca77f7ffa3c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97103713ff82ed69ebe21a0e01cf415f47fa936db40755ece089e860476e7887',2009,'NA','Namibia','communications',1259,'mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
2.69 children born/woman (2009 est.)','5a97ec2d65da6a0da6a81e94a512fd96c43e97d4d7669fe48d24716be9e10fdc','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('496ee5812828523e971245581cac7e47384a0852de854c02d52880959ded7a5e',2009,'NR','Nauru','communications',1260,'sandy beach rises to fertile ring around raised coral reefs
with phosphate plateau in center
Navassa Island
raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m high)
2.85 children born/woman (2009 est.)','e9ced44ed5a14760e7d46f37dc94293152bd970f7b4b5e91f2c46250fe75fc1f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7e8108c933813f18ed3bb9d3f3bbf4c97b728c5be9e43a9454110eb21995867',2009,'NP','Nepal','communications',1261,'Tarai or flat river plain of the Ganges in south, central hill
region, rugged Himalayas in north
2.64 children born/woman (2009 est.)','c151088eb625cf8902b49af953a70da4cdb7cfc91a2ed9f6a10c60259e7a9698','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84ff3a2c1a2b41cd878d59c0207b67b1b87a460aa5194951385b9f96c061b3ed',2009,'NL','Netherlands','communications',1262,'mostly coastal lowland and reclaimed land (polders);
some hills in southeast
Netherlands Antilles
generally hilly, volcanic interiors
1.66 children born/woman (2009 est.)
Netherlands Antilles
1.97 children born/woman (2009 est.)','6096f997ece63adaeac1cfbdaa986a064f75c72150b4e3479a9fabaf8813c1d9','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92a86b1d8468b8056d4a5774b0552ff7636646e4a4db205d3c97826788078a7b',2009,'NZ','New Zealand','communications',1263,'predominately mountainous with some large coastal plains
2.1 children born/woman (2009 est.)','9f1a70a055cc06685dc3c33d11cb885a4d53c6476fd19c3303ed4574750dcb42','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d81ab1bb9bedc39d2227ef987419c55c1683516a287d9e695ddb2f45f030c0b9',2009,'NI','Nicaragua','communications',1264,'extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
2.57 children born/woman (2009 est.)','67c0361d2f6cad70eec1fc0ee15d14111d0f0a9f74839befbdf51362885a302f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc6bb3f4d2e4ac100fd32029674a2ab4d5393c7ee134db1bed941a3528b6454e',2009,'NE','Niger','communications',1265,'predominately desert plains and sand dunes; flat to rolling
plains in south; hills in north
7.75 children born/woman (2009 est.)','36f778265eb9539ed28a7723ef7ac3f7f40d01e238c68ddefc041adbd5c910d5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('891cc9bed8f3afbb95d51cc6d19450eaa3df369e5e7a93b86c17ea1bf6a95420',2009,'NG','Nigeria','communications',1266,'southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
4.91 children born/woman (2009 est.)','e870859074f0e4b2da9adea5f30f6bed194098864fbd6569951f4dcf7401ced6','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3baf9b11208b6447139f482a6ef63242f81a6a444e3ff722e3cc43a9401d9fe6',2009,'MP','Northern Mariana Islands','communications',1267,'southern islands are limestone with level
terraces and fringing coral reefs; northern islands are volcanic
1.15 children born/woman (2009 est.)','fa6a5328dad3858045d30adab5b6d18881703b880734eabf41bf08dd8dbfc002','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e09d58d1fe51de9021e1e47f0a34e562dee6464b190e805b2409dced42d33a78',2009,'NO','Norway','communications',1268,'glaciated; mostly high plateaus and rugged mountains broken
by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
1.78 children born/woman (2009 est.)','548887a58f53dc4f2b5a4dc9fd81ef0d900210654985e5df68d608fbaa21fa2c','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a03a948ee67465e4908ba2b5d418ffd069368ec7b9ccba1e86bb3d8f83360bc',2009,'OM','Oman','communications',1269,'central desert plain, rugged mountains in north and south
Pacific Ocean
surface currents in the northern Pacific are dominated
by a clockwise, warm-water gyre (broad circular system of currents)
and in the southern Pacific by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in the Bering Sea and Sea of
Okhotsk in winter; in the southern Pacific, sea ice from Antarctica
reaches its northernmost extent in October; the ocean floor in the
eastern Pacific is dominated by the East Pacific Rise, while the
western Pacific is dissected by deep trenches, including the Mariana
Trench, which is the world''s deepest
5.53 children born/woman (2009 est.)','3809c2f0aff5565387a91e70248e05c51cafdcd943babf6f6bc01f5f9df18ba6','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7efe4df9a825a76aee3e962fc6201b1c2486e65d0fb1188d382b37708efeda93',2009,'PK','Pakistan','communications',1270,'flat Indus plain in east; mountains in north and northwest;
Balochistan plateau in west
3.6 children born/woman (2009 est.)','18177888f9398accafe9ef921a5a94c26dcc8cf622e770e1399de7ea0f0da3dd','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ebdb9316621e304fc75d2113d807155d1fa79ec1b58816a9fc8c2def036b586',2009,'PW','Palau','communications',1271,'varying geologically from the high, mountainous main island of
Babelthuap to low, coral islands usually fringed by large barrier
reefs
1.82 children born/woman (2009 est.)','628b1c458ca84cea205d59204b034541c88ff109628ec2a3b6d9fc133b0c51f7','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3a1792eb35784c748b579f961bc0d8f5e54a211225fe3cd004337e4c7fe8794',2009,'PA','Panama','communications',1272,'interior mostly steep, rugged mountains and dissected, upland
plains; coastal areas largely plains and rolling hills
2.53 children born/woman (2009 est.)','26c529572239d0c9f253a4162b1a94a796c3cb56e3422bbb7652359edfa0923b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5146779de5c4f629e9758da87d5e7161c65be92d62b59dedd7aa16aee8eb87c',2009,'PG','Papua New Guinea','communications',1273,'mostly mountains with coastal lowlands and rolling
foothills
Paracel Islands
mostly low and flat
3.62 children born/woman (2009 est.)','dad0b05d27f653eb2d185ce1a987649751268dd3458a8a203e4ea0a407567256','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c17a433dbe62700179b1c0cff78ddb4b63bd3f4b2304597898539b6e894f298',2009,'PY','Paraguay','communications',1274,'grassy plains and wooded hills east of Rio Paraguay; Gran
Chaco region west of Rio Paraguay mostly low, marshy plain near the
river, and dry forest and thorny scrub elsewhere
3.75 children born/woman (2009 est.)','e6fae0b030fb20fb09ee6dd147d3115f81fb755a86f564d94b4f26b52f8f61e8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('880678e4ab9fa563c389d19bafc78a06275646217db4ab48474d9582c53ed2d3',2009,'PE','Peru','communications',1275,'western coastal plain (costa), high and rugged Andes in center
(sierra), eastern lowland jungle of Amazon Basin (selva)
2.37 children born/woman (2009 est.)','39b00a19782c28a24f08604b9da07cc61d35700a98b2a7a46f3550ead28b6164','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9624f0fa1500934da880ee34be4e33a9e69105f538f1ecc5a90f09fc650b6ef1',2009,'PH','Philippines','communications',1276,'mostly mountains with narrow to extensive coastal
lowlands
Pitcairn Islands
rugged volcanic formation; rocky coastline with
cliffs
3.27 children born/woman (2009 est.)
Pitcairn Islands
NA (2008 est.)','daefc931c156ab18560eba6b133840ea363cdda8f4538e53b041c113765b27c5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4f05196348cc48e138ceed3adba919761b42e02cc0a321dcb5b94b2a1df9136',2009,'PL','Poland','communications',1277,'mostly flat plain; mountains along southern border
1.28 children born/woman (2009 est.)','e4979c54c0feac0d52a285705029a548a54a5c48320ccf9186a44f5a5c8912b7','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afd990f3560267e87041969c235083975aebb272a07a78c455aa0c4bdc190ef3',2009,'PT','Portugal','communications',1278,'mountainous north of the Tagus River, rolling plains in
south
1.49 children born/woman (2009 est.)','f5dc876be5e7d0a5636d6d14e1c432b750ff8edbe2f2da12b51ce50ddac8eefb','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd03dce58109b02b1870f2b6f4f79551c6ff21720a5acc26be0a2bb7f02f55c',2009,'PR','Puerto Rico','communications',1279,'mostly mountains with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
1.71 children born/woman (2009 est.)','16edd94d5e0ce18bff220186ad22d8a0c50a5ea12658548abc4bcbaa584c5845','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3caae2c19e548d1f0ee2c4300cd42714d88e124cb46bbb9a946e0683ecafe1d7',2009,'QA','Qatar','communications',1280,'mostly flat and barren desert covered with loose sand and
gravel
2.45 children born/woman (2009 est.)','fe294dd92f8f4d0d8646b320ecfa8e54f8e82205db0f10426248962bd61b8210','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1989f3ec15eb7a4bc311edd486bea0e981d6a66d4ea9490f3d455d9254b02747',2009,'RO','Romania','communications',1281,'central Transylvanian Basin is separated from the Moldavian
Plateau on the east by the Eastern Carpathian Mountains and
separated from the Walachian Plain on the south by the Transylvanian
Alps
Russia
broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia; uplands and mountains along southern
border regions
1.39 children born/woman (2009 est.)
Russia
1.41 children born/woman (2009 est.)','71471d61e7b40367be2dceb0080d9210f25d358991711ee2dcba0c9f068d5edb','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50625f5cf6e683070add4e36c0bfa8de90dd10e339c89df2411be4c757222ca9',2009,'RW','Rwanda','communications',1282,'mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Saint Barthelemy
hilly, almost completely surrounded by
shallow-water reefs, with 20 beaches
Saint Helena
the islands of this group result from volcanic activity
associated with the Atlantic Mid-Ocean Ridge
Saint Helena: rugged, volcanic; small scattered plateaus and plains
Ascension: surface covered by lava flows and cinder cones of 44
dormant volcanoes; ground rises to the east
Tristan da Cunha: sheer cliffs line the coastline of the nearly
circular island; the flanks of the central volcanic peak are deeply
dissected; narrow coastal plain lies between The Peak and the
coastal cliffs
5.25 children born/woman (2009 est.)
Saint Helena
1.56 children born/woman (2009 est.)','cc1a24d27a83d333a6a70ad1d00310fa98eb0104530dc990809fbb9a3c5975d5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73bd15dec814671ef6cf71bd28afc7c8f16c09e555698a9072395bb4628cbf01',2009,'LC','Saint Lucia','communications',1283,'volcanic and mountainous with some broad, fertile valleys
1.84 children born/woman (2009 est.)','ce0ff78145a630b26269e6a027f49e26553c74fa1e0caf2d8abf6162019360cf','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46fdc4c49272788a4416cfd338707c77e11100493c0b1ecb5b2da01370e347fd',2009,'WS','Samoa','communications',1284,'two main islands (Savaii, Upolu) and several smaller islands
and uninhabited islets; narrow coastal plain with volcanic, rocky,
rugged mountains in interior
4.16 children born/woman (2009 est.)','87a8569da1f520479fabb3756ab5586d860e48948665e6f8e09c902ab6cf36cc','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8ba976dfd4c0dbea241eda5e248f8fdffd443457476405511f4f96b794a9376',2009,'SN','Senegal','communications',1285,'generally low, rolling, plains rising to foothills in
southeast
4.95 children born/woman (2009 est.)','54c75e4cb3f6525194df4cd9efffdb1e886e4841ae23a1012cfba3354570afea','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd772edf5e0972303068eb958fe9f283781d9ea342b8b029c74c21eb15da6d2',2009,'RS','Serbia','communications',1286,'extremely varied; to the north, rich fertile plains; to the
east, limestone ranges and basins; to the southeast, ancient
mountains and hills
1.38 children born/woman (2009 est.)','9722f4379786e68dec186c5a85fd096d5b219e638a72d0d730c522c844fd1f58','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1140b3b287c92ef7083f79d5287316d7b9fd07b13bd21541d93a198c3e1bf16b',2009,'SC','Seychelles','communications',1287,'Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
1.93 children born/woman (2009 est.)','b996e261e7379279bfac95a3f6adec0f67006e1f353a369378e4b7d9db0acb8e','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4082eb95c12dde9dc65596791475e0bad70696b03d3e56128af0e8bd2b0a5ca9',2009,'SL','Sierra Leone','communications',1288,'coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
5.88 children born/woman (2009 est.)','4e1c77c255b11e7aaa548689fd4c7fa1ee28561e30b6d5b44b2616877a18221b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6f06fe81beeda3ee646656053fb78cbf8a4556a376520bc9728c86605bc37a1',2009,'SG','Singapore','communications',1289,'lowland; gently undulating central plateau contains water
catchment area and nature preserve
1.09 children born/woman (2009 est.)','5a57ec5284e52d377180b342d0d83a05d5cf3ef83359c7fb0d10e75a60b94b82','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94b836f86143539c4461140dfcd7cae56f4e47daca69bf5ac4bf5ca48818eed3',2009,'SK','Slovakia','communications',1290,'rugged mountains in the central and northern part and
lowlands in the south
1.35 children born/woman (2009 est.)','1a07ec6a379a51473f62aa94ad67333afcf529be3f3b5ec1f7fc889941d675e5','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa65f7e9c05dc6269309a5a98f3956fdb01658bbe817ee06f5dbd423af6d072c',2009,'SI','Slovenia','communications',1291,'a short coastal strip on the Adriatic, an alpine mountain
region adjacent to Italy and Austria, mixed mountains and valleys
with numerous rivers to the east
1.28 children born/woman (2009 est.)','6efb273bd7d8903b71431f5fb6e77fdcf90d8bfb5930176e8cba342d83380c74','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c76f930827ac01d4887d0bb8f32d886f0f3a34fe4621bc5421c2557241857ef4',2009,'SB','Solomon Islands','communications',1292,'mostly rugged mountains with some low coral atolls
3.52 children born/woman (2009 est.)','82716bc0ddf9eaedcecf2834a103b90a10c8432636e15cbcca5ef5223c0a222e','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29fce7b9348dfdf8f40f9618abe5cea1002073ee6aaef702bf5ff2c005d55556',2009,'SO','Somalia','communications',1293,'mostly flat to undulating plateau rising to hills in north
6.52 children born/woman (2009 est.)','6f68028041b3e6d3bf3b0d788df2241b7b6411ea0e38ee2ae44ec278e17b2f8b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86262525bdc6df6cead7259bf5ad68a1f73184d313f946138a4971a2521a8bee',2009,'ZA','South Africa','communications',1294,'vast interior plateau rimmed by rugged hills and narrow
coastal plain
South Georgia and South Sandwich Islands
most of the islands, rising
steeply from the sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered mountains; the South
Sandwich Islands are of volcanic origin with some active volcanoes
Southern Ocean
the Southern Ocean is deep, 4,000 to 5,000 m over
most of its extent with only limited areas of shallow water; the
Antarctic continental shelf is generally narrow and unusually deep,
its edge lying at depths of 400 to 800 m (the global mean is 133 m);
the Antarctic icepack grows from an average minimum of 2.6 million
sq km in March to about 18.8 million sq km in September, better than
a sixfold increase in area; the Antarctic Circumpolar Current
(21,000 km in length) moves perpetually eastward; it is the world''s
largest ocean current, transporting 130 million cubic meters of
water per second - 100 times the flow of all the world''s rivers
2.38 children born/woman (2009 est.)','4e1db920e349d9ae3799550905be79d3e5f9eed8e3f145ddd4783fb2b73a5255','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('129fdf35ad2006f78ad695aded11ee2a0228b4fb0e3f80a1578631ba9bf9d619',2009,'ES','Spain','communications',1295,'large, flat to dissected plateau surrounded by rugged hills;
Pyrenees in north
Spratly Islands
flat
1.31 children born/woman (2009 est.)','021405f504683ea65bf89eef4c627d89579bb54d93f85f4da3cd0b814f9f9d21','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452f8b7aa81365104d60823c7f933932c475a1fbd2a94ef8c7b9560f0100914e',2009,'LK','Sri Lanka','communications',1296,'mostly low, flat to rolling plain; mountains in
south-central interior
1.99 children born/woman (2009 est.)','ca83c47db7eafa76107ef9ad429a862841fa8c6d69d27c13760d2f7c6b8dc162','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3bf997fad25c95331581bae9dc222b96d0515a11c9b712025b0dff8d6190b0e',2009,'SD','Sudan','communications',1297,'generally flat, featureless plain; mountains in far south,
northeast and west; desert dominates the north
4.48 children born/woman (2009 est.)','f4638fea1c1ba0426854e2e80f7609b9164e19f161db43b8c5700d43884c217b','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a45a3775207359ce161d3889dfd1570b3b452320cd1c664381939698f9b56fe2',2009,'SR','Suriname','communications',1298,'mostly rolling hills; narrow coastal plain with swamps
Svalbard
wild, rugged mountains; much of high land ice covered; west
coast clear of ice about one-half of the year; fjords along west and
north coasts
Swaziland
mostly mountains and hills; some moderately sloping plains
1.99 children born/woman (2009 est.)
Svalbard
NA (2008 est.)
Swaziland
3.24 children born/woman (2009 est.)','a436921c193af7c75688b340bd8659796ac074d66bb96151530e512452620783','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74c452194980244b3ac6e1cd98d54c4d5087c29a848b1c3c67364772e5464976',2009,'SE','Sweden','communications',1299,'mostly flat or gently rolling lowlands; mountains in west
1.67 children born/woman (2009 est.)','826475dfa026dd03cbdb24e61b332eadf00b9c464cc5f15bbfb04f5421eca847','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fb7ce776fb28556f4c15849f8067c439392a5e45c66e64a4798ab055e8009e5',2009,'CH','Switzerland','communications',1300,'mostly mountains (Alps in south, Jura in northwest) with
a central plateau of rolling hills, plains, and large lakes
Syria
primarily semiarid and desert plateau; narrow coastal plain;
mountains in west
Taiwan
eastern two-thirds mostly rugged mountains; flat to gently
rolling plains in west
1.45 children born/woman (2009 est.)
Syria
3.12 children born/woman (2009 est.)
Taiwan
1.14 children born/woman (2009 est.)','b9d9d69674a1975a712eab8c7654202b163665f2dda7e55b503331a17f627ca2','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c567ab029c65369601bb1f2d62c70b389c8acc540f5a2fee551d6a893b06eb6',2009,'TJ','Tajikistan','communications',1301,'Pamir and Alay Mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Tanzania
plains along coast; central plateau; highlands in north,
south
2.99 children born/woman (2009 est.)
Tanzania
4.46 children born/woman (2009 est.)','53e6a2a2547adb6fbfbdcc2c835a56b1ddda8fa8c8ea831b868d2d1b8938ebec','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1659d54bbe77e9590f5ccef2af3b8501e932709406ba77205e262efb71382aa',2009,'TH','Thailand','communications',1302,'central plain; Khorat Plateau in the east; mountains
elsewhere
1.65 children born/woman (2009 est.)','07c8e71d0ecac9cead1df7e488daa813060823907d711f836221492710454e75','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43b115a90bb8d976f9748a0b3b7b24c8dad69d5b899ba3c64086dea839181660',2009,'TG','Togo','communications',1303,'gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
4.79 children born/woman (2009 est.)','c7ba971101fe335b8feef10b71a6a0828e286d4b4115642996f3d12b8a52c072','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4022922a70ab868075195b0ead5b6f5218d45ac1e3fdc437eb69639765fa7275',2009,'TO','Tonga','communications',1304,'most islands have limestone base formed from uplifted coral
formation; others have limestone overlying volcanic base
2.25 children born/woman (2009 est.)','b0fce91a3d6cdf9cb498c0826c89cab5a1a47014d4e45066c6df79fc3545580e','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22f268e160f77186fb8971543779f2ea33cab2ae92a697ad4639f38c9d0ca38b',2009,'TT','Trinidad and Tobago','communications',1305,'mostly plains with some hills and low mountains
1.72 children born/woman (2009 est.)','403d2a0d6982407277c91629a7880b9050ebd2ad03d55988e6adc317fc3b0948','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5b48ad72f329a9660ca226f491dc0347f725d6958f9451683543dc3d7387e60',2009,'TN','Tunisia','communications',1306,'mountains in north; hot, dry central plain; semiarid south
merges into the Sahara
Turkey
high central plateau (Anatolia); narrow coastal plain;
several mountain ranges
1.72 children born/woman (2009 est.)
Turkey
2.21 children born/woman (2009 est.)','8660d5bb40f1a5bb85962e589597a7340bdd1f6a07782ada6a5007eefe6ec33f','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b15fc168fbf9c8bca5c8e641d5beef0587eac7ff4a1c72de257d08d31028c245',2009,'TM','Turkmenistan','communications',1307,'flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
2.22 children born/woman (2009 est.)','7fa76c2dbd333ff8138ac6a116d1db2cd9a25f9ca72104b11bab00388ebe7ab8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2286bb76770bd04ec2f1413c4856d7a30051fa49e04a97a03f204146542faf',2009,'TC','Turks and Caicos Islands','communications',1308,'low, flat limestone; extensive marshes and
mangrove swamps
2.95 children born/woman (2009 est.)','065517426cc4278a3accb307bd3b4c7a313e3018713e1b12b81ba0e6dfcb26b8','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

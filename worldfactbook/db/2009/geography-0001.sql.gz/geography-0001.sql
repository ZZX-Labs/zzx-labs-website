SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('197809ff6112fd1bb7f7b619da0441bb0568d90c7de13b7ebf65be2d6ff77719',2009,'US','United States','geography',63,'Location
Geographic coordinates
Map references
Area
total
land
water
Area — comparative
Land boundaries
total
border countries
Coastline
Maritime claims
territorial sea
contiguous zone
exclusive economic zone
exclusive fishing zone
Climate
Terrain
Elevation extremes
lowest point
highest point
Natural resources
Land use
arable land
permanent crops
other
irrigated land
Total renewable water resources
Freshwater withdrawal
(domestic/industrial/agricultural)
total
per capita
Natural hazards
Environment— current issues
Environment— international agreements
party to
signed, but not ratified
Geography— note
Location: Southern Asia, north and west
of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00
E
Map references: Asia
Area:
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936
km, Pakistan 2,430 km, Tajikistan 1,206
km, Turkmenistan 744 km, Uzbekistan
137 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: arid to semiarid; cold winters
and hot summers
Terrain: mostly rugged mountains; plains
in north and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petro¬
leum, coal, copper, chromite, talc,
barites, sulfur, lead, zinc, iron ore, salt,
precious and semiprecious stones
Land use:
arable land: 12.13%
permanent crops: 0.21%
other: 87.66% (2005)
Irrigated land: 27,200 sq km (2003)
Total renewable water resources: 65 cu
km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 23.26 cu
km/yr (2%/0%/98%)
per capita: 779 cu m/yr (2000)
Natural hazards: damaging earthquakes
occur in Hindu Kush mountains;
flooding; droughts
Environment— current issues: limited
natural fresh water resources; inadequate
supplies of potable water; soil degrada¬
tion; overgrazing; deforestation (much of
the remaining forests are being cut down
for fuel and building materials); desertifi¬
cation; air and water pollution
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Endangered
Species, Environmental Modification,
Marine Dumping, Ozone Layer Protection
signed, but not ratified: Hazardous Wastes,
Law of the Sea, Marine Life Conservation
Geography— note: landlocked, the
Hindu Kush mountains that run north¬
east to southwest divide the northern
provinces from the rest of the country;
the highest peaks are in the northern
Vakhan (Wakhan Corridor)
Location: Middle America, bordering
the Caribbean Sea and the Gulf of
Mexico, between Belize and the US and
bordering the North Pacific Ocean,
between Guatemala and the US
Geographic coordinates: 23 00 N, 102
00 w
Map references: North America
Area: total: 1,972,550 sq km
land: 1,923,040 sq km
water: 49,510 sq km
Area — comparative: slightly less than
three times the size of Texas
Land boundaries:
total: 4,353 km
border countries: Belize 250 km,
Guatemala 962 km, US 3,141 km
Coastline: 9,330 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low
coastal plains; high plateaus; desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba
5,700 m
Natural resources: petroleum, silver,
copper, gold, lead, zinc, natural gas,
timber
Land use: arable land: 12.66%
permanent crops : 1.28%
other: 86.06% (2005)
Irrigated land: 63,200 sq km (2003)
Total renewable water resources: 457.2
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 78.22 cu
km/yr (17%/5%/77%)
per capita: 731 cu m/yr (2000)
427
THE CIA WORLD FACTBOOK
Natural hazards: tsunamis along the
Pacific coast, volcanoes and destructive
earthquakes in the center and south, and
hurricanes on the Pacific, Gulf of
Mexico, and Caribbean coasts
Environment— current Issues: scarcity
of hazardous waste disposal facilities;
rural to urban migration; natural fresh
water resources scarce and polluted in
north, inaccessible and poor quality in
center and extreme southeast; raw
sewage and industrial effluents polluting
rivers in urban areas; deforestation; wide¬
spread erosion; desertification; deterio¬
rating agricultural lands; serious air and
water pollution in the national capital
and urban centers along US-Mexico
border; land subsidence in Valley of
Mexico caused by groundwater depletion
note: the government considers the lack
of clean water and deforestation national
security issues
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location on
southern border of US; corn (maize), one
of the world’s major grain crops, is
thought to have originated in Mexico
Population: 109,955,400 (July 2008 est.)
Age structure:
0-14 years: 29.6% (male
16,619,995/female 15,936,154)
15-64 years: 64.3% (male
34,179,440/female 36,530,154)
65 years and over: 6.1% (male
3,023,185/female 3, 666,472) (2008 est.)
Median age:
total: 26 years
male: 24.9 years
female: 27 years (2008 est.)
Population growth rate: 1.142% (2008
est.)
Birth rate: 20.04 births/1,000 population
(2008 est.)
Death rate: 4.78 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -3.84 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 19.01 deaths/1,000 live births
male: 20.91 deaths/ 1,000 live births
female: 17.02 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 75.84 years
male: 73.05 years
female: 78.78 years (2008 est.)
Total fertility rate: 2.37 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.3%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 160,000 (2003 est.)
HIV/AIDS— deaths: 5,000 (2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorbome disease: dengue fever
water contact disease: leptospirosis (2008)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-
Spanish) 60%, Amerindian or predomi¬
nantly Amerindian 30%, white 9%,
other 1%
Religions: Roman Catholic 76.5%,
Protestant 6.3% (Pentecostal 1.4%,
Jehovah’s Witnesses 1.1%, other 3.8%),
other 0.3%, unspecified 13.8%, none
3.1% (2000 census)
Languages: Spanish, various Mayan,
Nahuatl, and other regional indigenous
languages
Literacy:
definition: age 15 and over can read and
write
total population: 91%
male: 92.4%
female: 89.6% (2004 est.)
Location: North America, bordering
both the North Atlantic Ocean and the
North Pacific Ocean, between Canada
and Mexico
Geographic coordinates: 38 00 N, 97 00
w
Map references: North America
Area: total: 9,826,630 sq km
land: 9,161,923 sq km
water: 664,707 sq km
note: includes only the 50 states and
District of Columbia
Area — comparative: about half the size
of Russia; about three-tenths the size of
Africa; about half the size of South
America (or slightly larger than Brazil);
slightly larger than China; more than
twice the size of the European Union
Land boundaries:
total: 12,034 km
border countries: Canada 8,893 km
(including 2,477 km with Alaska),
Mexico 3,141 km
note: US Naval Base at Guantanamo
Bay, Cuba is leased by the US and is part
of Cuba; the base boundary is 28 km
Coastline: 19,924 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: mostly temperate, but tropical
in Hawaii and Florida, arctic in Alaska,
semiarid in the great plains west of the
Mississippi River, and arid in the Great
Basin of the southwest; low winter tem¬
peratures in the northwest are amelio¬
rated occasionally in January and
February by warm chinook winds from
the eastern slopes of the Rocky
Mountains
Terrain: vast central plain, mountains in
west, hills and low mountains in east;
rugged mountains and broad river valleys
in Alaska; rugged, volcanic topography
in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,198 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium,
bauxite, gold, iron, mercury, nickel,
potash, silver, tungsten, zinc, petroleum,
natural gas, timber
Land use:
arable land: 18.01%
permanent crops: 0.21%
other: 81.78% (2005)
Irrigated land: 223,850 sq km (2003)
Total renewable water resources: 3,069
cu km (1985)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 477 cu
km/yr (13 %/46%/4 1 % )
per capita: 1,600 cu m/yr (2000)
Natural hazards: tsunamis, volcanoes,
and earthquake activity around Pacific
Basin; hurricanes along the Atlantic and
Gulf of Mexico coasts; tornadoes in the
midwest and southeast; mud slides in
California; forest fires in the west;
flooding; permafrost in northern Alaska,
a major impediment to development
Environment — current issues: air pollu¬
tion resulting in acid rain in both the US
and Canada; the US is the largest single
emitter of carbon dioxide from the
burning of fossil fuels; water pollution
from runoff of pesticides and fertilizers;
limited natural fresh water resources in
much of the western part of the country
require careful management; desertifica¬
tion
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
683
THE CIA WORLD FACTBOOK
Seals, Antarctic Treaty, Climate
Change, Desertification, Endangered
Species, Environmental Modification,
Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air
Pollution- Volatile Organic Compounds,
Biodiversity, Climate Change-Kyoto
Protocol, Hazardous Wastes
Geography — note: world’s third-largest
country by size (after Russia and Canada)
and by population (after China and
India); Mt. McKinley is highest point in
North America and Death Valley the
lowest point on the continent','374526d774ff687a6682410c128be006a763385fe2cf17935fb567e8125e3e6e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('889fd71f1d138a6fb90c791d8d99163a5e696ab007a14b669f51fc00e004df57',2009,'AF','Afghanistan','geography',73,'Location: Eastern Mediterranean, penin¬
sula on the southwest coast of Cyprus
Geographic coordinates: 34 37 N, 32 58
E
Map references: Middle East
Area:
total: 123 sq km
note: includes a salt lake and wetlands
Area— comparative: about 0.7 times the
size of Washington, DC
Land boundaries:
total: 47.4 km
border countries: Cyprus 47.4 km
Coastline: 56.3 km
Climate: temperate; Mediterranean with
hot, dry summers and cool winters
Environment— current issues: shooting
around the salt lake; note — breeding
place for loggerhead and green turtles;
only remaining colony of griffon vultures
is on the base
Geography— note: British extraterrito¬
rial rights also extended to several small
off-post sites scattered across Cyprus; of
the Sovereign Base Area land, 60% is
privately owned and farmed, 20% is
owned by the Ministry of Defense, and
20% is SBA Crown land
5
THE CIA WORLD FACTBOOK
IPW
Geographic coordinates: 41 00 N, 64 00
E
Map references: Asia
Area: total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
Area — comparative: slightly larger than
California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km,
Kazakhstan 2,203 km, Kyrgyzstan 1,099
km, Tajikistan 1,161 km, Turkmenistan
1,621 km
Coastline: 0 km (doubly landlocked);
note — Uzbekistan includes the southern
portion of the Aral Sea with a 420 km
shoreline
Maritime claims: none (doubly land¬
locked)
Climate: mostly midlatitude desert, long,
hot summers, mild winters; semiarid
grassland in east
Terrain: mostly flat-to-rolling sandy
desert with dunes; broad, flat intensely
irrigated river valleys along course of
Amu Darya, Syr Darya (Sirdaryo), and
Zarafshon; Fergana Valley in east sur¬
rounded by mountainous Tajikistan and
Kyrgyzstan; shrinking Aral Sea in west
Elevation extremes:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petro¬
leum, coal, gold, uranium, silver, copper,
lead and zinc, tungsten, molybdenum
Land use: arable land: 10.51%
permanent crops: 0.76%
other: 88.73% (2005)
Irrigated land: 42,810 sq km (2003)
Total renewable water resources: 72.2
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 58.34 cu
km/yr (5%/2%/93%)
per capita: 2,194 cu m/yr (2000)
Natural hazards: NA
Environment— current issues: shrinkage
of the Aral Sea is resulting in growing
concentrations of chemical pesticides
and natural salts; these substances are
then blown from the increasingly
exposed lake bed and contribute to
desertification; water pollution from
industrial wastes and the heavy use of
692','26942a3acc2dc481124fb2a1f5c01544bed62854b340eb44d6619825751ee039','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a866d0f3ca0fcdeec7e3d81e79b6e1f1f4257b9147907e854075f84175201c4',2009,'DZ','Algeria','geography',82,'Location: Northern Africa, bordering
the Mediterranean Sea, between
Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00
E
Map references: Africa
Area:
total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
Area — comparative: slightly less than
3.5 times the size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali
1,376 km, Mauritania 463 km, Morocco
1,559 km, Niger 956 km, Tunisia 965
km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 32-52 nm
Climate: arid to semiarid; mild, wet win¬
ters with hot, dry summers along coast;
drier with cold winters and hot summers
on high plateau; sirocco is a hot,
dust/sand-laden wind especially common
in summer
Terrain: mostly high plateau and desert;
some mountains; narrow, discontinuous
coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural
gas, iron ore, phosphates, uranium, lead,
zinc
Land use:
arable land: 3.17%
permanent crops: 0.28%
other: 96.55% (2005)
Irrigated land: 5,690 sq km (2003)
Total renewable water resources: 14.3
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 6.07 cu
km/yr (22%/13%/65%)
per capita: 185 cu m/yr (2000)
Natural hazards: mountainous areas
subject to severe earthquakes; mudslides
and floods in rainy season
Environment — current issues: soil ero¬
sion from overgrazing and other poor
farming practices; desertification;
dumping of raw sewage, petroleum
refining wastes, and other industrial
effluents is leading to the pollution of
rivers and coastal waters; Mediterranean
Sea, in particular, becoming polluted
from oil wastes, soil erosion, and fertilizer
runoff; inadequate supplies of potable
water
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution,
Wetlands
signed , but not ratified: none of the
selected agreements
Geography — note: second-largest
country in Africa (after Sudan)
Population: 33,769,669 (July 2008 est.)
Age structure:
0-14 years: 26.3% (male 4,528,919/
female 4,349,746)
15-64 years: 68.7% (male 11,699,701/
female 11,509,619)
65 years and over: 5% (male 779,467/
female 902,217) (2008 est.)
Median age:
total: 26 years
male: 25.8 years
female: 26.2 years (2008 est.)
Population growth rate: 1.209% (2008
est.)
Birth rate: 17.03 births/1,000 population
(2008 est.)
Death rate: 4.62 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -0.31 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.01 male(s)/female
(2008 est.)
Infant mortality rate:
total: 28.75 deaths/1,000 live births
male: 31.95 deaths/1,000 live births
female: 25.39 deaths/ 1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 73.77 years
male: 72.13 years
female: 75.49 years (2008 est.)
Total fertility rate: 1.82 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate:
0.1%; note — no country specific models
provided (2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 9,100 (2003 est.)
HIV/AIDS — deaths: fewer than 500
(2003 est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%,
European less than 1%
note: almost all Algerians are Berber in
origin, not Arab; the minority who iden¬
tify themselves as Berber live mostly in
the mountainous region of Kabylie east
of Algiers; the Berbers are also Muslim
but identify with their Berber rather than
Arab cultural heritage; Berbers have long
agitated, sometimes violently, for
autonomy; the government is unlikely to
grant autonomy but has offered to begin
sponsoring teaching Berber language in
schools
Religions: Sunni Muslim (state religion)
99%, Christian and Jewish 1%
Languages: Arabic (official), French,
Berber dialects
Literacy:
definition: age 15 and over can read and
write
total population: 69.9%
male: 79.6%
female: 60.1% (2002 est.)
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1.267 million sq km
land: 1,266,700 sq km
water: 300 sq km
Area— comparative: slightly less than
twice the size of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin
266 km, Burkina Faso 628 km, Chad
1,175 km, Libya 354 km, Mali 821 km,
Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty;
tropical in extreme south
Terrain: predominately desert plains and
sand dunes; flat to rolling plains in south;
hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Bagzane 2,022 m
Natural resources: uranium, coal, iron
ore, tin, phosphates, gold, molybdenum,
gypsum, salt, petroleum
Land use: arable land: 11.43%
permanent crops: 0.01%
other: 88.56% (2005)
Irrigated land: 730 sq km (2003)
Total renewable water resources: 33.7
cu km (2003)
Freshwater withdrawal (domestic/
Industrial/agricultural): total: 2.18 cu
km/yr (4%/0%/95%)
per capita: 156 cu m/yr (2000)
Natural hazards: recurring droughts
Environment— current issues: over-
grazing; soil erosion; deforestation; deser¬
tification; wildlife populations (such as
elephant, hippopotamus, giraffe, and
lion) threatened because of poaching
and habitat destruction
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; one of
the hottest countries in the world;
northern four-fifths is desert, southern
one-fifth is savanna, suitable for live¬
stock and limited agriculture
_ _ _
Geographic overview: The surface of the
earth is approximately 70.9% water and
29.1% land. The former portion is
divided into large water bodies termed
oceans. The World Factbook recognizes
and describes five oceans, which are in
decreasing order of size: the Pacific
Ocean, Atlantic Ocean, Indian Ocean,
Southern Ocean, and Arctic Ocean. The
land portion is generally divided into
several, large, discrete landmasses termed
continents. Depending on the conven¬
tion used, the number of continents can
vary from five to seven. The most
common classification recognizes seven,
which are (from largest to smallest):
Asia, Africa, North America, South
America, Antarctica, Europe, and
Australia. Asia and Europe are some¬
times lumped together into a Eurasian
continent resulting in six continents.
Alternatively, North and South America
are sometimes grouped as simply the
Americas, resulting in a continent total
of six (or five, if the Eurasia designation
714
WORLD
is used). North America is commonly
understood to include the island of
Greenland, the isles of the Caribbean,
and to extend south all the way to the
Isthmus of Panama. The easternmost
extent of Europe is generally defined as
being the Ural Mountains and the Ural
River; on the southeast the Caspian Sea;
and on the south the Caucasus
Mountains, the Black Sea, and the
Mediterranean. Africa’s northeast
extremity is frequently delimited at the
Isthmus of Suez, but for geopolitical pur¬
poses, the Egyptian Sinai Peninsula is
often included as part Africa. Asia usu¬
ally incorporates all the islands of the
Philippines, Malaysia, and Indonesia.
The islands of the Pacific are often
lumped with Australia into a “land mass”
termed Oceania or Australasia.
Although the above groupings are the
most common, different continental dis¬
positions are recognized or taught in cer¬
tain parts of the world, with some
arrangements more heavily based on cul¬
tural spheres rather than physical geo¬
graphic considerations.
Map references: Physical Map of the
World, Political Map of the World,
Standard Time Zones of the World
Area:
total: 510.072 million sq km
land: 148.94 million sq km
water: 361.132 million sq km
note: 70.9% of the world’s surface is
water, 29.1% is land
Area — comparative: land area about 16
times the size of the US
Land boundaries: the land boundaries in
the world total 251,060 km (not
counting shared boundaries twice); two
nations, China and Russia, each border
14 other countries
note : 45 nations and other areas are land¬
locked, these include: Afghanistan,
Andorra, Armenia, Austria, Azerbaijan,
Belarus, Bhutan, Bolivia, Botswana,
Burkina Faso, Burundi, Central African
Republic, Chad, Czech Republic,
Ethiopia, Holy See (Vatican City),
Hungary, Kazakhstan, Kosovo,
Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Luxembourg, Macedonia,
Malawi, Mali, Moldova, Mongolia,
Nepal, Niger, Paraguay, Rwanda, San
Marino, Serbia, Slovakia, Swaziland,
Switzerland, Tajikistan, Turkmenistan,
Uganda, Uzbekistan, West Bank,
Zambia, Zimbabwe; two of these,
Liechtenstein and Uzbekistan, are
doubly landlocked
Coastline: 356,000 km
note: 94 nations and other entities are
islands that border no other countries,
they include: American Samoa,
Anguilla, Antigua and Barbuda, Aruba,
Ashmore and Cartier Islands, The
Bahamas, Bahrain, Baker Island,
Barbados, Bermuda, Bouvet Island,
British Indian Ocean Territory, British
Virgin Islands, Cape Verde, Cayman
Islands, Christmas Island, Clipperton
Island, Cocos (Keeling) Islands,
Comoros, Cook Islands, Coral Sea
Islands, Cuba, Cyprus, Dominica,
Falkland Islands (Islas Malvinas), Faroe
Islands, Fiji, French Polynesia, French
Southern and Antarctic Lands,
Greenland, Grenada, Guam, Guernsey,
Heard Island and McDonald Islands,
Howland Island, Iceland, Isle of Man,
Jamaica, Jan Mayen, Japan, Jarvis Island,
Jersey, Johnston Atoll, Kingman Reef,
Kiribati, Madagascar, Maldives, Malta,
Marshall Islands, Martinique, Mauritius,
Mayotte, Federated States of Micronesia,
Midway Islands, Montserrat, Nauru,
Navassa Island, New Caledonia, New
Zealand, Niue, Norfolk Island, Northern
Mariana Islands, Palau, Palmyra Atoll,
Paracel Islands, Philippines, Pitcairn
Islands, Puerto Rico, Reunion, Saint
Barthelemy, Saint Helena, Saint Kitts
and Nevis, Saint Lucia, Saint Pierre and
Miquelon, Saint Vincent and the
Grenadines, Samoa, Sao Tome and
Principe, Seychelles, Singapore,
Solomon Islands, South Georgia and the
South Sandwich Islands, Spratly Islands,
Sri Lanka, Svalbard, Tokelau, Tonga,
Trinidad and Tobago, Turks and Caicos
Islands, Tuvalu, Vanuatu, Virgin Islands,
Wake Island, Wallis and Futuna, Taiwan
Maritime Claims: a variety of situations
exist, but in general, most countries
make the following claims measured
from the mean low-tide baseline as
described in the 1982 UN Convention
on the Law of the Sea: territorial sea — 12
nm, contiguous zone — 24 nm, and exclu¬
sive economic zone — 200 nm; additional
zones provide for exploitation of conti¬
nental shelf resources and an exclusive
fishing zone; boundary situations with
neighboring states prevent many coun¬
tries from extending their fishing or eco¬
nomic zones to a full 200 nm
Climate: a wide equatorial band of hot
and humid tropical climates — bordered
north and south by subtropical temperate
zones — that separate two large areas of
cold and dry polar climates
Terrain: the greatest ocean depth is the
Mariana Trench at 10,924 m in the
Pacific Ocean
Elevation extremes:
lowest point: Bentley Subglacial Trench -
2,540 m
note: in the oceanic realm, Challenger
Deep in the Mariana Trench is the
lowest point, lying -10,924 m below the
surface of the Pacific Ocean
highest point: Mount Everest 8,850 m
Natural resources: the rapid depletion
of nonrenewable mineral resources, the
depletion of forest areas and wetlands,
the extinction of animal and plant
species, and the deterioration in air and
water quality (especially in Eastern
Europe, the former USSR, and China)
pose serious long-term problems that
governments and peoples are only begin¬
ning to address
Land use: arable land: 13.31%
permanent crops : 4-71%
other: 81.98% (2005)
Irrigated land: 2,770,980 sq km (2003)
Natural hazards: large areas subject to
severe weather (tropical cyclones), nat¬
ural disasters (earthquakes, landslides,
tsunamis, volcanic eruptions)
Environment — current issues: large
areas subject to overpopulation, indus¬
trial disasters, pollution (air, water, acid
rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertifica¬
tion), loss of wildlife, soil degradation,
soil depletion, erosion; global warming
becoming a greater concern
Geography — note: the world is now
thought to be about 4-55 billion years
old, just about one-third of the 13.7-bil-
lion-year age estimated for the universe
Location: Middle East, bordering the
Arabian Sea, Gulf of Aden, and Red Sea,
between Oman and Saudi Arabia
Geographic coordinates: 15 00 N, 48 00
E
Map references: Middle East
Area:
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former
Yemen Arab Republic (YAR or North
Yemen), and the former People’s
Democratic Republic of Yemen (PDRY
or South Yemen)
Area — comparative: slightly larger than
twice the size of Wyoming
Land boundaries:
total: 1,746 km
border countries: Oman 288 km, Saudi
Arabia 1,458 km
Coastline: 1,906 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: mostly desert; hot and humid
along west coast; temperate in western
mountains affected by seasonal mon¬
soon; extraordinarily hot, dry, harsh
desert in east
Terrain: narrow coastal plain backed by
flat-topped hills and rugged mountains;
dissected upland desert plains in center
slope into the desert interior of the
Arabian Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu’ayb 3,760
m
Natural resources: petroleum, fish, rock
salt, marble; small deposits of coal, gold,
lead, nickel, and copper; fertile soil in
west
Land use:
arable land: 2.91%
permanent crops: 0.25%
other: 96.84% (2005)
Irrigated land: 5,500 sq km (2003)
Total renewable water resources: 4 1
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 6.63 cu
km/yr (4%/l%/95%)
per capita: 316 cu m/yr (2000)
Natural hazards: sandstorms and dust
storms in summer
Environment — current issues: limited
natural fresh water resources; inadequate
supplies of potable water; overgrazing;
soil erosion; desertification
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location on
Bab el Mandeb, the strait linking the
Red Sea and the Gulf of Aden, one of
world’s most active shipping lanes','14ee7ec5e45c4e2f2548327739ef99737fd386f4d941ac9b1f193565b8c8ac71','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fd53daf5395bb9d39c48a3fb0da726f5fe2f927066f349e93968aff3ab98e2d',2009,'AS','American Samoa','geography',86,'Location: Oceania, group of islands in
the South Pacific Ocean, about half way
between Hawaii and New Zealand
Geographic coordinates: 14 20 S, 170
00 w
Map references: Oceania
Area:
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains
Island
Area — comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine, moderated by
southeast trade winds; annual rainfall
averages about 3 m; rainy season
(November to April), dry season (May to
October); little seasonal temperature
variation
Terrain: five volcanic islands with rugged
peaks and limited coastal plains, two
coral atolls (Rose Island, Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata Mountain 964 m
Natural resources: pumice, pumicite
Land use:
arable land: 10%
permanent crops: 15%
other: 75% (2005)
Irrigated land: NA
Natural hazards: typhoons common
from December to March
Environment — current issues: limited
natural fresh water resources; the water
division of the government has spent
substantial funds in the past few years to
improve water catchments and pipelines
Geography — note: Pago Pago has one of
the best natural deepwater harbors in the
South Pacific Ocean, sheltered by shape
from rough seas and protected by periph¬
eral mountains from high winds;
strategic location in the South Pacific
Ocean
Population: 57,496 (July 2008 est.)
Age structure:
0-14 years: 32.5% (male 9,684/female
9,006)
15-64 years: 64-6% (male 19,377/female
17,757)
65 years and over: 2.9 % (male 591/female
1,081) (2008 est.)
Median age:
total: 24 years
male: 23.9 years
female: 24-2 years (2008 est.)
Population growth rate: -0.322% (2008
est.)
Birth rate: 21.24 births/1,000 population
(2008 est.)
Death rate: 3.24 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -21.22 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.55 male(s)/female
total population: 1.06 male(s)/female
(2008 est.)
Infant mortality rate:
total: 8.69 deaths/1,000 live births
male: 9.28 deaths/1,000 live births
female: 8.08 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 76.45 years
male: 72.9 years
female: 80.21 years (2008 est.)
Total fertility rate: 2.98 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
13
THE CIA WORLD FACTBOOK
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS — deaths: NA
Nationality:
noun: American Samoan(s) (US
nationals)
adjective: American Samoan
Ethnic groups: native Pacific islander
92.9%, Asian 2.9%, white 1.2%, mixed
2.8%, other 0.2% (2000 census)
Religions: Christian Congregationalist
50%, Roman Catholic 20%, Protestant
and other 30%
Languages: Samoan 90.6% (closely
related to Hawaiian and other
Polynesian languages), English 2.9%,
Tongan 2.4%, other Pacific islander
2.1%, other 2%
note: most people are bilingual (2000
census)
Literacy:
definition: age 15 and over can read and
write
total population: 97%
male: 98%
female: 97% (1980 est.)','c7320b75885d12686cffbdc93bc702266558c636aaecb3c4e39f0e695004e72c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c82ef897c07114b27c6e535817db974dae599734afede93699c9aa25a9b116',2009,'AD','Andorra','geography',91,'_
Location: Southwestern Europe, between
France and Spain
Geographic coordinates: 42 30 N, 1 30
E
Map references: Europe
Area:
total: 468 sq km
land: 468 sq km
water: 0 sq km
Area — comparative: 2.5 times the size of
Washington, DC
Land boundaries:
total: 120.3 km
border countries: France 56.6 km, Spain
63.7 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; snowy, cold winters
and warm, dry summers
Terrain: rugged mountains dissected by
narrow valleys
Elevation extremes:
lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral
water, timber, iron ore, lead
Land use:
arable land: 2.13%
permanent crops: 0%
other: 97.87% (2005)
Irrigated land: NA
Natural hazards: avalanches
Environment — current issues: defor¬
estation; overgrazing of mountain
meadows contributes to soil erosion; air
pollution; wastewater treatment and
solid waste disposal
Environment — international agree¬
ments: party to: Biodiversity,
Desertification, Flazardous Wastes
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; straddles
a number of important crossroads in the
Pyrenees
Population: 72,413 (July 2008 est.)
Age structure:
0-14 years: 14.3% (male 5,404/female
4,966)
15-64 years: 71% (male 26,892/female
24,519)
65 years and over: 14-7% (male
5,246/female 5,386) (2008 est.)
Median age:
total: 42.1 years
15
THE CIA WORLD FACTBOOK
male: 42.3 years
female: 41.9 years (2008 est.)
Population growth rate: 0.797% (2008
est.)
Birth rate: 8.23 births/1,000 population
(2008 est.)
Death rate: 6.63 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: 6.37 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.09 male(s)/female
15-64 years: 1.1 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.08 male(s)/female
(2008 est.)
Infant mortality rate:
total: 4.03 deaths/1,000 live births
male: 4*36 deaths/1,000 live births
female: 3.67 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 83.53 years
male: 80.63 years
female: 86.63 years (2008 est.)
Total fertility rate: 1.32 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS — deaths: NA
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%, Andorran
33%, Portuguese 11%, French 7%, other
6% (1998)
Religions: Roman Catholic (predomi-
nant)
Languages: Catalan (official), French,
Castilian, Portuguese
Literacy:
definition: NA
total population: 100%
male: 100%
female: 100%','51a873f2848a063746497091f5d320cba597920ac32633be1f942da9c304ca5d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('568ecfc459560ed0cfd1fa15c36e6d60ae769bde6d1334357f778c1512686bd8',2009,'AO','Angola','geography',98,'Location: Southern Africa, bordering the
South Atlantic Ocean, between
Namibia and Democratic Republic of
the Congo
Geographic coordinates: 12 30 S, 18 30
E
Map references: Africa
Area:
total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area — comparative: slightly less than
twice the size of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of
the Congo 2,51 1 km (of which 225 km is
the boundary of discontiguous Cabinda
Province), Republic of the Congo 201
km, Namibia 1,376 km, Zambia 1,110
km
Coastline: 1,600 km
Maritime claims:
territorial sea: 12 nm
17
THE CIA WORLD FACTBOOK
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: semiarid in south and along
coast to Luanda; north has cool, dry
season (May to October) and hot, rainy
season (November to April)
Terrain: narrow coastal plain rises
abruptly to vast interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, dia¬
monds, iron ore, phosphates, copper,
feldspar, gold, bauxite, uranium
Land use:
arable land: 2.65%
permanent crops: 0.23%
other: 97.12% (2005)
Irrigated land: 800 sq km (2003)
Total renewable water resources: 184
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.35 cu
km/yr (23%/17%/60%)
per capita: 22 cu m/yr (2000)
Natural hazards: locally heavy rainfall
causes periodic flooding on the plateau
Environment— current issues: overuse of
pastures and subsequent soil erosion attrib-
utable to population pressures; desertifica-
tion; deforestation of tropical rain forest,
in response to both international demand
for tropical timber and to domestic use as
fuel, resulting in loss of biodiversity; soil
erosion contributing to water pollution
and siltation of rivers and dams; made-
quate supplies of potable water
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the
selected agreements
Geography— note: the province of
Cabinda is an exclave, separated from
the rest of the country by the Democratic
Republic of the Congo
Population: 12,531,357 (July 2008 est.)
Age structure:
0-14 years: 43.6% (male 2,760,264/
female 2,707,665)
15-64 years: 53.6% (male 3,416,914/
female 3,302,552)
65 years and over: 2.7% (male 151,609/
female 192,353) (2008 est.)
Median age:
total: 18 years
male: 18 years
female: 18 years (2008 est.)
Population growth rate: 2.136% (2008
est.)
Birth rate: 44-09 births/1,000 population
(2008 est.)
Death rate: 24-44 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 1.72 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1.02 male(s)/female
(2008 est.)
Infant mortality rate:
total: 182.31 deaths/1,000 live births
male: 194-38 deaths/1,000 live births
female: 169.64 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 37.92 years
male: 36.99 years
female: 38.9 years (2008 est.)
Total fertility rate: 6.2 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 3.9%
(2003 est.)
HIV/AIDS — people living with
HIV/AIDS: 240,000 (2003 est.)
HIV/AIDS— deaths: 21,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A, typhoid
fever
vectorborne diseases: malaria, African try¬
panosomiasis (sleeping sickness)
water contact disease: schistosomiasis
(2008)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%,
Kimbundu 25%, Bakongo 13%, mestico
(mixed European and native African)
2%, European 1%, other 22%
Religions: indigenous beliefs 47%,
Roman Catholic 38%, Protestant 15%
(1998 est.)
Languages: Portuguese (official), Bantu
and other African languages
Literacy:
definition: age 15 and over can read and
write
total population: 67.4%
male: 82.9%
female: 54-2% (2001 est.)
Country name:
conventional long form: Republic of
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People’s Republic of Angola
Government type: republic; multiparty
presidential regime
Capital: name: Luanda
geographic coordinates: 8 50S, 13 14 E
time difference: UTC+1 (6 hours ahead of
Washington, DC during Standard Time)
Administrative divisions: 18 provinces
(provincias, singular — provincia);
Bengo, Benguela, Bie, Cabinda, Cuando
Cubango, Cuanza Norte, Cuanza Sul,
Cunene, Huambo, Huila, Luanda, Lunda
Norte, Lunda Sul, Malanje, Moxico,
Namibe, Uige, Zaire
Independence: 11 November 1975
(from Portugal)
National holiday: Independence Day, 11
November (1975)
Constitution: adopted by People’s
Assembly 25 August 1992
Legal system: based on Portuguese civil
law system and customary law; modified
to accommodate political pluralism and
increased use of free markets; has not
accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Jose Eduardo
DOS SANTOS (since 21 September
1979); note — the president is both chief
of state and head of government
head of government: President Jose
Eduardo DOS SANTOS ( since 21
September 1979); Fernando de Piedade
Dias DOS SANTOS was appointed
prime minister on 6 December 2002
cabinet: Council of Ministers appointed
by the president
elections: president elected by universal
ballot for a five-year term (eligible for a
second consecutive or discontinuous
term) under the 1992 constitution;
President DOS SANTOS originally
elected (in 1979) without opposition
under a one-party system and stood for
reelection in Angola’s first multiparty
elections 29-30 September 1992 (next
to be held in 2009)
election results: Jose Eduardo DOS
SANTOS 49.6%, Jonas SAVIMBI
40.1%, making a run-off election neces¬
sary; the run-off was not held because
SAVIMBI’s National Union for the Total
Independence of Angola (UNITA) repu¬
diated the results of the first election; the
civil war resumed leaving DOS
SANTOS in his current position as the
president
Legislative branch: unicameral
National Assembly or Assembleia
Nacional (220 seats; members elected by
proportional vote to serve four-year
terms)
elections: last held 29-30 September
1992 (next to be held on 5-6 September
2008)
18
election results: percent of vote by party —
MPLA 54%, UNITA 34%, other 12%;
seats by party — MPLA 129, UNITA 70,
PRS 6, FNLA 5, PLD 3, other 7
Judicial branch: Supreme Court and
separate provincial courts (judges are
appointed by the president)
Political parties and leaders: Liberal
Democratic Party or PLD [Analia de
Victoria PEREIRA]; National Front for
the Liberation of Angola or FNLA [dis¬
puted between Ngola KABANGU and
Lucas NGONDA]; National Union for
the Total Independence of Angola or
UNITA (largest opposition party) [Isaias
SAMAKUVA]; Popular Movement for
the Liberation of Angola or MPLA
(ruling party in power since 1975) [Jose
Eduardo DOS SANTOS]; Social
Renewal Party or PRS [Eduardo KUAN-
GANA]
note: about a dozen minor parties partic¬
ipated in the 1992 elections but only
won a few seats; they and more than 100
other smaller parties have little influence
in the National Assembly
Political pressure groups and leaders:
Front for the Liberation of the Enclave of
Cabinda or FLEC [N’zita Henriques
TIAGO, Antonio Bento BEMBE]
note: FLEC’s small-scale, highly faction-
alized armed struggle for the independ¬
ence of Cabinda Province ended after
BEMBE’s faction signed a peace accord
in August 2006; other factions have
since demobilized under provisions of
the accord, although the two main fac¬
tion leaders have not acceded to the
accord
International organization participa¬
tion: ACP, AfDB, AU, CPLP, FAO, G-
77, IAEA, IBRD, ICAO, ICCt
(signatory), ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Interpol, IOC,
IOM, IPU, ISO (correspondent), ITSO,
ITU, ITUC, MIGA, NAM, OAS
(observer), OPEC, SADC, UN,
UNCTAD, UNESCO, UNIDO, Union
Latina, UNWTO, UPU, WCO, WFTU,
WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Josefina
Perpetua Pitra DIAKITE
chancery: 2108 16th Street NW,
Washington, DC 20009
telephone: [1] (202) 785-1156
FAX: [1] (202) 785-1258
consulate (s) general: Houston, New York
Diplomatic representation from the US:
chief of mission: Ambassador Dan
MOZENA
embassy: number 32 Rua Houari
Boumedienne (in the Miramar area of
Luanda), Luanda
mailing address : international mail: Caixa
Postal 6468, Luanda; pouch: US Embassy
Luanda, US Department of State, 2550
Luanda Place, Washington, DC 20521-
2550
telephone: [244] (222) 64-1000
FAX: [244] (222) 64-1232
Flag description: two equal horizontal
bands of red (top) and black with a cen¬
tered yellow emblem consisting of a five-
pointed star within half a cogwheel
crossed by a machete (in the style of a
hammer and sickle)
Economy — overview: Angola’s high
growth rate is driven by its oil sector,
with record oil prices and rising petro¬
leum production. Oil production and its
supporting activities contribute about
85% of GDP. Increased oil production
supported growth averaging more than
15% per year from 2004 to 2007. A
postwar reconstruction boom and reset¬
tlement of displaced persons has led to
high rates of growth in construction and
agriculture as well. Much of the country’s
infrastructure is still damaged or unde¬
veloped from the 27-year- long civil war.
Remnants of the conflict such as wide¬
spread land mines still mar the country¬
side even though an apparently durable
peace was established after the death of
rebel leader Jonas SAVIMBI in February
2002. Subsistence agriculture provides
the main livelihood for most of the
people, but half of the country’s food
must still be imported. In 2005, the gov¬
ernment started using a $2 billion line of
credit, since increased to $7 billion, from
China to rebuild Angola’s public infra¬
structure, and several large-scale projects
were completed in 2006. Angola also has
large credit lines from Brazil, Portugal,
Germany, Spain, and the EU. The cen¬
tral bank in 2003 implemented an
exchange rate stabilization program
using foreign exchange reserves to buy
kwanzas out of circulation. This policy
became more sustainable in 2005
because of strong oil export earnings; it
has significantly reduced inflation.
Although consumer inflation declined
from 325% in 2000 to under 13% in
2007, the stabilization policy has put
pressure on international net liquidity.
Angola became a member of OPEC in
late 2006 and in late 2007 was assigned a
production quota of 1 .9 million barrels a
day, somewhat less than the 2-2.5 mil¬
lion bbl Angola’s government had
wanted. To fully take advantage of its
rich national resources — gold, diamonds,
extensive forests, Atlantic fisheries, and
large oil deposits — Angola will need to
implement government reforms, increase
transparency, and reduce corruption.
The government has rejected a formal
IMF monitored program, although it
continues Article IV consultations and
ad hoc cooperation. Corruption, espe¬
cially in the extractive sectors, and the
negative effects of large inflows of foreign
exchange, are major challenges facing
Angola.
GDP (purchasing power parity): $91.29
billion (2007 est.)
GDP (official exchange rate): $61.36
billion (2007 est.)
GDP— real growth rate: 21.1% (2007
est.)
GDP— per capita (PPP): $5,600 (2007
est.)
GDP — composition by sector:
agriculture: 9.5%
industry: 65.8%
services: 24.6% (2007 est.)
Labor force: 6.64 million (2007 est.)
Labor force — by occupation: agriculture:
85%
industry and services: 15% (2003 est.)
Unemployment rate: extensive unem¬
ployment and underemployment
affecting more than half the population
(2001 est.)
Population below poverty line: 70%
(2003 est.)
Household income or consumption by
percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 12.2%
(2007 est.)
Investment (gross fixed): 9.1% of GDP
(2007 est.)
Budget:
revenues: $17.29 billion
expenditures: $15.78 billion (2007 est.)
Public debt: 12% of GDP (2007 est.)
Agriculture — products: bananas, sugar¬
cane, coffee, sisal, corn, cotton, manioc
(tapioca), tobacco, vegetables, plantains;
livestock; forest products; fish
Industries: petroleum; diamonds, iron
ore, phosphates, feldspar, bauxite, ura¬
nium, and gold; cement; basic metal
products; fish processing; food pro¬
cessing, brewing, tobacco products,
sugar; textiles; ship repair
Industrial production growth rate:
24.4% (2007 est.)
Electricity— production: 2.585 billion
kWh (2005)
Electricity— production by source:
fossil fuel: 36.4%
hydro: 63.6%
nuclear: 0%
other: 0% (2001)
Electricity — consumption: 2.201 billion
kWh (2005)
Electricity— exports: 0 kWh (2005)
19
THE CIA WORLD FACTBOOK
Electricity— imports: 0 kWh (2005)
Oil — production: 1.26 million bbl/day
(2005 est.)
Oil— consumption: 50,000 bbl/day
(2005 est.)
Oil — exports: 1.021 million bbl/day
(2004)
Oil— imports: 18,290 bbl/day (2004)
Oil— proved reserves: 25 billion bbl
(2007 est.)
Natural gas— production: 767.3 million
cu m (2005 est.)
Natural gas— consumption: 767.3 mil¬
lion cu m (2005 est.)
Natural gas— exports: 0 cu m (2005
est.)
Natural gas — imports: 0 cu m (2005)
Natural gas— proved reserves: 44 bil¬
lion cu m (1 January 2006 est.)
Current account balance: $6,747 billion
(2007 est.)
Exports: $44.32 billion f.o.b. (2007 est.)
Exports — commodities: crude oil, dia¬
monds, refined petroleum products, gas,
coffee, sisal, fish and fish products,
timber, cotton
Exports— partners: US 38.1%, China
34-2%, Taiwan 5.8%, France 4.9%,
Chile 4.1% (2006)
Imports: $12.29 billion f.o.b. (2007 est.)
Imports — Commodities: machinery and
electrical equipment, vehicles and spare
parts; medicines, food, textiles, military
goods
Imports— partners: US 15.3%, Portugal
15%, South Korea 10.1%, China 8.8%,
Brazil 8.2%, South Africa 6.7%, France
6.2% (2006)
Economic aid— recipient: $441 8 mil¬
lion (2005)
Reserves of foreign exchange and
gold: $11.33 billion (31 December 2007
est.)
Debt— external: $8,234 billion (31
December 2007 est.)
Stock of direct foreign investment — at
home: $17.23 billion (2007 est.)
Stock of direct foreign investment-
abroad: $227 million (2006 est.)
Currency (code): kwanza (AOA)
Currency code: AOA
Exchange rates: kwanza per US dollar —
76.6 (2007), 80.4 (2006), 88.6 (2005),
83.541 (2004), 74.606 (2003)
Fiscal year: calendar year
Location: Caribbean, islands between
the Caribbean Sea and North Atlantic
Ocean, east of Puerto Rico
Geographic coordinates: 18 15 N, 63 10
w
Map references: Central America and
the Caribbean
Area:
total: 102 sq km
land: 102 sq km
water: 0 sq km
Area — comparative: about half the size
of Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; moderated by north¬
east trade winds
Terrain: flat and low-lying island of coral
and limestone
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (mostly rock with sparse
scrub oak, few trees, some commercial
salt ponds) (2005)
Irrigated land: NA
Natural hazards: frequent hurricanes
and other tropical storms (July to
October)
Environment — current issues: supplies
of potable water sometimes cannot meet
increasing demand largely because of
poor distribution system
Geography — note: the most northerly of
the Leeward Islands in the Lesser
Antilles
Location: continent mostly south of the
Antarctic Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
total: 14 million sq km
land: 14 million sq km (280,000 sq km
ice-free, 13.72 million sq km ice-cov¬
ered) (est.)
note: fifth-largest continent, following
Asia, Africa, North America, and South
America, but larger than Australia and
the subcontinent of Europe
Area — comparative: slightly less than
1.5 times the size of the US
Land boundaries: 0 km
note: see entry on Disputes— interna¬
tional
Coastline: 17,968 km
Maritime claims: Australia, Chile, and
Argentina claim Exclusive Economic
Zone (EEZ) rights or similar over 200 nm
extensions seaward from their conti¬
nental claims, but like the claims them¬
selves, these zones are not accepted by
other countries; 21 of 28 Antarctic con¬
sultative nations have made no claims to
Antarctic territory (although Russia and
the US have reserved the right to do so)
and do not recognize the claims of the
other nations; also see the Disputes —
international entry
Climate: severe low temperatures vary
with latitude, elevation, and distance
from the ocean; East Antarctica is colder
than West Antarctica because of its
higher elevation; Antarctic Peninsula
has the most moderate climate; higher
temperatures occur in January along the
coast and average slightly below freezing
Terrain: about 98% thick continental ice
sheet and 2% barren rock, with average
elevations between 2,000 and 4,000
meters; mountain ranges up to nearly
5,000 meters; ice-free coastal areas
include parts of southern Victoria Land,
Wilkes Land, the Antarctic Peninsula
area, and parts of Ross Island on
McMurdo Sound; glaciers form ice
shelves along about half of the coastline,
and floating ice shelves constitute 11%
of the area of the continent
Elevation extremes:
lowest point: Bentley Subglacial Trench -
2,555 m
highest point: Vinson Massif 4,897 m
note: the lowest known land point in
Antarctica is hidden in the Bentley
Subglacial Trench; at its surface is the
deepest ice yet discovered and the
world’s lowest elevation not under sea¬
water
Natural resources: iron ore, chromium,
copper, gold, nickel, platinum and other
minerals, and coal and hydrocarbons
have been found in small uncommercial
quantities; none presently exploited;
krill, finfish, and crab have been taken
by commercial fisheries
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (ice 98%, barren rock 2%)
(2005)
Natural hazards: katabatic (gravity-
driven) winds blow coastward from the
high interior; frequent blizzards form
near the foot of the plateau; cyclonic
storms form over the ocean and move
clockwise along the coast; volcanism on
Deception Island and isolated areas of
West Antarctica; other seismic activity
rare and weak; large icebergs may calve
from ice shelf
Environment— current issues: in 1998,
NASA satellite data showed that the
Antarctic ozone hole was the largest on
record, covering 27 million square kilo¬
meters; researchers in 1997 found that
increased ultraviolet light passing
through the hole damages the DNA of
icefish, an Antarctic fish lacking hemo¬
globin; ozone depletion earlier was
shown to harm one-celled Antarctic
marine plants; in 2002, significant areas
of ice shelves disintegrated in response to
regional warming
Geography — note: the coldest, windiest,
highest (on average), and driest conti¬
nent; during summer, more solar radia¬
tion reaches the surface at the South
Pole than is received at the Equator in an
equivalent period; mostly uninhabitable
Geographic coordinates: 0 00 N, 25 00
E
Map references: Africa
Area:
total: 2,345,410 sq km
land: 2,267,600 sq km
water: 77,810 sq km
Area — comparative: slightly less than
one-fourth the size of the US
Land boundaries:
total: 10,730 km
border countries: Angola 2,511 km (of
which 225 km is the boundary of
Angola’s discontiguous Cabinda
Province), Burundi 233 km, Central
African Republic 1,577 km, Republic of
the Congo 2,410 km, Rwanda 217 km,
Sudan 628 km, Tanzania 459 km,
Uganda 765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
territorial sea : 12 nm
exclusive economic zone: boundaries with
neighbors
Climate: tropical; hot and humid in
equatorial river basin; cooler and drier in
southern highlands; cooler and wetter in
eastern highlands; north of Equator —
wet season (April to October), dry
season (December to February); south of
Equator — wet season (November to
March), dry season (April to October)
Terrain: vast central basin is a low-lying
plateau; mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont
Ngaliema (Mount Stanley) 5,1 10 m
Natural resources: cobalt, copper, nio¬
bium, tantalum, petroleum, industrial
and gem diamonds, gold, silver, zinc,
manganese, tin, uranium, coal,
hydropower, timber
Land use:
arable land: 2.86%
permanent crops: 0.47%
other: 96.67% (2005)
Irrigated land: no sq km (2003)
Total renewable water resources: 1,283
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.36 cu
km/yr (53%/l 7%/3 1%)
per capita: 6 cu m/yr (2000)
Natural hazards: periodic droughts in
south; Congo River floods (seasonal); in
the east, in the Great Rift Valley, there
are active volcanoes
Environment — current issues: poaching
threatens wildlife populations; water pol¬
lution; deforestation; refugees respon¬
sible for significant deforestation, soil
erosion, and wildlife poaching; mining of
minerals (coltan — a mineral used in cre¬
ating capacitors, diamonds, and gold)
causing environmental damage
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Environmental
Modification
Geography — note: straddles equator; has
narrow strip of land that controls the
lower Congo River and is only outlet to
South Atlantic Ocean; dense tropical
rain forest in central river basin and
eastern highlands
Location: Western Africa, bordering the
South Atlantic Ocean, between Angola
and Gabon
Geographic coordinates: l 00 s, 15 00 E
Map references: Africa
Area: total: 342,000 sq km
land: 341,500 sq km
water: 500 sq km
Area— comparative: slightly smaller
than Montana
Land boundaries: total: 5,504 km
border countries: Angola 201 km,
Cameroon 523 km, Central African
Republic 467 km, Democratic Republic
of the Congo 2,410 km, Gabon 1,903 km
Coastline: 169 km
Maritime Claims: territorial sea: 200 nm
Climate: tropical; rainy season (March
to June); dry season (June to October);
persistent high temperatures and
humidity; particularly enervating climate
astride the Equator
Terrain: coastal plain, southern basin,
central plateau, northern basin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber,
potash, lead, zinc, uranium, copper,
phosphates, gold, magnesium, natural
gas, hydropower
Land use: arable land: 1.45%
permanent crops: 0.15%
other: 98.4% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 832
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.03 cu
km/yr (59%/29%/12%)
per capita: 8 cu m/yr (2000)
Natural hazards: seasonal flooding
155
THE CIA WORLD FACT BOOK
Environment — current issues: air pollu¬
tion from vehicle emissions; water pollu-
tion from the dumping of raw sewage; tap
water is not potable; deforestation
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: about 70% of the
population lives in Brazzaville, Pointe-
Noire, or along the railroad between
them','ae591a564c0ecfe381a1b0751297dc13829b5d9422bf0e5b8d3ebfa9cd52b63e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b7fd3692455c9259b2c7efcd53b99c179f71678e5175cb8c132971afac838e',2009,'AR','Argentina','geography',111,'Location: Southern South America, bor¬
dering the South Atlantic Ocean,
between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 w
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area — comparative: slightly less than
three-tenths the size of the US
Land boundaries:
total: 9,861 km
border countries: Bolivia 832 km, Brazil
1,261 km, Chile 5,308 km, Paraguay
1,880 km, Uruguay 580 km
Coastline: 4,989 km
Maritime claims:
territorial sea : 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: mostly temperate; arid in
southeast; subantarctic in southwest
Terrain: rich plains of the Pampas in
northern half, flat to rolling plateau of
Patagonia in south, rugged Andes along
western border
Elevation extremes:
lowest point: Laguna del Carbon -105 m
(located between Puerto San Julian and
Comandante Luis Piedra Buena in the
province of Santa Cruz)
highest point: Cerro Aconcagua 6,960 m
(located in the northwestern corner of
the province of Mendoza)
Natural resources: fertile plains of the
pampas, lead, zinc, tin, copper, iron ore,
manganese, petroleum, uranium
Land use:
arable land: 10.03%
permanent crops: 0.36%
other: 89.61% (2005)
Irrigated land: 15,500 sq km (2003)
Total renewable water resources: 814
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 29.19 cu
km/yr (17%/9%/74%)
per capita: 753 cu m/yr (2000)
Natural hazards: San Miguel de
Tucuman and Mendoza areas in the
Andes subject to earthquakes; pamperos
are violent windstorms that can strike
the pampas and northeast; heavy
flooding
Environment — current issues: environ¬
mental problems (urban and rural) typ¬
ical of an industrializing economy such as
deforestation, soil degradation, desertifi¬
cation, air pollution, and water pollution
note: Argentina is a world leader in set¬
ting voluntary greenhouse gas targets
Environment— international agree¬
ments: party to: Antarctic-Environ¬
mental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Marine Life
Conservation
Geography — note: second-largest
country in South America (after Brazil);
strategic location relative to sea lanes
between the South Atlantic and the
South Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake
Passage); diverse geophysical landscapes
range from tropical climates in the north
to tundra in the far south; Cerro
Aconcagua is the Western Hemisphere’s
tallest mountain, while Laguna del
Carbon is the lowest point in the
Western Hemisphere','12ed3d20d992634164b6e3787ef065b9794822470c26548d75814cfbc7577fb4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308716c8c11f21547fa28f3649e696740541df23b2a1b02b63d2fe266f60c336',2009,'AM','Armenia','geography',115,'Location: Southwestern Asia, east of
Turkey
Geographic coordinates: 40 00 N, 45 00
E
Map references: Asia
Area:
total: 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
Area— comparative: slightly smaller
than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566
km, Azerbaijan-Naxcivan exclave 221
km, Georgia 164 km, Iran 35 km, Turkey
268 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: highland continental, hot sum¬
mers, cold winters
Terrain: Armenian Highland with
mountains; little forest land; fast flowing
rivers; good soil in Aras River valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerrnagagat’ 4,090
m
Natural resources: small deposits of
gold, copper, molybdenum, zinc, bauxite
Land use:
arable land: 16.78%
permanent crops: 2.01%
other: 81.21% (2005)
Irrigated land: 2,860 sq km (2003)
Total renewable water resources: 10.5
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.95 cu
km/yr (30%/4%/66%)
per capita: 977 cu m/yr (2000)
Natural hazards: occasionally severe
earthquakes; droughts
Environment — current issues: soil pol¬
lution from toxic chemicals such as
DDT; the energy crisis of the 1990s led to
deforestation when citizens scavenged
for firewood; pollution of Hrazdan
(Razdan) and Aras Rivers; the draining
of Sevana Lich (Lake Sevan), a result of
its use as a source for hydropower,
threatens drinking water supplies; restart
of Metsamor nuclear power plant in spite
of its location in a seismically active zone
Environment — international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography— note: landlocked in the
Lesser Caucasus Mountains; Sevana Lich
(Lake Sevan) is the largest lake in this
mountain range
Location: Caribbean, island in the
Caribbean Sea, north of Venezuela
Geographic coordinates: 12 30 N, 69 58
W
Map references: Central America and
the Caribbean
Area:
total: 193 sq km
land: 193 sq km
water: 0 sq km
Area — comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims: territorial sea: 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: flat with a few hills; scant
vegetation
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources: NEGL; white sandy
beaches
Land use:
arable land: 10.53%
permanent crops: 0%
other: 89.47% (2005)
Irrigated land: 0.01 sq km (1998 est.)
Natural hazards: hurricanes; lies outside
the Caribbean hurricane belt and is
rarely threatened
Environment— current issues: NA
Geography — note: a flat, riverless island
renowned for its white sand beaches; its
tropical climate is moderated by con¬
stant trade winds from the Atlantic
Ocean; the temperature is almost con¬
stant at about 27 degrees Celsius (81
degrees Fahrenheit)','8b893e832b8dadb48127ceec45b7a89414e850a61f2fa6516574edfee5d3361a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db006bc0fd38a97b0d759c2da66a4a4a25904af16d58e4cf03ad28de3c538c16',2009,'AW','Aruba','geography',127,'Location: body of water between Africa,
Europe, the Southern Ocean, and the
Western Hemisphere
Geographic coordinates: 0 00 N, 25 00
w
Map references: Political Map of the
World
Area:
total: 76.762 million sq km
note: includes Baltic Sea, Black Sea,
Caribbean Sea, Davis Strait, Denmark
Strait, part of the Drake Passage, Gulf of
Mexico, Labrador Sea, Mediterranean
Sea, North Sea, Norwegian Sea, almost
all of the Scotia Sea, and other tributary
water bodies
Area — comparative: slightly less than
6.5 times the size of the US
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes)
develop off the coast of Africa near Cape
Verde and move westward into the
Caribbean Sea; hurricanes can occur
from May to December, but are most fre¬
quent from August to November
Terrain: surface usually covered with sea
ice in Labrador Sea, Denmark Strait, and
coastal portions of the Baltic Sea from
October to June; clockwise warm-water
gyre (broad, circular system of currents)
in the northern Atlantic, counterclock¬
wise warm-water gyre in the southern
Atlantic; the ocean floor is dominated by
the Mid-Atlantic Ridge, a rugged north-
south centerline for the entire Atlantic
basin
Elevation extremes:
lowest point: Milwaukee Deep in the
Puerto Rico Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields,
fish, marine mammals (seals and
whales), sand and gravel aggregates,
placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in
Davis Strait, Denmark Strait, and the
northwestern Atlantic Ocean from
February to August and have been
spotted as far south as Bermuda and the
Madeira Islands; ships subject to super-
39
THE CIA WORLD FACTBOOK
structure icing in extreme northern
Atlantic from October to May; persistent
fog can be a maritime hazard from May
to September; hurricanes (May to
December)
Environment — current issues: endan-
gered marine species include the man''
atee, seals, sea lions, turtles, and whales;
drift net fishing is hastening the decline
of fish stocks and contributing to inter¬
national disputes; municipal sludge pol¬
lution off eastern US, southern Brazil,
and eastern Argentina; oil pollution in
Caribbean Sea, Gulf of Mexico, Lake
Maracaibo, Mediterranean Sea, and
North Sea; industrial waste and munic¬
ipal sewage pollution in Baltic Sea,
North Sea, and Mediterranean Sea
Geography — note: major chokepoints
include the Dardanelles, Strait of
Gibraltar, access to the Panama and Suez
Canals; strategic straits include the Strait
of Dover, Straits of Florida, Mona
Passage, The Sound (Oresund), and
Windward Passage; the Equator divides
the Atlantic Ocean into the North
Atlantic Ocean and South Atlantic
Ocean','f6286204148238d8a073c5e732756bba6456f869f24c9a2abe7ae3aea2ea0181','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a4d120631ce547f40a0fdec012e4409ea05ca11202d0b5db0e863c7d7d6b8bd',2009,'AU','Australia','geography',129,'Location: Oceania, continent between
the Indian Ocean and the South Pacific
Ocean
Geographic coordinates: 27 00 S, 133
00 E
Map references: Oceania
Area:
total: 7,686,850 sq km
land: 7,617,9 30 sq km
water: 68,920 sq km
note: includes Lord Howe Island and
Macquarie Island
Area — comparative: slightly smaller
than the US contiguous 48 states
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: generally arid to semiarid; tem¬
perate in south and east; tropical in north
Terrain: mostly low plateau with deserts;
fertile plain in southeast
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciuszko 2,229 m
Natural resources: bauxite, coal, iron
ore, copper, tin, gold, silver, uranium,
nickel, tungsten, mineral sands, lead,
zinc, diamonds, natural gas, petroleum
Land use:
arable land: 6.15% (includes about 27
million hectares of cultivated grassland)
permanent crops: 0.04%
other: 93.81% (2005)
Irrigated land: 25,450 sq km (2003)
Total renewable water resources: 398
cu km (1995)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 24.06 cu
km/yr (15%/10%/75%)
per capita: 1,193 cu m/yr (2000)
Natural hazards: cyclones along the
coast; severe droughts; forest fires
Environment— current issues: soil ero¬
sion from overgrazing, industrial devel¬
opment, urbanization, and poor farming
practices; soil salinity rising due to the
use of poor quality water; desertification;
clearing for agricultural purposes
threatens the natural habitat of many
unique animal and plant species; the
Great Barrier Reef off the northeast
coast, the largest coral reef in the world,
is threatened by increased shipping and
its popularity as a tourist site; limited
natural fresh water resources
40
Environment— international agree¬
ments: party to: Antarctic-En¬
vironmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: world’s smallest con¬
tinent but sixth-largest country; popula¬
tion concentrated along the eastern and
southeastern coasts; the invigorating sea
breeze known as the “Premantle Doctor”
affects the city of Perth on the west
coast, and is one of the most consistent
winds in the world
Location: Caribbean, island in the
Caribbean Sea, 35 miles west of Tiburon
Peninsula of Haiti
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and
the Caribbean
Area:
total: 5.4 sq km
land: 5.4 sq km
water: 0 sq km
Area — comparative: about nine times
the size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: marine, tropical
Terrain: raised coral and limestone
plateau, flat to undulating; ringed by ver¬
tical white cliffs (9 to 15 m high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on
southwest side 77 m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Natural hazards: hurricanes
Environment— current issues: NA
Geography — note: strategic location
160 km south of the US Naval Base at
Guantanamo Bay, Cuba; mostly exposed
rock with numerous solution holes but
with enough grassland to support goat
herds; dense stands of fig trees, scattered
cactus
Geographic coordinates: 16 00 S, 167
00 E
Map references: Oceania
Area:
total: 12,200 sq km
land: 12,200 sq km
water: 0 sq km
note: includes more than 80 islands,
about 65 of which are inhabited
Area — comparative: slightly larger than
Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime Claims: measured from
claimed archipelagic baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical; moderated by south¬
east trade winds from May to October;
moderate rainfall from November to
April; may be affected by cyclones from
December to April
Terrain: mostly mountainous islands of
volcanic origin; narrow coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tabwemasana 1,877 m
Natural resources: manganese, hard¬
wood forests, fish
Land use:
arable land: 1.64%
permanent crops: 6.97%
other: 91.39% (2005)
Irrigated land: NA
Natural hazards: tropical cyclones or
typhoons (January to April); volcanic
eruption on Aoba (Ambae) island began
27 November 2005, volcanism also
causes minor earthquakes; tsunamis
Environment— current issues: most of
the population does not have access to a
reliable supply of potable water; defor¬
estation
Environment — international agree¬
ments: party to: Antarctic-Marine
Living Resources, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 94
signed, but not ratified: none of the
selected agreements
Geography— note: a Y shaped chain of
four main islands and 80 smaller islands;
several of the islands have active volca¬
noes','13cad5687b146a39716bbcdf2b1cb5001d7b09e260acb2a98155b4a13205d67b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cb2793cfd8c497f461de3bfd2a66f1da350a95cd7f1dafb090635407ab0475d',2009,'AT','Austria','geography',136,'Location: Central Europe, north of Italy
and Slovenia
Geographic coordinates: 47 20 N, 13 20
E
Map references: Europe
43
THE CIA WORLD FACTBOOK
Area:
total: 83,870 sq km
land: 82,444 sq km
water: 1,426 sq km
Area — comparative: slightly smaller
than Maine
Land boundaries:
total: 2,562 km
border countries: Czech Republic 362 km,
Germany 784 km, Hungary 366 km, Italy
430 km, Liechtenstein 35 km, Slovakia
91 km, Slovenia 330 km, Switzerland
164 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; continental, cloudy;
cold winters with frequent rain and some
snow in lowlands and snow in moun¬
tains; moderate summers with occasional
showers
Terrain : in the west and south mostly
mountains (Alps); along the eastern and
northern margins mostly flat or gently
sloping
Elevation extremes:
lowest point: Neusiedler See 115 m
highest point: Grossglockner 3,798 m
Natural resources: oil, coal, lignite,
timber, iron ore, copper, zinc, antimony,
magnesite, tungsten, graphite, salt,
hydropower
Land use:
arable land: 16.59%
permanent crops: 0.85%
other: 82.56% (2005)
Irrigated land: 40 sq km (2003)
Total renewable water resources: 84 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.67 cu
km/yr (35%/64%/l%)
per capita: 448 cu m/yr (1999)
Natural hazards: landslides; avalanches;
earthquakes
Environment— current issues: some
forest degradation caused by air and soil
pollution; soil pollution results from the
use of agricultural chemicals; air pollu¬
tion results from emissions by coal- and
oil-fired power stations and industrial
plants and from trucks transiting Austria
between northern and southern Europe
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulphur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; strategic
location at the crossroads of central
Europe with many easily traversable
Alpine passes and valleys; major river is
the Danube; population is concentrated
on eastern lowlands because of steep
slopes, poor soils, and low temperatures
elsewhere','a43a7a036e3048794c1c79bf835ddd7d55843982e6098dec9ec93ca9598ba9ee','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f3ceb11c24405d0613d09db9c6a0bb3eb14f53e8207cebdc491516854206ab9',2009,'AZ','Azerbaijan','geography',142,'Location: Southwestern Asia, bordering
the Caspian Sea, between Iran and
Russia, with a small European portion
north of the Caucasus range
Geographic coordinates: 40 30 N, 47 30
E
Map references: Asia
Area:
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan
Autonomous Republic and the Nagorno-
Karabakh region; the region’s autonomy
was abolished by Azerbaijani Supreme
Soviet on 26 November 1991
Area — comparative: slightly smaller
than Maine
Land boundaries:
total: 2,013 km
border countries: Armenia (with
Azerbaijan-proper) 566 km, Armenia
(with Azerbaijan-Naxcivan exclave) 221
km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km,
Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked); note —
Azerbaijan borders the Caspian Sea (800
km est.)
Maritime Claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi
(Kura-Araks Lowland) (much of it below
sea level) with Great Caucasus
Mountains to the north, Qarabag Yaylasi
(Karabakh Upland) in west; Baku lies on
Abseron Yasaqligi (Apsheron Peninsula)
that juts into Caspian Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural
gas, iron ore, nonferrous metals, bauxite
Land use: arable land: 20.62%
permanent crops: 2.61%
other: 76.77% (2005)
Irrigated land: 14,550 sq km (2003)
Total renewable water resources: 30.3
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 17.25 cu
km/yr (5%/28%/68%)
per capita: 2,051 cu m/yr (2000)
Natural hazards: droughts
Environment — current issues: local sci¬
entists consider the Abseron Yasaqligi
(Apsheron Peninsula) (including Baku
and Sumqayit) and the Caspian Sea to
be the ecologically most devastated area
in the world because of severe air, soil,
and water pollution; soil pollution results
from oil spills, from the use of DDT pes¬
ticide, and from toxic defoliants used in
the production of cotton
Environment— international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: both the main area of
the country and the Naxcivan exclave
are landlocked
Population: 8,177,717 (July 2008 est.)
Age structure:
0-14 years: 24.6% (male
1,061,318/female 947,607)
15-64 years: 68.6% (male
2,753,277/female 2,855,406)
65 years and over: 6.8% (male
208,293/female 351,816) (2008 est.)
Median age:
total: 27.9 years
male: 26.3 years
female: 29.7 years (2008 est.)
Population growth rate: 0.723% (2008
est.)
Birth rate: 17.52 births/1,000 population
(2008 est.)
Death rate: 8.32 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: - 1 .97 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1.12 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.97 male(s)/female
(2008 est.)
Infant mortality rate:
total: 56.43 deaths/1,000 live births
male: 62.09 deaths/1,000 live births
female: 49.98 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 66.31 years
male: 62.2 years
female: 71 years (2008 est.)
Total fertility rate: 2.05 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 1,400 (2003 est.)
HIV/AIDS — deaths: fewer than 100
(2001 est.)
Nationality:
noun: Azerbaijani s)
adjective: Azerbaijani
Ethnic groups: Azeri 90.6%, Dagestani
2.2%, Russian 1.8%, Armenian 1.5%,
other 3.9% (1999 census)
note: almost all Armenians live in the
separatist Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian
Orthodox 2.5%, Armenian Orthodox
2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal
in Azerbaijan; percentages for actual
practicing adherents are much lower
Languages: Azerbaijani (Azeri) 90.3%,
Lezgi 2.2%, Russian 1.8%, Armenian
1.5%, other 3.3%, unspecified 1% (1999
census)
Literacy:
definition: age 15 and over can read and
write
total population: 98.8%
male: 99.5%
female: 98.2% (1999 census)
Location: Caribbean, chain of islands in
the North Atlantic Ocean, southeast of
Florida, northeast of Cuba
Geographic coordinates: 24 15 N, 76 00
w
Map references: Central America and
the Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area — comparative: slightly smaller
than Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; moderated by
warm waters of Gulf Stream
Terrain: long, flat coral formations with
some low rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat
Island 63 m
Natural resources: salt, aragonite,
timber, arable land
Land use:
arable land: 0.58%
permanent crops: 0.29%
other: 99.13% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: NA
Natural hazards: hurricanes and other
tropical storms cause extensive flood and
wind damage
Environment — current issues: coral reef
decay; solid waste disposal
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location
adjacent to US and Cuba; extensive
island chain of which 30 are inhabited
Population: 307,451
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor¬
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 26.4% (male 40,608/female
40,506)
15—64 years: 66.9% (male
101,150/female 104,457)
65 years and over: 6.7% (male
8,472/female 12,258) (2008 est.)
Median age:
total: 28.4 years
male: 27.6 years
female: 29.2 years (2008 est.)
Population growth rate: 0.57% (2008
est.)
Birth rate: 17.06 births/1,000 population
(2008 est.)
Death rate: 9.22 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -2.14 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 23.67 deaths/1,000 live births
male: 28.89 deaths/ 1,000 live births
female: 18.34 deaths/ 1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 65.72 years
male: 62.5 years
female: 69 years (2008 est.)
Total fertility rate: 2.13 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 3%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 5,600 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 12%,
Asian and Hispanic 3%
Religions: Baptist 35.4%, Anglican
15.1%, Roman Catholic 13.5%,
Pentecostal 8.1%, Church of God 4.8%,
Methodist 4.2%, other Christian 15.2%,
none or unspecified 2.9%, other 0.8%
(2000 census)
Languages: English (official), Creole
(among Haitian immigrants)
Literacy:
definition: age 15 and over can read and
write
total population: 95.6%
male: 94-7%
female: 96.5% (2003 est.)','336130dffb9290f04fba698d6ca6e609c4ddfd373b1b751445a00c7608d5e542','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7af915d78fbc224c0dd5cd142eb095276c6f534634aa23124a04e0232aa563',2009,'BH','Bahrain','geography',151,'_ _
Location: Middle East, archipelago in
the Persian Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33
E
Map references: Middle East
Area:
total: 665 sq km
land: 665 sq km
water: 0 sq km
Area — comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
territorial sea: 12 nm
53
THE CIA WORLD FACTBOOK
contiguous zone: 24 nm
continental shelf: extending to boundaries
to be determined
Climate: arid; mild, pleasant winters;
very hot, humid summers
Terrain: mostly low desert plain rising
gently to low central escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and
nonassociated natural gas, fish, pearls
Land use: arable land: 2.82%
permanent crops: 5.63%
other: 91.55% (2005)
Irrigated land: 40 sq km (2003)
Total renewable water resources: 0.1
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.3 cu
km/yr (40%/3%/57%)
per capita: 411 cu m/yr (2000)
Natural hazards: periodic droughts ; dust
storms
Environment— current issues: desertifi-
cation resulting from the degradation of
limited arable land, periods of drought,
and dust storms; coastal degradation
(damage to coastlines, coral reefs, and
sea vegetation) resulting from oil spills
and other discharges from large tankers,
oil refineries, and distribution stations;
lack of freshwater resources (ground''
water and seawater are the only sources
for all water needs)
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: close to primary
Middle Eastern petroleum sources;
strategic location in Persian Gulf,
through which much of the Western
world’s petroleum must transit to reach
open ocean
Population: 718,306
note: includes 235,108 non-nationals
(July 2008 est.)
Age structure:
0-14 years: 26.4% (male 95,709/female
93,747)
15-64 years: 69.8% (male
288,957/female 212,706)
65 years and over: 3.8% (male
14,224/female 12,963) (2008 est.)
Median age:
total: 29.9 years
male: 33 years
female: 26.4 years (2008 est.)
Population growth rate: 1.337% (2008
est.)
Birth rate: 17.26 births/1,000 population
(2008 est.)
Death rate: 4.29 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: 0.4 migrant(s)/l,000
population (2008 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.36 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1.25 male(s)/female
(2008 est.)
Infant mortality rate:
total: 15.64 deaths/1,000 live births
male: 18.27 deaths/1,000 live births
female: 12.93 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 74-92 years
male: 72.41 years
female: 77.5 years (2008 est.)
Total fertility rate: 2.53 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.2%
(2001 est.)
HIV/AIDS — people living with
HIV/AIDS: fewer than 600 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 62.4%, non-
Bahraini 37.6% (2001 census)
Religions: Muslim (Shi’a and Sunni)
81.2%, Christian 9%, other 9.8% (2001
census)
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 15 and over can read and
write
total population: 86.5%
male: 88.6%
female: 83.6% (2001 census)
’■ ,/•. ;• V V- "''A • ‘ - Vj v* A"''f5b7fl''r 7 *V'' -C- TyW','a3c8a98493a5a99eb4a6611af385a3950dfc58d57af134eb5f7178ddd4f6d4b9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6fb078352b8007d0f01552943a0bc7b235246dc5c1f9fed7ac08081587f117b',2009,'BB','Barbados','geography',159,'Location: Caribbean, island in the North
Atlantic Ocean, northeast of Venezuela
Geographic coordinates: 13 10 N, 59 32
W
Map references: Central America and
the Caribbean
Area:
total: 43 1 sq km
land: 431 sq km
water: 0 sq km
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (June to
October)
Terrain: relatively flat; rises gently to
central highland region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, nat¬
ural gas
Land use: arable land: 37.21%
permanent crops: 2.33%
other: 60.46% (2005)
Irrigated land: 50 sq km (2003)
Total renewable water resources: 0.1
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.09 cu
km/yr (33%/44%/22%)
per capita: 333 cu m/yr (2000)
Natural hazards: infrequent hurricanes;
periodic landslides
59
THE CIA WORLD FACTBOOK
Environment — current issues: pollution
of coastal waters from waste disposal by
ships; soil erosion; illegal solid waste dis¬
posal threatens contamination of
aquifers
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: easternmost
Caribbean island
Population: 281,968 (July 2008 est.)
Age structure:
0-14 years: 19.3% (male 27,270/female
27,193)
15-64 years: 71.7% (male 99,357/female
102,683)
65 years and over: 9% (male 9,856/female
15,609) (2008 est.)
Median age:
total: 35.4 years
male: 34.2 years
female: 36.4 years (2008 est.)
Population growth rate: 0.36% (2008
est.)
Birth rate: 12.48 births/1,000 population
(2008 est.)
Death rate: 8.58 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: 0.31 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.01 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over : 0.63 male(s)/female
total population: 0.94 male(s)/female
(2008 est.)
Infant mortality rate:
total: 11.05 deaths/1,000 live births
male: 12.4 deaths/ 1,000 live births
female: 9.69 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 73.21 years
male: 71.2 years
female: 75.24 years (2008 est.)
Total fertility rate: 1.65 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 1.5%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 2,500 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Barbadian(s) or Bajan (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: black 90%, white 4%,
Asian and mixed 6%
Religions: Protestant 67% (Anglican
40%, Pentecostal 8%, Methodist 7%,
other 12%), Roman Catholic 4%, none
17%, other 12%
Languages: English
Literacy:
definition: age 15 and over has ever
attended school
total population: 99.7%
male : 99.7%
female: 99.7% (2002 est.)
Country name:
conventional long form: none
conventional short form: Barbados
Government type: parliamentary democ-
racy
Capital: name: Bridgetown
geographic coordinates: 13 06N,5937W
time difference: UTC''4 (1 hour ahead of
Washington, DC during Standard Time)
Administrative divisions: 11 parishes
and 1 city*; Bridgetown*, Christ
Church, Saint Andrew, Saint George,
Saint James, Saint John, Saint Joseph,
Saint Lucy, Saint Michael, Saint Peter,
Saint Philip, Saint Thomas
Independence: 30 November 1966
(from UK)
National holiday: Independence Day, 30
November (1966)
Constitution: 30 November 1966
Legal system: English common law; no
judicial review of legislative acts; accepts
compulsory ICJ jurisdiction, with reser-
vations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); represented by
Governor General Sir Clifford Straughn
HUSBANDS (since 1 June 1996)
head of government: Prime Minister David
THOMPSON (since 16 January 2008)
cabinet: Cabinet appointed by the gov¬
ernor general on the advice of the prime
minister
elections: the monarch is hereditary; gov¬
ernor general appointed by the monarch;
following legislative elections, the leader
of the majority party or the leader of the
majority coalition is usually appointed
prime minister by the governor general;
the prime minister recommends the
deputy prime minister
Legislative branch: bicameral
Parliament consists of the Senate (21
seats; members appointed by the gov¬
ernor general — 12 on the advice of the
Prime Minister, 2 on the advice of the
opposition leader, and 7 at his discre¬
tion) and the House of Assembly (30
seats; members are elected by direct pop¬
ular vote to serve five-year terms)
elections: House of Assembly — last held
15 January 2008 (next to be called in
2013)
election results: House of Assembly — per¬
cent of vote by party — DLP 52.5%, BLP
47.3%; seats by party — DLP 20, BLP 10
Judicial branch: Supreme Court of
Judicature (judges are appointed by the
Service Commissions for the Judicial and
Legal Services); Caribbean Court of
Justice is the highest court of appeal
Political parties and leaders: Barbados
Labor Party or BLP [Mia MOTTLEY];
Democratic Labor Party or DLP [David
THOMPSON]; People’s Empowerment
Party or PEP [David COMISSIONG]
Political pressure groups and leaders:
Barbados Secondary Teachers’ Union or
BSTU [Patrick FROST]; Barbados
Union of Teachers or BUT [Herbert
GITTENS]; Congress of Trade Unions
and Staff Associations of Barbados or
CTUSAB, (includes the BWU, NUPW,
BUT, and BSTU) [Leroy TROTMAN];
Barbados Workers Union or BWU
[Leroy TROTMAN]; Clement Payne
Labor Union [David COMISSIONG];
National Union of Public Workers
[Joseph GODDARD]
International organization participa¬
tion: ACP, C, Caricom, CDB, FAO, G-
77, IADB, IBRD, ICAO, ICCt, ICRM,
IDA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Interpol, IOC, ISO, ITSO, ITU,
ITUC, LAES, MIGA, NAM, OAS,
OPANAL, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCO,
WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Michael Ian
KING
chancery: 2144 Wyoming Avenue NW,
Washington, DC 20008
telephone: [1] (202) 939-9200
FAX: [1] (202) 332-7467
consulate(s) general: Miami, New York
consulate(s) : Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Mary M.
OURISMAN
embassy: U.S. Embassy, Wildey Business
Park, Wildey, St. Michael
mailing address: P. O. Box 302,
Bridgetown; CMR 1014, APO AA 34055
telephone: [1] (246) 436-4950
FAX: [1] (246) 429-5246, 429-3379
Flag description: three equal vertical
bands of blue (hoist side), gold, and blue
with the head of a black trident centered
on the gold band; the trident head repre¬
sents independence and a break with the
past (the colonial coat of arms contained
a complete trident)
60
V \\< Ac
Location: island 300 km southeast of','8beb32e35333183a1c12f77ef2e6a25d803bb3d6c24bd0f35c2991ecaf5318f6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c780443c19c5b0e9bfc76a3bd11e1b8b44f41398e9d18e56bd15bd79fcb40814',2009,'FR','France','geography',176,'Location: Central America, bordering
the Caribbean Sea, between Guatemala
and Mexico
Geographic coordinates: 17 15 N, 88 45
w
Map references: Central America and
the Caribbean
Area:
total: 22,966 sq km
land: 22,806 sq km
water: 160 sq km
Area — comparative: slightly smaller
than Massachusetts
Land boundaries:
total: 516 km
border countries: Guatemala 266 km,
Mexico 250 km
Coastline: 386 km
Maritime claims:
territorial sea: 12 nm in the north, 3 nm
in the south; note — from the mouth of
the Sarstoon River to Ranguana Cay,
Belize’s territorial sea is 3 nm; according
to Belize’s Maritime Areas Act, 1992, the
purpose of this limitation is to provide a
framework for negotiating a definitive
agreement on territorial differences with
Location: metropolitan France: Western
Europe, bordering the Bay of Biscay and
English Channel, between Belgium and
Spain, southeast of the UK; bordering
the Mediterranean Sea, between Italy
and Spain
French Guiana: Northern South
America, bordering the North Atlantic
Ocean, between Brazil and Suriname
Guadeloupe: Caribbean, islands between
the Caribbean Sea and the North
Atlantic Ocean, southeast of Puerto
Rico
Martinique: Caribbean, island between
the Caribbean Sea and North Atlantic
Ocean, north of Trinidad and Tobago
Reunion: Southern Africa, island in the
Indian Ocean, east of Madagascar
Geographic coordinates: metropolitan
France: 46 00 N, 2 00 E
French Guiana: 4 00 N, 53 00 W
Guadeloupe: 16 15 N, 61 35 W
Martinique: 14 40 N, 61 00 W
Reunion: 21 06 S, 55 36 E
Map references: metropolitan France:
Europe
French Guiana: South America
Guadeloupe: Central America and the
Caribbean
Martinique: Central America and the
Caribbean
Reunion: World
Area:
total: 643,427 sq km; 547,030 sq km
(metropolitan France)
land: 640,053 sq km; 545,630 sq km
(metropolitan France)
water: 3,374 sq km; 1,400 sq km (metro¬
politan France)
note: the first numbers include the over¬
seas regions of French Guiana,
Guadeloupe, Martinique, and Reunion
Area — comparative: slightly less than
the size of Texas
Land boundaries:
metropolitan France — total: 2,889 km
border countries: Andorra 56.6 km,
Belgium 620 km, Germany 451 km, Italy
488 km, Luxembourg 73 km, Monaco 4-4
km, Spain 623 km, Switzerland 573 km
French Guiana — total: 1,183 km
border countries : Brazil 673 km, Suriname
510 km
Coastline: total: 4,668 km
metropolitan France: 3,427 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm (does
not apply to the Mediterranean)
continental shelf: 200-m depth or to the
depth of exploitation
Climate: metropolitan France: generally
cool winters and mild summers, but mild
winters and hot summers along the
Mediterranean; occasional strong, cold,
dry, north-to-northwesterly wind known
as mistral
French Guiana: tropical; hot, humid;
little seasonal temperature variation
Guadeloupe and Martinique: subtropical
tempered by trade winds; moderately
high humidity; rainy season (June to
October); vulnerable to devastating
cyclones (hurricanes) every eight years
on average
Reunion: tropical, but temperature mod¬
erates with elevation; cool and dry (May
to November), hot and rainy (November
to April)
Terrain: metropolitan France: mostly flat
plains or gently rolling hills in north and
west; remainder is mountainous, espe¬
cially Pyrenees in south, Alps in east
French Guiana: low-lying coastal plains
rising to hills and small mountains
Guadeloupe: Basse-Terre is volcanic in
origin with interior mountains; Grande-
Terre is low limestone formation; most of
the seven other islands are volcanic in
origin
Martinique: mountainous with indented
coastline; dormant volcano
Reunion: mostly rugged and moun¬
tainous; fertile lowlands along coast
Elevation extremes:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: metropolitan France:
coal, iron ore, bauxite, zinc, uranium,
antimony, arsenic, potash, feldspar,
fluorspar, gypsum, timber, fish
French Guiana: gold deposits, petroleum,
kaolin, niobium, tantalum, clay
Land use: arable land: 33.46%
229
THE CIA WORLD FACTBOOK
permanent crops: 2.03%
other: 64-51%
note: French Guiana — arable land
0.13%, permanent crops 0.04%, other
99.83% (90% forest, 10% other);
Guadeloupe — arable land 11.70%, per¬
manent crops 2.92%, other 85.38%;
Martinique — arable land 9.09%, perma¬
nent crops 10.0%, other 80.91%;
Reunion — arable land 13.94%, perma¬
nent crops 1.59%, other 84-47% (2005)
Irrigated land: total: 26,190 sq km;
metropolitan France: 26,000 sq km (2003)
Total renewable water resources: 189
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 33.16 cu
km/yr (16%/74%/10%)
per capita: 548 cu m/yr (2000)
Natural hazards: metropolitan France:
flooding; avalanches; midwinter wind¬
storms; drought; forest fires in south near
the Mediterranean
overseas departments: hurricanes
(cyclones), flooding, volcanic activity
(Guadeloupe, Martinique, Reunion)
Environment— current issues: some
forest damage from acid rain; air pollu¬
tion from industrial and vehicle emis¬
sions; water pollution from urban wastes,
agricultural runoff
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: largest West
European nation
Population: total: 64,057,790
note: 60,876,136 in metropolitan France
(July 2008 est.)
Age structure:
0-14 years: 18.6% (male
6,091,571/female 5,803,127)
15-64 years: 65.2% (male
20,884,919/female 20,849,988)
65 years and over: 16.3% (male
4,335,996/female 6,092,189) (2008 est.)
Median age:
total: 39.2 years
male: 37.7 years
female: 40.7 years (2008 est.)
Population growth rate: 0.574% (2008
est.)
Birth rate: 12.73 births/1,000 population
(2008 est.)
Death rate: 8.48 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 1.48 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 3.36 deaths/1,000 live births
male: 3.69 deaths/ 1,000 live births
female: 3.02 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 80.87 years
male: 77.68 years
female: 84.23 years (2008 est.)
Total fertility rate: 1.98 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.4%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 120,000 (2003 est.)
HIV/AIDS — deaths: fewer than 1,000
(2003 est.)
Nationality:
noun: Frenchman(men),
Frenchwoman( women )
adjective: French
Ethnic groups: Celtic and Latin with
Teutonic, Slavic, North African,
Indochinese, Basque minorities
overseas departments: black, white,
mulatto, East Indian, Chinese,
Amerindian
Religions: Roman Catholic 83%-88%,
Protestant 2%, Jewish 1%, Muslim 5%-
10%, unaffiliated 4%
overseas departments: Roman Catholic,
Protestant, Hindu, Muslim, Buddhist,
pagan
Languages: French 100%, rapidly
declining regional dialects and languages
(Provencal, Breton, Alsatian, Corsican,
Catalan, Basque, Flemish)
overseas departments: French, Creole
patois
Literacy:
definition: age 15 and over can read and
write
total population: 99%
male: 99%
female: 99% (2003 est.)
Geographic coordinates: 40 00 N, 4 00
w
Map references: Europe
Area:
total: 504,782 sq km
land: 499,542 sq km
water: 5,240 sq km
note: there are two autonomous cities —
Ceuta and Melilla— and 17 autonomous
communities including Balearic Islands
and Canary Islands, and three small
Spanish possessions off the coast of
Morocco — Islas Chafarinas, Penon de
Alhucemas, and Penon de Velez de la
Gomera
Area— comparative: slightly more than
twice the size of Oregon
Land boundaries:
total: 1,917.8 km
border countries: Andorra 63.7 km,
France 623 km, Gibraltar 1.2 km,
Portugal 1,214 km, Morocco (Ceuta) 6.3
km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm (applies
only to the Atlantic Ocean)
Climate: temperate; clear, hot summers
in interior, more moderate and cloudy
along coast; cloudy, cold winters in inte¬
rior, partly cloudy and cool along coast
Terrain: large, flat to dissected plateau
surrounded by rugged hills; Pyrenees in
north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on
Canary Islands 3,718 m
Natural resources: coal, lignite, iron
ore, copper, lead, zinc, uranium, tung¬
sten, mercury, pyrites, magnesite,
fluorspar, gypsum, sepiolite, kaolin,
potash, hydropower, arable land
Land use:
arable land: 27.18%
permanent crops: 9.85%
other: 62.97% (2005)
Irrigated land: 37,800 sq km (2003)
Total renewable water resources: lll.l
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 37.22 cu
km/yr (13%/19%/68%)
per capita: 864 cu m/yr (2002)
Natural hazards: periodic droughts
Environment— current issues: pollution
of the Mediterranean Sea from raw
sewage and effluents from the offshore
production of oil and gas; water quality
and quantity nationwide; air pollution;
deforestation; desertification
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds,
Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography — note: strategic location
along approaches to Strait of Gibraltar
Population: 40,491,051 (July 2008 est.)
Age structure:
0-14 years: 14.4% (male
3,011,815/female 2,832,788)
15-64 years: 67.6% (male
13,741,493/female 13,641,914)
65 years and over: 17.9% (male
3,031,597/female 4,231,444) (2008 est.)
Median age:
total: 40.7 years
male: 39.3 years
female: 42.1 years (2008 est.)
Population growth rate: 0.096% (2008
est.)
Birth rate: 9.87 births/1,000 population
(2008 est.)
Death rate: 9.9 deaths/1,000 population
(2008 est.)
Net migration rate: 0.99 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.07 male(s)/female
603
THE CIA WORLD FACTBOOK
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 4-26 deaths/1,000 live births
male: 4-65 deaths/1,000 live births
female: 3.85 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 79.92 years
male: 76.6 years
female: 83.45 years (2008 est.)
Total fertility rate: 1.3 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.7%
(2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 140,000 (2001 est.)
HIV/AIDS — deaths: fewer than 1,000
(2003 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of
Mediterranean and Nordic types
Religions: Roman Catholic 94%, other
6%
Languages: Castilian Spanish (official)
74%, Catalan 17%, Galician 7%, Basque
2%, are official regionally
Literacy:
definition: age 15 and over can read and
write
total population: 97.9%
male: 98.7%
female: 97.2% (2003 est.)','278481b34eeef011c5ad8ea8a5e8ca709f0995eebedfaac2feeb61487633330b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc5c829c6ae3a96a61bb4eae7219547e1408e08fe497909ef5da042f2162aea0',2009,'GT','Guatemala','geography',177,'exclusive economic zone: 200 nm
Climate: tropical; very hot and humid;
rainy season (May to November); dry
season (February to May)
Terrain: flat, swampy coastal plain; low
mountains in south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Doyle’s Delight 1,160 m
Natural resources: arable land poten¬
tial, timber, fish, hydropower
Land use:
arable land: 3.05%
permanent crops: 1.39%
other: 95.56% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 18.6
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.15 cu
km/yr (7%/73%/20%)
per capita: 556 cu m/yr (2000)
Natural hazards: frequent, devastating
hurricanes (June to November) and
coastal flooding (especially in south)
Environment — current issues: defor¬
estation; water pollution from sewage,
industrial effluents, agricultural runoff;
solid and sewage waste disposal
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: only country in
Central America without a coastline on
the North Pacific Ocean
’ ''"V’*'' - '' '' -•-''•••■
MM j
Location: Central America, bordering
the North Pacific Ocean, between El
Salvador and Mexico, and bordering the
Gulf of Honduras (Caribbean Sea)
between Honduras and Belize
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and
the Caribbean
Area:
total: 108,890 sq km
land: 108,430 sq km
water: 460 sq km
Area — comparative: slightly smaller
than Tennessee
269
THE CIA WORLD FACTBOOK
Land boundaries:
total: 1,687 km
border countries: Belize 266 km, El
Salvador 203 km, Honduras 256 km,
Mexico 962 km
Coastline: 400 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: tropical; hot, humid in low-
lands; cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,21 1 m
Natural resources: petroleum, nickel,
rare woods, fish, chicle, hydropower
Land use:
arable land: 13.22%
permanent crops: 5.6%
other: 81.18% (2005)
Irrigated land: 1,300 sq km (2003)
Total renewable water resources: 111.3
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.01 cu
km/yr (6%/13%/8 0%)
per capita: 160 cu m/yr (2000)
Natural hazards: numerous volcanoes in
mountains, with occasional violent
earthquakes; Caribbean coast extremely
susceptible to hurricanes and other trop¬
ical storms
Environment— current issues: defor¬
estation in the Peten rainforest; soil ero¬
sion; water pollution
Environment— international agree¬
ments: party to: Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: no natural harbors
on west coast
Population: 13,002,206 (July 2008 est.)
Age structure:
0-14 years: 40.1% (male
2,653,915/female 2,565,841)
15-64 years: 56.2% (male
3,539,874/female 3,762,471)
65 years and over: 3.7% (male
222,303/female 257,802) (2008 est.)
Median age: total: 19.2 years
male: 18.6 years
female: 19.7 years (2008 est.)
Population growth rate: 2.11% (2008
est.)
Birth rate: 28.55 births/1,000 population
(2008 est.)
Death rate: 5.19 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -2.26 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.97 male(s)/female
(2008 est.)
Infant mortality rate:
total: 28.79 deaths/1,000 live births
male: 31.21 deaths/1,000 live births
female: 26.24 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 69.99 years
male: 68.22 years
female: 71.86 years (2008 est.)
Total fertility rate: 3.59 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 1.1%
(2003 est.)
HIV/AIDS — people living with
HIV/AIDS: 78,000 (2003 est.)
HIV/AIDS— deaths: 5,800 (2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorborne disease: dengue fever and
malaria (2008)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed
Amerindian-Spanish — in local Spanish
called Ladino) and European 59.4%,
K’iche 9.1%, Kaqchikel 8.4%, Mam
7.9%, Q’eqchi 6.3%, other Mayan 8.6%,
indigenous non-Mayan 0.2%, other
0.1% (2001 census)
Religions: Roman Catholic, Protestant,
indigenous Mayan beliefs
Languages: Spanish 60%, Amerindian
languages 40% (23 officially recognized
Amerindian languages, including
Quiche, Cakchiquel, Kekchi, Mam,
Garifuna, and Xinca)
Literacy: definition: age 15 and over can
read and write
total population: 69.1%
male: 75.4%
female: 63.3% (2002 census)
y. \\ ''AS A','7f435a8a89a8114f9b1f0fbbe7a73b289b1db3df395a3665dad1b52975dfd74a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808fa7d8d8fb35ed94d8fab9d2c2bf6424f212decf7d27e88623091856ac0aa2',2009,'BT','Bhutan','geography',195,'Location: Southern Asia, between China
and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area — comparative: about one-half the
size of Indiana
Land boundaries:
total: 1,075 km
border countries: China 470 km, India
605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropical in southern
plains; cool winters and hot summers in
central valleys; severe winters and cool
summers in Himalayas
Terrain: mostly mountainous with some
fertile valleys and savanna
Elevation extremes:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower,
gypsum, calcium carbonate
Land use:
arable land: 2.3%
permanent crops: 0.43%
other: 9121% (2005)
Irrigated land: 400 sq km (2003)
Total renewable water resources: 95 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.43 cu
km/yr (5%/l%/94%)
per capita: 199 cu m/yr (2000)
Natural hazards: violent storms from
the Himalayas are the source of the
country’s name, which translates as Land
of the Thunder Dragon; frequent land¬
slides during the rainy season
Environment — current issues: soil ero¬
sion; limited access to potable water
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes
signed, but not ratified: Law of the Sea
Geography — note: landlocked; strategic
location between China and India; con¬
trols several key Himalayan mountain
passes','613d9c31c0747bfeb50cb0344dd03af3733b9cd6f34c701212f0fa684dc0b961','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff5df44f11c7ccfa7ca39972f62970415f25754b24a96df31d3e0a91fd3c909b',2009,'ZA','South Africa','geography',210,'Geographic coordinates: 22 00 S, 24 00
E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
water: 15,000 sq km
Area — comparative: slightly smaller
than Texas
Land boundaries:
total: 4,013 km
border countries: Namibia 1,360 km,
South Africa 1,840 km, Zimbabwe 813
km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: semiarid; warm winters and hot
summers
Terrain: predominantly flat to gently
rolling tableland; Kalahari Desert in
southwest
Elevation extremes:
lowest point: junction of the Limpopo and
Shashe Rivers 513 m
highest point: Tsodilo Hills 1,489 m
Natural resources: diamonds, copper,
nickel, salt, soda ash, potash, coal, iron
ore, silver
Land use:
arable land: 0.65%
permanent crops : 0.01%
other: 99.34% (2 005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 14.7
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.19 cu
km/yr (41%/18%/41%)
per capita: 107 cu m/yr (2000)
Natural hazards: periodic droughts; sea¬
sonal August winds blow from the west,
carrying sand and dust across the
country, which can obscure visibility
Environment— current issues: over¬
grazing; desertification; limited fresh
water resources
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; popula¬
tion concentrated in eastern part of the
country
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area: total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry
winters; hot, wet summers
Terrain: mostly highland with plateaus,
hills, and mountains
Elevation extremes:
lowest point: junction of the Orange and
Makhaleng Rivers 1,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural
and grazing land, diamonds, sand, clay,
building stone
Land use:
arable land: 10.87%
permanent crops: 0.13%
other: 89% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 5.2
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.05 cu
km/yr (40%/40%/20%)
per capita: 28 cu m/yr (2000)
Natural hazards: periodic droughts
Environment— current issues: popula¬
tion pressure forcing settlement in mar¬
ginal areas results in overgrazing, severe
soil erosion, and soil exhaustion; deserti¬
fication; Highlands Water Project con¬
trols, stores, and redirects water to South
Africa
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
376
Location: Southern Africa, at the
southern tip of the continent of Africa
Geographic coordinates: 29 00 S, 24 00
E
Map reterences: Africa
Area:
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands
(Marion Island and Prince Edward
Island)
Area— comparative: slightly less than
twice the size of Texas
Land boundaries:
total: 4,862 km
border countries: Botswana 1,840 km,
Lesotho 909 km, Mozambique 491 km,
Namibia 967 km, Swaziland 430 km,
Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the
continental margin
Climate: mostly semiarid; subtropical
along east coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium,
antimony, coal, iron ore, manganese,
nickel, phosphates, tin, uranium, gem
diamonds, platinum, copper, vanadium,
salt, natural gas
Land use:
arable land: 12.1%
permanent crops: 0.79%
other: 87.11% (2005)
Irrigated land: 14,980 sq km (2003)
Total renewable water resources: 50 cu
km (1990)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 12.5 cu
km/yr (31%/6%/63%)
per capita: 264 cu m/yr (2000)
Natural hazards: prolonged droughts
Environment — current issues: lack of
important arterial rivers or lakes requires
extensive water conservation and con¬
trol measures; growth in water usage out¬
pacing supply; pollution of rivers from
agricultural runoff and urban discharge;
air pollution resulting in acid rain; soil
erosion; desertification
Environment — international agree¬
ments: party to: Antarctic-
Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: South Africa com¬
pletely surrounds Lesotho and almost
completely surrounds Swaziland','67f12a167cb75a5e432725a1a43f5444f89ea0c916c7db7b2129512af81f3ac6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fbae3876bfa17da240fad93b1636d6a107824d7614f551bc385efdae84b845f',2009,'BV','Bouvet Island','geography',219,'Location: Eastern South America, bor¬
dering the Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00
W
Map references: South America
Area:
total: 8,511,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando
de Noronha, Atol das Rocas, Ilha da
Trindade, Ilhas Martin Vaz, and Penedos
de Sao Pedro e Sao Paulo
Area — comparative: slightly smaller
than the US
Land boundaries:
total: 16,885 km
border countries: Argentina 1,261 km,
Bolivia 3,423 km, Colombia 1,644 km,
French Guiana 730 km, Guyana 1,606
km, Paraguay 1,365 km, Peru 2,995 km,
Suriname 593 km, Uruguay 1,068 km,
Venezuela 2,200 km
Coastline: 7,491 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the
continental margin
Climate: mostly tropical, but temperate
in south
Terrain: mostly flat to rolling lowlands in
north; some plains, hills, mountains, and
narrow coastal belt
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron
ore, manganese, nickel, phosphates, plat¬
inum, tin, uranium, petroleum,
hydropower, timber
Land use:
arable land: 6.93%
permanent crops: 0.89%
other: 92.18% (2005)
Irrigated land: 29,200 sq km (2003)
Total renewable water resources: 8,233
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 59.3 cu
km/yr (20%/18%/62%)
per capita: 318 cu m/yr (2000)
Natural hazards: recurring droughts in
northeast; floods and occasional frost in
south
Environment— current issues: defor¬
estation in Amazon Basin destroys the
90','247b59e43767ce1367f87d9c1b4dcf7fd1850daa9654d98bd0714525c35f74ca','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29345fffcd77c618707d39206345370779c2c789f8530996517616e860d13ea2',2009,'BR','Brazil','geography',220,'habitat and endangers a multitude of
plant and animal species indigenous to
the area; there is a lucrative illegal
wildlife trade; air and water pollution in
Rio de Janeiro, Sao Paulo, and several
other large cities; land degradation and
water pollution caused by improper
mining activities; wetland degradation;
severe oil spills
Environment— international agree¬
ments: party to: Antarctic-
Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: largest country in
South America; shares common bound¬
aries with every South American country
except Chile and Ecuador
Location: Caribbean, between the
Caribbean Sea and the North Atlantic
Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30
W
Map references: Central America and
the Caribbean
Area:
total: 153 sq km
land: 153 sq km
water: 0 sq km
note: comprised of 16 inhabited and
more than 20 uninhabited islands;
includes the islands of Tortola, Anegada,
Virgin Gorda, Jost van Dyke
Area— comparative: about 0.9 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: subtropical; humid; tempera¬
tures moderated by trade winds
Terrain: coral islands relatively flat; vol¬
canic islands steep, hilly
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 6.67%
other: 73.33% (2005)
Irrigated land: NA
Natural hazards: hurricanes and tropical
storms (July to October)
Environment— current issues: limited
natural fresh water resources (except for
a few seasonal streams and springs on
Tortola, most of the islands’ water supply
comes from wells and rainwater catch¬
ments)
Geography — note: strong ties to nearby
US Virgin Islands and Puerto Rico
Population: 24,004 (July 2008 est.)
Age structure:
0-14 years: 19.9% (male 2,431/female
2,356)
15-64 years: 74-5% (male 9,176/female
8,708)
65 years and over: 5.6% (male 700/female
633) (2008 est.)
Median age:
total: 32 years
male: 32.1 years
female: 31.8 years (2008 est.)
Population growth rate: 1.875% (2008
est.)
Birth rate: 14.75 births/1,000 population
(2008 est.)
Death rate: 4.46 deaths/ 1,000 popula¬
tion (2008 est.)
95
Net migration rate: 8.46 migrant(s)/
1,000 population (2008 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.11 male(s)/female
total population: 1.05 male(s)/female
(2008 est.)
Infant mortality rate:
total: 15.54 deaths/1,000 live births
male: 18.15 deaths/1,000 live births
female: 12.8 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 77.06 years
male: 75.87 years
female: 78.3 years (2008 est.)
Total fertility rate: 1.72 children
bom/woman (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 83%, other 17%
(includes white, Indian, Asian and
mixed)
Religions: Protestant 86% (Methodist
33%, Anglican 17%, Church of God 9%,
Seventh-Day Adventist 6%, Baptist 4%,
Jehovah’s Witnesses 2%, other 15%),
Roman Catholic 10%, other 2%, none
2% (1991)
Languages: English (official)
Literacy:
definition: age 15 and over can read and
write
total population: 97.8% (1991 est.)
male: NA%
female: NA%
Country name:
conventional long form: none
conventional short form: British Virgin
Islands
abbreviation: BVI
Dependency status: overseas territory of
the UK; internal self-governing
Government type: NA
Capital: name: Road Town
geographic coordinates: 1827N, 64 37W
time difference: UTC-4 (1 hour ahead of
Washington, DC during Standard Time)
Administrative divisions: none (over¬
seas territory of the UK)
Independence: none (overseas territory
of the UK)
National holiday: Territory Day, 1 July
(1956)
Constitution: 13 June 2007
Legal system: English law
Suffrage: 18 years of age; universal
THE CIA WORLD FACTBOOK
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); represented by
Governor David PEAREY (since 18
April 2006)
head of government: Premier Ralph T.
O’NEAL (since 23 August 2007)
cabinet: Executive Council appointed by
the governor from members of the House
of Assembly
elections: the monarch is hereditary; gov¬
ernor appointed by the monarch; fol¬
lowing legislative elections, the leader of
the majority party or the leader of the
majority coalition is usually appointed
premier by the governor
Legislative branch: unicameral House of
Assembly (13 elected seats and 1 non-
voting ex officio member in the attorney
general; members are elected by direct
popular vote, 1 member from each of
nine electoral districts, 4 at-large mem¬
bers; members serve four-year terms)
elections: last held 20 August 2007 (next
to be held in 201 1 )
election results: percent of vote by party —
VIP 45.2%, NDP 39.6%, independent
15.2%; seats by party — VIP 10, NDP 2,
independent 1
Judicial branch: Eastern Caribbean
Supreme Court, consisting of the High
Court of Justice and the Court of Appeal
(one judge of the Supreme Court is a res¬
ident of the islands and presides over the
High Court); Magistrate’s Court;
Juvenile Court; Court of Summary
Jurisdiction
Political parties and leaders:
Concerned Citizens Movement or CCM
[Ethlyn SMITH]; National Democratic
Party or NDP [Orlando SMITH]; United
Party or UP [Gregory MADURO];
Virgin Islands Party or VIP [Ralph T.
O’NEAL]
Political pressure groups and leaders:
NA
International organization participa¬
tion: Caricom (associate), CDB, Interpol
(subbureau), IOC, OECS, UNESCO
(associate), UPU
Diplomatic representation in the US:
none (overseas territory of the UK)
Diplomatic representation from the US:
none (overseas territory of the UK)
Flag description: blue, with the flag of
the UK in the upper hoist-side quadrant
and the Virgin Islander coat of arms cen¬
tered in the outer half of the flag; the
coat of arms depicts a woman flanked on
either side by a vertical column of six oil
lamps above a scroll bearing the Latin
word VIGILATE (Be Watchful)
Location: Southeastern Asia, bordering
the South China Sea and Malaysia
Geographic coordinates: 4 30 N, 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
Area— comparative: slightly smaller
than Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm or to
median line
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to moun¬
tains in east; hilly lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural
gas, timber
Land use:
arable land: 2.08%
permanent crops: 0.87%
other: 97.05% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 8.5
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.09
per capita: 243 cu m/yr (1994)
Natural hazards: typhoons, earthquakes,
and severe flooding are rare
Environment — current issues: seasonal
smoke/haze resulting from forest fires in','b3817b2f2571d25728f7da4c157d2cfaf592aaa814c0d4ffeb0c96f569b8a67d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e48237b0756c93beb93018be9635f793d8bca71a2d472ed3f829241d4c34754',2009,'ID','Indonesia','geography',227,'97
THE CIA WORLD FACTBOOK
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the
selected agreements
Geography — note: close to vital sea
lanes through South China Sea linking
Indian and Pacific Oceans; two parts
physically separated by Malaysia; almost
an enclave within Malaysia
Population: 381,371 (July 2008 est.)
Age structure:
0-14 years: 27.2% (male 53,400/female
50,333)
15-64 years: 69.6 % (male
132,895/female 132,391)
65 years and over: 3.2% (male
5,927/female 6,425) (2008 est.)
Median age: total: 27.5 years
male: 27.5 years
female: 27.5 years (2008 est.)
Population growth rate: 1.785% (2008
est.)
Birth rate: 18.39 births/1,000 population
(2008 est.)
Death rate: 3.28 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: 2.74 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1.02 male(s)/female
(2008 est.)
Infant mortality rate:
total: 12.69 deaths/1,000 live births
male: 15.19 deaths/1,000 live births
female: 10.07 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 75.52 years
male: 73.32 years
female: 77.83 years (2008 est.)
Total fertility rate: 1.94 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS— people living with
HIV/AIDS: fewer than 200 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality: noun: Bruneian(s)
adjective: Bruneian
Ethnic groups: Malay 67%, Chinese
15%, indigenous 6%, other 12%
Religions: Muslim (official) 67%,
Buddhist 13%, Christian 10%, other
(includes indigenous beliefs) 10%
Languages: Malay (official), English,
Chinese
Literacy:
definition: age 15 and over can read and
write
total population: 92.7%
male: 95.2%
female: 90.2% (2001 census)
Country name:
conventional long form: Brunei
Darussalam
conventional short form: Brunei
local long form: Negara Brunei
Darussalam
local short form: Brunei
Government type: constitutional sul¬
tanate
Capital: name: Bandar Seri Begawan
geographic coordinates: 4 53 N, 114 56 E
time difference: UTC+8 (13 hours ahead
of Washington, DC during Standard
Time)
Administrative divisions: 4 districts
(daerah-daerah, singular — daerah);
Belait, Brunei and Muara, Temburong,
Tutong
Independence: 1 January 1984 (from
UK)
National holiday: National Day, 23
February (1984); note — 1 January 1984
was the date of independence from the
UK, 23 February 1984 was the date of
independence from British protection
Constitution: 29 September 1959 (some
provisions suspended under a State of
Emergency since December 1962, others
since independence on 1 January 1984)
Legal system: based on English common
law; for Muslims, Islamic Shari’a law
supersedes civil law in a number of areas;
has not accepted compulsory ICJ juris¬
diction
Suffrage: 18 years of age for village elec¬
tions; universal
Executive branch:
chief of state: Sultan and Prime Minister
Sir HASSANAL Bolkiah (since 5
October 1967); note — the monarch is
both the chief of state and head of gov¬
ernment
head of government: Sultan and Prime
Minister Sir HASSANAL Bolkiah
(since 5 October 1967)
cabinet: Council of Cabinet Ministers
appointed and presided over by the
monarch; deals with executive matters;
note — there is also a Religious Council
(members appointed by the monarch)
that advises on religious matters, a Privy
Council (members appointed by the
monarch) that deals with constitutional
matters, and the Council of Succession
(members appointed by the monarch)
that determines the succession to the
throne if the need arises
elections: none; the monarch is heredi¬
tary
Legislative branch: Legislative Council
met on 25 September 2004 for first time
in 20 years with 21 members appointed
by the Sultan; passed constitutional
amendments calling for a 45 -seat council
with 15 elected members; Sultan dis¬
solved council on 1 September 2005 and
appointed a new council with 29 mem¬
bers as of 2 September 2005; council met
in March 2006 and in March 2007
elections: last held in March 1962 (date
of next election NA)
Judicial branch: Supreme Court — chief
justice and judges are sworn in by
monarch for three-year terms; Judicial
Committee of Privy Council in London
is final court of appeal for civil cases;
Shariah courts deal with Islamic laws
(2006)
Political parties and leaders: National
Development Party or NDP [YASSIN
Affendi]
note: Brunei National Solidarity Party or
PPKB [Abdul LATIF bin Chuchu] and
People’s Awareness Party or PAKAR
[Awang Haji MAIDIN bin Haji Ahmad]
were deregistered; parties are small and
have limited activity
Political pressure groups and leaders:
NA
International organization participa¬
tion: ADB, APEC, APT, ARF, ASEAN,
C, EAS, G-77, IBRD, ICAO, ICRM,
IDB, IFRCS, ILO, IMF, IMO, IMSO,
Interpol, IOC, ISO (correspondent),
ITSO, ITU, NAM, OIC, OPCW, UN,
UNCTAD, UNESCO, UNWTO, UPU,
WCO, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Pengiran
Anak Dato PUTEH
chancery: 3520 International Court NW,
Washington, DC 20008
telephone: [1] (202) 237-1838
FAX: [1] (202) 885-0560
Diplomatic representation from the US:
chief of mission: Ambassador Emil
SKODON
embassy: Third Floor, Teck Guan Plaza,
Jalan Sultan, Bandar Seri Begawan,
BS8811
mailing address: PSC 470 (BSB), FPO AP
96507; P.O. Box 2991, Bandar Seri
Begawan BS8675, Negara Brunei
Darussalam
telephone: [673] 222-0384
FAX: [673] 222-529 3
Flag description: yellow with two diag¬
onal bands of white (top, almost double
width) and black starting from the upper
hoist side; the national emblem in red is
98
BRUNEI
superimposed at the center; the emblem
includes a swallow-tailed flag on top of a
winged column within an upturned cres-
cent above a scroll and flanked by two
upraised hands
Location: Middle East, bordering the
Gulf of Oman, the Persian Gulf, and the
Caspian Sea, between Iraq and Pakistan
Geographic coordinates: 32 00 N, 53 00
E
Map references: Middle East
Area:
total: 1.648 million sq km
land: 1.636 million sq km
water: 12,000sqkm
Area— comparative: slightly larger than
Alaska
Land boundaries: total: 5,440 km
border countries: Afghanistan 936 km,
Armenia 35 km, Azerbaijan-proper 432
km, Azerbaijan-Naxcivan exclave 179
km, Iraq 1,458 km, Pakistan 909 km,
Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km; note — Iran also
borders the Caspian Sea (740 km)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: bilateral agree¬
ments or median lines in the Persian
Gulf
continental shelf: natural prolongation
Climate: mostly arid or semiarid, sub¬
tropical along Caspian coast
Terrain: rugged, mountainous rim; high,
central basin with deserts, mountains;
small, discontinuous plains along both
coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Kuh-e Damavand 5,671 m
Natural resources: petroleum, natural
gas, coal, chromium, copper, iron ore,
lead, manganese, zinc, sulfur
Land use:
arable land: 9.78%
permanent crops : 1.29%
other: 88.93% (2005)
Irrigated land: 7 6,500 sq km (2003)
Total renewable water resources: 137.5
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 72.88 cu
km/yr (7%/2%/91%)
per capita: 1,048 cu m/yr (2000)
Natural hazards: periodic droughts,
floods; dust storms, sandstorms; earth¬
quakes
Environment— current issues: air pollu¬
tion, especially in urban areas, from
vehicle emissions, refinery operations,
and industrial effluents; deforestation;
overgrazing; desertification; oil pollution
in the Persian Gulf; wetland losses from
drought; soil degradation (salination);
inadequate supplies of potable water;
water pollution from raw sewage and
industrial waste; urbanization
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental
Modification, Law of the Sea, Marine
Life Conservation
Geography — note: strategic location on
the Persian Gulf and Strait of Hormuz,
which are vital maritime pathways for
crude oil transport
Geographic coordinates: 6 00 S, 147 00
E
Map references: Oceania
Area: total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area — comparative: slightly larger than
California
Land boundaries:
total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime Claims: measured from
claimed archipelagic baselines
territorial sea: 12 nm
continental shelf: 200-m depth or to the
depth of exploitation
exclusive fishing zone: 200 nm
Climate: tropical; northwest monsoon
(December to March), southeast mon¬
soon (May to October); slight seasonal
temperature variation
Terrain: mostly mountains with coastal
lowlands and rolling foothills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver,
natural gas, timber, oil, fisheries
Land use:
arable land: 0.49%
permanent crops : 1.4%
other: 98.11% (2005)
Irrigated land: NA
Total renewable water resources: 801
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.1 cu
km/yr (56%/43%/l%)
per capita: 17 cu m/yr (1987)
Natural hazards: active volcanism; situ¬
ated along the Pacific “Ring of Fire”; the
country is subject to frequent and some¬
times severe earthquakes; mud slides;
tsunamis
Environment — current issues: rain
forest subject to deforestation as a result
of growing commercial demand for trop¬
ical timber; pollution from mining proj¬
ects; severe drought
Environment— international agree¬
ments: party to: Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the
selected agreements
505
THE CIA WORLD FACTBOOK
Geography — note: shares island of New
Guinea with Indonesia; one of world’s
largest swamps along southwest coast
Population: 5,931,769 (July 2008 est.)
Age structure:
0-14 years: 37.3% (male
1,124,174/female 1,086,478)
15-64 years: 58.7% (male
1,791,342/female 1,690,089)
65 years and over: 4% (male
111,023/female 128,663) (2008 est.)
Median age:
total: 21.5 years
male: 21.6 years
female: 21.4 years (2008 est.)
Population growth rate: 2.118% (2008
est.)
Birth rate: 28.14 births/1,000 population
(2008 est.)
Death rate: 6.96 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.04 male(s)/female
(2008 est.)
Infant mortality rate:
total: 46.67 deaths/1,000 live births
male: 50.68 deaths/ 1,000 live births
female: 42.47 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 66 years
male: 63.76 years
female: 68.35 years (2008 est.)
Total fertility rate: 3.71 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.6%
(2003 est.)
HIV/AIDS — people living with
HIV/AIDS: 60,000 (2005 est.)
HIV/AIDS— deaths: 600 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever and
malaria (2008)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan,
Negrito, Micronesian, Polynesian
Religions: Roman Catholic 22%,
Lutheran 16%,
Presbyterian/Methodist/London
Missionary Society 8%, Anglican 5%,
Evangelical Alliance 4%, Seventh-Day
Adventist 1%, other Protestant 10%,
indigenous beliefs 34%
Languages: Melanesian Pidgin serves as
the lingua franca, English spoken by 1%-
2%, Motu spoken in Papua region
note: 820 indigenous languages spoken
(over one-tenth of the world’s total)
Literacy: definition: age 15 and over can
read and write
total population: 57.3%
male: 63.4%
female: 50.9% (2000 census)
Country name:
conventional long form: Independent
State of Papua New Guinea
conventional short form: Papua New','adb61a3846ea1e52462b27be47eddf3de2a7cf6bdc30ac621dd17f28265618b4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('510997eaaeccada84122bfa1b9643b3a475fe4a4d3ed86f7109ac552b7e1f382',2009,'BF','Burkina Faso','geography',237,'Location: Western Africa, north of
Location: Southeastern Asia, bordering
the Andaman Sea and the Bay of Bengal,
between Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area— comparative: slightly smaller
than Texas
Land boundaries:
total: 5,876 km
border countries: Bangladesh 193 km,
China 2,185 km, India 1,463 km, Laos
235 km, Thailand 1,800 km
Coastline: 1,930 km
Maritime claims:
territorial sea: 12 nm
106
BURMA
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical monsoon; cloudy,
rainy, hot, humid summers (southwest
monsoon, June to September); less
cloudy, scant rainfall, mild temperatures,
lower humidity during winter (northeast
monsoon, December to April)
Terrain: central lowlands ringed by steep,
rugged highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber,
tin, antimony, zinc, copper, tungsten,
lead, coal, marble, limestone, precious
stones, natural gas, hydropower
Land use: arable land: 14-92%
permanent crops : 1.31%
other: 83.77% (2005)
Irrigated land: 18,700 sqkm (2003)
Total renewable water resources:
1,045.6 cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 33.23 cu
km/yr (l%/l%/98%)
per capita: 658 cu m/yr (2000)
Natural hazards: destructive earth''
quakes and cyclones; flooding and land¬
slides common during rainy season (June
to September); periodic droughts
Environment — current issues: defor¬
estation; industrial pollution of air, soil,
and water; inadequate sanitation and
water treatment contribute to disease
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location
near major Indian Ocean shipping lanes','548db2f5fab72a7a15bffd3be4ff842bfde2737878734a4c23af0df9f671aea3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0abee10f542b25f7d958f837219e030aa664cc2a58f4178a62e5acc020750bcc',2009,'GH','Ghana','geography',238,'Geographic coordinates: 13 00 N, 2 00
w
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area — comparative: slightly larger than
Colorado
Land boundaries:
total: 3,193 km
border countries: Benin 306 km, Cote
d’Ivoire 584 km, Ghana 549 km, Mali
1,000 km, Niger 628 km, Togo 126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters;
hot, wet summers
Terrain: mostly flat to dissected, undu¬
lating plains; hills in west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta)
River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, lime¬
stone, marble; small deposits of gold,
phosphates, pumice, salt
Land use:
arable land: 17.66%
permanent crops: 0.22%
other: 82.12% (2005)
Irrigated land: 250 sq km (2003)
Total renewable water resources: 17.5
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.8 cu
km/yr (13%/l%/86%)
per capita: 60 cu m/yr (2000)
Natural hazards: recurring droughts
Environment — current issues: recent
droughts and desertification severely
affecting agricultural activities, popula¬
tion distribution, and the economy;
overgrazing; soil degradation; deforesta¬
tion
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Flazardous Wastes, Law of the
Sea, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked savanna
cut by the three principal rivers of the
Black, Red, and White Voltas
Population: 15,264,735
103
THE CIA WORLD FACTBOOK
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor-
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 46.3% (male
3,549,034/female 3,521,684)
15-64 years: 51.1% (male
3,885,124/female 3,922,198)
65 years and over: 2.5% (male
154,476/female 232,219) (2008 est.)
Median age:
total: 16.7 years
male: 16.5 years
female: 16.9 years (2008 est.)
Population growth rate: 3.109% (2008
est.)
Birth rate: 44.68 births/1,000 population
(2008 est.)
Death rate: 13.59 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.99 male(s)/female
(2008 est.)
Infant mortality rate:
total: 86.02 deaths/1,000 live births
male: 93.68 deaths/1,000 live births
female: 78.12 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 52.55 years
male: 50.67 years
female: 54.49 years (2008 est.)
Total fertility rate: 6.34 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 4.2%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 300,000 (2003 est.)
HIV/AIDS— deaths: 29,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A, and
typhoid fever
vectorbome disease: malaria
water contact disease: schistosomiasis
respiratory disease: meningococcal
meningitis
note: highly pathogenic H5N1 avian
influenza has been identified in this
country; it poses a negligible risk with
extremely rare cases possible among US
citizens who have close contact with
birds (2008)
Nationality:
noun; Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi over 40%, other
approximately 60% (includes Gurunsi,
Senufo, Lobi, Bobo, Mande, and Fulani)
Religions: Muslim 50%, indigenous
beliefs 40%, Christian (mainly Roman
Catholic) 10%
Languages: French (official), native
African languages belonging to Sudanic
family spoken by 90% of the population
Literacy:
definition: age 15 and over can read and
write
total population: 21.8%
male: 29.4%
female: 15.2% (2003 est.)
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area: total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
Area — comparative: slightly smaller
than West Virginia
Land boundaries:
total: 1,647 km
border countries: Benin 644 km, Burkina
Faso 126 km, Ghana 877 km
Coastline: 56 km
Maritime claims:
territorial sea: 30 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid in south;
semiarid in north
Terrain: gently rolling savanna in north;
central hills; southern plateau; low
coastal plain with extensive lagoons and
marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Agou 986 m
Natural resources: phosphates, lime¬
stone, marble, arable land
Land use:
arable land: 44.2%
permanent crops : 2.11%
other: 53.69% (2005)
Irrigated land: 70 sq km (2003)
Total renewable water resources: 14.7
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.17 cu
km/yr (53%/2%/45%)
per capita: 28 cu m/yr (2000)
Natural hazards: hot, dry harmattan
wind can reduce visibility in north
during winter; periodic droughts
Environment— current issues: defor¬
estation attributable to slash-and-burn
agriculture and the use of wood for fuel;
water pollution presents health hazards
and hinders the fishing industry; air pol¬
lution increasing in urban areas
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: the country’s length
allows it to stretch through six distinct
geographic regions; climate varies from
tropical to savanna','5940238bd85f2a12dee6c344e4f12ac6b7117c838a86b9b6f1e26cf8f89c3689','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bde5f76b83cedb7c6d33ac9fb4031f0da709f492aae6bf404615146b5c006308',2009,'BI','Burundi','geography',247,'Location: Central Africa, east of
Democratic Republic of the Congo
Geographic coordinates: 3 30 s, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area— comparative: slightly smaller
than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of
the Congo 233 km, Rwanda 290 km,
Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: equatorial; high plateau with
considerable altitude variation (772 m to
2,670 m above sea level); average annual
temperature varies with altitude from 23
to 1 7 degrees centigrade but is generally
moderate as the average altitude is about
1,700 m; average annual rainfall is about
150 cm; two wet seasons (February to
May and September to November), and
two dry seasons (June to August and
December to January)
Terrain: hilly and mountainous, drop¬
ping to a plateau in east, some plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Heha 2,670 m
Natural resources: nickel, uranium, rare
earth oxides, peat, cobalt, copper, plat¬
inum, vanadium, arable land,
hydropower, niobium, tantalum, gold,
tin, tungsten, kaolin, limestone
Land use:
arable land: 35.57%
permanent crops : 13.12%
other: 51.31% (2005)
Irrigated land: 210 sq km (2003)
Total renewable water resources: 3.6
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.29 cu
km/yr (17%/6%/77%)
per capita: 38 cu m/yr (2000)
Natural hazards: flooding, landslides,
drought
Environment— current issues: soil ero¬
sion as a result of overgrazing and the
expansion of agriculture into marginal
lands; deforestation (little forested land
remains because of uncontrolled cutting
of trees for fuel); habitat loss threatens
wildlife populations
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: landlocked; straddles
crest of the Nile-Congo watershed; the
Kagera, which drains into Lake Victoria,
is the most remote headstream of the
White Nile
Location: Southeastern Asia, bordering
the Gulf of Thailand, between Thailand,
Vietnam, and Laos
Geographic coordinates: 13 00 N, 105
00 E
Map references: Southeast Asia
Area:
total: 181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area— comparative: slightly smaller
than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand
803 km, Vietnam 1,228 km
Coastline: 443 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; rainy, monsoon season
(May to November); dry season
(December to April); little seasonal tem¬
perature variation
Terrain: mostly low, flat plains; moun¬
tains in southwest and north
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1,810 m
Natural resources: oil and gas, timber,
gemstones, iron ore, manganese, phos¬
phates, hydropower potential
Land use:
arable land: 20.44%
permanent crops: 0.59%
Other: 78.97% (2005)
Irrigated land: 2,700 sq km (2003)
Total renewable water resources: 476.1
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 4 08 cu
km/yr ( 1 %/0%/98%)
per capita: 290 cu m/yr (2000)
Natural hazards: monsoonal rains (June
to November); flooding; occasional
droughts
Environment— current issues: illegal
logging activities throughout the country
and strip mining for gems in the western
region along the border with Thailand
have resulted in habitat loss and
declining biodiversity (in particular,
destruction of mangrove swamps
threatens natural fisheries); soil erosion;
in rural areas, most of the population
does not have access to potable water;
declining fish stocks because of illegal
fishing and overfishing
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Law of the Sea
Geography — note: a land of paddies and
forests dominated by the Mekong River
and Tonle Sap','bc4b59a6e7287ef7b8d89811b3874d7428a014f72ec6029160b1d5e5932fd0f6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11adddaa2c7316222e9b3d73c0bb808c0d3ba004fea16b4967326c52f989035d',2009,'CM','Cameroon','geography',260,'Location: Western Africa, bordering the
Bight of Biafra, between Equatorial
Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00
E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area — comparative: slightly larger than
California
Land boundaries:
total: 4,591 km
border countries: Central African
Republic 797 km, Chad 1,094 km,
Republic of the Congo 523 km,
Equatorial Guinea 189 km, Gabon 298
km, Nigeria 1,690 km
Coastline: 402 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
Climate: varies with terrain, from trop¬
ical along coast to semiarid and hot in
north
Terrain: diverse, with coastal plain in
southwest, dissected plateau in center,
mountains in west, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m (on Mt.
Cameroon)
Natural resources: petroleum, bauxite,
iron ore, timber, hydropower
117
THE CIA WORLD FACTBOOK
Land use:
arable land: 12.54%
permanent crops : 2.52%
other: 84-94% (2005)
Irrigated land: 260 sq km (2003)
Total renewable water resources: 285.5
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.99 cu
km/yr (18%/8%/74%)
per capita: 61 cu m/yr (2000)
Natural hazards: volcanic activity with
periodic releases of poisonous gases from
Lake Nyos and Lake Monoun volcanoes
Environment— current issues: water-
borne diseases are prevalent; deforesta¬
tion; overgrazing; desertification;
poaching; overfishing
Environment— international agree*
mentS: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: sometimes referred to
as the hinge of Africa; throughout the
country there are areas of thermal springs
and indications of current or prior vol¬
canic activity; Mount Cameroon, the
highest mountain in Sub-Saharan west
Africa, is an active volcano
Population: 18,467,692
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor¬
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 41.1% (male
3,826,232/female 3,757,859)
15-64 years: 55.7% (male
5,164,338/female 5,122,817)
65 years and over: 3.2% (male
274,821/female 321,625) (2008 est.)
Median age:
total: 19 years
male: 18.9 years
female: 19.2 years (2008 est.)
Population growth rate: 2.218% (2008
est.)
Birth rate: 34.59 births/1,000 population
(2008 est.)
Death rate: 12.41 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female
(2008 est.)
Infant mortality rate:
total: 64-57 deaths/1,000 live births
male: 69.39 deaths/1,000 live births
female: 59.62 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 53.3 years
male: 52.54 years
female: 54.08 years (2008 est.)
Total fertility rate: 441 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 6.9%
(2003 est.)
HIV/AIDS — people living with
HIV/AIDS: 560,000 (2003 est.)
HIV/AIDS— deaths: 49,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A and E,
and typhoid fever
vectorborne diseases: malaria and yellow
fever
water contact disease: schistosomiasis
respiratory disease: meningococcal
meningitis
animal contact disease: rabies (2008)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders
31%, Equatorial Bantu 19%, Kirdi 11%,
Fulani 10%, Northwestern Bantu 8%,
Eastern Nigritic 7%, other African 13%,
non- African less than 1%
Religions: indigenous beliefs 40%,
Christian 40%, Muslim 20%
Languages: 24 major African language
groups, English (official), French (offi¬
cial)
Literacy:
definition: age 15 and over can read and
write
total population: 67.9%
male: 77%
female: 59.8% (2001 est.)
Geographic coordinates: 10 00 N, 8 00
E
Map references: Africa
Area:
total: 923,768 sq km
land: 910,768 sq km
water: 13,000 sq km
Area — comparative: slightly more than
twice the size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km,
Cameroon 1,690 km, Chad 87 km, Niger
1,497 km
Coastiine: 853 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: varies; equatorial in south,
tropical in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus; mountains in
southeast, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources: natural gas, petro¬
leum, tin, iron ore, coal, limestone, nio¬
bium, lead, zinc, arable land
Land use:
arable land: 33.02%
permanent crops: 3.14%
other: 63.84% (2005)
Irrigated land: 2,820 sq km (2003)
Total renewable water resources: 286.2
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 8.01 cu
km/yr (21%/10%/69%)
per capita: 61 cu m/yr (2000)
Natural hazards: periodic droughts;
flooding
Environment — current issues: soil
degradation; rapid deforestation; urban
air and water pollution; desertification;
oil pollution — water, air, and soil; has
suffered serious damage from oil spills;
loss of arable land; rapid urbanization
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: the Niger enters the
country in the northwest and flows
southward through tropical rain forests
and swamps to its delta in the Gulf of','b58122ce3f9abbc638c790a2f7170d13d7ce14fb175cdc56232c89c3b169b484','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8af8e39f330ea6ee64f8e763b29ac0709fee0c26688f81388a4b408972b1d52d',2009,'CA','Canada','geography',265,'Location: Northern North America, bor¬
dering the North Atlantic Ocean on the
east, North Pacific Ocean on the west,
and the Arctic Ocean on the north,
north of the conterminous US
Geographic coordinates: 60 00 N, 95 00 w
Map references: North America
Area:
total: 9,984,67 0 sq km
land: 9,093,507 sq km
water: 891,163 sq km
120
Areo — comparative: somewhat larger
than the US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes
2,477 km with Alaska)
Coastline: 202,080 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: varies from temperate in south
to subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,959 m
Natural resources: iron ore, nickel, zinc,
copper, gold, lead, molybdenum, potash,
diamonds, silver, fish, timber, wildlife,
coal, petroleum, natural gas, hydropower
Land use:
arable land: 4.57%
permanent crops: 0.65%
other: 94.78% (2005)
Irrigated land: 7,850 sq km (2003)
Total renewable water resources: 3,300
cu km (1985)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 44.72 cu
km/yr (20%/69%/12%)
per capita: 1,386 cu m/yr (1996)
Natural hazards: continuous permafrost
in north is a serious obstacle to develop-
ment; cyclonic storms form east of the
Rocky Mountains, a result of the mixing
of air masses from the Arctic, Pacific,
and North American interior, and pro¬
duce most of the country’s rain and snow
east of the mountains
Environment — current issues: air pollu¬
tion and resulting acid rain severely
affecting lakes and damaging forests;
metal smelting, coal-burning utilities,
and vehicle emissions impacting on agri¬
cultural and forest productivity; ocean
waters becoming contaminated due to
agricultural, industrial, mining, and
forestry activities
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Antarctic-Environmental
Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Air Pollution-
Volatile Organic Compounds, Marine
Life Conservation
Geography— note: second-largest
country in world (after Russia); strategic
location between Russia and US via
north polar route; approximately 90% of
the population is concentrated within
160 km of the US border','c20519c437dfa6757e9fbe30311be206ccf3511262f2496e1dce54d72e060504','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e79bf6b85f7748f485c1eff42e2ebbafc3e18e6223c08c9d6fc2f2c1cf472c9',2009,'CF','Central African Republic','geography',281,'Location: Central Africa, north of
Democratic Republic of the Congo
Geographic coordinates: 7 00 N, 21 00
E
Map references: Africa
Area:
total: 622,984 sq km
land: 622,984 sq km
water: 0 sq km
Area — comparative: slightly smaller
than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km,
Chad 1,197 km, Democratic Republic of
the Congo 1,577 km, Republic of the
Congo 467 km, Sudan 1,165 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; hot, dry winters; mild
to hot, wet summers
Terrain: vast, flat to rolling, monotonous
plateau; scattered hills in northeast and
southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1,420 m
Natural resources: diamonds, uranium,
timber, gold, oil, hydropower
Land use:
arable land: 3.1%
permanent crops: 0.15%
other : 96.75% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 144.4
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.03 cu
km/yr (80%/16%/4%)
per capita: 7 cu m/yr (2000)
Natural hazards: hot, dry, dusty har-
mattan winds affect northern areas;
floods are common
Environment — current issues: tap water
is not potable; poaching has diminished
the country’s reputation as one of the last
great wildlife refuges; desertification;
deforestation
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Tropical Timber 94,
Wetlands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; almost
the precise center of Africa','95344ab8ac12aff279c8d1610418c253db03d87f1450c0c57d260072a0edbd40','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3717a748f665524796815e5a7a8cd209d539f73eee9b464747320837919ecc84',2009,'TD','Chad','geography',291,'Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00
E
Map references: Africa
Area:
total: 1.284 million sq km
land: 1,259,200 sq km
water: 24,800 sq km
Area — comparative: slightly more than
three times the size of California
Land boundaries: total. 5,968 km
border countries: Cameroon 1,094 km,
Central African Republic 1,197 km,
Libya 1,055 km, Niger 1,175 km, Nigeria
87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center,
desert in north, mountains in northwest,
lowlands in south
Elevation extremes:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum, uranium,
natron, kaolin, fish (Lake Chad), gold,
limestone, sand and gravel, salt
131
THE CIA WORLD FACTBOOK
Land use: arable land: 2.8%
permanent crops: 0.02%
other: 97-18% (2005)
Irrigated land: 300 sq km (2003)
Total renewable water resources: 43 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.23 cu
km/yr (17%/0%/83%)
per capita: 24 cu m/yr (2000)
Natural hazards: hot, dry, dusty har-
mattan winds occur in north; periodic
droughts; locust plagues
Environment — current issues: inade-
quate supplies of potable water; improper
waste disposal in rural areas contributes to
soil and water pollution; desertification
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea,
Marine Dumping
Geography— note: landlocked; Lake
Chad is the most significant water body
in the Sahel
Population: 10,111,337 (July 2008 est.)
Age structure:
0-14 years: 47% (male 2,408,638/female
2,346,984)
15-64 years: 50.1% (male
2,317,406/female 2,746,104)
65 years and over: 2.9% (male
123,561/female 168,644) (2008 est.)
Median age:
total: 16.4 years
male: 15.2 years
female: 17.5 years (2008 est.)
Population growth rate: 2.195% (2008 est.)
Birth rate: 41.61 births/1,000 population
(2008 est.)
Death rate: 16.39 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -3.27 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.84 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.92 male(s)/female
(2008 est.)
Infant mortality rate:
total: 100.36 deaths/1,000 live births
male: 106.48 deaths/1,000 live births
female: 94 deaths/ 1,000 live births (2008
est.)
Life expectancy at birth:
total population: 47.43 years
male: 46.4 years
female: 48.5 years (2008 est.)
Total fertility rate: 5 43 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 4.8%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 200,000 (2003 est.)
HIV/AIDS— deaths: 18,000 (2003 est.)
Major Infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A, and
typhoid fever
vectorbome disease: malaria
water contact disease: schistosomiasis
respiratory disease: meningococcal
meningitis (2008)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Sara 27.7%, Arab 12.3%,
Mayo-Kebbi 11.5%, Kanem-Bomou 9%,
Ouaddai 8.7%, Hadjarai 6.7%, Tandjile
6.5%, Gorane 6.3%, Fitri-Batha 4.7%,
other 6.4%, unknown 0.3% (1993
census)
Religions: Muslim 53.1%, Catholic
20.1%, Protestant 14-2%, animist 7.3%,
other 0.5%, unknown 1.7%, atheist
3.1% (1993 census)
Languages: French (official), Arabic
(official), Sara (in south), more than 120
different languages and dialects
Literacy: definition: age 15 and over can
read and write French or Arabic
total population: 47.5%
male: 56%
female: 39.3% (2003 est.)','964193ae05fc9e8a353c51d56819b181a366712acdc21728e794e4f28085066b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67bdb47d6b3aaf135a327dcecff1d43291f06251f6afb51a21de38b8debc6826',2009,'CL','Chile','geography',295,'Location: Southern South America, bor¬
dering the South Pacific Ocean, between
Argentina and Peru
Geographic coordinates: 30 00 S, 71 00
w
Map references: South America
Area:
total: 756,950 sq km
land: 748,800 sq km
water: 8,150 sq km
note: includes Easter Island (Isla de
Pascua) and Isla Sala y Gomez
Area — comparative: slightly smaller
than twice the size of Montana
Land boundaries:
total: 6,339 km
border countries: Argentina 5,308 km,
Bolivia 860 km, Peru 171 km
Coastline: 6,435 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200/350 nm
Climate: temperate; desert in north;
Mediterranean in central region; cool
and damp in south
Terrain: low coastal mountains; fertile
central valley; rugged Andes in east
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Ojos del Salado
6,880 m
Natural resources: copper, timber, iron
ore, nitrates, precious metals, molyb¬
denum, hydropower
Land use:
arable land: 2.62%
permanent crops: 0.43%
other: 96.95% (2005)
Irrigated land: 19,000 sq km (2003)
Total renewable water resources: 922
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 12.55 cu
km/yr ( 1 1%/25%/64%)
per capita: 770 cu m/yr (2000)
134
Natural hazards: severe earthquakes;
active volcanism; tsunamis
Environment — current issues: wide-
spread deforestation and mining
threaten natural resources; air pollution
from industrial and vehicle emissions;
water pollution from raw sewage
Environment— international agree¬
ments: party to: Antarctic-Environ-
mental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
GOOgraphy — note: strategic location rel¬
ative to sea lanes between Atlantic and
Pacific Oceans (Strait of Magellan,
Beagle Channel, Drake Passage);
Atacama Desert is one of world’s driest
regions','f48e599b118b0cd31ae0261bda8ca804ddeb4a78c0769fcdcc1578e034967230','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531ac39e2d658f964c530cef474f772612f27900ecd75c175234b860428cef63',2009,'CX','Christmas Island','geography',321,'Location: Middle America, atoll in the
North Pacific Ocean, 1,120 km south¬
west of Mexico
Geographic coordinates: 10 17 N, 109
13 W
Map references: Political Map of the
World
Area:
total: 6 sq km
land: 6 sq km
water: 0 sq km
Area— comparative: about 12 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; humid, average tem¬
perature 20-32 degrees C, wet season
(May to October)
Terrain: coral atoll
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (all coral) (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Geography— note: reef 12 km in circum¬
ference','d8a842b00dd0442fc2d0a9c52c0c9415ec072d70971e6efa6547f9292d12b9e6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bdee6a8707ed6701170a7b9504308b0f2fe0c0a991cbdad6110890687d7db21',2009,'CC','Cocos (Keeling) Islands','geography',325,'Location: Southeastern Asia, group of
islands in the Indian Ocean, southwest
of Indonesia, about halfway from
Australia to Sri Lanka
Geographic coordinates: 12 30 S, 96 50
E
Map references: Southeast Asia
Area:
total: 14 sq km
land: 14 sq km
water: 0 sq km
144
note: includes the two main islands of
West Island and Home Island
Area — comparative: about 24 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 26 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical with high humidity,
moderated by the southeast trade winds
for about nine months of the year
Terrain: flat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: cyclone season is
October to April
Environment — current issues: fresh
water resources are limited to rainwater
accumulations in natural underground
reservoirs
Geography — note: islands are thickly
covered with coconut palms and other
vegetation','c2a1a44c16e58bfd578729ae297bdf54ce76518ada4a066ea91dcb9e2f113f3e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('577e962901a1e4ae7fb5f52b29b6eae507b712f9d663b9f7f35ac957fc7d2ca7',2009,'YT','Mayotte','geography',339,'Location: Southern Africa, group of
islands at the northern mouth of the
Mozambique Channel, about two-thirds
of the way between northern Madagascar
and northern Mozambique
Geographic coordinates: 12 10 S, 44 15
E
Map references: Africa
Area:
total: 2,170 sq km
land: 2,170 sq km
water: 0 sq km
Area — comparative: slightly more than
12 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; rainy season
(November to May)
Terrain: volcanic islands, interiors vary
from steep mountains to low hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Le Kartala 2,360 m
Natural resources: NEGL
Land use:
arable land: 35.87%
permanent crops: 23.32%
other: 40.81% (2005)
Irrigated land: NA
Total renewable water resources: 1.2
cu km ( 2003 )
Freshwater withdrawal (domestic/
industrial/agricultural): total 0.01 cu
km/yr (48%/5%/47%)
per capita: 13 cu m/yr (1999)
Natural hazards: cyclones possible
during rainy season (December to April);
Le Kartala on Grand Comore is an active
volcano
Environment — current issues: soil
degradation and erosion results from crop
cultivation on slopes without proper ter¬
racing; deforestation
Environment — international agree¬
ments: party to: Biodiversity, Climate
149
THE CIA WORLD FACTBOOK
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: important location at
northern end of Mozambique Channel
Population: 731,775 (July 2008 est.)
Age structure:
0-14 years: 42.4% (male 155,662/female
154,520)
15-64 years: 54.6% (male
197,178/female 202,231)
65 years and over: 3% (male
10,203/female 11,981) (2008 est.)
Median age:
total: 18.7 years
male: 18.5 years
female: 19 years (2008 est.)
Population growth rate: 2.803% (2008
est.)
Birth rate: 35.78 births/1,000 population
(2008 est.)
Death rate: 7.76 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.98 male(s)/female
(2008 est.)
infant mortality rate:
total: 68.58 deaths/1,000 live births
male: 76.65 deaths/1,000 live births
female: 60.28 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 63.1 years
male: 60. 72 years
female: 65.55 years (2008 est.)
Total fertility rate: 4.9 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate:
0.12% (2001 est.)
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religions: Sunni Muslim 98%, Roman
Catholic 2%
Languages: Arabic (official), Lrench
(official), Shikomoro (a blend of Swahili
and Arabic)
Literacy: definition: age 15 and over can
read and write
total population: 56.5%
male: 63.6%
female: 49.3% (2003 est.)','6295a2e3291f837a2e3426388f2037c3793a1a1b6f2921001c66cd085f1bbdea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c268210c0b59c44fa279fe3cebfad5be9361497b755b15e6fd8d6e9328ea455',2009,'CK','Cook Islands','geography',355,'Location: Oceania, islands in the Coral
Sea, northeast of Australia
Geographic coordinates: 18 00 S, 152
00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands
and reefs scattered over a sea area of
about 780,000 sq km, with the Willis
Islets the most important
Area — comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical
Terrain: sand and coral reefs and islands
(or cays)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato
Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (mostly grass or scrub cover)
(2005)
Irrigated land: 0 sq km
Natural hazards: occasional tropical
cyclones
Environment — current issues: no per¬
manent fresh water resources
160','a5705362d2bdba061aa34bc025785714f50af859d7a2da78928645bb1254ab1e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e78eb24c3b7a968ae7e3c6bcef34cd7e69dc38060d7b1809ce2e3a5d3f2c6058',2009,'CR','Costa Rica','geography',356,'Geography — note: important nesting
area for birds and turtles
Location: Central America, bordering
both the Caribbean Sea and the North
Pacific Ocean, between Nicaragua and
Location: Western Africa, bordering the
North Atlantic Ocean, between Ghana
and Liberia
Geographic coordinates: 8 00 N, 5 00
w
Map references: Africa
Area:
total: 322,460 sq km
land: 318,000 sq km
water: 4,460 sq km
Area — comparative: slightly larger than
New Mexico
Land boundaries:
total: 3,110 km
border countries: Burkina Faso 584 km,
Ghana 668 km, Guinea 610 km, Liberia
716 km, Mali 532 km
Coastline: 515 km
164
COTE D’IVOIRE
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical along coast, semiarid
in far north; three seasons — warm and
dry (November to March), hot and dry
(March to May), hot and wet (June to
October)
Terrain: mostly flat to undulating plains;
mountains in northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1,752 m
Natural resources: petroleum, natural
gas, diamonds, manganese, iron ore,
cobalt, bauxite, copper, gold, nickel, tan¬
talum, silica sand, clay, cocoa beans,
coffee, palm oil, hydropower
Land use: arable land: 10.23%
permanent crops : 11.16%
other: 78.61% (2005)
Irrigated land: 730 sq km (2003)
Total renewable water resources: 81 cu
km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.93 cu
km/yr (24%/12%/65%)
per capita: 51 cu m/yr (2000)
Natural hazards: coast has heavy surf
and no natural harbors; during the rainy
season torrential flooding is possible
Environment — current issues: defor¬
estation (most of the country’s forests —
once the largest in West Africa — have
been heavily logged); water pollution
from sewage and industrial and agricul¬
tural effluents
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: most of the inhabi¬
tants live along the sandy coastal region;
apart from the capital area, the forested
interior is sparsely populated','8bb3dffbbddba684e524fde1cc5a506b6019027f6d1b31bc977b12b29faba8ff','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36af8ef3e0c11e6756318ca6588dfab3ba26b0c263e991299f91c6fa7848e50',2009,'PA','Panama','geography',363,'Geographic coordinates: 10 00 N, 84 00
w
Map references: Central America and
the Caribbean
Area:
total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area — comparative: slightly smaller
than West Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km,
Panama 330 km
Coastline: 1,290 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical and subtropical; dry
season (December to April); rainy season
(May to November); cooler in highlands
Terrain: coastal plains separated by
rugged mountains including over 100
volcanic cones, of which several are
major volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use: arable land: 4.4%
permanent crops: 5.87%
other: 89.73% (2005)
Irrigated land: 1,080 sqkm (2003)
Total renewable water resources: 112.4
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.68 cu
km/yr (29%/17%/53%)
per capita: 619 cu m/yr (2000)
Natural hazards: occasional earthquakes,
hurricanes along Atlantic coast; frequent
flooding of lowlands at onset of rainy
season and landslides; active volcanoes
Environment— current issues: deforesta¬
tion and land use change, largely a result
of the clearing of land for cattle ranching
and agriculture; soil erosion; coastal
marine pollution; fisheries protection;
solid waste management; air pollution
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Wetlands, Whaling
signed, but not ratified: Marine Life
Conservation
Geography — note: four volcanoes, two
of them active, rise near the capital of
San Jose in the center of the country;
one of the volcanoes, Irazu, erupted
destructively in 1963-65','1b083eb5df048d36affb9234c0431542ecdd5ea9e7bae3dddbd134c11783abe0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1608d4fc7bb547414d59429a96a0c96b9fc95d03d585a3eb1e40e8906947068',2009,'HR','Croatia','geography',372,'Location: Southeastern Europe, bor¬
dering the Adriatic Sea, between Bosnia
and Herzegovina and Slovenia
Geographic coordinates: 45 10 N, 15 30
E
Map references: Europe
Area:
total: 56,542 sq km
land: 56,414 sq km
water: 128 sq km
Area— comparative: slightly smaller
than West Virginia
Land boundaries:
total: 2,197 km
border countries: Bosnia and Herzegovina
932 km, Hungary 329 km, Serbia 241
km, Montenegro 25 km, Slovenia 670
km
Coastline: 5,835 km (mainland 1,777
km, islands 4,058 km)
Maritime claims:
territorial sea: 1 2 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: Mediterranean and conti¬
nental; continental climate predominant
with hot summers and cold winters; mild
winters, dry summers along coast
Terrain: geographically diverse; flat
plains along Hungarian border, low
mountains and highlands near Adriatic
coastline and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1,830 m
Natural resources: oil, some coal,
bauxite, low-grade iron ore, calcium,
gypsum, natural asphalt, silica, mica,
clays, salt, hydropower
Land use:
arable land: 25.82%
permanent crops : 2.19%
other: 71.99% (2005)
Irrigated land: 1 10 sq km (2003)
Total renewable water resources: 105.5
cu km (1998)
Natural hazards: destructive earth¬
quakes
Environment — current issues: air pollu¬
tion (from metallurgical plants) and
resulting acid rain is damaging the
forests; coastal pollution from industrial
and domestic waste; landmine removal
and reconstruction of infrastructure con¬
sequent to 1992-95 civil strife
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Sulfur 94, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography — note: controls most land
routes from Western Europe to Aegean
Sea and Turkish Straits; most Adriatic
Sea islands lie off the coast of Croatia —
some 1,200 islands, islets, ridges, and
rocks','7521e9144632ade18c3018deb3c2e628dc63a0d18b14de7ddcd7bb5fa56f0291','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('571b4bede3490c889d9f92152434499099cb19f4ef485c67d5662a6fc62a7e96',2009,'BS','Bahamas','geography',378,'Location: Caribbean, island between the
Caribbean Sea and the North Atlantic
Ocean, 150 km south of Key West,
Florida
Geographic coordinates: 21 30 N, 80 00
w
Map references: Central America and
the Caribbean
Area:
total: 1 10,860 sq km
land: 1 10,860 sq km
water: 0 sq km
Area — comparative: slightly smaller
than Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at
Guantanamo Bay 29 km
note: Guantanamo Naval Base is leased
by the US and remains part of Cuba
Coastline: 3,735 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade
winds; dry season (November to April);
rainy season (May to October)
Terrain: mostly flat to rolling plains, with
rugged hills and mountains in the south¬
east
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron
ore, chromium, copper, salt, timber,
silica, petroleum, arable land
Land use:
arable land: 27.63%
permanent crops: 6.54%
other: 65.83% (2005)
Irrigated land: 8,700 sq km (2003)
Total renewable water resources: 38.1
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 8.2 cu
km/yr ( 1 9%/l 2%/69% )
per capita: 728 cu m/yr (2000)
Natural hazards: the east coast is subject
to hurricanes from August to November
(in general, the country averages about
one hurricane every other year);
droughts are common
Environment — current issues: air and
water pollution; biodiversity loss; defor¬
estation
Environment — international agree¬
ments: party to: Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life
Conservation
Geography — note: largest country in
Caribbean and westernmost island of the
Greater Antilles
Population: 11,423,952 (July 2008 est.)
171
THE CIA WORLD FACTBOOK
Age structure:
0-14 years: 18.5% (male
1,088,311/female 1,030,499)
15-64 years: 70.5% (male
4,029,381/female 4,025,154)
65 years and over: 10.9% (male
569,002/female 681,605) (2008 est.)
Median age:
total: 36.8 years
male: 36.1 years
female: 37.5 years (2008 est.)
Population growth rate: 0.251% (2008
est.)
Birth rate: 11.27 births/ 1,000 population
(2008 est.)
Death rate: 7.19 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -1.57 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.99 male(s)/female
(2008 est.)
Infant mortality rate:
total: 5.93 deaths/1,000 live births
male: 6.64 deaths/1,000 live births
female: 5.17 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 77.27 years
male: 75.02 years
female: 79.64 years (2008 est.)
Total fertility rate: 1.6 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS — people living with
HIV/AIDS: 3,300 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea and hepatitis A
vectorbome diseases: dengue fever (2008)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51%, white 37%,
black 11%, Chinese 1%
Religions: nominally 85% Roman
Catholic prior to CASTRO assuming
power; Protestants, Jehovah’s Witnesses,
Jews, and Santeria are also represented
Languages: Spanish
Literacy: definition: age 15 and over can
read and write
total population: 99.8%
male: 99.8%
female: 99.8% (2002 census)
People — note: illicit emigration is a
continuing problem; Cubans attempt to
depart the island and enter the US using
homemade rafts, alien smugglers, direct
flights, or falsified visas; Cubans also use
non-maritime routes to enter the US
including direct flights to Miami and
over-land via the southwest border
Country name:
conventional long form: Republic of Cuba
conventional short form: Cuba
local long form: Republica de Cuba
local short form: Cuba
Government type: Communist state
Capital: name: Havana
geographic coordinates: 23 07 N, 82 21 W
time difference: UTC-5 (same time as
Washington, DC during Standard Time)
daylight saving time: +lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: 14 provinces
(provincias, singular — provincia) and 1
special municipality* (municipio espe¬
cial); Camaguey, Ciego de Avila,
Cienfuegos, Ciudad de La Habana,
Granma, Guantanamo, Holguin, Isla de
la Juventud*, La Habana, Las Tunas,
Matanzas, Pinar del Rio, Sancti Spiritus,
Santiago de Cuba, Villa Clara
Independence: 20 May 1902 (from
Spain 10 December 1898; administered
by the US from 1898 to 1902); not
acknowledged by the Cuban
Government as a day of independence
National holiday: Triumph of the
Revolution, 1 January (1959)
Constitution: 24 February 1976;
amended July 1992 and June 2002
Legal system: based on Spanish civil
law and influenced by American legal
concepts, with large elements of
Communist legal theory; has not
accepted compulsory ICJ jurisdiction
Suffrage: 16 years of age; universal
Executive branch:
chief of state: President of the Council of
State and President of the Council of
Ministers Gen. Raul CASTRO Ruz
(president since 24 February 2008); First
Vice President of the Council of State
and First Vice President of the Council
of Ministers Gen. Jose Ramon
MACHADO Ventura (since 24 February
2008); note — the president is both the
chief of state and head of government
head of government: President of the
Council of State and President of the
Council of Ministers Gen. Raul
CASTRO Ruz (president since 24
February 2008); First Vice President of
the Council of State and First Vice
President of the Council of Ministers
Gen. Jose Ramon MACHADO Ventura
(since 24 February 2008)
cabinet: Council of Ministers proposed by
the president of the Council of State and
appointed by the National Assembly or
the 31 -member Council of State, elected
by the Assembly to act on its behalf
when it is not in session
elections: president and vice presidents
elected by the National Assembly for a
term of five years; election last held 24
February 2008 (next to be held in 2013)
election results: Gen. Raul CASTRO Ruz
elected president; percent of legislative
vote — 100%; Gen. Jose Ramon
MACHADO Ventura elected vice presi¬
dent; percent of legislative vote — 100%
Legislative branch: unicameral
National Assembly of People’s Power or
Asemblea Nacional del Poder Popular
(number of seats in the National
Assembly is based on population; 614
seats; members elected directly from
slates approved by special candidacy
commissions to serve five-year terms)
elections: last held 20 January 2008 (next
to be held in January 2013)
election results: Cuba’s Communist Party
is the only legal party, and officially sanc¬
tioned candidates run unopposed
Judicial branch: People’s Supreme
Court or Tribunal Supremo Popular
(president, vice president, and other
judges are elected by the National
Assembly)
Political parties and leaders: Cuban
Communist Party or PCC [Fidel
CASTRO Ruz, first secretary]
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACP, FAO, G-77, IAEA, ICAO,
ICC, ICRM, IFAD, IFRCS, IHO, ILO,
IMO, IMSO, Interpol, IOC, IOM
(observer), IPU, ISO, ITSO, ITU,
LAES, LAIA, NAM, OAS (excluded
from formal participation since 1962),
OPANAL, OPCW, PCA, UN,
UNCTAD, UNESCO, UNIDO, Union
Latina, UNWTO, UPU, WCL, WCO,
WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
none; note — Cuba has an Interests
Section in the Swiss Embassy, headed by
Principal Officer Jorge BOLANOS
Suarez; address: Cuban Interests Section,
Swiss Embassy, 2630 16th Street NW,
Washington, DC 20009; telephone: [1]
(202) 797-8518; FAX: [1] (202) 797-
8521
Diplomatic representation from the US:
none; note — the US has an Interests
Section in the Swiss Embassy, headed by
Principal Officer Michael E. PARMLY;
address: USINT, Swiss Embassy, Calzada
between L and M Streets, Vedado,
Havana; telephone: [53] (7) 833-3551
172','1b1e45d871bada5e6e06a9e11f018887e50613b420f4dbf88c3f9f749bccae32','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('608b85e3c6cce7e5bf0ad5a4b8d4342848b4f68e631b2799c722c8c731a9f92f',2009,'CU','Cuba','geography',379,'through 3559 (operator assistance
required); FAX: [53] (7) 833-3700; pro¬
tecting power in Cuba is Switzerland
Flag description: five equal horizontal
bands of blue (top, center, and bottom)
alternating with white; a red equilateral
triangle based on the hoist side bears a
white, five-pointed star in the center','1352873bb55fb2be5a3dd38688afdc077e944ffc63b4bbab6f2debcc0474adae','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('652fec8196f12fe70c23856a286177def303178de4e6af31c7ae4221453ee7d6',2009,'CY','Cyprus','geography',384,'Location: Middle East, island in the
Mediterranean Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00
E
Map references: Middle East
Area:
total: 9,250 sq km (of which 3,355 sq km
are in north Cyprus)
land: 9,240 sq km
water: 10 sq km
Area — comparative: about 0.6 times the
size of Connecticut
Land boundaries:
total : 150.4 km (approximately)
border sovereign base areas: Akrotiri 47.4
km, Dhekelia 103 km (approximately)
Coastline: 648 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: temperate; Mediterranean with
hot, dry summers and cool winters
Terrain: central plain with mountains to
north and south; scattered but significant
plains along southern coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 1,951 m
Natural resources: copper, pyrites,
asbestos, gypsum, timber, salt, marble,
clay earth pigment
Land use:
arable land: 10.81%
permanent crops: 4-32%
other: 84.87% (2005)
Irrigated land: 400 sq km (2003)
Total renewable water resources: 0.4
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.21 cu
km/yr (27%/l%/71%)
per capita: 250 cu m/yr (2000)
Natural hazards: moderate earthquake
activity; droughts
Environment— current issues: water
resource problems (no natural reservoir
catchments, seasonal disparity in rain¬
fall, sea water intrusion to island’s largest
aquifer, increased salination in the
north); water pollution from sewage and
industrial wastes; coastal degradation;
loss of wildlife habitats from urbanization
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 94, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: the third largest
island in the Mediterranean Sea (after
Sicily and Sardinia)
Location: Central Europe, southeast of','7d531efb0d5f08360ee799911e0049c35dfefa7f5a4cba36f9353e2ab1696406','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a1422e7f88d26de6696728aa7f415da7def8489eb8cb054f81d64bd50f5b18',2009,'DE','Germany','geography',391,'Geographic coordinates: 49 45 N, 15 30
E
Map references: Europe
Area:
total: 78,866 sq km
land: 71,276 sq km
water: 1,590 sq km
Area — comparative: slightly smaller
than South Carolina
Land boundaries:
total: 2,290.2 km
border countries: Austria 466.3 km,
Germany 810.3 km, Poland 761.8 km,
Slovakia 251.8 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: Bohemia in the west consists of
rolling plains, hills, and plateaus sur¬
rounded by low mountains; Moravia in
the east consists of very hilly country
Elevation extremes:
lowest point: Elbe River 115 m
highest point: Snezka 1,602 m
Natural resources: hard coal, soft coal,
kaolin, clay, graphite, timber
Land use:
arable land: 38.82%
permanent crops: 3%
other: 58.18% (2005)
Irrigated land: 240 sq km (2003)
Total renewable water resources: 16 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.91 cu
km/yr (41%/57%/2%)
per capita: 187 cu m/yr (2002)
Natural hazards: flooding
Environment — current issues: air and
water pollution in areas of northwest
Bohemia and in northern Moravia
around Ostrava present health risks; acid
rain damaging forests; efforts to bring
industry up to EU code should improve
domestic pollution
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-
Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; strategi¬
cally located astride some of oldest and
most significant land routes in Europe;
Moravian Gate is a traditional military
corridor between the North European
Plain and the Danube in central Europe
Location: Northern Europe, bordering
the Baltic Sea and the North Sea, on a
peninsula north of Germany (Jutland);
also includes two major islands
(Sjaelland and Fyn)
Geographic coordinates: 56 00 N, 10 oo E
Map references: Europe
Area:
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in
the Baltic Sea and the rest of metropol¬
itan Denmark (the Jutland Peninsula,
and the major islands of Sjaelland and
Fyn), but excludes the Faroe Islands and
Land use:
arable land: 33.13%
permanent crops: 0.6%
other: 66.27% (2005)
Irrigated land: 4,850 sq km (2003)
Total renewable water resources: 188
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 38.01 cu
km/yr (12%/68%/20%)
per capita: 460 cu m/yr (2001)
Natural hazards: flooding
Environment— current issues: emis¬
sions from coal-burning utilities and
industries contribute to air pollution;
acid rain, resulting from sulfur dioxide
emissions, is damaging forests; pollution
in the Baltic Sea from raw sewage and
industrial effluents from rivers in eastern
Germany; hazardous waste disposal; gov¬
ernment established a mechanism for
ending the use of nuclear power over the
next 15 years; government working to
meet EU commitment to identify nature
preservation areas in line with the EU’s
Flora, Fauna, and Habitat directive
Environment— International agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution- Volatile
Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location on
North European Plain and along the
entrance to the Baltic Sea
Geographic coordinates: 52 00 N, 20 00
E
Map references: Europe
Area: total: 312,685 sq km
land: 304,465 sq km
water: 8,220 sq km
Area — comparative: slightly smaller
than New Mexico
Land boundaries:
total: 3,056 km
border countries: Belarus 416 km, Czech
Republic 790 km, Germany 467 km,
Lithuania 103 km, Russia (Kaliningrad
Oblast) 210 km, Slovakia 541 km,
Ukraine 529 km
Coastline: 491 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: defined by inter¬
national treaties
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation; mild summers with fre¬
quent showers and thundershowers
Terrain: mostly flat plain; mountains
along southern border
Elevation extremes:
lowest point: near Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper,
natural gas, silver, lead, salt, amber,
arable land
Land use:
arable land: 40.25%
permanent crops: 1%
other: 58.75% (2005)
Irrigated land: 1,000 sq km (2003)
Total renewable water resources: 63.1
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total. 11.73 cu
km/yr (13%/79%/8%)
per capita: 304 cu m/yr (2002)
Natural hazards: flooding
Environment — current issues: situation
has improved since 1989 due to decline
in heavy industry and increased environ¬
mental concern by post-Communist gov¬
ernments; air pollution nonetheless
remains serious because of sulfur dioxide
emissions from coal-fired power plants,
and the resulting acid rain has caused
forest damage; water pollution from
industrial and municipal sources is also a
problem, as is disposal of hazardous
wastes; pollution levels should continue
to decrease as industrial establishments
bring their facilities up to EU code, but
at substantial cost to business and the','2ef0ea82591cbec95674449b1a65e9a5b773ee271ded230f1f94660fa5167eff','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b70f0aa99704309da7ad5a37a2bc6433f9cf09c78503c971ae9661e100d251f',2009,'GL','Greenland','geography',398,'Area — comparative: slightly less than
twice the size of Massachusetts
Land boundaries:
total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: temperate; humid and overcast;
mild, windy winters and cool summers
Terrain: low and flat to gently rolling
plains
Elevation extremes:
lowest point: Lammefjord -7 m
highest point: Yding Skovhoej 173 m
Natural resources: petroleum, natural
gas, fish, salt, limestone, chalk, stone,
gravel and sand
Land use:
arable land: 52.59%
permanent crops: 0.19%
other: 47.22% (2005)
irrigated land: 4,490 sq km (2003)
Total renewable water resources: 6.1
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.67 cu
km/yr (32%/26%/42%)
per capita: 123 cu m/yr (2002)
Natural hazards: flooding is a threat in
some areas of the country (e.g., parts of
Jutland, along the southern coast of the
island of Lolland) that are protected
from the sea by a system of dikes
Environment — current issues: air pollu¬
tion, principally from vehicle and power
plant emissions; nitrogen and phos¬
phorus pollution of the North Sea;
drinking and surface water becoming
polluted from animal wastes and pesti¬
cides
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: controls Danish
Straits (Skagerrak and Kattegat) linking
Baltic and North Seas; about one-quarter
of the population lives in greater
Copenhagen
Location: Eastern Mediterranean, on the
southeast coast of Cyprus near Famagusta
Geographic coordinates: 34 59 N, 33 45
E
Map references: Middle East
Area: total: 130.8 sq km
note: area surrounds three Cypriot
enclaves
Area— comparative: about three-quar¬
ters the size of Washington, DC
Land boundaries:
total: 103 km (approximately)
border countries: Cyprus 103 km (approx¬
imately)
Coastline: 27.5 km
Climate: temperate; Mediterranean with
hot, dry summers and cool winters
Environment — current issues: netting
and trapping of small migrant songbirds
in the spring and autumn
Geography — note: British extraterrito¬
rial rights also extended to several small
off-post sites scattered across Cyprus; of
the Sovereign Base Area land 60% is pri¬
vately owned and farmed, 20% is owned
by the Ministry of Defense, and 20% is
SB A Crown land
Location: Eastern Africa, bordering the
Gulf of Aden and the Red Sea, between
Eritrea and Somalia
Geographic coordinates: 1 1 30 N, 43 00 E
Map references: Africa
Area:
total: 23,000 sq km
land: 22,980 sq km
water: 20 sq km
Area— comparative: slightly smaller
than Massachusetts
Land boundaries:
total: 516 km
border countries: Eritrea 109 km, Ethiopia
349 km, Somalia 58 km
Coastline: 314 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau sepa¬
rated by central mountains
Elevation extremes:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas,
gold, clay, granite, limestone, marble,
salt, diatomite, gypsum, pumice, petro¬
leum
Land use:
arable land: 0.04%
permanent crops : 0%
other: 99.96% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 0.3
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.02 cu
km/yr (84%/0%/16%)
per capita: 25 cu m/yr (2000)
Natural hazards: earthquakes; droughts;
occasional cyclonic disturbances from
the Indian Ocean bring heavy rains and
flash floods
Environment— current issues: inade¬
quate supplies of potable water; limited
arable land; desertification; endangered
species
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location
near world’s busiest shipping lanes and
close to Arabian oilfields; terminus of
rail traffic into Ethiopia; mostly waste¬
land; Lac Assal (Lake Assal) is the
lowest point in Africa
Geographic coordinates: 72 00 N, 40 00
w
Map references: Arctic Region
Area:
total: 2,166,086 sq km
land: 2,166,086 sq km (410,449 sq km
ice-free, 1,755,637 sq km ice-covered)
(2000 est.)
Area — comparative: slightly more than
three times the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm or agreed
boundaries or median line
continental shelf: 200 nm or agreed
boundaries or median line
Climate: arctic to subarctic; cool sum¬
mers, cold winters
Terrain: flat to gradually sloping icecap
covers all but a narrow, mountainous,
barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjom 3,700 m
Natural resources: coal, iron ore, lead,
zinc, molybdenum, diamonds, gold, plat¬
inum, niobium, tantalite, uranium, fish,
seals, whales, hydropower, possible oil
and gas
Land use:
arable land: 0%
permanent crops : 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: continuous permafrost
over northern two-thirds of the island
Environment — current issues: protec¬
tion of the arctic environment; preserva¬
tion of the Inuit traditional way of life,
including whaling and seal hunting
Geography — note: dominates North
Atlantic Ocean between North America
and Europe; sparse population confined to
small settlements along coast; close to one-
quarter of the population lives in the cap¬
ital, Nuuk; world’s second largest ice cap','183ab86b2cb8c062051df8e8a1b76e8271c676858204963da766774af8c5ee95','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('068bb14bbb952c0374ec890cee978e1fb5bd41049250e397cfd648ad783da8e2',2009,'DM','Dominica','geography',416,'Location: Caribbean, island between the
Caribbean Sea and the North Atlantic
Ocean, about half way between Puerto
Rico and Trinidad and Tobago
189
THE CIA WORLD FACTBOOK
Geographic coordinates: 15 25 N, 61 20
W
Map references: Central America and
the Caribbean
Area:
total: 754 sq km
land: 754 sq km
water: 0 sq km
Area — comparative: slightly more than
four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by north-
east trade winds; heavy rainfall
Terrain: rugged mountains of volcanic
origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber, hydropower,
arable land
Land use:
arable land: 6.67%
permanen t crops : 21.33%
other: 72% (2005)
Irrigated land: NA
Total renewable water resources: NA
Freshwater withdrawal (domestic/
industrial/agricultural): total. 0.02 cu
km/yr
per capita: 213 cu m/yr (1996)
Natural hazards: flash floods are a con¬
stant threat; destructive hurricanes can
be expected during the late summer
months
Environment — current issues: NA
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: known as “The
Nature Island of the Caribbean” due to
its spectacular, lush, and varied flora and
fauna, which are protected by an exten¬
sive natural park system; the most moun¬
tainous of the Lesser Antilles, its
volcanic peaks are cones of lava craters
and include Boiling Lake, the second-
largest, thermally active lake in the
world','c5260a417d2346d6855c90aec110b6b54eb7220e592ce0daac3b07a989cd2738','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cad849fc14bb0d305f9de193f35469a4fc89aa4388222266c665df90c4917d6',2009,'DO','Dominican Republic','geography',420,'Location: Caribbean, eastern two-thirds
of the island of Hispaniola, between the
Caribbean Sea and the North Atlantic
Ocean, east of Haiti
Geographic coordinates: 19 00 N, 70 40
w
Map references: Central America and
the Caribbean
Area:
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
Area — comparative: slightly more than
twice the size of New Hampshire
Land boundaries:
total: 360 km
border countries: Haiti 360 km
Coastline: 1,288 km
Maritime Claims: measured from
claimed archipelagic straight baselines
territorial sea: 6 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical maritime; little sea¬
sonal temperature variation; seasonal
variation in rainfall
Terrain: rugged highlands and mountains
with fertile valleys interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold,
silver
Land use:
arable land: 22.49%
permanent crops: 10.26%
other: 67.25% (2005)
Irrigated land: 2,750 sq km (2003)
Total renewable water resources: 21 cu
km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.39 cu
km/yr (32%/2%/66%)
per capita: 381 cu m/yr (2000)
Natural hazards: lies in the middle of
the hurricane belt and subject to severe
storms from June to October; occasional
flooding; periodic droughts
Environment — current issues: water
shortages; soil eroding into the sea dam¬
ages coral reefs; deforestation
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Law of the Sea
Geography — note: shares island of
Hispaniola with Haiti
192
Location: Western South America, bor¬
dering the Pacific Ocean at the Equator,
between Colombia and Peru
Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area— comparative: slightly smaller
than Nevada
Land boundaries:
total: 2,010 km
border countries: Colombia 590 km, Peru
1,420 km
Coastline: 2,237 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 100 nm from 2,500-m
isobath
Climate: tropical along coast, becoming
cooler inland at higher elevations; trop¬
ical in Amazonian jungle lowlands
Terrain: coastal plain (costa), inter-
Andean central highlands (sierra), and
flat to rolling eastern jungle (oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources: petroleum, fish,
timber, hydropower
Land use:
arable land: 5.71%
permanent crops: 4.81%
other: 89.48% (2005)
Irrigated land: 8,650 sq km (2003)
Total renewable water resources: 432
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 16.98 cu
km/yr (12%/5%/82%)
per capita: 1,283 cu m/yr (2000)
Natural hazards: frequent earthquakes,
landslides, volcanic activity; floods; peri¬
odic droughts
Environment— current issues: defor¬
estation; soil erosion; desertification;
water pollution; pollution from oil pro¬
duction wastes in ecologically sensitive
areas of the Amazon Basin and
Galapagos Islands
Environment — international agree¬
ments: party to: Antarctic-
Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: Cotopaxi in Andes is
highest active volcano in world
Population: 13,927,650 (July 2008 est.)
Age structure:
0-14 years: 32.1% (male
2,274,986/female 2,189,437)
15-64 years: 62.7% (male
4,355,909/female 4,381,141)
65 years and over: 5.2% (male
340,861/female 385,316) (2008 est.)
Median age:
total: 24-2 years
male: 23.7 years
female: 24.7 years (2008 est.)
Population growth rate: 0.935% (2008
est.)
Birth rate: 21.54 births/1,000 population
(2008 est.)
Death rate: 4.21 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -7.98 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 21.35 deaths/1,000 live births
male: 25.61 deaths/1,000 live births
female: 16.88 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 76.81 years
male: 73.94 years
female: 79.84 years (2008 est.)
Total fertility rate: 2.59 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.3%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 21,000 (2003 est.)
HIV/AIDS— deaths: 1,700 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever,
malaria, and yellow fever
water contact disease: leptospirosis (2008)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed
Amerindian and white) 65%,
Amerindian 25%, Spanish and others
7%, black 3%
Religions: Roman Catholic 95%, other
5%
Languages: Spanish (official),
Amerindian languages (especially
Quechua)
Literacy:
definition: age 15 and over can read and
write
total population: 91%
male: 92.3%
female: 89.7% (2001 census)','c59f706425a3e0d90157f6944fb446b0b32b61046d33bb555ae3ef2548bedd91','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24184898906015dc2430f2d4e8beffeddc37fbb786493a07a214084d0cd23369',2009,'EG','Egypt','geography',433,'Location: Northern Africa, bordering
the Mediterranean Sea, between Libya
and the Gaza Strip, and the Red Sea
north of Sudan, and includes the Asian
Sinai Peninsula
Geographic coordinates: 27 00 N, 30 00
E
Map references: Africa
Area:
total: 1,001,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area — comparative: slightly more than
three times the size of New Mexico
Land boundaries:
total: 2,665 km
border countries: Gaza Strip 11 km, Israel
266 km, Libya 1,115 km, Sudan 1,273
km
Coastline: 2,450 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone : 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: desert; hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted
by Nile valley and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural
gas, iron ore, phosphates, manganese,
limestone, gypsum, talc, asbestos, lead,
zinc
Land use:
arable land: 2.92%
permanent crops: 0.5%
other: 96.58% (2005)
Irrigated land: 34,220 sq km (2003)
Total renewable water resources: 86.8
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 68.3 cu
km/yr (8%/6%/86%)
per capita: 923 cu m/yr (2000)
Natural hazards: periodic droughts; fre¬
quent earthquakes, flash floods, land¬
slides; hot, driving windstorm called
khamsin occurs in spring; dust storms,
sandstorms
Environment — current issues: agricul¬
tural land being lost to urbanization and
windblown sands; increasing soil salina¬
tion below Aswan High Dam; desertifi¬
cation; oil pollution threatening coral
reefs, beaches, and marine habitats;
other water pollution from agricultural
pesticides, raw sewage, and industrial
effluents; limited natural fresh water
resources away from the Nile, which is
the only perennial water source; rapid
growth in population overstraining the
Nile and natural resources
199
THE CIA WORLD FACTBOOK
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: controls Sinai
Peninsula, only land bridge between
Africa and remainder of Eastern
Hemisphere; controls Suez Canal, a sea
link between Indian Ocean and
Mediterranean Sea; size, and juxtaposi¬
tion to Israel, establish its major role in
Middle Eastern geopolitics; dependence
on upstream neighbors; dominance of
Nile basin issues; prone to influxes of
refugees
_ _
Location: Central America, bordering
the North Pacific Ocean, between
Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and
the Caribbean
Area:
total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
Area — comparative: slightly smaller
than Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km,
Honduras 342 km
Coastline: 307 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (May to
October); dry season (November to
April); tropical on coast; temperate in
uplands
Terrain: mostly mountains with narrow
coastal belt and central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower, geot-
hermal power, petroleum, arable land
Land use:
arable land: 31.37 %
permanent crops : 11.88%
other: 56.75% (2005)
Irrigated land: 450 sq km (2003)
Total renewable water resources: 25.2
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.28 cu
km/yr (25%/16%/59%)
per capita: 186 cu m/yr (2000)
Natural hazards: known as the Land of
Volcanoes; frequent and sometimes
destructive earthquakes and volcanic
activity; extremely susceptible to hurrb
canes
Environment — current issues: defor¬
estation; soil erosion; water pollution;
contamination of soils from disposal of
toxic wastes
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: smallest Central
American country and only one without
a coastline on Caribbean Sea','058d2c723816c0dcd4a08121fb5343fb90053ba499c94189967b8e042be5c4fa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('373501cb6f063a8b93e5f6a2771ae0cdf509e126efd9252f1d3c99f55d5373fd',2009,'GA','Gabon','geography',444,'Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,051 sq km
land: 28,05 1 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km,
Gabon 350 km
Coastline: 296 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior
hills; islands are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: petroleum, natural
gas, timber, gold, bauxite, diamonds, tan¬
talum, sand and gravel, clay
Land use:
arable land: 4.63%
permanent crops: 3.57%
other: 91.8% (2005)
Irrigated land: NA
Total renewable water resources: 26 cu
km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.11 cu
km/yr (83%/16%/l%)
per capita: 220 cu m/yr (2000)
Natural hazards: violent windstorms,
flash floods
Environment— current issues: tap water
is not potable; deforestation
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: insular and conti¬
nental regions widely separated
Location: Western Africa, bordering the
North Atlantic Ocean and Senegal
Geographic coordinates: 13 28 N, 16 34
W
Map references: Africa
Area: total: 1 1,300 sq km
land: 10,000 sq km
water: 1,300 sq km
Area— comparative: slightly less than
twice the size of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 18 nm
exclusive fishing zone: 200 nm
continental shelf: extent not specified
Climate: tropical; hot, rainy season
(June to November); cooler, dry season
(November to May)
Terrain: flood plain of the Gambia River
flanked by some low hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish, titanium (rutile
and ilmenite), tin, zircon, silica sand,
clay, petroleum
Land use:
arable land: 27.88%
permanent crops: 0.44%
other: 71.68% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 8 cu
km (1982)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.03 cu
km/yr (23%/12%/65%)
per capita: 20 cu m/yr (2000)
Natural hazards: drought (rainfall has
dropped by 30% in the last 30 years)
Environment— current issues: defer
estation; desertification; water-borne dis¬
eases prevalent
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: almost an enclave of
Senegal; smallest country on the conti¬
nent of Africa','ef6d959ab624283118d58022e4b4ffbb3295fcab5eebb993808d4e5c47163293','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e617e5bf065a4afbd6a968c549fcd8323ab6470084785cb3fc80ae95d2475c2c',2009,'ER','Eritrea','geography',449,'Location: Eastern Africa, bordering the
Red Sea, between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
Area — comparative: slightly larger than
Pennsylvania
Land boundaries:
total: 1,626 km
border countries: Djibouti 109 km,
Ethiopia 912 km, Sudan 605 km
Coastline: 2,234 km (mainland on Red
Sea 1,151 km, islands in Red Sea 1,083
km)
Maritime Claims: territorial sea: 12 nm
Climate: hot, dry desert strip along Red
Sea coast; cooler and wetter in the cen-
tral highlands (up to 61 cm of rainfall
annually, heaviest June to September);
semiarid in western hills and lowlands
Terrain: dominated by extension of
Ethiopian north-south trending high¬
lands, descending on the east to a coastal
desert plain, on the northwest to hilly
terrain and on the southwest to flat-to-
rolling plains
Elevation extremes:
lowest point: near Kulul within the
Denakil depression -75 m
highest point: Soira 3,018 m
Natural resources: gold, potash, zinc,
copper, salt, possibly oil and natural gas,
fish
Land use:
arable land: 4-78%
permanent crops: 0.03%
other: 95.19% (2005)
Irrigated land: 210 sq km (2003)
Total renewable water resources: 6.3
cu km (2001 )
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.3 cu
km/yr (3%/0%/97%)
per capita: 68 cu m/yr (2000)
Natural hazards: frequent droughts;
locust swarms
Environment — current issues: defor¬
estation; desertification; soil erosion;
overgrazing; loss of infrastructure from
civil warfare
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: none of the
selected agreements
Geography — note: strategic geopolitical
position along world’s busiest shipping
lanes; Eritrea retained the entire coast¬
line of Ethiopia along the Red Sea upon
de jure independence from Ethiopia on
24 May 1993
Location: Eastern Europe, bordering the
Baltic Sea and Gulf of Finland, between
Latvia and Russia
Geographic coordinates: 59 00 N, 26 00
E
Map references: Europe
Area:
total: 45,226 sq km
land: 43,211 sq km
water: 2,015 sq km
note: includes 1,520 islands in the Baltic
Sea
Area— comparative: slightly smaller
than New Hampshire and Vermont com¬
bined
Land boundaries:
total: 633 km
border countries: Latvia 339 km, Russia
294 km
Coastline: 3,794 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: limits fixed in
coordination with neighboring states
Climate: maritime, wet, moderate win¬
ters, cool summers
Terrain: marshy, lowlands; flat in the
north, hilly in the south
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: oil shale, peat, phos¬
phorite, clay, limestone, sand, dolomite,
arable land, sea mud
Land use:
arable land: 12.05%
permanent crops : 0.35%
other: 87.6% (2005)
irrigated land: 40 sq km (2003)
Total renewable water resources: 21.1
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.41 cu
km/yr (56%/39%/5%)
per capita: 1,060 cu m/yr (2002)
Natural hazards: sometimes flooding
occurs in the spring
Environment— current issues: air pol¬
luted with sulfur dioxide from oil-shale
burning power plants in northeast; how¬
ever, the amount of pollutants emitted to
the air have fallen steadily, the emissions
of 2000 were 80% less than in 1980; the
amount of unpurified wastewater dis¬
charged to water bodies in 2000 was one-
20th the level of 1980; in connection
with the start-up of new water purifica¬
tion plants, the pollution load of waste-
water decreased; Estonia has more than
1,400 natural and manmade lakes, the
smaller of which in agricultural areas
need to be monitored; coastal seawater is
polluted in certain locations
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: the mainland terrain
is flat, boggy, and partly wooded; offshore
lie more than 1,500 islands
Population: 1,307,605 (July 2008 est.)
Age structure:
0-14 years: 14-9% (male 100,143/female
94,450)
15-64 years: 67.5% (male
420,896/female 462,072)
65 years and over: 17.6% (male
76,171/female 153,873) (2008 est.)
Median age:
total: 39.6 years
male: 36.2 years
female: 43.2 years (2008 est.)
Population growth rate: -0.632% (2008
est.)
Birth rate: 10.28 births/1,000 population
(2008 est.)
Death rate: 13.35 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -3.24 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.84 male(s)/female
(2008 est.)
Infant mortality rate:
total: 7.45 deaths/1,000 live births
male: 8.62 deaths/1,000 live births
female: 6.21 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 72.56 years
male: 67.16 years
female: 78.3 years (2008 est.)
Total fertility rate: 1.42 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 1.1%
(2001 est.)
HIV/AIDS — people living with
HIV/AIDS: 7,800 (2003 est.)
HIV/A!DS— deaths: fewer than 200
(2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea and hepatitis A
vectorborne disease: tickborne
encephalitis (2008)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 67.9%, Russian
25.6%, Ukrainian 2.1%, Belarusian
1.3%, Finn 0.9%, other 2.2% (2000
census)
Religions: Evangelical Lutheran 13.6%,
Orthodox 12.8%, other Christian
(including Methodist, Seventh-Day
Adventist, Roman Catholic,
Pentecostal) 1.4%, unaffiliated 34.1%,
other and unspecified 32%, none 6.1%
(2000 census)
Languages: Estonian (official) 67.3%,
Russian 29.7%, other 2.3%, unknown
0.7% (2000 census)
Literacy:
definition: age 15 and over can read and
write
total population: 99.8%
male: 99.8%
female: 99.8% (2000 census)
212','d4786c32075d8d951d58a5d8bf7d033540075d5b8c31f3aeffd5656ae2cb4b3c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e41e8163b9f8f6d845ae18b43ae2f9a183fdfb5696bcddd0fe3ce1596e44844',2009,'ET','Ethiopia','geography',465,'Location: Eastern Africa, west of
Location: Southern South America,
islands in the South Atlantic Ocean,
east of southern Argentina
Geographic coordinates: 51 45 S, 59 00
w
Map references: South America
Area:
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of
East and West Falkland and about 200
small islands
Area— comparative: slightly smaller
than Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
territorial sea: 12 nm
continental shelf: 200 nm
exclusive fishing zone: 200 nm
Climate: cold marine; strong westerly
winds, cloudy, humid; rain occurs on
more than half of days in year; average
annual rainfall is 24 inches in Stanley;
occasional snow all year, except in
January and February, but does not accu-
mulate
Terrain: rocky, hilly, mountainous with
some boggy, undulating plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, squid, wildlife,
calcified seaweed, sphagnum moss
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (99% permanent pastures,
1% other) (2005)
Irrigated land: NA
Natural hazards: strong winds persist
throughout the year
Environment — current issues: over-
fishing by unlicensed vessels is a
problem; reindeer were introduced to the
islands in 2001 for commercial reasons;
this is the only commercial reindeer herd
in the world unaffected by the 1986
Chornobyl disaster
Geography — note: deeply indented
coast provides good natural harbors;
short growing season
Location: Eastern Africa, bordering the
Indian Ocean, between Somalia and
Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
water: 13,400 sq km
Area— comparative: slightly more than
twice the size of Nevada
Land boundaries:
total: 3,477 km
border countries: Ethiopia 861 km,
Somalia 682 km, Sudan 232 km,
Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: varies from tropical along coast
to arid in interior
Terrain: low plains rise to central high¬
lands bisected by Great Rift Valley; fer¬
tile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: limestone, soda ash,
salt, gemstones, fluorspar, zinc,
diatomite, gypsum, wildlife, hydropower
Land use:
arable land: 8.01%
permanent crops: 0.97%
other: 91.02% (2005)
Irrigated land: 1,030 sq km (2003)
Total renewable water resources: 30.2
cu km (1990)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.58 cu
km/yr (30%/6%/64%)
per capita: 46 cu m/yr (2000)
Natural hazards: recurring drought;
flooding during rainy seasons
Environment— current issues: water
pollution from urban and industrial
wastes; degradation of water quality from
increased use of pesticides and fertilizers;
water hyacinth infestation in Lake
Victoria; deforestation; soil erosion;
desertification; poaching
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: the Kenyan
Highlands comprise one of the most suc¬
cessful agricultural production regions in
Africa; glaciers are found on Mount
Kenya, Africa’s second highest peak;
unique physiography supports abundant
and varied wildlife of scientific and eco¬
nomic value','810b1b2516dcc361a9b158cb8b4e954396220c81bee789a95340286c8f5b35fa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfe0a9379612d48a7e7b5f9d169ee207a23858779b0bec905cb00a231a7ee398',2009,'SO','Somalia','geography',466,'Geographic coordinates: 8 00 N, 38 00
E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Area — -comparative: slightly less than
twice the size of Texas
Land boundaries:
total: 5,328 km
border countries: Djibouti 349 km, Eritrea
912 km, Kenya 861 km, Somalia 1,600
km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central moun¬
tain range divided by Great Rift Valley
Elevation extremes:
lowest point: Denakil Depression -125 m
highest point: Ras Dejen 4,533 m
Natural resources: small reserves of
gold, platinum, copper, potash, natural
gas, hydropower
Land use:
arable land: 10.01%
permanent crops: 0.65%
other: 89.34% (2005)
Irrigated land: 2,900 sq km (2003)
Total renewable water resources: 110
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 5.56 cu
km/yr (6%/0%/94%)
per capita: 72 cu m/yr (2002)
Natural hazards: geologically active Great
Rift Valley susceptible to earthquakes, vol¬
canic eruptions; frequent droughts
Environment — current issues: defor¬
estation; overgrazing; soil erosion; deser¬
tification; water shortages in some areas
from water-intensive farming and poor
management
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Environmental
Modification, Law of the Sea
Geography — note: landlocked — entire
coastline along the Red Sea was lost with
the de jure independence of Eritrea on
24 May 1993; the Blue Nile, the chief
headstream of the Nile by water volume,
rises in T’ana Hayk (Lake Tana) in
northwest Ethiopia; three major crops
are believed to have originated in
Ethiopia: coffee, grain sorghum, and
castor bean
Location: Eastern Africa, bordering the
Gulf of Aden and the Indian Ocean, east
of Ethiopia
Geographic coordinates: 10 00 N, 49 00
E
Map references: Africa
Area:
total: 637,657 sq km
land: 627,337 sq km
water: 10,320 sq km
Area— comparative: slightly smaller
than Texas
Land boundaries:
total: 2,340 km
border countries: Djibouti 58 km,
Ethiopia 1,600 km, Kenya 682 km
Coastline: 3,025 km
Maritime Claims: territorial sea: 200 nm
Climate: principally desert; northeast
monsoon (December to February), mod¬
erate temperatures in north and hot in
south; southwest monsoon (May to
October), torrid in the north and hot in
the south, irregular rainfall, hot and
humid periods (tangambili) between
monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,416 m
Natural resources: uranium and largely
unexploited reserves of iron ore, tin,
gypsum, bauxite, copper, salt, natural gas,
likely oil reserves
Land use:
arable land: 1.64%
permanent crops: 0.04%
other: 98.32% (2005)
Irrigated land: 2,000 sq km (2003)
Total renewable water resources: 15.7
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.29 cu
km/yr (0%/0%/100%)
per capita: 400 cu m/yr (2000)
Natural hazards: recurring droughts; fre¬
quent dust storms over eastern plains in
summer; floods during rainy season
Environment — current issues: famine;
use of contaminated water contributes to
human health problems; deforestation;
overgrazing; soil erosion; desertification
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Endangered Species, Law of the
Sea, Ozone Layer Protection
Geography — note: strategic location on
Horn of Africa along southern
approaches to Bab el Mandeb and route
through Red Sea and Suez Canal','43cdba6eef2dc59ff1cc165fe2f01ad44ac5611447863eba2dd45d4545a378a3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('249d5d917bed633e67dfbd1c817bfaf6dd355c2e56aeb4e14330f2c641a9b977',2009,'FO','Faroe Islands','geography',473,'Location: Northern Europe, island group
between the Norwegian Sea and the
North Atlantic Ocean, about half way
between Iceland and Norway
Geographic coordinates: 62 00 N, 7 00
w
Map references: Europe
Area:
total: 1,399 sq km
land: 1,399 sq km
water: 0 sq km (some lakes and streams)
Area — comparative: eight times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims:
territorial sea: 3 nm
continental shelf: 200 nm or agreed
boundaries or median line
exclusive fishing zone: 200 nm or agreed
boundaries or median line
Climate: mild winters, cool summers;
usually overcast; foggy, windy
Terrain: rugged, rocky, some low peaks;
cliffs along most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales,
hydropower, possible oil and gas
Land use:
arable land: 2.14%
permanent crops: 0%
other: 97.86% (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Environment— international agree¬
ments: party to: Marine Dumping -asso¬
ciate member to the London
Convention and Ship Pollution
Geography — note: archipelago of 17
inhabited islands and one uninhabited
island, and a few uninhabited islets;
strategically located along important sea
lanes in northeastern Atlantic; precipi¬
tous terrain limits habitation to small
coastal lowlands
Population: 48,668 (July 2008 est.)
Age structure:
0-14 years: 21.9% (male 5,489/female
5,166)
15-64 years: 64% (male 16,650/female
14,482)
65 years and over: 14.1% (male
3,233/female 3,648) (2008 est.)
Median age:
total: 36.7 years
male: 36 years
female: 37.5 years (2008 est.)
Population growth rate: 0.376% (2008
est.)
Birth rate: 13.25 births/ 1,000 population
(2008 est.)
Death rate: 8.67 deaths/ 1,000 popula¬
tion (2008 est.)
Net migration rate: -0.82 migrant^ )/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.09 male(s)/female
(2008 est.)
Infant mortality rate:
total: 6.46 deaths/1,000 live births
male: 6.69 deaths/1,000 live births
female: 6.2 deaths/1,000 live births (2008
est.)
Life expectancy at birth:
total population: 79.29 years
male: 76.86 years
female: 81.89 years (2008 est.)
Total fertility rate: 2.45 children
born/woman (2008 est.)
HiV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old
Norse), Danish
Literacy:
NA; note — probably 100%, the same as
Denmark proper
Country name:
conventional long form: none
conventional short form: Faroe Islands
local long form: none
local short form: Foroyar
Dependency status: part of the Kingdom
of Denmark; self-governing overseas
administrative division of Denmark
since 1948
Government type: NA
Capital: name: Torshavn
geographic coordinates: 62 01 N, 6 46 W
time difference: UTC 0 (5 hours ahead of
Washington, DC during Standard Time)
daylight saving time: +lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: none (part of
the Kingdom of Denmark; self-governing
overseas administrative division of
Denmark); there are no first-order
administrative divisions as defined by the
US Government, but there are 34
municipalities
Independence: none (part of the
Kingdom of Denmark; self-governing
overseas administrative division of
Denmark)
National holiday: Olaifest (Olavasoka),
29 July
Constitution: 5 June 1953 (Danish con¬
stitution)
Legal system: the laws of Denmark,
where applicable, apply
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen MARGRETHE II of
Denmark (since 14 January 1972), repre¬
sented by High Commissioner Birgit
KLEIS, chief administrative officer
(since 1 November 2001)
head of government: Prime Minister
Joannes EIDESGAARD (since 3
February 2004)
cabinet: Landsstyri appointed by the
prime minister
elections: the monarch is hereditary; high
commissioner appointed by the
monarch; following legislative elections,
the leader of the majority party or the
leader of the majority coalition is usually
elected prime minister by the Faroese
Parliament; election last held 20 January
2004 (next to be held no later than
January 2008)
221
THE CIA WORLD FACTBOOK
election results: Joannes EIDESGAARD
elected prime minister; percent of parlia-
mentary vote — NA
Legislative branch: unicameral Faroese
Parliament or Logting (33 seats; merm
bers are elected by popular vote on a pro-
portional basis from the seven
constituencies to serve four-year terms)
elections: last held 19 January 2008 (next
to be held no later than January 2012)
election results: percent of vote by party —
Union Party 21%, Social Democratic
Party 19.4%, Republican Party 23.3%,
People’s Party 20.1%, Center Party 8.4%,
Self-Government Party 7.2%, other
0.6%; seats by party — Republican Party
8, Union Party 7, Social Democratic
Party 6, People’s Party 7, Center Party 3,
Independence Party 2
note: election of two seats to the Danish
Parliament was last held on 13
November 2007 (next to be held no later
than November 2011); results — percent
of vote by party — NA; seats by party —
Republican Party 1 , Union Party 1
Judicial branch: none
Political parties and leaders: Center
Party [Jenis A. RAN A]; Independence
Party [Kari P. HOJGAARD]; People’s
Party Qorgen NICLASEN]; Republican
Party [Hogni HOYDAL]; Social
Democratic Party [Joannes EIDES¬
GAARD]; Union Party [Kaj Leo
JOHANNESEN]
Political pressure groups and leaders:
NA
International organization participa¬
tion: Arctic Council, IMO (associate),
NC, NIB, UPU
Diplomatic representation in the US:
none (self-governing overseas adminis¬
trative division of Denmark)
Diplomatic representation from the US:
none (self-governing overseas adminis¬
trative division of Denmark)
Flag description: white with a red cross
outlined in blue extending to the edges
of the flag; the vertical part of the cross is
shifted toward the hoist side in the style
of the Dannebrog (Danish flag)','807aefcd9bf1add40a68d4adf45e310f419e09742e80c65b7502a069552319fb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff53db24f09633fc7d219630e617833309a382b0d8a853bbc9fd854fd3554956',2009,'FJ','Fiji','geography',479,'_
Location: Oceania, island group in the
South Pacific Ocean, about two-thirds of
the way from Hawaii to New Zealand
Geographic coordinates: 18 00 S, 175
00 E
Map references: Oceania
Area: total: 18,270 sq km
land: 18,270 sq km
water: 0 sq km
Area — comparative: slightly smaller
than New Jersey
Land boundaries: 0 km
Coastline: 1,129 km
Maritime Claims: measured from
claimed archipelagic straight baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation; rectilinear shelf
claim added
Climate: tropical marine; only slight sea¬
sonal temperature variation
Terrain: mostly mountains of volcanic
origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold,
copper, offshore oil potential, hydropower
Land use:
arable land: 10.95%
permanent crops: 4.65%
other: 84-4% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 28.6
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.07 cu
km/yr ( 1 4%/l 4%/7 1 % )
per capita: 82 cu m/yr (2000)
Natural hazards: cyclonic storms can
occur from November to January
Environment— current issues: defor¬
estation; soil erosion
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: includes 332 islands;
approximately 110 are inhabited','462f18baa1cc5d28dfd6a6f0328026ca524a0c963532f2eba05aeb6497271ea2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4c1e626e781093bc65e7c46ec44198a272cb98632e0e634d090f211ec65f5a9',2009,'PF','French Polynesia','geography',498,'Locafion: Oceania, archipelagoes in the
South Pacific Ocean about half way
between South America and Australia
Geographic coordinafes: 15 00 S, 140
00 w
Map references: Oceania
Area:
total: 4,167 sq km (118 islands and
atolls)
land: 3,660 sq km
water: 507 sq km
Area — comparative: slightly less than
one-third the size of Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical, but moderate
233
THE CIA WORLD FACTBOOK
Terrain: mixture of rugged high islands
and low islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Orohena 2,241 m
Natural resources: timber, fish, cobalt,
hydropower
Land use:
arable land: 0.75%
permanent crops: 5.5%
other: 93.75% (2005)
Irrigated land: 10 sq km (2003)
Natural hazards: occasional cyclonic
storms in January
Environment— current issues: NA
Geography— note: includes five archi¬
pelagoes (four volcanic, one coral);
Makatea in French Polynesia is one of
the three great phosphate rock islands in
the Pacific Ocean — the others are
Banaba (Ocean Island) in Kiribati and
Location: southeast and east of Africa,
islands in the southern Indian Ocean,
some near Madagascar and others about
equidistant between Africa, Antarctica,
and Australia; note — French Southern
and Antarctic Lands include He
Amsterdam, He Saint-Paul, lies Crozet,
lies Kerguelen, Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova
Island, and Tromelin Island in the
southern Indian Ocean, along with the
French-claimed sector of Antarctica,
“Adelie Land”; the US does not recog¬
nize the French claim to “Adelie Land”
Geographic coordinates: He Amsterdam
(He Amsterdam et He Saint-Paul): 37 50 S,
77 32 E
He Saint-Paul (He Amsterdam et He Saint-
Paul): 38 72 S, 77 53 E
lies Crozet: 46 25 S, 51 00 E
lies Kerguelen: 49 15 S, 69 35 E
Bassas da India (lies Eparses): 21 30 S, 39
50 E
Europa Island (lies Eparses): 22 20 S, 40
22 E
Glorioso Islands (lies Eparses): 1 1 30 S, 47
20 E
Juan de Nova Island (lies Eparses): 17 03
S, 42 45 E
Tromelin Island (lies Eparses): 15 52 S, 54
25 E
Map references: Antarctic Region,
Africa
Area:
He Amsterdam (lie Amsterdam et He Saint-
Paul): total — 55 sq km; land — 55 sq km;
water — 0 sq km
He Saint-Paul (He Amsterdam et He Saint-
Paul): total — 7 sq km; land — 7 sq km;
water — 0 sq km
lies Crozet: total — 352 sq km; land — 352
sq km; water — 0 sq km
lies Kerguelen: total — 7,215 sq km;
land — 7,215 sq km; water — 0 sq km
Bassas da India (lies Eparses): total — 80
sq km; land — 0.2 sq km; water — 79.8 sq
km (lagoon)
Europa Island (lies Eparses): total — 28 sq
km; land — 28 sq km; water — 0 sq km
Glorioso Islands (lies Eparses): total — 5 sq
km; land — 5 sq km; water — 0 sq km
Juan de Nova Island (lies Eparses): total —
4-4 sq km; land — 4-4 sq km; water — 0 sq
km
Tromelin Island (lies Eparses): total — 1 sq
km; land — 1 sq km; water — 0 sq km
note: excludes “Adelie Land” claim of
about 500,000 sq km in Antarctica that
is not recognized by the US
Area — comparative: He Amsterdam (lie
Amsterdam et He Saint-Paul): less than
one-half the size of Washington, DC
lie Saint-Paul (He Amsterdam et He Saint-
Paul): more than 10 times the size of The
Mall in Washington, DC
lies Crozet: about twice the size of
Washington, DC
lies Kerguelen: a little larger than
Delaware
Bassas da India (lies Eparses): land area
about one-third the size of The Mall in
Washington, DC
Europa Island (lies Eparses): about one-
sixth the size of Washington, DC
236
FRENCH SOUTHERN AND ANTARCTIC LANDS
Glorioso Islands (lies Eparses): about eight
times the size of The Mall in
Washington, DC
Jmn de Nova Island (lies Eparses): about
seven times the size of The Mall in
Washington, DC
T romelin Island (lies Eparses): about 1.7
times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: He Amsterdam (lie Amsterdam
et He Saint''Paul) : 28 km
He Saint''Paul (He Amsterdam et He Saint -
Paul) :
lies Kerguelen: 2,800 km
Bassos da India (lies Eparses): 35.2 km
Europa Island (lies Eparses): Til km
Glorioso Islands (lies Eparses): 35.2 km
Juan de Nova Island (lies Eparses): 24.1
km
Tromelin Island (lies Eparses): 3.7 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm from lies
Kerguelen and lies Eparses (does not
include the rest of French Southern and
Antarctic Lands); Juan de Nova Island
and Tromelin Island claim a continental
shelf of 200-m depth or to the depth of
exploitation
Climate: He Amsterdam et He Saint''Paul:
oceanic with persistent westerly winds
and high humidity
lies Crozet: windy, cold, wet, and cloudy
lies Kerguelen: oceanic, cold, overcast,
windy
lies Eparses: tropical
Terrain: He Amsterdam (He Amsterdam et
He Saint''Paul): a volcanic island with
steep coastal cliffs; the center floor of the
volcano is a large plateau
He Saint''Paul (He Amsterdam et He Saint''
Paul): triangular in shape, the island is
the top of a volcano, rocky with steep
cliffs on the eastern side; has active
thermal springs
lies Crozet: a large archipelago formed
from the Crozet Plateau is divided into
two groups of islands
lies Kerguelen: the interior of the large
island of lie Kerguelen is composed of
rugged terrain of high mountains, hills,
valleys, and plains with a number of
peninsulas stretching off its coasts
Bassos da India (lies Eparses): atoll, awash
at high tide; shallow (15 m) lagoon
Europa Island, Glorioso Islands, Juan de
Nova Island: low, flat, and sandy
Tromelin Island (lies Eparses): low, flat,
sandy; likely volcanic seamount
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont de la Dives on lie
Amsterdam (He Amsterdam et He Saint-
Paul) 867 m; unnamed location on He
Saint''Paul (He Amsterdam et He Saint-
Paul) 272 m; Pic Marion-Dufresne in lies
Crozet 1,090 m; Mont Ross in lies
Kerguelen 1,850 m; unnamed location
on Bassas de India (lies Eparses) 2.4 m;
unnamed location on Europa Island (lies
Eparses) 24 m; unnamed location on
Glorioso Islands (lies Eparses) 12 m;
unnamed location on Juan de Nova
Island (lies Eparses) 10 m; unnamed
location on Tromelin Island (lies
Eparses) 7 m
Natural resources: fish, crayfish
note: Glorioso Islands and Tromelin
Island (lies Eparses) have guano, phos¬
phates, and coconuts
Land use:
He Amsterdam (He Amsterdam et He
Saint''Paul) — 100% trees, grasses, ferns,
and moss; He Saint-Paul (lie Amsterdam
et He Saint-Paul) — 100% grass, ferns,
and moss; lies Crozet— 100% tossock
grass, heath, and fern; lies Kerguelen —
100% tossock grass and Kerguelen cab¬
bage; Bassas da India (lies
Eparses) — 100% rock, coral reef, and
sand; Europa Island (lies Eparses) —
100% mangrove swamp and dry wood¬
lands; Glorioso Islands (lies
Eparses) — 100% lush vegetation and
coconut palms; Juan de Nova Island (lies
Eparses) — 90% forest, 10% other;
Tromelin Island (lies Eparses) — 100%
grasses and scattered brush (2005)
Irrigated land: 0 sq km
Natural hazards: He Amsterdam and lie
Saint-Paul are inactive volcanoes; lies
Eparses subject to periodic cyclones;
Bassas da India is a maritime hazard since
it is under water for a period of three
hours prior to and following the high tide
and surrounded by reefs
Environment — current issues: introduc¬
tion of foreign species on lies Crozet has
caused severe damage to the original
ecosystem; overfishing of Patagonian
Toothfish around lies Crozet and lies
Kerguelen
Geography — note: islands component is
widely scattered across remote locations
in the southern Indian Ocean
Bassas da India (lies Eparses): the atoll is
a circular reef that sits atop a long-
extinct, submerged volcano
Europa Island and Juan de Nova Island
(lies Eparses): wildlife sanctuary for
seabirds and sea turtles
Glorioso Island (lies Eparses): the islands
and rocks are surrounded by an extensive
reef system
Tromelin Island (lies Eparses): climatolog-
ically important location for forecasting
cyclones in the western Indian Ocean;
wildlife sanctuary (seabirds, tortoises)
. .','16ab57cac193dcc5e53f288c7c1a5e26b37113d5fd3a937ec3bcf5f25bb81bf7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61a0a2babde02187e8adf800ad87036a7723ac6c8aa81e96032f9e19bab56ab7',2009,'MU','Mauritius','geography',506,'Location: Western Africa, bordering the
Atlantic Ocean at the Equator, between
Republic of the Congo and Equatorial
Location: Southern Africa, island in the
Indian Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33
E
Map references: Political Map of the
World
Area:
total: 2,040 sq km
land: 2,030 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados
Carajos Shoals (Saint Brandon), and
Rodrigues
Area — comparative: almost 11 times the
size of Washington, DC
Land boundaries: 0 km
Coastiine: 177 km
Maritime Claims: measured from
claimed archipelagic straight baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical, modified by southeast
trade winds; warm, dry winter (May to
November); hot, wet, humid summer
(November to May)
Terrain: small coastal plain rising to dis¬
continuous mountains encircling central
plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
Natural resources: arable land, fish
Land use: arable land: 49.02%
permanent crops : 2.94%
other: 48.04% (2005)
Irrigated land: 220 sq km (2003)
Total renewable water resources: 2.2
cu km (2001 )
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.61 cu
km/yr (25%/14%/60%)
per capita: 488 cu m/yr (2000)
Natural hazards: cyclones (November
to April); almost completely surrounded
by reefs that may pose maritime hazards
Environment — current issues: water
pollution, degradation of coral reefs
Environment — international agree¬
ments: party to: Antarctic-Marine
Living Resources, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: the main island, from
which the country derives its name, is of
volcanic origin and is almost entirely sur¬
rounded by coral reefs','ed1d58ae94720c7e96137ab8a6551605fe38d7def55d02dead6d9d0d8bd321dc','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76fe54932116956b8064abba97051003c3c36c3b70b400e334f3e5c4b0594811',2009,'GN','Guinea','geography',507,'Geographic coordinates: 1 00 S, 11 45 E
Map references: Africa
Area:
total: 267,667 sq km
land: 257,667 sq km
water: 10,000 sq km
Area — comparative: slightly smaller
than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km,
Republic of the Congo 1,903 km,
Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly inte¬
rior; savanna in east and south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1,575 m
Natural resources: petroleum, natural
gas, diamond, niobium, manganese, ura¬
nium, gold, timber, iron ore, hydropower
Land use:
arable land: 1.21%
permanent crops: 0.64%
other: 98.15% (2005)
Irrigated land: 70 sq km (2003)
Total renewable water resources: 164
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.12 cu
km/yr (50%/8%/42%)
per capita: 87 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: defor¬
estation; poaching
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: a small population
and oil and mineral reserves have helped
Gabon become one of Africa’s wealthier
countries; in general, these circum¬
stances have allowed the country to
maintain and conserve its pristine rain
forest and rich biodiversity
Location: Western Africa, bordering the
North Atlantic Ocean, between Guinea-
Bissau and Sierra Leone
Geographic coordinates: 1 1 00 N, 10 00 w
Map references: Africa
Area:
total: 245,857 sq km
land: 245,857 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Oregon
Land boundaries:
total: 3,399 km
border countries: Cote d’Ivoire 610 km,
Guinea-Bissau 386 km, Liberia 563 km,
Mali 858 km, Senegal 330 km, Sierra
Leone 652 km
Coastline: 320 km
274
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: generally hot and humid; mon-
soonahtype rainy season (June to
November) with southwesterly winds;
dry season (December to May) with
northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly
to mountainous interior
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: bauxite, iron ore,
diamonds, gold, uranium, hydropower,
fish, salt
Land use: arable land: 4-47%
permanent crops: 2.64%
other: 92.89% (2005)
Irrigated land: 950 sq km (2003)
Total renewable water resources: 226
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.51 cu
km/yr (8%/2%/90%)
per capita: 161 cu m/yr (2000)
Natural hazards: hot, dry, dusty har-
mattan haze may reduce visibility during
dry season
Environment — current issues: deforesta¬
tion; inadequate supplies of potable
water; desertification; soil contamination
and erosion; overfishing, overpopulation
in forest region; poor mining practices
have led to environmental damage
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: the Niger and its
important tributary the Milo have their
sources in the Guinean highlands
Population: 138,283,240
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor¬
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 42.2% (male
29,378,127/female 28,953,864)
15-64 years: 54.7% (male
38,466,129/female 37,172,355)
65 years and over: 3.1% (male
2,046,309/female 2,266,456) (2008 est.)
Median age:
total: 18.7 years
male: 18.8 years
female: 18.6 years (2008 est.)
Population growth rate: 2.382% (2008
est. )
Birth rate: 39.98 births/1,000 population
(2008 est.)
Death rate: 16.41 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 0.25 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15—64 years: 1.03 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.02 male(s)/female
(2008 est.)
Infant mortality rate:
total: 93.93 deaths/1,000 live births
male: 100.87 deaths/1,000 live births
female: 86.79 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 47.81 years
male: 47.15 years
female: 48.5 years (2008 est.)
Total fertility rate: 5.41 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 5 4%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 3.6 million (2003 est.)
HIV/AIDS— deaths: 310,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A, and
typhoid fever
vectorbome disease: malaria and yellow
fever
respiratory disease: meningococcal
meningitis
aerosolized dust or soil contact disease: one
of the most highly endemic areas for
Lassa fever
water contact disease: leptospirosis and
shistosomiasis
note: highly pathogenic H5N1 avian
influenza has been identified in this
country; it poses a negligible risk with
extremely rare cases possible among US
citizens who have close contact with
birds (2008)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Nigeria, Africa’s most
populous country, is composed of more
than 250 ethnic groups; the following are
the most populous and politically influ¬
ential: Hausa and Fulani 29%, Yoruba
21%, Igbo (Ibo) 18%, Ijaw 10%, Kanuri
4%, Ibibio 3.5%, Tiv 2.5%
Religions: Muslim 50%, Christian 40%,
indigenous beliefs 10%
Languages: English (official), Hausa,
Yoruba, Igbo (Ibo), Fulani
Literacy:
definition: age 15 and over can read and
write
total population: 68%
male: 75.7%
female: 60.6% (2003 est.)
VERNMENT
Country name:
conventional long form: Federal Republic
of Nigeria
conventional short form: Nigeria
Government type: federal republic
Capital: name: Abuja
geographic coordinates: 9 12 N, 7 1 1 E
time difference: UTC+1 (6 hours ahead of
Washington, DC during Standard Time)
Administrative divisions: 36 states and
1 territory*; Abia, Adamawa, Akwa
Ibom, Anambra, Bauchi, Bayelsa, Benue,
Borno, Cross River, Delta, Ebonyi, Edo,
Ekiti, Enugu, Federal Capital Territory*,
Gombe, Imo, Jigawa, Kaduna, Kano,
Katsina, Kebbi, Kogi, Kwara, Lagos,
Nassarawa, Niger, Ogun, Ondo, Osun,
Oyo, Plateau, Rivers, Sokoto, Taraba,
Yobe, Zamfara
Independence: 1 October I960 (from
UK)
National holiday: Independence Day
(National Day), 1 October (1960)
Constitution: new constitution adopted
5 May 1999; effective 29 May 1999
Legal system: based on English common
law, Islamic law (in 12 northern states),
and traditional law; accepts compulsory
ICJ jurisdiction with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Umaru Musa
479
THE CIA WORLD FACTBOOK
YAR’ADUA (since 29 May 2007);
note — the president is both the chief of
state and head of government
head of government: President Umaru
Musa YAR’ADUA (since 29 May 2007)
cabinet: Federal Executive Council
elections: president is elected by popular
vote for a four-year term (eligible for a
second term); election last held 21 April
2007 (next to be held in April 2011)
election results: Umaru Musa
YAR’ADUA elected president; percent
of vote — Umaru Musa YAR’ADUA
69.8%, Muhammadu BUHARI 18.7%,
Atiku ABUBAKAR 7.5%, Orji Uzor
KALU 1.7%, other 2.3%
Legislative branch: bicameral National
Assembly consists of the Senate (109
seats, 3 from each state plus 1 from
Abuja; members elected by popular vote
to serve four-year terms) and House of
Representatives (360 seats; members
elected by popular vote to serve four-year
terms)
elections: Senate — last held 21 April
2007 (next to be held in April 2011);
House of Representatives — last held 21
April 2007 (next to be held in April
2011)
election results : Senate — percent of vote
by party— PDP 53.7%, ANPP 27.9%,
AD 9.7%, other 8.7%; seats by party —
PDP 76, ANPP 27, AD 6; House of
Representatives — percent of vote by
party— PDP 54.5%, ANPP 27.4%, AD
8.8%, UNPP 2.8%, NPD 1.9%, APGA
1.6%, PRP 0.8%; seats by party — PDP
76, ANPP 27, AD 6, UNPP 2, APGA 2,
NPD 1, PRP 1, vacant 1
Judicial branch: Supreme Court (judges
appointed by the President); Federal
Court of Appeal (judges are appointed by
the federal government on the advice of
the Advisory judicial Committee)
Political parties and leaders: Accord
Party [Ikra Aliyu BILBIS]; Action
Congress or AC [Hassan ZUM1];
Alliance for Democracy or AD
[Mojisoluwa AKINFENWA]; All Nigeria
Peoples’ Party or ANPP [Edwin UME-
EZEOKE]; All Progressives Grand
Alliance or APGA [Victor C. UMEH];
Democratic People’s Party or DPP
[Jeremiah USENI]; Fresh Democratic
Party [Chris OKOTIEJ; Labor Party [Dan
NWANYANWU]; Movement for the
Restoration and Defense of Democracy
or MRDD [Mohammed Gambo
JIMETA]; National Democratic Party or
NDP [Aliyu Habu FARI]; Peoples
Democratic Party or PDP [vacant];
Peoples Progressive Alliance [Clement
EBRI]; Peoples Redemption Party or
PRP [Abdulkadir Balarabe MUSA];
Peoples Salvation Party or PSP [Lawal
MAITURARE]; United Nigeria Peoples
Party or UNPP [Mallam Selah JAMBO]
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACP, AfDB, AU, C, ECOWAS,
FAO, G-15, G-24, G-77, IAEA, IBRD,
ICAO, ICC, ICCt, ICRM, IDA, IDB,
IFAD, IFC, IFRCS, IHO, ILO, IMF,
IMO, IMSO, Interpol, IOC, IOM, IPU,
ISO, ITSO, ITU, ITUC, MIGA, MIN-
URSO, NAM, OAS (observer), OIC,
OPCW, OPEC, PCA, UN, UNAMID,
UNCTAD, UNESCO, UNHCR,
UNIDO, UNITAR, UNMEE, UNMIL,
UNMIS, UNOCI, UNOMIG,
UNWTO, UPU, WCO, WFTU, WHO,
WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Oluwole
ROTIMI
chancery: 3519 International Court NW,
Washington, DC 20008
telephone: [1] (202) 986-8400
FAX: [1] (202) 775-1385
consulate(s) general: Atlanta, New York
Diplomatic representation from the US:
chief of mission: Ambassador Robin
SANDERS
embassy: 1075 Diplomatic Drive, Abuja
mailing address: P. O. Box 5760, Garki,
Abuja
telephone: [234] (9) 461-4000
FAX: [234] (9) 461-4036/4273
Flag description: three equal vertical
bands of green (hoist side), white, and
green
local short form: Papuaniugini
former: Territory of Papua and New
abbreviation: PNG
Government type: constitutional parlia¬
mentary democracy
Capital: name: Port Moresby
geographic coordinates: 930S, 147 10E
time difference: UTC+10 (15 hours ahead
of Washington, DC during Standard
Time)
Administrative divisions: 20 provinces;
Bougainville, Central, Chimbu, Eastern
Highlands, East New Britain, East Sepik,
Enga, Gulf, Madang, Manus, Milne Bay,
Morobe, National Capital, New Ireland,
Northern, Sandaun, Southern
Highlands, Western, Western Highlands,
West New Britain
Independence: 16 September 1975
(from the Australian-administered UN
trusteeship)
National holiday: Independence Day, 16
September (1975)
Constitution: 16 September 1975
Legal system: based on English common
law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); represented by
governor general Sir Paulius MATANE
(since 29 June 2004)
head of government: Prime Minister Sir
Michael SOMARE (since 2 August
2002); Deputy Prime Minister Puka
TEMU (since 29 August 2007)
cabinet: National Executive Council
appointed by governor general on recom¬
mendation of prime minister
elections: monarch is hereditary; gov¬
ernor general nominated by parliament
and appointed by chief of state; following
legislative elections, leader of majority
party or leader of majority coalition usu¬
ally is appointed prime minister by gov¬
ernor general
Legislative branch: unicameral
National Parliament (109 seats, 89 filled
from open electorates and 20 from
provinces and national capital distict;
members elected by popular vote to serve
five-year terms); constitution allows up
to 126 seats
elections: last held from 30 June to 10 July
2007; next to be held in June 2012
election results: percent of vote by party —
NA; seats by party — National Alliance
27, PNGP 8, PAP 6, URP 6, PANGU 5,
PDM 5, independents 19, others 33;
note — election to 1 seat was nullified
note: 15 other parties won 4 or fewer
seats; association with political parties is
fluid
Judicial branch: Supreme Court (the
chief justice is appointed by the governor
general on the proposal of the National
Executive Council after consultation
with the minister responsible for justice;
other judges are appointed by the
Judicial and Legal Services Commission)
Political parties and leaders: National
Alliance Party or NA [Michael
SOMARE]; Papua and Niugini Union
Party or PANGU PATI [Andrew KUM-
BAKOR]; Papua New Guinea Party or
PNGP [Sir Mekere MORAUTA];
People’s Democratic Movement or PDM
[Michael OGIO]; People’s Action Party
or PAP [Gabriel KAPRIS]; United
Resources Party or URP [William
DUMA] (2007)
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACP, ADB, APEC, ARF, ASEAN
(observer), C, CP, FAO, G-77, IBRD,
ICAO, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, Interpol, IOC,
IOM (observer), IPU, ISO (correspon¬
dent), ITSO, ITU, MIGA, NAM,
OPCW, PIF, Sparteca, SPC, UN,
UNCTAD, UNESCO, UNIDO,
UN WTO, UPU, WCO, WFTU, WHO,
WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Evan Jeremy
PAKI
chancery: 1779 Massachusetts Avenue
NW, Suite 805, Washington, DC 20036
telephone: [1] (202) 745-3680
FAX: [1] (202) 745-3679
Diplomatic representation from the US:
chief of mission: Ambassador Leslie W.
Rowe
embassy: Douglas Street, Port Moresby,
N.C.D.
mailing address: 4240 Port Moresby PI,
US Department of State, Washington
DC 20521-4240
telephone: [675] 321-1455
FAX: [675] 321-3423
506
Location: Western Africa, islands in the
Gulf of Guinea, straddling the Equator,
west of Gabon
Geographic coordinates: l 00 N, 7 00 E
Map references: Africa
Area:
total: 1,001 sq km
land: 1,001 sq km
water: 0 sq km
Area— comparative: more than five
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime Claims: measured from
claimed archipelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; one rainy
season (October to May)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish, hydropower
Land use: arable land: 8.33%
permanent crops: 48.96%
other: 42.71% (2005)
Irrigated land: 100 sq km (2003)
Natural hazards: NA
Environment— current issues: defor¬
estation; soil erosion and exhaustion
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Endangered
Species, Environmental Modification,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: the smallest country
in Africa; the two main islands form part
of a chain of extinct volcanoes and both
are mountainous
Location: Middle East, bordering the
Persian Gulf and the Red Sea, north of','e2e720193c74fa286460788bae13b7d39c1739f9efe016e97a6ffacbd815237b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c7c59b809e045b86bf59952aac98955f4203a984a39e597d82e20d7a895660f',2009,'IL','Israel','geography',521,'Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: 0 sq km
Area — comparative: slightly more than
twice the size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51
km
Coastline: 40 km
Maritime Claims: Israeli-occupied with
current status subject to the Israeli-
Palestinian Interim Agreement — perma¬
nent status to be determined through
further negotiation
Climate: temperate, mild winters, dry
and warm to hot summers
Terrain: flat to rolling, sand- and dune-
covered coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ‘Awdah (Joz Abu
‘Auda) 105 m
Natural resources: arable land, natural
gas
Land use:
arable land: 29%
permanent crops : 2 1 %
other: 50% (2002)
Irrigated land: 150 sq km; note —
includes West Bank (2003)
Natural hazards: droughts
Environment — current issues: desertifi¬
cation; salination of fresh water; sewage
treatment; water-borne disease; soil
degradation; depletion and contamina¬
tion of underground water resources
Geography — note: strategic strip of land
along Mideast-North African trade
routes has experienced an incredibly tur¬
bulent history; the town of Gaza itself
has been besieged countless times in its
history
Location: Middle East, bordering the
Mediterranean Sea, between Egypt and','214efeeb79aaa11fa0d106e5ca235494b91974b509737512b2ed5a4d0c754a47','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4435894af161732af0d519cd7deecce6aafe61998527051feda3a78722ad4479',2009,'GE','Georgia','geography',530,'Location: Southwestern Asia, bordering
the Black Sea, between Turkey and
Russia
Geographic coordinates: 42 00 N, 43 30
E
Map references: Asia
Area:
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
Area — comparative: slightly smaller
than South Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km,
Azerbaijan 322 km, Russia 723 km,
Turkey 252 km
Coastline: 310 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: warm and pleasant;
Mediterranean-like on Black Sea coast
Terrain: largely mountainous with Great
Caucasus Mountains in the north and
Lesser Caucasus Mountains in the south;
Kolkhet’is Dablobi (Kolkhida Lowland)
opens to the Black Sea in the west;
Mtkvari River Basin in the east; good
soils in river valley flood plains, foothills
of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt’a Shkhara 5,201 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper,
minor coal and oil deposits; coastal cli¬
mate and soils allow for important tea
and citrus growth
Land use:
arable land: 11.51%
permanent crops: 3.79%
other: 84.7% (2005)
Irrigated land: 4,690 sq km (2003)
Total renewable water resources: 63.3
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.61 cu
km/yr (20%/21%/59%)
per capita: 808 cu m/yr (2000)
Natural hazards: earthquakes
Environment — current issues: air pollu¬
tion, particularly in Rust’avi; heavy pol¬
lution of Mtkvari River and the Black
Sea; inadequate supplies of potable
water; soil pollution from toxic chemi¬
cals
Environment — international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: strategically located
east of the Black Sea; Georgia controls
much of the Caucasus Mountains and
the routes through them
Population: 4,630,841 (July 2008 est.)
Age structure:
0-14 years: 16.3% (male 402,961/female
352,735)
15-64 years: 67.1% (male
1,496,802/female 1,610,725)
65 years and over: 16.6% (male
307,795/female 459,823) (2008 est.)
Median age: total: 38.3 years
male: 35.8 years
female: 40.7 years (2008 est.)
Population growth rate: -0.325% (2008
est.)
Birth rate: 10.62 births/1,000 population
(2008 est.)
Death rate: 9.51 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -4.36 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.13 male(s)/female
under 15 years: 1.14 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.91 male(s)/female
(2008 est.)
Infant mortality rate:
total: 16.78 deaths/1,000 live births
male: 18.81 deaths/1,000 live births
female: 14-48 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 76.51 years
male: 73.21 years
female: 80.26 years (2008 est.)
Total fertility rate: 1.43 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: less
than 0.1% (2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 3,000 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 83.8%, Azeri
6.5%, Armenian 5.7%, Russian 1.5%,
other 2.5% (2002 census)
Religions: Orthodox Christian 83.9%,
Muslim 9.9%, Armenian-Gregorian
3.9%, Catholic 0.8%, other 0.8%, none
0.7% (2002 census)
Languages: Georgian 71% (official),
Russian 9%, Armenian 7%, Azeri 6%,
other 7%
note: Abkhaz is the official language in
Abkhazia
Literacy: definition: age 15 and over can
read and write
total population: 100%
male: 100%
female: 100% (2004 est.)
247
THE CIA WORLD FACTBOOK
Location: Central Europe, bordering the
Baltic Sea and the North Sea, between
the Netherlands and Poland, south of
Land boundaries:
total: 1,703 km
border countries: Brazil 593 km, French
Guiana 510 km, Guyana 600 km
Coastline: 386 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade
winds
Terrain: mostly rolling hills; narrow
coastal plain with swamps
Elevation extremes:
lowest point: unnamed location in the
coastal plain -2 m
highest point: Juliana Top 1,230 m
Natural resources: timber, hydropower,
fish, kaolin, shrimp, bauxite, gold, and
small amounts of nickel, copper, plat¬
inum, iron ore
Land use:
arable land: 0.36%
permanent crops: 0.06%
other: 99.58% (2005)
Irrigated land: 510 sq km (2003)
Total renewable water resources: 122
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.6 7 cu
km/yr (4%/3%/93%)
per capita: 1,489 cu m/yr (2000)
Natural hazards: NA
Environment— current issues: defor¬
estation as timber is cut for export; pollu¬
tion of inland waterways by small-scale
mining activities
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: smallest independent
country on South American continent;
mostly tropical rain forest; great diversity
of flora and fauna that, for the most part,
is increasingly threatened by new devel¬
opment; relatively small population,
mostly along the coast
Land boundaries:
total: 1,424 km
border countries: Algeria 965 km, Libya
459 km
Coastline: 1,148 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 12 nm
Climate: temperate in north with mild,
rainy winters and hot, dry summers;
desert in south
Terrain: mountains in north; hot, dry
central plain; semiarid south merges into
the Sahara
Elevation extremes:
lowest point: Shatt al Gharsah -17 m
highest point: Jebel ech Chambi 1,544 m
Natural resources: petroleum, phos¬
phates, iron ore, lead, zinc, salt
Land use: arable land: 17.05%
permanent crops: 13.08%
other: 69.87% (2005)
Irrigated land: 3,940 sq km (2003)
Total renewable water resources: 4.6
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.64 cu
km/yr (14%/4%/82%)
per capita: 261 cu m/yr (2000)
Natural hazards: NA
Environment— current issues: toxic and
hazardous waste disposal is ineffective
and poses health risks; water pollution
from raw sewage; limited natural fresh
water resources; deforestation; over¬
grazing; soil erosion; desertification
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life
Conservation
654','d217bd9474d19a75e297a786e8b6949d34a1c818c39cf9c12c6e68f7bcd387e4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c13077cc4d01162cfb99439fcf23b80b3bb05a550852016e2e0bbbfbc880f0',2009,'DK','Denmark','geography',535,'Geographic coordinates: 51 00 N, 9 00
E
Map references: Europe
Area: total: 357,021 sq km
land: 349,223 sq km
water: 7,798 sq km
Area— comparative: slightly smaller
than Montana
Land boundaries:
total: 3,621 km
border countries: Austria 784 km,
Belgium 167 km, Czech Republic 646
km, Denmark 68 km, France 451 km,
Luxembourg 138 km, Netherlands 577
km, Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200- m depth or to the
depth of exploitation
Climate: temperate and marine; cool,
cloudy, wet winters and summers; occa¬
sional warm mountain (foehn) wind
Terrain: lowlands in north, uplands in
center, Bavarian Alps in south
Elevation extremes:
lowest point: Neuendorf bei Wilster -3.54 m
highest point: Zugspitze 2,963 m
Natural resources: coal, lignite, natural
gas, iron ore, copper, nickel, uranium,
potash, salt, construction materials,
timber, arable land
250','cc971b5ede4b2f18077366a3ae1d30a83b72b6673d0b99e99d5d448856366cb7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('262b4b1b358ee73daae61989c4eb1e2b690742212ea84e4d401af5a527b6a4df',2009,'GI','Gibraltar','geography',543,'Location: Southwestern Europe, bor¬
dering the Strait of Gibraltar, which
links the Mediterranean Sea and the
North Atlantic Ocean, on the southern
coast of Spain
Geographic coordinates: 36 08 N, 5 21 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area — comparative: a little less than
one half the size of Rhode Island
Land boundaries:
total: 1.2 km
border countries: Spain 1.2 km
Coastline: 12 km
Maritime claims: territorial sea: 3 nm
Climate: Mediterranean with mild win¬
ters and warm summers
Terrain: a narrow coastal lowland borders
the Rock of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: limited
natural freshwater resources: large con¬
crete or natural rock water catchments
collect rainwater (no longer used for
drinking water) and adequate desalina¬
tion plant
Geography — note: strategic location on
Strait of Gibraltar that links the North
Atlantic Ocean and Mediterranean Sea
Population: 28,002 (July 2008 est.)
Age structure:
0-14 years: 16.9% (male 2,426/female
2,309)
15-64 years: 66.6 % (male 9,507/female
9,153)
65 years and over: 16.5% (male
2,103/female 2,504) (2008 est.)
Median age:
total: 40.3 years
male: 39.8 years
female: 40.7 years (2008 est.)
Population growth rate: 0.125% (2008 est.)
Birth rate: 10.71 births/1,000 population
(2008 est.)
Death rate: 9.46 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 0 migrant(s)/l,000
population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.01 male(s)/female
(2008 est.)
Infant mortality rate:
total: 4.91 deaths/1,000 live births
male: 5.46 deaths/1,000 live births
female: 4.33 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 80.06 years
male : 77.17 years
female: 83.09 years (2008 est.)
Total fertility rate: 1.65 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality: noun: Gibraltarian(s)
adjective: Gibraltar
257
THE CIA WORLD FACTBOOK
Ethnic groups: Spanish, Italian, English,
Maltese, Portuguese, German, North
Africans
Religions: Roman Catholic 78.1%,
Church of England 7%, other Christian
3.2%, Muslim 4%, Jewish 2.1%, Hindu
1.8%, other or unspecified 0.9%, none
2.9% (2001 census)
Languages: English (used in schools and
for official purposes), Spanish, Italian,
Portuguese
Literacy:
definition: NA
total population: above 80%
male: NA
female: NA
Country name:
conventional long form: none
conventional short form: Gibraltar
Dependency status: overseas territory of
the UK
Government type: NA
Capital: name: Gibraltar
geographic coordinates: 36 08 N, 5 21 W
time difference: UTC+1 (6 hours ahead of
Washington, DC during Standard Time)
daylight saving time: +lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: none (oven
seas territory of the UK)
Independence: none (overseas territory
of the UK)
National holiday: National Day, 10
September (1967); note — day of the
national referendum to decide whether
to remain with the UK or go with Spain
Constitution: 5 June 2006; came into
force 2 January 2007
Legal system: the laws of the UK, where
applicable, apply
Suffrage: 18 years of age; universal; and
British citizens who have been residents
six months or more
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); represented by
Governor Sir Robert FULTON (since 27
October 2006)
head of government: Chief Minister Peter
CARUANA (since 17 May 1996)
cabinet: Council of Ministers appointed
from among the 17 elected members of
the Parliament by the governor in con-
sultation with the chief minister
elections: the monarch is hereditary; gov-
ernor appointed by the monarch; fob
lowing legislative elections, the leader of
the majority party or the leader of the
majority coalition is usually appointed
chief minister by the governor
Legislative branch: unicameral
Parliament (18 seats: 17 members
elected by popular vote, 1 for the
Speaker appointed by Parliament; to
serve four-year terms)
elections: last held 1 1 October 2007 (next
to be held not later than October 2011)
election results: percent of vote by party —
GSD 49.3%, GSLP 31.8%, Gibraltar
Liberal Party 13.6%; seats by party —
GSD 10, GSLP 4, Gibraltar Liberal Party
3
Judicial branch: Supreme Court; Court
of Appeal
Political parties and leaders: Gibraltar
Liberal Party [Joseph GARCIA];
Gibraltar Social Democrats or GSD
[Peter CARUANA]; Gibraltar Socialist
Labor Party or GSLP [Joseph John
BOSSANO]
Political pressure groups and leaders:
Chamber of Commerce; Gibraltar
Representatives Organization; Women’s
Association
International organization participa¬
tion: Interpol (subbureau), UPU
Diplomatic representation in the US:
none (overseas territory of the UK)
Diplomatic representation from the US:
none (overseas territory of the UK)
Flag description: two horizontal bands
of white (top, double width) and red
with a three-towered red castle in the
center of the white band; hanging from
the castle gate is a gold key centered in
the red band','df51591b9256dd59afe4103e6b241b9852bae360d82f09bdd9aed727a9a9fbd5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b10b2309cb5f04fc0a3780a3e722c10aa7f0b15f2e57bc46e1d0fdf5eedaf1a1',2009,'GR','Greece','geography',549,'Location: Southern Europe, bordering
the Aegean Sea, Ionian Sea, and the
Mediterranean Sea, between Albania
and Turkey
Geographic coordinates: 39 00 N, 22 00
E
Map references: Europe
Area:
total: 131,940 sq km
land: 130,800 sq km
water: 1,140 sq km
Area — comparative: slightly smaller
than Alabama
Land boundaries:
total: 1,228 km
border countries: Albania 282 km,
Bulgaria 494 km, Turkey 206 km,
Macedonia 246 km
Coastline: 13,676 km
Maritime claims:
territorial sea: 12 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: temperate; mild, wet winters;
hot, dry summers
Terrain: mostly mountains with ranges
extending into the sea as peninsulas or
chains of islands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: lignite, petroleum,
iron ore, bauxite, lead, zinc, nickel, mag¬
nesite, marble, salt, hydropower poten¬
tial
Land use:
arable land: 20.45%
permanent crops: 8.59%
other: 70.96% (2005)
Irrigated land: 14,530 sq km (2003)
Total renewable water resources: 72 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 8.7 cu
km/yr (16%/3%/81%)
per capita: 782 cu m/yr (1997)
259
THE CIA WORLD FACTBOOK
Natural hazards: severe earthquakes
Environment— current Issues: air pollu¬
tion; water pollution
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air
Pollution-Volatile Organic Compounds
Geography— note: strategic location
dominating the Aegean Sea and
southern approach to Turkish Straits; a
peninsular country, possessing an archi¬
pelago of about 2,000 islands
Population: 10,722,816 (July 2008 est.)
Age structure:
0-14 years : 14-3% (male 789,137/female
742,469)
15-64 years: 66.6% (male
3,568,101/female 3,575,572)
65 years and over: 19.1% (male
898,337/female 1,149,200) (2008 est.)
Median age:
total: 41.5 years
male: 40.4 years
female: 42.6 years (2008 est.)
Population growth rate: 0.146% (2008
est.)
Birth rate: 9.54 births/1,000 population
(2008 est.)
Death rate: 10.42 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 2.33 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 5.25 deaths/1,000 live births
male: 5.77 deaths/ 1,000 live births
female: 4-7 deaths/1,000 live births (2008
est.)
Life expectancy at birth:
total population: 79.52 years
male: 76.98 years
female: 82.21 years (2008 est.)
Total fertility rate: 1.36 children
bom/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.2%
(2001 est.)
HIV/AIDS — people living with
HIV/AIDS: 9,100 (2001 est.)
HIV/AIDS — deaths: fewer than 100
(2003 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Population: Greek 93%,
other (foreign citizens) 7% (2001
census)
note: percents represent citizenship,
since Greece does not collect data on
ethnicity
Religions: Greek Orthodox 98%,
Muslim 1.3%, other 0.7%
Languages: Greek 99% (official), other
1% (includes English and French)
Literacy:
definition: age 15 and over can read and
write
total population: 96%
male: 97.8%
female: 94-2% (2001 census)
Geographic coordinates: 41 50 N, 22 00
E
Map references: Europe
Area:
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area — comparative: slightly larger than
Vermont
Land boundaries:
total: 766 km
border countries: Albania 151 km,
Bulgaria 148 km, Greece 246 km,
Kosovo 159 km, Serbia 62 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: warm, dry summers and
autumns; relatively cold winters with
heavy snowfall
Terrain: mountainous territory covered
with deep basins and valleys; three large
396
MACEDONIA
lakes, each divided by a frontier line;
country bisected by the Vardar River
Elevation extremes:
lowest point: Vardar River 50 m
highest point: Golem Korab (Maja e
Korabit) 2,764 m
Natural resources: low-grade iron ore,
copper, lead, zinc, chromite, manganese,
nickel, tungsten, gold, silver, asbestos,
gypsum, timber, arable land
Land use: arable land: 22.01%
permanent crops: 1.79%
other: 76.2% (2005)
Irrigated land: 550 sq km (2003)
Total renewable water resources: 6.4
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.27
per capita: 1,118 cu m/yr (2000)
Natural hazards: high seismic risks
Environment — current issues: air pollu¬
tion from metallurgical plants
Environment — international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; major
transportation corridor from Western
and Central Europe to Aegean Sea and
Southern Europe to Western Europe','b86bfa954c902ee6e5bdcfb29238a020e80a1c2088803afd49f7f2f0634eeb54','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('895c55c2d313b93ca971286868c9f85d461cc678a2df5bd9503ff5884afd63ec',2009,'IT','Italy','geography',553,'Location: Northern North America, island
between the Arctic Ocean and the North
Atlantic Ocean, northeast of Canada
262','2a472c95966d682404e1e7751face5e1d11fbb4f5f524d1d69e9e0dcc6802d37','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbc03699537ee62566c7349dfdcb4f834e548a301f03fc295eed3c6a17dc1638',2009,'GU','Guam','geography',561,'Location: Oceania, island in the North
Pacific Ocean, about three-quarters of
the way from Hawaii to the Philippines
Geographic coordinates: 13 28 N, 144
47 E
Map references: Oceania
Area: total: 541.3 sq km
land: 541.3 sq km
water: 0 sq km
Area — comparative: three times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; generally
warm and humid, moderated by north¬
east trade winds; dry season (January to
June), rainy season (July to December);
little seasonal temperature variation
Terrain: volcanic origin, surrounded by
coral reefs; relatively flat coralline lime¬
stone plateau (source of most fresh
water), with steep coastal cliffs and
narrow coastal plains in north, low hills
in center, mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: aquatic wildlife (sup¬
porting tourism), fishing (largely unde¬
veloped)
Land use:
arable land: 3.64%
permanent crops : 18.18%
other: 78.18% (2005)
Irrigated land: NA
Natural hazards: frequent squalls during
rainy season; relatively rare, but poten¬
tially very destructive typhoons (June —
December)
267
THE CIA WORLD FACTBOOK
Environment— current issues: extirpa¬
tion of native bird population by the
rapid proliferation of the brown tree
snake, an exotic, invasive species
Geography— note: largest and southern¬
most island in the Mariana Islands archi¬
pelago; strategic location in western
North Pacific Ocean
Population: 175,877 (July 2008 est.)
Age structure:
0-14 years: 28.2% (male 25,644/female
23,910)
15-64 years: 64.8% (male 58,034/female
55,900)
65 years and over: 7% (male 5,801/female
6,588) (2008 est.)
Median age:
total: 28.9 years
male: 28.7 years
female: 29.2 years (2008 est.)
Population growth rate: 1.373% (2008
est.)
Birth rate: 18.37 births/1,000 population
(2008 est.)
Death rate: 4.65 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio: at birth: 1.06 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.04 male(s)/female
(2008 est.)
infant mortality rate:
total: 6.55 deaths/1,000 live births
male: 7.22 deaths/ 1,000 live births
female: 5.84 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 78.93 years
male: 75.86 years
female: 82.19 years (2008 est.)
Total fertility rate: 2.55 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS — deaths: NA
Nationality:
noun: Guamanian(s) (US citizens)
adjective: Guamanian
Ethnic groups: Chamorro 37.1%,
Filipino 26.3%, other Pacific islander
11.3%, white 6.9%, other Asian 6.3%,
other ethnic origin or race 2.3%, mixed
9.8% (2000 census)
Religions: Roman Catholic 85%, other
15% (1999 est.)
Languages: English 38.3%, Chamorro
22.2%, Philippine languages 22.2%,
other Pacific island languages 6.8%,
Asian languages 7%, other languages
3.5% (2000 census)
Literacy:
definition: age 15 and over can read and
write
total population: 99%
male: 99%
female: 99% (1990 est.)','5b811c135a4c7f3c1ac751822cbeda7be53dcc39c33c2ac88e8e3786d29ac346','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24ad67648ae4721f39fd1e0f7a91cd1316b68fe5a7f32c44c81c0d9e7731470',2009,'GY','Guyana','geography',588,'Location: Caribbean, western one-third
of the island of Hispaniola, between the
Caribbean Sea and the North Atlantic
Ocean, west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 w
Map references: Central America and
the Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
Area— comparative: slightly smaller
than Maryland
Land boundaries:
total: 360 km
border countries: Dominican Republic
360 km
Coastline: 1,771 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical; semiarid where moun¬
tains in east cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: bauxite, copper, cal¬
cium carbonate, gold, marble,
hydropower
Land use:
arable land: 28.11%
permanent crops : 11.53%
other: 60.36% (2005)
Irrigated land: 920 sq km (2003)
Total renewable water resources: 14 cu
km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total 0.99 cu
km/yr (5%/l%/94%)
per capita: 116 cu m/yr (2000)
Natural hazards: lies in the middle of
the hurricane belt and subject to severe
storms from June to October; occasional
flooding and earthquakes; periodic
droughts
Environment— current issues: exten¬
sive deforestation (much of the
remaining forested land is being cleared
for agriculture and used as fuel); soil ero¬
sion; inadequate supplies of potable
water
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea,
Marine Dumping, Marine Life
Conservation, Ozone Layer Protection
signed, but not ratified: Hazardous Wastes
Geography — note: shares island of
Hispaniola with Dominican Republic
(western one-third is Haiti, eastern two-
thirds is the Dominican Republic)
?APHY
_
Location: Northern Africa, bordering
the Mediterranean Sea, between Algeria
and Libya
Geographic coordinates: 34 00 N, 9 00
E
Map references: Africa
Area:
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Area— comparative: slightly larger than
Geographic coordinates: 8 00 N, 66 00
W
Map references: South America
Area: total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area — comparative: slightly more than
twice the size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km,
Colombia 2,050 km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 15 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: tropical; hot, humid; more
moderate in highlands
Terrain: Andes Mountains and
Maracaibo Lowlands in northwest; cen¬
tral plains (llanos); Guiana Highlands in
southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna)
5,007 m
Natural resources: petroleum, natural
gas, iron ore, gold, bauxite, other min¬
erals, hydropower, diamonds
Land use:
arable land: 2.85%
permanent crops: 0.88%
other: 96.27% (2005)
Irrigated land: 5,750 sq km (2003)
698
VENEZUELA
Total renewable water resources:
1,233.2 cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 8.37 cu
km/yr (6%/7%/47%)
per capita: 313 cu m/yr (2000)
Natural hazards: subject to floods, rock-
slides, mudslides; periodic droughts
Environment — current issues: sewage
pollution of Lago de Valencia; oil and
urban pollution of Lago de Maracaibo;
deforestation; soil degradation; urban
and industrial pollution, especially along
the Caribbean coast; threat to the rain¬
forest ecosystem from irresponsible
mining operations
Environment— international agree¬
ments: party to: Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands
signed but not ratified:: none of the
selected agreements
Geography — note: on major sea and air
routes linking North and South
America; Angel Falls in the Guiana
Highlands is the world’s highest waterfall
Location: Southeastern Asia, bordering
the Gulf of Thailand, Gulf of Tonkin,
and South China Sea, alongside China,
Laos, and Cambodia
Geographic coordinates: 16 00 N, 106
00 E
Map references: Southeast Asia
Area:
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area — comparative: slightly larger than
New Mexico
Land boundaries:
total: 4,639 km
border countries: Cambodia 1,228 km,
China 1,281 km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf : 200 nm or to the edge of
the continental margin
Climate: tropical in south; monsoonal in
north with hot, rainy season (May to
September) and warm, dry season
(October to March)
Terrain: low, flat delta in south and
north; central highlands; hilly, moun¬
tainous in far north and northwest
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Fan Si Pan 3,144 m
Natural resources: phosphates, coal,
manganese, bauxite, chromate, offshore
oil and gas deposits, forests, hydropower
Land use:
arable land: 20.14%
permanent crops : 6.93%
other: 72.93% (2005)
Irrigated land: 30,000 sq km (2003)
Total renewable water resources: 891.2
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 71.39 cu
km/yr (8%/24%/68%)
per capita: 847 cu m/yr (2000)
Natural hazards: occasional typhoons
(May to January) with extensive
flooding, especially in the Mekong River
delta
Environment — current issues: logging
and slash-and-burn agricultural practices
contribute to deforestation and soil
degradation; water pollution and over¬
fishing threaten marine life populations;
groundwater contamination limits
potable water supply; growing urban
industrialization and population migra¬
tion are rapidly degrading environment
in Hanoi and Ho Chi Minh City
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: extending 1,650 km
north to south, the country is only 50 km
across at its narrowest point
Location: Caribbean, islands between
the Caribbean Sea and the North
Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 20 N, 64 50
W
Map references: Central America and
the Caribbean
Area: total: 1,910 sq km
land: 346 sq km
water: 1,564 sq km
Area — comparative: twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: subtropical, tempered by east¬
erly trade winds, relatively low humidity,
little seasonal temperature variation;
rainy season September to November
Terrain: mostly hilly to rugged and
mountainous with little level land
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 475 m
Natural resources: sun, sand, sea, surf
Land use: arable land: 5.71%
permanent crops: 2.86%
other: 91.43% (2005)
705
THE CIA WORLD FACTBOOK
Irrigated land: NA
Natural hazards: several hurricanes in
recent years; frequent and severe
droughts and floods; occasional earth''
quakes
Environment — current issues: lack of
natural freshwater resources
Geography — note: important location
along the Anegada Passage — a key ship-
ping lane for the Panama Canal; Saint
Thomas has one of the best natural deep¬
water harbors in the Caribbean
Population: 108,210 (July 2008 est.)
Age structure:
0-14 years: 21.2% (male 11,546/female
11,354)
15-64 years: 66.4% (male 34,096/female
37,760)
65 years and over: 12.4% (male
5,961/female 7,493) (2008 est.)
Median age:
total: 38.3 years
male: 37.2 years
female: 39.1 years (2008 est.)
Population growth rate: -0.27% (2008
est.)
Birth rate: 13.43 births/1,000 population
(2008 est.)
Death rate: 6.79 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -9.33 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.91 male(s)/female
(2008 est.)
Infant mortality rate:
total: 7.53 deaths/1,000 live births
male: 8.57 deaths/1,000 live births
female: 6.43 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 79.34 years
male: 75.56 years
female: 83.35 years (2008 est.)
Total fertility rate: 2.14 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Virgin Islander(s) (US citizens)
adjective: Virgin Islander
Ethnic groups: black 76.2%, white
13.1%, Asian 1.1%, other 6.1%, mixed
3.5% (2000 census)
Religions: Baptist 42%, Roman
Catholic 34%, Episcopalian 17%, other
7%
Languages: English 74.7%, Spanish or
Spanish Creole 16.8%, French or French
Creole 6.6%, other 1.9% (2000 census)
Literacy:
definition: age 15 and over can read and
write
total population: 90-95% est.
male: NA%
female: NA% (2005 est.)','c083277ea3cf70043f28425fc159128850ea3ff8e378161d907bbbdfba3701a0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eaa07cda6338bcc29992fb650bfe9be36b713322364cd418eeaac9bb0cb8039',2009,'HM','Heard Island and McDonald Islands','geography',594,'Location: islands in the Indian Ocean,
about two-thirds of the way from
Madagascar to Antarctica
Geographic coordinates: 53 06 S, 72 31
E
Map references: Antarctic Region
Area:
total: 412 sq km
land: 412 sq km
water: 0 sq km
Area— comparative: slightly more than
two times the size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: antarctic
Terrain: Heard Island — 80% ice-cov¬
ered, bleak and mountainous, dominated
by a large massif (Big Ben) and an active
volcano (Mawson Peak); McDonald
Islands — small and rocky
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mawson Peak, on Big Ben
2,745 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: Mawson Peak, an
active volcano, is on Heard Island
Environment — current issues: NA
Geography — note: Mawson Peak on
Heard Island is the highest Australian
mountain (at 2,745 meters, it is taller
than Mt. Kosciuszko in Australia
proper), and one of only two active vol¬
canoes located in Australian territory,
the other being McDonald Island; in
1992, McDonald Island broke its dor¬
mancy and began erupting; it has erupted
several times since, the most recent
being in 2005
Location: Southern Europe, an enclave
of Rome (Italy)
Geographic coordinates: 41 54 N, 12 27
E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
Area — comparative: about 0.7 times the
size of The Mall in Washington, DC
Land boundaries:
total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters
(September to May) with hot, dry sum¬
mers (May to September)
Terrain: urban; low hill
Elevation extremes:
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (urban area) (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Environment— international agree¬
ments: party to: Climate Change
signed, but not ratified: Air Pollution,
Environmental Modification
Geography — note: landlocked; enclave
in Rome, Italy; world’s smallest state;
beyond the territorial boundary of
Vatican City, the Lateran Treaty of 1929
grants the Holy See extraterritorial
authority over 23 sites in Rome and five
outside of Rome, including the Pontifical
Palace at Castel Gandolfo (the Pope’s
summer residence)','af4460af2e3e62b3e747b3f8b10fc621c333406f338f34ab941f2ac6f0cf9202','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e81c2cbeb4366bf99118263456df4e4e8947d0d404138908b7f490fa836e8a82',2009,'NI','Nicaragua','geography',603,'Location: Central America, bordering
the Caribbean Sea, between Guatemala
and Nicaragua and bordering the Gulf of
Fonseca (North Pacific Ocean), between
El Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30
w
Map references: Central America and
the Caribbean
Area:
total: 11 2,090 sq km
land: 111,890 sq km
water: 200 sq km
Area — comparative: slightly larger than
Tennessee
Land boundaries:
total: 1,520 km
border countries: Guatemala 256 km, El
Salvador 342 km, Nicaragua 922 km
Coastline: 820 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: natural extension of ter¬
ritory or to 200 nm
Climate: subtropical in lowlands, tem¬
perate in mountains
Terrain: mostly mountains in interior,
narrow coastal plains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver,
copper, lead, zinc, iron ore, antimony,
coal, fish, hydropower
Land use:
arable land: 9.53%
permanent crops : 3.21%
other: 87.26% (2005)
Irrigated land: 800 sq km (2003)
Total renewable water resources: 95.9
cu km (2000)
288
Location: Central America, bordering
both the Caribbean Sea and the North
Pacific Ocean, between Costa Rica and','6a586c6f15db8b550edf61923de4d9c3cfa8f4a629749ad0c469201af3ac0e58','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d3754a8a6a15ac8cebc39b8b0888daf214a85e57535e922f0d57967899b7b2',2009,'HN','Honduras','geography',604,'Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.86 cu
km/yr (8%/12%/80%)
per capita: 119 cu m/yr (2000)
Natural hazards: frequent, but generally
mild, earthquakes; extremely susceptible
to damaging hurricanes and floods along
the Caribbean coast
Environment— current issues: urban
population expanding; deforestation
results from logging and the clearing of
land for agricultural purposes; further
land degradation and soil erosion has¬
tened by uncontrolled development and
improper land use practices such as
farming of marginal lands; mining activ¬
ities polluting Lago de Yojoa (the
country’s largest source of fresh water), as
well as several rivers and streams, with
heavy metals
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: has only a short
Pacific coast but a long Caribbean shore¬
line, including the virtually uninhabited
eastern Mosquito Coast
Geographic coordinates: 13 00 N, 85 00
W
Map references: Central America and
the Caribbean
Area:
total: 129,494 sq km
land: 120,254 sq km
water: 9,240 sq km
Area — comparative: slightly smaller
than the state of New York
Land boundaries:
total: 1,231 km
border countries: Costa Rica 309 km,
Honduras 922 km
Coastline: 910 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: natural prolongation
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive Atlantic coastal plains
rising to central interior mountains;
narrow Pacific coastal plain interrupted
by volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper,
tungsten, lead, zinc, timber, fish
Land use:
arable land: 14-81%
permanen t crops : 1.82%
other: 83.37% (2005)
Irrigated land: 610 sq km (2003)
Total renewable water resources: 196.7
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.3 cu
km/yr (15%/2%/83%)
per capita: 237 cu m/yr (2000)
Natural hazards: destructive earth¬
quakes, volcanoes, landslides; extremely
susceptible to hurricanes
Environment— current issues: defor¬
estation; soil erosion; water pollution
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Environmental
Modification
Geography— note: largest country in
Central America; contains the largest
freshwater body in Central America,
Lago de Nicaragua
Population: 5,785,846 (July 2008 est.)
Age structure:
0-14 years: 34.6% (male
1,019,281/female 981,903)
15-64 years: 62.1% (male
1,792,398/female 1,803,133)
65 years and over: 3.3% (male
82,840/female 106,291) (2008 est.)
Median age: total: 21.7 years
male: 21.3 years
female: 22.1 years (2008 est.)
Population growth rate: 1.825% (2008
est.)
Birth rate: 23.7 births/1,000 population
(2008 est.)
Death rate: 4.33 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -1.13 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total : 25.91 deaths/1,000 live births
male: 29.06 deaths/1,000 live births
female: 22.6 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 71.21 years
male: 69.08 years
female: 73.44 years (2008 est.)
Total fertility rate: 2.63 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.2%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 6,400 (2003 est.)
HiV/AIDS— deaths: fewer than 500
(2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorborne disease: dengue fever and
malaria
water contact disease : leptospirosis (2008)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic groups: mestizo (mixed
Amerindian and white) 69%, white
17%, black 9%, Amerindian 5%
Religions: Roman Catholic 72.9%,
Evangelical 15.1%, Moravian 1.5%,
Episcopal 0.1%, other 1.9%, none 8.5%
(1995 census)
Languages: Spanish 97.5% (official),
Miskito 1.7%, other 0.8% (1995 census)
note: English and indigenous languages
on Atlantic coast
Literacy:
definition: age 15 and over can read and
write
total population: 67.5%
male: 67.2%
female: 67.8% (2003 est.)','f8c2a5e75a7292649b5794e78f113423d70b4f99a2a2bc32a0f2cb50a770dfdb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e78206cc6f805347b7457f8b678ed453fb2922a86a78d31d957aff0135c4219a',2009,'HK','Hong Kong','geography',612,'Location: Eastern Asia, bordering the
South China Sea and China
Geographic coordinates: 22 15 N, 114
10 E
Map references: Southeast Asia
Area: total: 1,092 sq km
land: 1,042 sq km
water: 50 sq km
Area — comparative: six times the size of
Washington, DC
Land boundaries:
total: 30 km
regional border: China 30 km
291
THE CIA WORLD FACTBOOK
Coastline: 733 km
Maritime Claims: territorial sea: 3 nm
Climate: subtropical monsoon; cool and
humid in winter, hot and rainy from
spring through summer, warm and sunny
in fall
Terrain: hilly to mountainous with steep
slopes; lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deep¬
water harbor, feldspar
Land use:
arable land: 5.05%
permanent crops : 1.01%
other: 93.94% (2001)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: occasional typhoons
Environment — current issues: air and
water pollution from rapid urbanization
Environment— international agree¬
ments: party to: Marine Dumping (asso¬
ciate member), Ship Pollution (associate
member)
Geography— note: more than 200
islands
Population: 7,018,636 (July 2008 est.)
Age structure:
0-14 years: 12.6% (male 463,300/female
422,945)
15-64 years: 74.4% (male
2,535,246/female 2,684,495)
65 years and over: 13% (male
425,500/female 487,150) (2008 est.)
Median age:
total: 41.7 years
male: 41-4 years
female: 42 years (2008 est.)
Population growth rate: 0.532% (2008
est.)
Birth rate: 7.37 births/1,000 population
(2008 est.)
Death rate: 6.6 deaths/1 ,000 population
(2008 est.)
Net migration rate: 4.55 migrant(s)/
1,000 population (2008 est.)
Sex ratio: at birth: 1.08 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.95 male(s)/female
(2008 est.)
Infant mortality rate:
total: 2.93 deaths/1,000 live births
male: 3.11 deaths/1,000 live births
female: 2.73 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 81.77 years
male: 79.07 years
female: 84-69 years (2008 est.)
Total fertility rate: 1 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.1%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 2,600 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Chinese/Hong Konger
adjective: Chinese/Hong Kong
Ethnic groups: Chinese 94.9%, Filipino
2.1%, other 3% (2001 census)
Religions: eclectic mixture of local reli¬
gions 90%, Christian 10%
Languages: Chinese (Cantonese) 89.2%
(official), other Chinese dialects 6.4%,
English 3.2% (official), other 1.2%
(2001 census)
Literacy:
definition: age 15 and
attended school
total population: 93.5%
male: 96.9%
female: 89.6% (2002)
over
has
ever','a461ff65a3f97bade91237f0a10caa9378b815fe14679ef5890d8609f4cb9d33','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23ff528529d64d56edc0dfb3356aa685c43072261be931bbf3334302359405e3',2009,'RO','Romania','geography',617,'Location: Central Europe, northwest of
Geographic coordinates: 47 00 N, 20 00
E
294
Geographic coordinates: 47 00 N, 29 00 E
Map references: Europe
Area:
total: 33,843 sq km
land: 33,371 sq km
water: 472 sq km
Area — comparative: slightly larger than
Maryland
Land boundaries:
total: 1,389 km
border countries: Romania 450 km,
Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: moderate winters, warm sum¬
mers
Terrain: rolling Steppe, gradual slope
south to Black Sea
Elevation extremes:
lowest point: Dniester River 2 m
highest point: Dealul Balanesti 430 m
Natural resources: lignite, phosphorites,
gypsum, arable land, limestone
Land use:
arable land: 54-52%
permanent crops : 8.81%
other: 36.67% (2005)
Irrigated land: 3,000 sq km (2003)
Total renewable water resources: 11.7
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.31 cu
km/yr (10%/58%/33%)
per capita: 549 cu m/yr (2000)
Natural hazards: landslides
Environment — current issues: heavy
use of agricultural chemicals, including
banned pesticides such as DDT, has con¬
taminated soil and groundwater; exten¬
sive soil erosion from poor farming
methods
433
THE CIA WORLD FACTBOOK
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Persistent Organic Pollutants,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: landlocked; well
endowed with various sedimentary rocks
and minerals including sand, gravel,
gypsum, and limestone
Population: 4,324,450 (July 2008 est.)
Age structure:
0-14 years: 16.3% (male 361,000/female
341,785)
15-64 years: 72.9% (male
1,528,080/female 1,622,620)
65 years and over: 10.9% (male
174,448/female 296,517) (2008 est.)
Median age: total: 34.3 years
male: 32.4 years
female: 36.4 years (2008 est.)
Population growth rate: -0.092% (2008
est.)
Birth rate: 11.01 births/ 1,000 population
(2008 est.)
Death sOte: 10.8 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -1.13 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female
(2008 est.)
Infant mortality rate:
total: 13.5 deaths/1,000 live births
male: 14.95 deaths/1,000 live births
female: 11.96 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 70.5 years
male: 66.81 years
female: 74.41 years (2008 est.)
Total fertility rate: 1.26 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.2%
(2001 est.)
HIV/AIDS — people living with
HIV/AIDS: 5,500 (2001 est.)
HIV/AIDS— deaths: fewer than 300
(2001 est.)
Nationality: noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldovan/Romanian
78.2%, Ukrainian 8.4%, Russian 5.8%,
Gagauz 4*4%, Bulgarian 1.9%, other
1.3% (2004 census)
note: internal disputes with ethnic Slavs
in the Transnistrian region
Religions: Eastern Orthodox 98%,
Jewish 1.5%, Baptist and other 0.5%
(2000)
Languages: Moldovan (official, virtually
the same as the Romanian language),
Russian, Gagauz (a Turkish dialect)
Literacy: definition: age 15 and over can
read and write
total population: 99.1%
male: 99.7%
female: 98.6 % (2005 est.)
Country name:
conventional long form: Republic of
Moldova
conventional short form: Moldova
local long form: Republica Moldova
local short form: Moldova
former: Moldavian Soviet Socialist
Republic, Moldovan Soviet Socialist
Republic
Government type: republic
Capital: name: Chisinau (Kishinev)
note: pronounced kee-shee-now
geographic coordinates: 47 00 N, 28 51 E
time difference: UTC+2 (7 hours ahead of
Washington, DC during Standard Time)
daylight saving time: +lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: 32 raions
(raioane, singular — raionul), 3 munici¬
palities (municipiul), 1 autonomous ter¬
ritorial unit (unitatea teritoriala
autonoma), and 1 territorial unit (uni¬
tatea teritoriala)
raions: Anenii Noi, Basarabeasca,
Briceni, Cahul, Cantemir, Calarasi,
Causeni, Cimislia, Criuleni, Donduseni,
Drochia, Dubasari, Edinet, Falesti,
Floresti, Glodeni, Hincesti, Ialoveni,
Leova, Nisporeni, Ocnita, Orhei, Rezina,
Riscani, Singerei, Soldanesti, Soroca,
Stefan-Voda, Straseni, Taraclia,
Telenesti, Ungheni
municipalities: Balti, Bender, Chisinau
autonomous territorial unit: Gagauzia
territorial unit: Stinga Nistrului
Independence: 27 August 1991 (from
Soviet Union)
National holiday: Independence Day, 27
August (1991)
Constitution: new constitution adopted
29 July 1994, effective 27 August 1994;
replaced old Soviet constitution of 1979
Legal system: based on civil law system;
Constitutional Court reviews legality of
legislative acts and governmental deci¬
sions of resolution; accepts many UN
and Organization for Security and
Cooperation in Europe (OSCE) docu¬
ments; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Vladimir
VORONIN (since 4 April 2001)
head of government: Prime Minister
Zinaida GRECEANII (since 31 March
2008); First Deputy Prime Minister Igor
DODON (since 31 March 2008)
cabinet: Cabinet selected by president,
subject to approval of Parliament
elections: president elected by Parliament
for a four-year term (eligible for a second
term); election last held 4 April 2005
(next to be held in 2009); note — prime
minister designated by the president
upon consultation with Parliament;
within 15 days from designation, the
prime minister-designate must request a
vote of confidence from the Parliament
regarding his/her work program and
entire cabinet; prime minister designated
21 March 2008; cabinet received a vote
of confidence 3 1 March 2008
election results: Vladimir VORONIN
reelected president; parliamentary
votes — Vladimir VORONIN 75,
Gheorghe DUCA 1; Zinaida GRE¬
CEANII designated prime minister; par¬
liamentary votes of confidence — 56 of
101
Legislative branch: unicameral
Parliament or Parlamentul (101 seats;
434
MOLDOVA
parties and electoral blocs elected by
popular vote to serve four-year terms)
elections: last held 6 March 2005 (next to
be held in 2009)
election results: percent of vote by party —
PCRM 46.1%, Democratic Moldova
Bloc (AMN, PD, PSL) 28.4%, PPCD
9.1%, other parties 16.4%; seats by
party — PCRM 56, Democratic Moldova
Bloc (AMN, PD, PSL) 34, PPCD 11
Judicial branch: Supreme Court;
Constitutional Court (the sole authority
for constitutional judicature)
Political parties and leaders: Christian
Democratic People’s Party or PPCD
[lurie ROSC A]; Communist Party of the
Republic of Moldova or PCRM
[Vladimir VORONIN]; Democratic
Party or PD [Dumitru DIACOV]; Liberal
Democratic Party or PLDM [Vladmir
FILAT]; National Liberal Party or PNL
[Vitalia PAVLICENKO]; Our Moldova
Alliance or AMN [Serafim URE-
CHEAN]; Party for Social Democracy or
PDSM [Dumitru BRAGHIS]; Social
Liberal Party or PSL [Oleg SERE-
BRIAN]
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACCT, BSEC, CE, CEI, CIS,
EAEC (observer), EAPC, EBRD, FAO,
GCTU, GUAM, IAEA, IBRD, ICAO,
ICCt (signatory), IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Interpol, IOC,
IOM, IPU, ISO (correspondent), ITU,
MIGA, OIF, OPCW, OSCE, PFP, SECI,
UN, UNCTAD, UNESCO, UNIDO,
Union Latina, UNMIL, UNMIS,
UNOCI, UNOMIG, UN WTO, UPU,
WCO, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Nicolae
CHIRTOACA
chancery: 2101 S Street NW,
Washington, DC 20008
telephone: [1] (202) 667-1130
FAX: [1] (202) 667-1204
Diplomatic representation from the US:
chief of mission: Ambassador Michael D.
KIRBY
embassy: 103 Mateevici Street, Chisinau
MD-2009
mailing address: use embassy street address
telephone: [373] (22) 40-8300
FAX: [373] (22) 23-3044
Flag description: three equal vertical
bands of blue (hoist side), yellow, and
red; emblem in center of flag is of a
Roman eagle of gold outlined in black
with a red beak and talons carrying a
yellow cross in its beak and a green olive
branch in its right talons and a yellow
scepter in its left talons; on its breast is a
shield divided horizontally red over blue
with a stylized ox head, star, rose, and
crescent all in black-outlined yellow;
same color scheme as Romania
Location: Northern Asia (the area west
of the Urals is considered part of
Europe), bordering the Arctic Ocean,
between Europe and the North Pacific
Ocean
Geographic coordinates: 60 00 N, 100
00 E
Map references: Asia
Area:
total: 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
Area — comparative: approximately 1.8
times the size of the US
Land boundaries:
total: 20,096.5 km
border countries: Azerbaijan 284 km,
Belarus 959 km, China (southeast) 3,605
km, China (south) 40 km, Estonia 294
km, Finland 1,340 km, Georgia 723 km,
537
THE CIA WORLD FACTBOOK
Kazakhstan 6,846 km, North Korea 19
km, Latvia 217 km, Lithuania
(Kaliningrad Oblast) 280.5 km,
Mongolia 3,485 km, Norway 196 km,
Poland (Kaliningrad Oblast) 232 km,
Ukraine 1,576 km
Coastline: 37,653 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200''tn depth or to the
depth of exploitation
Climate: ranges from steppes in the
south through humid continental in
much of European Russia; subarctic in
Siberia to tundra climate in the polar
north; winters vary from cool along
Black Sea coast to frigid in Siberia; sum-
mers vary from warm in the steppes to
cool along Arctic coast
Terrain: broad plain with low hills west
of Urals; vast coniferous forest and
tundra in Siberia; uplands and moun¬
tains along southern border regions
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Gora El’brus 5,633 m
Natural resources: wide natural resource
base including major deposits of oil, nat¬
ural gas, coal, and many strategic min¬
erals, timber
note: formidable obstacles of climate, ter¬
rain, and distance hinder exploitation of
natural resources
Land use:
arable land: 7.17%
permanent crops : 0.11%
other: 92.72% (2005)
Irrigated land: 46,000 sq km (2003)
Total renewable water resources: 4,498
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 76.68 cu
km/yr (19%/63%/18%)
per capita: 535 cu m/yr (2000)
Natural hazards: permafrost over much
of Siberia is a major impediment to
development; volcanic activity in the
Kuril Islands; volcanoes and earthquakes
on the Kamchatka Peninsula; spring
floods and summer/autumn forest fires
throughout Siberia and parts of
European Russia
Environment— current issues: air pollu¬
tion from heavy industry, emissions of
coal-fired electric plants, and transporta¬
tion in major cities; industrial, munic¬
ipal, and agricultural pollution of inland
waterways and seacoasts; deforestation;
soil erosion; soil contamination from
improper application of agricultural
chemicals; scattered areas of sometimes
intense radioactive contamination;
groundwater contamination from toxic
waste; urban solid waste management;
abandoned stocks of obsolete pesticides
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands,
Whaling
signed, but not ratified: Air Pollution-
Sulfur 94
Geography — note: largest country in the
world in terms of area but unfavorably
located in relation to major sea lanes of
the world; despite its size, much of the
country lacks proper soils and climates
(either too cold or too dry) for agricul¬
ture; Mount El’brus is Europe’s tallest
peak','833fafb39743eb30e8227118f031a1a362288eaa089ee99947f780154fd74323','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee3ca23673612b57fbaae84eef0dc40f40c422ee95638ca4a97bb637c7957549',2009,'HU','Hungary','geography',618,'Map references: Europe
Area: total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area— comparative: slightly smaller
than Indiana
Land boundaries:
total: 2,171 km
border countries: Austria 366 km, Croatia
329 km, Romania 443 km, Serbia 151
km, Slovakia 677 km, Slovenia 102 km,
Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid
winters; warm summers
Terrain: mostly flat to rolling plains; hills
and low mountains on the Slovakian
border
Elevation extremes:
lowest point: Tisza River 78 m
highest point: Kekes 1,014 m
Natural resources: bauxite, coal, natural
gas, fertile soils, arable land
Land use:
arable land: 49.58%
permanent crops: 2.06%
other: 48.36% (2005)
Irrigated land: 2,300 sq km (2003)
Total renewable water resources: 120
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 21.03 cu
km/yr (9%/59%/32%)
per capita: 2,082 cu m/yr (2001)
Environment— current issues: the
upgrading of Hungary’s standards in
waste management, energy efficiency,
and air, soil, and water pollution to meet
EU requirements will require large
investments
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kvoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; strategic
location astride main land routes
between Western Europe and Balkan
Peninsula as well as between Ukraine
and Mediterranean basin; the north-
south flowing Duna (Danube) and Tisza
Rivers divide the country into three large
regions
Population: 9,930,915 (July 2008 est.)
Age structure:
0-14 years: 15.2% (male 774,092/female
730,485)
15-64 years: 69.3% (male
3,393,630/female 3,488,011)
65 years and over: 15.6% (male
559,483/female 985,214) (2008 est.)
Median age:
total: 39.1 years
male: 36.8 years
female: 41.8 years (2008 est.)
Population growth rate: -0.254% (2008
est.)
Birth rate: 9.59 births/1,000 population
(2008 est.)
Death rate: 12.99 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 0.86 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.57 male(s)/female
total population: 0.91 male(s)/female
(2008 est.)
Infant mortality rate:
total: 8.03 deaths/1,000 live births
male: 8.74 deaths/1,000 live births
female: 7.29 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 73.18 years
male: 69 years
female: 77.62 years (2008 est.)
Total fertility rate: 1.34 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 0.1%
(2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 2,800 (2001 est.)
HIV/AIDS — deaths: fewer than 100
(2001 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea and hepatitis A
vectorborne diseases: tickborne
encephalitis (2008)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 92.3%, Roma
1.9%, other or unknown 5.8% (2001
census)
Religions: Roman Catholic 51.9%,
Calvinist 15.9%, Lutheran 3%, Greek
Catholic 2.6%, other Christian 1%,
other or unspecified 11.1%, unaffiliated
14.5% (2001 census)
Languages: Hungarian 93.6%, other or
unspecified 6.4% (2001 census)
Literacy: definition: age 15 and over can
read and write
total population: 99.4%
male: 99.5%
female: 99.3% (2003 est.)
Country name:
conventional long form: Republic of
conventional short form: Hungary
local long form: Magyar Koztarsasag
local short form: Magyarorszag
Government type: parliamentary democ¬
racy
Capital: name: Budapest
geographic coordinates: 47 30 N, 19 05 E
time difference: UTC+1 (6 hours ahead of
Washington, DC during Standard Time)
daylight saving time: + lhr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: 19 counties
(megyek, singular — megye), 23 urban
counties (singular — megyei varos), and 1
capital city (fovaros)
counties: Bacs-Kiskun, Baranya, Bekes,
Borsod-Abauj-Zemplen, Csongrad, Fejer,
Gyor-Moson-Sopron, Hajdu-Bihar,
Heves, Jasz-Nagykun-Szolnok, Komarom-
Esztergom, Nograd, Pest, Somogy,
Szabolcs-Szatmar-Bereg, Tolna, Vas,
Veszprem, Zala
urban counties: Bekescsaba, Debrecen,
Dunaujvaros, Eger, Erd, Gyor,
Hodmezovasarhely, Kaposvar,
Kecskemet, Miskolc, Nagykanizsa,
Nyiregyhaza, Pecs, Salgotarjan, Sopron,
Szeged, Szekesfehervar, Szekszard,
Szolnok, Szombathely, Tatabanya,
Veszprem, Zalaegerszeg
capital city: Budapest
Independence: 25 December 1000
(crowning of King STEPHEN I, tradi¬
tional founding date)
National holiday: Saint Stephen’s Day,
20 August
Constitution: 18 August 1949, effective
20 August 1949; revised 19 April 1972; 18
October 1989 revision ensured legal rights
for individuals and constitutional checks
on the authority of the prime minister and
also established the principle of parlia¬
mentary oversight; 1997 amendment
streamlined the judicial system
Legal system: based on the German-
Austrian legal system; accepts compul¬
sory ICJ jurisdiction with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Laszlo SOLYOM
(since 5 August 2005)
head of government: Prime Minister
Ferenc GYURCSANY (since 29
September 2004)
295
THE CIA WORLD FACTBOOK
cabinet: Council of Ministers prime min¬
ister elected by the National Assembly
on the recommendation of the president;
other ministers proposed by the prime
minister and appointed and relieved of
their duties by the president
elections: president elected by the
National Assembly for a five-year term
(eligible for a second term); election last
held 6-7 June 2005 (next to be held by
June 2010); prime minister elected by
the National Assembly on the recom¬
mendation of the president; election last
held 29 September 2004
election results: Laszlo SOLYOM elected
president by a simple majority in the
third round of voting, 185 to 182; Ferenc
GYURCSANY elected prime minister;
result of legislative vote — 197 to 12
note: to be elected, the president must
win two-thirds of legislative vote in the
first two rounds or a simple majority in
the third round
Legislative branch: unicameral
National Assembly or Orszaggyules (386
seats; members are elected by popular
vote under a system of proportional and
direct representation to serve four-year
terms)
elections: last held 9 and 23 April 2006
(next to be held in April 2010)
election results: percent of vote by party
(5% or more of the vote required for par¬
liamentary representation in the first
round)— MSzP 43.2%, Fidesz-KDNP
42%, SzDSz 6.5%, MDF 5%, other 3.3%;
seats by party — MSzP 190, Fidesz-KDNP
164, SzDSz 20, MDF 11, independent 1
Judicial branch: Constitutional Court
(judges are elected by the National
Assembly for nine-year terms)
Political parties and leaders: Alliance
of Free Democrats or SzDSz [Janos
KOKA]; Christian Democratic People’s
Party or KDNP [Zsolt SEMJEN];
Flungarian Civic Alliance or Fidesz
[Viktor ORBAN, chairman]; Hungarian
Democratic Forum or MDF [Ibolya
DAVID]; Hungarian Socialist Party or
MSzP [Ferenc GYURCSANY]
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACCT (observer), Australia
Group, BIS, CE, CEI, CERN, EAPC,
EBRD, EIB, ESA (cooperating state),
EU, FAO, G-9, IAEA, IBRD, ICAO,
ICC, ICCt, 1CRM, IDA, IEA, IFC,
IFRCS, ILO, IMF, IMO, IMSO, Interpol,
IOC, IOM, IPU, ISO, ITSO, ITU,
ITUC, MIGA, MINURSO, NAM
(guest), NATO, NEA, NSG, OAS
(observer), OECD, OIF (observer),
OPCW, OSCE, PC A, Schengen
Convention, SECI, UN, UNCTAD,
UNESCO, UNFICYP, UNHCR,
UNIDO, UNOMIG, UNWTO, UPU,
WCL, WCO, WEU (associate), WFTU,
WHO, WIPO, WMO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Ferenc
SOMOGYI
chancery: 3910 Shoemaker Street NW,
Washington, DC 20008
telephone: [1] (202) 362-6730
FAX: [1] (202) 966-8135
consulate(s) general: Chicago, Los
Angeles, New York
Diplomatic representation from the US:
chief of mission: Ambassador April H.
FOLEY
embassy: Szabadsag ter 12, H-1054
Budapest
mailing address: pouch: American
Embassy Budapest, 5270 Budapest Place,
US Department of State, Washington,
DC 20521-5270
telephone: [36] (1) 475-4400
FAX: [36] (1) 475-4764
Flag description: three equal horizontal
bands of red (top), white, and green','63b1cbe227a0009d39089f4b0f6154738f2511b162d7d6bd0b280b05c976df3a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1bcbfad5fc47a7cac69c507de000e391df36cdb4bc0a267088fb8dfe0f2caa2',2009,'IN','India','geography',628,'Location: Southern Asia, bordering the
Arabian Sea and the Bay of Bengal,
between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00
E
Map references: Asia
Area:
total: 3,287,590 sq km
land: 2,973,190 sq km
water: 314,400 sq km
Area — comparative: slightly more than
one-third the size of the US
Land boundaries:
total: 14,103 km
border countries: Bangladesh 4,053 km,
Bhutan 605 km, Burma 1,463 km, China
3,380 km, Nepal 1,690 km, Pakistan
2,912 km
Coastline: 7,000 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: varies from tropical monsoon
in south to temperate in north
Terrain: upland plain (Deccan Plateau)
in south, flat to rolling plain along the
Ganges, deserts in west, Himalayas in
north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest
reserves in the world), iron ore, man¬
ganese, mica, bauxite, titanium ore,
chromite, natural gas, diamonds, petro¬
leum, limestone, arable land
Land use:
arable land: 48.83%
permanent crops: 2.8%
other: 48.37% (2005)
irrigated land: 558,080 sq km (2003)
Total renewable water resources:
1,907.8 cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 645.84 cu
km/yr (8%/5%/86%)
per capita: 585 cu m/yr (2000)
Natural hazards: droughts; flash floods,
as well as widespread and destructive
flooding from monsoonal rains; severe
thunderstorms; earthquakes
Environment — current issues: defor¬
estation; soil erosion; overgrazing; deser¬
tification; air pollution from industrial
effluents and vehicle emissions; water
pollution from raw sewage and runoff of
agricultural pesticides; tap water is not
potable throughout the country; huge
and growing population is overstraining
natural resources
Environment— international agree¬
ments: party to: Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: dominates South
Asian subcontinent; near important
Indian Ocean trade routes;
Kanchenjunga, third tallest mountain in
the world, lies on the border with Nepal
Location: body of water between Africa,
the Southern Ocean, Asia, and Australia
Geographic coordinates: 20 00 S, 80 00
E
Map references: Political Map of the
World
Area:
total: 68.556 million sq km
note: includes Andaman Sea, Arabian
Sea, Bay of Bengal, Flores Sea, Great
Australian Bight, Gulf of Aden, Gulf of
Oman, Java Sea, Mozambique Channel,
Persian Gulf, Red Sea, Savu Sea, Strait
of Malacca, Timor Sea, and other tribu¬
tary water bodies
Area — comparative: about 5.5 times the
size of the US
Coastline: 66,526 km
Climate: northeast monsoon (December
to April), southwest monsoon (June to
October); tropical cyclones occur during
May/June and October/November in the
northern Indian Ocean and
January/February in the southern Indian
Ocean
Terrain: surface dominated by counter¬
clockwise gyre (broad, circular system of
currents) in the southern Indian Ocean;
unique reversal of surface currents in the
northern Indian Ocean; low atmospheric
pressure over southwest Asia from hot,
rising, summer air results in the south¬
west monsoon and southwest-to-north-
east winds and currents, while high
pressure over northern Asia from cold,
falling, winter air results in the northeast
monsoon and northeast-to-southwest
winds and currents; ocean floor is domi¬
nated by the Mid-Indian Ocean Ridge
and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean
Ridge, and Ninetyeast Ridge
Elevation extremes:
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Natural resources: oil and gas fields,
fish, shrimp, sand and gravel aggregates,
placer deposits, polymetallic nodules
Natural hazards: occasional icebergs
pose navigational hazard in southern
reaches
Environment — current issues: endan¬
gered marine species include the dugong,
seals, turtles, and whales; oil pollution in
the Arabian Sea, Persian Gulf, and Red
Sea
Geography — note: major chokepoints
include Bab el Mandeb, Strait of
Hormuz, Strait of Malacca, southern
access to the Suez Canal, and the
Lombok Strait
Economy — overview: The Indian
Ocean provides major sea routes con¬
necting the Middle East, Africa, and East
Asia with Europe and the Americas. It
carries a particularly heavy traffic of
petroleum and petroleum products from
the oilfields of the Persian Gulf and
Indonesia. Its fish are of great and
growing importance to the bordering
countries for domestic consumption and
export. Fishing fleets from Russia, Japan,
South Korea, and Taiwan also exploit
the Indian Ocean, mainly for shrimp and
tuna. Large reserves of hydrocarbons are
being tapped in the offshore areas of
305
THE CIA WORLD FACTBOOK
Saudi Arabia, Iran, India, and western
Australia. An estimated 40% of the
world’s offshore oil production comes
from the Indian Ocean. Beach sands rich
in heavy minerals and offshore placer
deposits are actively exploited by bor-
dering countries, particularly India,
South Africa, Indonesia, Sri Lanka, and
Thailand.
Ports and terminals: Chennai (Madras;
India), Colombo (Sri Lanka), Durban
(South Africa), Jakarta (Indonesia),
Kolkata (Calcutta; India) Melbourne
(Australia), Mumbai (Bombay; India),
Richards Bay (South Africa)
Location: Southern Asia, bordering the
Arabian Sea, between India on the east
and Iran and Afghanistan on the west
and China in the north
Geographic coordinates: 30 00 N, 70 00
E
Map references: Asia
Area: total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area— comparative: slightly less than
twice the size of California
Land boundaries:
total: 6,774 km
border countries: Afghanistan 2,430 km,
China 523 km, India 2,912 km, Iran 909
km
Coastline: 1,046 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: mostly hot, dry desert; tem¬
perate in northwest; arctic in north
Terrain: flat Indus plain in east; moun¬
tains in north and northwest;
Balochistan plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen)
8,61 1 m
Natural resources: land, extensive nat¬
ural gas reserves, limited petroleum, poor
quality coal, iron ore, copper, salt, lime¬
stone
Land use: arable land: 24-44%
permanent crops: 0.84%
other: 74.72% (2005)
Irrigated land: 182,300 sq km (2003)
Total renewable water resources: 233.8
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 169.39 cu
km/yr (2%/2%/96%)
per capita: 1,072 cu m/yr (2000)
Natural hazards: frequent earthquakes,
occasionally severe especially in north
and west; flooding along the Indus after
heavy rains (July and August)
Environment — current issues: water
pollution from raw sewage, industrial
wastes, and agricultural runoff; limited
natural fresh water resources; most of the
population does not have access to
potable water; deforestation; soil erosion;
desertification
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life
Conservation
Geography— note: controls Khyber Pass
and Bolan Pass, traditional invasion
routes between Central Asia and the
Indian Subcontinent','e42f238c354413784613b57ef40af9af43b3cfb72416ef5644d1070aadbd0e9b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0941cbf46b3ffca2ecbd272bf31f52776bc5bb3b19a79f2d63a57f1e45e9a0df',2009,'IM','Isle of Man','geography',647,'Location: Western Europe, island in the
Irish Sea, between Great Britain and
Land use:
arable land: 9%
permanent crops: 0%
other: 91% (permanent pastures, forests,
mountain, and heathland) (2002)
Irrigated land: 0 sq km
Natural hazards: NA
Environment — current issues: waste
disposal (both household and industrial);
transboundary air pollution
Geography — note: one small islet, the
Calf of Man, lies to the southwest and is
a bird sanctuary','189070fb8416469d6b91717952f8fdacf8e80140fcfefca7abbe486f32b5e4df','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f4fa00b4badc3fcd4e4acdd40b19d37503a7199e7504bfe79409361aa69f725',2009,'IE','Ireland','geography',648,'Geographic coordinates: 54 15 N, 4 30
w
Map references: Europe
Area:
total: 572 sq km
land: 572 sq km
water: 0 sq km
Area — comparative: slightly more than
three times the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 12 nm
Climate: temperate; cool summers and
mild winters; overcast about one-third of
the time
Terrain: hills in north and south bisected
by central valley
Elevation extremes:
lowest point: Irish Sea 0 m
highest point: Snaefell 621 m
Natural resources: none
320','b65556a13ad0a73c823bf6316eb1bcd927c07aec061ec3e2033702c6c1adb5f7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288a4f4ec1fbdab9319d3e5e5b160e27631ed0dde7478573d32e109aad65c69a',2009,'LB','Lebanon','geography',654,'Geographic coordinates: 31 30 N, 34 45
E
Map references: Middle East
Area: total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area — comparative: slightly smaller
than New Jersey
Land boundaries:
total: 1,017 km
border countries: Egypt 266 km, Gaza
Strip 51 km, Jordan 238 km, Lebanon 79
km, Syria 76 km, West Bank 307 km
Coastline: 273 km
Maritime claims: territorial sea: 12 nm
continental shelf: to depth of exploitation
Climate: temperate; hot and dry in
southern and eastern desert areas
Terrain: Negev desert in the south; low
coastal plain; central mountains; Jordan
Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: timber, potash,
copper ore, natural gas, phosphate rock,
magnesium bromide, clays, sand
Land use:
arable land: 15.45%
permanent crops: 3.88%
other: 80.67% (2005)
Irrigated land: 1,940 sq km (2003)
Total renewable water resources: 1.7
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.05 cu
km/yr (31%/7%/62%)
per capita: 305 cu m/yr (2000)
Natural hazards: sandstorms may occur
during spring and summer; droughts;
periodic earthquakes
Environment — current issues: limited
arable land and natural fresh water
resources pose serious constraints; deser¬
tification; air pollution from industrial
and vehicle emissions; groundwater pol¬
lution from industrial and domestic
waste, chemical fertilizers, and pesticides
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Marine Life
Conservation
Geography — note: there are 242 Israeli
settlements and civilian land use sites in
the West Bank, 42 in the Israeli-occu¬
pied Golan Heights, 0 in the Gaza Strip,
and 29 in East Jerusalem (August 2005
est.); Lake Tiberias (Sea of Galilee) is an
important freshwater source','ab3c9e3019878472fef213f45df142642e59c9d7a3b001055053a9e17a7947a5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e90d0bcfe8039b53b201b37ec7a5a68f2c04e9ce2c2d4716acacf5dc35268b',2009,'JP','Japan','geography',671,'Location: Northern Europe, island
between the Greenland Sea and the
Norwegian Sea, northeast of Iceland
Geographic coordinates: 71 00 N, 8 00
W
Map references: Arctic Region
Area:
total: 377 sq km
land: 377 sq km
water: 0 sq km
Area — comparative: slightly more than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 1241 km
Maritime claims:
territorial sea: 4 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: arctic maritime with frequent
storms and persistent fog
Terrain: volcanic island, partly covered
by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII
Toppen/Beerenberg 2,277 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: dominated by the vol¬
cano Haakon VII Toppen/Beerenberg;
volcanic activity resumed in 1970; the
most recent eruption occurred in 1985
Environment— current issues: NA
Geography — note: barren volcanic
island with some moss and grass
Location: Eastern Asia, island chain
between the North Pacific Ocean and
the Sea of Japan, east of the Korean
Peninsula
Geographic coordinates: 36 00 N, 138
00 E
Map references: Asia
Area:
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
333
THE CIA WORLD FACTBOOK
note: includes Bonin Islands (Ogasawara-
gunto), Daito-shoto, Minami-jima,
Okino-tori''shima, Ryukyu Islands
(Nansei-shoto), and Volcano Islands
(Kazan-retto)
Area— comparative: slightly smaller
than California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
territorial sea: 12 nm; between 3 nm and
12 nm in the international straits — La
Perouse or Soya, Tsugaru, Osumi, and
Eastern and Western Channels of the
Korea or Tsushima Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: varies from tropical in south to
cool temperate in north
Terrain: mostly rugged and mountainous
Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Mount Fuji 3,776 m
Natural resources: negligible mineral
resources, fish
Land use: arable land: 11.64%
permanent crops: 0.9%
other: 87.46% (2005)
Irrigated land: 25,920 sq km (2003)
Total renewable water resources: 430
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 88.43 cu
km/yr (20%/18%/62%)
per capita: 690 cu m/yr (2000)
Natural hazards: many dormant and
some active volcanoes; about 1,500
seismic occurrences (mostly tremors)
every year; tsunamis; typhoons
Environment— current issues: air pollu¬
tion from power plant emissions results
in acid rain; acidification of lakes and
reservoirs degrading water quality and
threatening aquatic life; Japan is one of
the largest consumers of fish and tropical
timber, contributing to the depletion of
these resources in Asia and elsewhere
Environment— international agree¬
ments: party to: Antarctic-Environ-
mental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
Geography — note: strategic location in
northeast Asia
Population: 127,288,419 (July 2008 est.)
334
Age structure:
0-14 years: 13.7% (male
8,926,439/female 8,460,629)
15-64 years: 64.7% (male
41,513,061/female 40,894,057)
65 years and over: 21.6% (male
11,643,845/female 15,850,388) (2008
est.)
Median age: total: 43.8 years
male: 42.1 years
female: 45.7 years (2008 est.)
Population growth rate: -0.139% (2008
est.)
Birth rate: 7.87 births/1,000 population
(2008 est.)
Death rate: 9.26 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio: at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female
(2008 est.)
Infant mortality rate:
total: 2.8 deaths/1,000 live births
male: 3 deaths/ 1,000 live births
female: 2.58 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 82.07 years
male: 78.73 years
female: 85.59 years (2008 est.)
Total fertility rate: 1.22 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS — people living with
HIV/AIDS: 12,000 (2003 est.)
HIV/AIDS— deaths: 500 (2003 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 98.5%, Koreans
0.5%, Chinese 0.4%, other 0.6%
note: up to 230,000 Brazilians of Japanese
origin migrated to Japan in the 1990s to
work in industries; some have returned
to Brazil (2004)
Religions: observe both Shinto and
Buddhist 84%, other 16% (including
Christian 0.7%)
Languages: Japanese
Literacy: definition: age 15 and over can
read and write
total population: 99%
male: 99%
female: 99% (2002)
Country name:
conventional long form: none
conventional short form: Japan
local long form: Nihon-koku/Nippon-
koku
local short form: Nihon/Nippon
Government type: constitutional mon¬
archy with a parliamentary government
Capital: name: Tokyo
geographic coordinates: 35 41 N, 139 45 E
time difference: UTC+9 (14 hours ahead
of Washington, DC during Standard
Time)
Administrative divisions: 47 prefectures;
Aichi, Akita, Aomori, Chiba, Ehime,
Fukui, Fukuoka, Fukushima, Gifu,
Gunma, Hiroshima, Hokkaido, Hyogo,
Ibaraki, Ishikawa, Iwate, Kagawa,
Kagoshima, Kanagawa, Kochi,
Kumamoto, Kyoto, Mie, Miyagi,
Miyazaki, Nagano, Nagasaki, Nara,
Niigata, Oita, Okayama, Okinawa,
Osaka, Saga, Saitama, Shiga, Shimane,
Shizuoka, Tochigi, Tokushima, Tokyo,
Tottori, Toyama, Wakayama, Yamagata,
Yamaguchi, Yamanashi
Independence: 660 B.C. (traditional
founding by Emperor JIMMU)
National holiday: Birthday of Emperor
AKIHITO, 23 December (1933)
Constitution: 3 May 1947
Legal system: modeled after German
civil law system with English-American
influence; judicial review of legislative
acts in the Supreme Court; accepts com¬
pulsory ICJ jurisdiction with reservations
Suffrage: 20 years of age; universal
Executive branch:
chief of state : Emperor AKIHITO (since 7
January 1989)
head of government: Prime Minister Yasuo
FUKUDA (since 26 September 2007)
cabinet: Cabinet appointed by the prime
minister
elections: Diet designates prime minister;
constitution requires that prime minister
commands parliamentary majority; fol¬
lowing legislative elections, leader of
majority party or leader of majority coali¬
tion in House of Representatives usually
becomes prime minister; monarch is
hereditary
election results: FUKUDA elected prime
minister with 338 of 477 votes cast in the
House of Representatives; he received
106 of 240 votes cast in the House of
Councillors; vote of House of
Representatives prevailed
Legislative branch: bicameral Diet or
Kokkai consists of the House of
Councillors or Sangi-in (242 seats —
members elected for six-year terms; half
reelected every three years; 146 members
in multi-seat constituencies and 96 by
proportional representation) and the
House of Representatives or Shugi-in
(480 seats — members elected for four-
year terms; 300 in single-seat constituen¬
cies; 180 members by proportional
representation in 1 1 regional blocs)
elections: House of Councillors — last
held 29 July 2007 (next to be held in July
2010); House of Representatives — last
held 11 September 2005 (next election
by September 2009)
election results: House of Councillors —
percent of vote by party — NA; seats by
party — DPJ 109, LDP 83, Komeito 20,
JCP 7, SDP 5, others 18
: House of Representatives — percent of
vote by party (in single-seat constituen¬
cies) — LDP 47.8%, DPJ 36.4%, others
15.8%; seats by party — LDP 296, DPJ
113, Komeito 31, JCP 9, SDP 7, others
24 (2007)
Judicial branch: Supreme Court (chief
justice is appointed by the monarch after
designation by the cabinet; all other jus¬
tices are appointed by the cabinet)
Political parties and leaders:
Democratic Party of Japan or DPJ [Ichiro
OZAWA]; Japan Communist Party or
JCP [Kazuo SHII]; Komeito [Akihiro
OTA]; Liberal Democratic Party or LDP
[Yasuo FUKUDA]; Social Democratic
Party or SDP [Mizuho FUKUSH1MA]
Political pressure groups and leaders:
NA
international organization participa¬
tion: ADB, AfDB, APEC, APT, ARF,
ASEAN (dialogue partner), Australia
Group, BIS, CE (observer), CERN
(observer), CP, EAS, EBRD, FAO, G-5,
G-7, G-8, G-10, IADB, IAEA, IBRD,
ICAO, ICC, ICCt, ICRM, IDA, IEA,
IFAD, IFC, IFRCS, IHO, ILO, IMF,
IMO, IMSO, Interpol, IOC, IOM, IPU,
ISO, ITSO, ITU, ITUC, LAIA, MIGA,
NEA, NSG, OAS (observer), OECD,
OPCW, OSCE (partner), Paris Club,
PCA, PIF (partner), SAARC (observer),
SECI (observer), UN, UN Security
Council (temporary), UNCTAD,
UNDOF, UNESCO, UNHCR, UNIDO,
UNITAR, UNRWA, UNWTO, UPU,
WCL, WCO, WFTU, WHO, WIPO,
WMO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Ryozo
KATO
chancery: 2520 Massachusetts Avenue
NW, Washington, DC 20008
telephone: [1] (202) 238-6700
FAX: [1] (202) 328-2187
consulate(s) general: Anchorage, Atlanta,
Boston, Chicago, Denver, Detroit, Agana
(Guam), Honolulu, Houston, Los
Angeles, Miami, New Orleans, New York,
Portland (Oregon), San Francisco, Seattle
Diplomatic representation from the US:
chief of mission: Ambassador J. Thomas
SCHIEFFER
embassy: 1-10-5 Akasaka, Minato-ku,
Tokyo 107-8420
mailing address: APO AP 96337-5004
telephone: [81] (03) 3224-5000
FAX: [81] (03) 3505-1862
consulate(s) general: Naha (Okinawa),
Osaka-Kobe, Sapporo
consulate(s) : Fukuoka, Nagoya
Flag description: white with a large red
disk (representing the sun without rays)
in the center','b1e500242b9896e7216fe503fdd794ba3b56e9f6d2d8be22b3de0f6bddc56721','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99fbcfa5a33c6055b134b291b9f0308e3775b12a53a38d159793723e5b3b3e69',2009,'JE','Jersey','geography',680,'Location: Western Europe, island in the
English Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10
W
Map references: Europe
Area:
total: 116 sq km
land: 116 sq km
water: 0 sq km
Area — comparative: about two-thirds
the size of Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 12 nm
Climate: temperate; mild winters and
cool summers
Terrain: gently rolling plain with low,
rugged hills along north coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: arable land
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current Issues: NA
Geography — note: largest and southern¬
most of Channel Islands; about 30% of
population concentrated in Saint Helier','fc3afa97d0cca896a68e6f9998de68f8f8eae1cf9b921ff18ad93730ddd3e394','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cb6fb601e3fbb65b8290927343b88a148b9060f2b45f85c0c9762f73f09fd6a',2009,'SA','Saudi Arabia','geography',687,'Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area: total: 92,300 sq km
land: 91,971 sq km
water: 329 sq km
Area — comparative: slightly smaller
than Indiana
Land boundaries:
total: 1,635 km
border countries: Iraq 181 km, Israel 238
km, Saudi Arabia 744 km, Syria 375 km,
West Bank 97 km
Coastline: 26 km
Maritime Claims: territorial sea: 3 nm
Climate: mostly arid desert; rainy season
in west (November to April)
Terrain: mostly desert plateau in east,
highland area in west; Great Rift Valley
separates East and West Banks of the
Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1,734 m
Natural resources: phosphates, potash,
shale oil
Land use: arable land: 3.32%
permanent crops : 1.18%
other: 95.5% (2005)
Irrigated land: 750 sq km (2003)
Total renewable water resources: 0.9
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.01 cu
km/yr (21%/4%/75%)
per capita: 177 cu m/yr (2000)
Natural hazards: droughts; periodic
earthquakes
Environment — current issues: limited
natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location at
the head of the Gulf of Aqaba and as the
Arab country that shares the longest
border with Israel and the occupied West
Bank
Population: 6,198,677 (July 2008 est.)
Age structure:
0-14 years: 32.2% (male 1,017,233/
female 976,284)
15-64 years: 63.7% (male 2,110,293/
female 1,840,531)
65 years and over: 4-1% (male
122,975/female 131,361) (2008 est.)
Median age:
total: 23.9 years
male: 24-6 years
female: 23.2 years (2008 est.)
Population growth rate: 2.338% (2008
est.)
Birth rate: 20.13 births/1,000 population
(2008 est.)
Death rate: 2.72 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 5.97 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.94 male(s)/female
total population: 1.1 male(s)/female (2008
est.)
Infant mortality rate:
total: 15.57 deaths/ 1,000 live births
male: 18.62 deaths/1,000 live births
female: 12.34 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 78.71 years
male: 76.19 years
female: 81.39 years (2008 est.)
Total fertility rate: 2.47 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: less
than 0.1% (2001 est.)
HIV/AIDS— people living with
HIV/AIDS: 600 (2003 est.)
HIV/AIDS — deaths: fewer than 500
(2003 est.)
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian
1%, Armenian 1%
Religions: Sunni Muslim 92%,
Christian 6% (majority Greek
Orthodox, but some Greek and Roman
Catholics, Syrian Orthodox, Coptic
Orthodox, Armenian Orthodox, and
Protestant denominations), other 2%
(several small Shi’a Muslim and Druze
populations) (2001 est.)
Languages: Arabic (official), English
widely understood among upper and
middle classes
Literacy: definition: age 15 and over can
read and write
total population: 89.9%
male: 95.1%
female: 84.7% (2003 est.)','d2c0c86ebf622edbf8af2139e8115f897cd427eb0d80c3bfe5e93c29c1fb4537','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76970e3cc5219c01012477ac635859e65c4fe0277e0996e61ae8b29fc1a3bdb1',2009,'KI','Kiribati','geography',705,'Location: Oceania, group of 33 coral
atolls in the Pacific Ocean, straddling
the Equator; the capital Tarawa is about
half way between Hawaii and Australia;
note — on 1 January 1995, Kiribati pro¬
claimed that all of its territory lies in the
same time zone as its Gilbert Islands
group (UTC +12) even though the
Phoenix Islands and the Line Islands
under its jurisdiction lie on the other side
of the International Date Line
Geographic coordinates: l 25 N, 173 00
E
Map references: Oceania
Area: total: 811 sq km
land: 81 1 sq km
water: 0 sq km
note: includes three island groups —
Gilbert Islands, Line Islands, Phoenix
Islands
Area — comparative: four times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; marine, hot and
humid, moderated by trade winds
Terrain: mostly low-lying coral atolls sur¬
rounded by extensive reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on
Banaba 81m
Natural resources: phosphate (produc¬
tion discontinued in 1979)
Land use:
arable land: 2.74%
permanent crops: 47.95%
other: 49.31% (2005)
Irrigated land: NA
Natural hazards: typhoons can occur
any time, but usually November to
March; occasional tornadoes; low level
of some of the islands make them sensi¬
tive to changes in sea level
Environment — current issues: heavy
pollution in lagoon of south Tarawa atoll
due to heavy migration mixed with tradi¬
tional practices such as lagoon latrines
and open-pit dumping; ground water at
risk
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: 21 of the 33 islands
are inhabited; Banaba (Ocean Island) in
Kiribati is one of the three great phos¬
phate rock islands in the Pacific
Ocean — the others are Makatea in
French Polynesia, and Nauru
i _
Location: Eastern Asia, southern half of
the Korean Peninsula bordering the Sea
of Japan and the Yellow Sea
Geographic coordinates: 37 00 N, 127
30 E
Map references: Asia
Area:
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Area — comparative: slightly larger than
Indiana
Land boundaries:
total: 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
territorial sea: 12 nm; between 3 nm and
1 2 nm in the Korea Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: temperate, with rainfall heavier
in summer than winter
Terrain: mostly hills and mountains;
wide coastal plains in west and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halia-san 1,950 m
Natural resources: coal, tungsten,
graphite, molybdenum, lead, hydropower
potential
Land use:
arable land: 16.58%
permanent crops: 2.01%
other: 81.41% (2005)
Irrigated land: 8,780 sq km (2003)
Total renewable water resources: 69.7
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 18.59 cu
km/yr (36%/16%/48%)
per capita: 389 cu m/yr (2000)
Natural hazards: occasional typhoons
bring high winds and floods; low-level
seismic activity common in southwest
Environment — current issues: air pollu¬
tion in large cities; acid rain; water pollu¬
tion from the discharge of sewage and
industrial effluents; drift net fishing
Environment— international agree¬
ments: party to: Antarctic-
Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location on
Korea Strait
Population: 49,232,844 (July 2008 est.)
Age structure:
0-14 years: 17.7% (male
4,579,018/female 4,157,631)
15-64 years: 72.3% (male
18,150,771/female 17,464,610)
65 years and over: 9.9% (male
1,997,032/female 2,883,782) (2008 est.)
Median age:
total: 36.4 years
male: 35.3 years
female: 37-4 years (2008 est.)
Population growth rate: 0.371% (2008
est.)
Birth rate: 9.83 births/1,000 population
(2008 est.)
Death rate: 6.12 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 1.01 male(s)/female
(2008 est.)
Infant mortality rate:
total: 5.94 deaths/1,000 live births
male: 6.33 deaths/1,000 live births
female: 5.53 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 77.42 years
male: 74 years
female: 81.1 years (2008 est.)
Total fertility rate: 1.29 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 8,300 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for
about 20,000 Chinese)
Religions: Christian 26.3% (Protestant
19.7%, Roman Catholic 6.6%),
Buddhist 23.2%, other or unknown
1.3%, none 49.3% (1995 census)
Languages: Korean, English widely
taught in junior high and high school
Literacy: definition: age 15 and over can
read and write
355
THE CIA WORLD FACTBOOK
total population: 97.9%
male: 99.2%
female: 96.6% (2002)
Country name:
conventional long form: Republic of Korea
conventional short form: South Korea
local long form: Taehan-min’guk
local short form: Han’guk
abbreviation: ROK
Government type: republic
Capital: name: Seoul
geographic coordinates: 37 33 N, 126 59 E
time difference: UTC+9 (14 hours ahead
of Washington, DC during Standard
Time)
Administrative divisions: 9 provinces
(do, singular and plural) and 7 metropob
itan cities (gwangyoksi, singular and
plural)
provinces: Cheju-do, Cholla-bukto
(North Cholla), Cholla-namdo (South
Cholla), Ch’ungch’ong-bukto (North
Ch’ungch’ong), Ch’ungch’ong-namdo
(South Ch’ungch’ong), Kangwon-do,
Kyonggi-do, Kyongsang-bukto (North
Kyongsang), Kyongsang-namdo (South
Kyongsang)
metropolitan cities: Inch’on-gwangyoksi
(Inch’on), Kwangju-gwangyoksi
(Kwangju), Pusan-gwangyoksi (Pusan),
Soui-t’ukpyolsi (Seoul), Taegu-
gwangyoksi (Taegu), Taejon-gwangyoksi
(Taejon), Ulsan-gwangyoksi (Ulsan)
Independence: 15 August 1945 (from
Japan)
National holiday: Liberation Day, 15
August (1945)
Constitution: 17 July 1948; note-
amended or rewritten nine times; current
constitution approved on 29 October
1987
Legal system: combines elements of
continental European civil law systems,
Anglo-American law, and Chinese clas¬
sical thought; has not accepted compul¬
sory ICJ jurisdiction
Suffrage: 19 years of age; universal
Executive branch:
chief of state: President LEE Myung-bak
(since 25 February 2008)
head of government: Prime Minister HAN
Seung-soo (since 29 February 2008)
cabinet: State Council appointed by the
president on the prime minister’s recom¬
mendation
elections: president elected by popular
vote for a single five-year term; election
last held 19 December 2007 (next to be
held on in December 2012); prime min¬
ister appointed by president with consent
of National Assembly; deputy prime
ministers appointed by president on
prime minister’s recommendation
election results: ROH Moo-hyun elected
president on 19 December 2002; percent
of vote — ROH Moo-hyun (MDP)
48.9%; LEE Hoi-chang (GNP) 46.6%;
others 4.5%; LEE Myung-bak elected
president on 19 December 2007; percent
of vote — LEE Myung-bak (GNP) 48.7%;
CHUNG Dong-young (UNDP) 26.1%);
LEE Hoi-chang (independent) 15.1;
others 10.1%
Legislative branch: unicameral National
Assembly or Kukhoe (299 seats; 243
members elected in single-seat con¬
stituencies, 56 elected by proportional
representation; to serve four- year terms)
elections: last held 9 April 2008 (next to
be held in April 2012)
election results : percent of vote by party —
NA; seats by party — GNP 153, UDP 81,
LFP 18, Pro-Park Alliance 14, DLP 5,
CKP 3, independents 25
Judicial branch: Supreme Court (jus¬
tices appointed by the president with
consent of National Assembly);
Constitutional Court (justices appointed
by the president based partly on nomina¬
tions by National Assembly and Chief
Justice of the court)
Political parties and leaders: Creative
Korea Party or CKP [MOON Kook-
hyun]; Democratic Labor Party or DLP
[CHUN Young-se]; Grand National
Party or GNP [KANG Jae-sup]; Liberty
Forward Party or LFP [SIM Dae-pyung];
United Democratic Party or UDP
[SOHN Hak-kyu]
Political pressure groups and leaders:
Federation of Korean Industries;
Federation of Korean Trade Unions;
Korean Confederation of Trade Unions;
Korean National Council of Churches;
Korean Traders Association; Korean
Veterans’ Association; National Council
of Labor Unions; National Democratic
Alliance of Korea; National Federation
of Farmers’ Associations; National
Federation of Student Associations
International organization participa¬
tion: ADB, AfDB, APEC, APT, ARF,
ASEAN (dialogue partner), Australia
Group, BIS, CP, EAS, EBRD, FAO,
IADB, IAEA, IBRD, ICAO, ICC, ICCt,
ICRM, IDA, IEA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, IMSO, Interpol,
IOC, IOM, IPU, ISO, ITSO, ITU,
ITUC, LAIA, MIGA, NEA, NSG, OAS
(observer), OECD, OPCW, OSCE
(partner), PCA, PIF (partner), SAARC
(observer), UN, UNCTAD, UNESCO,
UNFICYP, UNHCR, UNIDO, UNIFIL,
UNMIL, UNMIS, UNMOGIP,
UNOMIG, UNWTO, UPU, WCL,
WCO, WHO, WIPO, WMO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador LEE Tae-sik
chancery: 2450 Massachusetts Avenue
NW, Washington, DC 20008
telephone: [1] (202) 939-5600
FAX: [1] (202) 387-0205
consulate(s) general: Agana (Guam),
Atlanta, Boston, Chicago, Honolulu,
Houston, Los Angeles, New York, San
Francisco, Seattle
Diplomatic representation from the US:
chief of mission: Ambassador Alexander
VERSHBOW
embassy: 32 Sejong-no, Jongno-gu, Seoul
110-710
mailing address: US Embassy Seoul, APO
AP 96205-5550
telephone: [82] (2) 397-4114
FAX: [82] (2) 738-8845
Flag description: white with a red (top)
and blue yin-yang symbol in the center;
there is a different black trigram from the
ancient I Ching (Book of Changes) in
each corner of the white field
Economy — overview: Since the 1960s,
South Korea has achieved an incredible
record of growth and integration into the
high-tech modem world economy. Four
decades ago, GDP per capita was compa¬
rable with levels in the poorer countries of
Africa and Asia. In 2004, South Korea
joined the trillion dollar club of world
economies. Today its GDP per capita is
roughly the same as that of Greece and
Spain. This success was achieved by a
system of close govemment/business ties
including directed credit, import restric¬
tions, sponsorship of specific industries,
and a strong labor effort. The government
promoted the import of raw materials and
technology at the expense of consumer
goods and encouraged savings and invest¬
ment over consumption. The Asian finan¬
cial crisis of 1997-98 exposed longstanding
weaknesses in South Korea’s development
model including high debt/equity ratios,
massive foreign borrowing, and an undisci¬
plined financial sector. GDP plunged by
6.9% in 1998, then recovered by 9.5% in
1999 and 8.5% in 2000. Growth fell back
to 3.3% in 2001 because of the slowing
global economy, falling exports, and the
perception that much-needed corporate
and financial reforms had stalled. Led by
consumer spending and exports, growth in
2002 was an impressive 7%, despite anemic
global growth. Between 2003 and 2007,
growth moderated to about 4-5% annu¬
ally. A downturn in consumer spending
was offset by rapid export growth.
Moderate inflation, low unemployment,
and an export surplus in 2007 characterize
this solid economy, but inflation and
unemployment are increasing in the face of
rising oil prices.
356
KOREA, SOUTH
GDP (purchasing power parity): $1,201
trillion (2007 est.)
GDP (official exchange rate): $957.1
billion (2007 est.)
GDP— real growth rate: 5% (2007 est.)
GDP— per capita (PPP): $24,800 (2007
est.)
GDP— composition by sector:
agriculture: 3%
industry: 39.4%
services: 57.6% (2007 est.)
Labor force: 24.22 million (2007 est.)
Labor force— by occupation:
agriculture: 7.5%
industry: 17.3%
services: 75.2% (2007)
Unemployment rate: 3.3% (2007 est.)
Population below poverty line: 15%
(2003 est.)
Household income or consumption by
percentage share:
lowest 10%: 2.9%
highest 10%: 25% (2005 est.)
Distribution of family income— Gini
index: 35.1 (2006)
Inflation rate (consumer prices): 2.5%
(2007)
Investment (gross fixed): 28.8% of
GDP (2007 est.)
Budget:
revenues: $248 billion
expenditures: $246.5 billion (2007 est.)
Public debt: 33.4% of GDP (2007 est.)
Agriculture— products: rice, root crops,
barley, vegetables, fruit; cattle, pigs,
chickens, milk, eggs; fish
Industries: electronics, telecommunica¬
tions, automobile production, chemicals,
shipbuilding, steel
Industrial production growth rate: 7.6%
(2007 est.)
Electricity— production: 403.2 billion
kWh (2007)
Electricity— production by source:
fossil fuel: 62.4%
hydro: 0.8%
nuclear: 36.6%
other: 0.2% (2001)
Electricity — consumption: 368.6 billion
kWh (2007)
Electricity— exports: 0 kWh (2005)
Electricity— imports: 0 kWh (2005)
Oil— production: 17,050 bbl/day (2005)
Oil — Consumption: 2.13 million bbl/day
(2006)
Oil — exports: NA bbl/day
Oil — imports: 2.41 million bbl/day (2006)
Oil — proved reserves: 0 bbl (1 January
2006 est.)
Natural gas — production: 1.66 billion
cu m (2006)
Natural gas — consumption: 34.2 billion
cu m (2006)
Natural gas— exports: 2,450 cu m
(2006)
Natural gas — imports: 35.86 billion cu
m (2006)
Natural gas — proved reserves: 0 cu m
(1 January 2006 est.)
Current account balance: $5,954 billion
(2007 est.)
Exports: $371.5 billion f.o.b. (2007)
Exports— commodities: semiconduc¬
tors, wireless telecommunications equip¬
ment, motor vehicles, computers, steel,
ships, petrochemicals
Exports— partners: China 22%, US
12.5%, Japan 7.1%, Hong Kong 5%
(2007)
Imports: $356.8 billion f.o.b. (2007)
Imports— commodities: machinery,
electronics and electronic equipment,
oil, steel, transport equipment, organic
chemicals, plastics
Imports— partners: China 17.7%, Japan
16%, US 10.7%, Saudi Arabia 5.9%,
UAE 4.2% (2007)
Economic aid — donor: ODA, $455.3
million (2006)
Economic aid— recipient: $68.07 mil¬
lion (2004)
Reserves of foreign exchange and
gold: $262.2 billion (31 December 2007)
Debt— external: $220.1 billion (31
December 2007)
Stock of direct foreign investment — at
home: $120.7 billion (2007 est.)
Stock of direct foreign investment —
abroad: $82.1 billion (2006)
Market value of publicly traded shares:
$1,051 trillion (2007)
Currency (code): South Korean won
(KRW)
Currency code: KRW
Exchange rates: South Korean won per
US dollar— 929.2 (2007), 954.8 (2006),
1,024.1 (2005), 1,145.3 (2004), 1,191.6
(2003)
Fiscal year: calendar year
Telephones— main lines in use: 26.866
million (2006)
Telephones— mobile cellular: 40.197
million (2006)
Telephone system:
general assessment: excellent domestic
and international services
domestic: NA
international: country code — 82;
numerous submarine cables provide links
throughout Asia, Australia, the Middle
East, Europe, and US; satellite earth sta¬
tions — 6 (3 Intelsat — 1 Pacific Ocean
and 2 Indian Ocean, 3 Inmarsat — 1
Pacific Ocean and 2 Indian Ocean)
Radio broadcast stations: AM 61, FM
150, shortwave 2 (2005)
Radios: 47.5 million (2000)
Television broadcast stations: 43 (plus
59 cable operators and 190 relay cable
operators) (2005)
Televisions: 15.9 million (1997)
Internet country code: kr
Internet hosts: 315,537 (2007)
Internet Service Providers (ISPs): 11
(2000)
Internet users: 34.12 million (2006)
Location: Southeast Europe, between
Serbia and Macedonia
Geographic coordinates: 42 35 N, 21 00
E
Map references: Europe
Area:
total: 10,887 sq km
land: 10,887 sq km
water: 0 sq km
Area— comparative: slightly larger than
Delaware
Land boundaries:
total: 702 km
border countries: Albania 112 km,
Macedonia 159 km, Montenegro 79 km,
Serbia 352 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: influenced by continental air
masses resulting in relatively cold winters
with heavy snowfall and hot, dry sum¬
mers and autumns; Mediterranean and
alpine influences create regional varia¬
tion; maximum rainfall between October
and December
Terrain: flat fluvial basin with an eleva¬
tion of 400-700 m above sea level sur¬
rounded by several high mountain ranges
with elevations of 2,000 to 2,500 m
Elevation extremes:
lowest point: Drini i Bardhe/Beli Drim
297 m (located on the border with
Albania)
highest point: Gjeravica/Deravica 2,565 m
358
KOSOVO
Natural resources: nickel, lead, zinc,
magnesium, lignite, kaolin, chrome,
bauxite','84a9db433dddbbea8a92aa105dda4572b60cef881be042ddf0fc1cf0f7384d0d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1d9a8fb442b6f32d15d47554b50c2a22dc49fab5493b8de0fb2a7cbaf0ef249',2009,'KG','Kyrgyzstan','geography',720,'Location: Southeastern Asia, northeast
of Thailand, west of Vietnam
Geographic coordinates: 18 00 N, 105
00 E
Map references: Southeast Asia
Area: total: 236,800 so, km
land: 230,800 sq km
water: 6,000 sq km
Area — comparative: slightly larger than
Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km,
Cambodia 541 km, China 423 km,
Thailand 1,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical monsoon; rainy season
(May to November); dry season
(December to April)
Terrain: mostly rugged mountains; some
plains and plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower,
gypsum, tin, gold, gemstones
Land use:
arable land: 4-01%
permanent crops: 0.34%
other: 95.65% (2005)
Irrigated land: 1,750 sq km (2003)
Total renewable water resources: 333.6
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3 cu km/yr
(4%/6%/90%)
per capita: 507 cu m/yr (2000)
Natural hazards: floods, droughts
Environment — current issues: unex-
ploded ordnance; deforestation; soil ero¬
sion; most of the population does not
have access to potable water
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; most of
the country is mountainous and thickly
forested; the Mekong River forms a large
part of the western boundary with','dd016d5e51f8af258bc535854da3f2134c62679c69b3c42a2da6ab2b53ee0a1c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eecd0348635e4eaf07e21914e95e9aa7bc8d936da1c0b78c47fa02420a9e56e',2009,'LT','Lithuania','geography',725,'Geographic coordinates: 57 00 N, 25 00
E
Map references: Europe
Area: total: 64,589 sq km
land: 63,589 sq km
water: 1 ,000 sq km
Area — comparative: slightly larger than
West Virginia
Land boundaries:
total: 1,348 km
border countries: Belarus 141 km, Estonia
343 km, Lithuania 588 km, Russia 276
km
Coastline: 498 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: maritime; wet, moderate win¬
ters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Galzina Kalns 312 m
Natural resources: peat, limestone,
dolomite, amber, hydropower, wood,
arable land
Land use:
arable land: 28.19%
permanent crops: 0.45%
other: 71.36% (2005)
Irrigated land: 200 sq km
note: land in Latvia is often too wet, and
in need of drainage, not irrigation;
approximately 16,000 sq km or 85% of
agricultural land has been improved by
drainage (2003)
Total renewable wcter resources: 49.9
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.25 cu
km/yr (55%/33%/12%)
per capita: 108 cu m/yr (2003)
Natural hazards: NA
Environment — current issues: Latvia’s
environment has benefited from a shift
to service industries after the country
regained independence; the main envi¬
ronmental priorities are improvement of
drinking water quality and sewage
system, household, and hazardous waste
management, as well as reduction of air
pollution; in 2001, Latvia closed the EU
accession negotiation chapter on envi¬
ronment committing to full enforcement
of EU environmental directives by 2010
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Persistent Organic Pollutants,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: most of the country
is composed of fertile, low-lying plains,
with some hills in the east','57cfecfd7046067e9a4e36d07143d9f88b3fbe6e8ff004f650425541cc91c54c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4413314f0bcceb7ce06f246063f98d4eab7c0a02da00952ba8d67dccfac8a334',2009,'LS','Lesotho','geography',738,'Location: Southern Africa, an enclave of
GGOgraphy — note: landlocked, com¬
pletely surrounded by South Africa;
mountainous, more than 80% of the
country is 1,800 m above sea level
Population: 2,128,180
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor¬
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 35.3% (male 377,784/female
372,840)
15-64 years: 59.8% (male
621,687/female 649,981)
65 years and over: 5% (male
42,348/female 63,540) (2008 est.)
Median age:
total: 21.2 years
male: 20.6 years
female: 21.8 years (2008 est.)
Population growth rate: 0.129% (2008
est.)
Birth rate: 24-41 births/1,000 population
(2008 est.)
Death rate: 22.33 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -0.78 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 78.59 deaths/1,000 live births
male: 83.01 deaths/1,000 live births
female: 74.03 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 40.17 years
male: 40.97 years
female: 39.34 years (2008 est.)
Total fertility rate: 3.13 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate:
28.9% (2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 320,000 (2003 est.)
HIV/AIDS— deaths: 29,000 (2003 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans,
Asians, and other 0.3%,
Religions: Christian 80%, indigenous
beliefs 20%
Languages: Sesotho (southern Sotho),
English (official), Zulu, Xhosa
Literacy: definition: age 15 and over can
read and write
total population: 84.8%
male: 74-5%
female: 94.5% (2003 est.)
Country name:
conventional long form: Kingdom of
conventional short form: Lesotho
local long form: Kingdom of Lesotho
local short form: Lesotho
former: Basutoland
Government type: parliamentary consti¬
tutional monarchy
Capital: name: Maseru
geographic coordinates: 29 19S, 27 29E
time difference: UTC+2 (7 hours ahead of
Washington, DC during Standard Time)
Administrative divisions: 10 districts;
Berea, Butha-Buthe, Leribe, Mafeteng,
Maseru, Mohale’s Hoek, Mokhotlong,
Qacha’s Nek, Quthing, Thaba-Tseka
Independence: 4 October 1966 (from
UK)
National holiday: Independence Day, 4
October (1966)
Constitution: 2 April 1993
Legal system: based on English common
law and Roman-Dutch law; judicial
review of legislative acts in High Court
and Court of Appeal; accepts compulsory
ICJ jurisdiction with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: King LETSIE III (since 7
February 1996); note — King LETSIE III
formerly occupied the throne from
November 1990 to February 1995 while
his father was in exile
head of government: Prime Minister
Pakalitha MOSISILI (since 23 May
1998)
cabinet: Cabinet
elections: according to the constitution,
the leader of the majority party in the
Assembly automatically becomes prime
minister; the monarch is hereditary, but,
under the terms of the constitution that
came into effect after the March 1993
election, the monarch is a “living symbol
of national unity” with no executive or
legislative powers; under traditional law
the college of chiefs has the power to
depose the monarch, determine who is
next in the line of succession, or who
shall serve as regent in the event that the
successor is not of mature age
Legislative branch: bicameral
Parliament consists of the Senate (33
members — 22 principal chiefs and 1 1
other members appointed by the ruling
party) and the Assembly (120 seats, 80
by popular vote and 40 by proportional
vote; members elected by popular vote
for five-year terms)
elections: last held 17 February 2007
(next to be held in 2012)
election results: percent of vote by party —
NA; seats by party — LCD 61, NIP 21,
ABC 17, LWP 10, ACP 4, BNP 3, other
4
Judicial branch: High Court (chief jus¬
tice appointed by the monarch acting on
the advice of the Prime Minister); Court
of Appeal; Magistrate Courts; customary
or traditional court
Political parties and leaders: Alliance
of Congress Parties or ACP; All Basotho
Convention or ABC [Thomas THA-
BANE]; Basotholand African Congress
or BAC [Khauhelo RALITAPOLE];
Basotho Congress Party or BCP
[Ntsukunyane MPHANYA]; Basotho
National Party or BNP [Maj. Gen. Justin
Metsing LEKHANYA]; Kopanang
Basotho Party or KPB [Pheelo
MOSALA]; Lesotho Congress for
Democracy or LCD (the governing
party) [Pakalitha MOSISILI]; Lesotho
Education Party or LEP [Thabo PITSO];
Lesotho Workers Party or LWP [Macaefa
BILLY]; Marematlou Freedom Party or
MFP [Vincent MALEBO]; National
Independent Party or NIP [Anthony
MANYELI]; New Lesotho Freedom
Party or NLFP [Manapo MAJARA];
Popular Front for Democracy or PFD
[Lekhetho RAKUOANE]; Sefate
Democratic Union or SDU [Bofihla
NKUEBE]; Social Democratic Party of
SDP [Masitise SELESO]
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACP, AfDB, AU, C, FAO, G-77,
IBRD, ICAO, ICCt, ICRM, IDA, IFAD,
IFC, IFRCS, ILO, IMF, Interpol, IOC,
ISO (subscriber), ITU, MIGA, NAM,
OPCW, SACU, SADC, UN,
UNCTAD, UNESCO, UNHCR,
UNIDO, UNWTO, UPU, WCO,
WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador (vacant);
Charge d’Affaires Mabasia
MOHOBANE
chancery: 2511 Massachusetts Avenue
NW, Washington, DC 20008
telephone: [1] (202) 797-5533 through
5536
FAX: [1] (202) 234-6815
Diplomatic representation from the US:
chief of mission: Ambassador Robert
NOLAN
embassy: 254 Kingsway, Maseru West
(Consular Section)
377
THE CIA WORLD FACTBOOK
mailing address: P. O. Box 333, Maseru
100, Lesotho
telephone: [266] 22 312666
FAX: [266] 22 310116
Flag description: three horizontal stripes
of blue (top), white, and green in the
proportions of 3:4:3; the colors represent
rain, peace, and prosperity respectively;
centered in the white stripe is a black
Basotho hat representing the indigenous
people; the flag was unfurled in October
2006 to celebrate 40 years of independ¬
ence','2a7e4be255fa43bd92b8d858d55b60eb9c5f1c297edb415fa5ffa2d65f8caa98','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70a1b0ceb27a7364af25693351e6eafd7d883c87d9abe0a486b4c466c001f48f',2009,'LY','Libya','geography',750,'; • . ''
Location: Northern Africa, bordering
the Mediterranean Sea, between Egypt
and Tunisia
Geographic coordinates: 25 00 N, 17 00
E
Map references: Africa
Area: total: 1,759,540 sq km
land: 1,759,540 sq km
water: 0 sq km
Area— comparative: slightly larger than
Alaska
Land boundaries:
total: 4,348 km
border countries: Algeria 982 km, Chad
1,055 km, Egypt 1,115 km, Niger 354
km, Sudan 383 km, Tunisia 459 km
Coastline: 1,770 km
Maritime claims:
territorial sea: 12 nm
note: Gulf of Sidra closing line — 32
degrees, 30 minutes north
exclusive fishing zone: 62 nm
Climate: Mediterranean along coast; dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural
gas, gypsum
Land use:
arable land: 1.03%
permanent crops: 0.19%
other: 98.78% (2005)
Irrigated land: 4,700 sq km (2003)
Total renewable water resources: 0.6
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 4 27 cu
km/yr (14%/3%/83%)
per capita: 730 cu m/yr (2000)
Natural hazards: hot, dry, dust-laden
ghibli is a southern wind lasting one to
four days in spring and fall; dust storms,
sandstorms
Environment — current issues: desertifi¬
cation; limited natural fresh water
resources; the Great Manmade River
Project, the largest water development
scheme in the world, is being built to
bring water from large aquifers under the
Sahara to coastal cities
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
382
Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: more than 90% of
the country is desert or semidesert','a6bfc37f7bc47908d97332c6e521ba0b7941bdb48293fed37e4fd6ed7e234604','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bb459912a0df68d476735580bb45fabbabbc19bd84163e7c845a62f6be8ff66',2009,'LI','Liechtenstein','geography',757,'Location: Central Europe, between
Austria and Switzerland
Geographic coordinates: 47 16 N, 9 32
E
Map references: Europe
Area:
total: 160 sq km
land: 160 sq km
water: 0 sq km
Area — comparative: about 0.9 times the
size of Washington, DC
Land boundaries:
total: 16 km
border countries: Austria 34-9 km,
Switzerland 41.1 km
Coastline: 0 km (doubly landlocked)
Maritime Claims: none (landlocked)
Climate: continental; cold, cloudy win¬
ters with frequent snow or rain; cool to
moderately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with
Rhine Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Vorder-Grauspitz 2,599 m
Natural resources: hydroelectric poten¬
tial, arable land
Land USe: arable land: 25%
permanent crops: 0%
other: 75% (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: NA
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution- Volatile
Organic Compounds, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: along with Uzbekistan,
one of only two doubly landlocked coun¬
tries in the world; variety of microclimatic
variations based on elevation','2faae4dcaffec798f1fd15b33591fa0f4993eef0f9d9b48924e0677966c77d37','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48a0ccd4ce825db608bfc7798cc0213b483afca7493e4bc5cef57afee8ad401a',2009,'LU','Luxembourg','geography',766,'Location: Western Europe, between
France and Germany
Geographic coordinates: 49 45 N, 6 10
E
Map references: Europe
Area: total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Rhode Island
390
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France
73 km, Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild
winters, cool summers
Terrain: mostly gently rolling uplands
with broad, shallow valleys; uplands to
slightly mountainous in the north; steep
slope down to Moselle flood plain in the
southeast
Elevation extremes:
lowest point: Moselle River 133 m
highest point: Buurgplaatz 559 m
Natural resources: iron ore (no longer
exploited), arable land
Land use:
arable land: 27.42%
permanent crops: 0.69%
other: 71.89% (includes Belgium) (2005)
Irrigated land: NA
Total renewable water resources: 1.6
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.06 cu
km/yr (42%/45%/13%)
per capita: 121 cu m/yr (1999)
Natural hazards: NA
Environment— current issues: air and
water pollution in urban areas, soil pollu-
tion of farmland
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution- Volatile
Organic Compounds, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Environmental
Modification
Geography — note: landlocked; the only
Grand Duchy in the world
Location: Eastern Asia, bordering the
South China Sea and China
Geographic coordinates: 22 10 N, 113
33 E
Map references: Southeast Asia
Area:
total: 28.2 sq km
land: 28.2 sq km
water: 0 sq km
Area — comparative: less than one-sixth
the size of Washington, DC
Land boundaries:
total: 0.34 km
regional border: China 0.34 km
Coastline: 41 km
Maritime claims: not specified
Climate: subtropical; marine with cool
winters, warm summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 172.4 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: typhoons
Environment— current issues: NA
Environment— international agree¬
ments: party to: Marine Dumping (asso¬
ciate member), Ship Pollution (associate
member)
Geography — note: essentially urban; an
area of land reclaimed from the sea meas¬
uring 5.2 sq km and known as Cotai now
connects the islands of Coloane and
Taipa; the island area is connected to the
mainland peninsula by three bridges','f20508afe68121cebf9ea2c27bc31ee6251d64c1f7676ed71079fbc2caabc057','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f44d30240073b2c5e60129bcf98f824a6f14d4eafdaac3e2864e10666655df2',2009,'ZM','Zambia','geography',782,'land: 94,080 sq km
water: 24,400 sq km
Area— comparative: slightly smaller
than Pennsylvania
Land boundaries:
total: 2,881 km
border countries: Mozambique 1,569 km,
Tanzania 475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: sub-tropical; rainy season
(November to May); dry season (May to
November)
Terrain: narrow elongated plateau with
rolling plains, rounded hills, some moun¬
tains
Elevation extremes:
lowest point: junction of the Shire River
402
M A LAW I
and international boundary with
Mozambique 37 m
highest point: Sapitwa (Mount Mlanje)
3,002 m
Natural resources: limestone, arable
land, hydropower, unexploited deposits
of uranium, coal, and bauxite
Land use:
arable land: 20.68%
permanen t crops : 1.18%
other: 78.14% (2005)
Irrigated land: 560 sq km (2003)
Total renewable water resources: 17.3
cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.01 cu
km/yr (15%/5%/80%)
per capita: 78 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: defor¬
estation; land degradation; water pollu¬
tion from agricultural runoff, sewage,
industrial wastes; siltation of spawning
grounds endangers fish populations
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; Lake
Nyasa, some 580 km long, is the country’s
most prominent physical feature
Population: 13,931,831
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor¬
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 46% (male 3,208,112/female
3,194,600)
15-64 years: 51.4% (male
3,592,073/female 3,563,840)
65 years and over: 2.7% (male
159,450/female 213,756) (2008 est.)
Median age: total: 16.8 years
male: 16.7 years
female: 16.8 years (2008 est.)
Population growth rate: 2.39% (2008
est.)
Birth rate: 41.79 births/1,000 population
(2008 est.)
Death rate: 17.89 deaths/ 1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.01 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over : 0.75 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 90.55 deaths/1,000 live births
male: 94-69 deaths/1,000 live births
female: 86.35 deaths/ 1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 43.45 years
male: 43.74 years
female: 43.15 years (2008 est.)
Total fertility rate: 5.67 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate:
14.2% (2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 900,000 (2003 est.)
HIV/AIDS— deaths: 84,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A, and
typhoid fever
vectorbome diseases: malaria and plague
water contact disease: schistosomiasis
(2008)
Nationality: noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja,
Tumbuka, Yao, Lomwe, Sena, Tonga,
Ngoni, Ngonde, Asian, European
Religions: Christian 79.9%, Muslim
12.8%, other 3%, none 4.3% (1998
census)
Languages: Chichewa 57.2% (official),
Chinyanja 12.8%, Chiyao 10.1%,
Chitumbuka 9.5%, Chisena 2.7%,
Chilomwe 2.4%, Chitonga 1.7%, other
3.6% (1998 census)
Literacy:
definition: age 15 and over can read and
write
total population: 62.7%
male: 76.1%
female: 49.8% (2003 est.)','90bf91986bf6ee57cec25457d407a3e98b7bb6579be6b0cf833ee122a4d8a6f6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c78d73e32e8f27b06cbeb7c7c5479bef63ed31ae069e26719661de850aed259',2009,'MY','Malaysia','geography',792,'_
Location: Southeastern Asia, peninsula
bordering Thailand and northern one-
405
THE CIA WORLD FACTBOOK
third of the island of Borneo, bordering
Indonesia, Brunei, and the South China
Sea, south of Vietnam
Geographic coordinates: 2 30 N, 112 30
E
Map references: Southeast Asia
Area:
total: 329,750 sq km
land: 328,550 sq km
water: 1,200 sq km
Area — comparative: slightly larger than
New Mexico
Land boundaries:
total: 2,669 km
border countries: Brunei 381 km,
Indonesia 1,782 km, Thailand 506 km
Coastline: 4,675 km (Peninsular
Malaysia 2,068 km, East Malaysia 2,607
km)
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation; specified boundary
in the South China Sea
Climate: tropical; annual southwest
(April to October) and northeast
(October to February) monsoons
Terrain: coastal plains rising to hills and
mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum,
timber, copper, iron ore, natural gas,
bauxite
Land use: arable land: 5.46%
permanen t crops : 17.54%
other: 77% (2005)
Irrigated land: 3,650 sq km (2003)
Total renewable water resources: 580
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 9.02 cu
km/yr (17%/21%/62%)
per capita: 356 cu m/yr (2000)
Natural hazards: flooding, landslides,
forest fires
Environment— current issues: air pollu¬
tion from industrial and vehicular emis¬
sions; water pollution from raw sewage;
deforestation; smoke/haze from
Indonesian forest fires
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands
Geography — note: strategic location
along Strait of Malacca and southern
South China Sea','858e4564120f7d7b9253bd20f2c28c9816f056a55040cad0dd080035a872f284','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6629313a37cab214d1a2e9e3a1f62a9d8fdf73da4b0bb30ee56d9ab6de7308a3',2009,'ML','Mali','geography',811,'Location: Southern Europe, islands in
the Mediterranean Sea, south of Sicily
(Italy)
Geographic coordinates: 35 50 N, 14 35
E
Map references: Europe
Area:
total: 316 sq km
land: 316 sq km
water: 0 sq km
Area— comparative: slightly less than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 196.8 km (does not include
56.01 km for the island of Gozo)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: 200 m depth or to the
depth of exploitation
exclusive fishing zone: 25 nm
Climate: Mediterranean; mild, rainy
winters; hot, dry summers
Terrain: mostly low, rocky, flat to dis¬
sected plains; many coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Ta’Dmejrek 253 m (near
Dingli)
Natural resources: limestone, salt,
arable land
Land use:
arable land: 31.25%
permanent crops : 3.13%
other: 65.62% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 0.07
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.02 cu
km/yr (74%/l%/25%)
per capita: 50 cu m/yr (2000)
Natural hazards: NA
Environment— current issues: limited
natural fresh water resources; increasing
reliance on desalination
Environment— international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: the country com-
prises an archipelago, with only the three
largest islands (Malta, Ghawdex or Gozo,
and Kemmuna or Comino) being inhab''
ited; numerous bays provide good har-
bors; Malta and Tunisia are discussing
the commercial exploitation of the con¬
tinental shelf between their countries,
particularly for oil exploration','46125eaabde95fb3001ac2ac72b9b1f54a44fcdee625e11f5b7529ff02810cea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b604bfaf5ef48c4ecb793b095aa07777d3a7c50844bcc565d80af48110bb847d',2009,'FM','Micronesia, Federated States of','geography',841,'Location: Oceania, island group in the
North Pacific Ocean, about three-quar¬
ters of the way from Hawaii to Indonesia
Geographic coordinates: 6 55 N, 158 15
E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
water: 0 sq km (fresh water only)
note: includes Pohnpei (Ponape), Chuuk
(Truk) Islands, Yap Islands, and Kosrae
(Kosaie)
Area — comparative: four times the size
of Washington, DC (land area only)
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; heavy year-round rain¬
fall, especially in the eastern islands;
located on southern edge of the typhoon
belt with occasionally severe damage
Terrain: islands vary geologically from
high mountainous islands to low, coral
atolls; volcanic outcroppings on
Pohnpei, Kosrae, and Chuuk
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Dolohmwar (Totolom) 791
m
Natural resources: forests, marine prod¬
ucts, deep-seabed minerals, phosphate
Land use:
arable land: 5.71%
permanent crops : 45.71%
other: 48.58% (2005)
Irrigated land: NA
Natural hazards: typhoons (June to
December)
Environment — current issues: over¬
fishing, climate change, pollution
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the
selected agreements
Geography — note: four major island
groups totaling 607 islands
Population: 107,665 (July 2008 est.)
Age structure:
0-14 years: 35.3% (male 19,344/female
18,687)
15-64 years: 61.8% (male 33,142/female
33,389)
65 years and over: 2.9% (male
1,320/female 1,783) (2008 est.)
Median age:
total: 21.6 years
male: 21.1 years
female: 22.1 years (2008 est.)
Population growth rate: -0.191% (2008
est.)
431
THE CIA WORLD FACTBOOK
Birth rote: 23.66 births/1,000 population
(2008 est.)
Death rate: 4.53 deaths/1,000 popular
tion (2008 est.)
Net migration rate: -21.04 migrant(s)/
1,000 population (2008 est.)
Sex ratio: NA
Infant mortality rate:
total: 27.03 deaths/1,000 live births
male: 29.8 deaths/1,000 live births
female: 24.13 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 70.65 years
male: 68.79 years
female: 72.61 years (2008 est.)
Total fertility rate: 2.98 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Chuukese,
Kosraen(s), Pohnpeian(s), Yapese
Ethnic groups: Chuukese 48.8%,
Pohnpeian 24.2%, Kosraean 6.2%,
Yapese 5.2%, Yap outer islands 4.5%,
Asian 1.8%, Polynesian 1.5%, other
6.4%, unknown 1.4% (2000 census)
Religions: Roman Catholic 50%,
Protestant 47%, other 3%
Languages: English (official and
common language), Trukese, Pohnpeian,
Yapese, Kosrean, Ulithian, Woleaian,
Nukuoro, Kapingamarangi
Literacy: definition: age 15 and over can
read and write
total population: 89%
male: 91%
female: 88% (1980 est.)
Country name:
conventional long form: Federated States
of Micronesia
conventional short form: none
local long form: Federated States of
Micronesia
local short form: none
former: Trust Territory of the Pacific
Islands, Ponape, Truk, and Yap Districts
abbreviation: FSM
Government type: constitutional gov¬
ernment in free association with the US;
the Compact of Free Association entered
into force 3 November 1986 and the
Amended Compact entered into force
May 2004
Capital: name: Palikir
geographic coordinates: 655N, 158 09 E
time difference: UTC+1 1 (16 hours ahead
of Washington, DC during Standard
Time)
Administrative divisions: 4 states;
Chuuk (Truk), Kosrae (Kosaie), Pohnpei
(Ponape), Yap
Independence: 3 November 1986 (from
the US-administered UN trusteeship)
National holiday: Constitution Day, 10
May (1979)
Constitution: 10 May 1979
Legal system: based on adapted Trust
Territory laws, acts of the legislature,
municipal, common, and customary
laws; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Emanuel MORI
(since 11 May 2007); Vice President
Alik L. ALIK (since 11 May 2007);
note — the president is both the chief of
state and head of government
head of government: President Emanuel
MORI (since 11 May 2007); Vice
President Alik L. ALIK (since 1 1 May
2007)
cabinet: Cabinet includes the vice presi¬
dent and the heads of the eight executive
departments
elections: president and vice president
elected by Congress from among the four
senators at large for a four-year term (eli¬
gible for a second term); election last
held 11 May 2007 (next to be held May
2011); note — a proposed constitutional
amendment to establish popular elec¬
tions for president and vice president
failed
election results: Emanuel MORI elected
president; percent of Congress vote —
NA; Alik L. ALIK elected vice presi¬
dent; percent of Congress vote — NA
Legislative branch: unicameral
Congress (14 seats; 4 — one elected from
each state to serve four-year terms and
10 — elected from single-member dis¬
tricts delineated by population to serve
two-year terms; members elected by pop¬
ular vote)
elections: last held 6 March 2007 (next to
be held in March 2009)
election results: percent of vote — NA%;
seats — independents 14
Judicial branch: Supreme Court
Political parties and leaders: no formal
parties
International organization participa¬
tion: ACP, ADB, FAO, G-77, IBRD,
ICAO, ICRM, IDA, IFC, IFRCS, IMF,
IOC, ITSO, ITU, MIGA, OPCW, PIF,
Sparteca, SPC, UN, UNCTAD,
UNESCO, WHO, WMO
Diplomatic representation in the US:
chief of mission: Ambassador Jesse
Bibiano MAREHALAU
chancery: 1725 N Street NW,
Washington, DC 20036
telephone: [1] (202) 223-4383
FAX: [1] (202) 223-4391
consulate(s) general: Honolulu, Tamuning
(Guam)
Diplomatic representation from the US:
chief of mission: Ambassador Miriam K.
HUGHES
embassy: 101 Upper Pics Road, Kolonia
mailing address: P. O. Box 1286, Kolonia,
Pohnpei, 96941
telephone: f691] 320-2187
FAX: [691] 320-2186
Flag description: light blue with four
white five-pointed stars centered; the
stars are arranged in a diamond pattern
Location: Eastern Europe, northeast of','8665731e394460dae8aabc8d7aea422319c760abd129707b6f96cf6513b5b95f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('340eb9490a151d1bd00c1d9e89d9450a8126c08e538c42a91f50a2df55f25821',2009,'MC','Monaco','geography',848,'Location: Western Europe, bordering the
Mediterranean Sea on the southern coast
of France, near the border with Italy
Geographic coordinates: 43 44 N, 7 24
E
Map references: Europe
Area:
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Area— comparative: about three times
the size of The Mall in Washington, DC
Land boundaries: total: 4 4 km
436
border countries: France 4-4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 12 nm
Climate: Mediterranean with mild, wet
winters and hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (urban area) (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: NA
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: second-smallest
independent state in the world (after
Holy See); almost entirely urban','27ce122fce8f62d593c1fb5882eb2bf95cafac28e769240c8f4a54614ea228d3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abafc1986e6eade395bb2716dd9639edfe5e36cd7be8ef518e608b2b58be6b93',2009,'MN','Mongolia','geography',855,'Location: Northern Asia, between
China and Russia
Geographic coordinates: 46 00 N, 105
00 E
Map references: Asia
Area:
total: 1,564,1 16 sq km
land: 1,554,731 sq km
water: 9,385 sq km
Area — comparative: slightly smaller
than Alaska
Land boundaries:
total: 8,220 km
border countries: China 4,677 km, Russia
3,543 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: desert; continental (large daily
and seasonal temperature ranges)
Terrain: vast semidesert and desert
plains, grassy steppe, mountains in west
and southwest; Gobi Desert in south-
central
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Nayramadlin Orgil (Huyten
Orgil) 4,374 m
Natural resources: oil, coal, copper,
molybdenum, tungsten, phosphates, tin,
nickel, zinc, fluorspar, gold, silver, iron
Land use:
arable land: 0.76%
permanent crops: 0%
other: 99.24% (2005)
irrigated land: 840 sq km (2003)
Total renewable water resources: 34 8
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.44 cu
km/yr (20%/27%/52%)
per capita: 166 cu m/yr (2000)
Natural hazards: dust storms, grassland
and forest fires, drought, and “zud,”
which is harsh winter conditions
Environment — current issues: limited
natural fresh water resources in some
areas; the policies of former Communist
regimes promoted rapid urbanization and
industrial growth that had negative
effects on the environment; the burning
of soft coal in power plants and the lack
of enforcement of environmental laws
severely polluted the air in Ulaanbaatar;
deforestation, overgrazing, and the con¬
verting of virgin land to agricultural pro¬
duction increased soil erosion from wind
and rain; desertification and mining
activities had a deleterious effect on the','0c69f6f30048e65e3a8133ad9e1f3fa6da02156cedc84ca1be8ba23b5b3bace2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('871a8eb30fde9c5dd1348a4ae6509bb490cd7aa4438a97189d4807d8fe6537bf',2009,'ME','Montenegro','geography',865,'Location: Southeastern Europe, between
the Adriatic Sea and Serbia
Geographic coordinates: 42 30 N, 19 18
E
Map references: Europe
Area:
total: 14,026 sq km
land: 13,812 sq km
water: 214 sq km
Area — comparative: slightly smaller
than Connecticut
Land boundaries:
total: 625 km
border countries: Albania 172 km, Bosnia
and Herzegovina 225 km, Croatia 25 km,
Kosovo 79 km, Serbia 124 km
Coastline: 293.5 km
Maritime claims:
territorial sea: 12 nm
continental shelf: defined by treaty
Climate: Mediterranean climate, hot dry
summers and autumns and relatively cold
winters with heavy snowfalls inland
Terrain: highly indented coastline with
narrow coastal plain backed by rugged
high limestone mountains and plateaus
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Bobotov Kuk 2,522 m
Natural resources: bauxite, hydroelec-
tricity
Land use:
arable land: 13.7%
permanent crops : 1 %
other: 85.3%
Irrigated land: NA
Natural hazards: destructive earth''
quakes
Environment— current issues: pollution
of coastal waters from sewage outlets,
especially in tourist-related areas such as
Kotor
Environment — international agree¬
ments: party to: Climate Change,
Climate Change-Kyoto Protocol,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ship Pollution
Geography — note: strategic location
along the Adriatic coast
Population: 678,177 (July 2008 est.)
Population growth rate: -0.925% (2008
est.)
Birth rate: 11.17 births/1,000 population
(2008 est.)
Death rate: 8.51 deaths/1,000 popula¬
tion (2008 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diar¬
rhea and hepatitis A
vectorborne disease: Crimean Congo
hemorrhagic fever (2008)
Nationality: noun: Montenegrin(s)
adjective: Montenegrin
Ethnic groups: Montenegrin 43%,
Serbian 32%, Bosniak 8%, Albanian 5%,
other (Muslims, Croats, Roma (Gypsy))
12%
Religions: Orthodox, Muslim, Roman
Catholic
Languages: Montenegrin (official),
Serbian, Bosnian, Albanian, Croatian','52ec6a8309a453ae6f1e6bb1d3f243f5cca844b35662f4f1cb275b00c1462ec1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b71c29d584e5d66db06d6392fd85b24be27657f4898de5440e400e02f212176',2009,'MZ','Mozambique','geography',883,'Location: Southeastern Africa, bordering
the Mozambique Channel, between
South Africa and Tanzania
Geographic coordinates: 18 15 S, 35 00
E
Map references: Africa
Area:
total: 801,590 sq km
land: 784,090 sq km
water: 17,500 sq km
Area — comparative: slightly less than
twice the size of California
Land boundaries:
total: 4,571 km
border countries: Malawi 1,569 km, South
Africa 491 km, Swaziland 105 km,
Tanzania 756 km, Zambia 419 km,
Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands
in center, high plateaus in northwest,
mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, nat¬
ural gas, hydropower, tantalum, graphite
449
THE CIA WORLD FACTBOOK
Land use: arable land: 5.43%
permanent crops: 0.29%
other: 94.28% (2005)
Irrigated land: 1,180 sq km (2003)
Total renewable water resources: 216
cu km (1992)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.63 cu
km/yr (ll%/2%/87%)
per capita: 32 cu m/yr (2000)
Natural hazards: severe droughts; devas-
fating cyclones and floods in central and
southern provinces
Environment— current issues: a long
civil war and recurrent drought in the
hinterlands have resulted in increased
migration of the population to urban and
coastal areas with adverse environmental
consequences; desertification; pollution
of surface and coastal waters; elephant
poaching for ivory is a problem
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: the Zambezi flows
through the north-central and most fer¬
tile part of the country
Location: Southern Africa, bordering the
South Atlantic Ocean, between Angola
and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
total: 825,418 sq km
land: 825,418 sq km
water: 0 sq km
Area— Comparative: slightly more than
half the size of Alaska
Land boundaries:
total: 3,936 km
border countries: Angola 1,376 km,
Botswana 1,360 km, South Africa 967
km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; hot, dry; rainfall sparse
and erratic
Terrain: mostly high plateau; Namib
Desert along coast; Kalahari Desert in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper,
uranium, gold, silver, lead, tin, lithium,
cadmium, tungsten, zinc, salt,
hydropower, fish
note: suspected deposits of oil, coal, and
iron ore
Land use:
arable land: 0.99%
permanent crops: 0.01%
other: 99% (2005)
Irrigated land: 80 sq km (2003)
Total renewable water resources: 45.5
cu km (1991)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.3 cu
km/yr (24%/5%/71%)
per capita: 148 cu m/yr (2000)
Natural hazards: prolonged periods of
drought
Environment— current issues: limited
natural fresh water resources; desertifica¬
tion; wildlife poaching; land degradation
has led to few conservation areas
Environment — international agree¬
ments: party to: Antarctic-Marine
Living Resources, Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: first country in the
world to incorporate the protection of
the environment into its constitution;
some 14% of the land is protected,
including virtually the entire Namib
Desert coastal strip
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,087 sq km
land: 886,037 sq km
water: 59,050 sq km
note: includes the islands of Mafia,
Pemba, and Zanzibar
Area — comparative: slightly larger than
twice the size of California
Land boundaries:
total: 3,861 km
border countries: Burundi 451 km,
Democratic Republic of the Congo 459
km, Kenya 769 km, Malawi 475 km,
Mozambique 756 km, Rwanda 217 km,
Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: varies from tropical along coast
to temperate in highlands
Terrain: plains along coast; central
plateau; highlands in north, south
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower, tin,
phosphates, iron ore, coal, diamonds,
gemstones, gold, natural gas, nickel
Land use:
arable land: 4-23%
permanent crops : 1.1 6%
other: 94.61% (2005)
Irrigated land: 1,840 sq km (2003)
Total renewable water resources: 91 cu
km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 5.18 cu
km/yr (10%/0%/89%)
per capita: 135 cu m/yr (2000)
Natural hazards: flooding on the central
plateau during the rainy season; drought
Environment — current issues: soil
degradation; deforestation; desertifica¬
tion; destruction of coral reefs threatens
marine habitats; recent droughts affected
marginal agriculture; wildlife threatened
by illegal hunting and trade, especially
for ivory
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: Kilimanjaro is
highest point in Africa; bordered by
three of the largest lakes on the conti¬
nent: Lake Victoria (the world’s second-
largest freshwater lake) in the north,
Lake Tanganyika (the world’s second
deepest) in the west, and Lake Nyasa in
the southwest','61fa740640ab49dcca922607dc838dd511f7ac74135b67e1e59e16412cb48dd9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c2ea85d6dc4c23f68a925b1285beeb5cda9201adbc06d3373cc67e886f4a01b',2009,'NR','Nauru','geography',894,'Location: Oceania, island in the South
Pacific Ocean, south of the Marshall
Islands
Geographic coordinates: 0 32 S, 166 55
E
Map references: Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area— comparative: about 0.1 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical with a monsoonal pat¬
tern; rainy season (November to February)
Terrain: sandy beach rises to fertile ring
around raised coral reefs with phosphate
plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along
plateau rim 61m
Natural resources: phosphates, fish
Land use:
arable land: 0%
permanent crops: 0%
Other: 100% (2005)
Irrigated land: NA
Natural hazards: periodic droughts
Environment— current issues: limited
natural fresh water resources, roof storage
tanks collect rainwater, but mostly
dependent on a single, aging desalina¬
tion plant; intensive phosphate mining
during the past 90 years — mainly by a
UK, Australia, and NZ consortium — has
left the central 90% of Nauru a waste¬
land and threatens limited remaining
land resources
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: Nauru is one of the
three great phosphate rock islands in the
Pacific Ocean — the others are Banaba
(Ocean Island) in Kiribati and Makatea
in French Polynesia; only 53 km south of
Equator
Population: 13,770 (July 2008 est.)
Age structure:
0-14 years: 35.5% (male 2,492/female
2,393)
15-64 years: 62.5% (male 4,237/female
4,363)
65 years and over: 2.1% (male 148/female
137) (2008 est.)
Median age:
total: 21.3 years
male: 20.7 years
female: 21.9 years (2008 est.)
Population growth rate: 1.772% (2008
est.)
Birth rate: 24.26 births/1,000 population
(2008 est.)
Death rate: 6.54 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 1.08 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 9.43 deaths/1,000 live births
male: 11.84 deaths/1,000 live births
female: 6.9 deaths/1,000 live births (2008
est.)
Life expectancy at birth:
total population: 63.81 years
male: 60.2 years
female: 67.6 years (2008 est.)
Total fertility rate: 2.94 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HiV/AIDS — deaths: NA
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other
Pacific Islander 26%, Chinese 8%,
European 8%
Religions: Christian (two-thirds
Protestant, one-third Roman Catholic)
Languages: Nauruan (official; a distinct
Pacific Island language), English widely
understood, spoken, and used for most
government and commercial purposes
Literacy: NA','179bcf1d18afeffea6ac7daf5dbc7dd35867b6213f8295c51260d934fece5691','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fdb6b1be07c1910b63fd29f3447523fef444ac3f43f6c5d33fbc644d56b000e',2009,'NP','Nepal','geography',898,'Location: Southern Asia, between China
and India
Geographic coordinates: 28 00 N, 84 00
E
Map references: Asia
Area: total: 147,181 sq km
land: 143,181 sq km
water: 4,000 sq km
Area — comparative: slightly larger than
Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1,236 km, India
1,690 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: varies from cool summers and
severe winters in north to subtropical
summers and mild winters in south
Terrain: Tarai or flat river plain of the
Ganges in south, central hill region,
rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,850 m
Natural resources: quartz, water, timber,
hydropower, scenic beauty, small deposits
of lignite, copper, cobalt, iron ore
Land use: arable land: 16.07%
permanent crops: 0.85%
other: 83.08% (2005)
Irrigated land: 11,700 sq km (2003)
Total renewable water resources: 210.2
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 10.18 cu
km/yr (3%/l%/96%)
per capita: 375 cu m/yr (2000)
Natural hazards: severe thunderstorms,
flooding, landslides, drought, and famine
depending on the timing, intensity, and
duration of the summer monsoons
Environment — current issues: defor¬
estation (overuse of wood for fuel and
lack of alternatives); contaminated water
(with human and animal wastes, agricul¬
tural runoff, and industrial effluents);
wildlife conservation; vehicular emis¬
sions
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Marine Life
Conservation
Geography — note: landlocked; strategic
location between China and India; con¬
tains eight of world’s 10 highest peaks,
including Mount Everest and
Kanchenjunga — the world’s tallest and
third tallest — on the borders with China
and India respectively','304f9aa5937810120ab425d0198248614657a084be0cafe03c02defc92bf9657','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20baacab65ab6231acbc7d248484033582ac6fc412123af58139813f05a8c445',2009,'NL','Netherlands','geography',908,'Location: Caribbean, two island groups
in the Caribbean Sea — composed of five
islands, Curacao and Bonaire located off
the coast of Venezuela, and Sint
Maarten, Saba, and Sint Eustatius lie
east of the US Virgin Islands
Geographic coordinates: 12 15 N, 68 45
W
Map references: Central America and
the Caribbean
Area:
total: 960 sq km
land: 960 sq km
water : 0 sq km
note: includes Bonaire, Curacao, Saba,
Sint Eustatius, and Sint Maarten (Dutch
part of the island of Saint Martin)
Area — comparative: more than five
times the size of Washington, DC
Land boundaries:
total: 15 km
border countries: Saint Martin 15 km
Coastline: 364 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 12 nm
Climate: tropical; ameliorated by north¬
east trade winds
Terrain: generally hilly, volcanic interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao
only), salt (Bonaire only)
Land use:
arable land: 10%
permanent crops: 0%
other: 90% (2005)
Irrigated land: NA
Natural hazards: Sint Maarten, Saba,
and Sint Eustatius are subject to hurri¬
canes from July to October; Curacao and
Bonaire are south of Caribbean hurri¬
cane belt and are rarely threatened
Environment— current issues: NA
Geography — note: the five islands of the
Netherlands Antilles are divided geo¬
graphically into the Leeward Islands
(northern) group (Saba, Sint Eustatius,
and Sint Maarten) and the Windward
Islands (southern) group (Bonaire and
Curacao); the island of Saint Martin is
the smallest landmass in the world
shared by two independent states, the
French territory of Saint Martin and the
Dutch territory of Sint Maarten','969e3ceb5ab89a24fd19bed55231d6b14b78ee995d3d7ce64a4ba7e10c508cea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('362fa602b86a0bc208f3ae08fafb20c3acde0d6df38b94efa11ef67c71055320',2009,'VU','Vanuatu','geography',914,'Location: Oceania, islands in the South
Pacific Ocean, east of Australia
Geographic coordinates: 21 30 S, 165
30 E
Map references: Oceania
Area: total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
Area — comparative: slightly smaller
than New Jersey
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast
trade winds; hot, humid
Terrain: coastal plains with interior
mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
467
THE CIA WORLD FACTBOOK
highest point: Mont Panie 1,628 m
Natural resources: nickel, chrome, iron,
cobalt, manganese, silver, gold, lead,
copper
Land use:
arable land: 0.32%
permanent crops: 0.22%
other: 99.46% (2005)
Irrigated land: 100 sq km (2003)
Natural hazards: cyclones, most fre¬
quent from November to March
Environment— current issues: erosion
caused by mining exploitation and forest
fires
Geography — note: consists of the main
island of New Caledonia (one of the
largest in the Pacific Ocean), the archi¬
pelago of lies Loyaute, and numerous
small, sparsely populated islands and
atolls
Population: 224,824 (July 2008 est.)
Age structure:
0-14 years: 27.3% (male 31,376/female
30,064)
15-64 years: 65.6% (male 74,064/female
73,369)
65 years and over: 7.1% (male
7,377/female 8,574) (2008 est.)
Median age:
total: 28.4 years
male: 28 years
female: 28.8 years (2008 est.)
Population growth rate: 1.175% (2008
est.)
Birth rate: 17.39 births/1,000 population
(2008 est.)
Death rate: 5.64 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
note: there has been steady emigration
from Wallis and Futuna to New
Caledonia (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.01 male(s)/female
(2008 est.)
Infant mortality rate:
total: 7.19 deaths/1,000 live births
male: 7.85 deaths/1,000 live births
female: 6.5 deaths/1,000 live births (2008
est.)
Life expectancy at birth:
total population: 74-75 years
male: 71.76 years
female: 77.88 years (2008 est.)
Total fertility rate: 2.21 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality: noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%,
European 37.1%, Wallisian 8.4%,
Polynesian 3.8%, Indonesian 3.6%,
Vietnamese 1.6%, other 3%
Religions: Roman Catholic 60%,
Protestant 30%, other 10%
Languages: French (official), 33
Melanesian-Polynesian dialects
Literacy:
definition: age 15 and over can read and
write
total population: 96.2%
male: 96.8%
female: 95.5% (1996 census)
Location: Oceania, group of islands in
the South Pacific Ocean, east of Papua
New Guinea
Geographic coordinates: 8 00 S, 159 00
E
Map references: Oceania
Area:
total: 28,450 sq km
land: 27,540 sq km
water: 910 sq km
Area — comparative: slightly smaller
than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime Claims: measured from
claimed archipelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 2 00 nm
Climate: tropical monsoon; few
extremes of temperature and weather
Terrain: mostly rugged mountains with
some low coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu
2,447 m
Natural resources: fish, forests, gold,
bauxite, phosphates, lead, zinc, nickel
Land use:
arable land: 0.62%
permanent crops: 2.04%
other: 97.34% (2005)
Irrigated land: NA
Total renewable water resources: 44 7
cu km (1987)
Natural hazards: typhoons, but rarely
destructive; geologically active region
with frequent earthquakes, tremors, and
volcanic activity; tsunamis
Environment — current issues: defor¬
estation; soil erosion; many of the sur¬
rounding coral reefs are dead or dying
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Environmental
Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location on
sea routes between the South Pacific
Ocean, the Solomon Sea, and the Coral
Sea; on 2 April 2007 an undersea earth¬
quake measuring 8.1 on the Richter scale
occurred 345 km WNW of the capital
Honiara, the resulting tsunami devas¬
tated coastal areas of Western and
Choiseul provinces with dozens of deaths
and thousands dislocated; the provincial
capital of Gizo was especially hard hit
Location: Northern South America, bor¬
dering the Caribbean Sea and the North
Atlantic Ocean, between Colombia and','ba64fbdd7d8a71218a3d9e27af13d8a936144cfb08ead5c1ed4954d72d8ad23b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fad1f096730c56973e16f99f9a3281a109a975089e655766ee446625862097c3',2009,'NZ','New Zealand','geography',922,'Location: Oceania, islands in the South
Pacific Ocean, southeast of Australia
Geographic coordinates: 41 00 S, 174
00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,021 sq km
water: NA
note: includes Antipodes Islands,
Auckland Islands, Bounty Islands,
Campbell Island, Chatham Islands, and
Kermadec Islands
Area— comparative: about the size of
Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: temperate with sharp regional
contrasts
Terrain: predominately mountainous
with some large coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Aoraki-Mount Cook 3,754 m
Natural resources: natural gas, iron ore,
sand, coal, timber, hydropower, gold,
limestone
Land use:
arable land: 5.54%
permanent crops: 6.92%
other: 87.54% (2005)
Irrigated land: 2,850 sq km (2003)
Total renewable water resources: 397
cu km (1995)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.11 cu
km/yr (48%/9%/42%)
per capita: 524 cu m/yr (2000)
Natural hazards: earthquakes are
common, though usually not severe; vob
canic activity
Environment— current issues: defor¬
estation; soil erosion; native flora and
fauna hard-hit by invasive species
Environment— international agree¬
ments: party to: Antarctic-Environ¬
mental Protocol, Antarctic-
Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic Seals,
Marine Life Conservation
Geography— note: about 80% of the
population lives in cities; Wellington is
the southernmost national capital in the
world','0e33e3afb636e72b1113850c86ef2e65a7274331cf6ecb72f24f6946a20a1b09','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53793e2033c141c973c0d04ebdc7df07355445bc484bc0176e1609f511b6373a',2009,'NE','Niger','geography',934,'Location: Western Africa, southeast of
Location: Western Africa, bordering the
478','63bed33ea8fb99b69a327dc1ebf9d9cd4b80112058d2b4fa644c6a52a983d7df','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e33b009d8a60baa04062a7e72f1fe748c88144432fce8cbf5ac05d898641c4f3',2009,'NG','Nigeria','geography',936,'Gulf of Guinea, between Benin and
Location: Oceania, island in the South
Pacific Ocean, east of Tonga
Geographic coordinates: 19 02 S, 169
52 W
Map references: Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area— comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast
trade winds
Terrain: steep limestone cliffs along
coast, central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near
Mutalau settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 11.54%
permanent crops: 15.38%
other: 73.08% (2005)
Irrigated land: NA
Natural hazards: typhoons
Environment— current issues:
increasing attention to conservationist
practices to counter loss of soil fertility
from traditional slash and burn agricul¬
ture
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea
signed, but not ratified: none of the
selected agreements
Geography — note: one of world’s largest
coral islands','80ff3eeb6665b0fb965c299f135774b76c49f16177131ff95f01ee8dfb05c885','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78e5fe061f4bb6bdc33f63037f2f969c6de957cb4090118118c0818afb71098',2009,'NF','Norfolk Island','geography',944,'Location: Oceania, island in the South
Pacific Ocean, east of Australia
Geographic coordinates: 29 02 S, 167
57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34-6 sq km
water: 0 sq km
Area— comparative: about 0.2 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: subtropical; mild, little sea¬
sonal temperature variation
Terrain: volcanic formation with mostly
rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: typhoons (especially
May to July)
Environment — current issues: NA
Geography— note: most of the 32 km
coastline consists of almost inaccessible
cliffs, but the land slopes down to the sea
in one small southern area on Sydney
Bay, where the capital of Kingston is sit¬
uated
Population: 2,128 (July 2008 est.)
Age structure:
0-14 years: 20.2%
15-64 years: 63.9%
65 years and over: 15.9% (2007 est.)
Population growth rate: 0.006% (2008
est.)
Birth rate: NA
Death rate: NA (2008 est.)
Net migration rate: NA
Sex ratio:
NA
Infant mortality rate: total NA
male: NA
female: NA (2008 est.)
Life expectancy at birth:
total population: NA
male: NA
female: NA (2008 est.)
Total fertility rate: NA (2008 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander (s)
Ethnic groups: descendants of the
Bounty mutineers, Australian, New
Zealander, Polynesian
Religions: Anglican 34.9%, Roman
Catholic 11.7%, Uniting Church in
Australia 11.2%, Seventh-Day
Adventist 2.8%, Australian Christian
2.4%, Jehovah’s Witness 0.9%, other
2.7%, unspecified 15.2%, none 18.1%
(2001 census)
Languages: English (official), Norfolk —
a mixture of 18th century English and
ancient Tahitian
Literacy:
NA','636ed8bf95ab798ae0ee3014e4fba22429ec80b4720ab8dab0f5c4003a498f9f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5d0d733018c31ae925bad312e1ba803d99e6e7fb281f5ca6d0183ae04ae0396',2009,'FI','Finland','geography',957,'Location: Northern Europe, bordering
the North Sea and the North Atlantic
Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00
E
Map references: Europe
Area:
total: 323,802 sq km
land: 307,442 sq km
water: 16,360 sq km
Area— comparative: slightly larger than
New Mexico
Land boundaries: total: 2,542 km
border countries: Finland 727 km, Sweden
1,619 km, Russia 196 km
Coastline: 25,148 km (includes main¬
land 2,650 km, as well as long fjords,
numerous small islands, and minor
indentations 22,498 km; length of island
coastlines 58,133 km)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: temperate along coast, modi¬
fied by North Atlantic Current; colder
interior with increased precipitation and
colder summers; rainy year-round on
west coast
Terrain: glaciated; mostly high plateaus
and rugged mountains broken by fertile
valleys; small, scattered plains; coastline
deeply indented by fjords; arctic tundra
in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Galdhopiggen 2,469 m
Natural resources: petroleum, natural
gas, iron ore, copper, lead, zinc, titanium,
pyrites, nickel, fish, timber, hydropower
Land use:
arable land: 2.7%
permanent crops: 0%
other: 97.3% (2005)
Irrigated land: 1,270 sq km (2003)
Total renewable water resources: 381.4
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.4 cu
km/yr (23%/67%/10%)
per capita: 519 cu m/yr (1996)
Natural hazards: rockslides, avalanches
Environment— current issues: water
pollution; acid rain damaging forests and
adversely affecting lakes, threatening fish
stocks; air pollution from vehicle emis¬
sions
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: about two-thirds
mountains; some 50,000 islands off its
much indented coastline; strategic loca¬
tion adjacent to sea lanes and air routes
in North Atlantic; one of most rugged
and longest coastlines in the world','05186b03e8dedde8e8311b06cc18d6f97e25d341456d000ccde86ebe1d99c691','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67fbee86ce8ef794d2ed23ac8ace46ddf45c1555dada3a0f1e8f6b67fe06f6ec',2009,'NO','Norway','geography',960,'Location: Middle East, bordering the
Arabian Sea, Gulf of Oman, and Persian
Gulf, between Yemen and UAE
Geographic coordinates: 21 00 N, 57 00
E
Map references: Middle East
Area: total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Kansas
Land boundaries:
total: 1,374 km
border countries: Saudi Arabia 676 km,
UAE 410 km, Yemen 288 km
Coastline: 2,092 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: dry desert; hot, humid along
coast; hot, dry interior; strong southwest
summer monsoon (May to September)
in far south
Terrain: central desert plain, rugged
mountains in north and south
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal Shams 2,980 m
Natural resources: petroleum, copper,
asbestos, some marble, limestone,
chromium, gypsum, natural gas
Land use:
arable land: 0.12%
permanent crops: 0.14%
other: 99.74% (2005)
Irrigated land: 720 sq km (2003)
Total renewable water resources: l cu
km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.36 cu
km/yr (7%/2%/90%)
per capita: 529 cu m/yr (2000)
Natural hazards: summer winds often
raise large sandstorms and dust storms in
interior; periodic droughts
Environment — current issues: rising
soil salinity; beach pollution from oil
spills; limited natural fresh water
resources
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location on
Musandam Peninsula adjacent to Strait
of Hormuz, a vital transit point for world
crude oil','6a88613a2063b9ac71e9c0c08f6476c498326d6501d2996167a206d36c3065be','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58187b2bd12014428e56128caddd61b200830f3735de25bbd291987bb37fb0fd',2009,'OM','Oman','geography',967,'Location: body of water between the
Southern Ocean, Asia, Australia, and
the Western Hemisphere
Geographic coordinates: 0 00 N, 160 00
w
Map references: Political Map of the
World
Area:
total: 155.557 million sq km
note: includes Bali Sea, Bering Sea,
Bering Strait, Coral Sea, East China Sea,
Gulf of Alaska, Gulf of Tonkin,
Philippine Sea, Sea of Japan, Sea of
Okhotsk, South China Sea, Tasman Sea,
and other tributary water bodies
Area — comparative: about 15 times the
size of the US; covers about 28% of the
global surface; larger than the total land
area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems
and resultant wind patterns exhibit
remarkable uniformity in the south and
east; trade winds and westerly winds are
well-developed patterns, modified by
seasonal fluctuations; tropical cyclones
(hurricanes) may form south of Mexico
from June to October and affect Mexico
and Central America; continental influ¬
ences cause climatic uniformity to be
much less pronounced in the eastern and
western regions at the same latitude in
the North Pacific Ocean; the western
Pacific is monsoonal — a rainy season
occurs during the summer months, when
moisture-laden winds blow from the
ocean over the land, and a dry season
during the winter months, when dry
winds blow from the Asian landmass
back to the ocean; tropical cyclones
(typhoons) may strike southeast and east
Asia from May to December
Terrain: surface currents in the northern
Pacific are dominated by a clockwise,
warm-water gyre (broad circular system
of currents) and in the southern Pacific
by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in
the Bering Sea and Sea of Okhotsk in
winter; in the southern Pacific, sea ice
from Antarctica reaches its northern¬
most extent in October; the ocean floor
in the eastern Pacific is dominated by the
East Pacific Rise, while the western
Pacific is dissected by deep trenches,
including the Mariana Trench, which is
the world’s deepest
Elevation extremes:
lowest point: Challenger Deep in the
Mariana Trench -10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields,
polymetallic nodules, sand and gravel
aggregates, placer deposits, fish
Natural hazards: surrounded by a zone
of violent volcanic and earthquake
activity sometimes referred to as the
“Pacific Ring of Fire”; subject to tropical
cyclones (typhoons) in southeast and
east Asia from May to December (most
frequent from July to October); tropical
cyclones (hurricanes) may form south of
Mexico and strike Central America and
Mexico from June to October (most
common in August and September);
cyclical El Nino/La Nina phenomenon
occurs in the equatorial Pacific, influ¬
encing weather in the Western
Hemisphere and the western Pacific;
ships subject to superstructure icing in
extreme north from October to May;
persistent fog in the northern Pacific can
be a maritime hazard from June to
December
Environment — current issues: endan¬
gered marine species include the dugong,
sea lion, sea otter, seals, turtles, and
whales; oil pollution in Philippine Sea
and South China Sea
Geography — note: the major choke-
points are the Bering Strait, Panama
Canal, Luzon Strait, and the Singapore
Strait; the Equator divides the Pacific
Ocean into the North Pacific Ocean and
the South Pacific Ocean; dotted with
low coral islands and rugged volcanic
islands in the southwestern Pacific
Ocean
Economy — overview: The Pacific
Ocean is a major contributor to the
world economy and particularly to those
nations its waters directly touch. It pro¬
vides low-cost sea transportation
between East and West, extensive fishing
grounds, offshore oil and gas fields, min¬
erals, and sand and gravel for the con¬
struction industry. In 1996, over 60% of
the world’s fish catch came from the
Pacific Ocean. Exploitation of offshore
oil and gas reserves is playing an ever-
increasing role in the energy supplies of
the US, Australia, NZ, China, and Peru.
The high cost of recovering offshore oil
and gas, combined with the wide swings
in world prices for oil since 1985, has led
to fluctuations in new drillings.','0396401d593ac2cc6ee4102aafe95898d4e00a8d0acc6a7b0acd0fe1480ab2d4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b306cd000c679593ab3448f73f0eba53370d7d955edfc636733bb6eb178345d',2009,'PG','Papua New Guinea','geography',984,'Location: Oceania, group of islands
including the eastern half of the island of
New Guinea between the Coral Sea and
the South Pacific Ocean, east of
Flag description: divided diagonally
from upper hoist-side comer; the upper
triangle is red with a soaring yellow bird
of paradise centered; the lower triangle is
black with five, white, five-pointed stars
of the Southern Cross constellation cen¬
tered','ebfcd29017afd91b6fcf166b2ec5b0fcc2d0627b21148465d25431009531104a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('255a748d048bfec25b5f645d10906012fd0b33a5812214ba84095beb9961e363',2009,'PY','Paraguay','geography',995,'Location: Central South America,
northeast of Argentina
508
Geographic coordinates: 23 00 S, 58 00
w
Map references: South America
Area: total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area — comparative: slightly smaller
than California
Land boundaries:
total: 3,995 km
border countries: Argentina 1,880 km,
Bolivia 750 km, Brazil 1,365 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: subtropical to temperate; sub¬
stantial rainfall in the eastern portions,
becoming semiarid in the far west
Terrain: grassy plains and wooded hills
east of Rio Paraguay; Gran Chaco region
west of Rio Paraguay mostly low, marshy
plain near the river, and dry forest and
thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay
and Rio Parana 46 m
highest point: Cerro Pero (Cerro Tres
Kandu) 842 m
Natural resources: hydropower, timber,
iron ore, manganese, limestone
Land use:
arable land: 7-47%
permanent crops: 0.24%
other: 92.29% (2005)
Irrigated land: 670 sq km (2003)
Total renewable water resources: 336
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total. 0.49 cu
km/yr ( 20%/8%/7 1 % )
per capita: 80 cu m/yr (2000)
Natural hazards: local flooding in south¬
east (early September to June); poorly
drained plains may become boggy (early
October to June)
Environment — current issues: defor¬
estation; water pollution; inadequate
means for waste disposal pose health risks
for many urban residents; loss of wet¬
lands
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; lies
between Argentina, Bolivia, and Brazil;
population concentrated in southern
part of country','950e11ef042084ba479ab697dd350578ecd831a7716ceeee6ee3523fc602b59e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed4af1a80d737824990c5a9d2223cb2cb132b45eeba407ba1d7c5b4d24cb4b2a',2009,'PE','Peru','geography',999,'Location: Western South America, bor-
dering the South Pacific Ocean, between
Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00
w
Map references: South America
Area: total: 1,285,220 sq km
land: 1.28 million sq km
water: 5,220 sq km
Area — comparative: slightly smaller
than Alaska
Land boundaries:
total: 7,461 km
border countries: Bolivia 1,075 km, Brazil
2,995 km, Chile 171 km, Colombia
1,800 km, Ecuador 1,420 km
Coastline: 2,414 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200 nm
Climate: varies from tropical in east to
dry desert in west; temperate to frigid in
Andes
Terrain: western coastal plain (costa),
high and rugged Andes in center (sierra),
eastern lowland jungle of Amazon Basin
(selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold,
petroleum, timber, fish, iron ore, coal,
phosphate, potash, hydropower, natural
gas
Land use: arable land: 2.88%
permanent crops: 0.47%
other: 96.65% (2005)
Irrigated land: 12,000 sq km (2003)
Total renewable water resources: 1,913
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 20.13 cu
km/yr (8%/10%/82%)
per capita: 720 cu m/yr (2000)
Natural hazards: earthquakes, tsunamis,
flooding, landslides, mild volcanic
activity
Environment — current issues: defer-
estation (some the result of illegal log''
ging); overgrazing of the slopes of the
costa and sierra leading to soil erosion;
desertification; air pollution in Lima;
pollution of rivers and coastal waters
from municipal and mining wastes
Environment — international agree¬
ments: party to: Antarctic-Environ-
mental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change''Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: shares control of
Lago Titicaca, world’s highest navigable
lake, with Bolivia; a remote slope of
Nevado Mismi, a 5,316 m peak, is the
ultimate source of the Amazon River','0e536aae6f805780730c13cf45e9089264cdc94d1672a1ddcde4569e491ceb2b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1b056a43a4d6da54bfcf80f6fd2b9f942456338fa6e439f0f5112a3ebb3fa5b',2009,'PH','Philippines','geography',1000,'Location: Southeastern Asia, archi¬
pelago between the Philippine Sea and
the South China Sea, east of Vietnam
Geographic coordinates: 13 00 N, 122
00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
land: 298,170 sq km
water: 1,830 sq km
Area — comparative: slightly larger than
Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims:
territorial sea: irregular polygon
extending up to 100 nm from coastline as
defined by 1898 treaty; since late 1970s
has also claimed polygonal-shaped area
in South China Sea up to 285 nm in
breadth
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical marine; northeast
monsoon (November to April); south¬
west monsoon (May to October)
Terrain: mostly mountains with narrow
to extensive coastal lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum,
nickel, cobalt, silver, gold, salt, copper
Land use:
arable land: 19%
permanent crops: 16.67%
other: 64.33% (2005)
Irrigated land: 15,500 sq km (2003)
Total renewable water resources: 479
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 28.52 cu
km/yr (17%/9%/74%)
per capita: 343 cu m/yr (2000)
Natural hazards: astride typhoon belt,
usually affected by 15 and struck by five
to six cyclonic storms per year; land¬
slides; active volcanoes; destructive
earthquakes; tsunamis
Environment — current issues: uncon¬
trolled deforestation especially in water¬
shed areas; soil erosion; air and water
pollution in major urban centers; coral
reef degradation; increasing pollution of
coastal mangrove swamps that are impor¬
tant fish breeding grounds
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
515
THE CIA WORLD FACTBOOK
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography — note: the Philippine archi¬
pelago is made up of 7,107 islands; favor¬
ably located in relation to many of
Southeast Asia’s main water bodies: the
South China Sea, Philippine Sea, Sulu
Sea, Celebes Sea, and Luzon Strait
Population: 92,681,453 (July 2008 est.)
Age structure:
0-14 years: 34.1% (male
16,121,508/female 15,487,841)
15-64 years: 61.7% (male
28,524,176/female 28,652,155)
65 years and over: 4.2% (male
1 ,690,006/female 2,205,767) (2008 est.)
Median age:
total: 23 years
male: 22.5 years
female: 23.5 years (2008 est.)
Population growth rate: 1.728% (2008
est.)
Birth rate: 24.07 births/1,000 population
(2008 est.)
Death rate: 5.32 deaths/ 1,000 popula¬
tion (2008 est.)
Net migration rate: -1.47 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 21.45 deaths/ 1,000 live births
male: 24-14 deaths/1,000 live births
female: 18.64 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 70.8 years
male: 67.89 years
female: 73.85 years (2008 est.)
Total fertility rate: 3 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 9,000 (2003 est.)
HIV/AIDS — deaths: fewer than 500
(2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorbome diseases: dengue fever and
malaria (2008)
Nationality: noun: Filipino(s)
adjective: Philippine
Ethnic groups: Tagalog 28.1%, Cebuano
13.1%, Ilocano 9%, Bisaya/Binisaya
7.6%, Hiligaynon Ilonggo 7.5%, Bikol
6%, Waray 3.4%, other 25.3% (2000
census)
Religions: Roman Catholic 80.9%,
Muslim 5%, Evangelical 2.8%, Iglesia ni
Kristo 2.3%, Aglipayan 2%, other
Christian 4-5%, other 1.8%, unspecified
0.6%, none 0.1% (2000 census)
Languages: Filipino (official; based on
Tagalog) and English (official); eight
major dialects — Tagalog, Cebuano,
Ilocano, Fliligaynon or Ilonggo, Bicol,
Waray, Pampango, and Pangasinan
Literacy: definition: age 15 and over can
read and write
total population: 92.6%
male: 92.5%
female: 92.7% (2000 census)
Location: Oceania, islands in the South
Pacific Ocean, about midway between
Peru and New Zealand
Geographic coordinates: 25 04 S, 130
06 W
Map references: Oceania
Area: total: 47 sq km
land: 47 sq km
water: 0 sq km
Area — comparative: about 0.3 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
territorial sea: 3 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; modi¬
fied by southeast trade winds; rainy
season (November to March)
Terrain: rugged volcanic formation;
rocky coastline with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold,
silver, and zinc have been discovered off¬
shore
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Natural hazards: typhoons (especially
November to March)
Environment — current issues: defor¬
estation (only a small portion of the orig¬
inal forest remains because of burning
and clearing for settlement)
Geography — note: Britain’s most iso¬
lated dependency; only the larger island
of Pitcairn is inhabited but it has no port
or natural harbor; supplies must be trans¬
ported by rowed longboat from larger
ships stationed offshore
Population: 48 (July 2008 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0% (2008 est.)
Birth rate: NA
Death rate: NA (2008 est.)
Net migration rate: NA
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA (2008 est.)
Life expectancy at birth:
total population: NA
male: NA
female: NA (2008 est.)
Total fertility rate: NA (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the
Bounty mutineers and their Tahitian
wives
Religions: Seventh-Day Adventist
100%
Languages: English (official), Pitkem
(mixture of an 18th century English
dialect and a Tahitian dialect)
Literacy: NA
Country name:
conventional long form: Pitcairn,
Henderson, Ducie, and Oeno Islands
conventional short form: Pitcairn Islands
Dependency status: overseas territory of
the UK
Government type: NA
Capital: name: Adamstown
geographic coordinates: 25 04 S, 130 05 W
time difference: UTC-9 (4 hours behind
Washington, DC during Standard Time)
519
THE CIA WORLD FACTBOOK
Administrative divisions: none (over-
seas territory of the UK)
Independence: none (overseas territory
of the UK)
National holiday: Birthday of Queen
ELIZABETH II, second Saturday in June
(1926)
Constitution: 30 November 1838;
reformed 1904 with additional reforms in
1940; further refined by the Local
Government Ordinance of 1964
Legal system: local island by-laws
Suffrage: 18 years of age; universal with
three years residency
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); represented by
UK High Commissioner to New Zealand
and Governor (nonresident) of the
Pitcairn Islands George FERGUSSON
(since April 2006); Commissioner (non¬
resident) Leslie JAQUES (since
September 2003) serves as liaison between
the governor and the Island Council
head of government: Governor George
FERGUSSON (since April 2006);
Mayor and Chairman of the Island
Council Mike WARREN (since 1
January 2008)
cabinet: NA
elections: the monarchy is hereditary;
governor and commissioner appointed
by the monarch; island mayor elected by
popular vote for a three-year term; elec¬
tion last held December 2004 (next to be
held in December 2007)
election results: Jay WARREN elected
mayor and chairman of the Island
Council
Legislative branch: unicameral Island
Council (10 seats; 5 members elected by
popular vote, 1 nominated by the 5
elected members, 2 appointed by the
governor including 1 seat for the Island
Secretary, the Island Mayor, and a com¬
missioner liaising between the governor
and council; elected members serve one-
year terms)
elections: last held 24 December 2006
(next to be held in December 2007)
election results: percent of vote — NA;
seats — all independents
Judicial branch: Magistrate’s Court;
Supreme Court; Court of Appeal;
Judicial Officers are appointed by the
Governor
Political parties and leaders: none
Political pressure groups and leaders:
none
International organization participa¬
tion: SPC, UPU
Diplomatic representation in the US:
none (overseas territory of the UK)
Diplomatic representation from the US:
none (overseas territory of the UK)
Flag description: blue with the flag of
the UK in the upper hoist-side quadrant
and the Pitcairn Islander coat of arms
centered on the outer half of the flag; the
coat of arms is yellow, green, and light
blue with a shield featuring a yellow
anchor
Geographic coordinates: 8 38 N, 1 1 1 55
E
Map references: Southeast Asia
Area: total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs,
and sea mounts scattered over an area of
nearly 410,000 sq km of the central
South China Sea
Area— comparative: NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on
Southwest Cay 4 m
Natural resources: fish, guano, undeter¬
mined oil and natural gas potential
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: typhoons; numerous
reefs and shoals pose a serious maritime
hazard
Environment — current issues: NA
Geography — note: strategically located
near several primary shipping lanes in
the central South China Sea; includes
numerous small islands, atolls, shoals,
and coral reefs','140c63b666ef70a17e22c8b9e8ec1a60e63bf65cb58695ef50e3a52ea5f73e1d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d0d1d2ad801a9788ac33e2b54e5ba1d72e1239ec97137a1eb8b710c8a41479',2009,'PR','Puerto Rico','geography',1014,'Location: Caribbean, island between the
Caribbean Sea and the North Atlantic
Ocean, east of the Dominican Republic
Geographic coordinates: 18 15 N, 66 30
w
Map references: Central America and
the Caribbean
Area:
total: 13,790 sq km
land: 8,87 0 sq km
water: 4,921 sq km
Area — comparative: slightly less than
three times the size of Rhode Island
527
THE CIA WORLD FACTBOOK
Mayagmz
N&&TN ATLANTIC QGMSM
^SAN JUAN
Araobo Bayamon M *
fiuaynabo* , •CaroSini''1'', ,«4*; . H
Fa,ardo* ’ >
Puerto Rico <*»*%, U '' ''
?SSS <!&
- - '' “*
''(^W) Cfe
Atea ,San German
r* ^T! *POflCe Guayama. V***
*Las Mareas
-
: V1 V T . '' '' ; '' ''
« |e*»
MMMMR
Cm Sb&
n & >m
y ww
-i -
„ &em\\
Land boundaries: 0 km
Coastline: 501 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine, mild; little sea¬
sonal temperature variation
Terrain: mostly mountains with coastal
plain belt in north; mountains precipi¬
tous to sea on west coast; sandy beaches
along most coastal areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1,339 m
Natural resources: some copper and
nickel; potential for onshore and off¬
shore oil
Land use: arable land: 3.69%
permanent crops: 5.59%
other: 90.72% (2005)
Irrigated land: 400 sq km (2003)
Natural hazards: periodic droughts; hur¬
ricanes
Environment— current issues: erosion;
occasional drought causing water short¬
ages
Geography— note: important location
along the Mona Passage — a key shipping
lane to the Panama Canal; San Juan is
one of the biggest and best natural har¬
bors in the Caribbean; many small rivers
and high central mountains ensure land
is well watered; south coast relatively
dry; fertile coastal plain belt in north
Population: 3,958,128 (July 2008 est.)
Age structure:
0-14 years: 20.5% (male 415,141/female
396,782)
15-64 years: 66% (male
1,254,416/female 1,358,229)
65 years and over: 13.5% (male
229,727/female 303,833) (2008 est.)
Median age: total: 35.6 years
male: 33.8 years
female: 37.3 years (2008 est.)
Population growth rate: 0.369% (2008
est.)
Birth rate: 12.61 births/1,000 population
(2008 est.)
Death rate: 7.88 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: -1.03 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.92 male(s)/female
(2008 est.)
Infant mortality rate:
total: 8.65 deaths/1,000 live births
male: 9.15 deaths/1,000 live births
female: 8.13 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 78.58 years
male: 74-64 years
female: 82.73 years (2008 est.)
Total fertility rate: 1.76 children
bom/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: 7,397 (1997)
HIV/AIDS — deaths: NA
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: white (mostly Spanish
origin) 80.5%, black 8%, Amerindian
0.4%, Asian 0.2%, mixed and other
10.9%
Religions: Roman Catholic 85%,
Protestant and other 15%
Languages: Spanish, English
Literacy: definition: age 15 and over can
read and write
total population: 94.1%
male: 93.9%
female: 94-4% (2002 est.)
Country name:
conventional long form: Commonwealth
of Puerto Rico
conventional short form: Puerto Rico
Dependency status: unincorporated,
organized territory of the US with com¬
monwealth status; policy relations
between Puerto Rico and the US con¬
ducted under the jurisdiction of the
Office of the President
Government type: commonwealth
Capital: name: San Juan
geographic coordinates: 18 28 N, 66 07 W
time difference: UTC-4 (1 hour ahead of
Washington, DC during Standard Time)
Administrative divisions: none (terri¬
tory of the US with commonwealth
status); there are no first-order adminis¬
trative divisions as defined by the US
Government, but there are 78 munici¬
palities (municipios, singular —
municipio) at the second order;
Adjuntas, Aguada, Aguadilla, Aguas
Buenas, Aibonito, Anasco, Arecibo,
Arroyo, Barceloneta, Barranquitas,
Bayamon, Cabo Rojo, Caguas, Camuy,
Canovanas, Carolina, Catano, Cayey,
Ceiba, Ciales, Cidra, Coamo, Comerio,
Corozal, Culebra, Dorado, Fajardo,
Florida, Guanica, Guayama, Guayanilla,
Guaynabo, Gurabo, Hatillo,
Hormigueros, Humacao, Isabela, Jayuya,
Juana Diaz, Juncos, Fajas, Fares, Fas
Marias, Las Piedras, Loiza, Luquillo,
Manati, Maricao, Maunabo, Mayaguez,
Moca, Morovis, Naguabo, Naranjito,
Orocovis, Patillas, Penuelas, Ponce,
Quebradillas, Rincon, Rio Grande,
Sabana Grande, Salinas, San German,
San Juan, San Lorenzo, San Sebastian,
Santa Isabel, Toa Alta, Toa Baja, Trujillo
Alto, Utuado, Vega Alta, Vega Baja,
Vieques, Villalba, Yabucoa, Yauco
Independence: none (territory of the US
with commonwealth status)
National holiday: US Independence
Day, 4 July (1776); Puerto Rico
Constitution Day, 25 July (1952)
Constitution: ratified 3 March 1952;
approved by US Congress 3 July 1952;
effective 25 July 1952
Legal system: based on Spanish civil
code and within the US Federal system
of justice
Suffrage: 18 years of age; universal;
island residents are US citizens but do
not vote in US presidential elections
Executive branch:
chief of state: President George W. BUSH
of the US (since 20 January 2001); Vice
President Richard B. CHENEY (since 20
January 2001)
head of government: Governor Anibal
ACEVEDO-VILA (since 2 January
2005)
cabinet: Cabinet appointed by the gov¬
ernor with the consent of the legislature
elections: under the US Constitution, res¬
idents of unincorporated territories, such
528
as Puerto Rico, do not vote in elections
for US president and vice president;
however, they may vote in Democratic
and Republican presidential primary
elections; governor elected by popular
vote for a four-year term (no term
limits); election last held 2 November
2004 (next to be held in November
2008)
election results: Anibal ACEVEDO-
VILA elected governor; percent of
vote — 48.4%
Legislative branch: bicameral
Legislative Assembly consists of the
Senate (at least 27 seats — currently 29;
members are directly elected by popular
vote to serve four-year terms) and the
House of Representatives (51 seats;
members are elected by popular vote to
serve four-year terms)
elections: Senate— last held 2 November
2004 (next to be held November 2008);
House of Representatives — last held 2
November 2004 (next to be held in
November 2008)
election results: Senate — percent of vote
by party— PNP 43.4%, PPD 40.3%, PIP
9.4%; seats by party — PNP 17, PPD 9,
PIP 1; House of Representatives — per¬
cent of vote by party — PNP 46.3%, PPD
43.1%, PIP 9.7%; seats by party — PNP
32, PPD 18, PIP 1
note: Puerto Rico elects, by popular vote,
a resident commissioner to serve a four-
year term as a nonvoting representative
in the US House of Representatives;
aside from not voting on the House floor,
he enjoys all the rights of a member of
Congress; elections last held 2
November 2004 (next to be held in
November 2008); results— percent of
vote by party — PNP 48.6%, other
51.4%; seats by party — PNP 1
Judicial branch: Supreme Court;
Appellate Court; Court of First Instance
composed of two sections: a Superior
Court and a Municipal Court (justices
for all these courts appointed by the gov¬
ernor with the consent of the Senate)
Political parties and leaders: National
Democratic Party [Roberto PRATS];
National Republican Party of Puerto
Rico [Dr. Tiody FERRE]; New
Progressive Party or PNP [Pedro
ROSSELLO] (pro-US statehood);
Popular Democratic Party or PPD
[Anibal ACEVEDO- VILA] (pro-com¬
monwealth); Puerto Rican
Independence Party or PIP [Ruben
BERRIOS Martinez] (pro-independ¬
ence)
Political pressure groups and leaders:
Boricua Popular Army or EPB (a revolu¬
tionary group also known as Los
Macheteros); note — the following rad¬
ical groups are considered dormant by
Federal law enforcement: Armed Forces
for National Liberation or FALN,
Armed Forces of Popular Resistance,
Volunteers of the Puerto Rican
Revolution
International organization participa¬
tion: Caricom (observer), Interpol (sub-
bureau), IOC, ITUC, UNWTO
(associate), UPU, WCL, WFTU
Diplomatic representation in the US:
none (territory of the US with common¬
wealth status)
Diplomatic representation from the US:
none (territory of the US with common¬
wealth status)
Flag description: five equal horizontal
bands of red (top and bottom) alter¬
nating with white; a blue isosceles tri¬
angle based on the hoist side bears a
large, white, five-pointed star in the
center; design initially influenced by the
US flag, but similar to the Cuban flag,
with the colors of the bands and triangle
reversed
Location: Middle East, peninsula bor¬
dering the Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15
E
Map references: Middle East
Area:
total: 11,437 sq km
land: 11,437 sq km
water: 0 sq km
Area — comparative: slightly smaller
than Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: as determined by
bilateral agreements or the median line
Climate: arid; mild, pleasant winters;
very hot, humid summers
Terrain: mostly flat and barren desert
covered with loose sand and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 103 m
Natural resources: petroleum, natural
gas, fish
Land use:
arable land: 1.64%
permanent crops: 0.27%
other: 98.09% (2005)
Irrigated land: 130 sq km (2002)
Total renewable water resources: 0.1
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.29 cu
km/yr (24%/3%/72%)
per capita: 358 cu m/yr (2000)
Natural hazards: haze, dust storms,
sandstorms common
Environment — current issues: limited
natural fresh water resources are
increasing dependence on large-scale
desalination facilities
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location in
central Persian Gulf near major petro¬
leum deposits
Geographic coordinates: 18 05 N, 63 57
W
Map references: Central America and
the Caribbean
Area: total: 54-4 sq km
land: 54-4 sq km
water: NEGL
Area — comparative: more than one-
third the size of Washington, DC
Land boundaries: total: 15 km
border countries: Netherlands Antilles
(Sint Maarten) 15 km
Coastline: 58.9 km (for entire island)
Climate: temperature averages 80-85
degrees all year long; low humidity,
gentle trade winds, brief, intense rain
showers; July-Novemeber is the hurri¬
cane season
Elevation extremes:
lowest point: Caribbean Ocean 0 m
highest point: Pic du Paradis 424 m
Natural resources: salt
Environment — current issues: fresh
water supply is dependent on desaliniza¬
tion of sea water
Geography— note: the island of Saint
Martin is the smallest landmass in the
world shared by two independent states,
the French territory of Saint Martin and
the Dutch territory of Sint Maarten
Population: 29,376 (July 2008 est.)
Ethnic groups: creole (mulatto), black,
Guadeloupe Mestizo (French-East Asia),
white, East Indian
Religions: Roman Catholic, Jehovah’s
Witness, Protestant, Hindu
Languages: French (official language),
English, Dutch, French Patois, Spanish,
Papiamento (dialect of Netherlands
Antilles)
Country name: conventional long form:
Overseas Collectivity of Saint Martin
conventional short form: Saint Martin
local long form: Collectivity d’outre mer
de Saint-Martin
local short form: Saint-Martin
Dependency status: overseas collec¬
tivity of France
Capital: name: Marigot
geographical coordinates: 18 04 N, 63 05 W
time difference: UTC-4 (1 hour behind
Washington, DC, during Standard Time)
daylight savings: +1 hour
Independence: none (overseas collec¬
tivity of France)
National holiday: Bastille Day, 14 July
(1789); note — local holiday is
Schoalcher Day (Slavery Abolition Day)
12 July (1848)
Constitution: 4 October 1958 (French
Constitution)
Legal system: the laws of France, where
applicable, apply
Suffrage: 18 years of age, universal
Executive branch:
chief of state: President Nicolas
SARKOZY (since 16 May 2007), repre¬
sented by Prefect Dominique LACROIX
(since 21 March 2007)
head of government: President of the
Territorial Council Louis-Constant
FLEMING (since 16 July 2007)
cabinet: Executive Council; note — there
is also an advisory economic, social, and
cultural council
election: French president elected by pop¬
ular vote to a five-year term; prefect
appointed by the French president on
the advice of the French Ministry of
Interior; president of the Territorial
Council is elected by the members of the
Council for a five-year term
election results: Louis-Constant
FLEMING unanimously elected presi¬
dent by the Territorial Council on 16
July 2007
554','7bea015ae23566e569a1333f3713f587c434556e4e9484d64cd0b957491f1187','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('542c2dabac73a1f61e33cb575f02b961cfb4df7cadbfb38f09dc01dbe78d1c15',2009,'RW','Rwanda','geography',1025,'Location: Central Africa, east of
Democratic Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,338 sq km
land: 24,948 sq km
water: 1,390 sq km
Area— comparative: slightly smaller
than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km,
Democratic Republic of the Congo 217
km, Tanzania 217 km, Uganda 169 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; two rainy seasons
(February to April, November to
January); mild in mountains with frost
and snow possible
Terrain: mostly grassy uplands and hills;
relief is mountainous with altitude
declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin
ore), wolframite (tungsten ore),
methane, hydropower, arable land
Land use:
arable land: 45.56%
permanent crops : 10.25%
other: 44-19% (2005)
Irrigated land: 90 sq km (2003)
Total renewable water resources: 5.2
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.15 cu
km/yr (24%/8%/68%)
per capita: 17 cu m/yr (2000)
Natural hazards: periodic droughts; the
volcanic Virunga mountains are in the
northwest along the border with
Democratic Republic of the Congo
Environment — current issues: defer-
estation results from uncontrolled cut¬
ting of trees for fuel; overgrazing; soil
exhaustion; soil erosion; widespread
poaching
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; most of
the country is savanna grassland with the
population predominantly rural','aa3149aaade7c42e72fa8b13bbec42d8b791cf3b4011df0fd76dfc214349a43e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed8339c860755c316f5712cfebd25949608609ec92e6e909995ae934b773dda4',2009,'GP','Guadeloupe','geography',1034,'Location: islands in the South Atlantic
Ocean, about midway between South
America and Africa; Ascension Island
lies 700 nm northwest of Saint Helena;
Tristan da Cunha lies 2300 nm southwest
of Saint Helena
Geographic coordinates: Saint Helena:
15 57 S, 5 42 W
Ascension Island: 7 57 S, 14 22 W
Tristan da Cunha island group: 37 15 S, 12
30 W
Map references: Africa
Area: total: 413 sq km
land: Saint Helena Island 122 sq km;
Ascension Island 90 sq km; Tristan da
Cunha island group 201 sq km
water: 0 sq km
Area — comparative: slightly more than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: Saint Helena: 60 km
Ascension Island: NA
Tristan da Cunha: 40 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: Saint Helena: tropical marine;
mild, tempered by trade winds
Ascension Island: tropical marine; mild,
semi-arid
Tristan da Cunha: temperate marine;
mild, tempered by trade winds (tends to
be cooler than Saint Helena)
Terrain: the islands of this group result
from volcanic activity associated with
the Atlantic Mid-Ocean Ridge
Saint Helena: rugged, volcanic; small
scattered plateaus and plains
Ascension: surface covered by lava flows
and cinder cones of 44 dormant volca¬
noes; ground rises to the east
Tristan da Cunha: sheer cliffs line the
coastline of the nearly circular island;
the flanks of the central volcanic peak
are deeply dissected; narrow coastal plain
lies between The Peak and the coastal
cliffs
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary’s Peak on
Tristan da Cunha 2,062 m; Green
Mountain on Ascension Island 859 rn;
Mount Actaeon on Saint Helena Island
818 m
Natural resources: fish, lobster
Land use: arable land: 12.9%
permanent crops: 0%
other: 87.1% (2005)
Irrigated land: NA
Natural hazards: active volcanism on
Tristan da Cunha, last eruption in 1961
Environment — current issues: NA
Geography — note: Saint Helena harbors
at least 40 species of plants unknown
anywhere else in the world; Ascension is
a breeding ground for sea turtles and
sooty terns; Queen Mary’s Peak on
Tristan da Cunha is the highest island
mountain in the South Atlantic and a
prominent landmark on the sea lanes
around southern Africa','48ef0e34710257541bfd5872495773f11516d4e436b21894565ab413c2b1e43d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381ff5726680694add8edd00ef34916a051051fd9123317b14b9bbb5675233df',2009,'KN','Saint Kitts and Nevis','geography',1041,'Location: Caribbean, islands in the
Caribbean Sea, about one-third of the
way from Puerto Rico to Trinidad and
Tobago
Geographic coordinates: 17 20 N, 62 45
W
Map references: Central America and
the Caribbean
Area:
total: 261 sq km (Saint Kitts 168 sq km;
Nevis 93 sq km)
land: 261 sq km
water: 0 sq km
Area — comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical, tempered by constant
sea breezes; little seasonal temperature
variation; rainy season (May to
November)
Terrain: volcanic with mountainous
interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: arable land
Land use:
arable land: 19.44%
permanen t crops : 2.78%
other: 77.78% (2005)
Irrigated land: NA
Total renewable water resources: 0.02
cu km (2000)
Natural hazards: hurricanes (July to
October)
Environment— current issues: NA
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: with coastlines in the
shape of a baseball bat and ball, the two
volcanic islands are separated by a 3-km-
wide channel called The Narrows; on
the southern tip of long, baseball bat-
shaped Saint Kitts lies the Great Salt
549
THE CIA WORLD FACTBOOK
Pond; Nevis Peak sits in the center of its
almost circular namesake island and its
ball shape complements that of its sister
island
Population: 39,619 (July 2008 est.)
Age structure:
0-14 years: 26.8% (male 5,441/female
5,184)
15-64 years: 65.4% (male 12,966/female
12,937)
65 years and over: 7.8% (male
1,286/female 1,805) (2008 est.)
Median age: total. 28.3 years
male: 27.6 years
female: 29 years (2008 est.)
Population growth rate: 0.745% (2008
est.)
Birth rate: 17.77 births/ 1,000 population
(2008 est.)
Death rate: 8 deaths/1,000 population
(2008 est.)
Net migration rate: 2.32 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.99 male(s)/female
(2008 est.)
Infant mortality rate:
total: 13.36 deaths/1,000 live births
male: 15.04 deaths/1,000 live births
female: 11.57 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 72.93 years
male: 70.06 years
female: 75.96 years (2008 est.)
Total fertility rate: 2.28 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS — people living with
HIV/AIDS: NA
HIV/AIDS — deaths: NA
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: predominantly black;
some British, Portuguese, and Lebanese
Religions: Anglican, other Protestant,
Roman Catholic
Languages: English
Literacy: definition: age 15 and over has
ever attended school
total population: 97.8%
male: NA%
female: NA% (2003 est.)
Country name:
conventional long form: Federation of
conventional short form: Saint Kitts and
Nevis
former: Federation of Saint Christopher
and Nevis
Government type: parliamentary democ-
racy
Capital: name: Basseterre
geographic coordinates: 17 18 N, 62 43 W
time difference: UTC-4 (1 hour ahead of
Washington, DC during Standard Time)
Administrative divisions: 14 parishes;
Christ Church Nichola Town, Saint
Anne Sandy Point, Saint George
Basseterre, Saint George Gingerland,
Saint James Windward, Saint John
Capesterre, Saint John Figtree, Saint
Mary Cayon, Saint Paul Capesterre,
Saint Paul Charlestown, Saint Peter
Basseterre, Saint Thomas Lowland,
Saint Thomas Middle Island, Trinity
Palmetto Point
Independence: 19 September 1983
(from UK)
National holiday: Independence Day, 19
September (1983)
Constitution: 19 September 1983
Legal system: based on English common
law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II
(since 6 February 1952); represented by
Governor General Cuthbert Montraville
SEBASTIAN (since 1 January 1996)
head of government: Prime Minister Dr.
Denzil DOUGLAS (since 6 July 1995);
Deputy Prime Minister Sam CONDOR
(since 6 July 1995)
cabinet: Cabinet appointed by the gov¬
ernor general in consultation with the
prime minister
elections: the monarch is hereditary; the
governor general is appointed by the
monarch; following legislative elections,
the leader of the majority party or leader
of a majority coalition is usually
appointed prime minister by the gov¬
ernor general; deputy prime minister
appointed by the governor general
Legislative branch: unicameral
National Assembly (14 seats, 3
appointed and 1 1 popularly elected from
single-member constituencies; members
serve five-year terms)
elections: last held 25 October 2004 (next
to be held by 2009)
election results: percent of vote by party —
NA; seats by party — SKNLP 7, CCM 2,
NRP 1, PAM 1
Judicial branch: Eastern Caribbean
Supreme Court (based on Saint Lucia;
one judge of the Supreme Court resides
in Saint Kitts and Nevis)
Political parties and leaders:
Concerned Citizens Movement or CCM
[Vance AMORYj; Nevis Reformation
Party or NRP [Joseph PARRY]; People’s
Action Movement or PAM [Lindsay
GRANT]; Saint Kitts and Nevis Labor
Party or SKNLP [Dr. Denzil DOUGLAS]
Political pressure groups and leaders:
NA
International organization participa¬
tion: ACP, C, Caricom, CDB, FAO, G-
77, IBRD, ICAO, ICCt, ICRM, IDA,
IFAD, IFC, IFRCS, ILO, IMF, IMO,
Interpol, IOC, ITU, MIGA, NAM,
OAS, OECS, OPANAL, OPCW, UN,
UNCTAD, UNESCO, UNIDO, UPU,
WHO, WIPO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Dr. Izben
Cordinal WILLIAMS
chancery: 3216 New Mexico Avenue
NW, Washington, DC 20016
telephone: [1] (202) 686-2636
FAX: [1] (202) 686-5740
consulate(s) general: New York
Diplomatic representation from the US:
the US does not have an embassy in
Saint Kitts and Nevis; the US
Ambassador to Barbados is accredited to
Flag description: divided diagonally
from the lower hoist side by a broad
black band bearing two white, five-
pointed stars; the black band is edged in
yellow; the upper triangle is green, the
lower triangle is red','365f714461131917f1687b5d9d5a68cc1ce012f833dc59a59622b19e81dde7ae','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb6c528da5f1d290980ba4d049a45c119793da04d63015a1dac5882cc8f8722',2009,'LC','Saint Lucia','geography',1046,'Location: Caribbean, island between
the Caribbean Sea and North
551
THE CIA WORLD FACTBOOK
Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates: 13 53 N, 60 58
W
Map references: Central America and
the Caribbean
Area:
total: 616 sq km
land: 60 6 sq km
water: 10 sq km
Area — comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical, moderated by north¬
east trade winds; dry season January to
April, rainy season May to August
Terrain: volcanic and mountainous with
some broad, fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy
beaches, minerals (pumice), mineral
springs, geothermal potential
Land use:
arable land: 6.45%
permanent crops: 22.58%
other: 70.97% (2005)
Irrigated land: 30 sq km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.01
per capita: 81 cu m/yr (1997)
Natural hazards: hurricanes and vol¬
canic activity
Environment— current issues: defor¬
estation; soil erosion, particularly in the
northern region
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: the twin Pitons
(Gros Piton and Petit Piton), striking
cone-shaped peaks south of Soufriere, are
one of the scenic natural highlights of
the Caribbean','06c5382dfc3095599d96dd7bb63ef751b8eb04c3680008fd50c69017c6287817','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed66188f4e520c1edeaf07f15c718eb485d8b4357aa29ff50399853355e1fbd2',2009,'PM','Saint Pierre and Miquelon','geography',1050,'Legislative branch: unicameral
Territorial Council (23 seats; members
are elected by popular vote to serve five-
year terms)
elections: last held 1 and 8 July 2007
(next to be held July 2012)
election results: percent of seats by
party — UPP 49%, RRR 42.2%, Reussir
Saint-Martin 8.9%; seats by party — UPP
16, RRR 6, Reussir Saint-Martin 1
Political parties and leaders: Union
Pour le Progres or UPP [Louis-Constant
FLEMING]; Rassemblement
Responsabilite Reussite or RRR [Alain
RICHARDSON]; Reussir Saint-Martin
[Jean-Luc HAMLET]
International organization participa¬
tion: UPU
Diplomatic representation in the US:
none (overseas collectivity of France)
Diplomatic representation from the US:
none (overseas collectivity of France)
Flag description: the flag of France is
used
Location: Northern North America,
islands in the North Atlantic Ocean,
south of Newfoundland (Canada)
Geographic coordinates: 46 50 N, 56 20
W
Map references: North America
Area:
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the
Saint Pierre and the Miquelon groups
Area — comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: cold and wet, with much mist
and fog; spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande
Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 12.5%
permanent crops: 0%
Other: 87.5% (2005)
Irrigated land: NA
Natural hazards: persistent fog
throughout the year can be a maritime
hazard
Environment— current issues: recent
test drilling for oil in waters around Saint
Pierre and Miquelon may bring future
development that would impact the','497d0031752c5e6fd36eb4e8344df969a7897c307c18da89ad0d1314c894df82','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d39a9400ce1d3cc4a9dbfdb60f92aa87d7e6ec6e338b4d3433ba2d893be4c5b',2009,'VC','Saint Vincent and the Grenadines','geography',1060,'Location: Oceania, group of islands in
the South Pacific Ocean, about half way
between Hawaii and New Zealand
Geographic coordinates: 13 35 S, 172
20 W
Map references: Oceania
Area:
total: 2,944 sq km
land: 2,934 sq km
water: 10 sq km
Area— comparative: slightly smaller
than Rhode Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season
(November to April), dry season (May to
October)
Terrain: two main islands (Savaii,
Upolu) and several smaller islands and
uninhabited islets; narrow coastal plain
with volcanic, rocky, rugged mountains
in interior
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili (Savaii)
1,857 m
Natural resources: hardwood forests,
fish, hydropower
Land use:
arable land: 21.13%
permanent crops: 24-3%
other: 54.57% (2005)
Irrigated land: NA
Natural hazards: occasional typh oons;
active volcanism
Environment— current issues: soil ero''
sion, deforestation, invasive species,
overfishing
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: occupies an almost
central position within Polynesia','6fdf440462ac2745c026cd150dd40f211d888e5883f6e4f18586e073fd90aab4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('018e2226e73b1904f6beeee754e7ce1ded7b0bf06272dac63ade23370fa53023',2009,'YE','Yemen','geography',1075,'Geographic coordinates: 25 00 N, 45 00
E
Map references: Middle East
Area: total: 2,149,690 sq km
land: 2,149,690 sq km
water: 0 sq km
Area — comparative: slightly more than
one-fifth the size of the US
Land boundaries:
total: 4,431 km
border countries: Iraq 814 km, Jordan 744
km, Kuwait 222 km, Oman 676 km,
Qatar 60 km, UAE 457 km, Yemen 1,458
km
Coastline: 2,640 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 18 nm
continental shelf: not specified
Climate: harsh, dry desert with great
temperature extremes
Terrain: mostly uninhabited, sandy
desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda’ 3,133 m
Natural resources: petroleum, natural
gas, iron ore, gold, copper
Land use:
arable land: 1.67%
permanent crops: 0.09%
other: 98.24% (2005)
irrigated land: 16,200 sq km (2003)
Total renewable water resources: 2.4
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 17.32 cu
km/yr (10%/l%/89%)
per capita: 705 cu m/yr (2000)
Natural hazards: frequent sand and dust
storms
Environment — current issues: desertifi
cation; depletion of underground water
resources; the lack of perennial rivers or
permanent water bodies has prompted
the development of extensive seawater
desalination facilities; coastal pollution
from oil spills
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the
selected agreements
Geography — note: extensive coastlines
on Persian Gulf and Red Sea provide
great leverage on shipping (especially
crude oil) through Persian Gulf and Suez
Canal','9094d7d5c02c21e2c7f6983a4be751bbe934e2f9e6b8e260f4d097ecc7ede88f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7c7b205685f3e88dd373e77c1b77761913db8b78b54639a87bc00059602a8bb',2009,'SN','Senegal','geography',1082,'Location: Western Africa, bordering the
North Atlantic Ocean, between Guinea-
Bissau and Mauritania
Geographic coordinates: 14 00 N, 14 00
w
Map references: Africa
Area: total: 196,190 sq km
land: 192,000 sq km
water: 4,190 sq km
Area— comparative: slightly smaller
than South Dakota
Land boundaries:
total: 2,640 km
border countries: The Gambia 740 km,
Guinea 330 km, Guinea-Bissau 338 km,
Mali 419 km, Mauritania 813 km
Coastline: 531 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical; hot, humid; rainy
season (May to November) has strong
southeast winds; dry season (December
to April) dominated by hot, dry, har-
mattan wind
Terrain: generally low, rolling, plains
rising to foothills in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near
Nepen Diakha 581 m
Natural resources: fish, phosphates, iron
ore
Land use: arable land: 12.51%
permanent crops: 0.24%
other: 87.25% (2005)
Irrigated land: 1,200 sq km (2003)
Total renewable water resources: 39.4
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.22 cu
km/yr (4%/3%/93%)
per capita: 190 cu m/yr (2002)
Natural hazards: lowlands seasonally
flooded; periodic droughts
Environment — current issues: wildlife
populations threatened by poaching;
deforestation; overgrazing; soil erosion;
desertification; overfishing
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Flazardous Wastes, Law of the
Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution,
Wetlands, Whaling
Geography — note: westernmost country
on the African continent; The Gambia
is almost an enclave within Senegal
Population: 12,853,259 (July 2008 est.)
Age structure:
0-14 years: 41.9% (male 2,717,257/
female 2,668,602)
15-64 years: 55.1% (male 3,524,683/
female 3,552,643)
570
65 years and over: 3% (male
183,188/female 206,886) (2008 est.)
Median age:
total: 18.8 years
male: 18.6 years
female: 19 years (2008 est.)
Population growth rate: 2.58% (2008
est.)
Birth rate: 36.52 births/1,000 population
(2008 est.)
Death rate: 10.72 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 0 migrant(s)/l,000
population (2008 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 58.93 deaths/1,000 live births
male: 62.79 deaths/1,000 live births
female: 54.96 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 57.08 years
male: 55.7 years
female: 58.5 years (2008 est.)
Total fertility rate: 4.86 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: 0.8%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 44,000 (2003 est.)
HIV/AIDS— deaths: 3,500 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and
protozoal diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: Crimean-Congo
hemorrhagic fever, dengue fever, malaria,
Rift Valley fever, and yellow fever
water contact disease: schistosomiasis
respiratory disease: meningococcal
meningitis (2008)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular
23.8%, Serer 14.7%, Jola 3.7%,
Mandinka 3%, Soninke 1.1%, European
and Lebanese 1%, other 9.4%
Religions: Muslim 94%, Christian 5%
(mostly Roman Catholic), indigenous
beliefs 1%
Languages: French (official), Wolof,
Pulaar, Jola, Mandinka
Literacy: definition: age 15 and over can
read and write
total population: 39.3%
male: 51.1%
female: 29.2% (2002 est.)','3431507b3c36db124cd6c1f1ddf966f580df62027cb05b468a5f491162806be5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0521894ea697ba3b9e8fc21cb3b20ea6e358dbef59fc43f9ca9b2239b968621b',2009,'RS','Serbia','geography',1088,'Location: Southeastern Europe, between
Macedonia and Hungary
Geographic coordinates: 44 00 N, 21 00
E
Map references: Europe
Area: total: 77,474 sq km
land: 77,474 sq km
water: 0 sq km
Area— comparative: slightly smaller
than South Carolina
Land boundaries:
total: 2,026 km
border countries: Bosnia and Herzegovina
302 km, Bulgaria 318 km, Croatia 241
km, Hungary 151 km, Kosovo 352 km,
Macedonia 62 km, Montenegro 124 km,
Romania 476 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: in the north, continental cli¬
mate (cold winters and hot, humid sum¬
mers with well distributed rainfall); in
other parts, continental and
Mediterranean climate (relatively cold
winters with heavy snowfall and hot, dry
summers and autumns)
Terrain: extremely varied; to the north,
rich fertile plains; to the east, limestone
ranges and basins; to the southeast,
ancient mountains and hills
Elevation extremes:
lowest point: NA
highest point: Midzor 2,169 m
Natural resources: oil, gas, coal, iron
ore, copper, zinc, antimony, chromite,
gold, silver, magnesium, pyrite, lime¬
stone, marble, salt, arable land
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Total renewable water resources: 208.5
cu km (note — includes Kosovo) (2003)
Natural hazards: destructive earth¬
quakes
Environment — current issues: air pollu¬
tion around Belgrade and other indus¬
trial cities; water pollution from
industrial wastes dumped into the Sava
which flows into the Danube
Environment— international agree¬
ments: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: controls one of the
major land routes from Western Europe
to Turkey and the Near East
Location: archipelago in the Indian
Ocean, northeast of Madagascar
576','4ab1075f5e7e514bed98adeb3aca9493823e0114a376d574fd4bb1bd3ccfa952','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b267008339c10873fd93817601011162ea9abe5e439f1af23e28b3891f2c0ef6',2009,'SC','Seychelles','geography',1091,'AimmA
ISLANDS
Atallde
Casmotecfe
PROYIDmce
ATOLL
ATOU OS
mnauHAfi
Agalegs islands
fSBMWfii i#3
as Qfesf»usw$
m «T-
ioe
206 snl «
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area — comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical marine; humid; cooler
season during southeast monsoon (late
May to September); warmer season
during northwest monsoon (March to
May)
Terrain: Mahe Group is granitic, narrow
coastal strip, rocky, hilly; others are
coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cin¬
namon trees
Land use:
arable land: 2.17%
permanen t crops : 13.04%
other: 84-79% (2005)
Irrigated land: NA
Natural hazards: lies outside the cyclone
belt, so severe storms are rare; short
droughts possible
Environment— current issues: water
supply depends on catchments to collect
rainwater
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: 41 granitic and about
75 coralline islands','4a629994cc7c80a5c57f9a82bfcbcd2d052663afd20cdb85693296beba4bfd97','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed3b2db5bc4caa4b974e954a3e25f32e5997f6e1a972d0288f82da6f36cff888',2009,'SL','Sierra Leone','geography',1099,'Location: Western Africa, bordering the
North Atlantic Ocean, between Guinea
and Liberia
Geographic coordinates: 8 30 N, ll 30
W
Map references: Africa
Area: total: 71,740 sq km
land: 71,620 sq km
water: 120 sq km
Area— comparative: slightly smaller
than South Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia
306 km
Coastline: 402 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; hot, humid; summer
rainy season (May to December); winter
dry season (December to April)
Terrain: coastal belt of mangrove
swamps, wooded hill country, upland
plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani)
1,948 m
Natural resources: diamonds, titanium
ore, bauxite, iron ore, gold, chromite
Land use:
arable land: 7.95%
permanen t crops : 1.05%
other: 91% (2005)
Irrigated land: 300 sq km (2003)
Total renewable water resources: 160
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.38 cu
km/yr (5%/3%/92%)
per capita: 69 cu m/yr (2000)
Natural hazards: dry, sand-laden har-
mattan winds blow from the Sahara
(December to February); sandstorms,
dust storms
Environment — current issues: rapid
population growth pressuring the envi¬
ronment; overharvesting of timber,
expansion of cattle grazing, and slash-
and-burn agriculture have resulted in
deforestation and soil exhaustion; civil
war depleted natural resources; over¬
fishing
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Environmental
Modification
Geography — -note: rainfall along the
coast can reach 495 cm (195 inches) a
year, making it one of the wettest places
along coastal, western Africa','09cf9da68f33e307d14cb06a5725d583f82cdc29154a534d287b05899844d25a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c114dbba544a2e38a8bfe4e19a33b848fdb871ad688949dec142d9df875bfd61',2009,'SG','Singapore','geography',1108,'Location: Southeastern Asia, islands
between Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48
E
Map references: Southeast Asia
Area: total: 692.7 sq km
land: 682.7 sq km
water: 10 sq km
Area — comparative: slightly more than
3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: within and beyond
territorial sea, as defined in treaties and
practice
Climate: tropical; hot, humid, rainy; two
distinct monsoon seasons —
Northeastern monsoon (December to
March) and Southwestern monsoon
(June to September); inter-monsoon —
frequent afternoon and early evening
thunderstorms
Terrain: lowland; gently undulating cen¬
tral plateau contains water catchment
area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Natural resources: fish, deepwater ports
Land use: arable land: 1.47%
permanen t crops : 1.47%
other: 97.06% (2005)
Irrigated land: NA
Total renewable water resources: 0.6
cu km (1975)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.19 cu
km/yr (45%/51%/4%)
per capita: 44 cu m/yr (1975)
Natural hazards: NA
Environment— current issues: indus¬
trial pollution; limited natural fresh
water resources; limited land availability
presents waste disposal problems; sea¬
sonal smoke/haze resulting from forest
fires in Indonesia
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the
selected agreements
Geography — note: focal point for
Southeast Asian sea routes','4160b922c1801c031a22a54d7903f3e4f1184ed88bae6fe191566d65d1a56683','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c25d5acb81a47b0430e40a884e7b2badf377b650d9bf710b90164c678ce4e4',2009,'SK','Slovakia','geography',1119,'Location: Central Europe, eastern Alps
bordering the Adriatic Sea, between
Austria and Croatia
Geographic coordinates: 46 07 N, 14 49
E
Map references: Europe
Area:
total: 20,273 sq km
land: 20,151 sq km
water: 122 sq km
Area— comparative: slightly smaller
than New Jersey
Land boundaries:
total: 1,382 km
border countries: Austria 330 km, Croatia
670 km, Hungary 102 km, Italy 280 km
Coastline: 46.6 km
Maritime Claims: territorial sea: 12 nm
Climate: Mediterranean climate on the
coast, continental climate with mild to
hot summers and cold winters in the
plateaus and valleys to the east
Terrain: a short coastal strip on the
Adriatic, an alpine mountain region
adjacent to Italy and Austria, mixed
mountains and valleys with numerous
rivers to the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead,
zinc, building stone, hydropower, forests
Land use:
arable land: 8.53%
permanent crops: 1.43%
other: 90.04% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 32.1
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.9
per capita: 457 cu m/yr (2002)
Natural hazards: flooding and earth¬
quakes
Environment— current issues: Sava
River polluted with domestic and indus¬
trial waste; pollution of coastal waters
with heavy metals and toxic chemicals;
forest damage near Koper from air pollu¬
tion (originating at metallurgical and
chemical plants) and resulting acid rain
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography— note: despite its small size,
this eastern Alpine country controls
some of Europe’s major transit routes
Population: 2,007,711 (July 2008 est.)
Age structure:
0-14 years: 13.6% (male 140,686/female
132,778)
15-64 years: 70.1% (male
709,689/female 697,862)
65 years and over: 16.3% (male
127,313/female 199,383) (2008 est.)
Median age:
total: 41.4 years
male: 39.8 years
female: 42.9 years (2008 est.)
Population growth rate: -0.088% (2008
est.)
Birth rate: 8.99 births/1,000 population
(2008 est.)
Death rate: 10.51 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 0.64 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.95 male(s)/female
(2008 est.)
Infant mortality rate:
total: 4-3 deaths/1,000 live births
male: 4.87 deaths/1,000 live births
female: 3.69 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 76.73 years
male: 73.04 years
female: 80.66 years (2008 est.)
Total fertility rate: 1.27 children
bom/woman (2008 est.)
HIV/AIDS — adult prevalence rate: less
than 0.1% (2001 est.)
HIV/AIDS — people living with
HIV/AIDS: 280 (2001 est.)
HIV/AIDS— deaths: fewer than 100
(2003 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 83.1%, Serb 2%,
Croat 1.8%, Bosniak 1.1%, other or
unspecified 12% (2002 census)
Religions: Catholic 57.8%, Muslim
2.4%, Orthodox 2.3%, other Christian
0.9%, unaffiliated 3.5%, other or unspec¬
ified 23%, none 10.1% (2002 census)
Languages: Slovenian 91.1%, Serbo-
Croatian 4.5%, other or unspecified
4.4% (2002 census)
Literacy:
definition: NA
total population: 99.7%
male: 99.7%
female: 99.6%','94506e68c8e051014969f3bd80fdc369247d1a98fe79956edb7a3366e56c5052','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a724ba202790982a5a1ad999ba82956df0a568928fc7e1bb3bc47dcb188a8b9a',2009,'GS','South Georgia and the South Sandwich Islands','geography',1141,'Location: body of water between 60
degrees south latitude and Antarctica
Geographic coordinates: 60 00 S, 90 00
E (nominally), but the Southern Ocean
has the unique distinction of being a
large circumpolar body of water totally
encircling the continent of Antarctica;
this ring of water lies between 60 degrees
601
THE CIA WORLD FACTBOOK
south latitude and the coast of
Antarctica and encompasses 360 degrees
of longitude
Map references: Antarctic Region
Area:
total: 20.327 million sq km
note: includes Amundsen Sea,
Bellingshausen Sea, part of the Drake
Passage, Ross Sea, a small part of the
Scotia Sea, Weddell Sea, and other trib¬
utary water bodies
Area — comparative: slightly more than
twice the size of the US
Coastline: 17,968 km
Climate: sea temperatures vary from
about 10 degrees Celsius to -2 degrees
Celsius; cyclonic storms travel eastward
around the continent and frequently are
intense because of the temperature con¬
trast between ice and open ocean; the
ocean area from about latitude 40 south
to the Antarctic Circle has the strongest
average winds found anywhere on Earth;
in winter the ocean freezes outward to 65
degrees south latitude in the Pacific
sector and 55 degrees south latitude in
the Atlantic sector, lowering surface
temperatures well below 0 degrees
Celsius; at some coastal points intense
persistent drainage winds from the inte¬
rior keep the shoreline ice-free
throughout the winter
Terrain: the Southern Ocean is deep,
4,000 to 5,000 m over most of its extent
with only limited areas of shallow water;
the Antarctic continental shelf is gener¬
ally narrow and unusually deep, its edge
lying at depths of 400 to 800 m (the
global mean is 133 m); the Antarctic
icepack grows from an average minimum
of 2.6 million sq km in March to about
18.8 million sq km in September, better
than a sixfold increase in area; the
Antarctic Circumpolar Current (21,000
km in length) moves perpetually east¬
ward; it is the world’s largest ocean cur¬
rent, transporting 130 million cubic
meters of water per second — 100 times
the flow of all the world’s rivers
Elevation extremes:
lowest point: -7,235 m at the southern
end of the South Sandwich Trench
highest point: sea level 0 m
Natural resources: probable large and
possible giant oil and gas fields on the
continental margin; manganese nodules,
possible placer deposits, sand and gravel,
fresh water as icebergs; squid, whales,
and seals — none exploited; krill, fish
Natural hazards: huge icebergs with
drafts up to several hundred meters;
smaller bergs and iceberg fragments; sea
ice (generally 0.5 to 1 m thick) with
sometimes dynamic short-term varia¬
tions and with large annual and interan¬
nual variations; deep continental shelf
floored by glacial deposits varying widely
over short distances; high winds and
large waves much of the year; ship icing,
especially May-October; most of region
is remote from sources of search and
rescue
Environment — current issues: increased
solar ultraviolet radiation resulting from
the Antarctic ozone hole in recent years,
reducing marine primary productivity
(phytoplankton) by as much as 15% and
damaging the DNA of some fish; illegal,
unreported, and unregulated fishing in
recent years, especially the landing of an
estimated five to six times more
Patagonian toothfish than the regulated
fishery, which is likely to affect the sus¬
tainability of the stock; large amount of
incidental mortality of seabirds resulting
from long-line fishing for toothfish
note: the now-protected fur seal popula¬
tion is making a strong comeback after
severe overexploitation in the 18th and
19th centuries
Environment— international agree¬
ments: the Southern Ocean is subject to
all international agreements regarding
the world’s oceans; in addition, it is sub¬
ject to these agreements specific to the
Antarctic region: International Whaling
Commission (prohibits commercial
whaling south of 40 degrees south [south
of 60 degrees south between 50 degrees
and 130 degrees west]); Convention on
the Conservation of Antarctic Seals
(limits sealing); Convention on the
Conservation of Antarctic Marine
Living Resources (regulates fishing)
note: many nations (including the US)
prohibit mineral resource exploration
and exploitation south of the fluctuating
Polar Front (Antarctic Convergence),
which is in the middle of the Antarctic
Circumpolar Current and serves as the
dividing line between the cold polar sur¬
face waters to the south and the warmer
waters to the north
Geography — note: the major choke-
point is the Drake Passage between
South America and Antarctica; the
Polar Front (Antarctic Convergence) is
the best natural definition of the
northern extent of the Southern Ocean;
it is a distinct region at the middle of the
Antarctic Circumpolar Current that sep¬
arates the cold polar surface waters to the
south from the warmer waters to the
north; the Front and the Current extend
entirely around Antarctica, reaching
south of 60 degrees south near New
Zealand and near 48 degrees south in the
far South Atlantic coinciding with the
path of the maximum westerly winds','97b91e1982b235c3e45ced4efac57261d8c80f3605f2ed86a8f7b32fe190de68','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df1adf9a45c9a57988e09718e40c5ee160d769903bacc37fd3a7bdb44ae19a00',2009,'ES','Spain','geography',1146,'Location: Southwestern Europe, bor¬
dering the Bay of Biscay, Mediterranean
Sea, North Atlantic Ocean, and
Pyrenees Mountains, southwest of','07278b8a341ae12033472ea22126f609024a599487badd5fd0c0e757f5288ee7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73058c7014820abfb715eeb42561fdc66711fb595f5a761d09ae8905f2109be2',2009,'LK','Sri Lanka','geography',1150,'Location: Southeastern Asia, group of
reefs and islands in the South China Sea,
about two-thirds of the way from
southern Vietnam to the southern','826aafb1dcd09233608e553bd356937b14156c80fb21bb1ed1c68a838e8854df','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4425c95de423508652b5d44bfd864cb3dc348684ed1315c0181cd165d7abae',2009,'SD','Sudan','geography',1157,'Location: Northern Africa, bordering
the Red Sea, between Egypt and Eritiea
Geographic coordinates: 15 00 N, 30 00
E
Map references: Africa
Area:
total: 2,505,810 sq km
land: 2.376 million sq km
water: 129,810 sq km
Area — comparative: slightly more than
one-quarter the size of the US
Land boundaries:
total: 7,687 km
border countries: Central African
Republic 1,165 km, Chad 1,360 km,
Democratic Republic of the Congo 628
km, Egypt 1,273 km, Eritrea 605 km,
Ethiopia 1,606 km, Kenya 232 km, Libya
383 km, Uganda 435 km
Coastline: 853 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 18 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical in south; arid desert in
north; rainy season varies by region
(April to November)
Terrain: generally flat, featureless plain;
mountains in far south, northeast and
west; desert dominates the north
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small
reserves of iron ore, copper, chromium
ore, zinc, tungsten, mica, silver, gold,
hydropower
Land use:
arable land: 6.78%
permanent crops : 0.17%
other: 93.05% (2005)
Irrigated land: 18,630 sq km (2003)
Total renewable water resources: 154
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 37.32 cu
km/yr (3%/l%/97%)
per capita: 1,030 cu m/yr (2000)
Natural hazards: dust storms and peri¬
odic persistent droughts
Environment— current issues: inade¬
quate supplies of potable water; wildlife
populations threatened by excessive
hunting; soil erosion; desertification;
periodic drought
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: largest country in
Africa; dominated by the Nile and its
tributaries
Location: Northern South America, bor¬
dering the North Atlantic Ocean,
between French Guiana and Guyana
Geographic coordinates: 4 00 N, 56 00
w
Map references: South America
Area: total: 163,270 sq km
PARAMARIBO Amsterdam
2L > , „ Moengo
Leiydorp
* 7
Srokopoixlo. /
rw? r .
dkfMm
Jm
mm
614','2b30767aecfb52200962e8481606436de54140f3bfb872e79e41148c0d221c77','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28482a3c53de0047dc504abdb25e53574c40d76478749a6b3a2af547950b666e',2009,'SR','Suriname','geography',1161,'land: 161,470 sq km
water: 1,800 sq km
Area — comparative: slightly larger than
Location: Northern Europe, islands
between the Arctic Ocean, Barents Sea,
Greenland Sea, and Norwegian Sea,
north of Norway
Geographic coordinates: 78 00 N, 20 00
E
Map references: Arctic Region
Area:
total: 61,020 sq km
land: 61,020 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya
(Bear Island)
Area — comparative: slightly smaller
than West Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
territorial sea: 4 nm
exclusive fishing zone: 200 nm unilaterally
claimed by Norway but not recognized by
Russia
Climate: arctic, tempered by warm
North Atlantic Current; cool summers,
cold winters; North Atlantic Current
617
THE CIA WORLD FACTBOOK
flows along west and north coasts of
Spitsbergen, keeping water open and
navigable most of the year
Terrain: wild, rugged mountains; much of
high land ice covered; west coast clear of
ice about one-half of the year; fjords
along west and north coasts
Elevation extremes:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, iron ore,
copper, zinc, phosphate, wildlife, fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (no trees; the only bushes
are crowberry and cloudberry) (2005)
Irrigated land: NA
Natural hazards: ice floes often block the
entrance to Bellsund (a transit point for
coal export) on the west coast and occa¬
sionally make parts of the northeastern
coast inaccessible to maritime traffic
Environment— current issues: NA
Geography — note: northernmost part of
the Kingdom of Norway; consists of nine
main islands; glaciers and snowfields
cover 60% of the total area; Spitsbergen
Island is the site of the Svalbard Global
Seed Vault, a seed repository established
by the Global Crop Diversity Trust and
the Norwegian Government
Population: 2,165 (July 2008 est.)
Age Structure: 0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.023% (2008
est.)
Birth rate: NA
Death rate: NA (2008 est.)
Net migration rate: NA
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA (2008 est.)
Life expectancy at birth:
total population: NA
male: NA
female: NA (2008 est.)
Total fertility rate: NA (2008 est.)
HIV/AIDS— adult prevalence rate: 0%
(2001)
HIV/AIDS— people living with
HIV/AIDS: 0 (2001)
HIV/AIDS— deaths: 0 (2001)
Ethnic groups: Norwegian 55.4%,
Russian and Ukrainian 44.3%, other
0.3% (1998)
Languages: Norwegian, Russian
Literacy: NA
>
Location: Southern Africa, between
Mozambique and South Africa
Geographic coordinates: 26 30 S, 31 30
E
Map references: Africa
Area: total: 17,363 sqkm
land: 17,203 sq km
water: 160 sq km
Area — comparative: slightly smaller
than New Jersey
Land boundaries:
total: 535 km
border countries: Mozambique 105 km,
South Africa 430 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: varies from tropical to near
temperate
Terrain: mostly mountains and hills;
some moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21m
highest point: Emlembe 1,862 m
Natural resources: asbestos, coal, clay,
cassiterite, hydropower, forests, small
gold and diamond deposits, quarry stone,
and talc
Land use:
arable land: 10.25%
permanent crops : 0.81%
other: 88.94% (2005)
Irrigated land: 500 sq km (2003)
Total renewable water resources: 4.5
cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricuitural): total: 1.04 cu
km/yr (2%/l%/97%)
per capita: 1,010 cu m/yr (2000)
Natural hazards: drought
Environment — current issues: limited
supplies of potable water; wildlife popu¬
lations being depleted because of exces¬
sive hunting; overgrazing; soil
degradation; soil erosion
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Law of the Sea
Geography — note: landlocked; almost
completely surrounded by South Africa','4ddba75d26312a489dc025cd44e0e2a58cd567b9f0fb91a7b6f31692dea11f33','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ce94e2636663954eee1bf42213c5ebf6b6fa553fb9e6bd802e1468ded86cb6d',2009,'SE','Sweden','geography',1170,'Location: Northern Europe, bordering
the Baltic Sea, Gulf of Bothnia,
Kattegat, and Skagerrak, between
Finland and Norway
Geographic coordinates: 62 00 N, 15 00
E
Map references: Europe
Area:
total: 449,964 sq km
land: 410,934 sq km
water: 39,030 sq km
Area — comparative: slightly larger than
California
Land boundaries:
total: 2,233 km
border countries: Finland 614 km, Norway
1,619 km
Coastline: 3,218 km
Maritime claims:
territorial sea: 12 nm (adjustments made
to return a portion of straits to high seas)
exclusive economic zone: agreed bound¬
aries or midlines
continental shelf: 200-m depth or to the
depth of exploitation
Climate: temperate in south with cold,
cloudy winters and cool, partly cloudy
summers; subarctic in north
Terrain: mostly flat or gently rolling low¬
lands; mountains in west
Elevation extremes:
lowest point: reclaimed bay of Lake
Hammarsjon, near Kristianstad -2.41 m
highest point: Kebnekaise 2,111 m
Natural resources: iron ore, copper,
lead, zinc, gold, silver, tungsten, ura¬
nium, arsenic, feldspar, timber,
hydropower
Land use: arable land: 5.93%
permanent crops: 0.01%
other: 94-06% (2005)
621
THE CIA WORLD FACTBOOK
.Kiruna
mmm
r 4
Nanw&m -bf*
^ . '' . .
Skelleftea *
Sundsvai^
□avie
Ume-l
*■'' ..
■i OlJiM %*
Y Bo0mm i
\\
PlMLAm
sr“. .»»«>•
AUWO t
IShAWS
„ f . ;> :
y sb
^rlstad V&sterfis„
WE«„,*STOCKHOU1
Norftdpjng # A
Lsnkdptrvg^ * Oxelfisund
i^Stenungs«nct
Goteborg ^ortsdptng 4
Boris I
? 0
ft.''. V
■ Halmstad „ , J:-:v
/* Kaunas^ ■:>?«
u^“iigbor§ Kaispaite
,Ma<me
.Tellftborg
0 SO lOOmi
Irrigated land: 1,150 sq km (2003)
Total renewable water resources: 179
cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total. 2.68 cu
km/yr (37%/54%/9%)
per capita: 296 cu m/yr (2002)
Natural hazards: ice floes in the sur¬
rounding waters, especially in the Gulf of
Bothnia, can interfere with maritime
traffic
Environment — current issues: acid rain
damage to soils and lakes; pollution of
the North Sea and the Baltic Sea
Environment — international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-
Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: strategic location
along Danish Straits linking Baltic and
North Seas','e959803514acf8e5d3dfb50caf0dac189aa351b2536f1a5126eb03a3a28d67c5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe8a1a929754dc0b9aa4d66376608c9f1ff7af72c94626257ba732099585693e',2009,'CH','Switzerland','geography',1177,'Location: Middle East, bordering the
Mediterranean Sea, between Lebanon
and Turkey
Geographic coordinates: 35 00 N, 38 00
E
Map references: Middle East
Area: total: 185,180 sq km
land: 184,050 sq km
water: 1,130 sq km
note: includes 1,295 sq km of Israeli-
occupied territory
Area — comparative: slightly larger than
North Dakota
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76
km, Jordan 375 km, Lebanon 375 km,
Turkey 822 km
Coastline: 193 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
Climate: mostly desert; hot, dry, sunny
summers (June to August) and mild,
rainy winters (December to February)
along coast; cold weather with snow or
sleet periodically in Damascus
Terrain: primarily semiarid and desert
plateau; narrow coastal plain; mountains
in west
Elevation extremes:
lowest point: unnamed location near Lake
Tiberias -200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum, phos¬
phates, chrome and manganese ores,
asphalt, iron ore, rock salt, marble,
gypsum, hydropower
Land use:
arable land: 24-8%
permanent crops: 4-47%
other: 70.73% (2005)
Irrigated land: 13,330 sq km (2003)
Total renewable water resources: 46.1
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 19.95 cu
km/yr (3%/2%/95%)
per capita: 1,048 cu m/yr (2000)
Natural hazards: dust storms, sand¬
storms
Environment — current issues: defor¬
estation; overgrazing; soil erosion; deser¬
tification; water pollution from raw
sewage and petroleum refining wastes;
inadequate potable water
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental
Modification
Geography — note: there are 42 Israeli
settlements and civilian land use sites in
the Israeli-occupied Golan Heights
(August 2005 est.)
Population: 19,747,586
note: in addition, about 40,000 people
live in the Israeli-occupied Golan
Heights— 20,000 Arabs (18,000 Druze
and 2,000 Alawites) and about 20,000
Israeli settlers (July 2008 est.)
Age structure:
0-14 years: 36.2% (male
3,679,473/female 3,467,096)
15-64 years: 60.5% (male
6,119,459/female 5,822,376)
65 years and over: 3.3% (male
310,838/female 348,344) (2008 est.)
Median age:
total: 21.4 years
male: 21.3 years
female: 21.5 years (2008 est.)
Population growth rate: 2.189% (2008
est.)
Birth rate: 26.57 births/1,000 population
(2008 est.)
Death rate: 4.68 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.05 male(s)/female
(2008 est.)
Infant mortality rate:
total: 26.78 deaths/1,000 live births
male: 27.04 deaths/1,000 live births
female: 26.52 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 70.9 years
male: 69.53 years
female: 72.35 years (2008 est.)
Total fertility rate: 3.21 children
born/woman (2008 est.)
HIV/AIDS — adult prevalence rate: less
than 0.1% (2001 est.)
HIV/AIDS — people living with
HIV/AIDS: fewer than 500 (2003 est.)
HIV/AIDS — deaths: fewer than 200
(2003 est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds,
Armenians, and other 9.7%
Religions: Sunni Muslim 74%, other
Muslim (includes Alawite, Druze) 16%,
Christian (various denominations) 10%,
Jewish (tiny communities in Damascus,
Al Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish,
Armenian, Aramaic, Circassian widely
understood; French, English somewhat
understood
Literacy:
definition: age 15 and over can read and
write
628
SYRIA
total population: 79.6%
male: 86%
female: 73.6% (2004 census)','e7d979a7b64025aa0cb7bd1f72e69ff28692b08207d45bf510915473f2c5b58b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('276d915b8f304ecf4b05f4644cd95356a157924f8ee308d8872202949b6d15d8',2009,'TK','Tokelau','geography',1200,'Location: Oceania, group of three atolls
in the South Pacific Ocean, about one-
half of the way from Flawaii to New
Zealand
Geographic coordinates: 9 00 S, 172 00
w
Map references: Oceania
Area:
total: 10 sq km
land: 10 sq km
water: 0 sq km
Area — comparative: about 17 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade
winds (April to November)
Terrain: low-lying coral atolls enclosing
large lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
647
THE CIA WORLD FACTBOOK
0 20 40 m
0 20 40 m»
%
Atafu
South Pacific Oman
id
y \\
Nukunonu
Fakaofo
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: lies in Pacific typhoon
belt
Environment— current issues: limited
natural resources and overcrowding are
contributing to emigration to New
Zealand
Geography — note: consists of three
atolls (Atafu, Fakaofo, Nukunonu), each
with a lagoon surrounded by a number of
reef-bound islets of varying length and
rising to over 3 m above sea level','42f3c489fab7d9c2fd1fb9ee31d43778a8d3c9574e1740fc00019e01e9aea02f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70cc74cec38561f4b2ecbb355c9a42895d6a904ca7c35ca781ccec20ef58c033',2009,'TO','Tonga','geography',1207,'Location: Oceania, archipelago in the
South Pacific Ocean, about two-thirds of
the way from Hawaii to New Zealand
Geographic coordinates: 20 00 S, 175
00 w
Map references: Oceania
Area: total: 748 sq km
land: 718 sq km
water: 30 sq km
Area — comparative: four times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: tropical; modified by trade
winds; warm season (December to May),
cool season (May to December)
Terrain: most islands have limestone
base formed from uplifted coral forma¬
tion; others have limestone overlying
volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao
Island 1,033 m
Natural resources: fish, fertile soil
Land use:
arable land: 20%
permanent crops: 14.67%
other: 65.33% (2005)
Irrigated land: NA
Natural hazards: cyclones (October to
April); earthquakes and volcanic activity
on Fonuafo’ou
Environment — current issues: defor¬
estation results as more and more land is
being cleared for agriculture and settle¬
ment; some damage to coral reefs from
starfish and indiscriminate coral and
shell collectors; overhunting threatens
native sea turtle populations
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea,
Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the
selected agreements
Geography — note: archipelago of 169
islands (36 inhabited)','886943d41810e966c71944c4700442bf7d1948bd04ae267776afae8949e9bbec','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0303eaf8224fa3f6e91b6610c53aeb2ee982247a72967f6b5351d38cad68442a',2009,'TT','Trinidad and Tobago','geography',1215,'Location: Caribbean, islands between
the Caribbean Sea and the North
Atlantic Ocean, northeast of Venezuela
Geographic coordinates: 1 1 00 N, 61 00
W
Map references: Central America and
the Caribbean
Area:
total: 5,128 sq km
land: 5,128 sq km
water: 0 sq km
Area — comparative: slightly smaller
than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims: measured from
claimed archipelagic baselines
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
651
THE CIA WORLD FACTBOOK
continental shelf: 200 nm or to the outer
edge of the continental margin
Climate: tropical; rainy season (June to
December)
Terrain: mostly plains with some hills
and low mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural
gas, asphalt
Land use:
arable land: 14-62%
permanent crops: 9.16%
other: 76.22% (2005)
Irrigated land: 40 sq km (2003)
Total renewable water resources: 3.8
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.31 cu
km/yr (68%/26%/6%)
per capita: 237 cu m/yr (2000)
Natural hazards: outside usual path of
hurricanes and other tropical storms
Environment— current issues: water
pollution from agricultural chemicals,
industrial wastes, and raw sewage; oil
pollution of beaches; deforestation; soil
erosion
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: Pitch Lake, on
Trinidad’s southwestern coast, is the
world’s largest natural reservoir of asphalt','d33d1357bd0da2ae6b794a832c2aa2d280ec3e7f3f2f92e559af7777ea2289d7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6562f737eda15999fe77aefc075d31022a2b45f2a727f788b4eaeeb516cc6e9',2009,'TN','Tunisia','geography',1220,'Geography — note: strategic location in
central Mediterranean; Malta and
Tunisia are discussing the commercial
exploitation of the continental shelf
between their countries, particularly for
oil exploration','c095f71d97dda968d15cf2061ce8ff3464fc463f964e3caf67a47c0121fb589d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80010dc8efa5c78adc93e76a44518e6ab673ea37a89aed8ac21b15535ba215b3',2009,'KZ','Kazakhstan','geography',1232,'Geographic coordinates: 40 00 N, 60 00
E
Map references: Asia
Area: total: 488,100 sq km
land: 488,100 sq km
water: NEGL
661
THE CIA WORLD FACTBOOK
Area— comparative: slightly larger than
California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km,
Iran 992 km, Kazakhstan 379 km,
Uzbekistan 1,621 km
Coastline: 0 km; note — Turkmenistan
borders the Caspian Sea (1,768 km)
Maritime Claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with
dunes rising to mountains in the south;
low mountains along border with Iran;
borders Caspian Sea in west
Elevation extremes:
lowest point: Vpadina Akchanaya -81 m;
note — Sarygamysh Koli is a lake in
northern Turkmenistan with a water
level that fluctuates above and below the
elevation of Vpadina Akchanaya (the
lake has dropped as low as -110 m)
highest point: Gora Ayribaba 3,139 m
Natural resources: petroleum, natural
gas, sulfur, salt
Land use:
arable land: 4-51%
permanent crops : 0.14%
other: 95.35% (2005)
Irrigated land: 18,000 sq km (2003)
Total renewable water resources: 60.9
cu km ( 1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 24.65 cu
km/yr (2%/l%/98%)
per capita: 5,104 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: contami¬
nation of soil and groundwater with agri¬
cultural chemicals, pesticides; salination,
water logging of soil due to poor irriga¬
tion methods; Caspian Sea pollution;
diversion of a large share of the flow of
the Amu Darya into irrigation con¬
tributes to that river’s inability to
replenish the Aral Sea; desertification
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: none of the
selected agreements
Geography— note: landlocked; the
western and central low-lying desolate
portions of the country make up the
great Garagum (Kara-Kum) desert,
which occupies over 80% of the country;
eastern part is plateau','4a1770f0095270fd09bb4ab5f0fe47e254e6dab5f09d382d135adda46b50505f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c06edf511a40e109ed9d3ffc27fe06ea8ccc97799e53083d9033a1839357623',2009,'TC','Turks and Caicos Islands','geography',1238,'Location: Caribbean, two island groups
in the North Atlantic Ocean, southeast
of The Bahamas, north of Haiti
Geographic coordinates: 21 45 N, 71 35
W
664
0 TO> 20 to
0 TO 80 mi
Mi
Ncmrtt ATLMMfm
mmm
North
Calces
p"*“SgS t
_■ Ptei''idencmlm
CAICOS ISLAND.
KsJVC ’Bottle Ow*
*LV>- Middle Cateo*
Bm t
J.%^; v, . cSeos
■ r-<
- ''
Hartour. ,
Sa;rf/i ‘I
C*ftxa> ,
4<Mtx»tp* C*8» *
GRAND
TOOK
liCWW JftiANTW
ocmN
* ■ TURKS
ISLANDS
,-
'' ''Mm-
Cays
. '' • ''
Map references: Central America and
the Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area— -comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical; marine; moderated by
trade winds; sunny and relatively dry
Terrain: low, flat limestone; extensive
marshes and mangrove swamps
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2.33%
permanent crops: 0%
other: 97.67% (2005)
Irrigated land: NA
Natural hazards: frequent hurricanes
Environment — current issues: limited
natural fresh water resources, private cis¬
terns collect rainwater
Geography — note: about 40 islands
(eight inhabited)
Location: Oceania, island group con¬
sisting of nine coral atolls in the South
Pacific Ocean, about one-half of the way
from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00
E
Map references: Oceania
Area: total: 26 sq km
land: 26 sq km
water: 0 sq km
Area— comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by easterly
trade winds (March to November); west-
666','1309d39631f7eaa6604bde5adb1423d02236950da9129dcd27823f1400b72fb5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38f1f17c36f2b8f8e9f1340cb28b57dcaca6ab56042aa943cb6f7439015f73e9',2009,'TV','Tuvalu','geography',1244,'* Namatm
Lotus
Tonga.
Nanurmnga
Niutao
Tanrake*
. Nui
PACIFIC
Asm .
* Vwtiipu
Savave*
FUNAFUTI*
Funafuti
Ntikutmfm
so 100 ten
IS
erly gales and heavy rain (November to
March)
Terrain: very low-lying and narrow coral
atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 66.67%
other: 33.33% (2005)
Irrigated land: NA
Natural hazards: severe tropical storms
are usually rare, but, in 1997, there were
three cyclones; low level of islands make
them sensitive to changes in sea level
Environment — current issues: since
there are no streams or rivers and
groundwater is not potable, most water
needs must be met by catchment systems
with storage facilities (the Japanese
Government has built one desalination
plant and plans to build one other);
beachhead erosion because of the use of
sand for building materials; excessive
clearance of forest undergrowth for use as
fuel; damage to coral reefs from the
spread of the Crown of Thorns starfish;
Tuvalu is concerned about global
increases in greenhouse gas emissions
and their effect on rising sea levels,
which threaten the country’s under¬
ground water table; in 2000, the govern¬
ment appealed to Australia and New
Zealand to take in Tuvaluans if rising sea
levels should make evacuation necessary
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea,
Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the
selected agreements
Geography — note: one of the smallest
and most remote countries on Earth; six
of the nine coral atolls — Nanumea, Nui,
Vaitupu, Nukufetau, Funafuti, and
Nukulaelae — have lagoons open to the
ocean; Nanumaya and Niutao have land¬
locked lagoons; Niulakita does not have
a lagoon
Population: 12,177 (July 2008 est.)
Age structure:
0-14 years: 29.4% (male 1,826/female
1,754)
15-64 years: 65.4% (male 3,891/female
4,073)
65 years and over: 5.2% (male 236/female
397) (2008 est.)
Median age:
total: 25.2 years
male: 24-2 years
female: 26.4 years (2008 est.)
Population growth rate: 1.577% (2008
est.)
Birth rate: 22.75 births/1,000 population
(2008 est.)
Death rate: 6.98 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: NA
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.96 male(s)/female
(2008 est.)
Infant mortality rate:
total: 18.97 deaths/1,000 live births
male: 21.56 deaths/1,000 live births
female: 16.25 deaths/ 1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 68.97 years
male: 66.7 years
female: 71.36 years (2008 est.)
Total fertility rate: 2.94 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: NA
HIV/AIDS— people living with
HIV/AIDS: NA
HIV/AIDS— deaths: NA
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%,
Micronesian 4%
Religions: Church of Tuvalu
(Congregationalist) 97%, Seventh-Day
Adventist 1.4%, Baha’i 1%, other 0.6%
Languages: Tuvaluan, English, Samoan,
Kiribati (on the island of Nui)
Literacy:
NA
Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00
E
Map references: Africa
Area: total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
Area — comparative: slightly smaller
than Oregon
Land boundaries:
total: 2,698 km
border countries: Democratic Republic of
the Congo 765 km, Kenya 933 km,
Rwanda 169 km, Sudan 435 km,
Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with
two dry seasons (December to February,
June to August); semiarid in northeast
Terrain: mostly plateau with rim of
mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount
Stanley 5,1 10 m
Natural resources: copper, cobalt,
hydropower, limestone, salt, arable land
Land use:
arable land: 21.57%
permanent crops: 8.92%
other: 69.51% (2005)
Irrigated land: 90 sq km (2003)
Total renewable water resources: 66 cu
km (1970)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.3 cu
km/yr (43%/17%/40%)
per capita: 10 cu m/yr (2002)
Natural hazards: NA
Environment— current issues: draining
of wetlands for agricultural use; defor¬
estation; overgrazing; soil erosion; water
hyacinth infestation in Lake Victoria;
widespread poaching
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: Environmental
Modification
Geography — note: landlocked; fertile,
well-watered country with many lakes
and rivers
Population: 31,367,972
note: estimates for this country explicitly
take into account the effects of excess
mortality due to AIDS; this can result in
lower life expectancy, higher infant mor¬
tality, higher death rates, lower popula¬
tion growth rates, and changes in the
distribution of population by age and sex
than would otherwise be expected (July
2008 est.)
Age structure:
0-14 years: 50% (male 7,903,935/female
7,789,792)
15-64 years: 47.8% (male
7,528,073/female 7,469,938)
65 years and over : 2.2% (male
284,122/female 392,112) (2008 est.)
Median age:
total: 15 years
male: 14.9 years
female: 15.1 years (2008 est.)
Population growth rate: 3.603% (2008
est.)
Birth rate: 48.15 births/1,000 population
(2008 est.)
Death rate: 12.32 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 0.21 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 1 male(s)/female (2008
est.)
Infant mortality rate:
total: 65.99 deaths/ 1,000 live births
male: 69.65 deaths/1,000 live births
female: 62.21 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 52.34 years
male: 51.31 years
female: 53.4 years (2008 est.)
Total fertility rate: 6.81 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate: 41%
(2003 est.)
HIV/AIDS— people living with
HIV/AIDS: 530,000 (2001 est.)
HIV/AIDS— deaths: 78,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diar¬
rhea, hepatitis A, and typhoid fever
vectorborne diseases: chikungunya,
malaria, plague, and African trypanoso¬
miasis (sleeping sickness)
water contact disease: schistosomiasis
(2008)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 16.9%,
Banyakole 9.5%, Basoga 8.4%, Bakiga
6.9%, Iteso 6.4%, Langi 6.1%, Acholi
4.7%, Bagisu 4.6%, Lugbara 4.2%,
Bunyoro 2.7%, other 29.6% (2002
census)
Religions: Roman Catholic 41.9%,
Protestant 42% (Anglican 35.9%,
Pentecostal 4-6%, Seventh Day
Adventist 1.5%), Muslim 12.1%, other
3.1%, none 0.9% (2002 census)
Languages: English (official national
language, taught in grade schools, used in
courts of law and by most newspapers
and some radio broadcasts), Ganda or
Luganda (most widely used of the Niger-
Congo languages, preferred for native
language publications in the capital and
may be taught in school), other Niger-
Congo languages, Nilo-Saharan lan¬
guages, Swahili, Arabic
Literacy:
definition: age 15 and over can read and
write
total population: 66.8%
male: 76.8%
female: 57.7% (2002 census)','abfeef98c3ec5547e8ca53f18a259feb35af2ff352ef4b8844f53a18609f4597','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f380cae7bcfe3f613c3d9c1b41f9c108074f4717ef9d16c2abc780552e49e23a',2009,'UA','Ukraine','geography',1260,'Location: Eastern Europe, bordering the
Black Sea, between Poland, Romania,
and Moldova in the west and Russia in
the east
Geographic coordinates: 49 00 N, 32 00
E
Map references: Asia, Europe
Area:
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Area— comparative: slightly smaller
than Texas
Land boundaries:
total: 4,663 km
border countries: Belarus 891 km,
Hungary 103 km, Moldova 939 km,
Poland 526 km, Romania (south) 169
km, Romania (west) 362 km, Russia
1,576 km, Slovakia 97 km
Coastline: 2,782 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200-m or to the depth of
exploitation
Climate: temperate continental;
Mediterranean only on the southern
Crimean coast; precipitation dispropor¬
tionately distributed, highest in west and
north, lesser in east and southeast; win¬
ters vary from cool along the Black Sea
to cold farther inland; summers are warm
across the greater part of the country, hot
in the south
Terrain: most of Ukraine consists of fer¬
tile plains (steppes) and plateaus, moun¬
tains being found only in the west (the
Carpathians), and in the Crimean
Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, man¬
ganese, natural gas, oil, salt, sulfur,
graphite, titanium, magnesium, kaolin,
nickel, mercury, timber, arable land
Land use:
arable land: 53.8%
permanent crops: 1.5%
other: 44-7% (2005)
Irrigated land: 22,080 sq km (2003)
Total renewable water resources: 139.5
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 37.53 cu
km/yr (12%/35%/52%)
per capita: 807 cu m/yr (2000)
Natural hazards: NA
Environment— current issues: inade¬
quate supplies of potable water; air and
water pollution; deforestation; radiation
contamination in the northeast from
1986 accident at Chornobyl’ Nuclear
Power Plant
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air
Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds
Geography — note: strategic position at
the crossroads between Europe and Asia;
second- largest country in Europe','b87a1592b9f8728decd4d28dfae9df78bdc50a5772107b3b90afb9a65e0a3edb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bfd6193f850e20eac72a720c05c12241378df7d06c9d566bc4b0c556035e543',2009,'UY','Uruguay','geography',1278,'Location: Southern South America, bor¬
dering the South Atlantic Ocean,
between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00
w
Map references: South America
Area:
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area — comparative: slightly smaller
than the state of Washington
Land boundaries:
total: 1,648 km
border countries: Argentina 580 km,
Brazil 1,068 km
Coastline: 660 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or edge of con¬
tinental margin
Climate: warm temperate; freezing tem¬
peratures almost unknown
Terrain: mostly rolling plains and low
hills; fertile coastal lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: arable land,
hydropower, minor minerals, fisheries
Land use:
arable land: 7.77%
permanent crops: 0.24%
other: 91.99% (2005)
Irrigated land: 2,100 sq km (2003)
Total renewable water resources: 139
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.15 cu
km/yr (2%/l%/96%)
per capita: 910 cu m/yr (2000)
Natural hazards: seasonally high winds
(the pampero is a chilly and occasional
violent wind that blows north from the
Argentine pampas), droughts, floods;
because of the absence of mountains,
which act as weather barriers, all loca¬
tions are particularly vulnerable to rapid
changes from weather fronts
Environment — current issues: water
pollution from meat packing/tannery
industry; inadequate solid/hazardous
waste disposal
Environment — international agree¬
ments: party to: Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 94, Wetlands
signed, but not ratified: Marine Dumping,
Marine Life Conservation
Geography — note: second-smallest South
American country (after Suriname); most
of the low-lying landscape (three-quarters
of the country) is grassland, ideal for cattle
and sheep raising','6f231413c5484c651a0f668b1336a72f9c9961f800f90b142f900d8835227de5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35ae189ee190aa858478d4806a4e17f0c473d6e916336b4acb113518106baed0',2009,'UZ','Uzbekistan','geography',1283,'Location: Central Asia, north of
fertilizers and pesticides is the cause of
many human health disorders; increasing
soil salination; soil contamination from
buried nuclear processing and agricul¬
tural chemicals, including DDT
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the
selected agreements
Geography — note: along with
Liechtenstein, one of the only two
doubly landlocked countries in the world
Location: Oceania, group of islands in
the South Pacific Ocean, about three-
quarters of the way from Hawaii to','0440736cd7ebaa7d4de3564de76b1a18a60151bcfdf01c617dbbdd943f69e9dd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('772938416980ca2a06ac3907a314b4e5d65c1b7544b5b7b6be1604eb8acbfb1b',2009,'WF','Wallis and Futuna','geography',1292,'Location: Oceania, islands in the South
Pacific Ocean, about two-thirds of the
way from Hawaii to New Zealand
Geographic coordinates: 13 18 S, 176
12 W
Map references: Oceania
Area: total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes lie Uvea (Wallis Island),
lie Futuna (Futuna Island), He Alofi, and
20 islets
Area— comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
708
0 2& 50* m
O 25
50 it*
ties
Wallis
MATA-UTU*
tie Uv6a
Scat
ties de Home
!(e Futum
ySigav® (Leava)
he Mod
h Pacific Oc''mn
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, rainy season
(November to April); cool, dry season
(May to October); rains 2,500-3,000
mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 7.14%
permanent crops: 35.71%
other: 57.15% (2005)
Irrigated land: NA
Natural hazards: NA
Environment— current issues: defor¬
estation (only small portions of the orig¬
inal forests remain) largely as a result of
the continued use of wood as the main
fuel source; as a consequence of cutting
down the forests, the mountainous ter¬
rain of Futuna is particularly prone to
erosion; there are no permanent settle¬
ments on Alofi because of the lack of
natural fresh water resources
Geography — note: both island groups
have fringing reefs','a3d143e5aa84a81c8b88562b92f4560ed99b96bd7ab3f4191e1b65f8eb1325a1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4108f5925d4dac26a35f92643246a037836277620553828909d21fa76faa2bf',2009,'NC','New Caledonia','geography',1299,'Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15
E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun
Salient, and the northwest quarter of the
Dead Sea, but excludes Mt. Scopus; East
Jerusalem and Jerusalem No Man’s Land
are also included only as a means of
depicting the entire area occupied by
Israel in 1967
Area— comparative: slightly smaller
than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97
km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; temperature and
precipitation vary with altitude, warm to
hot summers, cool to mild winters
Terrain: mostly rugged dissected upland,
some vegetation in west, but barren in
east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Natural resources: arable land
Land use:
arable land: 16.9%
permanent crops : 18.97%
other: 64.13% (2001)
Irrigated land: 150 sq km; note —
includes Gaza Strip (2003)
Natural hazards: droughts
Environment — current issues: adequacy
of fresh water supply; sewage treatment
Geography — note: landlocked; high¬
lands are main recharge area for Israel’s
coastal aquifers; there are 242 West Bank
settlements and 29 East Jerusalem settle¬
ments in addition to at least 20 occupied
outposts (August 2005 est.)','647c9e93e9f13cb13172d1b6a34390e9342db4a4bdab19a0a73a547f9cd537b7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d84eb9c4c12d271775d98a98c354fac2d768d3829a474fe55b5c04a8ad3e194c',2009,'EH','Western Sahara','geography',1301,'Location: Northern Africa, bordering
the North Atlantic Ocean, between
Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00
w
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area — comparative: about the size of
Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km,
Mauritania 1,561 km, Morocco 443 km
Coastline: 1,110 km
Maritime Claims: contingent upon reso¬
lution of sovereignty issue
Climate: hot, dry desert; rain is rare; cold
offshore air currents produce fog and
heavy dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed elevation 805 m
Natural resources: phosphates, iron ore
Land use: arable land: 0.02%
permanent crops: 0%
other: 99.98% (2005)
Irrigated land: NA
Natural hazards: hot, dry, dust/sand-
laden sirocco wind can occur during
winter and spring; widespread harmattan
haze exists 60% of time, often severely
restricting visibility
Environment — current issues: sparse
water and lack of arable land
Environment — international agree¬
ments: party to: none of the selected
agreements
signed, but not ratified: none of the
selected agreements
Geography — note: the waters off the
coast are particularly rich fishing areas','0947db1e270867e0c0eaf254995162dc8bf3ce3e47e04f76ad19ecd71b5eb282','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a121601f72575ba223c2b3c8b8578ebc9a279e8404350610f6cc87fe955ceab',2009,'ZW','Zimbabwe','geography',1320,'Location: Southern Africa, between
South Africa and Zambia
Geographic coordinates: 20 00 s, 30 00
E
Map references: Africa
Area: total: 390,580 sq km
land: 386,670 sq km
water: 3,910 sq km
Area — comparative: slightly larger than
Montana
Land boundaries: total: 3,066 km
border countries: Botswana 813 km,
Mozambique 1,231 km, South Africa
225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; moderated by altitude;
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld); mountains
in east
Elevation extremes:
lowest point: junction of the Runde and
Save rivers 162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore,
asbestos, gold, nickel, copper, iron ore,
vanadium, lithium, tin, platinum group
metals
Land use:
arable land: 8.24%
permanent crops: 0.33%
other: 91.43% (2005)
Irrigated land: 1,740 sq km (2003)
Total renewable water resources: 20 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 4.21 cu
km/yr (14%/7%/79%)
per capita: 324 cu m/yr (2002)
Natural hazards: recurring droughts;
floods and severe storms are rare
Environment — current issues: defor¬
estation; soil erosion; land degradation;
air and water pollution; the black rhi¬
noceros herd — once the largest concen¬
tration of the species in the world — has
been significantly reduced by poaching;
poor mining practices have led to toxic
waste and heavy metal pollution
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Endangered
Species, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the
selected agreements
Geography — note: landlocked; the
Zambezi forms a natural riverine
boundary with Zambia; in full flood
(February- April) the massive Victoria
Falls on the river forms the world’s
largest curtain of falling water
Location: Eastern Asia, islands bordering
the East China Sea, Philippine Sea,
South China Sea, and Taiwan Strait,
north of the Philippines, off the south¬
eastern coast of China
Geographic coordinates: 23 30 N, 121
00 E
Map references: Southeast Asia
Area:
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and
Quemoy islands
Area— comparative: slightly smaller
than Maryland and Delaware combined
Land boundaries: 0 km
Coastline: 1,566.3 km
Maritime claims:
tenitorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; marine; rainy season
during southwest monsoon (June to
August); cloudiness is persistent and
extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in
west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,952 m
Natural resources: small deposits of
coal, natural gas, limestone, marble, and
asbestos
Land use:
arable land: 24%
permanent crops: 1%
other: 75% (2001)
Irrigated land: NA
Total renewable water resources: 67 cu
km (2000)
Natural hazards: earthquakes and
typhoons
Environment— current issues: air pollu¬
tion; water pollution from industrial
emissions, raw sewage; contamination of
drinking water supplies; trade in endan¬
gered species; low-level radioactive waste
disposal
Environment— international agree¬
ments: party to: none of the selected
agreements because of Taiwan’s interna¬
tional status
signed, but not ratified: none of the
selected agreements because of Taiwan’s
international status
Geography — note: strategic location
adjacent to both the Taiwan Strait and
the Luzon Strait
Location: Europe between the North
Atlantic Ocean in the west and Russia,
Belarus, and Ukraine to the east
Map references: Europe
Area:
total: 4,324,782 sq km
Area — comparative: less than one-half
the size of the US
Land boundaries:
total: 12,440.8 km
border countries: Albania 282 km,
Andorra 120.3 km, Belarus 1,050 km,
Croatia 999 km, Holy See 3.2 km,
Liechtenstein 34-9 km, Macedonia 394
km, Moldova 450 km, Monaco 4.4 km,
Norway 2,348 km, Russia 2,257 km, San
Marino 39 km, Serbia 945 km,
Switzerland 1,811 km, Turkey 446 km,
Ukraine 1,257 km
note: data for European Continent only
Coastline: 65,992.9 km
Maritime claims: NA
Climate: cold temperate; potentially
subarctic in the north to temperate; mild
wet winters; hot dry summers in the
south
Terrain: fairly flat along the Baltic and
Atlantic coast; mountainous in the cen¬
tral and southern areas
Elevation extremes:
lowest point: Lammefjord, Denmark -7 m;
Zuidplaspolder, Netherlands -7 m
highest point: Mont Blanc 4,807 m;
note-situated on the border between
France and Italy
Naturai resources: iron ore, natural gas,
petroleum, coal, copper, lead, zinc,
bauxite, uranium, potash, salt,
hydropower, arable land, timber, fish
Land use:
arable land: NA
permanent crops: NA
other: NA
Irrigated land: 168,050 sq km (2003
est.)
Natural hazards: flooding along coasts;
avalanches in mountainous area; earth¬
quakes in the south; volcanic eruptions
in Italy; periodic droughts in Spain; ice
floes in the Baltic
Environment— current issues: NA
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants,
Air Pollution-Sulphur 94, Antarctic-
731
THE CIA WORLD FACTBOOK
Marine Living Resources, Biodiversity,
Climate Change, Climate Change-
Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Tropical Timber
82, Tropical Timber 94
signed but not ratified: Air Pollution-
Volatile Organic Compounds
Population: 491,018,677 (July 2008 est.)
Age structure:
0-14 years: 15.7% (male
37,208,905/female 35,254,445)
15-64 years: 67.2% (male
155,807,769/female 153,690,235)
65 years and over: 17.1% (male
32,592,595/female 46,273,197) (2008
est.)
Median age: note — see individual
country entries of member states
Population growth rate: 0.12% (2008
est.)
Birth rate: 9.97 births/1,000 population
(2008 est.)
Death rate: 10.22 deaths/1,000 popula¬
tion (2008 est.)
Net migration rate: 1.46 migrant(s)/
1,000 population (2008 est.)
Sex ratio:
at birth: NA
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female
(2007 est.)
Infant mortality rate:
total: 5.84 deaths/1,000 live births
male: 6.51 deaths/1,000 live births
female: 5.13 deaths/1,000 live births
(2008 est.)
Life expectancy at birth:
total population: 78.51 years
male: 75.39 years
female: 81.82 years (2008 est.)
Total fertility rate: 1.5 children
born/woman (2008 est.)
HIV/AIDS— adult prevalence rate:
note — see individual country entries of
member states
HIV/AIDS— people living with
HIV/AIDS: note — see individual country
entries of member states
HIV/AIDS— deaths: note — see indi¬
vidual country entries of member states
Religions: Roman Catholic, Protestant,
Orthodox, Muslim, Jewish
Languages: Bulgarian, Czech, Danish,
Dutch, English, Estonian, Finnish,
French, Gaelic, German, Greek,
Hungarian, Italian, Latvian, Lithuanian,
Maltese, Polish, Portuguese, Romanian,
Slovak, Slovene, Spanish, Swedish
note: only official languages are listed;
German, the major language of
Germany, Austria, and Switzerland, is
the most widely spoken mother
tongue — over 19% of the EU popula¬
tion; English is the most widely spoken
language — about 49% of the EU popula¬
tion is conversant with it (2007)
Union name: conventional long form:
European Union
abbreviation: EU
Political structure: a hybrid intergovern¬
mental and supranational organization
Capital: name: Brussels (Belgium),
Strasbourg (France), Luxembourg
geographic coordinates: 50 50 N, 4 20 E
time difference: UTC+1 (6 hours ahead of
Washington, DC during Standard Time)
daylight saving time: +lhr, begins last
Sunday in March; ends last Sunday in
October
note: the Council of the European Union
meets in Brussels, Belgium, the European
Parliament meets in Brussels and
Strasbourg, France, and the Court of
Justice of the European Communities
meets in Luxembourg
Member states: 27 countries: Austria,
Belgium, Bulgaria, Cyprus, Czech
Republic, Denmark, Estonia, Finland,
France, Germany, Greece, Hungary,
Ireland, Italy, Latvia, Lithuania,
Luxembourg, Malta, Netherlands,
Poland, Portugal, Romania, Slovakia,
Slovenia, Spain, Sweden, UK; note —
Canary Islands (Spain), Azores and
Madeira (Portugal), French Guiana,
Guadeloupe, Martinique, and Reunion
(France) are sometimes listed separately
even though they are legally a part of
Spain, Portugal, and France; candidate
countries: Croatia, Macedonia, Serbia,
Turkey
Independence: 7 February 1992
(Maastricht Treaty signed establishing
the EU); 1 November 1993 (Maastricht
Treaty entered into force)
National holiday: Europe Day 9 May
(1950); note — a Union-wide holiday,
the day that Robert SCHUMAN pro¬
posed the creation of the European Coal
and Steel Community to achieve an
organized Europe
Constitution: based on a series of
treaties: the Treaty of Paris, which set up
the European Coal and Steel
Community (ECSC) in 1951; the
Treaties of Rome, which set up the
European Economic Community (EEC)
and the European Atomic Energy
Community (Euratom) in 1957; the
Single European Act in 1986; the Treaty
on European Union (Maastricht) in
1992; the Treaty of Amsterdam in 1997;
and the Treaty of Nice in 2003; note — a
new draft Constitutional Treaty, signed
on 29 October 2004 in Rome, gave
member states two years for ratification
either by parliamentary vote or national
referendum before it was scheduled to
take effect on 1 November 2006; defeat
in French and Dutch referenda in May-
June 2005 dealt a severe setback to the
ratification process; in June 2007, the
European Council agreed on a clear and
concise mandate for an
Intergovernmental Conference to form a
political agreement and put it into legal
form; this agreement, known as the
Reform Treaty, is to serve as a constitu¬
tion and will be presented to the
European Council in October 2007, in
order to begin the ratification process
Legal system: comparable to the legal
systems of member states; first suprana¬
tional law system
Suffrage: 18 years of age; universal
Executive branch:
chief of union: President of the European
Commission Jose Manuel DURAO
BARROSO (since 22 November 2004)
cabinet: European Commission (com¬
posed of 27 members, one from each
member country; each commissioner
responsible for one or more policy areas)
elections: the president of the European
Commission is designated by member
governments and is confirmed by the
European Parliament; working from
member state recommendations, the
Commission president then assembles a
“college” of Commission members; the
European Parliament confirms the entire
Commission for a five-year term; the last
confirmation process was held 18
November 2004 (next to be held in
2009)
election results: European Parliament
approved the European Commission by
an approval vote of 449 to 149 with 82
abstentions
note: the European Council brings
together heads of state and government
and the president of the European
Commission and meets at least four
times a year; its aim is to provide the
impetus for the major political issues
relating to European integration and to
issue general policy guidelines
Legislative branch: two legislative
bodies consisting of the Council of the
European Union (27 member-state min¬
isters having 345 votes; the number of
votes is roughly proportional to member-
states’ population; note — the Council is
the main decision-making body of the
EU) and the European Parliament (785
seats, as of 1 January 2007; seats allo¬
cated among member states by propor¬
tion to population; members elected by
direct universal suffrage for a five-year
term)
elections: last held 10-13 June 2004 (next
to be held June 2009)
election results: percent of vote — NA;
seats by party — EPP-ED 268, PES 202,
ALDE 88, Greens/EFA 42, EUL/NGL
41, IND/DEM 36, UEN 27, independ¬
ents 28; note — seats by party as of 1
732
EUROPEAN UNION
December 2007— EPP-ED 275, PES 217,
ALDE 104, UEN 44, Greens/EFA 42,
EUL/NGL 41, IND/DEM 24, independ¬
ents 34, 4 unaccounted for
Judicial branch: Court of Justice of the
European Communities (ensures that
the treaties are interpreted and applied
uniformly throughout the EU; resolve
constitutional issues among the EU insti¬
tutions) — 27 justices (one from each
member state) appointed for a six-year
term; note — for the sake of efficiency,
the court can sit with 13 justices known
as the “Grand Chamber”; Court of First
Instance — 27 justices appointed for a six-
year term
Political parties and leaders:
Confederal Group of the European
United Left-Nordic Green Left or
EUL/NGL [Francis WURTZ]; European
People’s Party-European Democrats or
EPP-ED [Joseph DAUL]; Group of the
Alliance of Liberals and Democrats for
Europe or ALDE [Graham R.
WATSON]; Group of Greens/European
Free Alliance or Greens/EFA [Monica
FRASSONI and Daniel Marc COHN-
BENDIT]; Identity, Tradition,
Sovereignty Group or ITS [Bruno
GOLLNISCH];
Independence/Democracy Group or
IND/DEM Qens-Peter BONDE and
Nigel FAR AGE]; Socialist Group in the
European Parliament or PES [Martin
SCHULZ]; Union for Europe of the
Nations Group or UEN [Brian
CROWLEY and Cristiana MUSCAR-
DINI]
International organization participa¬
tion: European Union: ARF (dialogue
member), ASEAN (dialogue member),
IDA, OAS (observer), UN (observer)
European Community: Australian Group,
CBSS, CERN, FAO, EBRD, G-10,
NAM (observer), NSG (observer),
OECD, UNRWA, WCO, WTO, ZC
(observer)
European Central Bank: BIS
European Investment Bank: EBRD,
WADB (nonregional member)
Diplomatic representation in the US:
chief of mission: Ambassador John
BRUTON
chancery: 2300 M Street, NW,
Washington, DC 20037
telephone: [1] (202) 862-9500
FAX: [1] (202) 429-1766
Diplomatic representation from the US:
chief of mission: Ambassador C. Boyden
GRAY
embassy: 13 Zinnerstraat/Rue Zinner, B-
1000 Brussels
mailing address: same as above
telephone: [32] (2) 508-2222
FAX: [32] (2) 512-5720
Flag description: blue field with 12 five-
pointed gold stars arranged in a circle in
the center, representing the union of the
peoples of Europe; the number of stars is
fixed','f917941c4cfe5ecdf09158fbe60680f49e9c8ec23d1ebaeab9521689d82bf065','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea2311a1ef11c860cd6938b78cd9cf48d2e644ef73034f9982b1e1fca440b998',2009,'','','geography',2,'Location:
Geographic coordinates:
Map references:
Area:
total
land
water
Area - comparative:
Land boundaries:
total
border countries
Coastline:
Maritime claims:
territorial sea
contiguous zone
exclusive economic zone
continental shelf
exclusive fishing zone
Climate:
Terrain:
Elevation extremes:
lowest point
highest point
Natural resources:
Land use:
arable land
permanent crops
other
Irrigated land:
Total Renewable Water Resources:
Freshwater withdrawal (domestic/industrial/agricultural):
total
per capita
Natural hazards:
Environment - current issues:
Environment - international agreements:
party to
signed, but not ratified
Geography - note:','3f859db7313cd5b10d5cf390a07bf3ae8ab30197635ea84fb8220068ce109485','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b1d68ff391ec7ee229386fde5f414571d6d636e9f60ed76082ad8e7ec072b11',2009,'TC','Turks and Caicos Islands','geography',19,'This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note
This entry includes miscellaneous geographic information of
significance not included elsewhere.
Gini index
See entry for Distribution of family income - Gini index
Why can''t I find a geographic name for a particular country?
The World Factbook is not a gazetteer (a dictionary or index of
places, usually with descriptive or statistical information) and
cannot provide more than the names of the administrative divisions
(in the Government category) and major cities/towns (on the country
maps). Our expanded Cross-Reference List of Geographic Names,
however, includes many of the world''s major geographic features as
well as historic (former) names of countries and cities mentioned in
The World Factbook.
Why are Taiwan and the European Union listed out of alphabetical
order at the end of the Factbook entries?
Taiwan is listed after the A-Z country entries because even though
the mainland People''s Republic of China claims Taiwan, elected
Taiwanese authorities de facto administer the island and reject
mainland sovereignty claims. With the establishment of diplomatic
relations with China on January 1, 1979, the US Government
recognized the People''s Republic of China as the sole legal
government of China, acknowledging the Chinese position that there
is only one China and that Taiwan is part of China.
The European Union (EU) is not a country, but it has taken on many
nation-like attributes and these may be expanded in the future. A
more complete explanation on the inclusion of the EU into the
Factbook can be found in the Preliminary statement.
Since we have an ambassador who represents the US at the Vatican,
why is this entity not listed in the Factbook?
Vatican City is found under Holy See. The term "Holy See" refers to
the authority and sovereignty vested in the Pope and his advisors to
direct the worldwide Catholic Church. As the jurisdictional equal of
a state, the Holy See can enter into treaties and sends and receives
diplomatic representatives. Vatican City, created in 1929 to
administer properties belonging to the Holy See in Rome, is
recognized under international law as a sovereign state, but it does
not send or receive diplomatic representatives. Consequently, Holy
See is included as a Factbook entry, with Vatican City
cross-referenced in the Geographic Names appendix.
Why is Palestine not listed in The World Factbook?
The Palestinian areas of Gaza Strip and West Bank are listed in the
Factbook.
Why are the Golan Heights not shown as part of Israel or Northern
Cyprus with Turkey?
Territorial occupations/annexations not recognized by the United
States Government are not shown on US Government maps.
Why don''t you include information on entities such as Tibet or
Kashmir?
The World Factbook provides information on the administrative
divisions of a country as recommended by the United States Board on
Geographic Names (BGN). The BGN is a component of the US Government
that develops policies, principles, and procedures governing the
spelling, use, and application of geographic names - domestic,
foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to have access to
uniform names of geographic features.
Also included in the Factbook are entries on parts of the world
whose status has not yet been resolved (e.g., West Bank, Spratly
Islands). Specific regions within a country or areas in dispute
among countries are not covered.
What do you mean when you say that a country is "doubly landlocked"?
A doubly landlocked country is one that is separated from an ocean
or an ocean-accessible sea by two intervening countries. Uzbekistan
and Liechtenstein are the only countries that fit this definition.
Why is the area of the United States described as "slightly larger
than China" in the Factbook , while other sources list China as
larger in area than the United States?
It all depends on whether one is looking at total area (land and
water) when making the comparison (which is the criterion used by
the Factbook) or just land area (which excludes inland water
features such as rivers and lakes).
Total area (combining land and water)
United States = 9,826,630 sq km
China = 9,596,960 sq km
Land only (without any water features)
United States = 9,161,923 sq km
China = 9,326,410 sq km
Why has The World Factbook dropped the four French departments of
Guadeloupe, Martinique, Reunion, and French Guiana?
The four entities are no longer in The World Factbook because their
status has changed. While they are overseas departments of France,
they are also now recognized as French regions, having equal status
to the 22 metropolitan regions that make up European France. In
other words, they are now recognized as being part of France proper.
Their status is somewhat analogous to Alaska and Hawaii vis-a-vis
the contiguous United States. Although separated from the larger
geographic entity, they are still considered to be an integral part
of it.
Photos ::
Why do you not have pictures for every country?
Inclusion of photos in The World Factbook is a new feature that
premiered with the unveiling of the redesigned online World Factbook
in June 2009. This is a long-term project, and we plan to
continuously add more photos to the site over time. Eventually, we
hope to have images for every country in the Factbook.
Could you include photos of people from different locations around
the world?
Factbook policy is to not include photos showing identifiable
individuals.
I have great travel photos from my trips abroad. Can I submit them
to your web site to enhance your photo collection?
We appreciate the many offers from the public to contribute to our
photo collection. However, we only use photos from US Government
sources.
Can I use a photo in a report I''m writing?
Yes! All photos in The World Factbook are in the public domain.
Spelling and Pronunciation ::
Why is the spelling of proper names such as rulers, presidents, and
prime ministers in The World Factbook different than their spelling
in my country?
The Factbook staff applies the names and spellings from the Chiefs
of State link on the CIA Web site. The World Factbook is prepared
using the standard American English computer keyboard and does not
use any special characters, symbols, or most diacritical markings in
its spellings. Surnames are always spelled with capital letters;
they may appear first in some cultures.
Why does the spelling of geographic names, features, cities,
administrative divisions, etc. in the Factbook differ from those
used in my country?
The United States Board on Geographic Names (BGN) recommends and
approves names and spellings. The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic names -
domestic, foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to use uniform names
of geographic features. (A note is usually included where changes
may have occurred but have not yet been approved by the BGN). The
World Factbook is prepared using the standard American English
computer keyboard and does not use any special characters, symbols,
or most diacritical markings in its spellings.
Why does The World Factbook omit pronunciations of country or leader
names?
There are too many variations in pronunciation among
English-speaking countries, not to mention English renditions of
non-English names, for pronunciations to be included. American
English pronunciations are included for some countries such as Qatar
and Kiribati.
Why is the name of the Labour party misspelled?
When American and British spellings of common English words differ,
The World Factbook always uses the American spelling, even when
these common words form part of a proper name in British English.
Policies and Procedures ::
What is The World Factbook''s source for a specific subject field?
The Factbook staff uses many different sources to publish what we
judge are the most reliable and consistent data for any particular
category. Space considerations preclude a listing of these various
sources.
The names of some geographic features provided in the Factbook
differ from those used in other publications. For example, in Asia
the Factbook has Burma as the country name, but in other
publications Myanmar is used; also, the Factbook uses Sea of Japan
whereas other publications label it East Sea. What is your policy on
naming geographic features?
The Factbook staff follows the guidance of the United States Board
on Geographic Names (BGN). The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic names -
domestic, foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to have access to
uniform names of geographic features. The position of the BGN is
that the names Burma and Sea of Japan be used in official US
Government maps and publications.
Why is most of the statistical information in the Factbook given in
metric units, rather than the units standard to US measure?
US Federal agencies are required by the Metric Conversion Act of
1975 (Public Law 94-168) and by Executive Order 12770 of July 1991
to use the International System of Units, commonly referred to as
the metric system or SI. In addition, the metric system is used by
over 95 percent of the world''s population.
Why don''t you include information on minimum and maximum temperature
extremes?
The Factbook staff judges that this information would only be useful
for some (generally smaller) countries. Larger countries can have
large temperature extremes that do not represent the landmass as a
whole.
What information sources are used for the country flags?
Flag designs used in The World Factbook are based on various
national and vexillological sources.
Why do your GDP (Gross Domestic Product) statistics differ from
other sources?
We have two sets of GDP dollar estimates in The World Factbook , one
derived from purchasing power parity (PPP) calculations and the
other derived from official exchange rates (OER). Other sources
probably use one of the two. See the Definitions and Notes section
on GDP and GDP methodology for more information.
On the CIA Web site, Chiefs of State is updated weekly, but the last
update for the Factbook was an earlier date. Why the discrepancy?
Although Chiefs of State and The World Factbook both appear on the
CIA Web site, they are produced and updated by separate staffs.
Chiefs of State includes fewer countries but more leaders, and is
updated more frequently than The World Factbook, which has a much
larger database, and includes all countries.
Some percentage distributions do not add to 100. Why not?
Because of rounding, percentage distributions do not always add
precisely to 100%. Rounding of numbers always results in a loss of
precision - i.e., error. This error becomes apparent when percentage
data are totaled, as the following two examples show:
Original Data Rounded to whole integer
Example 1 43.2 43
30.4 30
26.4 26
---- --
100.0 99
Example 2 42.8 43
31.6 32
25.6 26
---- --
100.0 101
When this occurs, we do not force the numbers to add exactly to 100,
because doing so would introduce additional error into the
distribution.
What rounding convention does The World Factbook use?
In deciding on the number of digits to present,The Factbook staff
assesses the accuracy of the original data and the needs of US
Government officials. All of the economic data are processed by
computer - either at the source or by the Factbook staff. The
economic data presented in The Factbook, therefore, follow the
rounding convention used by virtually all numerical software
applications, namely, any digit followed by a "5" is rounded up to
the next higher digit, no matter whether the original digit is even
or odd. Thus, for example, when rounded to the nearest integer, 2.5
becomes 3, rather than 2, as occurred in some pre-computer rounding
systems.
Why do you list "Independence" dates for countries such as France,
Germany, and the United Kingdom?
For most countries, this entry presents the date that sovereignty
was achieved and from which nation, empire, or trusteeship. For
other countries, the date may be some other significant nationhood
event such as the traditional founding date or the date of
unification, federation, confederation, establishment, or state
succession and so may not strictly be an "Independence" date.
Dependent entities have the nature of their dependency status noted
in this same entry.
Technical ::
Does The World Factbook comply with Section 508 of the
Rehabilitation Act regarding accessibility of Web pages?
The World Factbook home page has a link entitled "Text/Low Bandwidth
Version." The country data in the text version is fully accessible.
We believe The World Factbook is compliant with the Section 508 law.
If you are experiencing difficulty, please use our comment form to
provide us details of the specific problem you are experiencing and
the assistive software and/or hardware you are using so that we can
work with our technical support staff to find and implement a
solution. We welcome visitors'' suggestions to improve accessibility
of The World Factbook and the CIA Web site.
I am using the Factbook online and it is not working. What is wrong?
Hundreds of "Factbook" look-alikes exist on the Internet. You can
access The World Factbook at: www.cia.gov, which is the only
official site.
When I attempt to download a PDF (Portable Document Format) map file
(or some other map) the file has no image. Can you fix this?
Some of the files on The World Factbook Web site are large and could
take several minutes to download on a dial-up connection. The screen
might be blank during the download process.
When I open a map on The World Factbook site, it is fuzzy or
granular, or too big or too small. Why?
Adjusting the resolution setting on your monitor should correct this
problem.
Is The World Factbook country data available in machine-readable
format? All I can find is HTML, but I''m looking for simple tabular
data.
The Factbook Web site now features Country Comparison pages for
selected Factbook entries. All of the Country Comparison pages can
be downloaded as tab-delimited data files that can be opened in
other applications such as spreadsheets and databases.
The online Factbook is updated bi-weekly. ISSN 1553-8133
For additional information on government leaders in selected foreign
countries, go to World Leaders.
======================================================================
@Afghanistan (South Asia)
Introduction ::Afghanistan','efe1a05af01d4dc6c9fe57face5364d6e5bad9e92b72882e70485f9f06dc1db7','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

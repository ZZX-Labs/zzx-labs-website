SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65bb0a80b48b3bc9eecd11beaf771c05e46cb365d43924992c52b9d3b74e6de6',2009,'US','United States','transportation',66,'Airports
Airports— with paved runways
total
over 3 ,047 m
2,438 to 3,047 m
l ,524 to 2,437 m
914 to 1 ,523 m
under 914 m
Airports— with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1 ,524 to 2,437 m
914 to 1 ,523 m
under 914 m
Heliports
Pipelines
Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Roadways
total
paved
unpaved
Waterways
Merchant marine
total
ships by type
foreign''Owned
registered in other countries
Ports and terminals
Transportation— note
Airports: 14,947 (2007)
Airports— with paved runways:
total: 5,143
over 3,047 m: 191
2,438 to 3,047 m: 224
1,524 to 2,437 m: 1,452
914 to 1,523 m: 2,323
under 914 m: 953 (2007)
Airports — with unpaved runways:
total: 9,804
2,438 to 3,047 m: 7
1,524 to 2,437 m: 153
914 to 1,523 m: 1,732
under 914 m: 7,912 (2007)
Heliports: 146 (2007)
Pipelines: petroleum products 244,620
km; natural gas 548,665 km (2006)
Railways:
total: 226,612 km
standard gauge: 226,612 km 1.435-m
gauge (2005)
Roadways:
total: 6,430,366 km
paved: 4,165,110 km (includes 75,009
km of expressways)
unpaved: 2,265,256 km (2005)
Waterways: 41,009 km (19,312 km used
for commerce)
note: Saint Lawrence Seaway of 3,769
km, including the Saint Lawrence River
of 3,058 km, shared with Canada (2007)
Merchant marine:
total: 446 ships (1000 GRT or over)
10,308,428 GRT/12,616,742 DWT
hy type: barge carrier 6, bulk carrier 64,
cargo 82, carrier 2, chemical tanker 20,
container 82, passenger 20, pas¬
senger/cargo 60, petroleum tanker 59,
refrigerated cargo 4, roll on/roll off 26,
specialized tanker 1, vehicle carrier 20
foreign-owned: 67 (Australia 2, Canada 4,
Denmark 29, Germany 6, Malaysia 4,
Netherlands 1, Norway 4, Singapore 11,
Sweden 5, UK 1)
registered in other countries: 785 (Antigua
and Barbuda 8, Australia 5, Bahamas
162, Belize 3, Bermuda 23, Cambodia 6,
Canada 3, Cayman Islands 41, Comoros
2, Cyprus 8, Ecuador 1, Greece 10,
Honduras 1, Hong Kong 22, Ireland 2,
Isle of Man 4, Italy 16, Liberia 103,
South Korea 7, Luxembourg 3, Malta 11,
Marshall Islands 129, Netherlands 13,
Netherlands Antilles 1, Norway 18,
Panama 115, Peru 1, Portugal 1, Puerto
Rico 3, Russia 1, Singapore 17, Spain 9,
St Vincent and The Grenadines 21,
Sweden 1, Trinidad and Tobago 1,
Tuvalu 1, UK 11, Vanuatu 1, unknown
4) (2007)
Ports and terminals: Corpus Christi,
Duluth, Hampton Roads, Houston, Long
Beach, Los Angeles, New York,
Philadelphia, Tampa, Texas City','ba0f760d31819a5438ca261f6d3d29ee2745a90d1476015f4df1579bfae97611','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bd3e29e3bc27052b39fd7c8ad629faaf282856fdfe77debeca0ee91dfd2e1da',2009,'AF','Afghanistan','transportation',71,'Airports: 46 (2007)
Airports— with paved runways:
total: 12
over 3,047 m: 4
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 34
over 3,047 m: 1
2,438 to 3,047 m: 4
1 ,524 to 2,437 m: 16
914 to 1 ,523 m: 4
under 914 m: 9 (2007)
Heliports: 9 (2007)
Pipelines: gas 466 km (2007)
Roadways:
total: 34,782 km
paved: 8,229 km
unpaved: 26,553 km (2004)
Waterways: 1,200 km (chiefly Amu
Darya, which handles vessels up to 500
DWT) (2007)
Ports and terminals: Kheyrabad, Shir
Khan
4* ^ISLAMABAD
''w''Zhob*
.Quetta ''4 .
<, Mu!! Jin
S'' Bahawaipur*
Sukkut
, Nok
Kundi','ba6515fb77e912d1ab01cf898c5f3ad4cbd04cc84625a296e4ade2620e88c17a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae30a8e498f59217965571e1d88e6796dc0e0697e2cb821d50f047bd3086900c',2009,'DZ','Algeria','transportation',80,'Airports: 11 (2007)
Airports — with paved runways:
total: 3
2,438 to 3,047 m: 3 (2007)
Airports— with unpaved runways:
total: 8
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1 ,523 m: 1
under 914 m: 4 (2007)
Heliports: 1 (2007)
Pipelines: gas 339 km; oil 207 km
(2007)
Railways:
total: 447 km
standard gauge: 447 km 1.435-m gauge
(2006)
Roadways:
total: 18,000 km
paved: 7,020 km
unpaved: 10,980 km (2002)
Waterways: 43 km (2007)
Merchant marine:
total: 24 ships (1000 GRT or over)
56,550 GRT/85, 521 DWT
by type: cargo 23, roll on/roll off 1
foreign-ovuned: 1 (Turkey 1)
registered in other countries: 3 (Georgia 2,
Panama 1) (2007)
Ports and terminals: Durres, Sarande,
Shengjin, Vlore
Military branches: Land Forces
Command (Army), Naval Forces
Command, Air Defense Command,
General Staff Pieadquarters (includes
Logistics Command, Training and
Doctrine Command) (2007)
Military service age and obligation: 19
years of age (2004)
Manpower available for military
service:
males age i 6 — 49 : 944,592
females age 16-49: 908,527 (2008 est.)
Manpower fit for military service:
males age 16-49: 798,454
females age 16-49: 767,143 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 36,340
females age 16-49: 33,077 (2008 est.)
Military expenditures— percent of
GDP: 1.49% (2005 est.)
Airports: 150 (2007)
Airports — with paved runways:
total: 52
over 3,047 m: 10
2,438 to 3,047 m: 27
1 ,524 to 2,437 m: 10
9 14 to l ,523 m: 4
under 914 m: 1 (2007)
Airports — with unpaved runways:
total: 98
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 26
914 to 1,523 m: 44
under 914 m: 25 (2007)
Heliports: 2 (2007)
Pipelines: condensate 1,532 km; gas
13,861 km; liquid petroleum gas 2,408
km; oil 6,878 km (2007)
Railways:
total: 3,973 km
standard gauge: 2,888 km 1.435-m gauge
(283 km electrified)
narrow gauge: 1,085 km 1.055-m gauge
(2006)
Roadways:
total: 108,302 km
paved: 76,028 km
unpaved: 32,274 km (2004)
Merchant marine:
total: 35 ships (1000 GRT or over)
694,686 GRT/707,251 DWT
by type: bulk carrier 6, cargo 8, chemical
tanker 2, liquefied gas 9, passenger/cargo
3, petroleum tanker 4, roll on/roll off 2,
specialized tanker 1
foreign''owned: 12 (UK 12) (2007)
Ports and terminals: Algiers, Annaba,
Arzew, Bejaia, Djendjene, Jijel,
Mostaganem, Oran, Skikda
Airports: total airports — 49,024
top ten by passengers: Atlanta —
84,846,639; Chicago — 77,028,134;
London— 67,530,197; Tokyo-
65, 8 10,672; Los Angeles — 61,041,066;
Dallas/Fort Worth — 60,226,138; Paris
56,849,567; Frankfurt — 52,810,683;
Beijing— 48,654,770; Denver-
47, 325, 016
top ten by cargo (metric tons): Memphis —
3,692,081; Hong Kong — 3,609,780;
Anchorage — 2,691,395; Seoul —
2,336,572; Tokyo — 2,280,830;
Shanghai — 2,168,122; Paris — 2,130,724;
Frankfurt — 2,127,646; Louisville
(US)— 1,983,032; Singapore—
1,931,881 (2006)
Heliports: 1,359 (2007)
Railways: total: 1,370,782 km (2006)
Roadways:
total: 32,345,165 km (2002)
Waterways: 671,886 km (2004)
Ports and terminals: top ten container
ports (TEUs): Singapore — 24,792,400;
Hong Kong— 23,539,000; Shanghai-
21, 710, 000; Shenzhen (China) —
18,468,890; Busan (South
Korea) — 12,030,000; Kaohsiung
(Taiwan)— 9,774,670;— Rotterdam—
9,603,000; Dubai (UAE)— 8,923,465;
Hamburg— 8,861,545; Los Angeles—
8,469,853 (2006)
Military expenditures— percent of
GDP: roughly 2% of gross world product
(2005 est.)','40ac11ae38d1f3baed341b9a95ed7c7d6b9e25aec41e0b66b763c97593e884e6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8174ea8a1010fa5932ee3e856f9178d06079866a3bda3f7ffb502d93e90ef8cc',2009,'AO','Angola','transportation',95,'Roadways:
total: 270 km
Airports: 232 (2007)
Airports— with paved runways:
total: 31
over 3,047 m: 5
2,438 to 3,047 m: 8
1,524 to 2,437 m: 12
914 to 1 ,523 m: 5
under 914 m: 1 (2007)
Airports — with unpaved runways:
total: 201
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 30
914 to 1,523 m: 95
under 914 m: 69 (2007)
Pipelines: gas 234 km; liquid petroleum
gas 85 km; oil 896 km; oil/gas/water 5 km
(2007)
Railways:
total: 2,761 km
narrow gauge: 2,638 km 1.067-m gauge;
123 km 0.600-m gauge (2006)
Roadways:
total: 51,429 km
paved: 5,349 km
unpaved: 46,080 km (2001)
Waterways: 1,300 km (2007)
Merchant marine:
total: 5 ships (1000 GRT or over) 6,865
GRT/8,825 DWT
by type: cargo 1, passenger/cargo 2, petro¬
leum tanker 2
foreign-owned: 1 (Spain 1)
registered in other countries: 6 (Bahamas 6)
(2007)
Ports and terminals: Cabinda, Lobito,
Luanda, Namibe
Airports: 3 (2007)
Airports — with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Airports — with unpaved runways:
total: 2
under 914 m: 2 (2007)
Roadways:
total: 175 km
paved: 82 km
unpaved: 93 km (2004)
Ports and terminals: Blowing Point,
Road Bay
Airports: 237 (2007)
Airports— with paved runways:
total: 26
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 17
914 to 1 ,523 m: 2
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 211
1,524 to 2,437 m: 17
914 to 1,523 m: 95
under 914 m: 99 (2007)
Pipelines: gas 62 km; oil 71 km (2007)
Railways:
total: 5,138 km
narrow gauge: 3,987 km 1.067-m gauge
(858 km electrified); 125 km 1.000-m
gauge; 1,026 km 0.600-m gauge (2006)
Roadways:
total: 153,497 km
paved: 2,794 km
unpaved: 150,703 km (2004)
Waterways: 15,000 km (2005)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,004
GRT/1,640 DWT
by type: petroleum tanker 1
foreign''owned: 1 (Congo, Republic of the
1) (2007)
Ports and terminals: Banana, Boma,
Bukavu, Bumba, Goma, Kalemie, Kindu,
Kinshasa, Kisangani, Matadi, Mbandaka
Military Congo, Democratic Republic of
the
Military branches: Armed Forces of the
Democratic Republic of the Congo
(FARDC): Army, Navy, Congolese Air
Force (Force Aerienne Congolaise,
FAC) (2008)
Military service age and obligation:
18-45 years of age for military service
Manpower available for military
service:
males age 16-49: 14,101,263 (2008 est.)
Manpower fit for military service:
males age 16-^19: 8,562,989 (2008 est.)
Military expenditures— percent of
GDP: 2.5% (2006)','7ec7f22b591006e381470b26c9046da563373482589f443660e4e707558f64c5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2005a5ced2d5d5ac24b9c2f0c11fdf062ac274e99c1d24a3cf73b3fa53cac50b',2009,'AG','Antigua and Barbuda','transportation',105,'Airports: 27 (2008)
Airports— with unpaved runways:
total: 27
over 3,047 m: 6
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 6 (2008)
Heliports: 53
note: all year-round and seasonal stations
operated by National Antarctic
Programs stations have some kind of hel¬
icopter landing facilities, prepared (heli¬
pads) or unprepared (2007)
Ports and terminals: there are no devel¬
oped ports and harbors in Antarctica;
most coastal stations have offshore
anchorages, and supplies are transferred
from ship to shore by small boats, barges,
and helicopters; a few stations have a
basic wharf facility; US coastal stations
include McMurdo (77 51 S, 166 40 E),
and Palmer (64 43 S, 64 03 W); govern¬
ment use only except by permit (see
Permit Office under “Legal System”); all
ships at port are subject to inspection in
accordance with Article 7, Antarctic
Treaty; offshore anchorage is sparse and
intermittent; relevant legal instruments
and authorization procedures adopted by
the states parties to the Antarctic Treaty
regulating access to the Antarctic Treaty
area, to all areas between 60 and 90
degrees of latitude south, have to be
complied with (see “Legal System”); The
Hydrographic Committee on Antarctica
(HCA), a special hydrographic commis¬
sion of International Hydrographic
Organization (IHO), is responsible for
hydrographic surveying and nautical
charting matters in Antarctic Treaty
area; it coordinates and facilitates provi¬
sion of accurate and appropriate charts
and other aids to navigation in support of
safety of navigation in region; member¬
ship of HCA is open to any IHO
Member State whose government has
acceded to the Antarctic Treaty and
which contributes resources and/or data
to IHO Chart coverage of the area;
members of HCA are Argentina,
Australia, Brazil, Chile, China, Ecuador,
France, Germany, Greece, India, Italy,
NZ, Norway, Russia, South Africa,
Spain, UK, and US (2007)','b3dbd913915784c1f12b764f1d3035e65c3bac5b328607981cae327e1101b844','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1846a7ef8cbc39e9c754654e9a09e6fd4c4d6706b3030d2d086ada08772994d6',2009,'AR','Argentina','transportation',109,'Ports and terminals: Churchill
(Canada), Murmansk (Russia), Prudhoe
Bay (US)
Transportation — note: sparse network of
air, ocean, river, and land routes; the
Northwest Passage (North America) and
Northern Sea Route (Eurasia) are impor¬
tant seasonal waterways','4a52750f0485e025f1de607c2230d3d7fcac3e42eeb0bf215a9b5525be5ede7f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e093008a53df4d51a01e3c4554570d6208e6651f6b44a1409fec3a57824a9d2',2009,'AW','Aruba','transportation',124,'Airports: 1 (2007)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (2007)
Roadways:
total: 800 km
Ports and terminals: Barcadera,
Oranjestad, Sint Nicolaas
Ports and terminals: Alexandria (Egypt),
Algiers (Algeria), Antwerp (Belgium),
Barcelona (Spain), Buenos Aires
(Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Den¬
mark), Dakar (Senegal), Gdansk
(Poland), Hamburg (Germany), Helsinki
(Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon
(Portugal), London (UK), Marseille
(France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New
Orleans (US), New York (US), Oran
(Algeria), Oslo (Norway), Peiraiefs or
Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint
Petersburg (Russia), Stockholm (Sweden)
Transportation — note: Kiel Canal and
Saint Lawrence Seaway are two impor¬
tant waterways; significant domestic
commercial and recreational use of
Intracoastal Waterway on central and
south Atlantic seaboard and Gulf of
Mexico coast of US','f4574bcbf6e33e8f63b1e1f24172a4868a807af7d7952c8868634142cfe71986','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13a03653e5bda739749811af6465ed91e9f56374667c086e1930b996ef762b56',2009,'AT','Austria','transportation',134,'Airports: 461 (2007)
Airports— with paved runways:
total: 317
over 3,047 m: 11
2,438 to 3,047 m: 12
1,524 to 2,437 m: 138
914 to 1 ,523 m: 143
under 914 m: 13 (2007)
Airports— with unpaved runways:
total: 144
1,524 to 2,437 m: 19
914 to 1,523 m: 109
under 914 m: 16 (2007)
Heliports: 1 (2007)
Pipelines: condensate/gas 469 km; gas
26,719 km; liquid petroleum gas 240 km;
oil 3,720 km; oil/gas/water 110 km
(2007)
Railways:
total: 38,550 km
broad gauge: 3,727 km 1.600-m gauge
standard gauge: 20,519 km 1.435-m gauge
(1,877 km electrified)
narrow gauge: 14,074 km 1.067-m gauge
(2,453 km electrified)
dual gauge: 230 km dual gauge (2006)
Roadways:
total: 812,972 km
paved: 341,448 km
unpaved: 471,524 km (2004)
Waterways: 2,000 km (mainly used for
recreation on Murray and Murray-
Darling river systems) (2006)
Merchant marine:
total: 52 ships (1000 CRT or over)
1,322,527 GRT/1,501,865 DWT
by type: bulk carrier 16, cargo 5, chemical
tanker 1, container 1, liquefied gas 4,
passenger 7, passenger/cargo 6, petro¬
leum tanker 7, roll on/roll off 5
foreign''owned: 16 (Canada 2, France 1,
Germany 2, Netherlands 2, Norway 1,
Philippines 1, UK 2, US 5)
registered in other countries: 29 (Antigua
and Barbuda 1, Bahamas 3, Bermuda 4,
Fiji 1, The Gambia 1, Fiberia 2, Marshall
Islands 1, Panama 4, Singapore 6, Tonga
1, UK 1, US 2, Vanuatu 2, unknown 1)
(2007)
Ports and terminals: Brisbane, Dampier,
Fremantle, Gladstone, Hay Point,
Melbourne, Newcastle, Port Hedland,
Port Kembla, Port Walcott, Sydney','520c0ba091c6a8b62df841c7b0bdbe315dda5e998073ef32abed66ff15fee085','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6696ba9cbe31b412f75f53228140b50512ad05ca5ebac8ca055214eba74d9de',2009,'AZ','Azerbaijan','transportation',146,'Airports: 35 (2007)
Airports— with paved runways:
total: 27
over 3,047 m: 2
2,438 to 3,047 m: 6
1 ,524 to 2,437 m: 13
914 to 1 ,523 m: 4
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 8
49
THE CIA WORLD FACTBOOK
9 14 to 1,523 m: 1
under 914 m: 7 (2007)
Heliports: 1 (2007)
Pipelines: gas 3,857 km; oil 2,436 km
(2007)
Railways:
total: 2,122 km
broad gauge: 2,122 km 1.520-m gauge
(1,278 km electrified) (2006)
Roadways:
total: 59,141 km
paved: 29,210 km
unpaved: 29,931 km (2004)
Merchant marine:
total: 86 ships (1000 GRT or over)
421,061 GRT/460,968 DWT
by type: cargo 26, passenger 2, pas-
senger/cargo 9, petroleum tanker 45, roll
on/roll off 1, specialized tanker 3
registered in other countries: 4 (Georgia 1,
Malta 3) (2007)
Ports and terminals: Baku (Baki)
Military branches: Army, Navy, Air and
Air Defense Forces (2008)
Military service age and obligation:
men between 18 and 35 are liable for
military service; 18 years of age for vol¬
untary mi litary service; length of military
service is 18 months and 12 months for
university graduates (2006)
Manpower available for military
service:
males age 1 6-49: 2,278,888
females age 16-49: 2,291,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,696,167
females age 16-49: 1,923,556 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 94,402
females age 16-49: 89,686 (2008 est.)
Military expenditures— percent of
GDP: 2.6% (2005 est.)','5ad1dbf85661af9ffad4782d99986d6edf9b4cedd1170cd443a5f0dfb373e67c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24e7b53d58ab5bd6b8442bd3e83a35ebe6b253d3dc59d28045f89284fd8674c',2009,'BH','Bahrain','transportation',149,'Airports: 62 (2007)
Airports— with paved runways:
total: 24
over 3,047 m: 2
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 12
914 to 1,523 m: 7 (2007)
Airports— with unpaved runways:
total: 38
1 ,524 to 2,437 m: 5
914 to 1,523 m: 11
under 914 m: 22 (2007)
Heliports: 1 (2007)
Roadways:
total: 2,693 km
paved: 1,546 km
unpaved: 1,147 km (2000)
Merchant marine:
total: 1,213 ships (1000 GRT or over)
40,403,455 GRT/54,276,183 DWT
by type: barge carrier 1, bulk carrier 225,
cargo 240, chemical tanker 84, combina¬
tion ore/oil 13, container 72, liquefied
gas 49, livestock carrier 2, passenger 117,
passenger/cargo 34, petroleum tanker
196, refrigerated cargo 118, roll on/roll
off 18, specialized tanker 4, specialized
tanker 1, vehicle carrier 39
foreign'' owned: 1,134 (Angola 6,
Australia 3, Belgium 15, Bermuda 12,
Brazil 1, Canada 13, China 9, Croatia 1,
Cuba 1, Cyprus 20, Denmark 66, Finland
8, France 43, Germany 40, Greece 214,
Flong Kong 3, Iceland 1, Indonesia 3,
Ireland 2, Italy 1, Japan 62, Jordan 2,
Kenya 1, Malaysia 11, Monaco 11,
Montenegro 2, Netherlands 24, Nigeria
2, Norway 232, Philippines 1, Poland 15,
Russia 5, Saudi Arabia 15, Singapore 9,
Slovenia 1, South Africa 1, Spain 11,
Sweden 5, Switzerland 2, Taiwan 1,
Thailand 1, Trinidad and Tobago 1,
Turkey 5, UAE 20, UK 68, US 162,
Uruguay 1, Venezuela 1)
registered in other countries: 3 (Barbados 1,
Panama 2) (2007)
Ports and terminals: Freeport, Nassau,
South Riding Point
Military branches: Royal Bahamian
Defense Force: Land Force, Navy, Air
Wing (2007)
Military service age and obligation: 18
years of age (est.); no conscription (2008)
Manpower available for military
service:
males age 16-49: 80,200 (2008 est.)
Manpower fit for military service:
males age 16-49: 50,282 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 3,016 (2008 est.)
Military expenditures — percent of
GDP: 0.5% (2006)','2e9e5f895f7c8f3de2bc0d6afa107ef6497419bdd3713a4915c4b74854bdb992','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46fac226115fc1d9dbec0dd922282057ea86c1563e661f1c8722bf0b66d6100e',2009,'BB','Barbados','transportation',158,'Airports: 16 (2007)
Airports— with paved runways:
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 5 (2007)
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Pipelines: gas 2,644 km (2007)
Railways: total: 2,768 km
broad gauge: 946 km 1.676-m gauge
narrow gauge: 1,822 km 1.000-m gauge
(2006)
Roadways:
total: 239,226 km
paved: 22,726 km
unpaved: 216,500 km (2003)
Waterways: 8,370 km
note: includes up to 3,060 km main cargo
routes; network reduced to 5,200 km in
dry season (2006)
Merchant marine:
total: 41 ships (1000 GRT or over)
328,530 GRT/468,509 DWT
by type: bulk carrier 3, cargo 27, con¬
tainer 6, passenger/cargo 1, petroleum
tanker 4
foreign- owned: 1 (China 1)
registered in other countries: 9 (Comoros 1,
Honduras 1, Malta 3, Panama 1,
Singapore 2, St Vincent and The
Grenadines 1) (2007)
Ports and terminals: Chittagong,
Mongla Port
Military branches: Bangladesh Defense
Force: Bangladesh Army, Bangladesh
Navy, Bangladesh Air Force (Bangladesh
Biman Bahini, BAF) (2008)
Military service age and obligation: 16
years of age for voluntary military
service; 17 years of age for officers (both
with parental consent); conscription
legally possible in emergency, but has
never been implemented (2008)
Manpower available for military
service:
males age 16-49: 41,199,340 (2008 est.)
Manpower fit for military service:
males age 16-49: 31,968,168 (2008 est.)
Military expenditures— percent of
GDP: 1.5% (2006)
Disputes— international: discussions
with India remain stalled to delimit a
small section of river boundary,
exchange territory for 51 small
Bangladeshi exclaves in India and 1 1 1
small Indian exclaves in Bangladesh,
allocate divided villages, and stop illegal
cross-border trade, migration, violence,
and transit of terrorists through the
porous border; Bangladesh resists India’s
attempts to fence or wall off high-traffic
sections of the porous boundary; a joint
Bangladesh-India boundary inspection
in 2005 revealed 92 pillars are missing;
dispute with India over New
Moore/South Talpatty/Purbasha Island
in the Bay of Bengal deters maritime
boundary delimitation; 21,000 Burmese
Rohingya Muslim refugees reside in two
camps in Bangladesh
Refugees and internally displaced per¬
sons: refugees (country of origin): 26,268
(Burma)
IDPs: 65,000 (land conflicts, religious
persecution) (2007)
Illicit drugs: transit country for illegal
drugs produced in neighboring countries','204b0f8e4787118f25d99f3d1f6439b58dca0ec40c472a407a31ce33b8449a5a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e345b12a48117dcdc84a1046c82ad85faf603f05f0cc04027f6b8870e59be20',2009,'BE','Belgium','transportation',169,'Airports: 67 (2007)
Airports— with paved runways:
total: 36
over 3 ,047 m: 2
2,438 to 3,047 m: 22
1 ,524 to 2,437 m: 4
914 to 1 ,523 m: 1
under 914 m: 7 (2007)
Airports— with unpaved runways:
total: 31
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 2
under 914 m: 27 (2007)
Heliports: 1 (2007)
Pipelines: gas 5,250 km; oil 1,528 km;
refined products 1,730 km (2007)
Railways:
total: 5,512 km
broad gauge: 5,497 km 1.520-m gauge
(874 km electrified)
standard gauge : 15 km 1.435 m (2006)
Roadways:
total: 94,797 km
paved: 84,028 km
unpaved: 10,769 km (2005)
Waterways: 2,500 km (use limited by
location on perimeter of country and by
shallowness) (2003)
Ports and terminals: Mazyr
Military branches: Belarus Armed
Forces: Land Force, Air and Air Defense
Force (2008)
Military service age and obligation:
18-27 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 18 months (2005)
Manpower available for military
service:
males age 16-4 9: 2,491,643
females age 16—49: 2,528,779 (2008 est.)
Manpower fit for military service:
males age 16—49: 1,727,974
females age 16-49: 2,093,106 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 64,232
females age 16-49: 60,788 (2008 est.)
Military expenditures — percent of
GDP: 1.4% (2005 est.)','5190b9de8c583986971e7d2034552edc84c81a311691b098c78f42c4572d8919','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8150268985b7c360d029a77d4f5546874b1b95922d83c127ab432e4a9eb58f5',2009,'FR','France','transportation',173,'Airports: 43 (2007)
Airports— with paved runways: total: 27
over 3,047 m: 6
2,438 to 3,047 m: 7
l ,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 9 (2007)
Airports — with unpaved runways:
total: 16
914 to 1 ,523 m: 1
under 914 m: 15 (2007)
Heliports: 1 (2007)
Pipelines: gas 1,562 km; oil 158 km;
refined products 535 km (2007)
Railways: total: 3,536 km
standard gauge: 3,536 km 1.435-m gauge
(2,950 km electrified) (2006)
Roadways: total: 150,567 km
paved: 1 17,442 km (includes 1,747 km of
expressways)
unpaved: 33,125 km (2004)
Waterways: 2,043 km (1,528 km in reg¬
ular commercial use) (2006)
Merchant marine:
total: 68 ships (1000 GRT or over)
3,786,089 GRT/6,074,664 DWT
by type: bulk carrier 20, cargo 5, chemical
tanker 2, container 9, liquefied gas 16,
passenger 1, petroleum tanker 10, roll
on/roll off 5
foreign-oumed: 9 (Denmark 3, France 1,
Germany 1, Greece 4)
registered in other countries : 123 (Bahamas
15, Bermuda 3, Cyprus 1, France 6,
Gibraltar 3, Greece 16, Hong Kong 4,
Liberia 1, Luxembourg 9, Malta 10,
Marshall Islands 1, Mozambique 2,
Netherlands 2, Netherlands Antilles 1,
Panama 11, Portugal 9, Russia 6, Sierra
Leone 1, Singapore 8, St Kitts and Nevis
1, St Vincent and The Grenadines 9,
Vanuatu 4) (2007)
Ports and terminals: Antwerp, Gent,
Liege, Zeebrugge
Airports: 2 (2007)
Airports— with paved runways:
total: 2
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 1 (2007)
Ports and terminals: Saint-Pierre','d37141597d2111fb733adc5a2e3fd42032edda98003bc4cb227893f33770ee31','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df97d62ec8b31aee4e424816be4875b518ac2c9631cf5e5edd1f4f2c147dc2c8',2009,'BJ','Benin','transportation',181,'Airports: 44 (2007)
Airports— with paved runways:
total: 4
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 1
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 40
2,438 to 3,047 m: 1
914 to 1,523 m: 12
under 9 14 m: 27 (2007)
Roadways:
total: 2,872 km
paved: 488 km
unpaved: 2,384 km (2000)
Waterways: 825 km (navigable only by
small craft) (2007)
Merchant marine:
total: 261 ships (1000 GRT or over)
940,852 GRT/1, 275,1 11 DWT
by type: barge carrier 1, bulk carrier 36,
cargo 190, chemical tanker 5, container
5, petroleum tanker 9, refrigerated cargo
8, roll on/roll off 6, specialized tanker 1
foreign- owned: 217 (China 107, Croatia
1, Cyprus 1, Estonia 1, Hong Kong 5,
Iceland 1, Italy 4, Japan 2, South Korea
4, Latvia 14, Norway 3, Peru 1,
Philippines 1, Russia 39, Singapore 3,
Spain 2, Turkey 11, Ukraine 10, UAE 4,
US 3) (2007)
Ports and terminals: Belize City, Big
Creek
Military branches: Belize Defense Force
(BDF): Army, BDF Air Wing, BDF
Volunteer Guard (2007)
Military service age and obligation: 18
years of age for voluntary military
service; laws allow for conscription only
if volunteers are insufficient; conscrip¬
tion has never been implemented; vol¬
unteers typically outnumber available
positions by 3:1 (2008)
Manpower available for military
service:
males age 16-49: 74,605
females age 16^19: 72,926 (2008 est.)
Manpower fit for military service:
males age 16-49: 54,627
females age 16-49: 53,500 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 3,580
females age 16—49: 3,449 (2008 est.)
Military expenditures— percent of
GDP: 1.4% (2006)
. ''
Airports: 5 (2007)
Airports— with paved runways: total: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 4
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1
914 to 1,523 m: 2 (2007)
Railways: total: 758 km
narrow gauge: 758 km 1.000-m gauge
(2006)
Roadways:
total: 16,000 km
paved: 1,400 km
unpaved: 14,600 km (2006)
Waterways: 150 km (on River Niger
along northern border) (2005)
Ports and terminals: Cotonou','e43b669b5e4c7ab840b42811567f183b156b1def101412c70d0ff2f41726b998','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62aff7301291f96d19ae9c048324aa445e66b4b0d9e7545877c4b078edf691f3',2009,'BM','Bermuda','transportation',191,'Airports: 1 (2007)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (2007)
Roadways: total: 447 km
paved: 447 km
note: public roads — 225 km; private
roads — 222 km (2002)
Merchant marine:
total: 133 ships (1000 GRT or over)
8,366,999 GRT/8,615,385 DWT
by type: bulk carrier 24, container 22, liq¬
uefied gas 30, passenger 23, pas¬
senger/cargo 5, petroleum tanker 15,
refrigerated cargo 10, roll on/roll off 4
foreign''owned: 126 (Australia 4, Belgium
3, China 10, France 1, Germany 21,
Greece 3, Hong Kong 4, Ireland 1, Israel
3, Japan 1, Nigeria 11, Norway 5,
Singapore 1, Sweden 15, UK 20, US 23)
registered in other countries: 50 (Bahamas
12, Croatia 2, Marshall Islands 5,
Philippines 31) (2007)
Ports and terminals: Hamilton, Saint
George','2a71c6adcde422d3ae88244fa5d07d0ab80539d801dafd0d92c75b0a925d7695','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aff9a16191307a596a70f619ab02949f36834099d5d7a20f877a42233916be09',2009,'PE','Peru','transportation',205,'Airports: 1,061 (2007)
Airports— with paved runways:
total: 16
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2007)
Airports — with unpaved runways:
total: 1,045
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 57
914 to 1,523 m: 183
under 914 m: 800 (2007)
Pipelines: gas 4,860 km; liquid petro¬
leum gas 47 km; oil 2,475 km; refined
products 1,589 km; unknown (oil/water)
247 km (2007)
Railways:
total: 3,504 km
narrow gauge: 3,504 km 1.000-m gauge
(2006)
Roadways:
total: 62,479 km
paved: 3,749 km
unpaved: 58,730 km (2004)
Waterways: 10,000 km (commercially
navigable) (2007)
Merchant marine:
total: 25 ships (1000 GRT or over)
73,877 GRT/1 10,148 DWT
by type: bulk carrier 1, cargo 12, carrier 1,
passenger/cargo 2, petroleum tanker 9
foreign''owned: 9 (Argentina 1, China 1,
Egypt 1, Iran 1, Italy 1, Singapore 1,
Syria 1, Taiwan 1, Yemen 1) (2007)
Ports and terminals: Puerto Aguirre
(inland port on the Paraguay/Parana
waterway at the Bolivia/Brazil border);
Bolivia has free port privileges in mar¬
itime ports in Argentina, Brazil, Chile,
and Paraguay
Airports: 838 (2007)
Airports— with paved runways:
total: 13
over 3,047 m: 3
1,524 to 2,437 m: 5
9 14 to 1,523 m: 5 (2007)
Airports— with unpaved runways:
total: 825
1 ,524 to 2,437 m : 26
914 to 1,523 m: 267
under 9 14 m: 532 (2007)
Railways:
total: 36 km
standard gauge: 36 km 1.435-m gauge
(2006)
Roadways:
total: 29,500 km
paved: 14,986 km
unpaved: 14,514 km (1999)
Waterways: 3,100 km (2007)
Merchant marine:
total: 22 ships (1000 GRT or over)
39,693 GRT/43,530 DWT
by type: cargo 16, container 1, livestock
carrier 1, passenger 1, petroleum tanker
2, roll on/roll off 1
foreign-owned: 5 (Argentina 3,
Netherlands 1, Switzerland 1) (2007)
Ports and terminals: Asuncion, Villeta,
San Antonio, Encarnacion','d0952c95367d27362cc0cedb07cee356e8e1bff6645fa0f631a1cf58e296b0fb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4226dfe43f0bf866d5b0c4511ccf3ef64b2257cd4653cd24fe83e9fa3ae05f5',2009,'BV','Bouvet Island','transportation',215,'Airports: 85 (2007)
Airports— with paved runways:
total: 11
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 7
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 74
1 ,524 to 2,437 m: 3
914 to 1 ,523 m: 54
under 9 14 m: 17 (2007)
Railways:
total: 888 km
narrow gauge: 888 km 1.067-m gauge
(2006)
Roadways:
total: 24,455 km
paved: 8,119 km
unpaved: 16,336 km (2004)
Military branches: Botswana Defense
Force (includes an air wing) (2008)
Military service age and obligation: 18
is the apparent age of voluntary military
service; the official qualifications for
determining minimum age are unknown
(2001)
Manpower available for military
service:
males age 16-49: 487,853
females age 16-49: 464,278 (2008 est.)
Manpower fit for military service:
males age 16-49: 290,093
females age 16-49: 257,700 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 23,007
females age 16-49: 22,551 (2008 est.)
Military expenditures— percent of
GDP: 3.3% (2006)
Ports and terminals: none; offshore
anchorage only','a20e702314937e6e17156c16ad55a108ac4f327b24a612f7b07f1879b3d58db0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0e382be4f57776ed1c3cb50bd0a2f7a10d3f8db647c20791f71c60e7c4cc150',2009,'BR','Brazil','transportation',225,'Airports: 4,263 (2007)
Airports — with paved runways:
total: 718
over 3,047 m: 7
2,438 to 3,047 m: 25
1 ,524 to 2,437 m: 167
914 to 1,523 m: 467
under 914 m: 52 (2007)
Airports— with unpaved runways:
total: 3,545
1,524 to 2,437 m: 83
914 to 1,523 m: 1,555
under 914 m: 1,907 (2007)
Heliports: 16 (2007)
Pipelines: condensate/gas 244 km; gas
12,070 km; liquid petroleum gas 351 km;
oil 5,214 km; refined products 4,410 km
(2007)
Railways:
total: 29,295 km
broad gauge: 4,932 km 1.600-m gauge
(939 km electrified)
standard gauge: 194 km 1.440-m gauge
narrow gauge: 23,773 km 1.000-m gauge
(581 km electrified)
dual gauge: 396 km 1.000 m and 1.600-m
gauges (three rails) (78 km electrified)
(2006)
Roadways:
total: 1,751,868 km
paved: 96,353 km
unpaved: 1,655,515 km (2004)
Waterways: 50,000 km (most in areas
remote from industry and population)
(2007)
Merchant marine:
total: 135 ships (1000 GRT or over)
2,020,182 GRT/3,039,015 DWT
by type: bulk carrier 20, cargo 21, carrier
1, chemical tanker 6, container 9, lique¬
fied gas 12, passenger/cargo 12, petro¬
leum tanker 47, roll on/roll off 7
foreign-owned: 16 (Chile 1, Denmark 2,
Germany 7, Mexico 1, Norway 1, Spain
4)
registered in other countries: 5 (Bahamas 1,
Ghana 1, Liberia 3) (2007)
Ports and terminals: Guaiba, Ilha
Grande, Paranagua, Rio Grande, Santos,
Sao Sebastiao, Tubarao','f66208f6404b7ed95c7f38883f5a7f729e01d25c9372e25055da3fd0e65141da','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84cb4b4c05e76835fc3d33a02a8f60f1272ec312ac20f978518d7f622ba7fa88',2009,'BF','Burkina Faso','transportation',235,'total: 131
over 3,047 m: 2
2,438 to 3,047 m: 18
1 ,524 to 2,437 m: 15
9 14 to 1 ,523 m: 1
under 914 m: 95 (2007)
Airports— with unpaved runways:
total: 83
1 ,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 72 (2007)
Heliports: 4 (2007)
Pipelines: gas 2,500 km; oil 339 km;
refined products 156 km (2007)
Railways:
total: 4,294 km
standard gauge: 4,049 km 1.435''m gauge
(2,710 km electrified)
narrow gauge: 245 km 0.760-m gauge
(2006)
Roadways:
total: 44,033 km
paved: 43,593 km (includes 333 km of
expressways)
unpaved: 440 km (2004)
Waterways: 470 km (2007)
Merchant marine:
total: 71 ships (1000 GRT or over)
833,153 GRT/1,194,660 DWT
by type: bulk carrier 37, cargo 14, chem-
ical tanker 4, container 6, liquefied gas 1,
passenger/cargo 2, petroleum tanker 3,
roll on/roll off 4
foreign-owned: 3 (Germany 1, Ireland 1,
Russia 1)
registered in other countries: 39 (Comoros
1, Malta 15, Mongolia 2, Panama 1,
Slovakia 7, St Vincent and The
Grenadines 13) (2007)
Ports and terminals: Burgas, Varna
Military branches: Bulgarian Armed
Forces: Ground Forces, Naval Forces,
Bulgarian Air Forces (Bulgarski
Voennovazdyshni Sily, BVVS) (2008)
Military service age and obligation:
18-27 years of age for voluntary military
service; conscript service obligation — 9
months; as of May 2006, 67% of the
Bulgarian Army comprised of profes-
sional soldiers; conscription ended as of 1
January 2008; Air and Air Defense
Forces and Naval Forces became fully
professional at the end of 2006 (2008)
Manpower available for military
service:
males age 16-49: 1,701,979
females age 16-49: 1,691,092 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,364,029
females age 16-49: 1,401,348 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 39,477
females age 16-49: 37,339 (2008 est.)
Military expenditures— percent of
GDP: 2.6% (2005 est.)
Disputes — international: none
Illicit drugs: major European transship¬
ment point for Southwest Asian heroin
and, to a lesser degree, South American
cocaine for the European market; limited
producer of precursor chemicals; some
money laundering of drug-related pro¬
ceeds through financial institutions
illiij
Juabigouya
A Dadougou OUAGADOUGOU''''-^
Koucfougou
Tsrskodogo‘
htgoui-ma
Dioulasso
„ Banfora
cm aha
C&TE
mvoim
Airports: 86 (2007)
Airports— with paved runways:
total: 25
over 3,047 m: 8
2,438 to 3,047 m: 10
1 ,524 to 2,437 m: 5
914 to 1 ,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 61
over 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1 ,523 m: 14
under 914 m: 32 (2007)
Heliports: 4 (2007)
Pipelines: gas 2,790 km; oil 558 km
(2007)
Railways:
total: 3,955 km
narrow gauge: 3,955 km 1.000-m gauge
(2006)
Roadways:
total: 27,000 km
paved: 3,200 km
unpaved: 23,800 km (2005)
Waterways: 12,800 km (2007)
Merchant marine:
total: 33 ships (1000 GRT or over)
364,447 GRT/549,310 DWT
by type: bulk carrier 7, cargo 20, pas¬
senger 2, passenger/cargo 3, specialized
tanker 1
foreign-owned: 8 (Germany 5, Japan 3)
(2007)
Ports and terminals: Moulmein,
Rangoon, Sittwe','93d4e74c5031065680b877c8df5b083f45ed6b4333c18fffee7966347835e185','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3eb046303fa730e2d6e5faa061b327aa263d92e5e40431cf35d667829b092b6',2009,'BI','Burundi','transportation',251,'Airports: 8 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Airports— with unpaved runways:
total: 7
914 to 1 ,523 m: 4
under 914 m: 3 (2007)
Heliports: 1 (2007)
Roadways: total: 12,322 km
paved: 1,286 km
unpaved: 11,036 km (2004)
Waterways: mainly on Lake Tanganyika
(2005)
Ports and terminals: Bujumbura','27c652cca4dd3ae14d89e7739ef7445c4fdff13c86920980209dfc7f1993e058','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91378266e284d08e45fa5206511e19cedb78abb337115709a6f935a8b3484d20',2009,'CM','Cameroon','transportation',257,'Airports: 17 (2007)
Airports— with paved runways:
total: 6
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 11
1 ,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 1 (2007)
Heliports: 1 (2007)
Railways: total: 602 km
narrow gauge: 602 km 1.000-m gauge
(2006)
Roadways:
total: 38,257 km
paved: 2,4 06 km
unpaved: 35,851 km (2004)
Waterways: 2,400 km (mainly on
Mekong River) (2005)
Merchant marine:
total: 586 ships (1000 GRT or over)
1,889,909 GRT/2,682,881 DWT
by type: bulk carrier 40, cargo 487, chem¬
ical tanker 10, container 9, livestock car¬
rier 3, passenger/cargo 5, petroleum
tanker 11, refrigerated cargo 18, roll
on/roll off 1 , specialized tanker 1 , vehicle
carrier 1
foreigri''Owned: 463 (Canada 6, China
166, Cyprus 9, Egypt 14, Estonia 1,
Gabon 1, Greece 5, Hong Kong 11,
Indonesia 1, Japan 3, South Korea 29,
Latvia 2, Lebanon 7, Nigeria 2, Romania
1, Russia 112, Singapore 2, Syria 32,
Taiwan 1, Turkey 20, Ukraine 27, UAE
2, US 6, Yemen 3) (2007)
Ports and terminals: Phnom Penh,
Kampong Saom (Sihanoukville)
Airports: 5 (2007)
Airports— with paved runways: total: 5
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 2 (2007)
Pipelines: condensate 42 km; conden-
sate/gas 5 km; gas 80 km; oil 54 km
(2007)
Roadways:
total: 2,880 km (2000)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,745
GRT/3,434 DWT
by type: cargo 1 (2007)
Ports and terminals: Bata, Malabo','dbc9721c95cdc320315bb8a3c56f85126f02c6339d661158fb267a4dcfd8983e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f33692879cd4d7142b57a7d5058b9c1f8b6a4847adec2d3c42430b19f5ed8191',2009,'CA','Canada','transportation',269,'Airports: 1,343 (2007)
Airports— with paved runways:
total: 509
over 3,047 m: 18
2,438 to 3,047 m: 16
1,524 to 2,437 m: 149
914 to 1,523 m: 248
under 914 m: 78 (2007)
Airports— with unpaved runways:
total: 834
1 ,524 to 2,437 m: 68
914 to 1,523 m: 356
under 9 14 m: 410 (2007)
Heliports: 11 (2007)
Pipelines: crude and refined oil 23,564
km; liquid petroleum gas 74,980 km
(2006)
Railways:
total: 48,068 km
standard gauge: 48,068 km 1.435-m gauge
(2006)
Roadways:
total: 1 ,042,300 km
paved: 415,600 km (includes 17,000 km
of expressways)
unpaved: 626,700 km (2006)
Waterways: 636 km
note: Saint Lawrence Seaway of 3,769
km, including the Saint Lawrence River
of 3,058 km, shared with United States
(2007)
Merchant marine:
total: 171 ships (1000 GRT or over)
2,191,099 GRT/2,815,416 DWT
by type: bulk carrier 60, cargo 10, carrier
1, chemical tanker 9, combination
ore/oil 1, container 2, passenger 6, pas-
senger/cargo 64, petroleum tanker 12,
roll on/roll off 6
foreign-owned: 8 (Germany 3,
Netherlands 1, Norway 1, US 3)
registered in other countries: 130 (Australia
2, Bahamas 13, Barbados 9, Cambodia 6,
Cyprus 2, Denmark 1, Honduras 1, Hong
Kong 39, Liberia 3, Malta 15, Marshall
Islands 4, Panama 17, St Vincent and
The Grenadines 6, Taiwan 3, US 4,
Vanuatu 5) (2007)
Ports and terminals: Fraser River Port,
Halifax, Hamilton, Montreal, Port-
Cartier, Quebec City, Saint John (New
Brunswick), Sept-Isles, Vancouver
Airports: 8 (2007)
Airports— with paved runways:
total: 8
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 1 (2007)
Roadways:
total: 1,350 km
paved: 932 km
unpaved: 418 km (2000)
Merchant marine:
total: 8 ships (1000 GRT or over) 13,922
GRT/7,726 DWT
by type: cargo 2, chemical tanker 1, pas¬
senger/cargo 5
foreigri''ovuned: 2 (Spain 1, UK 1) (2007)
Ports and terminals: Porto Grande','654f6dfaceea4c598e361d02d5a8d1c791064db9f00e911301062c47047bfc6b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a110c988612b2eb48f3a1ced4033a798424f580734a43869cea6857d5aba1968',2009,'KY','Cayman Islands','transportation',278,'Airports: 3 (2007)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 2 (2007)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (2007)
Roadways:
total: 785 km
paved: 785 km (2002)
Merchant marine:
total: 124 ships (1000 GRT or over)
2,953,923 GRT/4,597,716 DWT
by type: bulk carrier 33, cargo 11, chem¬
ical tanker 41, liquefied gas 1, passenger
1, petroleum tanker 17, refrigerated
cargo 13, roll on/roll off 3, vehicle carrier
4
foreign'' owned: 122 (Denmark 3,
Germany 17, Greece 23, Italy 10, Japan
6, Norway 2, Singapore 10, Sweden 1,
UK 9, US 41) (2007)
Ports and terminals: Cayman Brae,
George Town','f256f46d88f1f6dd3c88478f6649663a4a849f39babe5aa712c5658079ef471a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f4ae74961bed9da398d090a6ce889f171b58e9e715a4b3a8b6cc1d08d20705e',2009,'TD','Chad','transportation',287,'Airports: 51 (2007)
Airports — with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2007)
Airports— with unpaved runways:
total: 48
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1 ,523 m: 24
under 914 m: 13 (2007)
Roadways:
total: 24,307 km (2000)
Waterways: 2,800 km (primarily on the
Oubangui and Sangha rivers) (2006)
Ports and terminals: Bangui, Nola,
Salo, Nzinga','e135d44be213f36f0fddce877830e6f85f07b45c6efe04928ac180e373e7a353','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5900ef5a1ab55740fdecd9e4ae38b0b03b41e76df4c5c26fec1c0910a01e5b78',2009,'CL','Chile','transportation',302,'Airports: 358 (2007)
Airports— with paved runways:
total: 79
over 3,047 m: 5
2,438 to 3,047 m: 8
1,524 to 2,437 m: 22
9 14 to 1 ,523 m: 25
under 914 m: 19 (2007)
Airports— with unpaved runways:
total: 279
2,438 to 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 49
under 9 14 m: 216 (2007)
Pipelines: gas 2,550 km; gas/liquid
petroleum gas 42 km; liquid petroleum
gas 539 km; oil 1,002 km; refined prod¬
ucts 757 km; unknown (oil/water) 97 km
(2007)
Railways:
total: 6,585 km
broad gauge: 2,831 km 1.676-m gauge
(1,317 km electrified)
narrow gauge: 3,754 km 1.000-m gauge
(2006)
Roadways:
total: 79,605 km
paved: 16,080 km (includes 407 km of
expressways)
unpaved: 63,525 km (2001)
Merchant marine:
total: 48 ships (1000 GRT or over)
719,668 GRT/1,016,892 DWT
by type: bulk carrier 10, cargo 6, chemical
tanker 11, container 1, liquefied gas 2,
passenger 4, passenger/cargo 2, petro¬
leum tanker 8, roll on/roll off 1, vehicle
carrier 3
foreign-owned: 1 (Argentina 1)
registered in other countries: 20 (Argentina
7, Brazil 1, Marshall Islands 4, Panama 8)
(2007)
Ports and terminals: Coronel, Huasco,
Lirquen, Puerto Ventanas, San Antonio,
San Vicente, Valparaiso
Military branches: Army of the Nation,
Chilean Navy (Armada de Chile,
includes naval air, marine corps, and
Maritime Territory and Merchant
Marine Directorate (Directemar)),
Chilean Air Force (Fuerza Aerea de
Chile, FACh), Carabineros Corps
(Cuerpo de Carabineros) (2008)
Military service age and obligation:
18-45 years of age for voluntary male
and female military service, although the
right to compulsory recruitment is
retained; service obligation — 12 months
for Army, 22 months for Navy and Air
Force (2008)
Manpower available for military
service:
males age 16-49: 4,242,912
females age 16-49: 4,182,509 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,542,448
females age 16-49: 3,500,059 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 147,518
females age 16-49: 141,139 (2008 est.)
Military expenditures— percent of
GDP: 2.7% (2006)','971cf473ae6d0f3421a85a1188d948407bec1588d83380371633f613be35ceee','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92395a461aa5eb834a62f57ffe1971a0ee3c5fd9d4a6281bd5a4c4963c3ab29',2009,'CN','China','transportation',312,'Airports: 467 (2007)
Airports— with paved runways: total 403
over 3,047 m: 58
2,438 to 3,047 m: 128
1,524 to 2,437 m: 130
914 to 1,523 m: 20
under 914 m: 67 (2007)
Airports— with unpaved runways:
total: 64
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 13
914 to 1 ,523 m: 17
under 914 m: 26 (2007)
Heliports: 35 (2007)
Pipelines: gas 26,344 km; oil 17,240 km;
refined products 6,106 km (2007)
Railways:
total: 75,438 km
standard gauge: 75,438 km 1.43 5 -m gauge
(20,151 km electrified) (2005)
Roadways:
total: 1,930,544 km
paved: 1,575,571 km (includes 41,005
km of expressways)
unpaved: 354,973 km (2005)
Waterways: 124,000 km navigable
(2006)
Merchant marine:
total: 1,775 ships (1000 GRT or over)
22,219,786 GRT/33,8 19,636 DWT
by type: barge carrier 3, bulk carrier 415,
cargo 689, carrier 3, chemical tanker 62,
combination ore/oil 2, container 157,
liquefied gas 35, passenger 8, pas¬
senger/cargo 84, petroleum tanker 250,
refrigerated cargo 33, roll on/roll off 9,
specialized tanker 8, vehicle carrier 17
foreign''owned: 12 (Ecuador 1, Greece 1,
Hong Kong 6, Japan 2, South Korea 1,
Norway 1)
registered in other countries: 1,366
(Bahamas 9, Bangladesh 1, Belize 107,
Bermuda 10, Bolivia 1, Cambodia 166,
Cyprus 10, France 5, Georgia 4,
Germany 2, Honduras 3, Hong Kong
309, India 1, Indonesia 2, Liberia 32,
Malaysia 1, Malta 13, Marshall Islands 3,
Mongolia 3, Norway 47, Panama 473,
Philippines 2, Sierra Leone 8, Singapore
19, St Vincent and The Grenadines 106,
Thailand 1, Turkey 1, Tuvalu 25,
unknown 33) (2007)
Ports and terminals: Dalian,
Guangzhou, Ningbo, Qingdao,
Qinhuangdao, Shanghai, Shenzhen,
Tianj in','cb022e7803a88dcb0ea300d6726de029f199979b4c0fb7ecf6ceb67cac0bb272','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4d4c2d524b2db0f26501fc9cc92adfe0368780b447fb1e3f98326193e0a91a6',2009,'CX','Christmas Island','transportation',318,'Airports: 1 (2007)
Airports — with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 142 km
paved: 32 km
unpaved: 110 km (2006)
Ports and terminals: Flying Fish Cove
Ports and terminals: none; offshore
anchorage only','404402e1f31b3d36dc63c192e3d311fab5547ada11eb809c6373035ec31d2f90','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61ca72f827d438bc1b33aaad0250ccb51e6923a9e8d62ae81c3e157ce1924863',2009,'CO','Colombia','transportation',333,'Airports: 934 (2007)
Airports— with paved runways:
total: 103
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 39
914 to 1,523 m: 42
under 914 m: 12 (2007)
Airports— with unpaved runways:
total: 831
over 3,047 m: 1
1,524 to 2,437 m: 34
914 to 1,523 m: 216
under 914 m: 580 (2007)
Heliports: 2 (2007)
Pipelines: gas 4,329 km; oil 6,140 km;
refined products 3,145 km (2007)
Railways:
total: 3,304 km
standard gauge: 150 km 1.435-m gauge
narrow gauge: 3,154 km 0.914-m gauge
(2006)
148','c22850ff25df9364386d7702210fa559cf44b44f7e262937f19ac08e85d6cd35','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cec858fe3035cb0b8e8adbd7dc7170b7b54d1802775ce935985852e0486ea04',2009,'KM','Comoros','transportation',334,'Roadways: total: 164,257 km (2005)
Waterways: 18,000 km (2006)
Merchant marine:
total : 15 ships (1000 GRT or over)
35,949 GRT/49,161 DWT
by type: cargo 11, liquefied gas 1, petro-
leum tanker 3
registered in other countries: 5 (Antigua
and Barbuda 1, Panama 4) (2007)
Ports and terminals: Barranquilla,
Buenaventura, Cartagena, Santa Marta,
Turbo
Airports: 4 (2007)
Airports— with paved runways:
total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2007)
Roadways:
total: 880 km
paved: 673 km
unpaved: 207 km (2000)
Merchant marine:
total: 144 ships (1000 GRT or over)
657,755 GRT/954,498 DWT
by type: bulk carrier 11, cargo 101, chem¬
ical tanker 3, container 1, livestock car¬
rier 4, passenger 1, passenger/cargo 1,
petroleum tanker 9, refrigerated cargo 6,
roll on/roll off 6, specialized tanker 1
foreign'' owned: 70 (Bangladesh 1,
Bulgaria 1, Cyprus 1, Greece 8, India 2,
Kenya 1, Kuwait 1, Lebanon 5, Norway
1, Pakistan 2, Philippines 1, Russia 9,
Saudi Arabia 1, Syria 8, Turkey 8,
Ukraine 13, UAE 5, US 2) (2007)
Ports and terminals: Mayotte,
Mutsamudu','32a54244a3853c41a2a7e1e3cea5c21e60c5bf23958941b0564f2a705521842d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c896d7b78391ca7ba91065782dd5d684d82c079c919945b1b95e9e2a575b618',2009,'CK','Cook Islands','transportation',353,'Airports: 9 (2007)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 2 (2007)
Airports — with unpaved runways:
total: 7
1 ,524 to 2,437 m: 2
914 to 1 ,523 m: 4
under 914 m: 1 (2007)
Roadways:
total: 320 km
paved: 33 km
unpaved: 287 km (2003)
Merchant marine:
total: 16 ships (1000 GRT or over)
112,129 GRT/126,160 DWT
by type: cargo 5, petroleum tanker 1,
refrigerated cargo 9, roll on/roll off 1
foreign-owned: 11 (Norway 1, NZ 1,
Sweden 9) (2007)
Ports and terminals: Avatiu','23073253c1c0782978eedbbb29956b74273d8f784054c4614b8dc6ac8a3ea2a3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcafb41ce41f70162cfbf0c8d376d5edcd33a8b95a1a1d1decc00a4c6ec5321f',2009,'CR','Costa Rica','transportation',360,'_
Ports and terminals: none; offshore
anchorage only
Airports: 151 (2007)
Airports— with paved runways: total: 36
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 21
under 914 m: 11 (2007)
Airports— with unpaved runways: total: 115
914 to 1,523 m: 19
under 914 m: 96 (2007)
Pipelines: refined products 242 km
(2007)
Railways:
total: 278 km
narrow gauge: 278 km 1.067-m gauge
note: none of the railway network is in
use (2007)
Roadways:
total: 35,330 km
paved: 8,621 km
unpaved: 26,709 km (2004)
Waterways: 730 km (seasonally navi¬
gable by small craft) (2007)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,058
GRT/255 DWT
by type: passenger/cargo 1 (2007)
Ports and terminals: Caldera, Puerto
Limon','12a46b612b8621a63bc7bb5dacaa75fc3a3697153e43b30d617b00b5953e9e88','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4af56993725f7b002707ac58d843b7ffeb4720a43972a405123d29f78db2c704',2009,'HR','Croatia','transportation',368,'Airports: 34 (2007)
Airports— with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2007)
Airports— with unpaved runways:
total: 27
1 ,524 to 2,437 m: 8
914 to 1 ,523 m: 14
under 914 m: 5 (2007)
Pipelines: condensate 102 km; gas 245
km; oil 112 km (2007)
Railways:
total: 660 km
narrow gauge: 660 km 1.000 meter gauge
note: an additional 622 km of this rail¬
road extends into Burkina Faso (2006)
Roadways:
total: 80,000 km
paved: 6,500 km
unpaved: 73,500 km
note: includes intercity and urban roads;
another 20,000 km of dirt roads are in
poor condition and 150,000 km of dirt
roads are impassable (2006)
Waterways: 980 km (navigable rivers,
canals, and numerous coastal lagoons)
(2006)
Ports and terminals: Abidjan, Espoir,
San-Pedro
Airports: 68 (2007)
Airports— with paved runways:
total: 23
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1 ,523 m: 4
under 914 m: 9 (2007)
Airports— with unpaved runways:
total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 37 (2007)
Heliports: 2 (2007)
Pipelines: gas 1,556 km; oil 583 km
(2007)
Railways: total: 2,726 km
standard gauge: 2,726 km 1.435-m gauge
(1,199 km electrified) (2006)
Roadways:
total: 28,788 km (includes 877 km of
expressways) (2006)
Waterways: 785 km (2007)
Merchant marine:
total: 75 ships (1000 GRT or over)
1,165,409 GRT/1,867,160 DWT
by type: bulk carrier 21, cargo 12, chem¬
ical tanker 3, passenger/cargo 28, petro¬
leum tanker 7, refrigerated cargo 1, roll
on/roll off 3
foreign- owned: 2 (Bermuda 2)
registered in other countries: 36 (Bahamas
1, Belize 1, Liberia 5, Malta 12, Marshall
Islands 4, Panama 6, St Vincent and The
Grenadines 7) (2007)
Ports and terminals: Omisalj, Ploce,
Rijeka, Sibenik, Vukovar (on Danube)','a60d3b71bf7589b573c8df596b2328f1b328546af6d6eb56b84dedd0a45ae2b2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4d81e063a58167e6942c8279c43069a42c48d0215862e34e1695c5bf0827111',2009,'CY','Cyprus','transportation',389,'Airports: 16 (2007)
Airports — with paved runways:
total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (2007)
Airports — with unpaved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2007)
Heliports: 10 (2007)
Roadways:
total: 14,630 km (area under government
control: 12,280 km; area administered by
Turkish Cypriots: 2,350 km)
paved: area under government control:
7,979 km (includes 257 km of express¬
ways); area administered by Turkish
Cypriots: 1,370 km
unpaved: area under government control:
4,301 km; area administered by Turkish
Cypriots: 980 km (2006)
Merchant marine:
total: 868 ships (1000 GRT or over)
19,408,418 GRT/30,843,848 DWT
by type: bulk carrier 311, cargo 197,
chemical tanker 58, container 163, liq¬
uefied gas 7, passenger 6, passenger/cargo
24, petroleum tanker 64, refrigerated
cargo 17, roll on/roll off 16, vehicle car¬
rier 5
foreign''owned: 724 (Austria 1, Belgium 1,
Canada 2, China 10, Cuba 2, Denmark
1, Estonia 5, Germany 197, Greece 292,
Hong Kong 2, India 1, Iran 2, Ireland 1,
Israel 4, Italy 5, Japan 19, South Korea 2,
Latvia 1, Lebanon 1, Netherlands 23,
Norway 17, Philippines 1, Poland 18,
Portugal 1, Russia 50, Singapore 1,
Slovenia 4, Spain 7, Sweden 2,
Switzerland 3, Syria 2, Turkey 1, Ukraine
6, UAE 10, UK 21, US 8)
registered in other countries: 133 (Antigua
and Barbuda 2, Bahamas 20, Belize 1,
Cambodia 9, Comoros 1, Georgia 1,
Gibraltar 5, Greece 5, Isle of Man 4,
Liberia 5, Malta 15, Marshall Islands 39,
Norway 2, Panama 15, Russia 2, Samoa
1, St Vincent and The Grenadines 3,
Turkey 2, UK 1, unknown 1) (2007)
Ports and terminals: area under govern¬
ment control: Larnaca, Limassol,
Vasilikos; area administered by Turkish
Cypriots: Famagusta, Kyrenia','609a4cc7050a8d5955c49a2a6bac6283d6dde76a0866f7b01d455f8a6781b3e2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1574aa6473cdffae6fad17345874b4702de3b1146d659b251ef335228f95dad8',2009,'DE','Germany','transportation',396,'Airports: 122 (2007)
Airports— with paved runways:
total: 45
over 3,047 m: 2
2,438 to 3,047 m: 10
1 ,524 to 2,437 m: 13
914 to 1 ,523 m: 2
under 914 m: 18 (2007)
Airports— with unpaved runways:
total: 77
1,524 to 2,437 m: 1
914 to 1 ,523 m: 26
under 914 m: 50 (2007)
181
THE CIA WORLD FACTBOOK
Heliports: 1 (2007)
Pipelines: gas 7,010 km; oil 547 km;
refined products 94 km (2007)
Railways:
total: 9,597 km
standard gauge: 9,597 km 1.435-m gauge
(3,041 km electrified) (2006)
Roadways:
total: 127,865 km
paved: 127,865 km (includes 633 km of
expressways) (2006)
Waterways: 664 km (principally on
Elbe, Vltava, Oder, and other navigable
rivers, lakes, and canals) (2006)
Merchant marine:
registered in other countries: 1 (St Vincent
and The Grenadines 1) (2007)
Ports and terminals: Decin, Prague,
Usti nad Labem
Military branches: Army of the Czech
Republic ( ACR): Joint Forces Command
(includes Army and Air Forces), Support
and Training Forces Command (2007)
Military service age and obligation:
18- 28 years of age for voluntary and
19- 28 for compulsory military service
(2008)
Manpower available for military
service: males age 16-49: 2,522,383
females age 16-49: 2,425,095 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,100,789
females age 16—49: 2,018,101 (2008 est.)
Manpower reaching militarily signifi-
cant age annually:
males age 16-49: 63,124
females age 16-49: 59,786 (2008 est.)
Military expenditures— percent of
GDP: 1.46% (2007 est.)
Airports: 550 (2007)
Airports — with paved runways:
total: 331
over 3,047 m: 14
2,438 to 3,047 m: 52
1,524 to 2,437 m: 58
914 to 1,523 m: 72
under 914 m: 135 (2007)
Airports— with unpaved runways:
total: 219
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 3
914 to 1 ,523 m: 34
under 914 m: 181 (2007)
Heliports: 28 (2007)
Pipelines: condensate 37 km; gas 25,094
km; oil 3,546 km; refined products 3,828
km (2007)
Railways:
total: 48,215 km
standard gauge: 47,962 km 1.435-m gauge
(20,278 km electrified)
narrow gauge : 229 km 1.000-m gauge (16
km electrified); 24 km 0.750-m gauge
(2006)
Roadways:
total: 231,500 km
paved: 231,500 km (includes 12,400 km
of expressways) (2006)
Waterways: 7,467 km
note: Rhine River carries most goods;
Main-Danube Canal links North Sea
and Black Sea (2006)
Merchant marine:
total: 382 ships (1000 GRT or over)
12,085,484 GRT/14,261,476 DWT
by type: bulk carrier 1, cargo 50, chemical
tanker 11, container 269, liquefied gas 5,
passenger 5, passenger/cargo 26, petro¬
leum tanker 12, roll on/roll off 3
foreign''owned: 7 (China 2, Finland 4,
Ireland 1)
registered in other countries: 2,716
(Antigua and Barbuda 891, Australia 2,
Bahamas 40, Belgium 1, Bermuda 21,
Brazil 7, Bulgaria 1, Burma 5, Canada 3,
Cayman Islands 17, Cyprus 197,
Denmark 12, Faroe Islands 1, Finland 2,
France 1, Georgia 2, Gibraltar 117, Hong
Kong 10, Isle of Man 61, Italy 1, Jamaica
1, Liberia 728, Luxembourg 10, Malaysia
2, Malta 67, Marshall Islands 214,
Morocco 1, Netherlands 70, Netherlands
Antilles 48, Norway 2, NZ 1, Panama 38,
Portugal 22, Russia 2, Singapore 18,
Spain 9, Sri Lanka 6, St Vincent and
The Grenadines 3, Sweden 4, Turkey 1,
UK 71, US 6) (2007)
Ports and terminals: Bremen,
Bremerhaven, Duisburg, Hamburg,
Karlsruhe, Lubeck, Rostock,
Wilhemshaven','762d6b277187aad91487f8a37547cfb454df76abd4aa5a20acc29dd44e592ed0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccf294ecc3ecbcb323d694ad11e40c96bc114dcb39858c3b71e07d5a70fd8527',2009,'DM','Dominica','transportation',412,'Airports: 13 (2007)
Airports— with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 10
1 ,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2007)
Railways:
total: 100 km (Djibouti segment of the
Addis Ababa-Djibouti railway)
narrow gauge: 100 km 1.000-m gauge
note: railway under joint control of
Djibouti and Ethiopia but remains
largely inoperable (2006)
Roadways:
total: 3,065 km
paved: 1,226 km
unpaved: 1,839 km (2000)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,369
GRT/3,030 DWT
by type: cargo 1 (2007)
Ports and terminals: Djibouti
Airports: 2 (2007)
Airports — with paved runways: total: 2
914 to 1,523 m: 2 (2007)
191
THE CIA WORLD FACTBOOK
Roadways:
total: 780 km
paved: 393 km
unpaved: 387 km (2000)
Merchant marine:
total: 53 ships (1000 GRT or over)
716,435 GRT/1,252,537 DWT
by type: bulk carrier 9, cargo 30, chemical
tanker 2, container 1, petroleum tanker
7, refrigerated cargo 2, roll on/roll off 1,
vehicle carrier 1
foreign-owned: 50 (Estonia 8, Greece 8,
India 2, Latvia 2, Lebanon 1, Norway 1,
NZ 3, Russia 2, Saudi Arabia 1,
Singapore 8, Syria 2, Turkey 9, Ukraine
3) (2007)
Ports and terminals: Portsmouth,
Roseau','b96ef73a33032cffb01739f1399f0390a572d76ced8c949b2059cb59642203de','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e27c711b5c05a2f18a9ea809f396f774fbc32219b353677127a52a58c126f76',2009,'DO','Dominican Republic','transportation',425,'Airports: 34 (2007)
Airports— with paved runways:
total: 15
over 3,047 m: 3
2,438 to 3,047 m: 4
1 ,524 to 2,437 m: 4
914 to 1 ,523 m: 3
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 19
1 ,524 to 2,437 m: 3
914 to 1 ,523 m: 5
under 914 m: 11 (2007)
Railways:
total: 517 km
standard gauge: 375 km 1.435-m gauge
narrow gauge: 142 km 0.762-m gauge
note: additional 1,226 km operated by
sugar companies in 1.076 m, 0.889 m,
and 0.762-m gauges (2006)
Roadways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (2000)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,587
GRT/1,165 DWT
by type: cargo 1
registered in other countries : 1 (Panama 1)
(2007)
Ports and terminals: Boca Chica,
Caucedo, Puerto Plata, Rio Haina, Santo
Domingo','ed81df14e2ac698e6f23b0f1dbd95db75756a4aeef5507838f374a956ac699de','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4b5f8b529057ce399c9e137f4cd35ea74b570137f14ef49a34fe3b028c8a8ff',2009,'EC','Ecuador','transportation',431,'Airports: 406 (2007)
Airports— with paved runways:
total: 104
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 17
914 to 1,523 m: 26
under 914 m: 54 (2007)
Airports— with unpaved runways:
total: 302
914 to 1,523 m: 34
under 914 m: 268 (2007)
Heliports: 1 (2007)
Pipelines: extra heavy crude oil 578 km;
gas 71 km; oil 1,389 km; refined products
1,185 km (2007)
Railways:
total: 966 km
narrow gauge: 966 km 1.067-m gauge
(2006)
Roadways:
total: 43,197 km
paved: 6,467 km
unpaved: 36,730 km (2004)
Waterways: 1,500 km (most inacces¬
sible) (2006)
Merchant marine:
total: 33 ships (1000 GRT or over)
190,931 GRT/306,280 DWT
by type: chemical tanker 1, liquefied gas
1, passenger 8, petroleum tanker 22, spe¬
cialized tanker 1
foreign''owned: 2 (Philippines 1, US 1)
registered in other countries: 3 (China 1,
Panama 2) (2007)
Ports and terminals: Esmeraldas,
Guayaquil, Manta, Puerto Bolivar
198','f68d01c3f1ada1b1491d3a323dbbaede560c660fccc9fe18ed8d7fc7c1711b88','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7965a264ad281680540b8426358f550cde7e88896003f744b33b3cb9236bd99',2009,'EG','Egypt','transportation',438,'_
Airports: 88 (2007)
Airports— with paved runways: total 11
over 3,047 m: 15
2,438 to 3,047 m: 36
1 ,524 to 2,437 m: 16
under 914 m: 5 (2007)
Airports— with unpaved runways:
total: 16
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 7 (2007)
Heliports: 3 (2007)
Pipelines: condensate 483 km; conden¬
sate/gas 74 km; gas 6,466 km; liquid
petroleum gas 957 km; oil 5,518 km;
oil/gas/water 37 km; refined products 895
km (2007)
Railways: total 5,063 km
standard gauge: 5,063 km 1.435-m gauge
(62 km electrified) (2006)
Roadways: total: 92,370 km
paved: 74,820 km
unpaved: 17,550 km (2004)
Waterways: 3,500 km
note: includes Nile River, Lake Nasser,
Alexandria-Cairo Waterway, and
numerous smaller canals in delta; Suez
Canal (193.5 km including approaches)
navigable by oceangoing vessels drawing
up to 17.68 m (2006)
Merchant marine:
total: 77 ships (1000 GRT or over)
1,032,116 GRT/1,553,065 DWT
by type: bulk carrier 13, cargo 33, con¬
tainer 2, passenger/cargo 5, petroleum
tanker 14, roll on/roll off 10
foreign'' owned: 10 (Denmark 1, Greece 8,
Lebanon 1)
registered in other countries: 55 (Bolivia 1,
Cambodia 14, Georgia 14, Honduras 4,
North Korea 1, Panama 13, Sao Tome
and Principe 1, Saudi Arabia 1, St Kitts
and Nevis 2, St Vincent and The
Grenadines 4) (2007)
Ports and terminals: Ayn Sukhnah,
Alexandria, Damietta, El Dekheila, Sidi
Kurayr, Suez
Military branches: Army, Navy, Air
Force, Air Defense Command
Military service age and obligation:
18-30 years of age for male conscript
military service; service obligation 12-36
months, followed by a 9-year reserve
obligation (2008)
Manpower available for military
service:
males age 16-49: 21,247,777
females age 16-49: 20,406,408 (2008
est.)
Manpower fit for military service:
males age 16—49: 18,153,158
females age 1 6 — 49: 17,405,837 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 825,300
females age 16-49: 786,590 (2008 est.)
Military expenditures — percent of
GDP: 3.4% (2005 est.)','bb57ff2fd39d1181fbb78f92b82aa2a4a6abd9a741c56e1131460dccb92fad5b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5221fc6e5381b1ced581ea842b8566f59a6e4ef0dd8f112cf38cfb44dfcfd984',2009,'SV','El Salvador','transportation',442,'Airports: 65 (2007)
Airports— with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 61
1,524 to 2,437 m: 1
914 to 1 ,523 m: 12
under 914 m: 48 (2007)
Heliports: 1 (2007)
Railways:
total: 562 km
narrow gauge: 562 km 0.914-m gauge
note: railways not in operation since
2005 because of disuse and high costs
that led to a lack of maintenance (2007)
Roadways:
total: 10,886 km
paved: 2,827 km
unpaved: 8,059 km (2000)
Waterways: Rio Lempa partially navi¬
gable for small craft (2007)
Ports and terminals: Acajutla, Puerto
Cutuco
Military branches: Salvadoran Army
(ES), Salvadoran Navy (FNES),
Salvadoran Air Force (Fuerza Aerea
Salvadorena, FAS) (2008)
Military service age and obligation: 18
years of age for selective compulsory mil¬
itary service; 16 years of age for voluntary
service; 12-month service obligation
(2006)
Manpower available for military
service:
males age 16-49: 1,634,816
females age 16—49: 1,775,474 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,168,406
females age 16—49: 1,519,375 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 73,915
females age 16—49: 71,252 (2008 est.)
Military expenditures— percent of
GDP: 5% (2006)','b87e33e461181e518d68e774c39282e2c6d4dbb58bcc0336e44f8cf1c3bcf5bb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('687e22a274f1be3b4e043eeddc181f4a8ccea395720ec7842c69bc055e0fb690',2009,'ER','Eritrea','transportation',456,'Airports: 18 (2007)
Airports— with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2007)
Airports— with unpaved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 2 (2007)
Heliports: 1 (2007)
Railways:
total: 306 km
narrow gauge: 306 km 0.950-m gauge
(2006)
Roadways:
total: 4,010 km
paved: 874 km
unpaved: 3,136 km (2000)
Merchant marine:
total: 5 ships (1000 GRT or over) 12,529
GRT/ 15,023 DWT
by type: cargo 2, liquefied gas 1, petro¬
leum tanker 1, roll on/roll off 1 (2007)
Ports and terminals: Assab, Massawa
Military branches: Eritrean Armed
Forces: Ground Forces, Navy, Air Force
(2008)
Military service age and obligation:
18-40 years of age for male and female
voluntary and compulsory military
service; 16-month conscript service obli¬
gation (2006)
Manpower available for military
service:
males age 16-49: 1,108,836
females age 16-49: 1,096,120 (2008 est.)
Manpower fit for military service:
males age 16-49: 715,531
females age 16-49: 731,511 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 62,504
females age 16-4-9: 62,153 (2008 est.)
Military expenditures— percent of
GDP: 6.3% (2006 est.)','7a45f3b12fc8c786e43cb29e264dd09cc7332efdd43dd347fc9a869fe6fa7c91','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c743a50368521078308a4956616a0dc8f11bf925f6a92dddc23d8c936313f5',2009,'EE','Estonia','transportation',461,'_
Airports: 19 (2007)
Airports — with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 3 (2007)
Airports— with unpaved runways:
total: 7
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 3 (2007)
Heliports: 1 (2007)
Pipelines: gas 859 km (2007)
Railways:
total: 968 km
broad gauge: 968 km 1.520 m/1.524-m
gauge (2006)
Roadways: total: 57,016 km
paved: 12,926 km (includes 99 km of
expressways)
unpaved: 44,090 km (2005)
Waterways: 320 km (2006)
Merchant marine:
total: 33 ships (1000 GRT or over)
393,655 GRT/93,245 DWT
by type: cargo 7, chemical tanker 1, pas¬
senger/cargo 23, petroleum tanker 2
foreign-ovuned: 4 (Denmark 2, Norway 2)
registered in other countries: 67 (Antigua
and Barbuda 15, Belize 1, Cambodia 1,
Cyprus 5, Dominica 8, Latvia 1, Liberia
1, Malta 7, Norway 1, Panama 3,
Slovakia 2, St Kitts and Nevis 1, St
Vincent and The Grenadines 20,
Vanuatu 1) (2007)
Ports and terminals: Kuivastu, Kunda,
Muuga, Tallinn, Virtsu','d1744c6de985143878df0cac221340c846be632731c04c57e4facc4d8782098e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6166dd7d3ce9af85c6d4f08b104a89e808d26725ec097ae9f5a53e751ad73fe6',2009,'ET','Ethiopia','transportation',470,'_
Airports: 84 (2007)
Airports — with paved runways:
total: 15
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 5
1 ,524 to 2,437 m: 11
914 to 1 ,523 m: 29
under 914 m: 21 (2007)
Railways:
total: 699 km (Ethiopian segment of the
Addis Ababa-Djibouti railroad)
narrow gauge: 699 km 1.000''m gauge
note: railway under joint control of
Djibouti and Ethiopia but remains
largely inoperable (2006)
Roadways:
total: 36,469 km
paved: 6,980 km
unpaved: 29,489 km (2004)
Merchant marine:
total: 10 ships (1000 GRT or over)
120,383 GRT/152,418 DWT
by type: cargo 8, roll on/roll off 2 (2007)
Ports and terminals: Ethiopia is land¬
locked and uses ports of Djibouti in
Djibouti and Berbera in Somalia
Military branches: Ethiopian National
Defense Force (ENDF): Ground Forces,
Ethiopian Air Force (ETAF) (2008)
note: Ethiopia is landlocked and has no
navy; following the secession of Eritrea,
Ethiopian naval facilities remained in
Eritrean possession
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; theoretically, no com¬
pulsory military service, but the military
can conduct call-ups when necessary and
compliance is compulsory (2008)
Manpower available for military
service: males age 16-49: 17,666,967
females age 16-49: 17,530,211 (2008
est.)
Manpower fit for military service:
males age 16-49: 10,060,775
females age 16-49: 9,854,710 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 910,602
females age 16-49: 911,081 (2008 est.)
Military expenditures— percent of
GDP: 3% (2006)
Airports: 6 (2007)
Airports— with paved runways: total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways: total: 4
under 914 m: 4 (2007)
Roadways:
total: 440 km
paved: 50 km
unpaved: 390 km (2003)
Ports and terminals: Stanley','4271a76860ff1b3f365de6634f2a48598e3f286332ef2f761259d07f5c6acc2d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a7bea2147a624b4e489832834f87cb8a63cd36dcb0ee26c1543e8404265441b',2009,'FO','Faroe Islands','transportation',476,'Airports: 1 (2007)
Airports— with paved runways: total: 1
914 to 1,523 m: 1 (2007)
Roadways: total: 463 km (2006)
Merchant marine:
total: 16 ships (1000 GRT or over)
92,454 GRT/63,291 DWT
222','b5e2f0fee0969b703be54675c183f613d8fc3a6aa64cfa00cfd6560b4cee8210','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fcfb2bf58123f8e4174be56a51dd910912d763a0af0491287acf8c0b9d29b70',2009,'FJ','Fiji','transportation',477,'by type: cargo 10, container 2, pas-
senger/cargo 3, petroleum tanker 1
foreign'' owned: 8 (Iceland 4, Norway 4)
(2007)
Ports and terminals: Torshavn, Vagur
Airports: 28 (2007)
Airports— with paved runways: total: 3
over 3,047 m: 1
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 25
914 to 1 ,523 m: 7
under 914 m: 18 (2007)
Railways:
total: 597 km
narrow gauge: 597 km 0.600-m gauge
note: belongs to the government-owned
Fiji Sugar Corporation; used to haul sug¬
arcane during harvest season (May to
December) (2006)
Roadways:
total: 3,440 km
paved: 1,692 km
unpaved: 1,748 km (2000)
Waterways: 203 km
note: 122 km navigable by motorized
craft and 200-metric-ton barges (2006)
Merchant marine:
total: 8 ships (1000 GRT or over) 17,376
GRT/8,788 DWT
by type: passenger 3, passenger/cargo 3,
roll on/roll off 2
foreign'' owned: 1 (Australia 1) (2007)
Ports and terminals: Lautoka, Suva','9e3c758ecb26c3c8895da8846d028a05c33978e9a8b3ae9d0dcd37b8b2835b9b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d23c33bf190c6d3a46a56714448af89448f1e5caff62abf0976a65810655ea1c',2009,'FI','Finland','transportation',491,'Airports: 148 (2007)
Airports — with paved runways:
total: 76
over 3,047 m: 2
2,438 to 3,047 m: 27
1 ,524 to 2,437 m: 10
914 to 1,523 m: 22
under 914 m: 15 (2007)
Airports— with unpaved runways:
total: 72
914 to 1,523 m: 4
under 914 m: 68 (2007)
Pipelines: gas 694 km (2007)
Railways:
total: 5,741 km
broad gauge: 5,741 km 1.524-m gauge
(2,619 km electrified) (2006)
Roadways: total: 78,821 km
paved: 50,854 km (includes 700 km of
expressways)
unpaved: 27,967 km (2008)
Waterways: 7,842 km
note: includes Saimaa Canal system of
3,577 km; southern part leased from
Russia (2006)
Merchant marine:
total: 92 ships (1000 GRT or over)
1,362,014 GRT/1,002,280 DWT
by type: bulk carrier 3, cargo 26, chemical
tanker 6, container 3, passenger 5, pas¬
senger/cargo 20, petroleum tanker 4, roll
on/roll off 23, vehicle carrier 2
foreign''owned: 5 (Germany 2, Norway 1,
Sweden 2)
registered in other countries: 43 (Bahamas
8, Germany 4, Gibraltar 3, Marshall
Islands 2, Netherlands 14, Norway 1,
Sweden 10, UK 1) (2007)
Ports and terminals: Hamina, Helsinki,
Kokkola, Kotka, Naantali, Pori, Raahe,
Rauma, Turku
228','20352760e6b590263b688876f8f782815512138664f09489c31679ea7da91a15','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2ca8ffce8d968b38cab723f3e3993dd2dfdad66016e656bbae3fc99cac8b4ef',2009,'PF','French Polynesia','transportation',495,'Airports: 476 (2007)
Airports— with paved runways:
total: 292
over 3,047 m: 14
2,438 to 3,047 m: 27
1,524 to 2,437 m: 97
914 to 1 ,523 m: 80
under 914 m: 74 (2007)
Airports— with unpaved runways:
total: 184
1 ,524 to 2,437 m: 4
914 to 1 ,523 m: 72
under 914 m: 108 (2007)
Heliports: 3 (2007)
Pipelines: gas 14,665 km; oil 3,032 km;
refined products 4,947 km (2007)
Railways:
total: 29,370 km
standard gauge: 29,203 km 1.435-m gauge
(14,778 km electrified)
narrow gauge: 167 km 1.000-m gauge
(2006)
Roadways:
total: 950,985 km
paved: 950,985 km (metropolitan
France; includes 10,490 km of express¬
ways)
note: there are another 5,083 km of road¬
ways in overseas departments (2005)
Waterways: metropolitan France: 8,500
km (1,686 km accessible to craft of 3,000
metric tons)
French Guiana: 3,760 km (460 km navi¬
gable by small oceangoing vessels and
coastal and river steamers, 3,300 km by
native craft) (2006)
Merchant marine:
total: 141 ships (1000 GRT or over)
5,777,107 GRT/7,533,631 DWT
by type: bulk carrier 2, cargo 1, chemical
tanker 31, container 25, liquefied gas 14,
passenger 3, passenger/cargo 32, petro¬
leum tanker 22, roll on/roll off 7, vehicle
carrier 4
foreigri''Owned: 56 (Belgium 6, China 5,
Denmark 3, Germany 1, Italy 2, Japan 5,
Norway 17, NZ 1, Saudi Arabia 1,
Singapore 2, Sweden 10, Switzerland 3)
registered in other countries: 145 (Antigua
and Barbuda 1, Australia 1, Bahamas 43,
Belgium 1, Bermuda 1, Cameroon 1,
Gibraltar 1, Hong Kong 1, Indonesia 1,
Isle of Man 2, Italy 5, South Korea 8,
Liberia 5, Luxembourg 14, Malta 4,
Morocco 13, Netherlands 1, Norway 3,
Panama 15, Singapore 1, St Vincent and
The Grenadines 7, Taiwan 1, UK 9,
Wallis and Futuna 6) (2007)
Ports and terminals: Bordeaux, Calais,
Dunkerque, Le Havre, Marseille, Nantes,
Paris, Rouen, Strasbourg
Airports: 54 (2007)
Airports— with paved runways:
total: 37
over 3,047 m: 2
1 ,524 to 2,437 m: 5
914 to 1 ,523 m: 27
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 17
914 to 1 ,523 m: 9
under 914 m: 8 (2007)
Heliports: 1 (2007)
Roadways:
total: 2,590 km
paved: 1,735 km
unpaved: 855 km (1999)
Merchant marine:
total: 13 ships (1000 GRT or over)
23,684 GRT/17,291 DWT
by type: cargo 4, passenger 2, pas-
senger/cargo 5, refrigerated cargo 1, roll
on/roll off 1
registered in other countries: 2 (Wallis and
Futuna 2) (2007)
Ports and terminals: Papeete','f59abe04637b7835cec2d842cb327fbed32ab1fd9d27221dbb107b85c7cc4581','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4797213abd0639bc1214a4e5dd8e626555de72edb9ed35d3f7194e91875a376',2009,'GA','Gabon','transportation',512,'Airports: 53 (2007)
Airports — with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 7
914 to 1 ,523 m: 1 (2007)
Airports— with unpaved runways:
total: 43
1 ,524 to 2,437 m: 7
914 to 1 ,523 m: 13
under 914 m: 23 (2007)
Pipelines: gas 384 km; oil 1,427 km
(2007)
Railways:
total: 814 km
standard gauge: 814 km 1.435-m gauge
(2006)
Roadways:
total: 9,170 km
paved: 937 km
unpaved: 8,233 km (2004)
Waterways: 1,600 km (310 km on
Ogooue River) (2007)
Merchant marine:
registered in other countries: 2 (Cambodia
1, Panama 1) (2007)
Ports and terminals: Gamba, Libreville,
Lucinda, Port-Gentil','b242a4878f4a9c4b7c116977802b59e5c789599a53db010fb07301e16067305a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fea08fca2061458acde5f572050d56b064fc7d5833f3ff165050f99f2526ead',2009,'GM','Gambia','transportation',517,'Airports: 1 (2007)
Airports — with paved runways:
total: 1
over 3 ,047 m: 1 (2007)
Roadways:
total: 3,742 km
paved: 723 km
unpaved: 3,019 km (2004)
Waterways: 390 km (on River Gambia;
small ocean-going vessels can reach 190
km) (2006)
Merchant marine:
total: 5 ships (1000 GRT or over) 32,064
GRT/9,751 DWT
by type: passenger/cargo 4, petroleum
tanker 1
foreign''owned: 1 (Australia 1) (2007)
Ports and terminals: Banjul','1ab6ed5a2830ab91951be8ac4d6e7dd6d003821a913805f30e4a13c099f92ea1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b3deb4c8a5a711ca4f32ad656fd6dcf26e13e315f0138a00df4e3811da5c6e',2009,'IL','Israel','transportation',526,'Airports: 2 (2007)
Airports — with paved runways:
total: 1
over 3,047 m: 1 (2007)
Airports — with unpaved runways:
total: 1
under 914 m: 1 (2007)
Heliports: 1 (2007)
Roadways:
note: see entry for West Bank
Ports and terminals: Gaza
Airports: 53 (2007)
Airports— with paved runways:
total: 30
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 6 (2007)
Airports— with unpaved runways:
total: 23
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 2
under 914 m: 20 (2007)
Heliports: 3 (2007)
Pipelines: gas 160 km; oil 442 km;
refined products 261 km (2007)
Railways:
total: 853 km
standard gauge: 853 km 1.435-m gauge
(2006)
Roadways:
total: 17,686 km
paved: 17,686 km (includes 146 km of
expressways) (2006)
Merchant marine:
total: 18 ships (1000 GRT or over)
716,382 GRT/845,053 DWT
by type: cargo 2, container 16
registered in other countries: 51 (Bermuda
3, Cyprus 4, Honduras 1, North Korea 1,
Liberia 9, Malta 21, Panama 2, Slovakia
6, St Vincent and The Grenadines 4)
(2007)
Ports and terminals: Ashdod, Elat
(Eilat), Hadera, Haifa','046d76b64472e280bb8259cb8c608d4bcda75f92ead92cf6e2fa5aa72d5d5f90','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6583270f0d0d5ba459ddadf003b5f7b8e96f595a4730e73764cfce744d12799b',2009,'GE','Georgia','transportation',533,'Airports: 23 (2007)
Airports— with paved runways: total: 19
over 3,047 m: 1
2,438 to 3,047 m: 7
1 ,524 to 2,437 m: 5
914 to 1 ,523 m: 4
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 4
1 ,524 to 2,437 m: 1
9 14 to 1 ,523 m: 2
under 914 m: 1 (2007)
Heliports: 3 (2007)
Pipelines: gas 1,591 km; oil 1,253 km
(2007)
249
THE CIA WORLD FACTBOOK
Railways:
total: 1,612 km
broad gauge: 1,575 km 1.520-m gauge
(1,575 electrified)
narrow gauge: 37 km 0.912-m gauge (37
electrified) (2006)
Roadways:
total: 20,247 km
paved: 7,973 km
unpaved: 12,274 km (2004)
Merchant marine:
total: 209 ships (1000 GRT or over)
958,504 GRT/1,408,540 DWT
by type: bulk carrier 25, cargo 159, carrier
2, chemical tanker 1, container 5, lique-
fied gas 2, passenger/cargo 3, petroleum
tanker 4, refrigerated cargo 4, roll on/roll
off 3, vehicle carrier 1
foreigmowned: 180 (Albania 2,
Azerbaijan 1, China 4, Cyprus 1, Egypt
14, Germany 2, Greece 7, Lebanon 3,
Monaco 10, Romania 15, Russia 17,
Slovenia 2, Syria 54, Turkey 23, Ukraine
24, UAE 1) (2007)
Ports and terminals: Bat umi, P’ot’i
Transportation— note: large parts of
transportation network are in poor con-
dition because of lack of maintenance
and repair','dbe7c3681c245f79119f94908af8708f51226b3635495d3d73685e2816a56eff','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48bc410d9ce62d4aa06b7dbcf688ed39f1aada41748e51aad6bf53297f27147b',2009,'GH','Ghana','transportation',541,'Airports: 12 (2007)
Airports— with paved runways:
total: 7
over 3,047 m: 1
1 ,524 to 2,437 m: 4
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 5
914 to 1 ,523 m: 3
under 914 m: 2 (2007)
Pipelines: oil 13 km; refined products
316 km (2007)
Railways:
total: 953 km
narrow gauge: 953 km 1.067-m gauge
(2006)
Roadways:
total: 62,221 km
paved: 9,955 km
unpaved: 52,266 km (2006)
Waterways: 1,293 km
note: 168 km for launches and lighters on
Volta, Ankobra, and Tano rivers; 1,125
km of arterial and feeder waterways on
Lake Volta (2007)
Merchant marine:
total: 3 ships (1000 GRT or over) 5,032
GRT/7,282 DWT
by type: petroleum tanker 1, refrigerated
cargo 2
foreign''Owned: 1 (Brazil 1) (2007)
Ports and terminals: Tema','88b97803c514a54f6a9d3e61bf523c036d0ea2385598001098b98f7dc0572f4a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9f94588e9ebb03b721148e7ef2b6c720f23f2dd2a6dacf6719079e37c5cbc22',2009,'GR','Greece','transportation',547,'• v _ -
Airports: 1 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 29 km
paved: 29 km (2002)
Merchant marine:
total: 216 ships (1000 GRT or over)
1,422,155 GRT/1,866,572 DWT
by type: barge carrier 2, bulk carrier 5,
cargo 117, chemical tanker 39, container
31, passenger 1, petroleum tanker 13, roll
on/roll off 7, specialized tanker 1
foreign'' owned: 201 (Belgium 3, Cyprus 5,
Denmark 9, Finland 3, France 1,
Germany 117, Greece 8, Iceland 1, Italy
1, Netherlands 11, Norway 27, Sweden
10, UAE 2, UK 3)
registered in other countries: 7 (Liberia 7)
(2007)
Ports and terminals: Gibraltar
Military branches: Royal Gibraltar
Regiment
Manpower available for military service:
males age 16-4 9: 6,308 (2008 est.)
Manpower fit for military service:
males age 16—49: 5,244 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 190 (2008 est.)
Military — note: defense is the responsi¬
bility of the UK; the Royal Gibraltar
Regiment replaced the last British reg¬
ular infantry forces in 1992
Airports: 81 (2007)
Airports— with paved runways: total: 66
over 3,047 m: 5
2,438 to 3,047 m: 15
1,524 to 2,437 m: 20
9 14 to 1 ,523 m: 17
under 914 m: 9 (2007)
Airports— with unpaved runways:
total: 15
914 to 1 ,523 m: 3
under 914 m: 12 (2007)
Heliports: 9 (2007)
Pipelines: gas 1,166 km; oil 94 km (2007)
Railways: total: 2,571 km
standard gauge: 1,565 km 1.435-m gauge
(764 km electrified)
narrow gauge: 961 km 1.000-m gauge; 22
km 0.750-m gauge
dual gauge: 23 km combined 1.435 m and
1.000-m gauges (three rail system)
(2006)
Roadways:
total: 1 17,533 km
paved: 107,895 km (includes 880 km of
expressways)
unpaved: 9,638 km (2005)
Waterways: 6 km
note: Corinth Canal (6 km) crosses the
Isthmus of Corinth; shortens sea voyage
by 325 km (2007)
Merchant marine:
total: 824 ships (1000 GRT or over)
33,654,384 GRT/57,898,789 DWT
by type: bulk carrier 246, cargo 66, carrier
1, chemical tanker 52, combination
ore/oil 1, container 43, liquefied gas 6,
passenger 11, passenger/cargo 109, petro¬
leum tanker 269, roll on/roll off 19, spe¬
cialized tanker 1
foreign-owned: 49 (Belgium 16, Cyprus 5,
Italy 1, South Korea 2, UK 15, US 10)
registered in other countries: 2,324
(Antigua and Barbuda 3, Bahamas 214,
Barbados 11, Belgium 4, Bermuda 3,
Cambodia 5, Cayman Islands 23, China
1, Comoros 8, Cyprus 292, Denmark 4,
Dominica 8, Egypt 8, Georgia 7,
Gibraltar 8, Honduras 1, Hong Kong 30,
Isle of Man 48, Italy 13, Jamaica 8,
Lebanon 2, Liberia 311, Maldives 1,
Malta 448, Marshall Islands 226, Norway
6, Panama 505, Philippines 3, Portugal 4,
Russia 1, Sao Tome and Principe 1, Saudi
Arabia 2, Sierra Leone 1, Singapore 14,
Slovakia 4, St Kitts and Nevis 2, St
Vincent and The Grenadines 81, UAE 3,
UK 6, Uruguay 1, Venezuela 3, unknown
8) (2007)
Ports and terminals: Agioitheodoroi,
Aspropyrgos, Pachi, Piraeus, Thessaloniki','51ec9a569b2b8f2662279bc018abc85f5f661ea303b8dc9edf453ade31db474c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc7f95b2ba8c974413835fb95f9c5e059fd76448383e52392e4f57b85594f5bd',2009,'GD','Grenada','transportation',554,'Airports: 14 (2007)
Airports— with paved runways: total: 9
2,4^8 to 3,047 m: 2
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 5 (2007)
Airports— with unpaved runways:
total: 5
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 2
under 914 m: 2 (2007)
Roadways:
note: although there are short roads in
towns, there are no roads between towns;
inter-urban transport takes place either
by sea or air (2005)
Merchant marine:
total: 2 ships (1000 GRT or over) 3,422
GRT/2,340 DWT
by type: cargo 1, passenger 1
registered in other countries: 1 (Denmark
1) (2007)
Ports and terminals: Sisimiut
Military branches: no regular military
forces
Manpower available for military
service:
males age 16-49: 15,221 (2008 est.)
Manpower fit for military service:
males age 16-49: 10,739 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 509 (2008 est.)
Military — note: defense is the responsi¬
bility of Denmark
Disputes — international: managed dis¬
pute between Canada and Denmark over
Hans Island in the Kennedy Channel
between Canada’s Ellesmere Island and
_ _
■r. ,
LU ■
_
s
■ inzy*
Gouyave#
$*M
Catherine
A
GrerwiHe.
NORTH
ATLANTIC
OCEAN
SAINT
0 > «-','a842197034b69ed7bf4a6c0da147bf51e3b72d57431193875c418dc54f6f9b20','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbb16343ed96d4cfa8e99ebef29b6b8bc8efd06666e24695e34030f7af632ad5',2009,'GU','Guam','transportation',559,'Airports: 3 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1
under 914 m: 1 (2007)
Roadways:
total: 1,127 km
paved: 687 km
unpaved: 440 km (2000)
Ports and terminals: Saint George’s
Military branches: no regular military
forces; Royal Grenada Police Force
(includes Coast Guard) (2007)
Manpower available for military
service:
males age 16-49: 27,309 (2008 est.)
Manpower fit for military service:
males age 16-49: 20,249 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 1,034 (2008 est.)
Military expenditures — percent of
GDP: NA','db513875ded8dadfe817a7fb5b4d093879296c0ce1bce7694f05fc76e9e7c4df','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fae06f62994323319189b282d84c1c44117b76f10652a1c4ab6697e07e1b7699',2009,'GT','Guatemala','transportation',566,'Airports: 402 (2007)
Airports— with paved runways:
total: 12
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 390
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 82
under 914 m: 301 (2007)
Pipelines: oil 480 km (2007)
Railways:
total: 886 km
narrow gauge: 886 km 0.9 M-m gauge
(2006)
Roadways:
total: 14,095 km
paved: 4,863 km (includes 75 km of
expressways)
unpaved: 9,232 km (2000)
Waterways: 990 km
note: 260 km navigable year round; addi¬
tional 730 km navigable during high-
water season (2007)
Ports and terminals: Puerto Quetzal,
Santo Tomas de Castilla
Military branches: Army, Navy
(includes Marines), Air Force
Military service age and obligation: all
male citizens between the ages of 18 and
50 are liable for military service; con¬
script service obligation varies from 12 to
24 months; women can serve as officers
(2007)
Manpower available for military
service:
males age 16-49: 2,861,696
females age 16-49: 3,062,967 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,310,272
females age 16-49: 2,622,450 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 161,550
females age 16^9: 159,760 (2008 est.)
Military expenditures— percent of
6DP: 0.4% (2006)','dd0bb5bb197e8f2993c19a8148b71f92b80c99eead682583757407e86e739e06','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcb8ca4a9d5be55625a40ff313d4becaa11fe51693a100e47005c3c0bcb20b2a',2009,'GG','Guernsey','transportation',571,'Airports: 2 (2007)
Airports — with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2007)
Ports and terminals: Saint Peter Port,
Saint Sampson','f6868efff342a7036ed1927014027607986d08d467fb21fc2107e373b20f34fe','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e671c8046f95461c175d5870e49fe1586a94eb12b919a0b073004ddf8ebf1363',2009,'GW','Guinea-Bissau','transportation',574,'Airports: 16 (2007)
Airports— with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2007)
Airports— with unpaved runways:
total: 11
1 ,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 2 (2007)
Railways:
total: 837 km
standard gauge : 175 km 1.435-m gauge
narrow gauge: 662 km 1.000-m gauge
(2006)
Roadways:
total: 44,348 km
paved: 4,342 km
unpaved: 40,006 km (2003)
Waterways: 1,300 km (navigable by
shallow-draft native craft) (2005)
Ports and terminals: Conakry, Kamsar','3e6304aa76f3419492310d64aa5e714a8549ce119d7b1dc89787b8d63cc23fa8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29707ca08277f4153feac7568413c474916557e2dbadb27b61c5857ff6bb6704',2009,'GY','Guyana','transportation',585,'Airports: 93 (2007)
Airports— with paved runways: total: 9
1,524 to 2,437 m: 3
under 914 m: 6 (2007)
Airports— with unpaved runways:
total: 84
1 ,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 69 (2007)
Roadways: total: 7,970 km
paved: 590 km
unpaved: 7,380 km (2000)
Waterways: Berbice, Demerara, and
Essequibo rivers are navigable by ocean¬
going vessels for 150 km, 100 km, and 80
km respectively (2006)
Merchant marine:
total: 7 ships (1000 GRT or over) 12,516
GRT/14,193 DWT
by type: cargo 5, petroleum tanker 1,
refrigerated cargo 1
registered in other countries: 2 (St Vincent
and The Grenadines 2, unknown 1)
(2007)
Ports and terminals: Georgetown
Airports: 390 (2007)
Airports— with paved runways:
total: 128
over 3,047 m: 5
2,438 to 3,047 m: 10
1,524 to 2,437 m: 34
914 to 1 ,523 m: 61
under 914 m: 18 (2007)
Airports— with unpaved runways:
total: 262
2,438 to 3,047 m: 1
1,524 to 2,437 m: 15
914 to 1,523 m: 97
under 914 m: 149 (2007)
Heliports: 2 (2007)
Pipelines: extra heavy crude oil 992 km;
gas 5,400 km; oil 7,607 km; refined prod¬
ucts 1,650 km; unknown (oil/water) 141
km (2007)
Railways:
total: 682 km
standard gauge: 682 km 1.435-m gauge
(2006)
Roadways:
total: 96,155 km
paved: 32,308 km
unpaved: 63,847 km (1999)
Waterways: 7,100 km
note: Orinoco River (400 km) and Lake
de Maracaibo navigable by oceangoing
vessels (2005)
Merchant marine:
total: 59 ships (1000 GRT or over)
808,721 GRT/1,285,783 DWT
by type: bulk carrier 7, cargo 14, chemical
tanker 3, container 1, liquefied gas 6,
passenger/cargo 10, petroleum tanker 17,
refrigerated cargo 1
foreign''Owned: 12 (Denmark 3, Greece 3,
Mexico 3, Panama 1, Russia 1, Spain 1)
registered in other countries: 11 (Bahamas
1, Panama 10) (2007)
Ports and terminals: La Guaira,
Maracaibo, Puerto Cabello, Punta
Cardon
Airports: 44 (2007)
Airports— with paved runways: total: 37
over 3,047 m: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 13
914 to 1,523 m: 10 (2007)
Airports— with unpaved runways:
total: 7
1 ,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 3 (2007)
Heliports: 1 (2007)
Pipelines: condensate/gas 432 km; gas
510 km; oil 49 km; refined products 206
km (2007)
Railways: total: 2,600 km
standard gauge: 178 km 1.435-m gauge
narrow gauge: 2,169 km 1.000-m gauge
dual gauge: 253 km three-rail track com¬
bining 1.435 m and 1.000-m gauges
(2006)
Roadways:
total: 222,179 km
paved: 42,167 km
unpaved: 180,012 km (2004)
Waterways: 17,702 km (5,000 km navi¬
gable by vessels up to 1.8 m draft) (2005)
Merchant marine:
total: 314 ships (1000 GRT or over)
1,739,927 GRT/2, 68 1,003 DWT
by type: barge carrier 1, bulk carrier 26,
cargo 238, chemical tanker 7, container
6, liquefied gas 6, petroleum tanker 26,
refrigerated cargo 2, roll on/roll off 1,
specialized tanker 1
registered in other countries: 33 (Antigua
and Barbuda 1 , Honduras 1 , South Korea
1, Liberia 3, Mongolia 14, Panama 10,
Tuvalu 3, unknown 2) (2007)
Ports and terminals: Da Nang, Hai
Phong, Ho Chi Minh City
Airports: 2 (2007)
Airports— with paved runways:
total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 1,257 km (2004)
Ports and terminals: Charlotte Amalie,
Limetree Bay
Airports: 1 (2007)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (2007)
Ports and terminals: none; two offshore
anchorages for large ships
Transportation— note: there are no com¬
mercial or civilian flights to and from
Wake Island, except in direct support of
island missions; emergency landing is
available','8da840f8ed69a7bcd8aab64a9abcbfeb167339f1f48bcb9f33f8ecd71c6e63e9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1466691246b25476c78314c8f2e35f045d6def435ef4a8c7df22f7a551a0d12f',2009,'HK','Hong Kong','transportation',609,'Airports: 112 (2007)
Airports— with paved runways:
total: 12
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 2
914 to 1 ,523 m: 4
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 100
1,524 to 2,437 m: 2
914 to 1,523 m: 15
under 914 m: 83 (2007)
Railways:
total: 699 km
narrow gauge: 279 km 1.067-m gauge;
420 km 0.914''tn gauge (2006)
Roadways:
total: 13,600 km
paved: 2,775 km
unpaved: 10,825 km (2000)
Waterways: 465 km (most navigable
only by small craft) (2007)
Merchant marine:
total: 126 ships (1000 GRT or over)
352,534 GRT/481,217 DWT
by type: bulk carrier 9, cargo 58, chemical
tanker 5, container 1, liquefied gas 1,
livestock carrier 1, passenger 4, pas¬
senger/cargo 7, petroleum tanker 27,
refrigerated cargo 8, roll on/roll off 4,
specialized tanker 1
foreign''Owned: 40 (Bangladesh 1, Canada
1, China 3, Egypt 4, Greece 1, Hong
Kong 1, Israel 1, Japan 4, South Korea 6,
Lebanon 2, Mexico 1, Singapore 10,
Taiwan 2, Tanzania 1, US 1, Vietnam 1)
(2007)
Ports and terminals: La Ceiba, Puerto
Cortes, San Lorenzo, Tela
Airports: 2 (2007)
Airports— with paved runways:
total: 2
over 3,047 m: 1
I, 524 to 2,437 m: 1 (2007)
Heliports: 5 (2007)
Roadways:
total: 2,009 km
paved: 2,009 km (2007)
Merchant marine:
total: 1,009 ships (1000 GRT or over)
34,556,075 GRT/57,423,309 DWT
by type: barge carrier 2, bulk carrier 499,
cargo 135, chemical tanker 51, combina¬
tion ore/oil 3, container 173, liquefied
gas 24, passenger 6, passenger/cargo 5,
petroleum tanker 91, roll on/roll off 4,
specialized tanker 8, vehicle carrier 8
foreign''ovuned: 617 (Belgium 4, Canada
39, China 309, Denmark 12, France 1,
Germany 10, Greece 30, Indonesia 7,
Japan 78, South Korea 6, Lebanon 1,
Norway 30, Pakistan 1, Philippines 10,
Portugal 1, Singapore 11, Syria 1, Taiwan
II, UAE 1, UK 32, US 22)
registered in other countries: 275 (Bahamas
3, Belize 5, Bermuda 4, Cambodia 11,
China 6, Cyprus 2, Honduras 1, India 1,
Liberia 21, Malaysia 14, Malta 1,
Marshall Islands 4, Mongolia 1, Norway
5, Panama 137, Philippines 2, Seychelles
1, Singapore 37, St Vincent and The
Grenadines 7, Tuvalu 10, UK 2,
unknown 7) (2007)
Ports and terminals: Hong Kong','5bdba043ff6a2c5bcd375ea7f20bba49f55b0fe3a96d532a8561a2ea4aac73f0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deaf185c4a7d66a517d69fb858479d05851cecaf6e67a21fc95706e9499b274b',2009,'IS','Iceland','transportation',625,'Airports: 99 (2007)
Airports— with paved runways:
total: 5
over 3,047 m: 1
1 ,524 to 2,437 m: 3
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 94
1 ,524 to 2,437 m: 3
914 to 1,523 m: 28
under 914 m: 63 (2007)
Roadways:
total: 13,058 km
paved/oiled gravel: 4,397 km (does not
include urban roads)
unpaved: 8,661 km (2007)
Merchant marine:
total: 2 ships (1000 GRT or over) 4,704
GRT/729 DWT
by type: passenger/cargo 2
registered in other countries: 41 (Antigua
and Barbuda 9, Bahamas 1, Belize 1,
Faroe Islands 4, Gibraltar 1, Malta 7,
Norway 3, St Vincent and The
Grenadines 15) (2007)
Ports and terminals: Grundartangi,
Hafnarfjordur, Reykjavik','fcf2acb546c7c082dc47c00e1ee5aeed93b72b9809b9ceadbc7b6d772e9e69ea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0abff69cfe09bb104730bf59657ad06b4d5c1765cc0057457f7bd5370b0fe857',2009,'ID','Indonesia','transportation',635,'Airports: 652 (2007)
Airports — with paved runways: total: 158
over 3,047 m: 4
2,438 to 3,047 m: 15
1 ,524 to 2,437 m: 51
914 to 1,523 m: 49
under 914 m: 39 (2007)
Airports— with unpaved runways:
total: 494
1 ,524 to 2,437 m: 5
914 to 1,523 m: 27
under 914 m: 462 (2007)
Heliports: 17 (2007)
Pipelines: condensate 963 km; conden¬
sate/gas 81 km; gas 9,003 km; oil 7,471
km; oil/gas/water 77 km; refined products
1,365 km (2007)
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge
(125 km electrified); 497 km 0.750-m
gauge (2006)
Roadways:
total: 391,009 km
paved: 216,714 km
unpaved: 174,295 km (2005)
Waterways: 21,579 km (2007)
Merchant marine:
total: 965 ships (1000 GRT or over)
4,409,198 GRT/5,825,591 DWT
by type: bulk carrier 53, cargo 522, chem¬
ical tanker 25, container 66, liquefied gas
7, livestock carrier 1, passenger 44, pas¬
senger/cargo 67, petroleum tanker 155,
refrigerated cargo 2, roll on/roll off 11,
specialized tanker 8, vehicle carrier 4
foreign''Owned: 45 (China 2, France 1,
Japan 5, South Korea 1, Philippines 1,
Singapore 26, Switzerland 3, Taiwan 2,
Thailand 1, UK 3)
registered in other countries : 105 (Bahamas
3, Cambodia 1, Hong Kong 7, Liberia 1,
Panama 37, Singapore 56, unknown 5)
(2007)
Ports and terminals: Banjarmasin,
Belawan, Ciwandan, Kotabaru, Krueg
Geukueh, Palembang, Panjang, Sungai
Pakning, Tanjung Perak, Tanjung Priok
Military branches: Indonesian Armed
Forces (Tentara Nasional Indonesia,
TNI): Army (TNI-Angkatan Darat
(TNI-AD)), Navy (TNI-Angkatan Laut
(TNI-AL); includes marines, naval air
arm), Air Force (TNI-Angkatan Udara
(TNI-AU)), National Air Defense
Command (Kommando Pertahanan
Udara Nasional (Kohanudnas)) (2008)
Military service age and obligation: 18
years of age for selective compulsory and
voluntary military service; 2-year con¬
script service obligation, with reserve
obligation to age 45 (2006)
Manpower available for military
service:
males age 16—49: 63,800,825
females age 16-49: 61,729,717 (2008
est.)
Manpower fit for military service:
males age 16-49: 52,367,788
females age 16-4 9: 52,129,123 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 2,181,303
females age 16-49: 2,110,397 (2008 est.)
Military expenditures — percent of
GDP: 3% (2005 est.)
Disputes — international: Indonesia has
a stated foreign policy objective of estab¬
lishing stable fixed land and maritime
boundaries with all of its neighbors;
Timor-Leste-Indonesia Boundary
Committee has resolved all but a small
portion of the land boundary, but discus¬
sions on maritime boundaries are stale¬
mated over sovereignty of the
uninhabited coral island of Pulau
Batek/Fatu Sinai in the north and align¬
ment with Australian claims in the
south; many refugees from Timor-Leste
who left in 2003 still reside in Indonesia
and refuse repatriation; a 1997 treaty
between Indonesia and Australia settled
some parts of their maritime boundary
but outstanding issues remain; ICJ’s
award of Sipadan and Ligitan islands to
Malaysia in 2002 left the sovereignty of
Unarang rock and the maritime
boundary in the Ambalat oil block in the
Celebes Sea in dispute; the ICJ decision
has prompted Indonesia to assert claims
to and to establish a presence on its
smaller outer islands; Indonesia and
Singapore continue to work on finaliza¬
tion of their 1973 maritime boundary
agreement by defining unresolved areas
north of Indonesia’s Batam Island;
Indonesian secessionists, squatters, and
illegal migrants create repatriation prob¬
lems for Papua New Guinea; piracy
remains a problem in the Malacca Strait;
maritime delimitation talks continue
with Palau; Indonesian groups challenge
Australia’s claim to Ashmore Reef;
Australia has closed parts of the
Ashmore and Cartier Reserve to
Indonesian traditional fishing and placed
restrictions on certain catches
Refugees and internally displaced per¬
sons: IDPs: 200,000-35 0,000 (govern¬
ment offensives against rebels in Aceh;
most IDPs in Aceh, Central Kalimantan,
Central Sulawesi Provinces, and
Maluku) (2007)
Illicit drugs: illicit producer of cannabis
largely for domestic use; producer of
methamphetamine and ecstasy
Airports: 331 (2007)
Airports — with paved runways:
total: 129
over 3,047 m: 40
2,438 to 3,047 m: 28
1,524 to 2,437 m: 24
914 to 1 ,523 m: 32
under 914 m: 5 (2007)
Airports— with unpaved runways:
total: 202
over 3,047 m: 1
1 ,524 to 2,437 m: 10
914 to 1 ,523 m: 145
under 914 m: 46 (2007)
Heliports: 14 (2007)
Pipelines: condensate 7 km; conden¬
sate/gas 397 km; gas 19,161 km; liquid
petroleum gas 570 km; oil 8,438 km;
refined products 7,936 km (2007)
Railways:
total: 8,367 km
broad gauge: 94 km 1.676-m gauge
standard gauge: 8,273 km 1.435-m gauge
(146 km electrified) (2006)
Roadways:
total: 179,388 km
paved: 120,782 km (includes 878 km of
expressways)
unpaved: 58,606 km (2003)
Waterways: 850 km (on Karun River;
additional service on Lake Urmia)
(2006)
Merchant marine:
total: 131 ships (1000 GRT or over)
4,721,202 GRT/8,309,58 0 DWT
by type: bulk carrier 35, cargo 45, chem¬
ical tanker 4, container 9, liquefied gas 1,
passenger/cargo 4, petroleum tanker 29,
roll on/roll off 4
foreign-owned: 1 (UAE 1)
registered in other countries: 33 (Bolivia 1,
Cyprus 2, Malta 24, Panama 4, St Kitts
and Nevis 1, St Vincent and The
Grenadines 1) (2007)
Ports and terminals: Assaluyeh, Bandar
Abbas, Bandar-e-Eman Khomeyni
Military branches: Islamic Republic of
Iran Regular Forces (Artesh): Ground
Forces, Navy, Air Force of the Military of
the Islamic Republic of Iran (Niru-ye
Hava’i-ye Artesh-e Jomhuri-ye Eslami-ye
Iran; includes air defense); Islamic
Revolutionary Guard Corps (Sepah-e
Pasdaran-e Enqelab-e Eslami, IRGC):
Ground Forces, Navy, Air Force, Qods
Force (special operations), and Basij
Force (Popular Mobilization Army); Law
Enforcement Forces (2008)
Military service age and obligation: 19
years of age for compulsory military
service; 16 years of age for volunteers; 17
years of age for Law Enforcement Forces;
15 years of age for Basij Forces (Popular
Mobilization Army); conscript military
service obligation — 18 months; women
exempt from military service (2008)
Manpower available for military
service:
males age 16—49: 20,212,275
females age 16-49: 19,638,751 (2008
est.)
Manpower fit for military service:
males age 16-49: 17,416,126
females age 16-49: 16,928,226 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 766,668
females age 16—49: 727,654 (2008 est.)
Military expenditures— percent of
GDP: 2.5% (2006)
Disputes— international: Iran protests
Afghanistan’s limiting flow of dammed
tributaries to the Helmand River in
periods of drought; Iraq’s lack of a mar¬
itime boundary with Iran prompts juris¬
diction disputes beyond the mouth of the
Shatt al Arab in the Persian Gulf; Iran
and UAE dispute Tunb Islands and Abu
Musa Island, which are occupied by Iran;
Iran stands alone among littoral states in
insisting upon a division of the Caspian
Sea into five equal sectors
Refugees and internally displaced per¬
sons: refugees (country of origin): 914,268
(Afghanistan); 54,024 (Iraq) (2007)
Trafficking in persons: current situation:
Iran is a source, transit, and destination
country for women and girls trafficked
for the purposes of sexual exploitation
and involuntary servitude; according to
foreign observers, women and girls are
trafficked to Pakistan, Turkey, the
Persian Gulf, and Europe for sexual
exploitation, while boys from
Bangladesh, Pakistan, and Afghanistan
are trafficked through Iran en route to
Persian Gulf states where they are ulti¬
mately forced to work as camel jockeys,
beggars, or laborers; Afghan women and
girls are trafficked to the country for
forced marriages and sexual exploitation;
women and children are also trafficked
internally for the purposes of forced mar¬
riage, sexual exploitation, and involun¬
tary servitude
tier rating: Tier 3 — Iran is downgraded to
Tier 3 after persistent, credible reports of
Iranian authorities punishing victims of
trafficking with beatings, imprisonment,
and execution
Illicit drugs: despite substantial interdic¬
tion efforts, Iran remains a key transship¬
ment point for Southwest Asian heroin
to Europe; highest percentage of the pop¬
ulation in the world using opiates; lacks
anti-money-laundering laws
313
t im&mtik
Arhil
MosM
As Suiaymansyaii
S&marrti
BAGHDAD
Ar Autbab
Karbala''
An Naja!
Uwm Qasf
ARABIA
0 S3 100 ter,
Background: Formerly part of the
Ottoman Empire, Iraq was occupied by
Britain during the course of World War I;
in 1920, it was declared a League of
Nations mandate under UK administra-
tion. In stages over the next dozen years,
Iraq attained its independence as a
kingdom in 1932. A “republic” was pro-
claimed in 1958, but in actuality a series
of military strongmen ruled the country
until 2003. The last was SADDAM
Husayn. Territorial disputes with Iran led
to an inconclusive and costly eight-year
war (1980-88). In August 1990, Iraq
seized Kuwait but was expelled by US-
led, UN coalition forces during the Gulf
War of January-February 1991. Following
Kuwait’s liberation, the UN Security
Council (UNSC) required Iraq to scrap
all weapons of mass destruction and
long-range missiles and to allow UN ver¬
ification inspections. Continued Iraqi
noncompliance with UNSC resolutions
over a period of 12 years led to the US-
led invasion of Iraq in March 2003 and
the ouster of the SADDAM Husayn
regime. Coalition forces remain in Iraq
under a UNSC mandate, helping to pro¬
vide security and to support the freely
elected government. The Coalition
Provisional Authority, which tem¬
porarily administered Iraq after the inva¬
sion, transferred full governmental
authority on 28 June 2004 to the Iraqi
Interim Government, which governed
under the Transitional Administrative
Law for Iraq (TAL). Under the TAL,
elections for a 275-member Transitional
National Assembly (TNA) were held in
Iraq on 30 January 2005. Following these
elections, the Iraqi Transitional
Government (ITG) assumed office. The
TNA was charged with drafting Iraq’s
permanent constitution, which was
approved in a 15 October 2005 constitu¬
tional referendum. An election under
the constitution for a 275-member
Council of Representatives (CoR) was
held on 15 December 2005. The CoR
approval in the selection of most of the
cabinet ministers on 20 May 2006
marked the transition from the ITG to
Iraq’s first constitutional government in
nearly a half-century.
Location: Middle East, bordering the
Persian Gulf, between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00
E
Map references: Middle East
Area:
total: 437,072 sq km
land: 432,162 sq km
water: 4,910 sq km
Area — comparative: slightly more than
twice the size of Idaho
Land boundaries:
total: 3,650 km
border countries: Iran 1,458 km, Jordan
181 km, Kuwait 240 km, Saudi Arabia
814 km, Syria 605 km, Turkey 352 km
Coastline: 58 km
Maritime claims:
territorial sea: 12 nm
continental shelf: not specified
Climate: mostly desert; mild to cool win¬
ters with dry, hot, cloudless summers;
northern mountainous regions along
Iranian and Turkish borders experience
cold winters with occasionally heavy
snows that melt in early spring, some¬
times causing extensive flooding in cen¬
tral and southern Iraq
Terrain: mostly broad plains; reedy
marshes along Iranian border in south
with large flooded areas; mountains
along borders with Iran and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed peak; 3,611 m;
note — this peak is neither Gundah Zhur
3,607 m nor Kuh-e Hajji-Ebrahim 3,595
m
Natural resources: petroleum, natural
gas, phosphates, sulfur
Land use: arable land: 13.12%
permanent crops: 0.61%
other: 86.27% (2005)
Irrigated land: 35,250 sq km (2003)
Total renewable water resources: 96.4
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 42.7 cu
km/yr (3%/5%/92%)
per capita: 1,482 cu m/yr (2000)
Natural hazards: dust storms, sand¬
storms, floods
Environment— current issues: govern¬
ment water control projects have drained
most of the inhabited marsh areas east of
An Nasiriyah by drying up or diverting
the feeder streams and rivers; a once siz¬
able population of Marsh Arabs, who
inhabited these areas for thousands of
years, has been displaced; furthermore,
the destruction of the natural habitat
poses serious threats to the area’s wildlife
populations; inadequate supplies of
potable water; development of the Tigris
and Euphrates rivers system contingent
upon agreements with upstream riparian
Turkey; air and water pollution; soil
degradation (salination) and erosion;
desertification
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Law of the Sea
signed, but not ratified: Environmental
Modification
Geography — note: strategic location on
Shatt al Arab waterway and at the head
of the Persian Gulf
Airports: 8 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 5
914 to 1 ,523 m: 3
under 914 m: 2 (2007)
Heliports: 9 (2007)
Roadways:
total: 6,040 km
paved: 2,600 km
unpaved: 3,440 km (2005)
Merchant marine:
by type: passenger/cargo 1 (2007)
Ports and terminals: Dili','20b220ca65a89819874d5a97080293aa61241ecc6e8a3926246c32fb32a925ce','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('867683402a60cc27f760234029f55894a7e6012c87072c1ffd597f1aa0d5672d',2009,'IE','Ireland','transportation',642,'Airports: 110 (2007)
Airports— with paved runways:
total: 76
over 3,047 m: 19
2,438 to 3,047 m: 37
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 9 (2007)
Airports — with unpaved runways:
total: 34
over 3,047 m: 3
2,438 to 3,047 m: 4
1 ,524 to 2,437 m: 4
914 to 1 ,523 m: 13
under 914 m: 10 (2007)
Heliports: 17 (2007)
Pipelines: gas 2,250 km; liquid petro¬
leum gas 918 km; oil 5,509 km; refined
products 1,637 km (2007)
Railways:
total: 2,272 km
standard gauge: 2,272 km 1.435-m gauge
(2006)
Roadways:
total: 45,550 km
paved: 38,399 km
unpaved: 7,151 km (2000)
Waterways: 5,279 km
note: Euphrates River (2,815 km), Tigris
River (1,899 km), and Third River (565
km) are principal waterways (2006)
Merchant marine:
total: 13 ships (1000 GRT or over)
67,796 GRT/101,317 DWT
by type: cargo 11, petroleum tanker 2
(2007)
Ports and terminals: A1 Basrah, Khawr
az Zubayr, Umm Qasr
Military branches: Iraqi Armed Forces:
Iraqi Army (includes Iraqi Special
Operations Force, Iraqi Intervention
Force), Iraqi Navy (former Iraqi Coastal
Defense Force), Iraqi Air Force (former
Iraqi Army Air Corps) (2005)
Military service age and obligation:
1 8-40 years of age for voluntary military
service (2006)
Manpower available for military
service:
males age 16-49: 7,086,200
females age 16-49: 6,808,954 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,019,795
females age 16-49: 5,878,905 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 302,926
females age 16-49: 294,747 (2008 est.)
Military expenditures— percent of
GDP: 8.6% (2006)
Disputes— international: coalition
forces assist Iraqis in monitoring internal
and cross-border security; approximately
two million Iraqis have fled the conflict
in Iraq, with the majority taking refuge
in Syria and Jordan, and lesser numbers
to Egypt, Lebanon, Iran, and Turkey;
Iraq’s lack of a maritime boundary with
Iran prompts jurisdiction disputes
beyond the mouth of the Shatt al Arab
in the Persian Gulf; Turkey has expressed
concern over the autonomous status of
Kurds in Iraq
Refugees and internally displaced per¬
sons: refugees (country of origin):
10,000-15,000 (Palestinian Territories);
11,773 (Iran); 16,832 (Turkey)
IDPs: 2.4 million (ongoing US-led war
and ethno-sectarian violence) (2007)
Airports: 34 (2007)
Airports— with paved runways:
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 5 (2007)
Airports— with unpaved runways:
total: 19
914 to 1 ,523 m: 3
under 914 m: 16 (2007)
Pipelines: gas 1,855 km (2007)
Railways:
total: 3,237 km
broad gauge: 1,872 km 1.600-m gauge (37
km electrified)
narrow gauge: 1,365 km 0.914-m gauge
(operated by the Irish Peat Board to
transport peat to power stations and bri¬
quetting plants) (2006)
Roadways:
total: 96,602 km
paved: 96,602 km (includes 200 km of
expressways) (2003)
Waterways: 956 km (pleasure craft only)
(2007)
Merchant marine:
total: 27 ships (1000 GRT or over)
116,091 GRT/161,808 DWT
by type: cargo 23, chemical tanker 2,
container 1, roll on/roll off 1
foreign'' owned: 3 (Spain 1, US 2)
registered in other countries: 18 (Bahamas
2, Bermuda 1, Bulgaria 1, Cyprus 1,
Germany 1, Isle of Man 1, Netherlands
9, Panama 1, UK 1, unknown 1) (2007)
Ports and terminals: Cork, Dublin,
Shannon Foynes
Military branches: Irish Defense Forces
(Oglaigh na h-Eireann): Army (includes
Naval Service and Air Corps) (2008)
Military service age and obligation:
17-25 years of age for voluntary military
service; 16 years of age can be recruited
for apprentice specialist positions; max¬
imum obligation 12 years; 17-35 years of
age for the Reserve Defense Forces
(2008)
Manpower available for military
service:
males age 16-49: 1,024,635
females age 16-49: 1,024,276 (2008 est.)
Manpower fit for military service:
males age 16-49: 854,982
females age 16—49: 852,592 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 28,610
females age 16—49: 27,095 (2008 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)','ae8a665e716af886be3ba742071e6e16d35278965e4d23fda0e5757ca06b36d3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1a687a39b64c766092e2fa4d299fccf4b8db4a2b97e96f112a80ef3e931611',2009,'IM','Isle of Man','transportation',653,'Airports: 1 (2007)
Airports — with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Railways:
total: 65 km
standard gauge: 7 km 1.067-m gauge (7
km electrified)
narrow gauge: 58 km 0.9 1 4- m gauge (29
km electrified)
note: primarily summer tourist attrac¬
tions (2006)
Roadways:
total: 800 km
Merchant marine:
total: 297 ships (1000 GRT or over)
8,377,775 GRT/13,890,881 DWT
by type: bulk carrier 33, cargo 65, chem¬
ical tanker 54, combination ore/oil 1,
container 17, liquefied gas 34, pas¬
senger/cargo 1, petroleum tanker 74,
refrigerated cargo 5, roll on/roll off 8,
vehicle carrier 5
foreign-owned: 210 (Cyprus 4, Denmark
41, France 2, Germany 61, Greece 48,
Ireland 1, Italy 1, Japan 4, Monaco 3,
Netherlands 1, Norway 33, Singapore 2,
Sweden 3, Turkey 2, US 4) (2007)
Ports and terminals: Douglas, Ramsey','8c4db0393e006438667ba905a3fd30daba64f14cfccbd1831819ecd2c0d5bdbd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('461220027b7702f19a25b4ccba43a76d791b4a6eaa866c6129f4ee142c03ca93',2009,'IT','Italy','transportation',661,'Airports: 132 (2007)
Airports— with paved runways:
total: 101
over 3,047 m: 7
2,438 to 3,047 m: 32
1,524 to 2,437 m: 15
914 to 1,523 m: 34
under 914 m: 13 (2007)
Airports— with unpaved runways:
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 9 14 m: 19 (2007)
Heliports: 5 (2007)
Pipelines: gas 18,863 km; oil 1,258 km
(2007)
Railways:
total: 19,460 km
standard gauge: 18,038 km 1.435-m gauge
(11,354 km electrified)
narrow gauge: 123 km 1.000-m gauge
(123 km electrified); 1,299 km 0.950-m
gauge (161 km electrified) (2006)
Roadways:
total: 484,688 km
paved: 484,688 km (includes 6,529 km of
expressways) (2004)
Waterways: 2,400 km
note: used for commercial traffic; of lim¬
ited overall value compared to road and
rail (2006)
Merchant marine:
total: 604 ships (1000 GRT or over)
12,529,192 GRT/13,150,989 DWT
by type: bulk carrier 53, cargo 46, carrier
1, chemical tanker 141, combination
ore/oil 1, container 32, liquefied gas 33,
livestock carrier 3, passenger 17, pas-
senger/cargo 156, petroleum tanker 40,
refrigerated cargo 4, roll on/roll off 35,
specialized tanker 14, vehicle carrier 28
foreign'' owned: 62 (Denmark 2, France 5,
Germany 1, Greece 13, Sweden 1,
Switzerland 5, Taiwan 11, Turkey 1, UK
7, US 16)
registered in other countries: 169 (Bahamas
1, Belize 4, Bolivia 1, Cayman Islands 10,
Cyprus 5, France 2, Gibraltar 1, Greece
1, Isle of Man 1, Liberia 31, Malta 45,
Marshall Islands 3, Norway 4, Panama
10, Portugal 11, Singapore 4, Slovakia 1,
Spain 1, St Vincent and The Grenadines
19, Sweden 7, Turkey 3, UK 4) (2007)
Ports and terminals: Augusta, Genoa,
Livorno, Ravenna, Sarroch, Taranto,
Trieste, Venice','390a499a162d802b6576578742e8acb2fda374dfbcbddefee117b6dee077d534','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74581ead0b4b997c0ef22a0ed43e3dc68d792dcacbdcf54f3f9b71192fd9a1f5',2009,'JM','Jamaica','transportation',668,'Airports: 34 (2007)
Airports — with paved runways:
total: 1 1
2,438 to 3,047 m: 2
914 to 1 ,523 m: 4
under 914 m: 5 (2007)
Airports — with unpaved runways:
total: 23
914 to 1 ,523 m: 2
under 914 m: 21 (2007)
Roadways:
total: 21,552 km
paved: 15,937 km (includes 33 km of
expressways)
unpaved: 5,615 km (2005)
Merchant marine:
total: 13 ships (1000 GRT or over)
161,700 GRT/24 1,663 DWT
by type: bulk carrier 6, cargo 2, carrier 1,
petroleum tanker 1, roll on/roll off 3
foreign-owned: 12 (Denmark 1, Germany
1, Greece 8, Latvia 2)
registered in other countries: 1 (Panama 1)
(2007)
Ports and terminals: Kingston, Port
Esquivel, Port Kaiser, Port Rhoades,
Rocky Point','55ea7a602745e9594f0ed4c88fd15832acf7bb8849fe98b93946ba8548a44c4d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39337247b420f5d32e95bdadd5b16439abb4f520c6208cd0b339fc9e2eebfd8b',2009,'JP','Japan','transportation',676,'Airports: 1 (2007)
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Ports and terminals: none; offshore
anchorage only
Airports: 176 (2007)
Airports— with paved runways:
total: 145
over 3,047 m: 7
2,438 to 3,047 m: 41
1,524 to 2,437 m: 40
914 to 1,523 m: 28
under 914 m: 29 (2007)
Airports — with unpaved runways:
total: 31
914 to 1,523 m: 4
under 914 m: 21 (2007)
Heliports: 14 (2007)
Pipelines: gas 3,939 km; oil 170 km;
oil/gas/water 104 km (2007)
Railways:
total: 23,474 km
standard gauge: 3,204 km 1.435 -m gauge
(3,204 km electrified)
narrow gauge: 77 km 1.372-m gauge (77
km electrified); 20,182 km 1.067-m
gauge (13,334 km electrified); 11 km
0.762-m gauge (11 km electrified)
(2006)
Roadways:
total: 1.193 million km
paved: 942,000 km (includes 7,383 km of
expressways)
unpaved: 251,000 km (2005)
Waterways: 1,770 km (seagoing vessels
use inland seas) (2007)
Merchant marine:
total: 676 ships (1000 GRT or over)
10,386,894 GRT/1 1,689,142 DWT
by type: bulk carrier 131, cargo 29, carrier
3, chemical tanker 23, container 10, liq¬
uefied gas 58, passenger 14, pas¬
senger/cargo 142, petroleum tanker 157,
refrigerated cargo 2, roll on/roll off 52,
vehicle carrier 55
registered in other countries: 2,692
(Bahamas 62, Belize 2, Bermuda 1,
Burma 3, Cambodia 3, Cayman Islands
6, China 2, Cyprus 19, France 5,
Honduras 4, Hong Kong 78, Indonesia 5,
Isle of Man 4, South Korea 1, Liberia
111, Malaysia 4, Malta 3, Marshall
Islands 5, Mongolia 1, Norway 1,
Panama 2,151, Philippines 69, Portugal
10, Singapore 108, Sweden 1, Thailand
4, UK 1, Vanuatu 28, unknown 2)
(2007)
Ports and terminals: Chiba, Kawasaki,
Kobe, Mizushima, Moji, Nagoya, Osaka,
Tokyo, Tomakomai, Yohohama','71c6dd77995157ab7162b85033fe7dcd2cae6d795488dacc481ef3238f1e5b4f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('176faf987c118de277adcf462b9ef26ddb6f13736e2270bf01c9f2fa3f09b063',2009,'JE','Jersey','transportation',685,'Airports: 1 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 577 km (2002)
Ports and terminals: Gorey, Saint
Aubin, Saint Helier','c9005d9ab02f238db9c55a016b3779a5f030e62a2d494edde814e11fe25af59c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76360e20ea67645184090dc7dd2d77df6a0781926a0056a495b84c86836b071a',2009,'JO','Jordan','transportation',692,'Airports: 17 (2007)
Airports— with paved runways:
total: 15
over 3,047 m: 7
2,438 to 3,047 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 2
under 914 m: 2 (2007)
Heliports: 1 (2007)
Pipelines: gas 426 km; oil 49 km (2007)
Railways:
total: 505 km
narrow gauge: 505 km 1.050-m gauge
(2006)
Roadways:
total: 7,601 km
paved: 7,601 km (2005)
Merchant marine:
total: 30 ships (1000 GRT or over)
410,472 GRT/564,643 DWT
by type: bulk carrier 2, cargo 11, con¬
tainer 3, passenger/cargo 8, petroleum
tanker 2, roll on/roll off 4
foreign'' owned: 15 (UAE 15)
registered in other countries: 15 (Bahamas
2, Panama 11, Syria 2) (2007)
Ports and terminals: A1 Aqabah','e6aa722e00eee8b241600d759895f17ba5b8f5f013bb7fcd534d2f2407af00fe','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4b2e383acd4b1f691e6794a1ad7fad02d71e287b405914c30ac14d6efd0e6f3',2009,'KE','Kenya','transportation',700,'Airports: 97 (2007)
Airports— with paved runways:
total: 65
over 3,047 m: 9
2,438 to 3,047 m: 27
1 ,524 to 2,437 m: 17
914 to 1 ,523 m: 4
under 914 m: 8 (2007)
Airports — with unpaved runways:
total: 32
over 3,047 m: 4
2,438 to 3,047 m: 6
I , 524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 12 (2007)
Heliports: 5 (2007)
Pipelines: condensate 658 km; gas
II, 082 km; oil 10,376 km; refined prod¬
ucts 1,095 km (2007)
Railways: total: 13,700 km
broad gauge: 13,700 km 1.520-m gauge
(3,700 km electrified) (2006)
Roadways:
total: 90,018 km
paved: 84,104 km
unpaved: 5,914 km (2004)
Waterways: 4,000 km (on the Ertis
((Irtysh)) River (80%) and Syr Darya
((Syrdariya)) River) (2006)
Merchant marine:
total: 5 ships (1000 GRT or over) 30,01 1
GRT/49,223 DWT
by type: petroleum tanker 4, refrigerated
cargo 1 (2007)
Ports and terminals: Aqtau (Shev¬
chenko), Atyrau (Gur’yev), Oskemen
(Ust-Kamenogorsk), Pavlodar, Semey
(Semipalatinsk)
Airports: 225 (2007)
Airports— with paved runways: total: 15
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1 ,523 m: 5
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 210
1,524 to 2,437 m: 12
914 to 1,523 m: 113
under 914 m: 85 (2007)
Pipelines: refined products 900 km
(2007)
Railways:
total: 2,778 km
narrow gauge: 2,778 km 1.000-m gauge
(2006)
Roadways:
total: 63,265 km (interurban roads)
paved: 8,933 km
unpaved: 54,332 km
note: there also are 100,000 km of rural
roads and 14,500 km of urban roads for a
national total of 177,765 km (2004)
Waterways: part of Lake Victoria system
is within boundaries of Kenya (2006)
Merchant marine:
total: 1 ship (1000 GRT or over) 3,737
GRT/5,558 DWT
by type: petroleum tanker 1
registered in other countries: 5 (Bahamas 1,
Comoros 1, St Vincent and The
Grenadines 2, Tuvalu 1, unknown 1)
(2007)
Ports and terminals: Mombasa','e39029cc701e40175362ac36b8a11c63783df61e99d2d928190fef3c45b534b3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22966255163657803c5f005afa95cf027e5b2fff7c4188633ac1f58a78ee4fbd',2009,'KI','Kiribati','transportation',709,'Airports: 19 (2007)
Airports— with paved runways:
total: 4
1,524 to 2,437 m: 4 (2007)
Airports— with unpaved runways:
total: 15
914 to 1 ,523 m: 1 1
under 914 m: 4 (2007)
Roadways:
total: 670 km (2000)
Waterways: 5 km (small network of
canals in Line Islands) (2007)
Merchant marine:
total: 7 ships (1000 GRT or over) 28,435
GRT/42,682 DWT
by type: bulk carrier 1, cargo 3, pas-
senger/cargo 1, refrigerated cargo 2
foreign^ owned: 3 (Malaysia 1, Singapore
1, Turkey 1) (2007)
Ports and terminals: Betio
Military branches: no regular military
forces (constitutionally prohibited);
Police Force (2008)
Manpower available for military
service:
males age 16-49: 26,377 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,577 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 1,247 (2008 est.)
Military expenditures— percent of
GDP: NA
Military — note: Kiribati does not have
military forces; defense assistance is pro¬
vided by Australia and NZ
Airports: 77 (2007)
Airports — with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 22
1,524 to 2,437 m: 8
914 to 1,523 m: 1
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 41
2,438 to 3,047 m: 2
1,524 to 2,437 m: 19
914 to 1,523 m: 13
under 914 m: 7 (2007)
Heliports: 23 (2007)
Pipelines: oil 154 km (2007)
Railways:
total: 5,235 km
standard gauge: 5,235 km 1.435-m gauge
(3,500 km electrified) (2006)
Roadways:
total: 25,554 km
paved: 724 km
unpaved: 24,830 km (2006)
Waterways: 2,250 km (most navigable
only by small craft) (2007)
Merchant marine:
total: 171 ships (1000 GRT or over)
854,268 GRT/1,225,453 DWT
by type: bulk carrier 12, cargo 131, chem¬
ical tanker 1, container 1, livestock car¬
rier 1, passenger/cargo 4, petroleum
tanker 14, refrigerated cargo 4, roll
on/roll off 3
foreign'' owned: 29 (Egypt 1, India 1, Israel
1, Lebanon 3, Lithuania 1, Pakistan 1,
Romania 6, Russia 1, Syria 7, Turkey 1,
UAE 4, Yemen 2)
registered in other countries: (unknown 1)
(2007)
Ports and terminals: Ch’ongjin, Haeju,
Hungnam (Flamhung), Kimch’aek,
Kosong, Najin, Namp’o, Sinuiju,
Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Military branches: North Korean
People’s Army: Ground Forces, Navy,
Air Force; civil security forces (2005)
Military service age and obligation: 17
years of age (2004)
Manpower available for military
service: males age 16-49: 6,225,747
females age 16-A9: 6,188,270 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,141,240
females age 16-49: 5,139,447 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 199,628
females age 16—49: 192,388 (2008 est.)
Military expenditures— percent of
GDP: NA
A A . '' ■ A.. . - A
Airports: 105 (2007)
Airports— with paved runways:
total: 68
over 3,047 m: 3
2,438 to 3,047 m: 21
1,524 to 2,437 m: 14
914 to 1,523 m: 11
under 914 m: 19 (2007)
Airports— with unpaved runways:
total: 37
914 to 1,523 m: 3
under 914 m: 34 (2007)
Heliports: 536 (2007)
Pipelines: gas 1,482 km; refined prod¬
ucts 827 km (2007)
Railways:
total: 3,472 km
standard gauge: 3,472 km 1.435-m gauge
(1,342 km electrified) (2006)
Roadways:
total: 102,293 km
paved: 78,581 km (includes 3,060 km of
expressways)
unpaved: 23,712 km (2005)
Waterways: 1,608 km (most navigable
only by small craft) (2007)
Merchant marine:
total: 738 ships (1000 GRT or over)
10,636,466 GRT/1 7,37 1,943 DWT
by type: bulk carrier 187, cargo 202, car¬
rier 1, chemical tanker 119, container
81, liquefied gas 26, passenger 5, pas¬
senger/cargo 21, petroleum tanker 57,
refrigerated cargo 19, roll on/roll off 8,
specialized tanker 4, vehicle carrier 8
foreign''owned: 22 (China 2, France 8,
Japan 1, Sweden 2, UK 1, US 7, Vietnam
1)
registered in other countries: 386 (Belize 4,
Cambodia 29, China 1, Cyprus 2, Greece
2, Honduras 6, Hong Kong 6, Indonesia
1, Liberia 4, Malta 3, Marshall Islands 3,
Netherlands 1, Panama 316, Russia 1,
Singapore 7, unknown 4) (2007)
Ports and terminals: Inch on, P’ohang,
Pusan, Ulsan
Military branches: Republic of Korea
Army, Navy (includes Marine Corps),
Air Force (2008)
Military service age and obligation:
20-30 years of age for compulsory mili¬
tary service; conscript service obliga¬
tion — 24-28 months, depending on the
357
THE CIA WORLD FACTBOOK
military branch involved (to be reduced
to 18 months beginning 2016); 18 years
of age for voluntary military service;
women, in service since 1950, admitted
to 7 service branches, including infantry,
but excluded from artillery, armor, anti-
air, and chaplaincy corps; some 4,000
women serve as commissioned and non¬
commissioned officers, approx. 2.3% of
all officers (2007)
Manpower available for military
service:
males age 16-49: 13,691,809
females age 16-49: 13,029,859 (2008
est.)
Manpower fit for military service:
males age 16-49: 11,282,699
females age 16-49: 10,683,668 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 382,305
females age 16-49: 336,998 (2008 est.)
Military expenditures— percent of
GDP: 2.7% (2006)
- 0
Airports: 10 (2008)
Airports— with paved runways:
total: 6
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 9 14 m: 4 (2008)
Airports— with unpaved runways:
total: 4
under 9 14 m: 4 (2008)
Heliports: 2 (2008)
Railways:
total: 430 km (2005)
Roadways:
total: 1,924 km
paved: 1,666 km
unpaved: 258 km (2006)','06bee47360fa779932ad70ff9be92065f4baceea67d1d2f80ff8e9d7b6ef55f2','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e99ff636fcb313e1219a0cd0a6daaf174424c774a71b8371a3089402e5f5a493',2009,'KG','Kyrgyzstan','transportation',715,'Airports: 7 (2007)
Airports— with paved runways:
total: 4
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 3
1 ,524 to 2,437 m: 1
under 914 m: 2 (2007)
Heliports: 4 (2007)
Pipelines: gas 269 km; oil 540 km;
refined products 57 km (2007)
Roadways:
total: 5,749 km
paved: 4,887 km
unpaved: 862 km (2004)
Merchant marine:
total: 38 ships (1000 GRT or over)
2,195,831 GRT/3,566,308 DWT
by type: bulk carrier 2, cargo 1, container
6, liquefied gas 5, livestock carrier 3,
petroleum tanker 2 1
registered in other countries: 28 (Bahrain 3,
Comoros 1, Liberia 1, Libya 1, Panama 1,
Qatar 7, Saudi Arabia 6, UAE 8) (2007)
Ports and terminals: Ash Shu’aybah,
Ash Shuwaykh, Az Zawr (Mina’ Sa’ud),
Mina’ ‘Abd Allah, Mina’ al Ahmadi
Airports: 30 (2007)
Airports— with paved runways: total 18
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 11
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 12
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 10 (2007)
Pipelines: gas 254 km; oil 16 km (2007)
Railways:
total: 470 km
broad gauge: 470 km 1.520-m gauge
(2006)
Roadways:
total: 18,500 km
paved: 16,854 km
unpaved: 1,646 km (2000)
Waterways: 600 km (2007)
Ports and terminals: Balykchy (Ysyk-
Kol or Rybach’ye)','5762fa353ceb9bb082ec8b8332289c95ccc68ca10c9db69f8454965e0468ecc4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cbb409de98dada93dcfd4b62c2bf9a6644cef703526d7c8d5fc1a1bcb2405cc',2009,'SE','Sweden','transportation',730,'Cyprus 1, Dominica 2, Jamaica 2, Liberia
15, Malta 36, Marshall Islands 10,
Panama 5, Russia 2, St Kitts and Nevis 4,
St Vincent and The Grenadines 20)
(2007)
Ports and terminals: Riga, Ventspils
Military branches: Latvian Republic
Defense Force: Ground Forces, Navy
(Latvijas Juras Speki; includes Coast
Guard (Latvijas Kara Flotes)), Air Force
(Latvijas Gaisa Spelki), Border Guard,
Latvian Home Guard (Latvijas
Zemessardze) (2008)
Military service age and obligation: 18
years of age for voluntary military
service; conscription abolished January
2007; under current law, every citizen is
entitled to serve in the armed forces for
life (2006)
Manpower available for military
service:
males age i 6 — 49: 568,683
females age 16-49: 565,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 412,849
females age 16-49: 468,827 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 14,506
females age 16-49: 13,982 (2008 est.)
Military expenditures — percent of
GDP: 1.2% (2005 est.)
Airports: 250 (2007)
Airports— with paved runways:
total: 152
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 75
914 to 1,523 m: 24
under 914 m: 38 (2007)
Airports— with unpaved runways:
total: 98
914 to 1 ,523 m: 6
under 914 m: 92 (2007)
Heliports: 2 (2007)
Pipelines: gas 798 km (2007)
Railways:
total: 1 1,528 km
standard gauge: 11,528 km 1.435-m gauge
(7,527 km electrified) (2006)
Roadways:
total: 424,947 km
paved: 129,651 km (includes 1,591 km of
expressways)
unpaved: 295,296 km (2004)
Waterways: 2,052 km (2005)
Merchant marine:
total: 194 ships (1000 GRT or over)
3,883,695 GRT/2,451,123 DWT
by type: bulk carrier 7, cargo 23, carrier 1,
chemical tanker 49, passenger 2, pas¬
senger/cargo 37, petroleum tanker 15,
roll on/roll off 35, specialized tanker 3,
vehicle carrier 22
foreign''owned: 34 (Denmark 4, Finland
10, Germany 4, Italy 7, Japan 1, Norway
5, UK 2, US 1)
registered in other countries: 198 (Antigua
and Barbuda 1, Bahamas 5, Barbados 5,
Bermuda 15, Cayman Islands 1, Cook
Islands 9, Cyprus 2, Denmark 4, Finland
2, France 10, Gibraltar 10, Isle of Man 3,
Italy 1, South Korea 2, Liberia 11, Malta
1, Marshall Islands 1, Netherlands 27,
Netherlands Antilles 3, Norway 31,
Panama 9, Portugal 2, Singapore 17, St
Vincent and The Grenadines 2, UK 19,
US 5) (2007)
Ports and terminals: Brofjorden,
Goteborg, fdelsingborg, Lulea, Malmo,
Stenungsund, Stockholm, Trelleborg,
Visby
Military branches: Swedish Armed
Forces (Forsvarsmakten): Army
(Armen), Royal Swedish Navy
(Marinen), Swedish Air Force (Svenska
Flygvapnet) (2007)
Military service age and obligation: 19
years of age for compulsory military
service; conscript service obligation:
7-15 months (Navy), 8-12 months (Air
Force); after completing initial service,
soldiers have a reserve commitment until
age 47 (2006)
Manpower available for military
service:
males age 16-49: 2,052,890
females age 16-49: 1,980,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,699,115
females age 16-49: 1,637,868 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 64,605
females age 16-49: 61,110 (2008 est.)
Military expenditures — percent of
GDP: 1.5% (2005 est.)','12eac130e90f190627989afbd43011903eb478ab5dda49657304f70db1e11a27','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a45dea8145ce841a0d513ae37b75d7ebfa3f7347ea8c311ef6288249cb434b6a',2009,'LB','Lebanon','transportation',734,'Airports: 7 (2007)
Airports— with paved runways: total. 5
375
THE CIA WORLD FACTBOOK
over 3,047 m: 1
2,438 to 3,047 m: 2
914 to 1,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 2
9 14 to 1,523 m: 2 (2007)
Pipelines: gas 43 km (2007)
Railways:
total: 401 km
standard gauge: 319 km 1.435 m
narrow gauge: 82 km 1.050 m
note: rail system became unusable
because of damage done during fighting
in the 1980s and in 2006 (2006)
Roadways:
total: 6,970 km (includes 170 km of
expressways) (2005)
Merchant marine:
total: 35 ships (1000 GRT or over)
132,871 GRT/140,011 DWT
by type: bulk carrier 3, cargo 14, livestock
carrier 12, passenger/cargo 1, refrigerated
cargo 1, roll on/roll off 2, vehicle carrier
2
foreign-owned: 3 (Greece 2, Syria 1)
registered in other countries: 55 (Antigua
and Barbuda 1, Barbados 1, Cambodia 7,
Comoros 5, Cyprus 1, Dominica 1, Egypt
1, Georgia 3, Honduras 2, Hong Kong 1,
North Korea 3, Liberia 2, Malta 12,
Mongolia 1, Panama 3, St Vincent and
The Grenadines 7, Syria 4, unknown 2)
(2007)
Ports and terminals: Beirut, Tripoli
ft: Ti''.'', - ''■','51eeea48b22cd288b2c1e3c07f0f2db8bc98c97a513f12094ddf69dd28461f89','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dbcdec0688bcc380626447d106bd1f9ad71e7388e6f88500cc4547d89ddc9c9',2009,'ZA','South Africa','transportation',742,'Airports: 28 (2007)
Airports— with paved runways:
total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 25
914 to 1,523 m: 4
under 914 m: 21 (2007)
Roadways:
total: 5,940 km
paved: 1,087 km
unpaved: 4,853 km (1999)
378
Airports: 728 (2007)
Airports— with paved runways:
total: 146
over 3,047 m: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m: 51
914 to 1 ,523 m: 67
under 914 m: 13 (2007)
Airports— with unpaved runways:
total: 582
1 ,524 to 2,437 m: 34
914 to 1 ,523 m: 300
under 914 m: 248 (2007)
Heliports: 1 (2007)
Pipelines: condensate 100 km; gas 1,177
km; oil 992 km; refined products 1,379
km (2007)
Railways:
total: 20,872 km
599
THE CIA WORLD FACTBOOK
narrow gauge: 20,436 km 1.065-m gauge
(8,931 km electrified); 436 km 0.610-m
gauge (2006)
Roadways:
total: 362,099 km
paved: 73,506 km (includes 239 km of
expressways)
unpaved: 288,593 km (2002)
Merchant marine:
total: 2 ships (1000 GRT or over) 28,722
GRT/32,226 DWT
by type: container 1, petroleum tanker 1
foreign-owned: 1 (Denmark 1)
registered in other countries: 7 (Bahamas 1,
Seychelles 1, UK 4, unknown 1) (2007)
Ports and terminals: Cape Town,
Durban, Port Elizabeth, Richards Bay,
Saldanha Bay
Military branches: South African
National Defense Force (SANDF):
South African Army, South African
Navy (SAN), South African Air Force
(SAAF), Joint Operations Command,
Military Intelligence, Military Health
Service (2008)
Military service age and obligation: 18
years of age for voluntary military
service; women have a long history of
military service in noncombat roles
dating back to World War I (2004)
Manpower available for military
service:
males age 16-49: 11,622,507
females age 16-49: 11,501,537 (2008
est.)
Manpower fit for military service:
males age 16-49: 6,042,498
females age 16-49: 5,471,103 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 496,337
females age 16-49: 492,024 (2008 est.)
Military expenditures— percent of
GDP: 1.7% (2006)
Military — note: with the end of
apartheid and the establishment of
majority rule, former military, black
homelands forces, and ex-opposition
forces were integrated into the South
African National Defense Force
(SANDF); as of 2003 the integration
process was considered complete','c5ad1e8436c3968a29323cc2b9888653f2482a1baa7f5fe7ead5fd010fa9ebd4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6aff12995433f11c6b0db74edde4d65833ed42c6cb3848eaedc416bd529d33d',2009,'LY','Libya','transportation',754,'Airports: 141 (2007)
Airports — with paved runways:
total: 60
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 23
914 to 1 ,523 m: 6
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 81
over 3 ,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 41
under 914 m: 18 (2007)
384','fb7a3f6951de4ffd4c7e831012027666538872e7d9f0a1708ff5b180a785522c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b2be627936f8aa89663ae3d2f8394a560172de649dd6c21164bad36b211da36',2009,'LI','Liechtenstein','transportation',755,'Heliports: 2 (2007)
Pipelines: condensate 882 km; gas 3,425
km; oil 6,956 km (2007)
Railways:
0 km
note: Libya has announced plans to build
seven lines totaling 2,757 km of 1.435-m
gauge track (2006)
Roadways:
total: 83,200 km
paved: 47,590 km
unpaved: 35,610 km (1999)
Merchant marine:
total: 17 ships (1000 GRT or over)
67,200 GRT/85,931 DWT
by type: cargo 11, liquefied gas 3, petro-
leum tanker 2, roll on/roll off 1
foreign''Owned: 3 (Kuwait 1, Norway 1,
Syria 1)
registered in other countries: 4 (Malta 3,
Tunisia 1) (2007)
Ports and terminals: As Sidrah, Az
Zuwaytinah, Marsa al Burayqah, Ra’s
Lanuf, Tripoli, Zawiyah
Military branches: Armed Peoples on
Duty (APOD, Army), Libyan Arab
Navy, Libyan Arab Air Force (AL
Quwwat aLJawwiya abjamahiriya al-
Arabia aLLibyya, LAAF) (2008)
Military service age and obligation: 17
years of age (2004)
Manpower available for military
service: males age 16-49: 1,682,183
females age 16-49: 1,611,001 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,439,941
females age i 6 — 49: 1,381,914 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 61,305
females age 16-49: 58,788 (2008 est.)
Military expenditures— percent of
GDP: 3.9% (2005 est.)','ebef9354d95f090724c827cfbd0044b214aa15687aea06cb12556938205614a4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07cc8be6e5310c305d5b62c0866d8c1df1139cd0f52b1ef7b35a32b8df75522c',2009,'LT','Lithuania','transportation',762,'Pipelines: gas 20 km (2007)
Railways:
9 km 1.435-m gauge (electrified)
note: belongs to the Austrian Railway
System connecting Austria and
Switzerland (2006)
Roadways:
total: 380 km
paved: 380 km (2006)
Waterways: 28 km (2006)
Military branches: no regular military
forces (constitutionally prohibited);
Principality of Fiechtenstein National
Police (Landespolizei, FP) (2008)
Manpower available for military
service:
males age 16-49: 8,102 (2008 est.)
Manpower fit for military service:
males age 16—49: 6,584 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 202 (2008 est.)
Military — note: Fiechtenstein has no
military forces, but is interested in
European security policy and is an active
member of the Organization for Security
and Cooperation in Europe (OSCE)
Airports: 87 (2007)
Airports— with paved runways:
total: 30
over 3,047 m: 3
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 7
914 to 1,523 m: 2
under 914 m: 17 (2007)
Airports— with unpaved runways:
total: 57
over 3,047 m: 1
914 to 1 ,523 m: 3
under 914 m: 53 (2007)
Pipelines: gas 1,695 km; oil 228 km;
refined products 121 km (2007)
Railways:
total: 1,771 km
broad gauge: 1,749 km 1.524-m gauge
(122 km electrified)
standard gauge: 22 km 1.435-m gauge
(2006)
Roadways: total: 79,497 km
paved: 70,549 km (includes 417 km of
expressways)
unpaved: 8,948 km (2005)
Waterways: 425 km (2005)
Merchant marine:
total: 50 ships (1000 GRT or over)
363,795 GRT/366,624 DWT
by type: bulk carrier 4, cargo 22, chemical
tanker 1, container 1, passenger/cargo 5,
petroleum tanker 1, refrigerated cargo 16
foreign -owned: 9 (Denmark 9)
registered in other countries: 20 (Antigua
and Barbuda 6, North Korea 1, Norway
1, Panama 5, St Vincent and The
Grenadines 7, unknown 3) (2007)
Ports and terminals: Klaipeda','cc635cd6442559aac5d5829f3b0a738573cde653adc815fb4eb4dffccd688570','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5c4625bcf028fc8fbbf1f93fbd5c965eb00cbb0ec92a5e7a0d52b5b23cf957',2009,'LU','Luxembourg','transportation',770,'Airports: 2 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (2007)
Heliports: 1 (2007)
Pipelines: gas 155 km (2007)
Railways:
total: 275 km
standard gauge: 275 km 1.435-m gauge
(243 km electrified) (2006)
Roadways:
total: 5,227 km
paved: 5,227 km (includes 147 km of
expressways) (2004)
Waterways: 37 km (on Moselle River)
(2007)
Merchant marine:
total: 45 ships (1000 GRT or over)
682,955 GRT/858,985 DWT
by type: bulk carrier 7, chemical tanker
14, container 7, liquefied gas 2, passenger
3, passenger/cargo 1, petroleum tanker 4,
roll on/roll off 7
foreign- owned: 44 (Belgium 9, France 14,
Germany 10, Netherlands 1, UK 7, US
3) (2007)
Ports and terminals: Mertert
Military branches: Army (2007)
Military service age and obligation:
17-25 years of age for male and female
voluntary military service; soldiers under
18 are not deployed into combat or with
peacekeeping missions; no conscription
(2008)
Manpower available for military
service:
males age 16-49: 116,305
females age 2 6 — 49 : 114,566 (2008 est.)
Manpower fit for military service:
males age 2 6 — 49 : 95,152
females age 2 6 — 49 : 93,792 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 3,066
females age 16-49: 2,909 (2008 est.)
Military expenditures— percent of
GDP: 0.9% (2005 est.)
Airports: 1 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Heliports: 1 (2007)
Roadways:
total: 384 km
paved: 384 km (2006)
Ports and terminals: Macau
Military branches: no regular military
forces
Manpower available for military
service:
males age 16-49: 121,825 (2008 est.)
Manpower fit for military service:
males age 16—49: 100,826 (2008 est.)
Military — note: defense is the responsi¬
bility of China','b86dedfcdd6d8443b8435cced431496cc41a92fa95f93a6c831c03f23f631494','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd9b8f1f3116fe416a221855a44c7de483894a31ff3e90ea76253ed2126adfa1',2009,'MG','Madagascar','transportation',776,'Airports: 17 (2007)
Airports— with paved runways:
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (2007)
Airports— with unpaved runways:
total: 7
914 to 1 ,523 m: 3
under 914 m: 4 (2007)
Pipelines: gas 268 km; oil 120 km
(2007)
Railways:
total: 699 km
standard gauge: 699 km 1.435-m gauge
(223 km electrified) (2006)
Roadways: total: 8,684 km
paved: 5,540 km
unpaved: 3,144 km (1999)
Military branches: Army of the
Republic of Macedonia (ARM): Joint
Operational Command, with subordi¬
nate Air Wing (Makedonsko Voeno
Vozduhoplovstvo, MVV), Special
Operations Regiment (2007)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military
service:
males age 1 6 — 49: 532,856
females age 16-49: 513,684 (2008 est.)
Manpower fit for military service:
males age 16-49: 444,693
females age 16-49: 428,341 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 15,141
females age 16—49: 14,434 (2008 est.)
Military expenditures— percent of
GDP: 6% (2005 est.)
Airports: 104 (2007)
Airports — with paved runways:
total: 27
over 3,047 m: 1
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 6
914 to 1,523 m: 17
under 914 m: 1 (2007)
Airports — with unpaved runways:
total: 77
1,524 to 2,437 m: 2
914 to 1,523 m: 41
under 914 m: 34 (2007)
Railways: total: 854 km
narrow gauge: 854 km 1.000-m gauge
(2006)
Roadways: total: 49,827 km
paved: 5,780 km
unpaved: 44,047 km (1999)
Waterways: 600 km (2006)
Merchant marine:
total: 9 ships (1000 GRT or over) 13,896
GRT/1 8,466 DWT
by type: cargo 5, passenger/cargo 2, petro¬
leum tanker 2 (2007)
Ports and terminals: Antsiranana,
Mahajanga, Toamasina, Toliara','5153f48d4bd4cf758f687f09cdd1d4e45ad4e115943ce84e48fd803c2ccca6b0','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf6bed3d1c2bb43e4a25d3dc10e1fcf5ce3e8affd67b460a30c4b8f95e4c7ea9',2009,'MY','Malaysia','transportation',788,'Airports: 39 (2007)
Airports— with paved runways:
total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 4 (2007)
Airports— with unpaved runways:
total: 33
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 16
under 914 m: 16 (2007)
Railways:
total: 797 km
narrow gauge: 797 km 1.067-m gauge
(2006)
Roadways:
total: 15,451 km
paved: 6,956 km
unpaved: 8,495 km (2003)
Waterways: 700 km (on Lake Nyasa
(Lake Malawi) and Shire River) (2007)
Ports and terminals: Chipoka, Monkey
Bay, Nkhata Bay, Nkhotakota, Chilumba
Airports: 116 (2007)
Airports— with paved runways: total 36
over 3,047 m: 5
2,438 to 3,047 m: 9
1 ,524 to 2,437 m: 8
914 to 1,523 m: 8
under 914 m: 6 (2007)
Airports— with unpaved runways:
total: 80
1 ,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 72 (2007)
Heliports: 2 (2007)
Pipelines: condensate 282 km; gas 5,273
km; oil 1,750 km; oil/gas/water 19 km;
refined products 114 km (2007)
Railways:
total: 1,890 km
standard gauge: 57 km 1.435-m gauge (57
km electrified)
narrow gauge: 1,833 km 1.000-m gauge
(150 km electrified) (2006)
Roadways: total 98,721 km
paved: 80,280 km (includes 1,821 km of
expressways)
unpaved: 18,441 km (2004)
408','a94a15024caf040ea301147301d9a87b62f43dacf0431b9d13cb9dd7d16365d3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('856bb672e06c27476874fc2d5af491a20b3e74cd203d946c8a274e257be98f01',2009,'MV','Maldives','transportation',795,'Waterways: 7,200 km
note: Peninsular Malaysia 3,200 km;
Sabah 1,500 km; Sarawak 2,500 km
(2005)
Merchant marine:
total: 304 ships (1000 GRT or over)
6,154,877 GRT/8,364,578 DWT
by type: bulk carrier 16, cargo 98, chem¬
ical tanker 30, container 47, liquefied gas
30, livestock carrier 1, passenger/cargo 5,
petroleum tanker 68, roll on/roll off 5,
vehicle carrier 4
foreign''oumed: 43 (China 1, Germany 2,
Hong Kong 14, Japan 4, Singapore 22)
registered in other countries: 67 (Bahamas
11, Kiribati 1, Marshall Islands 3,
Mongolia 1, Panama 14, Philippines 2,
Singapore 28, Thailand 3, US 4,
unknown 1) (2007)
Ports and terminals: Bintulu, Johor
Bahru, Kuantan, Labuan, George Town
(Penang), Port Kelang, Tanjung Pelepas
Airports: 5 (2007)
Airports— with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 2
914 to 1,523 m: 2 (2007)
Roadways:
total: 88 km
paved roads: 88 km — 60 km in Male; 14
km on Addu Atolis; 14 km on Laamu
411
THE CIA WORLD FACTBOOK
note: village roads are mainly compacted
coral (2006)
Merchant marine:
total: 22 ships (1000 GRT or over)
85,935 GRT/1 14, 054 DWT
by type: cargo 17, petroleum tanker 3,
refrigerated cargo 2
foreign''owned: 1 (Greece 1)
registered in other countries: 2 (Panama 1,
Tuvalu 1) (2007)
Ports and terminals: Male
Military branches: Maldives National
Defense Force (MNDF): Quick Reaction
Force, Security Protection Group, Coast
Guard (2007)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16—49: 89,505
females age 16—49: 85,745 (2008 est.)
Manpower fit for military service:
males age 16—49: 72,150
females age 16—49: 69,058 (2008 est.)
Military expenditures— percent of
GDP: 5.5% (2005 est.)
Military — note: the Maldives National
Defense Force (MNDF), with its small
size and with little serviceable equip¬
ment, is inadequate to prevent external
aggression and is primarily tasked to rein¬
force the Maldives Police Service (MPS)
and ensure security in the exclusive eco¬
nomic zone (2008)','b255611b21c3b01a0ea9f550c71bd69e3713b8310d42e8b382d97f760f1084e5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f94abded393e361ca58eccb081baa9de7c2bfcac649be2abd7fde93e46770b96',2009,'ML','Mali','transportation',808,'Airports: 29 (2007)
Airports— with paved runways:
total: 8
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4 (2007)
Airports— with unpaved runways:
total: 21
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1 ,523 m: 7
under 914 m: 8 (2007)
Railways:
total: 729 km
narrow gauge: 729 km 1.000-m gauge
(2006)
Roadways:
total: 18,709 km
paved: 3,368 km
unpaved: 15,341 km (2004)
Waterways: 1,800 km (2007)
Ports and terminals: Koulikoro','5d145b67ead106a904ee3dfb546497b432f8d0684d206bb8278740bfc4967081','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4af0161ec61433743fcdcedf75c08a0597cf3359a39f2985065177bae047a800',2009,'MH','Marshall Islands','transportation',814,'■ -
Airports: 1 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Roadways:
total: 2,227 km
paved: 2,014 km
unpaved: 213 km (2004)
Merchant marine:
total: 1,281 ships (1000 GRT or over)
25,213,650 GRT/41, 033,203 DWT
by type: bulk carrier 439, cargo 382,
chemical tanker 125, combination
ore/oil 2, container 65, liquefied gas 15,
livestock carrier 1, passenger 15, pas¬
senger/cargo 14, petroleum tanker 132,
refrigerated cargo 41, roll on/roll off 31,
specialized tanker 2, vehicle carrier 17
foreign''Oivned: 1,197 (Austria 1,
Azerbaijan 3, Bangladesh 3, Belgium 10,
Bulgaria 15, Canada 15, China 13,
Croatia 12, Cyprus 15, Denmark 10,
Estonia 7, France 4, Germany 67, Greece
448, Flong Kong 1, Iceland 7, India 3,
Iran 24, Israel 21, Italy 45, Japan 3,
South Korea 3, Latvia 36, Lebanon 12,
Libya 3, Monaco 1, Netherlands 3,
Norway 71, Pakistan 2, Poland 25,
Portugal 3, Romania 10, Russia 66,
Slovenia 3, Spain 1, Sweden 1,
Switzerland 22, Syria 4, Turkey 143,
Ukraine 28, UAE 10, UK 12, US 11)
registered in other countries: 4 (Panama 2,
Portugal 1, St Vincent and The
Grenadines 1) (2007)
Ports and terminals: Marsaxlokk (Malta
Freeport), Valletta
Airports: 15 (2007)
Airports— with paved runways:
total: 4
1 ,524 to 2,437 m: 3
9 14 to 1,523 m: 1 (2007)
Airports — with unpaved runways:
total: 11
914 to 1 ,523 m: 10
under 914 m: 1 (2007)
Roadways:
total: 64.5 km
paved: 64.5 km
note: paved roads on major islands
(Majuro, Kwajalein), otherwise stone-,
coral-, or laterite-surfaced roads and
tracks (2002)
Merchant marine:
total: 902 ships (1000 GRT or over)
33,260,440 GRT/55,644,008 DWT
by type: barge carrier 2, bulk carrier 215,
cargo 61, carrier 1, chemical tanker 165,
combination ore/oil 6, container 171,
liquefied gas 28, passenger 6, petroleum
tanker 228, refrigerated cargo 2, roll
on/roll off 10, specialized tanker 2,
vehicle carrier 5
foreign-owned: 857 (Australia 1, Belgium
1, Bermuda 5, Canada 4, Chile 4, China
3, Croatia 4, Cyprus 39, Denmark 9,
Finland 2, Germany 214, Greece 226,
Hong Kong 4, Italy 3, Japan 5, South
Korea 3, Latvia 10, Malaysia 3, Monaco
7, Netherlands 5, Norway 62, Romania
1, Russia 4, Saudi Arabia 4, Singapore
12, Slovenia 3, Spain 3, Sweden 1,
Switzerland 14, Turkey 41, UAE 14, UK
17, US 129) (2007)
Ports and terminals: Majuro','ab0b22f85309d0fbb7c9cce25f7c35cb48781deba93c8a145e2603992ca2e2a8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8827f60a9b279af31a9a062497a19c30f800c7e2577645dab9759943742dea72',2009,'MR','Mauritania','transportation',824,'Airports: 25 (2007)
Airports — with paved runways:
total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5 (2007)
Airports — with unpaved runways:
total: 17
1,524 to 2,437 m: 9
914 to 1,523 m: 7
under 914 m: 1 (2007)
Railways:
717 km
standard gauge: 717 km 1.435-m gauge
(2006)
Roadways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1999)
Ports and terminals: Nouadhibou,
Nouakchott','459795b42f23dd9498816dc394d839e39c7bc01367a38a2584e0a764b15a94c7','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('055da8c77c5ff4012c9d086e2499d414ddfdf5217b4ed9249feb96890326807d',2009,'YT','Mayotte','transportation',831,'Airports: 5 (2007)
Airports— with paved runways:
total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (2007)
Airports — with unpaved runways:
total: 3
914 to 1 ,523 m: 2
under 914 m: 1 (2007)
Roadways:
total: 2,020 km
paved: 2,020 km (includes 75 km of
expressways) (2005)
Merchant marine:
total: 5 ships (1000 GRT or over) 19,417
GRT/19,700 DWT
by type: bulk carrier 2, passenger/cargo 2,
refrigerated cargo 1
foreigri''owned: 2 (India 2) (2007)
Ports and terminals: Port Louis
Military branches: no regular military
forces; National Police Force, Special
Mobile Force, National Coast Guard
(2007)
Manpower available for military
service:
males age 16—49: 341,018 (2008 est.)
Military expenditures — percent of
GDP: 0.3% (2006 est.)
Disputes — international: Mauritius
claims the Chagos Archipelago (UK-
administered British Indian Ocean
Territory), and its former inhabitants,
who reside chiefly in Mauritius; claims
French-administered Tromelin Island
Illicit drugs: consumer and transship¬
ment point for heroin from South Asia;
small amounts of cannabis produced and
consumed locally; significant offshore
financial industry creates potential for
money laundering, but corruption levels
are relatively low and the government
appears generally to be committed to reg¬
ulating its banking industry','99335341024dae128149492cc85b62832ecaaad7d4723eb130455e315a199cc3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af6400f6c41d1093566ac81be1c78d45ec73d458dba1b09baa0f96cd3308977a',2009,'MX','Mexico','transportation',834,'Airports: 1 (2007)
Airports— with paved runways:
total: 1
1 ,524 to 2,437 m: 1 (2007)
Roadways:
total: 100 km
Ports and terminals: Dzaoudzi','c3c9d9241ea035aff371ddac18f4efb2da30807c55defb7eaaaf9f1e210f0afb','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eae828dec5aa45c43204a8458a7f1fa0c9c23a4f85213eabe15d43bb4001f26',2009,'RO','Romania','transportation',845,'Airports: 10 (2007)
Airports — with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 4
1 ,524 to 2,437 m: 2
914 to 1 ,523 m: 1
under 914 m: 1 (2007)
Pipelines: gas 1,980 km (2007)
Railways:
total: 1,138 km
broad gauge: 1,124 km 1.520-m gauge
standard gauge: 14 km 1.435-m gauge
(2006)
Roadways:
total: 12,733 km
paved: 10,976 km
unpaved: 1,757 km (2004)
Waterways: 424 km (on Dniester and
Prut rivers) (2007)
Merchant marine:
total: 8 ships (1000 GRT or over) 15,668
GRT/1 7,585 DWT
by type: cargo 8
foreign-owned: 3 (Ukraine 3) (2007)
Airports: 61 (2007)
Airports— with paved runways:
total: 25
over 3,047 m: 3
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12
914 to 1,523 m: 1 (2007)
Airports — with unpaved runways:
total: 36
1 ,524 to 2,437 m: 2
914 to 1 ,523 m: 12
under 914 m: 22 (2007)
Heliports: 2 (2007)
Pipelines: gas 3,674 km; oil 2,424 km
(2007)
Railways:
total: 1 1,385 km
broad gauge: 60 km 1.524-m gauge
standard gauge: 10,898 km 1.435-m gauge
(3,888 km electrified)
narrow gauge: 427 km 0.760-m gauge
(2006)
Roadways:
total: 198,817 km
paved: 60,043 km (includes 228 km of
expressways)
unpaved: 138,774 km (2004)
536
RUSSIA
Waterways: 1,731 km
note: includes 1,075 km on Danube
River, 524 km on secondary branches,
and 132 km on canals (2006)
Merchant marine:
total: 19 ships (1000 GRT or over)
146,307 GRT/165,548 DWT
by type: cargo 13, passenger 1, pas-
senger/cargo 2, petroleum tanker 2, roll
on/roll off 1
registered in other countries: 50 (Cambodia
1, Georgia 15, North Korea 6, Malta 10,
Marshall Islands 1, Panama 8, Sierra
Leone 2, St Kitts and Nevis 1, St
Vincent and The Grenadines 1, Syria 4,
Tuvalu 1, unknown 4) (2007)
Ports and terminals: Braila, Constanta,
Galati, Tulcea
Airports: 1,260 (2007)
Airports — with paved runways:
total: 601
over 3,047 m: 51
2,438 to 3,047 m: 197
1,524 to 2,437 m: 129
914 to 1,523 m: 102
under 914 m: 122 (2007)
Airports— with unpaved runways:
total: 659
over 3,047 m: 4
2,438 to 3,047 m: 13
1 ,524 to 2,437 m: 69
914 to 1,523 m: 89
under 914 m: 484 (2007)
Heliports: 47 (2007)
Pipelines: condensate 122 km; gas
158,699 km; oil 72,347 km; refined prod¬
ucts 13,658 km (2007)
Railways:
total: 87,157 km
broad gauge: 86,200 km 1.520-m gauge
(40,300 km electrified)
narrow gauge: 957 km 1.067-m gauge (on
Sakhalin Island)
note: an additional 30,000 km of non-
common carrier lines serve industries
(2006)
Roadways:
total: 871,000 km
paved: 738,000 km (includes 29,000 km
of expressways)
unpaved: 133,000 km
note: includes public and departmental
roads (2004)
Waterways: 102,000 km (including
33,000 km with guaranteed depth)
note: 72,000 km system in European
Russia links Baltic Sea, White Sea,
Caspian Sea, Sea of Azov, and Black Sea
(2006)
Merchant marine:
total: 1,130 ships (1000 GRT or over)
4,712,349 GRT/5,747,083 DWT
by type: bulk carrier 28, cargo 718, carrier
2, chemical tanker 27, combination
ore/oil 35, container 10, passenger 15,
passenger/cargo 8, petroleum tanker 215,
refrigerated cargo 51, roll on/roll off 14,
specialized tanker 7
foreign'' owned: 101 (Belgium 6, Cyprus 2,
Germany 2, Greece 1, South Korea 1,
Latvia 2, Switzerland 6, Turkey 70,
Ukraine 10, US 1)
registered in other countries: 469 (Antigua
and Barbuda 5, Bahamas 5, Belize 39,
Bulgaria 1, Cambodia 112, Comoros 9,
Cyprus 50, Dominica 2, Georgia 17,
North Korea 1, Liberia 87, Malta 66,
Marshall Islands 4, Mongolia 17,
Panama 9, Sierra Leone 5, St Kitts and
Nevis 14, St Vincent and The
Grenadines 19, Thailand 1, Tuvalu 4,
Vanuatu 1, Venezuela 1, unknown 21)
(2007)
Ports and terminals: Azov, Kaliningrad,
Kavkaz, Nakhodka, Novorossiysk,
Primorsk, Saint Petersburg, Vostochnyy','be894d3eee39f9b81ab40b9c1dc74da9c0f8b285459ccfc1133a6222ee7a7af4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5471d26ed226bbb44a085b96b221e3af710b8ac83fa889caff00631793b3ee43',2009,'MC','Monaco','transportation',852,'Heliports: 1 (2007)
Roadways:
total: 50 km
paved: 50 km (1999)
Merchant marine:
registered in other countries: 64 (Bahamas
11, Barbados 1, Georgia 10, Isle of Man
3, Liberia 8, Malta 1, Marshall Islands 7,
Norway 5, Panama 11, St Kitts and
Nevis 1, St Vincent and The Grenadines
6, unknown 1) (2007)
Ports and terminals: Monaco','5ac13b98c63639ff474d4026b4eb6a4c3789b3cffa9bcc099e0364abc10dd4a8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55b5171c37c8fb974ced2c0108a6cbca692bc70721bc92b5b8fc960512e89496',2009,'ME','Montenegro','transportation',861,'Airports: 44 (2007)
Airports— with paved runways:
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 10
1,524 to 2,437 m: 2 (2007)
Airports— with unpaved runways:
total: 31
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 23
914 to 1,523 m: 1
under 914 m: 1 (2007)
Heliports: 1 (2007)
Railways:
total: 1,810 km
broad gauge: 1,810 km 1.524-m gauge
(2006)
Roadways:
total: 49,250 km
paved: 1,724 km
unpaved: 47,526 km (2002)
Waterways: 580 km
note: only waterway in operation is Lake
Hovsgol (135 km); Selenge River (270
km) and Orhon River (175 km) are nav¬
igable but carry little traffic; lakes and
rivers freeze in winter, are open from
May to September (2004)
Merchant marine:
total: 73 ships (1000 GRT or over)
448,252 GRT/668,689 DWT
by type: bulk carrier 12, cargo 52, chem¬
ical tanker 1, liquefied gas 1, pas-
senger/cargo 1, petroleum tanker 1, roll
on/roll off 5
foreign''Owned: 62 (Bulgaria 2, China 3,
Hong Kong 1, Japan 1, Lebanon 1,
Malaysia 1, Russia 17, Singapore 12,
Syria 1, Thailand 1, Ukraine 3, UAE 5,
Vietnam 14) (2007)
Airports: 5 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 2
914 to 1 ,523 m: 1
under 914 rn: 1 (2007)
Heliports: 1 (2007)
Railways:
total: 250 km
standard gauge: 250 km 1.43 5 -m gauge
(electrified 169 km) (2006)
Roadways:
total: 7,353 km
paved: 4,274 km
unpaved: 3,079 km (2005)
Merchant marine:
total: 4 ships (1000 GRT or over) 9,458
GRT/10,172 DWT
by type: cargo 4
registered in other countries: 3 (Bahamas 2,
St Vincent and The Grenadines 1)
(2007)
Ports and terminals: Bar','23c4f68f3183ff64a360396b45028870ea8f82552ec3fb57547b759f9a761dfd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05ad1499122c3e8e8450a66d6a1ba04314047e78f8cce82c8e0f97b0403382ac',2009,'MS','Montserrat','transportation',870,'Airports: 2 (2007)
Airports— with paved runways:
total: 2
under 914 m: 2 (2007)
Roadways:
total: 227 km
note: volcanic eruptions that began in
1995 destroyed most of the road system
(2003)
Ports and terminals: Little Bay,
Plymouth
445
THE CIA WORLD FACTBOOK
Military branches: no regular military
forces; Royal Montserrat Police Force
(2008)
Manpower available for military service:
males age 16-49: 2,528 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,097 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 1 6 — 49: 67 (2008 est.)
Military — note: defense is the responsi¬
bility of the UK','edbc2cc1559c970bc076917619b79ee57018e1bff89585e2bb16d53bfcd363c8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a39c29c82c2e91e5b9ad92f7604aa78906f8e2c637855b9d2af827a58e42b641',2009,'MZ','Mozambique','transportation',879,'Airports: 60 (2007)
Airports— with paved runways: total: 27
over 3,047 m: 11
2,438 to 3,047 m: 6
1 ,524 to 2,437 m: 7
914 to 1 ,523 m: 1
under 914 m; 2 (2007)
Airports— with unpaved runways: total: 33
2,438 to 3,047 m: 2
1,524 to 2,437 m: 9
914 to 1 ,523 m: 11
under 914 m: 11 (2007)
Heliports: 1 (2007)
Pipelines: gas 720 km; oil 439 km (2007)
Railways:
total: 1,907 km
standard gauge: 1,907 km 1.435-m gauge
(1,003 km electrified) (2006)
Roadways:
total: 57,493 km
paved: 32,716 km (includes 507 km of
expressways)
unpaved: 24,777 km (2004)
Merchant marine:
total: 35 ships (1000 GRT or over)
344,445 GRT/252,341 DWT
by type: cargo 3, chemical tanker 6, con¬
tainer 8, passenger/cargo 12, petroleum
tanker 1, refrigerated cargo 1, roll on/roll
off 4
foreign-owned: 14 (France 13, Germany
1) (2007)
Ports and terminals: Agadir,
Casablanca, Mohammedia, Safi
_ _
Airports: 147 (2007)
Airports— with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (2007)
Airports — with unpaved runways:
total: 125
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 36
under 914 m: 79 (2007)
Pipelines: gas 964 km; refined products
278 km (2007)
Railways: total: 3,123 km
narrow gauge: 2,983 km 1.067-m gauge;
140 km 0.762-m gauge (2006)
Roadways: total: 30,400 km
paved: 5,685 km
unpaved: 24,715 km (1999)
Waterways: 460 km (Zambezi River
navigable to Tete and along Cahora
Bassa Lake) (2007)
Merchant marine:
total: 2 ships (1000 GRT or over) 2,964
GRT/5,324 DWT
by type: cargo 2
foreign'' owned: 2 (Belgium 2) (2007)
Ports and terminals: Beira, Maputo,
Nacala
Airports: 124 (2007)
Airports— with paved runways:
total: 10
over 3 ,047 m: 2
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 5
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 114
1 ,524 to 2,437 m: 17
914 to 1,523 m: 63
under 914 m: 34 (2007)
Pipelines: gas 287 km; oil 891 km
(2007)
Railways:
total: 3,690 km
narrow gauge: 969 km 1.067-m gauge;
2,721 km 1.000-m gauge (2006)
Roadways:
total: 78,891 km
paved: 6,808 km
unpaved: 72,083 km (2003)
Waterways: Lake Tanganyika, Lake
Victoria, and Lake Nyasa principal
avenues of commerce with neighboring
countries; rivers not navigable (2005)
Merchant marine:
total: 9 ships (1000 GRT or over) 24,801
GRT/3 1,507 DWT
by type: cargo 1, passenger/cargo 4, petro¬
leum tanker 4
registered in other countries: 2 (Honduras
1, St Kitts and Nevis 1) (2007)
Ports and terminals: Dar es Salaam
Military branches: Tanzanian People’s
Defense Force (Jeshi la Wananchi la
Tanzania, JWTZ): Army, Naval Wing
(includes Coast Guard), Air Defense
637
THE CIA WORLD FACTBOOK
Command (includes Air Wing),
National Service (2007)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military
service:
males age 16-49: 9,108,177 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,278,833 (2008 est.)
Military expenditures— percent of
GDP: 0.2% (2005 est.)
Disputes — international: Tanzania still
hosts more than a half-million refugees,
more than any other African country,
mainly from Burundi and the
Democratic Republic of the Congo,
despite the international community’s
efforts at repatriation; disputes with
Malawi over the boundary in Lake Nyasa
(Lake Malawi) and the meandering
Songwe River remain dormant
Refugees and internally displaced per¬
sons: refugees (country of origin): 352,640
(Burundi); 127,973 (Democratic
Republic of the Congo) (2007)
Illicit drugs: growing role in transship¬
ment of Southwest and Southeast Asian
heroin and South American cocaine des¬
tined for South African, European, and
US markets and of South Asian
methaqualone bound for southern
Africa; money laundering remains a
problem','735e20a1b3be2bfbdd8dab9806099b79d4da4109390b71dafcf2015c1cd703f5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a41844967be64a35455531ddf08aed74ab9419f084c9972e2fe752ec2f082d8',2009,'NR','Nauru','transportation',891,'Airports: 137 (2007)
Airports— with paved runways:
total: 21
over 3,047 m: 3
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 13
914 to 1,523 m: 3 (2007)
Airports— with unpaved runways:
total: 116
2,438 to 3,047 m: 2
1,524 to 2,437 m: 22
914 to 1,523 m: 72
under 914 m: 20 (2007)
Railways:
total: 2,382 km
narrow gauge: 2,382 km 1.067-m gauge
(2006)
Roadways:
total: 42,237 km
paved: 5,406 km
unpaved: 36,831 km (2002)
Merchant marine:
total: 1 ship (1000 GRT or over) 2,265
GRT/3,605 DWT
by type: cargo 1 (2007)
Ports and terminals: Luderitz, Walvis
Bay
Military branches: Namibian Defense
Force: Army, Navy, Air Wing (2008)
Military service age and obligation:
18-25 years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 527,948 (2008 est.)
Manpower fit for military service:
males age 16-49: 313,497 (2008 est.)
Military expenditures— percent of
GDP: 3.7% (2006)
Airports: 1 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 30 km
Ports and terminals: Nauru','03472f1ddd3e7120d1635022c106c685601a19eb4139ad7fcf361a777226d788','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0584c7665ad8aaa0cfda4920019289fb4251ae4f73abba812eb8a97cd0ac98a',2009,'NL','Netherlands','transportation',904,'Airports: 47 (2007)
Airports — with paved runways:
total: 10
over 3,047 m: 1
914 to 1 ,523 m: 8
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 37
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 6
under 9 14 m: 30 (2007)
Railways: total: 59 km
narrow gauge: 59 km 0.762-m gauge
(2006)
Roadways:
total: 17,380 km
paved: 9,886 km
unpaved: 7,494 km (2004)
Military branches: Nepalese Army,
Armed Police Force (2008)
Military service age and obligation: 18
years of age for voluntary military
service; 15 years of age for military
training; no conscription (2008)
Manpower available for military
service:
males age 16-49: 7,322,965
females age 16-49: 6,859,064 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,146,958
females age 16-49: 4,724,495 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 335,747
females age 16-49: 312,297 (2008 est.)
Military expenditures— percent of
GDP: 1.6% (2006)
Airports: 27 (2007)
Airports — with paved runways:
total: 20
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2007)
Heliports: 1 (2007)
Pipelines: condensate 81 km; gas 7,394
km; oil 578 km; refined products 716 km
(2007)
Railways: total: 2,811 km
standard gauge: 2,811 km 1.435-m gauge
(2,064 km electrified) (2006)
Roadways:
total: 134,000 km (includes 3,270 km of
expressways) (2004)
Waterways: 6,183 km (navigable for
ships of 50 tons) (2005)
Merchant marine:
total: 566 ships (1000 GRT or over)
5,210,664 GRT/5,217,874 DWT
by type: bulk carrier 9, cargo 346, carrier
19, chemical tanker 39, container 63,
liquefied gas 13, passenger 14, pas¬
senger/cargo 16, petroleum tanker 12,
refrigerated cargo 11, roll on/roll off 20,
specialized tanker 4
foreign''owned: 172 (Belgium 2, Denmark
19, Finland 14, France 1, Germany 70,
Ireland 9, South Korea 1, Norway 9,
Sweden 27, UK 7, US 13)
registered in other countries: 220 (Antigua
and Barbuda 19, Australia 2, Austria 2,
Bahamas 24, Canada 1, Cyprus 23,
Gibraltar 11, Isle of Man 1, Liberia 28,
Luxembourg 1, Malta 3, Marshall Islands
5, Netherlands Antilles 53, Norway 1,
Panama 14, Paraguay 1, Philippines 22,
Portugal 1, St Vincent and The
Grenadines 5, UK 2, US 1, unknown 1)
(2007)
Ports and terminals: Amsterdam,
IJmuiden, Rotterdam, Terneuzen,
Vlissingen','67ac922681ee67424d0dad3871f6dc47ec453a158832da8389bdc2d29519204a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fb9a5940a82dd86535ae8f922b7452f44144c830d8f83095629a45eae1b30e5',2009,'NC','New Caledonia','transportation',911,'Airports: 5 (2007)
Airports— with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1 ,523 m: 1
under 914 m: 1 (2007)
Roadways:
total: 845
Merchant marine:
total: 138 ships (1000 GRT or over)
1,096,005 GRT/1,437,692 DWT
by type: barge carrier 2, bulk carrier 4,
cargo 70, carrier 12, chemical tanker 3,
container 10, liquefied gas 1, passenger 2,
petroleum tanker 2, refrigerated cargo
25, roll on/roll off 4, specialized tanker 3
foreign- owned: 125 (Belgium 1, Cuba 1,
Denmark 1, Germany 48, Netherlands
53, Norway 5, Sweden 3, Turkey 12, US
1) (2007)
Ports and terminals: Bopec Terminal,
Willemstad
Military branches: no regular military
forces; National Guard (2008)
Military service age and obligation: 16
years of age for National Guard recruit¬
ment; no conscription (2004)
Manpower available for military
service:
males age 16-49: 55,365
females age 16-49: 57,060 (2008 est.)
Manpower fit for military service:
males age 16-49: 46,102
females age 16-49: 47,219 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 1,855
females age 16—49: 1,760 (2008 est.)
Military — note: defense is the responsi¬
bility of the Kingdom of the Netherlands
Airports: 2 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 1
9 14 to 1,523 m: 1 (2007)
Merchant marine:
total: 8 ships (1000 GRT or over) 92,346
GRT/98,307 DWT
by type: chemical tanker 2, passenger 6
foreign-owned: 8 (France 6, French
Polynesia 2) (2007)
Ports and terminals: Leava, Mata-Utu
Airports: 3 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1
under 914 m: 1 (2007)
Roadways: total: 4,996 km
paved: 4,996 km
note: includes Gaza Strip (2004)','4a79633881260ba294bbf69b45573a1a3a6a4b956dcb87def430160338db8760','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5951b88f48335c53ca0d154ffb5e3d87e35c79326b7dd260d83fe32f8e344f5e',2009,'NZ','New Zealand','transportation',918,'Airports: 25 (2007)
Airports— with paved runways:
total: 12
over 3,047 m: 1
914 to 1 ,523 m: 9
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 13
914 to 1 ,523 m: 7
under 914 m: 6 (2007)
Heliports: 6 (2007)
Roadways:
total: 5,432 km (2000)
Merchant marine:
total: 2 ships (1000 GRT or over) 3,566
GRT/2,543 DWT
by type: cargo 1, passenger/cargo 1
(2007)
Ports and terminals: Noumea
Airports: 1 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 234 km
paved: 86 km
unpaved: 148 km (2001)
Ports and terminals: none; offshore
anchorage only','5569ab4e92938d961fdf73f85d2f82760b754ca6af616fcac2e9ebf2a0b87046','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6ec0cf1234519bc1913e539c8b869f9f738ada8fae0e139834e78687e9dcc49',2009,'NE','Niger','transportation',931,'Airports: 163 (2007)
Airports— with paved runways:
total: 11
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 2
914 to 1,523 m: 3
from France in 1960 and experienced
single-party and military rule until 1991,
when Gen. Ali SAIBOU was forced by
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 152
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 16
under 914 m: 135 (2007)
Pipelines: oil 54 km (2007)
Railways:
total: 6 km
narrow gauge: 6 km 1.067-m gauge
(2006)
Roadways:
total: 19,036 km
paved: 2,299 km
unpaved: 16,737 km (2005)
Waterways: 2,220 km (including lakes
Managua and Nicaragua) (2007)
Ports and terminals: Bluefields,
Corinto, El Bluff
Airports: 28 (2007)
Airports— with paved runways:
total: 9
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 5
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 19
1,524 to 2,437 m: 2
914 to 1 ,523 m: 14
under 914 m: 3 (2007)
Roadways:
total: 14,565 km
paved: 3,641 km
unpaved: 10,924 km (2004)
Waterways: 300 km (the Niger, the only
major river, is navigable to Gaya
between September and March) (2005)','8fd7da96b8f8be620e75e59dee63f926e6d9f0bde92c9d1b4390b758cc1d6cfd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43b973f1dc1fcd632592d04701f136a662e3d213726a92b56036f062cb915e68',2009,'MP','Northern Mariana Islands','transportation',949,'Airports: 1 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 80 km
paved: 53 km
unpaved: 27 km (2002)
Ports and terminals: none; loading jet¬
ties at Kingston and Cascade','dc0404f2c56eb0b05b2dbe52a4404c977567d5c8928eec40c03028232b04bfc4','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70b692a1938bff86112ec8fa55e800045a236ee2d31e8e9c43cfca3245c85520',2009,'NO','Norway','transportation',955,'Airports: 5 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2007)
Heliports: 1 (2007)
Roadways:
total: 536 km (2004)
Ports and terminals: Saipan, Tinian
Military — note: defense is the responsi¬
bility of the US
Airports: 98 (2007)
Airports— with paved runways:
total: 67
over 3,047 m: 1
2,438 to 3,047 m: 12
1,524 to 2,437 m: 12
914 to 1 ,523 m: 13
under 914 m: 29 (2007)
Airports— with unpaved runways:
total: 31
914 to 1,523 m: 6
under 914 m: 25 (2007)
Heliports: 1 (2007)
Pipelines: condensate 508 km; gas 6,529
km; oil 2,444 km; oil/gas/water 457 km
(2007)
Railways:
total: 4,043 km
standard gauge: 4,043 km 1.435-m gauge
(2,509 km electrified) (2006)
Roadways:
total: 92,513 km
paved: 71,832 km (includes 664 km of
expressways)
unpaved: 20,681 km (2005)
Waterways: 1,577 km (2007)
Merchant marine:
total: 715 ships (1000 GRT or over)
16,511,659 GRT/22,299,832 DWT
by type: bulk carrier 49, cargo 151, carrier
1, chemical tanker 146, combination
ore/oil 12, container 5, liquefied gas 72,
passenger/cargo 122, petroleum tanker
79, refrigerated cargo 12, roll on/roll off
16, specialized tanker 1, vehicle carrier
49
foreign''owned: 174 (China 47, Cyprus 2,
Denmark 26, Estonia 1, Finland 1,
France 3, Germany 2, Greece 6, Hong
Kong 5, Iceland 3, Italy 4, Japan 1,
Lithuania 1, Monaco 5, Netherlands 1,
Poland 3, Saudi Arabia 3, Singapore 1,
Sweden 31, UAE 1, UK 9, US 18)
registered in other countries: 872 (Antigua
and Barbuda 7, Australia 1, Bahamas
232, Barbados 35, Belize 3, Bermuda 5,
Brazil 1, Canada 1, Cayman Islands 2,
China 1, Comoros 1, Cook Islands 1,
Cyprus 17, Denmark 1, Dominica 1,
Estonia 2, Faroe Islands 4, Finland 1,
France 17, Gibraltar 27, Hong Kong 30,
Isle of Man 33, Liberia 42, Libya 1 , Malta
71, Marshall Islands 62, Mexico 1,
Netherlands 9, Netherlands Antilles 5,
Nigeria 1, Panama 60, Philippines 2,
Portugal 3, Singapore 125, Spain 6, St
490
Vincent and The Grenadines 19,
Sweden 5, UK 33, US 4, unknown 2)
(2007)
Ports and terminals: Bergen, Borg
Havn, Haugesund, Maaloy, Mongstad,
Narvik, Oslo, Sture','7370b96d5aa668c3a370bb69d17710ba5173661fe7cb6e2cac492c571b7249aa','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a52e2b7b1b395bd95fa203dc5eb24f7df2fd87dce14b1330ae939533a21de948',2009,'OM','Oman','transportation',964,'Airports: 137 (2007)
Airports — with paved runways:
total: 7
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Airports — with unpaved runways:
total: 130
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 5 1
914 to 1,523 m: 35
under 914 m: 34 (2007)
Heliports: 2 (2007)
Pipelines: gas 4,126 km; oil 3,558 km
(2007)
Roadways:
total: 34,965 km
paved: 9,673 km (includes 550 km of
expressways)
unpaved: 25,292 km (2001)
Merchant marine:
total: 2 ships (1000 GRT or over) 12,155
GRT/7,244 DWT
by type: chemical tanker 1, passenger 1
registered in other countries: 1 (Panama 1)
(2007)
Ports and terminals: Mina’ Qabus,
Salalah
Ports and terminals: Bangkok
(Thailand), Hong Kong (China), Kao-
hsiung (Taiwan), Los Angeles (US),
Manila (Philippines), Pusan (South
Korea), San Francisco (US), Seattle
(US), Shanghai (China), Singapore,
Sydney (Australia), Vladivostok
(Russia), Wellington (NZ), Yokohama
(Japan)
Transportation — note: Inside Passage
offers protected waters from southeast
Alaska to Puget Sound (Washington
state)
Disputes — international: some mar¬
itime disputes (see littoral states)
495','822c13a1344e82d42f8b4795689a12c2085dd3bb9e260dce67b51d33ed2cc63c','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf4e35408c2d18740b7a5cc61409766db9d09c4514d31f2e82b55e32d16ebade',2009,'PW','Palau','transportation',973,'Airports: 146 (2007)
Airports— with paved runways:
total: 92
over 3,047 m: 16
2,438 to 3,047 m: 19
1,524 to 2,437 m: 29
914 to 1,523 m: 18
under 914 m: 10 (2007)
Airports— with unpaved runways:
total: 54
2,438 to 3,047 m: 1
1,524 to 2,437 m: 16
914 to 1 ,523 m: 13
under 914 m: 24 (2007)
Heliports: 18 (2007)
Pipelines: gas 10,398 km; oil 2,076 km
(2007)
Railways:
total: 8,163 km
broad gauge : 7,718 km 1.676-m gauge
(293 km electrified)
narrow gauge: 445 km 1.000-m gauge
(2006)
Roadways:
total: 258,340 km
paved: 167,146 km (includes 711 km of
expressways)
unpaved: 91,194 km (2004)
Merchant marine:
total: 14 ships (1000 GRT or over)
325,254 GRT/536,876 DWT
by type: bulk carrier 1, cargo 10, petro¬
leum tanker 3
registered in other countries: 12 (Comoros
2, Hong Kong 1, North Korea 1, Malta 2,
Panama 5, St Vincent and The
Grenadines 1) (2007)
Ports and terminals: Karachi, Port
Muhammad Bin Qasim
Military branches: Army (includes
National Guard), Navy (includes
Marines and Maritime Security Agency),
Pakistan Air Force (Pakistan Fiza’ya)
(2008)
Military service age and obligation: 16
years of age for voluntary military
service; soldiers cannot be deployed for
combat until age of 18; the Pakistani Air
Force and Pakistani Navy have inducted
their first female pilots and sailors (2006)
Manpower available for military
service:
males age 16-49: 42,633,765
females age 16—49: 40,114,017 (2008
est.)
Manpower fit for military service:
males age 16-49: 32,453,913
females age 16-49: 31,369,057 (2008
est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 1,976,444
females age 16—49: 1,856,505 (2008 est.)
Military expenditures— percent of
GDP: 3% (2007 est.)
Airports: 3 (2007)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 2
1,524 to 2,437 m: 2 (2007)
Roadways:
total: 60 km
Ports and terminals: Koror','5ce9a904959a31c674289728d535a46bf152b0ae8f1c61dbe1a91e6aa35b2ee9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('085e7d9344c429e4a23977388135fe3f0808d1393a1b6d3b4e10e402d6355796',2009,'PA','Panama','transportation',981,'Airports: 116 (2007)
Airports— with paved runways:
total: 54
over 3,047 m: 1
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 5
91 4 to 1 ,523 m: 18
under 914 m: 29 (2007)
Airports— with unpaved runways:
total: 62
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 11
under 914 m: 50 (2007)
Heliports: 2 (2007)
Railways:
total: 355 km
standard gauge: 77 km 1.43 5 -m gauge
narrow gauge: 278 km 0.914-m gauge
(2006)
Roadways:
total: 11,643 km
paved: 4,028 km
unpaved: 7,615 km (2000)
Waterways: 800 km (includes 82 km
Panama Canal) (2007)
Merchant marine:
total: 5,764 ships (1000 GRT or over)
159,649,801 GRT/240, 190,3 16 DWT
by type: barge carrier 2, bulk carrier
504','d27f685bef00bd8762aee9d83c286ee2f68ebc23ba7d62a730a75a7368329625','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c854f4b88b9e3b4803048039c79363ab8b3ee3f3a196f1c6276f6140fc840c19',2009,'PG','Papua New Guinea','transportation',982,'1,940, cargo 1,034, carrier 3, chemical
tanker 507, combination ore/oil 6, con¬
tainer 710, liquefied gas 191, livestock
carrier 7, passenger 46, passenger/cargo
72, petroleum tanker 522, refrigerated
cargo 288, roll on/roll off 129, specialized
tanker 22, vehicle carrier 285
foreigri''Oumed: 4,949 (Albania 1,
Argentina 8, Australia 4, Bahamas 2,
Bangladesh 1, Belgium 11, Bulgaria 1,
Canada 17, Chile 8, China 473,
Colombia 4, Croatia 6, Cuba 11, Cyprus
15, Denmark 32, Dominican Republic 1,
Ecuador 2, Egypt 13, Estonia 3, France
15, Gabon 1, Germany 38, Greece 505,
Hong Kong 137, India 25, Indonesia 37,
Iran 4, Ireland 1, Israel 2, Italy 10,
Jamaica 1, Japan 2,151, Jordan 11, South
Korea 316, Kuwait 1, Latvia 5, Lebanon
3, Lithuania 5, Malaysia 14, Maldives 1,
Malta 2, Mexico 4, Monaco 11,
Netherlands 14, Nigeria 6, Norway 60,
Oman 1, Pakistan 5, Peru 15, Philippines
12, Poland 15, Portugal 9, Qatar 1,
Romania 8, Russia 9, Saudi Arabia 14,
Singapore 83, Spain 61, Sri Lanka 3,
Sweden 9, Switzerland 26, Syria 24,
Taiwan 306, Thailand 10, Turkey 53,
Turks and Caicos Islands 1, Ukraine 8,
UAE 108, UK 35, US 1 15, Venezuela 10,
Vietnam 10, Yemen 5)
registered in other countries: 1 (Venezuela
1) (2007)
Ports and terminals: Balboa, Colon,
Cristobal
Military branches: no regular military
forces; Panamanian Public Forces or PPF
includes the Panamanian National
Police (PNP), National Maritime
Service (NMS), and National Air
Service (NAS) (2008)
Manpower available for military
service:
males age 16-49: 851,044 (2008 est.)
Manpower fit for military service:
males age 16—49: 673,103 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 30,348 (2008 est.)
Military expenditures— percent of
GDP: 1% (2006)
Military — note: on 10 February 1990,
the government of then President
ENDARA abolished Panama’s military
and reformed the security apparatus by
creating the Panamanian Public Forces;
in October 1994, Panama’s Legislative
Assembly approved a constitutional
amendment prohibiting the creation of a
standing military force but allowing the
temporary establishment of special
police units to counter acts of “external
aggression”
Airports: 578 (2007)
Airports— with paved runways:
total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 557
1 ,524 to 2,437 m: 10
507
THE CIA WORLD FACTBOOK
914 to 1,523 m: 58
under 914 m; 489 (2007)
Heliports: 2 (2007)
Pipelines: oil 264 km (2007)
Roadways:
total: 19,600 km
paved: 686 km
unpaved: 18,914 km (1999)
Waterways: 11,000 km (2006)
Merchant marine:
total: 24 ships (1000 GRT or over)
56,157 GRT/72,821 DWT
by type: bulk carrier 3, cargo 20, petro-
leum tanker 1
foreign''ovuned: 6 (UK 6) (2007)
Ports and terminals: Kimbe, Lae,
Madang, Rabaul, Wewak','efdb15d6c345b1403d55485797a2d8f2aa7d4b3df2476fe71da1c9e6af0ca1e1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0d60b368e4bdb1995454e94f83c781ee4d33eca341d0f82f47155705ccb47c6',2009,'PH','Philippines','transportation',991,'Airports: 1 (2007)
Airports— with paved runways: total: 1
1,524 to 2,437 m: 1 (2007)
Ports and terminals: small Chinese port
facilities on Woody Island and Duncan
Island being expanded
Airports: 255 (2007)
Airports— with paved runways: total. 84
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 26
914 to 1 ,523 m: 36
under 914 m: 10 (2007)
Airports— with unpaved runways:
total: 171
1 ,524 to 2,437 m: 4
914 to 1 ,523 m: 68
under 914 m: 99 (2007)
Heliports: 2 (2007)
Pipelines: gas 565 km; oil 135 km;
refined products 105 km (2007)
Railways:
total: 897 km
narrow gauge: 897 km 1.067-m gauge
(492 km are in operation) (2006)
Roadways:
total: 200,037 km
paved: 19,804 km
unpaved: 180,233 km (2003)
Waterways: 3,219 km (limited to vessels
with draft less than 1.5 m) (2007)
Merchant marine:
total: 383 ships (1000 GRT or over)
4,542,681 GRT/6, 164,3 12 DWT
by type: bulk carrier 75, cargo 120, chem¬
ical tanker 16, container 5, liquefied gas
5, livestock carrier 16, passenger 7, pas¬
senger/cargo 66, petroleum tanker 34,
refrigerated cargo 14, roll on/roll off 13,
vehicle carrier 12
foreigri''owned: 135 (Bermuda 31, China
2, Greece 3, Hong Kong 2, Japan 69,
Malaysia 2, Netherlands 22, Norway 2,
Singapore 1, UAE 1)
registered in other countries: 34 (Australia
1, Bahamas 1, Belize 1, Comoros 1,
Cyprus 1, Ecuador 1, Hong Kong 10,
Indonesia 1, Panama 12, Singapore 4, St
Vincent and The Grenadines 1) (2007)
Ports and terminals: Cagayan de Oro,
Cebu, Davao, Liman, Manila, Nasipit
Harbor
Ports and terminals: Adamstown (on
Bounty Bay)','5c4eb662efd9307db79293afb3d2ba97eda735d47db57df7c195be34efae94f1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d434fc537f21284bd1411d566907f754cd5435f70fa7796f91a3b940eb4b8fdc',2009,'PR','Puerto Rico','transportation',1011,'Airports: 66 (2007)
Airports— with paved runways:
total: 44
over 3,047 m: 5
2,438 to 3,047 m: 9
1 ,524 to 2,437 m: 5
914 to 1 ,523 m: 13
under 914 m: 12 (2007)
Airports— with unpaved runways:
total: 22
914 to 1 ,523 m: 1
under 914 m: 21 (2007)
Pipelines: gas 1,098 km; oil 11 km;
refined products 188 km (2007)
Railways:
total: 2,786 km
broad gauge: 2,603 km 1.668-m gauge
(1,351 km electrified)
narrow gauge: 183 km 1.000-m gauge
(2006)
Roadways:
total: 78,470 km
paved: 67,484 km (includes 2,002 km of
expressways)
unpaved: 10,986 km (2004)
Waterways: 210 km (on Douro River
from Porto) (2006)
Merchant marine:
total: 117 ships (1000 GRT or over)
1,022,783 GRT/1,287,951 DWT
by type: bulk carrier 10, cargo 37, carrier
1, chemical tanker 16, container 6, liq¬
uefied gas 9, passenger 10, pas-
senger/cargo 10, petroleum tanker 6, roll
on/roll off 1, specialized tanker 1, vehicle
carrier 10
foreign''Owned: 80 (Belgium 9, Denmark
3, Germany 22, Greece 4, Italy 11, Japan
10, Malta 1, Mexico 1, Netherlands 1,
Norway 3, Spain 10, Sweden 2,
Switzerland 2, US 1)
registered in other countries: 15 (Cyprus 1,
Hong Kong 1, Malta 3, Panama 9, St
Vincent and The Grenadines 1) (2007)
Ports and terminals: Leixoes, Lisbon,
Setubal, Sines
Airports: 29 (2007)
Airports— with paved runways:
total: 17
over 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 5 (2007)
Airports— with unpaved runways:
total: 12
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 10 (2007)
Railways: total: 96 km
narrow gauge: 96 km 1.000-m gauge
(2006)
Roadways: total: 25,735 km
paved: 24,353 km (includes 427 km of
expressways)
unpaved: 1,382 km (2005)
Merchant marine:
total: 3 ships (1000 GRT or over) 77,177
GRT/50,138 DWT
by type: roll on/roll off 3
foreign-owned: 3 (US 3)
registered in other countries: 1 (St Vincent
and The Grenadines 1) (2007)
Ports and terminals: Guayanilla,
Mayaguez, San Juan','a81f3ade1b4820f6c3d79b4d6583a77fc00afa84132ddcface78017e3ebcfafe','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b853c68740ab9ecda33f68fa328cc41bbe91910ca7b19887c05ca534b5268664',2009,'QA','Qatar','transportation',1019,'Airports: 5 (2007)
Airports— with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 2
914 to 1 ,523 m: 1
under 914 m: 1 (2007)
Heliports: 1 (2007)
Pipelines: condensate 322 km; conden-
sate/gas 209 km; gas 1,970 km; liquid
petroleum gas 87 km; oil 741 km (2007)
Roadways: total: 1,230 km
paved: 1,107 km
unpaved: 123 km (1999)
Merchant marine:
total: 20 ships (1000 GRT or over)
574,969 GRT/856,057 DWT
by type: bulk carrier 1, cargo 2, chemical
tanker 2, container 8, liquefied gas 2,
petroleum tanker 4, roll on/roll off 1
foreign''Owned: 7 (Kuwait 7)
registered in other countries: 3 (Liberia 2,
Panama 1) (2007)
Ports and terminals: Doha, Ra’s Laffan
Military branches: Qatari Amiri Land
Force (QALF), Qatari Amiri Navy
(QAN), Qatari Amiri Air Force
(QAAF) (2007)
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16-49: 320,383
females age 16-4 9: 167,475 (2008 est.)
Manpower fit for military service:
males age 16-49: 258,159
females age 16—49: 143,999 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—4 9: 7,539
females age 16—49: 7,022 (2008 est.)
Military expenditures— percent of
GDP: 10% (2005 est.)','fa406e4b2b16992530d95a68f239b04b6c387c7fa4a19bfd8524c58e26cd0215','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ee3c0476b74c55e6b591cee8b1059fb991f95f9de67e36983236f08d5d91be2',2009,'RW','Rwanda','transportation',1029,'Airports: 9 (2007)
Airports — with paved runways: total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (2007)
Roadways:
total: 14,008 km
paved: 2,662 km
unpaved: 11,346 km (2004)
Waterways: Lac Kivu navigable by
shallow-draft barges and native craft
(2006)
Ports and terminals: Cyangugu,
Gisenyi, Kibuye
Military branches: Rwandan Defense
Forces: Army, Air Force
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16—49: 2,430,469
females age 16-49: 2,392,933 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,404,066
females age 16—4 9: 1,403,700 (2008 est.)
Military expenditures— percent of
GDP: 2.9% (2006 est.)
Disputes — international: fighting
among ethnic groups — loosely associated
political rebels, armed gangs, and various
government forces in Great Lakes region
transcending the boundaries of Burundi,
Democratic Republic of the Congo,
Rwanda, and Uganda — abated substan¬
tially from a decade ago due largely to
UN peacekeeping, international media¬
tion, and efforts by local governments to
create civil societies; nonetheless, 57,000
Rwandan refugees still reside in 21
African states, including Zambia,
Gabon, and 20,000 who fled to Burundi
in 2005 and 2006 to escape drought and
recriminations from traditional courts
investigating the 1994 massacres; the
2005 DROC and Rwanda border verifi¬
cation mechanism to stem rebel actions
on both sides of the border remains in
place
Refugees and internally displaced per¬
sons: refugees (country of origin): 46,272
(Democratic Republic of the Congo);
4,400 (Burundi) (2007)
545
'' . r ” ■>
tew
is/Ws !:#Ftdg&te
& m Ptxfsisms
tin ctmrmm
- Iki V&ftJ
A
■ w,
%;•■■■ -v
Mom*
<ti,< Vftvt A
%■
'' v
GUSTAVIA
<f& SiSC?®
tie Saint-
Bartheiemy
Y ■>
OvCece
Caripmm $00
6 2
0 i *«*
8^02%-
Background: Discovered in 1493 by
Christopher COLUMBUS who named it
for his brother Bartolomeo, St.
Bartheiemy was first settled by the
French in 1648. In 1784, the French sold
the island to Sweden, who renamed the
largest town Gustavia, after the Swedish
King GUSTAV III, and made it a free
port; the island prospered as a trade and
supply center during the colonial wars of
the 1 8th century. France repurchased the
island in 1878 and placed it under the
administration of Guadeloupe. St.
Bartheiemy retained its free port status
along with various Swedish appelations
such as Swedish street and town names,
and the three-crown symbol on the coat
of arms. In 2003, the populace of the
island voted to secede from Guadeloupe
and in 2007, the island became a French
overseas collectivity.
Location: located approximately 125
miles northwest of Guadeloupe
Geographic coordinates: 17 90 N, 62 85
w
Map references: Central America and
the Caribbean
Area: 21 sq km
Area — comparative: less than an eighth
of the size of Washington, DC
Land boundaries: 0 km
Climate: tropical, with practically no
variation in temperature; has two seasons
(dry and humid)
Terrain: hilly, almost completely sur¬
rounded by shallow-water reefs, with 20
beaches
Elevation extremes:
lowest point: Caribbean Ocean 0 m
highest point: Morne du Vitet 286 m
Natural resources: has few natural
resouces, its beaches being the most
important
Environment — current issues: with no
natural rivers or streams, fresh water is in
short supply, especially in summer, and
provided by desalinization of sea water,
collection of rain water, or imported via
water tanker
Population: 7,492 (July 2008 est.)
Ethnic groups: white, Creole (mulatto),
black, Guadeloupe Mestizo (French-East
Asia)
Religions: Roman Catholic, Protestant,
Jehovah’s Witness
Languages: French (primary), English','b9a383283682a79e74023ed62d2eb125cd310ef6815700116c3236f3c6b37dfd','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56fed49168ac8ca65a8781018c53ea2bb5928df3ee51ed29fda88be90bb8da62',2009,'GP','Guadeloupe','transportation',1032,'Airports: 1
Airports— with paved runways:
total: 1
under 914 m: 1
Transportation — note: nearest airport for
international flights is Princess Juliana
International Airport (SXM) located in
Sint Maarten (Netherlands Antilles)
Military — note: defense is the response
bility of France','18e3ab25b53e9fcb502d4c179c40018252047543c1c05c874c824b6c134cbe37','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05c0105cc3f59c23aa2c62c0d6e10d91f391a8e119b1ca2d8501c032dd2c4c26',2009,'LC','Saint Lucia','transportation',1044,'Airports: 2 (2007)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 1
9 14 to 1,523 m: 1 (2007)
Railways:
total: 50 km
narrow gauge: 50 km 0.762-m gauge on
Saint Kitts for tourists (2006)
Roadways:
total: 320 km
Merchant marine:
total: 104 ships (1000 GRT or over)
465,056 GRT/663, 511 DWT
by type: bulk carrier 3, cargo 66, chemical
tanker 8, container 1, passenger/cargo 2,
petroleum tanker 15, refrigerated cargo
5, roll on/roll off 2, specialized tanker 2
foreign''Owned: 76 (Belgium 1, Egypt 2,
Estonia 1, Greece 2, India 1, Iran 1,
Latvia 4, Monaco 1, Romania 1, Russia
14, Spain 1, Syria 5, Tanzania 1, Turkey
13, Ukraine 5, UAE 22, Yemen 1)
(2007)
Ports and terminals: Basseterre
Military branches: Saint Kitts and Nevis
Defense Force (includes Coast Guard),
Royal Saint Kitts and Nevis Police Force
Military service age and obligation: 18
years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service:
males age 16—49: 10,095
females age 16—49: 10,081 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,064
females age 16—49: 8,464 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—4 9: 366
females age 16-49: 354 (2008 est.)
Military expenditures— percent of
GDP: NA','d2383c507b2f67dba7624281262202dfffc33ba1ad4238e787cb9cd67244fdc1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae97fe255effe5511d8ce37e0616818d5faeb01265849b2507b4dd1c4379b822',2009,'PM','Saint Pierre and Miquelon','transportation',1052,'_
Airports: 1
Airports— with paved runways:
total: 1
914 to 1 ,523 m: 1
Transportation — note: nearest airport
for international flights is Princess
Juliana International Airport (SXM)
located in Sint Maarten
Military— note: defense is the responsi¬
bility of France
0 5 10 ter«
0 z> 10 m*
M^uelon*
w
;
wirn Oi \\ \\ x.
Si. Iswrenm \\ '' l
TO U
Miquelon
(Grande
Miquelon)
/
\\
r
/
Langlade
i Petite Miquelon)
“V"
fie Saint-Pierre
Z"0
/ f r. ,:> -
*SAINT-PiERRE
Q o
Nosh Atfmitc Oce&n','7b83d808d1c0dbb2313a62b4430141c2ad520cf6f9639bd77584d7ebc732d05b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd072331835d967f5917682fa5594444d30d802dbad4db4f1c00940f91e54860',2009,'VC','Saint Vincent and the Grenadines','transportation',1058,'Airports: 6 (2007)
Airports— with paved runways:
total: 5
9 14 to 1 ,523 m: 4
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (2007)
Roadways:
total: 829 km
paved: 58 0 km
unpaved: 249 km (2003)
Merchant marine:
total: 582 ships (1000 GRT or over)
5,598,917 GRT/8,255,014 DWT
by type: bulk carrier 92, cargo 353, carrier
19, chemical tanker 4, container 17, liq¬
uefied gas 6, livestock carrier 1, passenger
5, passenger/cargo 11, petroleum tanker
19, refrigerated cargo 31, roll on/roll off
21, specialized tanker 3
foreign-owned: 536 (Austria 2,
Bangladesh 1, Barbados 1, Belgium 9,
Bulgaria 13, Canada 6, China 106,
Croatia 7, Cyprus 3, Czech Republic 1,
Denmark 16, Egypt 4, Estonia 20, France
7, Germany 3, Greece 81, Guyana 2,
Hong Kong 7, Iceland 15, India 5, Iran 1,
Israel 4, Italy 19, Kenya 2, Latvia 20,
Lebanon 7, Lithuania 7, Malta 1,
Monaco 6, Montenegro 1, Netherlands
5, Norway 19, Pakistan 1, Philippines 1,
Poland 1, Portugal 1, Puerto Rico 1,
Romania 1, Russia 19, Singapore 6,
Slovenia 5, Sweden 2, Switzerland 12,
Syria 11, Turkey 20, Ukraine 12, UAE
12, UK 9, US 21) (2007)
Ports and terminals: Kingstown','b8f4845d1fd079482942f070c1c7ee8fd10dd64df9ef2298a1c4f9dc29227f0f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d5f5a9a51e24e2a1c4a9e1f3ee5aba99333fd219d85a9824c63888dfadf6461',2009,'WS','Samoa','transportation',1064,'Airports: 4 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (2007)
Roadways:
total: 2,337 km
paved: 332 km
unpaved: 2,005 km (2004)
Merchant marine:
total: 1 ship (1000 GRT or over) 7,091
GRT/8,127 DWT
by type: cargo 1
foreign-owned: 1 (Cyprus 1) (2007)
Ports and terminals: Apia','9bb0723cd1c530f39c14eb50f40651758d01bfc79d03b2775330ef0b0db00c84','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2ac3ce0af843291dfa926d2cd38f29e4573ef275a8a30035af76c205a4c941c',2009,'GN','Guinea','transportation',1074,'Airports: 2 (2007)
Airports— with paved runways:
total: 2
1 ,524 to 2,437 m: 1
9 14 to 1,523 m: 1 (2007)
Roadways:
total: 320 km
paved: 218 km
unpaved: 102 km (1999)
Merchant marine:
total: 7 ships (1000 GRT or over) 20,455
GRT/27,871 DWT
by type: bulk carrier 1, cargo 6
foreign''owned: 2 (Egypt 1, Greece 1)
(2007)
Ports and terminals: Sao Tome','c4c09b72a6d45b0189c6a8ee6fa0ff3e97b539c6a8c6a95c8fd31ded2ec3aed6','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81da18a258c8cc9aef33786c0dbda88a3d1b548f93c004478fc7de60b3a1fed4',2009,'SA','Saudi Arabia','transportation',1080,'Airports: 213 (2007)
Airports— with paved runways:
total: 77
over 3,047 m: 32
2,438 to 3,047 m: 15
1 ,524 to 2,437 m: 26
914 to 1,523 m: 2
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 136
over 3,047 m: 1
2,438 to 3,047 m: 8
1 ,524 to 2,437 m: 73
914 to 1 ,523 m: 39
under 914 m: 15 (2007)
Heliports: 8 (2007)
Pipelines: condensate 212 km; gas 1,880
km; liquid petroleum gas 1,183 km; oil
4,521 km; refined products 1,148 km
(2007)
Railways: total: 1,392 km
standard gauge: 1,392 km 1.435-m gauge
(with branch lines and sidings) (2006)
Roadways:
total: 152,044 km
paved: 45,461 km
unpaved: 106,583 km (2000)
Merchant marine:
total: 59 ships (1000 GRT or over)
847,094 GRT/1,059,026 DWT
by type: cargo 5, chemical tanker 15,
container 4, passenger/cargo 8, petro¬
leum tanker 16, refrigerated cargo 3, roll
on/roll off 8
foreign'' owned: 10 (Egypt 1, Greece 2,
Kuwait 6, UAE 1)
registered in other countries: 63 (Bahamas
15, Comoros 1, Dominica 1, France 1,
Liberia 24, Marshall Islands 4, Norway 3,
Panama 14) (2007)
Ports and terminals: Ad Dammam, A1
Jubayl, Jiddah, Yanbu’ al Sinaiyah
569
THE CIA WORLD FACTBOOK
Military branches: Land Forces (Army),
Navy, Air Force, Air Defense Force,
National Guard, Ministry of Interior
Forces (paramilitary)
Military service age and obligation: 18
years of age (est.); no conscription
(2004)
Manpower available for military
service:
males age 16-49: 8,547,441
females age 16-49: 6,381,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,398,417
females age 16—49: 5,525,357 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 272,046
females age 16—49: 261,991 (2008 est.)
Military expenditures — percent of
GDP: 10% (2005 est.)
Disputes— international: Saudi Arabia
has reinforced its concrete-filled security
barrier along sections of the now fully
demarcated border with Yemen to stem
illegal cross-border activities; Kuwait and
Saudi Arabia continue discussions on a
maritime boundary with Iran
Refugees and internally displaced per¬
sons: refugees (country of origin): 240,015
(Palestinian Territories) (2007)
Trafficking in persons: current situation:
Saudi Arabia is a destination country for
workers from South and Southeast Asia
who are subjected to conditions that
constitute involuntary servitude
including being subjected to physical
and sexual abuse, non-payment of wages,
confinement, and withholding of pass¬
ports as a restriction on their movement;
domestic workers are particularly vulner¬
able because some are confined to the
house in which they work unable to seek
help; Saudi Arabia is also a destination
country for Nigerian, Yemeni, Pakistani,
Afghan, Somali, Malian, and Sudanese
children trafficked for forced begging and
involuntary servitude as street vendors;
some Nigerian women were reportedly
trafficked into Saudi Arabia for commer¬
cial sexual exploitation
tier rating: Tier 3— Saudi Arabia does not
fully comply with the minimum stan¬
dards for the elimination of trafficking
and is not making significant efforts to
do so
Illicit drugs: death penalty for traf¬
fickers; improving anti-money-laun-
dering legislation and enforcement','0d9b36bf346ceed80a284de3d38e2c328a70ab8212ee78b0df77f3b49b78eee1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fafefe2e4146343901fb622c9dbef88bdbfaa33b1934a97c4939579680cd52c',2009,'SN','Senegal','transportation',1081,'Background: The French colonies of
Senegal and the French Sudan were
merged in 1959 and granted their inde¬
pendence as the Mali Federation in
1960. The union broke up after only a
few months. Senegal joined with The
Gambia to form the nominal confedera¬
tion of Senegambia in 1982, but the
envisaged integration of the two coun¬
tries was never carried out, and the
union was dissolved in 1989. The
Movement of Democratic Forces in the
Casamance (MFDC) has led a low-level
separatist insurgency in southern
Senegal since the 1980s, and several
peace deals have failed to resolve the
conflict. Nevertheless, Senegal remains
one of the most stable democracies in
Africa. Senegal was ruled by a Socialist
Party for 40 years until current President
Abdoulaye WADE was elected in 2000.
Fie was reelected in February 2007, but
complaints of fraud led opposition par¬
ties to boycott June 2007 legislative
polls. Senegal has a long history of par¬
ticipating in international peacekeeping.','f852d3eae9673bc873306fccbd4ef21a5761f76b8028c149ae70b21bda2ef15d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a479d93c988e67ab5107f7c6cad687ddcf6440bec63483f5111428777184b99d',2009,'RS','Serbia','transportation',1087,'Airports: 20 (2007)
Airports — with paved runways:
total: 9
over 3,047 m: 1
1 ,524 to 2,437 m: 7
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 11
1 ,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 1 (2007)
Pipelines: gas 43 km (2007)
Railways: total: 906 km
narrow gauge: 906 km 1.000 meter gauge
(2006)
Roadways:
total: 13,576 km
paved: 3,972 km (includes 7 km of
expressways)
unpaved: 9,604 km (2003)
Waterways: 1,000 km (primarily on
Senegal, Saloum, and Casamance rivers)
(2005)
Ports and terminals: Dakar
Military branches: Army, Senegalese
Navy (Marine Senegalaise), Senegalese
Air Force (Armee de l’Air du Senegal)
(2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion — 2 years (2004)
Manpower available for military
service:
males age 16-49: 2,943,619
females age 16-49: 2,955,179 (2008 est.)
Manpower fit for military service:
males age 16-4 9: 1,866,602
females age 16-4 9: 1,947,076 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 141,832
females age 16-49: 139,541 (2008 est.)
Military expenditures— percent of
GDP: 1.4% (2005 est.)
Disputes — international: The Gambia
and Guinea-Bissau attempt to stem sepa¬
ratist violence, cross border raids, and
arms smuggling into their countries from
Senegal’s Casamance region, and in
2006, respectively accepted 6,000 and
10,000 Casamance residents fleeing the
conflict; 2,500 Guinea-Bissau residents
fled into Senegal in 2006 to escape
armed confrontations along the border
Refugees and internally displaced per¬
sons: refugees (country of origin): 19,630
(Mauritania)
lDPs: 22,400 (approximately 65% of the
IDP population returned in 2005, but
new displacement is occurring due to
clashes between government troops and
separatists in Casamance region) (2007)
Illicit drugs: transshipment point for
Southwest and Southeast Asian heroin
and South American cocaine moving to
Europe and North America; illicit culti¬
vator of cannabis
■
AyAy. .
Airports: 39 (2007)
Airports— with paved runways:
total: 16
over 3,047 m: 2
2,438 to 3,047 m: 4
1 ,524 to 2,437 m: 4
9 14 to 1,523 m: 2
under 914 m: 4 (2007)
Airports— with unpaved runways:
total: 23
1 ,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 12 (2007)
Heliports: 2 (2007)
Pipelines: gas 1,921 km; oil 393 km
(2007)
Railways:
total: 3,379 km
standard gauge: 3,379 km 1.435-m gauge
(electrified 1,254 km) (2006)
Roadways:
total: 37,841 km
paved: 32,100 km
unpaved: 5,741 km (2006)
Waterways: 587 km (primarily on
Danube and Sava rivers) (2005)
Military branches: Serbian Armed
Forces (Vojska Srbije, VS): Land Forces
Command (includes Serbian naval force,
consisting of a river flotilla on the
Danube), Joint Operations Command,
Air and Air Defense Forces Command
(2007)
Military service age and obligation:
19-35 years of age for compulsory mili¬
tary service; under a state of war or
impending war, conscription can begin
at age 16; conscription is to be abolished
in 2010; 9-month service obligation,
with a reserve obligation to age 60 for
men and 50 for women (2007)','8366d92a7199fd0bbf29f8b416d0687f8fea08ca0c94d51fd70bc67c63ff55a1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d37d3636cbe91adde060e1c80dfd47feffed0d08af9289b41eecfe55ff76fb1',2009,'SC','Seychelles','transportation',1096,'Airports: 15 (2007)
Airports — with paved runways:
total: 9
2,438 to 3,047 m: 1
578','7e1bdcd15931813b49ad30ee1b6ef299242f38cc3b5b62e880cef18d3a865679','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e573b256af19adfdf85eb2c5172b8632505f34ca768631560bb9040531751e',2009,'SL','Sierra Leone','transportation',1097,'914 to 1 ,523 m: 6
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 6
914 to 1,523 m: 2
under 914 m: 4 (2007)
Roadways:
total: 458 km
paved: 440 km
unpaved: 18 km (2003)
Merchant marine:
total: 6 ships (1000 GRT or over)
108,348 GRT/165,593 DWT
by type: cargo 1, carrier 1, chemical
tanker 4
foreign-owned: 3 (Hong Kong 1, Nigeria
1, South Africa 1) (2007)
Ports and terminals: Victoria
Military branches: Seychelles Defense
Force: Army, Coast Guard (includes
Naval Wing, Air Wing), National Guard
(2005)
Military service age and obligation: 18
years of age for voluntary military service
(younger with parental consent); no
conscription (2008)
Manpower available for military
service: males age 16-49: 23,598
females age 16-49: 24,424 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,942
females age 16-49: 20,436 (2008 est.)
Military expenditures— percent of
GDP: 2% (2006 est.)','5bb6781ebff595fe2a53954506ed62f50838d0be351242e8f5d45c555f6c9b7a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9427890dad45b32562967faac785126638b21810ffa720c50c3804b1124e73b5',2009,'SG','Singapore','transportation',1104,'Airports: 10 (2007)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2007)
Airports— with unpaved runways:
total: 9
914 to 1,523 m: 7
under 914 m: 2 (2007)
Heliports: 2 (2007)
Roadways:
total: 11,300 km
paved: 904 km
unpaved: 10,396 km (2002)
Waterways: 800 km (600 km year
round) (2005)
Merchant marine:
total: 113 ships (1000 GRT or over)
314,549 GRT/419,409 DWT
by type: bulk carrier 1, cargo 85, chemical
tanker 4, combination ore/oil 1, con¬
tainer 4, liquefied gas 1, livestock carrier
1, passenger 1, passenger/cargo 4, petro¬
leum tanker 7, roll on/roll off 4
foreign'' owned: 47 (Belgium 1, China 8,
Greece 1, Romania 2, Russia 5, Syria 8,
Turkey 7, Ukraine 8, UAE 7) (2007)
Ports and terminals: Freetown, Pepel,
Sherbro Islands
Airports: 8 (2007)
Airports— with paved runways:
total: 8
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2007)
Pipelines: gas 139 km; refined products
8 km (2007)
Roadways:
total: 3,234 km
paved: 3,234 km (includes 150 km of
expressways) (2005)
Merchant marine:
total: 1,131 ships (1000 GRT or over)
33,237,005 GRT/52,487,127 DWT
by type: bulk carrier 167, cargo 85, carrier
1, chemical tanker 156, container 231,
liquefied gas 72, livestock carrier 2,
petroleum tanker 355, refrigerated cargo
6, roll on/roll off 3, specialized tanker 7,
vehicle carrier 46
foreign''owned: 652 (Australia 6,
Bangladesh 2, Belgium 8, China 19,
Denmark 68, France 1, Germany 18,
Greece 14, Hong Kong 37, India 9,
Indonesia 56, Italy 4, Japan 108, South
Korea 7, Malaysia 28, Norway 125,
Philippines 4, Slovenia 1, Sweden 17,
Switzerland 2, Taiwan 60, Thailand 20,
UAE 8, UK 13, US 17)
registered in other countries: 293 (Bahamas
9, Belize 3, Bermuda 1, Bolivia 1,
Cambodia 2, Cayman Islands 10, Cyprus
1, Dominica 8, France 2, Honduras 10,
Hong Kong 11, Indonesia 26, Isle of Man
2, Kiribati 1, Liberia 42, Malaysia 22,
Marshall Islands 12, Mongolia 12,
Nigeria 1, Norway 1, Panama 83,
Philippines 1, St Vincent and The
Grenadines 6, Thailand 2, Tuvalu 13,
US 11, unknown 4) (2007)
Ports and terminals: Singapore','b776c5b9479cc7ae3edf146dae4815081585b8826c98e5b0ae2e6e6f6f47fb42','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d33b7bcddcbcbaf951ba0ffbe3c0cd67a165ce73dcb2070b49db96820545945',2009,'SK','Slovakia','transportation',1116,'Airports: 35 (2007)
Airports— with paved runways:
total: 20
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1 ,523 m: 3
under 914 m: 10 (2007)
Airports— with unpaved runways:
total: 15
914 to 1 ,523 m: 8
under 9 14 m: 7 (2007)
Heliports: 1 (2007)
Pipelines: gas 6,769 km; oil 416 km
(2007)
Railways:
total: 3,662 km
broad gauge: 100 km 1.520-m gauge
standard gauge: 3,512 km 1.435-m gauge
(1,588 km electrified)
narrow gauge: 50 km (1.000-m or 0.750-
m gauge) (2006)
Roadways:
total: 42,993 km
paved: 37,533 km (includes 316 km of
expressways)
unpaved: 5,460 km (2004)
Waterways: 172 km (on Danube River)
(2005)
Merchant marine:
total: 54 ships (1000 GRT or over)
260,766 GRT/361,651 DWT
by type: bulk carrier 6, cargo 45, refriger¬
ated cargo 3
foreign''owned: 46 (Bulgaria 7, Estonia 2,
Greece 4, Israel 6, Italy 1, Poland 2, Syria
2, Turkey 11, Ukraine 10, UK 1) (2007)
Ports and terminals: Bratislava,
Komamo','53a5170201024f8752657c68f2002de4ecab41628846483d22ce175cb60d92c9','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('092e6a53ac7ce86edaec34b1feeb4de0c66baac34800ed7c362954c3dcc82dd8',2009,'SI','Slovenia','transportation',1122,'Airports: 14 (2007)
Airports — with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
590','6e44d56bc7ba2016ad034e91da17df675a1660f5832ed5426f968713535964b1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f93ccd172805e45a2c87be023be624d79df33349a0f73fd6fbb04d59155827d3',2009,'SB','Solomon Islands','transportation',1123,'914 to 1 ,523 m: 2
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 8
1 ,524 to 2,437 m: 2
914 to 1 ,523 m: 2
under 914 m: 4 (2007)
Pipelines: gas 840 km; oil 11 km (2007)
Railways:
total: 1,229 km
standard gauge: 1,229 km 1.435-m gauge
(504 km electrified) (2006)
Roadways:
total: 38,451 km
paved: 38,451 km (includes 483 km of
expressways) (2004)
Merchant marine:
registered in other countries: 26 (Antigua
and Barbuda 6, Bahamas 1, Cyprus 4,
Georgia 2, Liberia 1, Malta 3, Marshall
Islands 3, Singapore 1, St Vincent and
The Grenadines 5) (2007)
Ports and terminals: Koper
Military branches: Slovenian Army
(includes air and naval forces)
Military service age and obligation: 17
years of age for voluntary military
service; conscription abolished in 2003
(2007)
Manpower available for military
service:
males age 16-49: 494,496
females age 16—49: 481,180 (2008 est.)
Manpower fit for military service:
males age 16—49: 406,951
females age 16—49: 395,444 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 10,516
females age 16—4 9: 9,934 (2008 est.)
Military expenditures— percent of
GDP: 1.7% (2005 est.)
Disputes — international: the Croatia''
Slovenia land and maritime boundary
agreement, which would have ceded
most of Piran Bay and maritime access to
Slovenia and several villages to Croatia,
remains unratified and in dispute;
Slovenia also protests Croatia’s 2003
claim to an exclusive economic zone in
the Adriatic; as a member state that
forms part of the EU’s external border,
Slovenia has implemented the strict
Schengen border rules to curb illegal
migration and commerce through south¬
eastern Europe while encouraging close
cross-border ties with Croatia
Illicit drugs: minor transit point for
cocaine and Southwest Asian heroin
bound for Western Europe, and for pre¬
cursor chemicals
j*£w
QIIWt/4
Choiseul
Vv
Santa Isabel
Gizo*
Yanina «■**»
HONIARA® .
Guadalcanal
ftscife
. K.
Solomon
See
San
Cristobal
Santa
Cruz
Islands
o
o
Co'';)/
*50. 3«Sfcm
IB© 300 m','2ce1228be8404ce31ae15ec9451120aeb85579f98fda7b9a87551afe3c55ffb3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79f8429619eddb41141f0d9e606babe8229440aaabdfa3489d1394c450bbb0f8',2009,'SO','Somalia','transportation',1128,'Airports: 35 (2007)
Airports— with paved runways:
total: 2
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 33
1 ,524 to 2,437 m: 1
914 to 1 ,523 m: 9
under 914 m: 23 (2007)
Heliports: 3 (2007)
Roadways:
total: 1,360 km
paved: 34 km
unpaved: 1,326 km (1999)
Ports and terminals: Pfoniara, Malloco
Bay, Viru Harbor
Airports: 67 (2007)
Airports— with paved runways:
total: 7
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2007)
Airports — with unpaved runways:
total: 60
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 20
914 to 1 ,523 m: 29
under 914 m: 7 (2007)
Roadways:
total: 22,100 km
paved: 2,608 km
unpaved: 19,492 km (1999)
Merchant marine:
total: 1 ship (1000 GRT or over) 2,659
GRT/2,540 DWT
by type: cargo 1
foreign-owned: 1 (UAE 1) (2007)
Ports and terminals: Berbera, Kismaayo','5491d0b64ffc72ae7a6ceabc383d7b74ff9019ad857f8834d63606e38f34018b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5eca7d84385f06bc4fdb528eb76163908014551993b8fc77726c7db42c12f96',2009,'GS','South Georgia and the South Sandwich Islands','transportation',1142,'Ports and terminals: McMurdo, Palmer,
and offshore anchorages in Antarctica
note: few ports or harbors exist on
southern side of Southern Ocean; ice
conditions limit use of most to short
periods in midsummer; even then some
cannot be entered without icebreaker
escort; most Antarctic ports are operated
by government research stations and,
except in an emergency, are not open to
commercial or private vessels; vessels in
any port south of 60 degrees south are
subject to inspection by observers under
Article 7 of the Antarctic Treaty; The
Hydrographic Committee on Antarctica
(HCA), a special hydrographic commis¬
sion of International Hydrographic
Organization (IHO), is responsible for
hydrographic surveying and nautical
charting matters in Antarctic Treaty
area; it coordinates and facilitates provi¬
sion of accurate and appropriate charts
and other aids to navigation in support of
safety of navigation in region; member¬
ship of HCA is open to any IHO
Member State whose government has
acceded to the Antarctic Treaty and
which contributes resources and/or data
to IHO Chart coverage of the area;
members of HCA are Argentina,
Australia, Brazil, Chile, China, Ecuador,
France, Germany, Greece, India, Italy,
602','a7f6dfae4639bd5fe89c12dffb4bd2393549f496b57997846942f8c9bce737f3','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43a6c8c0edbfeebb4dc31909ede499957926969789a161d109f1250de1d18bfc',2009,'ES','Spain','transportation',1143,'NZ, Norway, Russia, South Africa,
Spain, UK, and US (2007)
Transportation— note: Drake Passage
offers alternative to transit through the
Panama Canal
Airports: 154 (2007)
Airports— with paved runways:
total: 96
over 3,047 m: 18
2,438 to 3,047 m: 11
1,524 to 2,437 m: 18
914 to 1 ,523 m: 25
under 914 m: 24 (2007)
Airports— with unpaved runways:
total: 58
1 ,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 42 (2007)
Heliports: 8 (2007)
Pipelines: gas 7,858 km; oil 622 km;
refined products 3,445 km (2007)
Railways:
total: 14,974 km
broad gauge: 11,919 km 1.668-m gauge
(6,950 km electrified)
standard gauge: 1,099 km 1.435-m gauge
(1,054 km electrified)
narrow gauge: 1,928 km 1.000-m gauge
(815 km electrified); 28 km 0.914-m
gauge (28 km electrified) (2006)
Roadways:
total: 666,292 km
paved: 659,629 km (includes 12,009 km
of expressways)
unpaved: 6,663 km (2003)
Waterways: 1,000 km (2003)
Merchant marine:
total: 167 ships (1000 GRT or over)
2,365,450 GRT/2,282,245 DWT
by type: bulk carrier 9, cargo 13, chemical
tanker 13, container 25, liquefied gas 10,
passenger 1, passenger/cargo 52, petro¬
leum tanker 15, refrigerated cargo 5, roll
on/roll off 17, specialized tanker 2,
vehicle carrier 5
foreign-owned: 33 (Cuba 1, Denmark 2,
Germany 9, Italy 1, Mexico 3, Norway 6,
US 9, Uruguay 2)
registered in other countries: 106 (Angola
1, Bahamas 11, Belize 2, Brazil 4, Cape
Verde 1, Cuba 1, Cyprus 7, Irland 1,
Malta 1, Marshall Islands 3, Nigeria 1,
Panama 61, Portugal 10, St Kitts and
Nevis 1, Venezuela 1) (2007)
Ports and terminals: Algeciras,
Barcelona, Bilbao, Cartagena, Fluelva,
Tarragona, Valencia','79f7dc9dfeaa790025df58c120a8d43d5780bf981cc920db144d852226a18d4e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d685eb1fc9a033a5f3bfee31c163fc46563741ced2468ea015c769cfd2daa90',2009,'LK','Sri Lanka','transportation',1154,'Airports: 18 (2007)
Airports— with paved runways:
total: 14
over 3,047 m: 1
1 ,524 to 2,437 m: 6
914 to 1,523 m: 7 (2007)
Airports— with unpaved runways:
total: 4
914 to 1,523 m: 1
under 914 m: 3 (2007)
Railways:
total: 1,449 km
broad gauge: 1,449 km 1.676-m gauge
(2006)
Roadways:
total: 97,287 km
paved: 78,802 km
unpaved: 18,485 km (2003)
Waterways: 160 km (primarily on rivers
in southwest) (2006)
Merchant marine:
total: 24 ships (1000 GRT or over)
162,280 GRT/227,478 DWT
by type: bulk carrier 2, cargo 18, con¬
tainer 2, petroleum tanker 2
foreign''Owned: 6 (Germany 6)
registered in other countries: 3 (Panama 3)
(2007)
Ports and terminals: Colombo','d94056c5083a968bfa130ae5ae9b580959ae773628e6fe6a940bc74c70a80bea','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7473b42d1e71cd582e49cd6e9b04fb13807d6c9212957b5d1e4fb9bae849426a',2009,'SD','Sudan','transportation',1160,'Airports: 101 (2007)
Airports— with paved runways:
total: 16
over 3,047 m: 2
2,438 to 3,047 m: 9
1 ,524 to 2,437 m: 4
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 85
over 3,047 m: 1
1 ,524 to 2,437 m: 20
914 to 1,523 m: 37
under 914 m: 27 (2007)
Heliports: 4 (2007)
Pipelines: gas 156 km; oil 4,070 km;
refined products 1,613 km (2007)
Railways:
total: 5,978 km
narrow gauge: 4,578 km 1.067-m gauge;
613
THE CIA WORLD FACTBOOK
1,400 km 0.600-m gauge for cotton plan¬
tations (2006)
Roadways:
total: 1 1,900 km
paved: 4,320 km
unpaved: 7,580 km (1999)
Waterways: 4,068 km (1,723 km open
year round on White and Blue Nile
rivers) (2006)
Merchant marine:
total: 3 ships (1000 GRT or over) 21,311
GRT/26,179 DWT
by type: cargo 2, livestock carrier 1
(2007)
Ports and terminals: Port Sudan
Military branches: Sudanese People’s
Armed Forces (SPAF): Land Forces,
Navy, Air Force, Popular Defense Forces;
Sudan People’s Liberation Army
(SPLA): Land Forces (2008)
Military service age and obligation:
18-30 years of age for compulsory mili¬
tary service; 2-year service obligation
(2006)
Manpower available for military
service:
males age 16-49: 9,639,923
females age 16-49: 9,321,106 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,586,468
females age 16-49: 5,678,427 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16—49: 488,679
females age 16-49: 469,547 (2008 est.)
Military expenditures— percent of
GDP: 3% (2005 est.)','3a33d44b5343cc0ca4adf60e541473d2a9076cadf87a63a5818ce1942a3dc70e','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1afae62410d742296e16a1969b3410976eb41598ed3da60efa34ff58d27d2dc1',2009,'SR','Suriname','transportation',1165,'Airports: 50 (2007)
Airports— with paved runways:
total: 5
over 3,047 m: 1
under 914 m: 4 (2007)
Airports— with unpaved runways:
total: 45
914 to 1 ,523 m: 5
under 914 m: 40 (2007)
Pipelines: oil 50 km (2007)
Roadways:
total: 4,304 km
paved: 1,130 km
unpaved: 3,174 km (2003)
Waterways: 1,200 km (most navigable
by ships with drafts up to 7 m) (2005)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,078
GRT/1,214 DWT
by type: cargo 1 (2007)
Ports and terminals: Paramaribo,
Wageningen
Airports: 4 (2007)
Airports — with paved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Airports— with unpaved runways:
total: 3
under 914 m: 3 (2007)
Heliports: 1 (2007)
Ports and terminals: Barentsburg,
Longyearbyen, Ny-Alesund, Pyramiden','b96835d7f83e81195e5eb9f8a8260a728f45c1ee2b9c4755b5dfc12fdaa1846d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e5d455ecec79943461c2d5d624b7e4579e1ac5b111c2bf8f54187990f8abba1',2009,'CH','Switzerland','transportation',1174,'Airports: 65 (2007)
Airports— with paved runways:
total: 42
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 12
914 to 1 ,523 m: 7
under 914 m: 16 (2007)
Airports— with unpaved runways:
total: 23
under 914 m: 23 (2007)
Heliports: 2 (2007)
Pipelines: gas 1,781 km; oil 94 km;
refined products 7 km (2007)
Railways:
total: 4,839 km
standard gauge: 3,561 km 1.435-m gauge
(3,195 km electrified)
narrow gauge: 1,268 km 1.000-m gauge
(1,274 km electrified); 10 km 0.800-m
gauge (10 km electrified) (2006)
Roadways:
total: 71,297 km
paved: 71,297 km (includes 1,728 of
expressways) (2004)
Waterways: 65 km (Rhine River
between Basel-Rheinfelden and
Schaffhausen-Bodensee) (2003)
Merchant marine:
total: 32 ships (1000 GRT or over)
577,765 GRT/918,974 DWT
by type: bulk carrier 13, cargo 8, chemical
tanker 4, container 6, specialized tanker
1
registered in other countries: 121 (Antigua
and Barbuda 5, Bahamas 2, Cyprus 3,
France 3, Indonesia 3, Italy 5, Liberia 11,
Malta 22, Marshall Islands 14, Panama
26, Paraguay 1, Portugal 2, Russia 6,
Singapore 2, St Vincent and The
Grenadines 12, Tonga 1, UK 1, Vanuatu
2) (2007)
Ports and terminals: Basel
Airports: 90 (2007)
Airports— with paved runways: total: 26
over 3,047 m: 6
2,438 to 3,047 m: 15
914 to 1,523 m: 3
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 64
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 52 (2007)
Heliports: 7 (2007)
Pipelines: gas 2,794 km; oil 2,000 km
(2007)
630
SYRIA
Railways:
total: 2,711 km
standard gauge: 2,460 km 1.435-m gauge
narrow gauge: 251 km 1.050-m gauge
(2006)
Roadways:
total: 94,890 km
paved: 19,073 km
unpaved: 75,817 km (2004)
Waterways: 900 km (not economically
significant) (2005)
Merchant marine:
total: 96 ships (1000 GRT or over)
353,351 GRT/512, 597 DWT
by type: bulk carrier 7, cargo 82, con¬
tainer 1, livestock carrier 4, petroleum
tanker 1 , roll on/roll off 1
foreigri''Owned: 10 (Jordan 2, Lebanon 4,
Romania 4)
registered in other countries: 164 (Bolivia
1, Cambodia 32, Comoros 8, Cyprus 2,
Dominica 2, Georgia 54, Hong Kong 1,
North Korea 7, Lebanon 1, Libya 1,
Malta 4, Mongolia 1, Panama 24, Sierra
Leone 8, Slovakia 2, St Kitts and Nevis
5, St Vincent and The Grenadines 11,
unknown 2) (2007)
Ports and terminals: Latakia, Tartus','4c63d3541107fe23a3ee1d63066145c68f0129410f7167253edffa31686b1c31','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f2e6bcc6c664c2f191acfe758bc63fa12990e9e4bfa41d71714a95eef7096cf',2009,'TJ','Tajikistan','transportation',1182,'Airports: 26 (2007)
Airports — with paved runways: total: 18
over 3,047 m: 2
2,438 to 3,047 m: 4
1 ,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 8
under 914 m: 8 (2007)
Pipelines: gas 549 km; oil 38 km (2007)
Railways: total: 482 km
broad gauge : 482 km 1.520-m gauge
(2006)
Roadways: total: 27,767 km (2000)
Waterways: 200 km (along Vakhsh
River) (2006)','3f5fa90de34db3b64de9a0e967602d275f133e2891acd1d76f10aa02f46b497b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf5d9db56de67242acf998ebf930dd8d9ed447072a754769408a588562810d3',2009,'TH','Thailand','transportation',1185,'Background: A unified Thai kingdom
was established in the mid- 14th century.
Known as Siam until 1939, Thailand is
the only Southeast Asian country never
to have been taken over by a European
power. A bloodless revolution in 1932
led to a constitutional monarchy. In
alliance with Japan during World War II,
Thailand became a US ally following the
conflict. Thailand is currently facing sep¬
aratist violence in its southern ethnic
Malay-Muslim provinces.
Location: Southeastern Asia, bordering
638
the Andaman Sea and the Gulf of
Thailand, southeast of Burma
Geographic coordinates: 15 00 N, 100
00 E
Map references: Southeast Asia
Area:
total: 514,000 sq km
land: 511,770 sq km
water: 2,230 sq km
Area— comparative: slightly more than
twice the size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1,800 km,
Cambodia 803 km, Laos 1,754 km,
Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the
depth of exploitation
Climate: tropical; rainy, warm, cloudy
southwest monsoon (mid-May to
September); dry, cool northeast mon¬
soon (November to mid-March);
southern isthmus always hot and humid
Terrain: central plain; Khorat Plateau in
the east; mountains elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural
gas, tungsten, tantalum, timber, lead,
fish, gypsum, lignite, fluorite, arable land
Land use: arable land: 27.54%
permanent crops: 6.93%
other: 65.53% (2005)
Irrigated land: 49,860 sq km (2003)
Total renewable water resources: 409.9
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 82.75 cu
km/yr (2%/2%/95%)
per capita: 1,288 cu m/yr (2000)
Natural hazards: land subsidence in
Bangkok area resulting from the deple¬
tion of the water table; droughts
Environment— current issues: air pollu¬
tion from vehicle emissions; water pollu¬
tion from organic and factory wastes;
deforestation; soil erosion; wildlife popu¬
lations threatened by illegal hunting
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Law of the Sea
Geography — note: controls only land
route from Asia to Malaysia and','5da3934fe2959dc3a0d0a0a0b7f77b41b5aa81535e5313975413738f1e0ab00b','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5380b27de283881614dbe7922854aec07d78fcbc39e0c17d9cc4dcda9a40a86',2009,'TL','Timor-Leste','transportation',1190,'Airports: 106 (2007)
Airports— with paved runways:
total: 65
over 3,047 m: 8
2,438 to 3,047 m: 11
1 ,524 to 2,437 m: 23
914 to 1,523 m: 17
under 914 m: 6 (2007)
Airports— with unpaved runways:
total: 41
1 ,524 to 2,437 m: 1
914 to 1,523 m: 12
under 914 m: 28 (2007)
Heliports: 3 (2007)
Pipelines: gas 4,381 km; refined prod¬
ucts 320 km (2007)
Railways:
total: 4,071 km
narrow gauge: 4,071 km 1.000-m gauge
(2006)
Roadways:
total: 57,403 km
paved: 56,542 km
unpaved: 861 km (2000)
Waterways: 4,000 km
note: 3,701 km navigable by boats with
drafts up to 0.9 m (2005)
Merchant marine:
total: 405 ships (1000 GRT or over)
2,640,857 GRT/4,043,938 DWT
by type: bulk carrier 53, cargo 140, chem¬
ical tanker 16, container 21, liquefied gas
30, passenger/cargo 9, petroleum tanker
101, refrigerated cargo 32, specialized
tanker 2, vehicle carrier 1
foreigri''owned: 15 (China 1, Japan 4,
Malaysia 3, Russia 1, Singapore 2,
Taiwan 1, UK 3)
registered in other countries: 34 (Bahamas
1, Indonesia 1, Mongolia 1, Panama 10,
Singapore 20, Tuvalu 1) (2007)
Ports and terminals: Bangkok, Laem
Chabang, Prachuap Port, Si Racha','bbf36e7cd969ae81541831a49a34253919e658a97f523435b93a1770763a25e5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('565b96bf42ece1cd783b3715ec52ca13021dc079c4f7d8401a390ac58e8bc3e8',2009,'TK','Tokelau','transportation',1198,'Airports: 9 (2007)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 2 (2007)
Airports— with unpaved runways:
total: 7
914 to 1,523 m: 4
under 914 m: 3 (2007)
Railways:
total: 568 km
narrow gauge: 568 km 1.000-m gauge
(2006)
Roadways:
total: 7,520 km
paved: 2,376 km
unpaved: 5,144 km (1999)
Waterways: 50 km (seasonally on Mono
River depending on rainfall) (2005)
Merchant marine:
total: 2 ships (1000 GRT or over) 3,918
GRT/3,852 DWT
by type: cargo 1, refrigerated cargo 1
(2007)
Ports and terminals: Kpeme, Lome
Military branches: Togolese Armed
Forces: Ground Forces, Togolese Navy
(Marine du Togo), Togolese Air Force
(Force Aerienne Togolaise, FAT),
National Gendarmerie (2008)
Military service age and obligation: 18
years of age for selective compulsory and
voluntary military service; 2-year service
obligation (2006)
Manpower available for military
service:
males age 16-49: 1,365,505
females age 16-49: 1,374,993 (2008 est.)
Manpower fit for military service:
males age 2 6 — 49: 897,195
females age 16—4 9: 913,327 (2008 est.)
Military expenditures— percent of
GDP: 1.6% (2005 est.)','542ccf57354d133ef3f11e5c772258d9dbcaf290db892a63f49dacc465de4c82','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ea09e1489641041f9f6566c9bc1a15f28d4dc705fbe1d8c8823e75299ceb618',2009,'TT','Trinidad and Tobago','transportation',1211,'Airports: 6 (2007)
Airports — with paved runways:
total: 1
2,438 to 3,047 m: 1 (2007)
Airports— with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1 ,523 m: 3
under 914 m: 1 (2007)
Roadways:
total: 680 km
paved: 184 km
unpaved: 496 km (1999)
Merchant marine:
total: 14 ships (1000 GRT or over)
58,756 GRT/67,889 DWT
by type: bulk carrier 1, cargo 9, liquefied
gas 1, livestock carrier 1, passenger/cargo
1 , refrigerated cargo 1
foreign-owned: 3 (Australia 1,
Switzerland 1, UK 1) (2007)
Ports and terminals: Nuku alofa','057136e31e288d02043353f10cb41f2aad98790bf5ee6bda8c8face24bd99ec8','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3e3bfc76a1b573ca199c35e558cabad8d45a5d31d504cdcd1a6f0f7ab0f6308',2009,'TN','Tunisia','transportation',1223,'Airports: 30 (2007)
Airports — with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1 ,523 m: 3 (2007)
Airports— with unpaved runways:
total: 16
1,524 to 2,437 m: 2
914 to 1 ,523 m: 7
under 914 m: 7 (2007)
Pipelines: gas 2,665 km; oil 1,235 km;
refined products 353 km (2007)
Railways:
total: 2,153 km
standard gauge: 471 km 1.435-m gauge
narrow gauge: 1,674 km 1.000-m gauge
(65 km electrified)
dual gauge: 8 km 1.435 m and 1.000-m
gauges (three rails) (2006)
Roadways:
total: 19,232 km
paved: 12,655 km (includes 262 km of
expressways)
unpaved: 6,577 km (2004)
Merchant marine:
total: 8 ships (1000 GRT or over)
130,475 GRT/91,013 DWT
by type: bulk carrier 1, cargo 1, chemical
tanker 2, passenger/cargo 4
foreign^ owned: 1 (Libya 1) (2007)
Ports and terminals: Bizerte, Gabes, La
Goulette, Rades, Sfax, Skhira
Military branches: Army, Navy,
Republic of Tunisia Air Force (Al-
Quwwat al-Jawwiya al-Jamahiriyah
At’tunisia) (2008)
Military service age and obligation: 20
years of age for compulsory military
service; conscript service obligation — 12
months; 18 years of age for voluntary
military service (2007)
Manpower available for military
service:
males age 16-49: 2,992,249
females age 16—49: 2,912,819 (2008 est.)
Manpower fit for military service:
males age 16—49: 2,539,962
females age 16-49: 2,465,295 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 101,794
females age 16—49: 95,198 (2008 est.)
Military expenditures— percent of
GDP: 1.4% (2006)
Airports: 117 (2007)
Airports — with paved runways:
total: 90
over 3,047 m: 15
2,438 to 3,047 m: 33
1,524 to 2,437 m: 19
914 to 1,523 m: 19
under 914 m: 4 (2007)
Airports— with unpaved runways:
total: 27
over 3,047 m: 1
1 ,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 17 (2007)
Heliports: 18 (2007)
Pipelines: gas 7,511 km; oil 3,636 km
(2007)
Railways:
total: 8,697 km
standard gauge: 8,697 km 1.435-m gauge
(1,920 km electrified) (2006)
660','62c543c0da3fb7a027bcf5f26ffdd431518a3aef9cdfe956cd7c71ecae5bac94','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1ecdff22d3e6939d247152da727222c4bfb30f51db16376d86f34bb38537361',2009,'TM','Turkmenistan','transportation',1228,'Roadways:
total: 426,906 km
paved: 177,550 km (includes 1,892 km of
expressways)
unpaved: 249,356 km (2004)
Waterways: 1,200 km (2005)
Merchant marine:
total: 565 ships (1000 GRT or over)
4,663,353 GRT/7,039,492 DWT
by type: bulk carrier 96, cargo 262, chem¬
ical tanker 58, combination ore/oil 1,
container 30, liquefied gas 7, passenger 4,
passenger/cargo 48, petroleum tanker 32,
refrigerated cargo 1, roll on/roll off 25,
specialized tanker 1
foreign''Otvned: 8 (China 1, Cyprus 2,
Germany 1, Italy 3, UAE 1)
registered in other countries: 470 (Albania
1, Antigua and Barbuda 7, Bahamas 5,
Belize 11, Cambodia 20, Comoros 8,
Cyprus 1, Dominica 9, Georgia 23, Isle of
Man 2, Italy 1, Kiribati 1, North Korea 1,
Liberia 7, Malta 143, Marshall Islands
41, Netherlands Antilles 12, Panama 53,
Russia 70, Sierra Leone 7, Slovakia 11,
St Kitts and Nevis 13, St Vincent and
The Grenadines 20, Tuvalu 1, UK 2,
unknown 3) (2007)
Ports and terminals: AUaga, Diliskelesi,
Izmir, Kocaeli (Izmit), Mercin Limani,
Nemrut Limani
Airports: 28 (2007)
Airports — with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 11
1 ,524 to 2,437 m: 8
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 6
1 ,524 to 2,437 m: 2
under 914 m: 4 (2007)
Heliports: 1 (2007)
Pipelines: gas 6,441 km; oil 1,361 km
(2007)
Railways:
total: 2,440 km
broad gauge: 2,440 km 1.520 -m gauge
(2006)
Roadways:
total: 24,000 km
paved: 19,488 km
unpaved: 4,512 km (1999)
Waterways: 1,300 km (Amu Darya and
Kara Kum canal important inland water¬
ways) (2006)
Merchant marine:
total: 8 ships (1000 GRT or over) 22,870
GRT/25,801 DWT
by type: cargo 4, combination ore/oil 1,
petroleum tanker 2, refrigerated cargo 1
(2007)
Ports and terminals: Turkmenbasy','ca74d3904fb55b5fa50f119a00a4969f293fff64a5c0854d1af1b8ebde7e736f','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b083b0f737ebf09cca60b972d790f88beda1e97aacf9daa5cd61332772254c4',2009,'TC','Turks and Caicos Islands','transportation',1242,'Airports: 8 (2007)
Airports— with paved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1 ,523 m: 1
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 2
under 914 m: 2 (2007)
Roadways:
total: 121 km
paved: 24 km
unpaved: 97 km (2003)
Merchant marine:
registered in other countries: 1 (Panama 1)
(2007)
Ports and terminals: Grand Turk,
Providenciales','3c95aa30ecd09fe29565369102ad9f5db5c05037428cf1723b8b952c3fd55ac5','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf975cd35b8bbd04922531420f5d67f71f110d9e2722c8d7af000323ffd63c3a',2009,'TV','Tuvalu','transportation',1248,'Airports: 1 (2007)
Airports — with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2007)
Roadways:
total: 8 km
paved: 8 km (2002)
Merchant marine:
total: 74 ships (1000 GRT or over)
568,759 GRT/928,697 DWT
by type: bulk carrier 4, cargo 45, chemical
tanker 5, container 2, passenger 2, pas-
senger/cargo 1, petroleum tanker 13,
refrigerated cargo 1, specialized tanker 1
foreign''Owned: 61 (China 25, Hong Kong
10, Kenya 1, Maldives 1, Romania 1,
Russia 4, Singapore 13, Thailand 1,
Turkey 1, US 1, Vietnam 3) (2007)
Ports and terminals: Funafuti','82d031339e3726d0daa05a5a2507dd773ea40762853d18f9e2374bf6a28d9707','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('360f35b20af1366f71eeb86250010e73230d0c5c5f2b45bee02f76b1baba1c62',2009,'UA','Ukraine','transportation',1258,'Airports: 32 (2007)
Airports— with paved runways:
total: 5
over 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 27
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 9 (2007)
Railways:
total: 1,244 km
the first eastern Slavic state, Kyivan Rus,
which during the 10th and 11th cen¬
turies was the largest and most powerful
narrow gauge: 1,244 km 1.000-m gauge
(2006)
Roadways:
total: 70,746 km
paved: 16,272 km
unpaved: 54,474 km (2003)
Waterways: on Lake Victoria, 200 km
on Lake Albert, Lake Kyoga, and parts of
Albert Nile (2005)
Ports and terminals: Entebbe, Jinja,
Port Bell','506e82dfb4ad790ebe115ed5dd789cb5cf8eeae4a111142ab56505e89e32bf80','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e6312c72c5b56fafc18a87ac6faa43a14fd5aad640eecc0b6fe79f69bf5bc6',2009,'AE','United Arab Emirates','transportation',1262,'Airports: 437 (2007)
Airports — with paved runways:
total: 193
over 3,047 m: 13
2,438 to 3,047 m: 53
1,524 to 2,437 m: 27
914 to 1 ,523 m: 5
under 914 m: 95 (2007)
Airports— with unpaved runways:
total: 244
2,438 to 3,047 m: 3
I , 524 to 2,437 m: 11
914 to 1,523 m: 13
under 914 m: 217 (2007)
Heliports: 10 (2007)
Pipelines: gas 33,721 km; oil 4,514 km;
refined products 4,211 km (2007)
Railways:
total: 22,473 km
broad gauge: 22,473 km 1.524-m gauge
(9,250 km electrified) (2006)
Roadways:
total: 169,477 km
paved: 164,732 km (includes 15 km of
expressways)
unpaved: 4,745 km (2004)
Waterways: 2,253 km (most on Dnieper
River) (2006)
Merchant marine:
total: 193 ships (1000 GRT or over)
763,293 GRT/899,859 DWT
by type: bulk carrier 6, cargo 145, con¬
tainer 3, passenger 6, passenger/cargo 4,
petroleum tanker 9, refrigerated cargo
II, roll on/roll off 7, specialized tanker 2
registered in other countries: 194 (Belize
10, Cambodia 27, Comoros 13, Cyprus 6,
Dominica 3, Georgia 24, Liberia 24,
Malta 28, Moldova 3, Mongolia 3,
Panama 8, Russia 10, Sierra Leone 8,
Slovakia 10, St Kitts and Nevis 5, St
Vincent and The Grenadines 12,
unknown 3) (2007)
Ports and terminals: Feodosiya, Kerch,
Kherson, Mariupol’, Mykolayiv, Odesa,
Yuzhnyy
Airports: 39 (2007)
Airports— with paved runways:
total: 22
over 3,047 m: 10
2,438 to 3,047 m: 3
1 ,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m: 5 (2007)
Heliports: 5 (2007)
Pipelines: condensate 520 km; gas 2,908
km; liquid petroleum gas 300 km; oil
2,950 km; oil/gas/water 5 km; refined
products 156 km (2007)
Roadways: total: 1,088 km
paved: 1,088 km (includes 253 km of
expressways) (1999)
Merchant marine:
total: 60 ships (1000 GRT or over)
617,519 GRT/858, 5 19 DWT
by type: bulk carrier 6, cargo 10, chemical
tanker 5, container 6, liquefied gas 1,
passenger/cargo 1, petroleum tanker 25,
roll on/roll off 5, specialized tanker 1
foreign''Owned: 11 (Greece 3, Kuwait 8)
registered in other countries: 281 (Bahamas
20, Belize 4, Cambodia 2, Comoros 5,
Cyprus 10, Georgia 1, Gibraltar 2, Hong
Kong 1, India 2, Iran 1, Jordan 15, North
Korea 4, Liberia 22, Malta 10, Marshall
Islands 14, Mexico 1, Mongolia 5,
Norway 1, Panama 108, Philippines 1,
Saudi Arabia 1, Sierra Leone 7,
Singapore 8, Somalia 1, St Kitts and
Nevis 22, St Vincent and The
Grenadines 12, Turkey 1, unknown 5)
(2007)
Ports and terminals: Mina’ Zayid (Abu
Dhabi), A1 Fujayrah, Mina’ Jabal ‘Ali
(Dubai), Mina’ Rashid (Dubai), Mina’
Saqr (Ra’s al Khaymah), Khawr Fakkan
(Sharjah)
Military branches: United Arab
Emirates Armed Forces: Army, Navy
(includes Marines), Air Force and Air
Defense, National Coast Guard (2008)
Military service age and obligation: 18
years of age (est.) for voluntary military
service; 18 years of age for officers and
women; no conscription (2008)
Manpower available for military
service:
males age 16-49: 2,405,884 (includes
non-nationals)
females age 16^\\ 9: 884,853 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,004,558
females age 16-49: 760,637 (2008 est.)
Manpower reaching militarily signifi¬
cant age annually:
males age 16-49: 25,856
females age 16-49: 23,085 (2008 est.)
Military expenditures— percent of
GDP: 3.1% (2005 est.)','bc9603ea0c7f3e210157e654a918c734d709ca6f7a1b1514d7082176a6a27731','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464bf5e5540866957d56be7278643a10e76d9df2b8ca70cff9b25fe54f3502e1',2009,'GB','United Kingdom','transportation',1271,'Airports: 449 (2007)
Airports — with paved runways:
total: 310
over 3,047 m: 8
2,438 to 3,047 m: 33
1 ,524 to 2,437 m: 131
914 to 1,523 m: 79
under 914 m: 59 (2007)
Airports — with unpaved runways:
total: 139
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 2
914 to 1,523 m: 23
under 914 m: 113 (2007)
Heliports: 11 (2007)
Pipelines: condensate 567 km; conden¬
sate/gas 22 km; gas 18,980 km; liquid
petroleum gas 59 km; oil 4,930 km;
oil/gas/water 165 km; refined products
4,444 km (2007)
Railways: total. 16,567 km
broad gauge: 303 km 1.600-m gauge (in
Northern Ireland)
standard gauge: 16,264 km 1.435-m gauge
(5,361 km electrified) (2006)
Roadways:
total: 388,008 km
paved: 388,008 km (includes 3,520 km of
expressways) (2005)
Waterways: 3,200 km (620 km used for
commerce) (2003)
Merchant marine:
total: 474 ships (1000 GRT or over)
1 1,723,618 GRT/12,315,588 DWT
by type: bulk carrier 26, cargo 60, carrier
4, chemical tanker 56, container 156,
liquefied gas 18, passenger 10, pas¬
senger/cargo 62, petroleum tanker 27,
refrigerated cargo 17, roll on/roll off 24,
vehicle carrier 14
foreign''Owned: 242 (Australia 1, Cyprus
1, Denmark 61, Finland 1, France 9,
Germany 71, Greece 6, Flong Kong 2,
Ireland 1, Italy 4, Japan 1, Netherlands 2,
NZ 1, Norway 33, South Africa 4,
Sweden 19, Switzerland 1, Taiwan 11,
Turkey 2, US 11)
registered in other countries: 412 (Algeria
12, Antigua and Barbuda 4, Argentina 4,
Australia 2, Bahamas 68, Barbados 3,
Bermuda 20, Brunei 8, Cape Verde 1,
Cayman Islands 9, Cyprus 21, Faroe
Islands 1, Gibraltar 3, Greece 15, Hong
Kong 32, India 1, Indonesia 3, Italy 7,
South Korea 1, Liberia 74, Luxembourg
7, Malta 12, Marshall Islands 17,
Netherlands 7, Norway 9, Panama 35,
Papua New Guinea 6, Singapore 13,
Slovakia 1, St Vincent and The
Grenadines 9, Sweden 2, Thailand 3,
Tonga 1, US 1, unknown 1) (2007)
Ports Olid terminals: Dover, Felixstowe,
Immingham, Liverpool, London,
Southampton, Teesport (England), Forth
Ports, Hound Point (Scotland), Milford
Haven (Wales)','4a8da64bc4266921f45943fce63b9868123e537bd7c003f040dfa5f009387015','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('694f6b839d854f5594c980d65295d26b1bcd22d3cfe1c1b830214fe4b7f9a589',2009,'UY','Uruguay','transportation',1281,'Airports: 60 (2007)
Airports— with paved runways:
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 2 (2007)
Airports— with unpaved runways:
total: 51
1,524 to 2,437 m: 3
914 to 1,523 m: 19
under 914 m: 29 (2007)
Pipelines: gas 257 km; oil 160 km
(2007)
Railways:
total: 2,073 km
standard gauge: 2,073 km 1.435-m gauge
note: 461 km have been taken out of
service and 460 km are in partial use
(2006)
Roadways:
total: 77,732 km
paved: 7,743 km
unpaved: 69,989 km (2004)
Waterways: 1,600 km (2005)
Merchant marine:
total: 14 ships (1000 GRT or over)
36,041 GRT/22,274 DWT
by type: cargo 2, chemical tanker 2, pas-
senger/cargo 7, petroleum tanker 2, roll
on/roll off 1
foreign- owned: 4 (Argentina 3, Greece 1)
registered in other countries: 7 (Argentina
1, Bahamas 1, Liberia 3, Spain 2) (2007)
Ports and terminals: Montevideo','1f5e04306b85e2d3efc70879ccf571c69aa98aeb0c3bc2072a96c583e35b0417','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4677ab7ce8841e5f983c3f26cb571bfbdc9877c621fda011a6c9b492221571e',2009,'UZ','Uzbekistan','transportation',1287,'Airports: 54 (2007)
Airports— with paved runways:
total: 33
over 3,047 m: 6
2,438 to 3,047 m: 13
1 ,524 to 2,437 m: 5
914 to 1 ,523 m: 5
under 914 m: 4 (2007)
Airports— with unpaved runways:
total: 21
2,438 to 3,047 m: 2
under 914 m: 19 (2007)
Pipelines: gas 9,725 km; oil 868 km
(2007)
Railways:
total: 3,950 km
broad gauge: 3,950 km 1.520-m gauge
(620 km electrified) (2006)
Roadways: total: 81,600 km
paved: 71,237 km
unpaved: 10,363 km (1999)
Waterways: 1,100 km (2006)
Ports and terminals: Termiz (Amu
Darya)','e2fa954b5987adf142d3be7d495cd1fb44c208162f38d6619507478b2a10b493','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4c6342ccd5f7c1d027aa24cd2ab6d3ade13b32ab794911a4358c140b8d5b881',2009,'VU','Vanuatu','transportation',1290,'Airports: 31 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1 ,524 to 2,437 m: 1
914 to 1,523 m: 1 (2007)
Airports— with unpaved runways:
total: 28
914 to 1 ,523 m: 6
under 914 m: 22 (2007)
Roadways:
total: 1,070 km
paved: 256 km
unpaved: 814 km (1999)
Merchant marine:
total: 51 ships (1000 GRT or over)
1,346,001 GRT/1,901,055 DWT
by type: bulk carrier 30, cargo 8, con¬
tainer 1, liquefied gas 2, petroleum
tanker 1, refrigerated cargo 3, roll on/roll
off 1 , vehicle carrier 5
foreign''Owned: 51 (Australia 2, Belgium
4, Canada 5, Estonia 1, Japan 28, Poland
7, Russia 1, Switzerland 2, US 1) (2007)
Ports and terminals: Forari, Port-Vila,
Santo (Espiritu Santo)','055a3ca5dd6c0a0f0a84be037659d8280569f0da426a76fd356671b3f39689e1','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91c78a81322015b539c851c350f748701e510b937f3bdcbd44f1009f89ae0257',2009,'EH','Western Sahara','transportation',1305,'Airports: 9 (2007)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 3 (2007)
Airports— with unpaved runways:
total: 6
1 ,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (2007)
Ports and terminals: Ad Dakhla, Cabo
Bojador, Laayoune (El Aaiun)','4c093a4df63d3e7ad85e1b28b983cd05586602f18740f2861f1976898f72f79a','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2522bcc1655db26fa0c80c752d0c1c73974d994b0e1c8500c33e62406a126800',2009,'YE','Yemen','transportation',1306,'Airports: 50 (2007)
Airports— with paved runways:
total: 17
over 3,047 m: 4
2,438 to 3,047 m: 8
1 ,524 to 2,437 m: 3
914 to 1 ,523 m: 1
under 914 m: 1 (2007)
Airports— with unpaved runways:
total: 33
over 3,047 m: 3
2,438 to 3,047 m: 8
1 ,524 to 2,437 m: 5
914 to 1 ,523 m: 13
under 914 m: 4 (2007)
Pipelines: gas 71 km; liquid petroleum
gas 22 km; oil 1,309 km (2007)
Roadways:
total: 71,300 km
paved: 6,200 km
unpaved: 65,100 km (2005)
Merchant marine:
total: 4 ships (1000 GRT or over) 15,474
GRT/18,072 DWT
by type: cargo 1, chemical tanker 1,
petroleum tanker 1 , roll on/roll off 1
registered in other countries: 12 (Bolivia 1,
Cambodia 3, North Korea 2, Panama 5,
St Kitts and Nevis 1) (2007)
Ports and terminals: Aden, Hudaydah,
Mukalla','e1fa3561c20348b9ce366f6970d833f3984e2235075e4497d39836936ed1bc2d','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83866b29bf4a6c6df247132f8b2b92628e5283e1be22bb4df370a029a0b2c0e9',2009,'ZM','Zambia','transportation',1313,'Airports: 107 (2007)
Airports— with paved runways:
total: 9
over 3,047 m: 1
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 4
914 to 1,523 m: 2 (2007)
Airports— with unpaved runways:
total: 98
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1 ,523 m: 64
under 914 m: 29 (2007)
Pipelines: oil 771 km (2007)
Railways:
total: 2,157 km
narrow gauge: 2,157 km 1.067-m gauge
note: includes 891 km of the Tanzania-
Zambia Railway Authority (TAZARA)
(2006)
Roadways: total: 91,440 km
paved: 20,1 17 km
unpaved: 71,323 km (2001)
Waterways: 2,250 km (includes Lake
Tanganyika and the Zambezi and
Luapula rivers) (2005)
Ports and terminals: Mpulungu','699041d35fa93f20be5011190f8c30e27c72d4bf147054bc5317d1dcfcdabdde','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e57c8650bda167e8dd8a591b225ad7285d66c4208892b1c107a5fd79b892703',2009,'ZW','Zimbabwe','transportation',1325,'Airports: 341 (2007)
Airports— with paved runways:
total: 19
over 3,047 m: 3
2,438 to 3,047 m: 2
1 ,524 to 2,437 m: 4
914 to 1,523 m: 10 (2007)
Airports— with unpaved runways:
total: 322
1 ,524 to 2,437 m: 4
914 to 1 ,523 m: 152
under 914 m: 166 (2007)
Pipelines: refined products 270 km
(2007)
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge
(313 km electrified) (2006)
Roadways:
total: 97,440 km
paved: 18,514 km
unpaved: 78,926 km (2002)
Waterways: on Lake Kariba (2005)
Ports and terminals: Binga, Kariba
Airports: 41 (2007)
Airports — with paved runways:
total: 38
over 3,047 m: 8
2,438 to 3,047 m: 9
1,524 to 2,437 m: 11
9 14 to 1,523 m: 7
under 914 m: 3 (2007)
Airports— with unpaved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2007)
Heliports: 4 (2007)
Pipelines: condensate 25 km; gas 661
km (2007)
Railways:
total: 1,588 km
standard gauge: 345 km 1.435 -m gauge
narrow gauge: 1,093 km 1.067-m gauge
note: 150 km .762-m gauge (belonging
primarily to Taiwan Sugar Corporation
and Taiwan Forestry Bureau; some to
other entities) (2007)
Roadways:
total: 40,262 km
paved: 38,171 km (includes 976 km of
expressways)
unpaved: 2,091 km (2007)
Merchant marine:
total: 102 ships (1000 GRT or over)
2,537,256 GRT/4,203,423 DWT
by type: bulk carrier 33, cargo 20, chem¬
ical tanker 2, container 21, pas-
senger/cargo 2, petroleum tanker 15,
refrigerated cargo 7, roll on/roll off 2
foreign-owned: 4 (Canada 3, France 1)
registered in other countries: 489 (Bahamas
1, Bolivia 1, Cambodia 1, Honduras 2,
Hong Kong 11, Indonesia 2, Italy 11,
Fiberia 82, Panama 306, Singapore 60,
Thailand 1, UK 11, unknown 3) (2007)
Ports and terminals: Chilung
(Keelung), Kaohsiung, Taichung
\\
Airports: 3,393 (2006)
Airports— with paved runways:
total: 1,991
over 3 ,047m: 110
2,438 to 3,047m: 347
1,524 to 2,437m: 545
914 to 1,523m: 420
under 914m: 569 (2007)
Airports— with unpaved runways:
total: 1,373
over 3,047m: 2
2,438 to 3,047m: 5
1,524 to 2,437m: 30
9 14m to 1 ,523m: 267
under 914m: 1,043 (2007)
Heliports: 100 (2007)
Railways: total: 236,436 km
broad gauge: 28,250 km
standard gauge: 200,401 km
narrow gauge: 7,771 km
other: 23 km (2007)
Roadways:
total: 5,269,163 km (includes 56,555 km
of expressways)
paved: 4,465,493 km
unpaved: 803,670 km (2006)
Waterways: 52,332 km (2006)
Ports and terminals: Antwerp
(Belgium), Barcelona (Spain), Braila
(Romania), Bremen (Germany), Burgas
(Bulgaria), Constanta (Romania),
Copenhagen (Denmark), Galati
(Romania), Gdansk (Poland), Hamburg
(Germany), Helsinki (Finland), Las
Palmas (Canary Islands, Spain), Le
Havre (France), Lisbon (Portugal),
London (UK), Marseille (France),
Naples (Italy), Peiraiefs or Piraeus
(Greece), Riga (Latvia), Rotterdam
(Netherlands), Stockholm (Sweden),
Talinn (Estonia), Tulcea (Romania),
Varna (Bulgaria)','1682ae9112127aa4638fbd1f6b445d232ecead79396219257106181b1fecfd39','internet-archive','ciaworldfactbook0000unit_t5b5','txt','045392c53029df153dbd5a0a2fbfed30205357353cc0846fb8cf0bbc2cdf67e9','https://archive.org/download/ciaworldfactbook0000unit_t5b5/ciaworldfactbook0000unit_t5b5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('323d6e56ed38576e34e90f175ef48973ec746c57e46019475e5bcba2184d4d9f',2009,'','','transportation',7,'Airports:
Airports - with paved runways:
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,530 m
under 914 m
Airports - with unpaved runways:
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,530 m
under 914 m
Heliports:
Pipelines:
Railways:
total
broad gauge
standard gauge
narrow gauge
dual gauge
Roadways:
total
paved
unpaved
Waterways:
Merchant marine:
total
ships by type
foreign-owned
registered in other countries
Ports and terminals :
Transportation - note:','9a8ae220f97e5ae4240d55cd036a5bce0e54f6b2495140203b6e4341923a28f0','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3baab5e22a5d33611cf4cf3c3c0ee57fd9d4ec51cf669cbfcd0dbdadac24b1fa',2009,'TC','Turks and Caicos Islands','transportation',31,'This category includes the entries dealing with the means for
movement of people and goods.
Transportation - note
This entry includes miscellaneous transportation information of
significance not included elsewhere.
U
UTC (Coordinated Universal Time)
See entry for Coordinated Universal Time.
Unemployment rate
This entry contains the percent of the labor force that is without
jobs. Substantial underemployment might be noted.
Urbanization
This entry provides two measures of the degree of urbanization of a
population. The first, urban population, describes the percentage of
the total population living in urban areas, as defined by the
country. The second, rate of urbanization, describes the projected
average rate of change of the size of the urban population over the
given period of time. Additionally, the World entry includes a list
of the ten largest urban agglomerations. An urban agglomeration is
defined as comprising the city or town proper and also the suburban
fringe or thickly settled territory lying outside of, but adjacent
to, the boundaries of the city.
W
Waterways
This entry gives the total length of navigable rivers, canals, and
other inland bodies of water.
Weights and Measures
This information is presented in This information is presented in <a
href = "../appendix/appendix-g.html"Appendix G: Weights and Measures
and includes mathematical notations (mathematical powers and names),
metric interrelationships (prefix; symbol; length, weight, or
capacity; area; volume), and standard conversion factors.
Y
Years
All year references are for the calendar year (CY) unless indicated
as fiscal year (FY). The calendar year is an accounting period of 12
months from 1 January to 31 December. The fiscal year is an
accounting period of 12 months other than 1 January to 31 December.
Note: Information for the US and US dependencies was complied from
material in the public domain and does not represent Intelligence
Community estimates.
======================================================================
CIA - The World Factbook -- About :: History
A Brief History of Basic Intelligence and The World Factbook
The Intelligence Cycle is the process by which information is
acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data that may
be fragmentary, contradictory, unreliable, ambiguous, deceptive, or
wrong. Intelligence is information that has been collected,
integrated, evaluated, analyzed, and interpreted. Finished
intelligence is the final product of the Intelligence Cycle ready to
be delivered to the policymaker.
The three types of finished intelligence are: basic, current, and
estimative. Basic intelligence provides the fundamental and factual
reference material on a country or issue. Current intelligence
reports on new developments. Estimative intelligence judges probable
outcomes. The three are mutually supportive: basic intelligence is
the foundation on which the other two are constructed; current
intelligence continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of country
and issue prospects for guidance of basic and current intelligence.
The World Factbook, The President''s Daily Brief, and the National
Intelligence Estimates are examples of the three types of finished
intelligence.
The United States has carried on foreign intelligence activities
since the days of George Washington but only since World War II have
they been coordinated on a government-wide basis. Three programs
have highlighted the development of coordinated basic intelligence
since that time: (1) the Joint Army Navy Intelligence Studies
(JANIS), (2) the National Intelligence Survey (NIS), and (3)The
World Factbook .
During World War II, intelligence consumers realized that the
production of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought
home to leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers. Detailed
and coordinated information was needed not only on such major powers
as Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and Marines
had to launch amphibious operations against many islands about which
information was unconfirmed or nonexistent. Intelligence authorities
resolved that the United States should never again be caught
unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office of
Naval Intelligence - ONI), and Gen. William J. Donovan (Director of
the Office of Strategic Services - OSS) decided that a joint effort
should be initiated. A steering committee was appointed on 27 April
1943 that recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish the
Joint Army Navy Intelligence Studies (JANIS). JANIS was the first
interdepartmental basic intelligence program to fulfill the needs of
the US Government for an authoritative and coordinated appraisal of
strategic basic intelligence. Between April 1943 and July 1947, the
board published 34 JANIS studies. JANIS performed well in the war
effort, and numerous letters of commendation were received,
including a statement from Adm. Forrest Sherman, Chief of Staff,
Pacific Ocean Areas, which said, "JANIS has become the indispensable
reference work for the shore-based planners."
The need for more comprehensive basic intelligence in the postwar
world was well expressed in 1946 by George S. Pettee, a noted author
on national security. He wrote in The Future of American Secret
Intelligence (Infantry Journal Press, 1946, page 46) that world
leadership in peace requires even more elaborate intelligence than
in war. "The conduct of peace involves all countries, all human
activities - not just the enemy and his war production."
The Central Intelligence Agency was established on 26 July 1947 and
officially began operating on 18 September 1947. Effective 1 October
1947, the Director of Central Intelligence assumed operational
responsibility for JANIS. On 13 January 1948, the National Security
Council issued Intelligence Directive (NSCID) No. 3, which
authorized the National Intelligence Survey (NIS) program as a
peacetime replacement for the wartime JANIS program. Before adequate
NIS country sections could be produced, government agencies had to
develop more comprehensive gazetteers and better maps. The US Board
on Geographic Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the maps.
The Hoover Commission''s Clark Committee, set up in 1954 to study the
structure and administration of the CIA, reported to Congress in
1955 that: "The National Intelligence Survey is an invaluable
publication which provides the essential elements of basic
intelligence on all areas of the world. There will always be a
continuing requirement for keeping the Survey up-to-date." The
Factbook was created as an annual summary and update to the
encyclopedic NIS studies. The first classified Factbook was
published in August 1962, and the first unclassified version was
published in June 1971. The NIS program was terminated in 1973
except for the Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with sales
through the US Government Printing Office (GPO). The Factbook was
first made available on the Internet in June 1997. The year 2009
marks the 62nd anniversary of the establishment of the Central
Intelligence Agency and the 66th year of continuous basic
intelligence support to the US Government by The World Factbook and
its two predecessor programs.
The Evolution of The World Factbook
National Basic Intelligence Factbook produced semiannually until
1980. Country entries include sections on Land, Water, People,
Government, Economy, Communications, and Defense Forces.
1981
Publication becomes an annual product and is renamed The World
Factbook. A total of 165 nations are covered on 225 pages.
1983
Appendices (Conversion Factors, International Organizations) first
introduced.
1984
Appendices expanded; now include: A. The United Nations, B. Selected
United Nations Organizations, C. Selected International
Organizations, D. Country Membership in Selected Organizations, E.
Conversion Factors.
1987
A new Geography section replaces the former separate Land and Water
sections. UN Organizations and Selected International Organizations
appendices merged into a new International Organizations appendix.
First multi-color-cover Factbook.
1988
More than 40 new geographic entities added to provide complete world
coverage without overlap or omission. Among the new entities are
Antarctica, oceans (Arctic, Atlantic, Indian, Pacific), and the
World. The front-of-the-book explanatory introduction expanded and
retitled to Notes, Definitions, and Abbreviations. Two new
Appendices added: Weights and Measures (in place of Conversion
Factors) and a Cross-Reference List of Geographic Names. Factbook
size reaches 300 pages.
1989
Economy section completely revised and now includes an Overview
briefly describing a country''s economy. New entries added under
People, Government, and Communications.
1990
The Government section revised and considerably expanded with new
entries.
1991
A new International Organizations and Groups appendix added.
Factbook size reaches 405 pages.
1992
Twenty new successor state entries replace those of the Soviet Union
and Yugoslavia. New countries are respectively: Armenia, Azerbaijan,
Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; and Bosnia and Hercegovina, Croatia, Macedonia, Serbia
and Montenegro, Slovenia. Number of nations in the Factbook rises to
188.
1993
Czechoslovakia''s split necessitates new Czech Republic and Slovakia
entries. New Eritrea entry added after it secedes from Ethiopia.
Substantial enhancements made to Geography section.
1994
Two new appendices address Selected International Environmental
Agreements. The gross domestic product (GDP) of most developing
countries changed to a purchasing power parity (PPP) basis rather
than an exchange rate basis. Factbook size up to 512 pages.
1995
The GDP of all countries now presented on a PPP basis. New appendix
lists estimates of GDP on an exchange rate basis. Communications
category split; Railroads, Highways, Inland waterways, Pipelines,
Merchant marine, and Airports entries now make up a new
Transportation category. The World Factbook is first produced on
CD-ROM.
1996
Maps accompanying each entry now present more detail. Flags also
introduced for nearly all entities. Various new entries appear under
Geography and Communications. Factbook abbreviations consolidated
into a new Appendix A. Two new appendices present a Cross-Reference
List of Country Data Codes and a Cross-Reference List of
Hydrogeographic Data Codes. Geographic coordinates added to Appendix
H, Cross-Reference List of Geographic Names. Factbook size expands
by 95 pages in one year to reach 652.
1997
A special edition for the CIA''s 50 th anniversary. A schema or Guide
to Country Profiles introduced. New color maps and flags now
accompany each country profile. Category headings distinguished by
shaded backgrounds. Number of categories expanded to nine -- the
current number -- with the addition of an Introduction (for only a
few countries) and Transnational Issues (which includes
Disputes-international and Illicit drugs). The World Factbook
introduced onto the Internet.
1998
The Introduction category with two entries, Current issues and
Historical perspective, expanded to more countries. Last year for
the production of CD-ROM versions of the Factbook.
1999
Historical perspective and Current issues entries in the
Introduction category combined into a new Background statement.
Several new Economy entries introduced. A new physical map of the
world added to the back-of-the-book reference maps.
2000
A new "country profile" added on the Southern Ocean. The Background
statements dramatically expanded to over 200 countries and
possessions. A number of new Communications entries added.
2001
Background entries completed for all 267 entities in the Factbook.
Several new HIV/AIDS entries introduced under the People category.
Revision begun on individual country maps to include elevation
extremes and a partial geographic grid. Weights and Measures
appendix deleted.
2002
New entry on Distribution of Family income -- Gini index added.
Revision of individual country maps continued (process still
ongoing).
2003
In the Economy category, petroleum entries added for oil production,
consumption, exports, imports, and proved reserves, as well as
natural gas proved reserves.
2004
Additional petroleum entries included for natural gas production,
consumption, exports, and imports. In the Transportation category,
under Merchant marine, subfields added for foreign-owned vessels and
those registered in other countries. Descriptions of the many forms
of government mentioned in the Factbook incorporated into the
Definitions and Notes.
2005
In the People category, a Major infectious diseases field added for
countries deemed to pose a higher risk for travelers. In the Economy
category, entries included for Current account balance, Investment,
Public debt, and Reserves of foreign exchange and gold. The
Transnational issues category expanded to include Refugees and
internally displaced persons. Category headings receive distinctive
colored backgrounds. These distinguishing colors are used in both
the printed and online versions of the Factbook. Size of the printed
Factbook reaches 702 pages.
2006
In the Economy category, national GDP figures now presented at
Official Exchange Rates (OER) in addition to GDP at purchasing power
parity (PPP). Entries in the Transportation section reordered;
Highways changed to Roadways, and Ports and harbors to Ports and
terminals.
2007
In the Government category, the Capital entry significantly expanded
with up to four subfields, including new information having to do
with time. The subfields consist of the name of the capital itself,
its geographic coordinates, the time difference at the capital from
coordinated universal time (UTC), and, if applicable, information on
daylight saving time (DST). Where appropriate, a special note is
added to highlight those countries with multiple time zones. A
Trafficking in persons entry added to the Transnational issues
category. A new appendix, Weights and Measures, (re)introduced to
the online version of the Factbook.
2008
In the Geography category, two fields focus on the increasingly
vital resource of water: Total renewable water resources and
Freshwater withdrawal. In the Economy category, three fields added
for: Stock of direct foreign investment - at home, Stock of direct
foreign investment - abroad, and Market value of publicly traded
shares. Concise descriptions of the major religions mentioned in the
Factbook included in the Definitions and Notes. Printing of the
Factbook turned over to the Government Printing Office.
2009
In the People category, two new fields provide information on
education in terms of opportunity and resources: School Life
Expectancy and Education expenditures. Additionally, the
Urbanization entry expanded to include all countries. In the Economy
category, five fields added: Central bank discount rate, Commercial
bank prime lending rate, Stock of money, Stock of quasi money, and
Stock of domestic credit. The online Factbook site completely
redesigned with many new features.
======================================================================
About :: Copyright and Contributors
The World Factbook is prepared by the Central Intelligence Agency for
the use of US Government officials, and the style, format, coverage,
and content are designed to meet their specific requirements.
Information is provided by Antarctic Information Program (National
Science Foundation), Armed Forces Medical Intelligence Center
(Department of Defense), Bureau of the Census (Department of
Commerce), Bureau of Labor Statistics (Department of Labor), Central
Intelligence Agency, Council of Managers of National Antarctic
Programs, Defense Intelligence Agency (Department of Defense),
Department of Energy, Department of State, Fish and Wildlife Service
(Department of the Interior), Maritime Administration (Department
of Transportation), National Geospatial-Intelligence Agency
(Department of Defense), Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs (Department of
the Interior), Office of Naval Intelligence (Department of Defense),
US Board on Geographic Names (Department of the Interior), US
Transportation Command (Department of Defense), Oil & Gas Journal,
and other public and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA).
The official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Citation model:
The World Factbook 2009. Washington, DC: Central Intelligence Agency,
2009.
https://www.cia.gov/library/publications/the-world-factbook/index.html
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn: Office of Public Affairs
Washington, DC 20505
Hours: Monday-Friday 8:00 AM-4:30 PM Eastern Standard Time
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
======================================================================
About :: Purchasing
Printed copies of The World Factbook may be obtained from the following:
US Government Printing Office
732 N. Capitol St.
Washington, DC 20401
Hours: Monday-Friday 7:00 AM-6:30 PM Eastern Standard Time (EST)
Telephone: [1] (202) 512-1800; toll free: [1] (866) 512-1800
FAX: [1] (202) 512-2104
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Hours: Monday-Friday 8:00 AM-6:00 PM Eastern Standard Time (EST)
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
https://www.cia.gov/library/publications/the-world-factbook/index.html
CIA - The World Factbook -- Frequently Asked Questions
Answers to many frequently asked questions (FAQs) are explained in
the Definitions and Notes section inThe World Factbook. Please
review this section to see if your question is already answered
there. In addition, we have compiled the following list of FAQs to
answer other common questions.
General ::
Can you provide additional information for a specific country?
The staff cannot provide data beyond what appears in The World
Factbook. The format and information in the Factbook are tailored to
the specific requirements of US Government officials and content is
focused on their current and anticipated needs. The staff welcomes
suggestions for new entries.
How often is The World Factbook updated?
Formerly our Web site and the published Factbook were only updated
annually. In November 2001, we began more frequent online updates,
and we now update the Web site every two weeks. The CIA discontinued
publishing the printed Factbook after the 2007 edition; the 2008 and
2009 editions are being published by the US Government Printing
Office.
Can I use some or all of The World Factbook for my Web site (book,
research project, homework, etc.)?
The World Factbook is in the public domain and may be used freely by
anyone at anytime without seeking permission. However, US Code
(Section 403m) prohibits use of the CIA seal in a manner which
implies that the CIA approved, endorsed, or authorized such use. For
any questions about your intended use, you should consult with legal
counsel. Further information on use of The World Factbook is
described on the Contributors and Copyright Information page. As a
courtesy, please cite The World Factbook when used.
Why are there discrepancies between The World Factbook''s demographic
statistics and other sources?
Although estimates and projections start with the same basic data
from censuses, surveys, and registration systems, final estimates
and projections can differ as a result of factors including data
availability, assessment, and methods and protocols.
Data availability Researchers may obtain specific country data at
different times. Estimates or projections developed before the
results of a census have been released will not be as accurate as
those that take into account new census results.
Assessment Researchers can differ in their assessment of data
quality and in their estimates based on the available country data.
They often need to adjust their estimates due to such factors as
undercounting in a census or underregistration of births or deaths.
Methods and protocols Differences in methods and protocols can
shape the way estimates and projections are made of fertility,
mortality, and international migration, and how these data are
integrated with the population data. For example, the US Census
Bureau uses a model that projects the population ahead by single
years of age, a single year at a time (population statistics used in
the Factbook are based on this model), whereas the United Nations
model projects five-year age groups forward, five years at a time.
Why doesn''t The World Factbook include information on states,
departments, provinces, etc., for each country?
The World Factbook provides national-level information on countries,
territories, and dependencies, but not subnational administrative
units within a country. A comprehensive encyclopedia might be a
source for state/province-level information.
Is it possible to access older editions of The World Factbook to do
comparative research and trend analysis?
Previous editions of the Factbook , beginning with 2000, are
available for downloading - but not browsing - on the CIA Web site.
Rehosted versions of earlier editions of the Factbook are available
for browsing, as well as for downloading, at other Internet web
sites. We urge caution, however, in attempting to create time series
by stringing together economic data - especially dollar values -
from previous editions of the Factbook . Over time, data sources,
definitions, and economic accounting methods have changed. We
occasionally have made these changes ourselves in order to provide
our readers with the best information available. Also, in the case
of dollar values, changes in relative exchange rates and prices may
make trends difficult to comprehend. Therefore, individuals should
consult additional resources when doing comparative research or
trend analysis.
Would it be possible to set up a partnership or collaboration
between the producers of The World Factbook and other organizations
or individuals?
The World Factbook does not partner with other organizations or
individuals, but we do welcome comments and suggestions that such
groups or persons choose to provide.','5165a4a1d088ad4f5cf0a1af54c20cc035bd2abd0fc1d619b879847456986ce1','internet-archive','theciaworldfactb35829gut','txt','5446a545f8f5ec70c3c461ac97b79d6255aa94b345750eb4a9b95c17758ab139','https://archive.org/download/theciaworldfactb35829gut/35829.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

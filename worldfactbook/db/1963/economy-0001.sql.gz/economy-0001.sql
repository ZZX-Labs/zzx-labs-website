SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc5d9e08f2b4a1fc140cf06ff70adc2511dc62b68c079f335b8c9ff1ba90d4f5',1963,'','','economy',4,'GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electrtc power: 2.6 million kw, capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 192, U.S. 102, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $1,602 million assistance disbursed 1963-69 by the Aid of Turkey Consortium
consisting of the U.S., 13 additiona) OECD member countries, the IMF, IBRD,
and European Fund of the EMA; $390.5 million extended by Communist countries
1955-December 1971; none extended in 1971; total U.S. economic, $2,727.9
million (July 1946-Ju : total U.S. military $3,250.2 million
(July 1946-June 1971)
Monetary conversion rate: urkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','1de57ea31cf866407b6e812547f4485a4e5342ee730fa5f2945b98c2595fcb1c','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

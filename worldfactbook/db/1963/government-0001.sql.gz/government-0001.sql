SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f85183db7e07c099461ab92dc291544377462095d9041574919a184e0317dcc',1963,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Acting Prime Minister Ferit Melen
Suffrage: universal over age 21
Elections: National Assembly (1973); Presidential (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party eh Bulent Ecevit; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyziogiu; New Turkey Party (NIP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbas{; Unity Party (UP), Mustafa Timisi; Republican Party (RP), Kemal
Satir (formed in 1972); Communist Party illegal
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% Reliance Party, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Other political or pressure groups: military overthrew government in 1960, forced
resignation of Demirel government in March 1971 and remains the dominant
force behind the new government
437
SECRER-
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRET.
GOVERNMENT (cont''d):
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECO, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO','f4f1ddb6b130a5df944f2a48ea3a62bd2ed409297de9eded809ce7b08c85e07a','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

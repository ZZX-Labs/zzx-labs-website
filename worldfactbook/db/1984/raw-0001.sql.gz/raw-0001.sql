SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaa84984825570a9dde2b4990630af5b8f10c38aed8f8a694ebaef07679e714a',1984,'','','raw',1,'i. ~<
Declassiied is Part - Sanitized Copy Approved for Release 2012/09/20 : Meee eee OOO TOO OOON
7 "Q\\ Intelligence ‘|
BK J Agency I he
World
Factbook
Nineteen Hundred and Eighty-Four
CtNTA
yuowrajddng parjissejy « moj-AYSry pue peipunyy Us0UIN «¢ /yooqioey, ppoAA AYUL
CR WF 84-002
Cov 2KQ7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
~&
V4
Pod
25X1
FANT to Danteal Bossa 5 , 2
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CROPS 020s OUI SOd ett .
£ g ~ : |
BARR REE UARe
cel
A.
25x1
_ 7 4 World _ re
: Factbook ss
Nineteen Hundred and Eighty-Four
i ee
& renee nll
,
?
}
}
)
i
Classified Supplement
The World Factbook and this Classified
Supplement aré produced annually by the ~
Directorate of Intelligence of the Central
Intelligence Agency. The supplement
contains the classified entries, 25X11
LOA |
In general, information available as of 1
January 1984 was used in the preparation of
this edition of the Factbook. The data are .
provided by various components of the ‘
\\ Central Intelligence Agency, the Defense ''
Intelligence Agency, the Bureau of the
Census, and the US State Department. The
Factbook production schedule precludes
formal coordination of these data. 25X11
Comments, and queries are welcome and
may be addressed to the Factbook Editor,
Office of Central Reference, 25X14
29X1
Secret
CR WF 84-002
(Supersedes CR 83-11301)
May 1984
- Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
‘
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
25X11
Contents
Page
Definitions, Abbreviations, and Explanatory Notes ix
A Abu Dhabi (see United Arab Emirates)
Afghanistan ]
©. Aiman (see United Arab Emirates)
; Albania 1
Algeria - 2
i Andorra . no supplemental data
Angola 3
Anguilla (formerly St. Christopher-Nevis-Anguilla) no supplemental data
Antigua and Barbuda 3
Argentina 4
Australia 4
Austria 5
Azores (see Portugal)
B Bahamas, The 5
Bahrain 6
Balearic Islands (sée Spain)
Bangladesh 6
Barbados 7
Belgian Congo (see Zaire)
Belgium 7
Belize (formerly British Honduras) 8
Benin (formerly Dahomey) 8
Bermuda 9
Bhutan 9
Bioko (see Equatorial Guinea) |
Bolivia 10
Bophuthatswana (see South Africa)
Botswana 10
Brazil ll
r British Honduras (see Belize)
British Solomon Islands (see Solomon Islands)
Brunei ll
Bulgaria 12
Burma : 12
Burundi 18
C Cabinda (see Angola)
Cambodia (see Kampuchea)
Cameroon ; ; 13
Canada 14
Canary Islands (see Spain)
iii Secret
- Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
es : 25X1
- Page
Central African Republic . 15
‘Ceylon (see Sri Lanka)
Chad nig 15
Chile Pos Geet 16
China (Taiwan listed at end of table) 16
Colombia as 18
Comoros - : : 18
Congo “ 19
Cook Islands ‘19
Costa Rica 19
Cuba 20
Cyprus 21
Czechoslovakia —_= 2)
D Dahomey (see Benin)
’ Denmark 29,
. Djibouti (formerly French Territory of the Afars and Issas) 23
i Dominica 23
: : Dominican Republic 23
Dubai (see United Arab Emirates)
E Ecuador : 24
| . Egypt 25
j Ellice Islands (see Tuvalu)
| El Salvador’ 25
Equatorial Guinea 26
: ; Ethiopia - 26
» UE Falkland Islands (Islas Malvinas) 27
Faroe Islands ; : 27
Fernando Po (see Equatorial Guinea)
Fiji 27
Finland a 28
France 28
| . French Guiana : 29
, French Polynesia 80
French Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
G Gabon nA 30
Gambia, The ie 81
German Democratic Republic Pe TE]
Germany, Federal Republic of . i 82
Ghana i, 4 , 82
Gibraltar - ne 83
|
'' Gilbert Islands (see Kiribati)
Secret iv
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
Page
Greece : . 33
Greenland . iG 34
Grenada = 1 84
8 Guadeloupe ene 35
Guatemala? oy ee ot 35
Guinea Re 35
: Guinea-Bissau (formerly Portuguese Guinea) 36
Guyaria a 86
H Haiti . ae 37
Honduras eee 37
Hong Kong ; ; 87
Hungary — eee 38
I Iceland Sey 38
India : 39
Indonesia : nie 40
Iran : sas ce ne Al
Iraq fe* Mens S 42
Ireland ves 42
Israel Dab ase eS. ue oh : 43
Italy see 43
Ivory Coast ; ; 44
J Jamaica a 44
Japan A E 45
Jordan ; 45
K Kampuchea (formerly Cambodia) — - 46
Kenya. 46
Kiribati (formerly Gilbert Islands) - 46
Korea, North .. 47
Korea, South 48
; Kuwait 48
7 : L Laos 49
; Lebanon be 50
Lesotho i? Gh aig = 50
: : Liberia ~ do Tee oe + 5]
Libya ; 51
Liechtenstein ; 52
Tuxemboure 23 53
M Macau te HE Ek _ ; 53
Madagascar age: 4 ’ 53
Madeira Islands (see Portugal)
Malagasy Republic (see Madagascar) :
Malawi ; 54
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
sae Mite ad
<
sia
Declassified in
Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
Page
Malaysia . _ 54
Maldives 55
Mali 55
Malta Apgete Meh 56 ©
Martinique 56
Mauritania... :.... . 56 Rees
Mauritius 57 q
Mexico 57 J
Monaco 58
Mongolia 58 |
Morocco 58
Mozambique . . 59 \\
Namibia (South-West Africa) _ 60 ;
Nauru 60 ,
» Nepal_ 60
Netherlands 61 {
Netherlands Antilles 61 +
New Caledonia — sce 62 | if
New Hebrides (see Vanuatu)
New Zealand 62 }
Nicaragua . 62
Niger. 63
Nigeria ta 63
Northern Rhodesia (see Zambia)
Norway 64 F
Oman 65
Pakistan 65
Panama 66
Papua New Guinea 66
Paraguay 67
Pemba (see Tanzania) .
Peru 68 ;
Philippines 68 4
Poland 69 7 |
Portugal Sei, 70 i
Portuguese Guinea (see Guinea-Bissau) {
Portuguese Timor (see-Indonesia). - .- 4
Qatar ae 71 }
Ra’s al-Khaymah (see United Arab Emirates) s
Reunion ae 71 s
Rhodesia (see Zimbabwe) re
‘A
«
*
¢
Secret _ vi }
| §
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7 j
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7 |, ,
25X11 |
SS a OS | ee
|
> \\
|
Page
Rio Muni (see Equatorial Guinea)
Romania ; 71
Rwanda 72
* S St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) 72
St. Lucia sell tS 73
St. Vincent and The Grenadines... ~ 73
San Marino no supplemental data
Sao Tome and Principe 73.
Saudi. Arabia ae: 74
Senegal — 74
‘Seychelles 75
Sharjah (see United Arab Emirates)
Sierra Leone AN 75
Singapore : 6
Solomon Islands (formerly British Solomon Islands) '' 76
Somalia ; cs 77
South: Africa Ss ae 17 |
Southern Rhodesia (see Zimbabwe)
South-West Africa (see Namibia)
Soviet Union ea 78
Spain j 79
Spanish Sahara (see Western Sahara)
Sri Lanka 5 ee 80
Sudan ee eS 81
Suriname vo 81
? Swaziland L264. oe 82
Sweden... Pees 82
Switzerland te 83
Syria Ss 83
T Tanganyika (see Tanzania)
. Tanzania . aie 84
, Tasmania (see Australia)
Thailand a 84
Z Togo ; % eee 85
Tonga a 85 _
Transkei (see South Africa) ;
Trinidad.and Tobago Be 86
Tunisia ; 86
. -Turkey~ = eS - 87
Turks and Caicos Islands no supplemental data
Tuvalu (formerly Ellice Islands) as : 87
, vii a Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
Page
aI eae a ey
U Uganda . 88
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 88
Ra’s 4l-Khaymah, Sharjah, Umm al-Qaywayn) ~
. United Arab Republic (see Egypt)
United Kingdom 2 89
United States ae no supplemental data
Upper Volta . 89
, Uruguay fa 90
Vv Vanuatu (formerly New Hebrides) 90 4
: Vatican City eo ; , 91 4
Venezuela a, 91
Vietnam . ane) — 92 {
Ww Wallis and Futuna : no supplemental data
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 92
Western Samoa : — 93
Y Yemen, Arab Republic (North Yemen) 93
Yemen, People’s Democratic Republic of (South Yemen) 94
_ Yugoslavia: : > ee - - : 94
Z Zaire 2 ; ee ; 95
Zambia (formerly Northern Rhodesia) 96 {
Zanzibar (see Tanzania) . ;
Zimbabwe (formerly Southern Rhodesia) 97
Taiwan ee, oe 97
West Bank and Gaza Strip . no supplemental data ;
. Appendix :
Conversion Factors o i 98
a
ae |
|
4
4
4
4
4
Secret . re viii ;
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
oe er, Sa ae
Nl ECS Ne ge ee
Definitions; Abbreviations,
and Explanatory Notes ©
Fiscal Year: The abbreviation FY stands for fiscal year; all years
- are galendas years unless otherwise indicated.
GDP and CNP: GDP i is the total market value of all goods and
services produced within the domestic borders of a country over
a particular time period, normally a year. GNP equals GDP plus
the i income accruing to domestic residents arising from invest-
ment abroad less income earned in the domestic market accruing
to foreigners abroad.
Imports, Exports, and Aid: Standard abbreviations used in
individual entries throughout this factbook are c.i-f. (cost, insur-
ance, and freight), f.0.b. (free on board), ODA (official develop-
ment assistance), and OOF (other official flows).
Land Utilization: Most of the land utilization percentages are
rough estimates. Figures for “arable” land in some cases reflect
the area under cultivation rather than the total cultivable area.
Maps: Referénces undér the locator maps pertain to the area
maps at the back of the unclassified version of The World
Factbook..
Maritime Zoriesi Fishing and é economic zones claimed by coastal
states ate included only when they differ from territorial sea
limits. Maritime claims do not necessarily represent the position
of the United States Government.
Money: All money figures are in contemporaneous US dollars
unless otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to
express volume of crude oil and refined products; a barrel equals
42.00 gallons, 158.99 liters, 5. 6r cubic feet, or 0.16 cubic meters.
Note: Sins of tis countries and sovennieae inoluded in this
publication are not fully independent, and others are not official-
ly recognized by the United States Government.
_ ix
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
TUITE
f 25X1
Afghanistan . . Albania
25X1
(See reference map Vill) (See reference map V)
25X1
Economy : Economy
Aid: economic commitments—US, including Major trade partners: $323.9 million; China,
Ex-Im (FY70-82), $221 million; Communist which replaced the Soviet Union as Albania’s
countries (1970-82), $1.8 billion, OPEC ODA major trade partner after the 1961
(1974-82), $940 million; military commit- Albanian-Soviet break, has withdrawn all of
ments—US (FY70-82), $2 million; Commu- its aid from Albania; 1978 est. trade—22%
nist countries (1970-82), $2.6 billion China, 36% East European Communist
a ; countries, 42% non-Communist countries
Defense Forces . 25X1
Personnel: Afghan Air and Air Defense : Communications |
Rg nA NN Sa a rm
e
Forces unknown but probably about 4,000
(half strength); Air Force 2,000 (pilot strength
175-200); Air Defense Force (Army), 3,000;
army and paramilitary personnel—Army,
50,000; Border Guard Command, 10,000-
12,000; Defense of Revolution Command,
8,000-10,000; Provisional Police, 15,000-
Merchant marine: 10.cargo ships (1,000 GRT
or over) totaling 51,677 GRT, 73,791 DWT
Airfields: 12 total; 6 with permanent-surface
runways; 5 with runways 3,500 m or more, 5
with runways 2,500-3,499 m, 5 with runways
25X1
20,000 1,000-2,499 m, 1 with runways less than 25X1
; 1,000 m, 1 heliport ZORK1I
Major ground units: 3 corps headquarters,
11 infantry divisions, 3 armored divisions, 3 Telecommunications: least developed of any
4 mountain brigades, 1] artillery brigades, 15 European Communist country; serves only
artillery regiments, 5 commando regiments, basic needs of government with very limited
1 parachute regiment : service to public; limited coverage by radin 5X 4
and wired broadcasts; 8 AM stations, 175,0Gu
Major air defense units (manned by army receivers; 2 TV stations, 4,200 receivers;
troops): | antiaircraft artillery division, 2 15,000 telephones 25X11
SAM brigades, 1 radar brigade, and] search- ~ ;
light brigade Defense Forces {
Personnel: (est.) ground forces 30,000; navai
forces 3,200; air and air defense forces 7,300;
paramilitary forces 12,500; personnel in re- |
ea
Aircraft: 225 (146 jet, 13 turboprop, 9 prop, }
56 helicopters) operationally assigned to air
force serve (not on active duty)—est. ground fore X1
: 180,000, naval forces unknown, air force uu-
Missiles: 120 SA-2s, 5 sites (3 operational, 1 known 25X11
assembly and storage, 1 training); 125 SA-3s ;
(5 sites) 25X1
1 Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Albania (continued)
Major ground units: 5 brigades (4 infantry, 1
tank), 2 coastal defense commands (approx.
brigade size), 4 artillery regiments, 1 engi-
neer regiment, | signal regiment, 1 chemical
defense battalion
Aircraft (in operational units): 102, includ-
ing 86 air defense, 12 ground attack, 4
transport
Missiles: 4 SA-2 SAM sites (24 launchers)
Supply: some small arms and ammunition
manufactured domestically; China has sup-
plied small torpedo boats, patrol craft, and
submarine sections to the navy; tanks, ar-
mored personnel carriers, trucks, SAMs,
infantry weapons, defensive chemical yA
biological warfare equipment, and ammuni-
tion to the army; and jet aircraft and
helicopters to the air force; Chinese aid has
been cut off
Secret','7ed9805b95a0e50eb1cad045172342b682cd542ac3dfd7820e453b9a935895b7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

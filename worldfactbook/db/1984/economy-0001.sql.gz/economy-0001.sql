SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1553515af13c556b460a481b695a96c94d2f4cdbc9d5c2d755a668ab6e3cb377',1984,'DZ','Algeria','economy',2,'Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-82),
$4.8 billion; US, including Ex-Im (FY70-82)
$1.4 billion; Communist countries (1970-82)
$1.6 billion; military commitments—Com-
?
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Ships: 2 submarines, 12 missile attack boats, 2
frigates, 2 fleet minesweepers,.1 medium
landing ship, 1 miscellaneous auxiliary, 1 div-
ing tender, 1 torpedo retriever, 19 patrol
ae. t
wo
mc intsn Gea sta eet tay enh et 52a cele
25X1
craft, 8 guided missile patrol combatants
Aircraft: 284 all-weather/day fighters, 22 .
4
25X1
25X11
bombers, 41 transports, 136 helicopter:
ZOXK1
Missiles: 2SA-2, 3SA-3, 15 SA-6 battalions
\\
25X11
Supply: in the past depended on France and
to a small extent on several non-Communist
countries and China; since 1975 materiel (in-
cluding surface-to-air, air-to-air, and naval
missiles, aircraft, naval ships, and ground ma-
teriel) supplied mostly by USSR; domestic
production of small amounts of ammunition
eee ee
and explosives is to begin in the near future
25X1
aia (1970-82), $4,750 million','94c5c1daee0ae1e26cf643fedde3d2786ba76ecc124cb59cd31b4778e3115684','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36fd3b7c831a900574257e68bf4a051958fead449712319d6b45987f88bd65c',1984,'AR','Argentina','economy',7,'Aid: economic commitments—US, ‘including
Ex-Im (FY70-82), $1,037 million; other.
Western countries ODA and OOF (1970- 81),
$1.8 billion; Communist, countries (1970-82),
$470 million; military commitments—US
(FY70-82), $137 million','4300439590eaa24613e10b4b3eeb0e39daf127381fbf6dcc7ad237a48ae11d5b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7eb0226faaeaaea6348e0c20b611dc1e54455a037be710e4616a561000043fb',1984,'AT','Austria','economy',11,'Aid: economic commitments—OPEC ODA
‘ (1974-82), $930 million; US (FY70-82), $24
million; other Western countries; ODA and
OOF (1970-81), $11 million
Aid: economic commitments—Communist
countries (1970-82), $1,065 million; OPEC
ODA (1974-82), $1,285 million; US, includ-
ing Ex-Im (FY70-82), $2.2 billion; other
Western countries, ODA and OOF (1980-81),
$1.8 billion; military commitments—Com-
Supply: military supplies consist of those cap-
tured from West Pakistani forces and
materiel provided by Egypt, France, India,
25X11
Yugoslavia, UK, China, and USSR
munist countries (1970-82), $213 million
Communications i
Merchant marine: 34 ships (1,000 GRT or
over) totaling 313,341 GRT, 443,400 DWT,
includes 30 cargo, 2 tanker, 1 passenger, and
1 ore/oil carrier
Defense Forces
Personnel: army 70, 000, navy 5, 500, air
force2,000 est) (t(‘ié‘s*™''
Major ground units:5 division Resdanariers
12 infantry brigades; about 32 infantry bat-
talions; 8 field artillery regiments; ] heavy
mortar battery; 1 armored brigade, sup-
ported''by 1 independent engineer brigade, 1
signal brigade, and other service elements; 1
independent antiaircraft regirnent:3 light ar- .
tillery regiments; and 1 armored cavalry °
regiment
Ships: 8 frigates, 4 guided viele patrol
boats, 20 coastal patrol boats/river patrol
boats, 1 submarine chaser, 3 auxiliary
Aircraft: 99 (58 jet, 4 turboprop, 20 prop, 22
helicopters) operationally assigned
CIA-RDP08-00534R000100050001-7
ee
i
25xX1
1°
ef a et tO FP pn nr A Ai eg ee Pek
ware
pe oe, a,
Te ee et ee er ee Te rer er rr te ee
. ee ee WT TT TR
eon!
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','faa6c83051872d34d5cb3c27bed03c4389f203cc60d0bb47eb3b47e0fae15a72','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a54c12b950dfb855fe7ecfb6b345d2733e81c862f26f633ffa4c3b11c4b7acec',1984,'BB','Barbados','economy',12,'»
(See reference map Ill)
Defense Forces
Personnel: 466
Major Ground Units: Barbados Regiment
Ships: 3 fast patrol craft (PCF), 4 patrol boats
(PB)
Aircraft: 1 utility
Supply: mostly from the UK
25X1
’ 2X1 25X1','d3e7f8193580be3da96992a8fea3f7ca33d3ec5c098897e172951fb782d11c0d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da7031017f0c06294c0513ac347e7e40624c5aced7b63fab3ae9c7465bd350bb',1984,'BE','Belgium','economy',13,'Aircraft: 437 (236 jet), including 347 (289 jet)
in air force, 3 in naval aviation, and 87 in
army aviation
25X11
Missiles: 6 SAM squadrons with NIKE Her-
cules in air force and 8 SAM battalions with
HAWK in ground force (see major ground
units)
25X1
Supply: significant production of small arms
and own ammunition and some production
of aircraft, infantry and antitank rocket
launchers, mortars, artillery and mortar am-
munition, rockets, electronic fire control
equipment, and biological/chemical warfare
defensive materiel; some assembly of ar-
mored personnel carriers; recently
completed 4 guided missile frigates and is
producing /assembling the US-designed F-1“
jet fighter; all other materiel imported fro20X1
NATO countries|
tainer, 13 tanker, 31 bulk, 2 liquefied gas : 25X1
carrier, 3 roll-on/roll-off, 1 specialized car- Military budget: for fiscal year ending 31 25X11
rier December 1982, $3.2 billion; 9.6% of cent ) 5X4
, ; government budget COR |
“ oewsrt
(See reference map V)','848db59e814dced3d0dbc455e3901094fdd0eebfcca828dd1d41b2ec92d6e551','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5393a20c2c58bbb42aa275b9cacc97fcf27304841c97e492c265c40f6d681b34',1984,'BJ','Benin','economy',17,'Aid: economic commitments—Communist
countries (1970-82), $54 million; US, includ-
ing Ex-Im (FY70-82), $24 million; other
Western countries, ODA and OOF (1980),
$60 million; OPEC ODA (1974-82), $30 mil-
lion; military commitments—Communist
countries (1970-82), $184 million','59f748e9f63f3ddf8d9c49db7aba66b4ffe0038af008007a6bfec5f39b6d47fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c94c3769dcb011ec88ae47340051e3b5b3a38b9317b74955d26c7b8f89eec754',1984,'BM','Bermuda','economy',19,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $474 million; other West-
ern (non-US).countries ODA and OOF
(1970-81); $481 million; OPEC ODA (1974-
82), $5 million; Communist countries ‘
(1970-82), $177 million; military commit-
ments—assistance from US (FY.70-82), $55
mliee| |','f1a7e3ec2fd096907aca256f754c8c988953e0be3630f4a02730244692515d68','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('530189ab909b5a00abc5e78a4e953979faca128d5a5883e3d55044e85cd7f840',1984,'BW','Botswana','economy',20,'- Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-81),
$712 million; US.(FY70-82), $12] million;
Communist countries (1970-82), $17 million;
military commitinents—Communist coun-
tries (1970-82), $8 million
Defense Forces
Personnel: army 3,200, police 1,000, limited
paramilitary capability
Major ground units: 5 independent com- ,
pany groups
Aircraft 15 utility] ,
Supply: UK, Belgium, US, USSR, and China
ee A ee Oe ek
25X11
25XK1
meiner
sr Tr eT Te I FT IT Oe re re ey re ee','dcff7ab74ac453b862e8b0dcd7a4756f29aa2802b0cafb1b38c227fcca0d8afb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09eed88c76ccfe2d143e42c86df9b5b9ca5266b99c408b140acfe5f422545a3e',1984,'BR','Brazil','economy',21,'’ BRAZIL
Brasilia
*
(See reference map !V)
Aid: economic commitments—US, including
Ex-Im (FY70-82), $2.4 billion; other Western
countries ODA and OOF (1970-81), $4.4 bil-
lion; Communist countries (1970-82), $718
million; OPEC countries ODA (1974-82), $85
million; military commitments—US (FY70-
82), $214.1 million','4ffed220c03b7b5e2e61945eaf718c69ba06765b3a27320e1cf93f08a16cfc2c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('158c82672171319a469ea85a73c67f43000dd18a0495bce14ea0826f06013895',1984,'BG','Bulgaria','economy',24,'Aid: USSR—about $2.08 billion economic
aid extended (1954-76); Bulgaria has ex-
tended foreign aid totaling more than $64
million to Communist countries (1945-70),
and $755 million in bilateral economic aid to
the non-Communist less developed couminics:
(1956-82)
Aid: economic commitments—Communist
countries (1970-82), $326 million; US, includ-
ing Ex-Im (FY70-82), $49 million; other
Western (non-US) countries ODA and OOF
(1970-81), $1.6 billion','17803157fa3792b7941791ad2d5a85056617aa94b731134e36a3f0957024029e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('980f9d2e93e175449e5b57a3efeef546ac16d4ffab61045c64146b80c54071e3',1984,'CM','Cameroon','economy',28,'Atd: economic commitments—Western ;
(non-US) countries ODA and OOF (1970-81),
$1.6 billion; Communist countries (1970-82),.
$104 million; US, including Ex-Im (FY70-;
82), $235 million, OPEC ODA (1974-82), . .
$110 million; military commitments—Com-,
munist countries (1970-82), $7 million; U55x14
(FY70-82), $14 million ZOK |','88fc7353a9deea5e4fcb64b919ae9c634136f8834a30e1722503b42c49503c0d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e293b5f8bfc0a8c2bba748401cf0bd1b595752f47c53ed1f43bc223e9d2a303e',1984,'CA','Canada','economy',30,'Aid: economic commitments—Western
(non-US) countries, ODA and OOF (1970-
81), $222 million; Communist countries
(1970-82), $25 million; US (FY75-82), $50
million; OPEC ODA (1974-82), $30 million;
military commitments—Communist coun-
tries lice: $65 million
Ginienieatens : ''
Merchant marine: 3 cargo isk (1,000 GRT
or over) totaling 6,458 GRT, 11,312 DWT
Defense Forces
Personnel: army 2,200, navy 100, air force
10, and militia 2,000; the armed forces are.
divided into 3 brigades or battalions |
Major equipment: 17 BRDM-2, 6 BTR-40,
unknown number of ZU-23 AAA, 10 light
tanks)
Ships: 3 craft (2 patrol torpedo boats and 1
transport, vessel class unknown)
Aircraft: 2 short-range transport planes
Supply: ammunition, trucks, armored vehi-
cles have been received from the USSR
Central African Republic |
AFRICAN
; REPUBLIC ;
(See reference.map Vil)
Aid: economic commitments—Western
(non-US) countries, ODA and OOF, (1970-
81), $420 million; Communist countries
(1970-82), $14 million; OPEC ODA (1974:
81); $70 million; US, including Ex-Im |
(1970- 82), "$20 million; military commit-
ments—Communist countriés (1970-82), $18
million = - 25x4 ‘
Defense Forces 7
Personnel: army 2,600, air force 230, na-
tional police 1,350, gendarmerie 1,600,
Central African Guard 700;-83 French mili-
tary advisers
Major ground units: 1 parachute interven-
tion regiment, | territorial defense regiment,
ClA- RDP08-00534R000100050001-7 |
63','0ddc771c7eeda31ba44d6ecf23ab7cad77d3eaa0399d947d78caf5dcaaf707c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e1c57e3263afe23bba99b0455863aeae5c0605d5c4684a492f8e7380b02df9f',1984,'TD','Chad','economy',31,'(See reference map Vii)
25X11
Aid: economic commitments— Western
(non-US) countries, ODA and OOF (1970-
81), $417 million; Communist countries
(1970-82), $70 million; OPEC ODA (1974-
82), $25 million; US (FY70-82), $70 million;
military commitments—Communist coun-
J support regiment, and 1 gendarmerie
Aircraft: 12 total; 7 transports, 3 utility, 2
trainers
Supply: dependent mainly on France, Libya,
and Italy|
tries (1970-82), $7 million
Defense Forces
25X1
Personnel: Army, est! 10,000; 304-man Air
Army (operations group 179; security bra noey4
125)
Aircraft: 22 total—8 transports, 8
25X1
5X1
utility /light observation, 6 helicopters (4 Sa-
880 PUMA and 2 SA-342 Gazelle)
u
25X1 25X11
Secret
25X1
25X1
25X1
ZOA1
25X1
25X1
25X14 25X1 25X14 29X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
OCCIce','16c6c15e06c3150caf57f972db651cf7f524084b8f454476ab454d9bb36ca00a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db4f5a86108b352030d96245b9f303de23feef139b6719cea82e2f49e599f3e9',1984,'CL','Chile','economy',32,'(See reference map IV)
Aid: economic commitments—US, including
Ex-Im (FY70-82), $510 million; Western
(non-US) countries ODA and OOF (1970-81),
$557 million; Communist countries (1970-
82), $386 million; military commitments—
US (1970-82), $50 million','9c1ce69b471d3ebf45343cd069d9e9817e96f62389fdae21ddec72cc366c3ff0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b27503cad5e257c5683c47a3865019ccdad627f702df8a380bb4be5de41d488d',1984,'CO','Colombia','economy',36,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $1,407 million; other
Western countries ODA and OOF (1970-81),
$714 million; Communist countries
(1970-82), $289 million; military commit-
ments—US (FY70-82), $132 million;
Communist countries (1970-82), $5 million','904d7e62dfe88e1333083a9780105f8b5f9ed7617e95669b148931c441c78189','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af43d0072e86ea833b5eba105101d747c04d48cc27d9702d572848766f2af4f5',1984,'KM','Comoros','economy',37,'Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-81),
$187 million; OPEC, ODA (1974-82) $185
million 7
Defense Forces
Personnel: 450-man Army; nominal Air
Force; 200-man Gendarmerie; 350-man
Presidential Guard under the direct control
of the President
Major ground units: army—1 headquarters
and 8 companies; gendarmerie—3 units;
equipment includes 500-600 semiautomatic
rifles, 281-mm mortars, 15 land rovers, and 4
reconnaissance vehicles
Aircraft: 8 fighter, 5 fighter trainers, 1 utility, .
3 transport
Supply: primarily dependent on France
ry
4
'' Congo
" , (See reference map Vil)
i]
Aid: economic eonmniewente— Western
(non-US) countries ODA and OOF (1970-81),
$661 million; Communist countries (1970-
82), $178 million, OPEC ODA (1974-82), _
$140 million; US, including Ex-Im (FY70-
82), $16 million; military commitments— -
Communist countries (1970-82), $134 million
Defense Forces
Personnel: army 7,000, navy 200, air force
325; military advisers—75 Soviet, 20 GDR,
800 Cuban, 60 Chinese
Major ground units: 3 mechanized infantry
battalions, 1 artillery battalion, 1 armor regi-
ment (battalion), 1 support battalion, 1
engineer battalion, 2 paracommando compa-
nies
Aircraft: 58 (17 transports, 9 MiG-17, 1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
Ships: 12 coastal patrol boats/river roadstead
« craft
Supply: former dependence on France re-
placed by USSR and China; received 3 fast
patrol craft from Spain
| . MiG-15, 12 MiG-21, 19 helicopters)
|
t
f
|
\\
}
5','b91e2bd2c56e23f9048163c3ca9609e91112fa544d8bdef2b5ea3dd838655e0d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8128eee52854816aab9580093de9440b8e60eaf0253fb72a39c05770c193cc00',1984,'CK','Cook Islands','economy',38,'(See reference map X)
Defense Forces
Personnel: no military forces maintained,
but there is a police force of about 54 men;
the Rarotonga police station is in Avarua next
to the post office
25xX1
19
> CIA-RDP08-00534R000100050001-7','6c8ebc85268e17ba0495df8f546c8eed1608b3037f4a2db73dd364a61cce283f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f565bbe851bbbfc68344799c52d8663cae103be7483999c84b571088825a3004',1984,'CY','Cyprus','economy',42,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $188 million; other West-
ern countries ODA and OOF (1970-81), $102
million, OPEC ODA (1977-80), $35 million;
Communist countries (1970-82), $24 million;
military commitments—Communist coun-
tries (1970-82), $37 million; Turkish sector
aid—Turkey, probably $20-30 million annu-
ally since 1975; primarily development and
budgetary aid with some balance-of-pay-
ments support','f8086dc391735300b8ef545f4f585570a81758324bc84b52378d0b1f9384d6e5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3dc4229d9bbfcfe77e1f67f9547285fefb4a0aeb25f5483d4cc932d9e7c1d4c',1984,'DJ','Djibouti','economy',44,'Aid: economic commitments— Western
(non-US) countries, including ODA and OOF
(1970-81), $150 million; US, including Ex-Im
(FY78-82),''$14 million; OPEC ODA (1974-
82), $240 million; Communist countries
(1970-82), $30 million
Defense Forces
Personnel: French—army 3,800, air force
200; Djibouti—army 2,700, of which 20 are
naval personnel
Major ground units: French—3 infantry
companies, 2 armored squadrons, 2 artillery
batteries; Djibouti—1 commando interven-
tion company, 1 Gendarmerie corps, 1
Frontier Commando group, 1 paratroop
company, | armored squadron, | naval force
Ships: French—3 frigates, 2 corvettes, 1 pa-
trol craft, 1 amphibious ship, 5 auxiliaries;','abda7070b6a638492bb9a2bd5b90a833505ab35c955994ee8a31165058862b5e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af9222474a9d2a1c1a513f52d18a469d77e4f1fd2ba2a56e6cf5ff9430aa18bf',1984,'DM','Dominica','economy',45,'(See reference map Ill)
Defense Forces
Local security force: Royal Dominiéd Police
Force, 450; Coast Guard (division of the po-
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001- ¢
Secret','32a013154e9596dc90beed14acb5597b46e0dec97133b626598fef2a932c27c8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('016cbb89bce49e04f5861de202e1f6967f164e9177e9874ff6946ae444cf19a4',1984,'EG','Egypt','economy',48,'Aid: economic commitments—OPEC ODA
(1974-82), $8 billion; US, including Ex-Im
(F Y70-82), $7.9 billion; Western (non-US)
countries ODA and OOF (1970-81), $3.8 bil-
lion; Communist countries (1970-82), $1.3
billion; military commitments—Communist
countries (1970-82), $4.1 billion; US (1970-
82), $2.9 billion
Budget: (1982 est.) revenues, $3,200 million;
-missile attack boats
amphibious, 17 auxiliary and service, and nu-
merous small craft
Aircraft: 1,038 (711 jet, 48 turboprop, 119
prop, 155 helicopters)
Missiles: 4 air defense divisions and''1 Air De-
fense Operations Group with 365 SA-2
launchers, 220 SA-3 launchers, 60 SA-6
launchers, 24 Crotale launchers, 721-HAWK:
launchers, and 1,300 SA-7 launchers
Supply: assembles light armored vehicles,
trainer aircraft, and antitank missiles; pro-
duces infantry weapons, ammunition, small .
naval oilers, patrol boats; is dependent on for-
eign sources for other equipment; received
from the Warsaw Pact before 1974 and from
Western Europe, the US, China; and North
Korea since then; UK recently supplied 6
Military budget: for fiscal year ending 30
June 1983, $3.4 billion; 16% of central gov-
ernment budget i
expenditures, $4,080 million','a6dd16ac35bdd11bea9cb668fadf580fc36b4cc0dba7e7b7ebcbe2567b4bafea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecbc6d91b162706c83e098909612fc1a9ff748387efab6d521a0417ae33e0ab6',1984,'GQ','Equatorial Guinea','economy',50,'Aid: economic Goren binant Comtiunist
countries (1970-82), $30 million; Western.
(non-US) countries ODA and OOF (1970-81),
$20 million; US, including Ex-Im (FY82), $2
million; military commitments—Commu-
nist countries (1970-82), $25 million','f79faf73619e2ea66c31092cce56f965cd33b8ca867c4ca11b8962015029cb15','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fe1ecfbb332c7fa1c0f2883cae0d4f81415917ecdee7dbde7250a1ee1a0feef',1984,'ET','Ethiopia','economy',52,'Aid: economic.commitments—Western
(non-US) countries ODA and OOF (1970-81),
$552. million; US, including Ex-Im (FY70- :
82),-$232 million; Communist.countries .
(1970-82), $1,055 million;OPEC ODA (1974-
82), $20 million; military commitments—US
(FY70-82), $122.5 million; Communist coun-
Aircraft: 238 in operational units (148 jet, 45
tries (1970-82), $4 billion','d858688d09a8b954d58b24dc19352eea0bc0414fcd798ed6d4ff650c9946e27c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d33a40ccbd7a9a2add18fbb962e551f9e330bdb42b07e8e571fffeb7cb51b67',1984,'GF','French Guiana','economy',56,'Aid: economic commitments-—USSR, “$900
million (1954-75); to less developed non-
Communist countries, $2.8 billion in bilateral
economic aid (1956-81)
Gommranieations
Merchant marine: 152 ships (1, 000 GRT and
over) totaling 1,300,000 GRT, 1,836,600
DWT; includes 1 passenger, 118 cargo, 5
roll-on/roll-off cargo, 5 tanker, 16 bulk, 4
combination ore/oil, 1 beach landing craft,
and 2 specialized carriers
Civil air: 38 major transport aircraft (1982)
Airfields: 189 total, 66 with permanent-
surface runways; 3 with runways 3,500 m or
over, 45 with runways 2,500-3,499 m, 73 with
runways 1,000-2, 499 m, 68 with runways less
than 1,000 m; 7 heliports
Palsclanmunicalions: domestic and interna-
tional facilities modern and: adequate; good
coverage:provided by 21 AM and 18 FM
broadcast stations, 7, 000, 000 receivers; 20
major TV stations supplemented -by 325 re-
broadcast stations; 5,550,000 TV receivers,
2,900,000 telephones (100% automatic)
Defense Forces
Personnel: (est.) ground forces 122,800, aval
forces 14,600, air and air defense forces
40,000, border troops, Ministry of State Secu-
rity (MFS) guard regiment, alert police, -
63,300; personnel in reserve (not on active
duty)—{est.) ground forces 700,000, naval
3]
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
(25X1
25X1
forces 30,000, air force 4,400; Soviet forces
(GSFG) in GDR asof 1 January 1983, 402,000
(365,000 ground; 37,000 air)
Major ground units: 6 divisions (4 motorized
rifle, 2 tank), 2 SCUD (SS-1) tactical missile
brigades, 4 regiments (2 artillery, 2 antiair-.
craft artillery), 1 airborne battalion, 2
antitank battalions, 2 SA-4 brigades, 6 SA-6
regiments (division subordinate)
Ships: 11 principal surface combatants, 6 pa-
trol combatants, 12 amphibious warfare
ships, 8] coastal patrol-river /roadstead craft,
28 mine warfare craft, 6 underway replen-
ishment ships, 2 fleet support ships, 35 other
auxiliariel si 25X14
Aircraft (operational units): 620, including
300 air defense fighters, 55 ground attack, 22
reconnaissance, 72 transports, 171 helicop-
ters (including naval helicopters)
Missiles: 25 onerational SA- 2 sites (150 25X1
launchers), 4 operational SA-3 sites (12 4-rail
and 4 dual-rail launchers); 2 brigades of the
SA-4 tactical missile system and 6 regiments
of SA-6 tactical missile system are deployed
with the GDR ground forces; the SA-7, SA-9,
and SA-13 tactical SAM systems are also de-
ployed; there is evidence that 2 SA-5 systems
are under construction
Supply: dependent on Communist countries,
mainly the USSR, Czechoslovakia and Po-
land, except for light infantry weapons, small
“arms ammunition, explosives, chemical war-
fare defensive materiel, signal equipme''-, 5X1
transport vehicles, and some minesweepv.:,
torpedo boats, amphibious and auxiliary
ships and service craft
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Germany, Federal Republic of
(See reference map V)','30d4b0566a6d21ca36548642e0f15fd4f651d94758a116c647553a4f9d619f3b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88ec77826d4a05e6b6c84781991b6410a4177465ecffb258d52a0b0b5cb2e4fb',1984,'GH','Ghana','economy',58,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $298.5 million; other
Western countries ODA and OOF (1970-81),
$797 million; OPEC ODA (1974-82), $80 mil-
lion; Communist countries (1970-82), $56
million; military commitments—Commu-
nist countries (1970-82), $12.0 million; US
(1970-82), $2 million','465df82b242ff06f2b1c6803b440f706daeb22607d7e9cf8964d8fe17ff39b17','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34e3e473dd2514024919bc34c51227837cb0e27c1bd5ee5e0b272e7689b69a28',1984,'GR','Greece','economy',61,'Aid: economic Siehent ache Weer
(non-US) countries ODA and OOF (1970-81);
$14 million, OPEC ODA (1974-82), $57 mil. 25X1
lion; Communist countries (1970-82), $57 °° 2 BX
million; military commitments—Commu-
nist countries (1970-82), $1-million
Defense Forces 25X1
Local security forces: Royal Grenada Police
Force 280; Coast Guard 1 55-foot patrol bo.25X 4
3 30-foot patrol] boats—the police commis-
sioner is the immediate supervisor of Be 25X1
Coast uate : io
25X14
CIA-RDP08-00534R000100050001-7
r)
?
oH
a ee a
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
Guadeloupe y
Guatemala ares
(See reference map Ill)
,
Defense Forces :
Defense is responsibility.of France; data. are
for Frénch military forces
“* (See reference map Iil)
Aid: economic commitments—Communist -
countries:(1970-82), $210. million; OPEC _. -
ODA (1974-82), $565 million; US authoriZX 1
tions, including Ex-Im (FY70-82), $118
million; other Western:countries ODA: ar20X1
OOF (1970-81), $227 million; military com-
mitments—Communist countries ug foRvVA
$190 million Cao
Communications tales -25x1
Merchant marine: 1 bulk a: 000 GRT or /f,
over) totaling 10,800 GRT, 15,300 DWT
25x1
Telecommunications: fair system of ope®
wire lines, small radiocommunication
stations, and new radio-relay system; 10 5X4
telephones (0.2 per 100 popl.); 2 AM staticz.,
1 FM, and 1 TV station; 1 Atlantic Ocean
satellite ground station) = sid
| 25X1
Defense Forces
Personnel: army est. 11,000, navy 900, air
force 750, gendarmerie 1,500, Sirete 25X11
Nationale 1,500, Republican Guard 1,200,
militia 35,100 25X11
Major ground units: 25 battalions (1 engi-
neer, 1 special, ] armored, 1 paracommando,
1 artillery, 20 unidentified)
Ships: 1 fleet minesweeper, 1 subchaser, 2
torpedo boats, 2 small torpedo boats, 1 patrol
craft, 6 patrol boats, 2 coastal patrol craft, 5
medium landing craft
25x11
25xX1.— 20X
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
OCCrel
Guinea (continued)
rc
y
Aircraft: 2] (12 jet, 2 unbopreD? 7 helicop-
ters)
Supply: dependent primarily on Communist
‘countries, mainly USSR, also France; naval
‘boats from China
25X11
25X1
“25X14
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','5725d9ee4bf6440f377483fa44bc51bd0898c36e7714bbd7df7f126c3b2e463c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9849ab9d308cdddc8ca644817406fe2370d8beec5bd20076cc657499af8746ad',1984,'GW','Guinea-Bissau','economy',62,'(formerly Portuguese Guinea)
(See reference map Vil)
Aid: economic commitments—Western .
(non-US) countries ODA and OOF (1970- 81),
$234 million; Communist countries (1970-
82), $51 million, OPEC ODA (1974-82), $20
million; US authorizations (FY70-82), $26.5
million; military commitments—Commu-
nist countries (1974-82), $45 million
Defense Forces
Personnel: army est. 6,000, navy 450, air
force 150, paramilitary 5,000
Major ground units: 4 infantry battalions, 1
mechanized brigade, | artillery group, 1 anti-
aircraft group, 1 transportation group, and 1
signal company
Ships: 15 (2 torpedo boats, 2 small torpedo
boats, 2 patrol boats, 6 medium landing craft,
1 hydrographic survey ship, 2 yard and serv-
ice craft)
Aircraft: 18 (7 jet fighters, 5 prop light trans-','aec5e59dae5c1944c712801390f6de7e3f1d0f4d9c8a39757e55b24547bbb5b9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b3676fc9cd5bf19679c152dbc2e8ba1ebf71f90d6cc04f25ff307f8e5999a89',1984,'GY','Guyana','economy',63,'(See reference map IV)
Aid: economic commitments—US, including
Ex-Im (FY70-82), $92 million; other Western
countries (1970-81), $299 million; OPEC
(1974-82), $50 million; Communist countries
(1970-82), $75 million','c8b30392d2978c2346d108f6cf9e1af3bd5926fef1dc29d774dfd30ceb9dd5bb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2536f127094ef15edce4348d1fa58781b14fcfcf9de082f2d2ff6bd44d3a976',1984,'IN','India','economy',71,'Aid: economic commitments—USSR (1970-
82), $1.5 billion; Eastern Europe (1970-82),
$105 million; OPEC ODA (1974-82), $1.8 bil-
lion; Western (non-US) ODA.and OOF
(1980-81), $2.2 billion; US, including Ex-Im
(FY70-82), $3.2 billion; military commit-
ments—Communist countries (1970-82),
boats, 8 submarines, 12 mine warfare, 9 am-
phibious, 10 corvette
Aircraft: 1,478 (855 jet) operationally as-
signed, including 1,391 (841 jet) in air force;
77 (14 jet) in navy; and 10 in Border Security
Force :
Missiles: (est.) 42 active SAM squadrons (20
SA-2, 15 SA-3, 3 training squadrons, 5 others)
$9.0 billion; US (FY70-82), $2 million','51420d266a141a6ae148574c5ea6063d86dcca9b93cdcac730137fb02e3ad2df','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e0965fdfdc608675bc6e815f3e5ce211b6f52e721f6971e82a141bcf40f5ded',1984,'ID','Indonesia','economy',73,'Aid: economic commitments—Communist
(1970-82), $175 million; US, including Ex-Im
(FY70-82), $3,125 million; other Western
countries ODA and OOF (1970-81), $8.3 bil-
lion; OPEC ODA (1981), $25 million;
military commitments—Communist (1970-
82), $32 million; US (FY70-82), $434 million
Aid: economic commitments— Western —
(non-US) countries. ODA and OOF .
(1970-81), $941 million; US, including Ex-Im
(1970-82), $1,038 million; Communist coun-
tries, (1970-82), $876 million; military
agreements—Communist countries (1970-
82), $2.1 billion; US (1970-82), $18.7 million','570160098aa08c458c0f94242e1cfd4ecb5fe4ecff85b08fc8d6b951d024b1a4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d9909f0e5368906fb9da3094a425faef4eddb8badf4d58cda3b9a33ffbe619c',1984,'IQ','Iraq','economy',74,'Aid: economic commitments—Communist
countries (1970-82), $770-million; US (FY70-
82), $3 million; Iraq pledged $3,310 million
in ODA to less developed countries (1974-80);
military commitments—Communist coun- -
Supply: produces some ammunition and.
small arms; dependent primarily on USSR
and East European Communist countries-for
combat materiel; increased import of weap-
ons systems from Western Europe to include
transport and electronic equipment, antitank
guided missiles, surface-to-air missiles, ar-
mored vehicles, super-extended and Mirage
F-] aircraft; 4 guided missile frigates, 6 mis-
sile:patrol combatants, and a replenishment.
oiler have been ordered from Italy
Military budget: estimated for fiscal year.
ending 31] December 1982, $12.0 billion; 70%
of the central government budget
tries (1970-82), $18 billion
Conimunieations :
Merchant marine: 49 ships 1.0 000 GRT or-
over) totaling 1,827,701 GRT; 2,452,849 .
DWT; 28:cargo, 20 tanker vand 1 cargo train-
ing
Defense Forées
Personnel: army 650, 000-450, 000; navy','23b12ea0aa7e7dd7e4cbcc5a3222b1e9a6a52a4a7ab557ce7c436012764eebf6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68d22781cadc2faf733ae870c7898ed8ab278871bde9fffd72d4bb4ad7e56097',1984,'JM','Jamaica','economy',78,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $435 million; other West-
ern countries ODA and OOF (1970-81), $480
million, OPEC ODA (1974-82), $100 million;
Communist countries (1974-82), $327 mil-
lion; military coramitments—US (FY8] -82),
$3.8 million]','3025ed2e6014fdae527a52acb28a9c6b231d1cec545cbbd4ab24c42b2bc3612a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd03bdc2d3787de2b581a3cd522aa4f42c581751095c6d8f4b58d1f9d1f4e9b1',1984,'KE','Kenya','economy',80,'‘Aid: economic commitments—Western
(non-US) countries ODA and OOF (1970-81),
$2.2 billion; US, including Ex-Im (FY70-82),
$352 million; OPEG ODA (1974-82), $145 :
million; Communist countries (1970-82), $46
million; military commitments—US (FY70-
82),$147 million .
Communications Hs
Merchant marine: 1 cargo ship (1,000 GRT
ee
or over) totaling 1, 168 GRT, 1 590 DWT
Defense Forces
Personnel: army about 13, 000, navy 650, air
force 2,500; paramilitary Police 1 800
Major ground hile 2 ae brigade
headquarters, 5 infantry battalions, 1 armor
brigade, 1 air cavalry battalion, 1 artillery -
brigade, 2 artillery battalions, 1 combat engi-
neer brigade, 2 combat engineer battalions, 1
airborne company
Aircraft: 72, including 28 jets, 38 prop (18
transport, 13 trainer, 2 utility aircraft), and
10 helicopters |
Supply: mostly from UK, but also from
France, FRG; Israel, Canada, and the US
46
CIA-RDP08-00534R000100050001-7','ac49e0a47e6cecc30e3638c40f8a27b6d460717b0e74f08d42d65f0f67e86fd6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d479b23634a925a765a391247d86cae9cfcdc2d3e255d68d7c288d76f328d1d5',1984,'LB','Lebanon','economy',84,'GNP: $3.8 billion (1979), $1,120 per capita
Aid: economic commitments—-OPEC ODA
(1974-82), $1,430 million; US, including
Ex-Im (FY70-82), $194 million; other West-
ern ODA and OOF (1970-81), $121 million;
Communist countries (1970-82), $9 million;
military commitments—US (FY70-82), $148
million; Comimunist countries (1970-82), $15
‘million','7d42bf208d71301159a3e870d72d2e01ef12fd789831a27a50fa4af4954b4015','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24271f1480b9f998ae792c07f6caaa797ac459c46452a00fb9da950d654a6ee7',1984,'LS','Lesotho','economy',85,'Aid: economic commitments— Western .
(non-US) countries ODA and OOF (1970-8)), 25X11
$329 million; US authorized (FY70-82), $117
million; OPEC ODA (1974-82), $30 million 25X11
. ZOK1
: . : ‘ H
Defense Forces , 25X1
Personnel: about 1,500-2,000 army; about °
1,200 police; no paramilitary capability |
Major ground units: 3 battalions, 1 engineer 25X1
company, 1 signal company, and 1 support |
company 7 25X11
Aircraft: 5 prop, 5 helicopters ( _ 25X11
Supply: ground force equipment from UK, 7
Iran, and FRG 25X11
Military budget: for fiscal year ending 30 °
March 1982, $12.5 million; 4.5% of central
government budget 25XK1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7 ,
P
Pn en Ee. ee
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
—25K1
a','979fcb8691202a2b7e2bef3028700011610c566bee9610631decf91d2c70cf18','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e71de64408d666cac68de45357ea502e3a29d96dda920f30827808622abefd5',1984,'MG','Madagascar','economy',90,'Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-895 X 4
$782 million; Communist countries (1970-
82), $203 million; US (FY70-82), $29 million;
OPEC ODA (1974-81), $150 million; milita25X 1
commitments—Communist countries (1979 5X1
82), $117 million 25X1
25X1','68bef0ba919f4dc514c84335b0d95fa930c7db85f95306a5dbd325f7503af272','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27fa2dbaa304984e37dae341df581228be0c8092ab5cfcd6232f427768197693',1984,'MY','Malaysia','economy',92,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $169 million; Western
(non-US) countries, ODA and OOF (1970-
81), $1.3 billion; OPEC ODA (1974-82), $415
million; military commitments—US (FY70-
82), $154 million :','88865ddb43c443fac7d3decfb959ca4941f0a25ab84db5b6832c55a786f026e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bed034399ca3eee27cc56a20129addf426833108adebfdb94cb07568aa0451a',1984,'ML','Mali','economy',94,'Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-825X1
$921 million; OPEC ODA (1974-82), $305
million; US, including Ex-Im (FY70-82),
$146 million; Communist countries (1970-
82), $119 million; military commitments—25X 1
Communist (1970-82), $163 million; US
(FY70-82), $0.9 million 29X11
Defense Forces
Personnel: 7,500 army, 400 air force, 2,000
gendarmerie, 700 police, 720 nomad security
guards, 1,500 republican guard, 150 Soviet
military advisers 25X1
Major ground units: 4 infantry battalions, 1
paratroop battalion, 1 tank group, 1 engineer
battalion, 1 special battalion, 1 mixed artil-
lery group, and 1 SA-3 battery
Aircraft (army): 50 (including 23 fighter, 3
trainer, 8 helicopters, 1 utility, and 15 trans-
port) 25X1
Sil dependent on foreign countries,
mainly the USSR; also has received eauip-29X1
ment from France, China, FRG, Japan, an
Spain 25X1
ZINA 1
Military budget: for fiscal year ending 31
December 1980, $37.0 million; about 20% of
central government budget
Secret
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret','870648188161b1a93baab59c7c088abaf09731a2d4fac18c85174f8431d25a14','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e8dddeb1f39da250837c43efcadb885004d7984d30b5ea758806254d9173d58',1984,'MT','Malta','economy',95,'Mediterranean Sea
(See reference map V)
Aid: economic commitments—US, including
Ex-Im, $171.6 million (FY70-82); other
Western bilateral ODA and OOF (1970-81),
$197 million; China (1972), $45 million;
OPEC ODA (1974-82), $145 million','17789c370116ccc7e2fe33e69200e14ca821e3bd62d6608929c9c6ce30faccc5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35139136a46118918ea5616a6b3c849420a5a2fa6507b553645bfdd9da507276',1984,'MR','Mauritania','economy',99,'Aid: economic commitments—-OPEC ODA
(1974-82), $1.6 billion; Western (non-US)
countries ODA and OOF (1970-81), $422
million; Communist countries (1970-82), $98
million; US, including Ex-Im (FY70-82), $88
million; military commitments—Commu-
nist countries (1976), $4 million','52f83cae4857dcdfdd2e222eb54c8bacee54ab3aa699874e6e047c8bad21c47a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38dfab7a91cf2d212b7e11f035a3fdac16e2290c51a7378c7b7293f18e1092a8',1984,'MU','Mauritius','economy',101,'Aid: economic commitments—OPEC ODA
(1974-82), $25 million, Western (non-US)
countries (1970-81), $179 million; Commu-
nist countries (1970-82), $40.2 million; US
authorizations (FY70-82), $33 million','ad9902cbf2a710141e8d0bdd1ef6f9a7aa32b47549683beb61788bf45032981f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8178cbb7e5106d3a3515f7f687c01e3631f22110c0ee19f819477394e332a11',1984,'MA','Morocco','economy',107,'Aid: economic commitments—Western . . 25X11
(non- US) countries ODA and. OOF (1970- 81), Z0A1
$2.0 billion; US, including Ex-Im.(FY70- -82), 5X1
$682 million; OPEC ODA (1974-82), $2.6 bil-
lion; Communist countries (1970-82), $2.25.
billion; military commitments—US (FY70- : 25X11
82), $304 million; Communist countries
(1970-82), $116 million 25X11','efe4e6bd7cbe39fe3cce87339808b1e9bb94f5dc647c28384e904c8474179ea7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdf0eda64acf8bb25829916794f01f642f52f9cd7ecaab2442249effb83afd9b',1984,'MZ','Mozambique','economy',108,'Exports: (OECD only) $224.7 million (c.i.f.,
1981); cashew nuts, cotton, sugar, mineral
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret
25X1°
Aircraft: 92 (58 jet, 17 prop, 17 peleopiers
era''s).
- = a. ZA |
Missiles: 8 SA-3 launchers, 39 oe A-5 launchers
products, timber products, tea, copra
Imports: (OECD only) $362.0 million (f.0.b.,
1981); machinery and electrical equipment,
cotton textiles, vehicles, petroleum products,
iron and steel
Aid: economic commitments—Western
(non-US) countries ODA and OOF (1970-81),
$968 million; Communist countries (1970-
82), $400 million; US, including Ex-Im
(FY70-82), $99 million; OPEC ODA (1974-
82), $90 million; military commitments—
Communist countries (1970-82), $446 million
Communications 7
Merchant marine: 7 ships totaling 18,764
GRT, 28,061 DWT; includes 6 cargo, and 1
tanker
Defense Forces _
Personnel: 18,000 army, 6,000 béider uard,
700 navy, 1,000 air force
Major ground units: the army has 8 motor-
ized infantry brigades, 1 counterinsurgency
brigade, and 1 armored brigade that serves as
a presidential guard; the border guard has 4
infantry brigades
Ships: 15 units, including 10 coastal patrol
craft
59
25X11
| 25X1
x1
~ 25X15X1
25X11
25X1
25X1
25X11
“25X11
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Prats Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret','5265a2bf1af239d1795613e9db83eb03da7fc2d2b24ba711209aeb7767284193','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60e2ac88d31b2b8d9c8228119b83657685e1225a3ffc2cac362f0ff666901119',1984,'NA','Namibia','economy',109,'(South-West Africa)
(See reference map Vil)
GDP: approximately $1.5 billion (est. 1983),
$1,500 per capita; real growth rate about
. —2% since 1980
Exports: $1.0 billion (f.0.b., 1980 est.); dia-
monds, uranium, base metals (blister copper,
lead-copper-zinc concentrates, refined lead),
cattle and karakul pelts, fish products (pil-
chard products, rock lobster, white fish)
Imports: $766 million (f.0.b., 1980 est.); grain
and other food products, steel, fertilizer, ce-
ment, textiles, and capital goods
Major trade partners: Republic of South Af-
rica supplies about 90% of country’s imports;
‘ most of the rest of Namibia’s trade is with the
UK and the FRG
‘Defense Forces
Personnel: about 20,000-26,000 total active
duty composed of 15,000-18,000 South Afri-
can Defense Force (SADF) personnel in
Namibia, 5,000-8,000 personnel in the South-
West Africa Territorial Force (SWATF), and
about-1,000 personnel in an irregular battal-
ion of ex-Angolans; SWATF is composed of
white, black, and colored personnel; it was
formed in 1980 and consists of 13 infantry
battalions, an airborne battalion, and a sup-
port unit; in addition, there are some
5,000-7,000 SWATF reservists not on active
duty; rebel forces—6,000-8,000 South-West
Africa People’s Organization guerrillas,
mainly at camps in Angola and Zambia
Secret ae','a97a5b1392e58294d33787f684713f42bdc07a87d25d5704c76ed532456aa5e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb0b65776e669e3c2add382601db71a412413410588617ab47aac519bdb40a6',1984,'NR','Nauru','economy',110,'(See reference map X)
‘Aid: economic commitments—Communist
countries (1970-82), $230 million; OPEC
ODA (1974-82), $55 million; US (FY70-82),
ue million; other Western ‘countries (1980-
81), $189 million |
Defense Forces
Personnel: 25,000 army
Major ground units: 14 infantry battalions
(subordinate to 1 palace and 7 infantry bri-
gade headquarters elements), 1 parachute
battalion, 1 artillery regiment, 1 engineer
battalion, the King’s Household Cavalry, and
other service elements; the army also in-
cludes 28 separate infantry companies
Supply: produces some small arms ammuni-
tion; performs small arms repair; bulk of |
military suppliés obtained frorn India and
‘France; lesser amounts from UK, US, China,
and FRG; 1983 deliveries included ARC |
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11,
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','3ed5767c1472ce902bbfef31f61e42b9f7f9978d2bb68a07721b36862aec3c99','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d88d99d8b440345367c97da36ff9bad820027e2d529d220c939e704222caa2c7',1984,'NE','Niger','economy',115,'Aid: economic commitments—Western
(non-US) countries ODA and OOF (1970-81),
$1,089 million; US, including Ex-Im (FY70-
82), $143 million; Communist countries
(1970-82), $110 million; OPEC ODA (1974-
81), $45 million; military commitments—US
(FY81-82), $4.9 billion
Defense Forces
Personnel: 2,600 army (plus 28 French and 6
West German. advisers), 100 air force (plus 6
French advisers), 800 Gendarmerie (plus 13
French advisers), 1,500 Republican Guard,
1,000 national police, and 200 Presidential
Guard ,
Major ground units: 3 defense zones with 1
small battalion in each
Aircraft: 9 (7 transport, 2 utility)
Supply: dependent on France exclusively un-
til 1964; since then has obtained ground force
materiel from other non-Communist coun-
tries, including Belgium, Israel, FRG, and','a51da7cdeff00cf7d3e7e708030f276c82c71415e5cd0b9b09b1146abe82530b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b687f9b80f9f397aad050c6a455fc673691978cc16252657530b4c2fd13bdde1',1984,'NG','Nigeria','economy',116,'Lagos é
(See reference map Vii)
Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-81),
$833 million; US, including Ex-Im (FY70-
82), $540 million; Communist countries,
(1970-82), $1.6 billion; military commit-
ments—Communist countries (1970-82),
$199 million
25X1','1746626ef9542ad3dd9428ee5e63a21602dd7ee45d3417135b5b646030e13b37','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59aaa5ef6ace2234f5eabdd702b5ad1e4d295877ea1c4f5a18aa114531543a8c',1984,'PK','Pakistan','economy',121,'Aid (including Bangladesh before 1972):
economic commitments—US (FY70-82),
$2.0 billion authorized (excluding what is ~
now Bangladesh); other Western countries
ODA and OOF (1980-81), $680 million;
OPEC ODA (1970-82), $2.5 billion commit-
ted; Communist countries (1970-82), $1.3
billion; military commitments—US (FY70-
82), $3.6 billion; Communist countries
(1970-82), $890 million','c33b5246e35811a6304a735340cab78a798ba3111b461f58c8932f823d2e10c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b81f94278f42f339183c35ddb6684d0678790f3b8797bd7b65b4e3d52d55a924',1984,'PH','Philippines','economy',127,'Aid: economiccommitments—US, including
Ex-Im (FY70-82), $1.8 billion; Western (non-
US) ODA and OOF (1970-81), $1.0 billion;
Commiinist (1975-82), $66 million; OPEC °
ODA (1974-82), $35 million; military com-
mitments—US (FY70-82) $536 million’
central government budget','05b410ef171d38deb156e95dcd493433f5e08875d0d2b149c6beae909ef634d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c41f32d3765080690ec0de95cb37d1db817278f2f9899918e2c440d83524ae85',1984,'PL','Poland','economy',129,'Aid: Western countries est. $20 billion
(short-,.medium-, and long-term debt, end of
1979); Polish bilateral economic aid commit-
ments to non-Communist''less developed
countries, $1.8 billion (1954-82)
Aid: Qatar pledged $1. 6 billion in ODA to less
developed countries (1974-82)','46bff093d2a4948ff3ca18db0f73b95b26521536ae0f128c31fee76207e2c8cb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8fc31f49d206e355b12c7bcbfa97aae6fdef4d77e162337a2eeb2cbb5d20690',1984,'RO','Romania','economy',131,'Aid: Western countries—estimated net in-
debtedness at end of 1979, $6.7 billion; 25x1
Romania has extended bilateral economic
aid totaling $3.1 billion to non-Communist
less developed countries (1956-82)
Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970- 81),
$726 million; OPECODA(1974- 82), $35 mil-
lion; Communist countries (1970-82), $58
million; US, including Ex-Im (1970-82), $41
million; military commitments—Commu-
nist countries (1970-82), $9 million; US
(F Y80-82), $1.6 million
Defense Forces
Personnel: about 5,000 army, 1,500 gendar-
merie (activated in late 1975 and still
organizing); military advisers—16 Belgian,
20 French, 3 FRG, 14 Chinese
Major ground units: 3 paracommando bat-
talions, 9-10 prefectural companies, 1
reconnaissance squadron, 1 heavy weapons
company, | engineer company, 1 aviation
St. Christopher and Nevis
(formerly St. Christopher-Nevis-
Anguilla)
company, and a logistic support base
Aircraft: 10 (2 turboprop, ] prop, 7 helicop-
ters)
Supply: dependent primarily on Belgium;
has received equipment from France, UK,
FRG, Belgium, Italy, Libya, and China
72
$
25X1
25X1
(See reference map MD
25X1
Defense Forces :
Local security forces: 300 Royal St. Christo- 5X1
pher-Névis Police Force; Coast Guard
(division of the police); 1 29-foot patrol boat 25x41
and 2 27-foot port security boats
5X4 25X1
25x11
55x
25X11
25X1
é
25X1
25X1
CIA-RDP08-00534R000100050001-7
Q
‘
d
‘
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
St. Lucia St. Vincent and The Grenadines Sao Tome and Principe
xe Attentic Ocean fe
Caribbesn See
(See reference map III) (See reference map iM) (See ‘feleiance vil)
25X1
29X11 Defense Forces Defense Forces Defense Forces
; 25X14 Local security forces: 515 Royal St. Lucia Local security forces: 550 Royal St. Vincent Personnel: Army, est. 1,200; foreign person-
Police Force; 30 St. Lucia Auxiliary Con- Police Force; 1 75-foot patrol boat and 2 27- nel include 50-60 Cuban army troops, 1,000
25X1 stabulary; 1 27-foot port security boat foot port security boats (police) (est.) Angolan troops, 100 (est.) Guinea-Bissau
(PSB)—police troops, 100 Soviet advisers, unknown number
of Libyans and North Koreans
25X1
Ships: several small boats for patrolling terri-
torial waters between Sao Tome and Principe
normally have crews of armed military per-
sonnel 25X1
Aircraft: 4 total (2 AM-2 Colts added in 1983)
25x14 25X1
»
‘
73 Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','8b008ddbbb8dbb982ae2bc6665393251fd07736de41cf48629dbb4c11aae7dad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d60cdf18e780a7710c58549110eeb1466511c57684bd79d4bbb0559e5350dec5',1984,'SA','Saudi Arabia','economy',132,'_ Riyadh,
SAUDI
ARABIA
(See reference map VI)
Aid: large aid donor; bilateral ODAc commit-
ments U974- -82), $24 billion
Cindinalicatons ;
Merchant marine:-154 digs @ 000 GRT or
over) totaling 3,114,209 GRT, 5,672;973
DWT; includes 9 passenger, 67 cargo, 46
tanker, 14 specialized carrier, 9 bulk,.2 lique-
fied gas, 6 roll-on/roll-off, and 1 container
Defense Forces
Personnel: 31,000 army, 5, 500 navy, 2 000
air defense, 17,000 air force (325. pilots),
25,000 national guard
Major ground units: | infantry brigade, 3
mechanized infantry brigades, 1 airborne
brigade, 2 armored brigades, 4 battalions (1
royal guard, } light armored, 2 field artillery);
12 J-HAWK air defense missile batteries; in
addition, national guard has 1 mechanized
brigade, 2 mechanized battalions, and 4] bat-
talion-size units
oe
| Ships: 13 guided missile patrol combatants, 4
, and 16 hovercraft,
'' 43 Nana
coastal minesweepers, 2 utility landing craft
. in naval force, 8 medium landing craft, 183
patrol boats/craft (iticluding coast guard),
. Aircraft: 323 (224 jet, 43 turboprop, 18 prop,
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
’ France
Supply: produces some ammunition, small
arms, and aerial bombs; otherwise relies on
Western sources, particularly US, FRG, UK
Italy, and France; 4 guided missile frigates
and 2 replenishment oilers are on order from
74','4b8fd43824c32b07720f96b06a93f7a66e219e3354f951d63bda65d20188679e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9758ee1e251028d3cf71ca6d7b8843c4dba035809bc9d9a1617b0714b1b34c4',1984,'SN','Senegal','economy',133,'(See reference map Vil)
Aid: economic commitments—Western ;
(non-US) countries ODA and OOF (1970-81),
$1.4 billion; Communist countries (1970-82),
$88 million; OPEC ODA (1974-82), $445 mil-
lion; US, including Ex-Im (FY70-82), $198
million; military commitments—US (FY70-
82), $8.9 million','06936cae8b13ea4cde5ebe7d8729112ae7b5484d77601128428430a8ff82aa87','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3077de96dcbecf22015423bbc3c000e4c32e8a2830f503add2d170ca12748b6f',1984,'SL','Sierra Leone','economy',136,'Aid: economic commitments— Western (non-
US) countries ODA and OOF (1970-81), $264
million; US, including Ex-Im (FY70-82), $86
million; Communist countries (1970-82), $63
million; military commitments—Communist
countries (1970-82), $5 million
Communications 25X1
Merchant marine: 1 cargo ship (1,000 GRT
or over) totaling 2,000 GRT, 3,000 DWT
Defense Forces
Personnel: 3,000 army, 45 navy, 5,000 police
and security units, 800-man special security
division 25X11
Major ground units: 2 infantry battalions
Ships: 1 fast patrol boat, 1 auxiliary
Aircraft: 2 helicopters (piloted and main-
tained by the French)
25X1
Supply: most army materiel from UK; some
small arms, ammunition, and a patrol boat
from UK and armored cars from Switzer25X 4
land; other materiel from the FRG and
Switzerland 25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','7498d9508ebbfb610f085d259a423a38187d4ec82cc737e7144704310ad7b18e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17aff774feea616490778ed1702897a55efffaa2b7c818d195814433cb47b47c',1984,'SG','Singapore','economy',137,'Ships: 18 amphibious warfare ships/craft; 26
coastal patrol-river/roadstead.craft, 2 mine
warfare oh 4 pay and service craft
+t
ener approximately 230 (50 je
s t tet i
Missiles: 3: Bloodhound SAM dies 1 HAWK
and Rapier units in formation
Supply: self-sufficient in production of small
arms, mortars, mortar ammunition, and ©:
quartermaster-type individual equipment;
some small patrol craft and missile gunboats
built; all other materiel imported, mainly
from UK, US, Taiwan, Israel, and Switzer-
land; 2 missile gun boats from FRG,
(See reference map > IX)
ship-to-ship missiles from Israel','a3cc773476c1d9c2055a672c55ec370302540e86095cc2d76afa9b19509c4578','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b294e5b144feafa4faab3a6212ea30d27c43f9f79137bbb8ce0112352291a51',1984,'SO','Somalia','economy',141,'Aid: economic commitments—OPEC ODA
(1974-82), $1.2 billion; Communist countries
(1970-82), $250 million; Western (non-US)
countries ODA and OOF (1970-81), $565 - .
million; US (FY70-82), $239 million; military
commitments—Communist countries (1970-
82), $429 million; US (FY80-82), $65 million','01c81ef7134637f680f26394d6d35a63d77f75277d3dbeef7371ef7403ee078b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cddbc761d5f4ef4512cfd8beadc3ab8a2e51e0286e3ecc71ab347dc5cb9b87d6',1984,'LK','Sri Lanka','economy',145,'Aid: economic commitments—Communist
countries (1970-82), $290 million; OPEC
ODA (1974-82), $325. million; US, including
Ex-Im (FY70-82), $529 million; other West-
ern countries ODA and OOF (1980-81), $712
million; military commitments—US (FY70-
82), $5.3 million; Communist countries
(1970-82), $35 million','8f89b9fa3bad9ba99ce5c5f23069f105c979b239a781c2dca7eae6413d5c8302','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21e2e484046c080989770a4f0545bed8eae65db806ed25ab5b1e1e77765476d6',1984,'SD','Sudan','economy',148,'Aid: economic commitments—OPEC ODA
(1974-82), $2.3 billion; Western (non-US)
countries ODA and OOF (1970-81), $1.9 bil-
lion; Communist countries (1970-82), $369
million; US, including Ex-Im (FY70-82),
$500 million; military commitments—Com-
munist countries (1970-82), $109 million; US
(FY70-82), $164 million','327e91d288b31a3fce5898ee33a2164c77e07be35c87a0f5eda184b4bac0e14e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d98b1866dce0c13d834e3e66e21bbe5bee07eefd4643a15f704eb0692f71c0dd',1984,'CH','Switzerland','economy',152,'Aid: economic commitments-~OPEC ODA
(1974-82), $6.6 billion, Communist countries
(1970-82), $1.6 billion; US (1970-82), $537.9
milliori, Western (non-US) countries (1970-
81), $338 million; military commitments—
Communist countries (1970-82), $14.3 billion
frontier guard, 1,800 fortification guard
NF)
Aircraft: 684 (437 jet, 113 prop, 38 turbo-
prop, 96 helicopters)
Missiles: 6 batteries of Bloodhounds
Supply: can produce armored vehicles, artil-
lery, rocket launchers, mortars, small arms,
ammunition, a variety of chemical warfare
agents, military electronics, and optical equip-
ment; some medium and heavy equipment is
imported from US and Western Europe; 60
Rapier surface-to-air missile systems, pur-
chased from the UK, are scheduled for
delivery between 1982 and 1987; assembles jet
aircraft (under license); produces light trainer
aircraft and utility transports, is collaborating
with US on ADATS SAM system
Aid: economic eoranuitnients= Wee:
(non-US) countries ODA and OOF (1970-81),
$3.9 billion; Communist countries (1970-82),
$468 million; OPEC ODA (1974-82), $325
million; US, including Ex-Im (FY70-82),
$280 million; military commitments—Com-
Supply: produces some ammunition;
dependent on external sources, primarily
PRC, but also UK, USSR, Canada, Sweden,
and Italy; Tanzanian Peoples Defense Force
, (TPDF) ships supplied by GDR, FRG, UK,
“USSR, and PRC; SAMs from USSR
Military budget: for fiscal year edi 380
June 1982, $155 million; 10.4% of central
government budget
munist countries (1970-82), $510 million
Commnmications
Merchant marine: 9 ships.(1, 000 GRT or
over) totaling 47,292 GRT, 61,528.DWT,; in-
cludes 7 cargo, 1 tanker, and 1 roll-on/roll-off
cargo .
Defense Forces
Personnel: 40,000 army, 850 naval wing, air
wing estimated at 1,000 (60 pilots), 1,430 po-
lice field force units, 130 police marine units
Major ground units: 3 infantry divisions, 8
infantry brigades, 27 infantry battalions, 8
artillery battalions, 6 armor battalions, 1
heavy mortar battalion, 6 air defense battal-
ions, 2 service battalions, 8 communications
companies, and 8 engineer companies
Ships: 27 patrol and utility craft, including 6
Shanghai-class patrol boats and 4 hydrofoil.
torpedo boats provided by China; the police
marine unit has its own Gar) craft
Aircraft: 75 (32 jet, 32 transports, 11 elicon
ters)
Secret
84','1e22b50c7fb1b204d6bef3c2ef2642d7ace9ee3aaa92930181250467c7a88da7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead12c5b2d5545d13410fff5d198f0ef6348a2afa991ff2d2beb581f6cbe97d2',1984,'TH','Thailand','economy',153,'(See reference map IX)
Aid: economic conimitments—US, including
Ex-Im (FG Y70-82), $551 million; Western
(non-US) countries ODA and OOF (1970-81),
$2.5 billion, OPEC ODA (1974-82), $150 mil-
lion; military commitments—US (1970- 82),
$870 million','d2ad559dbf3958d708fbabcf3283e07f747bccee0d50a33be0e6d99e3845fd81','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdcf64027ab68bb2bf6e3ba3ad5a39b7a7abdde64c7d1dcffae35cbbc940b43c',1984,'TG','Togo','economy',156,'Aid: economic commitments—Western
(non-US) countries ODA and OOF (1970-81),
$604 million; US, including Ex-Im (FY70-
82), $59 million, OPEC ODA (1974-82), $35
million; Communist countries (1970-82), $45
million; military commitments—Commu-
nist countries (1970-82), $4 million','af1cf35f864f4ed2d1340227311c9f1d1d318665b627c08cf6be1e918d188365','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfac227cc30293a463fa6c75e977f4b00a5b404b72d6fc112c8d86c8a33b0fb8',1984,'TN','Tunisia','economy',160,'Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-81),
$2.3 billion; US, including Ex-Im (FY70-82),
$487 million; OPEC ODA (1974-82), $955
million; Communist countries (1970-82),
$329 million; military commitments=Com-
muinist countries (1970-82), $31 million; US.
25X1
Supply: dependent on foreign sources;
mostly US, with lesser amounts from France,
Austria, Italy, and FRG; two patrol boats de-
livered from UK and two motor gunboats
from China in 1977; artillery and small arms
also received from China; produces some -
small arms ammunition
(FY70-82), $258 million
Aid: economic commitments—US, including
Ex-Im (FY70-82), $1.3 billion; other Western
ODA and OOF (1970-81), $4.1 billion; Com-
munist (1970-82), ‘$3.8 billion; OPEC ODA
(1974-82), $915 million; military commit-
ments—US (1970-82), $2,634 million
proposed central government budget
Ships: 18 destroyers, 3 frigates, 16 subma-
rines, 13 guided missile patrol boats, 36 fast
attack craft, 5 amphibious ships, 35 mine
warfare, 48 auxiliaries, 169 service
Aircraft: 991 (535 jet)—696 (535 jet) in air
force, 392 in army aviation, 21 in naval air
Missiles: 8 SAM squadrons (NIKE Hercules
with 72 launchers)
Supply: mostly dependent on foreign
sources, primarily US, Canada, and FRG;
manufactures some small arms, mortars,
trucks, and adequate quantities of ammuni-
tion; builds some of its naval ships, including
submarines, with technical and material as-
sistance’
Military budget: for fiscal year ending 31
December 1983, $2.6 billion; about 17% of','55cc478cc403354892e6a190da9f4251dc224e000b883cc606479ba735faf02e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18dc95565255820a50f8caef6bc92af4aa6c83bb12756cabc53be37242a5eca9',1984,'UG','Uganda','economy',163,'Aid: economic commitments—OPEC ODA
(1974-82), $305 million; Western (non-US)
ODA.and OOF (1970-81), $288 million; US,
including Ex-Im (1970-82), $42 million;
Communist countries (1970-82), $59 million;
military commitments—Communist coun-
tries (1970-82), $160 million','ae2c95d991ff9d309e8d48e676866bb14114db6d3de4c7517a21c2c299e9ad78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('055a0684fa9b9f24781b3ce0fbfe622505cbe0e3348b56d11331e8154733248b',1984,'AE','United Arab Emirates','economy',165,'Major industries: oil production fishing,
trading (oil production began in Abu Dhabi
in-1962, and in 1982 reached ‘900 million
b/d; Dubai has best port and is a commercial
center; oil was discovered in commercial ©
quantities in 1966 and production began in‘
1969; 1982 production 350 thousand b/d;
Sharjah began production in 1974; revenues
paid to UAE ih 1979 were $14 billion); fish-
ing, some boat building, handicrafts, animal
Aircraft: 129 (48 jet, 10 prop, 21 turboprop,
55 helicopters)
Supply: mostly from UK and France; some
from FRG, Italy, and Jordan
husbandry, pearling Be area
Aid: UAE pledged $6.9 billion in ODA to less
developed countries (1974-82)','994195ac73a9794ff3cf038b3cfe6f33ae7f24594b6e2a73a5e73e7463b8ec47','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5fea8117e5246c1e117d31232e925ac0b72abbcfcf1db78974c5c7576ec8599',1984,'VU','Vanuatu','economy',169,'Aid: economic commitments—US, including
Ex-Im (FY70-82), $474 million; Communist
countries (1970-82), $10 million; military
commitments—US (FY70-82), $49.1 million','7d36d39f01c82f97e77b5c6e8a1d629722abe047feb85ef19d498ff8c62cdea5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('055b946de343fadf93e1c99d6b81d7303ab4686a21a381d36774233285ab8126',1984,'EH','Western Sahara','economy',171,'Aid: economic commitments-—OPEC ODA
(1974-82), $3.4 billion; US, including Ex-Im
(1970-82), $128 million; Western countries
(non-US) ODA and OOF (1970-81), $436 mil-
lion; Communist countries (1970-82), $195
million; military commitments—Commu-
nist countries (1970-82) $1.2 billion: US
(1970-82), $16 million
Defense Forces
Personnel: 30,000 army, 850 navy, 1,000 air
force (50 pilots)
Major ground units: 10 infantry brigades, 1
airborne brigade, 8 armored brigades, 3 field
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
VOUITL
25X11
artillery brigades, 1 air defense brigade
Ships: 2 inshore minesweepers, 3 torpedo
boats, 6 patrol boats, 2 medium landing craft,
1 miscellaneous craft
Aircraft: 168 (117 jet, 8 turboprop, 2 prop, 41
helicopters)
Missiles: SA-2 sites currently under construc-
tion; SA-7 with YAR Army units
Supply: heavily dependent on outside
sources, primarily USSR; some aid from
Saudi Arabia and Saudi-sponsored programs
Military budget for fiscal year ending 31 De-
cember 1982, $750 million; 38% of central
government budget
93
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
25X1
25X11
25X1
25X11
25X11
25X1
25X11
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Yemen, People’s Democratic
Republic of (South Yemen)
(See reference map Vi)
Economy a
Aid: economic commitments—OPEC ODA
(1974-82), $705 million; Communist coun-
tries (1970-82), $374 million; Western
(non-US) countries ODA and OOF (1970-81),
$53 million: US (FY70- 82), $4.5 million; mili-
tary commitments—Communist countriés
(1970-82), $1.2 billion
Debt and aid: Yugoslav outstanding net ex- ''
ternal debt (medium/long-term) end 1982,
$18.28 billion; Yugoslavia has extended bilat- ;
eral économic aid totaling ‘about $1.3 billion
to''ndh-Cémmunist less developed countries :
(1966-80) obv«A
25X1
Aid: economic commitments— Western
(non-US) countries ODA and OOF (1970-81),
$3.2 billion; US, including Ex-Im (1970-82),
$667 million; Communist countries (1970-
82), $138 million; OPEC ODA (1974-82),
$200 million; military commitments—US
(1970-82), $147 million; Communist coun-
tries (1970-82), $63 million
Aid: economic Gommitments-—Western ine : a, oe )
(non-US) countriés ODA and OOF (1970-81),
$1.6 billion; Communist countries (1970-82),
$496 million; US, including Ex-Im (1970-82),
$274 million, OPEC ODA (1974-82), $160-:. opts Meath gia Be
million; military commitments—Commu- -
nist countries (1970-82), $325 million wales ’ 25X1
: Communications ni ;
Merchant marine: 1 cargo i totaling, 500 Do :
GRT, 9,100 DWT - 25X11
Defense Forces
Personnel: 12,500 army, 1,800 air force,
12,000 police, 1,400 paramilitary, 15,000
Zambian national service, and 4;000 army-re-
sete Sahel 25x
Major ground units: 6 infantry battalions, 1 Ss :
armored regiment, | artillery regiment eigce ots a s : 5 25X1
Aircraft: 160 (62 jet, 57 prop, 41 helicopters)
Missiles: SAM-7, SAM-8, Tigercat and Ra- 4
pier SAM launchers 25X1
Supply: until 1970s heavily dependent on
UK; since then, equipment received from the
USSR, China, North Korea, and several West
and East European countries; the USSR has
become the major supplier of military equip-
ment since 1979; Zambia has shown
willingness to seek military assistance from.
virtually any country 25X1
Secret ; 96
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','4ebc75800de48171b9ad242a649741de9aebde3f260ab0423b3dc6a868258ad5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8293364b5b9f2e62d359ed005f266a90eac3ce0da35c0aa5f056a32bf5da1e',1984,'ZW','Zimbabwe','economy',173,'(formerly Southern Rhodesia)
(See reference map Vil)
Defense Forces
Personnel: 41,500 army, 800 air force, 9,000
police, and 3,000 paramilitary police, 8,000
militia
Major ground units: 5 brigade headquarters,
20 battalions, 1 artillery regiment, 1
armored-car regiment, 1 parachute group, 1
Presidential Guard Brigade
Aircraft: 108 (20 jet, 56 prop, 29 helicopters)
Supply: mainly dependent upon UK since in-
dependence on 8 April 1980; North Korea
supplied material to equip 1 brigade of the
army
Taiwan
(China listed alphabetically)
(See reference map Vili)','f89e7e03f8cdfb7850b8a782fed7438107e911ce192ef1ad01ae5493165516c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18f93a8df7c2818c65c55ea8816848d076ece7d816aa1a5e414ac587917629ae',1984,'MX','Mexico','government',103,'Communists: Mexican Communist Party
(est. 100,000) and other minor far-left parties','20dbca5590702c284d6531d62c253dbb29fc8d6ddc7916cfacbc98734883d4ff','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c7e4e62798e3c32bea28727c9942fb2322f476ce4b07bc6aa31b3ec7083ae42',1984,'SD','Sudan','government',147,'Communists: party decimated following
July 1971 coup and countercoup; by mid-
1979 party had built up to an estimated
15,000 members; its role in student dem-
onstrations and strikes in August 1979 again
resulted in government crackdown on party,
but it ene retains capability to instigate
civil disorders','7458817a1accf6525de46a1b81c29027f265ed366a307156335eb30bd492e345','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a3d05017862df779d7f6f94cf6ad6f578fb054a42f6c83848a5f0ad3d3680c',1984,'DZ','Algeria','communications',3,'Merchant marine: 74 ships (1,000 GRT or
over) totaling 1,350,933 GRT, 1,947,395
DWT; includes 5 passenger, 23 cargo, ll
roll-on/roll-off cargo, 12 tanker, 8 liquefied
gas, 6 bulk, 9 specialized carrier
Telecommunications: excellent domestic
and international service in the north, sparse
in the south; Atlantic and Indian Ocean
INTELSAT and Soviet STATSIONAR serv-
ice, plus 15 domestic satellite stations:
485,000 telephones (2.5 per 100 popl.); 26 AM
and 102 TV stations; 6 submarine coaxial
cables
Defense Forces
Personnel: army 150,000, navy 6,500, air
force 12,000 (est. 325 pilots), National Gen-
darmerie 24,000
Major ground units: 9 motorized infantry
brigades, 5 mechanized infantry brigades, 3
armored brigades, 1 airborne brigade, 40 in-
dependent battalions, and training and
support installations
4YUN I
25X11
25X11
ows
25X1
25X
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
en on ne
—_—
RE EN A, IT ET RAE I BE TO A NIL, i Ua NS WP et a er','a32a526425fc2714be58a25e5340fc847071b601dd65d9fd76dbb0d433816286','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7682b33d704c47926cc6f166468a7d104ad38e9afdb37e3f9e2a13bc1546a7b9',1984,'AO','Angola','communications',4,'(See reference map VII)
Economy 7
Aid: economic commitments—Western °
(non-US) countries ODA and OOF (1970-81),
$334 million; Communist countries (1970-
82), $104 million; US, including Ex-Im
(FY70-82), $104 million; OPEC ODA (1974-
82), $35 million; military commitments— ,
Communist countries (1970- 82), $1.0 billion
Merchant marine: 14 ships (1,000 GRT or —
over) totaling 76,395 GRT, 118,705 DWT; in-
cludes 13 cargo, 1 tanker
Defense Forces
Personnel: army est. 35,000, navy 1,500, air
force 2,000, police corps 8,000, People’s De-
fense Organization (militia) 30,000-65,000,
Frontier Guard size unknown; foreign advis-
ers—600 Soviet, 5 Polish, 500 East German,
150 Romanian; foreign forces—30,000 Cu-
Aircraft: 271 (89 jet, 33 turboprop, 46 prop,
108 helicopters)
Missiles: at least 33 SA-3 /GOA launchers, 16
SA-6/GAINFUL launchers, several hundred
SA-7/GRAIL launchers, 8 SA-8/GECKO
launchers, 12 SA-9 GASKIN launchers
Supply: dependent on foreign sources, espe-
cially USSR and Cuba; some equipment left
by the Portuguese
ban troops and advisers and 6,500 civilians
Major ground units: brigade-size infantry
and air defense units; as many as 17 infantry
and mechanized infantry brigades of about
1,000 men each; about 55 combat battalions,
mostly infantry with about 300 men each
Ships: 8 medium amphibious assault landing
ships, 4 missile attack boats, 3 torpedo boats,
15 patrol boats, 5 utility landing craft, 5 me-
dium landing craft, 4 personnel landing
craft, and 5 cargo ships
25X1
25xX1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','795893486e1ae0fe532851438e4cf64b5e2800c9108178426aa674c22480ecb8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58c1fbfe241f94ea0b78891b95aab1ba79b125f4e5665d10a1c6d4eed32581a0',1984,'AG','Antigua and Barbuda','communications',5,'(See reference map Ill)
25X1
Defense Ferees
Personnel: Antigua and Barbuda Herne
Force 75 (5 officers)
Ships: 1 harbor patrol boat
Supply: mostly from the UK
oye
25X1
25X1
25X1
25X1
25X1
25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7 |
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','81122aa2c1eb046b903dc7fb543f0145541a53dd543b11a622c53fa292d7785d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cda3d4b31a2d67a10714042f50e8649e98016f39de2ad287ead6b47fb8b919a',1984,'AR','Argentina','communications',6,'|) ARGENTINA
Buenos Aires
. (See reference map IV)
Mg BG tel FS ap Fs ag
Merchant marine: 176 (1,000 GRT or over)
totaling 1 ,873,746 GRT, 2, 858, 033 DWT:. in-
cludes.2 2 passenger, 91 cargo, 56 tanker, 3.
liquefied gas, 16 bulk, iL .combination ore/oil,
5 specialized carrier; 1 roll- -on/ roll- off, 1 con-
tainer; additionally, 1 naval tanker and 1
military transport are sometimes used com-
mercially
Defense Forces
Personnel: 104,000 army; 35,900 navy (in-
cluding 2,900 in naval air, and 10,000 naval
infantry); 17,000 air force (535 pilots); 12,000
National Gendarmerie; 9,000 Argentine Na-
val Prefecture; 2,000 National Aeronautical
Police Force
Major ground units: 1 army headquarters, 5
army corps headquarters; 12 brigades (2 ar-
mored, 3 infantry, 2 mechanized infantry, 2
jungle infantry, 2 mountain infantry, 1] air-
borne infantry), 2 armored cavalry regi-
ments, 2 separate regiments (1 infantry, 1
cavalry), 1 amphibious engineer group, 1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
communications group, 2 mountain cavalry
reconnaissance detachments; additionally,
within each corps theres an armored cavalry
reconnaissance squadron, as well-as combat
support.and, service support ‘units including”
field artillery, air defense artillery, engineer,
corimunication, and military police
Ships: 1 light aircraft carrier, 2 sae missile
destroyers, 8 destroyers, 1 light cruiser, 2
guided missile frigates, 6 corvettes, 3 subma-
rines,''37 patrol ships and craft, 6 mine
warfare ships, 1 amphibious warfare ship, 19
amphibious warfare craft, 38
auxiliaries/service craft
Aircraft: 632 total; 389 air force (169 jet, 96,
turboprop, 87 prop, 37 helicopters); 148 navy
(45 jet, 54 prop, 34 turboprop, 15 helicopters);
95 army
Supply: produces some weapons, ammuni-
tion, armored personnel carriers and light
tanks, motor transports, an air-to-surface
missile, an antitank guided missile, andétarbo "
prop aircraft; assembled 2 submarines in
1972-73; has built a guided missile destroyer
with materials and technical aid provided by:
UK; currently producing 2 FRG- designed
submarines and 6 FRG-designed guided mis-
sile corvettes; past ‘dependence upon US,
Canada, and Western Europé being shifted *
almost exclusively to Europe
2 eo
Military budget: reported defense budget for
fiscal year ending 31 December 1983, $1.3
billion; 12.7% of the ntral governnient bud-','411d1a5f15ea739faa2a31d752846a949f71008a0d3efbad90a1fca9781ef1db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36c6739a27b7f38a77708b97bcaab54a1b3757fcb557e657c414fa2e7c0068ea',1984,'AU','Australia','communications',8,'Canberra
*
(See reference map X)
Merchant marine: 86 ships (1,000 GRT or |
over) totaling fe 717, 050 GRT, 2,702 260
DWT; includes ] passenger, 6 cargo, 5 con-
tainer, 23 roll- -on/roll- off cargo, 16 tanker, 33
bulk, 1 combination ore/oil, 1 liquefied gas
carrier
Defense Forces
Personnel: army 33,096, navy 17, 183 (in-
cluding 1,600 naval air), air force 22,557 (800
pilots
Major ground units: 1 infantry division
headquarters, 6 infantry battalions, 1 Special
Air Service Regiment (battalion), 3 artillery
regiments (battalions), 1 armored regiment
(battalion), 1 light AD regiment (battalion), 2
cavalry regiments (battalions), 1 aviation reg-
iment (battalion)
Ships: 12 principal combatants, 6 subma-
tines, 17 coastal patrol craft, 6 amphibious
craft, 3 mine warfare craft, 7 auxiliary craft,
and 4 service craft
Aircraft: approximately 522 (209 jet), includ-
ing 63 (20 jet) in naval air, 389 (199 jet) in air
force, and 70 (nonjet) in army aviation
Missiles: Rapier SAM system, delivered in
1979,andRedeyel si
Supply: produces antisubmarine missiles,
light aircraft, some types of army equipment,
light armored vehicles, small arms and am-
munition, and ships, including destroyers;
a ee Cee ee ee ee ee ee a ay Sere Cre we ee Vrae e
25x11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
submarines and limited quantities of jet
fighters and heavy equipment purchased
abroad (US, UK, Canada, FRG, Belgium, and','33eb56baea5bea8069b56e931f37befb902b5b7700613ef528fc57a35dd39a5d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00a4533edee7c283e2851440b0bc6a2767a5276f384c8cb0812d99c62652a3a',1984,'FR','France','communications',9,'25X11
Pi
(See reference map V)
''
Merchant marine: 326 ships (1,000 GRT or
over) totaling 10,168,920 GRT, 18, 236,839 25X14
_DWT; includes 16 passenger, 188 cargo, 22
container, 57 roll-on/off cargo, 74 tanker, 8
-liquefied gas, 35 bulk, 5 combination ore/oil,
and 2] specialized carrier
25X1
Defense Forces
Personnel: army 305,000, navy 68,400 (in-
cluding 11,500 in naval air, 680 in naval 25X1
amphibious group), air force 100,120 (3,000
pilots), national gendarmerie 89,300 ''
Major ground units: army consists of 1 arm20X1
headquarters with 3 corps with 8 light ar-
mored divisions, 5 light infantry divisions, 1
alpine and 1 airborne division, 1 Foreign Le-
gion demibrigade, 1 amphibious interven-
tion brigade, 1 Foreign Legion group, 40
nondivisional combat and artillery regiments
in France, and 13 independent combat over-
seas regiments; Army and corps combat
support units include 4 I-HAWK missile air
defense, 5 other air defense, and 5 Pluton tac-
tical nuclear regiments (French regiments 2 {
are roughly equivalent in size to US battal-
ions) ; DAX1
Ships: 2 aircraft carriers, 1 training cruiser, ]
guided missile cruiser, 5 guided missile de-
stroyers, 14 destroyers, 24 frigates/corvette,
5 nuclear-powered ballistic-missile subma-
rines (SSBNs), 20 attack submarines, ] |
experimental submarine, 19 patrol .
ships/craft, 28 mine warfare ships, 26 am-
phibious, 61 auxiliaries
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
a a ee re I
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
25X1
Aircraft: 3,230 (1,424 jet), including 700
nonjet in army aviation, 376 (115 jet) in naval
aviation, and 2,154 (1,309 jet).in the air force
Missiles: army has 4 I-HAWK battalions, 5
Pluton battalion equivalents; 6 Roland I regi-
ments (64 launchers); air force has 4 Crotale
squadrons
Supply: develops and produces ground force
equipment of all types in quantities sufficient
for domestic needs plus considerable exports;
produces all types of ships up to and includ-
ing nuclear-powered ballistic-missile
submarines; naval armaments, electronics;
exports frigates, submarines, patrol boats,
and auxiliaries; independently produces and
exports a wide variety of aircraft and missile
systems, including intermediate-range ballis-
tic missiles, surface-to-surface, air-to-
surface, surface-to-air, air-to-air, and anti-
ship, antitank missiles; some aircraft
purchases from the US; collaborating with
the UK and FRG in joint aircraft develop-
ment and production programs, and the UK,
FRG, and Italy in joint missile development
and production programs; produces small
quantities of offensive chemical warfare
agents and biological/chemical warfare de-
fensive materiel
Secret
2 baht
Supply: mostly UK, some US equipment
Military budget: for fiscal year ar ending 8]
December 1982, $22.7 million; 9.0% of cen-
tral government budget
36
20X14
LOA |
25X1
25X1
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
25X11','e9ceda0a4d1442053a919836025227a0af7a8f40b78e858ec385a8d0cf4ea70e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52bdb0bc8b5e866ae6d33124503d4798d225a5e07d6d6b56dd942cbc83be1762',1984,'AT','Austria','communications',10,'‘Vienna,
AUSTRIA &
(See reference map V)
Merchant marine: 12 ships (1,000 GRT or
over) totaling 67,499 GRT, 106,071 DWT; in-
cludes 9 cargo, 1 container, 2 bulk:
Defense Forces
Personnel: army 36,500, air force 2,275 (200
pilots), gendarmerie 11,000
Major ground units: 1 mechanized division,
29 militia regiments, 3 artillery battalions, 1
armored reconnaissance battalion, 3 infantry
battalions, 3 engineer battalions (1 division
controlled), 3 air defense battalions (1 divi-_
sion controlled)
Aircraft: 162 (32 jet, 29 prop, 14 turboprop,
87 helicopters)
Supply: produces some small arms and am-
munition, trucks, artillery, light armored
vehicles, and tank destroyers; current sources
of other items are the US, Western Europe,
The Bahamas
(See reference map Ili)
Merchant marine: 23 ships (1,000 GRT or
over) totaling 264,025 GRT, 315,161 DWT;
includes 11 cargo and 2 roll-on/roll-off, 2 25X1
tanker, 5 passenger, and 3 bulk; a flag of con-
and some Communist countries
5
venience registry 25X11
Defense Forces 25X1
Persorinel: 420 25X1
Ships: 1 fast patrol an eR) 10 patrol *
boats (PB) 25X1
Supply: mostly from the UK, 25X11
25X1
,.20K1
fe. 25x11
25X1
Secret oo
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Bahrain .
(See reference map VI)
Merchant marine: | cargo ship of 1 600
GRT, 2,600 DWT
Defense Forces
Personnel: 2,000-man defense force, 100-
man naval wing, 100-man air wing,
4,000-man police force; equipment includes
110 Panhard APCs and 50 armored cars, 9
81- -mm mortars, 8 40-mm and 4 35-mm anti-
aircraft guns, 6 MOBAT towed antitank
guns, 30 106-mm recoilless rifles, 8 105-mm
guns, 300 LAW antitank rockets
Ships: 1 guided missile patrol boat, 19 patrol
-boats/craft, 2 medium landing craft, 10 yard
and service craft
Aircraft: 16 helicopters
iMissiles: 150 TOW antitank guided missiles,
84 RBS-70 SAMs
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Bangladesh:
(See reference map Vill)','4bf10f28f79868286660b54fd355193a92459be69da58b9e5651df5add60cc2a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3da1de6ebfd9844dc519d48522f274f9cbc3940418519ac8d15a866fe5581ec0',1984,'BE','Belgium','communications',14,'Merchant marine: 86 ships (1,000 GRT or
over) totaling 1,793,453 GRT, 2,839,097
DWT; includes 4 passenger, 28 cargo, 4 con-
Defense. Forces
Personnel: army 63,700, navy 4,450, air
force 19,600 (512 pilots), national gendar-
merie 16,300
Major ground units: Belgian Army’s I Corps
has 2 mechanized division headquarters, 4
brigades, 1 armored infantry brigade (re-
serve), 1 motorized infantry brigade
(reserve), 3 reconnaissance battalions, 1
Lance battalion, 1 8-inch self-propelled how-
itzer battalion, 4 air defense artillery
battalions (including 2 HAWK and 2 35-mm
Gepard), 2 155-mm self-propelled howitzer
battalions, | 155-mm towed artillery battal-
ion (reserve), and 2 combat engineer
battalions, 2 combat engineer batallions (re-
serve); Interior Forces Command has 1
paracommando regiment, 2 light infantry”
regiments (reserve), 2 light infantry battal-
ions (reserve), 2 combat engineer battalions, 2
combat engineer battalions (reserve), plus lo-
gistic elements; army aviation has 3 light
aviation squadrons
25X1
25X1
Ships: 4 frigates, 27 mine warfare, 6 coastal
patrol craft, 4 auxiliaries
25X1
7 Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','3f3c7c54aace9e5b0d2b15c18a1de3756859d816f445592f328755d0d4142803','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6246b99b60ae714ea79ce04525c6bd9a0670d230a88e74dad47cfda8791d843b',1984,'BZ','Belize','communications',15,'(formerly British Honduras)
Gulf of soe 5
Mexico f f
Caribbean
Sea —
fx Balmopan
| MEXICE . BELIZE
HONDURAS;
(See reference map Ill)
Defense Forces
Since independence from the UK in 1981,
Belize has been almost totally dependent on
the continuing presence of the 1,800-man
British Forces Belize (BFB) for its national
defense; the 1,400-man ground element of
the BFB and the 400-man air element in Be-
lize ona rotational basis are headquartered at
Airport Camp, adjacent to Belize Interna-
tional Airport; major units: 1 infantry
battalion, 1 engineer squadron, } signal
troop, 1 armored reconnaissance troop, I
field squadron, 1 Army Air Corps detach-
ment; the British Government is providing
training, equipment, financial aid, and mili-
tary advisers for the upgrading of the Belize
Defense Force so that the UK forces may
eventually leave; in addition, the British
Armed Forces maintain a company of
Caribbean-area-trained Royal Marine Com-
mandos in the UK for immediate airlift to the
Caribbean
Personnel: Belize Defense Force consists of
525 regulars and 290 Volunteer Guard per-
sonnel; police 500
Major ground units: Belize Defense Force, 3
regular companies, at a low level of combat
effectiveness; the reserve-type Volunteer
Guard is constabulary in nature and lacks any
combat capability
Ships: Coast Guard, 2 40-foot patrol boats
(PB)
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
Aircraft: a nascent air element reportedly has
2 Norman Britten aircraft
Military budget: for 1984, $4.5 million; 4.5%
of the central government budget','7ae9c13e3e22585bd098105e85a890093839e4d2f666b7a7ad01f2bf9dc142f5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8e273f8d476fde451da22307d4b3d360bb4fe30d6f7916469867f1410cf0fbc',1984,'BJ','Benin','communications',16,'(formerly Dahomey)
appen vauta
NIGERIA”
(See reference map Vil)
Merchant marine: 1 cargo ship (1,000 GRT
or over) totaling 3,000 GRT, 4,400 DWT
Defense Forces
Personnel: army 3,200, air force 160, navy
100, civilian militia 1,500, gendarmerie
2,000, presidential guard 100; USSR advisers
20, Cuban advisers 8, East German advisers
2, North Korean advisers 12, Libyan advisers
unknown number
Major ground units: 3 interarms battalions, 1
paracommando battalion, 1 air defense bat-
talion, 1 service battalion, 1 engineer
battalion, 2 armored groups; most battalions
and groups company strength
Ships: 6 patrol boats (4 ZHUK from USSR, 2
P-4 without torpedo tubes from North Korea)
Aircraft: 1 AN-26, 2 AN-2, 3 F-27, 3C-47, 1
Dessault Falcon-50 business-type luxury jet,
1Boeing 707
: CIA-RDP08-00534R000100050001-7
25X11
25X11
at sate dl
ne ae a ae ee el a aia Ne Nt EI gue RE SE IO SI etl
i
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08- DOD SAR CORO Sees -7
Supply: depends mainly on France and the .
USSR; some aid from the Netherlands, FRG,
Libya, and other countries
4
Military budget: for fiscal year ending 31
December 1981, $31.8 million; about 15% of
central government budget
»
©
e','2db7f032d6264f07d5939fc95e7f6bb2ab2019f6d4661b7480569b85337acc98','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23e70ace9736dc7f92c114f736a4f865e8aadff4aa39433ccec905f76e989d0b',1984,'BM','Bermuda','communications',18,'(See reference map II)
Defense Forces
UK is responsible for external defense; con-
tingencies now met by deploying ships from
the Eastern Atlantic; in addition, the British
Armed Forces maintain a company of
Caribbean-area-trained Royal Marine Com-
mandos in the UK for immediate airlift to the
Caribbean
Local security forces: Bermuda Regiment,
463 (force is basically a reserve unit—in-
cludes headquarters staff of 20 and
Volunteer Reserve Force of 38); Bermuda
Police Force, 365; Bermuda Reserve
Constabulary, 78
wewres
Bhutan . ie
(See reference map Vill)
Defense Forces
Defense has been the de facto responsibility
of India since 1949; possibly up to 10,000 In-
dian Army troops stationed‘in Bhutan;
frequently rotated to maximize Indian troop
familiarization ° 25x11
‘ Personnel: 6. “Odo lapiroR. )army and 550} 25X11
ace guard troops: poorly’ equipped ‘and
tamed! - _ 7 “95X14
Major ground units: possibly Sue — ;
arate squads arid platoons
225X1
25x14
25X1
Secret .
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Bolivia
(See reference map''IV)
Merchant marine: 2.cargo ships (1, 000 GRT
‘or over) totaling 15,130 GRT, 18,934 DWT; 1
owned by- pelwian Navy,
Defense Forces
Personnel: army 20,200, navy 2,665, air
force-4,000 (400 pilots)
Major ground units: 9 divisions comprising
35 regiments (15 infantry, including 1 jungle
infantry, 1 motorized infantry, 4 infantry as-
sault, 1 airborne, 3 armored, 6 cavalry, 1
cavalry assault, 4 artillery), 6 engineer battal-
ions (including 1 combat engineer) and 1
engineer company; in addition, there are 4.
separate units—1] infantry regiment, ] cav-
alry regiment, 1 military police battalion,
and.1 signal company
Ships: ocean-going cargo ship; 5 river patrol
craft; 1 harbor patrol.boat; 43 service craft,
including 34 small-river transports and 1 hos-
pital barge; 1 medium amphibious assault
landing ship
‘Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
‘Netherlands, and Ganada
Aircraft: 134 total; 138 air force (18 jet, 46
turboprop, 63 prop, 6 helicopters); 1 navel
aviation (turboprop)
Supply: totally dependent on foreign sources
primarily US; also Argentina; Brazil, Israel,
10
Missiles 12 SA-7 frien','65ba8a74a36a6f96f2d556844fe26e5ae894006cad5738712778f0d7904760e0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e7018b9d4408d6e912bef1fcbe4146c25825acbf7b2a0e628a12266c050ad38',1984,'BR','Brazil','communications',22,'Merchant marine: 297 ships (1,000 GRT or
over) totaling 5,113,825 GRT, 8,595,168
DWT; includes 1 passenger, 156 cargo, 49
tanker, 8 liquefied gas, 55 bulk, 17 combina-
tion ore/oil, 5 specialized carrier, 6 roll-on/
roll-off cargo; additionally, 1 naval tanker
and 4 military transports are sometimes used
commercially
Defense Forces
Personnel: army 182,750, navy 47,300 (in-
cluding 117 in naval air and 14,500 in
marines), air force 49,679 (1,584 pilots), mili-
tarized state police constituting state guard
184,000 :
Major ground units: 4 army headquarters; 2
separate area command headquarters; 8 divi-
sions comprising 20 brigades (3 infantry, 9
motorized infantry, 3 armored infantry, 4
mechanized cavalry, 1 armored cavalry), 2
mechanized cavalry regiments, and 23 com-
bat and combat support battalions; 6 separate
brigades (1 motorized infantry, 1 air defense
artillery, 1 airborne, 1 mixed, 2 jungle infan-
try), 2 engineer construction groups, 3
separate cavalry guards regiments, and 18
separate battalions (2 infantry-type, 3 infan-
try guards, 3 frontier, 5 military police, 1 .
railroad construction engineer, 3 signal, 1
combat engineer)
Ships: 1 ASW-support aircraft carrier, 16 de-
stroyers, 7 submarines, 10 patrol combatants,
6 coastal patrol craft, 7 river and roadstead
patrol craft, 6 mine warfare ships, 2 amphibi-
ous warfare ships, 3 amphibious warfare .
craft, 42 auxiliaries, 16 service craft (includes
8 auxiliary dry docks)
Aircraft: 692; air force 644 (192 jet, 181 tur-
boprop, 214 prop, 57 helicopters); naval air
arm, 48 helicopters
Supply: produces infantry weapons, light ar-
tillery, ammunition, explosives, wheeled
armored and cargo vehicles, tanks, patrol
boats, auxiliary ships, and transport, trainer,
and light aircraft; also built 2 destroyers with
UK support; heavier equipment imported
from US and Western Europe; majority of
naval ships acquired from US and UK; with
technical assistance, intends to produce do-
mestically 4-12 corvettes and 3 submarines
Declassified in Part - Sanitized Copy ness for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Brunei
(See reference map !*)
25X1
Defense Forces 25K1
Personnel: Brunei has a military force of
about 3,700; police, about 1,700
Major units: 1 indigenous regiment consist-
ing of a regimental headquarters, training’
depot, 2 infantry battalions, 1 armored re-
connaissance squadron, 1 engineer squaQ5X
1 special boat squadron, an air wing, and 1
river flotilla; 1 British Gurkha anfaiiey 95X11
talion : 25X14 1
Ships: 3 missile attack bake 9 coastal 25xX1
boats, 3 river patrol craft, 2 amphibious craft,
and 26 small amphibious assault craft
Aircraft: 22, 2 light-wing aircraft, 20 helicop-
Ce 225x1
Supply: dependent primarily on UK; pur-
chased fast patrol boats from Singapore
ll
25X1 ee
25X1
25X11
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7','6d8389cc7c55bd2a2f7f680cb5beab12042468252510f4ae128bb895c20b4e8a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5662cad00442936cec35a468e46a8c3a415ef1537c11e9dbd2400ed8fdb0a10d',1984,'BG','Bulgaria','communications',23,'‘BULGARIA
* Sotia
(See reference map V)
Pipelines: crude oil, 193 km; natural gas, 920.’
km; Tesined products 418 km
Merchant marine: 102 ships ne 000 CRT and
over) totaling 1,096,600 GRT, 1,637,400
DWT; includes 2 passenger, 36 cargo, 1 cargo:
training, 17 tanker, 41 bulk, 1 combination
ore/oil, 2 specialized carrier, 2 roll- -on/roll-
off cargo
Civil air: 45 major transport aircraft (1978) °
t tt
Airfields: 385 total: 127 with permanent-
surface runways; 15 with runways 2,500-
3,499 m, 32 with runways 1,000-2,499 m, 338
with runways less than 1,000 m: 3 heliports
apie
WN
Telecommunications: inferior to most other
East European countries; meets only mini-
mum requirements of government and
public; wired broadcasts used extensively; 10
AM, 5 FM stations, 2,301,462 receivers; ] ma-
jor and 25 relay TV stations, 1,441,122
receivers; 640,842 telephones, 90.7% auto-
matic
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Defense Forces os
Personnel: (est.) ground forces 120,000, naval
forces 8,600, air and air defense forces
34,500; paramilitary 15,000; personnel in re-
serve (not on active‘duty)—(est.) ground
forces 700;000, naval. forces 21,000, air force
unknown ;
West fot
Major ground units: 8 motorized rifle divi-
sions, 9 brigades‘(5 tank, 3 SCUD [A&B]
tactical missile, 1 SA-4 SAM), 11 regiments (1-
airborne, 4 artillery, 2 antitank, 1 SA-6, 3
antiaircraft), 1 attack helicopter regiment, 4
engineer regiments, 1 pontoon bridge regi-
ment, 6 S-16 regiments
Ships: 2 submarines, 2 principal surface com-
batants, 3 patrol combatants, 2 mine warfare
ships, 18 coastal patrol-river/roadstead craft,
23 amphibious warfare craf t, 25 mine war-
fare craft, ] underway replenishment ship, 1
fleet support ship, 2 othér auxiliaries
Atrerafi (in operational tinits): 347 total, in-
cluding 79 air defense fighters, 64 counter air
fighters, 94 ground attack, 32 reconnais-
sance, 1] transports, 67 helicopters (includes
nave) netteopters)
esi 17 operationa] SA-2 SAM sites (102
launchers), 7 operational SA-3 sites-(35 4-rail
launchers); 1 SA-6 regiment and 1-SA-4 bri-
gade; 1 SSC-16 coastal defense site; the SA-7
is deployed with the Bulgarian ground forces °
on a limited scale; SA-5 sites are under con-
struction
Supply: very limited local production of
small arms, SP artillery and wheeled ar-
mored vehicles; USSR major supplier, with
West Germany currently active in supplying
ground forces production technology; naval
vessels from: UK, US, Yugoslavia, Denmark,
and Japan; in 1981] Bulgaria built a medium-
size naval auxiliary ship
12
Burma
(See reference maps Vill and IX)
Merchant marine: 15 ships (1,000 GRT or
over) totaling 63,243 GRT, 86,867 DWT; in-
cludes 12 cargo, 1 container, 1 tanker, and ]
specialized carrier
Defense Forces
Personnel: army 190,000, navy 7,000, air
force 8,000
Major ground units: 6 infantry division
headquarters, 152 battalions (145 infantry, 4
artillery, 2 armored, 1 antitank/mortar, 1-
antiaircraft artillery battery)
Ships: 5 patrol combatants, 36 coastal patrol,
48 river/roadstead patrol craft, 2 amphibious
ships; 3 auxiliary
Aircraft: approximately 118 (11 jets)
Supply: very limited local production; vari-
ous countries suppliers, especially FRG;
naval vessels from UK, US, Yugoslavia, and','9f78814bc915e41f5664eca32ff9a65e06e37273cf63f1bbb96c3e66f3e88f96','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de58e9c812a032fda458b99aeedb598ffd796e913ffea9bda47af9beb924c800',1984,'JP','Japan','communications',25,'CIA-RDP08-00534R000100050001-7
25X1
NT a ea I INE Gh A FN SN I IEE Te
ee eS ee ee ee ee ee
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
25X11
25X11
25x14
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
(See reference map VIil)
Merchant marine: 1,818 ships (1,000 GRT or
over) totaling 33,994,128 GRT, 57,573,169
DWT; includes 79 passenger, 472 cargo, 71
container, 27 roll-on/roll-off cargo, 397
tanker, 64 gas carrier, 279 bulk, 44 combina-
tion ore/oil, 385 specialized carrier
Defense Forces
Ships: 53 destroyer /frigates, 15 submarines,
51 mine warfare, 8 amphibious, 15 auxiliary,
and over 300 service craft (an additional
force of 404 patrol and service craft operates
under the jurisdiction of the Maritime Safety
Agency)
Aircraft: 1,591, including 308 in army avia-
tion, 310 in naval air, 832 (698 jet) in air force,
and 55 in Maritime Safety Agency','28626ebdcc06708d9fd5a87d1bf71d4cc784ecf3b09c03714293f2ee21266a8b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23eefe1563cc7ed9053fb4ba8958a87b3f2a8ef8c0287838f3cc4faf4fcbf93f',1984,'BI','Burundi','communications',26,'(See reference map Vil)
Econdiny ;
Aid: economic commitments—Western
(non-US) countries ODA and OOF (1970-81),
$444 million; Communist countries (1970-
82), $58 million; US (FY70-82), $31 million;
OPEC ODA (1974- 82), $70 million; military
commitments—Communist countries (1970-
82), $42 million
Defense Forces
Personnel: army 9,000; military advisers
20 French, 35 Soviet, 17 North Korean
Major ground units: 5 battalions (8 infantry,
2 paracommando), 1 support company, and 1
transport company (there are also 5 gendar-
merie companies with territorial
responsibilities)
Ships: 8 high-speed boats
Aircraft: 14 (10 prop, 3 helicopters
Supply: formerly. by Belgium but in recent
years has received materiel from the USSR,
China, France, UK, Greece, Euler a
and Libya
13
CIA- RDPO8- 00534R000100050001-7
JCurce','e5392c04785e6f134b93f09d80f4b2862267ccf9ff8d45980bed4d613207b28d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8b303de5aeb6530d432a74144fac37669af84706ffab8413f8b5da8b72f8634',1984,'CM','Cameroon','communications',27,'(See res map vil)
Merchant marine: 4 cargo ships (1, 000 C3z 5X1
or over) totaling 36, 792 GRT, 58,700 DW5
25X11
Defense Forces ;
Personnel: army 8,000, navy 350, air force,
350, gendarmerie 8,000, French advisers 5X1
(French Army 52, Navy 4, Air Force 14, gen
darmerie 12) 25X1
‘Major ground units: 4 infantry battalion5X 1
armored battalion, 1 engineer battalion, |
parachute infantry battalion, 2 artillery bat-
teries, 2 air defense batteries
Ships: 11, including 7 coastal patrol- 2 x4
river /roadstead craft, 2 amphibious warlare
craft, and 2 yard and service craft
Aircraft: 24 (13 transports, 5 fighter /trainers,
6 helicopters) - 25X1
Supply: mostly from France; smaller
amounts from other West European‘coun-
tries, US, China, and Canada y
25X11
Secret
: CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy
WouUlTe
Cameroon (continued)
Secret
Approved for Release 2012/09/20 :','4bc7d885c3d6fb9b833882d85d82daad3ef82a0bc2f7842ebc12a79b371ede00','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2291db99ba8d29c8b34a99fe262113d4fcee8ceb6561288ddb62c1360f63ece',1984,'CA','Canada','communications',29,'(See reference map Il)
Merchant marine: 105 ships (1,000 GRT or
over) totaling 746,082 GRT, 1,017,348 DWT;
includes 8 passenger, 31 cargo, 5 container, 1
roll-on/roll-off cargo, 31 tanker, 18 bulk, 9
specialized carrier, and 2 combination
ore/oil
Defense Forces
Personnel: Canadian Armed Forces 82,675
Major ground units: 1 mechanized brigade
group, 2 general purpose brigade groups, 1
airportable Special Service Force
Ships: 4 destroyers, 19 frigates, 3 submarines,
7 patrol craft, 10 auxiliaries
Aircraft: 807 (479 jet)
Missiles: 108 Blowpipe
Supply: limited production of armored com-
bat rehicles, small arms, artillery
ammunition, propellants, and high explo-
sives as well as military electronic items and
engineering equipment; most naval ships (ex-
cept submarines) and transport equipment
also produced; relies heavily on US and toa
lesser degree on UK; some antitank missiles
from France, medium tanks from FRG, and
Blowpipe missiles from UK for air defense
14
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
CIA-RDP08-00534R000100050001-7
25X11
CIA-RDP08-00534R0001 00050001-7
ae ee ee ee ae ae ee ee Ey a a i 4
25XK1
.
»
A eee BR ke Bt ke he le ee ett ed ie el ln i ee ae aa hoo 4
eB a
25X1
Ca do ae ee, ee ae
a i tl
a a a en” ee cae ik ee eat A a al i i a a ae On a Ta
we
»
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Cape Verde
(See reference map VII)','2cc4eb5939a0660b934670bd825833de5080b3bbb2f33ca2ad6ef4257aee7280','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be51866d5c419f608b2c2151c2adf344703fe33a2ecc6d419e8178e801340000',1984,'CL','Chile','communications',33,'Merchant marine: 41 ships (1,000 GRT or
over) totaling 506,127 GRT, 831,442 DWT;
includes 1 passenger, 24 cargo, 1 tanker, 2
liquefied gas, 7 bulk, 8 combination ore/oil, 2
roll-on/roll-off, 1 specialized carrier; addi-
tionally 2 naval tankers and 2 military trans-
guided missile patrol combatants, 1 subma-
rine chaser, 4 torpedo boats, 6 amphibious
warfare ships, 1 amphibious warfare craft, 14
patrol craft, 13 auxiliaries, and 16 yard and
service craft
Aircraft: 342 total; 245 in air force (133 jet, 40
turboprop, 50 prop, 22 helicopters); 36 in
navy (23 turboprop, 12 helicopters); 61 in
army (1 jet, 14 turboprop, 21 prop, 25 heli-
copters)
Supply: small amounts of armored cars, small
arms, rockets, ammunition, and military pro-
pellant and explosives are produced; has de-
pended mainly on UK for naval craft; aircraft
from Western Europe; and ground force
equipment from Western Europe and Brazil;
the Chilean Air Force is involved in 3 copro-
duction and assembly projects—the Piper
Dakota (parts have been indigenously pro- -’
duced since 1980), the T-35 Pillan (assembled
and partially produced since late 1981), and
the CASA 101B (Chilean production ‘of some
components started in January 1983)
Military budget: for fiscal year ending 31
December 1982, $1,548 million; about 18.5%
of the central budget
ports are sometimes used commercially
Defense Forces
Personnel: army 48,554, navy 22,000 (in-
cluding 145 in naval air and 3,749 in
marines), air force 12,500 (400 pilots), carabi-
neros (national police) 27,000
Major ground units: 6 divisions (5 infantry, 1
cavalry), 1 independent motorized mountain
infantry brigade, an Army Troops command,
and the Military Institute Command (non-
combat, equivalent to a division in strength)
Ships: 2 submarines, 2 light cruisers, 3 guided
missile destroyers, 2 destroyers, 2 frigates, 2
Secret
16','012bbb454839dd9a0d196f7c9ad23f587e4aae2fa3d57ca9d04047f3ac5ed889','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a47b1494578b36dc18a19f580a0ea2290e65c9d0272effb52c5c7210f021c9cd',1984,'CN','China','communications',34,'(Taiwan listed at
end of table)
Beijing *
60
(See reference map VIII)
Merchant marine: 907 ships (1,000 GRT or
over) totaling 8,206,955 GRT, 12,220,385
DWT; includes 53 passenger, 564 cargo, 5
cargo training, 17 roll-on/roll-off cargo, 3
container, | specialized carrier, 136 tanker,
128 bulk; in terms of DWT, about 31% of the
fleet is employed in domestic operations and
the rest in international operations to all con-
tinents; China beneficially owns an addi-
tional 140 ships (1,000 GRT or over) totaling
2,077,800 GRT, 3,251,300 DWT, which op-
erate under the Panamanian and British
(Hong Kong) flags
Civil air: 156 maior transport aircraft
equate international systems maintained
primarily for official use; telephone and tele-
graph-nationwide, limited telex and
facsimile service available; TV, AM radio,
and wired broadcast available nationwide,
FM radio in a few locations; international
service via radio, landline, and satellite;
about 4 million telephones, 4 per 100 popl.;
2,000 telegraph offices; about 130 interna-
tional telex circuits; about 350 radio
broadcast stations; 2,300 wired-broadcast
distribution stations; 50 million radio and 140
million wired-broadcast receivers; about 40
major TV stations and.150 secondary trans-
mitters; 5 million TV receivers; international
facilities include ] coaxial submarine cable to
Japan, buried coaxial cable and radio-relay to
Hong Kong, 10 INTELSAT ground stations
\\
d
q
<e28 ?
Telecommunications: fair domestic and ad-25X1 5
‘
{
ra
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X
°
woo 4
ay
25x1
a,
~ Arar
,
25X11
accessing Pacific and Indian Ocean satellites,
high-frequency radio and openwire line cir-
cuits
Defense Forces iat.
Personnel: China’s armed forces are unified
and include three main service branches—
Army, Navy, Air Force—and technical and
combat service support arms, including the
Second Artillery Corps (China’s strategic bal-
listic missile force); there are 4,238,210
members of the armed forces (manually tab-
ulated results of China’s 1982 census),
8,491,300 ground forces, 360,000 Navy (in-
cluding 300,000 general service and 40,000
naval air), and 485,000 Air Force (including
220,000 assigned to ACW, SAM, and AAA
units); there are approximately 100,000-
150,000 troops assigned to the Second
Artillery Corps; other personnel are attached
to the various corps-type service support and
combat support arms; personnel in reserve
(not on active duty)—Army about 10 million
(armed militia); Navy and Air Force have no
62 amphibious warfare ships, 1,033 coastal
patrol-river/roadstead craft (included in this
total are 228 missile attack boats and 257 _
small torpedo boats), and 20 mine warfare
craft
Aircraft: Chinese People’s Liberation Army
Air Force (CPLAAF) total 5,962, including
3,605 jet air defense fighters, 109 jet and 7
prop intermediate-range bombers, 330 jet
and 35 prop medium-range bombers, 580 jet
attack aircraft, 147 jet and 10 turboprop re-
connaissance aircraft, 44 medium-range and
219 short-range transports, 290 prop and 170
helicopter liaison aircraft, 150 support heli-
copters, and 270 combat trainers; Chinese
People’s Liberation Army Naval Aviation
(CPLANA) total 1,008, including 620 jet
fighters, 9 jet intermediate-range bombers,
140 jet and 18 prop medium-range bombers,
20 jet and 6 prop reconnaissance aircraft, 31
jet attack aircraft, 2 medium-range and 43
short-range transport, 24 prop liaison air-
craft, 55 helicopters, and 40 combat trainers
known organized reserve
Major ground units: Army has 11 territorial
commands (military regions) and 36 army
headquarters, with a total of 210 divisions—
179 combat divisions (116 infantry, 14 tank, 3
airborne, 5 border defense/internal defense,
4] garrison), 31 combat support (16 field ar-
tillery, 15 antiaircraft); in addition, the Army
has 290 independent regiments—126 com-
bat (18 tank, 29 garrison, 76 border
defense/internal defense, 2 cavalry, 1 recon-
ndissance), 93 combat support (12 field
artillery, 3 antiaircraft, 7 antichemical war-
fare, 54 engineer, 17 signal), 71 combat
service support (motor transport)
Ships: 1,278 combatant units (not including
800 yard/service craft and about 500 mecha-
nized landing craft), supported by 3
underway replenishment ships, 5 materiel
support ships, 85 fleet support ships, and 175
other auxiliaries, organized in 3 fleets—
North, East, and South Seas; combatant units
include 1 ballistic missile submarine (used for
SLBM R&D), 1 nuclear-power ballistic mis-
*sile submarine (undergoing at-sea trials), 2
nuclear-power attack submarines (1st unit
not operational), 111 attack submarines, 14
destroyers, 26 frigates, 8 patrol combatants,
Antiaircraft artillery: some 30 divisions of
CPLAAF AAA, in addition, there are 15
PRCA AAA divisions (listed above)
Missiles: defensive—120 CSA-1 sites for air
defense (including 9 unoccupied sites, and 3
training areas) plus 3 R&D sites; 22
land-based antiship cruise missile sites; stra-
tegic (land-based offensive)—China has
deployed a small number of ICBMs capable
of striking targets throughout the USSR and is
deploying a few long-range ICBMs capable
of reaching continental US targets; China also
has a regional nuclear strike capability with
_approximately. 65-120 medium- and inter-
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
VEULe
including submarines and guided missile de-
stroyers, and unknown quantities of
chemical and biological warfare defensiv? 5X1
materiel; transport aircraft obtained from
USSR, UK, and US; helicopters from Frar25X 4
and West Germany 25X11
Military budget: although China provides an
annual budget figure in yuan, it is clear that
this figure substantially understates actual
defense spénding; tentative estimates indi-
cate that defense spending for 1984 will be
equivalent to about $20 billion
mediate-range missile launchers
Supply: military industrial base:supports a
comprehensive and integrated modern
weapons program; production includes sub-
stantial quantities of infantry weapons,
tanks, armored personnel carriers, artillery
pieces, ammunition, radar and signal equip-
ment, trucks and jeeps, jet aircraft, lesser
quantities of surface-to-surface missiles,
surface-to-air and naval cruise missiles, as
well as some air-to-air missiles; naval ships,
17
25X11
25X1
25X1
25X1
Secret
> Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
wewave','a49a000127ccca5deecdd601c83f288f756b7be6c31158ef32cfb911886d47b6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3db4004a9ef4406638aa4b6b86e281b6517a176ee8e9092e450c10a323628f12',1984,'CO','Colombia','communications',35,'x Bogota
(See reference map IV)
Merchant marine: 37 ships (1,000 GRT or
over) totaling 265,513 GRT, 348,062 DWT;
includes 29 cargo, 6 bulk, 2 tanker
Defense Forces
Personnel: army 58,600, navy 8,228, air
force 3,850(285 pilots) sid
Major ground units: 2 divisions, including 5
brigades with 30 battalions (2 mechanized in-
fantry, 11] infantry, 3 mechanized cavalry, 3
artillery, 1 air-defense artillery, 3 construc-
tion engineer, | combat engineer, 2 military
police, 4 services); 6 independent infantry
brigades, including 33 battalions(13 infantry,
2 airborne infantry, 2 mechanized cavalry, 3
artillery, 4 construction engineer, 1 engineer
support, 2 military police, 6 services); 1 spe-
cial capital security brigade, including 7
battalions (2 infantry, 1 mechanized cavalry,
1 construction engineer, 2 military police, 1
services) and 5 schools battalions; 1 logistics
brigade, including 4 battalions (1 transporta-
tion, 1 maintenance, 1 supply, 1 quarter-
master); and 2 independent battalions (1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
intelligence/counterintelligence, 1 infantry
with Multinational Force and Observers in
Sinai) :
Ships: 3 destroyers, 1 frigate, 4 submarines, 2
coastal patrol craft, 25 coastal patrol /river
roadstead craft, 9 auxiliaries, 25 service craft
Aircraft: 291 (74 iets, 6 turboprop, 155 prop,
56 helicopters)
Supply: small arms, small arms ammunition,
mortar and artillery rounds and antitank
mines produced; US and Western Europe are
principal suppliers of ground force equip-
ment; Italy delivered 2 unassembled midget
submarines (assembly completed during
1973), and FRG delivered 2 1,000-ton sub-
marines in 1975 and is currently supplying 4
guided missile corvettes ;
25XK1
18
= ,','41a305d72c07832eee5ed503b39c001570b846634723b585d4acf02c59f6c389','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2654fb747cef805f681c68ec42baa9d93c8a094fb9f0ab4c480fba683ad27c6d',1984,'CR','Costa Rica','communications',39,'Merchant marine: 4 roll-on/roll-off cargo
ships (1,000 GRT or over) totaling 11,796
GRT, 17,965 DWT
25x11
Defense Forces 2X1
Personnel: Civi] Guard 4,500, primarily an
urban police/border control force (constitu-
tion prohibits armed forces); Rural uae” 5X14
Guard 3,200, arural police force (under opeé
ational control of Civil Guard Sate
emergency deployment)
Major ground units: approximately half of
the Civil Guard is stationed in San José; re25X1
mainder organized into 6 provincial capital
commands and 3 border area commands
(Northern, Southern, and Atlantic); forces in
San José consist of 1 radio patrol unit, 1 mili-
tary police company, | Presidential Guard
unit, and 5 Civil Guard companies: small R25X11
ral Assistance Guard detachments are
scattered throughout the country; increasing
numbers of Rural Assistance Guard persorp5X 4
nel are being used to augment Civil Guara
forces stationed along the Costa Rican-Nica-
raguan border ~ 25x1
25X1
Ships: 5 patrol craft
‘Aireraft: 6 prop (light), 3 helicopters’
. 25X11
" 25x1
25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','7cfb3598007ad8405cef3783d7bc6eca1f2af9d44998e48f63ff60bf76d113ac','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27203881c7b3d0e84c2117622f2c68232cb78db3369bdc2bc7c0b32c192534a',1984,'CU','Cuba','communications',40,'(See reference map Ill)
Merchant marine: 82 ships (1,000 GRT and
over) totaling 666,300 GRT, 957,600 DWT;
includes 53 dry cargo, 10 tanker, 8 bulk,.3
cargotraining, 1 specialized carrier, 1 passen-
ger; Cuba beneficially owns 10 additional
ships(1,000 GRT or over), 127,100 DWT, un-
der Panamanian flag
Telecommunications: modern facilities ade-
quately serve military, governmental, and
most civilian needs; excellent international
facilities via HF and satellite; 321,000 tele-
phones (3.3 per 100 popl.); 148 AM, 25 FM,
and 53 TV stations; 2 submarine cable, 1
Molniya and 1 Atlantic Ocean INTELSAT
station
’ Defense Forces
’ Personnel: ground forces 220,000-255,000
(includes 110,000-120,000 full-time active
duty troops—about 75,000 in Cuba, 37,000-
42,000 overseas—and 110,000-135,000
reservists capable of mobilization on short
notice); navy (MGR) 12,500; Air and Air De-
fense Force (DAAFAR) 18,500 (includes air
force, surface-to-air missile, air control and
warning forces, and some air defense artil-
lery); Special Troops 2,500; Youth Labor
Army (paramilitary) 80,000; Civil Defense
50,000 (in wartime would also include police,
firefighters, and others totalling over
100,000); territorial militia 100,000; Depart-
ment of State Security 15,000; Border Guard
Troops 3,500; National Revolutionary Police
15,000]
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
~ 25X14
Major ground units: ground forces in Cuba
organized into Western Army, High Com-
mand Reserve, Central Army, Eastern Army,
and the Isle of Youth Military Region; total 4
corps headquarters, 9 active divisions, 18 re-
serve divisions, 9 separate active brigades (4
artillery, I-frontier infantry, 1 air defense ar-.
tillery, 1 air assault, 1 naval infantry, 1 special
forces); basic combat unit is the infantry bat-
talion; overseas—2 Combat Commands
(Angola and Ethiopia), each with 4 brigades
Ships: 2 attack submarines, 1 frigate, 2 me-
. dium landing ships, 22 missile attack boats, 3
submarine chasers, 9 hydrofoil torpedo boats,
9 small torpedo boats, 11 patrol boats, 1 har-
bor patrol boat, 6 medium landing craft, 2
coastal minesweepers, 9 inshore minesweep-
25X11
ers, and 40 auxiliary service craft
Aircraft: 516 (300 jet including 42 MIG-
23/FLOGGER, 29 turboprop, 118 prop, and
69 helicopters)
Missiles: 24 operational SA-2 SAM sites and
"11 operational SA-3 SAM sites, at least 20 SA-
6 transporter-erector-launchers (TELs), at
least 12 SA-9 TELs, and unknown SA-7
shoulder-fired missiles; Atoll, Aphid, and
KERRY air-to-air missiles and SAGGER
antitank missiles; Navy has SAMLET (in re-
serve) for coastal defense, STYX cruise
missiles (aboard OSA- and KOMAR-class
PTGs) and SA-N-4 (aboard the frigate) and
SA-N-5 (aboard the medium landing ships
and some of the OSAs); Army has FROG,
SALISH tactical missiles (both in réserve),
and SNAPPER and SAGGER antitank mis-
siles assigned in unknown numbers
Supply: almost wholly dependent upon
USSR; produces some ammunition; assem-
bles some transport vehicles
Military budget: for 1983, $929.5 million:
9.4% of the central government budget
20°
: CIA-RDP08-00534R000100050001-7
25X1
25X1
25x11
25X1
25X11)
.
le
ee |
gg gg ee NS
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1','3e9debf604087e7590d7e7919c3145f018af4c549ab2dfe6d2b34dec9497739e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('083be227a330de71782b7d2102dbebba8aac9d86ef18555a183567299832fa3e',1984,'CY','Cyprus','communications',41,'(See reference map Vi) ©
Merchant marine: 382 ships (1,000 GRT or
over) totaling 1,611,708 GRT, 2,382,939
DWT; includes 10 passenger, 252 cargo, 3
container, 10 tanker, 2 liquefied gas, 1 com-
bination ore/oil, 26 bulk, 6 roll-on/roll-off
cargo, 22 specialized carrier; all but a few are
owned and operated by Greek nationals
Defense Forces
Personnel: 12,000 Greek Cypriot National
Guard (CNG), including 650 Hellenic Army
mainland regulars and 225 naval personnel,
3,700 Greek Cypriot Police; foreign forces in-
clude 2,280 UN Forces in Cyprus
(UNFICYP), 2,640 UK Army (not in
UNFICYP), 700 British Royal Air Force (not
in UNFICYP), 2,850 Hellenic Army Contin-
gent and Raiding Force battalion; other
forces include 44,000 Greek Cypriot Reserve,
4,600 Turkish Cypriot (Security Force), in-
cluding 400 Turkish Army mainland
regulars; 10,500 Turkish Cypriot reserves;
19,000 Turkish (mainland) peacekeeping
force’
Major ground units: Greek Cypriot National
Guard has 55 battalions (20 infantry, 4 raid-
ing forces, 1 reconnaissance, 1 mechanized, 1
armored, 7 field artillery, 1 engineer, J: anti-
aircraft artillery, 1 ordnance, 1 signal, 15
reserve.infantry, and 2 reserve artillery);
UNFICYP has military contingents from
Austria, Canada, Denmark, Finland, Ire:
land, Sweden, UK, a medical detachment
from Austria, and a 175-man civilian police
detachment comprised of personnel from:
Australia, Austria, Denmark, and Sweden;
Hellenic Army contingent has 1 infantry reg-
iment and 2 raiding force companies: _
Turkish forces include 1 corps headquarters,
2 infantry divisions, and supporting forces;
Turkish Cypriot forces have 7 infantry bat-
tglions
Ships: Greek Cypriot National ‘Guard naval
element has 3 patrol boats (est.)
'' Aircraft: Greek Cypriot Police has 8 or 4 heli-
copters, 1 BN Islander aircraft commander,
and 2 or 3 single-engine aircraft; they are pe-
riodically loaned to the CNG; British Royal
Air Force has 1 SAR helicopter squadron (8
helicopters), and there is 1 UK Army Air
Corps flight with 8 helicopters
Supply: Greek Cypriots (government forces)
entirely dependent on foreign supplies for
their materiel; since 1964 have received in-
fantry weapons, machineguns, mortars,
artillery, ammunition, trucks, armored per-
sonnel carriers, tanks, antitank missiles, and
launchers from Czechoslovakia, Poland, Por-
tugal, Egypt, Yugoslavia, and Brazil; torpedo
boats from-Yugoslavia, Malta, and the USSR;
also, UK- and US-manufactured infantry
weapons, artillery, patrol boats, armored
cars, and radar equipment were received
from Greece; Yugoslavia, Portugal, and Bra-
zil are currently providing most heavy
equipment
21
Czechoslovakia
" CZECHOSLOVAKIA
(See reference map V)
Economy 25X1
Aid: Czechoslovakia has exterided bilateral
economic aid totaling $2.7 billion to non- ''
Communist less developed countries 25X1
(1954-82) and has received some medium-
and long-term credits from Western coun-
tries and the USSR 25X1
Merchant marine: 19 ships (1,000 GRT or
over) totaling 183,500 GRT, 275,000 DWT;
includes 14 cargo, 5 bulk
Civil air: 54 major transport aircraft (1982)
25K1
Airfields: 140 total; 41 with permanent-
surface runways; 1 with runways 3,500 m or
over; 17 with runways 2,500-3,499 m; 69 with
runways 1,000-2,499 m; 53 with runways less
than 1,000 m; 4 heliports 25X11
Telecommunications: systems are used pri-
marily to support operations of government
and industry; requirements of public receive
secondary consideration; good coverage is.
provided by 23 AM and 16 FM broadcast sta-
tions; 3,883,882 receivers; 10 major TV 25X11
stations, supplemented by 300 relay stations;
4,000,000 TV receivers; 2,900,000 est. tele-
phones (96% automatic)
25X11
Defense Forces
Personnel: (est.) ground forces 149, 000, air
_and air defense forces 56,500, paramilitary
forces 11,200; personnel in reserve (not onac-
tive duty)—(est.) ground forces 15 million;
25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Czechoslovakia (continued)
air force unknown; Soviet forces (CGF) in
Czechoslovakia as of 1 January 1982, 80,900
(76,000 ground; 4,900 air)
Major ground units: 11 divisions (5 motor-
ized rifle, 5 tank, 1 artillery), 6 brigades (3
SCUD SS-1 tactical missile, 1 SA-4, 2 artil-
lery), 2 antitank regiments, 5 SA-6 regiments,
1 antiaircraft artillery regiment, 1 airborne
regiment; 3 SA-6 regiments are division
subordinate
Ships: est. 50 river patrol types, all frontier
guard
Aircraft: (operational units) 820, including
170 air defense fighters, 138 counter air
fighters, 160 ground attack, 48 reconnais-
sance, 66 transports, and 238 helicopters
Missiles: 26 operational SA-2 SAM sites (156
launchers); 14 operational SA-3 SAM sites (56
4-rail launchers); 1] SA-5 site under construc-
tion; 1 SA-4 brigade, 5 SA-6 regiments, and
563 SA-7 SAM systems are deployed with the
Czechoslovakian ground forces
Supply: produces substantial quantities of in-
fantry weapons, rocket launchers, ammuni-
tion, trucks, tactical signal equipment,
infantry combat vehicles, self-propelled anti-
aircraft guns, and tanks; produces copies of
Soviet antitank missiles, and jet trainer and
small transport aircraft as well as small
amounts of chemical warfare agents; chemi-
cal and biological warfare defensive materiel;
dependent on the USSR for more complex
equipment and combat aircraft; has received
amphibious armored reconnaissance cars
from Hungary, as well as trucks from Roma-
nia and GDR, antitank rocket launchers from
Bulgaria, and trucks, fighter aircraft, and heli-
copters from Poland; river craft are imported
or built under license from GDR
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','7c3a04b04b84ccd06d1303aca8f17ff0088575e13654eba5645cecf7d83a91ef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b50d1c9cd175cc3c3d02461ecdb45d22bf195fea8b43da66c214601326eac0b',1984,'DK','Denmark','communications',43,'(See reference map V)
Merchant marine: 268 ships (1,000 GRT or
over) totaling 4,970,866 GRT, 7,514,876
DWT; includes 20 passenger, 97 cargo, 29
container, .18 roll-on/roll-off cargo, 44
tanker, 17 liquefied gas, 20 bulk, 2 combina-
Military budget: proposed for fiscal year
ending 31 December 1983, $1.2 billion;
about 4.3% of proposed central government
budget
ee ee
tion ore/oil, 21 specialized carrier
Defense Forces
Personnel: army 18,358, navy 5,800, air force
6,750 (210 pilots)
Major ground units: army is organized intoa
field army of 1 mechanized division and 1
mechanized division equivalent (with only 2
standing mechanized brigades during peace-
time), a light infantry brigade equivalent,
and 6 regimental combat teams plus support
under regional commands
Ships: 2 frigates, 3 corvettes, 4 submarines, 5
patrol ships, 10 missile attack boats, 6 torpedo
boats, 8 patrol craft, 7 minelayers, 6 mine-
sweepers
Aircraft: 203 (141 jet), including 23 army and
8 navy :
Missiles: 520 Redeye launchers, 4 I-HAWK
squadrons
Supply: dependent on US, Canada, UK, and
Western Europe; most naval ships produced
domestically; produces small quantities of
biological /chemical warfare defensive equip-
ment; some small arms mortar and artillery
ammunition, some airframes, avionics and en-
gine parts, and electronic equipment
22
}
25X1
25X1
25X1
25X1
i
gg i TT I a I I I a
‘eraft','6a088f6b154ab4e7d9ac77c55d4527598c9d367d931ec87f9e8e8d0a3f426b14','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c225d80ff4738f64a63a6923eb3a7fdd3624d809b7d8b3b2ba2468eb95e3a6a',1984,'DO','Dominican Republic','communications',46,'Merchant marine: 9 hie (1,000 GRT or
over) totaling 24,886 GRT, 43,178 DWT; in-
cludes 2 cargo, J bulk, 6 roll-on/roll-off car25X11
lice), 1 27-foot port security boat (PSB)
Djibouti—7 landing craft
Aircraft: French—10 Mirage III jet fighters,
6 antitank and armed reconnaissance heli-
copters, 9 assault helicopters; Djibouti—3
‘intermediate-range transports, 3 utility air-
Supply: France is the leading supplier of mil-
itary equipment
1
23
: DAX1
25X1
Defense Forces 25X1
Personnel: army 12,900, navy 4,900, air
force 4,300 (90 pilots) 25X1
Major ground units: 3:infantry brigades (7
tactically organized and 6 constabulary ba25X 1
talions); a combat support command (1
armored battalion, | artillery battalion, and 1
constabulary battalion): a service support
command (1 engineer, 1 communications, ]
transportation); Directorate General of Mili-
tary Training (1 recruit training battalion), a
presidential guard battalion, and a military
hospital; navy has 2 marine infantry battal25X1
ions " 25X11
Ships: 5 patrol ships (PGF), 4 patrol craft
(PC), 5 patrol boats (PB), 1 medium landin25X 1
ship (LSM), 1 medium landing craft (LCM), 1
utility landing craft (LCU), 18 auxiliaries, 1]
service craft 25X1
Aircraft: 52 (1 turboprop, 38 prop, 13 heli-
copters) plus 6 air police companies and a 25X1
special forces group 25X1
Supply: dependent upon US and Western 25x 1
Europe; has assembled some armored cars
and ammunition 25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Secret
25X1
(continued).
Ecuador > 5X1
’ (See reference map IV)
Merchant marine: 44 ships (1,000 GRT or
over) totaling 338,414 GRT, 494,163 DWT;
includes 22 cargo, 20 tanker, 1 container, and
1 specialized carrier
Defense Forces
Personnel: army 27,500; navy 4,100 (includ-
ing 1,200 marines), air force 3,800 (175 pilots)
Major ground units: 7 infantry brigades, 1
armored brigade, | special forces (paratroop)
brigade, 5 separate battalions (2 engineer, 1
signal, 1 civic action, 1 military police)
Ships: 1 destroyer, 1 frigate, 3 patrol combat-
ants, 2 submarines, 22 patrol craft, 3
amphibious warfare ships, 6 medium landing
craft, 4 personnel landing craft, 6 auxiliaries,
11 service craft
Aircraft: 158 total; 118 (63 jet, 32 turboprop,
9 prop, 9 helicopters) in air force; 8 (1 jet, 5
turboprop, 2 helicopters) in navy; 37 (1 jet, 10
turboprop, 3 prop, 23 helicopters) in army,
Supply: dependent primarily on US; some
major purchases from Western Europe (FRG
has supplied patrol boats, 3 missile attack
boats, and 2 submarines; Italy is currently
‘ supplying 6 guided missile patrol combat-
ants; fighter aircraft purchased from Israel;
France has supplied over 100 armored vehi-
cles in addition to fighter aircraft)
Secret 24
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
aU
25X1:
25X11
eee ae
25X1
25X1
a','0c3839b24c4f9e973e2b353ba8a94223bd22b316e5c2b92a4fda81e0d4ad4beb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ce00949781d315e9fe055c235b9a0bcc32dd2fea9f88d60c143cf6323bd43b',1984,'EG','Egypt','communications',47,'(See reference maps VI and Vil)
Merchant marine: 100 ships (1,000 GRT or
over) totaling 490,954 GRT, 675,527 DWT,
includes 8 passenger, 76 cargo, 13 tanker, 1
container, 1 bulk, and 2 specialized carrier
Defense Forces
Personnel: army 320,000, navy 20,000, air
force 27,000 (1,085 pilots), air defense 80,000,
frontier corps and coast guard 17,300
Major ground units: 2 separate field armies
and a total force of 1] divisions (3 infantry, 5
mechanized infantry, 3 armored); 7 inde-
pendent infantry brigades; 1 independent .
mechanized brigade; 1 independent ar-
mored brigade; 1 paratroop brigade; 2 air
assault brigades; 5 commando groups; 26 air
defense SAM brigades
Ships: 5 destroyers, 12 submarines, 2 frigates,
22 missile attack boats, 50 patrol boats, 3 air
cushion vehicles, 17 mine warfare craft, 16
25
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
secret
25X11
EI Salvador . 25X11
25x11
(See reference map III)
Merchant marine: 1 cargo ship (1,000 GRT
or over) totaling 1,800 GRT, 3,200 DWT
25X1
Defense Forces ; ;
Personnel: army 25,500, navy 450 (plus 100
civilian technicians), air force 450 (320 civil-
ian technicians), national guard 4,230, nat-
ional police 5,500, treasury police 1,677|_ |
3 ~25x1
Major ground units: 7 brigades (6 infantry, 1
artillery), 6 military détachments, 1 com- 25X11
mando instruction center, 1 engineer
instruction center, and’ 1 signal instruction
center comprising a total of 40 battalions (6
infantry, 31 countersubversion, 2 field artil-
lery, 1 antiaircraft artillery); 1 cavalry 25X11
regiment, | military police company, | air-
borne battalion (4 immediate reaction
battalions), 1 medical company
Ships: 12 armed, sal patrol craft (3 PC, 2
PBR, and 6 PBS), 1 harbor craft (locally pro-
duced) nw
25X1
Aircraft: 94 (22 jet, 4 turboprop, 31 prop, and
37 helicopters) 25X11
Supply: army and air force equipment pro-
cured from US, Western Europe, Israel, and
Yugoslavia; navy depends on US
Secret
\\ Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','29abc459b32116ef8c9b8c93e43b11bff1c0b330fb981336178063267836cf67','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61132548d5dd4d23944d1e320d2f001af6b66d3dcf26b715b73074f3477d0dcf',1984,'GQ','Equatorial Guinea','communications',49,'(See reference map Vil)
Merchant marine: 2 cargo fits (1,000 GRT
or over) totaling 6,400 GRT, 6,600 DWT
Defense Forces - :
Personnel: army. 1,500; navy 125- 150: militia
(paramilitary) 600; military advisers—Cuba
unknown, Spain 40, Morocco 300-400
Major equipment: 10 Soviet amphibious per-
sonnel carriers (3 small and 7 large); 3 ZHUK
patrol craft and 2 aircraft (transport)
Supply: cages a variety of sealitats equip-
ment primarily from Spain and Morocco; in
the early -1970s Soviet equipment was im-
ported
Secret','c63ff673219a71b4613bd1c4269c81c74e07d9750c5697e0363ed8d7d918c3ab','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e755144da9ffec7d159d3343253d9d57adc36952b0a9d9bdd95ff0045afec4e',1984,'ET','Ethiopia','communications',51,'(See ‘reference map Vil)
Merchant marine: 5 ships (, 000 CRT o or
over) totaling 20,340 GRT, 27,595: DWT; in-
cludes 3 cargo and 2 tanker
Telecommunications: fair system of radio
relay and wire; Addis Ababa principal cen-
ter, Asmara secondary center; 83,800
telephones (0.2 per 100 popl.); Soviet facilities
located in Addis Ababa and elsewhere; 8 AM,
no FM, and 2 TV stations; 1 Atlantic Ocean
INTELSAT station
Defeuise Fores
Personnel: army 240,000, navy 3,500, air
force 4,000, air defense (missile) 3,000, emer-
gency police 9,000
Major ground units: 22 infantry divisions
with organic armor and artillery support, 1
administrative/support division
Ships: 16 patrol craft, 8 landing craft, 1 auxil-
iary ship, 2 torpedo boats, 4 muse attack
boats
26
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
prop, 45 helicopters) 25X1
Supply: produces some small arms anmimuni- ‘
tion; the Soviet Union is the principal __ ae
supplier of military equipment; ground force ,
materiel has also been purchased from sev-
eral non-Communist countries; aircraft from eo
the Soviet Union predominantly; older air- - ome
craft from UK, US, Sweden, Canada, and ‘
France; “naval materiel from thé US, Yugosla-, i
via, France, the Netherlands; and the USSR {
25X1
Military budget: for fiscal year ending 6 July25X1
1982, $381.8 million; 16.7% of central gov-
ernment budget —
|
25X1
25X1
25X1
25X1
]
25X1
25X1
{
25X11
25X1
i ’ ad
25X1
25X1
25X1
Og gE NE I NG I SN ge I ag nN I IAEA NA RIAN Nn EK AA Ae
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Falkland Islands
(Islas Malvinas)
‘
; (See reference map IV). °
NOTE:
The possession of the Falkland Islands has
been disputed by.the,UK and Argentina
'' (which refers to them as the Islas Malvinas)
since 1833. oi
Defense Forces. PAE: yuu Hee
Royal Air Force assets deployed in the Falk-
lands include 9 Phantom all-weather
interceptors, 8 Harrier GR-3 ground. attack
aircraft, 2 Hercules transport/tankers, 5 CH-
47 Chinook heavy lift helicopters, 3 Sea King
transport-helicopters,.and 8 Ropier surface-
to-air missile launchers; Royal Navy forces
_deployed in support of the Falklands garri-
son, including 1] nuclear-powered submarine,
2 guided missile destroyers, 2 frigates, a
replenishment oiler, a stores ship, and a bar-
racks ship
A British Army garrison of approximately
3,500 men and a detachment of approxi-
mately 40 Royal Marines are deployed in the
Falkland','369208b58a42f6d58e1aef5b6a604077e339fa391763137aaf95a9573f7d1845','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f0f3f0ce4aef57cd93380b14a9fed60aa9249e968a835ca7b4aee1bffd37380',1984,'FO','Faroe Islands','communications',53,'(See reference map V)
Defense Forces
Royal Danish Navy operates 1 or 2 patrol es-
cort ships in islands’ waters for fishery
inspection; the ships can ‘accommodate heli-
copters; Royal Danish Air Force-has a:control
and reporting post at Torshavn, manned by
108 personnel; the islands have no organized
native military forces; only ‘a small police
force is maintained
25x1
“97
wees
CIA-RDP08-00534R0001 00050001-7
(See reference map X)
Merchant marine: 4 ships (1,000 GRT or: ’
over) totaling 9,371 GRT, 11,548 DWT; in-
cludes 8 liquefied gas:and 1 roll-on/roll-off
cargo
Defense Forces ~ _
Personnel: Royal Fiji Military Force
(RFMF), 1,400; Territorial Force (Reserve? 5X1
600; Royal Fiji Police; 950; Royal Fiji Mari. _
25XK1
time Squadron, 114
Major ground units: 3 regular infantry com-
panies, 1 reserve infantry battalion; a
650-man-infantry battalion''is on duty. with
the UN peacekeeping force in Lebanon
Major naval units: 1 naval squadron com-
prised of 3 ex-minesweeper craft and 1
hydrographic survey vessel; personnel
trained by US and New Zealand
No formal defense agreements have been
uae
a
25X11
reached since gaining independence; how-25X1
ever, the UK has agreed to provide training
and equipment to modernize the RFMF; 25X1
New Zealand and India provide defense ad-
vice, training, and financial assistance
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','dff61d6a974e70220d89505463aaed530d59f75bc9bb423a4cdc15a4e9b0b5fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2351e5c942afc49cbbb6be3b3e3146c5f2e08f6fbf5ef0ba79b06ce3c05fbf42',1984,'FI','Finland','communications',54,'{See reference map V)
Merchant marine: 181 ships (1,000 GRT or
, over) totaling 2,249,698 GRT, 3,665,221
‘DWT; includes 16 passenger, 71 cargo, 1 con-
tainer, 17 roll-on/roll-off cargo, 32 tanker, 34
bulk, 8 specialized carrier, and 2 liquefied
gas carrier
Defense Forces
Personnel: army 31,400, navy 2,500, air
force 2,250 (210 pilots), border guard 3,650
(including coast guard, 650)
Major ground units: 8 brigades (7 infantry, 1
armored), 7 regiments (8 field artillery, ] air
defense artillery, 2 coast artillery, 1 signal), 44
battalions (6 infantry, 8 artillery, 1 target ac-
quisition, 6 air defense, 8 Jaeger, 1 coastal
Jaeger, 4 refresher Teng, 1 tank, 2 engineer, 6
coast artillery, 1 signal)
Ships: 2 patrol combatants, 5 submarine
chasers, 13 fast patrol boats, 6 missile attack
boats, 3 minelayers, 6 minesweepers, 14 mi-
nor amphibious, 8 auxiliary
Aircraft: 212 (149 jet)
ships produced domestically; production also
includes small quantities of chemical warfare
defensive materiel
Missiles: 1 SA-3 battalion
Supply: produces small quantities of ammu-
nition and equipment up to medium
artillery; has developed an armored car; pro-
duced the Vinka basic training aircraft; :
began assembly of the British HAWK air-
craft in 1981; remainder from USSR, UK,
FRG, Sweden, France, Switzerland; new
Secret
28','5aa8ce90f415615daa2790769402dc87403a09b17288e7b78c08aa56772579a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85efb0699c6b13a4174a489896ea6eaae14cb328c934e223129250bd4690ad58',1984,'GF','French Guiana','communications',55,'(See reference map IV)
Defense Forces
France maintains an army force in Frencl95y 4
Guiana; also available army and naval forces
located in Martinique and Guadeloupe’
Personnel: 1,078 (readily augmented by
1,800 personnel, aircraft, and ships/craft sta-
tioned in Martinique and Guadeloupe); 260
gendarmerie 25X11
Major ground units: 1 infantry battalion, 1
foreign legion infantry regiment, ] signal
center, 1 engineer battalion of the Military
Service (SMA; a vocational training corps for
indigenous personnel led by French Army
personnel) 25X11
Ships: 1 patrol boat (French)
Aircraft: 2 helicopters available from Gen-
darmerie’ 25x41
25X1
25X1
25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret :
French Polynesia 4 Gabon .
Supply: primarily dependent on France,
Brazil, and Morocco; 1 patrol boat from Italy. ,
25X11
~
'' 25XK1
(See reference map X) : (See reference map VII)
Defense Forces 5) Economy .
Personnel: army 2,000, navy 2,150, air force Aid: economic commitments—Western : 3 so ane :
70, gendarmerie 409 (non-US) countries ODA and OOF (1970-81), ees a37* 25X1
: $664 million; Communist countries (1970- cca
Major ground units: 1 infantry regiment, 1 82),-$27 million; US, including Ex-Im - wer Se ase
maritime/ infantry battalion, a security and (FY70-82), $32.1 million; military commit- we Bw
engineer unit ments—US (FY70-82), $9.3 million; ; a ~ 25X11
pag , Communist countries (1975-82), $7.0 million mee _
Ships: Pacific Naval Command at Papeete; Aa: : 25xX1
France currently has 3 frigates, 4 patrol com- : :
batants, 1 amphibious ship, 1 amphibious Communications é : ; 5
craft, and 1 auxiliary assigned Merchant marine: 1 tanker (1,000 GRT or ; 25X1
over) totaling 74,100 GRT, 140,700 DWT : , 25X1
Aircraft: 25 (11 jet) te a ZOA |.
Defense Forces ,
Personnel: army 1,700, navy 200, air force
500, gendarmerie 2,300, Gabonese presiden-
; teat : ; tial guard 1,400(plus 30 French nationals and
40 Moroccans); French Army 630 (organized
in 1 infantry battalion, which also performs
training function), includes 145 military ad-
: | visers . : 25X1
ae 7 Major ground units: 6 infantry companies, 1
engineer battalion (company size), 1 com-
ot he mand and support battalion (company size), 1
ss paracommando company, 81-mm mortar -
battery _
Ships: 8 patrol craft (PC), 1 missile attack boat : . ‘
Aircraft: 67 total; 42 air force (27 transport
and VIP passenger, 8 helicopters, 1 trainer, 6
utility), 26 presidential guard (10 fighters, 2
helicopters, including 1 VIP, 13 trainers) ; BP . 25X1
Secret : 30
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
(PTG), and 1 medium landing craft Ps ‘ = ~ a 25X1,
25X1
25x41
25X1
25X1
on
25X11
25X11
\\
;
f
|
The Gambia
(See reference map Vil)
25X11
Merchant marine: 1 cargo ship (1,000 GRT
or over) totaling oR GRT, 2,700 DWT |
Defense Forces
Personnel: gendarmerie 284, army 100 (be-
ing formed); Senegambia Confederation
formed effective 1 February 1982; under the
confederation the security and defense forces
in The Gambia are to be integrated with the
450 Senegalese troops in The Gambia; the
Gambian Gendarmerie (formerly the Gam-
bian Field Force) has been integrated as a
separate unit serving with the Senegalese
troops; a Gambian army is being formed and
will also be integrated with the Senegalese
Forces ;
Supply: defense agreement with Senegal; in-
direct defense support from UK; has received
small arms from the USSR and the PRC;
small patrol craft from the UK]
-25K1
German Democratic Republic
(See reference map V)
25X1
Merchant marine: 437 ships (1,000 GRT or
over) totaling 6,703,394 GRT, 10,749,936
DWT; includes 13 passenger, 185 cargo, 80 |
container, 22 roll-on/roll-off cargo, 49
tanker, 9 liquefied gas, 34 bulk, 1 combina-
tion ore/oil, 43 specialized carrier, and 1
cargo training
Defense Forces
Personnel: army 336,782, navy 37,000 (in-
cluding 7,000 in naval air), air force 109,000
(1,600 pilots), federal border police 22,400
Supply: supplies most of its own needs for
ground forces materiel but has large procure-
ment program in NATO countries; produces -
tanks, armored vehicles, artillery, infantry
weapons; produces biological /chemical war-
fare protective materiel as well as military
electronic and optical equipment; has pur-
chased antitank, air-to-surface,
surface-to-air and antiship, and ship-to-ship
missiles from US and France and helicopters
and naval surface-to-air missiles from the
UK; domestic output of aircraft is expected to
be maintained with the continuing BO-105
helicopter production and joint aircraft and
helicopter development and production pro-
grams with the UK, France, Italy, and Japan;
previously produced antitank and .
air-to-surface antiship missiles; collaborating
with the US, UK, France, Canada, and other
West European nations on a wide variety of
missile and drone systems; produces destroy-
ers, frigates, submarines, guided missile
patrol combatants, missile attack boats, .
minecraft, and auxiliaries; naval weapon sys-
tems obtained from NATO countries;
frigates, submarines, patrol boats, and missile
boats are produced for export
Major ground units: 12 combat divisions (4
armored infantry, 6 armored, 1 mountain, 1
airborne), 6 home defense brigades, 6 avia-
tion regiments, 4 Lance missile battalions;
reorganization to occur through 1985 will re-
sult in 6 armored divisions, 5 armored
infantry divisions, ] airborne division, and .
will add 8 Roland regiments (see Missiles be-
low), 3 helicopter regiments (antitank), and 6
additional home defense brigades to existing
force structure Ro
Ships: 3 guided missile destroyers, 4 destroy-
ers, 24 submarines, 6 frigates, 5 subchasers, 14
guided missile patrol combatants, 20 missile
attack boats, 4 torpedo boats, 59 mine warfare,
28 minor amphibious, 47 auxiliaries
Aircraft: 2,235 (1,042 jet), including 703 in
army aviation, 230 (131 jet) in navy aviation,
1,329 (975 jet) in air force
Missiles: 24 NIKE Hercules, 36 I-HAWK, 3
Roland II regiments (79 launchers), 8 Per-
shing squadrons; 1 Honest John, 26 Lance
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','9248019c902d8c952e72a239025d0419d663bf0bf543766193ad31f1ff06bca3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b7f2ea4650831a0263cdac7a1cfaaae1b76894c112da37d322179626b5edfa',1984,'GH','Ghana','communications',57,'Vil)
ee reference map
Merchant marine: 25 cargo ships (1,000 GRT
oa 172,182 GRT, 231,291 DWT
32
Defense Forces .
Personnel: army 4,700, navy 500, air force
400, border guard 2,500, national police
force 17,000, Military Strike Force 100, Pal-
ace Guard 50, people’s militia unknown
Major ground units: 3 brigades—] service
brigade, 2 infantry brigades (6 infantry bat-
talions, 1 airborne battalion); although the
term regiment is used for each of the follow-
ing, unit strength is equivalent to a
battalion—1 mortar regiment, } field engi-
neer regiment, 1 reconnaissance regiment
(understrength), and } signal regiment
Ships: 12(2 patrol escorts, 2 fast patrol craft, 4
patrol craft, and 4 patrol boats)
Aircraft: 46 (11 short-range transport, 10 jet
trainers, 12 prop trainers, 8 utility aircraft, 5
support helicopters)
q
a
|
:
|
|
:
|
|
|
|
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
Supply: dependent on imports; primarily
from the UK; other West European coun-
tries, Canada, USSR, Libya, Israel, Bulgaria,
and Czechoslovakia have also supplied some
materiel
Military budget: for fiscal year ending 30
- June 1981, $15.5 million; (5% of central gov-
ernment budget
25X1
>
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20','edfefa253b0c402a2bef1d9d6d94d21b3480b2e1c1aca3858a0ecc8620cb09a8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1ad29d9b5184ae4539730084736945e8e7b6870d0041e46ad7f73acaa048aee',1984,'GI','Gibraltar','communications',59,'(See reference map V)
Defense Forces
Personnel: UK Army 842, eolonialess: Revel
Navy 664, Royal Air Force 420
M ajor ground units: 1 UK infantry battalion
Ships: 1 destroyer-type ship deployed in the
area rotates as the Gibraltar guardship, addi-
tional ships are often temporarily deployed
to the area for exercise and training or for
refit or maintenance of a varied number of
ships and craft ;
Aircraft: small detachment of fighter /
trainer aircraft (2)
33
‘| special forces division (3 raiding forces régi- ''
: CIA-RDP08-00534R000100050001-7
secret','8d887065e6439ceb3b059b95527bad88aa44fddf7a741ccdb71ea8fe9843b9b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f49d4591da43681310b6f1aea31281daf5e20ac36263c72bd1e81c1ad50fbe69',1984,'GR','Greece','communications',60,'.25K1
(See reference map V)
Merchant marine: 2,857 ships (1,000 GRT or"
over) totaling 42,305,162 GRT, 73,327,17895 x 4
DWT; includes 84 passenger, 1,323 cargo, lo.
container, 385 tanker, 9 liquefied gas, 31
roll-on/roll-off cargo; 880 bulk, 62 combing x 4
tion ore/oil, 68 specialized carrier; ethnic “;
Greeks also own largé numbers of ships under
Liberian, Panamanian, Cypriot, and Leba-. ,
nese flags | 25X14
25X1
Defense Forces.
Personnel: army 14]:,000, navy 18,000, air
force 23,600 (755 pilots), police 24,000 e.
Major ground units: | army headauarters95 x
corps headquarters, 1] infantry divisions (5 at
full strength), 1 mechanized division, 1 ar-25
mored division, 3 separate armored brigades,
ments, | parachute regiment, 1 marine ioe
regiment), 1 high military command, 6 island |
military commands (brigade equivalents), 1 4
infantry regiment (Cyprus); 2 army aviation
battalions, 4 corps-level aviation units, and 1,
army aviation school
Ships: 14 destroyers, 3 frigates, 4 corvettes, 10
submarines, 16 guided missile patrol boats,
20 fast action craft, 13 amphibious warfare
ships, 14 auxiliaries
Aircraft: 850 (432 jets), including 618 (482.
jets) in air force, 224 in army aviation, 13 in
naval aviation 25X1
Secret
: CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
VCuUT
Greece (continued)
Missiles: 5 NIKE Hercules squadrons (72
launchers), 8 I- HAWK battalions (45 launch-
ers), 1 Redeye (1,000 launchers)
supply: devendaiit laseely on foreign
sources, mainly US and other NATO coun-
tries; armored vehicles, missile attack boats
and trucks from Austria, France, and Italy,
submarines and artillery from FRG, and re-
coilless rifles from Spain; produces small -
arms and ammunition in small quantities; has
assembled armored vehicles and has pro-
duced six guided missile patrol combatants of
French design; purchased two new guided
missile frigates from the Netherlands and has
an option to build one or more units under
license in country
Military budget: proposed for fiscal year °-
ending 31 December 1980, $2.2 billion; +
about 18% of central. government budget
Greenland aD. ihe st
(See reference map Il)
Defense Forces ee
Defense is responsibility of Denmark, but un-
der térms of a US-Danish agreement of 1951,
defense is actually shared by US and Danish
forces; Danish forces in Greenland consist of
mostly naval personnel; one or two patrol es-
cort ships are in Greenland waters for fishery
inspection; both ships can accommodate heli-
copters; there is one Royal Danish Air Force
Gulfstream III always on rotational duty in
Greenland; Greenland has no organized na-
tive military forces; only-small local police
forces are maintained
Secret -
25X11
34
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Grenada ; wR
’ (See reference map III)
Merchant ‘marine: 6 cargo oe (1, 000 GRT
or over) totaling 27,972 GRT,-89;126 DWT.
. . YES week eo +
a oS Sagres . reas ae Get PB
eee ra eee
Personnel: 450 army infantry
Major ground units: 1. company of overseas
infantry regiment
Ships: 1 patrol boat
Aircraft: 1 helicopter
Lg a NTE EE IP TA ANI AO NN NI AR NI NO
*y
ar ate
25X11
25X1
a ogte” 1ydoyte. # “4
Défense Forces or
Personnel: army 28,570, navy 920, air force
750 (140 pilots
Major ground units: 19 infantry battalions, ‘1
military police battalion, 1 Presidential
Guard Battalion; I engineer constrtiction bat-
talion, 1 mobile military police battalion; 1
cadet battalion, and''6 strategic reaction bat-
talions (4 infantry, 2 airborne infantry); 2
marine infantry battalions; in -addition,.a +.
400-man tactical group stationed at La Au-
rora Airbase for airport |
Ships: 1 fast patrol craft, 9 patrol boats, 2°
river patrol boats, 1 medium landing craft
(LCM), 2 other auxiliaries
Aircraft: 96 (14 jet, 24 turboprop, 30 prop, 28
helicopters)
Supply: substantial quantities of army mate-
riel obtained from US through 1977; recently
from Israel, the Republic of Korea, and Eu-
rope
ht Nt, Beads ae |
: CIA-RDP08-00534R000100050001-7
wuwres
Guinea 2 Sah
(See reference map Vil)‘
t ge ee Joos','60fa50c2e78d2f6ee6a402a42c690616f6941d3d15e4481a939f1e22d1c1f6b1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee0c7f97328ac84b7e7527fe79e9016f74285e3a61eb7865913a331d103e8359',1984,'GY','Guyana','communications',64,'Merchant marine: 1 bulk (1,000 GRT or °”
over) totaling 3,000 ORE, 3,100 DWT
ieteade Forces
Personnel: Guyana Defense Force (GDF).
6,400; Guyana Police Force 4,500
Major ground units: | brigade (3 infantry
battalions, 1 support battalion), 1 special
forces battalion, 1 training unit
Ships: 8 patrol craft, 5 miscellaneous auxil-
iary vessels
25X1
25X11
25X41
Aircraft: 2 turboprop, 6 prop, 9 helicopters
ports, 2 prop light trainers, 4 helicopters)
Supply: dependent on outside sources, pri-
marily the USSR; some items received from','d0f6ef0e9d07e1353de9e95798c004e1c1607a5349f0fdf0ebb1b1e3d84fe04b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5bb858862f0e4dbfb13e544faaa6f8c3cbb20a70f6d2f41ab964a37f43d0c0d',1984,'HT','Haiti','communications',65,'(See reference map Ill)
Defense Forces
Personnel: army 6,400, navy 260 (including
4] officers), air corps 220 (28 pilots)
Major ground units: Leopard Corps, Presi-
dential Guard, Casernes Dessalines, and
Port-au-Prince Police Armed Forces of Haiti
organized into 51 companies, including 10 in-
fantry, 1 heavy weapons, 24 district police,
and miscellaneous other elements; only 2
units have marginal combat capabilities (the
Leopard Corps and the Casernes Dessalines)
Ships: 13 patrol boats—3 65-foot patrol, 9
40-foot patrol, 1 harbor patrol; 1 ocean tug
(ATA
Aircraft: 40 (9 helicopters, 23 prop, 8 turbo-
prop)
Supply: current supplies from US commer-
cial sources and from Israel; sources in the
past have included Belgium, Czechoslovakia,
Italy, Jordan, Nicaragua, Yugoslavia, and
primarily the US
Military budget: for fiscal year ending 30
September 1981, $15.3 million; about 4.1% of
central government budget sd','4e3c24c0c1d1b34fdad47452635dc6c1e85a3353a787cab19901bc8218abf797','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093c48393ef6fb669b4bf7cb370023e1b8783bcb6af6223565cb740075953ef6',1984,'HN','Honduras','communications',66,'(See reference map Iii)
Merchant marine: 48 ships (1,000 GRT or
over) totaling 156,828 GRT, 256,902 DWT;
includes 31 cargo, 12 tanker, 2 bulk, and 3
container carriers; a flag of convenience reg-
istry| |
Defense Forces
Personnel: army 14,500, navy 800, air force
1,200
Major ground units: 12 infantry battalions, 4
artillery battalions, 1 engineer battalion, 1 ar-
mored cavalry regiment, 1 special forces
battalion
Ships: 8 patrol craft, 6 patrol boats, 7
river /roadstead patrol boats, 1 buoy tender
Aircraft: 114 (81 jet, 1 turboprop, 48 prop, 34
helicopters)
Supply: equipment procured from US, Israel,
and Western Europe
Military budget: for the fiscal year ending 31
December 1982, $45.5 million; about 6% of
the central government budget
37','4991073683fe3db8356e26f3cbb593306e12874fe6bc8907ab0cc22cef3a604f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1505db1397256e57ff90564a7da41f43fcd08b4570e78e07391200212e8d2078',1984,'HK','Hong Kong','communications',67,'e
(See reference map Vill)
Merchant marine: 15 ships (1,000 GRT or
over), totaling 295,702 GRT, 455,260 DW25X1
includes 1 passenger, 1 cargo, 1 tanker, 7
bulk, 4 container, and 1 specialized carrier;
ships registered in Hong Kong fly the UK 95x
flag; an estimated 500 Hong Kong-owned
ships are registered elsewhere
Defense Forces 25X1 25X14
Personnel: ground forces—UK army 1,943,
colonials 4,986, locals 1,230 (ground), police
11,580; auxiliary police 3,100, UK navy 395X1
350 locals (navy); air force 220; auxiliary air
force 90 25X1 25X11
Major ground units: 1 Gurkha field force
Ships: Hong Kong Marine Police, 38 policD5 x 4
boats; UK naval ships homeported in the W5x1
operate occasionally in the Indian Ocean,
Gulf, and Far East; 5 patrol combatants a20X1
signed to Commander, Hong Kong
~— 25X1
Aircraft: 13 helicopters (7 RAF, 6 Army ‘95x 4
Corps) 25X11
25X1
25X1
25X11
25X1
Secret 25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7','7bfc654749dc88dad8fe53d8cdf616e75e8613d0fc07628f52342343411c5a66','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('568ebd11ec89cf3eab7a06e03766bcfd8e6a661956b6094f67333f086af8352b',1984,'HU','Hungary','communications',68,'(See releronce rab Vv)
Eccnomy
Aid: extended to non- -Commiiinist less devel-
oped countries (1962-82), $1.3 billion in
bilateral aid
Civil air: 29 major transport aircraft (1979)
Merchant marine: 22 cargo ships (1,000 GRT
or over) totaling 83,803 GRT, 113,945 DWT
|
Airfields: 98 total; 2] with permanent-
‘Surface runways; 2 with runways 3,500 m or
‘over, 14 with runways 2,500-3,499 m, 25 with
runways 1,000-2,499 m, 57 with runways less
_than 1,000 m, 19 heliports
Telecommunications: services meet most
h ‘government and industrial requirements, but
t local public telephone service is inadequate;
, “radio and TV. broadcasts can be received
‘ throughout most of the country; 11 AMand 4
‘F M stations; more than 3,000,000 receivers; 1
‘ major and 11 relay TV stations; 2,600,000 TV
i receivers; 950,000 telephones (80.3% auto-
matic)
Defense Forces
Personnel: est. ground forces 75,000 (includ-
ing a river flotilla), air and air defense force
21,750, paramilitary forces 16,000; Soviet
forces (SGF)in Hungary as of 1 January 1983,
74,000 (64,000 ground, 10,000 air); personnel
in reserve (not on active duty)—{est.) ground
forces 985,000, naval forces 3,400, air force
unknown
Secret
Major ground units: 6 divisions (5 motorized
rifle, 1 tank), 3 brigades (1 SCUD [SS-1] tacti-
cal missile, 1 artillery, 1 SA-4), 5 regiments (3
SA-6, 1 antiaircraft, 1 antitank), 1 airborne
reconnaissance battalion
Ships: (est.) 45 river patrol types, 60 mine-
sweepers, 2 landing craft, 2 auxiliaries
Aircraft: (operational units) 257, including
153 air defense fighters, 16 transports, and-
108 helicopters
Missiles: 12 operational SA-2 SAM sites (72
launchers); 6 operational SA-3 sites (24 4-rail
launchers); 3SA-6 SAM regiments and 1 SA-4
brigade are deployed with the ground forces
(includes 1 atmy-level regiment and 2 divi-
sional regiments); SA-9 and SA-7 systems are
deployed with the Hungarian ground forces;
sites are under construction for the SA-5:sys-
tem
Supply: produces small arms, ammunition,
explosives, light artillery, some trucks, chem-
ical warfare defensive materiel and small
quantities of agents, some types of electronic
équipmeént; dependent upon other Warsaw
Pact countries, primarily the USSR, for other
military equipment including radar and mis-
siles; imports minesweepers from Yugoslavia','d5644655148697106a6fd2a73d94b5751927dff36222459c56799e039d2581ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b92897263ba04b14435ad2e9fe50ef04f6227760b00717c82a96e1b1b7845f49',1984,'IS','Iceland','communications',69,'(See reference map V)
Merchant marine: 37 ships (1,000 GRT or
over) totaling 72,098 GRT, 117,555 DWT; in-
cludes 29 cargo, 2 bulk, 1 tanker, 4 .
roll-on/roll-off ships, and 1 specialized car-
rier :
Defense Forces
Iceland has no armed forces; police forces est.
390, Coast Guard Service consists of 4 patrol
vessels, 2 helicopters, 1 light transport air-
eraft, and anest. 160 personnel; under NATO
provisions, the US operates the Iceland De-
fense Forces
25X1
25X1
25X11
25X11
ie
25X11
Personnel: US, 2,600 navy and air''
Aircraft (operational): 28, including 21 com-
bat aircraft, 3 airborne early warning
aircraft, 1 transport, 3 helicopters
25X11
38
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
5x1
25X1
25X11
25X11
25X1
25X1
ge','f833c47799298d862c5f384b30f024617a68a49b354d582c6847613efb67f249','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9e76baa1c3fa24a9cde106d8bd289da961ff42fe52b2cb72f734ecd997544b9',1984,'IN','India','communications',70,'(See reference map VIII)
Merchant marine: 374 ships (1,000 GRT or
over) totaling 5,846,541 GRT, 9,611,233 -
DWT; includes 2 passenger, 218 cargo, 34
tanker, 91 bulk, 16 combination ore/oil, 2
specialized carrier, 1 barge carrier, and 10
container
Defense Forces
Personnel: army 1,092,000, navy 46,000 (in-
cluding 2,000 in naval air arm); air force
114,600 (about 3,270 pilots); armed police
242,000; Central Reserve Police 78,800; Bor-
der Security Force, at least 84,800
Major ground units: 9 corps, 32 divisions (19
infantry, 10 mountain, 2 armored, 1 mecha-
nized), 32 independent brigades (6 armored,
3 infantry, 1 mountain, 1 parachute, 12 artil-
lery, 6 air defense, and 4 engineer); also 25
paramilitary battalions integrated on rota-
tional bass|—
Ships: | light carrier, | light cruiser (nonop-
erational), 6 frigates, 3 guided missile patrol
combatants, 3 guided missile destroyers, 3
guided missile frigates, 13 guided missile
Supply: increasingly self-sufficient, includ-
ing manufacture/assembly of own small
arms, artillery, ammunition, variety of air-
craft, military electronics, and medium
tanks; guided missile frigates, patrol craft and
landing craft being built domestically; US
and UK were principal foreign suppliers until
1965; since then the USSR has become the
principal foreign source; since 1965 the USSR
has supplied ground, naval, and air equip-
ment to India; included are 191 T-72 tanks,
more than 600 T-55 tanks, 178 PT-76 tanks,
tank transporters, approximately 581 130-
mm guns, 180 100-mm guns, 8 submarines,
10 light frigates, 6 medium landing ships, 16
guided missile patrol boats, 1 submarine sup-
port ship, 3 guided missile destroyers, 3
guided missile patrol combatants, 9 fleet
minesweepers, more than 300 MiG-21 fight-
ers(including in-country assembly), 131 SU-7
fighters, transport aircraft, and helicopters;
medium tanks obtained from Czechoslo-
vakia and Poland; 4 medium landing ships
from Poland; armored personnel carriers and
tank transports from Czechoslovakia and the
USSR; small amounts of other army materiel
_ from Bulgaria and Yugoslavia; small arms,
towed artillery, armor, armor components,
military electronics, and self-propelled artil-
lery and aircraft from UK; licensed radar
production with France and toa lesser extent,
Switzerland; produces MiG-21s under license
from USSR—maijority of components do-
mestically produced; licensed production
French helicopters; licensed production of
British Jaguar aircraft; licensed missile
assembly /production programs include the
French SS-11 ATM and the Soviet Atoll AAM
39
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
25X1
25x11
25X1-
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
25X1
25X1
25X1
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','33441e91401204055e746a1df582df52119706557ee7497d9eda156f54f6655b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('912baab30439a3ebaf61d208c14461828c851ed7abba0b68a903557bacaf6c8d',1984,'ID','Indonesia','communications',72,'(See reference map IX)
Pipelines: crude oil, 2,591 km; refined prod-
ucts, 310 km; natural gas, 518 km
Merchant marine: 308 ships (1,000 GRT or
over) totaling 1,377,909 GRT, 2,072,413
DWT, includes 1 passenger, 224 cargo, 2. con-
tainer, 2 roll-on/roll-off cargo, 47 tanker, 27
bulk, 8 specialized carrier; in addition, 1 na-
val tanker and 5 troop transports sometimes
used commercially; only a small part of the
fleet is in international trade; in the domestic
fleet as many as half of the ships are inopera-
ble because of chronic lack of spare parts and
trained personnel, although a newly begun
fleet modernization program should gradu-
ally change this
Defense Forces
Personnel: army 206,000; navy 37,421 (in-
cluding 12,700 marines and 800 naval air); air
force 25,000 (2,000 officers, 11,000 NCOs,
12,000 airmen), police 11,800 (mobile bri-
gade)
Secret
Major ground units: 16 brigades (13 infan-
try, 2 airborne, 1 cavalry), 3 regiments (1 field
artillery, 1 antiaircraft artillery, 1 combat en-
gineer), Police Mobile Brigade (10 infantry
25X1
battalions), 2 marine infantry regiments
Ships: 11 frigates, 4 submarines, 34 coastal
patrol-river/roadstead patrol, 2 mine war-
fare, 5 amphibious, 15 support auxiliary
ships/craft, and 8 service craft
Aircraft: approximately 390 (82 jet), includ-
ing 40 naval air and 283 (91 jet) in air force; 62
army aviation
Missiles: Soviet-made ground air-defense
missile site deactivated and missiles in stor-
age; manportable air defense missiles being
procured from Sweden
Supply: small quantities of ammunition and
small arms produced; assembles Spanish
CASA C-212 utility aircraft, FRG BO-105,
and French Puma helicopters, also working
on coproduction of the CN-235 medium
transport with Spain (production slated for
1984); during 1957-65 Indonesia purchased
most military equipment from Communist
countries, the majority during 1960-65 from
the USSR; naval ships and équipment from a
large variety of Communist and non-
Communist sources; naval surface-to-
surface, air-to-air, air-to-surface, and
surface-to-air missiles from USSR and
France; antitank missiles from Switzerland
and France; recent purchases generally for
cash; both purchases and grant-aid from non-
Communist sources; naval purchases include
4 missile boats and 6 landing ships from South
Korea, 3 corvettes from the Netherlands, and
2 submarines from FRG; F-5 fighters have
been purchased from the US, A-4s have been
purchased from Israel, and air defense radar
from France; recent major armored vehicle
purchases (mostly used equipment) from the
Netherlands, Singapore, and France; equip-
ment purchases curtailed in 1983 because of
economic downturn
40
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
25X1
25X11
25X1
25X1
25X1
: CIA-RDP08-00534R000100050001-7
Iran
reference map Vi)
Merchant marine: 58 ships (1,000 GRT or
over) totaling 1,077,569 GRT, 1,852,391
DWT; includes 38 cargo, 12 tanker, 5 bulk,
and 3 beach landing cargo ships (converted
US LCT)
Telecommunications: advanced system but
not properly maintained; only partially oper-
ative; Tehran principal center and hub of
critical radio relay, troposcatter links;
1,220,000 telephones (3.2 per 100 popl.);
about 38 AM, 28 FM, and 250 TV stations,
Atlantic and Indian Ocean INTELSAT sta-
tions
Defense Forces
Personnel: joint staff 3,750; ground force
235,000; navy 15,000; air force 50,000 (500
pilots); gendarmerie 45,000; revolutionary
guards 200,000-250,000
Major ground units: 9 divisions (5 infantry, 4
armored), 6 independent brigades (3 infan-
try, 1 airborne infantry, 1 special forces, 1
armored); 1 aviation command; 5 artillery
groups; over 35 Revolutionary Guard bri-
gades
Ships: 8 guided-missile destroyers, 4 -
guided-missile frigates, 11 missile attack
boats, 2 patrol combatants, 44 patrol -
boats/craft, 13 amphibious vessels, 4 mine-
sweepers, 14 hovercraft, 9 other. vessels _ ;
(auxiliary) -
Aircraft: approximately 1;100, including an
estimated 250 jet fighters, 70 transport (prop),
VJUUICL
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 - CIA-RDP08-00534R000100050001-7
25X1
25x11
25X1
22 transport (jet), and 600 helicopters
Missiles: 21 active SAM sites
Supply: can produce small arms, 20-mm can-
nons, rockets, rocket launchers, explosives,
and various calibers of ammunition; bulk of
equipment from US before 1979, some anti-
tank missiles from France, some surface-
to-air missiles and naval craft from UK, Italy,
and India, helicopters from Italy; since 1967
has received significant quantities of ar-
mored vehicles, artillery—including ~
self-propelled antiaircraft (AA) guns, and
transport vehicles from the USSR; has pro-
cured AA guns and associated radar from —
Switzerland, tanks from UK, and significant
quantities of other military materiel from
FRG, France, Italy, Canada, and Israel; 12
missile attack boats acquired from France
during late 1970s and early 1980s; since the
end of 1980, Iran has received tanks from
Libya and North Korea and significant quan-
tities of ground forces niateriel have been
exported from Syria, Libya, North Korea,
China, South Korea, and the West; broker
and black market sales account for most of
free world sales; black market sales are esti-
mated to exceed $1 billion!
Military budget: for fiscal year ending 20
March 1983, $8.6 billion; 22% of the central
government budget
4)
“25Xx1
.. Secret.
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','b514dc55f8ded15275a8996f5432815b3f5f1c33ad9bc5fecd388ff963641936','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee0f1938aa9c2f121bb22454f03220182b856afaf538e430f8b45758f0cc820',1984,'IE','Ireland','communications',75,'Merchant marine: 36 ships (1,000 CRT o or:
over) totaling 215,182 GRT, 313,181: DWT:
includes 4 passenger, 2 container, 1 tanker,:2:
roll-on/roll-off cargo, 6 bulk,: 15 cargo, 4''spe-
cialized carrier, and 1 combination ore/oil
‘4,500; air force 85,000 (2 ,000-1,100 pilots)
Major ground units: 4 mountain infantry di-
visions, 11 infantry ‘divisions, 2 mechanized
infantry divisions, 5 ‘armored divisions, ] bor-
der guard division, 2’ republican guards
mechanized brigades, 11 independent ar-
mored brigades, 1 independent mechanized
infantry brigade, 10 reserve infantry bri-
gades, 49 infantry brigades mobilized for-
Iraq- Iran war, 8 special forces brigades
Ships: ] training frigate, 8 missile attack
boats, 8 small torpedo boats, 3 submarine
chasers, 3 river gunboats, 5 patrol boats, 6 fast
patrol craft (air cushion),-8 service craft, 8
minesweepers, 3:medium landing ships
Aircraft: 1;310 (750 jet, 75 turboprop, 40
prop, 445 helicopters)
Secret .
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
42
Defense Fores
Personnel: army 12,850 (navy and air Foes
are subordinate to the army), navy 910, air
corps 680 (60 pilots)
Ships: 6 patrol ships, 2 auxiliary, 1 service
Aircraft: 37 (7 iet)
Missiles: RBS-70 (10 launchers)
Supply: formerly primarily from the UK, but
since 1961 from other European countries,
especially France; 4 naval service fishing pro:
tection ships produced domestically; another
2 larger units are planned; has RBS-70
surface-to-air missiles from Sweden; recently
acquired additional 6 105-mm guns and 4.ad-
ditional Scorpion light tanks from the UK
CIA-RDP08-00534R000100050001-7
'' Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
I BS a ee IT II IF LITLE ALE AAI,
a ee ee
No
oO
x<
—
N
oO
x<
_
@)','9c4c0279bd0cd6f5146923679437907571ed579ef7aa53a498ff7e40f0597e21','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a77ddc7a7b5b8f5f98a4ac1b9fde20e6a6b0188ff386c1793d0af1f92188c8e0',1984,'IL','Israel','communications',76,'(See reference map VI)
NOTE: the Arab territories occupied by Is-
rael since the 1967 war are not included in the
data below. As stated in the’ 1978 Camp Da-
vid Accords and reaffirmed by.the:.
President’s. 1. September 1982 peace initia-. -
tive, the final status of the West Bank and
Gaza Strip and a peace treaty between Israel
and Jordan are to be negotiated among the
concerned parties; Camp David further spec-
ifies that these negotiations will resolve the’ ''
location.of the respective boundaries; pend-
ing the completion of this process, it is US
policy. that the final status of the West Bank
and Gaza Strip has yet to be determined (see
West Bank and Gaza Strip “factsheet” in The
World Factbook), on 25 April 1982 Israel re-
linquished control of the Sinai to Egypt;
statistics for the Israeli-occupied Golan
Heights are included in the Syria “factsheet.”
Economy eo ep ite
Aid: economic commitments—US, including
Ex-Im(FY70-82), $7.1 billion; other Western
countries ODA and OOF (1970-80), $953
million; military commitments—US (FY70-
82) $15.5 billionf
Communications . «| oe
Merchant marine: 46 ships (1,000 GRT or
over) totaling 606,188 GRT, 792,893 DWT;
includes 13 cargo, 16 container, 4
roll-on/roll-off cargo, 12 bulk, and 1 special-
ized carrier
Defense, Forces
Personnel: army 135,000 (plus 300,000 re-
serve), navy 6,600, air force 30,000 (1,500 .
pilots), NAHAL 5,000, frontier guard 4,500,
CHEN (women) 42,000
Major ground units: 11.armored divisions, 1
airmobile division HQ (provisional), 4 territo-
rial infantry division HQs (provisional), 10
mechanized infantry, 5 airborne, and 5 in-
fantry brigades
Ships: 3 submarines, 12 guided missile patrol
combatants, 12 missile attack boats, 2 hydro-
foils, 40 patrol boats, 13 river/roadstead
patrol boats, 5 amphibious, 5 service, and 3
auxiliary
Aircraft: 1,488-(956 jet, 263 prop, 28 turbo-
prop, 241 helicopters)
Missiles: 17 HAWK missile batteries (16
towed and 1 self-propelled) and 48 Chaparral
launchers
Supply: produces most types of ammunition,
vehicles up to 50/60-ton tank transporters,
small arms, mortars up to 160-mm, 155-mm
self-propelled and towed artillery, indige-
nously designed medium tanks, and chemical
and biological warfare defensive materiel,
aircraft from native designs, and small turbo-
jet engines, engine parts and components;
produces a variety of defense electronics
equipment; also produces GABRIEL, an in-
digenously designed and produced naval
surface-to-surface missile, as well as the
SHAFRIR air-to-air missile; almost all naval!
combatants are being domestically pro-
duced, excluding submarines
43
CIA-RDP08-00534R0001 00050001-7
‘(See reference map V)
Communications 25K"
Merchant marine: 636 ships (1,000 GRT or
over) totaling 9,783,833 GRT, 16,389,020. -: -;
DWT;,includes 55 passenger, 154 cargo; 1,6.°
container, 52 roll-on/roll-off cargo, 155 ..: +."
tanker, 28 liquefied gas, 107 bulk,.26 com- --
bination ore/oil, 43 specialized ‘carrier
Defense Forces . os 25X1
Personnel: army 290,500, navy 43,400(in-; *
cluding 220 pilots and 960 naval infantry), air.
force 68,000 (1,400 pilots); carabinieri 82,000
25X1
Major ground units: 4 divisions (8 mecha- .
nized, 1 armored), and the following separate
maneuver units: 12 brigades (5 alpine, l:air-
borne, 2 mechanized, and 4 motorized), 1
brigade equivalent (Trieste Troop com-.
mand), 4 battalions (1 mechanized, 2 ..
armored, 1 armored cavalry); separate 20X11
bat support units include | missile artillery.’:
brigade, 1 air defense command (3 regi- 5X1
ments), 5 field artillery. regiments, 1 separac
artillery battalion, 4 light aviation grouD75 y 4
engineer regiments, .9 engineer battalions, +
amphibious regiment, and 10 signal battal-_
ions 25X1
av/N |
Ships: 1 guided missile aviation cruiser, 2.
guided missile cruisers, 4 guided missile de-
stroyers, 13 frigates, 8 corvettes, 10
submarines, 6 missile attack hydrofoils, 1
missile attack boat, 3 fast attack craft, 2 am-.
phibious warfare, 31 mine warfare, 24 X1
25X11
auxiliaries
Secret
; Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08- 00534R000100050001-7
Italy (continued)
Aircraft: 1,597 (662 jet), including 982 (622
jet) in air force, 110 (nonjet) in naval air, 505
in army aviation
Missiles: 2 -HAWK regiments, 8 NIKE
squadrons
Supply: produces infantry weapons, armored
vehicles, electronics and optical equipment,
artillery, ammunition up to 203- -mm;
collaborating with France and FRG, to de-
velop a family of antitank missiles and
antiship missiles; indigenously developing
surface-to-air and antiship missiles; a VSTOL
aircraft carrier, guided missile destroyers,
frigates, submarines, and patrol craft (midget
submarines, guided missile frigates, patrol
craft, and missile attack boats produced for
export); jet fighter, trainer transport and util-
ity aircraft, as well as helicopters; small
amounts of biological /chemical warfare de-
fensive materiel; some materiel, chiefly
Ivory Coast
(See reference map Vil)
Merchant marine: 10 cargo eer 000 GRT
or over) totaling 122,060 GRT, 161,888 DWT
heavy equipment, imported from US
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Defense Forces
Personnel: 4,350 army, 444 navy, 600 air
force (plus 17 French), 4,312 gendarmerie,
1,067 Presidential Guard (plus 104 French
advisers and 400 French troops)
Major ground units: 3 infantry battalions, 1
armored car company, | artillery battery, 1
light antiaircraft artillery battery, 1 engineer
battalion
Ships: 9 (4 gunboats, 1 landing craft, and 4
patrolerafif
Aircraft: 30 (4 jet, 16 transports, 10 turbine
helicopters)
Supply: principally dependent on France;
has purchased transport aircraft from Neth-
erlands
Military budget: for fiscal year ending 31
December 1982, $84.7 million; about 6.7% of','ebf529719fa68e389835c824b18e25cc1f2a3c3359f3dc50400a42b9f6937910','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4a49765d42822d423830405e34a6344b0ccc1859417e6e9c3da15f9203bc95',1984,'JM','Jamaica','communications',77,'(See relatenes map mM)
Merchant marine: 1 cargo and 1 roll-on /roll-
off ship (1,000 GRT or over) totaling 4,977
GRT, 8,010 DWT
Defense Forces
Personnel: 3,400
Major ground units: | regiment consisting of
2 active duty battalions, 1 reserve battalion,
and 1 support and services battalion
the central government budget
44
CIA-RDP08-00534R000100050001-7
1
ow oa
wae OP Ne yr
ow
oe wr OT
WW ere Or ow eT
wee wwe
“+','164ed4d535fcdbf17a069f9f75b5cc654a13254a05a4e64a3bc69257c09d0e8d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e49a8c64a4f11198656f45d6a9e34e1ff4824d412ddd1065ea4f9266fac87b7d',1984,'JO','Jordan','communications',79,'(See reference map VI)
NOTE: The war between Israel and the Arab
states in June 1967 ended with Israel in con-
trol of the West Bank. As stated in the 1978
Camp David Accords and reaffirmed by the ,
President’s 1 September 1982 peace initia-
tive, the final status of the West Bank and
Gaza Strip and a peace treaty between Israel
and Jordan are to be negotiated among the
concerned parties; Camp David further spec-
ifies that these negotiations will resolve the
location of the respective boundaries; pend-
ing the completion of this process, it is US
policy that the final status of the West Bank
and Gaza Strip has yet to be-determined (see
West Bank and Gaza Strip “factsheet” in The
World Factbook).
Defense Forces
Personnel: army 57,700, coast guard 190, air
force 7,500 (155 pilots), Public Security Force
(National Police) 5,700
Major ground units: organized around divi-
sional structure; 2 mechanized divisions
(each composed of 2 mechanized brigades, 1
infantry brigade, divisional artillery battal-
ions, combat support and combat service
support units), 2 armor divisions (each com-
posed of 3 armor brigades, divisional artillery
battalions, combat support and combat serv-
ice support units), 1 Royal Guards brigade
with supporting units, and a Special Forces
brigade
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
wewnve
25X11
Aircraft: 202 (173 jet, 19 prop, 9 turboprop,
31 helicopters) - . 25X14
Supply: dependent on outside sources; US
and UK principal suppliers of military equip-.
ment; has purchased fighter aircraft from.
France and is expected to purchase French
helicopters and surface-to-air missile system; |
has purchased a limited number of ground-
based air defense systems from the USSR and
has recently-received first shipments of USSR
and Chinese equipment
Military budget: for fiscal year ending 31
December 1983, $804 million; 37% of central
government budget 25X1
Ships: 6 operational small patrol craft
45
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25x11
. LZOAl
25X11
ZOXK1
25X1
25x11
25X1
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Kampuchea
(formerly Cambodia)
" (See reference map IX):
Merchant marine: 1 cargo ship totaling 1,400
GRT, 2,600 DWT; the present status of this
vessel is unknown
Defense Forces
Personnel: Democratic Kampuchea, about
80,000-35,000; Khmer People’s National
Liberation Front, 10,000-12,000; Sihanoukist
National Army, 3,000-4,000; PRK, 20,000-
30,000
Major ground units: Democratic
Kampuchea—14 designated divisional units,
which are severely under strength and are
actually equivalent to regiment-sized guer-
rilla force units, PRK—4 understrength
divisions and 32 infantry battalions assigned
to provincial military commands
Ships: 2 coastal patrol craft-river patrol craft,
1 amphibious warfare craft};
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Ships: 7 patrol boats','78288d340b3129d8bddc56df912e4314ee43ed666cc0aba407fe89a50f4882e2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50735ad542b3fac09b8be67f829013926803e4d9fc2fcc9ecad4a1fe601148b6',1984,'KI','Kiribati','communications',81,'Airfields: 18 total, 12 usable; 2 with perma-
nent-surface runways; 4 with runways
1,220-2,439.m
Defense Forces
Personnel: no military force maintained;
there are small police posts on all islands of
Kiribati | :
|
i
Korea, North
(See reference map Vili)
Freight carried: rail—133 million metric
tons (1978); highway—116 million metric .
tons (1969); waterway—540 million metric
ton/km, 7.7 million metric tons (1969);
coastal—170 million metric ton/km, 0.4 mil-
lion metric tons (1969)
Merchant marine: 37 ships (1,000 GRT and
over) totaling 288,212 GRT, 469,917 DWT;
includes 27 cargo, 5 tanker, 1 combination
passenger-cargo, 1 passenger, and 3 bulk;
North Korea beneficially owns 2 cargo ships
of 4,900 GRT and 8,500 DWT, operated un-
der the Japanese flag
Airfields: 64 (24 with permanent-surface
runways): 20 with runways over 2,500 m, 22
with runways 1,700-2,499 m; 22 with run-
ways less than 1,700 m
Telecommunications: domestic and interna-
tional services are adequate for needs;
oriented to political, military, and industrial
use; upgrading in progress; good coverage by
radio, TV, and wire broadcasts; about
130,000 telephones; 300,000 radios; 10,000
est. TV receivers; 34 AM radiobroadcast sta-
tions; 3 TV stations and unknown number of
police 5,000, coastal/border security units
45,000), Paramilitary/Militia 5 million
Major ground units: 9 corps headquarters, 1
capital defense corps, 32 standard infantry
divisions, 6 truck-mobile infantry divisions, 3
mechanized infantry divisions, 2 armored di-
visions, SAM command (11 regiments), 7
infantry brigades, 10 light infantry brigades,
4 airborne brigades, 2 amphibious assault bri-
gades, 4 reconnaissance brigades, 1
(women’s) AA brigade, 10 AAA regiments, 8
armored brigades, 3 tank regiments, 5 com-
bined arms brigades, 1 engineer river
crossing regiment, 3 engineer pontoon bridge
regiments, 3 engineer river crossing battal-
ions, 3 engineer amphibian battalions, 6
FROG battalions, 94 artillery battalions
(nondivisional), 82 rocket launcher battalions
TV repeaters; color TV available
Defense Forces
Personnel: army at least 745,000 peacetime,
over 811,000 at wartime table of organization
and equipment; navy 37,500; air force
56,000; military security forces 56,000 (in-
cluding internal security force 8,000, railroad
Ships: | frigate, 2 corvettes, 6 patrol combat-
ants, 21 attack submarines, 30 missile attack
boats, 308 coastal patrol types, 19 mine war-
fare, 125 amphibious warfare, 1 auxiliary,
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
re)
ecree
25X1
25X11
constituting 14.8% of the central government
budget; actual military spending was proba-
bly at least twice the stated amount
and over 100 service craft
Aircraft: 1,280 in air force (667 jet fighters,
83 light bombers, 294 transports, 115 helicop-
ters, 120 trainers, and 1 utility)
Missiles: 45 operational SA-2 SAM sites, 2
SSC-2b (SAMLET) sites
Supply: produces infantry weapons, towed
and self-propelled artillery, rocket launchers,
ammunition (including artillery), tanks, ar-
mored vehicles, explosives, trucks, some
radar and telecommunications equipment,
naval ships (including patrol escorts, subma-
rines, and missile boats), and some chemical
warfare defensive materiel; produces copies
of Soviet surface-to-air and antitank missiles;
dependent on USSR and China for high per-
formance aircraft and sophisticated elec-
tronic equipment
Military budget: no accurate estimates of
military spending are available; announced
military budget is equivalent to-$1.65 billion
for the fiscal year ending 31 December 1983,
47
25X1
25X1
25X1
25X1
25X1
25X1
25X1
25X11
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Declassified
Secrer
Korea, South
(See reference map Vill)
Railroads: (commercial) 3,135 km total
(1980); 3,070 km 1.435-meter standard
gauge, 65 km 0.610-meter narrow gauge; 720
km double track; 429 km electrified; govern-
ment owned
Inland waterways: 1,609 km; use restricted
to small native craft
Merchant marine: 436 ships (1,000 GRT or
over) totaling 4,612,081 GRT, 8,382,018
DWT; includes 205 cargo, 36 container, 50
tanker, 110 bulk, 26 specialized carrier, 4
combination ore/oil, 4 liquefied gas carrier,
and ] passenger
Defense Forces
Personnel: army 520,000, navy 47,700 (in-
cluding 24,000 marines), air force 31,900
Ships: 20 destroyer/frigates, 4 corvettes, 1i
missile attack boats, 67 coastal patrol, 9 mine
warfare, 35 amphibious ships and craft, 10
auxiliary and 140 various service craft
Aircraft: 1,226, including 520 (208 fixed -
wing and 312 helicopters) in army, 65 (28
* prop and 37 helicopters) in naval air, and 64
(495 jet) in air force
Missiles: 34 SAM sites, including 24 HAWK
and 10 NIKE; 1 SSM NIKE site
Suppliy: assembles armored personnel-carri-
ers; retrofits tanks; produces rifles, mortars,
howitzers, other crew-served weapons, small
arms and artillery ammunition, explosives,
some éngineer equipment and quarter-
" master-type equipment; builds frigates,
corvettes, and other naval craft, including
motor gunboats, missile boats, landing craft,
and small auxiliary craft; I frigate completed
and others under construction; 4 corvettes
built and 4 more under construction; assem-
bles limited numbers of helicopters and has
begun assembly of F-5E/F fighter /trainer
aircraft, both under US license; most other
materiel obtained from US
Major ground units: 3 army and 7 corps
headquarters, 2] (19 army, 2 marine) infan-
try divisions, 1 mechanized infantry division,
1 independent infantry brigade, 1 independ-
ent marine brigade, 25 reserve infantry
divisions at cadre strength, 2 air defense artil-
lery (ADA) brigades (including 6 HAWK
battalions, 2 NIKE battalions), 1 ADA GP (9
batteries), 5 independent ADA battalions, 2
armored brigades, 9 separate armored battal-
ions, 7 special forces brigades (airborne), 44
corps and army field artillery battalions (4
light, 25 medium, 15 heavy), 1 multiple
rocket launcher battalion, 2 Honest John bat-
talions, 1 army aviation brigade
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
48
in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7','454c9eee9bdb629e9182975a97b4f3f4808059348ba5f16c0b2991ff99fca390','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e010ac0463aa1be11ab8b0d8ca20dc9d2f09953d1e1a2a45fe9b3ee58db9857c',1984,'KW','Kuwait','communications',82,'(See reference map V1)
Merchant marine: 83 ships (1,000 GRT or
over), totaling 2,377,621 GRT, 3,895,033
DWT; includes 1 passenger, 42 cargo, 20
tanker, 8 specialized carrier, 5 liquefied gas
carrier, and 7 container
Defense Forces
Personnel: army 10,000, navy 470, air force
4,000 (70 pilots), national police force 8,000
Major ground units: 3 brigades (2 mecha-
nized infantry brigades and 1 armored
brigade); 1 Amiri Guard battalion, and 1 mili-
tary police battalion
Aircraft: 93 (59 jet, 4 transport, 30 helicop-
ters) -
Ships: 6 guided missile patrol boats, 43 patrol
boats, 6 utility landing craft
Supply: dependent mainly on UK, but alsoon
Belgium, France, Italy, and FRG; on Singa-
pore for patrol boats; on FRG for missile
attack boats and guided missile patrol com-
batants; field artillery, rocket launchers and
rockets obtained from USSR
Laos
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
(See reference map IX)
Civil air: 9 major transport aircraft
Defense Forces :
Personnel: ground 53,000, air force 800 (pos-
sibly 200 pilots), river flotilla unknown
Major ground units: 4 infantry.and 1 artil-
lery divisions, 7 infantry regiments, 1
engineer regiment; 54 infantry, 4 artillery, 2
armor, and 10 AAA battalions; in addition,
there are believed to be elements of 4 Peo-
ple’s Army of Vietnam (PAVN) infantry
divisions, 2 combat regiments, 2 engineer di-
visions, and assorted PAVN logistics forces in
Laos
Ships: 15 coastal-river patrol craft, 4 am-
phibious warfare craft, 6 service craft
Aircraft: 51 (37 fixed wing—19 combat, 12
transport, 6 utility; 14 helicopters—14 tur-
bine)
Supply: dependent on USSR and Vietnam
Military budget: announced for fiscal year
ending 30 June 1979, $50 million; about 29%
of total government budget
49 Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
-25XK1
25X1
25X1
25X1
25X11
25x1
25X1
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','522089bb0b588c801ea4744ce595068d9ac0705630c5edfa02ef466510aa77e3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3d588bf5ca1ec73984f1aad9cc90ee3ffb0bf987c416ad6b46f5c39fc763096',1984,'LB','Lebanon','communications',83,'_ (See reference map Vi)
Merchant marine: 99 ships (1,000 GRT or
over) totaling 279,234 GRT, 389,415 DWT;
includes 82 cargo, 3 bulk, 7 specialized car-
rier, 6 roll-on/roll-off cargo, and 1 container;
Supply: nearly all supplies purchased abroad,
principally from US, France, and''‘UK; minor
amounts from USSR and Yugoslavia
a flag of convenience registry
Deterse Forces -
Personnel: 23,000 as.of 31 December 1982
Major ground units: 1 mechanized infantry
brigade and 6.infantry brigades are being
formed; eventually, all are to be mechanized;
each brigade wil] consist of 8 mechanized
battalions, an artillery battalion, and an ar-
mored reconnaissance battalion
Ships: 1-motor gunboat, 12 patrol boats
’ Aircraft: 68 (26 jet, 9 prop, 33 helicopters);
only. about two-thirds of inventory opera-
tional; air force now is basically a rotary-wing
element of the LAF ioe
Secret
50','b417eb38001a985391042161fc7c8200760e2b6498b861b21424f76b4d5a2253','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35dca1d9b9b0be30b5f14b7fa91d02c1ebe10569cbceb944f362adb04c7e222a',1984,'LR','Liberia','communications',86,'Merchant marine: 2,149 ships (1, 000 GRT< or
over) totaling 74,097,051 GRT, 144,167;616
‘DWT; includes 7 passenger, 411] cargo, 40
container, 22 roll-on/roll-off cargo, 662 —
tanker, 49 liquefied gas, 639 bulk, 129 com-
bination ore/oil, 5 barge carrier, 185
specialized carrier; although this registry.
ranks first in tonnage in the world, all but 2
ships are entirely.foreign owned-and oper-’
ated
Defense For ‘orces
Personnel: army 4, 500, coast guard anes
Military budget: for year ending 30 June.
1982,-$60.1 million; 13.9% of oneal govern-
ment budget
448, nationa) police force 1,300
Major ground units: 1 brigade headquarters,
3‘infantry battalions, 1-executive mansion’
guard battalion, 1] engineer battalion, ] artil-
lery battalion, 1 brigade armored scout unit,
1 service support battalion, ] agricultural:
battalion, 2 border. guard battalions, and 1 air
reconnaissance unit
Ships: 1 gunboat and 6 patrol boats
Aircraft: 9 light prop
Supply: dependent mainly on US, has re-
ceived rifles from Ethiopia, small arms and
ammunition from Israel, armored cars from
Switzerland, trucks from Japan and materiel
from the FRG and the ROK, and 8 patrol
boats from Sweden
51
25X1
Libya e ae
“(See veleieiles map vi
''
Economy 5
Aid: economic commitments—Western
(non-US) ODA and OOF (1970-81), $90 mil-
lion; US (FY70-82), $0.5 million; military
commitmeénts—Communist countries (1970-
82), $18.5 billion; US (FY70), $0.1 million’
oni
Corinianieations
. Merchant niarine: 28 ships (1,000 GRT or.
over) totaling 876,904 GRT, 1,577,266 DV25X1
includes 7 cargo, 4 roll-on/ roll-off cargo, 13
tanker, 1 specialized carrier, and 3 passenger
Ge TS ZO
‘Defense Forces
ae : “ . " 2ZOXT
Telecontnmicaione system is in top third
of African systems; coaxial cable and radio
relay used widely; domestic satellite network
under construction; Soviet facilities at To-
bruk; principal centers are Tripoli and
Benghazi; 200,000 telephones (6 per.100 °
popl.); 18 AM, 3 FM, and 16''TV stations; 2
submarine cables.to France and Sicily; satel-
lite service from Tripoli, 8 antennas, 1
ARABSAT station under construction
‘ 25x14
Personnel: army 60,000, navy ‘8, 000, air:
force 10,000 (350 pilots), air defense: 12, 000
_ 25X14
laste Biounduie 2 divisions (1. armored, ]
mechanized); 8-identified maneuver brs, -
gades; 3 identified artillery brigades; 2 25X14
_ brigade-equivalent-.Jamahiriya: Guard units
» 25X1
Secret oat ee,
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Libya (continued)
Ships: 6 attack submarines; 7 guided-missile
patrol combatants; 24 missile attack boats; 7
amphibious landing ships
Aircraft: 8 intermediate-range bombers; 381
all-weather fighters; 95 fighter bombers; 63
transports; 395 trainers; 157 helicopters; 33
ASW helicopters
Missiles: 25 SA-2 battalions (160 SA-2 -
launchers), 28 SA-3 battalions (120-SA-3 -
launchers), 20 SA-6 battalions (160 SA-6
launchers), 5 Crotale batteries (24 Crotale
launchers), 14 SA-8 launchers, 60 SA-9
launchers
Supply: dependent mainly on UK and US up
to 1969; UK provided a Vosper Mk. 7 frigate
in 1973; current contract for 10 French mis-
sile attack boats; 4 patrol guided missile
combatants delivered by Italy 1979-81;
France primary supplier of aircraft and sup-
plied the Crotale surface-to-air missile in
1973; Soviet military aid began in 1970 and
accelerated throughout the 1970s, with sub-
stantial deliveries of tanks, armored
personnel carriers (APCs), artillery, transport
vehicles, 12 missile attack boats, 5 subma-
rines, 2 guided missile patrol combatants, 4
fleet minesweepers, bomber and fighter air-
craft, SCUD surface-to-surface missiles and
surface-to-air missile systems; additional
missile boats and submarines are to be re-
ceived; Czechoslovakia and Poland also have
provided APCs, artillery, and tanks and 4
medium landing ships; Italy has provided ar-
tillery, APCs, 1 vehicle cargo ship, and 4
missile attack boats
Military budget: estimated for fiscal year
ending 31 December 1983, $4.3 billion; 27%','64984504073fbdf47470e444aa1ce3c7f2b0d4626b1c2972612af060265a0084','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6658b36c10df555ebb7ee513152d1cbc766293d2d372dca33620c4e76f837596',1984,'LI','Liechtenstein','communications',87,'(See reference map V)
of central government budget
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
52
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
25X1','6ca518e1477bed8cf64c6015a76e7b935dddac0c7ef2bc99ee8a0321c7040ac1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee7dffd71e304228f6dbd264c4781c9dbb36c7cc5127b9f0c6ab385bec17bd37',1984,'LU','Luxembourg','communications',88,'(See reference map V)
Defense Forces
Personnel: army 618, national gendarmerie
463
Major ground unit: | light infantry battalion
Supply: completely dependent on other
Macau
enone KonG
MACAU
PHILIPPINES} ©
(See reference map Vill)
Defense Forces
Personnel: several Portuguese military per-
sonnel are assigned to nondefense positions in
the government
Ships: 8 patrol craft, under control of Water
and Customs Police
NATO countries, primarily the US
Military budget: proposed for fiscal year
ending 31 December 1982, $47.9 million;
3.5% of central government budget
53
CIA-RDP08-00534R0001 00050001 -/
ecret','44d2d5daaeb19a5dd833fc48c76c7854c285dd64d618cc1c6bea72e5e0dcf797','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26ede3e37ca745b1eb46d8ba996457bd241429352d6f080fb184d59c3eb2feee',1984,'MG','Madagascar','communications',89,'(See reference map Vil)
Merchant marine: 16 ships (1,000 GRT or
over) totaling 69,257 GRT, 97,474 DWT; in-
cludes 10 cargo, 2 tanker, 1 specialized 25X11
carrier, 1 liquefied gas carrier, and 2 roll-
on/roll-off
25X11
Defense Forces
Personnel: 20,000 army, 400 navy, 500 air
force, 8,000 gendarmerie
Major ground units: 2 intervention brigades,
1 air defense brigade, 1 artillery brigade, 1
armored brigade, 1] engineer regiment, 7
development force regiments, 1 communica-
tions regiment, ] support regiment, | motor
transport regiment, ] presidential security
regiment; equipment includes light tanks, ar-
mored cars, scout cars, air defense artillery,
field guns, howitzers, mortars, and antitank
rocket launchers 25X1
Ships: 4 fast patrol craft, 1 patrol craft, ] am-
phibious assault landing ship, and 1
miscellaneous auxiliary
Aircraft: 41 (18 jet, 15 transports, 5 utility, 3
helicopters) 25X1
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
secret
Madagascar (continued) Malawi
Supply: increasingly supplied with equip-
ment by Communist countries, including
USSR, North Korea, and GDR; some equip-
ment is also supplied by France and FRG
(See reference map VII)
Defense Forces
Personnel: 6,000 army, 3,000 police (includ-
ing 460 police mobile force), est. 600 Malawi
Young Pioneers
Major ground units: 3 motorized infantry
battalions; a paratroop wing was formed dur-
ing 1981
Ships: 4 patrol craft (8 limited operation, 1
out of operation)
Aircraft: 8 prop utility aircraft, 5 helicopters
Missiles: 11 Blowpipe SAM
Supply: mainly from UK, but also from sev-
eral other Western and Third World
countries
Military budget: for fiscal year ending 31 |
March 1983, $29.2 million; 11.4% of recur-
rent central government budget
’ Secret 54
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7','bdffb1034bf722bdfb19908daad7185ae3f9c4b1b716dca6de550d8a2220b218','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c2f652dac2e2dba8fae8529b1eec49e0127bb133e9e71b564d288667e06d8e',1984,'MY','Malaysia','communications',91,'(See reference map IX)
NOTE: Established on 16 September 1963,
Malaysia consists of Peninsular Malaysia,
which includes 11 states of the former Fed-
eration of Malaya, and East Malaysia, which
includes the 2 former colonies of North
Borneo (renamed Sabah) and Sarawak.
Merchant marine: 91 ships (1,000 GRT or
over) totaling 1,031,480 GRT, 1,366,904
DWT; includes 53 cargo, 6 tanker, 11 bulk, 2.
roll-on/roll-off, 1 combination ore/oil, 10
container, 4 specialized carrier, and 4 lique-
fied gas tanker
Ships: 2 frigates, 4 amphibious ships, 95
coastal patrol-river/roadstead craft, 20 am-
phibious warfare craft, 2 auxiliaries, 5 yard
and service craft
Defense Forces
Personnel: army 83,000, territorial army
50,000, navy 10,000, police field force
22,000, marine police 2,800, Sarawak Border
25X1
25x11
25XK1
25X1
25X1
25X1
~25K1
29X11
25X11
25X1
25X1
Scouts 1,300, air force 12,000 (500 pilots) 25X11
Major ground units: 4 infantry divisions, 42
battalions, 4 cavalry battalions, 5 artillery
battalions, 1 air defense/artillery battalion, 2
peciassiiicd in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
>
alin ate ae i id
oe
special service battalions, 11 engineer battal-
ions, 4 signal battalions, and 21 police held
force battalions
Ships: 2 frigates, 8 missile attack boats, 29
coastal] patrol, 14 auxiliary, 21 amphibious
ships/craft; and 2 service craft; in addition
Marine Police have approximately 100
coastal patrol craft and numerous siriall pa-
trol vessels
Aircraft: approximately 155 (33 jets
Supply: fast patrol boats and ammunition do-
mestically produced; naval ships and
equipment from New Zealand, Singapore,
France, Australia, UK, Sweden, and the US;
some air force equipment from Canada,
France, UK, US, and Australia; ground force
equipment from Yugoslavia, Australia,
France, FRG, Italy, ROK, Sweden, and UK; 2
guided missile corvettes from FRG; 4 mine-
sweepers from Italy; armored vehicles from
US, UK, and Belgium
25X11
. Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
25X1','b56136ea44b104615de9b798373318cbb72405a2c1aef701c9c560f282b582ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db6be76142ac36ea1da1ce3c099f6080f1b12a4438549d40849d66773608f299',1984,'MV','Maldives','communications',93,'(See reference map VIII)
Merchant marine: 30 ships (1,000 GRT or
over) totaling 146,904 GRT, 207,983 DWT;
includes 28 cargo, 1 container, and 1 bulk
carrier
Defense Forces
Branches: no formal defense structure and no
regular armed forces exist; National Security
Service of the Maldives, a paramilitary orga-
nization with an est. 1,000 members, consists
of a marine division (coast guard), an air pa-
trol, and some smaller units; has coastal
defense responsibilities
Ships: 3 ex-Taiwanese trawlers, armed with 1
twin 25-mm gun; 1 13.7-meter launch; 1 ex-
British landing craft; 1 ex-British 19.2-meter
boat (manned by 100 men)
Aircraft; 5 light aircraft
25X1
55
Secret','4bdb04a1ab8eb96c0090682a430cd735cb16183e09570e7720eb31cc6d85537e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc3a08c82df29cacdbf18b501724c39f574acc48a6e19e6527b15da1b8b7b1ec',1984,'MT','Malta','communications',96,'Merchant marine: 38 ships (1,000 GRT or
over) totaling 201,263 GRT, 312,321] DWT;
includes 22 cargo, 6 roll-on/ roll-off cargo, 5
bulk, 2 specialized carrier, 2 tanker, and 1
passenger
Defense Forces
Defense no longer responsibility of UK; Reg-
ular Armed Forces of Malta consist of a small
headquarters staff; a regiment (US battalion)
consisting of the regimental headquarters
battery, a maritime unit with 10 coastal pa-
trol boats, and a helicopter detachment with
8 helicopters; 1 infantry company; and a
service support unit including engineers; per-
sonnel strength is approx. 700; the
paramilitary Id-Dejma consists of 1 corps of
about 1,000 personnel; the Arms of Malta
consists of 1 battalion of about 4,000 person-
nel
Malta police force is composed of about 1,300
Maltese','274663b8d500c303af8bfef4d167f73f2de8e587dae96d948857a3be55028345','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3425d0de4747e31d21737be168e85567a4972e224fe96e58c5cc0a57af471bac',1984,'MQ','Martinique','communications',97,'Atlantic Ocean
(See reference man Ill)
Defense Forces
Defense is responsibility of France; data are
for French military forces
Personnel: 1,850 army infantry; 900 civic ac-
tion; 200 navy; small air force detachment;
800 gendarmes
Major ground units: 1 overseas infantry regi-
ment, 1 civic action battalion
Ships: 2 patrol craft, 3 landing ship/craft, 1
auxiliary
Aircraft: 10
Secret
25X1
25X1 25x11
25X1 25X1
56','87ead464b6d0822bb9bc5d7154f6e4cf83794abc5d7c0080106e60840588b619','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0acf805a199f62cb7ab5fd7c42d8f7a74cb5572c985b43a36ec081ac0a40a197',1984,'MR','Mauritania','communications',98,'_ Atlantic
Corel <a
: On SF
(See reference map VII)
Merchant marine: | cargo ship totaling 1,500
GRT, 1,700 DWT
Defense Forces
Personnel: 8,300 army, 400 navy, 150 air
force, 2,200 gendarmerie, 3,000 national
guard
Major ground units: 1 headquarters com-
pany, 1 engineer company, | artillery
battalion, 2 armored car squadrons, 1] tacti-
cal units (company), 1 commando company,
l air defense battery
Ships: 9 patrol craft, 1 landing craft
Aircraft: 16 prop (8 transport, 8 utility)
29X1 25X1
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
25X11
25X1
25X1
ZOA |
25X1
25X1
'' Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','e5cad4b1b75d256c2324b59e7587d2660d0389cd9493ba79fb593613b3d8190d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa19d9f7bca8e12d5f118c897aaebd3ab456d3fe7fa17574323b4e7766573430',1984,'MU','Mauritius','communications',100,'(See reference map VII)
Merchant marine: 6 cargo ships (1,000 GRT
or over) totaling 32,464 GRT, 47,874 DWT
Defense Forces
Personnel: 700-man paramilitary Special
Mobile Force (SMF); 240-man Police Riot
Unit (PRU), 4,000-man police force (includes
personnel assigned to PRU); SMF is well orga-
nized and capable of providing security
during small-scale uprisings; the PRU and the
police force are capable of assisting the SMF;
major equipment of the SMF includes small
arms, an Alouette III helicopter, and 11 per-
sonnel carriers
Ships: 1 patrol craft assigned to police
Supply: Mauritius looks to India and France
for military aid','9b60375695488a25860b7f5bacbdeac4298c19c49d1fd902105f02de2c54a335','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04b4c583f9daaad05ce4948179935d996345af1538986a7d73a9b90618a8fe32',1984,'MX','Mexico','communications',102,'(See reference map Il)
Merchant marine: 78 ships (1,000 GRT or
over) totaling 1,003,831 GRT, 1,500,924
DWT; includes 6 passenger, 18 cargo, 3
roll-on/roll-off cargo, 36 tanker, 2 special-
ized carrier, 6 bulk, and 7 liquefied gas
carrier
Defense Forces
Personnel: 74,000 army, 23,400 navy (in-
cluding 4,900 marines, 500 naval air), 5,000
air force (including 450 pilots)
Major ground units: 4 brigades (1 presiden-
tial guard, 2 infantry, and 1 military police),
65 separate infantry battalions, 1 cavalry
regiment (horse), 23 motorized cavalry regi-
ments, 1 mechanized cavalry regiment, 1
armored cavalry regiment, 5 artillery regi-
ments, 1 armored infantry regiment, 1
engineer service regiment, 1 combat engi-
neer battalion, 1 signal battalion, 1 transport
regiment; regiments are comparable in size
to battalions; air force has 1 airborne brigade,
Secret
Aircraft: air force 282 (37 jet, 76 turboprop,
146 prop, 23 turbine helicopters, 1 piston he-
licopter); naval air 40 (1 jet, 3 turboprop, 26
prop, 10 helicopters) 25X1
Supply: produces small arms, mortars, am-
munition and quartermaster equipment, as
well as its own armored cars—the DN II] and
the DN IV; some medical supplies and gen-
eral purpose motor transport vehicles are ~
procured from domestic sources; a small''na-
val ship production capability exists; 25X1
produces patrol boats; imports other mate-
riel, including most naval ships, from US,
Western Europe, Israel, Spain, and Japan;-
large aircraft order with Switzerland
1 combat engineer battalion
Ships: 6 corvettes, 34 patrol ships, 31 patrol
craft, 14 patrol boats, 5 amphibious warfare
personnel transport, 2 amphibious vehicle
landing ships, 13 support ships and other aux-
iliaries
57
Secret
’ Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret','8bb64b464f657f9e0dda5702b82f6519967d916dff109cc5d23a8eea6ab6171d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fc4da80afcebdc8f4534790dfb4d7423c5ebb27a54d7f0dcf274a96cd92ccbe',1984,'MC','Monaco','communications',104,'(See reference map V)
Merchant marine: 2 tankers totaling 28,154
GRT, 45,405 DWT
29X11
Secret','d6646094e17b198d42895714204c278c4f4067575caff9eaf21fdc13b30c27b4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c64df8474c48a4533144ba1d8239e93b7f7039b36fc93ae5fbeb2310431a15e',1984,'MN','Mongolia','communications',105,'(See reference map VIII)
Civil air: 22 major transport aircraft (1984)
Airfields:''34 total; 9 with permanent-surface
runways; 16 with runways 2,500-3,499 m, 15
with runways 1,000-2,499 m, 3 with runways
less than 1,000 m; 1 heliport
Telecommunications: domestic and interna-
tional facilities are being modernized and
provide fairly good service; 25,805 tele-
phones (96% automatic); about''93 telephone
exchanges and 25 telegraph offices; 2 main
AM radiobroadcast stations supplemented by
about 294 wired broadcast distribution sta-
tions; 111,000 radio and 67,000 wired
broadcast receivers; 3 TV stations; 20,000 TV
receivers (est.
Defense Forces
Personnel: (est.) 20,000 ground forces; 100 pi-
lots in air force (operate civil airline); 15,700
paramilitary forces; as of 1 January 1983,
49.000 Soviet ground forces troops and 6,500
Soviet air force personnel in Mongolia
fayos es Kaige neg Legs — +
Major ground units: 3 identified motorized
rifle divisions, 1 artillery brigade, 1 AAA reg-
iment, and 1 rocket launcher regiment, plus.
combat and service support unity si
58','1322b85e3e3079d26352bb552849323e06d572807dda36c1d6f1962c9e08becb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7aa1115324f5d136afd00158520b662261df2e815f98498329cc73d1da5a4c',1984,'MA','Morocco','communications',106,'re
@
: (See reference map Vil) ;
Merchant marine:.48 ships (1,000 GRT Or.
over) totaling 345, 906 GRT, 571,323 DWT:
includes 1 passenger, 22 cargo, 2 roll-on/ roll-
off, 3 container, 5 tanker, 3 bulk, 11
specialized carrier, and 1 liquefied gas car-..
rier — a) <
, ZOA
Defense Forces
Personnel: 160,000 army, 7,000 navy, 13, 500
air force (270 pilots), 29,000 auxiliary forces,
8,800 royal gendarmerie, 5,800 mobile inter- *
vention companies of national police 95X1
Major ground units: 3 mechanized infantry 25X1
brigades, 1 light security brigade, 1 para-
chute brigade, 8 mechanized infantry
regiments, 24 separate infantry battalions, 7
armored battalions, 10 artillery battalions[_|
25X11.
Ships: 1 Exocet-missile-equpped frigate, 1
submarine chaser, 2 patrol escorts, 2 patrol 25X11
craft, 4 missile attack boats, 11 patrol boats, 1
coastal minesweeper, 3 medium landing
ships, 2 service craft, and 1 utility landing
craft 25X1°
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
. ee ee ee re ee
cw Se ee ee
at
Aircraft: 72 fighter aircraft, 23 transports, 48
trainers/utility, 7 reconnaissance, 118 heli-"
copters (all services)
Sinabi: dependent entirely on foreign sup-
plies, principally France and US, but also
obtains some equipment from Warsaw Pact
countries; 4 guided missile patrol combatants
and a corvette received from Spain; with
French assistance, has begun development of
a trainer aircraft','74ab1576c85c2fd8109d5c3f31e39b012655101a8e6bed01e9d747c6c3f7343a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9838c3e9cc21569505c7837ce4156919296f052059750704858f687db08cadf',1984,'NR','Nauru','communications',111,'Merchant marine: 4 ships (1,000 GRT or
over) totaling 50,743 GRT, 72,177 DWT; in-
cludes 1 cargo, ands 3 bulk
25X1
25xX1
25X1
60
- scout cars and 105-mm guns from UK
Nepal P+ Bae
(See reference map Vill)','1368c19819e7a830022402e87de59badd9cdce7cd0a33525d72111d6943d6d1b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93570b9353289065c16d86911e6d923ca901b0e2ae2ceaf57927e1f9e70cfba8',1984,'NL','Netherlands','communications',112,'Merchant marine: 406 ships (1,000 GRT or
over) totaling 3,857,877 GRT, 5,176,798
DWT; includes 3 passenger, 284 cargo, 22
container, 9 roll-on/roll-off cargo, 24 tanker,
33 bulk, 1 barge/lighter carrier, 26 special-
Missiles: 4 NIKE-Hercules squadrons and 15
I-HAWK squadrons
Supply: naval ships produced domestically
include guided missile frigates, submarines.
and mine warfare types; has built guided
missile frigates and corvettes for export, 2
transport-type aircraft, produces US F-16
fighters as part of a European consortium;
moderate quantities of ammunition, some
CW/BW defense materiel, and military
telecom and electronics equipment: most
supplies from other NATO countries; naval
surface-to-air missiles from the UK,
p
air-to-surface missiles from France
ized carrier, and 4 liquefied gas carrier
25X1
Defense Forces
Personnel: 72,400 army, 16,800 navy (in-
cluding 2,200 naval air and 2,600 marines),
17,879 air force approx. (497 pilots), 3,975
royal constabulary
Major ground units: | NATO-committed
corps consisting of 2 active mechanized divi-
sions, 1 reserve mechanized division, 1
reserve motorized infantry brigade, a corps
artillery group with a Lance battalion, an SP
155-mm howitzer battalion, a 175-mm gun
battalion, and an SP 203-mm howitzer battal-
ion (1 reserve field artillery group with 6 155-
mm towed howitzer battalions and 2 208-
mm towed howitzer battalions, 1 combat
engineer group, | aviation group, 1 signal
& group, and | corps command
Ships: 2 guided missile destroyers, 6 subma-
rines, 15 frigates, 9 patrol vessels, 16 mine
warfare ships/craft
25X1
Aircraft: 367 (224 jet, 14 turboprop, 12] heli-
copters); 335 air force (224 jet, 14 turboprop,
99 helicopters); 32 naval air arm (10 turbo-
prop, 22 helicopters)
61
Secret
Netherlands Antilles
~25K1
Atlantic Ocean |
Caribbean ANTILLES
Sea
“25X11
(See reference map Iii)
25X1
Merchant marine: 56 ships (1,000 GRT or
over) totaling 1,607,903 GRT, 2,876,660
DWT; includes 5 passenger, 17 cargo, 2 con-
tainer, 3 roll-on/roll-off cargo, 14 tanker, 4
liquefied gas, 5 bulk, and 6 specialized car-
rier; all but a few are Dutch owned
Defense Forces 25K1
Local security forces: civil police, 675 (in-
cluding 40 Dutch under contract in adviser
and warrant officer duties); 200 Antilles ma-
rines; National Guard, 200 (force is a res25X1
unit) 25X1
Personnel: Dutch forces: 1,600 navy, 400
marines with 200 Antillean conscripts (600
total); local civil police force cooperates with
Dutch forces 25X1
Ships: | frigate, and 1 medium landing craft
from the Netherlands inventory
Aircraft: 2 prop
25X1
20X11
ZOA |
25X1
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Secret','b67206d5e1029f8e13af52fe99698c5111b57c0de87aff3efc805966cc77dc76','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca1f5eef0683ea9d14e9e60feee9df3c1e42c4eaaf414e6a5ff7d2bb9965cbf',1984,'NC','New Caledonia','communications',113,'(See reference map X)
Defense Forces
France provides for deisics there are about
2,900 military personnel in New Caledonia,
including paramilitary forces (gendarmes |
and police agents); a Gendarmerie division is
stationed there; officers of this force are re-
cruited in France; there is also an auxiliary,
Gendarmerie of Melanesians; the police -
force, as distinct from the Gendarmerie, is
locally recruited and operates in Noumea un-
der a French officer; there is a naval base at
Noumea (2 patrol combatants, 1 amphibious
ship; 2 auxiliaries homeported), 1 fleet air -
squadron (4 fixed-wing transports), and 10+to
15 helicopters at Tontouta Airport
Major ground units: 1 infantry regiment (3
motorized infantry companies and ] air-
borne company)
Secret','fb2a4095091dc4d6ad46eef64ad2b2f085d9207be4dac3b5d78a005b32e9b6f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a555ce57f8926226f2ef833cff844d6d835d26f631f506f467fc49708908e8',1984,'NZ','New Zealand','communications',114,'(See reference map''X)
Merchant marine: 24 ships a, 000 GRT or
over) totaling 205, 646 GRT, 232,030 DWT;
includes 2 passenger, 5 cargo, 4 roll-on/ .
roll-off cargo, 3 bulk, 3 tanker, 6 specialized
carrier, and 1 container
Defense Forces or
Personnel: 5,675 army, 2, 781 navy, 4 220 air
force
Major ground units: 2 infantry regiments
(battalion), including 1 in Singapore, and 1
special air service squadron (remainder of
army essentially a cadre force)
Ships: 5 frigates, 9 coastal patrol, 4 auxiliary-
service craft
Aircraft: 102 (80 jet)
Supply: capable of producing some small
arms ammunition; produces some utility air-
craft; dependent on foreign sources for all
other materiel, principally UK, US, FRG,
‘CIA-RDPO8-00534R0001 00050001-7
(See reference map Ill)
Merchant marine: 8 ships (1, 000 CRT or °
over) totaling 25,470 GRT, 37,864 DWT: in-
cludes 5 cargo, 2 roll-on/roll-off, and 2 tanker
Defense Forces
Personnel: est. 32, 500 anciodes Sandinista
Popular Army, Border Guard troops, navy,
air force, and Ministry of Interior troops)
Australia (also ‘Canads for naval items)
62 -
Major ground units: 12 infantry battalions, 3
armor battalions, ] artillery brigade, assorted
logistics units, 6. Bordet Guard battalions, 40-
50 reserve infantry battalions,.and 30-50
militia battalions; air force controls 1 Air De-
fense Group
Ships: at Test 17 patrol craft plus an un-
known number.of armed fishing craft (S)
Aircraft: 61 (8 jet, 43 mixed prop.and turbo-
prop, 15 helicopters)
Supply: dependent sdeanty upon Cuba.and
the USSR: since 1974; has purchased. aircraft
and patrol boats from Israel
M ilitaty budget: estimated for fiscal year
ending 31 December 1982, $89.9 million
(est.) for the Ministry of Defense, including
civil functions (e.g., police and civil-air): 8.6%
of central government budge
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
LUA I
25X1
25X11
25X1
25X1
a2v/NXN 1
25X1
NEVA
“25X1
25X11.
pe
25X1
25X1
25X11.
Ss Signs cage I rem RT am rm ry a RN ner nr eer ear a ey ver
ee er eee oe
eer ee
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :','ec383af901503245e7caf4f24ddf2f8015679988f7b59ad2ba884395f6eddede','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a6e45ea08a73be8aa5fbac2f233a6d0f9098c2c928b1a10c55de5e66a6d808d',1984,'NG','Nigeria','communications',117,'Merchant marine: 27 cargo ships (1,000 GRT
or over) totaling 423,309 GRT, 608,772
DWT; includes 26 cargo and 1 tanker
Defense Forces
Personnel: army 110,000; navy 6,000; ai12 5X 4
force 11,000; police force 93,000; military
advisers: 40 UK, 25 Pakistani, 34 Indian, 10
Soviet 25X1
Major ground units: 2 mechanized divisi25 X (|
1 armored division, 1 special purpose divi-
sion, 1 artillery corps (18 brigade
headquarters—5 mechanized, 4 armored, 3
artillery, 1 infantry, 1 airborne, 1 air porta-
ble, 1 amphibious, and 1 air defense); 12
division combat support units (battalion 25X11
size—4 field engineer, 4 signal, and 4 mainte-
nance); 16 division service units (battalio25X 4
size—4 medical, 4 provost marshall, 4 supply
and transport, and 4 ordnance/ammunition
depots) 25X1
Ships: 54 total (1 frigate, 1 guided missile frig-
ate, 10 patrol combatants, 2 amphibious
landing craft, 37 coastal patrol boats, 2 auxil-
iaries, lfireboat)) =| 5X
Secret
CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Nigeria (continued)
Aircraft: 137 (40 jet, 8 turboprop, 44 Prop, 45
helicopters)
Supply: produced some small arms and am-
munition in the past; army materiel obtained
from France, FRG, Austria, Belgium, Italy,
and UK; other ‘materiel imported primarily
from UK, USSR, and FRG; dependent for
ships on UK, FRG, and France; received air-
craft from Czechoslovakia, Sudan, Egypt,
and the USSR in the past; UK and France
morerecently) —_—si
Military budget: for fiscal year ending 31 °
December 1983, $1.28 billion; about 8.3% of
the central government budget
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :','35a224f547232f0680bbc410cc280b8175a9fb097884d641b8b34c47119a0f75','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b20b577be016076b182af21754144c1533fee3f5c9340bd418e208c03698bf20',1984,'NO','Norway','communications',118,'(See reference map V)
Merchant marine: 615 ships (1,000 GRT or
over) totaling 1,697,950 GRT, 39,214,296
DWT; includes 38 passenger, 103 cargo, 2
container, 32 roll-on/roll-off cargo, 138
tanker, 48 liquefied gas, 108 bulk, 44 com-
bination ore/oil, and 102 specialized carriér
Defense Forces
Personnel: 18,000 army, 8,900 navy, includ-
ing coast artillery and coast guard, 9,950 air
force (235 pilots)
Major ground units: | active brigade, 13 mo-
bilization brigades
Ships: (including Coast Guard assets) 8 frig-
ates, 14 submarines, 2 patrol combatants, 11
patrol ships, 39 missile attack boats, 8 torpedo
boats, 3 minelayers, 9 coastal minesweepers,
1 coastal minehunter, 10 auxiliaries, 8 am-
pbibious craft
Pree. 246 (151 jet)
M isbilee 1 NIKE Rahealios (4 batteries), RBS-
70 (36 launchers)
Supply: ammunition and explosives, some
light armaments, electronic equipment,
chemical warfare defensive materials, air-
craft, avionics, engine parts, and naval ships
(except submarines) produced domestically;
has exported missile attack boats; producing
64
CIA-RDP08-00534R000100050001-7
small antiship missile, Penguin; most equip-
ment from other NATO countries, Sweden,
and US
25X11
25X11
4
25xX1
CIA-RDP08-00534R000100050001-7
25X11
25X11
25X1
25X1
25X11
LT a','e1d3bb84c3bf02cabb3c0cd51dd54958c2e655c6be43ab6a3d014cb370fd2b50','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3614fcbd6fda8f1f30cba072b532e146fbb134b7e5c5078ef0b3e72b0d476985',1984,'OM','Oman','communications',119,'(See reference map VI)
Economy j :
Aid: economic commitments—OPEC ODA
(1974-82), $1.6 billion; Western (non-US)
countries ODA and OOF (1970-81), $22 mil-
lion; US (FY70-82), $24 million
Merchant marine: | roll-on/roll-off ship to-
taling 1,500 GRT, unknown DWT
Defense Forces
Personnel: 15,600 army, 1,500 navy, 2,200
air force (350 officers)
Major ground units: 2 infantry brigades, 1
royal guard brigade, 1 special forces unit, 1
artillery regiment, | armored regiment, and
1 airborne regiment
Ships: 1 guided missile boat, 1 guided missile
patrol combatant, 23 patrol boats/craft, 6
medium landing craft, 1 personnel landing
craft, 1 command amphibious ship, 6 auxilia-
ries
Aircraft: 119 (57 jet, 9 prop, 18 turboprop, 35
helicopters)
Supply: mostly from UK; some ground
equipment and aircraft from China, Bel-
gium, France, Italy, Iran, Jordan, and Saudi
Arabia','d38afea2af8242fe4899b44240635e012fa7858b1f7ae6fa37e46e76e0fd7450','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa1a8322a2fe6ab48adfa25d8cb832d5cab96905b2045b40d724f78f8fb7402',1984,'PK','Pakistan','communications',120,'(See reference map VIII)
Merchant marine: 52 ships (1,000 GRT o
over) totaling 473,195 GRT, 645,513 DWT; .
includes 51 cargo and 1 bulk
Defense Forces 5. os ae
Personnel: 450,000 army, 13,000 navy, about
18,000 air force (600 pilots), 76,000 civil
armed forces :
Major ground units: 7 corps headquarters,
17 infantry divisions, 2 armored divisions, 11
independent infantry brigade groups, 7 corps
artillery brigades, 4 independent armored
brigade groups, 3 AAA brigades, 8 SAM
squadrons, and | special services group, plus
an army air arm
Ships: 1 nonoperational training cruiser, 8
destroyers, 6 submarines, 5 midget subma-
rines, 22 coastal patrol, 3 mine warfare, 3
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
force; 10 helicopters and 1 turboprop aircraft
plus 3 long-range maritime patrol aircraft as-
signed to navy air
Supply: produces infantry weapons, mortars,
sma}] arms, ammunition and aerial bombs, .
and has limited capability to repair its armor:
inventory; has produced support''ships; US -
and Western Europe were principal suppli-
ers until arms ‘embargo in September 1965; :
since then, China and France.have become
major sources; US reinitiated arms deliveries
between March 1975 and April 1979 and pro-
vided armored personnel carriers and TOW
missile systems, but all US military sales were
then suspended in response to Pakistan’s con-
tinued nuclear weapons development
program; infantry weapons, tanks, and artil-
lery have been provided by China; artillery.”
and ammunition by North Korea; tank main-
tenance service from Jran; aircraft by China,
France, Italy, Sweden; FRG, and the US; 25X14
helicopters provided by USSR, US, UK, ana
France; transport vehicles supplied by
China; USSR, US, Czechoslovakia, and Ja- --
pan; France has provided 6 submarines, 8% 5X1
Mirage fighters, and Exocet missiles; China
has supplied over 200 jet fighters and trairQ5X 4
ers, 4 guided missile patrol boats, 12
Shanghai-II-class patrol boats, 4 Hainan-cl: 5X1
subchasers, and 4 Hu-Chwan-class torpedu
boats; other naval ships have come from It-
aly, the UK, and the US
auxiliary, 4 guided missile patrol boats
Aircraft: 489 (445 jet, 15 turboprop, 21 prop,
8 helicopters) operationally assigned to air
65
25X1
5X1 25K ay
25X1
25X11
25x1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','a66491f18ffa2a513564f560ac210ea09cb0a03ce445a07c3b8cc00c7470d56d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d23315d9c67a4e3d9618b4b72f89a0f951946372a9ac3924543e28b9f8c39e33',1984,'PA','Panama','communications',122,'(See reference map III)
Merchant marine: 2,598 ships(1,000 GRT or
over) totaling 27,419,642 GRT, 45,325,114
DWT; includes 22 passenger, 1,541 cargo, 84
container, 37 roll-on/roll-off cargo, 247
tanker, 44 liquefied gas, 435 bulk, 9 combina-
tion ore/oil, 162 specialized carrier, 1 cargo
training, and 8 beach landing cargo; all for-
eign owned and operated; 114 ships are
owned by China, 15 by Vietnam, 7 by Yugo-
the military ground forces—National Guard
(which previously combined all police/
military /internal security functions), Na-
tional Navy, Panamanian Air Force, traffic
police/highway patrol, Panama Canal De-
fense Force, National Department of
Investigations, and Department of Immigra-
tion
Ships: 6 patrol boats, 4 amphibious warfare
craft, 3 service/utility craft
Aircraft: 41 (12 transport, 6 utility, and 23
helicopters)
Supply: principally dependent on US but has
acquired infantry weapons and ammunition
from Western Europe and 2 motor gunboats
from the UK
slavia, and 9 by Cuba
Defense Forces
Personnel: (approx.) 12,500, including about
3,000 National Guard military ground forces;
9,000 police and highway patrol/traffic po-
lice; 200 National Navy; and 300
Panamanian Air Force; most personnel, in-
cluding police, air force, and navy, have
received basic training as infantry riflemen
Major ground units: infantry trained and
equipped units are 7 rifle companies, a public
order company, a Presidential Guard com-
pany, a cavalry squadron, an anti-
terrorist/SWAT element, and 6 platoon-size
combat units; remainder primarily police;
forces are deployed in 11 geographic admin-
istrative zones; bulk of forces concentrated in
Panama City area; remainder of forces as-
signed to detachments scattered throughout
the country; effective 30 September 1983 all
military /police/internal security forces
were consolidated—at least on paper—into a
new organization known as the Defense
Forces of the Republic of Panama; includes
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X11
66','e6fd33b8b550b561c150363c52d0823a3f5758078b2df980751d37e7c22a2578','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c277b23b20ddc32550a1f818b0ee7507557611caaf70084a6a07e00f6f5a57',1984,'PG','Papua New Guinea','communications',123,'(See reference map X)
Defense Forces
Personnel: Papua New Guinea Defense
Forces (PNGDF), consists of a land element
(3,415 personnel with 2 infantry battalions, 1
engineer battalion, 1 signal squadron), a mar-
itime element (414 personnel), and an air
element (82 personnel); the PNGDF has 5 pa-
trol craft, 2 amphibious craft, 7 C-47
transport and approximately 7 Nomad N-22
utility aircraft; additionally, there are 250
Australian personnel integrated into the
PNGDF
Ships: 5 coastal patrol-river /roadstead craft,
25X1
25X1
29X11
25X11 ©
2 amphibious warfare craft
''
1
b','72316619227597369d8a2080094b6ea6a1e91f08db615250db1b4bc77bde9a49','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6489c1d36754688b926d285c6cd0f013004d9c0d51c666cd16bce28bc7226395',1984,'PY','Paraguay','communications',124,'(See reference map IV)
Merchant marine: 17 ships (1,000 GRT or
over) totaling 22,404 GRT, 28,342 DWT; in-
cludes 14 cargo, 2 tanker, 1-specialized ;
carrier; domestic ships are operated mostly in
river traffic; most international seaborne
25X1
trade is carried by foreign-flag ships
Defense Forces
Personnel: 12,500 army, 2,540 navy (includ-
ing 55 in naval air and 346 in marines), 1,067
air force (150 pilots)
Major ground units: 3 corps (comprising 8
infantry divisions and 1] cavalry division), 1
presidential escort regiment, 1 combat sup-
port command, 1 logistics command, 1
military education institutes command
Ships: 2 patrol combatants, 13 patrol craft, 1
amphibious command ship, 2 utility landing
craft, 3 material support ships, 5 light cargo
ships, 1 small floating dry dock, 4 small har-
bor tugs, 1 floating workshop barge
Aircraft: 127 total; 112 air force (9 jet, 3 tur-
boprop, 89 prop, 11 helicopters), plus 28
nonflyable); 15 navy (9 prop, 6 helicopters; 2
fixed-wing and 2 helicopters are nonflyable)
Supply: dependent on foreign sources (pri-
marily US, Brazil, Argentina, South Africa,
Japan, and Belgium) for all materiel
67
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
25x11
25x14
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','9f4c0875f3d26903a555a39a8981184ab20f4e586c39e629cb3c8ed0f1b19c08','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61fcf027efdade5613c9dd4cb936a68e1c0864d729e0f263a2cbdaa4032b8a84',1984,'PE','Peru','communications',125,'(See reference map IV)
Economy . ws
Aid: economic commitments—US, including
Ex-Im (1970-82), $1,040 million; other West-
ern countries ODA and OOF (1970-81), $1:8
billion; Comm tnist countries (1970-82), $565:
million; military commitments—US (FY70-
82), $99-million; Communist ee eh $1.4
billion
Gorinnunieations :
Merchant marine: 58 ships a, 000 CRT or
over) totaling 662,191 GRT, 1,060,824 DWT;
includes 38 cargo, 4 tanker, 12 bulk, 1 com-
bination ore/oil, and 1 liquefied gas;
additionally, 5 naval tankers are sometimes |
used commercially
Defense Roices |
. Personnel: 75,000 army, 21,000 navy (in-
cluding 120 naval air officers, 2,500 marines),
40,000 air force (including 580 pilots), 41,700
Civil Guard (400-coast guard plus 400-civil-
ians),-4,500 Republican Guard (plus 65
civilians)
Major ground units::14 combat divisions (7
infantry; 1-airborne, 4:armored, 1 jungle,.1
cavalry), 1 division-size detachment, 7.
groups (2 infantry, 1 air defense artillery, ]
surface-to-air missile, 2 artillery, 1 engineer),
3 separate regiments (2 horse cavalry, 1 ar-
mored cavalry), 13 separate combat and
combat support battalions (5 motorized in-
fantry, 2 artillery, ! air defense artillery, 2
combat-engineer, 3 construction engineer)
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Ships: 2 light cruisers, 10 destroyers, 2 frig-
ates, 12 submarines, 6 patrol combatants, 8
patrol boats, 7 amphibious warfare ships and
craft, 12 auxiliaries, 15 service craft (not in-
cluding 12 coast guard patrol vessels)
Aircraft: 380 (157 jet), including 32(11 turbo-
prop, 8 prop, 13 helicopters) in naval air, 315.
(157 jet, 54 turboprop, 40 prop, 64 helicop-
ters) in air force, and 33 (2 prop, 31
helicopters) in army
Supply: produces somie small arms ammuni-
tion and hand grenades and is producing two
guided missile frigates with Jtalian assistance;
army materiel is supplied by Western Eu-
rope and the US; USSR has supplied tanks
and helicopters since 1973 and engineer
equipment, military trucks, artillery, and
guided missiles since 1975; aircraft and ships
from France and UK represent three-fourths
of the total value of non-US imports since °°
1953; ships also furnished by US, Nether-
lands, Italy, and FRG; fighter aircraft from
USSR plus license to produce spare parts for
SU-22
Military budget: for fiscal year ending 31
December 1982, $1.1 billion; about 19.1% of','211cf34c6750e584ea7005fd548359eabbd9e53c0c3c6352e3841e1fa8c4aa84','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('011f47654a3a8d25db6803df674a6ee2fefa9aa4475e0f5ffded4bbd193c66b8',1984,'PH','Philippines','communications',126,'- (See reference map IX)
Merchant marine: 292 ships (1,000 GRT or
over) totaling 2,436,495 GRT, 3,677,403
DWT; includes 10 passenger, 178 cargo, 37
tanker, 44 bulk, 2 combination ore/oil, 3 gas
carrier, 3 roll-on/roll-off, 14 specialized car-
rier, and 1 container
Defense Forces
Personnel: 70,000 army; 13,700 navy (in-
cluding 8,780 marines and 3,600 coast
guard); 16,800 air force; 42,000 constabulary
68
Major ground units: 5 infantry divisions, 2
engineer brigades, 4 artillery regiments, 1
light armor regiment, 1 scout ranger regi-
ment, 1 constabulary brigade, and 3 marine
brigades
Ships: 7 frigates, 13 patrol combatants, 94
coastal patrol-river/roadstead patrol, 29 am-
phibious, 16 support/auxiliaries, 8 yard and
service craft
Aircraft: approximately 311 (47 jet) in air
force and 6 (nonjet) in navy air group
25X11
25X11
: Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
ys
Missiles: 1 Redeye (12 launchers)','5c6a274d8f872dde2a0eef831db8fd59080f91bff7eb3bdaa03e8935100690f7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50ed357ac9e40ac58c95cede63243c7e172f50ca8cf1dae90d2d6588fdb2ac60',1984,'PL','Poland','communications',128,'(See reference map V)-.
Merchant marine: 305 ships (1,000 GRT or
over) totaling 3,172,000 GRT, 4,694,208
DWT; includes 7 passenger, 172 cargo, 4
roll-on/roll-off cargo, 9 tanker, 100 bulk, 4.
specialized carrier, 3.cargo training, and 4 -
container
Civil air: 49 major transport aircraft (1982)
Airfields: 162 total; 89 with permanent-
surface runways; 2 with runways 3,500 m or
over; 34 with runways 2,500-3,499 m, 93 with
runways 1,000-2,499 m; 33 with runways less
than 1,000 m; 4 heliports|
Telecommunications: adequate for govern-
ment needs but only limited service is - .
available to the public; international facilities
are adequate; modern radio and TV network
is used effectively to educate and entertain
the public; 31 AM and 29 FM broadcast sta-
tions, 8,500,000 receivers; 32 TV stations and
61 TV transmitters; 7,200,000 TV receivers;
3,000,000 telephones (86.1% automatic)
Defense Forces
Military manpower: males 15-49, 9,276,000;
7,355,000 fit for military service; 287,000
reach military age (19) annually
69
| Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
CIA-RDP08-00534R000100050001-7
25X11
Personnel: 234,000 (est.) ground forces; So2 5X 1
viet forces (NGF) in Poland as of 1 January
1978, 57,500 (43,500 ground; 14,000 air); iD 5X 4
addition, there are 9,000 Internal Defense
Forces (WOW), 25,000 Territorial Defense
Forces (OT); 30,000 engineer construction
units, which are nominally part of the ground
forces; 21,800 naval forces; 43,500 air forces; .
47,700 national air defense forces; 21,500
paramilitary forces; personnel in reserve (not —
on active duty)—-2;000,000(est.) ground”
forces, 52,000 naval forces, 12,500 air force
25X1
Major ground units: 15 divisions (8 mecha-
nized, 5 armored, 1 airborne, 1 sea landing), 8
brigades (4 SCUD tactical missile, 3 artillery,
1SA-4), 1] regiments (3 antitank, 1 artillery, 6
SA-6, and 1 SA-8)
Ships: 4 submarines, ] principal surface com-
batant, 1 patrol combatant,.23 amphibious
warfare ships, 23 mine warfare ships, 54 25X14
coastal patrol/river roadstead craft, 18 am-.
phibious warfare craft, 27 mine warfare _
craft, 3 underway replenishment ships, 7
fleet support ships, 11 other auxiliaries
Aircraft (in operational units): 1,162, includ-
ing 72 in naval air (36 attack, 22 reconnais- -
sance, 14 helicopters) and 1,090 in air and air
defense forces (822 air.defense fighters, 108 .
counter air fighters, 22] ground attack, 65
reconnaissance, 74 transports, 300 helicorD 5X1
ters—224 helicopters in ground force
aviation) 25X1
Missiles: 35 operational SA-2 SAM sites (210.
launchers); 14 operational SA-3 sites (52
four-rail and 4 unknown type launchers):''25X 1
regiments of the SA-6 tactical missile system
and 1 SA-8 regiment, and an SA-4 brigade are
deployed with the Polish ground forces; SA-9
and SA-7 tactical systems are also deployed
on a limited scale 25X1
Supply: produces infantry weapons, armored
personnel carriers, tanks, ammunition, elec-
tronic equipment including radar, trucks,
chemical and biological defensive materi95\\X 4
and small quantities of chemical warfare
agents; builds small combatants and naval
auxiliary ships for the Polish navy and coast
25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
Poland (continued) Portugal
guard and is a major supplier of amphibious
warfare ships and naval auxiliaries for USSR;
also produces helicopters, jet trainers, small
transport utility aircraft and surface-to-air
missiles; other equipment primarily from
USSR
Merchant marine: 76 ships (1,000 GRT or
over) totaling 1,204,534 GRT, 2,075,987
DWT; includes 2 passenger, 47 cargo, 2 con-
tainer, 16’tanker, 2 liquefied gas, 6 bulk, and
25X1 1 specialized carrier
Defense Forces
Personnel: (est.) 44,600 army, 12,500 navy
(including 2,500 marines), 9,000 air force
(400 pilots, 1,200 paratroops); 14,100 Na-
tional Republican Guard, 6,160 Fiscal
Guard, 14,600 Public Security Police
Major ground units: metropolitan army has
1 mixed infantry brigade, 24 regiments (11
infantry, 3 armored cavalry, 3 artillery, 1
coast artillery, 1 military police, 1 signal, 1
transport, 1 armored, 2 engineer, 1 com- .
mando) and 5 independent battalions (1
infantry, 1 quartermaster, ] medical, 1 signal
reconnaissance, | military administration),
Azores and Madeira Islands have total of 3
infantry regiments; major changes in orga-
nization are continuing; current plans call for
two types of forces—intervention and terri-
torial
Ships: 3 submarines, 17 frigates/corvettes, 13
minor amphibious, 5 auxiliaries, 18 patrol
craft, and ] service craft
telecom and electronics equipment, and in-
cendiary, smoke, and tear agent munitions;
also produces naval ships up to frigate size; -
other military equipment imported from
other NATO countries; navy ships, weapons, 4
and equipment from US, FRG, UK, Canada, 25X11
Italy, France, Brazil, Austria, South Africa, 5X1
Spain Lo Na
25X11
25X1
Aircraft: 320 (165 jet)
Supply: produces transport vehicles, wheeled
armored personnel carriers, small arms, mor-
tars, ammunition, aerial bombs, military
Secret 70
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
: CIA-RDP08-00534R000100050001-7
~
el
25X1
25X1
25X1
Lee
25X1
25X11
‘oa
|
Qatar eo oad
(See reference map Vi)
Merchant marine: 6 ships (1, 000 GRT or.
over) totaling 91,692 GRT, 163,122 DWT; in-
cludes 1 tanker, 1 specialized carrier, and 4
cargo
Defense Forces ;
Qatar Public Security Forces comprise a-
5,000-man army, a 2,500-man police force, a
300-man air force, and a 700-man sea arm,
equipment includes 40 armored cars, 30
tanks, 87 armored personnel carriers, 6 155-
mm howitzers, 18 Rapier SAM launchers, 3
guided missile patrol boats, 37 patrol
boats/craft, 1 utility landing craft, 1 auxiliary
craft, 3 Hunter jet fighters, 8 Alpha jets, 12
Reunion
(See reference map Vil)
Defense Forces
Reunion has no security forces; security for
the island is maintained by French forces;
about 2,968 military personnel are stationed
on the island, including a reinforced para-
chute regiment numbering 1,250, a navy of
174 personnel, and a 308-man air force; the
remainder of thé personnel belong to the
French Indian Ocean Naval Command,
ships homeported at French naval base at
Ports-des-Gatets include 3 patrol craft, 4 am-
phibious craft, 2 auxiliary craft; other French
ships are available in the Indian Ocean at Dji-
bouti; French Air Force unit operates 3
medium-range transports, and 2 helicopters;
the gendarmerie operates 5-9 helicopters; the
Frencti Navy operates a maritime patrol. air-
craft
helicopters, and 1 transport
Supply: mostly from UK and France
7),
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 CIA-RDP08-00534R000100050001-7','9e94e3cd9037c5dc3323df06807a0c9c1ee8180c0f0eeffd044ecc2054701051','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a56e02759c34c6253c45268a64a2b3c2b0ed4e477c58007b60d8bc94d1466e2',1984,'RO','Romania','communications',130,'(See reference map V)
Merchant. marine: 202 ships U. 000 GRT5 54
over) totaling 1, 894, 000 GRT, 2,941,500
DWT; includes 143 cargo, 9 tanker, 48 bulk,
1 cargo training, and 1 specialized carrier
Civil ite 8] major transport aircraft (1982
ba te
Airfields: 165 total; 30 with permanent-
surface runways; 3 with runways 3,500 rm or
over: 12 with runways 2,500-3,499 m; 29 with
runways 1,000-2,499 m, 121 with runways
léss than 1,000 m; 2 heliports
Telecommunications: systems dre used pri-
marily for government and military 25X1
purposes; only a few facilities are available to
public; wired-broadcast network offers
broad coverage; 15-AM and 5 FM stations;
3,250,000 receivers; 13 major and 20 relay:
TV stations, 3,200,000 receivers: 1,133,000
(est.) telephones (84.3% automatic)
Defense Forces
Personnel: 170,000 ground forces, 6,700 na-
val forces, 34,000 air and air defense forces,
35,000 paramilitary forces; personnel in re-
serve (not on active duty): 1,300,000 (est.)
ground forces, 30,000 naval forces, unknown
air force 25X1
Secret
i Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Romania (continued). - .
Major ground units: 10 divisions (8 motor-
ized infantry, 2 tank), 11 brigades (2 artillery,
1 attack brigade, 2 SCUD tactical missile, 3 -
mountain infantry, 3 antiaircraft artillery), 4
airborne regiments, 5 artillery regiments, 1
antiaircraft artillery regiment, 3 SA-6 regi-
ments, and 5 antitank regiments
ne 1 principal sitaee eeiibAbant 8 patrol .
combatants, 6 mine warfare ships, 89 coastal
patrol-river /roadstead craft, 32 mine war-
fare craft, 2 material support ships, 2 fleet
support ships, 5 other auxiliaries
Aircraft: (in operational units) 448 (212 air
defense fighters, 82 ground attack, 2] recon-
naissance, 20 transports, 113 helicopters)
Missiles: 18 operational SA-2 SAM sites (108,
launchers); 3 regiments of the SA-6 tactical
missile system are deployed with the Roma-
nian ground forces; the SA-7 is also deployed:.
the SA-3 may be in country.
Supply: produces rocket launchers, artillery,
infantry weapons, armored personnel carri-
ers, ammunition, medium trucks and jeeps,
smal] numbers of tanks, chemical warfare of-
fensive and defensive materiel, and several
types of coastal patrol-river/roadstead craft:
building naval ships of up to helicopter-
carrying destroyer size; limited quantity of
subsonic fighters, assembles aircraft and heli-
copters under license from the UK and
France; attempting to produce tanks and na-.
val ships of frigate size: dependent on imports:
from Communist countries, primarily the
USSR, for other military equipment
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Rwanda .
(See jelerence map Vil)','c3eed682aab161867f174696c7c53293c2493507c4dd9bad5047853fa0f472b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0343998cf6c14403e60d1c3e4e304c985357778957799ae0b7f499a222170cd4',1984,'SN','Senegal','communications',134,'Merchant marine: 6 ships (1,000 GRT and
over) totaling 14,728 GRT, 21,641 DWT; in-
cludes 3 cargo, 2 specialized carrier, and ]
bulk
Defense Forces
Personnel: 8,486 army, 700 navy, 160 air
force, 2,355 gendarmerie, 1,500-2,000
French forces; 27 French advisers
Major ground units: 6 infantry battalions, 1
training battalion, 1 armor battalion, 1 artil-
lery battalion, } parachute group (2
companies), 1 commando group (2 compa-
nies), 1 engineer battalion (3 combat
construction companies, 1 HQ/Training
Company), 1 supporting arms company; one
of the infantry battalions is serving with UN
Interim Forces in Lebanon
Ships: 1 patrol combatant, 2 patrol boats, 8
patrol craft, ] utility landing craft, 2 medium
landing craft, 1 training craft, and 1 tug
Aircraft: 22 (4 fighter trainers, 13 prop trans-
ports, 2 prop utility, 3 helicopters)
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
Supply: primarily dependent on France,
Netherlands, and Canada; beginning to di-
versify sources of supply
25X11
25x11
25X11','7ff0e2fe504061236d3e670f3a77d197564874e67b95061c9c32eff618dc884b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('688507e12c098229f9f462f399be5eb9059d9d6640529eebef3b080541ea8517',1984,'SC','Seychelles','communications',135,'(See reference map VII)
Merchant marine: | cargo ship (1,000 GRT
or over) totaling 2,388 GRT, 3,698 DWT
Defense Forces
Personnel: a 700-man army, 2,000-man mili-
tia, and 500-man police force capable of
assisting the army in maintaining internal
stability; 60-man navy; 12-man air force
Major Ground Units: 1 infantry battalion, 3
infantry companies, associated headquarters
and support units; equipment includes 6
BRDM-2 armored cars, 37-mm antiaircraft
guns, RPG 7 grenade launchers, 75-mm re-
coilless rifles; reports indicate the Seychelles
People’s Liberation Army (SPLA) has an
SA-7 GRAIL SAM system
Ships: 4 patrol craft, 1 landing craft
Aircraft: 2 Alouette helicopters, 2 utility
Supply: equipment has been supplied pri-
marily by the Soviet Union and Tanzania
25X1
25X11
75
CIA-RDP08-00534R000100050001-7
ween','e781aae8bbdf497ef67313fd541e3314296e157884eb4255e049c0bcbd6080da','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74adbe28b443ae722607cf1eb2203bb8f8455e5d700ad88b7c40e1f96fe71161',1984,'SG','Singapore','communications',138,'Merchant marine:.571 ships au 000 CRT o or
over) totaling 7,099,537 GRT, 11,944:43]
DWT; includes 3.passenger, 296 cargo, 68
container, 6 roll-on/roll-off cargo, 96 tanker,:
83 bulk, 4 combination ore/oil, 2 liquefied
gas, 12 specialized carrier; most: foreign
owned
a
Defense Rorces. .
External defense provided by. sos Five
Power Defense Arrangement (FPDA), which
replaced Anglo-Malayan Defense Agree- -
ment of 1957; FPDA, effective as of 1
November 1971
ve ?
‘ we
Personnel: 50,000 army, 3,500 navy, 6,000: -
air force, 7,500 police force, 120,000 army,
reserve, 30,000 People’s Defense Force, 450
naval reserve (People’s Defense Force/Sea);
in addition, the navy:can be augmented by
the.700-man marine ‘police with s some 80
small craft] is
“?
Maisteronad units: 1 infantry division com-
prising 3 infantry brigades, 9 infantry,
battalions,.1 artillery brigade of 6-~
battalion-size units, 1’armored brigade with 1
tank, 1 reconnaissance, and:2 mechanized °-
battalions, 1 commando battalion, 6 engineer
battalions, 3 signal battalioris, 2-reserve infan- ''
try divisions (1 at full strength, 1 building up
since 1979); reserves include] commando, 5
armor, 5 artillery, 5 engineer, 3 signals, and
18 infantry battalions-
re
Secret foo 76','27ebd4e51633ccb2df1b10d5b40be942f0fa4aad6a3adc7f2fe090fef0224825','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53eb7a59f142bf23ec217a0e4508be79b05c93b58545296af47bf337d34b72da',1984,'SB','Solomon Islands','communications',139,'(formerly British Solomon ideas
§ 25X1
25X1
25X1
: isée reference map X) :
— 25x1
NOTE: Independent as of 7 July 1978, this -
archipelagic nation includes southern Solo- 25X11
mon Islands, primarily Guadalcanal, 25X14
Malaita; San Cristobal, Santa Isabel, and “
Choiseul. Northern Solomon Islands consti-: :
tute-part of Papua New Guinea.
Defense Forces 25X1
Personnel: no military forces maintained; ©
however, the British maintain a well-trained
Police Force of about 300 for peacekeeping
and security purposes| | 25X14
| 25x11
Z2OoX%1
25X1
: : 4
a . - 25x11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
1','b5a4cda70238259f3ac468a3bfb2948ad86a685e68e2a67d5bc1ff3e0bf086be','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8748f5916c99d04814cb6fce1ce51ed15fa7af1efcebd67faba2756136a12b98',1984,'SO','Somalia','communications',140,'y
(See reference map
Merchant marine: 3 cargo ships (1,000 GRT
Supply: dependent on outside ‘sources;
ground materiel predominantly from the
USSR and since mid-1977-from several ''Euro-
pean and Middle Eastern countries; naval
ships from the USSR; aircraft from.the USSR;
Italy, Egypt, China, and UAE; SAM systems
and associated radar equipment from USSR
or over) totaling 11,300 GRT, 9,800 DWT
Defense Forces
Personnel: 36,000 army, about 2,000 navy,
2,000 air force, 3,500 air defense forces,
18,000 National Police
Major ground units: 4 corps headquarters,
11 divisions, 29 infantry brigades, 2 mecha-
nized infantry brigades, 4 armored brigades,
8 field artillery brigades, 5 commando bri-
gades, and 8 air defense brigades
Ships: 15 patrol craft, including 2 OSA II
guided missile patrol boats, 2 MOL torpedo
boats, 4 P-6 torpedo boats, 2 MOL patrol
boats, and 5 POLUCHAT; none of the craft
possess a full range of combat capabilities
Aircraft: 110, including 45 fighter, 8 fighter-
bombers, 3 bombers, 7 utility, 21 transports,
16 fighter trainers, and 10 helicopters
25X1
77
cret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
: se','66b6598925ef0616b20c7c4d5ad449ed8a5310e78c9784cc39e422d45c143921','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08c25e042b3de5aba4e82517556b827d8332037d2d337e0d98243f622da2176c',1984,'ZA','South Africa','communications',142,'Pretoria
| SOUTH Bro
AFRICA
(See reference map Vil)
25X1
Communications an
Merchant marine: 28 ships {1,000 GRT or
over) totaling 578,735 GRT, 753,887 DWT;
includes 1] cargo, 8 container, 2 tanker, 5
bulk, and 2 specialized carrier
Defense Forces : a Te eS ;
Personnel: 75,000 army, 5,000 navy, 11,300
air force (700 pilots); 4,000 Cape Corps; 400
Indian Corps; 1,200 Blacks; Citizen Force © -
(active reserve)—100,000 army, 11,000 navy,
20,000 air force; 90,000:Army Commandos
(home defense force); 8,500 Medical Services
25X11
Major ground units: 25 combat-type battal-
ions, plus 75 citizen force reserve battalions
and 250 Commando units
Independent homeland forces: : 25X1
Bophuthatswana, 600-man national guard;
Transkei, 1,000-man army; Venda, 550-man:
defense force; Ciskei, 400-man defense force;
rebel forces—6,000-8,000 Namibian South-
West Africa People’s Organization (SWAPO)
rebel elements largely in Angola arid Zambia;
1,500-2,000 African National Congress
(ANC) rebel elements largely in Angola, Mo-
zambique, and Tanzania
Ships: 3 submarines, | frigate, 8 missile pat?5X 4
boats, 33 patrol type, 7 mine warfare craft, 11
auxiliaries, 7 service craft 25X11
Aircraft: 905 (369 jet, 23 turboprop, 316 25X14
prop, 197 helicopters) 25xX1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
South Africa (continued)
Missiles: SSM Scorpion (modified version of
Israeli Gabriel); AGM, AS20, AS380; AAM,
R530, R550 (MATRA), V3 KUKRI—indige-
nously developed; ATGM, Entac and SS-11;
SAM, 24 Cactus launchers, 1 Crotale
launcher and 1 SA-7 (captured by SADF in
Angola)
Nuclear Weapons: may be developing a nu-
clear weapons capability
Supply: produces all of the small arms, mor-
tars, and ammunition it requires;
manufactures armored cars, armored per-
sonnel carriers, and guided missile patrol
combatants; most naval ships originally sup-
plied by UK; submarines from France:
guided missile patrol combatants, initially
supplied by Israel, now being produced do-
mestically under Israeli license; has produced
MB 326 (Impala) jet trainer and attack air-
craft under license; has assembled Mirage
F-] jet fighter under license; has developed
and is producing air-to-air missiles
Military budget: for year ending 31 March
1982, $3.1 billion; 16.1% of central govern-
ment budget
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Soviet Union
SOVIET UNION
(See reference map Vill)
NOTE: the US Government does not recog-
nize the incorporation of the Baltic States—
Estonia, Latvia, and Lithuania—into the So-
viet Union.
Merchant marine: 1,736 ships (1,000 GRT or
over) totaling 13,994,900 GRT, 19,289,800
DWT; includes 68 passenger, 1,163 cargo, 30
container, 53 roll-on/roll-off cargo, 280
tanker, 11 liquefied gas, 111 bulk, 10 com-
bination ore/oil, and 10 specialized carriers;
664 merchant ships based in Black Sea, 398 in
Baltic Sea, 427 in Soviet Far East, and 247 in
Barents/ White Sea
Civil air: 1,380 major transport aircraft
(1982
Airfields: 4,200 total; 910 with permanent:
surface runways; 50 with runways over
3,500 m, 389-with runways 2,500-3,499 m,
1,025 with runways 1,000-2,499 m, 2,736
with runways less than -1,000 m; 78 heliports
Telecommunications: extensive and rela-
tively modern domestic and international
systems maintained primarily for official
use; 19.3 million telephones; an estimated
37,000 telephone exchanges; 83,100 main
and branch telegraph offices; about 135 main
AM broadcast network stations; 280 FM
broadcast and 40,000 wired-broadcast distri-
bution stations; 59.8 million radio and 56
million wired broadcast receivers; 1,620 TV
broadcast and rebroadcast stations: 60 mil-
lion TV receivers
78
Defense Forces
Personnel: (estimated as of January 1983)
2,841,000 ground forces; 448,900 naval
forces (excluding Maritime Border Guard): :
.580,000 air forces; 322,000 strategic rocket
forces; 494,000 strategic air defense forces;
550,000 paramilitary forces, including bor-
der guards; these strengths, redistributed to
correspond with US force programs rather |
than with Soviet military structure, are set
forth as follows:
Total Estimated Military and
Paramilitary Strength
Command.and General Support 1,568,000
General Purpose Ground Forces 1,812,000
General Purpose Naval Forces 323,900
General Purpose Air Forces 352,000
Strategic Attack Forces
(including MRBM/IRBMs) 288,000
Strategic Defense Forces 886,000
Frontier Troops 192,000
Internal Troops 264,000
Total 5,185,900
Total Estimated Personnel Released into
Reserve System for last 5 Years
Command and General Support 2,879,000
General Purpose Ground Forces 3,298,000
General Purpose Naval Forces
(including naval infantry) 449,000
General Purpose Air Forces 504,000
Strategic Attack Forces 485,000
Strategic Defense Forces 768,000
Frontier Troops 270,000
Internal Troops 466,000
9,119,000
Total .
Major ground units: general purpose ground
forces—27 armies, 10 corps, 194 divisions, 2
(new type) corps structures, plus 15 artillery
divisions, 200 brigades, 280 regiments, and
many smaller combat and combat support
units
Ships: submarines—65 nuclear-powered bal-
listic missile, 15 ballistic missile,. 49
nuclear-powered cruise missile attack, 14
cruise missile attack, 66 nuclear-powered at-
tack, 138 attack, 10 auxiliary, 4 communica-
tions, 12 unknown, | radar picket, 4 training;
surface ships—8 guided missile VSTOL air-
craft carriers, 2 guided missile aviation _
é
25X11
>
25X11 |
25X11
25xX1 |
25X1 |
25X11 §
25X11
25X11
25X11
¥
nN
ney Ne Baoan a ee a A Ae ee
25X1
25X1
mn ,
ae ee
gg I I I I I GS I I a a NN
®
cruisers, 2 nuclear-powered guided missile
cruisers, 26 guided missile cruisers, 9 light
cruisers, 36 guided missile destroyers, 27 de-
stroyers, 32 guided missile frigates, 34 -
frigates; 113 corvettes, 168 patrol combat-
ants, 82 amphibious warfare ships, 138 mine
warfare ships, 414 coastal patrol-river/ ;
roadstead craft, 97 amphibious warfare craft,
264 mine warfare craft, 83 underway replen-
ishment ships, 71 material support ships, 145
fleet support ships, 481 other auxiliaries
Aircraft: 15,484 operational aircraft; by.
force, strength data follows: Strategic.
Bomber Force 912 (253 long-range bombers,
457 intermediate- -range bombers, 46 tankers,
33 reconnaissance, 118 ECM/SIGINT); Avi-
ation of Air Defense,.1,215 fighters (9 > -
airborne warning and control): Tactical Avia-
tion, 6,150 combat aircraft (2,670 ground ~
attack, 2,990 fighters [including 1,196 ex-
APVO], 490 reconnaissance/ECM/SIGINT);
Army Aviation, 4,340 helicopters (1,700 at-
tack, 1,171 transport, 164 ECM, 1,305
support, 607 administrative/liaison helicop-
ters); Naval Aviation, 1,323 bombers,
reconnaissance, fighter, and ASW aircraft
(146 long-range, 454 intermediate-range
bomber/tanker/reconnaissance, 134
fighters /fighter-bombers, 462 ASW, includ-
ing 258 helicopters, 26 helicopters, 157
miscellaneous training type aircraft); support
aircraft strength of all services, 2,474 trans-
ports and helicopters (1,659 transports (291
long-range, 652 medium-range, and 716°
short-range], 815 admin/liaison helicopters)
Defensive missiles: about 9 SA-2 battalions,
36 SA-3 battalions, 153 SA-4 battalions, _
2SA-5 complexes, 37 SA-6B/SA-11] regi-
ments, and 30 SA-8 regiments are deployed
with Soviet Theater General Purpose Forcés
and Soviet forces in GDR, Czechoslovakia,
Hungary, Poland, and Mongolia; approxi-
mately 336 SA- 9/SA-13 fire units and about
24.400 SA-7/14 missiles are available in ma-
neuver regiments; some of these SAM
systems could augment the national air de- .
fense forces in times of crisis; the defensive
missile force for national defense includes
1,032 operationally deployed surface-to-air
missile sites and complexes (13,790 launch
rails); 54 SA-1 sites (3,033 launch rails) de-
ployed only in defense of Moscow; 48] SA-2
sites (2,886 launch rails) provide point de-
fense of important strategic targets and
barrier defense of the country; deployed pri-
marily in peripheral areas and in already
SAM- defended areas to provide low-altitude
coverage are 325 SA-3 sites (352 dual-rail and
948 four-rail platforms) with 4,496 launch
rails; 131 SA-5 complexes (2,040 launch rails)
and 41 SA-10 sites(1,344 launchers) provide a
barrier and vital area defense of targets
throughout the Soviet Union; deployed
around the city of Moscow are 4 ABM-1b
complexes (32 launchers); there are. -also 13
coastal defense cruise missile sites located
throughout the 4 fleet areas that utilize the
SSC-1b (SEPAL) cruise missile
Offensive missiles: Sutatesio— abet 1,398
ICBM launchers and about 615 MB/IRBMs
Nuclear weapons: satisfies major require-
ments of Soviet forces
Supply: fully supplies own needs and pro-,
duces large quantities of all types of materiel
for export; Warsaw Pact countries provide
the bulk of amphibious and auxiliary ship re-
placements as well as trainers and other light
aircraft; some trucks and light armored vehi-
cles have also been obtained from Eastern
Europe as an economic measure
Military budget (announced): for fiscal year
ending 31 December 1981, only the figure
17.05 billion rubles was released; this figure is
manipulated for political purposes and cov-
ers only a small portion of total military
expenditures, which are as much as six times
greater; the estimated dollar costs of military
activities in 1982, excluding pensions, are
$236 billion (in 1982 dollars)
79
Declassified in Part - Sanitized Copy Approved for Rulsade 2012/09/20 : cue RDP08-00534R000100050001-7
Secret','b94242ef6d2b8ee80ea96d9aa188bbf7659e00c408a88f4ae4e84dd23d626e2f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c629d813b7aab470ec8d3b713c530d3caefb42fb75453bc02604c9c9186cbef',1984,'ES','Spain','communications',143,'5X1
(See reference map V and vil)
oe 25X1
Merchant marine: 553 ships (1,000 GRT or
over) totaling 7,640,263 GRT, 13,567,739
DWT; includes 18 passenger, 271 cargo, 395x1 |
container, 20 roll-on/roll-off cargo, 95
tanker, 13 liquefied gas, 73 bulk, 4 combina-
tion ore/oil, and 24 specialized carrier
Defense Forces 25X1 25X11
Personnel: 294,000 army, 47,300 navy (not
including 11,925 marines), 42,000 air force
(1,170 pilots), 65,000 civil guard, 45,000
armed police
25X11
Major ground units: 5 combat divisions (1
mechanized infantry, 1 motorized infantry 5X1
mountain, 1 armored), 16 brigades (1 para-
chute infantry, 1 air transport, 1 high
mountain, J cavalry, 10 infantry, 2 artillery),
16 combat regiments (14 infantry, 2 light ce:
alry), 23 combat support regiments (12 25X1
artillery, ] artillery observation, 6 engineer, 4 -
air defense artillery)
Ships: 1 VSTOL aircraft carrier, 11 destroy-
ers, 8 submarines, 6 patrol ships, 5 guidedd5x 4
missile frigates, 15 frigates/corvettes, 96 pa-
trol ships and craft, 12 mine warfare 25X1
ships/craft, 6 amphibious ships and 7 cratt,
1Qauxiliarie| 25X1
Aircraft: 1,150 (344 jet)—878 (334 jet) in air
force, 68 (10 jet) in naval air, and 204 in army
25X11
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20
Secret.
Spain (continued) .
Missiles: 1 NIKE Hercules battalion (9
launchers) and 1 I-HAWK battalion (24
launchers) under army control
Supply: produces naval ships to VSTOL air-
craft carrier size, small arms, mortars, some
-artillery, ammunition, armored and trans-
port vehicles; French-designed tanks;
military telecom and electronic equipment;
‘produces C-101 AVIO JET trainer, C-212
utility, and assembles GDR BO-105 helicop-
ter; all other equipment primarily from US
and secondarily from West European coun-
tries
25X1
Secret','ca0f016fd2edae0da1c41d574fdef2c5b259aa9b165cbd59aae5e1939abcf822','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5016c750bdce175dfca755ac8e93d9eb47d59694dd7cda4bdee02498af9df346',1984,'LK','Sri Lanka','communications',144,'(See reference map Vili)
Merchant marine: 13 ships (1,000 GRT or
over) totaling 96,036 GRT, 141,400 DWT; in-
cludes 11 cargo, and 2 tanker
Defense Forces
Personnel: 13,000 army, 2,824 navy, 3,386
air force, 15,000 police, 12,000-man Volun-
teer Force (approximately one-third of Sri
Lanka’s Volunteer Force is-on active duty at
all times
Major ground units: 5 infantry regiments
and supporting units; 1 commando squadron,
1 artillery regiment (4 batteries), 1 armored
reconnaissance regiment, 1 engineer regi-
ment, 1 signal regiment
Ships: 8 fast patrol craft, 8 patrol boats,.5 har-
bor patrol boats, 10 patrol craft, 1 lighthouse
support vessel
: CIA-RDP08-00534R000100050001-7
Supply: has a limited shipbuilding capability;
currently producing patrol craft; dependent
on imports for all categories of military mate-
-riel; ground force equipment from UK, -
China, USSR, Yugoslavia, Australia, and In-
dia; naval ships have been acquired mainly
from the UK but with Italy, Israel, and Singa-
pore each supplying some craft; 5 Shanghai
II-class patrol boats provided by China; 1
coastal patrol boat provided by USSR; jet air-
25X11
¢
>
X1
craft and helicopters have been purchased 25X14
from USSR
Aircraft: 35 (26 prop, 9 helicopters)
80
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1''
2 Ra eh Sig SS Fae a Oe nk, aS. ot,
wAL A AL
UA
ee a a
eT Te
an ee an oe a a a','9c3abf783a2fddd9864722697f9882bed013326bbcf228d5b92a9715f2a22d73','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de3684c8950995943a0acbbba02a7d0373e12a398688b854e88bbb3106cf6dfd',1984,'SD','Sudan','communications',146,'Khartoum,
(See reference map
Merchant marine: 10 ships (1,000 GRT or
over) totaling 89,916 GRT, 121,978 DWT; in-
Ships: 9 patrol boats (4 operational), 2 utility
landing craft, 4 river/roadstead patrol boats,
4 auxiliaries, 15 percent operational
Aircraft: 100 (66 jet, 10 prop transport, and
39 helicopters), 30 percent operational
Missiles: 2 SA-2 brigades, 3 SA-7 platoons
Supply: produces some small arms ammuni-
tion; all other materiel imported; formerly
the USSR and Czechoslovakia were primary
sources, but in 1972 China began supplying a
variety of materiel, including tanks and
fighter aircraft; materiel also received from
FRG, Canada, France, UK, Egypt, Algeria,
the Netherlands, Yugoslavia, US, and Saudi
Arabia
Military budget: for fiscal- year ending 30
June 1982, $310 million; 9% of central gov-
ernment budget
cludes 8 cargo and 2 roll-on/roll-off cargo
Defense Forces
Personnel: 51,000 army, 1,500 navy, 3,000
air force (100 pilots), 3,000 air defense’
Major ground units: 9 infantry brigades, 37
infantry battalions, 1 armored corps (1 ar-
mored division, 2 armored brigades, 4
independent armored battalions), 1 artillery
corps, 1 airborne brigade, 1 engineer corps, 1
border guard brigade, 1 special protective
troop (battalion-size), plus support troops
25X1
— 25xX1 |
25X1.
81
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret
25X11
25x11
25X1','55ac2aef9c1d3aa168e66475e51e7dae8228cd07cc67d7a537f1556db4e81fa8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18772254b5976f19b3dc47799159d14e2550a353b7ec7bb81606b8ec53e9646b',1984,'SR','Suriname','communications',149,'(See reference map IV)
25X1
Communications 25X1
Merchant marine: 4 ships (1,000 GRT or
over) totaling 9,210 GRT, 12,977 DWT; in-
cludes 3 cargo and 1 container
25X1
Defense Forces
Personnel: 1,525 Suriname National Army
(1,275 army, 100 military police, 100 navy,
and 50 air force); 760 civil police (constabu-
lary) 25X11
Major ground units: 1 independent infantry
battalion (headquarters company, 4 infantry
companies, ] commando company, logistics
elements, and a military hospital)
Ships: 3 river patrol craft, 3 coastal patrol
boats, 3 high seas patrol boats
Aircraft: 4 turboprop, 1 prop
Military Budget: for fiscal year ending 25X1
30 June 1982, $29 million; 5.7% of central
government budget
ae 25X41 25X14
25X14
25X14
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret
Swaziland
(See reference map VII)
Defense Forces ,
Personnel: 2,700 army, only 2,000 physically
fit; 900 police (including 100-man police mo-
bile unit) oo
Major ground units: 3 battalions of about
500 men, each
Aircraft: 2 light transports (leased from Is-
rael) 7
Supply: mostly from UK and South Africa;
Military budget: for fiscal year ending 31
March 1982, $12.2 million; 4.8% of central
government budget
Secret','58ecbe787a5fc02e30290c9c1b84c4804c05d4b6cfa162adbb10edfd70ececee','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('135b0c32e4f6fac384dd78fc41857845fc5bf8e4d920f6efd1575c72a8ee881b',1984,'SE','Sweden','communications',150,'(See reference map V)
Merchant marine: 249 ships (1,000 GRT or
over) totaling 3,609,917 GRT, 5,641,761]
DWT; includes 21 passenger, 46 cargo, 13
container; 58 roll-on/roll-off cargo, 44:
tanker, 1 liquefied gas, 25 bulk, 3 combina-
Missiles: 1 HAWK/I-HAWK (18 launchers),
RBS-70 (252 launchers)
Supply: can produce vehicles, tanks, aircraft;
currently producing specialized vehicles, in-
fantry weapons, artillery, ammunition,
chemical and biological warfare defensive
materiel, RBS-70 surface-to-air and antiship
missiles; is developing an antiship missile and
an antitank missile; imports considerable
quantities from NATO countries; most naval
ships produced domestically, including sub-
marines
2K:
25x11
tion ore/oil, and 39 specialized carrier
Defense Forces
Personnel: 45,700 army (10,000 regulars on
staff and in training cadre, remaining troops
are conscripts for training), 300,000 local de-
fense reserves, 100,000 home guard reserves,
11,285 navy (including 4,400 coast artillery
and 214 in naval helicopter service), 15,100
air force (including 750 pilots and 4,470 civil-
ians)
Major ground units: the Swedish Army has
no standing tactical units; the mobilization
field army (300,000 army reservists) is orga-
nized into 20 infantry, 4 Norrland (arctic
trained), 4 armored brigades, and 150 inde-
pendent battalions; planning, supply, and
training are performed in-48 peacetime
training regiments (16 infantry, 6 armored, 7
field artillery, 6 air defense, 3 cavalry, 3 sig-
nal, 3 engineer, 4 service)
Ships: 2 destroyers, 12 submarines, 47 patrol
boats, 12 minelayers, 28 minesweepers, 80
miscellaneous amphibious, auxiliary, and
service craf t
Aircraft: 796 (550 jet); 687 (550 jet) in air
force, 33 helicopters in navy, 76 aircraft in
army
82
25X1 ©
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
OT eg ay Nae mene
. hana
Oe','fa47cc7cd44a6615299cc82e63b0ff55ae4d94192da4c9a96aac02848795b24a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a54d1e53cdb27b932f52d159f0be3eeab91c6cbf503ac4e58b4821b0c467cc5',1984,'CH','Switzerland','communications',151,'(See reference.map V)
Goriinanieations =
Merchant marine: 32 re a, 000 CRT or
over):totaling- 311,201 GRT, 429,651 DWT;
includes 17. cargo, 9 bulk; 1 roll-on/roll-off
cargo, and 5 specialized carrier;-fleet is regis-
tered in Basel, operated mainly out of Genoa,
Hamburg, and Rotterdam
Defense Forces
Personnel: 19,700 army (includes cadre of
1,400 permanent personnel; remainder are
‘recruits undergoing training), 3,500 air force
(about 150 pilots and 30 trainees), about 600
Syria
(See reference map VI)
Merchant marine: 11 ships (1,000 GRT or
over) totaling 28,894 GRT, 39,052 DWT; in-
cludes 9 cargo, 1 bulk, and 1 specialized ~
carrier :
Defense Forces
Personnel: army 300,000, navy 2,500, air
force 40,000 with air defense having an addi-
tional 60,000; police and security force
10,000
Major ground units: 5 armored divisions, 3
mechanized infantry divisions; separate units
include 2 infantry brigades, 31 reserve infan-
try regiments, I border guard brigade; 2
artillery brigades; 3 SSM brigades; 30 com-’
mando and 1 reconnaissance battalions; 16
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA- RDPO8- 00534R000100050001- i
Secret
Missiles: 37 SA-2 battalions, 36 SA-3 battal-
ions, 2:SA-5 battalions, 33 SA-6.battalions;. :
200 SA-7 platoons, 1 SA-8 brigade, 2-SA-9 ~
battalions 25X11
Sapaly: capable of siaducihe fared quanti-
ties of small arms ammunition; “otherwise |
dependent on outside sources, principally _ -
USSR, as well as Bulgaria, Czechoslovakia, -
GDR, Hungary, and Poland; some equip-. -
ment from West European countries,
including France, ERG: and UK
Military budget: for Bice! year oie 31
December 1982, $4.3 billion; 55% of central
government budget
air defense missile. brigades
‘Ships: 2 frigates, 19 missile attack boats, 13
patrol boats, 4 minesweepers, | torpedo re-
triever
Aircraft: 988 (799 jet, 10 turboprop, 40 prop,
223 helicopters)
83
25X11
LOA!
af 25x1
. 25X1
25X1
wat
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized d Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret
Tanzania
TANZANIA
Dar es Sataam-
(See reference map Vil) ©','12823802c04e1ad92bef43aac3d946c6cbdd7b03f53341350f7886095d93e981','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3dd28efb9c0f4f085d1aeb1c36e5d98913c4872c7cabdf6c6d5cbaae1319003',1984,'TH','Thailand','communications',154,'Merchant marine: 75 ships (1,000 GRT or
over) totaling 337,742 GRT, 520,52] DWT;
includes 50 cargo, 21 tanker, 2 container, “2
bulk, and 1 specialized carrie
Defense Forces
Personnel: 163,000 army; 36,200 navy (in-
cluding 20,000 marines); 43,100 air force:
15,000 border patrol police (includes 1,300
Police Aerial Reinforcement Unit); 3,500
Special Action Forces; 500 Police Aviation
Division; 1,700 Thai Marine Police; 37,000
Volunteer Defense Corps
Major ground units: 8 infantry divisions (one
is a cavalry division that operates as infantry)
1 armor division (more akin to a mechanized
infantry division); 2 special forces divisions;
and a marine corps of 2 infantry, 1 artillery,
and | security regiments
Ships: 6 principal combatants, 1 patrol com-
batant, 100 coastal-river /roadstead, 9
amphibious warfare ships, 44 amphibious
warfare craft, 2 mine warfare ships, 9 mine
warfare craft, 2 underway replenishment
ships, 6 auxiliaries, and 9 yard and service
craft
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Aircraft: 666 operational; 377 air force (57
combat, 10 reconnaissance, 47 transports, 77
trainers, 38 utility aircraft, and 46 helicop-
ters); 247 army (102 reconnaissance, 23
trainers, 6 transports, and 116 helicopters); 53
navy (10 antisubmarine warfare, 4 search
and rescue, 8 transports, 12 helicopters, 19
utility)
Supply: limited local production of small
arms ammunition, rifles, small naval craft,
and personal equipment; most other equip-
ment from US; ground force equipment from
Austria, Sweden, Netherlands, Singapore,
UK, ROK, FRG, and Canada; | frigate pur-
chased from UK; 3 missile attack boats from
Singapore, 3 patrol boats from Italy and 3
more on order; 154 tracked reconnaissance
vehicles from UK; will begin licensed assem-
bly and then production of FRG fantrainer
by 1984','d1ae11473d5cb7369e50b52fb6ee8fb922ef328570af6b3cc4af5106382c7302','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a502c9d8a112963eb7b12939e062c1ba1a82a12efea58195bf04e190aab48779',1984,'TG','Togo','communications',155,'(See reference map VII)
Merchant Marine: 8 cargo ships (1,000 GRT
or over) totaling 25,008 GRT, 36,120 DWT
25X1
Defense Forces
Personnel: 3,440 army, 62 air force, 48 navy,
700 gendarmerie, 800 presidential guard, 82
French military advisers
Major ground units: 1 presidential guard
regiment, 1 paracommando regiment, | serv-
ice and support regiment, 2 infantry
regiments
Ships: 2 patrol boats
Aircraft: 27 (7 transport, 2 utility, 3 helicop-
ters, 15 jet trainers)
Supply: most military materiel obtained
from France, Canada, and Brazil
85
Secret','b13c17e69971364d45c1505f0decb947e82b7c3a3f1dd77a35bc732fcc732f50','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c208f2bdba95de599f53de34f23aabf3d5dfc4b83d1d06b814ec52ad07eb3357',1984,'TO','Tonga','communications',157,'(See reference map X)
Merchant marine: 6 ships (1,000 GRT or
over) totaling 13,408 GRT, 19,360 DWT; in-
cludes 3 cargo, 1 liquefied gas, 1
roll-on/roll-off, and 1 bulk cargo
25x1
Defense Forces
Personnel: the Tongan Defense Services 25X11
comprise approximately 310 men; over the
next 3 years the Tongan Defense Services will
be reoriented from a primarily land-based
force to a predominantly maritime force) _|
25X1
Major ground units: 1 infantry company; 1
territorial infantry company; | police unit
Ships: 2 coastal patrol manned by 90 naval
personnel 25X1
25X1
25X11
25X11
25X11
25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret','d071b63feadb791aa75b8d7dd2a7acc4d19133db882c168c84ac9be9ef2170bb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89d54d6343765029cf584830e2377a428c37a74918fb740cbcfebbcc95862c25',1984,'TT','Trinidad and Tobago','communications',158,'(See reference map Wh)
Defense Forces
Personnel: 2,017
Major ground units: I regiment (consisting
of 1 infantry battalion, } service support bat-
talion, and 1 reserve company)
Ships: 2 fast patrol craft, 4 patrol craft, 8 pa-
trol boats, 1 small harbor tug
Aircraft: 1 light observation, 3 helicopters
(under Ministry of National Security)
Supply: mostly UK but 2 fast patrol craft
fromSweden[
Military budget: for fiscal year ending 3]
December 1982, $149 million; about 5% of
the central governinent budget
Secret','2a75cb040bf068d4114a7d2a37d86b7d41a4e449e487373473e13b110f2a9add','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36075413c42c06c40591dd9d23e29c3b371e6eeb139e07941cf18a1bed07188c',1984,'TN','Tunisia','communications',159,'(See reference map Vil)
Merchant marine: 21 ships (1,000 GRT or
over) totaling 130,205 GRT, 168,685 DWT;
includes 7 cargo, 2 tanker, 4 bulk, 5 special-
ized carrier, 2 roll-on/roll-off cargo, and 1
passenger
Defense Forces
Personnel: 30,000 army, 4,500 navy, 3,500
air force (180 pilots), 3,000 paramilitary
Major ground units: 4 brigades (2 infantry, 1.
paracommando, | Sahara border) and 10 in-
dependent regiments (1 signal, 2 air defense
artillery, 1 armored reconnaissance, } anti-
tank, 1 artillery , 1 engineer, | transportation,
l military police, 1 maintenance
Ships: 1 frigate, 3 missile attack boats, 16 pa-
trol boats, 2 coastal minesweepers, 2 auxiliary
Aircraft: 120 (25 jet, 50 prop, 45 helicopters)
86
25X1
25X11
2
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
ae ee oe ee ee
a ae
25X11
(25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Turkey
(See reference map VI)
Merchant marine: 197 ships (1,000 GRT or
over) totaling 1,720,541 GRT, 2,816,350
DWT; includes 12 passenger, 117 cargo, 1
liquefied gas, 25 tanker, 28 bulk, 7 special-
ized carrier, 5 roll-on/roll-off cargo, and 2
combination ore/oil
Defense Forces
Personnel: 536,900 army, 50,200 navy (in-
cluding 4,000 naval infantry), 60,000 air
force (970 pilots), 126,000 gendarmerie
Major ground units: Ground Forces Com-
mand (GFC)—4 armies, 10 corps with corps
troops, 14 infantry divisions, 2 mechanized
divisions, 6 separate armored brigades, 4
‘mechanized infantry brigades, 11 infantry
brigades, 1 airborne brigade, 1 commando
brigade, 3 mobile gendarmerie brigades, 3
regiments (2 infantry, 1 armored), 34 battal-
ions (28 artillery, 11 border); each field army
has | aviation regiment assigned and each
corps has 1 aviation battalion
87
Secret','f99c7bf7491a6683750fc01818cfb0243d7be6e5fe8fc4bddac04cc9bf8ef926','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1db3b88272ffa01e4e979f46ee00073d404c750c95c624582bd871a9e94367',1984,'TV','Tuvalu','communications',161,'(formerly Ellice Islands)
(See reference map X)
NOTE: On 1 October 1975, by Constitutional
Order, the Ellice-Islands were formally sepa-
rated from the British colony-of Gilbert and
Ellice Islands, thus forming the colony of
Tuvalu. The remaining islands in the former
Gilbert and. Ellice Islands Colony are now? 5X1
named Kiribati. Tuvalu includes the islan25X1
of Nanumanga, Nanumea, Nui, Niutao, 25X11
Vaitupu, and the four islands of the Tuvalu
group formerly claimed by the United States:
Funafuti, Nukufetau, Nukulailai
(Nukulaelae), and Nurakita (Niulakita).
Defense Forces 25X1
No military forces maintained; a small police
post is located at Funafuti 25X11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
i
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
1
have been formed
'' Aircraft: no operational combat aircraft
-North Korea
Secret','33af4495ea0c6f7f9ad1c3ff6497bd0c2b1d58ef6ee0e22406ccd427a88ae216','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93136d2c2c01a99be42048df55dc6002d9ff5d40275ccc83ccb4fc61b134167a',1984,'UG','Uganda','communications',162,'(See reference map VII)
Merchant marine: 1 cargo ship (1, 000 GRT
or over) totaling 5,500 GRT, 9,100 DWT
Defense Forces
NOTE: As a result of the defeat af the Idi
Amin regime, the Ugandan defense forces
have been reorganized; most military equip-
ment was damaged, destroyed, stolen, or
'' captured; the forces have been totally recon-
- stituted
Personnel: 14,000 army
Major ground units: 4 infantry brigades
: Supply: dependent on external sources—UK,
USSR, Czechoslovakia, Egypt, Canada,.and
Military budget: for fiscal year ending 30
-June 1982, $114.3 million; 25.7% of central
government budget
Secret','d4b8863cda608b6686d1faa5b8419385080b1e71477ce35109c35ba2a86d70b5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ecfc4fc5b7e9b602a53ada0c7f6370f1ff188a5dcbc13839c849dafd7729bf4',1984,'AE','United Arab Emirates','communications',164,'(See reference map VI)
Merchant marine: 21 ships (1,000 GRT or
over) totaling 144,794 GRT, 233,926 DWT;
includes 17 cargo, 2 tanker, 1 roll-on/roll-off,
and J specialized carrier
Defense Forces
Personnel: 40,100 army, 2,500 air force,
1,500 navy, and 9,800 paramilitary
Major ground units: 2 infantry brigades, 1
mechanized infantry brigade, | field artil-
lery brigade, 1 air defense artillery brigade, 1
armored brigade, 1 royal guard brigade
Ships: 6 missile attack boats, 27 patrol
boats/craft, 17 harbor patrol boats
88
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
25X1
25X1
ic
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7','62d709522b8ec2e237c149bfe85cd3a0c75e55012f02a8d97c5c70f36184903c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0290d5d21d84131a81b853268741ef2ca6d3ab18c373b697ab786981fddff0d4',1984,'GB','United Kingdom','communications',166,'ee reference map V)
Merchant marine: 1,184 ships(1,000 GRT or
over) totaling 25,312,602 GRT, 40,611,003
DWT, includes 47 passenger, 314 cargo, 97
container, 70 roll-on/roll-off cargo, 249
tanker, 41 liquefied gas, 269 bulk, 38 com-
bination ore/oil, and 67 specialized carrier
Defense Forces
Personnel: about 159,700 army (plus 9,700
colonials, including 1,493 locally entered
personnel—Maltese, Goans, and Hong Kong
and Singapore Chinese); 71,300 navy (includ-
ing 9,530 naval air and 7,700 marines),
90,500 air force (3,860 pilots) oo]
Major ground units: army is organized into 1
corps with 8 armored, 1 infantry, and 1 artil-
lery divisions; 10 infantry brigades, 1
airborne infantry brigrade; 7 nonbrigaded
infantry battalions and 8 nonbrigaded artil-
. lery regiments in the UK; 5 overseas infantry
battalions and 1 Gurkha field force; army
aviation is organized into an Army Air Corps,
& 1 regiment, 14 squadrons, and 4 separate
flights
Ships: 3 ASW carriers, 14 destroyers, 46 frig-
ates, 4 nuclear-powered ballistic missile
submarines, 11 nuclear-powered attack sub-
marines, 15 submarines, 21 patrol-type ships,
36 mine warfare ships, 9 amphibious warfare
ships, 47 auxiliaries
Secret
Upper Volta
Aircraft: 2,514 (1,386 jet), including 353 (323
helicopters) in army aviation, 331 (61 jet) in
naval air, 1,830 (1,325 jet) in air force
5X1
Missiles: Bloodhound II SAM, Rapier SAM,
Lance S-5 missile; also collaborating with
FRG for ASRAAM air-to-air missile
5X1
Supply: capable of producing all types of
equipment, but some aircraft supplies, as
well as Polaris missiles, come from US; all
types of naval ships constructed, including
nuclear-powered ballistic missile subma-
rines; exports destroyers, frigates,
submarines, patrol craft, missiles and air-
craft; produces surface-to-air, air-to-air,
antiship, and antitank missile
(See reference map vi)
25X1
Defense Forces
Personnel: 5,200 army, 100 air force, goc2 oX1
gendarmerie, 1,175 republican guard, 270
republican security company, 455 police, 18
French advisers 25X1
Major ground units: 3 infantry regiment>
(total of 6 infantry battalions and 1 com- 29X11
mando battalion); a coup in August 1983
brought in a regime with plans to increase the
size of the army by at least 2 regiments
Aircraft: 7 prop (8 transport, 2 utility), 2 heli-
copters 2 5X1
M ilitary budget: for fiscal year ending 3120X1
December 1980, $27.9 million; 20% of cen-
tral government budget
25X11
25X1
25X1
25X1
25X11
89 Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret','4266c3bd1faf8c89c6957a6c010cfefa222f1a9e357110d103bfd9aa12f3922c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d506c7e9bcf8d910cca2389283ef48562efcfbe0370f2da7d1f65f49d929811d',1984,'UY','Uruguay','communications',167,'. (See reference map IV)
2:
fre
Merchant marine: 15 ships (1,000 GRT or
over) totaling 93,752 GRT, 132,386 DWT; in-
cludes 12 cargo, 2 tanker, and 1 bulk; ;
additionally, 2 naval tankers are sometimes
used commercially
4
Defense Forces
Personnel: 22 ,300 army, 4,700 navy (includ-
ing 430 in naval air arm and 500 marines),
3,260 air force (including 341 pilots), 1,685
maritime police, 520 Republican Guard, 650
Metropolitan Guard
Major ground units: 4 army divisions com-
prising 7 brigades (4 infantry, 3 cavalry) and
11 battalion-size units (6 field artillery, 4 en-
gineering, | air defense), 3 independent
brigades (1 cavalry, 1 engineering, ] commu-
nications)
Ships: 3 frigates, 7 patrol ships and craft, 2°
former minesweepers now designated as cor-
, vettes with no mine warfare capability, 5
; amphibious warfare craft, 2 tankers, 6 auxil-
iaries, 1 training ship, 7 service craft
. Aircraft: 134, including 112 in air force (10
: jet, 21 turboprop, 68 prop, 13 helicopters), 22
: in naval air arm (3 turboprop, 16 prop, 3 heli-
'' copter)
Supply: since 1976 has relied heavily on Ar-
‘gentina, Brazil, Spain, Portugal, ROK,
France. and FRG for major items of equip-
ment .
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
90','b6a0c38ccf31581b0b8e9be9880e3f1e61fb7152cdff00601c4dff7f88e6a9a8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22a0adce611d44f036cee1ced688ca5e7ab41d44ca598d345e4897de6140c400',1984,'VU','Vanuatu','communications',168,'(formerly New Hebrides)
(See reference map X)
‘25XK1
25x1
25X11 |
25X11
'' Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 :
25X1
SE
ote
Vatican City
(See reference map V) ;
Venezuela a
(See reference map IV)
Merchant marine: 64 ships (1,000 GRT or
over) totaling 771,570 GRT, 1,082,970 DWT;
includes 5 passenger, 30 cargo, 19 tanker, 6
CIA-RDP08-00534R000100050001-7
Supply: produces portion of small arms and
amminition, aerial bombs, and military ex-
plosives and propellants; dependent upon US
and Western Europe for all other materiel; 2
submarines purchased from FRG,*6 fast pa-
trol boats from the UK, and 6 frigates from
Italy '' 25X1
Military budget: proposed for fiscal year
ending 31 December; 1983,.$1,094 million;
about 6.1% of central government budget
bulk, and 6 roll-on/roll-off cargo
Defense Forces .
Personnel: 27,000 army, 9,100 navy (includ-
ing 4,500 marines), 4,500 air force, 15,000
national guard, 450 (est.) coast guard
Major ground units: 4 divisions (2 infantry, 1
cavalry, 1 jungle), ] armored brigade, 1
ranger brigade, 1 airborne regiment
Ships: 3 submarines, 6 frigates, 4 amphibious
warfare ships, 3 missile attack boats, 3 patrol
craft, 56 patrol boats, 6 auxiliary ships, 3 serv-
ice craft
Aircraft: 280 operational (79 jet, 45 turbo-
prop, 86 prop, 70 helicopters), 183 (79 jet) in
air force; additional 77 aircraft not assigned
to operational units that are in storage await-
ing disposal; 26 aircraft assigned to the navy;
25 to the army, 46 to the national guard; air
force total includes 6 F-16 jet aircraft; an ad-
ditional 18 F-16 jet aircraft are scheduled for
delivery in 1985
"91
2K}.
eee ee ge 25X1
~ 25x11
-25X1,
eee | 25x11
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Vietnam
(See reference map IX)
Merchant marine: 45 ships (1,000 GRT or
over) totaling 231,200 GRT, 339,400 DWT;
includes 38 cargo, 7 tanker, 3 bulk, 1
passenger-car, and } roll-on/roll-off cargo;
Vietnam beneficially owns 10 cargo ships
(1,000 GRT or over) totaling 80,000 GRT,
Ships: 4 frigates (FFL), 4 patrol combatants,
106. coastal patrol-river/roadstead craft, in-
cluding 11 missile attack boats (PTG), 4
amphibious warfare ships (LST, LSM), 7
mine warfare ships, 32 amphibious warfaré
alt and 2.auriliary /service craft
Aircraft: 761, including 261 jet fighters/
ground attack aircraft, 2 reconnaissance air-
craft, 83 jet trainers, 19 jet transports, 62
turboprop transports, 38 prop transports, 102
helicopters, 4 ASW turboprop aircraft, and
14 ASW helicopters; 132 jet fighters and 42.
helicopters i in storage
M ‘estes: 13 SAM regiments and 37 AAA regi-
ments
Supply: limited production of small arms and
ammunition; dependent for all other equip-
ment on USSR
115,000 DWT under the Panamanian flag
f dacoridaanicationé: government require-
ments fulfilled mainly through radio-
communications and radio-relay networks;
radio stations provide alternate communica-
tion links; international facilities adequate
from Hanoi and Ho Chi Minh City (Saigon),
radio and wired-broadcast coverage is good
and most important means of mass commu-
nications; about 60,000 telephones; estimated
8 to 4 million radios and over 300,000 TV sets;
approximately 18 shortwave and 5
mediumwave. radio transmitters;.11 AM, 1
‘ FM, and 6 TV stations
Defense Forces
-NOTE: all figures under defense iotes: are
‘preliminary
,
‘Personnel: 1,200,000-1,400,000 army; 3,000-
6,000 navy; 12,200 air force
Major ground units: 60 infantry divisions, 12
economic construction divisions, 11 engineer
divisions, 4 training divisions, 1 transporta-
tion division, 11 armor brigades, 10 AAA
brigades, 19 artillery brigades/regiments, 22
engineer brigades
Secret
92','22419a4ee3de9a059d94cc98e04862036d219d96b868b3dd57cc14541cc47c6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d863ccf9e8ce9942fcecc4be11489b1b46787da4f93b8a714230c46f46566f2',1984,'EH','Western Sahara','communications',170,'(formerly Spanish Sahara)
(See reference map Vii)
Communications a
Telecommunications: sparse er fragmen-
tary-system with facilities concentrated in-
northwest area; some radio relay, wire, and:
radiocommunications stations in use; 1,000
telephones:(0.7 per 100 popl:); 2.satellite ...:
£
25X11 |
ground stations for traffic to Rabat
25X11
ae Eeewed
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Western Samoa
(See reference map X)
Defense Forces
Western Samoa has informal defense ties to
New Zealand but has no formal defense
structure and no regular armed forces; a na-
tive police force of 245 men is maintained;
the 1972 budget for police and prisons was
US$405,230, 3.8% of total government bud-
get
Yemen Arab Republic
(North Yemen)
(See reference map VI)
Merchant marine: 8 cargo ships (1,000 GRT
Missiles: 4 SA-2 batteries; SA-7s are deployed
with PDRY Army units; SA-6s newly ac-
quired and being incorporated into
HAVE MIORY
cn
aaa ce sre a
Supply: dependent’ on outside sources, pri-
malily USSR[
Military budget: for fiscal yéar ending 31
December 1983, $186 million; 21% of ceritral
government budget
or over) totaling 4,300 GRT, 6,600 DWT
Defense Forces
Personnel: 22,000 army, 1,000 navy, 2,500
air force (100 pilots), 15,000 people’s police
(paramilitary), 15,000 people’s militia (para-
Merchant marine: 260 ships (1,000 GRT or:
over) totaling 2,472,200 GRT, 4,111,400
DWT; includes 7 passenger, 176 cargo, 4 con. 20X11
tainer, 9 roll-on/roll-off cargo, 1] tanker, 53
bulk; Yugoslavia beneficially owns 7 7 addi- — 25X11
tional ships (1,000 GRT or over) totaling
70,400 GRT, 112,300 DWT, which are regis-
tered under the Panamanian flag
25x1
Civil air: 42 major transport aircraft (1982)
25X1
Airfields: 139 total; 48 with permanent-_
surface runways; 19 with runways .
2;500:3,499 m, 45 with runways 1,000-2,499 25X1-
m, 75 with runways less than 1,000 m; 1 heli- =,
port 25X1
Telecommunications: services available to
public are limited but system as a whole is
adequate; telephone and telegraph services 25x1
are provided by open-wire lines, multi-
conductor, coaxial, and submarine cables;
radio and TV broadcast facilities provide 25X11
coverage to nearly all sections of country; 26
main and 48 relay AM stations and 47 FM
stations; 4,650,000 receivers; 25 major and
152 relay TV stations; 3,800,000 receivers;
1,600,000 telephones (97% automatic)
25X1
1
25X11
’
Defense Forces
Personnel: 141,967 ground forces, 12,000 na-
val forces, 36,700 air and air defense forces,
18,000 paramilitary forces; personnel in re-
serve (not on active’ duty): (est.) 2,100,000
ground forces, 48,000 naval forces, air force
unknown
Major ground units: 8 infantry divisions, 27
brigades(14 infantry, 3 mechanized, | moun-_
tain, 8 tank, 1 parachute), 38 regiments (2
infantry, 1] artillery, 6 antitank, 13 antiair-
craft artillery, and 6 SA-6 regiments)
Ships: 7 submarines, 2 principal surface com-
batants, 83 coastal patrol-river/roadstead
craft, 40 amphibious warfare craft, 31 mine
warfare craft, 2 underway replenishment
ships, 2 fleet support ships, 9 other auxiliaries
Aircraft: (in operational units) 522, including
189 air defense fighters, 167 ground attack,
63 reconnaissance, 34 transports, 119 heli- .
copters
Missiles: 8 operational SA-2 sites (48 launch-
ers); 9 operational SA-3 sites (36 four-rail
launchers); 6 regiments of the SA-6 SAM sys-
tem are deployed with the ground forces; and
the SA-7 and SA-9 systems are also believed
to be deployed on a limited basis
Supply: produces weapons and ammunition
up to medium artillery, ATGMs and SA-7s,
trucks, MIGV, signal equipment,
offensive/defensive chemical warfare mate-
riel; builds submersibles, midget submarines,
submarines, missile attack boats, amphibious
warfare craft, and up to frigate-size surface
combatants and naval auxiliary ships; builds
limited quantity of subsonic fighter aircraft,
and assembles limited quantities of helicop-
ters; other materiel now obtained primarily
from USSR, although limited quantities of
military equipment have been received from
free world suppliers, particularly Sweden
25X11
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Zaire
oX1
5X1
5X1
(See reference map Vil)
25X11
Merchant marine: 8 cargo ships (1,000 GRT
or over) totaling 77,400 GRT, 117,443 DWT
25X1
25X1
Defense Forces
Personnel: 24,000 army, 2,000 air force,
2,000 navy, 24,000 gendarmerie, 3,000 Spe-
cial Presidential Brigade, 5,000 Corlog,
armed forces headquarters; military advis-
ers—110 Belgian, 125 French, 126 Chinese,
10 FRG, 10 Israeli, and 15 Egyptian
Major ground units: 1 infantry division, 1
airborne brigade (3 battalions), 1 armored
brigade, 3 infantry brigades, 1 Special Bri-
gade (headquarters, ceremonial, and
miscellaneous units, as well as 1 Presidential
Guard battalion, 1 parachute battalion, and 1
armored infantry battalion)
Ships: 42 total (4 coastal escorts, 3 motor tor-
pedo boats, 33 patrol boats, 2 landing craft)
aes 25X1
Aircraft: 65 (27 jet, 8 turboprop, 19 prop, 11
helicopters) 25X1
25X1
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDPO8-00534R000100050001-7
Zaire (continued) Zambia
(formerly Northern Rhodesia) — a.
Supply: historically dependent on Western
sources, principally France and US, and toa
lesser extent Belgium, Israel, and Italy; in
1975 began receiving Chinese, FRG, Cana-
dian, and North Korean equipment
Military budget: for fiscal year ending 31 _
December 1980, $324.4 million; 21% of cen-
tral government budget 25X1
20X11
Military budget: for fiscal year ending 31
December 1983, $48.26 million; 7.1% of.cen-
tral government budget
25x11
25x1
reference map VII):','dc799263343f8a07e4ebe455d2338b360e092619e9a897b36fed928c7f8daf0f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f4dd464d1edbb50aecca3d02f38e40d38587b93dafe5fac896c14e9994a913e',1984,'ZW','Zimbabwe','communications',174,'Merchant marine: 148 ships (1,000 GRT or
over) totaling 1,827,855 GRT, 2,779,780
DWT; includes | passenger, 85 cargo, 17 con-
tainer, 13 tanker, 25 bulk, 1 combination
ore/oil, 1 specialized carrier
Civil air: 47 major transport aircraft
Defense Forces
Personnel: 310,000 army, 61,200 navy
(31,000 marines), 68,000 air force, 39,600
Ministry of National Defense (not included in
service totals), 7,600 Combined Service
forces
Major ground units: the army has 8 field ar-
mies, 1 defense command, and 6 corps
comprising 12 heavy infantry divisions, 6
light infantry divisions, 3 marine divisions, 6
armored brigades, 4 tank groups, 2 airborne
brigades, 1 Taiwan Garrison General Head-
quarters (25,000 national security police), 1
Anti-Communist National Salvation Corps
(light division equivalent), 25 GS field artil-
lery battalions, 2 NIKE Hercules missile
battalions, 4 I-HAWK missile battalions;
army aviation has 3 general support aviation
battalions; 9 reserve infantry divisions (cadre
only for reserve, recruit, and ROTC training)
Ships: 185 combatant units (not including 28
yard/service craft and 302 minor amphibi-
ous craft), supported by 3 underway
replenishment ships, 1 materiel support ship,
8 fleet support ships, and 8 other auxiliaries;
97
combatant units include 2 training subma-
rines, 24 destroyers, 10 frigates, 1 guided
missile patrol combatant, 4 patrol combat-
ants, 29 amphibious warfare ships, 74 coastal
patrol-river/roadstead craft (50 of which are
to be missile-equipped fast patrol craft; to
date only 2 have had their missile launchers
installed), 21 amphibious warfare craft, and
2] mine warfare cr: |
lm arfare craft 25X14
Aircraft: 984, including 795 (487 jet) in air
force, 169 in army aviation, 20 in marine avi-
ation 25X1
Missiles: NIKE Hercules, HAWK
Chapparal, Ching Feng medium-range mis-
sile, Hsiung Feng cruise missile, 1 Kunwu
(“sword”) antitank guided missile
Supply: some production of missile- 25X11
equipped patrol boats, infantry weapons, 5X1
armored vehicles, artillery weapons, tactica:
communications equipment, artillery am- 5X1
munition, chemical /biological warfare pro-
tective masks, assembly of general purpose 5X4
vehicles, quartermaster items; moderate re. 5X1
ance upon US for other military supplies;
assembling US F-5E fighters under license; 2
submarines on order from the Netherlands
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Appendix
Conversion Factors
To Convert From To Multiply By To Convert From To Multiply By
Acres se Hectares 0.4046856 Meters, cubic Tons, register 0.353147
Acres Kilometers, square 0.004046856 Miles, nautical Kilometers 1.852
Acres Meters, square 4046.856 Miles, statute Centimeters 160934.4 s
Centimeters Meters 0.01 Miles, statute Meters 1609.344 a
Centimeters, square Meters, square 0.0001 Miles, statute Kilometers 1.609344
Degrees, Fahrenheit Degrees, Celsius subtract 32 and Miles, square Hectares 258.9998 Q
multiply by 5/9 Miles, square Kilometers, square 2.589998 _
Feet Centimeters 30.48 Ounces, avoirdupois Grams 28.349523
Feet Meters 0.3048 Ounces, avoirdupois Kilograms 0.028349523 .
Feet Kilometers 0.0003048 Ounces, troy Pounds, troy 0.083333 ''
Feet, cubic Liters 28.316847 Ounces, troy Grams 31.10348 .
Feet, cubic Meters, cubic 0.028316847 Pints, liquid Milliliters 473.176473 ‘
Feet, square Centimeters, square 929.0304 Pints, liquid Liters 0.473176473
Feet, square Meters, square 0.09290304 Pounds, avoirdupois Grams 453.59237 sod
Gallons, US liquid Liters 3.785412 Pounds, avoirdupois Kilograms 0.45359237 ‘
Gallons, US liquid Meters, cubic 0.003785412 Pounds, avoirdupois Quintals 0.00453592 ‘
Grams Ounces, troy 0.032151 Pounds, avoirdupois Tons, metric 0.000453592 :
Grams Pounds, troy 0.002679 Pounds, troy Ounces, troy 12 ‘
Hectares Kilometers, square 0.01 Pounds, troy Grams 373.241722 4
Hectares Meters, square 10,000 Quarts, dry Liters 1.101221 ‘
Inches Centimeters 2.54 Quarts, dry Dekaliters 0.1101221 4
Inches Meters 0.0254 Quarts, liquid Milliliters 946.352946 ‘
Inches, cubic Milliliters 16.387064 Quarts, liquid Liters 0.946352946
Inches, cubic Liters 0.016387064 Quintals Tons, metric 0.1
Inches, cubic Meters, cubic 0.000016387064 Tons, long Kilograms 1016.047°
Inches, square Centimeters, square 6.4516 Tons, long Tons, metric 1.016047
Inches, square Meters, square 0.00064516 Tons, metric Quintals 10
Kilograms Ounces, troy 32.15075 Ton-miles, long Ton-kilometers, metric 1.635169
Kilograms Pounds, troy 2.679229 Ton-miles, short Ton-kilometers, metric 1.459972
Kilograms Tons, metric 0.001 Tons, register Meters, cubic 2.831685
Kilometers, square Hectares 100 Tons, short Kilograms 907.185 -
Liters Milliliters 1000 Tons, short Tons, metric 0.907185
Liters Meters, cubic 0.001 Yards Centimeters 91.44
Meters Millimeters 1000 Yards Meters 0.9144
Meters Centimeters 100 Yards, cubic Liters 764.5549
Meters Kilometers 0.001 Yards, cubic Meters, cubic 0.7645549
Meters, cubic Liters
Secret
1000 Yards, square Meters, square 0.836127
ee ee eo
a
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
~~ Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
Secret
-a™ Decliassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7 :','39b5316ed36b731ad8ae4909f1e3131b96041c7418aade98398d2d6eb68cb639','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

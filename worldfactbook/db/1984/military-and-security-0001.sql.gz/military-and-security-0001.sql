SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1add54ee199b316cdd4d445b2ad923b869b7671b172011dec6ac81b5623743f',1984,'EH','Western Sahara','military-and-security',172,'Major ground units: 10 infantry brigades (3
battalions per brigade), 1 mechanized infan-
try brigade, ‘1 armored brigade (training), 1
field artillery brigade (training), ]
missile/rocket brigade
Ships: 8 guided missile patrol boats, 2 smal]
submarine chasers, 2 torpedo boats, | patrol
ship, 7 patrol boats, 1 mine warfare ship, 1
landing ship, 3 medium landing ships, 5 land-
ing craft, 1 fireboat
Aircraft: 191 (125 jet, 8 prop, 7 turboprop, 51
helicopters)
Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/09/20 : CIA-RDP08-00534R000100050001-7
94
Yugoslavia
25x1
25X1
25X1
25X1
(See reference map V) ''
: 1','d34912895f11fe20e23127ce9df31702c850874ef87af28dbb4822525d2ede63','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100050001-7','txt','2db3a9170c0f7692ec8ac3b5c5c75062bd584881a9c7fd597ba16e4e275c94e7','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100050001-7/cia-rdp08-00534r000100050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

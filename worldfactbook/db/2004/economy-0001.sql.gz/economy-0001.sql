SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d03e488c36a9aa5aa200161aa6410db5f9773ed7ba84a15a43dffe42e6de5360',2004,'ZW','Zimbabwe','economy',4,'GDP
GDP - real growth rate
GDP - per capita
Investment, gross fixed
Inflation rate (consumer prices)
Labor force
Unemployment rate
Public debt
Industrial production growth rate
Electricity - production
Electricity - consumption
Oil - production
Oil - consumption
Oil - exports
Oil - imports
Oil - proved reserves
Natural Gas - production
Natural Gas - consumption
Natural Gas - exports
Natural Gas - imports
Natural Gas - proved reserves
Current account balance
Exports
Imports
Reserves of foreign exchange and gold
Debt - external
This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview
This entry briefly describes the type of economy, including the degree
of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It
also characterizes major economic events and policy changes in the most
recent 12 months and may include a statement about one or two key
future macroeconomic trends.
Electricity - consumption
This entry consists of total electricity generated annually plus
imports and minus exports, expressed in kilowatt-hours. The discrepancy
between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in
transmission and distribution.
Electricity - exports
This entry is the total exported electricity in kilowatt-hours.
Electricity - imports
This entry is the total imported electricity in kilowatt-hours.
Electricity - production
This entry is the annual electricity generated expressed in kilowatt-
hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted
for as loss in transmission and distribution.
Electricity - production by source
This entry states the percentage share of electricity generated from
each energy source. These are fossil fuel, hydro, nuclear, and other
(solar, geothermal, and wind).
Elevation extremes
This entry includes both the highest point and the lowest point.
Entities
Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. "Independent state" refers to a people politically
organized into a sovereign state with a definite territory.
"Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an
independent state. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 271 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
192 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic Lands,
Glorioso Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte,
New Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island,
The UK annexed Southern Rhodesia from the South Africa
Company in 1923. A 1961 constitution was formulated that favored
whites in power. In 1965 the government unilaterally declared its
independence, but the UK did not recognize the act and demanded more
complete voting rights for the black African majority in the country
(then called Rhodesia). UN sanctions and a guerrilla uprising
finally led to free elections in 1979 and independence (as Zimbabwe)
in 1980. Robert MUGABE, the nation''s first prime minister, has been
the country''s only ruler (as president since 1987) and has dominated
the country''s political system since independence. His chaotic land
redistribution campaign begun in 2000 caused an exodus of white
farmers, crippled the economy, and ushered in widespread shortages
of basic commodities. Ignoring international condemnation, MUGABE
rigged the 2002 presidential election to ensure his reelection.
Opposition and labor groups launched general strikes in 2003 to
pressure MUGABE to retire early; security forces continued their
brutal repression of regime opponents.
This page was last updated on 10 February, 2005
======================================================================
@2030 Airports - with paved runways
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2004 est.)
This page was last updated on 10 February, 2005
======================================================================
@2031 Airports - with unpaved runways
total: 387
1,524 to 2,437 m: 5
914 to 1,523 m: 186
under 914 m: 196 (2004 est.)
This page was last updated on 10 February, 2005
======================================================================
@2032 Environment - current issues
deforestation; soil erosion; land degradation; air and
water pollution; the black rhinoceros herd - once the largest
concentration of the species in the world - has been significantly
reduced by poaching; poor mining practices have led to toxic waste
and heavy metal pollution
This page was last updated on 10 February, 2005
======================================================================
@2033 Environment - international agreements
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
This page was last updated on 10 February, 2005
======================================================================
@2034 Military expenditures - percent of GDP (%)
1.7% (2003)
This page was last updated on 10 February, 2005
======================================================================
@2038 Electricity - production (kWh)
6.735 billion kWh (2001)
This page was last updated on 10 February, 2005
======================================================================
@2042 Electricity - consumption (kWh)
9.813 billion kWh (2001)
This page was last updated on 10 February, 2005
======================================================================
@2043 Electricity - imports (kWh)
3.55 billion kWh (2001)
This page was last updated on 10 February, 2005
======================================================================
@2044 Electricity - exports (kWh)
0 kWh (2001)
This page was last updated on 10 February, 2005
======================================================================
@2045
This page was last updated on 10 February, 2005
======================================================================
@2046 Population below poverty line (%)
70% (2002 est.)
This page was last updated on 10 February, 2005
======================================================================
@2047 Household income or consumption by percentage share (%)
lowest 10%: 1.97%
highest 10%: 40.42% (1995)
This page was last updated on 10 February, 2005
======================================================================
@2048 Labor force - by occupation (%)
agriculture 66%, industry 10%, services 24% (1996)
This page was last updated on 10 February, 2005
======================================================================
@2049 Exports - commodities
tobacco, gold, ferroalloys, textiles/clothing
This page was last updated on 10 February, 2005
======================================================================
@2050 Exports - partners (%)
Zambia 6.3%, South Africa 6.1%, China 5.3%, Germany 4.6%,
Japan 4.4% (2003)
This page was last updated on 10 February, 2005
======================================================================
@2051 Administrative divisions
8 provinces and 2 cities* with provincial status;
Bulawayo*, Harare*, Manicaland, Mashonaland Central, Mashonaland
East, Mashonaland West, Masvingo, Matabeleland North, Matabeleland
South, Midlands
This page was last updated on 10 February, 2005
======================================================================
@2052 Agriculture - products
corn, cotton, wheat, coffee, sugarcane, peanuts; sheep,
goats, pigs
This page was last updated on 10 February, 2005
======================================================================
@2053 Airports
404 (2003 est.)
This page was last updated on 10 February, 2005
======================================================================
@2054 Birth rate (births/1,000 population)
30.05 births/1,000 population (2004 est.)
This page was last updated on 10 February, 2005
======================================================================
@2055 Military branches
Zimbabwe National Army, Air Force of Zimbabwe, Zimbabwe
Republic Police (includes Police Support Unit, Paramilitary Police)
This page was last updated on 10 February, 2005
======================================================================
@2056 Budget
revenues: $1.568 billion
expenditures: $2.004 billion, including capital expenditures of NA
(2003)
This page was last updated on 10 February, 2005
======================================================================
@2057 Capital
The government of Zimbabwe faces a wide variety of
difficult economic problems as it struggles with an unsustainable
fiscal deficit, an overvalued exchange rate, soaring inflation, and
bare shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the country''s failure to meet budgetary goals.
Inflation rose from an annual rate of 32% in 1998 to 383% in 2003,
and is expected to reach 700% in 2004. The government''s land reform
program, characterized by chaos and violence, has badly damaged the
commercial farming sector, the traditional source of exports and
foreign exchange and the provider of 400,000 jobs.
This page was last updated on 10 February, 2005
======================================================================
@2117 Pipelines (km)
refined products 261 km (2004)
This page was last updated on 10 February, 2005
======================================================================
@2118 Political parties and leaders','828c9657846cf9bafaa133c050bf769cbce2ef3883e82b99ed32c86cecb5f9b7','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('589fe0c1a7406448dc33310c55e9011e096888c133a2f8ed628024f5b9344996',2004,'WF','Wallis and Futuna','economy',23,'2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
17 UK - Akrotiri, Anguilla, Bermuda, British Indian Ocean
Territory, British Virgin Islands, Cayman Islands, Dhekelia, Falkland
Islands, Gibraltar, Guernsey, Jersey, Isle of Man, Montserrat, Pitcairn
Islands, Saint Helena, South Georgia and the South Sandwich Islands,
Although discovered by the Dutch and the British
in the 17th and 18th centuries, it was the French who declared a
protectorate over the islands in 1842. In 1959, the inhabitants of
the islands voted to become a French overseas territory.
West Bank
The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements (the DOP), signed in Washington on 13
September 1993, provided for a transitional period not exceeding
five years of Palestinian interim self-government in the Gaza Strip
and the West Bank. Under the DOP, Israel agreed to transfer certain
powers and responsibilities to the Palestinian Authority, which
includes the Palestinian Legislative Council elected in January
1996, as part of the interim self-governing arrangements in the West
Bank and Gaza Strip. A transfer of powers and responsibilities for
the Gaza Strip and Jericho took place pursuant to the Israel-PLO 4
May 1994 Cairo Agreement on the Gaza Strip and the Jericho Area and
in additional areas of the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement, the Israel-PLO 15 January 1997
Protocol Concerning Redeployment in Hebron, the Israel-PLO 23
October 1998 Wye River Memorandum, and the 4 September 1999 Sharm
el-Sheikh Agreement. The DOP provides that Israel will retain
responsibility during the transitional period for external and
internal security and for public order of settlements and Israeli
citizens. Direct negotiations to determine the permanent status of
Gaza and West Bank that began in September 1999 after a three-year
hiatus, were derailed by a second intifadah that broke out in
September 2000. The resulting widespread violence in the West Bank
and Gaza Strip, Israel''s military response, and instability within
the Palestinian Authority continue to undermine progress toward a
permanent agreement. Following the death of longtime Palestinian
leader Yasir ARAFAT in November 2004, the election of his successor
Mahmud ABBAS in January 2005 could bring a turning point in the
conflict.
total: 1
1,524 to 2,437 m: 1 (2004 est.)
West Bank
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
total: 1
914 to 1,523 m: 1 (2004 est.)
deforestation (only small portions of the original
forests remain) largely as a result of the continued use of wood as
the main fuel source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone to erosion;
there are no permanent settlements on Alofi because of the lack of
natural fresh water resources
West Bank
adequacy of fresh water supply; sewage treatment
NA kWh
West Bank
NA kWh; note - most electricity imported from Israel; East
Jerusalem Electric Company buys and distributes electricity to
Palestinians in East Jerusalem and its concession in the West Bank;
the Israel Electric Company directly supplies electricity to most
Jewish residents and military facilities; some Palestinian
municipalities, such as Nablus and Janin, generate their own
electricity from small power plants
NA kWh
West Bank
NA kWh
0 kWh (2002)
West Bank
NA kWh
0 kWh (2002)
NA
West Bank
60% (2003 est.)
lowest 10%: NA
highest 10%: NA
West Bank
lowest 10%: NA
highest 10%: NA
agriculture, livestock, and fishing 80%,
government 4% (2001 est.)
West Bank
agriculture 13%, industry 21%, services 66% (1996)
copra, chemicals, construction materials
West Bank
olives, fruit, vegetables, limestone
Italy 40%, Croatia 15%, US 14%, Denmark 13%
West Bank
Israel, Jordan, Gaza Strip (2000)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are three kingdoms at the second order named
Alo, Sigave, Wallis
breadfruit, yams, taro, bananas; pigs, goats
West Bank
olives, citrus, vegetables; beef, dairy products
2 (2003 est.)
West Bank
3 (2003 est.)
NA births/1,000 population
West Bank
33.21 births/1,000 population (2004 est.)
revenues: $20 million
expenditures: $17 million, including capital expenditures of NA
(1998 est.)
West Bank
revenues: $676.6 million
expenditures: $1.155 billion, including capital expenditures of NA
(includes Gaza Strip) (2003 est.)
The economy is limited to traditional subsistence
agriculture, with about 80% labor force earnings from agriculture
(coconuts and vegetables), livestock (mostly pigs), and fishing.
About 4% of the population is employed in government. Revenues come
from French Government subsidies, licensing of fishing rights to
Japan and South Korea, import taxes, and remittances from expatriate
workers in New Caledonia.
West Bank
Real per capita GDP for the West Bank and Gaza Strip
(WBGS) declined by about one-third between 1992 and 1996 due to the
combined effect of falling aggregate incomes and rapid population
growth. The downturn in economic activity was largely the result of
Israeli closure policies - the imposition of border closures in
response to security incidents in Israel - which disrupted labor and
commodity market relationships between Israel and the WBGS. The most
serious social effect of this downturn was rising unemployment,
which in the WBGS during the 1980s was generally under 5%; by 1995
it had risen to over 20%. Israel''s use of comprehensive closures
during the next three years decreased and, in 1998, Israel
implemented new policies to reduce the impact of closures and other
security procedures on the movement of Palestinian goods and labor.
These changes fueled an almost three-year-long economic recovery in
the West Bank and Gaza Strip; real GDP grew by 5% in 1998 and 6% in
1999. Recovery was upended in the last quarter of 2000 with the
outbreak of violence, which triggered tight Israeli closures of
Palestinian self-rule areas and severely disrupted trade and labor
movements. In 2001, and even more severely in 2002, Israeli military
measures in Palestinian Authority areas resulted in the destruction
of much capital plant and administrative structure, widespread
business closures, and a sharp drop in GDP. Including Gaza Strip,
the UN estimates that more than 100,000 Palestinians out of the
125,000 who used to work in Israel, in Israeli settlements, or in
joint industrial zones have lost their jobs. In addition, about
80,000 Palestinian workers inside the Territories are losing their
jobs. International aid of $2 billion in 2001-02 to the West Bank
and Gaza Strip prevented the complete collapse of the economy. In
2004, on-going border issues and the death of Yasser ARAFAT
continued to complicate the economic situation.','05dfb9103927b6a90dc9cbd5ee7560064bad1dfc946b1b569681bc0601de074f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a780b3f0f56500522fb21e6ac57709df842f9b9a9eb86b0706991ab97e45ede8',2004,'TC','Turks and Caicos Islands','economy',24,'14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Northern Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands,
Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West
Bank, Western Sahara
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific
Ocean, Southern Ocean
1 World
271 total
Environment - current issues
This entry lists the most pressing and important environmental
problems. The following terms and abbreviations are used throughout
the entry:
acidification - the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwater fish
and plants dependent on more neutral or alkaline conditions (see acid
rain).
acid rain - characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially deadly
to the earth''s fragile ecosystems; acidity is measured using the pH
scale where 7 is neutral, values greater than 7 are considered
alkaline, and values below 5.6 are considered acid precipitation; note
- a pH of 2.4 (the acidity of vinegar) has been measured in rainfall in
New England.
aerosol - a collection of airborne particles dispersed in a gas,
smoke, or fog.
afforestation - converting a bare or agricultural space by
planting trees and plants; reforestation involves replanting trees on
areas that have been cut or destroyed by fire.
asbestos - a naturally occurring soft fibrous mineral commonly
used in fireproofing materials and considered to be highly carcinogenic
in particulate form.
biodiversity - also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces an
ecosystem''s ability to recover from natural or man-induced disruption.
bio-indicators - a plant or animal species whose presence,
abundance, and health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given
area or volume.
carbon cycle - the term used to describe the exchange of carbon
(in various forms, e.g., as carbon dioxide) between the atmosphere,
ocean, terrestrial biosphere, and geological deposits.
catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited
freshwater resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless
insecticide that has toxic effects on most animals; the use of DDT was
banned in the US in 1972.
defoliants - chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g.,
unsustainable forestry practices, agricultural and range land clearing,
and the over exploitation of wood products for use as fuel) without
planting new growth.
desertification - the spread of desert-like conditions in arid or
semi-arid areas, due to overgrazing, loss of agriculturally productive
soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g.,
shellfish) or harvesting coral, often causing significant destruction
of reef and ocean-floor ecosystems.
drift-net fishing - done with a net, miles in extent, that is
generally anchored to a boat and left to float with the tide; often
results in an over harvesting and waste of large populations of non-
commercial marine species (by-catch) by its effect of "sweeping the
ocean clean."
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial
waste which are released into the environment, subsequently polluting
it.
endangered species - a species that is threatened with extinction
either by direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources
include lakes, streams, rivers, glaciers, and underground aquifers.
greenhouse gas - a gas that "traps" infrared radiation in the
lower atmosphere causing surface warming; water vapor, carbon dioxide,
nitrous oxide, methane, hydrofluorocarbons, and ozone are the primary
greenhouse gases in the Earth''s atmosphere.
groundwater - water sources found below the surface of the earth
often in naturally occurring reservoirs in permeable rock strata; the
source for wells and natural springs.
Highlands Water Project - a series of dams constructed jointly by
Lesotho and South Africa to redirect Lesotho''s abundant water supply
into a rapidly growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the most costly
and controversial; objections to the project include claims that it
forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 145,000 Inuits
of Russia, Alaska, Canada, and Greenland in international environmental
issues; a General Assembly convenes every three years to determine the
focus of the ICC; the most current concerns are long-range transport of
pollutants, sustainable development, and climate change.
metallurgical plants - industries which specialize in the science,
technology, and processing of metals; these plants produce highly
concentrated and toxic wastes which can contribute to pollution of
ground water and air when not properly disposed.
noxious substances - injurious, very harmful to living beings.
overgrazing - the grazing of animals on plant material faster than
it can naturally regrow leading to the permanent loss of plant cover, a
common effect of too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas (O3)
that resides approximately 25 miles above the Earth''s surface and
absorbs solar ultraviolet radiation that can be harmful to living
organisms.
poaching - the illegal killing of animals or fish, a great concern
with respect to endangered or threatened species.
pollution - the contamination of a healthy environment by man-made
waste.
potable water - water that is drinkable, safe to be consumed.
salination - the process through which fresh (drinkable) water
becomes salt (undrinkable) water; hence, desalination is the reverse
process; also involves the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that can
eventually render soil incapable of supporting crops.
siltation - occurs when water channels and reservoirs become
clotted with silt and mud, a side effect of deforestation and soil
erosion.
slash-and-burn agriculture - a rotating cultivation technique in
which trees are cut down and burned in order to clear land for
temporary agriculture; the land is used until its productivity declines
at which point a new plot is selected and the process repeats; this
practice is sustainable while population levels are low and time is
permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences
for the environment .
soil degradation - damage to the land''s productive capacity
because of poor agricultural practices such as the excessive use of
pesticides or fertilizers, soil compaction from heavy equipment, or
erosion of topsoil, eventually resulting in reduced ability to produce
agricultural products.
soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic
energy emitted by the sun and naturally filtered in the upper
atmosphere by the ozone layer; UV radiation can be harmful to living
organisms and has been linked to increasing rates of skin cancer in
humans.
water-born diseases - those in which the bacteria survive in, and
is transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements
This entry separates country participation in international
environmental agreements into two levels - party to and signed but not
ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements
This information is presented in Appendix C: Selected International
Environmental Agreements, which includes the name, abbreviation, date
opened for signature, date entered into force, objective, and parties
by category.
Ethnic groups
This entry provides an ordered listing of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates
This entry provides the official value of a country''s monetary unit at
a given date or over a given period of time, as expressed in units of
local currency per US dollar and as determined by international market
forces or official fiat.
Executive branch
This entry includes several subfields. Chief of state includes the name
and title of the titular leader of the country who represents the state
at official and ceremonial functions but may not be involved with the
day-to-day activities of the government. Head of government includes
the name and title of the top administrative leader who is designated
to manage the day-to-day activities of the government. For example, in
the UK, the monarch is the chief of state, and the prime minister is
the head of government. In the US, the president is both the chief of
state and the head of government. Cabinet includes the official name
for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in the
last election.
Exports
This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities
This entry provides a rank ordering of exported products starting with
the most important; it sometimes includes the percent of total dollar
value.
Exports - partners
This entry provides a rank ordering of trading partners starting with
the most important; it sometimes includes the percent of total dollar
value.
Fiscal year
This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but
which may begin in any month. All yearly references are for the
calendar year (CY) unless indicated as a noncalendar fiscal year (FY).
Flag description
This entry provides a written flag description produced from actual
flags or the best information available at the time the entry was
written. The flags of independent states are used by their dependencies
unless there is an officially recognized local flag. Some disputed and
other areas do not have flags.
Flag graphic
Most versions of the Factbook include a color flag at the beginning of
the country profile. The flag graphics were produced from actual flags
or the best information available at the time of preparation. The flags
of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not
have flags.
GDP
This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. GDP dollar
estimates in the Factbook are derived from purchasing power parity
(PPP) calculations. See the note on GDP methodology for more
information.
GDP methodology
In the Economy category, GDP dollar estimates for all countries are
derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method
involves the use of standardized international dollar price weights,
which are applied to the quantities of final goods and services
produced in a given economy. The data derived from the PPP method
provide the best available starting point for comparisons of economic
strength and well-being between countries. The division of a GDP
estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. Most of the GDP estimates are based on
extrapolation of PPP numbers published by the UN International
Comparison Program (UNICP) and by Professors Robert Summers and Alan
Heston of the University of Pennsylvania and their colleagues. In
contrast, the currency exchange rate method involves a variety of
international and domestic financial forces that often have little
relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Furthermore, exchange rates
may suddenly go up or down by 10% or more because of market forces or
official fiat whereas real output has remained unchanged. On 12 January
1994, for example, the 14 countries of the African Financial Community
(whose currencies are tied to the French franc) devalued their
currencies by 50%. This move, of course, did not cut the real output of
these countries by half. One important caution: the proportion of,
say, defense expenditures as a percentage of GDP in local currency
accounts may differ substantially from the proportion when GDP accounts
are expressed in PPP terms, as, for example, when an observer tries to
estimate the dollar level of Russian or Japanese military expenditures.
Note: the numbers for GDP and other economic data cannot be chained
together from successive volumes of the Factbook because of changes in
the US dollar measuring rod, revisions of data by statistical agencies,
use of new or different sources of information, and changes in national
statistical methods and practices.
GDP - composition by sector
This entry gives the percentage contribution of agriculture, industry,
and services to total GDP.
GDP - per capita
This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
GDP - real growth rate
This entry gives GDP growth on an annual basis adjusted for inflation
and expressed as a percent.
Geographic coordinates
This entry includes rounded latitude and longitude figures for the
purpose of finding the approximate geographic center of an entity and
is based on the Gazetteer of Conventional Names, Third Edition, August
1988, US Board on Geographic Names and on other sources.
Geographic names
This information is presented in Appendix F: Cross-Reference List of
Geographic Names. It includes a listing of various alternate names,
former names, local names, and regional names referenced to one or more
related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
The islands were part of the UK''s Jamaican
colony until 1962, when they assumed the status of a separate crown
colony upon Jamaica''s independence. The governor of The Bahamas
oversaw affairs from 1965 to 1973. With Bahamian independence, the
islands received a separate governor in 1973. Although independence
was agreed upon for 1982, the policy was reversed and the islands
remain a British overseas territory.
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 2 (2004 est.)
total: 2
under 914 m: 2 (2004 est.)
limited natural fresh water resources,
private cisterns collect rainwater
5 million kWh (2001)
4.65 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
about 33% in government and 20% in
agriculture and fishing; significant numbers in tourism, financial,
and other services
lobster, dried and fresh conch, conch shells
US, UK
none (overseas territory of the UK)
corn, beans, cassava (tapioca), citrus
fruits; fish
8 (2003 est.)
22.85 births/1,000 population (2004 est.)
revenues: $47 million
expenditures: $33.6 million, including capital expenditures of NA
(1997-98 est.)
The Turks and Caicos economy is based on
tourism, fishing, and offshore financial services. Most capital
goods and food for domestic consumption are imported. The US is the
leading source of tourists, accounting for more than half of the
93,000 visitors in the late 1990s. Major sources of government
revenue include fees from offshore financial activities and customs
receipts. Tourism fell by 6% in 2002.','91ccbe5b44866ea182d4d088f5f2b192e1753605ef15f411705dd6aeb89e35e9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc947ade97f290bf1183c9be0ad16521efc1d3458733d737c35d3a3364a86d63',2004,'TG','Togo','economy',70,'GDP:
purchasing power parity - $27.75 billion (2003 est.)
GDP - real growth rate:
4.2% (2003 est.)
GDP - per capita:
purchasing power parity - $1,800 (2003 est.)
GDP - composition by sector:
agriculture: 42.6%
industry: 19.8%
services: 37.6% (2003 est.)
Investment (gross fixed):
19.4% of GDP (2003)
Population below poverty line:
48% (2000 est.)
Household income or consumption by percentage share:
lowest 10%: 1.9%
highest 10%: 36.6% (1996)
Distribution of family income - Gini index:
47.7 (1996)
Inflation rate (consumer prices):
2.3% (2003 est.)
Labor force:
6.49 million NA (2003)
Labor force - by occupation:
agriculture 70%, industry and commerce 13%, other 17%
Unemployment rate:
30% (2001 est.)
Budget:
revenues: $2.442 billion
expenditures: $1.941 billion, including capital expenditures of NA
(2003 est.)
Public debt:
57.1% of GDP (2003)
Agriculture - products:
coffee, cocoa, cotton, rubber, bananas, oilseed, grains, root
starches; livestock; timber
Industries:
petroleum production and refining, food processing, light consumer
goods, textiles, lumber
Industrial production growth rate:
4.2% (1999 est.)
Electricity - production:
3.613 billion kWh (2001)
Electricity - consumption:
3.36 billion kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
0 kWh (2001)
Oil - production:
76,650 bbl/day (2001 est.)
Oil - consumption:
22,000 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Oil - proved reserves:
200 million bbl (1 January 2002)
Natural gas - production:
0 cu m (2001 est.)
Natural gas - consumption:
0 cu m (2001 est.)
Natural gas - exports:
0 cu m (2001 est.)
Natural gas - imports:
0 cu m (2001 est.)
Natural gas - proved reserves:
55.22 billion cu m (1 January 2002)
Current account balance:
$-564 million (2003)
Exports:
$1.873 billion f.o.b. (2003 est.)
Exports - commodities:
crude oil and petroleum products, lumber, cocoa beans, aluminum,
coffee, cotton
Exports - partners:
Spain 21.9%, Italy 13.4%, France 10.8%, Netherlands 10.6%, US 7.5%,
China 4.4% (2003)
Imports:
$1.959 billion f.o.b. (2003 est.)
Imports - commodities:
machinery, electrical equipment, transport equipment, fuel, food
Imports - partners:
France 21.9%, Nigeria 9.5%, Japan 6.8%, US 5.7%, China 4.9%,
Germany 4.3% (2003)
Reserves of foreign exchange & gold:
$634 million (2003)
Debt - external:
$7.236 billion (2003 est.)
Economic aid - recipient:
on 23 January 2001, the Paris Club agreed to reduce Cameroon''s debt
of $1.3 billion by $900 million; debt relief now totals $1.26 billion
Currency:
Communaute Financiere Africaine franc (XAF); note - responsible
authority is the Bank of the Central African States
Currency code:
XAF
Exchange rates:
Communaute Financiere Africaine francs (XAF) per US dollar - 581.2
(2003), 696.988 (2002), 733.039 (2001), 711.976 (2000), 615.699
(1999)
Fiscal year:
1 July - 30 June
Communications Cameroon
Telephones - main lines in use:
110,900 (2002)
Telephones - mobile cellular:
1.077 million (2003)
Telephone system:
general assessment: available only to business and government
domestic: cable, microwave radio relay, and tropospheric scatter
international: country code - 237; satellite earth stations - 2
Intelsat (Atlantic Ocean); fiber optic submarine cable (SAT-3/WASC)
provides connectivity to Europe and Asia
Radio broadcast stations:
AM 2, FM 9, shortwave 3 (2002)
Radios:
2.27 million (1997)
Television broadcast stations:
1 (2002)
Televisions:
450,000 (1997)
Internet country code:
.cm
Internet hosts:
479 (2004)
Internet Service Providers (ISPs):
1 (2002)
Internet users:
60,000 (2002)
note: Cameroon also had more than 100 cyber-cafes in 2001
Transportation Cameroon
Railways:
total: 1,008 km
narrow gauge: 1,008 km 1.000-m gauge (2003)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1999 est.)
Waterways:
navigation mainly on Benue River; limited during rainy season (2004)
Pipelines:
gas 90 km; liquid petroleum gas 9 km; oil 1,120 km (2004)
Ports and harbors:
Bonaberi, Douala, Garoua, Kribi, Tiko
Merchant marine:
total: 1 ships (1,000 GRT or over) 169,593 GRT/357,023 DWT
by type: petroleum tanker 1 (2004 est.)
Airports:
47 (2003 est.)
Airports - with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 7
914 to 1,523 m: 20
under 914 m: 9 (2004 est.)
Military Cameroon
Military branches:
Army, Navy (includes Naval Infantry), Air Force
Military manpower - military age and obligation:
18 years of age for voluntary military service; no conscription
(1999)
Military manpower - availability:
males age 15-49: 3,898,944 (2004 est.)
Military manpower - fit for military service:
males age 15-49: 1,979,151 (2004 est.)
Military manpower - reaching military age annually:
males: 184,054 (2004 est.)
Military expenditures - dollar figure:
$189.2 million (2003)
Military expenditures - percent of GDP:
1.4% (2003)
Transnational Issues Cameroon
Disputes - international:
ICJ ruled in 2002 on the entire Cameroon-Nigeria land and maritime
boundary but the parties formed a Joint Border Commission to resolve
differences bilaterally and have commenced with demarcation in
less-contested sections of the boundary, starting in Lake Chad in
the north; the ICF ruled on an equidistance settlement of
Cameroon-Equatorial Guinea-Nigeria maritime boundary in the Gulf of
Guinea, however, implementation of the decision is delayed due to
imprecisely defined coordinates, the unresolved Bakasi allocation,
and a sovereignty dispute between Equatorial Guinea and Cameroon
over an island at the mouth of the Ntem River; Nigeria initially
rejected cession of the Bakasi Peninsula; Lake Chad Commission
continues to urge signatories Cameroon, Chad, Niger, and Nigeria to
ratify delimitation treaty over the lake region, which remains the
site of armed clashes among local populations and militias
Refugees and internally displaced persons:
refugees (country of origin): 39,261 (Chad), 16,983 (Nigeria),
9,634 (Cote d''Ivoire) (2004)
This page was last updated on 10 February, 2005
======================================================================
@Canada
Introduction Canada
French Togoland became Togo in 1960. Gen. Gnassingbe EYADEMA,
installed as military ruler in 1967, is Africa''s longest-serving
head of state. Despite the facade of multiparty elections instituted
in the early 1990s, the government continues to be dominated by
President EYADEMA, whose Rally of the Togolese People (RPT) party
has maintained power almost continually since 1967. In addition,
Togo has come under fire from international organizations for human
rights abuses and is plagued by political unrest. While most
bilateral and multilateral aid to Togo remains frozen, the European
Union initiated a partial resumption of cooperation and development
aid to Togo in late 2004.
total: 2
2,438 to 3,047 m: 2 (2004 est.)
total: 7
914 to 1,523 m: 5
under 914 m: 2 (2004 est.)
deforestation attributable to slash-and-burn agriculture and
the use of wood for fuel; water pollution presents health hazards
and hinders the fishing industry; air pollution increasing in urban
areas
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
1.9% (2003)
101.6 million kWh (2001)
614.5 million kWh (2001)
520 million kWh; note - electricity supplied by Ghana (2001)
0 kWh (2001)
32% (1989 est.)
lowest 10%: NA
highest 10%: NA
agriculture 65%, industry 5%, services 30% (1998 est.)
reexports, cotton, phosphates, coffee, cocoa
Burkina Faso 16.6%, Ghana 15.4%, Netherlands 13%, Benin 9.6%,
Mali 7.7% (2003)
5 regions (regions, singular - region); Kara, Plateaux,
Savanes, Centrale, Maritime
coffee, cocoa, cotton, yams, cassava (tapioca), corn, beans,
rice, millet, sorghum; livestock; fish
9 (2003 est.)
34.36 births/1,000 population (2004 est.)
Army, Navy, Air Force, Gendarmerie
revenues: $214.5 million
expenditures: $296.4 million, including capital expenditures of NA
(2003 est.)
This small sub-Saharan economy is heavily dependent on both
commercial and subsistence agriculture, which provides employment
for 65% of the labor force. Some basic foodstuffs must still be
imported. Cocoa, coffee, and cotton generate about 40% of export
earnings, with cotton being the most important cash crop. Togo is
the world''s fourth-largest producer of phosphate, but production
fell an estimated 22% in 2002 due to power shortages and the cost of
developing new deposits. The government''s decade-long effort,
supported by the World Bank and the IMF, to implement economic
reform measures, encourage foreign investment, and bring revenues in
line with expenditures has moved slowly. Progress depends on
following through on privatization, increased openness in government
financial operations, progress toward legislative elections, and
continued support from foreign donors.','cad564be4797d583e31fa352ca1618fa5012d8a87c4e7c4c8f7fbf5738a66182','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad855dc500384b8d61c6825c93bf400297d191b284836f018880a7938055d97',2004,'FR','France','economy',200,'GDP:
purchasing power parity - $73.7 billion (2003 est.)
GDP - real growth rate:
5.5% (2003 est.)
GDP - per capita:
purchasing power parity - $3,700 (2003 est.)
GDP - composition by sector:
agriculture: 19.9%
industry: 26.3%
services: 53.8% (2003)
Investment (gross fixed):
22.7% of GDP (2003)
Population below poverty line:
22% (1997 est.)
Household income or consumption by percentage share:
lowest 10%: 3.5%
highest 10%: 28% (1995)
Distribution of family income - Gini index:
34.4 (1995)
Inflation rate (consumer prices):
6.3% (2003 est.)
Labor force:
7.17 million (2003)
Labor force - by occupation:
agriculture 38%, industry 17%, services 45% (1998 est.)
Unemployment rate:
8.4% (2003)
Budget:
revenues: $3.229 billion
expenditures: $4.526 billion, including capital expenditures of NA
(2003 est.)
Public debt:
105.1% of GDP (2003)
Agriculture - products:
rice, sugarcane, grains, pulses, oilseed, spices, tea, rubber,
coconuts; milk, eggs, hides, beef
Industries:
rubber processing, tea, coconuts, and other agricultural
commodities; clothing, cement, petroleum refining, textiles, tobacco
Industrial production growth rate:
5.8% (2003)
Electricity - production:
6.36 billion kWh (2001)
Electricity - consumption:
5.915 billion kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
0 kWh (2001)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
75,000 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Current account balance:
$-278 million (2003)
Exports:
$5.269 billion f.o.b. (2003 est.)
Exports - commodities:
textiles and apparel, tea, diamonds, coconut products, petroleum
products
Exports - partners:
US 34.6%, UK 12.5%, India 4.8%, Germany 4.5% (2003)
Imports:
$6.626 billion f.o.b. (2003 est.)
Imports - commodities:
textiles, mineral products, petroleum, foodstuffs, machinery and
equipment
Imports - partners:
India 16.1%, Hong Kong 8.4%, Singapore 7.8%, Japan 6.7%, China
4.9%, South Korea 4.2%, Taiwan 4.2%, UK 4.1%, Malaysia 4% (2003)
Reserves of foreign exchange & gold:
$2.273 billion (2003)
Debt - external:
$10.52 billion (2003)
Economic aid - recipient:
$577 million (1998)
Currency:
Sri Lankan rupee (LKR)
Currency code:
LKR
Exchange rates:
Sri Lankan rupees per US dollar - 96.521 (2003), 95.6621 (2002),
89.383 (2001), 77.0051 (2000), 70.6354 (1999)
Fiscal year:
calendar year
Communications Sri Lanka
Telephones - main lines in use:
881,400 (2002)
Telephones - mobile cellular:
931,600 (2002)
Telephone system:
general assessment: very inadequate domestic service, particularly
in rural areas; likely improvement with privatization of national
telephone company and encouragement to private investment; good
international service (1999)
domestic: national trunk network consists mostly of digital
microwave radio relay; fiber-optic links now in use in Colombo area
and two fixed wireless local loops have been installed; competition
is strong in mobile cellular systems; telephone density remains low
at 2.6 main lines per 100 persons (1999)
international: country code - 94; submarine cables to Indonesia and
Djibouti; satellite earth stations - 2 Intelsat (Indian Ocean) (1999)
Radio broadcast stations:
AM 26, FM 45, shortwave 1 (1998)
Radios:
3.85 million (1997)
Television broadcast stations:
21 (1997)
Televisions:
1.53 million (1997)
Internet country code:
.lk
Internet hosts:
1,882 (2003)
Internet Service Providers (ISPs):
5 (2000)
Internet users:
200,000 (2002)
Transportation Sri Lanka
Railways:
total: 1,449 km
broad gauge: 1,449 km 1.676-m gauge (2003)
Highways:
total: 96,695 km
paved: 91,860 km
unpaved: 4,835 km (1999)
Waterways:
160 km (primarily on rivers in southwest) (2004)
Ports and harbors:
Colombo, Galle, Jaffna, Trincomalee
Merchant marine:
total: 18 ships (1,000 GRT or over) 120,924 GRT/173,604 DWT
by type: cargo 14, container 2, petroleum tanker 2
registered in other countries: 4 (2004 est.)
foreign-owned: Germany 8, Singapore 1
Airports:
14 (2003 est.)
Airports - with paved runways:
total: 13
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 6 (2004 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2004 est.)
Military Sri Lanka
Military branches:
Army, Navy, Air Force, Police Force
Military manpower - military age and obligation:
18 years of age for voluntary military service (2001)
Military manpower - availability:
males age 15-49: 5,418,496 (2004 est.)
Military manpower - fit for military service:
males age 15-49: 4,195,736 (2004 est.)
Military manpower - reaching military age annually:
males: 179,869 (2004 est.)
Military expenditures - dollar figure:
$518 million (2003)
Military expenditures - percent of GDP:
3.2% (2003)
Transnational Issues Sri Lanka
Disputes - international:
none
Refugees and internally displaced persons:
IDPs: 362,000 (both Tamils and non-Tamils displaced due to Tamil
conflict) (2004)
This page was last updated on 10 February, 2005
======================================================================
@Sudan
Introduction Sudan
total: 283
over 3,047 m: 13
2,438 to 3,047 m: 28
1,524 to 2,437 m: 95
914 to 1,523 m: 82
under 914 m: 65 (2004 est.)
total: 195
1,524 to 2,437 m: 3
914 to 1,523 m: 72
under 914 m: 120 (2004 est.)
some forest damage from acid rain; air pollution from
industrial and vehicle emissions; water pollution from urban wastes,
agricultural runoff
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
2.6% (2003)
520.1 billion kWh (2001)
415.3 billion kWh (2001)
4.2 billion kWh (2001)
72.6 billion kWh (2001)
6.5% (2000)
lowest 10%: 2.8%
highest 10%: 25.1% (1995)
agriculture 4.1%, industry 24.4%, services 71.5% (1999)
machinery and transportation equipment, aircraft, plastics,
chemicals, pharmaceutical products, iron and steel, beverages
Germany 14.9%, Spain 9.6%, UK 9.4%, Italy 9.3%, Belgium 7.2%,
US 6.8% (2003)
22 regions (regions, singular - region); Alsace, Aquitaine,
Auvergne, Basse-Normandie, Bourgogne, Bretagne, Centre,
Champagne-Ardenne, Corse, Franche-Comte, Haute-Normandie,
Ile-de-France, Languedoc-Roussillon, Limousin, Lorraine,
Midi-Pyrenees, Nord-Pas-de-Calais, Pays de la Loire, Picardie,
Poitou-Charentes, Provence-Alpes-Cote d''Azur, Rhone-Alpes
note: metropolitan France is divided into 22 regions (including the
"territorial collectivity" of Corse or Corsica) and is subdivided
into 96 departments; see separate entries for the overseas
departments (French Guiana, Guadeloupe, Martinique, Reunion) and the
overseas territorial collectivities (Mayotte, Saint Pierre and
Miquelon)
wheat, cereals, sugar beets, potatoes, wine grapes; beef,
dairy products; fish
477 (2003 est.)
12.34 births/1,000 population (2004 est.)
Army (includes Marines, Foreign Legion, Army Light Aviation),
Navy (including naval air), Air Force (including Air Defense),
National Gendarmerie
revenues: $882.8 billion
expenditures: $955.4 billion, including capital expenditures of $23
billion (2003 est.)
France is in the midst of transition, from a well-to-do
modern economy that has featured extensive government ownership and
intervention to one that relies more on market mechanisms. The
Socialist-led government partially or fully privatized many large
companies, banks, and insurers, but the government retains
controlling stakes in several leading firms, including Air France,
France Telecom, Renault, and Thales, and is dominant in some
sectors, particularly power, public transport, and defense
industries. The telecommunications sector is gradually being opened
to competition. France''s leaders remain committed to a capitalism in
which they maintain social equity by means of laws, tax policies,
and social spending that reduce income disparity and the impact of
free markets on public health and welfare. The current government
has lowered income taxes and introduced measures to boost
employment. The government is focusing on the problems of the high
cost of labor and labor market inflexibility resulting from the
35-hour workweek and restrictions on lay-offs. The government is
also pushing for pension reforms and simplification of
administrative procedures. The tax burden remains one of the highest
in Europe (43.8% of GDP in 2003). The current economic slowdown and
inflexible budget items have pushed the 2003 deficit to 4% of GDP,
above the EU''s 3% debt limit. Business investment remains listless
because of low rates of capital utilization, sluggish demand, high
debt, and the steep cost of capital.
gas 14,232 km; oil 3,024 km; refined products 4,889 km (2004)','17b846da17f94df0d14d90e7e69553a6f7b027f868660d102ac201bfee9fa276','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('631c55936a4508678e4541732c12cb1061aa587dea3464ff11016ffb65a4def6',2004,'SA','Saudi Arabia','economy',606,'In 1902, ABD AL-AZIZ bin Abd al-Rahman Al Saud captured
Riyadh and set out on a 30-year campaign to unify the Arabian
Peninsula. Today, the monarchy is ruled by a son of ABD AL-AZIZ, and
the country''s Basic Law stipulates that the throne shall remain in
the hands of the aging sons and grandsons of the kingdom''s founder.
Following Iraq''s invasion of Kuwait in 1990, Saudi Arabia accepted
the Kuwaiti royal family and 400,000 refugees while allowing Western
and Arab troops to deploy on its soil for the liberation of Kuwait
the following year. The continuing presence of foreign troops on
Saudi soil after Operation Desert Storm remained a source of tension
between the royal family and the public until the US military''s
near-complete withdrawal to neighboring Qatar in 2003. The first
major terrorist attacks in Saudi Arabia in several years, which
occurred in May and November 2003, prompted renewed efforts on the
part of the Saudi government to counter domestic terrorism and
extremism, which also coincided with a slight upsurge in media
freedom and announcement of government plans to phase in partial
political representation. A burgeoning population, aquifer
depletion, and an economy largely dependent on petroleum output and
prices are all ongoing governmental concerns.
total: 72
over 3,047 m: 32
2,438 to 3,047 m: 13
1,524 to 2,437 m: 23
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
total: 129
over 3047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 72
914 to 1,523 m: 39
under 914 m: 12 (2004 est.)
desertification; depletion of underground water
resources; the lack of perennial rivers or permanent water bodies
has prompted the development of extensive seawater desalination
facilities; coastal pollution from oil spills
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
10% (2002)
122.4 billion kWh (2001)
113.8 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 12%, industry 25%, services 63% (1999 est.)
petroleum and petroleum products 90%
US 20.6%, Japan 15.4%, South Korea 9.8%, China 5.5%,
Taiwan 4.5%, Singapore 4.1% (2003)
13 provinces (mintaqat, singular - mintaqah); Al Bahah,
Al Hudud ash Shamaliyah, Al Jawf, Al Madinah, Al Qasim, Ar Riyad,
Ash Sharqiyah (Eastern Province), ''Asir, Ha''il, Jizan, Makkah,
Najran, Tabuk
wheat, barley, tomatoes, melons, dates, citrus; mutton,
chickens, eggs, milk
204 (2003 est.)
29.74 births/1,000 population (2004 est.)
Land Force (Army), Navy, Air Force, Air Defense Force,
National Guard, Ministry of Interior Forces (paramilitary)
revenues: $78.77 billion
expenditures: $66.76 billion, including capital expenditures of NA
(2003 est.)
This is an oil-based economy with strong government
controls over major economic activities. Saudi Arabia has the
largest reserves of petroleum in the world (25% of the proved
reserves), ranks as the largest exporter of petroleum, and plays a
leading role in OPEC. The petroleum sector accounts for roughly 75%
of budget revenues, 45% of GDP, and 90% of export earnings. About
40% of GDP comes from the private sector. Roughly five and a half
million foreign workers play an important role in the Saudi economy,
for example, in the oil and service sectors. The government in 1999
announced plans to begin privatizing the electricity companies,
which follows the ongoing privatization of the telecommunications
company. The government is encouraging private sector growth to
lessen the kingdom''s dependence on oil and increase employment
opportunities for the swelling Saudi population. Priorities for
government spending in the short term include additional funds for
education and for the water and sewage systems. Economic reforms
proceed cautiously because of deep-rooted political and social
conservatism.
condensate 212 km; gas 1,780 km; liquid petroleum gas
1,191 km; oil 5,068 km; refined products 1,162 km (2004)','691885649e35d7caa42ce7d9c3dc8dd7f2fae0acf4cae042d354e719fa8a4e79','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af9a42a73ba68950f25c27b0e22e6a2e40e11877353a55e2b6fc7625430aa7e4',2004,'SN','Senegal','economy',607,'Independent from France in 1960, Senegal joined with The
Gambia to form the nominal confederation of Senegambia in 1982.
However, the envisaged integration of the two countries was never
carried out, and the union was dissolved in 1989. Despite peace
talks, a southern separatist group sporadically has clashed with
government forces since 1982. Senegal has a long history of
participating in international peacekeeping.
Serbia and Montenegro
The Kingdom of Serbs, Croats, and Slovenes was
formed in 1918; its name was changed to Yugoslavia in 1929.
Occupation by Nazi Germany in 1941 was resisted by various
paramilitary bands that fought each other as well as the invaders.
The group headed by Marshal TITO took full control upon German
expulsion in 1945. Although Communist, his new government and its
successors (he died in 1980) managed to steer their own path between
the Warsaw Pact nations and the West for the next four and a half
decades. In the early 1990s, post-TITO Yugoslavia began to unravel
along ethnic lines: Slovenia, Croatia, Macedonia, and Bosnia and
Herzegovina were recognized as independent states in 1992. The
remaining republics of Serbia and Montenegro declared a new "Federal
Republic of Yugoslavia" (FRY) in April 1992 and, under President
Slobodan MILOSEVIC, Serbia led various military intervention efforts
to unite ethnic Serbs in neighboring republics into a "Greater
Serbia." All of these efforts were ultimately unsuccessful and led
to Yugoslavia being ousted from the UN in 1992. In 1998-99, massive
expulsions by FRY forces and Serb paramilitaries of ethnic Albanians
living in Kosovo provoked an international response, including the
NATO bombing of Serbia and the stationing of a NATO-led force
(KFOR), in Kosovo. Federal elections in the fall of 2000, brought
about the ouster of MILOSEVIC and installed Vojislav KOSTUNICA as
president. The arrest of MILOSEVIC in 2001 allowed for his
subsequent transfer to the International Criminal Tribunal for the
Former Yugoslavia in The Hague to be tried for crimes against
humanity. In 2001, the country''s suspension from the UN was lifted,
and it was once more accepted into UN organizations under the name
of the Federal Republic of Yugoslavia. Kosovo has been governed by
the UN Interim Administration Mission in Kosovo (UNMIK) since June
1999, under the authority of UN Security Council Resolution 1244,
pending a determination by the international community of its future
status. In 2002, the Serbian and Montenegrin components of
Yugoslavia began negotiations to forge a looser relationship. These
talks became a reality in February 2003 when lawmakers restructured
the country into a loose federation of two republics called Serbia
and Montenegro. The Constitutional Charter of Serbia and Montenegro
includes a provision that allows either republic to hold a
referendum after three years that would allow for their independence
from the state union.
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 2 (2004 est.)
Serbia and Montenegro
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m: 2
under 914 m: 4 (2004 est.)
total: 11
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
Serbia and Montenegro
total: 25
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 13 (2004 est.)
wildlife populations threatened by poaching; deforestation;
overgrazing; soil erosion; desertification; overfishing
Serbia and Montenegro
pollution of coastal waters from sewage
outlets, especially in tourist-related areas such as Kotor; air
pollution around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava which flows
into the Danube
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
Serbia and Montenegro
party to: Air Pollution, Biodiversity, Climate
Change, Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.5% (2003)
Serbia and Montenegro
NA
1.518 billion kWh (2001)
Serbia and Montenegro
31.71 billion kWh (2001)
1.412 billion kWh (2001)
Serbia and Montenegro
32.37 billion kWh (2001)
0 kWh (2001)
Serbia and Montenegro
3.33 billion kWh (2001)
0 kWh (2001)
Serbia and Montenegro
446 million kWh (2001)
54% (2001 est.)
Serbia and Montenegro
30% (1999 est.)
lowest 10%: 2.6%
highest 10%: 33.5% (1995)
Serbia and Montenegro
lowest 10%: NA
highest 10%: NA
agriculture 70%
Serbia and Montenegro
agriculture NA, industry NA, services NA
fish, groundnuts (peanuts), petroleum products, phosphates,
cotton
Serbia and Montenegro
manufactured goods, food and live animals, raw
materials
India 13%, France 12.2%, Mali 9.5%, Italy 8.5%, Cote
d''Ivoire 5.4%, Spain 5% (2003)
Serbia and Montenegro
Italy 31.6%, Germany 17.5%, Austria 6.2%,
France 6%, Greece 5.4%, Slovenia 4.1%, Hungary 4% (2003)
11 regions (regions, singular - region); Dakar, Diourbel,
Fatick, Kaolack, Kolda, Louga, Matam, Saint-Louis, Tambacounda,
Thies, Ziguinchor
Serbia and Montenegro
2 republics (republike, singular - republika);
and 2 nominally autonomous provinces* (autonomn pokrajine, singular
- autonomna pokrajina); Kosovo* (currently under UN administration
pending resolution of its future status), Montenegro, Serbia,
Vojvodina*
peanuts, millet, corn, sorghum, rice, cotton, tomatoes,
green vegetables; cattle, poultry, pigs; fish
Serbia and Montenegro
cereals, fruits, vegetables, tobacco, olives;
cattle, sheep, goats
20 (2003 est.)
Serbia and Montenegro
45 (2003 est.)
35.72 births/1,000 population (2004 est.)
Serbia and Montenegro
12.13 births/1,000 population (2004 est.)
Army, Navy, Air Force, National Gendarmerie, National Police
(Surete Nationale)
Serbia and Montenegro
Army (VJ) (including ground forces with border
troops, naval forces, air and air defense forces)
revenues: $1.304 billion
expenditures: $1.367 billion, including capital expenditures of $357
million (2003 est.)
Serbia and Montenegro
revenues: $8.668 billion
expenditures: $9.633 billion, including capital expenditures of NA
(2003 est.)
In January 1994, Senegal undertook a bold and ambitious
economic reform program with the support of the international donor
community. This reform began with a 50% devaluation of Senegal''s
currency, the CFA franc, which was linked at a fixed rate to the
French franc. Government price controls and subsidies have been
steadily dismantled. After seeing its economy contract by 2.1% in
1993, Senegal made an important turnaround, thanks to the reform
program, with real growth in GDP averaging 5% annually during
1995-2003. Annual inflation had been pushed down to the low single
digits. As a member of the West African Economic and Monetary Union
(WAEMU), Senegal is working toward greater regional integration with
a unified external tariff. Senegal also realized full Internet
connectivity in 1996, creating a miniboom in information
technology-based services. Private activity now accounts for 82% of
GDP. On the negative side, Senegal faces deep-seated urban problems
of chronic unemployment, trade union militancy, juvenile
delinquency, and drug addiction.
Serbia and Montenegro
MILOSEVIC-era mismanagement of the economy, an
extended period of economic sanctions, and the damage to
Yugoslavia''s infrastructure and industry during the NATO airstrikes
in 1999 have left the economy only half the size it was in 1990.
After the ousting of former Federal Yugoslav President MILOSEVIC in
October 2000, the Democratic Opposition of Serbia (DOS) coalition
government implemented stabilization measures and embarked on an
aggressive market reform program. After renewing its membership in
the IMF in December 2000, Yugoslavia continued to reintegrate into
the international community by rejoining the World Bank (IBRD) and
the European Bank for Reconstruction and Development (EBRD). A World
Bank-European Commission sponsored Donors'' Conference held in June
2001 raised $1.3 billion for economic restructuring. An agreement
rescheduling the country''s $4.5 billion Paris Club government debts
was concluded in November 2001; it wrote off 66% of the debt. The
smaller republic of Montenegro severed its economy from federal
control and from Serbia during the MILOSEVIC era and continues to
maintain its own central bank, uses the euro instead of the Yugoslav
dinar as official currency, collects customs tariffs, and manages
its own budget. Kosovo, while technically still part of the Federal
Republic of Yugoslavia (now Serbia and Montenegro) according to
United Nations Security Council Resolution 1244, is largely
autonomous under United Nations Interim Administration Mission in
Kosovo (UNMIK) and is greatly dependent on the international
community and the diaspora for financial and technical assistance.
The euro and the Yugoslav dinar are official currencies, and UNMIK
collects taxes and manages the budget. The complexity of Serbia and
Montenegro political relationships, slow progress in privatization,
legal uncertainty over property rights, and scarcity of
foreign-investment are holding back Serbia and Montenegro''s economy.
Arrangements with the IMF, especially requirements for fiscal
discipline, are an important element in policy formation. Severe
unemployment remains a key political economic problem.
gas 564 km (2004)
Serbia and Montenegro
gas 3,177 km; oil 393 km (2004)','8fedd45d664b9be54e536bbc671ca714c8e9be3b41b5f0326698a24ec10dd82c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4df4e0816dd3dbed8f1d63866a329a7275901c8d2bcbf419e79803ce94c37007',2004,'SC','Seychelles','economy',608,'A lengthy struggle between France and Great Britain for
the islands ended in 1814, when they were ceded to the latter.
Independence came in 1976. Socialist rule was brought to a close
with a new constitution and free elections in 1993. The most recent
presidential elections were held 31 August-2 September 2001.
President RENE, who has served since 1977, was re-elected. On 14
April 2004 RENE stepped down and Vice President James MICHEL was
sworn in as president.
total: 8
2,438 to 3,047 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2004 est.)
water supply depends on catchments to collect rainwater
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
1.8% (2003)
160 million kWh (2001)
148.8 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 10%, industry 19%, services 71% (1989)
canned tuna, frozen fish, cinnamon bark, copra, petroleum
products (reexports)
UK 38.8%, France 31.8%, Italy 14.5%, Germany 7.5% (2003)
23 administrative districts; Anse aux Pins, Anse Boileau,
Anse Etoile, Anse Louis, Anse Royale, Baie Lazare, Baie Sainte Anne,
Beau Vallon, Bel Air, Bel Ombre, Cascade, Glacis, Grand'' Anse (on
Mahe), Grand'' Anse (on Praslin), La Digue, La Riviere Anglaise, Mont
Buxton, Mont Fleuri, Plaisance, Pointe La Rue, Port Glaud, Saint
Louis, Takamaka
coconuts, cinnamon, vanilla, sweet potatoes, cassava
(tapioca), bananas; broiler chickens; tuna fish
15 (2003 est.)
16.55 births/1,000 population (2004 est.)
Army, Coast Guard (including Navy Wing, Air Wing),
National Guard, Presidential Protection Unit (includes Presidential
Guard), Seychelles National Police (includes Police Mobile Unit)
revenues: $338.7 million
expenditures: $323.3 million, including capital expenditures of NA
(2003 est.)
Since independence in 1976, per capita output in this
Indian Ocean archipelago has expanded to roughly seven times the old
near-subsistence level. Growth has been led by the tourist sector,
which employs about 30% of the labor force and provides more than
70% of hard currency earnings, and by tuna fishing. In recent years
the government has encouraged foreign investment in order to upgrade
hotels and other services. At the same time, the government has
moved to reduce the dependence on tourism by promoting the
development of farming, fishing, and small-scale manufacturing. A
sharp drop illustrated the vulnerability of the tourist sector in
1991-92 due largely to the Gulf war, and once again following the 11
September 2001 terrorist attacks on the US. Other issues facing the
government are the curbing of the budget deficit, including the
containment of social welfare costs, and further privatization of
public enterprises. Growth slowed in 1998-2002, due to sluggish
tourist and tuna sectors. Also, tight controls on exchange rates and
the scarcity of foreign exchange have impaired short-term economic
prospects. The black market value of the Seychelles rupee is half
the official exchange rate; without a devaluation of the currency
the tourist sector should remain sluggish as vacationers seek
cheaper destinations such as Comoros, Mauritius, and Madagascar.','e249b2adfe505e53252d96b0a759f274a332493d2e1cd341682d1f8b3632bf23','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01650425f0dc85c9ff78a43ccd4d71e89a8649846e8d320c3c2f44a1806aeba0',2004,'SL','Sierra Leone','economy',609,'The 1991 to 2002 civil war between the government and
the Revolutionary United Front (RUF) resulted in tens of thousands
of deaths and the displacement of more than 2 million people (well
over one-third of the population), many of whom are now refugees in
neighboring countries. With the support of the UN peacekeeping force
and contributions from the World Bank and international community,
demobilization and disarmament of the RUF and Civil Defense Forces
(CDF) combatants has been completed. National elections were held in
May 2002 and the government continues to slowly reestablish its
authority. However, the gradual withdrawal of most UN Mission in
Sierra Leone (UNAMSIL) peacekeepers in 2004 and early 2005,
deteriorating political and economic conditions in Guinea, and the
tenuous security situation in neighboring Liberia may present
challenges to the continuation of Sierra Leone''s stability.
total: 1
over 3,047 m: 1 (2004 est.)
total: 9
914 to 1,523 m: 7
under 914 m: 2 (2004 est.)
rapid population growth pressuring the environment;
overharvesting of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.5% (2003)
250.1 million kWh (2001)
232.6 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
68% (1989 est.)
lowest 10%: 0.5%
highest 10%: 43.6% (1989)
agriculture NA, industry NA, services NA
diamonds, rutile, cocoa, coffee, fish (1999)
Belgium 61.2%, Germany 14.2%, UK 4.5%, US 4.5% (2003)
3 provinces and 1 area*; Eastern, Northern, Southern,
Western*
rice, coffee, cocoa, palm kernels, palm oil, peanuts;
poultry, cattle, sheep, pigs; fish
10 (2003 est.)
43.34 births/1,000 population (2004 est.)
Army (RSLAF)
revenues: $96 million
expenditures: $351 million, including capital expenditures of NA
(2000 est.)
Sierra Leone is an extremely poor African nation with
tremendous inequality in income distribution. It does have
substantial mineral, agricultural, and fishery resources. However,
the economic and social infrastructure is not well developed, and
serious social disorders continue to hamper economic development,
following a 11-year civil war. About two-thirds of the working-age
population engages in subsistence agriculture. Manufacturing
consists mainly of the processing of raw materials and of light
manufacturing for the domestic market. Plans continue to reopen
bauxite and rutile mines shut down during the conflict. The major
source of hard currency consists of the mining of diamonds. The fate
of the economy depends upon the maintenance of domestic peace and
the continued receipt of substantial aid from abroad, which is
essential to offset the severe trade imbalance and to supplement
government revenues.','73b9c112775a5e241a2c3c3de6d8d2adb92f6d73828848d17d71a0f1b5c166c5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39317af70fb25a9b34399a41a0e00f465522040a90887a026fdf598be51d8e20',2004,'SG','Singapore','economy',610,'Singapore was founded as a British trading colony in 1819.
It joined the Malaysian Federation in 1963 but separated two years
later and became independent. It subsequently became one of the
world''s most prosperous countries with strong international trading
links (its port is the world''s busiest in terms of tonnage handled)
and with per capita GDP equal to that of the leading nations of
Western Europe.
total: 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
industrial pollution; limited natural fresh water
resources; limited land availability presents waste disposal
problems; seasonal smoke/haze resulting from forest fires in
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
4.9% (FY01)
30.48 billion kWh (2001)
28.35 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
manufacturing 18%, construction 6%, transportation and
communication 11%, financial, business, and other services 49%,
other 16% (2003)
machinery and equipment (including electronics), consumer
goods, chemicals, mineral fuels
Malaysia 15.8%, US 14.3%, Hong Kong 10%, China 7%, Japan
6.7%, Taiwan 4.7%, Thailand 4.3%, South Korea 4.2% (2003)
none
rubber, copra, fruit, orchids, vegetables, poultry, eggs,
fish, ornamental fish
9 (2003 est.)
9.63 births/1,000 population (2004 est.)
Army, Navy, Air Force, People''s Defense Force
revenues: $14.15 billion
expenditures: $15.61 billion, including capital expenditures of $5.6
billion (2003 est.)
Singapore, a highly developed and successful free market
economy, enjoys a remarkably open and corruption-free environment,
stable prices, and a high per capita GDP. The economy depends
heavily on exports, particularly in electronics and manufacturing.
It was hard hit in 2001-03 by the global recession and the slump in
the technology sector. The government hopes to establish a new
growth path that will be less vulnerable to the external business
cycle but is unlikely to abandon efforts to establish Singapore as
Southeast Asia''s financial and high-tech hub. Fiscal stimulus, low
interest rates, and global economic recovery should lead to much
improved growth in 2004.
gas 139 km (2004)','27cacbaaf83a075416e0c53eb81cfacd79505c6ccb2e940e3e7c532d87944a37','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489462b1dc59719b7caf747ff41d5994340c3fe564b0584aac03249e00318d9b',2004,'SK','Slovakia','economy',611,'In 1918 the Slovaks joined the closely related Czechs to
form Czechoslovakia. Following the chaos of World War II,
Czechoslovakia became a Communist nation within Soviet-ruled Eastern
Europe. Soviet influence collapsed in 1989 and Czechoslovakia once
more became free. The Slovaks and the Czechs agreed to separate
peacefully on 1 January 1993. Slovakia joined both NATO and the EU
in the spring of 2004.
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 7 (2004 est.)
total: 17
2,438 to 3,047 m: 1
914 to 1,523 m: 9
under 914 m: 7 (2004 est.)
air pollution from metallurgical plants presents human
health risks; acid rain damaging forests
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.89% (2002)
30.29 billion kWh (2001)
24.41 billion kWh (2001)
1.381 billion kWh (2001)
5.141 billion kWh (2001)
NA
lowest 10%: 5.1%
highest 10%: 18.2% (1992)
agriculture 8.9%, industry 29.3%, construction 8%,
transport and communication 8.2%, services 45.6% (1994)
machinery and transport equipment 39.4%, intermediate
manufactured goods 27.5%, miscellaneous manufactured goods 13%,
chemicals 8% (1999)
Germany 37.2%, Czech Republic 12%, Austria 9.8%, Italy
5.4%, Poland 4.7%, US 4.7%, Hungary 4.2% (2003)
8 regions (kraje, singular - kraj); Banskobystricky,
Bratislavsky, Kosicky, Nitriansky, Presovsky, Trenciansky, Trnavsky,
Zilinsky
grains, potatoes, sugar beets, hops, fruit; pigs, cattle,
poultry; forest products
34 (2003 est.)
10.57 births/1,000 population (2004 est.)
Ground Forces (including Home Guard [Domobrana]), Air and
Air Defense Forces (January 2003)
revenues: $12.03 billion
expenditures: $13.69 billion, including capital expenditures of NA
(2003)
Slovakia has mastered much of the difficult transition from
a centrally planned economy to a modern market economy. The DZURINDA
government made excellent progress during 2001-03 in macroeconomic
stabilization and structural reform. Major privatizations are nearly
complete, the banking sector is almost completely in foreign hands,
and foreign investment has picked up. Slovakia''s economy exceeded
expectations in 2001-03, despite the general European slowdown.
Unemployment, at an unacceptable 15% in 2003, remains the economy''s
Achilles heel. The government faces other strong challenges in 2004,
especially cutting the budget deficit, containing inflation, and
strengthening the health care system.
gas 6,769 km; oil 449 km (2004)','7a891d6cd2d29c93fe3e4798eb61a9c446c73f9c4dced43e1e08f63eb98bc1e5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c5a4ed3edf33a7ba3c4cbb4957d409e9c991ed145da46b80c8beca01c4bedb2',2004,'SI','Slovenia','economy',612,'The Slovene lands were part of the Holy Roman Empire and
Austria until 1918 when the Slovenes joined the Serbs and Croats in
forming a new multinational state, renamed Yugoslavia in 1929. After
World War II, Slovenia became a republic of the renewed Yugoslavia,
which though Communist, distanced itself from Moscow''s rule.
Dissatisfied with the exercise of power of the majority Serbs, the
Slovenes succeeded in establishing their independence in 1991 after
a short 10-day war. Historical ties to Western Europe, a strong
economy, and a stable democracy have assisted in Slovenia''s
transformation to a modern state. Slovenia acceded to both NATO and
the EU in the spring of 2004.
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2004 est.)
Sava River polluted with domestic and industrial waste;
pollution of coastal waters with heavy metals and toxic chemicals;
forest damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid rain
party to: Air Pollution, Air Pollution-Sulfur 94,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.7% (FY00)
13.69 billion kWh (2001)
13.83 billion kWh (2001)
4.1 billion kWh (2001)
3 billion kWh (2001)
NA
lowest 10%: 3.9%
highest 10%: 23% (1998)
agriculture NA, industry NA, services NA
manufactured goods, machinery and transport equipment,
chemicals, food
Germany 23.2%, Italy 13.2%, Croatia 9%, Austria 7.3%,
France 5.7%, Bosnia and Herzegovina 4.2% (2003)
182 municipalities (obcine, singular - obcina) and 11 urban
municipalities* (mestne obcine , singular - mestna obcina )
Ajdovscina, Beltinci, Benedikt, Bistrica ob Sotli, Bled, Bloke,
Bohinj, Borovnica, Bovec, Braslovce, Brda, Brezice, Brezovica,
Cankova, Celje*, Cerklje na Gorenjskem, Cerknica, Cerkno,
Cerkvenjak, Crensovci, Crna na Koroskem, Crnomelj, Destrnik, Divaca,
Dobje, Dobrepolje, Dobrna, Dobrova-Horjul-Polhov Gradec,
Dobrovnik-Dobronak, Dolenjske Toplice, Dol pri Ljubljani, Domzale,
Dornava, Dravograd, Duplek, Gorenja Vas-Poljane, Gorisnica, Gornja
Radgona, Gornji Grad, Gornji Petrovci, Grad, Grosuplje, Hajdina,
Hoce-Slivnica, Hodos-Hodos, Horjul, Hrastnik, Hrpelje-Kozina,
Idrija, Ig, Ilirska Bistrica, Ivancna Gorica, Izola-Isola, Jesenice,
Jezersko, Jursinci, Kamnik, Kanal, Kidricevo, Kobarid, Kobilje,
Kocevje, Komen, Komenda, Koper-Capodistria*, Kostel, Kozje, Kranj*,
Kranjska Gora, Krizevci, Krsko, Kungota, Kuzma, Lasko, Lenart,
Lendava-Lendva, Litija, Ljubljana*, Ljubno, Ljutomer, Logatec, Loska
Dolina, Loski Potok, Lovrenc na Pohorju, Luce, Lukovica, Majsperk,
Maribor*, Markovci, Medvode, Menges, Metlika, Mezica, Miklavz na
Dravskem Polju, Miren-Kostanjevica, Mirna Pec, Mislinja, Moravce,
Moravske Toplice, Mozirje, Murska Sobota*, Muta, Naklo, Nazarje,
Nova Gorica*, Novo Mesto*, Odranci, Oplotnica, Ormoz, Osilnica,
Pesnica, Piran-Pirano, Pivka, Podcetrtek, Podlehnik, Podvelka,
Polzela, Postojna, Prebold, Preddvor, Prevalje, Ptuj*, Puconci,
Race-Fram, Radece, Radenci, Radlje ob Dravi, Radovljica, Ravne na
Koroskem, Razkrizje, Ribnica, Ribnica na Pohorju, Rogasovci, Rogaska
Slatina, Rogatec, Ruse, Salovci, Selnica ob Dravi, Semic,
Sempeter-Vrtojba, Sencur, Sentilj, Sentjernej, Sentjur pri Celju,
Sevnica, Sezana, Skocjan, Skofja Loka, Skofljica, Slovenj Gradec*,
Slovenska Bistrica, Slovenske Konjice, Smarje pri Jelsah, Smartno ob
Paki, Smartno pri Litiji, Sodrazica, Solcava, Sostanj, Starse,
Store, Sveta Ana, Sveti Andraz v Slovenskih Goricah, Sveti Jurij,
Tabor, Tisina, Tolmin, Trbovlje, Trebnje, Trnovska Vas, Trzic,
Trzin, Turnisce, Velenje*, Velika Polana, Velike Lasce, Verzej,
Videm, Vipava, Vitanje, Vodice, Vojnik, Vransko, Vrhnika, Vuzenica,
Zagorje ob Savi, Zalec, Zavrc, Zelezniki, Zetale, Ziri, Zirovnica,
Zuzemberk, Zrece
note: there may be 45 more municipalities
potatoes, hops, wheat, sugar beets, corn, grapes; cattle,
sheep, poultry
14 (2003 est.)
8.9 births/1,000 population (2004 est.)
Slovenian Army (includes Air and Naval Forces)
revenues: $11.46 billion
expenditures: $11.85 billion, including capital expenditures of NA
(2003 est.)
Slovenia, with its historical ties to Western Europe,
enjoys a GDP per capita substantially higher than that of the other
transitioning economies of Central Europe. In March 2004, Slovenia
became the first transition country to graduate from borrower status
to donor partner at the World Bank. Privatization of the economy
proceeded at an accelerated pace in 2002-03, and the budget deficit
dropped from 3.0% of GDP in 2002 to 1.6% in 2003. Despite the
economic slowdown in Europe in 2001-03, Slovenia maintained 3%
growth. Structural reforms to improve the business environment allow
for greater foreign participation in Slovenia''s economy and help to
lower unemployment. Further measures to curb inflation are also
needed. Corruption and the high degree of coordination between
government, business, and central bank policy are issues of concern
in the run-up to Slovenia''s scheduled 1 May 2004 accession to the
European Union.
gas 2,526 km; oil 11 km (2004)','958d464d30fc0bcdc574316bd051fd405e753e9cb0c1a1c5540e75c3478f375d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f9f79032e7c0cce17b4093b40918657531a01b465aa1f068a204b31d7fc35f3',2004,'SB','Solomon Islands','economy',613,'The UK established a protectorate over the Solomon
Islands in the 1890s. Some of the bitterest fighting of World War II
occurred on these islands. Self-government was achieved in 1976 and
independence two years later. Ethnic violence, government
malfeasance, and endemic crime have undermined stability and civil
society. In June 2003, Prime Minister Sir Allen KEMAKEZA sought the
assistance of Australia in reestablishing law and order; the
following month, an Australian-led multinational force arrived to
restore peace and disarm ethnic militias. The Regional Assistance
Mission to the Solomon Islands (RAMSI) has been very effective in
restoring law and order and rebuilding government institutions.
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 21 (2004 est.)
deforestation; soil erosion; many of the surrounding
coral reefs are dead or dying
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Environmental Modification,
Law of the Sea, Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
NA
32 million kWh (2001)
29.76 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 75%, industry 5%, services 20% (2000
est.)
timber, fish, copra, palm oil, cocoa
China 25.2%, South Korea 17.6%, Japan 13.4%,
Philippines 8.4%, Singapore 5.9%, Thailand 5.9% (2003)
9 provinces and 1 capital territory*; Central,
Choiseul, Guadalcanal, Honiara*, Isabel, Makira, Malaita, Rennell
and Bellona, Temotu, Western
cocoa beans, coconuts, palm kernels, rice, potatoes,
vegetables, fruit; cattle, pigs; timber; fish
33 (2003 est.)
31.6 births/1,000 population (2004 est.)
no regular military forces; Solomon Islands National
Reconnaissance and Surveillance Force; Royal Solomon Islands Police
(RSIP)
revenues: $38 million
expenditures: NA, including capital expenditures of NA (2001)
The bulk of the population depends on agriculture,
fishing, and forestry for at least part of their livelihood. Most
manufactured goods and petroleum products must be imported. The
islands are rich in undeveloped mineral resources such as lead,
zinc, nickel, and gold. However, severe ethnic violence, the closing
of key business enterprises, and an empty government treasury have
led to serious economic disarray, indeed near collapse. Tanker
deliveries of crucial fuel supplies (including those for electrical
generation) have become sporadic due to the government''s inability
to pay and attacks against ships. Telecommunications are threatened
by the nonpayment of bills and by the lack of technical and
maintenance staff many of whom have left the country. The
disintegration of law and order left the economy in tatters by
mid-2003, and on 24 July 2003 more than 2000 Australian soldiers
entered the Solomon Islands to restore order and to facilitate the
restoration of basic services.','0cdc30377cbd621ca16c19cdb5f3cbaf3f2a58bb8b50f5e0d42cc2a060a8bedb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4575aec56bef9d7cd08762ed372545a5ca5217f8bfa51f20984d74928497e1c',2004,'SO','Somalia','economy',614,'The SIAD BARRE regime was ousted in January 1991; turmoil,
factional fighting, and anarchy have followed in the years since. In
May of 1991, northern clans declared an independent Republic of
Somaliland that now includes the administrative regions of Awdal,
Woqooyi Galbeed, Togdheer, Sanaag, and Sool. Although not recognized
by any government, this entity has maintained a stable existence,
aided by the overwhelming dominance of a ruling clan and economic
infrastructure left behind by British, Russian, and American
military assistance programs. The regions of Bari and Nugaal and
northern Mudug comprise a neighboring self-declared autonomous state
of Puntland, which has been self-governing since 1998, but does not
aim at independence; it has also made strides towards reconstructing
a legitimate, representative government, but has suffered some civil
strife. Puntland disputes its border with Somaliland as it also
claims portions of eastern Sool and Sanaag. Beginning in 1993, a
two-year UN humanitarian effort (primarily in the south) was able to
alleviate famine conditions, but when the UN withdrew in 1995,
having suffered significant casualties, order still had not been
restored. The mandate of the Transitional National Government (TNG),
created in August 2000 in Arta, Djibouti, expired in August 2003.
New Somali President Abdullahi YUSUF Ahmed has formed a new
Transitional Federal Government (TFG) consisting of a 275-member
parliament. It was established in October 2004 to replace the TNG
but has not yet moved to Mogadishu. Discussions regarding the
establishment of a new government in Mogadishu are ongoing in Kenya.
Numerous warlords and factions are still fighting for control of the
capital city as well as for other southern regions. Suspicion of
Somali links with global terrorism further complicates the picture.
total: 6
over 3,047 m: 4
2438 to 3047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 54
2,438 to 3,047 m: 4
1,524 to 2,437 m: 19
914 to 1,523 m: 29
under 914 m: 2 (2004 est.)
famine; use of contaminated water contributes to human
health problems; deforestation; overgrazing; soil erosion;
desertification
party to: Endangered Species, Law of the Sea, Ozone Layer
Protection
0.9% (2003)
245.1 million kWh (2001)
227.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture (mostly pastoral nomadism) 71%, industry and
services 29%
livestock, bananas, hides, fish, charcoal, scrap metal
UAE 37.2%, Yemen 22.3%, Oman 10.1%, China 6%, Kuwait 4.4%,
Nigeria 4% (2003)
18 regions (plural - NA, singular - gobolka); Awdal, Bakool,
Banaadir, Bari, Bay, Galguduud, Gedo, Hiiraan, Jubbada Dhexe,
Jubbada Hoose, Mudug, Nugaal, Sanaag, Shabeellaha Dhexe, Shabeellaha
Hoose, Sool, Togdheer, Woqooyi Galbeed
cattle, sheep, goats; bananas, sorghum, corn, coconuts,
rice, sugarcane, mangoes, sesame seeds, beans; fish
60 (2003 est.)
46.04 births/1,000 population (2004 est.)
A Somali National Army was attempted under the interim
government; numerous factions and clans maintain independent
militias, and the Somaliland and Puntland regional governments
maintain their own security and police forces
revenues: NA
expenditures: NA, including capital expenditures of NA
Somalia''s economic fortunes are being driven by its deep
political divisions. The northern area has declared its independence
as "Somaliland"; the central area, Puntland, is a self-declared
autonomous state; and the remaining southern portion is riddled with
the struggles of rival factions. Economic life continues, in part
because much activity is local and relatively easily protected.
Agriculture is the most important sector, with livestock normally
accounting for about 40% of GDP and about 65% of export earnings,
but Saudi Arabia''s recent ban on Somali livestock, because of Rift
Valley Fever concerns, has severely hampered the sector. Nomads and
semi-nomads, who are dependent upon livestock for their livelihood,
make up a large portion of the population. Livestock, hides, fish,
charcoal, and bananas are Somalia''s principal exports, while sugar,
sorghum, corn, qat, and machined goods are the principal imports.
Somalia''s small industrial sector, based on the processing of
agricultural products, has largely been looted and sold as scrap
metal. Despite the seeming anarchy, Somalia''s service sector has
managed to survive and grow. Telecommunication firms provide
wireless services in most major cities and offer the lowest
international call rates on the continent. In the absence of a
formal banking sector, money exchange services have sprouted
throughout the country, handling between $200 million and $500
million in remittances annually. Mogadishu''s main market offers a
variety of goods from food to the newest electronic gadgets. Hotels
continue to operate, and militias provide security. The ongoing
civil disturbances and clan rivalries, however, have interfered with
any broad-based economic development and international aid
arrangements. In 2002 Somalia''s overdue financial obligations to the
IMF continued to grow. Statistics on Somalia''s GDP, growth, per
capita income, and inflation should be viewed skeptically.','ad4198e335549954f14ea03612cbc89bc0895f6edc96cc74dd2d950d92954a7e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a6e4edb3cacbe6cc131b2b7c2c868c20da9a7f47f6b1aa1c18e517216262ba4',2004,'ZA','South Africa','economy',615,'After the British seized the Cape of Good Hope area in
1806, many of the Dutch settlers (the Boers) trekked north to found
their own republics. The discovery of diamonds (1867) and gold
(1886) spurred wealth and immigration and intensified the
subjugation of the native inhabitants. The Boers resisted British
encroachments, but were defeated in the Boer War (1899-1902). The
resulting Union of South Africa operated under a policy of apartheid
- the separate development of the races. The 1990s brought an end to
apartheid politically and ushered in black majority rule.
total: 144
over 3,047 m: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m: 51
914 to 1,523 m: 67
under 914 m: 11 (2004 est.)
total: 584
1,524 to 2,437 m: 34
914 to 1,523 m: 300
under 914 m: 250 (2004 est.)
lack of important arterial rivers or lakes requires
extensive water conservation and control measures; growth in water
usage outpacing supply; pollution of rivers from agricultural runoff
and urban discharge; air pollution resulting in acid rain; soil
erosion; desertification
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Southern Ocean
the Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition, it is subject
to these agreements specific to the Antarctic region: International
Whaling Commission (prohibits commercial whaling south of 40 degrees
south [south of 60 degrees south between 50 degrees and 130 degrees
west]); Convention on the Conservation of Antarctic Seals (limits
sealing); Convention on the Conservation of Antarctic Marine Living
Resources (regulates fishing)
note: many nations (including the US) prohibit mineral resource
exploration and exploitation south of the fluctuating Polar Front
(Antarctic Convergence) which is in the middle of the Antarctic
Circumpolar Current and serves as the dividing line between the very
cold polar surface waters to the south and the warmer waters to the
north
1.7% (2003)
195.6 billion kWh (2001)
181.2 billion kWh (2001)
6.2 billion kWh (2001)
6.91 billion kWh (2001)
50% (2000 est.)
lowest 10%: 1.1%
highest 10%: 45.9% (1994)
agriculture 30%, industry 25%, services 45% (1999 est.)
gold, diamonds, platinum, other metals and minerals,
machinery and equipment (1998 est.)
UK 12.6%, US 12.4%, Japan 9.2%, Germany 8.1%, China
4.7%, Italy 4.4% (2003)
9 provinces; Eastern Cape, Free State, Gauteng,
KwaZulu-Natal, Limpopo, Mpumalanga, North-West, Northern Cape,
Western Cape
corn, wheat, sugarcane, fruits, vegetables; beef,
poultry, mutton, wool, dairy products
728 (2003 est.)
18.38 births/1,000 population (2004 est.)
South African National Defense Force: Army, Navy, Air
Force, and Medical Services
revenues: $37.48 billion
expenditures: $41.46 billion, including capital expenditures of $NA
billion (2003)
South Africa is a middle-income, emerging market with
an abundant supply of natural resources; well-developed financial,
legal, communications, energy, and transport sectors; a stock
exchange that ranks among the 10 largest in the world; and a modern
infrastructure supporting an efficient distribution of goods to
major urban centers throughout the region. However, growth has not
been strong enough to lower South Africa''s high unemployment rate;
and daunting economic problems remain from the apartheid era,
especially poverty and lack of economic empowerment among the
disadvantaged groups. High crime and HIV/AIDS infection rates also
deter investment. South African economic policy is fiscally
conservative, but pragmatic, focusing on targeting inflation and
liberalizing trade as means to increase job growth and household
income.
condensate 100 km; gas 1,052 km; oil 847 km; refined
products 1,354 km (2004)','ecc5a54cf9932d3286bca04099ada48c89c50a00fc44c8dc9f35f66436d875a1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1565be02a79f38342d5b15c5f37f87fd399dca368483a158465b9c67de7a93bb',2004,'GS','South Georgia and the South Sandwich Islands','economy',616,'The islands lie
approximately 1,000 km east of the Falkland Islands and have been
under British administration since 1908, except for a brief period
in 1982 when Argentina occupied them. Grytviken, on South Georgia,
was a 19th and early 20th century whaling station. Famed explorer
Ernest SHACKLETON stopped there in 1914 en route to his ill-fated
attempt to cross Antarctica on foot. He returned some 20 months
later with a few companions in a small boat and arranged a
successful rescue for the rest of his crew, stranded off the
Antarctic Peninsula. He died in 1922 on a subsequent expedition and
is buried in Grytviken. Today, the station houses scientists from
the British Antarctic Survey. The islands have large bird and seal
populations, and, recognizing the importance of preserving the
marine stocks in adjacent waters, the UK, in 1993, extended the
exclusive fishing zone from 12 nm to 200 nm around each island.
Southern Ocean
A decision by the International Hydrographic
Organization in the spring of 2000 delimited a fifth world ocean -
the Southern Ocean - from the southern portions of the Atlantic
Ocean, Indian Ocean, and Pacific Ocean. The Southern Ocean extends
from the coast of Antarctica north to 60 degrees south latitude,
which coincides with the Antarctic Treaty Limit. The Southern Ocean
is now the fourth largest of the world''s five oceans (after the
Pacific Ocean, Atlantic Ocean, and Indian Ocean, but larger than the
Arctic Ocean).
NA
Southern Ocean
increased solar ultraviolet radiation resulting from
the Antarctic ozone hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and damaging the DNA
of some fish; illegal, unreported, and unregulated fishing in recent
years, especially the landing of an estimated five to six times more
Patagonian toothfish than the regulated fishery, which is likely to
affect the sustainability of the stock; large amount of incidental
mortality of seabirds resulting from long-line fishing for toothfish
note: the now-protected fur seal population is making a strong
comeback after severe overexploitation in the 18th and 19th centuries
none (2003 est.)
Some fishing takes
place in adjacent waters. Fees from fishing licenses and related
activities traditionally account for around 90% of South Georgia''s
revenue (about $5.6 million in 2004). There is a potential source of
income from harvesting finfish and krill. The islands receive income
from postage stamps produced in the UK, sale of fishing licenses,
and harbor and landing fees from tourist vessels. Tourism from
specialized cruise ships is increasing rapidly. Annual tourist
volume hovers around 3,000 arrivals.
Southern Ocean
Fisheries in 2000-01 (1 July to 30 June) landed
112,934 metric tons, of which 87% was krill and 11% Patagonian
toothfish. International agreements were adopted in late 1999 to
reduce illegal, unreported, and unregulated fishing, which in the
2000-01 season landed, by one estimate, 8,376 metric tons of
Patagonian and antarctic toothfish. In the 2000-01 antarctic summer
12,248 tourists, most of them seaborne, visited the Southern Ocean
and Antarctica, compared to 14,762 the previous year.','ef13b220164ab224c77465f05d63d917b6f1bf203760010162e708e4bf60d766','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b25af742508e8242b0c2fa5e618c6ec3a330d7f15c74c7d8a18126d9d8d4954e',2004,'ES','Spain','economy',617,'Spain''s powerful world empire of the 16th and 17th centuries
ultimately yielded command of the seas to England. Subsequent
failure to embrace the mercantile and industrial revolutions caused
the country to fall behind Britain, France, and Germany in economic
and political power. Spain remained neutral in World Wars I and II,
but suffered through a devastating civil war (1936-39). In the
second half of the 20th century, Spain has played a catch-up role in
the western international community; it joined the EU in 1986.
Continuing challenges include Basque Fatherland and Liberty (ETA)
terrorism and further reductions in unemployment.
Spratly Islands
The Spratly Islands consist of more than 100 small
islands or reefs. They are surrounded by rich fishing grounds and
potentially by gas and oil deposits. They are claimed in their
entirety by China, Taiwan, and Vietnam, while portions are claimed
by Malaysia and the Philippines. About 45 islands are occupied by
relatively small numbers of military forces from China, Malaysia,
the Philippines, Taiwan, and Vietnam. Brunei has established a
fishing zone that overlaps a southern reef, but has not made any
formal claim.
total: 95
over 3,047 m: 15
2,438 to 3,047 m: 10
1,524 to 2,437 m: 19
914 to 1,523 m: 23
under 914 m: 28 (2004 est.)
Spratly Islands
total: 2
914 to 1,523 m: 1
less than 914 m: 1 (2004 est.)
total: 61
1,524 to 2,437 m: 2
914 to 1,523 m: 15
under 914 m: 44 (2004 est.)
Spratly Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
pollution of the Mediterranean Sea from raw sewage and
effluents from the offshore production of oil and gas; water quality
and quantity nationwide; air pollution; deforestation;
desertification
Spratly Islands
NA
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.2% (2003)
222.5 billion kWh (2001)
210.4 billion kWh (2001)
7.588 billion kWh (2001)
4.138 billion kWh (2001)
NA
lowest 10%: 2.8%
highest 10%: 25.2% (1990)
agriculture 7%, manufacturing, mining, and construction 29%,
services 64% (2001 est.)
machinery, motor vehicles; foodstuffs, other consumer goods
France 19.2%, Germany 11.9%, Italy 9.7%, UK 9.4%, Portugal
9.3%, US 4.2% (2003)
17 autonomous communities (comunidades autonomas, singular -
comunidad autonoma)and 2 autonomous cities* (ciudades autonomas,
singular - ciudad autonoma); Andalucia, Aragon, Asturias, Baleares
(Balearic Islands), Ceuta*, Canarias (Canary Islands), Cantabria,
Castilla-La Mancha, Castilla y Leon, Cataluna, Comunidad Valenciana,
Extremadura, Galicia, La Rioja, Madrid, Melilla*, Murcia, Navarra,
Pais Vasco (Basque Country)
note: three small Spanish possessions of Islas Chafarinas, Penon de
Alhucemas, and Penon de Velez de la Gomera, administered directly by
the Spanish central government, are all located off the coast of
Morocco and are collectively referred to as Places of Sovereignty
(Plazas de Soberania)
grain, vegetables, olives, wine grapes, sugar beets, citrus;
beef, pork, poultry, dairy products; fish
156 (2003 est.)
Spratly Islands
3 (2003 est.)
10.11 births/1,000 population (2004 est.)
Army, Navy, Air Force (Ejercito del Aire, EdA), Marines
revenues: $330.7 billion
expenditures: $335.3 billion, including capital expenditures of
$12.8 billion (2003 est.)
Spain''s mixed capitalist economy supports a GDP that on a per
capita basis is 80% that of the four leading West European
economies. The center-right government of former President AZNAR
successfully worked to gain admission to the first group of
countries launching the European single currency (the euro) on 1
January 1999. The AZNAR administration continued to advocate
liberalization, privatization, and deregulation of the economy and
introduced some tax reforms to that end. Unemployment fell steadily
under the AZNAR administration but remains high at 11.7%. Growth of
2.4% in 2003 was satisfactory given the background of a faltering
European economy. Incoming President RODRIGUEZ ZAPATERO, whose party
won the election three days after the Madrid train bombings in
March, plans to reduce government intervention in business, combat
tax fraud, and support innovation, research and development, but
also intends to reintroduce labor market regulations that had been
scrapped by the AZNAR government. Adjusting to the monetary and
other economic policies of an integrated Europe - and reducing
unemployment - will pose challenges to Spain over the next few years.
Spratly Islands
Economic activity is limited to commercial fishing.
The proximity to nearby oil- and gas-producing sedimentary basins
suggests the potential for oil and gas deposits, but the region is
largely unexplored; there are no reliable estimates of potential
reserves; commercial exploitation has yet to be developed.
gas 7,306 km; oil 730 km; refined products 3,512 km (2004)','557f71c089c71ef8d7c846f1d5876096fa61d9deb489ac7ee6ba23d4216d06ba','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15367ffe688db329f45f1d88e16d5e64cdd6bbc6365fb77b9cc5b1078820f9f1',2004,'LK','Sri Lanka','economy',618,'The Sinhalese arrived in Sri Lanka late in the 6th century
B.C., probably from northern India. Buddhism was introduced
beginning in about the mid-third century B.C., and a great
civilization developed at the cities of Anuradhapura (kingdom from
circa 200 B.C. to circa A.D. 1000) and Polonnaruwa (from about 1070
to 1200). In the 14th century, a south Indian dynasty seized power
in the north and established a Tamil kingdom. Occupied by the
Portuguese in the 16th century and by the Dutch in the 17th century,
the island was ceded to the British in 1796, became a crown colony
in 1802, and was united under British rule by 1815. As Ceylon, it
became independent in 1948; its name was changed to Sri Lanka in
1972. Tensions between the Sinhalese majority and Tamil separatists
erupted into war in 1983. Tens of thousands have died in an ethnic
conflict that continues to fester. After two decades of fighting,
the government and Liberation Tigers of Tamil Eelam formalized a
cease-fire in February 2002, with Norway brokering peace
negotiations.
total: 13
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 6 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
deforestation; soil erosion; wildlife populations
threatened by poaching and urbanization; coastal degradation from
mining activities and increased pollution; freshwater resources
being polluted by industrial wastes and sewage runoff; waste
disposal; air pollution in Colombo
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
3.2% (2003)
6.36 billion kWh (2001)
5.915 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
22% (1997 est.)
lowest 10%: 3.5%
highest 10%: 28% (1995)
agriculture 38%, industry 17%, services 45% (1998 est.)
textiles and apparel, tea, diamonds, coconut products,
petroleum products
US 34.6%, UK 12.5%, India 4.8%, Germany 4.5% (2003)
8 provinces; Central, North Central, North Eastern, North
Western, Sabaragamuwa, Southern, Uva, Western; note - North Eastern
province may have been divided in two - Northern and Eastern
rice, sugarcane, grains, pulses, oilseed, spices, tea,
rubber, coconuts; milk, eggs, hides, beef
14 (2003 est.)
15.88 births/1,000 population (2004 est.)
Army, Navy, Air Force, Police Force
revenues: $3.229 billion
expenditures: $4.526 billion, including capital expenditures of NA
(2003 est.)
In 1977, Colombo abandoned statist economic policies and
its import substitution trade policy for market-oriented policies
and export-oriented trade. Sri Lanka''s most dynamic sectors now are
food processing, textiles and apparel, food and beverages,
telecommunications, and insurance and banking. In 2003, plantation
crops made up only 15% of exports (compared with 93% in 1970), while
textiles and garments accounted for 63%. GDP grew at an average
annual rate of 5.5% in the early 1990s until a drought and a
deteriorating security situation lowered growth to 3.8% in 1996. The
economy rebounded in 1997-2000 with average growth of 5.3%, but 2001
saw the first contraction in the country''s history, -1.4%, due to a
combination of power shortages, severe budgetary problems, the
global slowdown, and continuing civil strife. Growth recovered to
4.0% in 2002 and 5.2% in 2003. About 800,000 Sri Lankans work
abroad, 90% in the Middle East. They send home about $1 billion a
year. The struggle by the Tamil Tigers of the north and east for a
largely independent homeland continues to cast a shadow over the','a3b1f6015349b685d9b4f835de245c5d410a12092b975ce200c41f14b761d36f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bfebc55533b1005ccdc0fbeffcf32b101089b60c70fe0e0b67521c319e9a4ba',2004,'SD','Sudan','economy',619,'Military regimes favoring Islamic-oriented governments have
dominated national politics since independence from the UK in 1956.
Sudan has been embroiled in a civil war for all but 10 years of this
period (1972-82). The wars are rooted in northern economic,
political, and social domination of non-Muslim, non-Arab southern
Sudanese. Since 1983, the war and war- and famine-related effects
have led to more than 2 million deaths and over 4 million people
displaced. The ruling regime is a mixture of military elite and an
Islamist party that came to power in a 1989 coup. Some northern
opposition parties have made common cause with the southern rebels
and entered the war as a part of an anti-government alliance. Peace
talks gained momentum in 2002-03 with the signing of several
accords, including a cease-fire agreement.
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (2004 est.)
total: 63
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 17
914 to 1,523 m: 33
under 914 m: 11 (2004 est.)
inadequate supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion; desertification;
periodic drought
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
2.5% (1999)
2.389 billion kWh (2001)
2.222 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA (2004 est.)
lowest 10%: NA
highest 10%: NA
agriculture 80%, industry and commerce 7%, government 13%
(1998 est.)
oil and petroleum products; cotton, sesame, livestock,
groundnuts, gum arabic, sugar
China 40.9%, Saudi Arabia 17.2%, UAE 5.4% (2003)
26 states (wilayat, singular - wilayah); A''ali an Nil, Al Bahr
al Ahmar, Al Buhayrat, Al Jazirah, Al Khartum, Al Qadarif, Al
Wahdah, An Nil al Abyad, An Nil al Azraq, Ash Shamaliyah, Bahr al
Jabal, Gharb al Istiwa''iyah, Gharb Bahr al Ghazal, Gharb Darfur,
Gharb Kurdufan, Janub Darfur, Janub Kurdufan, Junqali, Kassala, Nahr
an Nil, Shamal Bahr al Ghazal, Shamal Darfur, Shamal Kurdufan, Sharq
al Istiwa''iyah, Sinnar, Warab
cotton, groundnuts (peanuts), sorghum, millet, wheat, gum
arabic, sugarcane, cassava (tapioca), mangos, papaya, bananas, sweet
potatoes, sesame; sheep, livestock
63 (2003 est.)
35.79 births/1,000 population (2004 est.)
Sudanese People''s Armed Forces (SPAF), Navy, Air Force,
Popular Defense Forces
revenues: $2.402 billion
expenditures: $2.546 billion, including capital expenditures of $304
million (2003 est.)
Sudan has turned around a struggling economy with sound
economic policies and infrastructure investments, yet it still faces
formidable economic problems, starting from its low level of per
capita output and extending to its devastating civil stife. From
1997 to date, Sudan has been implementing IMF macroeconomic reforms.
In 1999, Sudan began exporting crude oil and in the last quarter of
1999 recorded its first trade surplus, which, along with monetary
policy, has stabilized the exchange rate. Increased oil production,
revived light industry, and expanded export processing zones helped
sustain GDP growth at 6.1% in 2003 and 7% in 2004. Agriculture
production remains Sudan''s most important sector, employing 80% of
the work force and contributing 39% of GDP, but most farms remain
rain-fed and susceptible to drought. Chronic instability - including
the long-standing civil war between the Muslim north and the
Christian/pagan south, the ethnic purges in Darfur, adverse weather,
and weak world agricultural prices - ensure that much of the
population will remain at or below the poverty line for years.
gas 156 km; oil 2,365 km; refined products 810 km (2004)','f3908487026b82ef25f30811c27b59aab17c149db47895df8d6989b6f5571183','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb36783efbf8b4ec7641f149eb20b24201f2b62d5b08db6aa1913181a4acc474',2004,'SR','Suriname','economy',620,'Independence from the Netherlands was granted in 1975. Five
years later the civilian government was replaced by a military
regime that soon declared a socialist republic. It continued to rule
through a succession of nominally civilian administrations until
1987, when international pressure finally forced a democratic
election. In 1989, the military overthrew the civilian government,
but a democratically-elected government returned to power in 1991.
Svalbard
First discovered by the Norwegians in the 12th century, the
islands served as an international whaling base during the 17th and
18th centuries. Norway''s sovereignty was recognized in 1920; five
years later it officially took over the territory.
Swaziland
Autonomy for the Swazis of southern Africa was guaranteed
by the British in the late 19th century; independence was granted in
1968. Student and labor unrest during the 1990s pressured the
monarchy (one of the oldest on the continent) to grudgingly allow
political reform and greater democracy. Swaziland recently surpassed
Botswana as the country with the world''s highest known rates of
HIV/AIDS infection
total: 5
over 3,047 m: 1
under 914 m: 4 (2004 est.)
Svalbard
total: 2
1,524 to 2,437 m: 1
914 to 1523 m: 1 (2004 est.)
Swaziland
total: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 41
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 35 (2004 est.)
Svalbard
total: 2
under 914 m: 2 (2004 est.)
Swaziland
total: 17
914 to 1,523 m: 7
under 914 m: 10 (2004 est.)
deforestation as timber is cut for export; pollution of
inland waterways by small-scale mining activities
Svalbard
NA
Swaziland
limited supplies of potable water; wildlife populations
being depleted because of excessive hunting; overgrazing; soil
degradation; soil erosion
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Swaziland
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Ozone Layer Protection
signed, but not ratified: Law of the Sea
0.7% (2003)
Swaziland
1.8% (2003)
1.959 billion kWh (2001)
Svalbard
NA kWh
Swaziland
348.3 million kWh (2001)
1.822 billion kWh (2001)
Svalbard
NA kWh
Swaziland
962.9 million kWh (2001)
0 kWh (2001)
Swaziland
639 million kWh; note - electricity supplied by South
Africa (2001)
0 kWh (2001)
Swaziland
0 kWh (2001)
70% (2002 est.)
Svalbard
NA
Swaziland
40% (1995)
lowest 10%: NA
highest 10%: NA
Svalbard
lowest 10%: NA
highest 10%: NA
Swaziland
lowest 10%: 1%
highest 10%: 50.2% (1995)
agriculture NA, industry NA, services NA
Swaziland
NA
alumina, crude oil, lumber, shrimp and fish, rice, bananas
Swaziland
soft drink concentrates, sugar, wood pulp, cotton yarn,
refrigerators, citrus and canned fruit
US 23.3%, Norway 18.4%, Belgium 12.5%, France 10.1%,
Trinidad and Tobago 7.1%, Iceland 4.7%, Italy 4.3%, Netherlands 4.2%
(2003)
Swaziland
South Africa 72%, EU 14.2%, Mozambique 3.7%, US 3.5% (1999)
10 districts (distrikten, singular - distrikt); Brokopondo,
Commewijne, Coronie, Marowijne, Nickerie, Para, Paramaribo,
Saramacca, Sipaliwini, Wanica
Swaziland
4 districts; Hhohho, Lubombo, Manzini, Shiselweni
paddy rice, bananas, palm kernels, coconuts, plantains,
peanuts; beef, chickens; forest products; shrimp
Swaziland
sugarcane, cotton, corn, tobacco, rice, citrus,
pineapples, sorghum, peanuts; cattle, goats, sheep
46 (2003 est.)
Svalbard
4 (2003 est.)
Swaziland
18 (2003 est.)
18.87 births/1,000 population (2004 est.)
Svalbard
NA births/1,000 population
Swaziland
28.55 births/1,000 population (2004 est.)
National Army (includes small Navy and Air Force elements)
Swaziland
Umbutfo Swaziland Defense Force (Army, including Air Wing)
revenues: $393 million
expenditures: $403 million, including capital expenditures of $34
million (1997 est.)
Svalbard
revenues: $11.5 million
expenditures: $11.5 million, including capital expenditures of NA
(1998 est.)
Swaziland
revenues: $462.4 million
expenditures: $563.4 million, including capital expenditures of $147
million (2003)
The economy is dominated by the bauxite industry, which
accounts for more than 15% of GDP and 70% of export earnings.
Suriname''s economic prospects for the medium term will depend on
renewed commitment to responsible monetary and fiscal policies and
to the introduction of structural reforms to liberalize markets and
promote competition. The government of Ronald VENETIAAN has begun an
austerity program, raised taxes, and attempted to control spending.
However, in 2002, President VENETIAAN agreed to a large pay raise
for civil servants, which threatens his earlier gains in stabilizing
the economy. The Dutch Government has agreed to restart the aid
flow, which will allow Suriname to access international development
financing. The short-term economic outlook depends on the
government''s ability to control inflation and on the development of
projects in the bauxite and gold mining sectors.
Svalbard
Coal mining is the major economic activity on Svalbard. The
treaty of 9 February 1920 gives the 41 signatories equal rights to
exploit mineral deposits, subject to Norwegian regulation. Although
US, UK, Dutch, and Swedish coal companies have mined in the past,
the only companies still mining are Norwegian and Russian. The
settlements on Svalbard are essentially company towns. The Norwegian
state-owned coal company employs nearly 60% of the Norwegian
population on the island, runs many of the local services, and
provides most of the local infrastructure. There is also some
hunting of seal, reindeer, and fox.
Swaziland
In this small, landlocked economy, subsistence agriculture
occupies more than 80% of the population. The manufacturing sector
has diversified since the mid-1980s. Sugar and wood pulp remain
important foreign exchange earners. Mining has declined in
importance in recent years with only coal and quarry stone mines
remaining active. Surrounded by South Africa, except for a short
border with Mozambique, Swaziland is heavily dependent on South
Africa from which it receives about nine-tenths of its imports and
to which it sends nearly three-quarters of its exports. Customs
duties from the Southern African Customs Union and worker
remittances from South Africa substantially supplement domestically
earned income. The government is trying to improve the atmosphere
for foreign investment. Overgrazing, soil depletion, drought, and
sometimes floods persist as problems for the future. More than
one-fourth of the population needed emergency food aid in 2002
because of drought, and more than one-third of the adult population
was infected by HIV/AIDS.
oil 51 km (2004)','aebd401e3734b09edd3e7721a7ae345295aaec50d302a824b4f14a3eea9d1ca5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5df5c18cb9ce086938abd4f7159a6d80099c4b49744655c82182fe020f8760b4',2004,'SE','Sweden','economy',621,'A military power during the 17th century, Sweden has not
participated in any war in almost two centuries. An armed neutrality
was preserved in both World Wars. Sweden''s long-successful economic
formula of a capitalist system interlarded with substantial welfare
elements was challenged in the 1990s by high unemployment and in
2000-02 by the global economic downturn, but fiscal discipline over
the past several years has allowed the country to weather economic
vagaries. Indecision over the country''s role in the political and
economic integration of Europe delayed Sweden''s entry into the EU
until 1995, and waived the introduction of the euro in 1999.
total: 154
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 82
914 to 1,523 m: 22
under 914 m: 35 (2004 est.)
total: 100
914 to 1,523 m: 10
under 914 m: 90 (2004 est.)
acid rain damage to soils and lakes; pollution of the North
Sea and the Baltic Sea
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
2.1% (FY01)
152.9 billion kWh (2001)
134.9 billion kWh (2001)
11.14 billion kWh (2001)
18.45 billion kWh (2001)
NA
lowest 10%: 3.7%
highest 10%: 20.1% (1992)
agriculture 2%, industry 24%, services 74% (2000 est.)
machinery 35%, motor vehicles, paper products, pulp and wood,
iron and steel products, chemicals
US 11.5%, Germany 10%, Norway 8.4%, UK 7.8%, Denmark 6.4%,
Finland 5.7%, Netherlands 4.9%, France 4.9%, Belgium 4.5% (2003)
21 counties (lan, singular and plural); Blekinge, Dalarnas,
Gavleborgs, Gotlands, Hallands, Jamtlands, Jonkopings, Kalmar,
Kronobergs, Norrbottens, Orebro, Ostergotlands, Skane,
Sodermanlands, Stockholms, Uppsala, Varmlands, Vasterbottens,
Vasternorrlands, Vastmanlands, Vastra Gotalands
barley, wheat, sugar beets; meat, milk
255 (2003 est.)
10.46 births/1,000 population (2004 est.)
Army, Royal Navy, Air Force (Flygvapnet)
revenues: $177.7 billion
expenditures: $176.9 billion, including capital expenditures of NA
(2003 est.)
Aided by peace and neutrality for the whole 20th century,
Sweden has achieved an enviable standard of living under a mixed
system of high-tech capitalism and extensive welfare benefits. It
has a modern distribution system, excellent internal and external
communications, and a skilled labor force. Timber, hydropower, and
iron ore constitute the resource base of an economy heavily oriented
toward foreign trade. Privately owned firms account for about 90% of
industrial output, of which the engineering sector accounts for 50%
of output and exports. Agriculture accounts for only 2% of GDP and
2% of the jobs. The government''s commitment to fiscal discipline
resulted in a substantial budgetary surplus in 2001, which was cut
by more than half in 2002, due to the global economic slowdown,
declining revenue, and increased spending. The Swedish central bank
(the Riksbank) is focusing on price stability with its inflation
target of 2%. Growth remained sluggish in 2003. On September 14,
2003, Swedish voters turned down entry into the euro system,
concerned about the impact on democracy and sovereignty.
gas 798 km (2004)','f49f794d5d390888ed51ad393eb72d70a10ef7fafecc269ba3b3002c2c4f4e96','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df03d3803695bb9a5585be5d8912e1d094c76ccbd35f96e80e0175221f68f1ae',2004,'CH','Switzerland','economy',622,'Switzerland''s independence and neutrality have long been
honored by the major European powers, and Switzerland was not
involved in either of the two World Wars. The political and economic
integration of Europe over the past half century, as well as
Switzerland''s role in many UN and international organizations, has
strengthened Switzerland''s ties with its neighbors. However, the
country did not officially become a UN member until 2002.
Switzerland remains active in many UN and international
organizations, but retains a strong commitment to neutrality.
Syria
Following the breakup of the Ottoman Empire during World War
I, Syria was administered by the French until independence in 1946.
In the 1967 Arab-Israeli War, Syria lost the Golan Heights to
Israel. Since 1976, Syrian troops have been stationed in Lebanon,
ostensibly in a peacekeeping capacity. Over the past decade, Syria
and Israel have held occasional peace talks over the return of the
Golan Heights.
Taiwan
In 1895, military defeat forced China to cede Taiwan to
Japan. Taiwan reverted to Chinese control after World War II.
Following the Communist victory on the mainland in 1949, 2 million
Nationalists fled to Taiwan and established a government using the
1946 constitution drawn up for all of China. Over the next five
decades, the ruling authorities gradually democratized and
incorporated the native population within the governing structure.
In 2000, Taiwan underwent its first peaceful transfer of power from
the Nationalist to the Democratic Progressive Party. Throughout this
period, the island prospered and became one of East Asia''s economic
"Tigers." The dominant political issues continue to be the
relationship between Taiwan and China - specifically the question of
eventual unification - as well as domestic political and economic
reform.
total: 42
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 8
under 914 m: 16 (2004 est.)
Syria
total: 26
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
Taiwan
total: 37
over 3,047 m: 8
2,438 to 3,047 m: 8
1,524 to 2,437 m: 12
914 to 1,523 m: 8
under 914 m: 1 (2004 est.)
total: 23
under 914 m: 23 (2004 est.)
Syria
total: 66
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 54 (2004 est.)
Taiwan
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2004 est.)
air pollution from vehicle emissions and open-air
burning; acid rain; water pollution from increased use of
agricultural fertilizers; loss of biodiversity
Syria
deforestation; overgrazing; soil erosion; desertification;
water pollution from raw sewage and petroleum refining wastes;
inadequate potable water
Taiwan
air pollution; water pollution from industrial emissions, raw
sewage; contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste disposal
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Law of the Sea
Syria
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
Taiwan
party to: none of the selected agreements because of Taiwan''s
international status
signed, but not ratified: none of the selected agreements because of
Taiwan''s international status
1% (FY01)
Syria
5.9% (FY00)
Taiwan
2.7% (2003)
68.68 billion kWh (2001)
Syria
23.26 billion kWh (2001)
Taiwan
151.1 billion kWh (2001)
53.43 billion kWh (2001)
Syria
21.63 billion kWh (2001)
Taiwan
140.5 billion kWh (2001)
24.1 billion kWh (2001)
Syria
0 kWh (2001)
Taiwan
0 kWh (2001)
34.54 billion kWh (2001)
Syria
0 kWh (2001)
Taiwan
0 kWh (2001)
NA
Syria
20% (2003 est.)
Taiwan
1% (2000 est.)
lowest 10%: 2.6%
highest 10%: 25.2% (1992)
Syria
lowest 10%: NA
highest 10%: NA
Taiwan
lowest 10%: 6.7%
highest 10%: 41.1% (2002 est.)
agriculture 4.6%, industry 26.3%, services 69.1% (1998)
Syria
agriculture, industry, services NA
Taiwan
agriculture 7.5%, industry 35%, services 57% (2001 est.)
machinery, chemicals, metals, watches, agricultural
products
Syria
crude oil, petroleum products, fruits and vegetables, cotton
fiber, clothing, meat and live animals, wheat
Taiwan
computer products and electrical equipment, metals, textiles,
plastics and rubber products, chemicals (2002)
Germany 20.8%, US 11.3%, France 8.7%, Italy 8.3%, UK
4.9%, Japan 4% (2003)
Syria
Germany 20.9%, Italy 12.6%, UAE 7.6%, Lebanon 6.2%, Turkey 6%,
France 5.4%, Croatia 4.8%, US 4.1% (2003)
Taiwan
China 25.3%, US 20.5%, Japan 9.2% (2002)
26 cantons (cantons, singular - canton in French;
cantoni, singular - cantone in Italian; kantone, singular - kanton
in German); Aargau, Appenzell Ausser-Rhoden, Appenzell Inner-Rhoden,
Basel-Landschaft, Basel-Stadt, Bern, Fribourg, Geneve, Glarus,
Graubunden, Jura, Luzern, Neuchatel, Nidwalden, Obwalden, Sankt
Gallen, Schaffhausen, Schwyz, Solothurn, Thurgau, Ticino, Uri,
Valais, Vaud, Zug, Zurich
Syria
14 provinces (muhafazat, singular - muhafazah); Al Hasakah, Al
Ladhiqiyah, Al Qunaytirah, Ar Raqqah, As Suwayda'', Dar''a, Dayr az
Zawr, Dimashq, Halab, Hamah, Hims, Idlib, Rif Dimashq, Tartus
Taiwan
includes central island of Taiwan plus numerous smaller
islands near central island and off coast of China''s Fujian
Province; Taiwan is divided into 18 counties (hsien, singular and
plural), 5 municipalities (shih, singular and plural), and 2 special
municipalities (chuan-shih, singular and plural)
counties: Chang-hua, Chia-i, Hsin-chu, Hua-lien, I-lan, Kao-hsiung
county, Kin-men, Lien-chiang, Miao-li, Nan-t''ou, P''eng-hu,
P''ing-tung, T''ai-chung, T''ai-nan, T''ai-pei county, T''ai-tung,
T''ao-yuan, and Yun-lin
municipalities: Chia-i, Chi-lung, Hsin-chu, T''ai-chung, T''ai-nan
special municipalities: Kao-hsiung city, T''ai-pei city
note: Taiwan generally uses Wade-Giles system for romanization;
special municipality of Taipei adopted standard pinyin romanization
for street and place names within city boundaries, other local
authorities have selected a variety of romanization systems
grains, fruits, vegetables; meat, eggs
Syria
wheat, barley, cotton, lentils, chickpeas, olives, sugar
beets; beef, mutton, eggs, poultry, milk
Taiwan
rice, corn, vegetables, fruit, tea; pigs, poultry, beef,
milk, fish
65 (2003 est.)
Syria
93 (2003 est.)
Taiwan
40 (2003 est.)
9.83 births/1,000 population (2004 est.)
Syria
28.93 births/1,000 population (2004 est.)
Taiwan
12.7 births/1,000 population (2004 est.)
Land Forces, Air Force
Syria
Syrian Arab Army, Syrian Arab Navy, Syrian Arab Air Force
(including Air Defense Command), Police and Security Force
Taiwan
Army, Navy (including Marine Corps), Air Force, Coast Guard
Administration, Armed Forces Reserve Command, Combined Service
Forces Command, Armed Forces Police Command
revenues: $123.2 billion
expenditures: $128 billion, including capital expenditures of NA
(2003 est.)
Syria
revenues: $6.106 billion
expenditures: $7.397 billion, including capital expenditures of $3.6
billion (2003 est.)
Taiwan
revenues: $56.58 billion
expenditures: $69.21 billion, including capital expenditures of
$14.4 billion (2003 est.)
Switzerland is a prosperous and stable modern market
economy with low unemployment, a highly skilled labor force, and a
per capita GDP larger than that of the big Western European
economies. The Swiss in recent years have brought their economic
practices largely into conformity with the EU''s to enhance their
international competitiveness. Switzerland remains a safe haven for
investors, because it has maintained a degree of bank secrecy and
has kept up the franc''s long-term external value. Reflecting the
anemic economic conditions of Europe, GDP growth dropped in 2001 to
about 0.8%, to 0.2% in 2002, and to -0.3% in 2003.
Syria
Syria''s predominantly statist economy lately has been growing
more slowly than its 2.4% annual population growth rate. Recent
legislation allows private banks to operate in Syria, although a
private banking sector will take years and further government
cooperation to develop. Factors, including the war between the
US-led coalition and Iraq, probably drove real annual GDP growth
levels back below 1% in 2003 following growth of 3.5% in 2001 and
4.5% in 2002. A long-run economic constraint is the pressure on
water supplies caused by rapid population growth, industrial
expansion, and increased water pollution.
Taiwan
Taiwan has a dynamic capitalist economy with gradually
decreasing guidance of investment and foreign trade by government
authorities. In keeping with this trend, some large government-owned
banks and industrial firms are being privatized. Exports have
provided the primary impetus for industrialization. The trade
surplus is substantial, and foreign reserves are the world''s third
largest. Agriculture contributes 2% to GDP, down from 32% in 1952.
While Taiwan is a major investor throughout Southeast Asia, China
has become the largest destination for investment and has overtaken
the US to become Taiwan''s largest export market. Because of its
conservative financial approach and its entrepreneurial strengths,
Taiwan suffered little compared with many of its neighbors from the
Asian financial crisis in 1998. The global economic downturn,
combined with problems in policy coordination by the administration
and bad debts in the banking system, pushed Taiwan into recession in
2001, the first year of negative growth ever recorded. Unemployment
also reached record levels. Output recovered moderately in 2002 in
the face of continued global slowdown, fragile consumer confidence,
and bad bank loans. Growing economic ties with China are a dominant
long-term factor. Exports to China - mainly parts and equipment for
the assembly of goods for export to developed countries - drove
Taiwan''s economic recovery in 2002. Although the SARS epidemic,
Typhoon Maemi, corporate scandals, and a drop in consumer spending
caused GDP growth to contract to 3.2% in 2003, increasingly strong
export performance kept Taiwan''s economy on track, and the
government expects Taiwan''s economy to grow 4.1% in 2004.
gas 1,831 km; oil 94 km; refined products 7 km (2004)
Syria
gas 2,300 km; oil 2,183 km (2004)
Taiwan
condensate 25 km; gas 435 km (2004)','9df6b72db6d75201fb823092b6cf9030eb35dd4255f2e56f5ccda4aeb8e0f695','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba9ab14389772c49cc66eb5e11016386bf06646a1a1de022500df530589416a',2004,'TJ','Tajikistan','economy',623,'Tajikistan has completed its transition from the civil
war that plagued the country from 1992 to 1997. There have been no
major security incidents in more than two years, although the
country remains the poorest in the region. Attention by the
international community in the wake of the war in Afghanistan has
brought increased economic development assistance, which could
create jobs and increase stability in the long term. Tajikistan is
in the early stages of seeking World Trade Organization membership
and has joined NATO''s Partnership for Peace.
Tanzania
Shortly after independence, Tanganyika and Zanzibar merged
to form the nation of Tanzania in 1964. One-party rule came to an
end in 1995 with the first democratic elections held in the country
since the 1970s. Zanzibar''s semi-autonomous status and popular
opposition have led to two contentious elections since 1995, which
the ruling party won despite international observers'' claims of
voting irregularities.
total: 15
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 2
under 914 m: 2 (2003 est.)
Tanzania
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 51
1,524 to 2,437 m: 1
914 to 1,523 m: 10
under 914 m: 40 (2003 est.)
Tanzania
total: 112
1,524 to 2,437 m: 19
914 to 1,523 m: 60
under 914 m: 33 (2004 est.)
inadequate sanitation facilities; increasing levels of
soil salinity; industrial pollution; excessive pesticides
Tanzania
soil degradation; deforestation; desertification;
destruction of coral reefs threatens marine habitats; recent
droughts affected marginal agriculture; wildlife threatened by
illegal hunting and trade, especially for ivory
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Tanzania
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
3.9% (FY01)
Tanzania
0.2% (2003)
14.18 billion kWh (2001)
Tanzania
2.906 billion kWh (2001)
14.52 billion kWh (2001)
Tanzania
2.752 billion kWh (2001)
5.242 billion kWh (2001)
Tanzania
50 million kWh (2001)
3.909 billion kWh (2001)
Tanzania
0 kWh (2001)
60% (2003 est.)
Tanzania
36% (2002 est.)
lowest 10%: 3.2%
highest 10%: 25.2% (1998)
Tanzania
lowest 10%: 2.8%
highest 10%: 30.1% (1993)
agriculture 67.2%, industry 7.5%, services 25.3% (2000
est.)
Tanzania
agriculture 80%, industry and services 20% (2002 est.)
aluminum, electricity, cotton, fruits, vegetable oil,
textiles
Tanzania
gold, coffee, cashew nuts, manufactures, cotton
Netherlands 25.4%, Turkey 24.4%, Latvia 9.9%, Switzerland
9.7%, Uzbekistan 8.5%, Russia 6.6%, Iran 6.4% (2003)
Tanzania
Japan 9.5%, India 8.6%, Netherlands 8.2%, Germany 5.3%, UK
5.3%, Kenya 4.8% (2003)
2 provinces (viloyatho, singular - viloyat) and 1
autonomous province* (viloyati mukhtor); Viloyati Mukhtori Kuhistoni
Badakhshon* [Gorno-Badakhshan] (Khorugh), Viloyati Khatlon
(Qurghonteppa), Viloyati Sughd (Khujand)
note: the administrative center name follows in parentheses
Tanzania
26 regions; Arusha, Dar es Salaam, Dodoma, Iringa, Kagera,
Kigoma, Kilimanjaro, Lindi, Manyara, Mara, Mbeya, Morogoro, Mtwara,
Mwanza, Pemba North, Pemba South, Pwani, Rukwa, Ruvuma, Shinyanga,
Singida, Tabora, Tanga, Zanzibar Central/South, Zanzibar North,
Zanzibar Urban/West
cotton, grain, fruits, grapes, vegetables; cattle, sheep,
goats
Tanzania
coffee, sisal, tea, cotton, pyrethrum (insecticide made
from chrysanthemums), cashew nuts, tobacco, cloves, corn, wheat,
cassava (tapioca), bananas, fruits, vegetables; cattle, sheep, goats
66 (2003 est.)
Tanzania
123 (2003 est.)
32.63 births/1,000 population (2004 est.)
Tanzania
39 births/1,000 population (2004 est.)
Army, Air Force, Air Defense Force, Presidential National
Guard
Tanzania
Tanzanian People''s Defense Force: Army, Naval Wing, and Air
Defense Command; National Service
revenues: $253.5 million
expenditures: $238.5 million, including capital expenditures of $86
million (2003 est.)
Tanzania
revenues: $1.879 billion
expenditures: $1.873 billion, including capital expenditures of NA
(2003 est.)
Tajikistan has the lowest per capita GDP among the 15
former Soviet republics. Only 5% to 6% of the land area is arable.
Cotton is the most important crop. Mineral resources, varied but
limited in amount, include silver, gold, uranium, and tungsten.
Industry consists only of a large aluminum plant, hydropower
facilities, and small obsolete factories mostly in light industry
and food processing. The civil war (1992-97) severely damaged the
already weak economic infrastructure and caused a sharp decline in
industrial and agricultural production. Even though 60% of its
people continue to live in abject poverty, Tajikistan has
experienced steady economic growth since 1997. Continued
privatization of medium and large state-owned enterprises will
further increase productivity. Tajikistan''s economic situation,
however, remains fragile due to uneven implementation of structural
reforms, weak governance, widespread unemployment, and the external
debt burden. A debt restructuring agreement was reached with Russia
in December 2002, including an interest rate of 4%, a 3-year grace
period, and a US $49.8 million credit to the Central Bank of
Tajikistan.
Tanzania
Tanzania is one of the poorest countries in the world. The
economy depends heavily on agriculture, which accounts for about
half of GDP, provides 85% of exports, and employs 80% of the work
force. Topography and climatic conditions, however, limit cultivated
crops to only 4% of the land area. Industry traditionally featured
the processing of agricultural products and light consumer goods.
The World Bank, the International Monetary Fund, and bilateral
donors have provided funds to rehabilitate Tanzania''s out-of-date
economic infrastructure and to alleviate poverty. Growth in
1991-2002 featured a pickup in industrial production and a
substantial increase in output of minerals, led by gold. Oil and gas
exploration and development played an important role in this growth.
Recent banking reforms have helped increase private sector growth
and investment. Continued donor assistance and solid macroeconomic
policies supported real GDP growth of more than 5.2% in 2004.
gas 541 km; oil 38 km (2004)
Tanzania
gas 29 km; oil 866 km (2004)','9f7aedd48cae2fae4d56babb72b9054352c905880d5a0de226ee3b36ccd998e8','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d250dded6dab60ca6112ee8378eb93ab9c6550f5556c3c03d9a2b84d8059054d',2004,'TH','Thailand','economy',624,'A unified Thai kingdom was established in the mid-14th
century. Known as Siam until 1939, Thailand is the only Southeast
Asian country never to have been taken over by a European power. A
bloodless revolution in 1932 led to a constitutional monarchy. In
alliance with Japan during World War II, Thailand became a US ally
following the conflict. Thailand is currently facing armed violence
in its three Muslim-majority southernmost provinces.
total: 65
over 3,047 m: 7
2,438 to 3,047 m: 10
1,524 to 2,437 m: 23
914 to 1,523 m: 19
under 914 m: 6 (2004 est.)
total: 44
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 28 (2004 est.)
air pollution from vehicle emissions; water pollution from
organic and factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
1.8% (2003)
97.6 billion kWh (2001)
90.91 billion kWh (2001)
350 million kWh (2001)
200 million kWh (2001)
10.4% (2002 est.)
lowest 10%: 2.8%
highest 10%: 32.4% (1998)
agriculture 49%, industry 14%, services 37% (2000 est.)
computers, office machine parts, transistors, rubber,
vehicles (cars and trucks), plastic, seafood (2002)
US 17%, Japan 14.2%, Singapore 7.3%, China 7.1%, Hong Kong
5.4%, Malaysia 4.8% (2003)
76 provinces (changwat, singular and plural); Amnat
Charoen, Ang Thong, Buriram, Chachoengsao, Chai Nat, Chaiyaphum,
Chanthaburi, Chiang Mai, Chiang Rai, Chon Buri, Chumphon, Kalasin,
Kamphaeng Phet, Kanchanaburi, Khon Kaen, Krabi, Krung Thep
Mahanakhon (Bangkok), Lampang, Lamphun, Loei, Lop Buri, Mae Hong
Son, Maha Sarakham, Mukdahan, Nakhon Nayok, Nakhon Pathom, Nakhon
Phanom, Nakhon Ratchasima, Nakhon Sawan, Nakhon Si Thammarat, Nan,
Narathiwat, Nong Bua Lamphu, Nong Khai, Nonthaburi, Pathum Thani,
Pattani, Phangnga, Phatthalung, Phayao, Phetchabun, Phetchaburi,
Phichit, Phitsanulok, Phra Nakhon Si Ayutthaya, Phrae, Phuket,
Prachin Buri, Prachuap Khiri Khan, Ranong, Ratchaburi, Rayong, Roi
Et, Sa Kaeo, Sakon Nakhon, Samut Prakan, Samut Sakhon, Samut
Songkhram, Sara Buri, Satun, Sing Buri, Sisaket, Songkhla,
Sukhothai, Suphan Buri, Surat Thani, Surin, Tak, Trang, Trat, Ubon
Ratchathani, Udon Thani, Uthai Thani, Uttaradit, Yala, Yasothon
rice, cassava (tapioca), rubber, corn, sugarcane, coconuts,
soybeans
109 (2003 est.)
16.04 births/1,000 population (2004 est.)
Royal Thai Army, Royal Thai Navy (including Royal Thai
Marine Corps), Royal Thai Air Force
revenues: $24.41 billion
expenditures: $24.01 billion, including capital expenditures of $5
billion (2003 est.)
Thailand has a free-enterprise economy and welcomes foreign
investment. Exports feature textiles and footwear, fishery products,
rice, rubber, jewelry, automobiles, computers and electrical
appliances. Thailand has recovered from the 1997-98 Asian Financial
Crisis and was one of East Asia''s best performers in 2002. Increased
consumption and investment spending and strong export growth pushed
GDP growth up to 6.3% in 2003 despite a sluggish global economy. The
highly popular government has pushed an expansionist policy,
including major support of village economic development.
gas 3,112 km; refined products 265 km (2004)','07c6de2bed49bec7290cc1ad40625104e83485a0c03bbafa2a367511b203cb0a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f596b19e1d5c76947d21bafedc527108d9255de60905eb3b314dab7d31cf258',2004,'TK','Tokelau','economy',625,'Originally settled by Polynesian emigrants from surrounding
island groups, the Tokelau Islands were made a British protectorate
in 1889. They were transferred to New Zealand administration in 1925.
very limited natural resources and overcrowding are
contributing to emigration to New Zealand
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
stamps, copra, handicrafts
New Zealand (2000)
none (territory of New Zealand)
coconuts, copra, breadfruit, papayas, bananas; pigs,
poultry, goats
none; lagoon landings are possible by amphibious aircraft
(2003 est.)
NA births/1,000 population
revenues: $430,800
expenditures: $2.8 million, including capital expenditures of
$37,300 (1987 est.)
Tokelau''s small size (three villages), isolation, and lack
of resources greatly restrain economic development and confine
agriculture to the subsistence level. The people rely heavily on aid
from New Zealand - about $4 million annually - to maintain public
services, with annual aid being substantially greater than GDP. The
principal sources of revenue come from sales of copra, postage
stamps, souvenir coins, and handicrafts. Money is also remitted to
families from relatives in New Zealand.','9ad215af0aef1d112a91514984c5b121e32ec7a19475c9cf517b39f35b8e1b2b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96d507765f74d668a4506880bb79ca62697ad5a5980a68debf3821276cefb85f',2004,'TO','Tonga','economy',626,'The archipelago of "The Friendly Islands" was united into a
Polynesian kingdom in 1845. It became a constitutional monarchy in
1875 and a British protectorate in 1900. Tonga acquired its
independence in 1970 and became a member of the Commonwealth of
Nations. It remains the only monarchy in the Pacific.
total: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
deforestation results as more and more land is being cleared
for agriculture and settlement; some damage to coral reefs from
starfish and indiscriminate coral and shell collectors; overhunting
threatens native sea turtle populations
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA
27.27 million kWh (2001)
25.36 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 65% (1997 est.)
squash, fish, vanilla beans, root crops
US 50%, Japan 35.7%, Italy 3.6% (2003)
3 island groups; Ha''apai, Tongatapu, Vava''u
squash, coconuts, copra, bananas, vanilla beans, cocoa,
coffee, ginger, black pepper; fish
6 (2003 est.)
24.87 births/1,000 population (2004 est.)
Tonga Defense Services: Ground Forces (Royal Marines, Royal
Guard), Maritime Force (including Air Wing)
revenues: $39.9 million
expenditures: $52.4 million, including capital expenditures of $1.9
million (FY99/00 est.)
Tonga, a small, open, South Pacific island economy, has a
narrow export base in agricultural goods. Squash, coconuts, bananas,
and vanilla beans are the main crops, and agricultural exports make
up two-thirds of total exports. The country must import a high
proportion of its food, mainly from New Zealand. Tourism is the
second-largest source of hard currency earnings following
remittances. The country remains dependent on external aid and
remittances from Tongan communities overseas to offset its trade
deficit. The government is emphasizing the development of the
private sector, especially the encouragement of investment, and is
committing increased funds for health and education. Tonga has a
reasonably sound basic infrastructure and well-developed social
services. High unemployment among the young and the continuing
upturn in inflation are major issues facing the government.','3fa66e6f4533194a84adf35c4483b761f5fab4213bb4f77cd3491a49d3428af5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3cb38b428007dc79700fe5bc2871de354a4b67157b51b472a2a211daa3fabef',2004,'TT','Trinidad and Tobago','economy',627,'The islands came under British control in the
19th century; independence was granted in 1962. The country is one
of the most prosperous in the Caribbean thanks largely to petroleum
and natural gas production and processing. Tourism, mostly in
Tobago, is targeted for expansion and is growing.
Tromelin Island
First explored by the French in 1776, the island
came under the jurisdiction of Reunion in 1814. At present, it
serves as a sea turtle sanctuary and is the site of an important
meteorological station.
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2004 est.)
Tromelin Island
total: 1
under 914 m: 1 (2004 est.)
water pollution from agricultural chemicals,
industrial wastes, and raw sewage; oil pollution of beaches;
deforestation; soil erosion
Tromelin Island
NA
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
0.6% (2003)
5.315 billion kWh (2001)
4.943 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
21% (1992 est.)
lowest 10%: NA
highest 10%: NA
agriculture 9.5%, manufacturing, mining, and
quarrying 14%, construction and utilities 12.4%, services 64.1%
(1997 est.)
petroleum and petroleum products, chemicals,
steel products, fertilizer, sugar, cocoa, coffee, citrus, flowers
US 63.5%, Jamaica 5.6%, France 3.2% (2003)
9 regional corporations, 2 city corporations, 3
borough corporations, and 1 ward
regional corporations: Couva/Tabaquite/Talparo, Diego Martin,
Mayaro/Rio Claro, Penal/Debe, Princes Town, Sangre Grande, San
Juan/Laventille, Siparia, Tunapuna/Piarco
city corporations: Port of Spain, San Fernando;
borough corporations: Arima, Point Fortin, Chaguanas
ward: Tobago
cocoa, sugarcane, rice, citrus, coffee,
vegetables; poultry
6 (2003 est.)
Tromelin Island
1 (2003 est.)
12.75 births/1,000 population (2004 est.)
Trinidad and Tobago Defense Force: Ground Force,
Coast Guard, and Air Wing
revenues: $2.663 billion
expenditures: $2.51 billion, including capital expenditures of
$117.3 million (2003)
Trinidad and Tobago, the leading Caribbean
producer of oil and gas, has earned a reputation as an excellent
investment site for international businesses. Tourism is a growing
sector, although not proportionately as important as in many other
Caribbean islands. The economy benefits from low inflation and a
growing trade surplus. Prospects for growth in 2004 are good as
prices for oil, petrochemicals, and liquified natural gas are
expected to remain high, and foreign direct investment continues to
grow to support expanded capacity in the energy sector. The
government is coping with a rise in violent crime.
Tromelin Island
no economic activity
condensate 253 km; gas 1,117 km; oil 478 km
(2004)','ccad01ab5502ef9ca457628b66af52b0fd596db089f2e4e7b515099172c699b5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcd3b0869587e9a91dbd9d00f97847f3a64f85a0020d4aa24690b3524a5c2414',2004,'TN','Tunisia','economy',628,'Following independence from France in 1956, President Habib
BOURGUIBA established a strict one-party state. He dominated the
country for 31 years, repressing Islamic fundamentalism and
establishing rights for women unmatched by any other Arab nation. In
recent years, Tunisia has taken a moderate, non-aligned stance in
its foreign relations. Domestically, it has sought to defuse rising
pressure for a more open political society.
Turkey
Modern Turkey was founded in 1923 from the Anatolian remnants
of the defeated Ottoman Empire by national hero Mustafa KEMAL, who
was later honored with the title Ataturk, or "Father of the Turks."
Under his authoritarian leadership, the country adopted wide-ranging
social, legal, and political reforms. After a period of one-party
rule, an experiment with multi-party politics led to the 1950
election victory of the opposition Democratic Party and the peaceful
transfer of power. Since then, Turkish political parties have
multiplied, but democracy has been fractured by periods of
instability and intermittent military coups (1960, 1971, 1980),
which in each case eventually resulted in a return of political
power to civilians. In 1997, the military again helped engineer the
ouster - popularly dubbed a "post-modern coup" - of the then
Islamic-oriented government. Turkey intervened militarily on Cyprus
in 1974 to prevent a Greek takeover of the island and has since
acted as patron state to the "Turkish Republic of Northern Cyprus,"
which only Turkey recognizes. A separatist insurgency begun in 1984
by the Kurdistan Workers'' Party (PKK) - now known as the People''s
Congress of Kurdistan or Kongra-Gel (KGK) - has dominated the
Turkish military''s attention and claimed more than 30,000 lives, but
after the capture of the group''s leader in 1999, the insurgents
largely withdrew from Turkey, mainly to northern Iraq. In 2004, KGK
announced an end to its ceasefire and attacks attributed to the KGK
increased. Turkey joined the UN in 1945 and in 1952 it became a
member of NATO. In 1964, Turkey became an associate member of the
European Community; over the past decade, it has undertaken many
reforms to strengthen its democracy and economy, enabling it to
begin accession membership talks with the European Union.
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (2004 est.)
Turkey
total: 87
over 3,047 m: 16
2,438 to 3,047 m: 30
1,524 to 2,437 m: 20
914 to 1,523 m: 17
under 914 m: 4 (2004 est.)
total: 16
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 7 (2004 est.)
Turkey
total: 32
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 20 (2004 est.)
toxic and hazardous waste disposal is ineffective and poses
health risks; water pollution from raw sewage; limited natural fresh
water resources; deforestation; overgrazing; soil erosion;
desertification
Turkey
water pollution from dumping of chemicals and detergents; air
pollution, particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Turkey
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.5% (FY99)
Turkey
5.3% (2003)
10.48 billion kWh (2001)
Turkey
116.6 billion kWh (2001)
9.748 billion kWh (2001)
Turkey
112.6 billion kWh (2001)
1 million kWh (2001)
Turkey
4.579 billion kWh (2001)
0 kWh (2001)
Turkey
433 million kWh (2001)
7.6% (2001 est.)
Turkey
18% (2001)
lowest 10%: 2.3%
highest 10%: 31.8% (1995)
Turkey
lowest 10%: 2.3%
highest 10%: 32.3% (1994)
services 55%, industry 23%, agriculture 22% (1995 est.)
Turkey
agriculture 39.7%, industry 22.4%, services 37.9% (3rd
quarter, 2001)
textiles, mechanical goods, phosphates and chemicals,
agricultural products, hydrocarbons
Turkey
apparel, foodstuffs, textiles, metal manufactures, transport
equipment
France 32.6%, Italy 21.9%, Germany 10.7%, Spain 4.7%, Libya
4.4% (2003)
Turkey
Germany 15.8%, US 8%, UK 7.8%, Italy 6.8%, France 6% (2003)
24 governorates; Ariana (Aryanah), Beja (Bajah), Ben Arous
(Bin ''Arus), Bizerte (Banzart), Gabes (Qabis), Gafsa (Qafsah),
Jendouba (Jundubah), Kairouan (Al Qayrawan), Kasserine (Al Qasrayn),
Kebili (Qibili), Kef (Al Kaf), Mahdia (Al Mahdiyah), Manouba
(Manubah), Medenine (Madanin), Monastir (Al Munastir), Nabeul
(Nabul), Sfax (Safaqis), Sidi Bou Zid (Sidi Bu Zayd), Siliana
(Silyanah), Sousse (Susah), Tataouine (Tatawin), Tozeur (Tawzar),
Tunis, Zaghouan (Zaghwan)
Turkey
81 provinces (iller, singular - il); Adana, Adiyaman,
Afyonkarahisar, Agri, Aksaray, Amasya, Ankara, Antalya, Ardahan,
Artvin, Aydin, Balikesir, Bartin, Batman, Bayburt, Bilecik, Bingol,
Bitlis, Bolu, Burdur, Bursa, Canakkale, Cankiri, Corum, Denizli,
Diyarbakir, Duzce, Edirne, Elazig, Erzincan, Erzurum, Eskisehir,
Gaziantep, Giresun, Gumushane, Hakkari, Hatay, Igdir, Isparta,
Istanbul, Izmir, Kahramanmaras, Karabuk, Karaman, Kars, Kastamonu,
Kayseri, Kilis, Kirikkale, Kirklareli, Kirsehir, Kocaeli, Konya,
Kutahya, Malatya, Manisa, Mardin, Mersin, Mugla, Mus, Nevsehir,
Nigde, Ordu, Osmaniye, Rize, Sakarya, Samsun, Sanliurfa, Siirt,
Sinop, Sirnak, Sivas, Tekirdag, Tokat, Trabzon, Tunceli, Usak, Van,
Yalova, Yozgat, Zonguldak
olives, olive oil, grain, dairy products, tomatoes, citrus
fruit, beef, sugar beets, dates, almonds
Turkey
tobacco, cotton, grain, olives, sugar beets, pulse, citrus;
livestock
30 (2003 est.)
Turkey
120 (2003 est.)
15.74 births/1,000 population (2004 est.)
Turkey
17.22 births/1,000 population (2004 est.)
Army, Navy, Air Force
Turkey
Turkish Armed Forces (TSK): Land Forces, Naval Forces Command
(includes Naval Air and Naval Infantry), Air Force, Coast Guard
Command, Gendarmerie (Jandarma)
revenues: $6.101 billion
expenditures: $6.855 billion, including capital expenditures of $1.6
billion (2003 est.)
Turkey
revenues: $66.79 billion
expenditures: $93.31 billion, including capital expenditures of NA
(2003)
Tunisia has a diverse economy, with important agricultural,
mining, energy, tourism, and manufacturing sectors. Governmental
control of economic affairs while still heavy has gradually lessened
over the past decade with increasing privatization, simplification
of the tax structure, and a prudent approach to debt. Real growth,
averaging 5% for the latter half of the last decade, slowed to a
15-year low of 1.9% in 2002 because of agricultural drought, slow
investment, and lackluster tourism. Better rains in 2003, however,
pushed GDP growth up to an estimated 6 percent, and tourism also
recovered after the end of combat operations in Iraq. GDP growth
remained at 6% in 2004. Tunisia has agreed to gradually remove
barriers to trade with the European Union over the next decade.
Broader privatization, further liberalization of the investment code
to increase foreign investment, improvements in government
efficiency, and reduction of the trade deficit are among the
challenges for the future.
Turkey
Turkey''s dynamic economy is a complex mix of modern industry
and commerce along with a traditional agriculture sector that in
2001 still accounted for 40% of employment. It has a strong and
rapidly growing private sector, yet the state still plays a major
role in basic industry, banking, transport, and communication. The
largest industrial sector is textiles and clothing, which accounts
for one-third of industrial employment; it faces stiff competition
in international markets with the end of the global quota system.
However, other sectors, notably the automotive and electonics
industries, are rising in importance within Turkey''s export mix. In
recent years the economic situation has been marked by erratic
economic growth and serious imbalances. Real GNP growth has exceeded
6% in many years, but this strong expansion has been interrupted by
sharp declines in output in 1994, 1999, and 2001. Meanwhile, the
public sector fiscal deficit has regularly exceeded 10% of GDP - due
in large part to the huge burden of interest payments, which
accounted for more than 40% of central government spending in 2003.
Inflation, in recent years in the high double-digit range, fell to
11.3% in 2004. Perhaps because of these problems, foreign direct
investment in Turkey remains low - less than $1 billion annually.
Results in 2002-04 improved, because of strong financial support
from the IMF and tighter fiscal policy. A major political and
economic issue over the next decade is whether or not Turkey will
become a member of the EU.
gas 3,059 km; oil 1,203 km; refined products 345 km (2004)
Turkey
gas 3,177 km; oil 3,562 km (2004)','910eea0c03b64f120432a93ec3f2adaef32b861c49b0e3a7a501c2c866761004','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3bcd074c1d265c092ca05057bc7ba59de33033595c4ddc2c964a18d416d6c00',2004,'TM','Turkmenistan','economy',629,'Annexed by Russia between 1865 and 1885, Turkmenistan
became a Soviet republic in 1924. It achieved its independence upon
the dissolution of the USSR in 1991. President NIYAZOV retains
absolute control over the country and opposition is not tolerated.
Extensive hydrocarbon/natural gas reserves could prove a boon to
this underdeveloped country if extraction and delivery projects were
to be expanded. The Turkmenistan Government is actively seeking to
develop alternative petroleum transportation routes in order to
break Russia''s pipeline monopoly.
total: 24
over 3,047 m: 1
2,438 to 3,047 m: 12
1,524 to 2,437 m: 8
914 to 1,523 m: 2
under 914 m: 1 (2003 est.)
total: 45
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 36 (2003 est.)
contamination of soil and groundwater with agricultural
chemicals, pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of a large
share of the flow of the Amu Darya into irrigation contributes to
that river''s inability to replenish the Aral Sea; desertification
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
3.4% (FY99)
10.18 billion kWh (2001)
8.509 billion kWh (2001)
20 million kWh (2001)
980 million kWh (2001)
34.4% (2001 est.)
lowest 10%: 2.6%
highest 10%: 31.7% (1998)
agriculture 48%, industry 15%, services 37% (1998 est.)
gas 57%, oil 26%, cotton fiber 3%, textiles 2% (2001)
Ukraine 39.2%, Italy 18.1%, Iran 14.7%, Turkey 6.5%
(2003)
5 provinces (welayatlar, singular - welayat): Ahal
Welayaty (Ashgabat), Balkan Welayaty (Balkanabat), Dashoguz
Welayaty, Lebap Welayaty (Turkmenabat), Mary Welayaty
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
cotton, grain; livestock
69 (2003 est.)
27.82 births/1,000 population (2004 est.)
Ministry of Defense (Army, Air and Air Defense, Navy,
Border Troops, and Internal Troops), National Guard
revenues: $3.477 billion
expenditures: $3.908 billion, including capital expenditures of NA
(2003 est.)
Turkmenistan is largely desert country with intensive
agriculture in irrigated oases and large gas and oil resources.
One-half of its irrigated land is planted in cotton, making it at
one time the world''s tenth-largest producer. Poor harvests in recent
years have led to a nearly 46% decline in cotton exports. With an
authoritarian ex-Communist regime in power and a tribally based
social structure, Turkmenistan has taken a cautious approach to
economic reform, hoping to use gas and cotton sales to sustain its
inefficient economy. Privatization goals remain limited. In
1998-2003, Turkmenistan suffered from the continued lack of adequate
export routes for natural gas and from obligations on extensive
short-term external debt. At the same time, however, total exports
rose by 38% in 2003, largely because of higher international oil and
gas prices. Overall prospects in the near future are discouraging
because of widespread internal poverty, the burden of foreign debt,
and the unwillingness of the government to adopt market-oriented
reforms. However, Turkmenistan''s cooperation with the international
community in transporting humanitarian aid to Afghanistan may
foreshadow a change in the atmosphere for foreign investment, aid,
and technological support. Turkmenistan''s economic statistics are
state secrets, and GDP and other figures are subject to wide margins
of error. In particular, the 20% rate of GDP growth is a guess.
gas 6,549 km; oil 1,395 km (2004)','fe97d54abdbbeb68c076d9175b07f0c29faea98410da0c84d98a325716d9994e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03fc5b8dff8fbe5e4ec07e064d680c0d128bf7340cf464e6aaf23ac74967c5ca',2004,'TV','Tuvalu','economy',630,'In 1974, ethnic differences within the British colony of the
Gilbert and Ellice Islands caused the Polynesians of the Ellice
Islands to vote for separation from the Micronesians of the Gilbert
Islands. The following year, the Ellice Islands became the separate
British colony of Tuvalu. Independence was granted in 1978. In 2000,
Tuvalu negotiated a contract leasing its Internet domain name ".tv"
for $50 million in royalties over the next dozen years.
total: 1
1,524 to 2,437 m: 1 (2004 est.)
since there are no streams or rivers and groundwater is not
potable, most water needs must be met by catchment systems with
storage facilities (the Japanese Government has built one
desalination plant and plans to build one other); beachhead erosion
because of the use of sand for building materials; excessive
clearance of forest undergrowth for use as fuel; damage to coral
reefs from the spread of the Crown of Thorns starfish; Tuvalu is
very concerned about global increases in greenhouse gas emissions
and their effect on rising sea levels, which threaten the country''s
underground water table; in 2000, the government appealed to
Australia and New Zealand to take in Tuvaluans if rising sea levels
should make evacuation necessary
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected agreements
NA
NA
lowest 10%: NA
highest 10%: NA
people make a living mainly through exploitation of the sea,
reefs, and atolls and from wages sent home by those abroad (mostly
workers in the phosphate industry and sailors)
copra, fish
UK 37.5%, Poland 19.1%, Philippines 9.2%, Australia 9.1%,
Fiji 6.2% (2003)
none
coconuts; fish
1 (2003 est.)
21.63 births/1,000 population (2004 est.)
no regular military forces; Police Force (includes Maritime
Surveillance Unit for search and rescue missions and surveillance
operations)
revenues: $22.5 million
expenditures: $11.2 million, including capital expenditures of $4.2
million (2000 est.)
Tuvalu consists of a densely populated, scattered group of
nine coral atolls with poor soil. The country has no known mineral
resources and few exports. Subsistence farming and fishing are the
primary economic activities. Fewer than 1,000 tourists, on average,
visit Tuvalu annually. Government revenues largely come from the
sale of stamps and coins and worker remittances. About 1,000
Tuvaluans work in Nauru in the phosphate mining industry. Nauru has
begun repatriating Tuvaluans, however, as phosphate resources
decline. Substantial income is received annually from an
international trust fund established in 1987 by Australia, NZ, and
the UK and supported also by Japan and South Korea. Thanks to wise
investments and conservative withdrawals, this Fund has grown from
an initial $17 million to over $35 million in 1999. The US
government is also a major revenue source for Tuvalu, because of
payments from a 1988 treaty on fisheries. In an effort to reduce its
dependence on foreign aid, the government is pursuing public sector
reforms, including privatization of some government functions and
personnel cuts of up to 7%. In 1998, Tuvalu began deriving revenue
from use of its area code for "900" lines and in 2000, from the
lease of its ".tv" Internet domain name. Royalties from these new
technology sources could increase substantially over the next
decade. With merchandise exports only a fraction of merchandise
imports, continued reliance must be placed on fishing and
telecommunications license fees, remittances from overseas workers,
official transfers, and investment income from overseas assets.','3d60bc7a8d67e9e48ba218e7ccec0801e9622bac22a2eff4aa04847194b59f42','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb752f25cd49c1b7eab6ca6d3e82089ca3e83efdfff7633399ef3725d9bce5b0',2004,'UG','Uganda','economy',631,'Uganda achieved independence from the UK in 1962. The
dictatorial regime of Idi AMIN (1971-79) was responsible for the
deaths of some 300,000 opponents; guerrilla war and human rights
abuses under Milton OBOTE (1980-85) claimed at least another 100,000
lives. During the 1990s, the government promulgated non-party
presidential and legislative elections.
total: 4
over 3,047 m: 3
1,524 to 2,437 m: 1 (2004 est.)
total: 25
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 7 (2004 est.)
draining of wetlands for agricultural use; deforestation;
overgrazing; soil erosion; water hyacinth infestation in Lake
Victoria; poaching is widespread
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Life Conservation, Ozone Layer Protection,
Wetlands
signed, but not ratified: Environmental Modification
2.1% (2003)
1.928 billion kWh (2001)
1.62 billion kWh (2001)
1 million kWh (2001)
174 million kWh (2001)
35% (2001 est.)
lowest 10%: 4%
highest 10%: 21% (2000)
agriculture 82%, industry 5%, services 13% (1999 est.)
coffee, fish and fish products, tea; gold, cotton, flowers,
horticultural products
Kenya 14.7%, Switzerland 13.7%, Netherlands 9.2%, UK 6.4%,
South Africa 5.6% (2003)
56 districts; Adjumani, Apac, Arua, Bugiri, Bundibugyo,
Bushenyi, Busia, Gulu, Hoima, Iganga, Jinja, Kabale, Kabarole,
Kaberamaido, Kalangala, Kampala, Kamuli, Kamwenge, Kanungu,
Kapchorwa, Kasese, Katakwi, Kayunga, Kibale, Kiboga, Kisoro, Kitgum,
Kotido, Kumi, Kyenjojo, Lira, Luwero, Masaka, Masindi, Mayuge,
Mbale, Mbarara, Moroto, Moyo, Mpigi, Mubende, Mukono, Nakapiripirit,
Nakasongola, Nebbi, Ntungamo, Pader, Pallisa, Rakai, Rukungiri,
Sembabule, Sironko, Soroti, Tororo, Wakiso, Yumbe
coffee, tea, cotton, tobacco, cassava (tapioca), potatoes,
corn, millet, pulses; beef, goat meat, milk, poultry, cut flowers
27 (2003 est.)
46.31 births/1,000 population (2004 est.)
Ugandan Peoples'' Defense Force (UPDF): Army, Marine Unit, Air
Wing
revenues: $1.123 billion
expenditures: $1.433 billion, including capital expenditures of $NA
(FY98/99 est.) (2003)
Uganda has substantial natural resources, including fertile
soils, regular rainfall, and sizable mineral deposits of copper and
cobalt. Agriculture is the most important sector of the economy,
employing over 80% of the work force. Coffee accounts for the bulk
of export revenues. Since 1986, the government - with the support of
foreign countries and international agencies - has acted to
rehabilitate and stabilize the economy by undertaking currency
reform, raising producer prices on export crops, increasing prices
of petroleum products, and improving civil service wages. The policy
changes are especially aimed at dampening inflation and boosting
production and export earnings. During 1990-2001, the economy turned
in a solid performance based on continued investment in the
rehabilitation of infrastructure, improved incentives for production
and exports, reduced inflation, gradually improved domestic
security, and the return of exiled Indian-Ugandan entrepreneurs.
Corruption within the government and slippage in the government''s
determination to press reforms raise doubts about the continuation
of strong growth. In 2000, Uganda qualified for enhanced Highly
Indebted Poor Countries (HIPC) debt relief worth $1.3 billion and
Paris Club debt relief worth $145 million. These amounts combined
with the original HIPC debt relief added up to about $2 billion.
Growth for 2001-02 was solid despite continued decline in the price
of coffee, Uganda''s principal export. Solid growth in 2003 reflected
an upturn in Uganda''s export markets.','b7297ea10746f3ea454a30d6d8d7971683ab2f5d4fd37d9f4729993f19bc42ec','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee23c4d1e4813f8cd8614b0c018dcbaa898bad1ea8de25f98cdf71a5d104756',2004,'UA','Ukraine','economy',632,'Ukraine was the center of the first Slavic state, Kievan
Rus, which during the 10th and 11th centuries was the largest and
most powerful state in Europe. Weakened by internecine quarrels and
Mongol invasions, Kievan Rus was incorporated into the Grand Duchy
of Lithuania and eventually into the Polish-Lithuanian Commonwealth.
The cultural and religious legacy of Kievan Rus laid the foundation
for Ukrainian nationalism through subsequent centuries. A new
Ukrainian state, the Cossack Hetmanate, was established during the
mid-17th century after an uprising against the Poles. Despite
continuous Muscovite pressure, the Hetmanate managed to remain
autonomous for well over 100 years. During the latter part of the
18th century, most Ukrainian ethnographic territory was absorbed by
the Russian Empire. Following the collapse of czarist Russia in
1917, Ukraine was able to bring about a short-lived period of
independence (1917-1920), but was reconquered and forced to endure a
brutal Soviet rule that engineered two artificial famines (1921-22
and 1932-33) in which over 8 million died. In World War II, German
and Soviet armies were responsible for some 7 to 8 million more
deaths. Although final independence for Ukraine was achieved in 1991
with the dissolution of the USSR, democracy remained elusive as the
legacy of state control and endemic corruption stalled efforts at
economic reform, privatization, and civil liberties. A peaceful mass
protest "Orange Revolution" in the closing months of 2004 forced the
authorites to overturn a rigged presidential election and to allow a
new internationally monitored vote that swept into power a reformist
slate under Viktor YUSHCHENKO. The new government presents its
citizens with hope that the country may at last attain true freedom
and prosperity.
total: 174
over 3,047 m: 13
2,438 to 3,047 m: 57
1,524 to 2,437 m: 30
914 to 1,523 m: 4
under 914 m: 70 (2003 est.)
total: 528
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 17
914 to 1,523 m: 35
under 914 m: 469 (2003 est.)
inadequate supplies of potable water; air and water
pollution; deforestation; radiation contamination in the northeast
from 1986 accident at Chornobyl'' Nuclear Power Plant
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds
1.4% (FY02)
164.7 billion kWh (2001)
152.4 billion kWh (2001)
0 kWh (2001)
800 million kWh (2001)
29% (2003 est.)
lowest 10%: 3.7%
highest 10%: 23.2% (1999)
agriculture 24%, industry 32%, services 44% (1996)
ferrous and nonferrous metals, fuel and petroleum products,
chemicals, machinery and transport equipment, food products
Russia 17.8%, Germany 5.9%, Italy 5.3%, China 4.1% (2003)
24 provinces (oblasti, singular - oblast''), 1 autonomous
republic* (avtonomna respublika), and 2 municipalities (mista,
singular - misto) with oblast status**; Cherkasy, Chernihiv,
Chernivtsi, Crimea or Avtonomna Respublika Krym* (Simferopol''),
Dnipropetrovs''k, Donets''k, Ivano-Frankivs''k, Kharkiv, Kherson,
Khmel''nyts''kyy, Kirovohrad, Kiev (Kyyiv)**, Kyyiv, Luhans''k, L''viv,
Mykolayiv, Odesa, Poltava, Rivne, Sevastopol''**, Sumy, Ternopil'',
Vinnytsya, Volyn'' (Luts''k), Zakarpattya (Uzhhorod), Zaporizhzhya,
Zhytomyr
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
grain, sugar beets, sunflower seeds, vegetables; beef, milk
702 (2003 est.)
10.21 births/1,000 population (2004 est.)
Ground Forces, Naval Forces, Air and Air Defense Forces,
Ministry of Internal Affairs (MVS) Troops, Border Troops
revenues: $14.1 billion
expenditures: $14.19 billion, including capital expenditures of NA
(2003 est.)
After Russia, the Ukrainian republic was far and away the
most important economic component of the former Soviet Union,
producing about four times the output of the next-ranking republic.
Its fertile black soil generated more than one-fourth of Soviet
agricultural output, and its farms provided substantial quantities
of meat, milk, grain, and vegetables to other republics. Likewise,
its diversified heavy industry supplied the unique equipment (for
example, large diameter pipes) and raw materials to industrial and
mining sites (vertical drilling apparatus) in other regions of the
former USSR. Ukraine depends on imports of energy, especially
natural gas, to meet some 85% of its annual energy requirements.
Shortly after independence in December 1991, the Ukrainian
Government liberalized most prices and erected a legal framework for
privatization, but widespread resistance to reform within the
government and the legislature soon stalled reform efforts and led
to some backtracking. Output by 1999 had fallen to less than 40% of
the 1991 level. Loose monetary policies pushed inflation to
hyperinflationary levels in late 1993. Ukraine''s dependence on
Russia for energy supplies and the lack of significant structural
reform have made the Ukrainian economy vulnerable to external
shocks. President KUCHMA had pledged to reduce the number of
government agencies, streamline the regulatory process, create a
legal environment to encourage entrepreneurs, and enact a
comprehensive tax overhaul. Reforms in the more politically
sensitive areas of structural reform and land privatization are
still lagging. Outside institutions - particularly the IMF - have
encouraged Ukraine to quicken the pace and scope of reforms. GDP in
2000 showed strong export-based growth of 6% - the first growth
since independence - and industrial production grew 12.9%. The
economy continued to expand in 2001 as real GDP rose 9% and
industrial output grew by over 14%. Growth of 4.6% in 2002 was more
moderate, in part a reflection of faltering growth in the developed
world. In general, growth has been undergirded by strong domestic
demand, low inflation, and solid consumer and investor confidence.
Growth was a sturdy 9.3% in 2003 and a remarkable 12% in 2004,
despite a loss of momentum in needed economic reforms.
gas 20,069 km; oil 4,540 km; refined products 4,169 km (2004)','44128b627a458d72108ea9b69e3170b3ffbcd42f32b6d4f415271b46e4cb2b77','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7cc694085ea6a3512870dd99c7ae9ee9f5aa8f1b869702fc08eae91ae7385b0',2004,'AE','United Arab Emirates','economy',633,'The Trucial States of the Persian Gulf coast
granted the UK control of their defense and foreign affairs in 19th
century treaties. In 1971, six of these states - Abu Zaby, ''Ajman,
Al Fujayrah, Ash Shariqah, Dubayy, and Umm al Qaywayn - merged to
form the United Arab Emirates (UAE). They were joined in 1972 by
Ra''s al Khaymah. The UAE''s per capita GDP is on par with those of
leading West European nations. Its generosity with oil revenues and
its moderate foreign policy stance have allowed the UAE to play a
vital role in the affairs of the region.
total: 22
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 4 (2004 est.)
lack of natural freshwater resources
compensated by desalination plants; desertification; beach pollution
from oil spills
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: Law of the Sea
3.1% (FY00)
37.74 billion kWh (2001)
35.1 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 7%, industry 15%, services 78%
(2000 est.)
crude oil 45%, natural gas, reexports, dried
fish, dates
Japan 26.2%, South Korea 10.5%, Iran 3.8% (2003)
7 emirates (imarat, singular - imarah); Abu
Zaby (Abu Dhabi), ''Ajman, Al Fujayrah, Ash Shariqah (Sharjah),
Dubayy (Dubai), Ra''s al Khaymah, Umm al Qaywayn
dates, vegetables, watermelons; poultry, eggs,
dairy products; fish
35 (2003 est.)
18.65 births/1,000 population (2004 est.)
Army, Navy (including Marines and Coast Guard),
Air and Air Defense Force, paramilitary forces (includes Federal
Police Force)
revenues: $17.35 billion
expenditures: $23.85 billion, including capital expenditures of $3.4
billion (2003 est.)
The UAE has an open economy with a high per
capita income and a sizable annual trade surplus. Its wealth is
based on oil and gas output (about 33% of GDP), and the fortunes of
the economy fluctuate with the prices of those commodities. Since
1973, the UAE has undergone a profound transformation from an
impoverished region of small desert principalities to a modern state
with a high standard of living. At present levels of production, oil
and gas reserves should last for more than 100 years. The government
has increased spending on job creation and infrastructure expansion
and is opening up its utilities to greater private sector
involvement.
condensate 469 km; gas 2,655 km; liquid
petroleum gas 300 km; oil 2,936 km; oil/gas/water 5 km (2004)','ece32b1f7f11381a93e1aec7a332baa6a20cffeb105cea473ee8dabb75b2c1e9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d0dcdbd01ef26cd86f3b49589d426d8ece15a79ce520e6a8c179043385b9e40',2004,'GB','United Kingdom','economy',634,'Great Britain, the dominant industrial and maritime
power of the 19th century, played a leading role in developing
parliamentary democracy and in advancing literature and science. At
its zenith, the British Empire stretched over one-fourth of the
earth''s surface. The first half of the 20th century saw the UK''s
strength seriously depleted in two World Wars. The second half
witnessed the dismantling of the Empire and the UK rebuilding itself
into a modern and prosperous European nation. As one of five
permanent members of the UN Security Council, a founding member of
NATO, and of the Commonwealth, the UK pursues a global approach to
foreign policy; it currently is weighing the degree of its
integration with continental Europe. A member of the EU, it chose to
remain outside the European Monetary Union for the time being.
Constitutional reform is also a significant issue in the UK. The
Scottish Parliament, the National Assembly for Wales, and the
Northern Ireland Assembly were established in 1999, but the latter
is suspended due to bickering over the peace process.
total: 334
over 3,047 m: 8
2,438 to 3,047 m: 33
1,524 to 2,437 m: 150
914 to 1,523 m: 86
under 914 m: 57 (2004 est.)
total: 137
2438 to 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 112 (2004 est.)
continues to reduce greenhouse gas emissions (has met
Kyoto Protocol target of a 12.5% reduction from 1990 levels and
intends to meet the legally binding target and move towards a
domestic goal of a 20% cut in emissions by 2010); by 2005 the
government aims to reduce the amount of industrial and commercial
waste disposed of in landfill sites to 85% of 1998 levels and to
recycle or compost at least 25% of household waste, increasing to
33% by 2015; between 1998-99 and 1999-2000, household recycling
increased from 8.8% to 10.3%
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
2.4% (2003)
360.9 billion kWh (2001)
346.1 billion kWh (2001)
10.66 billion kWh (2001)
264 million kWh (2001)
17% (2002 est.)
lowest 10%: 2.3%
highest 10%: 27.7% (1995)
agriculture 1%, industry 25%, services 74% (1999)
manufactured goods, fuels, chemicals; food,
beverages, tobacco
US 15.7%, Germany 10.5%, France 9.5%, Netherlands
6.9%, Ireland 6.5%, Belgium 5.6%, Spain 4.4%, Italy 4.4% (2003)
England - 47 boroughs, 36 counties, 29 London
boroughs, 12 cities and boroughs, 10 districts, 12 cities, 3 royal
boroughs
boroughs: Barnsley, Blackburn with Darwen, Blackpool, Bolton,
Bournemouth, Bracknell Forest, Brighton and Hove, Bury, Calderdale,
Darlington, Doncaster, Dudley, Gateshead, Halton, Hartlepool,
Kirklees, Knowsley, Luton, Medway, Middlesbrough, Milton Keynes,
North Tyneside, Oldham, Poole, Reading, Redcar and Cleveland,
Rochdale, Rotherham, Sandwell, Sefton, Slough, Solihull,
Southend-on-Sea, South Tyneside, St. Helens, Stockport,
Stockton-on-Tees, Swindon, Tameside, Thurrock, Torbay, Trafford,
Walsall, Warrington, Wigan, Wirral, Wolverhampton
counties: Bedfordshire, Buckinghamshire, Cambridgeshire, Cheshire,
Cornwall, Cumbria, Derbyshire, Devon, Dorset, Durham, East Sussex,
Essex, Gloucestershire, Hampshire, Herefordshire, Hertfordshire,
Isle of Wight, Kent, Lancashire, Leicestershire, Lincolnshire,
Norfolk, Northamptonshire, Northumberland, North Yorkshire,
Nottinghamshire, Oxfordshire, Shropshire, Somerset, Staffordshire,
Suffolk, Surrey, Warwickshire, West Sussex, Wiltshire, Worcestershire
London boroughs: Barking and Dagenham, Barnet, Bexley, Brent,
Bromley, Camden, Croydon, Ealing, Enfield, Greenwich, Hackney,
Hammersmith and Fulham, Haringey, Harrow, Havering, Hillingdon,
Hounslow, Islington, Lambeth, Lewisham, Merton, Newham, Redbridge,
Richmond upon Thames, Southwark, Sutton, Tower Hamlets, Waltham
Forest, Wandsworth
cities and boroughs: Birmingham, Bradford, Coventry, Leeds,
Liverpool, Manchester, Newcastle upon Tyne, Salford, Sheffield,
Sunderland, Wakefield, Westminster
districts: Bath and North East Somerset, East Riding of Yorkshire,
North East Lincolnshire, North Lincolnshire, North Somerset,
Rutland, South Gloucestershire, Telford and Wrekin, West Berkshire,
Wokingham
cities: City of Bristol, Derby, City of Kingston upon Hull,
Leicester, City of London, Nottingham, Peterborough, Plymouth,
Portsmouth, Southampton, Stoke-on-Trent, York
royal boroughs: Kensington and Chelsea, Kingston upon Thames,
Windsor and Maidenhead
Northern Ireland - 24 districts, 2 cities, 6 counties
districts: Antrim, Ards, Armagh, Ballymena, Ballymoney, Banbridge,
Carrickfergus, Castlereagh, Coleraine, Cookstown, Craigavon, Down,
Dungannon, Fermanagh, Larne, Limavady, Lisburn, Magherafelt, Moyle,
Newry and Mourne, Newtownabbey, North Down, Omagh, Strabane
cities: Belfast, Derry
counties: County Antrim, County Armagh, County Down, County
Fermanagh, County Londonderry, County Tyrone
Scotland - 32 council areas: Aberdeen City, Aberdeenshire, Angus,
Argyll and Bute, The Scottish Borders, Clackmannanshire, Dumfries
and Galloway, Dundee City, East Ayrshire, East Dunbartonshire, East
Lothian, East Renfrewshire, City of Edinburgh, Falkirk, Fife,
Glasgow City, Highland, Inverclyde, Midlothian, Moray, North
Ayrshire, North Lanarkshire, Orkney Islands, Perth and Kinross,
Renfrewshire, Shetland Islands, South Ayrshire, South Lanarkshire,
Stirling, West Dunbartonshire, Eilean Siar (Western Isles), West
Lothian;
Wales - 11 county boroughs, 9 counties, 2 cities and counties
county boroughs: Blaenau Gwent, Bridgend, Caerphilly, Conwy,
Gwynedd, Merthyr Tydfil, Neath Port Talbot, Newport, Rhondda Cynon
Taff, Torfaen, Wrexham
counties: Isle of Anglesey, Ceredigion, Carmarthenshire,
Denbighshire, Flintshire, Monmouthshire, Pembrokeshire, Powys, The
Vale of Glamorgan
cities and counties: Cardiff, Swansea
cereals, oilseed, potatoes, vegetables; cattle,
sheep, poultry; fish
471 (2003 est.)
10.88 births/1,000 population (2004 est.)
Army, Royal Navy (including Royal Marines), Royal Air
Force
revenues: $688.9 billion
expenditures: $746.1 billion, including capital expenditures of NA
(2003)
The UK, a leading trading power and financial center,
is one of the quartet of trillion dollar economies of Western
Europe. Over the past two decades the government has greatly reduced
public ownership and contained the growth of social welfare
programs. Agriculture is intensive, highly mechanized, and efficient
by European standards, producing about 60% of food needs with only
1% of the labor force. The UK has large coal, natural gas, and oil
reserves; primary energy production accounts for 10% of GDP, one of
the highest shares of any industrial nation. Services, particularly
banking, insurance, and business services, account by far for the
largest proportion of GDP while industry continues to decline in
importance. GDP growth slipped in 2001-03 as the global downturn,
the high value of the pound, and the bursting of the "new economy"
bubble hurt manufacturing and exports. Still, the economy is one of
the strongest in Europe; inflation, interest rates, and unemployment
remain low. The relatively good economic performance has complicated
the BLAIR government''s efforts to make a case for Britain to join
the European Economic and Monetary Union (EMU). Critics point out,
however, that the economy is doing well outside of EMU, and they
point to public opinion polls that continue to show a majority of
Britons opposed to the euro. Meantime, the government has been
speeding up the improvement of education, transport, and health
services, at a cost in higher taxes. The war in March-April 2003
between a US-led coalition and Iraq, together with the subsequent
problems of restoring the economy and the polity, involve a heavy
commitment of British military forces.
condensate 370 km; gas 21,446 km; liquid petroleum
gas 59 km; oil 6,420 km; oil/gas/water 63 km; refined products 4,474
km (2004)','d0b4e0b91e6c325c1e4850b97fd452361a842f6e6e024045631e6d38211eb318','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aa99a63335e4fa4d6f567457bb7d6bebfbcfcdabfebd89a21f01faa7e34a182',2004,'US','United States','economy',635,'Britain''s American colonies broke with the mother
country in 1776 and were recognized as the new nation of the United
States of America following the Treaty of Paris in 1783. During the
19th and 20th centuries, 37 new states were added to the original 13
as the nation expanded across the North American continent and
acquired a number of overseas possessions. The two most traumatic
experiences in the nation''s history were the Civil War (1861-65) and
the Great Depression of the 1930s. Buoyed by victories in World Wars
I and II and the end of the Cold War in 1991, the US remains the
world''s most powerful nation state. The economy is marked by steady
growth, low unemployment and inflation, and rapid advances in
technology.
total: 5,128
over 3,047 m: 188
2,438 to 3,047 m: 221
1,524 to 2,437 m: 1,375
914 to 1,523 m: 2,383
under 914 m: 961 (2004 est.)
total: 9,729
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 160
914 to 1,523 m: 1,718
under 914 m: 7,843 (2004 est.)
air pollution resulting in acid rain in both the US
and Canada; the US is the largest single emitter of carbon dioxide
from the burning of fossil fuels; water pollution from runoff of
pesticides and fertilizers; limited natural fresh water resources in
much of the western part of the country require careful management;
desertification
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Marine Dumping, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change-Kyoto Protocol, Hazardous Wastes
3.3% (FY03 est.) (February 2004)
3.719 trillion kWh (2001)
3.602 trillion kWh (2001)
38.48 billion kWh (2001)
18.17 billion kWh (2001)
12% (2003 est.)
lowest 10%: 1.8%
highest 10%: 30.5% (1997)
managerial, professional, and technical 34.9%, sales
and office 25.5%, manufacturing, extraction, transportation, and
crafts 22.7%, other services 16.3%, farming, forestry, and fishing
0.7%
note: figures exclude the unemployed (2004)
capital goods, automobiles, industrial supplies and
raw materials, consumer goods, agricultural products
Canada 23.4%, Mexico 13.5%, Japan 7.2%, UK 4.7%,
Germany 4% (2003)
50 states and 1 district*; Alabama, Alaska, Arizona,
Arkansas, California, Colorado, Connecticut, Delaware, District of
Columbia*, Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa,
Kansas, Kentucky, Louisiana, Maine, Maryland, Massachusetts,
Michigan, Minnesota, Mississippi, Missouri, Montana, Nebraska,
Nevada, New Hampshire, New Jersey, New Mexico, New York, North
Carolina, North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode
Island, South Carolina, South Dakota, Tennessee, Texas, Utah,
Vermont, Virginia, Washington, West Virginia, Wisconsin, Wyoming
wheat, corn, other grains, fruits, vegetables, cotton;
beef, pork, poultry, dairy products; forest products; fish
14,807 (2003 est.)
14.13 births/1,000 population (2004 est.)
Army, Navy and Marine Corps, Air Force, and Coast
Guard (Coast Guard administered in peacetime by the Department of
Homeland Security, but in wartime reports to the Department of the
Navy)
revenues: $1.782 trillion
expenditures: $2.156 trillion, including capital expenditures of NA
(2003)
The US has the largest and most technologically
powerful economy in the world, with a per capita GDP of $37,800. In
this market-oriented economy, private individuals and business firms
make most of the decisions, and the federal and state governments
buy needed goods and services predominantly in the private
marketplace. US business firms enjoy considerably greater
flexibility than their counterparts in Western Europe and Japan in
decisions to expand capital plant, to lay off surplus workers, and
to develop new products. At the same time, they face higher barriers
to entry in their rivals'' home markets than the barriers to entry of
foreign firms in US markets. US firms are at or near the forefront
in technological advances, especially in computers and in medical,
aerospace, and military equipment; their advantage has narrowed
since the end of World War II. The onrush of technology largely
explains the gradual development of a "two-tier labor market" in
which those at the bottom lack the education and the
professional/technical skills of those at the top and, more and
more, fail to get comparable pay raises, health insurance coverage,
and other benefits. Since 1975, practically all the gains in
household income have gone to the top 20% of households. The years
1994-2000 witnessed solid increases in real output, low inflation
rates, and a drop in unemployment to below 5%. The year 2001 saw the
end of boom psychology and performance, with output increasing only
0.3% and unemployment and business failures rising substantially.
The response to the terrorist attacks of 11 September 2001 showed
the remarkable resilience of the economy. Moderate recovery took
place in 2002 with the GDP growth rate rising to 2.4%. A major
short-term problem in first half 2002 was a sharp decline in the
stock market, fueled in part by the exposure of dubious accounting
practices in some major corporations. The war in March/April 2003
between a US-led coalition and Iraq shifted resources to the
military. In 2003, growth in output and productivity and the
recovery of the stock market to above 10,000 for the Dow Jones
Industrial Average were promising signs. Unemployment stayed at the
6% level, however, and began to decline only at the end of the year.
Long-term problems include inadequate investment in economic
infrastructure, rapidly rising medical and pension costs of an aging
population, sizable trade and budget deficits, and stagnation of
family income in the lower economic groups.
petroleum products 244,620 km; natural gas 548,665 km
(2003)','ecf4fe6cf0ce2df02918636f2d4dbf85cd89af3daeed494af16c4efa62256039','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df08d10574dcd13d1bc2c73fdd35580daaae9f3ba134069921d64de61e34f5f',2004,'UY','Uruguay','economy',636,'A violent Marxist urban guerrilla movement, the Tupamaros,
launched in the late 1960s, led Uruguay''s president to agree to
military control of his administration in 1973. By yearend, the
rebels had been crushed, but the military continued to expand its
hold throughout the government. Civilian rule was not restored until
1985. Uruguay''s political and labor conditions are among the freest
on the continent.
total: 14
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 2 (2004 est.)
total: 50
1,524 to 2,437 m: 2
914 to 1,523 m: 17
under 914 m: 31 (2004 est.)
water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life Conservation
2% (2003)
7.963 billion kWh (2001)
6.152 billion kWh (2001)
123 million kWh (2001)
1.377 billion kWh (2001)
23.7% (2002)
lowest 10%: 3.7%
highest 10%: 25.8% (1997)
agriculture 14%, industry 16%, services 70%
meat, rice, leather products, wool, fish, dairy products
Brazil 21.4%, US 11.4%, Argentina 7.1%, Germany 6.6%, China
4.3%, Mexico 4.1%, Italy 4.1%, Canada 4% (2003)
19 departments (departamentos, singular - departamento);
Artigas, Canelones, Cerro Largo, Colonia, Durazno, Flores, Florida,
Lavalleja, Maldonado, Montevideo, Paysandu, Rio Negro, Rivera,
Rocha, Salto, San Jose, Soriano, Tacuarembo, Treinta y Tres
rice, wheat, corn, barley; livestock; fish
64 (2003 est.)
14.44 births/1,000 population (2004 est.)
Army, Navy (includes Naval Air Arm, Marines, Maritime
Prefecture in wartime), Air Force
revenues: $2.934 billion
expenditures: $3.425 billion, including capital expenditures of $193
million (2003)
Uruguay''s well-to-do economy is characterized by an
export-oriented agricultural sector, a well-educated workforce, and
high levels of social spending. After averaging growth of 5%
annually during 1996-98, in 1999-2002 the economy suffered a major
downturn, stemming largely from the spillover effects of the
economic problems of its large neighbors, Argentina and Brazil. For
instance, in 2001-02 massive withdrawals by Argentina of dollars
deposited in Uruguayan banks led to a plunge in the Uruguyan peso
and a massive rise in unemployment. Total GDP in these four years
dropped by nearly 20%, with 2002 the worst year due to the serious
banking crisis. Unemployment rose to nearly 20% in 2002, inflation
surged, and the burden of external debt doubled. Cooperation with
the IMF and the US has limited the damage. The debt swap with
private creditors carried out in 2003, which extended the maturity
dates on nearly half of Uruguay''s $11.3 billion in public debt,
substantially alleviated the country''s amortization burden in the
coming years and restored public confidence. The economy is expected
to resume growth in 2004 (perhaps 4% or more) as a result of high
commodity prices for Uruguayan exports, the weakness of the dollar
against the euro, growth in the region, low international interest
rates, and greater export competitiveness. On the negative side, in
December 2003 the electorate voted to repeal the law permitting a
cautious liberalization of the energy industry.
gas 192 km (2004)','1d81430fef75690459da05793d4b55b7dbf983dd2fa2d92cc505cf443a30a318','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b1cca77dca29780cf54ebcc2cff0b0060cc7e0452efe621ea973fc0b8902000',2004,'UZ','Uzbekistan','economy',637,'Russia conquered Uzbekistan in the late 19th century.
Stiff resistance to the Red Army after World War I was eventually
suppressed and a socialist republic set up in 1924. During the
Soviet era, intensive production of "white gold" (cotton) and grain
led to overuse of agrochemicals and the depletion of water supplies,
which have left the land poisoned and the Aral Sea and certain
rivers half dry. Independent since 1991, the country seeks to
gradually lessen its dependence on agriculture while developing its
mineral and petroleum reserves. Current concerns include terrorism
by Islamic militants, economic stagnation, and the curtailment of
human rights and democratization.
total: 33
over 3,047 m: 5
2,438 to 3,047 m: 14
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 4 (2003 est.)
total: 214
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 200 (2003 est.)
shrinkage of the Aral Sea is resulting in growing
concentrations of chemical pesticides and natural salts; these
substances are then blown from the increasingly exposed lake bed and
contribute to desertification; water pollution from industrial
wastes and the heavy use of fertilizers and pesticides is the cause
of many human health disorders; increasing soil salination; soil
contamination from buried nuclear processing and agricultural
chemicals, including DDT
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
2% (FY97)
44.49 billion kWh (2001)
47.07 billion kWh (2001)
9.7 billion kWh (2001)
3.998 billion kWh (2001)
NA (2004 est.)
lowest 10%: 1.2%
highest 10%: 32.8% (1998)
agriculture 44%, industry 20%, services 36% (1995)
cotton 41.5%, gold 9.6%, energy products 9.6%, mineral
fertilizers, ferrous metals, textiles, food products, automobiles
(1998 est.)
Russia 22.4%, China 9.3%, Ukraine 7.5%, Tajikistan 6.2%,
Bangladesh 4.7%, Turkey 4.6%, Japan 4.3%, Kazakhstan 4.2%, US 4.1%
(2003)
12 provinces (viloyatlar, singular - viloyat), 1
autonomous republic* (respublika), and 1 city** (shahar); Andijon
Viloyati, Buxoro Viloyati, Farg''ona Viloyati, Jizzax Viloyati,
Namangan Viloyati, Navoiy Viloyati, Qashqadaryo Viloyati (Qarshi),
Qaraqalpog''iston Respublikasi* (Nukus), Samarqand Viloyati, Sirdaryo
Viloyati (Guliston), Surxondaryo Viloyati (Termiz), Toshkent
Shahri**, Toshkent Viloyati, Xorazm Viloyati (Urganch)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
cotton, vegetables, fruits, grain; livestock
247 (2003 est.)
26.12 births/1,000 population (2004 est.)
Army, Air and Air Defense Forces, National Guard
revenues: $2.176 billion
expenditures: $2.207 billion, including capital expenditures of NA
(2003 est.)
Uzbekistan is a dry, landlocked country of which 11%
consists of intensely cultivated, irrigated river valleys. More than
60% of its population lives in densely populated rural communities.
Uzbekistan is now the world''s second-largest cotton exporter, a
large producer of gold and oil, and a regionally significant
producer of chemicals and machinery. Following independence in
December 1991, the government sought to prop up its Soviet-style
command economy with subsidies and tight controls on production and
prices. Uzbekistan responded to the negative external conditions
generated by the Asian and Russian financial crises by emphasizing
import substitute industrialization and by tightening export and
currency controls within its already largely closed economy. The
government, while aware of the need to improve the investment
climate, sponsors measures that often increase, not decrease, the
government''s control over business decisions. A sharp increase in
the inequality of income distribution has hurt the lower ranks of
society since independence. In 2003, the government accepted the
obligations of Article VIII under the International Monetary Fund
(IMF), providing for full currency convertibility. However, strict
currency controls and tightening of borders have lessened the
effects of convertibility and have also lead to some shortages which
have further stifled economic activity.
gas 9,149 km; oil 869 km; refined products 33 km (2004)
Venezuela
extra heavy crude 992 km; gas 5,262 km; oil 7,360 km;
refined products 1,681 km; unknown (oil/water) 141 km (2004)
Vietnam
condensate/gas 432 km; gas 210 km; oil 3 km; refined
products 206 km (2004)','f3c54359c2934c483c23b12f5ebe846d8fc7ac1e6608b2e2098eb6db4370ccc2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305e20852e0faefa98826bf1545268fa92c82532e31fe3b3daf5ccf054a1b641',2004,'VU','Vanuatu','economy',638,'The British and French, who settled the New Hebrides in the
19th century, agreed in 1906 to an Anglo-French Condominium, which
administered the islands until independence in 1980.
Venezuela
Venezuela was one of three countries that emerged from the
collapse of Gran Colombia in 1830 (the others being Colombia and
Ecuador). For most of the first half of the 20th century, Venezuela
was ruled by generally benevolent military strongmen, who promoted
the oil industry and allowed for some social reforms. Democratically
elected governments have held sway since 1959. Current concerns
include: a polarized political environment, a divided military,
drug-related conflicts along the Colombian border, increasing
internal drug consumption, overdependence on the petroleum industry
with its price fluctuations, and irresponsible mining operations
that are endangering the rain forest and indigenous peoples.
Vietnam
The conquest of Vietnam by France began in 1858 and was
completed by 1884. It became part of French Indochina in 1887.
Independence was declared after World War II, but the French
continued to rule until 1954 when they were defeated by Communist
forces under Ho Chi Minh, who took control of the North. US economic
and military aid to South Vietnam grew through the 1960s in an
attempt to bolster the government, but US armed forces were
withdrawn following a cease-fire agreement in 1973. Two years later,
North Vietnamese forces overran the South. Despite the return of
peace, for over two decades the country experienced little economic
growth because of conservative leadership policies. Since 2001,
Vietnamese authorities have committed to economic liberalization and
enacted structural reforms needed to modernize the economy and to
produce more competitive, export-driven industries. The country
continues to experience protests from the Montagnard ethnic minority
population of the Central Highlands over loss of land to Vietnamese
settlers and religious persecution.
Virgin Islands
During the 17th century, the archipelago was divided
into two territorial units, one English and the other Danish.
Sugarcane, produced by slave labor, drove the islands'' economy
during the 18th and early 19th centuries. In 1917, the US purchased
the Danish portion, which had been in economic decline since the
abolition of slavery in 1848.
Wake Island
The US annexed Wake Island in 1899 for a cable station.
An important air and naval base was constructed in 1940-41. In
December 1941, the island was captured by the Japanese and held
until the end of World War II. In subsequent years, Wake was
developed as a stopover and refueling site for military and
commercial aircraft transiting the Pacific. Since 1974, the island''s
airstrip has been used by the US military and some commercial cargo
planes, as well as for emergency landings. There are over 700
landings a year on the island.
total: 3
2,438 to 3,047 m: 1
1524 to 2437 m: 1
914 to 1,523 m: 1 (2004 est.)
Venezuela
total: 127
over 3,047 m: 5
2,438 to 3,047 m: 11
1,524 to 2,437 m: 31
914 to 1,523 m: 61
under 914 m: 19 (2004 est.)
Vietnam
total: 16
over 3,047 m: 6
2,438 to 3,047 m: 4
1,524 to 2,437 m: 6 (2003 est.)
Virgin Islands
total: 2
1,524 to 2,437 m: 2 (2004 est.)
Wake Island
total: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 27
914 to 1,523 m: 10
under 914 m: 17 (2004 est.)
Venezuela
total: 242
1,524 to 2,437 m: 10
914 to 1,523 m: 88
under 914 m: 144 (2004 est.)
Vietnam
total: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2003 est.)
a majority of the population does not have access to a
potable and reliable supply of water; deforestation
Venezuela
sewage pollution of Lago de Valencia; oil and urban
pollution of Lago de Maracaibo; deforestation; soil degradation;
urban and industrial pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem from irresponsible mining
operations
Vietnam
logging and slash-and-burn agricultural practices contribute
to deforestation and soil degradation; water pollution and
overfishing threaten marine life populations; groundwater
contamination limits potable water supply; growing urban
industrialization and population migration are rapidly degrading
environment in Hanoi and Ho Chi Minh City
Virgin Islands
lack of natural freshwater resources
Wake Island
NA
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Venezuela
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
Vietnam
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
NA
Venezuela
1.3% (2003)
Vietnam
2.5% (FY98)
West Bank
NA
43.46 million kWh (2001)
Venezuela
87.6 billion kWh (2001)
Vietnam
29.8 billion kWh (2001)
Virgin Islands
1.03 billion kWh (2001)
Wake Island
NA
40.42 million kWh (2001)
Venezuela
81.47 billion kWh (2001)
Vietnam
27.71 billion kWh (2001)
Virgin Islands
957.9 million kWh (2001)
0 kWh (2001)
Venezuela
0 kWh (2001)
Vietnam
0 kWh (2001)
Virgin Islands
0 kWh (2001)
0 kWh (2001)
Venezuela
0 kWh (2001)
Vietnam
0 kWh (2001)
Virgin Islands
0 kWh (2001)
NA
Venezuela
47% (1998 est.)
Vietnam
37% (1998 est.)
Virgin Islands
NA
lowest 10%: NA
highest 10%: NA
Venezuela
lowest 10%: 0.8%
highest 10%: 36.5% (1998)
Vietnam
lowest 10%: 3.6%
highest 10%: 29.9% (1998)
Virgin Islands
lowest 10%: NA
highest 10%: NA
agriculture 65%, industry 5%, services 30% (2000 est.)
Venezuela
agriculture 13%, industry 23%, services 64% (1997 est.)
Vietnam
agriculture 63%, industry and services 37% (2000 est.)
Virgin Islands
agriculture 1%, industry 19%, services 80% (2003 est.)
copra, beef, cocoa, timber, kava, coffee
Venezuela
petroleum, bauxite and aluminum, steel, chemicals,
agricultural products, basic manufactures
Vietnam
crude oil, marine products, rice, coffee, rubber, tea,
garments, shoes
Virgin Islands
refined petroleum products
India 32.8%, Thailand 25.5%, Indonesia 9.6%, Japan 7.6%,
Australia 4%, Poland 4% (2003)
Venezuela
US 52.9%, Netherlands Antilles 5%, Dominican Republic 3%
(2003)
Vietnam
US 21.9%, Japan 13.8%, Australia 6.8%, China 6.5%, Germany
5.8%, Singapore 4.6%, UK 4.4% (2003)
Virgin Islands
US, Puerto Rico
6 provinces; Malampa, Penama, Sanma, Shefa, Tafea, Torba
Venezuela
23 states (estados, singular - estado), 1 federal
district* (distrito federal), and 1 federal dependency**
(dependencia federal); Amazonas, Anzoategui, Apure, Aragua, Barinas,
Bolivar, Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**,
Distrito Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas,
Nueva Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas,
Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Vietnam
59 provinces (tinh, singular and plural) and 5
municipalities (thu do, singular and plural)
provinces: An Giang, Bac Giang, Bac Kan, Bac Lieu, Bac Ninh, Ba
Ria-Vung Tau, Ben Tre, Binh Dinh, Binh Duong, Binh Phuoc, Binh
Thuan, Ca Mau, Cao Bang, Dac Lak, Dac Nong, Dien Bien, Dong Nai,
Dong Thap, Gia Lai, Ha Giang, Hai Duong, Ha Nam, Ha Tay, Ha Tinh,
Hau Giang, Hoa Binh, Hung Yen, Khanh Hoa, Kien Giang, Kon Tum, Lai
Chau, Lam Dong, Lang Son, Lao Cai, Long An, Nam Dinh, Nghe An, Ninh
Binh, Ninh Thuan, Phu Tho, Phu Yen, Quang Binh, Quang Nam, Quang
Ngai, Quang Ninh, Quang Tri, Soc Trang, Son La, Tay Ninh, Thai Binh,
Thai Nguyen, Thanh Hoa, Thua Thien-Hue, Tien Giang, Tra Vinh, Tuyen
Quang, Vinh Long, Vinh Phuc, Yen Bai
municipalities: Can Tho, Da Nang, Hai Phong, Ha Noi, Ho Chi Minh
Virgin Islands
none (territory of the US); there are no first-order
administrative divisions as defined by the US Government, but there
are three islands at the second order; Saint Croix, Saint John,
Saint Thomas
copra, coconuts, cocoa, coffee, taro, yams, coconuts,
fruits, vegetables; fish, beef
Venezuela
corn, sorghum, sugarcane, rice, bananas, vegetables,
coffee; beef, pork, milk, eggs; fish
Vietnam
paddy rice, corn, potatoes, rubber, soybeans, coffee, tea,
bananas, sugar; poultry, pigs, fish
Virgin Islands
fruit, vegetables, sorghum; Senepol cattle
30 (2003 est.)
Venezuela
368 (2003 est.)
Vietnam
19 (2003 est.)
Virgin Islands
2 (2003 est.)
Wake Island
1 (2003 est.)
23.67 births/1,000 population (2004 est.)
Venezuela
19.34 births/1,000 population (2004 est.)
Vietnam
19.58 births/1,000 population (2004 est.)
Virgin Islands
14.49 births/1,000 population (2004 est.)
no regular military forces; Vanuatu Police Force (VPF;
including the paramilitary Mobile Force or VMF)
Venezuela
National Armed Forces (Fuerzas Armadas Nacionales or FAN)
includes Ground Forces or Army (Fuerzas Terrestres or Ejercito),
Naval Forces (Fuerzas Navales or Armada - including marines and
Coast Guard), Air Force (Fuerzas Aereas or Aviacion), Armed Forces
of Cooperation or National Guard (Fuerzas Armadas de Cooperacion or
Guardia Nacional)
Vietnam
People''s Army of Vietnam: Ground Forces, People''s Navy
Command (including Naval Infantry), Air and Air Defense Force, Coast
Guard
revenues: $94.4 million
expenditures: $99.8 million, including capital expenditures of $30.4
million (1996 est.)
Venezuela
revenues: $19.33 billion
expenditures: $24.34 billion, including capital expenditures of $2.6
billion (2003)
Vietnam
revenues: $8.689 billion
expenditures: $9.718 billion, including capital expenditures of $1.8
billion (2003 est.)
Virgin Islands
revenues: $560
expenditures: NA (2003)
This South Pacific island economy is based primarily on
small-scale agriculture, which provides a living for 65% of the
population. Fishing, offshore financial services, and tourism, with
about 50,000 visitors in 1997, are other mainstays of the economy.
Mineral deposits are negligible; the country has no known petroleum
deposits. A small light industry sector caters to the local market.
Tax revenues come mainly from import duties. Economic development is
hindered by dependence on relatively few commodity exports,
vulnerability to natural disasters, and long distances from main
markets and between constituent islands. A severe earthquake in
November 1999 followed by a tsunami, caused extensive damage to the
northern island of Pentecote and left thousands homeless. Another
powerful earthquake in January 2002 caused extensive damage in the
capital, Port-Vila, and surrounding areas, and also was followed by
a tsunami. GDP growth rose less than 3% on average in the 1990s. In
response to foreign concerns, the government has promised to tighten
regulation of its offshore financial center. In mid-2002 the
government stepped up efforts to boost tourism. Agriculture,
especially livestock farming, is a second target for growth.
Australia and New Zealand are the main suppliers of tourists and
foreign aid. Growth expanded moderately in 2003.
Venezuela
Venezuela continues to be highly dependent on the
petroleum sector, which accounts for roughly one-third of GDP,
around 80% of export earnings, and more than half of government
operating revenues. Despite higher oil prices at the end of 2002 and
into 2003, domestic political instability, culminating in a
disastrous two-month national oil strike from December 2002 to
February 2003, temporarily halted economic activity. The economy
remained in depression in 2003, declining by 9.2% after an 8.9% fall
in 2002. In late 2003, President CHAVEZ committed himself to $1
billion in new social programs, money the government does not have.
Vietnam
Vietnam is a poor, densely-populated country that has had to
recover from the ravages of war, the loss of financial support from
the old Soviet Bloc, and the rigidities of a centrally-planned
economy. Substantial progress was achieved from 1986 to 1996 in
moving forward from an extremely low starting point - growth
averaged around 9% per year from 1993 to 1997. The 1997 Asian
financial crisis highlighted the problems in the Vietnamese economy,
but rather than prompting reform, reaffirmed the government''s belief
that shifting to a market-oriented economy would lead to disaster.
GDP growth of 8.5% in 1997 fell to 6% in 1998 and 5% in 1999. Growth
then rose to 6% to 7% in 2000-02 even against the background of
global recession. These numbers mask some major difficulties in
economic performance. Many domestic industries, including coal,
cement, steel, and paper, have reported large stockpiles of
inventory and tough competition from more efficient foreign
producers. Since the Party elected new leadership in 2001,
Vietnamese authorities have reaffirmed their commitment to economic
liberalization and have moved to implement the structural reforms
needed to modernize the economy and to produce more competitive,
export-driven industries. The US-Vietnam Bilateral Trade Agreement
entered into force near the end of 2001 and is expected to
significantly increase Vietnam''s exports to the US. The US is
assisting Vietnam with implementing the legal and structural reforms
called for in the agreement.
Virgin Islands
Tourism is the primary economic activity, accounting
for 80% of GDP and employment. The islands normally host 2 million
visitors a year. The manufacturing sector consists of petroleum
refining, textiles, electronics, pharmaceuticals, and watch
assembly. The agricultural sector is small, with most food being
imported. International business and financial services are a small
but growing component of the economy. One of the world''s largest
petroleum refineries is at Saint Croix. The islands are subject to
substantial damage from storms. The government is working to improve
fiscal discipline, to support construction projects in the private
sector, to expand tourist facilities, to reduce crime, and to
protect the environment.
Wake Island
Economic activity is limited to providing services to
contractors located on the island. All food and manufactured goods
must be imported.','71f5518347ff4688c2cdbd641aa07db8dd871f3c810f8193a361319f73d067dc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f38e4f272a7f9bfd53d2e3ce54d47c6186023a3fbccb5cbc982ea1b0b46a01f',2004,'EH','Western Sahara','economy',639,'Morocco virtually annexed the northern two-thirds of
Western Sahara (formerly Spanish Sahara) in 1976, and the rest of
the territory in 1979, following Mauritania''s withdrawal. A
guerrilla war with the Polisario Front contesting Rabat''s
sovereignty ended in a 1991 UN-brokered cease-fire; a UN-organized
referendum on final status has been repeatedly postponed.
World
Globally, the 20th century was marked by: (a) two devastating
world wars; (b) the Great Depression of the 1930s; (c) the end of
vast colonial empires; (d) rapid advances in science and technology,
from the first airplane flight at Kitty Hawk, North Carolina (US) to
the landing on the moon; (e) the Cold War between the Western
alliance and the Warsaw Pact nations; (f) a sharp rise in living
standards in North America, Europe, and Japan; (g) increased
concerns about the environment, including loss of forests, shortages
of energy and water, the decline in biological diversity, and air
pollution; (h) the onset of the AIDS epidemic; and (i) the ultimate
emergence of the US as the only world superpower. The planet''s
population continues to explode: from 1 billion in 1820, to 2
billion in 1930, 3 billion in 1960, 4 billion in 1974, 5 billion in
1988, and 6 billion in 2000. For the 21st century, the continued
exponential growth in science and technology raises both hopes
(e.g., advances in medicine) and fears (e.g., development of even
more lethal weapons of war).
total: 3
2,438 to 3,047 m: 3 (2004 est.)
total: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
sparse water and lack of arable land
World
large areas subject to overpopulation, industrial disasters,
pollution (air, water, acid rain, toxic substances), loss of
vegetation (overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
NA
World
roughly 2% of gross world product (1999 est.)
90 million kWh (2001)
World
14.93 trillion kWh (2001 est.)
83.7 million kWh (2001)
World
13.94 trillion kWh (2001 est.)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
World
lowest 10%: NA
highest 10%: NA
animal husbandry and subsistence farming 50%
World
agriculture NA, industry NA, services NA
phosphates 62%
World
the whole range of industrial and agricultural goods and
services
Morocco claims and administers Western Sahara, so
trade partners are included in overall Moroccan accounts
World
US 16.4%, Germany 7.9%, UK 5.2%, France 5.1%, China 5%, Japan
4.6% (2003)
none (under de facto control of Morocco)
World
271 nations, dependent areas, and other entities
fruits and vegetables (grown in the few oases);
camels, sheep, goats (kept by nomads)
11 (2003 est.)
NA births/1,000 population
World
20.24 births/1,000 population (2004 est.)
revenues: NA
expenditures: NA, including capital expenditures of NA
Western Sahara depends on pastoral nomadism, fishing,
and phosphate mining as the principal sources of income for the
population. The territory lacks sufficient rainfall for sustainable
agricultural production, and most of the food for the urban
population must be imported. All trade and other economic activities
are controlled by the Moroccan Government. Moroccan energy interests
in 2001 signed contracts to explore for oil off the coast of Western
Sahara, which has angered the Polisario. Incomes and standards of
living in Western Sahara are substantially below the Moroccan level.
World
Global output rose by 3.7% in 2003, led by China (9.1%), India
(7.6%), and Russia (7.3%). The other 14 successor nations of the
USSR and the other old Warsaw Pact nations again experienced widely
divergent growth rates; the three Baltic nations continued as strong
performers, in the 5%-7% range of growth. Growth results posted by
the major industrial countries varied from a loss by Germany (-0.1%)
to a strong gain by the United States (3.1%). The developing nations
also varied in their growth results, with many countries facing
population increases that erode gains in output. Externally, the
nation-state, as a bedrock economic-political institution, is
steadily losing control over international flows of people, goods,
funds, and technology. Internally, the central government often
finds its control over resources slipping as separatist regional
movements - typically based on ethnicity - gain momentum, e.g., in
many of the successor states of the former Soviet Union, in the
former Yugoslavia, in India, in Iraq, in Indonesia, and in Canada.
Externally, the central government is losing decision-making powers
to international bodies. In Western Europe, governments face the
difficult political problem of channeling resources away from
welfare programs in order to increase investment and strengthen
incentives to seek employment. The addition of 80 million people
each year to an already overcrowded globe is exacerbating the
problems of pollution, desertification, underemployment, epidemics,
and famine. Because of their own internal problems and priorities,
the industrialized countries devote insufficient resources to deal
effectively with the poorer areas of the world, which, at least from
the economic point of view, are becoming further marginalized. The
introduction of the euro as the common currency of much of Western
Europe in January 1999, while paving the way for an integrated
economic powerhouse, poses economic risks because of varying levels
of income and cultural and political differences among the
participating nations. The terrorist attacks on the US on 11
September 2001 accentuate a further growing risk to global
prosperity, illustrated, for example, by the reallocation of
resources away from investment to anti-terrorist programs. The
opening of war in March 2003 between a US-led coalition and Iraq
added new uncertainties to global economic prospects. After the
coalition victory, the complex political difficulties and the high
economic cost of establishing domestic order in Iraq became major
global problems that continue into 2004.','b765d8bc4fbb9c83c025d011cc0c5b622ea9f2b01b24728ee9c246d5e41d1ef2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ecded0e082e18a77b45c9a514e1d96f1783354711d5389ecf9a1d2903e15bac',2004,'YE','Yemen','economy',640,'North Yemen became independent of the Ottoman Empire in 1918.
The British, who had set up a protectorate area around the southern
port of Aden in the 19th century, withdrew in 1967 from what became
South Yemen. Three years later, the southern government adopted a
Marxist orientation. The massive exodus of hundreds of thousands of
Yemenis from the south to the north contributed to two decades of
hostility between the states. The two countries were formally
unified as the Republic of Yemen in 1990. A southern secessionist
movement in 1994 was quickly subdued. In 2000, Saudi Arabia and
Yemen agreed to a delimitation of their border.
total: 16
over 3,047 m: 3
2,438 to 3,047 m: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 11
under 914 m: 4 (2004 est.)
very limited natural fresh water resources; inadequate
supplies of potable water; overgrazing; soil erosion; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
7.9% (2003)
3.01 billion kWh (2001)
2.8 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
15.7% (2001)
lowest 10%: 3%
highest 10%: 25.9% (2003)
most people are employed in agriculture and herding; services,
construction, industry, and commerce account for less than
one-fourth of the labor force
crude oil, coffee, dried and salted fish
China 31.7%, Thailand 20.3%, India 15.6%, South Korea 4.9%,
Malaysia 4.3% (2003)
19 governorates (muhafazat, singular - muhafazah); Abyan,
''Adan, Ad Dali'', Al Bayda'', Al Hudaydah, Al Jawf, Al Mahrah, Al
Mahwit, ''Amran, Dhamar, Hadramawt, Hajjah, Ibb, Lahij, Ma''rib,
Sa''dah, San''a'', Shabwah, Ta''izz
note: for electoral and administrative purposes, the capital city of
Sanaa is treated as an additional governorate
grain, fruits, vegetables, pulses, qat (mildly narcotic
shrub), coffee, cotton; dairy products, livestock (sheep, goats,
cattle, camels), poultry; fish
44 (2003 est.)
43.16 births/1,000 population (2004 est.)
Army (including Special Forces), Naval Forces and Coastal
Defenses (including Marines), Air Force (including Air Defense
Forces), Republican Guard
revenues: $3.729 billion
expenditures: $4.107 billion, including capital expenditures of NA
(2003 est.)
Yemen, one of the poorest countries in the Arab world,
reported strong growth in the mid-1990s with the onset of oil
production. It has been harmed by periodic declines in oil prices,
but now benefits from current high prices. Yemen has embarked on an
IMF-supported structural adjustment program designed to modernize
and streamline the economy, which has led to substantial foreign
debt relief and restructuring. International donors, meeting in
Paris in October 2002, agreed on a further $2.3 billion economic
support package. Yemen has worked to maintain tight control over
spending and to implement additional components of the IMF program.
A markedly high population growth rate and internal political
dissension complicate the government''s task. Plans include a
diversification of the economy, encouragement of tourism, and more
efficient use of scarce water resources.
gas 88 km; oil 1,174 km (2004)','9c1e31205675be6752d7d5118d218911245360d1c602b732c36f6f9a5fc7701c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('158f2d71696d10c7fb69f7c340deaec95d7f110ee1de71b2c31fda478a40043d',2004,'ZM','Zambia','economy',641,'The territory of Northern Rhodesia was administered by the
South Africa Company from 1891 until it was taken over by the UK in
1923. During the 1920s and 1930s, advances in mining spurred
development and immigration. The name was changed to Zambia upon
independence in 1964. In the 1980s and 1990s, declining copper
prices and a prolonged drought hurt the economy. Elections in 1991
brought an end to one-party rule, but the subsequent vote in 1996
saw blatant harassment of opposition parties. The election in 2001
was marked by administrative problems with three parties filing a
legal petition challenging the election of ruling party candidate
Levy MWANAWASA. The new president launched a far-reaching
anti-corruption campaign in 2002, which resulted in the prosecution
of former President Frederick CHILUBA and many of his supporters in
late 2003. Opposition parties currently hold a majority of seats in
the National Assembly.
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2004 est.)
total: 99
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 62
under 914 m: 32 (2004 est.)
air pollution and resulting acid rain in the mineral
extraction and refining region; chemical runoff into watersheds;
poaching seriously threatens rhinoceros, elephant, antelope, and
large cat populations; deforestation; soil erosion; desertification;
lack of adequate water treatment presents human health risks
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
0.9% (2003)
7.751 billion kWh (2001)
5.458 billion kWh (2001)
0 kWh (2001)
1.75 billion kWh (2001)
86% (1993)
lowest 10%: 1.1%
highest 10%: 41% (1998)
agriculture 85%, industry 6%, services 9%
copper 55%, cobalt, electricity, tobacco, flowers, cotton
UK 26.7%, South Africa 21.6%, Tanzania 13.9%, Switzerland
8.1% (2003)
9 provinces; Central, Copperbelt, Eastern, Luapula, Lusaka,
Northern, North-Western, Southern, Western
corn, sorghum, rice, peanuts, sunflower seed, vegetables,
flowers, tobacco, cotton, sugarcane, cassava (tapioca); cattle,
goats, pigs, poultry, milk, eggs, hides; coffee
109 (2003 est.)
38.99 births/1,000 population (2004 est.)
Zambian National Defense Force (ZNDF): Army, Air Force,
Police, National Service
revenues: $896.7 million
expenditures: $1.142 billion, including capital expenditures of NA
(2003 est.)
Despite progress in privatization and budgetary reform,
Zambia''s economic growth remains below the 5% to 7% necessary to
reduce poverty significantly. Privatization of government-owned
copper mines relieved the government from covering mammoth losses
generated by the industry and greatly improved the chances for
copper mining to return to profitability and spur economic growth.
Copper output increased in 2003 and is expected to increase again in
2004, due to higher copper prices. The maize harvest doubled in
2003, helping boost GDP by 4.0%. Cooperation continues with
international bodies on programs to reduce poverty, including a new
lending arrangement with the IMF expected in the second quarter,
2004. A tighter monetary policy will help cut inflation, but Zambia
still has a serious problem with fiscal discipline.
oil 771 km (2004)','a439493d8a4389703d797651ac316742f17cfac2e82746d5b8bafb0f37e8dca2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('018702eb15f753d1db288575f7b2f5569ee133c1b3f237d1292b6a4449712c1c',2004,'AF','Afghanistan','economy',642,'total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 1 (2004 est.)
total: 37
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 11 (2004 est.)
limited natural fresh water resources; inadequate
supplies of potable water; soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification; air and water
pollution
Akrotiri
shooting around the salt lake; note - breeding place for
loggerhead and green turtles; only remaining colony of griffon
vultures is on the base
party to: Biodiversity, Desertification, Endangered
Species, Environmental Modification, Marine Dumping
signed, but not ratified: Climate Change, Hazardous Wastes, Law of
the Sea, Marine Life Conservation
1% (2003)
334.8 million kWh (2001)
511.4 million kWh (2001)
200 million kWh (2001)
0 kWh (2001)
23% (2002)
lowest 10%: NA
highest 10%: NA
agriculture 80%, industry 10%, services 10% (1990 est.)
opium, fruits and nuts, handwoven carpets, wool, cotton,
hides and pelts, precious and semi-precious gems
US 27%, France 17.5%, India 16.6%, Pakistan 13.3% (2003)
34 provinces (velayat, singular - velayat); Badakhshan,
Badghis, Baghlan, Balkh, Bamian, Daykondi, Farah, Faryab, Ghazni,
Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Khowst,
Konar, Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Nurestan,
Oruzgan, Paktia, Paktika, Panjshir, Parvan, Samangan, Sar-e Pol,
Takhar, Vardak, and Zabol
opium, wheat, fruits, nuts, wool, mutton, sheepskins,
lambskins
47 (2003 est.)
47.27 births/1,000 population (2004 est.)
Afghan National Army, currently being trained by the US
with the assistance of the international community, is 7,000 strong;
note - the December 2001 Bonn Agreement called for all militia
forces to come under the authority of the central government, but
regional leaders have continued to retain their militias and the
formation of a national army remains a gradual process;
Afghanistan''s militia forces continue to be factionalized, largely
along ethnic lines
revenues: $200 million
expenditures: $550 million, including capital expenditures of NA
(2003 plan)
Kabul
Akrotiri
Episkopi; also serves as capital of Dhekelia
gas 387 km (2004)
note - includes only political parties approved by the
Ministry of Justice: Afghan Millat [Anwarul Haq AHADI]; De
Afghanistan De Solay Ghorzang Gond [Shahnawaz TANAI]; De Afghanistan
De Solay Mili Islami Gond [Shah Mahmood Polal ZAI]; Harakat-e-Islami
Afghanistan [Mohammad Asif MOHSINEE];
Hezb-e-Aarman-e-Mardum-e-Afghanistan [Iihaj Saraj-u-din ZAFAREE];
Hezb-e-Aazadee Afghanistan [Abdul MALIK]; Hezb-e-Adalat-e-Islami
Afghanistan [Mohammad Kabeer MARZBAN]; Hezb-e-Afghanistan-e-Wahid
[Mohammad Wasil RAHEEMEE]; Hezb-e-Afghan Watan Islami Gond [NA
leader]; Hezb-e-Congra-e-Mili Afghanistan [Lateef PIDRAM];
Hezb-e-Falah-e-Mardum-e-Afghanistan [Mohammad ZAREEF];
Hezb-e-Libral-e-Aazadee Khwa-e-Mardum-e-Afghanistan [Ajmal SOHAIL];
Hezb-e-Hambastagee Mili Jawanan-e-Afghanistan [Mohammad Jamil
KARZAI]; Hezb-e-Hamnbatagee-e-Afghanistan [Abdul Khaleq NEMAT];
Hezb-e-Harakat-e-Mili Wahdat-e-Afghanistan [Moahammad Nadir AATASH];
Hezb-e-Harak-e-Islami Mardum-e-Afghanistan [Ilhaj Said Hssain
ANWARY]; Hezb-e-Ifazat Az Uqoq-e-Bashar Wa Inkishaf-e-Afghanistan
[Baryalai NASRATEE]; Hezb-e-Istiqlal-e-Afghanistan [Dr. Gh. Farooq
NIJZRABEE]; Hezb-e-Jamhoree Khwahan [Sibghatullah SANJAR];
Hezb-e-Kar Wa Tawsiha-e-Afghanistan [Zulfiar OMID]; Hezb-e-Mili
Afghanistan [Abdul Rasheed AARYAN]; Hezb-e-Mili
Wahdat-e-Aqwam-e-Islami Afghanistan [Mohammad Shah KHOGYANEE];
Hezb-e-Nuhzhat-e-Mili Afghanistan [Ahmad Wali MASOUD];
Hezb-e-Paiwand-e-Mili Afghanistan [Said Mansoor NADIRI];
Hezb-e-Rastakhaiz-e-Islami Mardum-e-Afghanistan [Said ZAHIR];
Hezb-e-Refah-e-Mardum-e-Afghanistan [Mia Gul WASEEQ];
Hezb-e-Risalat-e-Mardum-e-Afghanistan [Noor Aqa ROEEN];
Hezb-e-Sahadat-e-Mardum-e-Afghanistan [Mohammad Zubair PAIROZ];
Hezb-e-Sahadat-e-Mili Wa Islami Afghanistan [Mohammad Usman
SALIGZADA]; Hezb-e-Sulh-e-Mili Islami Aqwam-e-Afghanistan [Abdul
Qahir SHARYATEE]; Hezb-e-Sulh Wa Wahdat-e-Mili Afghanistan [Abdul
Qadir IMAMEE]; Hezb-e-Tafahum-e-Wa Democracy Afghanistan [Ahamad
SHAHEEN]; Hezb-e-Wahdat-e-Islami Afghanistan [Mohammad Karim
KHALILI]; Hezb-e-Wahdat-e-Islami Mardum-e-Afghanistan [Haji Mohammad
MUHAQIQ]; Hezb-e-Wahdat-e-Mili Afghanistan [Abdul Rasheed Jalili];
Jamahat-ul-Dahwat ilal Qurhan-wa-Sunat-ul-Afghanistan [Mawlawee
Samiullah NAJEEBEE]; Jombesh-e Milli [Abdul Rashjid DOSTUM];
Mahaz-e-Mili Islami Afghanistan [Said Ahmad GAILANEE]; Majmah-e-Mili
Fahaleen-e-Sulh-e-Afghanistan [Shams ul Haq Noor SHAMS];
Nuhzat-e-Aazadee Wa democracy Afghanistan [Abdul Raqeeb Jawid
KUHISTANEE]; Nuhzat-e-Hambastagee Mili Afghanistan [Peer Said Ishaq
GAILANEE]; Sazman-e-Islami Afghanistan-e-Jawan [Siad Jawad
HUSSAINEE]; Tahreek Wahdat-e-Mili [Sultan Mahmood DHAZI] (30 Sep
2004)','5d3fc46c3cc3db9f7e15cab94893eecf0fe54875758b67536d5ba29a0c1e8f3a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7bcaaa37f8fcbb5ad2b95617cc20bfc69fd9875edbe6af16727a1e0707ed4fe',2004,'AL','Albania','economy',643,'total: 3
2,438 to 3,047 m: 3 (2004 est.)
total: 8
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 4 (2004 est.)
deforestation; soil erosion; water pollution from industrial
and domestic effluents
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.49% (FY02)
5.289 billion kWh (2001)
5.898 billion kWh (2001)
1.2 billion kWh (2001)
221 million kWh (2001)
30% (2001 est.)
lowest 10%: NA
highest 10%: NA
agriculture 57%, non-agricultural private sector 20%, public
sector 23% (2003 est.)
textiles and footwear; asphalt, metals and metallic ores,
crude oil; vegetables, fruits, tobacco
Italy 74.9%, Greece 12.8%, Germany 3.4% (2003)
12 counties (qarqe, singular - qark); Qarku i Beratit, Qarku
i Dibres, Qarku i Durresit, Qarku i Elbasanit, Qarku i Fierit, Qarku
i Gjirokastres, Qarku i Korces, Qarku i Kukesit, Qarku i Lezhes,
Qarku i Shkodres, Qarku i Tiranes, Qarku i Vlores
wheat, corn, potatoes, vegetables, fruits, sugar beets,
grapes; meat, dairy products
11 (2003 est.)
15.08 births/1,000 population (2004 est.)
General Staff Headquarters, Land Forces Command (Army),
Naval Forces Command, Air Forces Command, Doctrine and Exercises
Command, Logistics Support Command
revenues: $1.36 billion
expenditures: $1.627 billion, including capital expenditures of $406
million (2003 est.)
Tirana
gas 339 km; oil 207 km (2004)
Agrarian Environmentalist Party or PAA [Lufter XHUVELI];
Christian Democratic Party or PDK [Nikolle LESI]; Communist Party of
Albania or PKSH [Hysni MILLOSHI]; Democratic Alliance Party or PAD
[Neritan CEKA]; Democratic Party or PD [Sali BERISHA]; Legality
Movement Party or PLL [Ekrem SPAHIU]; Liberal Union Party or PBL
[Arjan STAROVA]; National Front Party (Balli Kombetar) or PBK
[Adriatik ALIMADHI]; New Democratic Party or PDR [Genc POLLO]; Party
of National Unity or PUK [Idajet BEQIRI]; Renewed Democratic Party
or PDR [Dashamir SHEHI]; Republican Party or PR [Fatmir MEDIU];
Social Democracy Party or PDS [Paskal MILO]; Social Democratic Party
or PSD [Skender GJINUSHI]; Socialist Movement for Integration or LSI
[Ilir META]; Socialist Party or PS (formerly the Albanian Party of
Labor) [Fatos NANO]; Union for Human Rights Party or PBDNJ [Vangjel
DULE]','d9ef33c3cf35a60269918ac82be4a6ddd3e4213e967bf9cfa25fe87c18d24aa9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ad2838cf7254575c31589e96f1e67d76fd552c4ba98da57b60ade47443fa6f',2004,'DZ','Algeria','economy',644,'total: 52
over 3,047 m: 10
2,438 to 3,047 m: 27
1,524 to 2,437 m: 10
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
total: 85
2,438 to 3,047 m: 2
1,524 to 2,437 m: 26
914 to 1,523 m: 38
under 914 m: 19 (2004 est.)
soil erosion from overgrazing and other poor farming
practices; desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is leading to the
pollution of rivers and coastal waters; Mediterranean Sea, in
particular, becoming polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
3.5% (2003)
24.69 billion kWh (2001)
22.9 billion kWh (2001)
275 million kWh (2001)
340 million kWh (2001)
23% (1999 est.)
lowest 10%: 2.8%
highest 10%: 26.8% (1995)
agriculture 14%, industry 13.4%, construction and public
works 10%, trade 14.6%, government 32%, other 16% (2003 est.)
petroleum, natural gas, and petroleum products 97%
Italy 19.5%, US 18.5%, France 13.6%, Spain 11.2%, Canada
6.2%, Belgium 5.1%, Brazil 4.9% (2003)
48 provinces (wilayas, singular - wilaya); Adrar, Ain Defla,
Ain Temouchent, Alger, Annaba, Batna, Bechar, Bejaia, Biskra, Blida,
Bordj Bou Arreridj, Bouira, Boumerdes, Chlef, Constantine, Djelfa,
El Bayadh, El Oued, El Tarf, Ghardaia, Guelma, Illizi, Jijel,
Khenchela, Laghouat, Mascara, Medea, Mila, Mostaganem, M''Sila,
Naama, Oran, Ouargla, Oum el Bouaghi, Relizane, Saida, Setif, Sidi
Bel Abbes, Skikda, Souk Ahras, Tamanghasset, Tebessa, Tiaret,
Tindouf, Tipaza, Tissemsilt, Tizi Ouzou, Tlemcen
wheat, barley, oats, grapes, olives, citrus, fruits; sheep,
cattle
137 (2003 est.)
17.76 births/1,000 population (2004 est.)
People''s National Army (ANP; includes Ground Forces),
Algerian National Navy (ANN), Air Force (QJA), Territorial Air
Defense
revenues: $25.49 billion
expenditures: $22.87 billion, including capital expenditures of $5.8
billion (2003 est.)
Algiers
condensate 1,344 km; gas 85,946 km; liquid petroleum gas
2,213 km; oil 6,496 km (2004)
Algerian National Front or FNA [Moussa TOUATI]; Democratic
National Rally or RND [Ahmed OUYAHIA, chairman]; Islamic Salvation
Front or FIS (outlawed April 1992) [Ali BELHADJ and Dr. Abassi
MADANI, Rabeh KEBIR (self-exiled in Germany)]; National Entente
Movement or MEN [Ali BOUKHAZNA]; National Liberation Front or FLN
[Abdelaziz BELKHADEM, secretary general (also serves as Foreign
Minister)]; National Reform Movement or Islah (formerly MRN)
[Abdellah DJABALLAH]; National Renewal Party or PRA [Yacine
TERKMANE]; Progressive Republican Party [Khadir DRISS]; Rally for
Culture and Democracy or RCD [Said SAADI, secretary general];
Renaissance Movement or EnNahda Movement [Fatah RABEI]; Social
Liberal Party or PSL [Ahmed KHELIL]; Socialist Forces Front or FFS
[Hocine Ait AHMED, secretary general (self-exiled in Switzerland)];
Society of Peace Movement or MSP [Boujerra SOLTANI]; Workers Party
or PT [Louisa HANOUN]
note: a law banning political parties based on religion was enacted
in March 1997','786b1faee4fabb3fda2a9863bfcd00f0febcde3dcd2057d5240987ec46265a68','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60c8f43c9d58f833bb6660a04b75ebb849633b5a5de91ab4c8eb996e8e130d20',2004,'AS','American Samoa','economy',645,'total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
limited natural fresh water resources; the water
division of the government has spent substantial funds in the past
few years to improve water catchments and pipelines
130 million kWh (2001)
120.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
tuna canneries 34%, government 33%, other 33% (1990)
canned tuna 93%
Samoa 33.3%, Japan 22.2%, Australia 11.1%, Canada
11.1%, New Zealand 11.1% (2003)
none (territory of the US); there are no first-order
administrative divisions as defined by the US Government, but there
are three districts and two islands* at the second order; Eastern,
Manu''a, Rose Island*, Swains Island*, Western
bananas, coconuts, vegetables, taro, breadfruit,
yams, copra, pineapples, papayas; dairy products, livestock
3 (2003 est.)
24.46 births/1,000 population (2004 est.)
revenues: $121 million (37% in local revenue and 63%
in US grants)
expenditures: $127 million, including capital expenditures of NA
(FY96/97)
Pago Pago
Democratic Party [leader NA]; Republican Party
[leader NA]','af4394ab13606eabca86d67ba8239f80981ecca6b7eec60d6ff01e4a8c2f4ec4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08db18d1eace65abf65423583e1efd614f0aeb52af69f59f3e11672f54762966',2004,'AO','Angola','economy',646,'total: 32
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 14
914 to 1,523 m: 5
under 914 m: 1 (2004 est.)
total: 211
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 30
914 to 1,523 m: 95
under 914 m: 80 (2004 est.)
overuse of pastures and subsequent soil erosion attributable
to population pressures; desertification; deforestation of tropical
rain forest, in response to both international demand for tropical
timber and to domestic use as fuel, resulting in loss of
biodiversity; soil erosion contributing to water pollution and
siltation of rivers and dams; inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
1.9% (2003)
1.45 billion kWh (2001)
1.348 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
70% (2003 est.)
lowest 10%: NA
highest 10%: NA
agriculture 85%, industry and services 15% (2003 est.)
crude oil, diamonds, refined petroleum products, gas, coffee,
sisal, fish and fish products, timber, cotton
US 47.7%, China 23.4%, Taiwan 8%, France 7.4% (2003)
18 provinces (provincias, singular - provincia); Bengo,
Benguela, Bie, Cabinda, Cuando Cubango, Cuanza Norte, Cuanza Sul,
Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda Sul, Malanje,
Moxico, Namibe, Uige, Zaire
bananas, sugarcane, coffee, sisal, corn, cotton, manioc
(tapioca), tobacco, vegetables, plantains; livestock; forest
products; fish
244 (2003 est.)
45.14 births/1,000 population (2004 est.)
Army, Navy (Marinha de Guerra, MdG), Air and Air Defense
Forces (FANA)
revenues: $4.874 billion
expenditures: $6.012 billion, including capital expenditures of $963
million (2003 est.)
Luanda
gas 214 km; liquid natural gas 14 km; liquid petroleum gas 30
km; oil 837 km; refined products 56 km (2004)
Liberal Democratic Party or PLD [Analia de Victoria PEREIRA];
National Front for the Liberation of Angola or FNLA [disputed
leadership: Lucas NGONDA, Holden ROBERTO]; National Union for the
Total Independence of Angola or UNITA [Isaias SAMAKUVA], largest
opposition party has engaged in years of armed resistance; Popular
Movement for the Liberation of Angola or MPLA [Jose Eduardo DOS
SANTOS], ruling party in power since 1975; Social Renewal Party or
PRS [disputed leadership: Eduardo KUANGANA, Antonio MUACHICUNGO]
note: about a dozen minor parties participated in the 1992 elections
but only won a few seats and have little influence in the National
Assembly','6b8281863a817490838aaa35d8522543b29bcaccb6e31572f126bd08c6f588de','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6683d3dac54a17ffb318a989b18d0662fda9af05f315ec277e130b73aa593a1a',2004,'AI','Anguilla','economy',647,'total: 1
914 to 1,523 m: 1 (2004 est.)
total: 2
under 914 m: 2 (2004 est.)
supplies of potable water sometimes cannot meet increasing
demand largely because of poor distribution system
NA
42.6 million kWh
NA
lowest 10%: NA
highest 10%: NA
agriculture/fishing/forestry/mining 4%, manufacturing 3%,
construction 18%, transportation and utilities 10%, commerce 36%,
services 29% (2000 est.)
lobster, fish, livestock, salt, concrete blocks, rum
UK, US, Puerto Rico, Saint-Martin (2000)
none (overseas territory of the UK)
small quantities of tobacco, vegetables; cattle raising
3 (2003 est.)
14.45 births/1,000 population (2004 est.)
revenues: $22.8 million
expenditures: $22.5 million, including capital expenditures of NA
(2000 est.)
The Valley
Anguilla United Movement or AUM [Hubert HUGHES]; The United
Front or UF [Osbourne FLEMING, Victor BANKS], a coalition of the
Anguilla Democratic Party or ADP and the Anguilla National Alliance
or ANA; Anguilla Patriotic Movement or APM [Quincy GUMBS]; Movement
for Grassroots Democracy or MFGD [Joyce KENTISH, John BENJAMIN]','38c5610e854ba6eb73d65370c8679d55bd98331dcec1eeb914f1b5901f4b3437','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9524144e4b1bd7dddb484a553cf06450a50bba213014535de4de78880314f26',2004,'AG','Antigua and Barbuda','economy',648,'total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
water management - a major concern because of
limited natural fresh water resources - is further hampered by the
clearing of trees to increase crop production, causing rainfall to
run off quickly
Arctic Ocean
endangered marine species include walruses and whales;
fragile ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
105.3 million kWh (2001)
97.89 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 7%, industry 11%, services 82% (1983)
petroleum products 48%, manufactures 23%,
machinery and transport equipment 17%, food and live animals 4%,
other 8%
Germany 84.9%, UK 3.8%, US 3.3% (2003)
6 parishes and 2 dependencies*; Barbuda*,
Redonda*, Saint George, Saint John, Saint Mary, Saint Paul, Saint
Peter, Saint Philip
cotton, fruits, vegetables, bananas, coconuts,
cucumbers, mangoes, sugarcane; livestock
3 (2003 est.)
17.7 births/1,000 population (2004 est.)
Royal Antigua and Barbuda Defense Force
(including Coast Guard)
revenues: $123.7 million
expenditures: $145.9 million, including capital expenditures of NA
(2000 est.)
Saint John''s (Antigua)
Antigua Labor Party or ALP [Lester Bryant BIRD];
Barbuda People''s Movement or BPM [Thomas H. FRANK]; United
Progressive Party or UPP [Baldwin SPENCER] (a coalition of three
opposition parties - United National Democratic Party or UNDP,
Antigua Caribbean Liberation Movement or ACLM, and Progressive Labor
Movement or PLM)','b1ad7520aa64be27d2edea717566bea4e00cff82ca2608b7415bc9e2cfdd180c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33097b2a779ecceb574ac004bd87f3d9a8ecac853ea07bdae4ebe9527fda7c7b',2004,'AR','Argentina','economy',649,'total: 144
over 3,047 m: 4
2,438 to 3,047 m: 26
1,524 to 2,437 m: 62
914 to 1,523 m: 44
under 914 m: 8 (2004 est.)
total: 1,190
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 50
914 to 1,523 m: 569
under 914 m: 567 (2004 est.)
environmental problems (urban and rural) typical of an
industrializing economy such as deforestation, soil degradation,
desertification, air pollution, and water pollution
note: Argentina is a world leader in setting voluntary greenhouse
gas targets
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
1.3% (FY00)
97.17 billion kWh (2001)
92.12 billion kWh (2001)
7.417 billion kWh (2001)
5.662 billion kWh (2001)
51.7% (May 2003)
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
edible oils, fuels and energy, cereals, feed, motor
vehicles
Brazil 15.8%, Chile 12%, US 10.6%, China 8.4%, Spain 4.7%
(2003)
23 provinces (provincias, singular - provincia), and 1
autonomous city* (distrito federal); Buenos Aires, Buenos Aires
Capital Federal*, Catamarca, Chaco, Chubut, Cordoba, Corrientes,
Entre Rios, Formosa, Jujuy, La Pampa, La Rioja, Mendoza, Misiones,
Neuquen, Rio Negro, Salta, San Juan, San Luis, Santa Cruz, Santa Fe,
Santiago del Estero, Tierra del Fuego - Antartida e Islas del
Atlantico Sur, Tucuman
note: the US does not recognize any claims to Antarctica
sunflower seeds, lemons, soybeans, grapes, corn, tobacco,
peanuts, tea, wheat; livestock
1,335 (2003 est.)
17.19 births/1,000 population (2004 est.)
Argentine Army, Navy of the Argentine Republic (includes
Naval Aviation and Marines), Argentine Air Force (Fuerza Aerea
Argentina, FAA)
revenues: $26.62 billion
expenditures: $26 billion, including capital expenditures of NA
(2003 est.)
Buenos Aires
gas 27,166 km; liquid petroleum gas 41 km; oil 3,668 km;
refined products 2,945 km; unknown (oil/water) 13 km (2004)
Action for the Republic or AR [Domingo CAVALLO];
Alternative for a Republic of Equals or ARI [Elisa CARRIO]; Front
for a Country in Solidarity or Frepaso (a four-party coalition)
[Dario Pedro ALESSANDRO]; Interbloque Federal or IF (a broad
coalition of approximately 12 parties including RECREAR) [leader
NA]; Justicialist Party or PJ [leader NA] (Peronist umbrella
political organization); Radical Civic Union or UCR [Angel ROZAS];
Federal Recreate Movement or RECREAR [Ricardo LOPEZ MURPHY];
Socialist Party or PS [Ruben GIUSTINIANI]; Union For All [Patricia
BULLRICH]; several provincial parties','cc24212126eebc27d4b6c74ee1159d172b637e037d58bf2f3523b001276dcf28','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa35234855ae049050b9c03984d8d55a66ad4ad6ba7d51404a441ae354ec499e',2004,'AM','Armenia','economy',650,'total: 11
over 3,047 m: 2
2,438 to 3,047: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2003 est.)
total: 6
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 1 (2003 est.)
soil pollution from toxic chemicals such as DDT; the energy
crisis of the 1990s led to deforestation when citizens scavenged for
firewood; pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its use as a
source for hydropower, threatens drinking water supplies; restart of
Metsamor nuclear power plant in spite of its location in a
seismically active zone
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
6.5% (FY01)
6.479 billion kWh (2001)
5.784 billion kWh (2001)
463 million kWh; note - imports an unknown quantity from
Iran (2001)
704 million kWh; note - exports an unknown quantity to
Georgia; includes exports to Nagorno-Karabakh region in Azerbaijan
(2001)
50% (2002 est.)
lowest 10%: 2.3%
highest 10%: 46.2% (1999)
agriculture 45%, industry 25%, services 30% (2002 est.)
diamonds, mineral products, foodstuffs, energy
Belgium 18.2%, UK 16.8%, Israel 15.7%, Russia 12.1%, Iran
7.9%, US 6.3%, Germany 5% (2003)
11 provinces (marzer, singular - marz); Aragatsotn, Ararat,
Armavir, Geghark''unik'', Kotayk'', Lorri, Shirak, Syunik'', Tavush,
Vayots'' Dzor, Yerevan
fruit (especially grapes), vegetables; livestock
17 (2003 est.)
11.43 births/1,000 population (2004 est.)
Army, Air Force and Air Defense Force
revenues: $425.9 million
expenditures: $460.3 million, including capital expenditures of $NA
(2003)
Yerevan
gas 1,871 km (2004)
Agro-Industrial Party [Vladimir BADALIAN]; Armenia Party
[Myasnik MALKHASYAN]; Armenian National Movement or ANM [Alex
ARZUMANYAN, chairman]; Armenian Ramkavar Liberal Party or HRAK
[Harutyun MIRZAKHANYAN, chairman]; Armenian Revolutionary Federation
("Dashnak" Party) or ARF [Vahan HOVHANISSIAN]; Democratic Party
[Aram SARKISYAN]; Justice Bloc (comprised of the Democratic Party,
National Democratic Party, National Democratic Union, and the
People''s Party); National Democratic Party [Shavarsh KOCHARIAN];
National Democratic Union or NDU [Vazgen MANUKIAN]; National Unity
Party [Artashes GEGAMIAN, chairman]; People''s Party of Armenia
[Stepan DEMIRCHYAN]; Republic Party [Albert BAZEYAN and Aram
SARKISYAN, chairmen]; Republican Party or RPA [Andranik MARKARYAN];
Rule of Law Party [Artur BAGDASARIAN, chairman]; Union of
Constitutional Rights [Hrant KHACHATURYAN]; United Labor Party
[Gurgen ARSENIAN]','49d2758ec7ca7d560ed3ee2419315f78004b828643d67d9218b0f3091efada13','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('997d66b4b0eeb8ec65d47a4a554033d7a6bdfefce4028432d7ba3d39e111f59f',2004,'AW','Aruba','economy',651,'total: 1
2,438 to 3,047 m: 1 (2004 est.)
NA
Ashmore and Cartier Islands
NA
Atlantic Ocean
endangered marine species include the manatee, seals,
sea lions, turtles, and whales; drift net fishing is hastening the
decline of fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern Brazil, and
eastern Argentina; oil pollution in Caribbean Sea, Gulf of Mexico,
Lake Maracaibo, Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North Sea, and
Mediterranean Sea
531.9 million kWh (2001)
494.7 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
most employment is in wholesale and retail trade and repair,
followed by hotels and restaurants; oil refining
live animals and animal products, art and collectibles,
machinery and electrical equipment, transport equipment
Netherlands 33.7%, Colombia 12%, Netherlands Antilles 12%,
Panama 12%, Venezuela 10.8%, US 9.6% (2003)
none (part of the Kingdom of the Netherlands)
aloes; livestock; fish
1 (2003 est.)
11.53 births/1,000 population (2004 est.)
no regular indigenous military forces; Royal Dutch Navy and
Marines, Coast Guard
revenues: $135.8 million
expenditures: $147 million, including capital expenditures of NA
(2000)
Oranjestad
Aruba Solidarity Movement or MAS [leader NA]; Aruban
Democratic Alliance or Aliansa [leader NA]; Aruban Democratic Party
or PDA [Leo BERLINSKI]; Aruban Liberal Party or OLA [Glenbert
CROES]; Aruban Patriotic Party or PPA [Benny NISBET]; Aruban
People''s Party or AVP [Jan (Henny) H. EMAN]; Concentration for the
Liberation of Aruba or CLA [leader NA]; People''s Electoral Movement
Party or MEP [Nelson O. ODUBER]; For a Restructured Aruba Now or
PARA [Urbana LOPEZ]; National Democratic Action or ADN [Pedro Charro
KELLY]','b91e488d3def0c8a476edca6ec89803bb44e1e82293a4892099e76ed6b9aae80','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5b47a6f1c35980dbaf9afb57de20791feef3e6820bd1b32586d3f8069adaac9',2004,'AU','Australia','economy',652,'total: 305
over 3,047 m: 10
2,438 to 3,047 m: 12
1,524 to 2,437 m: 131
914 to 1,523 m: 139
under 914 m: 13 (2004 est.)
total: 143
1,524 to 2,437 m: 17
914 to 1,523 m: 112
under 914 m: 14 (2004 est.)
soil erosion from overgrazing, industrial development,
urbanization, and poor farming practices; soil salinity rising due
to the use of poor quality water; desertification; clearing for
agricultural purposes threatens the natural habitat of many unique
animal and plant species; the Great Barrier Reef off the northeast
coast, the largest coral reef in the world, is threatened by
increased shipping and its popularity as a tourist site; limited
natural fresh water resources
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
2.8% (2003)
198.2 billion kWh (2001)
184.4 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: 2%
highest 10%: 25.4% (1994)
agriculture 5%, industry 22%, services 73% (1997 est.)
coal, gold, meat, wool, alumina, iron ore, wheat,
machinery and transport equipment
Japan 18.1%, US 8.7%, China 8.4%, South Korea 7.4%, New
Zealand 7.4%, UK 6.7% (2003)
6 states and 2 territories*; Australian Capital
Territory*, New South Wales, Northern Territory*, Queensland, South
Australia, Tasmania, Victoria, Western Australia
wheat, barley, sugarcane, fruits; cattle, sheep, poultry
444 (2003 est.)
12.4 births/1,000 population (2004 est.)
Australian Army, Royal Australian Navy, Royal Australian
Air Force, new Special Operations Command (announced in December
2002)
revenues: $185 billion
expenditures: $181 billion, including capital expenditures of NA
(2003)
Canberra
condensate/gas 492 km; gas 28,680 km; liquid petroleum gas
240 km; oil 4,773 km; oil/gas/water 110 km (2004)
Australian Democrats [Andrew BARTLETT]; Australian Labor
Party [Mark LATHAM]; Australian Progressive Alliance [Meg LEES];
Country Liberal Party [Terry MILLS]; Australian Greens [Bob BROWN];
Liberal Party [John Winston HOWARD]; The Nationals [John ANDERSON];
One Nation Party [Len HARRIS]','f28cd0bd5d0a668b5ae06dc3d54a88ba35f94c9c8b07a667eccee08c3e601f78','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d19c63e120b394e1efc7fe7657ec1ce24bb4fe3a313e7d47699edbdd625f3219',2004,'AT','Austria','economy',653,'total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 14 (2004 est.)
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 27 (2004 est.)
some forest degradation caused by air and soil pollution;
soil pollution results from the use of agricultural chemicals; air
pollution results from emissions by coal- and oil-fired power
stations and industrial plants and from trucks transiting Austria
between northern and southern Europe
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
0.85% (June 2004)
58.75 billion kWh (2001)
54.85 billion kWh (2001)
14.47 billion kWh (2001)
14.25 billion kWh (2001)
3.9% (1999)
lowest 10%: 2.5%
highest 10%: 22.5% (1995)
agriculture and forestry 4%, industry and crafts 29%,
services 67% (2001 est.)
machinery and equipment, motor vehicles and parts, paper and
paperboard, metal goods, chemicals, iron and steel; textiles,
foodstuffs
Germany 31.9%, Italy 9.6%, Switzerland 5.2%, US 4.9%, France
4.8%, UK 4.7% (2003)
9 states (Bundeslaender, singular - Bundesland); Burgenland,
Kaernten, Niederoesterreich, Oberoesterreich, Salzburg, Steiermark,
Tirol, Vorarlberg, Wien
grains, potatoes, sugar beets, wine, fruit; dairy products,
cattle, pigs, poultry; lumber
55 (2003 est.)
8.9 births/1,000 population (2004 est.)
Land Forces (KdoLdSK), Air Forces (KdoLuSK)
revenues: $67 billion
expenditures: $70 billion, including capital expenditures of NA
(2004 est.)
Vienna
gas 2,722 km; oil 663 km; refined products 149 km (2004)
Austrian People''s Party or OeVP [Wolfgang SCHUESSEL];
Freedom Party of Austria or FPOe [Ursula HAUBNER]; Social Democratic
Party of Austria or SPOe [Alfred GUSENBAUER]; The Greens [Alexander
VAN DER BELLEN]','49d84820800dfa15d7f46c46c892131b322289b4c1abf2e906efd633b1817dbf','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('976e4068f110db2adf8e04f193c376f377545a72e5b446a73867814d55279d11',2004,'AZ','Azerbaijan','economy',654,'total: 27
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 15
914 to 1,523 m: 3
under 914 m: 1 (2003 est.)
Bahamas, The
total: 29
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 14
914 to 1,523 m: 9
under 914 m: 1 (2004 est.)
total: 40
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 32 (2003 est.)
Bahamas, The
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 10
under 914 m: 21 (2004 est.)
local scientists consider the Abseron Yasaqligi (Apsheron
Peninsula) (including Baku and Sumqayit) and the Caspian Sea to be
the ecologically most devastated area in the world because of severe
air, soil, and water pollution; soil pollution results from oil
spills, from the use of DDT as a pesticide, and from toxic
defoliants used in the production of cotton
Bahamas, The
coral reef decay; solid waste disposal
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Bahamas, The
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2.6% (FY99)
Bahamas, The
NA
18.23 billion kWh (2001)
Bahamas, The
1.56 billion kWh (2001)
16.65 billion kWh (2001)
Bahamas, The
1.451 billion kWh (2001)
400 million kWh (2001)
Bahamas, The
0 kWh (2001)
700 million kWh (2001)
Bahamas, The
0 kWh (2001)
49% (2002 est.)
Bahamas, The
NA
lowest 10%: 2.8%
highest 10%: 27.8% (1995)
Bahamas, The
lowest 10%: NA
highest 10%: NA
agriculture and forestry 41%, industry 7%, services 52%
(2001)
Bahamas, The
agriculture 5%, industry 5%, tourism 50%, other
services 40% (1999 est.)
oil and gas 90%, machinery, cotton, foodstuffs
Bahamas, The
fish and crawfish; rum, salt, chemicals; fruit and
vegetables
Italy 34.1%, Czech Republic 11.4%, Germany 10.5%, France
8.2%, Turkey 5.9%, Georgia 4.5%, Russia 4.5% (2003)
Bahamas, The
US 35%, Spain 9.6%, Germany 7.8%, France 7.6%, Poland
5.3%, Switzerland 4.8%, Peru 4.2%, Paraguay 4.2% (2003)
59 rayons (rayonlar; rayon - singular), 11 cities*
(saharlar; sahar - singular), 1 autonomous republic** (muxtar
respublika)
rayons: Abseron Rayonu, Agcabadi Rayonu, Agdam Rayonu, Agdas Rayonu,
Agstafa Rayonu, Agsu Rayonu, Astara Rayonu, Balakan Rayonu, Barda
Rayonu, Beylaqan Rayonu, Bilasuvar Rayonu, Cabrayil Rayonu,
Calilabad Rayonu, Daskasan Rayonu, Davaci Rayonu, Fuzuli Rayonu,
Gadabay Rayonu, Goranboy Rayonu, Goycay Rayonu, Haciqabul Rayonu,
Imisli Rayonu, Ismayilli Rayonu, Kalbacar Rayonu, Kurdamir Rayonu,
Lacin Rayonu, Lankaran Rayonu, Lerik Rayonu, Masalli Rayonu,
Neftcala Rayonu, Oguz Rayonu, Qabala Rayonu, Qax Rayonu, Qazax
Rayonu, Qobustan Rayonu, Quba Rayonu, Qubadli Rayonu, Qusar Rayonu,
Saatli Rayonu, Sabirabad Rayonu, Saki Rayonu, Salyan Rayonu, Samaxi
Rayonu, Samkir Rayonu, Samux Rayonu, Siyazan Rayonu, Susa Rayonu,
Tartar Rayonu, Tovuz Rayonu, Ucar Rayonu, Xacmaz Rayonu, Xanlar
Rayonu, Xizi Rayonu, Xocali Rayonu, Xocavand Rayonu, Yardimli
Rayonu, Yevlax Rayonu, Zangilan Rayonu, Zaqatala Rayonu, Zardab
Rayonu
cities: Ali Bayramli Sahari, Baki Sahari, Ganca Sahari, Lankaran
Sahari, Mingacevir Sahari, Naftalan Sahari, Saki Sahari, Sumqayit
Sahari, Susa Sahari, Xankandi Sahari, Yevlax Sahari
autonomous republic: Naxcivan Muxtar Respublikasi
Bahamas, The
21 districts; Acklins and Crooked Islands, Bimini, Cat
Island, Exuma, Freeport, Fresh Creek, Governor''s Harbour, Green
Turtle Cay, Harbour Island, High Rock, Inagua, Kemps Bay, Long
Island, Marsh Harbour, Mayaguana, New Providence, Nichollstown and
Berry Islands, Ragged Island, Rock Sound, Sandy Point, San Salvador
and Rum Cay
cotton, grain, rice, grapes, fruit, vegetables, tea,
tobacco; cattle, pigs, sheep, goats
Bahamas, The
citrus, vegetables; poultry
67 (2003 est.)
Bahamas, The
63 (2003 est.)
19.81 births/1,000 population (2004 est.)
Bahamas, The
18.22 births/1,000 population (2004 est.)
Army, Navy, Air and Air Defense Forces
Bahamas, The
Royal Bahamas Defense Force (including Coast Guard)
revenues: $2.063 billion
expenditures: $2.202 billion, including capital expenditures of NA
(2003)
Bahamas, The
revenues: $918.5 million
expenditures: $956.5 million, including capital expenditures of
$106.7 million (FY99/00)
Baku (Baki)
Bahamas, The
Nassau
gas 4,451 km; oil 1,518 km (2004)
Azerbaijan Popular Front or APF [Ali KARIMLI, leader of
"Reform" faction; Mirmahmud MIRALI-OGLU, leader of "Classic"
faction]; Civic Solidarity Party or CSP [Sabir RUSTAMKHANLY]; Civic
Union Party [Ayaz MUTALIBOV]; Communist Party of Azerbaijan or CPA
[Ramiz AHMADOV]; Compatriot Party [Mais SAFARLI]; Democratic Party
for Azerbaijan or DPA [Rasul QULIYEV, chairman]; Justice Party
[Ilyas ISMAILOV]; Liberal Party of Azerbaijan [Lala Shovkat
HACIYEVA]; Musavat [Isa GAMBAR, chairman]; New Azerbaijan Party or
NAP [vacant]; Party for National Independence of Azerbaijan or PNIA
[Etibar MAMMADLI, chairman]; Social Democratic Party of Azerbaijan
or SDP [Araz ALIZADE and Ayaz MUTALIBOV]
note: opposition parties regularly factionalize and form new parties
Bahamas, The
Free National Movement or FNM [Tommy TURNQUEST];
Progressive Liberal Party or PLP [Perry CHRISTIE]','e65ba27db0c098fd2654434d051509b937c892b5db818fd95ec2bcf3c8c65bbf','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b05d365327a748b542d6ede39e5cf375569038ee4a240729cf3a040b8f4b1e6a',2004,'BH','Bahrain','economy',655,'total: 3
over 3,047 m: 2
1524 to 2437 m: 1 (2004 est.)
total: 1
1,524 to 2,437 m: 1 (2004 est.)
desertification resulting from the degradation of limited
arable land, periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and sea vegetation)
resulting from oil spills and other discharges from large tankers,
oil refineries, and distribution stations; lack of freshwater
resources, groundwater and seawater are the only sources for all
water needs
Baker Island
no natural fresh water resources
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
7.5% (2003)
6.257 billion kWh (2001)
5.819 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 1%, industry, commerce, and services 79%,
government 20% (1997 est.)
petroleum and petroleum products, aluminum, textiles
US 3.5%, India 3.3%, South Korea 2.2% (2003)
12 municipalities (manatiq, singular - mintaqah); Al Hadd,
Al Manamah, Al Mintaqah al Gharbiyah, Al Mintaqah al Wusta, Al
Mintaqah ash Shamaliyah, Al Muharraq, Ar Rifa'' wa al Mintaqah al
Janubiyah, Jidd Hafs, Madinat Hamad, Madinat ''Isa, Juzur Hawar,
Sitrah
note: all municipalities administered from Manama
fruit, vegetables; poultry, dairy products; shrimp, fish
4 (2003 est.)
Baker Island
1 abandoned World War II runway of 1,665 m, completely
covered with vegetation and unusable (2003 est.)
18.54 births/1,000 population (2004 est.)
Bahrain Defense Forces (BDF): Ground Force (includes Air
Defense), Navy, Air Force, National Guard
revenues: $2.981 billion
expenditures: $3.019 billion, including capital expenditures of $700
million (2003 est.)
Manama
gas 20 km; oil 53 km (2004)
political parties prohibited but politically oriented
societies are allowed','9746498d8dd0c5af9da9a05c2cc1d85a1c958ab6a7d03770c597e65bf9a3f541','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98521ea7590f7138c77365682b99d86079b78716c42ce421677bdce73eff21fc',2004,'BD','Bangladesh','economy',656,'total: 15
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 6 (2004 est.)
total: 1
1,524 to 2,437 m: 1 (2004 est.)
many people are landless and forced to live on and
cultivate flood-prone land; water-borne diseases prevalent in
surface water; water pollution, especially of fishing areas, results
from the use of commercial pesticides; ground water contaminated by
naturally occurring arsenic; intermittent water shortages because of
falling water tables in the northern and central parts of the
country; soil degradation and erosion; deforestation; severe
overpopulation
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.2% (2003)
15.33 billion kWh (2001)
14.25 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
35.6% (FY95/96 est.)
lowest 10%: 3.9%
highest 10%: 28.6% (1995-96 est.)
agriculture 63%, industry 11%, services 26% (FY95/96)
garments, jute and jute goods, leather, frozen fish and
seafood (2001)
US 23.9%, Germany 13.6%, UK 9.7%, France 5.9% (2003)
6 divisions; Barisal, Chittagong, Dhaka, Khulna,
Rajshahi, and Sylhet
rice, jute, tea, wheat, sugarcane, potatoes, tobacco,
pulses, oilseeds, spices, fruit; beef, milk, poultry
16 (2003 est.)
30.03 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $5.352 billion
expenditures: $7.55 billion, including capital expenditures of NA
(2003)
Dhaka
gas 2,012 km (2004)
Awami League or AL [Sheikh HASINA]; Bangladesh Communist
Party or BCP [Saifuddin Ahmed MANIK]; Bangladesh Nationalist Party
or BNP [Khaleda ZIA, chairperson]; Islami Oikya Jote or IOJ [Mufti
Fazlul Haq AMINI]; Jamaat-e-Islami or JI [Motiur Rahman NIZAMI];
Jatiya Party or JP (Ershad faction) [Hussain Mohammad ERSHAD];
Jatiya Party (Manzur faction) [Naziur Rahman MANZUR]','4cddf497b7708a2cbc55f6134ff4ac057b189c5b96a72d37cb0b7662bf76e809','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3375909e1a7d531fec811231a57b851bdacce9430acb0d9099877c809dd013e',2004,'BB','Barbados','economy',657,'total: 1
over 3,047 m: 1 (2004 est.)
pollution of coastal waters from waste disposal by ships;
soil erosion; illegal solid waste disposal threatens contamination
of aquifers
Bassas da India
NA
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA
780 million kWh (2001)
725.4 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 10%, industry 15%, services 75% (1996 est.)
sugar and molasses, rum, other foods and beverages,
chemicals, electrical components
US 18.7%, Trinidad and Tobago 14.5%, UK 14%, Jamaica 7.8%,
Saint Lucia 6.2%, Saint Vincent and the Grenadines 4.7% (2003)
11 parishes; Christ Church, Saint Andrew, Saint George,
Saint James, Saint John, Saint Joseph, Saint Lucy, Saint Michael,
Saint Peter, Saint Philip, Saint Thomas; note - the city of
Bridgetown may be given parish status
sugarcane, vegetables, cotton
1 (2003 est.)
12.98 births/1,000 population (2004 est.)
Royal Barbados Defense Force (Troops Command and Coast
Guard)
revenues: $847 million (including grants)
expenditures: $886 million, including capital expenditures of NA
(2000 est.)
Bridgetown
Barbados Labor Party or BLP [Owen ARTHUR]; Democratic Labor
Party or DLP [Clyde Mascoll]','832080b71cc457f8edbd5874a602aa1cd1052b492ea166e551407e8545373774','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c78872b125aafc4062dbbafdea2951769885c83dc7eb6d0fca6a763985afea',2004,'BY','Belarus','economy',658,'total: 50
over 3,047 m: 2
2,438 to 3,047 m: 21
1,524 to 2,437 m: 6
under 914 m: 21 (2003 est.)
total: 85
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 11
under 914 m: 64 (2003 est.)
soil pollution from pesticide use; southern part of the
country contaminated with fallout from 1986 nuclear reactor accident
at Chornobyl'' in northern Ukraine
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
1.4% (FY02)
24.4 billion kWh (2001)
26.69 billion kWh (2001)
4.3 billion kWh (2001)
300 million kWh (2001)
22% (1995 est.)
lowest 10%: 5.1%
highest 10%: 20% (1998)
NA
machinery and equipment, mineral products, chemicals,
metals; textiles, foodstuffs
Russia 49.1%, UK 9.4%, Poland 4.4%, Germany 4.2%,
Netherlands 4.2% (2003)
6 provinces (voblastsi, singular - voblasts'') and 1
municipality* (horad); Brest, Homyel'', Horad Minsk*, Hrodna,
Mahilyow, Minsk, Vitsyebsk
note: administrative divisions have the same names as their
administrative centers
grain, potatoes, vegetables, sugar beets, flax; beef, milk
135 (2003 est.)
10.52 births/1,000 population (2004 est.)
Army, Air and Air Defense Force
revenues: $2.976 billion
expenditures: $3.211 billion, including capital expenditures of $180
million (2003 est.)
Minsk
gas 5,223 km; oil 2,443 km; refined products 1,686 km (2004)
Pro-government parties: Agrarian Party or AP; Belarusian
Communist Party or KPB; Belarusian Patriotic Movement (Belarusian
Patriotic Party) or BPR [Anatoliy BARANKEVICH, chairman]; Liberal
Democratic Party of Belarus [Sergei GAYDUKEVICH]; Social-Sports
Party; Opposition parties: Belarusian Popular Front or BNF [Vintsuk
VYACHORKA]; Belarusian Social-Democrat Party Narodnaya Gromada or
BSDP NG [Nikolay STATKEVICH, chairman]; Belarusian Social-Democratic
Party Hromada [Stanislav SHUSHKEVICH, chairman]; United Civic Party
or UCP [Anatol LEBEDKO]; Party of Communists Belarusian or PKB
[Sergei KALYAKIN, chairman]; Women''s Party "Nadezhda" [Valentina
MATUSEVICH, chairperson]
note: the opposition Belarusian Party of Labor [Aleksandr
BUKHVOSTOV] was liquidated in August 2004, but remains active','eec0e859da3050a4d1e9eb619737a7bf5e5ca8e7d8b3b9f8c9ab06adaaf50b9e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab303ab52ba3d5102fff865eaa689a0a0be1d360601a25a7d93cb9161c1ff821',2004,'BE','Belgium','economy',659,'total: 25
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 7 (2004 est.)
total: 18
914 to 1,523 m: 2
under 914 m: 16 (2004 est.)
the environment is exposed to intense pressures from human
activities: urbanization, dense transportation network, industry,
extensive animal breeding and crop cultivation; air and water
pollution also have repercussions for neighboring countries;
uncertainties regarding federal and regional responsibilities (now
resolved) have slowed progress in tackling environmental challenges
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.3% (2003)
74.28 billion kWh (2001)
78.18 billion kWh (2001)
15.82 billion kWh (2001)
6.712 billion kWh (2001)
4% (1989 est.)
lowest 10%: 3.2%
highest 10%: 23% (1996)
agriculture 1.3%, industry 24.5%, services 74.2% (2003 est.)
machinery and equipment, chemicals, diamonds, metals and
metal products, foodstuffs
Germany 19.5%, France 17.4%, Netherlands 11.7%, UK 9%, US
6.7%, Italy 5.4% (2003)
10 provinces (French: provinces, singular - province; Dutch:
provincies, singular - provincie) and 3 regions* (French: regions;
Dutch: gewesten); Antwerpen, Brabant Wallon, Brussels* (Bruxelles),
Flanders*, Hainaut, Liege, Limburg, Luxembourg, Namur,
Oost-Vlaanderen, Vlaams-Brabant, Wallonia*, West-Vlaanderen
note: as a result of the 1993 constitutional revision that furthered
devolution into a federal state, there are now three levels of
government (federal, regional, and linguistic community) with a
complex division of responsibilities
sugar beets, fresh vegetables, fruits, grain, tobacco; beef,
veal, pork, milk
42 (2003 est.)
10.59 births/1,000 population (2004 est.)
Army, Naval, and Air Operations Commands
revenues: $151.6 billion
expenditures: $151.1 billion, including capital expenditures of
$1.56 billion (2003)
Brussels
gas 1,485 km; oil 158 km; refined products 535 km (2004)
Bolivia
gas 4,860 km; liquid petroleum gas 47 km; oil 2,457 km;
refined products 1,589 km; unknown (oil/water) 247 km (2004)
Christian Democrats and Flemish or CD & V [Jo VANDEURZEN];
Ecolo (Francophone Greens) [Jean-Michel JAVAUX, Evelyne HUYTEBROECK,
Claude BROUIR]; Flemish Liberal Democrats or VLD [Bart SOMERS];
Flemish Socialist Party.Alternative or SP.A [Steve STEVAERT];
Francophone Humanist and Democratic Center of CDH [Joelle MILQUET];
Francophone Reformist Movement or MR [Didier REYNDERS]; Francophone
Socialist Party or PS [Elio DI RUPO]; GROEN! (formerly AGALEV,
Flemish Greens) [Vera DUA]; National Front or FN [Daniel FERET]; New
Flemish Alliance or NVA [Bart DE WEVER]; Spirit [Els VAN WEERT];
note - new party now associated with SP.A; Vlaams Belang or VB
[Frank VANHECKE]; other minor parties','333601f384a9ec551ccda5e13a31194fab74a10d52070d660702df08faa2b53d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac4eb9614f2da2259d8c9ecd0e13c403475188861a9a4b1041396722bd184c6',2004,'BZ','Belize','economy',660,'total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
total: 38
2,438 to 3,047 m: 1
914 to 1,523 m: 11
under 914 m: 26 (2004 est.)
deforestation; water pollution from sewage, industrial
effluents, agricultural runoff; solid and sewage waste disposal
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2% (2003)
199.5 million kWh (2001)
185.5 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
33% (1999 est.)
lowest 10%: NA
highest 10%: NA
agriculture 27%, industry 18%, services 55% (2001 est.)
sugar, bananas, citrus, clothing, fish products, molasses,
wood
US 39.1%, UK 25%, France 4% (2003)
6 districts; Belize, Cayo, Corozal, Orange Walk, Stann Creek,
Toledo
bananas, coca, citrus, sugar; fish, cultured shrimp; lumber;
garments
43 (2003 est.)
29.89 births/1,000 population (2004 est.)
Belize Defense Force (includes Army, Maritime Wing, Air Wing,
and Volunteer Guard)
revenues: $222 million
expenditures: $300 million, including capital expenditures of $70
million (2003 est.)
Belmopan
People''s United Party or PUP [Said MUSA]; United Democratic
Party or UDP [Dean BARROW, party leader; Douglas SINGH, party
chairman]','1f2430efe6eae2da4b718ef4e736472c73ea821b4a2d71759bb22f46589c1085','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c70155a42ac3056785dc7fc76deef2c5850086a304cb22fe6887d13455764401',2004,'BJ','Benin','economy',661,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2004 est.)
inadequate supplies of potable water; poaching threatens
wildlife populations; deforestation; desertification
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2.7% (2003)
274.3 million kWh (2001)
631.1 million kWh (2001)
376 million kWh (2001)
0 kWh (2001)
37% (2001 est.)
lowest 10%: NA
highest 10%: NA
cotton, crude oil, palm products, cocoa
China 21.1%, India 18%, Thailand 6.8%, Ghana 5.8%, Niger 4.4%,
Indonesia 4.1% (2003)
12 departments; Alibori, Atakora, Atlantique, Borgou,
Collines, Kouffo, Donga, Littoral, Mono, Oueme, Plateau, Zou
cotton, corn, cassava (tapioca), yams, beans, palm oil,
peanuts, livestock (2001)
5 (2003 est.)
42.57 births/1,000 population (2004 est.)
Armed Forces: Army, Navy, Air Force
revenues: $698.9 million
expenditures: $613.2 million, including capital expenditures of NA
(2003)
Porto-Novo is the official capital; Cotonou is the seat of
African Congress for Renewal or DUNYA [Saka SALEY]; African
Movement for Democracy and Progress or MADEP [Sefou FAGBOHOUN];
Alliance of the Social Democratic Party or PSD [Bruno AMOUSSOU];
Coalition of Democratic Forces [Gatien HOUNGBEDJI]; Democratic
Renewal Party or PRD [Adrien HOUNGBEDJI]; Front for Renewal and
Development or FARD-ALAFIA [Jerome Sakia KINA]; Impulse for Progress
and Democracy or IPD [Bertin BORNA]; Key Force or FC [leader NA];
Presidential Movement (UBF, MADEP, FC, IDP, and 4 other small
parties); Renaissance Party du Benin or PRB [Nicephore SOGLO]; The
Star Alliance (Alliance E''toile) [Sacca LAFIA]; Union of Tomorrow''s
Benin or UBF [Bruno AMOUSSOU]
note: approximately 20 additional minor parties','0dbc55dd2089b802a84bb5ce0ef90ab9568309eacd35c6c13b2f05af7648716d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b6debd7127867bd76e31e67599cb4287b9ace43d4d6337aecdfa5264aed6bcf',2004,'BM','Bermuda','economy',662,'total: 1
2,438 to 3,047 m: 1 (2004 est.)
asbestos disposal; water pollution; preservation of open
space; sustainable development
0.11% (FY00/01)
643.7 million kWh (2001)
598.6 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
19% (2000)
lowest 10%: NA
highest 10%: NA
agriculture and fishing 3%, laborers 17%, clerical 22%,
professional and technical 17%, administrative and managerial 13%,
sales 8%, services 20% (2000 est.)
reexports of pharmaceuticals
France 62%, Norway 13.8%, UK 7.5% (2003)
9 parishes and 2 municipalities*; Devonshire, Hamilton,
Hamilton*, Paget, Pembroke, Saint George*, Saint George''s, Sandys,
Smith''s, Southampton, Warwick
bananas, vegetables, citrus, flowers; dairy products
1 (2003 est.)
11.83 births/1,000 population (2004 est.)
Bermuda Regiment
revenues: $671.1 million
expenditures: $594.6 million, including capital expenditures of $55
million (FY03/04)
Gombey Liberation Party or GLP [Gavin Sundjata SMITH];
National Liberal Party or NLP [Dessaline WALDRON]; Progressive Labor
Party or PLP [William Alexander SCOTT]; United Bermuda Party or UBP
[Grant GIBBONS];','3c2a0162d97624ada131e63b53928e57d603365f9c348bcde71d7cccfac16d64','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2cf8717190b6083714f8b59fc6e00b95a6e5f5b8069056d15668768f6a4478b',2004,'BT','Bhutan','economy',663,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
Bolivia
total: 16
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2004 est.)
total: 1
914 to 1,523 m: 1 (2004 est.)
Bolivia
total: 1,049
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 60
914 to 1,523 m: 207
under 914 m: 778 (2004 est.)
soil erosion; limited access to potable water
Bolivia
the clearing of land for agricultural purposes and the
international demand for tropical timber are contributing to
deforestation; soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture); desertification;
loss of biodiversity; industrial pollution of water supplies used
for drinking and irrigation
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes
signed, but not ratified: Law of the Sea
Bolivia
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification, Marine Life
Conservation, Ozone Layer Protection
1.9% (2003)
Bolivia
1.6% (2003)
1.896 billion kWh (2001)
Bolivia
3.901 billion kWh (2001)
379.5 million kWh (2001)
Bolivia
3.634 billion kWh (2001)
16 million kWh (2001)
Bolivia
9 million kWh (2001)
1.4 billion kWh (2001)
Bolivia
3 million kWh (2001)
NA
Bolivia
70% (1999 est.)
lowest 10%: NA
highest 10%: NA
Bolivia
lowest 10%: 1.3%
highest 10%: 32% (1999)
agriculture 93%, industry and commerce 2%, services 5%
Bolivia
agriculture NA, industry NA, services NA
electricity (to India), cardamom, gypsum, timber,
handicrafts, cement, fruit, precious stones, spices
Bolivia
soybeans, natural gas, zinc, gold, wood (2000)
Bangladesh 60.5%, US 11.7%, Malaysia 5.7% (2003)
Bolivia
Brazil 37%, Venezuela 12.9%, Colombia 11.9%, US 11.5%, Peru
5.1% (2003)
18 districts (dzongkhag, singular and plural); Bumthang,
Chhukha, Chirang, Dagana, Geylegphug, Ha, Lhuntshi, Mongar, Paro,
Pemagatsel, Punakha, Samchi, Samdrup Jongkhar, Shemgang, Tashigang,
Thimphu, Tongsa, Wangdi Phodrang
note: there may be two new districts named Gasa and Yangtse
Bolivia
9 departments (departamentos, singular - departamento);
Chuquisaca, Cochabamba, Beni, La Paz, Oruro, Pando, Potosi, Santa
Cruz, Tarija
rice, corn, root crops, citrus, foodgrains; dairy products,
eggs
Bolivia
soybeans, coffee, coca, cotton, corn, sugarcane, rice,
potatoes; timber
2 (2003 est.)
Bolivia
1,067 (2003 est.)
34.41 births/1,000 population (2004 est.)
Bolivia
24.65 births/1,000 population (2004 est.)
Royal Bhutan Army, Royal Bodyguard, National Militia
Bolivia
Army (Ejercito Boliviano), Navy (Fuerza Naval, includes
Marines), Air Force (Fuerza Aerea Boliviana)
revenues: $146 million
expenditures: $152 million, including capital expenditures of NA
note: the government of India finances nearly three-fifths of
Bhutan''s budget expenditures (FY95/96 est.)
Bolivia
revenues: $2.346 billion
expenditures: $2.957 billion, including capital expenditures of $NA
(2003)
no legal parties
Bolivia
Bolivian Socialist Falange or FSB [Romel PANTOJA]; Civic
Solidarity Union or UCS [Johnny FERNANDEZ]; Free Bolivia Movement or
MBL [Franz BARRIOS]; Marshal of Ayacucho Institutional Vanguard or
VIMA [Freddy ZABALA]; Movement of the Revolutionary Left or MIR
[Jaime PAZ Zamora]; Movement Toward Socialism or MAS [Evo MORALES];
Movement Without Fear or MSM [Juan DEL GRANADO]; Nationalist
Democratic Action or ADN [Jorge Fernando QUIROGA Ramirez];
Nationalist Revolutionary Movement or MNR [leader NA]; New
Republican Force or NFR [Manfred REYES-VILLA]; Pachakuti Indigenous
Movement or MIP [Felipe QUISPE]; Socialist Party or PS [Jeres
JUSTINIANO]','e560ca811fb9f08718c17a912aab97722f4c3c4326747212127595641ba79fc8','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8142f7eb912329e3d93829148664557e383e94844cc5cecb4444a3e021d6deb4',2004,'BA','Bosnia and Herzegovina','economy',664,'total: 8
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
under 914 m: 3 (2004 est.)
total: 19
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 11 (2004 est.)
air pollution from metallurgical plants;
sites for disposing of urban waste are limited; water shortages and
destruction of infrastructure because of the 1992-95 civil strife;
deforestation
party to: Air Pollution, Biodiversity,
Climate Change, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
4.5% (FY02)
9.979 billion kWh (2001)
8.116 billion kWh (2001)
1.405 billion kWh (2001)
2.569 billion kWh (2001)
NA (2004 est.)
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
metals, clothing, wood products
Italy 28.7%, Croatia 18.3%, Germany 17.1%,
Austria 9.2%, Slovenia 7.1% (2003)
2 first-order administrative divisions and 1
internationally supervised district* - Brcko district (Brcko
Distrikt)*, the Bosniak/Croat Federation of Bosnia and Herzegovina
(Federacija Bosna i Hercegovina) and the Bosnian Serb-led Republika
Srpska; note - Brcko district is in northeastern Bosnia and is an
administrative unit under the sovereignty of Bosnia and Herzegovina;
the district remains under international supervision
wheat, corn, fruits, vegetables; livestock
27 (2003 est.)
12.56 births/1,000 population (2004 est.)
VF Army (the air and air defense forces are
subordinate commands within the Army), VRS Army (the air and air
defense forces are subordinate commands within the Army)
revenues: $3.271 billion
expenditures: $3.242 billion, including capital expenditures of NA
(2003 est.)
Alliance of Independent Social Democrats or
SNSD [Milorad DODIK]; Bosnian Party or BOSS [Mirnes AJANOVIC]; Civic
Democratic Party or GDS [Ibrahim SPAHIC]; Croatian Democratic Union
of Bosnia and Herzegovina or HDZ-BH [Barisa COLAK]; Croat Christian
Democratic Union of Bosnia and Herzegovina or HKDU [Mijo
IVANIC-LONIC]; Croat Party of Rights or HSP [Zdravko HRISTIC]; Croat
Peasants Party or HSS [Marko TADIC]; Democratic National Union or
DNZ [Fikret ABDIC]; Liberal Democratic Party or LDS [Rasim KADIC];
New Croat Initiative or NHI [Kresimir ZUBAK]; Party for Bosnia and
Herzegovina or SBiH [Safet HALILOVIC]; Party of Democratic Action or
SDA [Sulejman TIHIC]; Party of Democratic Progress or PDP [Mladen
IVANIC]; Serb Democratic Party or SDS [Dragan CAVIC - acting]; Serb
Radical Party of the Republika Srpska or SRS-RS [Milanko MIHAJLICA];
Serb Radical Party-Dr. Vojislav Seselj or SRS-VS [Radislav
KANJERIC]; Social Democratic Party of BIH or SDP [Zlatko
LAGUMDZIJA]; Social Democratic Union or SDU [Miro LAZOVIC];
Socialist Party of Republika Srpska or SPRS [Petar DJOKIC]','e9c108456930bdbb4ca6cf58df05db9d0edd233bfb22ce4c2bfc965ddf5695d7','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d18723355b6c1cc0d699d01b2b430bef683369b0b8d9d41be55c89443691aaa',2004,'BW','Botswana','economy',665,'total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2004 est.)
total: 75
1,524 to 2,437 m: 3
914 to 1,523 m: 54
under 914 m: 18 (2004 est.)
overgrazing; desertification; limited fresh water resources
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
3.6% (2003)
409.8 million kWh (2001)
1.564 billion kWh (2001)
1.183 billion kWh (2001)
0 kWh (2001)
47% (2002 est.)
lowest 10%: NA
highest 10%: NA
NA
diamonds, copper, nickel, soda ash, meat, textiles
European Free Trade Association (EFTA) 87%, Southern
African Customs Union (SACU) 7%, Zimbabwe 4% (2000)
9 districts and four town councils*; Central, Francistown*,
Gaborone*, Ghanzi, Kgalagadi, Kgatleng, Kweneng, Lobatse*,
Northwest, Northeast, Selebi-Pikwe*, Southeast, Southern
livestock, sorghum, maize, millet, beans, sunflowers,
groundnuts
85 (2003 est.)
24.71 births/1,000 population (2004 est.)
Botswana Defense Force (including an Air Wing)
revenues: $3.263 billion
expenditures: $3.283 billion, including capital expenditures of NA
(2003)
Botswana Democratic Party or BDP [Seretse Ian KHAMA];
Botswana National Front or BNF [Otswoletse MOUPO]; Botswana Congress
Party or BCP [Mokgweetsi KGOSIPULA]; Botswana Alliance Movement or
BAM [Ephraim Lepetu SETSHWAELO]
note: a number of minor parties joined forces in 1999 to form the
BAM but did not capture any parliamentary seats; the BAM parties
are: the United Action Party [Ephraim Lepetu SETSHWAELO], the
Independence Freedom Party or IFP [Motsamai MPHO], and the Botswana
Progressive Union [D. K. KWELE]','b704e9b33a83e02dbc5942b04f49e4e475667561a882e8ae4a4f5ac99058a2a4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57b024c80d52d14115f090baa21e6dcb912bd870c98dd0bdfaf282ef2d11d9e3',2004,'BR','Brazil','economy',666,'total: 698
over 3,047 m: 7
2,438 to 3,047 m: 23
1,524 to 2,437 m: 158
914 to 1,523 m: 461
under 914 m: 49 (2004 est.)
total: 3,438
over 3,047 m: 1
1,524 to 2,437 m: 78
914 to 1,523 m: 1,579
under 914 m: 1,780 (2004 est.)
British Virgin Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
Brunei
total: 1
914 to 1,523 m: 1 (2004 est.)
deforestation in Amazon Basin destroys the habitat and
endangers a multitude of plant and animal species indigenous to the
area; there is a lucrative illegal wildlife trade; air and water
pollution in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by improper
mining activities; wetland degradation; severe oil spills
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Brunei
party to: Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
2.1% (2003)
Brunei
5.9% (2003)
321.2 billion kWh (2001)
335.9 billion kWh (2001)
37.19 billion kWh; note - supplied by Paraguay (2001)
British Virgin Islands
0 kWh (2001)
Brunei
0 kWh (2001)
0 kWh (2001)
British Virgin Islands
0 kWh (2001)
Brunei
0 kWh (2001)
22% (1998 est.)
British Virgin Islands
NA
Brunei
NA (1992 est.)
lowest 10%: 0.7%
highest 10%: 48% (1998)
British Virgin Islands
lowest 10%: NA
highest 10%: NA
Brunei
lowest 10%: NA
highest 10%: NA
agriculture 23%, industry 24%, services 53%
British Virgin Islands
agriculture NA, industry NA, services NA
Brunei
agriculture, forestry, and fishing 10%, production of oil,
natural gas, services, and construction 42%, government 48% (1999
est.)
transport equipment, iron ore, soybeans, footwear, coffee,
autos
British Virgin Islands
rum, fresh fish, fruits, animals; gravel, sand
Brunei
crude oil, natural gas, refined products
US 23%, Argentina 6.1%, China 6%, Netherlands 5.8%, Germany
4.2% (2003)
British Virgin Islands
Virgin Islands (US), Puerto Rico, US
Brunei
Japan 41%, South Korea 11.2%, Thailand 9.4%, Australia 8.4%,
US 7.8%, China 6.7%, Singapore 4.5% (2003)
26 states (estados, singular - estado) and 1 federal
district* (distrito federal); Acre, Alagoas, Amapa, Amazonas, Bahia,
Ceara, Distrito Federal*, Espirito Santo, Goias, Maranhao, Mato
Grosso, Mato Grosso do Sul, Minas Gerais, Para, Paraiba, Parana,
Pernambuco, Piaui, Rio de Janeiro, Rio Grande do Norte, Rio Grande
do Sul, Rondonia, Roraima, Santa Catarina, Sao Paulo, Sergipe,
Tocantins
British Virgin Islands
none (overseas territory of the UK)
Brunei
4 districts (daerah-daerah, singular - daerah); Belait,
Brunei and Muara, Temburong, Tutong
coffee, soybeans, wheat, rice, corn, sugarcane, cocoa,
citrus; beef
British Virgin Islands
fruits, vegetables; livestock, poultry; fish
Brunei
rice, vegetables, fruits, chickens, water buffalo
3,803 (2003 est.)
17.25 births/1,000 population (2004 est.)
British Virgin Islands
14.96 births/1,000 population (2004 est.)
Brunei
19.33 births/1,000 population (2004 est.)
Brazilian Army, Brazilian Navy (including Naval Air and
Marines), Brazilian Air Force (FAB)
Brunei
Royal Brunei Land Forces, Royal Brunei Navy, Royal Brunei Air
Force
revenues: $147.2 billion
expenditures: $172.4 billion, including capital expenditures of NA
(2003)
British Virgin Islands
revenues: $121.5 million
expenditures: $115.5 million, including capital expenditures of NA
(1997)
Brunei
revenues: $2.5 billion
expenditures: $2.6 billion, including capital expenditures of $1.35
billion (1997 est.)
condensate/gas 244 km; gas 10,739 km; liquid petroleum gas
341 km; oil 5,212 km; refined products 4,755 km (2004)
Brunei
gas 665 km; oil 439 km (2004)
Brazilian Democratic Movement Party or PMDB [Federal Deputy
Michel TEMER]; Brazilian Labor Party or PTB [Federal Deputy Roberto
JEFFERSON]; Brazilian Social Democracy Party or PSDB [Senator
Eduardo AZAREDO]; Brazilian Socialist Party or PSB [Federal Deputy
Miguel ARRAES]; Communist Party of Brazil or PCdoB [Renato RABELO];
Democratic Labor Party or PDT [Carlos LUPI]; Green Party or PV [Jose
Luiz de Franca PENNA]; Liberal Front Party or PFL [Senator Jorge
BORNHAUSEN]; Liberal Party or PL [Federal Deputy Valdemar COSTA
Neto]; National Order Reconstruction Party or PRONA [Federal Deputy
Dr. Eneas CARNEIRO]; Popular Socialist Party or PPS [Federal Deputy
Roberto FREIRE]; Progressive Party or PP [Federal Deputy Pedro
CORREA]; Worker''s Party or PT [Jose GENOINO]; Social Christian Party
or PSC [Vitor Jorge ABDALA NOSSEIS]
British Virgin Islands
Concerned Citizens Movement or CCM [Ethlyn
SMITH]; National Democratic Party or NDP [Orlando SMITH]; United
Party or UP [Gregory MADURO]; Virgin Islands Party or VIP [Ralph T.
O''NEAL]
Brunei
other parties include Brunei People''s Party or PRB (banned in
1962) and Brunei National Democratic Party (registered in May 1965,
deregistered by the Brunei Government in 1988)','52d9ececfbe733014127592c4f2e09a188af8b084a26d7dfbadfeab4b2216c9b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99f1d3bfb5083d37552083aa20b64302f34cb57bd8038c15089f790525331643',2004,'IO','British Indian Ocean Territory','economy',667,'total: 1
over 3,047 m: 1 (2004 est.)
British Virgin Islands
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
Brunei
total: 1
over 3,047 m: 1 (2004 est.)
NA
British Virgin Islands
limited natural fresh water resources (except
for a few seasonal streams and springs on Tortola, most of the
islands'' water supply comes from wells and rainwater catchments)
Brunei
seasonal smoke/haze resulting from forest fires in Indonesia
NA kWh; note - electricity supplied
by the US military
British Virgin Islands
38.1 million kWh (2001)
Brunei
2.497 billion kWh (2001)
NA kWh
British Virgin Islands
35.43 million kWh (2001)
Brunei
2.322 billion kWh (2001)
1 (2003 est.)
British Virgin Islands
3 (2003 est.)
Brunei
2 (2003 est.)','7aee55956f0bc80dd40f9787664bc41fb21a9f1d9995c2192d2b2575cdcaea07','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e10d9f743d371ebae91ac18693c33047f83bf06f33f90afe187fe008de72b48f',2004,'BG','Bulgaria','economy',668,'total: 128
over 3,047 m: 1
2,438 to 3,047 m: 19
1,524 to 2,437 m: 15
914 to 1,523 m: 1
under 914 m: 92 (2004 est.)
total: 85
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 72 (2004 est.)
air pollution from industrial emissions; rivers polluted
from raw sewage, heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical plants and
industrial wastes
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulfur 94
2.6% (2003)
41.38 billion kWh (2001)
32.52 billion kWh (2001)
830 million kWh (2001)
6.79 billion kWh (2001)
13.4% (2002 est.)
lowest 10%: 4.5%
highest 10%: 22.8% (1997)
agriculture 26%, industry 31%, services 43% (1998 est.)
clothing, footwear, iron and steel, machinery and
equipment, fuels
Italy 14.1%, Germany 10.9%, Greece 10.5%, Turkey 9.2%,
France 5.1%, US 4.5% (2003)
28 provinces (oblasti, singular - oblast); Blagoevgrad,
Burgas, Dobrich, Gabrovo, Khaskovo, Kurdzhali, Kyustendil, Lovech,
Montana, Pazardzhik, Pernik, Pleven, Plovdiv, Razgrad, Ruse, Shumen,
Silistra, Sliven, Smolyan, Sofiya, Sofiya-Grad, Stara Zagora,
Turgovishte, Varna, Veliko Turnovo, Vidin, Vratsa, Yambol
vegetables, fruits, tobacco, livestock, wine, wheat,
barley, sunflowers, sugar beets
212 (2003 est.)
9.65 births/1,000 population (2004 est.)
Army, Navy, Air and Air Defense Forces
revenues: $8.121 billion
expenditures: $8.121 billion, including capital expenditures of NA
(2003 est.)
gas 2,425 km; oil 339 km; refined products 156 km (2004)
Burma
gas 2,056 km; oil 558 km (2004)
Bulgarian Agrarian National Union-People''s Union or BANU
[Anastasia MOZER]; Bulgarian Socialist Party or BSP [Sergei
STANISHEV]; Coalition for Bulgaria or CfB (coalition of parties
dominated by BSP) [Sergei STANISHEV]; Democrats for a Strong
Bulgaria or DSB [Ivan KOSTOV]; Movement for Rights and Freedoms or
MRF [Ahmed DOGAN]; National Movement for Simeon II or NMS2 [Simeon
SAXE-COBURG-GOTHA]; New Time [Emil KOSHLUKOV]; Union of Democratic
Forces or UDF [Nadezhda MIKHAYLOVA]; Union of Free Democrats or UFD
[Stefan SOFIYANSKI]; United Democratic Forces or UtDF (a coalition
of center-right parties dominated by DSB)','9c9baa2fcd7b04926bb45a468b586c8b8d1f52fe3b79de1245e712e2e6382c3e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e687088a9d5df71836cadc9286df16e5da420295ce4c425e0edf1abb8090c24',2004,'BF','Burkina Faso','economy',669,'total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2004 est.)
Burma
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 2 (2004 est.)
total: 31
1,524 to 2,437 m: 3
914 to 1,523 m: 11
under 914 m: 17 (2004 est.)
Burma
total: 69
over 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 20
under 914 m: 31 (2004 est.)
recent droughts and desertification severely affecting
agricultural activities, population distribution, and the economy;
overgrazing; soil degradation; deforestation
Burma
deforestation; industrial pollution of air, soil, and water;
inadequate sanitation and water treatment contribute to disease
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Burma
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: none of the selected agreements
1.6% (2003)
Burma
2.1% (FY97)
279.2 million kWh (2001)
Burma
6.139 billion kWh (2001)
259.6 million kWh (2001)
Burma
5.709 billion kWh (2001)
0 kWh (2001)
Burma
0 kWh (2001)
0 kWh (2001)
Burma
0 kWh (2001)
45% (2003 est.)
Burma
25% (2000 est.)
lowest 10%: 2%
highest 10%: 46.8% (1994)
Burma
lowest 10%: 2.8%
highest 10%: 32.4% (1998)
agriculture 90% (2000 est.)
Burma
agriculture 70%, industry 7%, services 23% (2001 est.)
cotton, livestock, gold
Burma
Clothing, gas, wood products, pulses, beans, fish, rice
Singapore 12.8%, China 11.6%, Thailand 8%, Italy 6.4%,
India 6%, Colombia 5.2%, Ghana 5.2%, France 4.8%, Niger 4% (2003)
Burma
Thailand 31.5%, US 10.2%, India 9.3%, China 5.8%, Japan 4.8%
(2003)
45 provinces; Bale, Bam, Banwa, Bazega, Bougouriba,
Boulgou, Boulkiemde, Comoe, Ganzourgou, Gnagna, Gourma, Houet, Ioba,
Kadiogo, Kenedougou, Komondjari, Kompienga, Kossi, Koulpelogo,
Kouritenga, Kourweogo, Leraba, Loroum, Mouhoun, Namentenga, Nahouri,
Nayala, Noumbiel, Oubritenga, Oudalan, Passore, Poni, Sanguie,
Sanmatenga, Seno, Sissili, Soum, Sourou, Tapoa, Tuy, Yagha, Yatenga,
Ziro, Zondoma, Zoundweogo
Burma
7 divisions (taing-myar, singular - taing) and 7 states (pyi
ne-myar, singular - pyi ne)
divisions: Ayeyarwady, Bago, Magway, Mandalay, Sagaing, Tanintharyi,
Yangon (Rangoon)
states: Chin State, Kachin State, Kayin State, Kayah State, Mon
State, Rakhine State, Shan State
cotton, peanuts, shea nuts, sesame, sorghum, millet,
corn, rice; livestock
Burma
rice, pulses, beans, sesame, groundnuts, sugarcane; hardwood;
fish and fish products
33 (2003 est.)
Burma
79 (2003 est.)
44.46 births/1,000 population (2004 est.)
Burma
18.64 births/1,000 population (2004 est.)
Army, Air Force
Burma
Army, Navy, Air Force
revenues: $599.8 million
expenditures: $748.8 million NA, including capital expenditures of
NA (2003)
Burma
revenues: $7.9 billion
expenditures: $12.2 billion, including capital expenditures of $5.7
billion (FY96/97)
African Democratic Rally-Alliance for Democracy and
Federation or RDA-ADF [Herman YAMEOGO]; Confederation for Federation
and Democracy or CFD [Amadou Diemdioda DICKO]; Congress for
Democracy and Progress or CDP [Roch Marc-Christian KABORE]; Movement
for Tolerance and Progress or MTP [Nayabtigungou Congo KABORE];
Party for African Independence or PAI [Philippe OUEDRAOGO]; Party
for Democracy and Progress or PDP [Joseph KI-ZERBO]; Union of Greens
for the Development of Burkina Faso or UVDB [Ram OVEDRAGO]
Burma
National League for Democracy or NLD [AUNG SHWE, chairman,
AUNG SAN SUU KYI, general secretary]; National Unity Party or NUP
(progovernment) [THA KYAW]; Shan Nationalities League for Democracy
or SNLD [KHUN HTUN OO]; and other smaller parties','ee8355ca11af1d7ba43f6c21c68b818750b22d8faa68c275f63ed746cdaa82ae','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b2595dddef44c40bd720ce81022a67993b2e185eb5aa35c3a27f555751b7518',2004,'BI','Burundi','economy',670,'total: 1
over 3,047 m: 1 (2004 est.)
total: 7
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
soil erosion as a result of overgrazing and the expansion of
agriculture into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for fuel); habitat
loss threatens wildlife populations
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: Law of the Sea
6% (2003)
155.4 million kWh (2001)
177.5 million kWh (2001)
33 million kWh; note - supplied by the Democratic Republic
of the Congo (2001)
0 kWh (2001)
68% (2002 est.)
lowest 10%: 1.8%
highest 10%: 32.9% (1998)
agriculture 93.6%, industry 2.3%, services 4.1% (2002 est.)
coffee, tea, sugar, cotton, hides
Switzerland 31.6%, UK 15.8%, Netherlands 5.3%, Rwanda 5.3%
(2003)
16 provinces; Bubanza, Bujumbura, Bururi, Cankuzo, Cibitoke,
Gitega, Karuzi, Kayanza, Kirundo, Makamba, Muramvya, Muyinga, Mwaro,
Ngozi, Rutana, Ruyigi
coffee, cotton, tea, corn, sorghum, sweet potatoes, bananas,
manioc (tapioca); beef, milk, hides
8 (2003 est.)
39.68 births/1,000 population (2004 est.)
Army (including Naval Detachment and Air Wing), National
Gendarmerie
revenues: $179.4 million
expenditures: $209 million, including capital expenditures of $NA
(2003)
the two national, mainstream, governing parties are: Unity
for National Progress or UPRONA [Alphonse KADEGE, president];
Burundi Democratic Front or FRODEBU [Jean MINANI, president]
note: a multiparty system was introduced after 1998, included are:
Burundi African Alliance for the Salvation or ABASA [Terrence
NSANZE]; Rally for Democracy and Economic and Social Development or
RADDES [Joseph NZEYIMANA]; Party for National Redress or PARENA
[Jean-Baptiste BAGAZA]; People''s Reconciliation Party or PRP
[Mathias HITIMANA]','0cda7093820a91d72e5013c126363315d9d347b05224e44bb497226cb4f8506e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf5f6c9da6331272ae5efe5b5575abddbbcf1d6fe5e76ca258d1e3053cbcecad',2004,'KH','Cambodia','economy',671,'total: 6
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2 (2004 est.)
total: 14
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 1 (2004 est.)
illegal logging activities throughout the country and strip
mining for gems in the western region along the border with Thailand
have resulted in habitat loss and declining biodiversity (in
particular, destruction of mangrove swamps threatens natural
fisheries); soil erosion; in rural areas, most of the population
does not have access to potable water; declining fish stocks because
of illegal fishing and overfishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3% (FY01 est.)
119 million kWh (2001)
110.6 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
36% (1997 est.)
lowest 10%: 2.9%
highest 10%: 33.8% (1997)
agriculture 75% (2003 est.)
Clothing, timber, rubber, rice, fish, tobacco, footwear
US 58.4%, Germany 10.3%, UK 7.2% (2003)
20 provinces (khaitt, singular and plural) and 4
municipalities (krong, singular and plural)
provinces: Banteay Mean Chey, Batdambang, Kampong Cham, Kampong
Chhnang, Kampong Spoe, Kampong Thum, Kampot, Kandal, Koh Kong,
Kracheh, Mondol Kiri, Otdar Mean Chey, Pouthisat, Preah Vihear, Prey
Veng, Rotanakir, Siem Reab, Stoeng Treng, Svay Rieng, Takao
municipalities: Keb, Pailin, Phnom Penh, Preah Sihanouk (formerly
Kompong Som)
rice, rubber, corn, vegetables, cashews, tapioca
20 (2003 est.)
27.13 births/1,000 population (2004 est.)
Royal Cambodian Armed Forces: Army, Navy, Air Force
revenues: $476.5 million
expenditures: $734.8 million, including capital expenditures of $291
million of which 75% was financed by external assistance (2003 est.)
Cambodian Pracheachon Party (Cambodian People''s Party) or
CPP [CHEA SIM]; National United Front for an Independent, Neutral,
Peaceful, and Cooperative Cambodia or FUNCINPEC [Prince NORODOM
Ranariddh]; Sam Rangsi Party or SRP [SAM RANGSI]','4ab0486a6420111390a436454b8c495fe7c010a514c1129f4ce0af488f1c5a2f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e9a5ad8744b2df67af692cfe6cfc6225267bdb2eff2ad85808064c9c7d7774',2004,'CM','Cameroon','economy',672,'total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 36
1,524 to 2,437 m: 7
914 to 1,523 m: 20
under 914 m: 9 (2004 est.)
water-borne diseases are prevalent; deforestation;
overgrazing; desertification; poaching; overfishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
1.4% (2003)
3.613 billion kWh (2001)
3.36 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
48% (2000 est.)
lowest 10%: 1.9%
highest 10%: 36.6% (1996)
agriculture 70%, industry and commerce 13%, other 17%
crude oil and petroleum products, lumber, cocoa beans,
aluminum, coffee, cotton
Spain 21.9%, Italy 13.4%, France 10.8%, Netherlands 10.6%,
US 7.5%, China 4.4% (2003)
10 provinces; Adamaoua, Centre, Est, Extreme-Nord,
Littoral, Nord, Nord-Ouest, Ouest, Sud, Sud-Ouest
coffee, cocoa, cotton, rubber, bananas, oilseed, grains,
root starches; livestock; timber
47 (2003 est.)
35.08 births/1,000 population (2004 est.)
Army, Navy (includes Naval Infantry), Air Force
revenues: $2.442 billion
expenditures: $1.941 billion, including capital expenditures of NA
(2003 est.)
gas 90 km; liquid petroleum gas 9 km; oil 1,120 km (2004)
Cameroonian Democratic Union or UDC [Adamou NDAM NJOYA];
Democratic Rally of the Cameroon People or RDCP [Paul BIYA];
Movement for the Defense of the Republic or MDR [Dakole DAISSALA];
Movement for the Liberation and Development of Cameroon or MLDC
[leader Marcel YONDO]; Movement for the Youth of Cameroon or MYC
[Dieudonne TINA]; National Union for Democracy and Progress or UNDP
[Maigari BELLO BOUBA]; Social Democratic Front or SDF [John FRU
NDI]; Union of Cameroonian Populations or UPC [Augustin Frederic
KODOCK]','750dec4390865cc4c7f92e7c7cc8000b8040a787be431ac714f402d55b7fbb04','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57ac91a7d9e0e9ecaa256ff536c81a1c10fa4278a2628683ee44482095eea886',2004,'CA','Canada','economy',673,'total: 503
over 3,047 m: 18
2,438 to 3,047 m: 15
1,524 to 2,437 m: 150
914 to 1,523 m: 245
under 914 m: 75 (2004 est.)
Cape Verde
total: 6
over 3,047 m: 1
914 to 1,523 m: 5 (2004 est.)
total: 823
1,524 to 2,437 m: 67
914 to 1,523 m: 347
under 914 m: 409 (2004 est.)
Cape Verde
total: 1
under 914 m: 1 (2004 est.)
air pollution and resulting acid rain severely affecting
lakes and damaging forests; metal smelting, coal-burning utilities,
and vehicle emissions impacting on agricultural and forest
productivity; ocean waters becoming contaminated due to
agricultural, industrial, mining, and forestry activities
Cape Verde
soil erosion; demand for wood used as fuel has resulted
in deforestation; desertification; environmental damage has
threatened several species of birds and reptiles; illegal beach sand
extraction; overfishing
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Marine Life Conservation
Cape Verde
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
1.1% (2003)
Cape Verde
1.5% (2003)
566.3 billion kWh (2001)
Cape Verde
42.03 million kWh (2001)
504.4 billion kWh (2001)
Cape Verde
39.08 million kWh (2001)
16.11 billion kWh (2001)
Cape Verde
0 kWh (2001)
38.4 billion kWh (2001)
Cape Verde
0 kWh (2001)
NA
Cape Verde
30% (2000)
lowest 10%: 2.8%
highest 10%: 23.8% (1994)
Cape Verde
lowest 10%: NA
highest 10%: NA
agriculture 3%, manufacturing 15%, construction 5%, services
74%, other 3% (2000)
motor vehicles and parts, industrial machinery, aircraft,
telecommunications equipment; chemicals, plastics, fertilizers; wood
pulp, timber, crude petroleum, natural gas, electricity, aluminum
Cape Verde
fuel, shoes, garments, fish, hides
US 86.6%, Japan 2.1%, UK 1.4% (2003)
Cape Verde
Portugal 31%, France 27.6%, UK 17.2%, US 17.2% (2003)
10 provinces and 3 territories*; Alberta, British Columbia,
Manitoba, New Brunswick, Newfoundland and Labrador, Northwest
Territories*, Nova Scotia, Nunavut*, Ontario, Prince Edward Island,
Quebec, Saskatchewan, Yukon Territory*
Cape Verde
17 municipalities (concelhos, singular - concelho); Boa
Vista, Brava, Maio, Mosteiros, Paul, Praia, Porto Novo, Ribeira
Grande, Sal, Santa Catarina, Santa Cruz, Sao Domingos, Sao Filipe,
Sao Miguel, Sao Nicolau, Sao Vicente, Tarrafal
wheat, barley, oilseed, tobacco, fruits, vegetables; dairy
products; forest products; fish
Cape Verde
bananas, corn, beans, sweet potatoes, sugarcane, coffee,
peanuts; fish
1,357 (2003 est.)
Cape Verde
7
note: 3 airports are reported to be nonoperational (2003 est.)
10.91 births/1,000 population (2004 est.)
Cape Verde
26.13 births/1,000 population (2004 est.)
Canadian Armed Forces: Land Forces Command, Maritime Command,
Air Command
Cape Verde
Army, Coast Guard
revenues: $348.2 billion
expenditures: $342.7 billion, including capital expenditures of NA
(2003 est.)
Cape Verde
revenues: $252.9 million
expenditures: $269.9 million, including capital expenditures of NA
(2003)
As an affluent, high-tech industrial society, Canada today
closely resembles the US in its market-oriented economic system,
pattern of production, and high living standards. Since World War
II, the impressive growth of the manufacturing, mining, and service
sectors has transformed the nation from a largely rural economy into
one primarily industrial and urban. The 1989 US-Canada Free Trade
Agreement (FTA) and the 1994 North American Free Trade Agreement
(NAFTA) (which includes Mexico) touched off a dramatic increase in
trade and economic integration with the US. As a result of the close
cross-border relationship, the economic sluggishness in the United
States in 2001-02 had a negative impact on the Canadian economy.
Real growth averaged nearly 3% during 1993-2000, but declined in
2001, with moderate recovery in 2002-03. Unemployment is up, with
contraction in the manufacturing and natural resource sectors.
Nevertheless, given its great natural resources, skilled labor
force, and modern capital plant Canada enjoys solid economic
prospects. Solid fiscal management has produced a long-term budget
surplus which is substantially reducing the national debt, although
public debate continues over how to manage the rising cost of the
publicly funded healthcare system. Trade accounts for roughly a
third of GDP. Canada enjoys a substantial trade surplus with its
principal trading partner, the United States, which absorbs more
than 85% of Canadian exports. Roughly 90% of the population lives
within 160 kilometers of the US border.
Cape Verde
This island economy suffers from a poor natural resource
base, including serious water shortages exacerbated by cycles of
long-term drought. The economy is service-oriented, with commerce,
transport, tourism, and public services accounting for 72% of GDP.
Although nearly 70% of the population lives in rural areas, the
share of agriculture in GDP in 2001 was only 11%, of which fishing
accounted for 1.5%. About 82% of food must be imported. The fishing
potential, mostly lobster and tuna, is not fully exploited. Cape
Verde annually runs a high trade deficit, financed by foreign aid
and remittances from emigrants; remittances supplement GDP by more
than 20%. Economic reforms are aimed at developing the private
sector and attracting foreign investment to diversify the economy.
Prospects for 2004 depend heavily on the maintenance of aid flows,
tourism, remittances, and the momentum of the government''s
development program.
crude and refined oil 23,564 km; liquid petroleum gas 74,980
km (2003)
Bloc Quebecois [Gilles DUCEPPE]; Conservative Party of Canada
(a merger of the Canadian Alliance and the Progressive Conservative
Party) [Stephen HARPER]; Liberal Party [Paul MARTIN]; New Democratic
Party [Jack LAYTON]
Cape Verde
African Party for Independence of Cape Verde or PAICV
[Jose Maria Pereira NEVES, chairman]; Democratic Alliance for Change
or ADM [Dr. Eurico MONTEIRO] (a coalition of PCD, PTS, and UCID);
Democratic Christian Party or PDC [Manuel RODRIGUES, chairman];
Democratic Renovation Party or PRD [Jacinto SANTOS, president];
Movement for Democracy or MPD [Agostinho LOPES, president]; Party
for Democratic Convergence or PCD [Dr. Eurico MONTEIRO, president];
Party of Work and Solidarity or PTS [Isaias RODRIGUES, president];
Social Democratic Party or PSD [Joao ALEM, president]','7305e7728966854f00c7de7ffed72faa7d93b8f9903b58d1c0bf4981c6e767a9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c0e002fefbe5767adf88c91316ae5e031627d3702793ac6df2e877eb6cc591e',2004,'KY','Cayman Islands','economy',674,'total: 2
1,524 to 2,437 m: 2 (2004 est.)
total: 1
914 to 1,523 m: 1 (2004 est.)
no natural fresh water resources; drinking water
supplies must be met by rainwater catchments
381.9 million kWh (2001)
355.2 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA (2002 est.)
lowest 10%: NA
highest 10%: NA
agriculture 1.4%, industry 12.6%, services 86% (1995)
turtle products, manufactured consumer goods
mostly US
8 districts; Creek, Eastern, Midland, South Town,
Spot Bay, Stake Bay, West End, Western
vegetables, fruit; livestock, turtle farming
3 (2003 est.)
13.11 births/1,000 population (2004 est.)
no regular military forces; Royal Cayman Islands
Police Force
revenues: $265.2 million
expenditures: $248.9 million, including capital expenditures of NA
(1997)
With no direct taxation, the islands are a thriving
offshore financial center. More than 40,000 companies were
registered in the Cayman Islands as of 1998, including almost 600
banks and trust companies; banking assets exceed $500 billion. A
stock exchange was opened in 1997. Tourism is also a mainstay,
accounting for about 70% of GDP and 75% of foreign currency
earnings. The tourist industry is aimed at the luxury market and
caters mainly to visitors from North America. Total tourist arrivals
exceeded 1.2 million in 1997, with 600,000 from the US. About 90% of
the islands'' food and consumer goods must be imported. The
Caymanians enjoy one of the highest outputs per capita and one of
the highest standards of living in the world.
no national teams (loose groupings of political
organizations) were formed for the 2000 elections; United Democratic
Party or UDP [leader McKeeva BUSH]; People''s Progressive Movement or
PPM [leader Kurt TIBBETTS]','2e1ac0ce4578c07fa50b1c026f3596a9241a81c9162bad4411a92dd99640a7e4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79695c4bda3db303d831d6cb4d6fd79f2b8570e6a2fffa135b5903bcbc3312bd',2004,'CF','Central African Republic','economy',675,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2004 est.)
total: 47
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 13 (2004 est.)
tap water is not potable; poaching has
diminished the country''s reputation as one of the last great
wildlife refuges; desertification; deforestation
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection,
Tropical Timber 94
signed, but not ratified: Law of the Sea
1.1% (2003)
106 million kWh (2001)
98.63 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA (1993)
lowest 10%: 0.7%
highest 10%: 47.7% (1993)
diamonds, timber, cotton, coffee, tobacco
Belgium 41.8%, Italy 10.7%, Spain 9.8%,
France 7.4%, Indonesia 6.6% (2003)
14 prefectures (prefectures, singular -
prefecture), 2 economic prefectures* (prefectures economiques,
singular - prefecture economique), and 1 commune**;
Bamingui-Bangoran, Bangui**, Basse-Kotto, Haute-Kotto, Haut-Mbomou,
Kemo, Lobaye, Mambere-Kadei, Mbomou, Nana-Grebizi*, Nana-Mambere,
Ombella-Mpoko, Ouaka, Ouham, Ouham-Pende, Sangha-Mbaere*, Vakaga
cotton, coffee, tobacco, manioc (tapioca),
yams, millet, corn, bananas; timber
50 (2003 est.)
35.55 births/1,000 population (2004 est.)
Central African Armed Forces (FACA):
Republican Guard, Ground Forces, Naval Forces, Air Force
revenues: NA
expenditures: NA, including capital expenditures of NA
Subsistence agriculture, together with
forestry, remains the backbone of the economy of the Central African
Republic (CAR), with more than 70% of the population living in
outlying areas. The agricultural sector generates half of GDP.
Timber has accounted for about 16% of export earnings and the
diamond industry for 54%. Important constraints to economic
development include the CAR''s landlocked position, a poor
transportation system, a largely unskilled work force, and a legacy
of misdirected macroeconomic policies. Factional fighting between
the government and its opponents remains a drag on economic
revitalization, with GDP likely to contract in 2004. Distribution of
income is extraordinarily unequal. Grants from France and the
international community can only partially meet humanitarian needs.
Alliance for Democracy and Progress or ADP
[Jacques MBOLIEDAS]; Central African Democratic Assembly or RDC
[Andre KOLINGBA]; Civic Forum or FC [Gen. Timothee MALENDOMA];
Democratic Forum for Modernity or FODEM [Charles MASSI]; Liberal
Democratic Party or PLD [Nestor KOMBO-NAGUEMON]; Movement for
Democracy and Development or MDD [David DACKO]; Movement for the
Liberation of the Central African People or MLPC [the party of
deposed president, Ange-Felix PATASSE]; Patriotic Front for Progress
or FPP [Abel GOUMBA]; People''s Union for the Republic or UPR [Pierre
Sammy MAKFOY]; National Unity Party or PUN [Jean-Paul NGOUPANDE];
Social Democratic Party or PSD [Enoch LAKOUE]','0fedc24ed4a13eb762f9706534ad41f806c0e56ee06d0dc7b70ac64db6b69e2b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0990ac20b4fb43bab05b135036478f28db45f9bdabb85edcb08ea1421800a217',2004,'TD','Chad','economy',676,'total: 7
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
total: 44
1,524 to 2,437 m: 14
914 to 1,523 m: 20
under 914 m: 10 (2004 est.)
inadequate supplies of potable water; improper waste disposal
in rural areas contributes to soil and water pollution;
desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
2.1% (2003)
94.04 million kWh (2001)
87.46 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
80% (2001 est.)
lowest 10%: NA
highest 10%: NA
agriculture more than 80% (subsistence farming, herding, and
fishing)
cotton, cattle, gum arabic
US 25%, Germany 17%, Portugal 15.9%, France 6.8%, Morocco 4.5%
(2003)
14 prefectures (prefectures, singular - prefecture); Batha,
Biltine, Borkou-Ennedi-Tibesti, Chari-Baguirmi, Guera, Kanem, Lac,
Logone Occidental, Logone Oriental, Mayo-Kebbi, Moyen-Chari,
Ouaddai, Salamat, Tandjile
note: instead of 14 prefectures, there may be a new administrative
structure of 28 departments (departments, singular - department),
and 1 city*; Assongha, Baguirmi, Bahr El Gazal, Bahr Koh, Batha
Oriental, Batha Occidental, Biltine, Borkou, Dababa, Ennedi, Guera,
Hadjer Lamis, Kabia, Kanem, Lac, Lac Iro, Logone Occidental, Logone
Oriental, Mandoul, Mayo-Boneye, Mayo-Dallah, Monts de Lam,
N''Djamena*, Ouaddai, Salamat, Sila, Tandjile Oriental, Tandjile
Occidental, Tibesti
cotton, sorghum, millet, peanuts, rice, potatoes, manioc
(tapioca); cattle, sheep, goats, camels
50 (2003 est.)
46.5 births/1,000 population (2004 est.)
Armed Forces: National Army (ANT), Air Force, and Republican
Guard
revenues: $591.2 million
expenditures: $680.9 million, including capital expenditures of $146
million (2003 est.)
Chad''s primarily agricultural economy will continue to be
boosted by major oilfield and pipeline projects that began in 2000.
Over 80% of Chad''s population relies on subsistence farming and
stock raising for its livelihood. Cotton, cattle, and gum arabic
provide the bulk of Chad''s export earnings, but Chad will begin to
export oil in 2004. Chad''s economy has long been handicapped by its
landlocked position, high energy costs, and a history of
instability. Chad relies on foreign assistance and foreign capital
for most public and private sector investment projects. A consortium
led by two US companies has been investing $3.7 billion to develop
oil reserves estimated at 1 billion barrels in southern Chad. Oil
production came on stream in late 2003.
oil 205 km (2004)
Federation Action for the Republic or FAR [Ngarlejy YORONGAR];
National Rally for Development and Progress or RNDP [Mamadou BISSO];
National Union for Democracy and Renewal or UNDR [Saleh KEBZABO];
Patriotic Salvation Movement or MPS [Mahamat Saleh AHMAT, chairman]
(originally in opposition but now the party in power and the party
of the president); Rally for Democracy and Progress or RPD [leader
NA]; Union for Renewal and Democracy or URD [Gen. Wadal Abdelkader
KAMOUGUE]; Viva Rally for Development and Progress or Viva RNDP
[Delwa Kassire COUMAKOYE]','1519e35f26908c4e05715215cb38037e0fbad33f3e5baafb04fde90d2a05aecd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a50c91a622cfd390c2db00f0130585daffa1be47955abad113e31ee8f803f34',2004,'CL','Chile','economy',677,'total: 71
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 21
914 to 1,523 m: 23
under 914 m: 15 (2004 est.)
total: 293
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 60
under 914 m: 217 (2004 est.)
widespread deforestation and mining threaten natural
resources; air pollution from industrial and vehicle emissions;
water pollution from raw sewage
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
4% (2003)
41.66 billion kWh (2001)
40.13 billion kWh (2001)
1.386 billion kWh (2001)
0 kWh (2001)
20.6% (2000 est.)
lowest 10%: 3.7%
highest 10%: 41% (2000)
agriculture 13.6%, industry 23.4%, services 63% (2003 est.)
copper, fish, fruits, paper and pulp, chemicals, wine
US 16.2%, Japan 10.5%, China 8.6%, South Korea 4.7%, Mexico
4.3%, Italy 4.2% (2003)
13 regions (regiones, singular - region); Aisen del General
Carlos Ibanez del Campo, Antofagasta, Araucania, Atacama, Bio-Bio,
Coquimbo, Libertador General Bernardo O''Higgins, Los Lagos,
Magallanes y de la Antartica Chilena, Maule, Region Metropolitana
(Santiago), Tarapaca, Valparaiso
note: the US does not recognize claims to Antarctica
grapes, apples, pears, onions, wheat, corn, oats, peaches,
garlic, asparagus, beans, beef, poultry, wool; fish; timber
363 (2003 est.)
15.77 births/1,000 population (2004 est.)
Army of the Nation, National Navy (including Naval Air, Coast
Guard, and Marine Corps), Air Force of the Nation, Chilean
Carabineros (National Police)
revenues: $15.44 billion
expenditures: $16.02 billion, including capital expenditures of $NA
(2003 est.)
Chile has a market-oriented economy characterized by a high
level of foreign trade. During the early 1990s, Chile''s reputation
as a role model for economic reform was strengthened when the
democratic government of Patricio AYLWIN - which took over from the
military in 1990 - deepened the economic reform initiated by the
military government. Growth in real GDP averaged 8% during 1991-97,
but fell to half that level in 1998 because of tight monetary
policies implemented to keep the current account deficit in check
and because of lower export earnings - the latter a product of the
global financial crisis. A severe drought exacerbated the recession
in 1999, reducing crop yields and causing hydroelectric shortfalls
and electricity rationing, and Chile experienced negative economic
growth for the first time in more than 15 years. Despite the effects
of the recession, Chile maintained its reputation for strong
financial institutions and sound policy that have given it the
strongest sovereign bond rating in South America. By the end of
1999, exports and economic activity had begun to recover, and growth
rebounded to 4.2% in 2000. Growth fell back to 3.1% in 2001 and 2.1%
in 2002, largely due to lackluster global growth and the devaluation
of the Argentine peso, but recovered to 3.2% in 2003. Unemployment,
although declining over the past year, remains stubbornly high,
putting pressure on President LAGOS to improve living standards. One
bright spot was the signing of a free trade agreement with the US,
which took effect on 1 January 2004. In 2004, GDP growth is set to
accelerate to more than 4% as copper prices rise, export earnings
grow, and foreign direct investment picks up.
gas 2,583 km; gas/lpg 42 km; liquid petroleum gas 539 km; oil
1,003 km; refined products 757 km (2004)
Alliance for Chile ("Alianza") or APC - including RN and UDI;
Christian Democratic Party or PDC [Adolfo ZALDIVAR]; Coalition of
Parties for Democracy ("Concertacion") or CPD - including PDC, PS,
PPD, PRSD; Communist Party or PC [Gladys MARIN]; Independent
Democratic Union or UDI [Pablo LONGUEIRA]; National Renewal or RN
[Sebastian PINERA]; Party for Democracy or PPD [Victor BARRUETO];
Radical Social Democratic Party or PRSD [Orlando CANTUARIAS];
Socialist Party or PS [Gonzalo MARTNER]','ccd69462cacf2d6156e622ca87ca7dd9808f1945efd9b57fd42d8b747a1c9268','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b671524669ba6756b0b3b25603fcfe00576a6679e712291979f1cdb5b67508e',2004,'CN','China','economy',678,'total: 332
over 3,047 m: 49
2,438 to 3,047 m: 97
1,524 to 2,437 m: 129
914 to 1,523 m: 22
under 914 m: 35 (2003 est.)
total: 175
over 3,047 m: 23
2,438 to 3,047 m: 10
1,524 to 2,437 m: 36
914 to 1,523 m: 40
under 914 m: 66 (2003 est.)
air pollution (greenhouse gases, sulfur dioxide particulates)
from reliance on coal produces acid rain; water shortages,
particularly in the north; water pollution from untreated wastes;
deforestation; estimated loss of one-fifth of agricultural land
since 1949 to soil erosion and economic development;
desertification; trade in endangered species
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
3.5-5.0% (FY03 est.)
1.42 trillion kWh (2001)
1.312 trillion kWh (2001)
1.8 billion kWh (2001)
10.3 billion kWh (2001)
10% (2001 est.)
lowest 10%: 2.4%
highest 10%: 30.4% (1998)
agriculture 50%, industry 22%, services 28% (2001 est.)
machinery and equipment, textiles and clothing, footwear, toys
and sporting goods, mineral fuels
US 21.1%, Hong Kong 17.4%, Japan 13.6%, South Korea 4.6%,
Germany 4% (2003)
23 provinces (sheng, singular and plural), 5 autonomous
regions (zizhiqu, singular and plural), and 4 municipalities (shi,
singular and plural)
provinces: Anhui, Fujian, Gansu, Guangdong, Guizhou, Hainan, Hebei,
Heilongjiang, Henan, Hubei, Hunan, Jiangsu, Jiangxi, Jilin,
Liaoning, Qinghai, Shaanxi, Shandong, Shanxi, Sichuan, Yunnan,
Zhejiang
autonomous regions: Guangxi, Nei Mongol, Ningxia, Xinjiang, Xizang
(Tibet)
municipalities: Beijing, Chongqing, Shanghai, Tianjin
note: China considers Taiwan its 23rd province; see separate entries
for the special administrative regions of Hong Kong and Macau
rice, wheat, potatoes, sorghum, peanuts, tea, millet, barley,
cotton, oilseed, pork, fish
507 (2003 est.)
12.98 births/1,000 population (2004 est.)
People''s Liberation Army (PLA): comprises ground forces, Navy
(including naval infantry and naval aviation), Air Force, and II
Artillery Corps (strategic missile force), People''s Armed Police
Force (internal security troops, nominally a state security body but
included by the Chinese as part of the "armed forces" and considered
to be an adjunct to the PLA), militia
revenues: $265.8 billion
expenditures: $300.2 billion, including capital expenditures of $NA
(2003)
In late 1978 the Chinese leadership began moving the economy
from a sluggish, inefficient, Soviet-style centrally planned economy
to a more market-oriented system. Whereas the system operates within
a political framework of strict Communist control, the economic
influence of non-state organizations and individual citizens has
been steadily increasing. The authorities switched to a system of
household and village responsibility in agriculture in place of the
old collectivization, increased the authority of local officials and
plant managers in industry, permitted a wide variety of small-scale
enterprises in services and light manufacturing, and opened the
economy to increased foreign trade and investment. The result has
been a quadrupling of GDP since 1978. Measured on a purchasing power
parity (PPP) basis, China in 2003 stood as the second-largest
economy in the world after the US, although in per capita terms the
country is still poor. Agriculture and industry have posted major
gains especially in coastal areas near Hong Kong, opposite Taiwan,
and in Shanghai, where foreign investment has helped spur output of
both domestic and export goods. The leadership, however, often has
experienced - as a result of its hybrid system - the worst results
of socialism (bureaucracy and lassitude) and of capitalism (growing
income disparities and rising unemployment). China thus has
periodically backtracked, retightening central controls at
intervals. The government has struggled to (a) sustain adequate jobs
growth for tens of millions of workers laid off from state-owned
enterprises, migrants, and new entrants to the work force; (b)
reduce corruption and other economic crimes; and (c) keep afloat the
large state-owned enterprises, many of which had been shielded from
competition by subsidies and had been losing the ability to pay full
wages and pensions. From 80 to 120 million surplus rural workers are
adrift between the villages and the cities, many subsisting through
part-time, low-paying jobs. Popular resistance, changes in central
policy, and loss of authority by rural cadres have weakened China''s
population control program, which is essential to maintaining
long-term growth in living standards. Another long-term threat to
growth is the deterioration in the environment, notably air
pollution, soil erosion, and the steady fall of the water table
especially in the north. China continues to lose arable land because
of erosion and economic development. Beijing says it will intensify
efforts to stimulate growth through spending on infrastructure -
such as water supply and power grids - and poverty relief and
through rural tax reform. Accession to the World Trade Organization
helps strengthen its ability to maintain strong growth rates but at
the same time puts additional pressure on the hybrid system of
strong political controls and growing market influences. China has
benefited from a huge expansion in computer internet use. Foreign
investment remains a strong element in China''s remarkable economic
growth. Growing shortages of electric power and raw materials will
hold back the expansion of industrial output in 2004.
gas 15,890 km; oil 14,478 km; refined products 3,280 km (2004)
Chinese Communist Party or CCP [HU Jintao, General Secretary
of the Central Committee]; eight registered small parties controlled
by CCP','5d4fe25a787b30f5159fb79cf9eee7e197ab517fe864f8ab64b90854f0f73f44','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ee5e81561f1e354d7fc28fc414ef19906825f7bdece871559ba1b99960c9603',2004,'CX','Christmas Island','economy',679,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
NA
Clipperton Island
NA
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
NA
phosphate
Australia, NZ
none (territory of Australia)
NA
1 (2003 est.)
NA births/1,000 population (2004 est.)
revenues: NA
expenditures: NA, including capital expenditures of NA
Phosphate mining had been the only significant
economic activity, but in December 1987 the Australian Government
closed the mine. In 1991, the mine was reopened. With the support of
the government, a $34 million casino opened in 1993. The casino
closed in 1998. The Australian Government in 2001 agreed to support
the creation of a commercial space-launching site on the island,
projected to begin operations in mid-2004
Clipperton Island
Although 115 species of fish have been identified
in the territorial waters of Clipperton Island, the only economic
activity is tuna fishing.
none','0ab741a0f151dff5c91a91b00385978e13a313a431235520ad958b602c4e2fa0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97dbc5c9f586514ac81571ad93ab34e33da4ddaf5f28cd2179d450e89e140a78',2004,'CC','Cocos (Keeling) Islands','economy',680,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
fresh water resources are limited to
rainwater accumulations in natural underground reservoirs
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
the Cocos Islands Cooperative Society Ltd.
employs construction workers, stevedores, and lighterage workers;
tourism employs others
copra
none (territory of Australia)
vegetables, bananas, pawpaws, coconuts
1 (2003 est.)
NA births/1,000 population (2004 est.)
revenues: NA
expenditures: NA, including capital expenditures of NA
Grown throughout the islands, coconuts are
the sole cash crop. Small local gardens and fishing contribute to
the food supply, but additional food and most other necessities must
be imported from Australia. There is a small tourist industry.
none','94cf5cf73dae1ddc890f2921bf1f273aca63152705e6baa1918ee1c265594077','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9308af2c7736c44b8495080ec1955186e8ac3558d35b8fc21455e683dad3556e',2004,'CO','Colombia','economy',681,'total: 101
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 39
914 to 1,523 m: 39
under 914 m: 12 (2004 est.)
total: 879
2,438 to 3,047 m: 1
1,524 to 2,437 m: 34
914 to 1,523 m: 272
under 914 m: 572 (2004 est.)
Congo, Democratic Republic of the
total: 206
1,524 to 2,437 m: 17
914 to 1,523 m: 92
under 914 m: 97 (2004 est.)
Congo, Republic of the
total: 28
1,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 11 (2004 est.)
deforestation; soil and water quality damage from overuse
of pesticides; air pollution, especially in Bogota, from vehicle
emissions
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3.4% (FY01)
42.99 billion kWh (2001)
39.81 billion kWh (2001)
40 million kWh (2001)
210 million kWh (2001)
55% (2001)
lowest 10%: 1%
highest 10%: 44% (1999)
agriculture 30%, industry 24%, services 46% (1990)
petroleum, coffee, coal, apparel, bananas, cut flowers
US 47.1%, Ecuador 6%, Venezuela 5.3% (2003)
32 departments (departamentos, singular - departamento) and
1 capital district* (distrito capital); Amazonas, Antioquia, Arauca,
Atlantico, Distrito Capital de Bogota*, Bolivar, Boyaca, Caldas,
Caqueta, Casanare, Cauca, Cesar, Choco, Cordoba, Cundinamarca,
Guainia, Guaviare, Huila, La Guajira, Magdalena, Meta, Narino, Norte
de Santander, Putumayo, Quindio, Risaralda, San Andres y
Providencia, Santander, Sucre, Tolima, Valle del Cauca, Vaupes,
Vichada
coffee, cut flowers, bananas, rice, tobacco, corn,
sugarcane, cocoa beans, oilseed, vegetables; forest products; shrimp
980 (2003 est.)
21.19 births/1,000 population (2004 est.)
Army (Ejercito Nacional), Navy (Armada Nacional, including
Naval Aviation, Marines, and Coast Guard), Air Force (Fuerza Aerea
Colombiana)
revenues: $24 billion
expenditures: $25.6 billion, including capital expenditures of $NA
(2004 est.)
Colombia''s economy suffers from weak domestic and foreign
demand, austere government budgets, and serious internal armed
conflict, but seems poised for recovery. Other economic problems
facing President URIBE range from reforming the pension system to
reducing high unemployment. Two of Colombia''s leading exports, oil
and coffee, face an uncertain future; new exploration is needed to
offset declining oil production, while coffee harvests and prices
are depressed. On the positive side, several international financial
institutions have praised the economic reforms introduced by URIBE,
which includes measures designed to reduce the public-sector deficit
below 2.5% of GDP in 2004. The government''s economic policy and
democratic security strategy have engendered a growing sense of
confidence in the economy, particularly within the business sector,
and GDP growth in 2003 was among the highest in Latin America.
gas 4,360 km; oil 6,134 km; refined products 3,140 km (2004)
Congo, Democratic Republic of the
gas 54 km; oil 71 km (2004)
Congo, Republic of the
gas 53 km; oil 646 km (2004)
Conservative Party or PSC [Carlos HOLGUIN Sardi]; Liberal
Party or PL [Camilo SANCHEZ]; Colombian Communist Party or PCC
[Jaime CAICEDO]; Democratic Pole or PDI [Antonio NAVARRO Wolff]
note: Colombia has about 60 formally recognized political parties,
most of which do not have a presence in either house of Congress','a55f0299d90b7ae4eda376d4c993ed4cf339ff424b61552cd193d42cba26acba','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9cb6fc15496c2e58c89a16c2991c2ff82d8946f61e001d0057c567a15d70d3',2004,'KM','Comoros','economy',682,'total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2004 est.)
Congo, Democratic Republic of the
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 2 (2004 est.)
Congo, Republic of the
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3 (2004 est.)
soil degradation and erosion results from crop cultivation
on slopes without proper terracing; deforestation
Congo, Democratic Republic of the
poaching threatens wildlife
populations; water pollution; deforestation; refugees responsible
for significant deforestation, soil erosion, and wildlife poaching;
mining of minerals (coltan - a mineral used in creating capacitors,
diamonds, and gold) causing environmental damage
Congo, Republic of the
air pollution from vehicle emissions; water
pollution from the dumping of raw sewage; tap water is not potable;
deforestation
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Congo, Democratic Republic of the
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Congo, Republic of the
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3% (2003)
Congo, Democratic Republic of the
1.4% (2003)
Congo, Republic of the
2.8% (2003)
21.27 million kWh (2001)
Congo, Democratic Republic of the
5.243 billion kWh (2001)
Congo, Republic of the
358.1 million kWh (2001)
19.78 million kWh (2001)
Congo, Democratic Republic of the
3.839 billion kWh (2001)
Congo, Republic of the
633 million kWh (2001)
0 kWh (2001)
Congo, Democratic Republic of the
60 million kWh (2001)
Congo, Republic of the
300 million kWh (2001)
0 kWh (2001)
Congo, Democratic Republic of the
1.097 billion kWh (2001)
Congo, Republic of the
0 kWh (2001)
60% (2002 est.)
Congo, Democratic Republic of the
NA
Congo, Republic of the
NA
lowest 10%: NA
highest 10%: NA
Congo, Democratic Republic of the
lowest 10%: NA
highest 10%: NA
Congo, Republic of the
lowest 10%: NA
highest 10%: NA
agriculture 80%
Congo, Democratic Republic of the
NA
vanilla, ylang-ylang, cloves, perfume oil, copra
Congo, Democratic Republic of the
diamonds, copper, crude oil,
coffee, cobalt
Congo, Republic of the
petroleum, lumber, plywood, sugar, cocoa,
coffee, diamonds
France 46.9%, Germany 18.8%, US 12.5% (2003)
Congo, Democratic Republic of the
Belgium 54.9%, US 15.4%, Zimbabwe
11.1%, Finland 4.8% (2003)
Congo, Republic of the
China 28.6%, Taiwan 19.3%, US 16%, South
Korea 12.9% (2003)
3 islands; Grande Comore (Njazidja), Anjouan (Nzwani), and
Moheli (Mwali); note - there are also four municipalities named
Domoni, Fomboni, Moroni, and Moutsamoudou
Congo, Democratic Republic of the
10 provinces (provinces, singular
- province) and one city* (ville); Bandundu, Bas-Congo, Equateur,
Kasai-Occidental, Kasai-Oriental, Katanga, Kinshasa*, Maniema,
Nord-Kivu, Orientale, Sud-Kivu
Congo, Republic of the
10 regions (regions, singular - region) and 1
commune*; Bouenza, Brazzaville*, Cuvette, Cuvette-Ouest, Kouilou,
Lekoumou, Likouala, Niari, Plateaux, Pool, Sangha
vanilla, cloves, perfume essences, copra, coconuts, bananas,
cassava (tapioca)
Congo, Democratic Republic of the
coffee, sugar, palm oil, rubber,
tea, quinine, cassava (tapioca), palm oil, bananas, root crops,
corn, fruits; wood products
Congo, Republic of the
cassava (tapioca), sugar, rice, corn,
peanuts, vegetables, coffee, cocoa; forest products
4 (2003 est.)
Congo, Democratic Republic of the
230 (2003 est.)
Congo, Republic of the
32 (2003 est.)
38 births/1,000 population (2004 est.)
Congo, Democratic Republic of the
44.73 births/1,000 population
(2004 est.)
Congo, Republic of the
28.66 births/1,000 population (2004 est.)
Comoran Security Force
Congo, Democratic Republic of the
Army, Navy, Air Force
Congo, Republic of the
Congolese Armed Forces (FAC): Army, Air
Force, Navy
revenues: $27.6 million
expenditures: NA, including capital expenditures of NA (2001 est.)
Congo, Democratic Republic of the
revenues: $269 million
expenditures: $244 million, including capital expenditures of $24
million (1996 est.)
Congo, Republic of the
revenues: $1.025 billion
expenditures: $946.8 million, including capital expenditures of NA
(2003 est.)
One of the world''s poorest countries, Comoros is made up of
three islands that have inadequate transportation links, a young and
rapidly increasing population, and few natural resources. The low
educational level of the labor force contributes to a subsistence
level of economic activity, high unemployment, and a heavy
dependence on foreign grants and technical assistance. Agriculture,
including fishing, hunting, and forestry, contributes 40% to GDP,
employs 80% of the labor force, and provides most of the exports.
The country is not self-sufficient in food production; rice, the
main staple, accounts for the bulk of imports. The government -
which is hampered by internal political disputes - is struggling to
upgrade education and technical training, to privatize commercial
and industrial enterprises, to improve health services, to diversify
exports, to promote tourism, and to reduce the high population
growth rate. Increased foreign support is essential if the goal of
4% annual GDP growth is to be met. Remittances from 150,000 Comorans
abroad help supplement GDP.
Congo, Democratic Republic of the
The economy of the Democratic
Republic of the Congo - a nation endowed with vast potential wealth
- has declined drastically since the mid-1980s. The war, which began
in August 1998, has dramatically reduced national output and
government revenue, has increased external debt, and has resulted in
the deaths from war, famine, and disease of perhaps 3.5 million
people. Foreign businesses have curtailed operations due to
uncertainty about the outcome of the conflict, lack of
infrastructure, and the difficult operating environment. The war has
intensified the impact of such basic problems as an uncertain legal
framework, corruption, inflation, and lack of openness in government
economic policy and financial operations. Conditions improved in
late 2002 with the withdrawal of a large portion of the invading
foreign troops. Several IMF and World Bank missions have met with
the government to help it develop a coherent economic plan, and
President KABILA has begun implementing reforms. Much economic
activity lies outside the GDP data. Economic stability, aided by
international donors, improved in 2003. New mining contracts have
been approved, which - combined with high mineral and metal prices -
could improve Kinshasa''s fiscal position and GDP growth.
Congo, Republic of the
The economy is a mixture of village
agriculture and handicrafts, an industrial sector based largely on
oil, support services, and a government characterized by budget
problems and overstaffing. Oil has supplanted forestry as the
mainstay of the economy, providing a major share of government
revenues and exports. In the early 1980s, rapidly rising oil
revenues enabled the government to finance large-scale development
projects with GDP growth averaging 5% annually, one of the highest
rates in Africa. The government has mortgaged a substantial portion
of its oil earnings, contributing to a shortage of revenues. The 12
January 1994 devaluation of Franc Zone currencies by 50% resulted in
inflation of 61% in 1994, but inflation has subsided since. Economic
reform efforts continued with the support of international
organizations, notably the World Bank and the IMF. The reform
program came to a halt in June 1997 when civil war erupted. Denis
SASSOU-NGUESSO, who returned to power when the war ended in October
1997, publicly expressed interest in moving forward on economic
reforms and privatization and in renewing cooperation with
international financial institutions. However, economic progress was
badly hurt by slumping oil prices and the resumption of armed
conflict in December 1998, which worsened the republic''s budget
deficit. The current administration presides over an uneasy internal
peace and faces difficult economic problems of stimulating recovery
and reducing poverty.
Forces pour l''Action Republicaine or FAR [Col. Abdourazak
ABDULHAMID]; Forum pour la Redressement National or FRN (alliance of
12 parties); Front Democratique or FD [Moustoifa Said CHEIKH]; Front
National pour la Justice or FNJ (Islamic party in opposition) [Ahmed
RACHID]; Movement des Citoyens pour la Republique or MCR [Mahamoud
MRADABI]; Mouvement Populaire Anjouanais or MPA (Anjouan separatist
movement) [leader NA]; Mouvement pour la Democratie et le Progress
or MDP-NGDC [Abbas DJOUSSOUF]; Movement pour le Socialisme et la
Democratie or MSD (splinter group of FD) [Abdou SOEFOU]; Parti
Comorien pour la Democratie et le Progress or PCDP [Ali MROUDJAE];
Rassemblement National pour le Development or RND (party of the
government) [Omar TAMOU, Abdoulhamid AFFRAITANE]
Congo, Democratic Republic of the
Democratic Social Christian Party
or PDSC [Andre BO-BOLIKO]; Forces for Renovation for Union and
Solidarity or FONUS [Joseph OLENGHANKOY]; National Congolese
Lumumbist Movement or MNC [Francois LUMUMBA]; Popular Movement of
the Revolution or MPR (three factions: MPR-Fait Prive [Catherine
NZUZI wa Mbombo]; MPR/Vunduawe [Felix VUNDUAWE]; MPR/Mananga
[MANANGA Dintoka Mpholo]); Unified Lumumbast Party or PALU [Antoine
GIZENGA]; Union for Democracy and Social Progress or UDPS [Etienne
TSHISEKEDI wa Mulumba]; Union of Federalists and Independent
Republicans or UFERI (two factions: UFERI [Lokambo OMOKOKO];
UFERI/OR [Adolph Kishwe MAYA])
Congo, Republic of the
the most important of the many parties are
the Democratic and Patriotic Forces or FDP (an alliance of
Convention for Alternative Democracy, Congolese Labor Party or PCT,
Liberal Republican Party, National Union for Democracy and Progress,
Patriotic Union for the National Reconstruction, and Union for the
National Renewal) [Denis SASSOU-NGUESSO, president]; Congolese
Movement for Democracy and Integral Development or MCDDI [Michel
MAMPOUYA]; Pan-African Union for Social Development or UPADS [Martin
MBERI]; Rally for Democracy and Social Progress or RDPS [Jean-Pierre
Thystere TCHICAYA, president]; Rally for Democracy and the Republic
or RDR [Raymond Damasge NGOLLO]; Union for Democracy and Republic or
UDR [leader NA]; Union of Democratic Forces or UFD [Sebastian EBAO]','eee0cbf8e13384715ed7a0276e6bdd0879cd14ecdddc40e19ef0d1f8d522033d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ebe5b21d17d931888806379ed7da360f9230d79c36761afcd6cc381d93d1bb3',2004,'CK','Cook Islands','economy',683,'total: 2
1,524 to 2,437 m: 2 (2004 est.)
total: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
NA
Coral Sea Islands
no permanent fresh water resources
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the Sea
signed, but not ratified: none of the selected agreements
27.43 million kWh (2001)
25.51 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 29%, industry 15%, services 56%
note: shortage of skilled labor (1995)
copra, papayas, fresh and canned citrus fruit, coffee;
fish; pearls and pearl shells; clothing
Australia 34%, Japan 27%, New Zealand 25%, US 8% (2000)
none
copra, citrus, pineapples, tomatoes, beans, pawpaws,
bananas, yams, taro, coffee; pigs, poultry
9 (2003 est.)
NA births/1,000 population (2004 est.)
revenues: $28 million
expenditures: $27 million, including capital expenditures of $3.3
million (FY00/01 est.)
Like many other South Pacific island nations, the Cook
Islands'' economic development is hindered by the isolation of the
country from foreign markets, the limited size of domestic markets,
lack of natural resources, periodic devastation from natural
disasters, and inadequate infrastructure. Agriculture provides the
economic base with major exports made up of copra and citrus fruit.
Manufacturing activities are limited to fruit processing, clothing,
and handicrafts. Trade deficits are offset by remittances from
emigrants and by foreign aid, overwhelmingly from New Zealand. In
the 1980s and 1990s, the country lived beyond its means, maintaining
a bloated public service and accumulating a large foreign debt.
Subsequent reforms, including the sale of state assets, the
strengthening of economic management, the encouragement of tourism,
and a debt restructuring agreement, have rekindled investment and
growth.
Coral Sea Islands
no economic activity
Cook Islands People''s Party or CIP [Geoffrey HENRY];
Democratic Alliance Party or DAP [Terepai MAOATE]; New Alliance
Party or NAP [Norman GEORGE]; Cook Islands National Party or CIN
[Teariki HEATHER]; Demo Party Tumu [Robert WOONTON]','1da4870314265958d568f40f0d2d95b3f0f3392360aa47bbb9f5ed01f1df5888','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a976462d1784c2936804d756771a50c51629abc997a27947d48038fe28530ae3',2004,'CR','Costa Rica','economy',684,'total: 30
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 8 (2004 est.)
Cote d''Ivoire
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2004 est.)
total: 119
914 to 1,523 m: 24
under 914 m: 95 (2004 est.)
Cote d''Ivoire
total: 30
1,524 to 2,437 m: 7
914 to 1,523 m: 15
under 914 m: 8 (2004 est.)
deforestation and land use change, largely a result of
the clearing of land for cattle ranching and agriculture; soil
erosion; coastal marine pollution; fisheries protection; solid waste
management; air pollution
Cote d''Ivoire
deforestation (most of the country''s forests - once
the largest in West Africa - have been heavily logged); water
pollution from sewage and industrial and agricultural effluents
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Cote d''Ivoire
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
0.4% (2003)
Cote d''Ivoire
1.2% (2003)
6.839 billion kWh (2001)
Cote d''Ivoire
4.605 billion kWh (2001)
6.109 billion kWh (2001)
Cote d''Ivoire
2.983 billion kWh (2001)
128 million kWh (2001)
Cote d''Ivoire
0 kWh (2001)
379 million kWh (2001)
Cote d''Ivoire
1.3 billion kWh (2001)
20.6% (2002 est.)
Cote d''Ivoire
37% (1995)
lowest 10%: 1.1%
highest 10%: 36.8% (2002)
Cote d''Ivoire
lowest 10%: 3.1%
highest 10%: 28.8% (1995)
agriculture 20%, industry 22%, services 58% (1999 est.)
coffee, bananas, sugar; pineapples; textiles, electronic
components, medical equipment
Cote d''Ivoire
cocoa, coffee, timber, petroleum, cotton, bananas,
pineapples, palm oil, fish
US 14.2%, Guatemala 3%, Nicaragua 2.7% (2003)
Cote d''Ivoire
France 19.1%, Netherlands 17.7%, US 7.1%, Spain 5.6%
(2003)
7 provinces (provincias, singular - provincia); Alajuela,
Cartago, Guanacaste, Heredia, Limon, Puntarenas, San Jose
Cote d''Ivoire
19 regions; Agneby, Bafing, Bas-Sassandra, Denguele,
Dix-Huit Montagnes, Fromager, Haut-Sassandra, Lacs, Lagunes,
Marahoue, Moyen-Cavally, Moyen-Comoe, N''zi-Comoe, Savanes,
Sud-Bandama, Sud-Comoe, Vallee du Bandama, Worodougou, Zanzan
coffee, pineapples, bananas, sugar, corn, rice, beans,
potatoes; beef; timber
Cote d''Ivoire
coffee, cocoa beans, bananas, palm kernels, corn,
rice, manioc (tapioca), sweet potatoes, sugar, cotton, rubber; timber
149 (2003 est.)
Cote d''Ivoire
37 (2003 est.)
18.99 births/1,000 population (2004 est.)
Cote d''Ivoire
39.64 births/1,000 population (2004 est.)
no regular military forces; Ministry of Public Security
Cote d''Ivoire
Army, Navy, Air Force, paramilitary Gendarmerie,
Republican Guard (includes Presidential Guard)
revenues: $2.313 billion
expenditures: $2.851 billion, including capital expenditures of NA
(2003 est.)
Cote d''Ivoire
revenues: $2.339 billion
expenditures: $2.749 billion, including capital expenditures of $420
million (2003 est.)
Costa Rica''s basically stable economy depends on tourism,
agriculture, and electronics exports. Poverty has been substantially
reduced over the past 15 years, and a strong social safety net has
been put into place. Foreign investors remain attracted by the
country''s political stability and high education levels, and tourism
continues to bring in foreign exchange. Low prices for coffee and
bananas have hurt the agricultural sector. The government continues
to grapple with its large deficit and massive internal debt. The
reduction of inflation remains a difficult problem because of rises
in the price of imports, labor market rigidities, and fiscal
deficits. Costa Rica recently concluded negotiations to participate
in the US - Central American Free Trade Agreement, which, if
ratified by the Costa Rican Legislature, would result in economic
reforms and an improved investment climate.
Cote d''Ivoire
Cote d''Ivoire is among the world''s largest producers
and exporters of coffee, cocoa beans, and palm oil. Consequently,
the economy is highly sensitive to fluctuations in international
prices for these products and to weather conditions. Despite
government attempts to diversify the economy, it is still heavily
dependent on agriculture and related activities, which engage
roughly 68% of the population. After several years of lagging
performance, the Ivorian economy began a comeback in 1994, due to
the 50% devaluation of the CFA franc and improved prices for cocoa
and coffee, growth in nontraditional primary exports such as
pineapples and rubber, limited trade and banking liberalization,
offshore oil and gas discoveries, and generous external financing
and debt rescheduling by multilateral lenders and France. Moreover,
government adherence to donor-mandated reforms led to a jump in
growth to 5% annually during 1996-99. Growth was negative in 2000-03
because of the difficulty of meeting the conditions of international
donors, continued low prices of key exports, and severe civil war.
Political uncertainty will continue to cloud the economic outlook in
2004, but rising world prices for cocoa will help both the current
account and the government balances.
refined products 242 km (2004)
Cote d''Ivoire
condensate 107 km; gas 223 km; oil 104 km (2004)
Authentic Member from Heredia [Jose SALAS]; Citizen
Action Party or PAC [Otton SOLIS]; Costa Rican Renovation Party or
PRC [Justo OROZCO]; Democratic Force Party or PFD [Juan Carlos
CHAVES Mora]; Democratic National Alliance [Emilia RODRIGUEZ];
General Union Party or PUGEN [Carlos Alberto FERNANDEZ Vega];
Homeland First [Juan Jose VARGAS]; Independent Worker Party or PIO
[Jose Alberto CUBERO Carmona]; Libertarian Movement Party or PML
[Otto GUEVARA Guth]; National Christian Alliance Party or ANC
[Victor GONZALEZ]; National Integration Party or PIN [Walter MUNOZ
Cespedes]; National Liberation Party or PLN [Francisco Antonio
PACHECO]; National Patriotic Party or PPN [Daniel Enrique REYNOLDS
Vargas]; National Rescue Party or PRN [Carlos VARGAS Solano];
Patriotic Union [Humberto ARCE]; Popular Vanguard [Trino BARRANTES
Araya]; Social Christian Unity Party or PUSC [Lorena VASQUEZ Badilla]
Cote d''Ivoire
Democratic Party of Cote d''Ivoire-African Democratic
Rally or PDCI-RDA [Aime Henri Konan BEDIE]; Ivorian Popular Front or
FPI [Laurent GBAGBO]; Ivorian Worker''s Party or PIT [Francis WODIE];
Rally of the Republicans or RDR [Alassane OUATTARA]; Union for
Democracy and Peace or UDPCI [leader NA]; over 20 smaller parties','30692847807ee237e027c6d162337928ec73c9a8ba9f71ad3026ec9f80b499df','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2af85dab8fc5caf8e0bbbe93be874367d5c102b9fe6159e1ea0cda572d78fc',2004,'HR','Croatia','economy',685,'total: 23
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 9 (2004 est.)
total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 37 (2004 est.)
air pollution (from metallurgical plants) and resulting acid
rain is damaging the forests; coastal pollution from industrial and
domestic waste; landmine removal and reconstruction of
infrastructure consequent to 1992-95 civil strife
party to: Air Pollution, Air Pollution-Sulfur 94,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
2.39% (2002 est.)
12.12 billion kWh (2001)
14.27 billion kWh (2001)
3.386 billion kWh (2001)
386 million kWh (2001)
NA
lowest 10%: 3.7%
highest 10%: 23.3% (1998)
agriculture 13.2%, industry 25.4%, services 46.4% (2002)
transport equipment, textiles, chemicals, foodstuffs, fuels
Italy 26.1%, Bosnia and Herzegovina 14.6%, Germany 12%,
Slovenia 8.3%, Austria 7.9% (2003)
20 counties (zupanije, zupanija - singular) and 1 city*
(grad - singular); Bjelovarsko-Bilogorska Zupanija, Brodsko-Posavska
Zupanija, Dubrovacko-Neretvanska Zupanija, Istarska Zupanija,
Karlovacka Zupanija, Koprivnicko-Krizevacka Zupanija,
Krapinsko-Zagorska Zupanija, Licko-Senjska Zupanija, Medimurska
Zupanija, Osjecko-Baranjska Zupanija, Pozesko-Slavonska Zupanija,
Primorsko-Goranska Zupanija, Sibensko-Kninska Zupanija,
Sisacko-Moslavacka Zupanija, Splitsko-Dalmatinska Zupanija,
Varazdinska Zupanija, Viroviticko-Podravska Zupanija,
Vukovarsko-Srijemska Zupanija, Zadarska Zupanija, Zagreb*,
Zagrebacka Zupanija
wheat, corn, sugar beets, sunflower seed, barley, alfalfa,
clover, olives, citrus, grapes, soybeans, potatoes; livestock, dairy
products
68 (2003 est.)
9.51 births/1,000 population (2004 est.)
Ground Forces (Hrvatska Vojska, HKoV), Naval Forces
(Hrvatska Ratna Mornarica, HRM), Air and Air Defense Forces
(Hrvatsko Ratno Zrakoplovstvo i Protuzrakoplovna Obrana, HRZiPZO)
revenues: $12.76 billion
expenditures: $14.31 billion, including capital expenditures of NA
(2003 est.)
Before the dissolution of Yugoslavia, the Republic of
Croatia, after Slovenia, was the most prosperous and industrialized
area, with a per capita output perhaps one-third above the Yugoslav
average. The economy emerged from a mild recession in 2000 with
tourism, banking, and public investments leading the way.
Unemployment remains high, at over 13 percent, with structural
factors slowing its decline. While macroeconomic stabilization has
largely been achieved, structural reforms lag because of deep
resistance on the part of the public and lack of strong support from
politicians. Growth, while impressively over 4% for the last several
years, has been achieved through high fiscal and current account
deficits. The government is gradually reducing a heavy back log of
civil cases, many involving land tenure. The EU accession process
should accelerate fiscal and structural reform.
gas 1,340 km; oil 583 km (2004)
Croatian Bloc or HB [Ivic PASALIC]; Croatian Christian
Democratic Union or HKDU [Anto KOVACEVIC]; Croatian Democratic Union
or HDZ [Ivo SANADER]; Croatian Party of Rights or HSP [Anto DJAPIC];
Croatian Peasant Party or HSS [Zlatko TOMCIC]; Croatian Pensioner
Party or HSU [Vladimir JORDAN]; Croatian People''s Party or HNS
[Vesna PUSIC]; Croatian Social Liberal Party or HSLS [Ivan CEHOK];
Croatian True Revival Party or HIP [Miroslav TUDJMAN]; Democratic
Centre or DC [Vesna SKARE-OZBOLT]; Independent Democratic Serb Party
or SDSS [Vojislav STRANIMIROVIC]; Istrian Democratic Assembly or IDS
[Ivan JAKOVCIC]; Liberal Party or LS [Zlatko BENASIC]; Party of
Liberal Democrats or Libra [Jozo RADOS]; Social Democratic Party of
Croatia or SDP [Ivica RACAN]','48c670be24c0dbd36ef332f8d208b9fb74069eee846675c8baa0df1c98d64adb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9866f151cf94001fd9348ccd03beaccc650fcedb118af524bc1fa8be857f26d6',2004,'CU','Cuba','economy',686,'total: 79
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m: 20
914 to 1,523 m: 6
under 914 m: 37 (2004 est.)
total: 91
914 to 1,523 m: 29
under 914 m: 62 (2004 est.)
air and water pollution; biodiversity loss; deforestation
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
1.8% (2003)
14.38 billion kWh (2001)
13.38 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 24%, industry 25%, services 51% (1999)
sugar, nickel, tobacco, fish, medical products, citrus, coffee
Netherlands 21.8%, Canada 16.2%, Russia 10.7%, Spain 8.7%,
China 7.3% (2003)
14 provinces (provincias, singular - provincia) and 1 special
municipality* (municipio especial); Camaguey, Ciego de Avila,
Cienfuegos, Ciudad de La Habana, Granma, Guantanamo, Holguin, Isla
de la Juventud*, La Habana, Las Tunas, Matanzas, Pinar del Rio,
Sancti Spiritus, Santiago de Cuba, Villa Clara
sugar, tobacco, citrus, coffee, rice, potatoes, beans; livestock
170 (2003 est.)
12.18 births/1,000 population (2004 est.)
Revolutionary Armed Forces (FAR): Revolutionary Army (ER),
Revolutionary Navy (MGR), Air and Air Defense Force (DAAFAR),
Territorial Militia Troops (MTT), Youth Labor Army (EJT)
revenues: $17.21 billion
expenditures: $18.28 billion, including capital expenditures of NA
(2003 est.)
The government continues to balance the need for economic
loosening against a desire for firm political control. It has
undertaken limited reforms to increase enterprise efficiency and
alleviate serious shortages of food, consumer goods, and services. A
major feature of the economy is the dichotomy between relatively
efficient export enclaves and inefficient domestic sectors. The
average Cuban''s standard of living remains at a lower level than
before the depression of the 1990s, which was caused by the loss of
Soviet aid and domestic inefficiencies. The government reluctantly
allows a large dollar market sector, fueled by tourism and
remittances from Cubans abroad.
gas 49 km; oil 230 km (2004)
Czech Republic
gas 7,020 km; oil 547 km; refined products 94 km
(2004)
only party - Cuban Communist Party or PCC [Fidel CASTRO Ruz,
first secretary]','a5da40a8c2b506221ded72140ba4ac6d49edf72cdf41e50c47604c2188e594a3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e29a4d38398b588ec8bba3844cb3bd724ed77c7d0edec5825ac302cb1cc35343',2004,'CY','Cyprus','economy',687,'total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
Czech Republic
total: 44
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 14
914 to 1,523 m: 2
under 914 m: 17 (2004 est.)
total: 4
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
Czech Republic
total: 76
1,524 to 2,437 m: 1
914 to 1,523 m: 27
under 914 m: 48 (2004 est.)
water resource problems (no natural reservoir catchments,
seasonal disparity in rainfall, sea water intrusion to island''s
largest aquifer, increased salination in the north); water pollution
from sewage and industrial wastes; coastal degradation; loss of
wildlife habitats from urbanization
Czech Republic
air and water pollution in areas of northwest Bohemia
and in northern Moravia around Ostrava present health risks; acid
rain damaging forests; efforts to bring industry up to EU code
should improve domestic pollution
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
Czech Republic
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
3.8% (FY02)
Czech Republic
2.1% (FY01)
3.401 billion kWh; north Cyprus: NA kWh (2001)
Czech Republic
70.04 billion kWh (2001)
Republic of Cyprus: 3.163 billion kWh; north Cyprus: NA kWh
(2001)
Czech Republic
55.6 billion kWh (2001)
0 kWh (2001)
Czech Republic
9.38 billion kWh (2001)
0 kWh (2001)
Czech Republic
18.92 billion kWh (2001)
NA
Czech Republic
NA
lowest 10%: NA
highest 10%: NA
Czech Republic
lowest 10%: 4.3%
highest 10%: 22.4% (1996)
Republic of Cyprus: services 75.6%, industry 19.4%,
agriculture 4.9% (2003); north Cyprus: services 68.9%, industry
20.5%, agriculture 10.6% (2003)
Czech Republic
agriculture 5%, industry 35%, services 60% (2001 est.)
Republic of Cyprus: citrus, potatoes, pharmaceuticals,
cement, clothing and cigarettes; north Cyprus: citrus, potatoes,
textiles
Czech Republic
machinery and transport equipment 44%, intermediate
manufactures 25%, chemicals 7%, raw materials and fuel 7% (2000)
UK 32.1%, Greece 9.2%, Lebanon 3.5% (2003)
Czech Republic
Germany 37.1%, Slovakia 8%, Austria 6.3%, UK 5.4%,
Poland 4.8%, France 4.7%, Italy 4.5%, Netherlands 4.1% (2003)
6 districts; Famagusta, Kyrenia, Larnaca, Limassol, Nicosia,
Paphos; note - Turkish Cypriot area''s administrative divisions
include Kyrenia, all but a small part of Famagusta, and small parts
of Lefkosia (Nicosia) and Larnaca
Czech Republic
13 regions (kraje, singular - kraj) and 1 capital
city* (hlavni mesto); Jihocesky Kraj, Jihomoravsky Kraj, Karlovarsky
Kraj, Kralovehradecky Kraj, Liberecky Kraj, Moravskoslezsky Kraj,
Olomoucky Kraj, Pardubicky Kraj, Plzensky Kraj, Praha*, Stredocesky
Kraj, Ustecky Kraj, Vysocina, Zlinsky Kraj
potatoes, citrus, vegetables, barley, grapes, olives,
vegetables, poultry, pork, lamb, kids, dairy
Czech Republic
wheat, potatoes, sugar beets, hops, fruit; pigs,
poultry
17 (2003 est.)
Czech Republic
120 (2003 est.)
12.66 births/1,000 population (2004 est.)
Czech Republic
9.1 births/1,000 population (2004 est.)
Republic of Cyprus: Greek Cypriot National Guard (GCNG;
including air and naval elements), Greek Cypriot Police
north Cyprus: Turkish Cypriot Security Force (GKK)
Czech Republic
Czech Army: Ground Forces, Air Forces, Special Forces
revenues: Republic of Cyprus - $3.971 billion, north Cyprus -
$231.3 million (2002 est.)
expenditures: $4.746 billion, Republic of Cyprus - $539 million,
including capital expenditures of $539 million, north Cyprus -
$432.8 million, including capital expenditures of NA (2003)
Czech Republic
revenues: $33.25 billion
expenditures: $38.88 billion, including capital expenditures of NA
(2003 est.)
The Greek Cypriot economy is prosperous but highly
susceptible to external shocks. Erratic growth rates over the past
decade reflect the economy''s vulnerability to swings in tourist
arrivals, caused by political instability in the region and
fluctuations in economic conditions in Western Europe. Economic
policy is focused on meeting the criteria for admission to the EU.
EU-driven tax reforms in 2003 have introduced fiscal imbalances,
which, coupled with a sluggish tourism sector, have resulted in
growing fiscal deficits. As in the Turkish sector, water shortages
are a perennial problem; a few desalination plants are now on-line.
After 10 years of drought, the country received substantial rainfall
from 2001-03, alleviating immediate concerns. The Turkish Cypriot
economy has roughly one-third of the per capita GDP of the south.
Because it is recognized only by Turkey, it has had much difficulty
arranging foreign financing and investment. It remains heavily
dependent on agriculture and government service, which together
employ about half of the work force. To compensate for the economy''s
weakness, Turkey provides grants and loans to support economic
development. Ankara provided $200 million in 2002 and pledged $450
million for the 2003-05 period. Future events throughout the island
will be highly influenced by the outcome of negotiations on the
UN-sponsored agreement to unite the Greek and Turkish areas.
Czech Republic
One of the most stable and prosperous of the
post-Communist states, the Czech Republic has been recovering from
recession since mid-1999. Growth in 2000-03 was supported by exports
to the EU, primarily to Germany, and a near doubling of foreign
direct investment. Domestic demand is playing an ever more important
role in underpinning growth as interest rates drop and the
availability of credit cards and mortgages increases. High current
account deficits - averaging around 5% of GDP in the last several
years - could be a persistent problem. Inflation is under control.
The EU put the Czech Republic just behind Poland and Hungary in
preparations for accession, which will give further impetus and
direction to structural reform. Moves to complete banking,
telecommunications, and energy privatization will encourage
additional foreign investment, while intensified restructuring among
large enterprises and banks, and improvements in the financial
sector, should strengthen output growth. Nonetheless, revival in the
European economies remains essential to stepped-up growth.
Republic of Cyprus: Democratic Party or DIKO [Tassos
PAPADOPOULOS]; Democratic Rally or DISY [Nikos ANASTASIADHIS];
Fighting Democratic Movement or ADIK [Dinos MIKHAILIDIS]; Green
Party of Cyprus [George PERDIKIS]; New Horizons [Nikolaus KOUTSOU];
Restorative Party of the Working People or AKEL (Communist Party)
[Dimitrios CHRISTOFIAS]; Social Democrats Movement or KISOS
(formerly United Democratic Union of Cyprus or EDEK) [Yiannakis
OMIROU]; United Democrats Movement or EDE [George VASSILIOU]; north
Cyprus: Democratic Party or DP [Serder DENKTASH]; National Birth
Party or UDP [Enver EMIN]; National Unity Party or UBP [Dervis
EROGLU]; Our Party or BP [Okyay SADIKOGLU]; Patriotic Unity Movement
or YBH [Alpay DURDURAN]; Peace and Democratic Movement [Mustafa
AKINCI]; Republican Turkish Party or CTP [Mehmet ALI TALAT]
Czech Republic
Christian and Democratic Union-Czechoslovak People''s
Party or KDU-CSL [Miroslav KALOUSEK, chairman]; Civic Democratic
Alliance or ODA [Jirina NOVAKOVA, chairman]; Civic Democratic Party
or ODS [Mirek TOPOLANEK, chairman]; Communist Party of Bohemia and
Moravia or KSCM [Miroslav GREBENICEK, chairman]; Communist Party of
Czechoslovakia or KSC [Miroslav STEPAN, chairman]; Czech National
Social Party of CSNS [Jaroslav ROVNY, chairman]; Czech Social
Democratic Party or CSSD [Stanislav GROSS, acting chairman];
European Democrats [Jan KASL]; Freedom Union-Democratic Union or
US-DEU [Pavel NEMEC, chairman]; Green Party; Open Democracy','0cf9d79a9da6362e0bfb4df4555a107b1b32b139930353ee2fe1af760c2ec008','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ef022740548b2fcc7948834d85ccbb8de18d01775b675f6195f4b9428b9a3fd',2004,'DK','Denmark','economy',688,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2004 est.)
total: 69
914 to 1,523 m: 6
under 914 m: 63 (2004 est.)
air pollution, principally from vehicle and power plant
emissions; nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from animal wastes and
pesticides
Dhekelia
netting and trapping of small migrant songbirds in the
spring and autumn
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Law of the Sea
1.6% (2003)
35.47 billion kWh (2001)
32.41 billion kWh (2001)
8.199 billion kWh (2001)
8.775 billion kWh (2001)
NA
lowest 10%: 2%
highest 10%: 24% (2000 est.)
agriculture 4%, industry 17%, services 79% (2002 est.)
machinery and instruments, meat and meat products, dairy
products, fish, chemicals, furniture, ships, windmills
Germany 18.7%, Sweden 12.6%, UK 8.5%, US 6.2%, Norway 5.7%,
France 5.1%, Netherlands 4.7% (2003)
metropolitan Denmark - 14 counties (amter, singular - amt)
and 2 boroughs* (amtskommuner, singular - amtskommune); Arhus,
Bornholm, Frederiksberg*, Frederiksborg, Fyn, Kobenhavn,
Kobenhavns*, Nordjylland, Ribe, Ringkobing, Roskilde, Sonderjylland,
Storstrom, Vejle, Vestsjalland, Viborg
note: see separate entries for the Faroe Islands and Greenland,
which are part of the Kingdom of Denmark and are self-governing
overseas administrative divisions
barley, wheat, potatoes, sugar beets; pork, dairy products;
fish
99 (2003 est.)
11.59 births/1,000 population (2004 est.)
Royal Danish Army, Royal Danish Navy, Royal Danish Air
Force, Home Guard
revenues: $118.5 billion
expenditures: $116 billion, including capital expenditures of $500
million (2003 est.)
This thoroughly modern market economy features high-tech
agriculture, up-to-date small-scale and corporate industry,
extensive government welfare measures, comfortable living standards,
a stable currency, and high dependence on foreign trade. Denmark is
a net exporter of food and energy and enjoys a comfortable balance
of payments surplus. Government objectives include streamlining the
bureaucracy and further privatization of state assets. The
government has been successful in meeting, and even exceeding, the
economic convergence criteria for participating in the third phase
(a common European currency) of the European Economic and Monetary
Union (EMU), but Denmark has decided not to join 12 other EU members
in the euro; even so, the Danish Krone remains pegged to the euro.
Given the sluggish state of the European economy, growth in 2003 was
a mere 0.3%.
Dhekelia
Economic activity is limited to providing services to the
military and their families located in Dhekelia. All food and
manufactured goods must be imported.
condensate 12 km; gas 3,892 km; oil 455 km; oil/gas/water 2
km; unknown (oil/water) 64 km (2004)
Center Democratic Party [Mimi JAKOBSEN]; Christian Democrats
(was Christian People''s Party) [Marianne KARLSMOSE]; Conservative
Party (sometimes known as Conservative People''s Party) [Bendt
BENDTSEN]; Danish People''s Party [Pia KJAERSGAARD]; Liberal Party
[Anders Fogh RASMUSSEN]; Social Democratic Party [Mogens LYKKETOFT];
Social Liberal Party (sometimes called the Radical Left) [Marianne
JELVED, leader; Soren BALD, chairman]; Socialist People''s Party
[Holger K. NIELSEN]; Red-Green Unity List (bloc includes Left
Socialist Party, Communist Party of Denmark, Socialist Workers''
Party) [collective leadership]','d44f53038605666c4b8623156498da7d4827c680f012ea6ba97bd82de1a82d62','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77134aa8e1a56e84cc7d123697f72d7d4a88b73f18af9fa4b76ea0b4da101fd2',2004,'DJ','Djibouti','economy',689,'total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1524 to 2437 m: 1 (2004 est.)
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2004 est.)
inadequate supplies of potable water; limited arable land;
desertification; endangered species
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected agreements
4.4% (2003)
180 million kWh (2001)
167.4 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
50% (2001 est.)
lowest 10%: NA
highest 10%: NA
NA
reexports, hides and skins, coffee (in transit)
Somalia 63.9%, Yemen 22.5%, Ethiopia 4.7% (2003)
5 districts (cercles, singular - cercle); ''Ali Sabih,
Dikhil, Djibouti, Obock, Tadjoura
fruits, vegetables; goats, sheep, camels
13 (2003 est.)
40.39 births/1,000 population (2004 est.)
Djibouti National Army (including Navy and Air Force)
revenues: $135 million
expenditures: $182 million, including capital expenditures of NA
(1999 est.)
The economy is based on service activities connected with
the country''s strategic location and status as a free trade zone in
northeast Africa. Two-thirds of the inhabitants live in the capital
city, the remainder being mostly nomadic herders. Scanty rainfall
limits crop production to fruits and vegetables, and most food must
be imported. Djibouti provides services as both a transit port for
the region and an international transshipment and refueling center.
It has few natural resources and little industry. The nation is,
therefore, heavily dependent on foreign assistance to help support
its balance of payments and to finance development projects. An
unemployment rate of 50% continues to be a major problem. Inflation
is not a concern, however, because of the fixed tie of the franc to
the US dollar. Per capita consumption dropped an estimated 35% over
the last seven years because of recession, civil war, and a high
population growth rate (including immigrants and refugees). Faced
with a multitude of economic difficulties, the government has fallen
in arrears on long-term external debt and has been struggling to
meet the stipulations of foreign aid donors.
Democratic National Party or PND [ADEN Robleh Awaleh];
Democratic Renewal Party or PRD [Abdillahi HAMARITEH]; Djibouti
Development Party or PDD [Mohamed Daoud CHEHEM]; Front pour la
Restauration de l''Unite Democratique or FRUD [Ali Mohamed DAOUD];
People''s Progress Assembly or RPP (governing party) [Ismail Omar
GUELLEH]; Peoples Social Democratic Party or PPSD [Moumin Bahdon
FARAH]; Republican Alliance for Democracy or ARD [Ahmed Dini AHMED];
Union for Democracy and Justice or UDJ [leader NA]','0e0119f12ae9629f0d30a641d64038ad507600515b2804171fa0f2eda49c4717','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fba13918507057f483071d7a0cc45037feb95cb00eb07f0d98a59b707df3d46',2004,'DM','Dominica','economy',690,'total: 2
914 to 1,523 m: 2 (2004 est.)
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
72.41 million kWh (2001)
67.35 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
30% (2002 est.)
lowest 10%: NA
highest 10%: NA
agriculture 40%, industry and commerce 32%, services 28%
bananas, soap, bay oil, vegetables, grapefruit, oranges
UK 20%, Jamaica 18.5%, Antigua and Barbuda 7.7%, US 7.7%,
Guyana 6.2%, Japan 6.2%, Trinidad and Tobago 4.6% (2003)
10 parishes; Saint Andrew, Saint David, Saint George, Saint
John, Saint Joseph, Saint Luke, Saint Mark, Saint Patrick, Saint
Paul, Saint Peter
bananas, citrus, mangoes, root crops, coconuts, cocoa;
forest and fishery potential not exploited
2 (2003 est.)
16.25 births/1,000 population (2004 est.)
no regular military forces; Commonwealth of Dominica Police
Force (including Coast Guard)
revenues: $73.9 million
expenditures: $84.4 million, including capital expenditures of NA
(2001)
The Dominican economy depends on agriculture, primarily
bananas, and remains highly vulnerable to climatic conditions and
international economic developments. Production of bananas dropped
precipitously in 2003, a major reason for the 1% decline in GDP.
Tourism increased in 2003 as the government sought to promote
Dominica as an "ecotourism" destination. Development of the tourism
industry remains difficult, however, because of the rugged
coastline, lack of beaches, and the absence of an international
airport. The government began a comprehensive restructuring of the
economy in 2003 - including elimination of price controls,
privatization of the state banana company, and tax increases - to
address Dominica''s economic crisis and to meet IMF targets. In order
to diversify the island''s production base the government is
attempting to develop an offshore financial sector and is planning
to construct an oil refinery on the eastern part of the island.
Dominica Freedom Party or DFP [Charles SAVARIN]; Dominica
Labor Party or DLP [Roosevelt SKERRIT]; United Workers Party or UWP
[Edison JAMES]','5e2185bde4b35c0e7a08646c59c7c6be0312ba664de32f24092ee5a96af19cba','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6154e4041c38300ea5e1128058a35ae8ab5c269ada4578bfa69e3be716d5263b',2004,'DO','Dominican Republic','economy',691,'total: 13
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
East Timor
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 18
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 10 (2004 est.)
East Timor
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
water shortages; soil eroding into the sea
damages coral reefs; deforestation
East Timor
widespread use of slash and burn agriculture has led to
deforestation and soil erosion
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Law of the Sea
East Timor
NA
1.1% (1998)
East Timor
NA
9.186 billion kWh (2001)
East Timor
NA kWh (2001)
8.543 billion kWh (2001)
East Timor
NA kWh (2001)
0 kWh (2001)
East Timor
0 kWh (2001)
0 kWh (2001)
East Timor
0 kWh (2001)
25%
East Timor
42% (2003 est.)
lowest 10%: 2.1%
highest 10%: 37.9% (1998)
East Timor
lowest 10%: NA
highest 10%: NA
agriculture 17%, industry 24.3%, services and
government 58.7% (1998 est.)
East Timor
NA
ferronickel, sugar, gold, silver, coffee, cocoa,
tobacco, meats, consumer goods
East Timor
coffee, sandalwood, marble; note - the potential for oil
and vanilla exports
US 83.8%, Canada 1.5%, Haiti 1.5% (2003)
East Timor
NA
31 provinces (provincias, singular - provincia)
and 1 district* (distrito); Azua, Baoruco, Barahona, Dajabon,
Distrito Nacional*, Duarte, Elias Pina, El Seibo, Espaillat, Hato
Mayor, Independencia, La Altagracia, La Romana, La Vega, Maria
Trinidad Sanchez, Monsenor Nouel, Monte Cristi, Monte Plata,
Pedernales, Peravia, Puerto Plata, Salcedo, Samana, Sanchez Ramirez,
San Cristobal, San Jose de Ocoa, San Juan, San Pedro de Macoris,
Santiago, Santiago Rodriguez, Santo Domingo, Valverde
East Timor
13 administrative districts; Aileu, Ainaro, Baucau,
Bobonaro (Maliana), Cova-Lima (Suai), Dili, Ermera, Lautem (Los
Palos), Liquica, Manatuto, Manufahi (Same), Oecussi (Ambeno),
Viqueque
sugarcane, coffee, cotton, cocoa, tobacco, rice,
beans, potatoes, corn, bananas; cattle, pigs, dairy products, beef,
eggs
East Timor
coffee, rice, maize, cassava, sweet potatoes, soybeans,
cabbage, mangoes, bananas, vanilla
31 (2003 est.)
East Timor
8 (2003 est.)
23.6 births/1,000 population (2004 est.)
East Timor
27.46 births/1,000 population (2004 est.)
Army, Navy, Air Force
East Timor
East Timor Defense Force (Forcas de Defesa de
Timor-L''este, FDTL): Army, Navy
revenues: $2.601 billion
expenditures: $3.353 billion, including capital expenditures of $1.1
billion (2003 est.)
East Timor
revenues: $36 million
expenditures: $97 million, including capital expenditures of NA
(2003 est.)
The Dominican Republic is a Caribbean
representative democracy which enjoyed GDP growth of more than 7% in
1998-2000. Growth subsequently plummeted as part of the global
economic slowdown. Although the country has long been viewed
primarily as an exporter of sugar, coffee, and tobacco, in recent
years the service sector has overtaken agriculture as the economy''s
largest employer, due to growth in tourism and free trade zones. The
country suffers from marked income inequality; the poorest half of
the population receives less than one-fifth of GNP, while the
richest 10% enjoys nearly 40% of national income. Growth turned
negative in 2003 with reduced tourism, a major bank fraud, and
limited growth in the US economy, the source of 87% of export
revenues. Resumption of a badly needed IMF loan was slowed due to
government repurchase of electrical power plants.
East Timor
In late 1999, about 70% of the economic infrastructure of
East Timor was laid waste by Indonesian troops and anti-independence
militias, and 260,000 people fled westward. Over the next three
years, however, a massive international program, manned by 5,000
peacekeepers (8,000 at peak) and 1,300 police officers, led to
substantial reconstruction in both urban and rural areas. By
mid-2002, all but about 50,000 of the refugees had returned. Growth
was held back in 2003 by extensive drought and the gradual winding
down of the international presence. The country faces great
challenges in continuing the rebuilding of infrastructure,
strengthening the infant civil administration, and generating jobs
for young people entering the workforce. One promising long-term
project is the planned development of oil and gas resources in
nearby waters, but the government faces a substantial financing gap
over the next several years before these revenues start flowing into
state coffers.
Dominican Liberation Party or PLD [Leonel
FERNANDEZ Reyna]; Dominican Revolutionary Party or PRD [Vicente
Sanchez BARET]; Social Christian Reformist Party or PRSC [Enrique
ATUN]
East Timor
Associacao Social-Democrata Timorense or ASDT [Francisco
Xavier do AMARAL]; Christian Democratic Party of Timor or PDC
[Antonio XIMENES]; Christian Democratic Union of Timor or UDC
[Vicente da Silva GUTERRES]; Democratic Party or PD [Fernando de
ARAUJO]; Liberal Party or PL [leader NA]; Maubere Democratic Party
or PDM [leader NA]; People''s Party of Timor or PPT [Jacob XAVIER];
Revolutionary Front of Independent East Timor or FRETILIN [Lu OLO];
Social Democrat Party of East Timor or PSD [Mario CARRASCALAO];
Socialist Party of Timor or PST [leader Avelino COELHO]; Sons of the
Mountain Warriors (also known as Association of Timorese Heroes) or
KOTA [Clementino dos Reis AMARAL]; Timor Democratic Union or UDT
[Joao CARRASCALAO]; Timor Labor Party or PTT [Paulo Freitas DA
SILVA]; Timorese Nationalist Party or PNT [Abilio ARAUJO]; Timorese
Popular Democratic Association or APODETI [Frederico Almeida-Santos
DA COSTA]','06835af90f37a321b15688bbc78dc33485b828a7a4dd9ff7e7e6daf3768c6664','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf92230da146cd5f69d316b1fb74bbfee7ba1dd82c05311ba4db88f24209545e',2004,'EC','Ecuador','economy',692,'total: 62
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 18
914 to 1,523 m: 19
under 914 m: 18 (2004 est.)
total: 143
914 to 1,523 m: 30
under 914 m: 113 (2004 est.)
deforestation; soil erosion; desertification; water
pollution; pollution from oil production wastes in ecologically
sensitive areas of the Amazon Basin and Galapagos Islands
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
2.4% (2003)
75.23 billion kWh (2001)
69.96 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
65% (2003 est.)
lowest 10%: 2.2%
highest 10%: 33.8% (1995)
agriculture 30%, industry 25%, services 45% (2001 est.)
petroleum, bananas, cut flowers, shrimp
US 42.4%, Colombia 5.7%, Germany 5.6% (2003)
22 provinces (provincias, singular - provincia); Azuay,
Bolivar, Canar, Carchi, Chimborazo, Cotopaxi, El Oro, Esmeraldas,
Galapagos, Guayas, Imbabura, Loja, Los Rios, Manabi,
Morona-Santiago, Napo, Orellana, Pastaza, Pichincha, Sucumbios,
Tungurahua, Zamora-Chinchipe
bananas, coffee, cocoa, rice, potatoes, manioc (tapioca),
plantains, sugarcane; cattle, sheep, pigs, beef, pork, dairy
products; balsa wood; fish, shrimp
205 (2003 est.)
23.18 births/1,000 population (2004 est.)
Army, Navy (including Marines), Air Force, National Police
revenues: $6.908 billion
expenditures: planned $6.594 billion, including capital expenditures
of $1.6 billion (2003)
Ecuador has substantial petroleum resources, which have
accounted for 40% of the country''s export earnings and one-fourth of
public sector revenues in recent years. Consequently, fluctuations
in world market prices can have a substantial domestic impact. In
the late 1990s, Ecuador suffered its worst economic crisis, with
natural disasters and sharp declines in world petroleum prices
driving Ecuador''s economy into free fall in 1999. Real GDP
contracted by more than 6%, with poverty worsening significantly.
The banking system also collapsed, and Ecuador defaulted on its
external debt later that year. The currency depreciated by some 70%
in 1999, and, on the brink of hyperinflation, the MAHAUD government
announced it would dollarize the economy. A coup, however, ousted
MAHAUD from office in January 2000, and after a short-lived junta
failed to garner military support, Vice President Gustavo NOBOA took
over the presidency. In March 2000, Congress approved a series of
structural reforms that also provided the framework for the adoption
of the US dollar as legal tender. Dollarization stabilized the
economy, and growth returned to its pre-crisis levels in the years
that followed. Under the administration of Lucio GUTIERREZ, who took
office in January 2003, Ecuador benefited from higher world
petroleum prices, but the government has made little progress on
fiscal reforms and reforms of state-owned enterprises necessary to
reduce Ecuador''s vulnerability to petroleum price swings and
financial crises.
extra heavy crude 578 km; gas 71 km; oil 1,386 km; refined
products 1,185 km (2004)
Concentration of Popular Forces or CFP [Averroes BUCARAM];
Democratic Left or ID [Guillermo LANDAZURI]; National Action
Institutional Renewal Party or PRIAN [Alvaro NOBOA]; Pachakutik
Movement [Gilberto TALAHUA]; Patriotic Society Party or PSP [Lucio
GUTIERREZ Borbua]; Popular Democracy or DP [Dr. Juan Manuel
FUERTES]; Popular Democratic Movement or MPD [Gustavo TERAN Acosta];
Radical Alfarista Front or FRA [Fabian ALARCON, director]; Roldosist
Party or PRE [Abdala BUCARAM Ortiz, director]; Social Christian
Party or PSC [Leon FEBRES CORDERO]; Socialist Party - Broad Front or
PS-FA [Victor GRANDA]','e4ec2941459967e76df8cfee2bec5c0628bfc0bfbb390c27ce0fccafb013ef3c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee1bf615208a4f5e184224cdb80fc38df1586ff2bedcbae53270443d57d74fc',2004,'EG','Egypt','economy',693,'total: 72
over 3,047 m: 13
2,438 to 3,047 m: 38
1,524 to 2,437 m: 17
under 914 m: 4 (2004 est.)
total: 15
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 7 (2004 est.)
agricultural land being lost to urbanization and windblown
sands; increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs, beaches, and
marine habitats; other water pollution from agricultural pesticides,
raw sewage, and industrial effluents; very limited natural fresh
water resources away from the Nile which is the only perennial water
source; rapid growth in population overstraining the Nile and
natural resources
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
3.6% (2003)
75.23 billion kWh (2001)
69.96 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
16.7% (2000 est.)
lowest 10%: 3.7%
highest 10%: 29.5% (1999)
agriculture 32%, industry 17%, services 51% (2001 est.)
crude oil and petroleum products, cotton, textiles, metal
products, chemicals
US 13.3%, Italy 12.3%, UK 7.9%, France 4.7%, Germany 4.7%,
India 4.2% (2003)
26 governorates (muhafazat, singular - muhafazah); Ad
Daqahliyah, Al Bahr al Ahmar, Al Buhayrah, Al Fayyum, Al Gharbiyah,
Al Iskandariyah, Al Isma''iliyah, Al Jizah, Al Minufiyah, Al Minya,
Al Qahirah, Al Qalyubiyah, Al Wadi al Jadid, Ash Sharqiyah, As
Suways, Aswan, Asyut, Bani Suwayf, Bur Sa''id, Dumyat, Janub Sina'',
Kafr ash Shaykh, Matruh, Qina, Shamal Sina'', Suhaj
cotton, rice, corn, wheat, beans, fruits, vegetables; cattle,
water buffalo, sheep, goats
89 (2003 est.)
23.84 births/1,000 population (2004 est.)
Army, Navy, Air Force, Air Defense Command
revenues: $14.69 billion
expenditures: $19.03 billion, including capital expenditures of $2.7
billion (2003)
Lack of substantial progress on economic reform since the mid
1990s has limited foreign direct investment in Egypt and kept annual
GDP growth in the range of 2-3 percent in 2001-03. Egyptian
officials in late 2003 and early 2004 proposed new privatization and
customs reform measures, but the government is likely to pursue
these initiatives cautiously and gradually to avoid a public
backlash over potential inflation or layoffs associated with the
reforms. Monetary pressures on an overvalued Egyptian pound led the
government to float the currency in January 2003, leading to a sharp
drop in its value and consequent inflationary pressure. The
existence of a black market for hard currency is evidence that the
government continues to influence the official exchange rate offered
in banks. In September 2003, Egyptian officials increased subsidies
on basic foodstuffs, helping to calm a frustrated public but
widening an already deep budget deficit. Egypt''s balance-of-payments
position was not hurt by the war in Iraq in 2003, as tourism and
Suez Canal revenues fared well. The development of an export market
for natural gas is a bright spot for future growth prospects, but
improvement in the capital-intensive hydrocarbons sector does little
to reduce Egypt''s persistent unemployment.
condensate 289 km; condensate/gas 94 km; gas 6,115 km; liquid
petroleum gas 852 km; oil 5,032 km; oil/gas/water 36 km; refined
products 246 km (2004)
Nasserist Arab Democratic Party or Nasserists [Dia'' al-din
DAWUD]; National Democratic Party or NDP [President Mohammed Hosni
MUBARAK] - governing party; National Progressive Unionist Grouping
or Tagammu [Rifaat EL-SAID]; New Wafd Party or NWP [No''man GOMA];
Socialist Liberal Party or Al-Ahrar [Hilmi SALIM]; Tomorrow Party or
Al-Ghad [Ayman NOUR]
note: formation of political parties must be approved by the','2f19e9b8287d9ef52adb773f9db0a86f40038605f0eb6ca4843b40fd5f005763','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2fa86c7c446027970804f428dd767fddbf3ce78df2a4069fb5c7b8d750bb77d',2004,'SV','El Salvador','economy',694,'total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2004 est.)
total: 69
914 to 1,523 m: 15
under 914 m: 54 (2004 est.)
deforestation; soil erosion; water pollution;
contamination of soils from disposal of toxic wastes
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
1.1% (2003)
3.729 billion kWh (2001)
3.777 billion kWh (2001)
353 million kWh (2001)
44 million kWh (2001)
48% (1999 est.)
lowest 10%: 1.4%
highest 10%: 39.3% (2001)
agriculture 30%, industry 15%, services 55% (1999 est.)
offshore assembly exports, coffee, sugar, shrimp,
textiles, chemicals, electricity
US 67.8%, Guatemala 11.5%, Honduras 5.9% (2003)
14 departments (departamentos, singular - departamento);
Ahuachapan, Cabanas, Chalatenango, Cuscatlan, La Libertad, La Paz,
La Union, Morazan, San Miguel, San Salvador, Santa Ana, San Vicente,
Sonsonate, Usulutan
coffee, sugar, corn, rice, beans, oilseed, cotton,
sorghum; shrimp; beef, dairy products
73 (2003 est.)
27.48 births/1,000 population (2004 est.)
Army, Navy (FNES), Air Force
revenues: $2.434 billion
expenditures: $2.625 billion, including capital expenditures of NA
(2003 est.)
With the adoption of the US dollar as its currency, El
Salvador has lost control over monetary policy and must concentrate
on maintaining a disciplined fiscal policy. GDP per capita is
roughly only half that of Brazil, Argentina, and Chile, and the
distribution of income is highly unequal. The trade deficit has been
offset by annual remittances of almost $2 billion from Salvadorans
living abroad and external aid. The government is striving to open
new export markets, encourage foreign investment, modernize the tax
and healthcare systems, and stimulate the sluggish economy.','7481004ffe455c67d1bd5549fce5a7f526e60537ee6f322f4b7713323e87f48b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e29f7831a0e47c5ff54bcd780847bdec6f67276f4e6cdaa8e8c3faea05bcb0e',2004,'GQ','Equatorial Guinea','economy',695,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
less than 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
tap water is not potable; deforestation
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ship Pollution
signed, but not ratified: none of the selected agreements
2.5% (2003)
23.56 million kWh (2001)
21.91 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
petroleum, methanol, timber, cocoa
US 33.6%, Spain 25.8%, China 14.4%, Canada 11.8%,
Italy 6.4% (2003)
7 provinces (provincias, singular - provincia);
Annobon, Bioko Norte, Bioko Sur, Centro Sur, Kie-Ntem, Litoral,
Wele-Nzas
coffee, cocoa, rice, yams, cassava (tapioca),
bananas, palm oil nuts; livestock; timber
3 (2003 est.)
36.56 births/1,000 population (2004 est.)
Army, Navy, Air Force, Rapid Intervention Force
revenues: $708.5 million
expenditures: $317.6 million, including capital expenditures of NA
(2003 est.)
The discovery and exploitation of large oil
reserves have contributed to dramatic economic growth in recent
years. Forestry, farming, and fishing are also major components of
GDP. Subsistence farming predominates. Although pre-independence
Equatorial Guinea counted on cocoa production for hard currency
earnings, the neglect of the rural economy under successive regimes
has diminished potential for agriculture-led growth (the government
has stated its intention to reinvest some oil revenue into
agriculture). A number of aid programs sponsored by the World Bank
and the IMF have been cut off since 1993 because of corruption and
mismanagement. No longer eligible for concessional financing because
of large oil revenues, the government has been unsuccessfully trying
to agree on a "shadow" fiscal management program with the World Bank
and IMF. Businesses, for the most part, are owned by government
officials and their family members. Undeveloped natural resources
include titanium, iron ore, manganese, uranium, and alluvial gold.
Growth will remain strong in 2004, led by oil.
condensate 37 km; gas 39 km; liquid natural gas 4
km; oil 24 km (2004)','163c66f87a35c822e611e4b3e6bcf9e151f1c5afbaa0c471a786a01ddb3d6dc8','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e06cd55182d6199cbce5c6e6305d3792dc154f4094f0535830fe830c54d1855',2004,'ER','Eritrea','economy',696,'total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2004 est.)
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 2 (2004 est.)
deforestation; desertification; soil erosion; overgrazing;
loss of infrastructure from civil warfare
party to: Biodiversity, Climate Change, Desertification,
Endangered Species
signed, but not ratified: none of the selected agreements
11.8% (2003)
220.5 million kWh (2001)
205.1 million kWh (2001)
0 kWh NA kWh (2001)
0 kWh NA kWh (2001)
53% (1993/94)
lowest 10%: NA
highest 10%: NA
agriculture 80%, industry and services 20%
livestock, sorghum, textiles, food, small manufactures (2000)
Malaysia 65.1%, Italy 10.4%, France 4.4% (2003)
6 regions (zobatat, singular - zoba); Anseba, Debub,
Debubawi K''eyih Bahri, Gash Barka, Ma''akel, Semenawi Keyih Bahri
sorghum, lentils, vegetables, corn, cotton, tobacco, coffee,
sisal; livestock, goats; fish
18 (2003 est.)
39.03 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $235.7 million
expenditures: $375 million, including capital expenditures of $NA
(2003 est.)
Since independence from Ethiopia on 24 May 1993, Eritrea has
faced the economic problems of a small, desperately poor country.
Like the economies of many African nations, the economy is largely
based on subsistence agriculture, with 80% of the population
involved in farming and herding. The Ethiopian-Eritrea war in
1998-2000 severely hurt Eritrea''s economy. GDP growth fell to zero
in 1999 and to -12.1% in 2000. The May 2000 Ethiopian offensive into
northern Eritrea caused some $600 million in property damage and
loss, including losses of $225 million in livestock and 55,000
homes. The attack prevented planting of crops in Eritrea''s most
productive region, causing food production to drop by 62%. Even
during the war, Eritrea developed its transportation infrastructure,
asphalting new roads, improving its ports, and repairing war damaged
roads and bridges. Since the war ended, the government has
maintained a firm grip on the economy, expanding the use of the
military and party-owned businesses to complete Eritrea''s
development agenda. Erratic rainfall and the delayed demobilization
of agriculturalists from the military kept cereal production well
below normal, holding down growth in 2002. Eritrea''s economic future
depends upon its ability to master social problems such as
illiteracy, unemployment, and low skills, and to open its economy to
private enterprise so the diaspora''s money and expertise can foster
economic growth.','3a74da221e7cfcf21a8980494921103729a3e48911cf7767f6a60a4888b1461e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45f83788d896dcd405d7e8c0a3fb263ec4e231999c5628334ee0413a8371d4d2',2004,'EE','Estonia','economy',697,'total: 14
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2003 est.)
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 6 (2003 est.)
air polluted with sulfur dioxide from oil-shale burning
power plants in northeast; however, the amount of pollutants emitted
to the air have fallen steadily, the emissions of 2000 were 80% less
than in 1980; the amount of unpurified wastewater discharged to
water bodies in 2000 was one twentieth the level of 1980; in
connection with the start-up of new water purification plants, the
pollution load of wastewater decreased; Estonia has more than 1,400
natural and manmade lakes, the smaller of which in agricultural
areas need to be monitored; coastal seawater is polluted in certain
locations
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes, Ship Pollution,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
2% (2002 est.)
7.937 billion kWh (2001)
6.192 billion kWh (2001)
0 kWh (2001)
1.19 billion kWh (2001)
NA (2000)
lowest 10%: 3%
highest 10%: 29.8% (1998)
agriculture 11%, industry 20%, services 69% (1999 est.)
machinery and equipment 33%, wood and paper 15%, textiles
14%, food products 8%, furniture 7%, metals, chemical products (2001)
Finland 21.9%, Sweden 12.5%, Russia 11.4%, Germany 8.4%,
Latvia 7.4%, Lithuania 4% (2003)
15 counties (maakonnad, singular - maakond): Harjumaa
(Tallinn), Hiiumaa (Kardla), Ida-Virumaa (Johvi), Jarvamaa (Paide),
Jogevamaa (Jogeva), Laanemaa (Haapsalu), Laane-Virumaa (Rakvere),
Parnumaa (Parnu), Polvamaa (Polva), Raplamaa (Rapla), Saaremaa
(Kuressaare), Tartumaa (Tartu), Valgamaa (Valga), Viljandimaa
(Viljandi), Vorumaa (Voru)
note: counties have the administrative center name following in
parentheses
potatoes, vegetables; livestock and dairy products; fish
29 (2003 est.)
9.79 births/1,000 population (2004 est.)
Estonia Defense Forces (including Ground Forces, Navy, Air
Force), Republic Security Forces (internal and border troops),
Volunteer Defense League (Kaitseliit), Maritime Border Guard, Coast
Guard
note: Border Guards and Ministry of Internal Affairs become part of
the Estonian Defense Forces in wartime; the Coast Guard is
subordinate to the Ministry of Defense in peacetime and the Estonian
Navy in wartime
revenues: $3.806 billion
expenditures: $3.648 billion, including capital expenditures of NA
(2003 est.)
Estonia, as a new member of the World Trade Organization, is
steadily moving toward a modern market economy with increasing ties
to the West, including the pegging of its currency to the euro. The
economy benefits from strong electronics and telecommunications
sectors. Estonia has been invited to join the European Union and
will do so in May 2004. The economy is greatly influenced by
developments in Finland, Sweden, Russia, and Germany, four major
trading partners. The high current account deficit remains a
concern. However, the state budget enjoyed a surplus of $130 million
in 2003.
gas 859 km (2004)','e12964d757d487ee376f4ff0ea0f420aa3c673c9be60fe775690a5b73b863625','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('207b6c070c95f9bc8c5dca22dc951945cce2d3ebfa1d1f04ec35cfa1e17a472e',2004,'ET','Ethiopia','economy',698,'total: 14
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2004 est.)
Falkland Islands (Islas Malvinas)
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 27
under 914 m: 23 (2004 est.)
Europa Island
total: 1
914 to 1,523 m: 1 (2004 est.)
Falkland Islands (Islas Malvinas)
total: 3
under 914 m: 3 (2004 est.)
deforestation; overgrazing; soil erosion; desertification;
water shortages in some areas from water-intensive farming and poor
management
Europa Island
NA
European Union
NA
Falkland Islands (Islas Malvinas)
overfishing by unlicensed vessels
is a problem; reindeer were introduced to the islands in 2001 for
commercial reasons; this is the only commercial reindeer herd in the
world unaffected by the Chornobyl disaster
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Environmental Modification, Law of the Sea
European Union
Hazardous Wastes, Biodiversity, Air Pollution,
Antarctic-Marine Living Resources, Tropical Timber 82, Tropical
Timber 94, Ozone Layer Protection, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Law of the Sea, Desertification, Climate
Change; has signed, but not yet ratified: Air Pollution-Volatile
Organic Compounds, Air Pollution-Persistent Organic Pollutants
5.2% (2003)
Falkland Islands (Islas Malvinas)
NA
1.713 billion kWh (2001)
European Union
2.822 trillion kWh (2001)
Falkland Islands (Islas Malvinas)
16.33 million kWh (2001)
1.594 billion kWh (2001)
European Union
2.635 trillion kWh (2001)
Falkland Islands (Islas Malvinas)
15.19 million kWh (2001)
0 kWh (2001)
European Union
245.7 billion kWh (2001)
Falkland Islands (Islas Malvinas)
0 kWh (2001)
0 kWh (2001)
European Union
234.8 billion kWh (2001)
Falkland Islands (Islas Malvinas)
0 kWh (2001)
50% (2003 est.)
European Union
NA
Falkland Islands (Islas Malvinas)
NA
lowest 10%: 3%
highest 10%: 33.7% (1995)
European Union
lowest 10%: 2.9%
highest 10%: 25.2% (1995 est.)
Falkland Islands (Islas Malvinas)
lowest 10%: NA
highest 10%: NA
agriculture and animal husbandry 80%, industry and
construction 8%, government and services 12% (1985)
European Union
agriculture 4.3%, industry 29%, services 66.8% (2000)
Falkland Islands (Islas Malvinas)
agriculture 95% (mostly
sheepherding and fishing)
coffee, qat, gold, leather products, live animals, oilseeds
European Union
machinery, motor vehicles, aircraft, plastics,
pharmaceuticals and other chemicals, fuels, iron and steel,
nonferrous metals, wood pulp and paper products, textiles, meat,
dairy products, fish, alcoholic beverages.
Falkland Islands (Islas Malvinas)
wool, hides, meat
Djibouti 13.4%, Germany 11.4%, Saudi Arabia 6.9%, Japan
6.8%, Italy 6.4%, US 5.1% (2003)
European Union
NA
Falkland Islands (Islas Malvinas)
Spain 80%, UK 9.3%, US 3.6% (2003)
9 ethnically-based states (kililoch, singular - kilil) and
2 self-governing administrations* (astedaderoch, singular -
astedader); Adis Abeba* (Addis Ababa), Afar, Amara (Amhara),
Binshangul Gumuz, Dire Dawa*, Gambela Hizboch (Gambela Peoples),
Hareri Hizb (Harari People), Oromiya (Oromia), Sumale (Somali),
Tigray, Ye Debub Biheroch Bihereseboch na Hizboch (Southern Nations,
Nationalities and Peoples)
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)
cereals, pulses, coffee, oilseed, sugarcane, potatoes, qat;
hides, cattle, sheep, goats
European Union
wheat, barley, oilseeds, sugar beets, wine, grapes,
dairy products, cattle, sheep, pigs, poultry, fish
Falkland Islands (Islas Malvinas)
fodder and vegetable crops; sheep,
dairy products
82 (2003 est.)
Europa Island
1 (2003 est.)
European Union
total: 3,130
with paved runways: 1,834
with unpaved runways: 1,296 (2003)
Falkland Islands (Islas Malvinas)
5 (2003 est.)
39.23 births/1,000 population (2004 est.)
European Union
10.2 births/1,000 population (July 2004 est.)
Falkland Islands (Islas Malvinas)
NA births/1,000 population (2004
est.)
Ethiopian National Defense Force: Ground Forces, Air Force,
Mobilized Militia
note: Ethiopia is landlocked and has no navy; following the
secession of Eritrea, Ethiopian naval facilities remained in
Eritrean possession
Falkland Islands (Islas Malvinas)
no regular military forces
revenues: $1.813 billion
expenditures: $2.4 billion, including capital expenditures of $788
million (2003 est.)
Falkland Islands (Islas Malvinas)
revenues: $66.2 million
expenditures: $67.9 million, including capital expenditures of $23.2
million (FY98/99 est.)
Ethiopia''s poverty-stricken economy is based on
agriculture, which accounts for half of GDP, 60% of exports, and 80%
of total employment. The agricultural sector suffers from frequent
drought and poor cultivation practices. Coffee is critical to the
Ethiopian economy with exports of some $156 million in 2002, but
historically low prices have seen many farmers switching to qat to
supplement income. The war with Eritrea in 1998-2000 and recurrent
drought have buffeted the economy, in particular coffee production.
In November 2001 Ethiopia qualified for debt relief from the Highly
Indebted Poor Countries (HIPC) initiative. Under Ethiopia''s land
tenure system, the government owns all land and provides long-term
leases to the tenants; the system continues to hamper growth in the
industrial sector as entrepreneurs are unable to use land as
collateral for loans. Drought struck again late in 2002, leading to
a 2% decline in GDP in 2003. Return to normal weather patterns late
in 2003 should help agricultural and GDP growth recover in 2004. The
government estimates that annual growth of 7% is needed to reduce
poverty.
Europa Island
no economic activity
European Union
Domestically, the European Union attempts to lower
trade barriers, adopt a common currency, and move toward convergence
of living standards. Internationally, the EU aims to bolster
Europe''s trade position and its political and economic power.
Because of the great differences in per capita income (from $10,000
to $28,000) and historic national animosities, the European
Community faces difficulties in devising and enforcing common
policies. For example, both Germany and France since 2003 have
flouted the member states'' treaty obligation to prevent their
national budgets from running more than a 3% deficit. In 2004, the
EU admitted 10 central and eastern European countries that are, in
general, less advanced technologically and economically than the
existing 15. The Economic and Monetary Union (EMU), an associated
organization, introduced the euro as the common currency on 1
January 1999. The UK, Sweden, and Denmark do not now participate;
the 10 new countries may choose to join the EMU when they meet its
fiscal and monetary criteria and the member states so agree.
Falkland Islands (Islas Malvinas)
The economy was formerly based on
agriculture, mainly sheep farming, but today fishing contributes the
bulk of economic activity. In 1987 the government began selling
fishing licenses to foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees total more than $40
million per year, which goes to support the island''s health,
education, and welfare system. Squid accounts for 75% of the fish
taken. Dairy farming supports domestic consumption; crops furnish
winter fodder. Exports feature shipments of high-grade wool to the
UK and the sale of postage stamps and coins. The islands are now
self-financing except for defense. The British Geological Survey
announced a 200-mile oil exploration zone around the islands in
1993, and early seismic surveys suggest substantial reserves capable
of producing 500,000 barrels per day; to date no exploitable site
has been identified. An agreement between Argentina and the UK in
1995 seeks to defuse licensing and sovereignty conflicts that would
dampen foreign interest in exploiting potential oil reserves.
Tourism, especially eco-tourism, is increasing rapidly, with about
30,000 visitors in 2001. Another large source of income is interest
paid on money the government has in the bank. The British military
presence also provides a sizeable economic boost.','ca3a36d1ec1d9ef6261716537e2e471a94b4047ba42862561e180ab67134e957','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('182d3673bdb8daf8831944d8b973adbd6de538159de83ecd5b0ac5a52a383c57',2004,'FO','Faroe Islands','economy',699,'total: 1
914 to 1,523 m: 1 (2004 est.)
NA
NA
160.4 million kWh (2001)
149.1 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
fishing, fish processing, and manufacturing 33%,
construction and private services 33%, public services 34%
fish and fish products 94%, stamps, ships (1999)
Denmark 36.7%, UK 32.1%, Netherlands 6.1%, Nigeria
5.6%, Norway 5.4% (2003)
none (part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark); there are no
first-order administrative divisions as defined by the US
Government, but there are 49 municipalities
milk, potatoes, vegetables; sheep; salmon, other fish
1 (2003 est.)
13.89 births/1,000 population (2004 est.)
no regular military forces
revenues: $488 million
expenditures: $484 million, including capital expenditures of $21
million (1999)
The Faroese economy has had a strong performance since
1994, mostly as a result of increasing fish landings and high and
stable export prices. Unemployment is falling and there are signs of
labor shortages in several sectors. The positive economic
development has helped the Faroese Home Rule Government produce
increasing budget surpluses, which in turn help to reduce the large
public debt, most of it owed to Denmark. However, the total
dependence on fishing makes the Faroese economy extremely
vulnerable, and the present fishing efforts appear in excess of what
is a sustainable level of fishing in the long term. Oil finds close
to the Faroese area give hope for deposits in the immediate Faroese
area, which may eventually lay the basis for a more diversified
economy and thus lessen dependence on Danish economic assistance.
Aided by a substantial annual subsidy (15% of GDP) from Denmark, the
Faroese have a standard of living not far below the Danes and other
Scandinavians.','7fb66f1886cc1a20aae8b2742ab1243eea99240740ff03df3128b4ce6d7c7b53','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('080388b26df1259b47419e4ee695614f9c40ef702ed89f185e3fdeb9addd01de',2004,'FJ','Fiji','economy',700,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 25
914 to 1,523 m: 6
under 914 m: 19 (2004 est.)
deforestation; soil erosion
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
2.2% (FY02)
520.1 million kWh (2001)
483.7 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
25.5% (1990-91)
lowest 10%: NA
highest 10%: NA
agriculture, including subsistence agriculture 70% (2001 est.)
sugar, garments, gold, timber, fish, molasses, coconut oil
US 23.7%, Australia 18.4%, UK 13.6%, Samoa 6%, Japan 4.8% (2003)
4 divisions and 1 dependency*; Central, Eastern, Northern,
Rotuma*, Western
sugarcane, coconuts, cassava (tapioca), rice, sweet potatoes,
bananas; cattle, pigs, horses, goats; fish
28 (2003 est.)
22.91 births/1,000 population (2004 est.)
Republic of Fiji Military Forces (RFMF): Land Forces, Naval
Division
revenues: $427.9 million
expenditures: $531.4 million, including capital expenditures of NA
(2000 est.)
Fiji, endowed with forest, mineral, and fish resources, is one
of the most developed of the Pacific island economies, though still
with a large subsistence sector. Sugar exports and a growing tourist
industry - with 300,000 to 400,000 tourists annually - are the major
sources of foreign exchange. Sugar processing makes up one-third of
industrial activity. Long-term problems include low investment,
uncertain land ownership rights, and the government''s ability to
manage its budget. Yet short-run economic prospects are good,
provided tensions do not again erupt between indigenous Fijians and
Indo-Fijians.','ec39af3011edfe96f6ad4e6cd133b649dd5c487288ee9be585ecad31eafbfb74','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b25afbea6b18c362d235ee619304327710ac633308f5dcec7955da46455dc0c',2004,'FI','Finland','economy',701,'total: 75
over 3,047 m: 2
2,438 to 3,047 m: 27
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 13 (2004 est.)
total: 73
914 to 1,523 m: 4
under 914 m: 69 (2004 est.)
air pollution from manufacturing and power plants
contributing to acid rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife populations
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
2% (FY98/99)
71.2 billion kWh (2001)
76.18 billion kWh (2001)
11.77 billion kWh (2001)
1.81 billion kWh (2001)
NA
lowest 10%: 4.2%
highest 10%: 21.6% (1991)
agriculture and forestry 8%, industry 22%, construction 6%,
commerce 14%, finance, insurance, and business services 10%,
transport and communications 8%, public services 32%
machinery and equipment, chemicals, metals; timber, paper,
pulp (1999)
Germany 11.8%, Sweden 9.9%, US 8.2%, UK 8%, Russia 7.5%,
Netherlands 4.8% (2003)
6 provinces (laanit, singular - laani); Aland, Etela-Suomen
Laani, Ita-Suomen Laani, Lansi-Suomen Laani, Lappi, Oulun Laani
barley, wheat, sugar beets, potatoes; dairy cattle; fish
148 (2003 est.)
10.56 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $87.03 billion
expenditures: $81.62 billion, including capital expenditures of NA
(2003 est.)
Finland has a highly industrialized, largely free-market
economy, with per capita output roughly that of the UK, France,
Germany, and Italy. Its key economic sector is manufacturing -
principally the wood, metals, engineering, telecommunications, and
electronics industries. Trade is important, with exports equaling
one-third of GDP. Except for timber and several minerals, Finland
depends on imports of raw materials, energy, and some components for
manufactured goods. Because of the climate, agricultural development
is limited to maintaining self-sufficiency in basic products.
Forestry, an important export earner, provides a secondary
occupation for the rural population. Rapidly increasing integration
with Western Europe - Finland was one of the 12 countries joining
the European Economic and Monetary Union (EMU) - will dominate the
economic picture over the next several years. Growth in 2003 was
held back by the global slowdown but will pick up in 2004 provided
the world economy suffers no further blows.
gas 694 km (2004)','a6de17bc385656d2b87c6268a20dec23afff4809c5c0b2fd3120da0906a3a30a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cf8e79544ac368bc9605e0cf1dbff0fc9351e1e5d3d475323ca72ecf67a4415',2004,'GF','French Guiana','economy',702,'total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2004 est.)
NA
NA
455 million kWh (2001)
423.2 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 18.2%, industry 21.2%, services,
government, and commerce 60.6% (1980)
shrimp, timber, gold, rum, rosewood essence, clothing
France 62%, Switzerland 7%, US 2% (2001)
none (overseas department of France)
corn, rice, manioc (tapioca), sugar, cocoa,
vegetables, bananas; cattle, pigs, poultry
11 (2003 est.)
21 births/1,000 population (2004 est.)
no regular military forces; Gendarmerie
revenues: $225 million
expenditures: $390 million, including capital expenditures of $105
million (1996)
The economy is tied closely to the larger French
economy through subsidies and imports. Besides the French space
center at Kourou (which accounts for 25% of GDP), fishing and
forestry are the most important economic activities. Forest and
woodland cover 90% of the country. The large reserves of tropical
hardwoods, not fully exploited, support an expanding sawmill
industry that provides sawn logs for export. Cultivation of crops is
limited to the coastal area, where the population is largely
concentrated; rice and manioc are the major crops. French Guiana is
heavily dependent on imports of food and energy. Unemployment is a
serious problem, particularly among younger workers.','d89c9169caf0708652b2aeef5a277bab3eb4228333a3b1c31586f0a9e674bbf6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e15c08dfc8e741d486205805569a1b05bcf08e57eed5b05615c85ab27014d091',2004,'PF','French Polynesia','economy',703,'total: 37
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 23
under 914 m: 7 (2004 est.)
total: 13
914 to 1,523 m: 5
under 914 m: 8 (2004 est.)
NA
French Southern and Antarctic Lands
NA
428.3 million kWh (2001)
398.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 13%, industry 19%, services 68% (1997)
cultured pearls, coconut products, mother-of-pearl,
vanilla, shark meat
France 66.3%, Japan 16.1%, US 9.1% (2003)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 5 archipelagic divisions named Archipel
des Marquises, Archipel des Tuamotu, Archipel des Tubuai, Iles du
Vent, and Iles Sous-le-Vent
note: Clipperton Island is administered by France from French
Polynesia
French Southern and Antarctic Lands
none (overseas territory of
France); there are no first-order administrative divisions as
defined by the US Government, but there are 3 districts named Ile
Crozet, Iles Kerguelen, and Iles Saint-Paul et Amsterdam; excludes
"Adelie Land" claim in Antarctica that is not recognized by the US
coconuts, vanilla, vegetables, fruits; poultry,
beef, dairy products, coffee
49 (2003 est.)
French Southern and Antarctic Lands
none
17.34 births/1,000 population (2004 est.)
no regular military forces; Gendarmerie and
National Police Force
revenues: $1 billion
expenditures: $900 million, including capital expenditures of $185
million (1996)
Since 1962, when France stationed military
personnel in the region, French Polynesia has changed from a
subsistence agricultural economy to one in which a high proportion
of the work force is either employed by the military or supports the
tourist industry. With the halt of French nuclear testing in 1996,
the military contribution to the economy fell sharply. Tourism
accounts for about one-fourth of GDP and is a primary source of hard
currency earnings. Other sources of income are pearl farming and
deep-sea commercial fishing. The small manufacturing sector
primarily processes agricultural products. The territory benefits
substantially from development agreements with France aimed
principally at creating new businesses and strengthening social
services.
French Southern and Antarctic Lands
Economic activity is limited to
servicing meteorological and geophysical research stations and
French and other fishing fleets. The fish catches landed on Iles
Kerguelen by foreign ships are exported to France and Reunion.','415eaa4d2da6440a7286c3565c06fa0e8e7b50a2ee1624a2659e6f3fde3166bc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d669bd448b4e1ee6742958621ecf736018997761a2ceb8c857d25e289e2935a',2004,'GA','Gabon','economy',704,'total: 11
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 1 (2004 est.)
Gambia, The
total: 1
over 3,047 m: 1 (2004 est.)
Gaza Strip
total: 1
over 3,047 m: 1 (2004 est.)
total: 45
1,524 to 2,437 m: 7
914 to 1,523 m: 15
under 914 m: 23 (2004 est.)
Gaza Strip
total: 1
under 914 m: 1 (2004 est.)
deforestation; poaching
Gambia, The
deforestation; desertification; water-borne diseases
prevalent
Gaza Strip
desertification; salination of fresh water; sewage
treatment; water-borne disease; soil degradation; depletion and
contamination of underground water resources
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
Gambia, The
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2% (2003)
Gambia, The
0.3% (2003)
Gaza Strip
NA
798.4 million kWh (2001)
Gambia, The
85.33 million kWh (2001)
Gaza Strip
NA kWh; note - electricity supplied by Israel
742.5 million kWh (2001)
Gambia, The
79.36 million kWh (2001)
Gaza Strip
NA kWh
0 kWh (2001)
Gambia, The
0 kWh (2001)
Gaza Strip
NA kWh; note - electricity supplied by Israel (2001)
0 kWh (2001)
Gambia, The
0 kWh (2001)
Gaza Strip
0 kWh (2001)
NA
Gambia, The
NA
Gaza Strip
60% (2003 est.)
lowest 10%: NA
highest 10%: NA
Gambia, The
lowest 10%: NA
highest 10%: NA
Gaza Strip
lowest 10%: NA
highest 10%: NA
agriculture 60%, industry 15%, services 25%
Gambia, The
agriculture 75%, industry, commerce, and services 19%,
government 6%
Gaza Strip
agriculture 13%, industry 21%, services 66% (1996)
crude oil 77%, timber, manganese, uranium (2001)
Gambia, The
peanut products, fish, cotton lint, palm kernels,
re-exports
Gaza Strip
citrus, flowers
US 51.5%, France 8.7%, China 7.5%, Japan 4% (2003)
Gambia, The
UK 26.7%, Belgium 6.7%, China 6.7%, Germany 6.7%, Italy
6.7%, Malaysia 6.7%, Thailand 6.7% (2003)
Gaza Strip
Israel, Egypt, West Bank
9 provinces; Estuaire, Haut-Ogooue, Moyen-Ogooue, Ngounie,
Nyanga, Ogooue-Ivindo, Ogooue-Lolo, Ogooue-Maritime, Woleu-Ntem
Gambia, The
5 divisions and 1 city*; Banjul*, Central River, Lower
River, North Bank, Upper River, Western
cocoa, coffee, sugar, palm oil, rubber; cattle; okoume (a
tropical softwood); fish
Gambia, The
rice, millet, sorghum, peanuts, corn, sesame, cassava
(tapioca), palm kernels; cattle, sheep, goats
Gaza Strip
olives, citrus, vegetables; beef, dairy products
56 (2003 est.)
Gambia, The
1 (2003 est.)
Gaza Strip
2 (2001)
note: includes Gaza International Airport (GIA), inaugurated on 24
November 1998 as part of agreements stipulated in the September 1995
Oslo II Accord and the 23 October 1998 Wye River Memorandum; GIA has
been largely closed since October 2000 by Israeli orders and its
runway was destroyed by the Israeli Defense Forces in December 2001
(2003 est.)
36.4 births/1,000 population (2004 est.)
Gambia, The
40.3 births/1,000 population (2004 est.)
Gaza Strip
40.62 births/1,000 population (2004 est.)
Army, Navy, Air Force, National Gendarmerie, National Police
Gambia, The
Gambian National Army (GNA) (including Naval Unit),
Presidential Guard
Gaza Strip
in accordance with the peace agreement, the Palestinian
Authority is not permitted conventional military forces; there are,
however, a Public Security Force and a civil Police Force
revenues: $1.771 billion
expenditures: $1.413 billion, including capital expenditures of $310
million (2003 est.)
Gambia, The
revenues: $58.63 million
expenditures: $62.64 million, including capital expenditures of $4.1
million (2003 est.)
Gaza Strip
revenues: $676.6 million
expenditures: $1.155 billion, including capital expenditures of $NA
(includes West Bank) (2003)
Gabon enjoys a per capita income four times that of most
nations of sub-Saharan Africa. This has supported a sharp decline in
extreme poverty; yet because of high income inequality a large
proportion of the population remains poor. Gabon depended on timber
and manganese until oil was discovered offshore in the early 1970s.
The oil sector now accounts for 50% of GDP. Gabon continues to face
fluctuating prices for its oil, timber, and manganese exports.
Despite the abundance of natural wealth, poor fiscal management
hobbles the economy. Devaluation of its Francophone currency by 50%
on 12 January 1994 sparked a one-time inflationary surge, to 35%;
the rate dropped to 6% in 1996. The IMF provided a one-year standby
arrangement in 1994-95, a three-year Enhanced Financing Facility
(EFF) at near commercial rates beginning in late 1995, and stand-by
credit of $119 million in October 2000. Those agreements mandate
progress in privatization and fiscal discipline. France provided
additional financial support in January 1997 after Gabon had met IMF
targets for mid-1996. In 1997, an IMF mission to Gabon criticized
the government for overspending on off-budget items, overborrowing
from the central bank, and slipping on its schedule for
privatization and administrative reform. The rebound of oil prices
in 1999-2000 helped growth, but drops in production hampered Gabon
from fully realizing potential gains. In December 2000, Gabon signed
a new agreement with the Paris Club to reschedule its official debt.
A follow-up bilateral repayment agreement with the US was signed in
December 2001. Short-term progress depends on an upbeat world
economy and fiscal and other adjustments in line with IMF policies.
Gambia, The
The Gambia has no important mineral or other natural
resources and has a limited agricultural base. About 75% of the
population depends on crops and livestock for its livelihood.
Small-scale manufacturing activity features the processing of
peanuts, fish, and hides. Reexport trade normally constitutes a
major segment of economic activity, but a 1999 government-imposed
preshipment inspection plan, and instability of the Gambian dalasi
(currency) have drawn some of the reexport trade away from The
Gambia. The government''s 1998 seizure of the private peanut firm
Alimenta eliminated the largest purchaser of Gambian groundnuts; the
following two marketing seasons have seen substantially lower prices
and sales. A decline in tourism in 2000 has also held back growth.
Unemployment and underemployment rates are extremely high. Shortrun
economic progress remains highly dependent on sustained bilateral
and multilateral aid, on responsible government economic management
as forwarded by IMF technical help and advice, and on expected
growth in the construction sector.
Gaza Strip
Economic output in the Gaza Strip - under the
responsibility of the Palestinian Authority since the Cairo
Agreement of May 1994 - declined by about one-third between 1992 and
1996. The downturn was largely the result of Israeli closure
policies - the imposition of generalized border closures in response
to security incidents in Israel - which disrupted previously
established labor and commodity market relationships between Israel
and the WBGS (West Bank and Gaza Strip). The most serious negative
social effect of this downturn was the emergence of high
unemployment; unemployment in the WBGS during the 1980s was
generally under 5%; by 1995 it had risen to over 20%. Israel''s use
of comprehensive closures decreased during the next few years and,
in 1998, Israel implemented new policies to reduce the impact of
closures and other security procedures on the movement of
Palestinian goods and labor. These changes fueled an almost
three-year-long economic recovery in the West Bank and Gaza Strip;
real GDP grew by 5% in 1998 and 6% in 1999. Recovery was upended in
the last quarter of 2000 with the outbreak of violence, triggering
tight Israeli closures of Palestinian self-rule areas and a severe
disruption of trade and labor movements. In 2001, and even more
severely in 2002, Israeli military measures in Palestinian Authority
areas resulted in the destruction of capital plant and
administrative structure, widespread business closures, and a sharp
drop in GDP. Including West Bank, the UN estimates that more than
100,000 Palestinians out of the 125,000 who used to work in Israel,
in Israeli settlements, or in joint industrial zones have lost their
jobs. In addition, about 80,000 Palestinian workers inside the
Territories are losing their jobs. International aid of $2 billion
in 2001-02 to the West Bank and Gaza Strip prevented the complete
collapse of the economy and allowed Finance Minister Salam FAYYAD to
implement several financial and economic reforms. Budgetary support,
however, was not as forthcoming in 2003.
gas 210 km; oil 1,385 km (2004)','33416347fbbd0a384dc13842dbf6ec03ab5e8a4c6570719a1da20ab3e0751f6b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e29bb5e694c2d68484936e35ca278147de9cc77a448816a7b469757c446896b',2004,'GE','Georgia','economy',705,'total: 17
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 2
under 914 m: 2 (2003 est.)
total: 13
914 to 1,523 m: 3
under 914 m: 10 (2004 est.)
air pollution, particularly in Rust''avi; heavy pollution of
Mtkvari River and the Black Sea; inadequate supplies of potable
water; soil pollution from toxic chemicals
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.59% (FY00)
7.27 billion kWh (2001)
7.611 billion kWh (2001)
850 million kWh (2001)
0 kWh (2001)
54% (2001 est.)
lowest 10%: 2.3%
highest 10%: 27.9% (1996)
agriculture 40%, industry 20%, services 40% (1999 est.)
scrap metal, machinery, chemicals; fuel reexports; citrus
fruits, tea, wine
Russia 17.7%, Turkey 17.3%, Turkmenistan 12.2%, Armenia
8.6%, Switzerland 6.9%, Ukraine 6.3%, UK 5.9% (2003)
9 regions (mkharebi, singular - mkhare), 9 cities
(k''alak''ebi, singular - k''alak''i), and 2 autonomous republics
(avtomnoy respubliki, singular - avtom respublika)
regions: Guria, Imereti, Kakheti, Kvemo Kartli, Mtskheta-Mtianeti,
Racha-Lechkhumi and Kvemo Svaneti, Samegrelo and Zemo Svaneti,
Samtskhe-Javakheti, Shida Kartli
cities: Chiat''ura, Gori, K''ut''aisi, P''ot''i, Rust''avi, T''bilisi,
Tqibuli, Tsqaltubo, Zugdidi
autonomous republics: Abkhazia or Ap''khazet''is Avtonomiuri
Respublika (Sokhumi), Ajaria or Acharis Avtonomiuri Respublika
(Bat''umi)
note: the administrative centers of the 2 autonomous republics are
shown in parentheses
citrus, grapes, tea, hazelnuts, vegetables; livestock
31 (2003 est.)
10.1 births/1,000 population (2004 est.)
Ground Forces (including National Guard), Air and Air
Defense Forces, Maritime Defense Force
revenues: $603.5 million
expenditures: $700.5 million, including capital expenditures of NA
(2003 est.)
Georgia''s main economic activities include the cultivation
of agricultural products such as citrus fruits, tea, hazelnuts, and
grapes; mining of manganese and copper; and output of a small
industrial sector producing alcoholic and nonalcoholic beverages,
metals, machinery, and chemicals. The country imports the bulk of
its energy needs, including natural gas and oil products. Its only
sizable internal energy resource is hydropower. Despite the severe
damage the economy has suffered due to civil strife, Georgia, with
the help of the IMF and World Bank, has made substantial economic
gains since 1995, achieving positive GDP growth and curtailing
inflation. However, the Georgian Government suffers from limited
resources due to a chronic failure to collect tax revenues. Georgia
also suffers from energy shortages; it privatized the T''bilisi
distribution network in 1998, but collection rates are low, making
the venture unprofitable. The country is pinning its hopes for
long-term growth on its role as a transit state for pipelines and
trade. The start of construction on the Baku-T''bilisi-Ceyhan oil
pipeline and the Baku-T''bilisi-Erzerum gas pipeline will bring
much-needed investment and job opportunities.
gas 1,697 km; oil 1,027 km; refined products 232 km (2004)','1d34f16627e78d40667048b244389ac77a420d9b69d19d708d84fbbf29443f7f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef4e9f653219bae37fb2574293ab4e9c1e80fe0f056085b1ca4626201ad074a1',2004,'DE','Germany','economy',706,'total: 331
over 3,047 m: 13
2,438 to 3,047 m: 51
1,524 to 2,437 m: 62
914 to 1,523 m: 71
under 914 m: 134 (2004 est.)
total: 219
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 31
under 914 m: 185 (2004 est.)
emissions from coal-burning utilities and industries
contribute to air pollution; acid rain, resulting from sulfur
dioxide emissions, is damaging forests; pollution in the Baltic Sea
from raw sewage and industrial effluents from rivers in eastern
Germany; hazardous waste disposal; government established a
mechanism for ending the use of nuclear power over the next 15
years; government working to meet EU commitment to identify nature
preservation areas in line with the EU''s Flora, Fauna, and Habitat
directive
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.5% (2003)
544.8 billion kWh (2001)
506.8 billion kWh (2001)
44 billion kWh (2001)
43.9 billion kWh (2001)
NA
lowest 10%: 3.6%
highest 10%: 25.1% (1997)
agriculture 2.8%, industry 33.4%, services 63.8% (1999)
machinery, vehicles, chemicals, metals and manufactures,
foodstuffs, textiles
France 10.6%, US 9.3%, UK 8.4%, Italy 7.4%, Netherlands
6.2%, Austria 5.3%, Belgium 5.1%, Spain 4.9%, Switzerland 4% (2003)
13 states (Laender, singular - Land) and 3 free states*
(Freistaaten, singular - Freistaat); Baden-Wuerttemberg, Bayern*,
Berlin, Brandenburg, Bremen, Hamburg, Hessen,
Mecklenburg-Vorpommern, Niedersachsen, Nordrhein-Westfalen,
Rheinland-Pfalz, Saarland, Sachsen*, Sachsen-Anhalt,
Schleswig-Holstein, Thueringen*
potatoes, wheat, barley, sugar beets, fruit, cabbages;
cattle, pigs, poultry
550 (2003 est.)
8.45 births/1,000 population (2004 est.)
Army (Heer), Navy (Deutsche Marine; including Naval Air
arm), Air Force (Luftwaffe), Joint Support Service, Central Medical
Service
revenues: $1.079 trillion
expenditures: $1.173 trillion, including capital expenditures of NA
(2003 est.)
Germany''s affluent and technologically powerful economy- the
fifth largest national economy in the world - has become one of the
slowest growing economies in the entire euro zone, and a quick
turnaround is not in the offing in the foreseeable future. Growth in
2001-03 fell short of 1%. The modernization and integration of the
eastern German economy continues to be a costly long-term process,
with annual transfers from west to east amounting to roughly $70
billion. Germany''s ageing population, combined with high
unemployment, has pushed social security outlays to a level
exceeding contributions from workers. Structural rigidities in the
labor market - including strict regulations on laying off workers
and the setting of wages on a national basis - have made
unemployment a chronic problem. Corporate restructuring and growing
capital markets are setting the foundations that could allow Germany
to meet the long-term challenges of European economic integration
and globalization, particularly if labor market rigidities are
further addressed. The government is also starting long-needed
structural reforms designed to revitalize the country''s economy. In
the short run, however, the fall in government revenues and the rise
in expenditures have raised the deficit above the EU''s 3% debt limit.
condensate 325 km; gas 25,293 km; oil 3,540 km; refined
products 3,827 km (2004)','beb43f1b6d318922af58f7ed1b49058cb9095aba2e63590ec3447c9f7919b641','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9f310331461f387cfc72d658b21b929ca5387a05e27dcd7098b622ab2f0a79e',2004,'GH','Ghana','economy',707,'total: 7
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2004 est.)
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
Glorioso Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
recurrent drought in north severely affects agricultural
activities; deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations; water pollution;
inadequate supplies of potable water
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Marine Life Conservation
0.6% (2003)
8.801 billion kWh (2001)
8.835 billion kWh (2001)
950 million kWh (2001)
300 million kWh (2001)
31.4% (1992 est.)
lowest 10%: 2.2%
highest 10%: 30.1% (1999)
agriculture 60%, industry 15%, services 25% (1999 est.)
gold, cocoa, timber, tuna, bauxite, aluminum, manganese ore,
diamonds
Netherlands 11.2%, UK 10.7%, France 7.7%, Germany 6.2%, Japan
5.2%, Italy 4.6%, Turkey 4.4%, US 4.3% (2003)
10 regions; Ashanti, Brong-Ahafo, Central, Eastern, Greater
Accra, Northern, Upper East, Upper West, Volta, Western
cocoa, rice, coffee, cassava (tapioca), peanuts, corn, shea
nuts, bananas; timber
12 (2003 est.)
24.9 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $1.943 billion
expenditures: $2.192 billion, including capital expenditures of NA
(2003 est.)
Well endowed with natural resources, Ghana has roughly twice
the per capita output of the poorer countries in West Africa. Even
so, Ghana remains heavily dependent on international financial and
technical assistance. Gold, timber, and cocoa production are major
sources of foreign exchange. The domestic economy continues to
revolve around subsistence agriculture, which accounts for 35% of
GDP and employs 60% of the work force, mainly small landholders.
Ghana opted for debt relief under the Heavily Indebted Poor Country
(HIPC) program in 2002. Policy priorities include tighter monetary
and fiscal policies, accelerated privatization, and improvement of
social services. Receipts from the gold sector should help sustain
GDP growth in 2004. Inflation should ease, but remain a major
internal problem.
refined products 74 km (2004)','cb8b3c6cdb81775e3614e73766667d73cf1b8f5f4e10fe421c95240172635038','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d44f67882ebe039538472a95fa515a64ad20baddb956fdbe3430fff357466fc',2004,'GI','Gibraltar','economy',708,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
limited natural freshwater resources: large concrete or
natural rock water catchments collect rainwater (no longer used for
drinking water) and adequate desalination plant
Glorioso Islands
NA
100 million kWh (2001)
93 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture negligible, industry 40%, services 60%
(principally reexports) petroleum 51%, manufactured goods
41%, other 8%
Germany 25.6%, France 24.8%, UK 14.3%, Turkmenistan 9.4%,
Switzerland 7.5%, Spain 5.6% (2003)
none (overseas territory of the UK)
none
1 (2003 est.)
Glorioso Islands
1 (2003 est.)
10.99 births/1,000 population (2004 est.)
Royal Gibraltar Regiment
revenues: $307 million
expenditures: $284 million, including capital expenditures of NA
(FY00/01 est.)
Gibraltar benefits from an extensive shipping trade,
offshore banking, and its position as an international conference
center. The British military presence has been sharply reduced and
now contributes about 7% to the local economy, compared with 60% in
1984. The financial sector, tourism (almost 5 million visitors in
1998), shipping services fees, and duties on consumer goods also
generate revenue. The financial sector, the shipping sector, and
tourism each contribute 25%-30% of GDP. Telecommunications accounts
for another 10%. In recent years, Gibraltar has seen major
structural change from a public to a private sector economy, but
changes in government spending still have a major impact on the
level of employment.
Glorioso Islands
no economic activity','e7621d8a92757eb4f2107262d9236075007660c54facf1497d8ab80ef4edf6c9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92f9bb6960ce8b3f34fb11ab5855d0708724736dccc3d4778bdf0b43dbb54058',2004,'GR','Greece','economy',709,'total: 66
over 3,047 m: 5
2,438 to 3,047 m: 16
1,524 to 2,437 m: 20
914 to 1,523 m: 16
under 914 m: 9 (2004 est.)
total: 14
914 to 1,523 m: 3
under 914 m: 11 (2004 est.)
air pollution; water pollution
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds
4.3% (2003)
49.79 billion kWh (2001)
48.8 billion kWh (2001)
3.562 billion kWh (2001)
1.062 billion kWh (2001)
NA
lowest 10%: 3%
highest 10%: 25.3% (1993 est.)
agriculture 20%, industry 20%, services 60% (2000 est.)
food and beverages, manufactured goods, petroleum products,
chemicals, textiles
Germany 12.6%, Italy 10.5%, UK 7%, US 6.5%, Bulgaria 6.2%,
Cyprus 4.8%, France 4.2%, Turkey 4% (2003)
51 prefectures (nomoi, singular - nomos) and 1 autonomous
region*; Agion Oros* (Mt. Athos), Achaia, Aitolia kai Akarmania,
Argolis, Arkadia, Arta, Attiki, Chalkidiki, Chanion, Chios,
Dodekanisos, Drama, Evros, Evrytania, Evvoia, Florina, Fokidos,
Fthiotis, Grevena, Ileia, Imathia, Ioannina, Irakleion, Karditsa,
Kastoria, Kavala, Kefallinia, Kerkyra, Kilkis, Korinthia, Kozani,
Kyklades, Lakonia, Larisa, Lasithi, Lefkas, Lesvos, Magnisia,
Messinia, Pella, Pieria, Preveza, Rethynnis, Rodopi, Samos, Serrai,
Thesprotia, Thessaloniki, Trikala, Voiotia, Xanthi, Zakynthos
wheat, corn, barley, sugar beets, olives, tomatoes, wine,
tobacco, potatoes; beef, dairy products
79 (note - new Athens airport at Spata opened in March 2001)
(2003 est.)
9.73 births/1,000 population (2004 est.)
Hellenic Army, Hellenic Navy, Hellenic Air Force (EPA),
National Guard
revenues: $76.84 billion
expenditures: $79.48 billion, including capital expenditures of NA
(2003 est.)
Greece has a mixed capitalist economy with the public sector
accounting for about 40% of GDP and with per capita GDP 70% of the
leading euro-zone economies. Tourism provides 15% of GDP. Immigrants
make up nearly one-fifth of the work force, mainly in menial jobs.
Greece is a major beneficiary of EU aid, equal to about 3.3% of
annual GDP. The Greek economy grew by about 4.0% for the past two
years, largely because of an investment boom and infrastructure
upgrades for the 2004 Athens Olympic Games. Despite strong growth,
Greece has failed to meet the EU''s Growth and Stability Pact budget
deficit criteria of 3% of GDP since 2000; public debt, inflation,
and unemployment are also above the eurozone average. Further
restructuring of the economy include privatizing several state
enterprises, undertaking pension and other reforms, and minimizing
bureaucratic inefficiencies.
gas 1,166 km; oil 94 km (2004)','b45e8a7030309a3307e955b906853d8e7a3702a249fc106086bfee1b44c2d386','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d4fced802e07fa773eb05960e76d821e542de7f918d97de815e1c99c7fad1a2',2004,'GL','Greenland','economy',710,'total: 9
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 5 (2004 est.)
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
protection of the arctic environment; preservation of the
Inuit traditional way of life, including whaling and seal hunting
245 million kWh (2001)
227.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
fish and fish products 94% (prawns 63%)
Denmark 64.7%, Japan 14.2%, China 4.4% (2003)
3 districts (landsdele); Avannaa (Nordgronland), Tunu
(Ostgronland), Kitaa (Vestgronland)
note: there are 18 municipalities in Greenland
forage crops, garden and greenhouse vegetables; sheep,
reindeer; fish
14 (2003 est.)
15.96 births/1,000 population (2004 est.)
revenues: $646 million
expenditures: $629 million, including capital expenditures of $85
million (1999)
The economy remains critically dependent on exports of
fish and substantial support from the Danish Government, which
supplies about half of government revenues. The public sector,
including publicly-owned enterprises and the municipalities, plays
the dominant role in the economy. Despite several interesting
hydrocarbon and minerals exploration activities, it will take
several years before production can materialize. Tourism is the only
sector offering any near-term potential, and even this is limited
due to a short season and high costs.','fa71ed6d4fd4d205dfdc6b523d914b66642ef9bac8c6ae3b6a44c6fbc5abeb7d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1881c7644a699157be8e59a4cf04341434ba651888b941ccede1fcfd65fc7d65',2004,'GD','Grenada','economy',711,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
NA
138 million kWh (2001)
128.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
32% (2000)
lowest 10%: NA
highest 10%: NA
agriculture 24%, industry 14%, services 62% (1999 est.)
bananas, cocoa, nutmeg, fruit and vegetables, clothing, mace
US 14.9%, Germany 12.8%, Netherlands 8.5%, Saint Lucia 8.5%,
Antigua and Barbuda 6.4%, UK 6.4%, Belgium 4.3%, Dominica 4.3%,
France 4.3%, Saint Kitts and Nevis 4.3%, Trinidad and Tobago 4.3%
(2003)
6 parishes and 1 dependency*; Carriacou and Petit
Martinique*, Saint Andrew, Saint David, Saint George, Saint John,
Saint Mark, Saint Patrick
bananas, cocoa, nutmeg, mace, citrus, avocados, root crops,
sugarcane, corn, vegetables
3 (2003 est.)
22.61 births/1,000 population (2004 est.)
no regular military forces; Royal Grenada Police Force
revenues: $85.8 million
expenditures: $102.1 million, including capital expenditures of $28
million (1997)
Grenada relies on tourism as its main source of foreign
exchange, especially since the construction of an international
airport in 1985. Strong performances in construction and
manufacturing, together with the development of an offshore
financial industry, have also contributed to growth in national
output.','bdb96ba1a9ba2edef4ff8f0878e5dab94334fa92a22e0c7c645e77081da3a25e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2648c9ca70a5ea8106cc2153eefe817b78c18e88b66a5c99854dc0e8a08ccdc0',2004,'GP','Guadeloupe','economy',712,'total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
NA
1.155 billion kWh (2001)
1.074 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
NA
bananas, sugar, rum
France 60%, Martinique 18%, US 4% (1999)
none (overseas department of France)
bananas, sugarcane, tropical fruits and vegetables;
cattle, pigs, goats
9 (2003 est.)
15.79 births/1,000 population (2004 est.)
no regular military forces
revenues: $225 million
expenditures: $390 million, including capital expenditures of $105
million (1996)
The Caribbean economy depends on agriculture, tourism,
light industry, and services. It also depends on France for large
subsidies and imports. Tourism is a key industry, with most tourists
from the US; an increasingly large number of cruise ships visit the
islands. The traditional sugarcane crop is slowly being replaced by
other crops, such as bananas (which now supply about 50% of export
earnings), eggplant, and flowers. Other vegetables and root crops
are cultivated for local consumption, although Guadeloupe is still
dependent on imported food, mainly from France. Light industry
features sugar and rum production. Most manufactured goods and fuel
are imported. Unemployment is especially high among the young.
Hurricanes periodically devastate the economy.','e1f666ad1e382d177c20805966ee15adc77684e4281d45994b6b983e960d737a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90469af18c8cda5ed5e1c6a56301d5f2f7764b44e08262ffbce3cb59c722200',2004,'GU','Guam','economy',713,'total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
extirpation of native bird population by the rapid
proliferation of the brown tree snake, an exotic, invasive species
830 million kWh (2001)
771.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
23% (2001 est.)
lowest 10%: NA
highest 10%: NA
private 74% (industry 10%, trade 24%, other services 40%),
federal and territorial government 26% (2000 est.)
mostly transshipments of refined petroleum products;
construction materials, fish, food and beverage products
Japan 70.1%, South Korea 17.9%, Singapore 6% (2003)
none (territory of the US)
fruits, copra, vegetables; eggs, pork, poultry, beef
5 (2003 est.)
19.31 births/1,000 population (2004 est.)
revenues: $340 million
expenditures: $445 million, including capital expenditures of NA
(2000 est.)
The economy depends on US military spending, tourism, and the
export of fish and handicrafts. Total US grants, wage payments, and
procurement outlays amounted to $1 billion in 1998. Over the past 20
years, the tourist industry has grown rapidly, creating a
construction boom for new hotels and the expansion of older ones.
More than 1 million tourists visit Guam each year. The industry had
recently suffered setbacks because of the continuing Japanese
slowdown; the Japanese normally make up almost 90% of the tourists.
Most food and industrial goods are imported. Guam faces the problem
of building up the civilian economic sector to offset the impact of
military downsizing.','37e552f840db861d931037257f44c2d0362bcb51e02269ccb759eb5582bc5b37','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48e6a73d9223fa1ace47ac6cf9e7a2cf05c768f2b4f0e79cbd820b73f5282e12',2004,'GT','Guatemala','economy',714,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (2004 est.)
total: 441
2,438 to 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 109
under 914 m: 323 (2004 est.)
deforestation in the Peten rainforest; soil erosion; water
pollution
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.8% (2003)
6.237 billion kWh (2001)
5.559 billion kWh (2001)
95 million kWh (2001)
336 million kWh (2001)
75% (2002 est.)
lowest 10%: 1.6%
highest 10%: 46% (1998)
agriculture 50%, industry 15%, services 35% (1999 est.)
coffee, sugar, bananas, fruits and vegetables, cardamom,
meat, apparel, petroleum, electricity
US 56.7%, El Salvador 10.8%, Nicaragua 3.6% (2003)
22 departments (departamentos, singular - departamento);
Alta Verapaz, Baja Verapaz, Chimaltenango, Chiquimula, El Progreso,
Escuintla, Guatemala, Huehuetenango, Izabal, Jalapa, Jutiapa, Peten,
Quetzaltenango, Quiche, Retalhuleu, Sacatepequez, San Marcos, Santa
Rosa, Solola, Suchitepequez, Totonicapan, Zacapa
sugarcane, corn, bananas, coffee, beans, cardamom; cattle,
sheep, pigs, chickens
452 (2003 est.)
34.58 births/1,000 population (2004 est.)
Army, Navy (includes Marines), Air Force
revenues: $2.741 billion
expenditures: $3.316 billion, including capital expenditures of $750
million (2003 est.)
Guatemala is the largest and most populous of the Central
American countries with a GDP per capita roughly one-half that of
Brazil, Argentina, and Chile. The agricultural sector accounts for
about one-fourth of GDP, two-thirds of exports, and half of the
labor force. Coffee, sugar, and bananas are the main products. The
1996 signing of peace accords, which ended 36 years of civil war,
removed a major obstacle to foreign investment, but widespread
political violence and corruption scandals continue to dampen
investor confidence. The distribution of income remains highly
unequal, with perhaps 75% of the population below the poverty line.
Ongoing challenges include increasing government revenues,
negotiating further assistance from international donors, upgrading
both government and private financial operations, curtailing drug
trafficking, and narrowing the trade deficit.
oil 480 km (2004)','296986dade80c6109faacfa164f98ac561ad9543226b54b5d020b0543b470115','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1cacdf38b0698d95d9752a631757dee5f1a34cb398c0a92c5eb49597c963d25',2004,'GG','Guernsey','economy',715,'total: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
NA
NA kWh
NA kWh
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
tomatoes, flowers and ferns, sweet peppers, eggplant, other
vegetables
UK (regarded as internal trade)
none (British crown dependency); there are no first-order
administrative divisions as defined by the US Government, but there
are 10 parishes including Saint Peter Port, Saint Sampson, Vale,
Castel, Saint Saviour, Saint Pierre du Bois, Torteval, Forest, Saint
Martin, Saint Andrew
tomatoes, greenhouse flowers, sweet peppers, eggplant,
fruit; Guernsey cattle
2 (2003 est.)
9.16 births/1,000 population (2004 est.)
revenues: $381.3 million
expenditures: $368.8 million, including capital expenditures of NA
(2000 est.)
Financial services - banking, fund management, insurance,
etc. - account for about 55% of total income in this tiny Channel
Island economy. Tourism, manufacturing, and horticulture, mainly
tomatoes and cut flowers, have been declining. Light tax and death
duties make Guernsey a popular tax haven. The evolving economic
integration of the EU nations is changing the environment under
which Guernsey operates.','872b994ea855ac7ee3bffe8dddfe066f292d8c2b1525cb47458b9d294576ffdb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd1e5d59fd0168278c4826b74eb7791b3a4e50d1a30aa75797eaf93eb2a58559',2004,'GN','Guinea','economy',716,'total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2004 est.)
total: 11
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
deforestation; inadequate supplies of potable water;
desertification; soil contamination and erosion; overfishing,
overpopulation in forest region; poor mining practices have led to
environmental damage
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.7% (2003)
790.6 million kWh (2001)
735.2 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
40% (2003 est.)
lowest 10%: 2.6%
highest 10%: 32% (1994)
agriculture 80%, industry and services 20% (2000 est.)
bauxite, alumina, gold, diamonds, coffee, fish, agricultural
products
South Korea 14.8%, Spain 10.7%, US 10.1%, France 9.2%, Russia
9%, Ireland 7.9%, Belgium 6.4%, Germany 5.6%, Ukraine 5.3% (2003)
33 prefectures and 1 special zone (zone special)*; Beyla,
Boffa, Boke, Conakry*, Coyah, Dabola, Dalaba, Dinguiraye, Dubreka,
Faranah, Forecariah, Fria, Gaoual, Gueckedou, Kankan, Kerouane,
Kindia, Kissidougou, Koubia, Koundara, Kouroussa, Labe, Lelouma,
Lola, Macenta, Mali, Mamou, Mandiana, Nzerekore, Pita, Siguiri,
Telimele, Tougue, Yomou
rice, coffee, pineapples, palm kernels, cassava (tapioca),
bananas, sweet potatoes; cattle, sheep, goats; timber
16 (2003 est.)
42.26 births/1,000 population (2004 est.)
Army, Navy, Air Force, Republican Guard, Presidential Guard,
National Gendarmerie, General Directorate of National Police
revenues: $410.7 million
expenditures: $708.5 million, including capital expenditures of $NA
million (2003 est.)
Guinea possesses major mineral, hydropower, and agricultural
resources, yet remains an underdeveloped nation. The country
possesses over 30% of the world''s bauxite reserves and is the
second-largest bauxite producer. The mining sector accounted for
about 75% of exports in 1999. Long-run improvements in government
fiscal arrangements, literacy, and the legal framework are needed if
the country is to move out of poverty. Fighting along the Sierra
Leonean and Liberian borders, as well as refugee movements, have
caused major economic disruptions, including a loss in investor
confidence. Foreign mining companies have reduced expatriate staff,
while panic buying has created food shortages and inflation in local
markets. Guinea is not receiving multilateral aid. The IMF and World
Bank cut off most assistance in 2003. Growth should strengthen in
2004, however, because of a slowly improving security situation and
increased investor confidence.','63733ec962ed83502ae5a863b02c52fd6bd3183dc067d20a4826bd23ab2454f8','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9168618b620cdb00bd21a030bb2d64d83791216ba2d9ffa0769724d8f490d56a',2004,'GW','Guinea-Bissau','economy',717,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 25
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 20 (2004 est.)
deforestation; soil erosion; overgrazing; overfishing
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Wetlands
signed, but not ratified: none of the selected agreements
2.8% (2003)
55 million kWh (2001)
51.15 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: 0.5%
highest 10%: 42.4% (1991)
agriculture 82% (2000 est.)
cashew nuts, shrimp, peanuts, palm kernels, sawn lumber
India 76.8%, Nigeria 12.1%, Italy 5.1% (2003)
9 regions (regioes, singular - regiao); Bafata,
Biombo, Bissau, Bolama, Cacheu, Gabu, Oio, Quinara, Tombali; note -
Bolama may have been renamed Bolama/Bijagos
rice, corn, beans, cassava (tapioca), cashew nuts,
peanuts, palm kernels, cotton; timber; fish
28 (2003 est.)
38.03 births/1,000 population (2004 est.)
People''s Revolutionary Armed Force (FARP; includes
Army, Navy, and Air Force), paramilitary force
revenues: NA
expenditures: NA, including capital expenditures of NA
One of the 10 poorest countries in the world,
Guinea-Bissau depends mainly on farming and fishing. Cashew crops
have increased remarkably in recent years, and the country now ranks
sixth in cashew production. Guinea-Bissau exports fish and seafood
along with small amounts of peanuts, palm kernels, and timber. Rice
is the major crop and staple food. However, intermittent fighting
between Senegalese-backed government troops and a military junta
destroyed much of the country''s infrastructure and caused widespread
damage to the economy in 1998; the civil war led to a 28% drop in
GDP that year, with partial recovery in 1999-2002. Before the war,
trade reform and price liberalization were the most successful part
of the country''s structural adjustment program under IMF
sponsorship. The tightening of monetary policy and the development
of the private sector had also begun to reinvigorate the economy.
Because of high costs, the development of petroleum, phosphate, and
other mineral resources is not a near-term prospect. However,
unexploited offshore oil reserves could provide much-needed revenue
in the long run. The inequality of income distribution is one of the
most extreme in the world. The government and international donors
continue to work out plans to forward economic development from a
lamentably low base. Government drift and indecision, however, have
resulted in low growth in 2002-03 and dim prospects for 2004.','6100229374323741a6f9c5c5771b44282b922ee68c66d630ac262368a287ceb2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1431d9b28be11b812c92f6c05235dfb3d3492066d258da6b007f76d42e07aa7',2004,'GY','Guyana','economy',718,'total: 8
1,524 to 2,437 m: 3
under 914 m: 5 (2004 est.)
total: 41
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 32 (2004 est.)
water pollution from sewage and agricultural and industrial
chemicals; deforestation
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
0.8% (2003)
852 million kWh (2001)
792.4 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
sugar, gold, bauxite/alumina, rice, shrimp, molasses, rum,
timber
Canada 23.2%, US 21.8%, UK 13.5%, Portugal 6.7%, Belgium
6.5%, Jamaica 6.1% (2003)
10 regions; Barima-Waini, Cuyuni-Mazaruni, Demerara-Mahaica,
East Berbice-Corentyne, Essequibo Islands-West Demerara,
Mahaica-Berbice, Pomeroon-Supenaam, Potaro-Siparuni, Upper
Demerara-Berbice, Upper Takutu-Upper Essequibo
sugar, rice, wheat, vegetable oils; beef, pork, poultry,
dairy products; fish (shrimp)
49 (2003 est.)
17.85 births/1,000 population (2004 est.)
Guyana Defense Force: Ground Forces, Coast Guard, Air Corps;
Guyana People''s Militia
revenues: $263.4 million
expenditures: $326.7 million, including capital expenditures of
$93.4 million (2003)
The Guyanese economy exhibited moderate economic growth in
2001-02, based on expansion in the agricultural and mining sectors,
a more favorable atmosphere for business initiatives, a more
realistic exchange rate, fairly low inflation, and the continued
support of international organizations. Growth then slowed in 2003.
Chronic problems include a shortage of skilled labor and a deficient
infrastructure. The government is juggling a sizable external debt
against the urgent need for expanded public investment. The bauxite
mining sector should benefit in the near term by restructuring and
partial privatization.','08dc03ebae40e1215ddbfed4e553480c0ed78c0132e88e04a5ec2fd297b8dc0d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c30ea262d3343198752c3d648767b71a7fa73679065f2aabab2ffd6ba3be48f',2004,'HT','Haiti','economy',719,'total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2004 est.)
total: 9
914 to 1,523 m: 4
under 914 m: 5 (2004 est.)
extensive deforestation (much of the remaining forested land
is being cleared for agriculture and used as fuel); soil erosion;
inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection
signed, but not ratified: Hazardous Wastes
Holy See (Vatican City)
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental Modification
0.9% (2003)
580 million kWh (2001)
Holy See (Vatican City)
NA kWh
539.4 million kWh (2001)
Holy See (Vatican City)
NA kWh
0 kWh (2001)
Holy See (Vatican City)
NA kWh; note - electricity supplied by Italy
0 kWh (2001)
Holy See (Vatican City)
0 kWh
80% (2003 est.)
Holy See (Vatican City)
NA
lowest 10%: NA
highest 10%: NA
Holy See (Vatican City)
lowest 10%: NA
highest 10%: NA
agriculture 66%, industry 9%, services 25%
Holy See (Vatican City)
essentially services with a small amount of
industry; note - dignitaries, priests, nuns, guards, and 3,000 lay
workers live outside the Vatican
manufactures, coffee, oils, cocoa
US 83.8%, Dominican Republic 6.5%, Canada 3.2% (2003)
9 departments (departements, singular - departement);
Artibonite, Centre, Grand ''Anse, Nord, Nord-Est, Nord-Ouest, Ouest,
Sud, Sud-Est
Holy See (Vatican City)
none
coffee, mangoes, sugarcane, rice, corn, sorghum, wood
12 (2003 est.)
Holy See (Vatican City)
none (2003 est.)
33.76 births/1,000 population (2004 est.)
Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force have been
demobilized but still exist on paper until or unless they are
constitutionally abolished
Holy See (Vatican City)
Swiss Guards Corps (Corpo della Guardia
Svizzera)
revenues: $231.6 million
expenditures: $366.7 million, including capital expenditures of NA
(2003 est.)
Holy See (Vatican City)
revenues: $245.2 million
expenditures: $260.4 million, including capital expenditures of NA
(2002)
In this poorest country in the Western Hemisphere, 80% of the
population lives in abject poverty. Two-thirds of all Haitians
depend on the agriculture sector, which consists mainly of
small-scale subsistence farming. Following legislative elections in
May 2000, fraught with irregularities, international donors -
including the US and EU - suspended almost all aid to Haiti. The
economy shrank an estimated 1.2% in 2001 and an estimated 0.9% in
2002. Suspended aid and loan disbursements totaled more than $500
million at the start of 2003. Haiti also suffers from rampant
inflation, a lack of investment, and a severe trade deficit. The
resumption of aid flows from all donors will alleviate but not end
the nation''s bitter economic problems. Extensive civil strife in
early 2004, marked by the flight of President ARISTIDE, further
impoverished Haiti.','c434c9cbc7a8e8cefbd2371d0227393f7c1be05fa25c0b782e1734d82f8a0f92','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f86b6b8e9691ee4eab4e03e5e1f4851bba82b555ecce147ef715017dd8b30620',2004,'HN','Honduras','economy',720,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2004 est.)
total: 104
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 84 (2004 est.)
urban population expanding; deforestation results from
logging and the clearing of land for agricultural purposes; further
land degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as farming of
marginal lands; mining activities polluting Lago de Yojoa (the
country''s largest source of fresh water), as well as several rivers
and streams, with heavy metals
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
1.5% (2003)
3.778 billion kWh (2001)
3.822 billion kWh (2001)
308 million kWh (2001)
0 kWh (2001)
53% (1993 est.)
lowest 10%: 0.6%
highest 10%: 42.7% (1998)
agriculture 34%, industry 21%, services 45% (2001 est.)
coffee, bananas, shrimp, lobster, meat; zinc, lumber (2000)
US 65.5%, El Salvador 3.5%, Guatemala 2.4% (2003)
18 departments (departamentos, singular - departamento);
Atlantida, Choluteca, Colon, Comayagua, Copan, Cortes, El Paraiso,
Francisco Morazan, Gracias a Dios, Intibuca, Islas de la Bahia, La
Paz, Lempira, Ocotepeque, Olancho, Santa Barbara, Valle, Yoro
bananas, coffee, citrus; beef; timber; shrimp
115 (2003 est.)
31.04 births/1,000 population (2004 est.)
Army, Navy (including Naval Infantry), Air Force
revenues: $1.342 billion
expenditures: $1.744 billion, including capital expenditures of $106
million (2003)
Honduras, one of the poorest countries in the Western
Hemisphere with an extraordinarily unequal distribution of income
and massive unemployment, is banking on expanded trade privileges
under the Enhanced Caribbean Basin Initiative and on debt relief
under the Heavily Indebted Poor Countries (HIPC) initiative. While
the country has met most of its macroeconomic targets, it has failed
to meet the IMF''s goals to liberalize its energy and
telecommunications sectors. Growth remains dependent on the status
of the US economy, its major trading partner, on commodity prices,
particularly coffee, and on reduction of the high crime rate.','3e8eecc54d8d5b6c467d9a3ba15488b1f39ebc4bce82c74b6b473fdc98d4176e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba62964c59200e1b6cde157ecbc3d515030c1ca2fdb693978bf663316ae702d',2004,'HK','Hong Kong','economy',721,'total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1523 m: 1
under 914 m: 1 (2004 est.)
air and water pollution from rapid urbanization
Howland Island
no natural fresh water resources
party to: Marine Dumping (associate member)
NA (FY02)
30.48 billion kWh (2001)
37.12 billion kWh (2001)
10.36 billion kWh (2001)
1.581 billion kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
manufacturing 8.2%, construction 2.9%, wholesale and
retail trade, restaurants, and hotels 43.5%, financing, insurance,
and real estate 19.5%, transport and communications 7.8%, community
and social services 17.8% (Note: above data exclude public sector)
(2002 est.)
electrical machinery and appliances, textiles, apparel,
footwear, watches and clocks, toys, plastics, precious stones
China 42.6%, US 18.7%, Japan 5.4% (2003)
none (special administrative region of China)
fresh vegetables, poultry, fish, pork
4 (2003 est.)
Howland Island
airstrip constructed in 1937 for scheduled refueling
stop on the round-the-world flight of Amelia EARHART and Fred NOONAN
- they left Lae, New Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable (2003 est.)
7.23 births/1,000 population (2004 est.)
no regular indigenous military forces; Hong Kong garrison
of China''s People''s Liberation Army (PLA) including elements of the
PLA Ground Forces, PLA Navy, and PLA Air Force; these forces are
under the direct leadership of the Central Military Commission in
Beijing and under administrative control of the adjacent Guangzhou
Military Region
revenues: $26.17 billion
expenditures: $32.64 billion, including capital expenditures of $5
billion (2003)
Hong Kong has a free market economy highly dependent on
international trade. Natural resources are limited, and food and raw
materials must be imported. Imports and exports, including
reexports, each exceed GDP in dollar value. Even before Hong Kong
reverted to Chinese administration on 1 July 1997 it had extensive
trade and investment ties with China. Hong Kong has been further
integrating its economy with China because China''s growing openness
to the world economy has increased competitive pressure on Hong
Kong''s service industries, and Hong Kong''s re-export business from
China is a major driver of growth. Per capita GDP compares with the
level in the four big economies of Western Europe. GDP growth
averaged a strong 5% in 1989-1997, but Hong Kong suffered two
recessions in the past 6 years because of the Asian financial crisis
in 1998 and the global downturn of 2001-2002. The Severe Acute
Respiratory Syndrome (SARS) outbreak also battered Hong Kong''s
economy, but a boom in tourism from the mainland because of China''s
easing of travel restrictions, a return of consumer confidence, and
a solid rise in exports resulted in the resumption of strong growth
in late 2003.
Howland Island
no economic activity','a24d4a467c6779f59e480750c656e2e9df2f2c6218f80bc215a5e260475e8138','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('269db535150fe6c3324751cf7c29d1699a4ed1ad7943a55c5f18d629a769580f',2004,'HU','Hungary','economy',722,'total: 18
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
total: 26
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 11
under 914 m: 9 (2004 est.)
the upgrading of Hungary''s standards in waste management,
energy efficiency, and air, soil, and water pollution with
environmental requirements for EU accession will require large
investments
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulfur 94
1.75% (2002 est.)
34.39 billion kWh (2001)
35.15 billion kWh (2001)
10.43 billion kWh (2001)
7.261 billion kWh (2001)
8.6% (1993 est.)
lowest 10%: 4.1%
highest 10%: 20.5% (1998)
agriculture 8%, industry 27%, services 65% (1996)
machinery and equipment 57.6%, other manufactures 31.0%,
food products 7.5%, raw materials 1.9%, fuels and electricity 1.9%
(2001)
Germany 34.1%, Austria 8%, Italy 5.8%, France 5.7%, UK 4.5%,
Netherlands 4.1% (2003)
19 counties (megyek, singular - megye), 20 urban counties
(singular - megyei varos), and 1 capital city (fovaros)
counties: Bacs-Kiskun, Baranya, Bekes, Borsod-Abauj-Zemplen,
Csongrad, Fejer, Gyor-Moson-Sopron, Hajdu-Bihar, Heves,
Jasz-Nagykun-Szolnok, Komarom-Esztergom, Nograd, Pest, Somogy,
Szabolcs-Szatmar-Bereg, Tolna, Vas, Veszprem, Zala
urban counties: Bekescsaba, Debrecen, Dunaujvaros, Eger, Gyor,
Hodmezovasarhely, Kaposvar, Kecskemet, Miskolc, Nagykanizsa,
Nyiregyhaza, Pecs, Sopron, Szeged, Szekesfehervar, Szolnok,
Szombathely, Tatabanya, Veszprem, Zalaegerszeg
capital city: Budapest
wheat, corn, sunflower seed, potatoes, sugar beets; pigs,
cattle, poultry, dairy products
43 (2003 est.)
9.77 births/1,000 population (2004 est.)
Ground Forces, Air Forces
revenues: $35 billion
expenditures: $39.88 billion, including capital expenditures of NA
(2003 est.)
Hungary has made the transition from a centrally planned to
a market economy, with a per capita income one-half that of the Big
Four European nations. Hungary continues to demonstrate strong
economic growth and joined the European Union in May 2004. The
private sector accounts for over 80% of GDP. Foreign ownership of
and investment in Hungarian firms are widespread, with cumulative
foreign direct investment totaling more than $23 billion since 1989.
Hungarian sovereign debt was upgraded in 2000 to the second-highest
rating among all the Central European transition economies.
Inflation has declined substantially, from 14% in 1998 to 4.7% in
2003; unemployment has persisted around the 6% level. Germany is by
far Hungary''s largest economic partner. Short-term issues include
the reduction of the public sector deficit and further increasing
the flexibility of the labor markets.
gas 4,397 km; oil 990 km; refined products 335 km (2004)','dc9bd7af07843e92efaedcad04fd50afa72c12dbe46af907220eea1ec16edc57','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba1dc89fc8bf31111525fa533490993d33aa973663531751afcc0c4080736049',2004,'IS','Iceland','economy',723,'total: 5
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2004 est.)
total: 93
1,524 to 2,437 m: 3
914 to 1,523 m: 29
under 914 m: 61 (2004 est.)
water pollution from fertilizer runoff; inadequate
wastewater treatment
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Kyoto Protocol, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Transboundary Air Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Environmental Modification, Marine Life Conservation
7.894 billion kWh (2001)
7.341 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 5.1%, fishing and fish processing 11.8%,
manufacturing 12.9%, construction 10.7%, services 59.5% (1999)
fish and fish products 70%, animal products, aluminum,
diatomite, ferrosilicon
Germany 17.4%, UK 17.4%, Netherlands 11.2%, US 9.8%, Spain
6.3%, Denmark 5%, Norway 4.5%, France 4% (2003)
8 regions; Austurland, Hofudhborgarsvaedhi, Nordhurland
Eystra, Nordhurland Vestra, Sudhurland, Sudhurnes, Vestfirdhir,
Vesturland
potatoes, green vegetables, mutton, dairy products, fish
100 (2003 est.)
13.83 births/1,000 population (2004 est.)
no regular armed forces; Police, Coast Guard
revenues: $4.205 billion
expenditures: $4.405 billion, including capital expenditures of $467
million (2003)
Iceland''s Scandinavian-type economy is basically
capitalistic, yet with an extensive welfare system (including
generous housing subsidies), low unemployment, and remarkably even
distribution of income. In the absence of other natural resources
(except for abundant geothermal power), the economy depends heavily
on the fishing industry, which provides 70% of export earnings and
employs 12% of the work force. The economy remains sensitive to
declining fish stocks as well as to fluctuations in world prices for
its main exports: fish and fish products, aluminum, and
ferrosilicon. Government policies include reducing the budget and
current account deficits, limiting foreign borrowing, containing
inflation, revising agricultural and fishing policies, diversifying
the economy, and privatizing state-owned industries. The government
remains opposed to EU membership, primarily because of Icelanders''
concern about losing control over their fishing resources. Iceland''s
economy has been diversifying into manufacturing and service
industries in the last decade, and new developments in software
production, biotechnology, and financial services are taking place.
The tourism sector is also expanding, with the recent trends in
ecotourism and whale watching. Growth had been remarkably steady in
1996-2001 at 3%-5%, but could not be sustained in 2002 in an
environment of global recession. Growth resumed in 2003, and
inflation dropped back from 5% to 2%.','8c4ee8a2ecd17349a362030856244c6f095404e73d2b6a3b60b7e9a335f2f643','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d6a44962f3cb2e7f291ede8b1a114138a6045108a844b850d580db27ff3f6b9',2004,'IN','India','economy',724,'total: 234
over 3,047 m: 14
2,438 to 3,047 m: 47
1,524 to 2,437 m: 78
914 to 1,523 m: 74
under 914 m: 21 (2004 est.)
total: 99
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
914 to 1,523 m: 42
under 914 m: 45 (2004 est.)
deforestation; soil erosion; overgrazing; desertification; air
pollution from industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural pesticides; tap
water is not potable throughout the country; huge and growing
population is overstraining natural resources
Indian Ocean
endangered marine species include the dugong, seals,
turtles, and whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
2.4% (2003)
533.3 billion kWh (2001)
497.2 billion kWh (2001)
1.54 billion kWh (2001)
321 million kWh (2001)
25% (2002 est.)
lowest 10%: 3.5%
highest 10%: 33.5% (1997)
agriculture 60%, industry 17%, services 23% (1999)
textile goods, gems and jewelry, engineering goods, chemicals,
leather manufactures
US 20.6%, China 6.4%, UK 5.3%, Hong Kong 4.8%, Germany 4.4%
(2003)
28 states and 7 union territories*; Andaman and Nicobar
Islands*, Andhra Pradesh, Arunachal Pradesh, Assam, Bihar,
Chandigarh*, Chhattisgarh, Dadra and Nagar Haveli*, Daman and Diu*,
Delhi*, Goa, Gujarat, Haryana, Himachal Pradesh, Jammu and Kashmir,
Jharkhand, Karnataka, Kerala, Lakshadweep*, Madhya Pradesh,
Maharashtra, Manipur, Meghalaya, Mizoram, Nagaland, Orissa,
Pondicherry*, Punjab, Rajasthan, Sikkim, Tamil Nadu, Tripura,
Uttaranchal, Uttar Pradesh, West Bengal
rice, wheat, oilseed, cotton, jute, tea, sugarcane, potatoes;
cattle, water buffalo, sheep, goats, poultry; fish
333 (2003 est.)
22.8 births/1,000 population (2004 est.)
Army, Navy (including naval air arm), Air Force, Coast Guard,
various security or paramilitary forces (including Border Security
Force, Assam Rifles, National Security Guards, Indo-Tibetan Border
Police, Special Frontier Force, Central Reserve Police Force,
Central Industrial Security Force, Railway Protection Force, and
Defense Security Corps)
revenues: $86.69 billion
expenditures: $114.6 billion, including capital expenditures of
$13.5 billion (2003)
India''s economy encompasses traditional village farming,
modern agriculture, handicrafts, a wide range of modern industries,
and a multitude of support services. Government controls have been
reduced on foreign trade and investment, and privatization of
domestic output has proceeded slowly. The economy has posted an
excellent average growth rate of 6% since 1990, reducing poverty by
about 10 percentage points. India is capitalizing on its large
numbers of well-educated people skilled in the English language to
become a major exporter of software services and software workers.
Despite strong growth, the World Bank and others worry about the
continuing public-sector budget deficit, running at approximately
60% of GDP.
Indian Ocean
The Indian Ocean provides major sea routes connecting
the Middle East, Africa, and East Asia with Europe and the Americas.
It carries a particularly heavy traffic of petroleum and petroleum
products from the oilfields of the Persian Gulf and Indonesia. Its
fish are of great and growing importance to the bordering countries
for domestic consumption and export. Fishing fleets from Russia,
Japan, South Korea, and Taiwan also exploit the Indian Ocean, mainly
for shrimp and tuna. Large reserves of hydrocarbons are being tapped
in the offshore areas of Saudi Arabia, Iran, India, and western
Australia. An estimated 40% of the world''s offshore oil production
comes from the Indian Ocean. Beach sands rich in heavy minerals and
offshore placer deposits are actively exploited by bordering
countries, particularly India, South Africa, Indonesia, Sri Lanka,
and Thailand.
gas 6,171 km; liquid petroleum gas 1,195 km; oil 5,613 km;
refined products 5,567 km (2004)','ceeb9daf0e42740b26e156e6d42e1024d2c3913fc6f0ecb445a2ce3ddeae8943','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df7d3aed24aafeb6111396a68af43f959d56b9c25692e396cb435fabc645dadb',2004,'ID','Indonesia','economy',725,'total: 154
over 3,047 m: 4
2,438 to 3,047 m: 13
1,524 to 2,437 m: 44
914 to 1,523 m: 49
under 914 m: 44 (2004 est.)
Iran
total: 127
over 3,047 m: 39
2,438 to 3,047 m: 25
1,524 to 2,437 m: 26
914 to 1,523 m: 32
under 914 m: 5 (2004 est.)
total: 513
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 27
under 914 m: 480 (2004 est.)
Iran
total: 178
over 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 129
under 914 m: 39 (2004 est.)
deforestation; water pollution from industrial wastes,
sewage; air pollution in urban areas; smoke and haze from forest
fires
Iran
air pollution, especially in urban areas, from vehicle
emissions, refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution in the
Persian Gulf; wetland losses from drought; soil degradation
(salination); inadequate supplies of potable water; water pollution
from raw sewage and industrial waste; urbanization
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Iran
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Ozone Layer
Protection, Wetlands
signed, but not ratified: Environmental Modification, Law of the
Sea, Marine Life Conservation
1.3% (FY98)
Iran
3.3% (2003 est.)
95.78 billion kWh (2001)
Iran
124.6 billion kWh (2001)
89.08 billion kWh (2001)
Iran
115.9 billion kWh (2001)
0 kWh (2001)
Iran
0 kWh (2001)
0 kWh (2001)
Iran
0 kWh (2001)
27% (1999)
Iran
40% (2002 est.)
lowest 10%: 4%
highest 10%: 26.7% (1999)
Iran
lowest 10%: NA
highest 10%: NA
agriculture 45%, industry 16%, services 39% (1999 est.)
Iran
agriculture 30%, industry 25%, services 45% (2001 est.)
oil and gas, electrical appliances, plywood, textiles,
rubber
Iran
petroleum 80%, chemical and petrochemical products, fruits and
nuts, carpets
Japan 22.3%, US 12.1%, Singapore 8.9%, South Korea 7.1%,
China 6.2% (2003)
Iran
Japan 21.8%, China 9.7%, Italy 6.3%, Taiwan 5.5%, Turkey 5.4%,
South Korea 5.4% (2003)
30 provinces (propinsi-propinsi, singular - propinsi), 2
special regions* (daerah-daerah istimewa, singular - daerah
istimewa), and 1 special capital city district** (daerah khusus
ibukota); Aceh*, Bali, Banten, Bengkulu, Gorontalo, Irian Jaya
Barat, Jakarta Raya**, Jambi, Jawa Barat, Jawa Tengah, Jawa Timur,
Kalimantan Barat, Kalimantan Selatan, Kalimantan Tengah, Kalimantan
Timur, Kepulauan Bangka Belitung, Kepulauan Riau, Lampung, Maluku,
Maluku Utara, Nusa Tenggara Barat, Nusa Tenggara Timur, Papua, Riau,
Sulawesi Barat, Sulawesi Selatan, Sulawesi Tengah, Sulawesi
Tenggara, Sulawesi Utara, Sumatera Barat, Sumatera Selatan, Sumatera
Utara, Yogyakarta*; note - with the implementation of
decentralization on 1 January 2001, the 357 districts or regencies
became the key administrative units responsible for providing most
government services
Iran
28 provinces (ostanha, singular - ostan); Ardabil, Azarbayjan-e
Gharbi, Azarbayjan-e Sharqi, Bushehr, Chahar Mahall va Bakhtiari,
Esfahan, Fars, Gilan, Golestan, Hamadan, Hormozgan, Ilam, Kerman,
Kermanshah, Khorasan, Khuzestan, Kohgiluyeh va Buyer Ahmad,
Kordestan, Lorestan, Markazi, Mazandaran, Qazvin, Qom, Semnan,
Sistan va Baluchestan, Tehran, Yazd, Zanjan
rice, cassava (tapioca), peanuts, rubber, cocoa, coffee,
palm oil, copra, poultry, beef, pork, eggs
Iran
wheat, rice, other grains, sugar beets, fruits, nuts, cotton;
dairy products, wool; caviar
661 (2003 est.)
Iran
303 (2003 est.)
21.11 births/1,000 population (2004 est.)
Iran
17.1 births/1,000 population (2004 est.)
Indonesia Armed Forces (TNI): Army (TNI-AD), Navy (TNI-AL,
including Marines, Naval Air arm), Air Force (TNI-AU)
Iran
Islamic Republic of Iran regular forces (includes Ground
Forces, Navy, Air Force and Air Defense Command), Islamic
Revolutionary Guards Corps (IRGC) (includes Ground Forces, Air
Force, Navy, Qods Force [special operations], and Basij [Popular
Mobilization Army]), Law Enforcement Forces
revenues: $40.91 billion
expenditures: $44.95 billion, including capital expenditures of NA
(2003 est.)
Iran
revenues: $40.38 billion
expenditures: $40.29 billion, including capital expenditures of $7.6
billion (2003 est.)
Indonesia, a vast polyglot nation, faces economic
development problems stemming from recent acts of terrorism, unequal
resource distribution among regions, endemic corruption, the lack of
reliable legal recourse in contract disputes, weaknesses in the
banking system, and a generally poor climate for foreign investment.
Indonesia withdrew from its IMF program at the end of 2003, but
issued a "White Paper" that commits the government to maintaining
fundamentally sound macroeconomic policies previously established
under IMF guidelines. Investors, however, continued to face a host
of on-the-ground microeconomic problems and an inadequate judicial
system. Keys to future growth remain internal reform, building up
the confidence of international and domestic investors, and strong
global economic growth.
Iran
Iran''s economy is marked by a bloated, inefficient state
sector, over reliance on the oil sector, and statist policies that
create major distortions throughout. Most economic activity is
controlled by the state. Private sector activity is typically
small-scale - workshops, farming, and services. President KHATAMI
has continued to follow the market reform plans of former President
RAFSANJANI, with limited progress. Relatively high oil prices in
recent years have enabled Iran to amass some $22 billion in foreign
exchange reserves, but have not eased economic hardships such as
high unemployment and inflation. In December 2003 a major earthquake
devastated the city of Bam in southeastern Iran, killing more than
30,000 people.
condensate 850 km; condensate/gas 128 km; gas 8,506 km;
oil 7,472 km; oil/gas/water 66 km; refined products 1,329 km (2004)
Iran
condensate/gas 212 km; gas 16,998 km; liquid petroleum gas 570
km; oil 8,256 km; refined products 7,808 km (2004)','675ae1acbc9b363b41737d33772760a621a42ccb510197818ac38864d2523e4a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5903a74c1ffd4964e751099b774f61494eaa27188d3f7a860dcfdcbb6a6aebae',2004,'IQ','Iraq','economy',726,'total: 79
over 3,047 m: 21
2,438 to 3,047 m: 36
1,524 to 2,437 m: 5
914 to 1,523 m: 7
under 914 m: 10 (2004 est.)
total: 32
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 9 (2004 est.)
government water control projects have drained most of the
inhabited marsh areas east of An Nasiriyah by drying up or diverting
the feeder streams and rivers; a once sizable population of Marsh
Arabs, who inhabited these areas for thousands of years, has been
displaced; furthermore, the destruction of the natural habitat poses
serious threats to the area''s wildlife populations; inadequate
supplies of potable water; development of the Tigris and Euphrates
rivers system contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation (salination) and
erosion; desertification
party to: Law of the Sea
signed, but not ratified: Environmental Modification
NA
36.01 billion kWh (2001)
33.49 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
crude oil
US 48.8%, Jordan 8.4%, Canada 8%, Italy 7.9%, Morocco 5.3%
(2003)
18 governorates (muhafazat, singular - muhafazah); Al Anbar, Al
Basrah, Al Muthanna, Al Qadisiyah, An Najaf, Arbil, As Sulaymaniyah,
At Ta''mim, Babil, Baghdad, Dahuk, Dhi Qar, Diyala, Karbala'', Maysan,
Ninawa, Salah ad Din, Wasit
wheat, barley, rice, vegetables, dates, cotton; cattle, sheep
111; note - unknown number were damaged during the March-April
2003 war (2003 est.)
33.09 births/1,000 population (2004 est.)
note: in the summer of 2003 the Coalition Provisional Authority
(CPA) began recruiting and training a New Iraqi Army (NIA) that
would have a purely defensive mission and capability; in March 2004,
the Iraqi Interim Government established a Ministry of Defense to
create an Iraqi Armed Force; at that time the NIA was renamed the
Iraqi Armed Force - Army (IAF-A); plans also were put into effect to
reconstitute an Iraqi Army Air Corps (IAAC) and Coastal Defense
Force (navy), but there are no plans to reconstitute an Iraqi Air
Force; the Army''s primary new focus will be domestic
counterinsurgency, which is a change of direction from the CPA''s
intent to create an army not involved in domestic politics; in
mid-2004 the Iraqi Civil Defense Corps (ICDC) was designated the
Iraqi National Guard (ING) and subordinated to the Defense Ministry
and the Iraqi Armed Forces Pre-war Iraqi military equipment was
largely destroyed by Coalition forces during combat operations in
early 2003 or subsequently looted or scrapped (September 2004)
revenues: $12.8 billion NA
expenditures: $13.4 billion NA, including capital expenditures of NA
(2004 budget)
Iraq''s economy is dominated by the oil sector, which has
traditionally provided about 95% of foreign exchange earnings. In
the 1980s financial problems caused by massive expenditures in the
eight-year war with Iran and damage to oil export facilities by Iran
led the government to implement austerity measures, borrow heavily,
and later reschedule foreign debt payments; Iraq suffered economic
losses from that war of at least $100 billion. After hostilities
ended in 1988, oil exports gradually increased with the construction
of new pipelines and restoration of damaged facilities. Iraq''s
seizure of Kuwait in August 1990, subsequent international economic
sanctions, and damage from military action by an international
coalition beginning in January 1991 drastically reduced economic
activity. Although government policies supporting large military and
internal security forces and allocating resources to key supporters
of the regime have hurt the economy, implementation of the UN''s
oil-for-food program beginning in December 1996 helped improve
conditions for the average Iraqi citizen. Iraq was allowed to export
limited amounts of oil in exchange for food, medicine, and some
infrastructure spare parts. In December 1999, the UN Security
Council authorized Iraq to export under the program as much oil as
required to meet humanitarian needs. The drop in GDP in 2001-02 was
largely the result of the global economic slowdown and lower oil
prices. Per capita food imports increased significantly, while
medical supplies and health care services steadily improved. Per
capita output and living standards were still well below the
pre-1991 level, but any estimates have a wide range of error. The
military victory of the US-led coalition in March-April 2003
resulted in the shutdown of much of the central economic
administrative structure, but with the loss of a comparatively small
amount of capital plant. The rebuilding of oil, electricity, and
other production is proceeding steadily at the start of 2004 with
foreign support and despite the continuation of severe internal
strife. A joint UN and World Bank report released in the fall of
2003 estimated that Iraq''s key reconstruction needs through 2007
would cost $55 billion. In October 2003, international donors
pledged assistance worth more than $33 billion toward this
rebuilding effort.
gas 1,739 km; oil 5,418 km; refined products 1,343 km (2004)','3f1a0389767fd6e02615487632c993cadb3f7d057457d57b4844a708375e2eb6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c2234ad22f2e8946438626650e1a623b702c6808ee7107afe9724c93a970076',2004,'IE','Ireland','economy',727,'total: 15
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 6 (2004 est.)
total: 21
914 to 1,523 m: 4
under 914 m: 17 (2004 est.)
water pollution, especially of lakes, from agricultural
runoff
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Marine Life Conservation
0.9% (FY00/01)
23.53 billion kWh (2001)
21.63 billion kWh (2001)
38 million kWh (2001)
285 million kWh (2001)
10% (1997 est.)
lowest 10%: 2%
highest 10%: 27.3% (1997)
agriculture 8%, industry 29%, services 64% (2002 est.)
machinery and equipment, computers, chemicals,
pharmaceuticals; live animals, animal products (1999)
US 20.5%, UK 18.1%, Belgium 12.6%, Germany 8.3%, France
6.1%, Netherlands 5.1%, Italy 4.6% (2003)
26 counties; Carlow, Cavan, Clare, Cork, Donegal, Dublin,
Galway, Kerry, Kildare, Kilkenny, Laois, Leitrim, Limerick,
Longford, Louth, Mayo, Meath, Monaghan, Offaly, Roscommon, Sligo,
Tipperary, Waterford, Westmeath, Wexford, Wicklow
note: Cavan, Donegal, and Monaghan are part of Ulster Province
turnips, barley, potatoes, sugar beets, wheat; beef, dairy
products
36 (2003 est.)
14.47 births/1,000 population (2004 est.)
Army (including Naval Service and Air Corps)
revenues: $53.22 billion
expenditures: $53.5 billion, including capital expenditures of $5.5
billion (2003)
Ireland is a small, modern, trade-dependent economy with
growth averaging a robust 8% in 1995-2002. The global slowdown,
especially in the information technology sector, pressed growth down
to 2.1% in 2003. Agriculture, once the most important sector, is now
dwarfed by industry and services. Industry accounts for 46% of GDP
and about 80% of exports and employs 28% of the labor force.
Although exports remain the primary engine for Ireland''s growth, the
economy has also benefited from a rise in consumer spending,
construction, and business investment. Per capita GDP is 10% above
that of the four big European economies and the second highest in
the sEU, behind Luxembourg. Over the past decade, the Irish
Government has implemented a series of national economic programs
designed to curb price and wage inflation, reduce government
spending, increase labor force skills, and promote foreign
investment. Ireland joined in launching the euro currency system in
January 1999 along with 10 other EU nations.
gas 1,795 km (2004)','423bed42eab73ee167578024e49e2723f413211c45d738915e41967c31f1ebe1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80dacaa20fcd93591e3e9241e9b8e5db870d064d69dd229207164bcb010433f5',2004,'IL','Israel','economy',728,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m: 10
under 914 m: 4 (2004 est.)
total: 23
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 20 (2004 est.)
limited arable land and natural fresh water resources pose
serious constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from industrial and
domestic waste, chemical fertilizers, and pesticides
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
8.7% (FY02)
42.24 billion kWh (2001)
37.82 billion kWh (2001)
0 kWh (2001)
1.457 billion kWh (2001)
18% (2001 est.)
lowest 10%: 2.4%
highest 10%: 28.3% (1997)
agriculture, forestry, and fishing 2.6%, manufacturing 20.2%,
construction 7.5%, commerce 12.8%, transport, storage, and
communications 6.2%, finance and business 13.1%, personal and other
services 6.4%, public services 31.2% (1996)
machinery and equipment, software, cut diamonds, agricultural
products, chemicals, textiles and apparel
US 38.4%, Belgium 7.4%, Hong Kong 4.8% (2003)
6 districts (mehozot, singular - mehoz); Central, Haifa,
Jerusalem, Northern, Southern, Tel Aviv
citrus, vegetables, cotton; beef, poultry, dairy products
51 (2003 est.)
18.45 births/1,000 population (2004 est.)
Israel Defense Forces (IDF): Ground Corps (including Pioneer
Fighting Youth (Nahal)), Navy, Air Force(including Air Defense
Forces); note - historically there have been no separate Israeli
military services
revenues: $44.98 billion
expenditures: $51.07 billion, including capital expenditures of NA
(2003)
Israel has a technologically advanced market economy with
substantial government participation. It depends on imports of crude
oil, grains, raw materials, and military equipment. Despite limited
natural resources, Israel has intensively developed its agricultural
and industrial sectors over the past 20 years. Israel imports
substantial quantities of grain but is largely self-sufficient in
other agricultural products. Cut diamonds, high-technology
equipment, and agricultural products (fruits and vegetables) are the
leading exports. Israel usually posts sizable current account
deficits, which are covered by large transfer payments from abroad
and by foreign loans. Roughly half of the government''s external debt
is owed to the US, which is its major source of economic and
military aid. The bitter Israeli-Palestinian conflict; difficulties
in the high-technology, construction, and tourist sectors; and
fiscal austerity in the face of growing inflation led to small
declines in GDP in 2001 and 2002. The economy grew at 1% in 2003,
with improvements in tourism and foreign direct investment. In 2004,
rising business and consumer confidence - as well as higher demand
for Israeli exports - boosted GDP by 2.7%.
gas 140 km; oil 1,509 km (2004)','e19c2152f706b05f45c16c7de720cfa3289c6dc757e5075a1ae5c3f7cf07e655','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6101d5d852af2095adca16a18d660fd9e5c870bc38d7c87725d9674095f54a87',2004,'IT','Italy','economy',729,'total: 96
over 3,047 m: 6
2,438 to 3,047 m: 32
1,524 to 2,437 m: 16
914 to 1,523 m: 30
under 914 m: 12 (2004 est.)
total: 38
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 18 (2004 est.)
air pollution from industrial emissions such as sulfur
dioxide; coastal and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.9% (2003)
258.8 billion kWh (2001)
289.1 billion kWh (2001)
48.93 billion kWh (2001)
556 million kWh (2001)
NA
lowest 10%: 2.1%
highest 10%: 26.6% (2000)
agriculture 5%, industry 32%, services 63% (2001)
engineering products, textiles and clothing, production
machinery, motor vehicles, transport equipment, chemicals; food,
beverages and tobacco; minerals and nonferrous metals
Germany 13.8%, France 12.3%, US 8.5%, Spain 7%, UK 6.9% (2003)
16 regions (regioni, singular - regione) and 4 autonomous
regions* (regioni autonome, singular - regione autonoma); Abruzzo,
Basilicata, Calabria, Campania, Emilia-Romagna, Friuli-Venezia
Giulia*, Lazio, Liguria, Lombardia, Marche, Molise, Piemonte,
Puglia, Sardegna*, Sicilia, Toscana, Trentino-Alto Adige*, Umbria,
Valle d''Aosta*, Veneto
fruits, vegetables, grapes, potatoes, sugar beets, soybeans,
grain, olives; beef, dairy products; fish
134 (2003 est.)
9.05 births/1,000 population (2004 est.)
Army, Navy, Air Force (Aeronautica Militare Italiana, AMI),
Carabinieri
revenues: $668 billion
expenditures: $703.1 billion, including capital expenditures of NA
(2003)
Italy has a diversified industrial economy with roughly the
same total and per capita output as France and the UK. This
capitalistic economy remains divided into a developed industrial
north, dominated by private companies, and a less developed,
welfare-dependent agricultural south, with 20% unemployment. Most
raw materials needed by industry and more than 75% of energy
requirements are imported. Over the past decade, Italy has pursued a
tight fiscal policy in order to meet the requirements of the
Economic and Monetary Unions and has benefited from lower interest
and inflation rates. The current government has enacted numerous
short-term reforms aimed at improving competitiveness and long-term
growth. Italy has moved slowly, however, on implementing needed
structural reforms, such as lightening the high tax burden and
overhauling Italy''s rigid labor market and over-generous pension
system, because of the current economic slowdown and opposition from
labor unions.
gas 17,335 km; oil 1,136 km (2004)','bd03fceec58e1b9c342afe33d439f32be1d6b0d329fda7bbf642ae503c323a46','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('570ef3cc46934d19dc34b4c341e29989e53da4eb7fb67bd8d3bec89085f2c7c9',2004,'JM','Jamaica','economy',730,'total: 11
2,438 to 3,047 m: 2
914 to 1,523 m: 4
under 914 m: 5 (2004 est.)
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2004 est.)
Jan Mayen
total: 1
1,524 to 2,437 m: 1 (2004 est.)
heavy rates of deforestation; coastal waters polluted by
industrial waste, sewage, and oil spills; damage to coral reefs; air
pollution in Kingston results from vehicle emissions
Jan Mayen
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.4% (2003)
6.272 billion kWh (2001)
5.833 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
19.7% (2002 est.)
lowest 10%: 2.7%
highest 10%: 30.3% (2000)
agriculture 21%, industry 19%, services 60% (1998)
alumina, bauxite, sugar, bananas, rum, coffee, yams,
beverages, chemicals, wearing apparel, mineral fuels
US 29.6%, UK 11%, Canada 10.8%, France 7.9%, Norway 6.8%,
Germany 6.2%, China 6%, Netherlands 4.4% (2003)
14 parishes; Clarendon, Hanover, Kingston, Manchester,
Portland, Saint Andrew, Saint Ann, Saint Catherine, Saint Elizabeth,
Saint James, Saint Mary, Saint Thomas, Trelawny, Westmoreland
note: for local government purposes, Kingston and Saint Andrew were
amalgamated in 1923 into the present single corporate body known as
the Kingston and Saint Andrew Corporation
sugarcane, bananas, coffee, citrus, yams, vegetables,
poultry, goats, milk, crustaceans, and mollusks
35 (2003 est.)
Jan Mayen
1 (2003 est.)
16.94 births/1,000 population (2004 est.)
Jamaica Defense Force: Ground Forces, Coast Guard, Air Wing
revenues: $2.596 billion
expenditures: $3.111 billion, including capital expenditures of $236
million (2003 est.)
The Jamaican economy is heavily dependent on services, which
now account for 70% of GDP. The country continues to derive most of
its foreign exchange from tourism, remittances, and bauxite/alumina.
The global economic slowdown, particularly after the terrorist
attacks in the US on 11 September 2001, stunted economic growth; the
economy rebounded moderately in 2003, with one of the best tourist
seasons on record. But the economy faces serious long-term problems:
high interest rates; increased foreign competition; a pressured,
sometimes sliding, exchange rate; a sizable merchandise trade
deficit; large-scale unemployment; and a growing internal debt, the
result of government bailouts to ailing sectors of the economy. The
ratio of debt to GDP is close to 150%. Inflation, previously a
bright spot, is expected to remain in the double digits. Depressed
economic conditions have led to increased civil unrest, including
gang violence fueled by the drug trade. In 2004, the government
faces the difficult prospect of having to achieve fiscal discipline
in order to maintain debt payments while simultaneously attacking a
serious and growing crime problem that is hampering economic growth.
Jan Mayen
Jan Mayen is a volcanic island with no exploitable natural
resources. Economic activity is limited to providing services for
employees of Norway''s radio and meteorological stations on the
island.','65a97f8dfa45a18747c035cb448d133f15ab31695abb5d7681c6cd65428feaf1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e48e059d82c791cf8dc07023992876494ae76f91ba1e6a38464523aa60f1d72a',2004,'JP','Japan','economy',731,'total: 143
over 3,047 m: 7
2,438 to 3,047 m: 37
1,524 to 2,437 m: 39
914 to 1,523 m: 28
under 914 m: 32 (2004 est.)
total: 31
over 3047 m: 1
914 to 1,523 m: 4
under 914 m: 26 (2004 est.)
air pollution from power plant emissions results in acid rain;
acidification of lakes and reservoirs degrading water quality and
threatening aquatic life; Japan is one of the largest consumers of
fish and tropical timber, contributing to the depletion of these
resources in Asia and elsewhere
Jarvis Island
no natural fresh water resources
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
1% (2003)
1.037 trillion kWh (2001)
964.2 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: 4.8%
highest 10%: 21.7% (1993)
agriculture 5%, industry 25%, services 70% (2002 est.)
motor vehicles, semiconductors, office machinery, chemicals
US 24.8%, China 12.1%, South Korea 7.3%, Taiwan 6.6%, Hong
Kong 6.3% (2003)
47 prefectures; Aichi, Akita, Aomori, Chiba, Ehime, Fukui,
Fukuoka, Fukushima, Gifu, Gumma, Hiroshima, Hokkaido, Hyogo,
Ibaraki, Ishikawa, Iwate, Kagawa, Kagoshima, Kanagawa, Kochi,
Kumamoto, Kyoto, Mie, Miyagi, Miyazaki, Nagano, Nagasaki, Nara,
Niigata, Oita, Okayama, Okinawa, Osaka, Saga, Saitama, Shiga,
Shimane, Shizuoka, Tochigi, Tokushima, Tokyo, Tottori, Toyama,
Wakayama, Yamagata, Yamaguchi, Yamanashi
rice, sugar beets, vegetables, fruit, pork, poultry, dairy
products, eggs, fish
174 (2003 est.)
9.56 births/1,000 population (2004 est.)
Ground Self-Defense Force (Army), Maritime Self-Defense Force
(Navy), Air Self-Defense Force (Air Force), Coast Guard
revenues: $1.327 trillion
expenditures: $1.646 trillion, including capital expenditures
(public works only) of about $71 billion (2003 est.)
Government-industry cooperation, a strong work ethic, mastery
of high technology, and a comparatively small defense allocation (1%
of GDP) helped Japan advance with extraordinary rapidity to the rank
of second most technologically-powerful economy in the world after
the US and third-largest economy after the US and China. One notable
characteristic of the economy is the working together of
manufacturers, suppliers, and distributors in closely-knit groups
called keiretsu. A second basic feature has been the guarantee of
lifetime employment for a substantial portion of the urban labor
force. Both features are now eroding. Industry, the most important
sector of the economy, is heavily dependent on imported raw
materials and fuels. The much smaller agricultural sector is highly
subsidized and protected, with crop yields among the highest in the
world. Usually self-sufficient in rice, Japan must import about 50%
of its requirements of other grain and fodder crops. Japan maintains
one of the world''s largest fishing fleets and accounts for nearly
15% of the global catch. For three decades overall real economic
growth had been spectacular: a 10% average in the 1960s, a 5%
average in the 1970s, and a 4% average in the 1980s. Growth slowed
markedly in the 1990s, averaging just 1.7%, largely because of the
after effects of overinvestment during the late 1980s and
contractionary domestic policies intended to wring speculative
excesses from the stock and real estate markets. Government efforts
to revive economic growth have met with little success and were
further hampered in 2000-2003 by the slowing of the US, European,
and Asian economies. Japan''s huge government debt, which totals more
than 150% of GDP, and the ageing of the population are two major
long-run problems. Robotics constitutes a key long-term economic
strength with Japan possessing 410,000 of the world''s 720,000
"working robots." Internal conflict over the proper way to reform
the ailing banking system continues.
Jarvis Island
no economic activity
gas 2,719 km; oil 170 km; oil/gas/water 60 km (2004)','67a7f372682072c1553c9c1c20b680f07946bba28c79305c20649291612e34df','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67a20ed9059d2261b61d779ca4b5dc29db21e272a7d81df8024de609985e94ef',2004,'JE','Jersey','economy',732,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
Johnston Atoll
total: 1
2,438 to 3,047 m: 1 (2004 est.)
NA
Johnston Atoll
no natural fresh water resources
NA kWh; note - electricity supplied by France
NA
lowest 10%: NA
highest 10%: NA
light industrial and electrical goods, foodstuffs, textiles
UK
none (British crown dependency)
potatoes, cauliflower, tomatoes; beef, dairy products
1 (2003 est.)
Johnston Atoll
1 (2003 est.)
10.04 births/1,000 population (2004 est.)
revenues: $601 million
expenditures: $588 million, including capital expenditures of $98
million (2000 est.)
The economy is based largely on international financial
services, agriculture, and tourism. Potatoes, cauliflower, tomatoes,
and especially flowers are important export crops, shipped mostly to
the UK. The Jersey breed of dairy cattle is known worldwide and
represents an important export income earner. Milk products go to
the UK and other EU countries. In 1996 the finance sector accounted
for about 60% of the island''s output. Tourism, another mainstay of
the economy, accounts for 24% of GDP. In recent years, the
government has encouraged light industry to locate in Jersey, with
the result that an electronics industry has developed alongside the
traditional manufacturing of knitwear. All raw material and energy
requirements are imported, as well as a large share of Jersey''s food
needs. Light taxes and death duties make the island a popular tax
haven.
Johnston Atoll
Economic activity is limited to providing services to
US military personnel and contractors located on the island. All
food and manufactured goods must be imported.','3f098515a3fca335210e6df7e05f4dd4c3c67ed50bad8418e4d700cb07388f6b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d7f34af6fcee0e0800ecb718e93f6cd814a37f6c297beef8a967e8cdaccd179',2004,'JO','Jordan','economy',733,'total: 15
over 3,047 m: 7
2,438 to 3,047 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 2
under 914 m: 2 (2004 est.)
Juan de Nova Island
total: 1
914 to 1,523 m: 1 (2004 est.)
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Juan de Nova Island
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
20.2% (2003)
7.091 billion kWh (2001)
6.86 billion kWh (2001)
267 million kWh (2001)
2 million kWh (2001)
30% (2001 est.)
lowest 10%: 3.3%
highest 10%: 29.8% (1997)
agriculture 5%, industry 12.5%, services 82.5% (2001 est.)
clothing, phosphates, fertilizers, potash, vegetables,
manufactures, pharmaceuticals
US 21.5%, Iraq 17.6%, Switzerland 6.5%, India 6.5%, Saudi
Arabia 5.3% (2003)
12 governorates (muhafazat, singular - muhafazah); Ajlun, Al
''Aqabah, Al Balqa'', Al Karak, Al Mafraq, ''Amman, At Tafilah, Az
Zarqa'', Irbid, Jarash, Ma''an, Madaba
wheat, barley, citrus, tomatoes, melons, olives; sheep,
goats, poultry
17 (2003 est.)
Juan de Nova Island
1 (2003 est.)
22.73 births/1,000 population (2004 est.)
Jordanian Armed Forces (JAF) (Royal Jordanian Land Force,
Royal Naval Force, Royal Jordanian Air Force, and Special Operations
Command or SOCOM); note - Public Security Directorate normally falls
under Ministry of Interior but comes under JAF in wartime or crisis
situations
revenues: $2.397 billion
expenditures: $3.587 billion, including capital expenditures of $582
million (2003 est.)
Jordan is a small Arab country with inadequate supplies of
water and other natural resources such as oil. Debt, poverty, and
unemployment are fundamental problems, but King ABDALLAH, since
assuming the throne in 1999, has undertaken some broad economic
reforms in a long-term effort to improve living standards. ''Amman in
the past three years has worked closely with the IMF, practiced
careful monetary policy, and made substantial headway with
privatization. The government also has liberalized the trade regime
sufficiently to secure Jordan''s membership in the WTrO (2000), a
free trade accord with the US (2000), and an association agreement
with the EU (2001). These measures have helped improve productivity
and have put Jordan on the foreign investment map. The US-led war in
Iraq in 2003 dealt an economic blow to Jordan, which was dependent
on Iraq for discounted oil (worth $300-$600 million a year). Several
Gulf nations have provided temporary aid to compensate for the loss
of this oil; when this foreign aid expires, the Jordanian government
has pledged to raise retail petroleum product prices and the sales
tax base. Other ongoing challenges include fiscal adjustment to
reduce the budget deficit, broader investment incentives to promote
job-creating ventures, and the encouragement of tourism.
Juan de Nova Island
Up to 12,000 tons of guano are mined per year.
gas 10 km; oil 743 km (2004)','dbc1033c67fe16ce190c5c29aab7b1f30d6e52c99189b591a558ffd989860cc6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27f0343b50f12467dd7514903fad77cc5c0e9f211369f4024aef64a4563833d4',2004,'KZ','Kazakhstan','economy',734,'total: 64
over 3,047 m: 9
2,438 to 3,047 m: 26
1,524 to 2,437 m: 16
914 to 1,523 m: 3
under 914 m: 10 (2003 est.)
total: 328
over 3,047 m: 7
2,438 to 3,047 m: 11
1,524 to 2,437 m: 22
914 to 1,523 m: 71
under 914 m: 217 (2003 est.)
radioactive or toxic chemical sites associated with
former defense industries and test ranges scattered throughout the
country pose health risks for humans and animals; industrial
pollution is severe in some cities; because the two main rivers
which flowed into the Aral Sea have been diverted for irrigation, it
is drying up and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are then picked up by
the wind and blown into noxious dust storms; pollution in the
Caspian Sea; soil pollution from overuse of agricultural chemicals
and salination from poor infrastructure and wasteful irrigation
practices
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
0.9% (Ministry of Defense expenditures) (FY02)
52.43 billion kWh (2001)
48.36 billion kWh (2001)
3.2 billion kWh (2001)
3.6 billion kWh (2001)
26% (2001 est.)
lowest 10%: 2.8%
highest 10%: 27.3% (2001)
agriculture 20%, industry 30%, services 50% (2002 est.)
oil and oil products 58%, ferrous metals 24%, chemicals
5%, machinery 3%, grain, wool, meat, coal (2001)
Bermuda 17%, Russia 15.2%, Switzerland 13%, China 12.8%,
Italy 7.8% (2003)
14 provinces (oblystar, singular - oblys) and 3 cities*
(qala, singular - qalasy); Almaty Oblysy, Almaty Qalasy*, Aqmola
Oblysy (Astana), Aqtobe Oblysy, Astana Qalasy*, Atyrau Oblysy, Batys
Qazaqstan Oblysy (Oral), Bayqongyr Qalasy*, Mangghystau Oblysy
(Aqtau), Ongtustik Qazaqstan Oblysy (Shymkent), Pavlodar Oblysy,
Qaraghandy Oblysy, Qostanay Oblysy, Qyzylorda Oblysy, Shyghys
Qazaqstan Oblysy (Oskemen), Soltustik Qazaqstan Oblysy
(Petropavlovsk), Zhambyl Oblysy (Taraz)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses); in 1995 the Governments of
Kazakhstan and Russia entered into an agreement whereby Russia would
lease for a period of 20 years an area of 6,000 sq km enclosing the
Baykonur space launch facilities and the city of Bayqongyr
(Baykonur, formerly Leninsk)
grain (mostly spring wheat), cotton; livestock
392 (2003 est.)
15.52 births/1,000 population (2004 est.)
Ground Forces, Air and Air Defense Forces, Naval Force,
Republican Guard
revenues: $6.729 billion
expenditures: $6.999 billion, including capital expenditures of NA
(2003 est.)
Kazakhstan, the largest of the former Soviet republics in
territory, excluding Russia, possesses enormous fossil fuel reserves
as well as plentiful supplies of other minerals and metals. It also
is a large agricultural - livestock and grain - producer.
Kazakhstan''s industrial sector rests on the extraction and
processing of these natural resources and also on a growing
machine-building sector specializing in construction equipment,
tractors, agricultural machinery, and some defense items. The
breakup of the USSR in December 1991 and the collapse in demand for
Kazakhstan''s traditional heavy industry products resulted in a
short-term contraction of the economy, with the steepest annual
decline occurring in 1994. In 1995-97, the pace of the government
program of economic reform and privatization quickened, resulting in
a substantial shifting of assets into the private sector. Kazakhstan
enjoyed double-digit growth in 2000-01 - and a solid 9.5% in 2002 -
thanks largely to its booming energy sector, but also to economic
reform, good harvests, and foreign investment. The opening of the
Caspian Consortium pipeline in 2001, from western Kazakhstan''s
Tengiz oilfield to the Black Sea, substantially raised export
capacity. The country has embarked upon an industrial policy
designed to diversify the economy away from overdependence on the
oil sector, by developing light industry. Additionally, the policy
aims to reduce the influence of foreign investment and foreign
personnel; the government has engaged in several disputes with
foreign oil companies over the terms of production agreements, and
tensions continue.
condensate 18 km; gas 10,370 km; oil 10,158 km; refined
products 1,187 km (2004)','4afa06cae8cceadda98c858503ad30d5e09e63881526e1bbfe423c2209524094','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abfe2613f78674f8f86ec36204d6ec34633a4fc2431d47f192bd59aa7d80513e',2004,'KE','Kenya','economy',735,'total: 15
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 6
under 914 m: 1 (2004 est.)
total: 206
1,524 to 2,437 m: 12
914 to 1,523 m: 110
under 914 m: 84 (2004 est.)
water pollution from urban and industrial wastes; degradation
of water quality from increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria; deforestation; soil
erosion; desertification; poaching
Kingman Reef
none
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.8% (2003)
4.033 billion kWh (2001)
3.981 billion kWh (2001)
230 million kWh (2001)
0 kWh (2001)
50% (2000 est.)
lowest 10%: 2%
highest 10%: 37.2% (2000)
agriculture 75% (2003 est.)
Korea, North
agricultural 36%, nonagricultural 64%
Korea, South
agriculture 8.8%, industry 19.1%, services 72.1% (2001)
tea, horticultural products, coffee, petroleum products, fish,
cement
Uganda 12.7%, UK 12.5%, US 9.4%, Netherlands 8.5%, Pakistan
5%, Egypt 4.6%, Tanzania 4.3% (2003)
7 provinces and 1 area*; Central, Coast, Eastern, Nairobi
Area*, North Eastern, Nyanza, Rift Valley, Western
tea, coffee, corn, wheat, sugarcane, fruit, vegetables; dairy
products, beef, pork, poultry, eggs
221 (2003 est.)
Kingman Reef
lagoon was used as a halfway station between Hawaii and
American Samoa by Pan American Airways for flying boats in 1937 and
1938 (2003 est.)
27.82 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $2.761 billion
expenditures: $3.406 billion, including capital expenditures of NA
(2003 est.)
The regional hub for trade and finance in East Africa, Kenya
has been hampered by corruption, notably in the judicial system, and
by reliance upon several primary goods whose prices have remained
low. In 1997, the IMF suspended Kenya''s Enhanced Structural
Adjustment Program due to the government''s failure to maintain
reforms and curb corruption. A severe drought from 1999 to 2000
compounded Kenya''s problems, causing water and energy rationing and
reducing agricultural output. As a result, GDP contracted by 0.2% in
2000. The IMF, which had resumed loans in 2000 to help Kenya through
the drought, again halted lending in 2001 when the government failed
to institute several anticorruption measures. Despite the return of
strong rains in 2001, weak commodity prices, endemic corruption, and
low investment limited Kenya''s economic growth to 1.2%. Growth
lagged at 1.1% in 2002 because of erratic rains, low investor
confidence, meager donor support, and political infighting up to the
elections. In the key 27 December 2002 elections, Daniel Arap MOI''s
24-year-old reign ended, and a new opposition government took on the
formidable economic problems facing the nation. In 2003, progress
was made in rooting out corruption, and encouraging donor support,
with GDP growth edging up to 1.7%.
Kingman Reef
no economic activity
refined products 752 km (2004)
Korea, North
oil 154 km (2004)
Korea, South
gas 1,433 km; refined products 827 km (2004)','0eac5047802b31a676afa6c2c12dbf27980b9b445d94c3ae71a81145e3a9ba03','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbbfa6e53c506ef7e04aabfb5fcfdd97af60e1809a2704f646649c5d8f697299',2004,'KI','Kiribati','economy',736,'total: 3
1,524 to 2,437 m: 3 (2004 est.)
Korea, North
total: 35
over 3,047 m: 3
2,438 to 3,047 m: 23
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 3 (2003 est.)
Korea, South
total: 88
over 3,047 m: 3
2,438 to 3,047 m: 21
1,524 to 2,437 m: 14
914 to 1,523 m: 12
under 914 m: 38 (2004 est.)
total: 17
1,524 to 2,437 m: 1
914 to 1,523 m: 12
under 914 m: 4 (2004 est.)
Korea, North
total: 43
2,438 to 3,047 m: 1
1,524 to 2,437 m: 20
914 to 1,523 m: 14
under 914 m: 8 (2003 est.)
Korea, South
total: 91
914 to 1,523 m: 3
under 914 m: 88 (2004 est.)
heavy pollution in lagoon of south Tarawa atoll due to
heavy migration mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Korea, North
water pollution; inadequate supplies of potable water;
water-borne disease; deforestation; soil erosion and degradation
Korea, South
air pollution in large cities; acid rain; water
pollution from the discharge of sewage and industrial effluents;
drift net fishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Korea, North
party to: Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Law of the Sea
Korea, South
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
NA
Korea, North
22.9% (2003)
Korea, South
2.7% (FY03)
7 million kWh (2001)
Korea, North
30.01 billion kWh (2001)
Korea, South
290.7 billion kWh (2001)
6.51 million kWh (2001)
Korea, North
27.91 billion kWh (2001)
Korea, South
270.3 billion kWh (2001)
0 kWh (2001)
Korea, North
0 kWh (2001)
Korea, South
0 kWh (2001)
0 kWh (2001)
Korea, North
0 kWh (2001)
Korea, South
0 kWh (2001)
NA
Korea, North
NA
Korea, South
4% (2001 est.)
lowest 10%: NA
highest 10%: NA
Korea, North
lowest 10%: NA
highest 10%: NA
Korea, South
lowest 10%: 2.9%
highest 10%: 22.5% (1999 est.)
copra 62%, coconuts, seaweed, fish
Korea, North
minerals, metallurgical products, manufactures
(including armaments); textiles and fishery products
Korea, South
Semiconductors, wireless telecommunications equipment,
motor vehicles, computers, steel, ships, petrochemicals
Japan 75%, Australia 8.3%, US 8.3%, Philippines 4.2%,
Thailand 4.2% (2003)
Korea, North
South Korea 28.5%, China 28.4%, Japan 24.7% (2002)
Korea, South
China 18.2%, US 17.8%, Japan 9%, Hong Kong 7.6% (2003)
3 units; Gilbert Islands, Line Islands, Phoenix Islands;
note - in addition, there are 6 districts (Banaba, Central Gilberts,
Line Islands, Northern Gilberts, Southern Gilberts, Tarawa) and 21
island councils - one for each of the inhabited islands (Abaiang,
Abemama, Aranuka, Arorae, Banaba, Beru, Butaritari, Kanton,
Kiritimati, Kuria, Maiana, Makin, Marakei, Nikunau, Nonouti, Onotoa,
Tabiteuea, Tabuaeran, Tamana, Tarawa, Teraina)
Korea, North
9 provinces (do, singular and plural) and 4
municipalities (si, singular and plural)
provinces: Chagang-do (Chagang), Hamgyong-bukto (North Hamgyong),
Hamgyong-namdo (South Hamgyong), Hwanghae-bukto (North Hwanghae),
Hwanghae-namdo (South Hwanghae), Kangwon-do (Kangwon),
P''yongan-bukto (North P''yongan), P''yongan-namdo (South P''yongan),
Yanggang-do (Yanggang)
municipalites: Kaesong-si (Kaesong), Najin Sonbong-si (Najin),
Namp''o-si (Namp''o), P''yongyang-si (Pyongyang)
Korea, South
9 provinces (do, singular and plural) and 7
metropolitan cities (gwangyoksi, singular and plural)
provinces: Cheju-do, Cholla-bukto (North Cholla), Cholla-namdo
(South Cholla), Ch''ungch''ong-bukto (North Ch''ungch''ong),
Ch''ungch''ong-namdo (South Ch''ungch''ong), Kangwon-do, Kyonggi-do,
Kyongsang-bukto (North Kyongsang), Kyongsang-namdo (South Kyongsang)
metropolitan cities: Inch''on-gwangyoksi (Inchon), Kwangju-gwangyoksi
(Kwangju), Pusan-gwangyoksi (Pusan), Soul-t''ukpyolsi (Seoul),
Taegu-gwangyoksi (Taegu), Taejon-gwangyoksi (Taejon),
Ulsan-gwangyoksi (Ulsan)
copra, taro, breadfruit, sweet potatoes, vegetables; fish
Korea, North
rice, corn, potatoes, soybeans, pulses; cattle, pigs,
pork, eggs
Korea, South
rice, root crops, barley, vegetables, fruit; cattle,
pigs, chickens, milk, eggs; fish
20 (2003 est.)
Korea, North
78 (2003 est.)
Korea, South
102 (2003 est.)
30.99 births/1,000 population (2004 est.)
Korea, North
16.77 births/1,000 population (2004 est.)
Korea, South
12.33 births/1,000 population (2004 est.)
no regular military forces; Police Force (carries out law
enforcement functions and paramilitary duties; small police posts
are on all islands)
Korea, North
Korean People''s Army (includes Army, Navy, Air Force),
Civil Security Forces
Korea, South
Army, Navy, Air Force, Marine Corps, National Maritime
Police (Coast Guard)
revenues: $28.4 million
expenditures: $37.2 million, including capital expenditures of NA
(2000 est.)
Korea, North
revenues: NA
expenditures: NA, including capital expenditures of NA
Korea, South
revenues: $135.5 billion
expenditures: $128.7 billion, including capital expenditures of
$23.5 billion (2003)
A remote country of 33 scattered coral atolls, Kiribati has
few natural resources. Commercially viable phosphate deposits were
exhausted at the time of independence from the UK in 1979. Copra and
fish now represent the bulk of production and exports. The economy
has fluctuated widely in recent years. Economic development is
constrained by a shortage of skilled workers, weak infrastructure,
and remoteness from international markets. Tourism provides more
than one-fifth of GDP. The financial sector is at an early stage of
development as is the expansion of private sector initiatives.
Foreign financial aid from UK, Japan, Australia, New Zealand, and
China equals 25%-50% of GDP. Remittances from workers abroad account
for more than $5 million each year.
Korea, North
North Korea, one of the world''s most centrally planned
and isolated economies, faces desperate economic conditions.
Industrial capital stock is nearly beyond repair as a result of
years of underinvestment and spare parts shortages. Industrial and
power output have declined in parallel. The nation has suffered its
tenth year of food shortages because of a lack of arable land,
collective farming, weather-related problems, and chronic shortages
of fertilizer and fuel. Massive international food aid deliveries
have allowed the regime to escape mass starvation since 1995-96, but
the population remains the victim of prolonged malnutrition and
deteriorating living conditions. Large-scale military spending eats
up resources needed for investment and civilian consumption. In
2003, heightened political tensions with key donor countries and
general donor fatigue threatened the flow of desperately needed food
aid and fuel aid as well. Black market prices continued to rise
following the increase in official prices and wages in the summer of
2002, leaving some vulnerable groups, such as the elderly and
unemployed, less able to buy goods. The regime, however, relaxed
restrictions on farmers'' market activities in spring 2003, leading
to an expansion of market activity.
Korea, South
Since the early 1960s, South Korea has achieved an
incredible record of growth and integration into the high-tech
modern world economy. Four decades ago GDP per capita was comparable
with levels in the poorer countries of Africa and Asia. Today its
GDP per capita is 18 times North Korea''s and equal to the lesser
economies of the European Union. This success through the late 1980s
was achieved by a system of close government/business ties,
including directed credit, import restrictions, sponsorship of
specific industries, and a strong labor effort. The government
promoted the import of raw materials and technology at the expense
of consumer goods and encouraged savings and investment over
consumption. The Asian financial crisis of 1997-99 exposed
longstanding weaknesses in South Korea''s development model,
including high debt/equity ratios, massive foreign borrowing, and an
undisciplined financial sector. Growth plunged to a negative 6.6% in
1998, then strongly recovered to 10.8% in 1999 and 9.2% in 2000.
Growth fell back to 3.3% in 2001 because of the slowing global
economy, falling exports, and the perception that much-needed
corporate and financial reforms had stalled. Led by consumer
spending and exports, growth in 2002 was an impressive 6.2%, despite
anemic global growth, followed by moderate 2.8% growth in 2003. In
2003 the National Assembly approved legislation reducing the six-day
work week to five days.','8758d04fa05f1ad48781956428efc29d50b81781f6515ce1696e1111f43d4963','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73c1a51affca7e649111eb56dca026d73fbf31ca11ad5b4aba0b0cf1b54d66e9',2004,'KW','Kuwait','economy',737,'total: 4
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2004 est.)
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2004 est.)
limited natural fresh water resources; some of world''s
largest and most sophisticated desalination facilities provide much
of the water; air and water pollution; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: Marine Dumping
5.8% (2003)
31.49 billion kWh (2001)
29.29 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industries NA, services NA
oil and refined products, fertilizers
Japan 21.3%, South Korea 14.9%, US 11.5%, Singapore 9.8%,
Taiwan 9.3% (2003)
5 governorates (muhafazat, singular - muhafazah); Al Ahmadi,
Al Farwaniyah, Al ''Asimah, Al Jahra'', Hawalli
practically no crops; fish
7 (2003 est.)
21.85 births/1,000 population (2004 est.)
Land Forces, Navy, Air Force (including Air Defense Force),
National Guard
revenues: $29.41 billion
expenditures: $17.57 billion, including capital expenditures of NA
(2003)
Kuwait is a small, rich, relatively open economy with proved
crude oil reserves of about 98 billion barrels - 10% of world
reserves. Petroleum accounts for nearly half of GDP, 95% of export
revenues, and 80% of government income. Kuwait''s climate limits
agricultural development. Consequently, with the exception of fish,
it depends almost wholly on food imports. About 75% of potable water
must be distilled or imported. Kuwait continues its discussions with
foreign oil companies to develop fields in the northern part of the
country.
gas 169 km; oil 540 km; refined products 57 km (2004)','01a4d68db475a447a234a08a74ad05cc05126f4f8b420fdf1504cfe6fba0cee9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0395879c5ba4c6b64a0141260a13a302c607976c2c88e1563a5be0ac62045a56',2004,'KG','Kyrgyzstan','economy',738,'total: 17
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 11
under 914 m: 2 (2003 est.)
Laos
total: 9
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2004 est.)
total: 44
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 37 (2003 est.)
Laos
total: 35
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m: 21 (2004 est.)
water pollution; many people get their water directly
from contaminated streams and wells; as a result, water-borne
diseases are prevalent; increasing soil salinity from faulty
irrigation practices
Laos
unexploded ordnance; deforestation; soil erosion; most of the
population does not have access to potable water
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Laos
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
1.4% (FY01)
Laos
0.5% (2003)
13.45 billion kWh (2001)
Laos
1.317 billion kWh (2001)
10.46 billion kWh (2001)
Laos
824.7 million kWh (2001)
200 million kWh (2001)
Laos
0 kWh (2001)
2.25 billion kWh (2001)
Laos
400 million kWh (2001)
50% (2003 est.)
Laos
40% (2002 est.)
lowest 10%: 3.2%
highest 10%: 27.7% (1999)
Laos
lowest 10%: 3.2%
highest 10%: 30.6% (1997)
agriculture 55%, industry 15%, services 30% (2000 est.)
Laos
agriculture 80% (1997 est.)
cotton, wool, meat, tobacco; gold, mercury, uranium,
natural gas, hydropower; machinery; shoes
Laos
garments, wood products, coffee, electricity, tin
UAE 24.7%, Switzerland 20.3%, Russia 16.7%, Kazakhstan
9.8%, Canada 5.3%, China 4% (2003)
Laos
Thailand 20.7%, Vietnam 15.9%, France 7.3%, Germany 5.3%,
Belgium 4% (2003)
7 provinces (oblastlar, singular - oblasty) and 1 city*
(shaar); Batken Oblasty, Bishkek Shaary*, Chuy Oblasty (Bishkek),
Jalal-Abad Oblasty, Naryn Oblasty, Osh Oblasty, Talas Oblasty,
Ysyk-Kol Oblasty (Karakol)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
Laos
16 provinces (khoueng, singular and plural), 1 municipality*
(kampheng nakhon, singular and plural), and 1 special zone**
(khetphiset, singular and plural); Attapu, Bokeo, Bolikhamxai,
Champasak, Houaphan, Khammouan, Louangnamtha, Louangphrabang,
Oudomxai, Phongsali, Salavan, Savannakhet, Viangchan*, Viangchan,
Xaignabouli, Xaisomboun**, Xekong, Xiangkhoang
tobacco, cotton, potatoes, vegetables, grapes, fruits and
berries; sheep, goats, cattle, wool
Laos
sweet potatoes, vegetables, corn, coffee, sugarcane, tobacco,
cotton, tea, peanuts, rice, water buffalo, pigs, cattle, poultry
61 (2003 est.)
Laos
46 (2003 est.)
22.13 births/1,000 population (2004 est.)
Laos
36.47 births/1,000 population (2004 est.)
Army, Air and Air Defense, Security Forces, Border Troops
Laos
Lao People''s Army (LPA; including Riverine Force), Air Force
revenues: $371.5 million
expenditures: $387.1 million, including capital expenditures of NA
(2003 est.)
Laos
revenues: $298.5 million
expenditures: $429.9 million, including capital expenditures of NA
(2003 est.)
Kyrgyzstan is a poor, mountainous country with a
predominantly agricultural economy. Cotton, tobacco, wool, and meat
are the main agricultural products, although only tobacco and cotton
are exported in any quantity. Industrial exports include gold,
mercury, uranium, and natural gas and electricity. Kyrgyzstan has
been fairly progressive in carrying out market reforms, such as an
improved regulatory system and land reform. Kyrgyzstan was the first
CIS country to be accepted into the World Trade Organization. With
fits and starts, inflation has been lowered to an estimated 7% in
2001, 2.1% in 2002, and 4.0% in 2003. Much of the government''s stock
in enterprises has been sold. Drops in production had been severe
after the breakup of the Soviet Union in December 1991, but by
mid-1995 production began to recover and exports began to increase.
Kyrgyzstan has distinguished itself by adopting relatively liberal
economic policies. The drop in output at the Kumtor gold mine
sparked a 0.5% decline in GDP in 2002, but GDP growth bounced back
to 6% in 2003. The government has made steady strides in controlling
its substantial fiscal deficit and aims to reduce the deficit to 4.4
percent of GDP in 2004. The government and the international
financial institutions have been engaged in a comprehensive
medium-term poverty reduction and economic growth strategy. Further
restructuring of domestic industry and success in attracting foreign
investment are keys to future growth.
Laos
The government of Laos - one of the few remaining official
Communist states - began decentralizing control and encouraging
private enterprise in 1986. The results, starting from an extremely
low base, were striking - growth averaged 7% in 1988-2001 except
during the short-lived drop caused by the Asian financial crisis
beginning in 1997. Despite this high growth rate, Laos remains a
country with a primitive infrastructure; it has no railroads, a
rudimentary road system, and limited external and internal
telecommunications. Electricity is available in only a few urban
areas. Subsistence agriculture accounts for half of GDP and provides
80% of total employment. The economy will continue to benefit from
aid from the IMF and other international sources and from new
foreign investment in food processing and mining.
gas 367 km; oil 13 km (2004)
Laos
refined products 540 km (2004)','1b9be0b8439d2cd9be478bcf73c7ac28f4ee19fe6516a8a314734f67abff2db3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dcef84524ce54ccf028657cdac06f01c68f2f7d5d549e6305a88e890f6c1774',2004,'LV','Latvia','economy',739,'total: 27
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 16 (2003 est.)
total: 24
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 20 (2003 est.)
Latvia''s environment has benefited from a shift to service
industries after the country regained independence; the main
environmental priorities are improvement of drinking water quality
and sewage system, household and hazardous waste management, and
reduction of air pollution; in 2001, Latvia closed the EU accession
negotiation chapter on environment committing to full enforcement of
EU environmental directives by 2010
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered Species, Hazardous Wastes,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.2% (FY01)
4.365 billion kWh (2001)
6.046 billion kWh (2001)
2.69 billion kWh (2001)
703 million kWh (2001)
NA
lowest 10%: 2.9%
highest 10%: 25.9% (1998)
agriculture 15%, industry 25%, services 60% (2000 est.)
wood and wood products, machinery and equipment, metals,
textiles, foodstuffs
UK 15.6%, Germany 14.8%, Sweden 10.5%, Lithuania 8.2%,
Estonia 6.6%, Denmark 6%, Russia 5.4% (2003)
26 counties (singular - rajons) and 7 municipalities*:
Aizkraukles Rajons, Aluksnes Rajons, Balvu Rajons, Bauskas Rajons,
Cesu Rajons, Daugavpils*, Daugavpils Rajons, Dobeles Rajons,
Gulbenes Rajons, Jekabpils Rajons, Jelgava*, Jelgavas Rajons,
Jurmala*, Kraslavas Rajons, Kuldigas Rajons, Liepaja*, Liepajas
Rajons, Limbazu Rajons, Ludzas Rajons, Madonas Rajons, Ogres Rajons,
Preilu Rajons, Rezekne*, Rezeknes Rajons, Riga*, Rigas Rajons,
Saldus Rajons, Talsu Rajons, Tukuma Rajons, Valkas Rajons, Valmieras
Rajons, Ventspils*, Ventspils Rajons
grain, sugar beets, potatoes, vegetables; beef, pork, milk,
eggs; fish
51 (2003 est.)
8.87 births/1,000 population (2004 est.)
Ground Forces, Navy, Air Force, Border Guard, Home Guard
(Zemessardze)
revenues: $3.691 billion
expenditures: $3.871 billion, including capital expenditures of NA
(2003 est.)
Latvia''s transitional economy recovered from the 1998 Russian
financial crisis, largely due to the SKELE government''s budget
stringency and a gradual reorientation of exports toward EU
countries, lessening Latvia''s trade dependency on Russia. The
majority of companies, banks, and real estate have been privatized,
although the state still holds sizable stakes in a few large
enterprises. Latvia officially joined the World Trade Organization
in February 1999. Preparing for EU membership continues as a top
foreign policy goal. The current account and internal government
deficits remain major concerns, but the government''s efforts to
increase efficiency in revenue collection may lessen the budget
deficit.
gas 1,097 km; oil 409 km; refined products 415 km (2004)','278cd399e2010a0a6434f6b9708b52967e8a9718cd6e2db1d568cca07c2b9359','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae6261d973414104767a8daa943c69143f6cc4cf814a9708ef024c2a35451da4',2004,'LB','Lebanon','economy',740,'total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
total: 3
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
deforestation; soil erosion; desertification; air pollution
in Beirut from vehicular traffic and the burning of industrial
wastes; pollution of coastal waters from raw sewage and oil spills
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification, Marine Life
Conservation
4.8% (FY99)
6.728 billion kWh (2001)
7.44 billion kWh (2001)
1.183 billion kWh (2001)
0 kWh (2001)
28% (1999 est.)
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
authentic jewelry, inorganic chemicals, miscellaneous
consumer goods, fruit, tobacco, construction minerals, electric
power machinery and switchgear, textile fibers, paper
Switzerland 10.8%, UAE 10%, Saudi Arabia 7.5%, US 7.3%,
Turkey 5.5%, Jordan 4.4% (2003)
6 governorates (mohafazat, singular - mohafazah); Beyrouth,
Beqaa, Liban-Nord, Liban-Sud, Mont-Liban, Nabatiye
citrus, grapes, tomatoes, apples, vegetables, potatoes,
olives, tobacco; sheep, goats
8 (2003 est.)
19.31 births/1,000 population (2004 est.)
Lebanese Armed Forces (LAF; includes Army, Navy, and Air
Force)
revenues: $4.414 billion
expenditures: $7.026 billion, including capital expenditures of NA
(2003 est.)
The 1975-91 civil war seriously damaged Lebanon''s economic
infrastructure, cut national output by half, and all but ended
Lebanon''s position as a Middle Eastern entrepot and banking hub.
Peace enabled the central government to restore control in Beirut,
begin collecting taxes, and regain access to key port and government
facilities. Economic recovery was helped by a financially sound
banking system and resilient small- and medium-scale manufacturers.
Family remittances, banking services, manufactured and farm exports,
and international aid provided the main sources of foreign exchange.
Lebanon''s economy made impressive gains since the launch in 1993 of
"Horizon 2000," the government''s $20 billion reconstruction program.
Real GDP grew 8% in 1994, 7% in 1995, 4% in 1996 and in 1997, but
slowed to 1.2% in 1998, -1.6% in 1999, -0.6% in 2000, 0.8% in 2001,
1.5% in 2002, and 3% in 2003. During the 1990s, annual inflation
fell to almost 0% from more than 100%. Lebanon has rebuilt much of
its war-torn physical and financial infrastructure. The government
nonetheless faces serious challenges in the economic arena. It has
funded reconstruction by borrowing heavily - mostly from domestic
banks. In order to reduce the ballooning national debt, the
re-installed HARIRI government began an economic austerity program
to rein in government expenditures, increase revenue collection, and
privatize state enterprises. The HARIRI government met with
international donors at the Paris II conference in November 2002 to
seek bilateral assistance restructuring its domestic debt at lower
rates of interest. While privatization of state-owned enterprises
had not occurred by the end of 2003, massive receipts from donor
nations stabilized government finances in 2002-04.
oil 209 km (2004)','5b7ec392bbdd11f9b21c1e4983d35412a16fe0a3075ea274a8abed1049893c52','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d16211315aa3e43d2b60e07ffc18ca7b54d67cc3d4224a76cd9cbc1314175be',2004,'LS','Lesotho','economy',741,'total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 25
914 to 1,523 m: 4
under 914 m: 21 (2004 est.)
population pressure forcing settlement in marginal areas
results in overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls, stores, and
redirects water to South Africa
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Ozone Layer Protection
signed, but not ratified: Law of the Sea
2.6% (2003)
0 kWh NA kWh; note - electricity supplied by South Africa
(2001)
40 million kWh (2001)
40 million kWh; note - electricity supplied by South Africa
(2001)
0 kWh (2001)
49% (1999)
lowest 10%: 0.9%
highest 10%: 43.4%
86% of resident population engaged in subsistence
agriculture; roughly 35% of the active male wage earners work in
manufactures 75% (clothing, footwear, road vehicles), wool
and mohair, food and live animals (2000)
US 97.6%, Canada 1.5%, France 0.5% (2003)
10 districts; Berea, Butha-Buthe, Leribe, Mafeteng, Maseru,
Mohale''s Hoek, Mokhotlong, Qacha''s Nek, Quthing, Thaba-Tseka
corn, wheat, pulses, sorghum, barley; livestock
28 (2003 est.)
26.91 births/1,000 population (2004 est.)
Lesotho Defense Force (LDF; with Army and Air Wing)
revenues: $625.4 million
expenditures: $675.2 million, including capital expenditures of $15
million (2003 est.)
Small, landlocked, and mountainous, Lesotho relies on
remittances from miners employed in South Africa and customs duties
from the Southern Africa Customs Union for the majority of
government revenue, but the government has strengthened its tax
system to reduce dependency on customs duties. Completion of a major
hydropower facility in January 1998 now permits the sale of water to
South Africa, also generating royalties for Lesotho. As the number
of mineworkers has declined steadily over the past several years, a
small manufacturing base has developed based on farm products that
support the milling, canning, leather, and jute industries and a
rapidly growing apparel-assembly sector. The economy is still
primarily based on subsistence agriculture, especially livestock,
although drought has decreased agricultural activity. The extreme
inequality in the distribution of income remains a major drawback.
Lesotho has signed an Interim Poverty Reduction and Growth Facility
with the IMF.','19e7d01ef48525276600c283f56c6b81e35e5593620792885d63c221f0287357','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('763afba630b17c90b6069259dff63198fa96c2982932a22581c43ff7a5e465ed',2004,'LR','Liberia','economy',742,'total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 51
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m: 38 (2004 est.)
tropical rain forest deforestation; soil erosion; loss of
biodiversity; pollution of coastal waters from oil residue and raw
sewage
party to: Biodiversity, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Climate Change, Environmental
Modification, Law of the Sea, Marine Life Conservation
1.3% (2003)
468.8 million kWh (2001)
435.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
80%
lowest 10%: NA
highest 10%: NA
agriculture 70%, industry 8%, services 22% (2000 est.)
rubber, timber, iron, diamonds, cocoa, coffee
Germany 43.3%, Poland 10.9%, Greece 9.1%, US 6%, France
5.5%, Thailand 4.9%, China 4.1% (2003)
15 counties; Bomi, Bong, Gbarpolu, Grand Bassa, Grand Cape
Mount, Grand Gedeh, Grand Kru, Lofa, Margibi, Maryland, Montserrado,
Nimba, River Cess, River Gee, Sinoe
rubber, coffee, cocoa, rice, cassava (tapioca), palm oil,
sugarcane, bananas; sheep, goats; timber
53 (2003 est.)
44.81 births/1,000 population (2004 est.)
Armed Forces of Liberia (AFL): Army, Navy, Air Force
revenues: $85.4 million
expenditures: $90.5 million, including capital expenditures of NA
(2000 est.)
Civil war and misgovernment have destroyed much of Liberia''s
economy, especially the infrastructure in and around Monrovia. Many
businessmen have fled the country, taking capital and expertise with
them. Some have returned, many will not. Richly endowed with water,
mineral resources, forests, and a climate favorable to agriculture,
Liberia had been a producer and exporter of basic products -
primarily raw timber and rubber. Local manufacturing, mainly foreign
owned, had been small in scope. The departure of the former
president, Charles TAYLOR, to Nigeria in August 2003, the
establishment of the all-inclusive National Transition Government of
Liberia (NTGL), and the arrival of a UN mission are all encouraging
signs that the political crisis is coming to an end. The restoration
of infrastructure and the raising of incomes in this ravaged economy
depend on the implementation of sound macro- and micro-economic
policies, including the encouragement of foreign investment, and
generous support from donor countries.','cc4e2be5476ed106fde258fa6b13316b3abe3399d44da7b54194cbd65b656649','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51a620b457a1c54a346936bf91f2680cc56e2bcdd3c151f18eec790b04dee819',2004,'LY','Libya','economy',743,'total: 59
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 23
914 to 1,523 m: 5
under 914 m: 2 (2004 est.)
total: 80
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 41
under 914 m: 18 (2004 est.)
desertification; very limited natural fresh water resources;
the Great Manmade River Project, the largest water development
scheme in the world, is being built to bring water from large
aquifers under the Sahara to coastal cities
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Ozone Layer
Protection
signed, but not ratified: Law of the Sea
3.9% (FY99)
20.18 billion kWh (2001)
18.77 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 17%, industry 29%, services 54% (1997 est.)
crude oil, refined petroleum products (1999)
Italy 38.8%, Spain 13.4%, Germany 13.4%, Turkey 7.1%, France
6.1% (2003)
25 municipalities (baladiyat, singular - baladiyah); Ajdabiya,
Al ''Aziziyah, Al Fatih, Al Jabal al Akhdar, Al Jufrah, Al Khums, Al
Kufrah, An Nuqat al Khams, Ash Shati'', Awbari, Az Zawiyah, Banghazi,
Darnah, Ghadamis, Gharyan, Misratah, Murzuq, Sabha, Sawfajjin, Surt,
Tarabulus, Tarhunah, Tubruq, Yafran, Zlitan; note - the 25
municipalities may have been replaced by 13 regions
wheat, barley, olives, dates, citrus, vegetables, peanuts,
soybeans; cattle
140 (2003 est.)
27.17 births/1,000 population (2004 est.)
Armed Peoples on Duty (Army), Navy, Air Force, Air Defense
Command
revenues: $10.28 billion
expenditures: $7.86 billion, including capital expenditures of NA
(2003 est.)
The Libyan economy depends primarily upon revenues from the
oil sector, which contribute practically all export earnings and
about one-quarter of GDP. These oil revenues and a small population
give Libya one of the highest per capita GDPs in Africa, but little
of this income flows down to the lower orders of society. Libyan
officials in the past three years have made progress on economic
reforms as part of a broader campaign to reintegrate the country
into the international fold. This effort picked up steam after UN
sanctions were lifted in September 2003 and as Libya announced in
December 2003 that it would abandon programs to build weapons of
mass destruction. Libya faces a long road ahead in liberalizing the
socialist-oriented economy, but initial steps - including applying
for WTO membership, reducing some subsidies, and announcing plans
for privatization - are laying the groundwork for a transition to a
more market-based economy. The non-oil manufacturing and
construction sectors, which account for about 20% of GDP, have
expanded from processing mostly agricultural products to include the
production of petrochemicals, iron, steel, and aluminum. Climatic
conditions and poor soils severely limit agricultural output, and
Libya imports about 75% of its food.
condensate 225 km; gas 3,611 km; oil 7,252 km (2004)','0ef419a5c5cef55d86b3ec0db43cd8baa0e0e80b02d206e3025e94c6095b1272','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7140ba06bf60c551e26c6cec918dd8723dcbad7286f338d5138bfaee88c1d870',2004,'LT','Lithuania','economy',744,'total: 28
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 2
under 914 m: 14 (2003 est.)
total: 74
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 67 (2003 est.)
contamination of soil and groundwater with petroleum
products and chemicals at military bases
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.9% (FY01)
14.62 billion kWh (2001)
8.683 billion kWh (2001)
1.389 billion kWh (2001)
6.3 billion kWh (2001)
NA
lowest 10%: 3.1%
highest 10%: 25.6% (1996)
agriculture 20%, industry 30%, services 50% (1997 est.)
mineral products 23%, textiles and clothing 16%, machinery
and equipment 11%, chemicals 6%, wood and wood products 5%,
foodstuffs 5% (2001)
Switzerland 11.6%, Russia 10.1%, Germany 9.9%, Latvia
9.7%, UK 6.4%, France 5.1%, Denmark 4.7%, Estonia 4.3%, Sweden 4%
(2003)
10 counties (apskritys, singular - apskritis); Alytaus,
Kauno, Klaipedos, Marijampoles, Panevezio, Siauliu, Taurages,
Telsiu, Utenos, Vilniaus
grain, potatoes, sugar beets, flax, vegetables; beef,
milk, eggs; fish
102 (2003 est.)
8.49 births/1,000 population (2004 est.)
National Defense Volunteer Forces (SKAT), Ground Forces,
Navy, Air Force
revenues: $5.427 billion
expenditures: $5.742 billion, including capital expenditures of NA
(2003 est.)
Lithuania, the Baltic state that has conducted the most
trade with Russia, has slowly rebounded from the 1998 Russian
financial crisis. Unemployment remains high, still 10.7% in 2003,
but is improving. Growing domestic consumption and increased
investment have furthered recovery. Trade has been increasingly
oriented toward the West. Lithuania has gained membership in the
World Trade Organization and has moved ahead with plans to join the
EU. Privatization of the large, state-owned utilities, particularly
in the energy sector, is nearing completion. Overall, more than 80%
of enterprises have been privatized. Foreign government and business
support have helped in the transition from the old command economy
to a market economy.
gas 1,696 km; oil 331 km; refined products 109 km (2004)','286b73af1e96e09a04d64a357b823d72f9ea6642ea1b5f06f53c801ffafeca29','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4cd1046a332d9b3cae640ca5b515079ac8c8a29853b5535accefeac6cb0730',2004,'LU','Luxembourg','economy',745,'total: 1
over 3,047 m: 1 (2004 est.)
Macau
total: 1
over 3,047 m: 1 (2004 est.)
Macedonia
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
Macedonia
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2004 est.)
air and water pollution in urban areas, soil pollution of
farmland
Macau
NA
Macedonia
air pollution from metallurgical plants
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Macedonia
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.9% (2003)
Macedonia
6% (FY01/02 est.)
457 million kWh (2001)
Macau
1.611 billion kWh (2002)
Macedonia
6.465 billion kWh (2001)
6.07 billion kWh (2001)
Macau
1.688 billion kWh (2002)
Macedonia
6.112 billion kWh (2001)
6.389 billion kWh (2001)
Macau
193 million kWh (2002)
Macedonia
100 million kWh (2001)
744 million kWh (2001)
Macau
1 million kWh (2001)
Macedonia
0 kWh (2001)
NA
Macau
NA
Macedonia
30.2% (2002 est.)
lowest 10%: NA
highest 10%: NA
Macau
lowest 10%: NA
highest 10%: NA
Macedonia
lowest 10%: NA
highest 10%: NA
agriculture 1.9%, industry 8%, services 90.1% (1999 est.)
Macau
manufacturing 20%, construction 7%, transport and
communications 6%, wholesale and retail trade 15%, restaurants and
hotels 12%, gambling 7%, public sector 8%, other services and
agriculture 25% (2002 est.)
Macedonia
agriculture NA, industry NA, services NA
machinery and equipment, steel products, chemicals,
rubber products, glass
Macau
clothing, textiles, footwear, cement, machines, and parts
Macedonia
food, beverages, tobacco; miscellaneous manufactures, iron
and steel
Germany 23.3%, France 19%, Belgium 10.4%, UK 9.1%, Italy
6.8%, Spain 4.6%, Netherlands 4.3% (2003)
Macau
US 49.4%, China 14.1%, Germany 8.1%, Hong Kong 6.7%, UK 4.5%
(2003)
Macedonia
Serbia and Montenegro 37.8%, Germany 27%, Italy 14.7%,
Greece 9.7%, Croatia 6.9%, US 6.1%, Netherlands 4.8% (2003)
3 districts; Diekirch, Grevenmacher, Luxembourg
Macau
none (special administrative region of China)
Macedonia
123 municipalities (opstini, singular - opstina);
Aracinovo, Bac, Belcista, Berovo, Bistrica, Bitola, Blatec,
Bogdanci, Bogomila, Bogovinje, Bosilovo, Brvenica, Cair (Skopje),
Capari, Caska, Cegrane, Centar (Skopje), Centar Zupa, Cesinovo,
Cucer-Sandevo, Debar, Delcevo, Delogozdi, Demir Hisar, Demir Kapija,
Dobrusevo, Dolna Banjica, Dolneni, Dorce Petrov (Skopje), Drugovo,
Dzepciste, Gazi Baba (Skopje), Gevgelija, Gostivar, Gradsko,
Ilinden, Izvor, Jegunovce, Kamenjane, Karbinci, Karpos (Skopje),
Kavadarci, Kicevo, Kisela Voda (Skopje), Klecevce, Kocani, Konce,
Kondovo, Konopiste, Kosel, Kratovo, Kriva Palanka, Krivogastani,
Krusevo, Kuklis, Kukurecani, Kumanovo, Labunista, Lipkovo, Lozovo,
Lukovo, Makedonska Kamenica, Makedonski Brod, Mavrovi Anovi,
Meseista, Miravci, Mogila, Murtino, Negotino, Negotino-Polosko,
Novaci, Novo Selo, Oblesevo, Ohrid, Orasac, Orizari, Oslomej,
Pehcevo, Petrovec, Plasnica, Podares, Prilep, Probistip, Radovis,
Rankovce, Resen, Rosoman, Rostusa, Samokov, Saraj, Sipkovica,
Sopiste, Sopotnica, Srbinovo, Star Dojran, Staravina, Staro
Nagoricane, Stip, Struga, Strumica, Studenicani, Suto Orizari
(Skopje), Sveti Nikole, Tearce, Tetovo, Topolcani, Valandovo,
Vasilevo, Velesta, Veles, Vevcani, Vinica, Vitoliste, Vranestica,
Vrapciste, Vratnica, Vrutok, Zajas, Zelenikovo, Zeleno, Zitose,
Zletovo, Zrnovci
note: the seven municipalities followed by Skopje in parentheses
collectively constitute "greater Skopje"; new information suggests
that the 123 municipalities have been consolidated into 84
municipalities
barley, oats, potatoes, wheat, fruits, wine grapes;
livestock products
Macau
vegetables, livestock
Macedonia
rice, tobacco, wheat, corn, millet, cotton, sesame,
mulberry leaves, citrus, vegetables; beef, pork, poultry, mutton
2 (2003 est.)
Macau
1 (2003 est.)
Macedonia
17 (2003 est.)
12.21 births/1,000 population (2004 est.)
Macau
8.04 births/1,000 population (2004 est.)
Macedonia
13.14 births/1,000 population (2004 est.)
Army
Macau
responsibility for defense reverted to China on 20 December
1999; there are local police forces
Macedonia
Army of the Republic of Macedonia (ARM; including Air and
Air Defense Command)
revenues: $11.82 billion
expenditures: $12.06 billion, including capital expenditures of $760
million (2003 est.)
Macau
revenues: $1.9 billion
expenditures: $1.68 billion, including capital expenditures of $194
million (2002)
Macedonia
revenues: $1.582 billion
expenditures: $1.661 billion, including capital expenditures of $80
million NA (2003 est.)
This stable, high-income economy features solid growth,
low inflation, and low unemployment. The industrial sector,
initially dominated by steel, has become increasingly diversified to
include chemicals, rubber, and other products. Growth in the
financial sector, which now accounts for about 22% of GDP, has more
than compensated for the decline in steel. Most banks are
foreign-owned and have extensive foreign dealings. Agriculture is
based on small family-owned farms. The economy depends on foreign
and trans-border workers for more than 30% of its labor force.
Although Luxembourg, like all EU members, has suffered from the
global economic slump, the country has maintained a fairly strong
growth rate and enjoys an extraordinarily high standard of living.
Macau
Macau''s well-to-do economy has remained one of the most open
in the world since its reversion to China in 1999. The territory''s
net exports of goods and services account for roughly 41% of GDP
with tourism and apparel exports as the mainstays. Although the
territory was hit hard by the 1998 Asian financial crisis and the
global downturn in 2001, its economy grew 9.5% in 2002. A rapid rise
in the number of mainland visitors because of China''s easing of
restrictions on travel drove the recovery. The budget also returned
to surplus in 2002 because of the surge in visitors from China and a
hike in taxes on gambling profits, which generated about 70% of
government revenue. The liberalization of Macao''s gambling monopoly
contributes to GDP growth, as the three companies awarded gambling
licenses have pledged to invest $2.2 billion in the territory. Much
of Macau''s textile industry may move to the mainland as the
Multi-Fiber Agreement is phased out. The territory may have to rely
more on gambling and trade-related services to generate growth. The
government estimated GDP growth at 4% in 2003 with the drop in large
measure due to concerns over the Severe Acute Respiratory Syndrome
(SARS), but private sector analysts think the figure may have been
higher because of the continuing boom in tourism.
Macedonia
At independence in September 1991, Macedonia was the least
developed of the Yugoslav republics, producing a mere 5% of the
total federal output of goods and services. The collapse of
Yugoslavia ended transfer payments from the center and eliminated
advantages from inclusion in a de facto free trade area. An absence
of infrastructure, UN sanctions on Yugoslavia, one of its largest
markets, and a Greek economic embargo over a dispute about the
country''s constitutional name and flag hindered economic growth
until 1996. GDP subsequently rose each year through 2000. However,
the leadership''s commitment to economic reform, free trade, and
regional integration was undermined by the ethnic Albanian
insurgency of 2001. The economy shrank 4.5% because of decreased
trade, intermittent border closures, increased deficit spending on
security needs, and investor uncertainty. Growth barely recovered in
2002 to 0.9%, then rose to 2.8% in 2003. Unemployment at one-third
of the workforce remains the most critical economic problem. The
gray economy is estimated at around 40% of GDP. Politically, the
country is more stable than in 2002.
gas 155 km (2004)
Macedonia
gas 268 km; oil 120 km (2004)','1aee1f9d143a33821b1f16b9a93196876a0414f79baafddd926d5a3fc6f387e2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de45e4a0d8b3d517884d0ba8acadd5a99131d02126975c3198b8d8a58fcf6ce1',2004,'MG','Madagascar','economy',746,'total: 29
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (2004 est.)
total: 87
1,524 to 2,437 m: 2
914 to 1,523 m: 42
under 914 m: 43 (2004 est.)
soil erosion results from deforestation and overgrazing;
desertification; surface water contaminated with raw sewage and
other organic wastes; several species of flora and fauna unique to
the island are endangered
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.2% (2003)
830.2 million kWh (2001)
772.1 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
71% (1999 est.)
lowest 10%: 3%
highest 10%: 29% (1999)
coffee, vanilla, shellfish, sugar; cotton cloth,
chromite, petroleum products
France 37.4%, US 29.2%, Germany 5.5%, Mauritius 5.2%
(2003)
6 provinces (faritany); Antananarivo, Antsiranana,
Fianarantsoa, Mahajanga, Toamasina, Toliara
coffee, vanilla, sugarcane, cloves, cocoa, rice, cassava
(tapioca), beans, bananas, peanuts; livestock products
116 (2003 est.)
41.91 births/1,000 population (2004 est.)
People''s Armed Forces: comprising Intervention Force,
Development Force, and Aeronaval - Navy and Air - Force; National
Gendarmerie
revenues: $739.6 million
expenditures: $1.071 billion, including capital expenditures of $331
million (2003)
Having discarded past socialist economic policies,
Madagascar has since the mid 1990s followed a World Bank and IMF led
policy of privatization and liberalization. This strategy has placed
the country on a slow and steady growth path from an extremely low
level. Agriculture, including fishing and forestry, is a mainstay of
the economy, accounting for more than one-fourth of GDP and
employing four-fifths of the population. Exports of apparel have
boomed in recent years primarily due to duty-free access to the
United States. Deforestation and erosion, aggravated by the use of
firewood as the primary source of fuel are serious concerns.
President RAVALOMANANA has worked aggressively to revive the economy
following the 2002 political crisis, which triggered a 12% drop in
GDP that year. Poverty reduction and combating corruption will be
the centerpieces of economic policy for the next few years.','9407aaeba7aa8a35575ec9ee7016dbbc10b5191d24c93086ff8683dc9484dd36','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33010c9a8d5aad58b39849886f0acf658bf8fbccb0ca56ac4cdc0db41fe0faa5',2004,'MW','Malawi','economy',747,'total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 4 (2004 est.)
total: 36
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 20 (2004 est.)
deforestation; land degradation; water pollution from
agricultural runoff, sewage, industrial wastes; siltation of
spawning grounds endangers fish populations
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
0.7% (2003)
769.2 million kWh (2001)
715.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
55% (2003 est.)
lowest 10%: NA
highest 10%: NA
agriculture 90% (2003 est.)
tobacco 60%, tea, sugar, cotton, coffee, peanuts, wood
products, apparel
South Africa 23.3%, US 13.4%, Germany 11.3%, Egypt 5.7%,
Portugal 4.8%, Japan 4.5%, Netherlands 4.1% (2003)
27 districts; Balaka, Blantyre, Chikwawa, Chiradzulu,
Chitipa, Dedza, Dowa, Karonga, Kasungu, Likoma, Lilongwe, Machinga
(Kasupe), Mangochi, Mchinji, Mulanje, Mwanza, Mzimba, Ntcheu, Nkhata
Bay, Nkhotakota, Nsanje, Ntchisi, Phalombe, Rumphi, Salima, Thyolo,
Zomba
tobacco, sugarcane, cotton, tea, corn, potatoes, cassava
(tapioca), sorghum, pulses; groundnuts, Macadamia nuts; cattle, goats
42 (2003 est.)
44.35 births/1,000 population (2004 est.)
Army (including Air Wing and Naval Detachment), Police
(including Mobile Force Unit)
revenues: $528.1 million
expenditures: $653.2 million, including capital expenditures of NA
(2003)
Landlocked Malawi ranks among the world''s least developed
countries. The economy is predominately agricultural, with about 90%
of the population living in rural areas. Agriculture accounted for
nearly 40% of GDP and 88% of export revenues in 2001. The economy
depends on substantial inflows of economic assistance from the IMF,
the World Bank, and individual donor nations. In late 2000, Malawi
was approved for relief under the Heavily Indebted Poor Countries
(HIPC) program. In November 2002 the World Bank approved a $50
million drought recovery package, which is to be used for famine
relief. The government faces strong challenges, e.g., to fully
develop a market economy, to improve educational facilities, to face
up to environmental problems, to deal with the rapidly growing
problem of HIV/AIDS, and to satisfy foreign donors that fiscal
discipline is being tightened. The performance of the tobacco sector
is key to short-term growth as tobacco accounts for over 50% of
exports.','35a142e613428039e178fa69b51e4aa047ce6fc6409af86ca764c23369489d59','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91c75b1182a8c1bf2ab7ed5d458fa557f92b1f86fd3c4ec73ed9720ce8920614',2004,'MY','Malaysia','economy',748,'total: 38
over 3,047 m: 5
2,438 to 3,047 m: 7
1,524 to 2,437 m: 10
914 to 1,523 m: 9
under 914 m: 7 (2004 est.)
total: 79
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 72 (2004 est.)
air pollution from industrial and vehicular emissions;
water pollution from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
2.03% (FY00)
75.33 billion kWh (2002)
68.4 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
8% (1998 est.)
lowest 10%: 1.4%
highest 10%: 39.2% (2003 est.)
agriculture 14.5%, industry 36%, services 49.5% (2000 est.)
electronic equipment, petroleum and liquefied natural gas,
wood and wood products, palm oil, rubber, textiles, chemicals
US 19.6%, Singapore 15.7%, Japan 10.7%, China 6.5%, Hong
Kong 6.5%, Thailand 4.4% (2003)
13 states (negeri-negeri, singular - negeri) Johor, Kedah,
Kelantan, Melaka, Negeri Sembilan, Pahang, Perak, Perlis, Pulau
Pinang, Sabah, Sarawak, Selangor, and Terengganu; and one federal
territory (wilayah persekutuan) with three components, city of Kuala
Lumpur, Labuan, and Putrajaya
Peninsular Malaysia - rubber, palm oil, cocoa, rice; Sabah
- subsistence crops, rubber, timber, coconuts, rice; Sarawak -
rubber, pepper; timber
117 (2003 est.)
23.37 births/1,000 population (2004 est.)
Malaysian Army, Royal Malaysian Navy, Royal Malaysian Air
Force, Royal Malaysian Marine Police, Sarawak Border Scouts
revenues: $22.95 billion
expenditures: $27.75 billion, including capital expenditures of $9.4
billion (2003 est.)
Malaysia, a middle-income country, transformed itself from
1971 through the late 1990s from a producer of raw materials into an
emerging multi-sector economy. Growth was almost exclusively driven
by exports - particularly of electronics. As a result Malaysia was
hard hit by the global economic downturn and the slump in the
information technology (IT) sector in 2001 and 2002. GDP in 2001
grew only 0.5% due to an estimated 11% contraction in exports, but a
substantial fiscal stimulus package equal to US $1.9 billion
mitigated the worst of the recession and the economy rebounded in
2002 with a 4.1% increase. The economy grew 4.9% in 2003,
notwithstanding a difficult first half, when external pressures from
SARS and the Iraq War led to caution in the business community.
Healthy foreign exchange reserves and a relatively small external
debt make it unlikely that Malaysia will experience a crisis similar
to the one in 1997, but the economy remains vulnerable to a more
protracted slowdown in Japan and the US, top export destinations and
key sources of foreign investment. The Malaysian ringgit is pegged
to the dollar, and the Japanese central bank continues to intervene
and prop up the yen against the dollar.
condensate 279 km; gas 5,047 km; oil 1,841 km; refined
products 114 km (2004)','f7e7e1daa1862de6fc92e1a0d537f196f4d75ec5d08a59ea9de2a299cd652dc4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('268ef10d05f6e71134e58fa07efaaf5a2c6d5e1338f28a2abc5147ad6f8fadae',2004,'MV','Maldives','economy',749,'total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 3
914 to 1,523 m: 3 (2004 est.)
depletion of freshwater aquifers threatens water supplies;
global warming and sea level rise; coral reef bleaching
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
8.6% (2003)
117 million kWh (2001)
108.8 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 22%, industry 18%, services 60% (1995)
fish, clothing
US 32.1%, Thailand 17%, Sri Lanka 13.4%, Japan 10.7%, UK
9.8%, Indonesia 4.5% (2003)
19 atolls (atholhu, singular and plural) and 1 other
first-order administrative division*; Alifu, Baa, Dhaalu, Faafu,
Gaafu Alifu, Gaafu Dhaalu, Gnaviyani, Haa Alifu, Haa Dhaalu, Kaafu,
Laamu, Lhaviyani, Maale*, Meemu, Noonu, Raa, Seenu, Shaviyani, Thaa,
Vaavu
coconuts, corn, sweet potatoes; fish
5 (2003 est.)
36.06 births/1,000 population (2004 est.)
National Security Service: comprising Security Branch
(ground forces), Air Element; Coast Guard
revenues: $224 million (excluding foreign grants)
expenditures: $282 million, including capital expenditures of $80
million (2002 est.)
Tourism, Maldives'' largest industry, accounts for 20% of
GDP and more than 60% of the Maldives'' foreign exchange receipts.
Over 90% of government tax revenue comes from import duties and
tourism-related taxes. Fishing is a second leading sector. The
Maldivian Government began an economic reform program in 1989
initially by lifting import quotas and opening some exports to the
private sector. Subsequently, it has liberalized regulations to
allow more foreign investment. Agriculture and manufacturing
continue to play a lesser role in the economy, constrained by the
limited availability of cultivable land and the shortage of domestic
labor. Most staple foods must be imported. Industry, which consists
mainly of garment production, boat building, and handicrafts,
accounts for about 18% of GDP. Maldivian authorities worry about the
impact of erosion and possible global warming on their low-lying
country; 80% of the area is one meter or less above sea level.','1fb269b5e51ee50327521ca22e0943e3fb1e1c689fac80ccd17c859c5255d27d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a5638535adac362e41442a8a209e167f1a49b0f677dfe4df8481527a2b097bd',2004,'ML','Mali','economy',750,'total: 9
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2004 est.)
total: 19
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 8 (2004 est.)
deforestation; soil erosion; desertification; inadequate
supplies of potable water; poaching
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.3% (2003)
480.2 million kWh (2001)
446.6 million kWh (2001)
0 kWh (2001)
0 kWh; note - recent hydropower developments may be providing
electricity to Senegal and Mauritania (2001)
64% average; 30% of the total population living in urban areas;
70% of the total population living in rural areas) (2001 est.)
lowest 10%: 1.8%
highest 10%: 40.4% (1994)
agriculture and fishing 80% (2001 est.)
cotton, gold, livestock
Thailand 14%, China 12.1%, India 7.9%, Italy 7.5%, Bangladesh
6.1%, UK 6.1% (2003)
8 regions (regions, singular - region); Gao, Kayes, Kidal,
Koulikoro, Mopti, Segou, Sikasso, Tombouctou
cotton, millet, rice, corn, vegetables, peanuts; cattle, sheep,
goats
27 (2003 est.)
47.29 births/1,000 population (2004 est.)
Army, Air Force, National Guard
revenues: $764 million
expenditures: $828 million, including capital expenditures of NA
(2002 est.)
Mali is among the poorest countries in the world, with 65% of
its land area desert or semidesert and with a highly unequal
distribution of income. Economic activity is largely confined to the
riverine area irrigated by the Niger. About 10% of the population is
nomadic and some 80% of the labor force is engaged in farming and
fishing. Industrial activity is concentrated on processing farm
commodities. Mali is heavily dependent on foreign aid and vulnerable
to fluctuations in world prices for cotton, its main export, along
with gold. The government has continued its successful
implementation of an IMF-recommended structural adjustment program
that is helping the economy grow, diversify, and attract foreign
investment. Mali''s adherence to economic reform and the 50%
devaluation of the African franc in January 1994 have pushed up
economic growth to a sturdy 5% average in 1996-2002. Worker
remittances and external trade routes have been jeopardized by
continued unrest in neighboring Cote d''Ivoire.','02267b35406d92252ff49e19015474360ec1132adf41153019ae456a0e248c52','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a00ae636e6d40a64241af6f2288ca715c51677e7cda96bfb51a0f02e092c0b2b',2004,'MT','Malta','economy',751,'total: 1
over 3,047 m: 1 (2004 est.)
Man, Isle of
total: 1
1,524 to 2,437 m: 1 (2004 est.)
very limited natural fresh water resources; increasing
reliance on desalination
Man, Isle of
waste disposal (both household and industrial);
transboundary air pollution
party to: Air Pollution, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.7% (2003)
1.768 billion kWh (2001)
1.644 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
Man, Isle of
NA
lowest 10%: NA
highest 10%: NA
Man, Isle of
lowest 10%: NA
highest 10%: NA
agriculture 5%, industry 24%, services 71% (1999 est.)
Man, Isle of
agriculture, forestry and fishing 3%, manufacturing
11%, construction 10%, transport and communication 8%, wholesale and
retail distribution 11%, professional and scientific services 18%,
public administration 6%, banking and finance 18%, tourism 2%,
entertainment and catering 3%, miscellaneous services 10%
machinery and transport equipment, manufactures
Man, Isle of
tweeds, herring, processed shellfish, beef, lamb
Singapore 17.4%, US 11.6%, UK 9.4%, Germany 8.8%, France 7.5%,
China 7% (2003)
Man, Isle of
UK (2000)
none (administered directly from Valletta); note - Local
Councils carry out administrative orders
Man, Isle of
none; there are no first-order administrative divisions
as defined by the US Government, but there are 24 local authorities
each with its own elections
potatoes, cauliflower, grapes, wheat, barley, tomatoes,
citrus, cut flowers, green peppers; pork, milk, poultry, eggs
Man, Isle of
cereals, vegetables; cattle, sheep, pigs, poultry
1 (2003 est.)
Man, Isle of
1 (2003 est.)
10.09 births/1,000 population (2004 est.)
Man, Isle of
11.28 births/1,000 population (2004 est.)
Armed Forces: Land Forces (including Air Squadron and Maritime
Squadron), Revenue Security Corps
revenues: $2.086 billion
expenditures: $2.367 billion, including capital expenditures of NA
(2003)
Man, Isle of
revenues: $485 million
expenditures: $463 million, including capital expenditures of NA
(FY00/01 est.)
Major resources are limestone, a favorable geographic
location, and a productive labor force. Malta produces only about
20% of its food needs, has limited fresh water supplies, and has no
domestic energy sources. The economy is dependent on foreign trade,
manufacturing (especially electronics and textiles), and tourism.
Malta is privatizing state-controlled firms and liberalizing markets
in order to prepare for membership in the European Union. The island
remains divided politically, however, over the question of joining
the EU. Continued sluggishness in the global economy is holding back
exports, tourism, and overall growth.
Man, Isle of
Offshore banking, manufacturing, and tourism are key
sectors of the economy. The government''s policy of offering
incentives to high-technology companies and financial institutions
to locate on the island has paid off in expanding employment
opportunities in high-income industries. As a result, agriculture
and fishing, once the mainstays of the economy, have declined in
their shares of GDP. Trade is mostly with the UK. The Isle of Man
enjoys free access to EU markets.','264d5b2d89fab082b88b97135c83db4af434d42dcc673f8203246a1f32f6fd2d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('627842d6a09ca77053ebbe44a395fbfec8abc650600791b3803f84e6f875d3f1',2004,'MH','Marshall Islands','economy',752,'total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2004 est.)
total: 11
914 to 1,523 m: 10
under 914 m: 1 (2004 est.)
inadequate supplies of potable water; pollution of
Majuro lagoon from household waste and discharges from fishing
vessels
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA
NA
lowest 10%: NA
highest 10%: NA
agriculture 21.4%, industry 20.9%, services 57.7%
copra cake, coconut oil, handicrafts, fish
US, Japan, Australia, China (2000)
33 municipalities; Ailinginae, Ailinglaplap, Ailuk,
Arno, Aur, Bikar, Bikini, Bokak, Ebon, Enewetak, Erikub, Jabat,
Jaluit, Jemo, Kili, Kwajalein, Lae, Lib, Likiep, Majuro, Maloelap,
Mejit, Mili, Namorik, Namu, Rongelap, Rongrik, Toke, Ujae, Ujelang,
Utirik, Wotho, Wotje
coconuts, tomatoes, melons, taro, breadfruit,
fruits; pigs, chickens
15 (2003 est.)
33.88 births/1,000 population (2004 est.)
no regular military forces; Marshall Islands Police
revenues: $42 million
expenditures: $40 million, including capital expenditures of $NA
(1999)
US Government assistance is the mainstay of this
tiny island economy. Agricultural production is primarily
subsistence and is concentrated on small farms; the most important
commercial crops are coconuts and breadfruit. Small-scale industry
is limited to handicrafts, tuna processing, and copra. The tourist
industry, now a small source of foreign exchange employing less than
10% of the labor force, remains the best hope for future added
income. The islands have few natural resources, and imports far
exceed exports. Under the terms of the Compact of Free Association,
the US has provided more than $1 billion in aid since 1986.
Negotiations have continued for an extended agreement. Government
downsizing, drought, a drop in construction, the decline in tourism
and foreign investment due to the Asian financial difficulties, and
less income from the renewal of fishing vessel licenses have held
GDP growth to an average of 1% over the past decade.','261ef04b7578fc5692fea6615a109423f38c202b822974c15f8cb4b6b2d3c56a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b09aa732586f1f5e410d79da036a7f321a3ffcf134c15f0673a27eb7d30899d6',2004,'MQ','Martinique','economy',753,'total: 1
over 3,047 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
NA
1.151 billion kWh (2001)
1.07 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 10%, industry 17%, services 73% (1997)
refined petroleum products, bananas, rum, pineapples
(2001 est.)
France 45%, Guadeloupe 28% (2000)
none (overseas department of France)
pineapples, avocados, bananas, flowers, vegetables,
sugarcane
2 (2003 est.)
14.56 births/1,000 population (2004 est.)
no regular military forces; Gendarmerie
revenues: $900 million
expenditures: $2.5 billion, including capital expenditures of $140
million (1996)
The economy is based on sugarcane, bananas, tourism, and
light industry. Agriculture accounts for about 6% of GDP and the
small industrial sector for 11%. Sugar production has declined, with
most of the sugarcane now used for the production of rum. Banana
exports are increasing, going mostly to France. The bulk of meat,
vegetable, and grain requirements must be imported, contributing to
a chronic trade deficit that requires large annual transfers of aid
from France. Tourism, which employs more than 11,000 people, has
become more important than agricultural exports as a source of
foreign exchange.','728179cdc9c9251405dbef2b0b14743d9824e27554cbf7075c7b1f9c538431cb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0be8d495766f89f34694fbc7ce343a454843fc6332ddc2fcd8e6fa3439f0a88',2004,'MR','Mauritania','economy',754,'total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5 (2004 est.)
total: 16
1,524 to 2,437 m: 9
914 to 1,523 m: 6
under 914 m: 1 (2004 est.)
overgrazing, deforestation, and soil erosion aggravated
by drought are contributing to desertification; very limited natural
fresh water resources away from the Senegal, which is the only
perennial river; locust infestation
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
3.7% (2003)
157.4 million kWh (2001)
146.3 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
50% (2001 est.)
lowest 10%: 2.5%
highest 10%: 30.2% (2000)
agriculture 50%, industry 10%, services 40% (2001 est.)
iron ore, fish and fish products, gold
Japan 12.5%, France 12.1%, Spain 11.4%, Italy 10.4%,
Belgium 7.8%, Germany 7.4%, Russia 5%, Cote d''Ivoire 4.2%,
Netherlands 4% (2003)
12 regions (regions, singular - region) and 1 capital
district*; Adrar, Assaba, Brakna, Dakhlet Nouadhibou, Gorgol,
Guidimaka, Hodh Ech Chargui, Hodh El Gharbi, Inchiri, Nouakchott*,
Tagant, Tiris Zemmour, Trarza
dates, millet, sorghum, rice, corn, dates; cattle, sheep
24 (2003 est.)
41.79 births/1,000 population (2004 est.)
Army, Navy (including Naval Infantry), Air Force,
National Gendarmerie, National Guard, National Police, Presidential
Guard (BSSP)
revenues: $421 million
expenditures: $378 million, including capital expenditures of $154
million (2002 est.)
Half the population still depends on agriculture and
livestock for a livelihood, even though many of the nomads and
subsistence farmers were forced into the cities by recurrent
droughts in the 1970s and 1980s. Mauritania has extensive deposits
of iron ore, which account for nearly 40% of total exports. The
decline in world demand for this ore, however, has led to cutbacks
in production. The nation''s coastal waters are among the richest
fishing areas in the world, but overexploitation by foreigners
threatens this key source of revenue. The country''s first deepwater
port opened near Nouakchott in 1986. In the past, drought and
economic mismanagement resulted in a buildup of foreign debt. In
February 2000, Mauritania qualified for debt relief under the
Heavily Indebted Poor Countries (HIPC) initiative and in December
2001 received strong support from donor and lending countries at a
triennial Consultative Group review. In 2001, exploratory oil wells
in tracts 80 km offshore indicated potential extraction at current
world oil prices. A new investment code approved in December 2001
improved the opportunities for direct foreign investment. Ongoing
negotiations with the IMF involve problems of economic reforms and
fiscal discipline. Substantial oil production and exports probably
will not begin until 2005. Meantime the government emphasizes
reduction of poverty, improvement of health and education, and
promoting privatization of the economy.','03a1e436298385d651159db461900fdd143ca1f06553152fd1f3a9d39fafc29f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('333868ed9e453415e2ccadbb5bf4b859549e1adce5331864a17421e728d3f593',2004,'MU','Mauritius','economy',755,'total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 4
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
water pollution, degradation of coral reefs
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.2% (2003)
1.311 billion kWh (2001)
1.219 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
10% (2001 est.)
lowest 10%: NA
highest 10%: NA
agriculture and fishing 14%, construction and industry
36%, transportation and communication 7%, trade, restaurants, hotels
16%, finance 3%, other services 24% (1995)
clothing and textiles, sugar, cut flowers, molasses
UK 31%, France 21.3%, US 17.6%, Madagascar 6.3% (2003)
9 districts and 3 dependencies*; Agalega Islands*, Black
River, Cargados Carajos Shoals*, Flacq, Grand Port, Moka,
Pamplemousses, Plaines Wilhems, Port Louis, Riviere du Rempart,
Rodrigues*, Savanne
sugarcane, tea, corn, potatoes, bananas, pulses; cattle,
goats; fish
5 (2003 est.)
15.85 births/1,000 population (2004 est.)
National Police Force (includes the paramilitary Special
Mobile Force or SMF and National Coast Guard)
revenues: $1.122 billion
expenditures: $1.461 billion, including capital expenditures of $NA
(2003)
Since independence in 1968, Mauritius has developed from a
low-income, agriculturally based economy to a middle-income
diversified economy with growing industrial, financial, and tourist
sectors. For most of the period, annual growth has been in the order
of 5% to 6%. This remarkable achievement has been reflected in more
equitable income distribution, increased life expectancy, lowered
infant mortality, and a much-improved infrastructure. Sugarcane is
grown on about 90% of the cultivated land area and accounts for 25%
of export earnings. The government''s development strategy centers on
expanding local financial institutions and building a domestic
information telecommunications industry. Mauritius has attracted
more than 9,000 offshore entities, many aimed at commerce in India
and South Africa, and investment in the banking sector alone has
reached over $1 billion. Mauritius, with its strong textile sector
and responsible fiscal management, has been well poised to take
advantage of the Africa Growth and Opportunity Act (AGOA).','2e72b76496e18d4ccfad2fe86f6590898fa1e68759b421ce0830458ab693f67f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('881f5ebf9d2800f10d6a9a34f52f171d79c2ab1669c6907f2773a88409b4f0d4',2004,'YT','Mayotte','economy',756,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
NA
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
ylang-ylang (perfume essence), vanilla, copra, coconuts,
coffee, cinnamon
France 80%, Comoros 15%, Reunion (2000)
none (territorial collectivity of France)
vanilla, ylang-ylang (perfume essence), coffee, copra
1 (2003 est.)
42.19 births/1,000 population (2004 est.)
revenues: NA
expenditures: $73 million, including capital expenditures of NA
(1991 est.)
Economic activity is based primarily on the agricultural
sector, including fishing and livestock raising. Mayotte is not
self-sufficient and must import a large portion of its food
requirements, mainly from France. The economy and future development
of the island are heavily dependent on French financial assistance,
an important supplement to GDP. Mayotte''s remote location is an
obstacle to the development of tourism.','4494bfb501c227d870b9182e0633b53d4b9c3c38f6f4e5fd3802c1223a3dd552','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc7f1391ae27f766cc65f5901891a182de7f871e7f90aa932511dbde4473405c',2004,'MX','Mexico','economy',757,'total: 233
over 3,047 m: 12
2,438 to 3,047 m: 28
1,524 to 2,437 m: 84
914 to 1,523 m: 80
under 914 m: 29 (2004 est.)
total: 1,600
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 69
914 to 1,523 m: 454
under 914 m: 1,075 (2004 est.)
Midway Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
Moldova
total: 18
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 11 (2003 est.)
scarcity of hazardous waste disposal facilities; rural to
urban migration; natural fresh water resources scarce and polluted
in north, inaccessible and poor quality in center and extreme
southeast; raw sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion; desertification;
deteriorating agricultural lands; serious air and water pollution in
the national capital and urban centers along US-Mexico border; land
subsidence in Valley of Mexico caused by groundwater depletion
note: the government considers the lack of clean water and
deforestation national security issues
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
0.9% (2003)
Moldova
0.4% (FY02)
198.6 billion kWh (2001)
186.7 billion kWh (2001)
2.068 billion kWh (2001)
Moldova
60 million kWh (2001)
77 million kWh (2001)
Moldova
0 kWh (2001)
40% (2003 est.)
lowest 10%: 1.6%
highest 10%: 35.6% (2002)
agriculture 18%, industry 24%, services 58% (2003)
manufactured goods, oil and oil products, silver, fruits,
vegetables, coffee, cotton
US 87.6%, Canada 1.8%, Germany 1.2% (2003)
31 states (estados, singular - estado) and 1 federal
district* (distrito federal); Aguascalientes, Baja California, Baja
California Sur, Campeche, Chiapas, Chihuahua, Coahuila de Zaragoza,
Colima, Distrito Federal*, Durango, Guanajuato, Guerrero, Hidalgo,
Jalisco, Mexico, Michoacan de Ocampo, Morelos, Nayarit, Nuevo Leon,
Oaxaca, Puebla, Queretaro de Arteaga, Quintana Roo, San Luis Potosi,
Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz-Llave,
Yucatan, Zacatecas
corn, wheat, soybeans, rice, beans, cotton, coffee, fruit,
tomatoes; beef, poultry, dairy products; wood products
1,827 (2003 est.)
21.44 births/1,000 population (2004 est.)
National Defense Secretariat (Sedena) (including Army and Air
Force), Navy Secretariat (including Naval Air and Marines)
Moldova
National Army: Ground Forces, Air Force
revenues: $148.3 billion
expenditures: $152.4 billion, including capital expenditures of NA
(2003 est.)
Mexico has a free market economy with a mixture of modern and
outmoded industry and agriculture, increasingly dominated by the
private sector. Recent administrations have expanded competition in
seaports, railroads, telecommunications, electricity generation,
natural gas distribution, and airports. Per capita income is
one-fourth that of the US; income distribution remains highly
unequal. Trade with the US and Canada has tripled since the
implementation of NAFTA in 1994. Real GDP growth was a weak -0.3% in
2001, 0.9% in 2002, and 1.2% in 2003, with the US slowdown the
principal cause. Mexico implemented free trade agreements with
Guatemala, Honduras, El Salvador, and the European Free Trade Area
in 2001, putting more than 90% of trade under free trade agreements.
The government is cognizant of the need to upgrade infrastructure,
modernize the tax system and labor laws, and provide incentives to
invest in the energy sector, but progress is slow.
crude oil 28,200 km; petroleum products 10,150 km; natural
gas 13,254 km; petrochemical 1,400 km (2003)
Moldova
gas 606 km (2004)','b4886eb805d4c321bd692934dfc1d944ab75833aec67bffb0082ae0a4d5255a2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0580fef10f934f1672ae04853de74e974e521d9b04b6e8e26b4e7947befca7b4',2004,'FM','Micronesia, Federated States of','economy',758,'total: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2004 est.)
Midway Islands
total: 2
1,524 to 2,437 m: 2 (2004 est.)
Moldova
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 1 (2003 est.)
overfishing, climate change,
pollution
Midway Islands
NA
Moldova
heavy use of agricultural chemicals, including banned
pesticides such as DDT, has contaminated soil and groundwater;
extensive soil erosion from poor farming methods
party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Moldova
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
NA kWh
Moldova
3.394 billion kWh (2001)
NA kWh
Moldova
3.216 billion kWh (2001)
26.7%
Moldova
80% (2001 est.)
lowest 10%: NA
highest 10%: NA
Moldova
lowest 10%: 2.2%
highest 10%: 30.7% (1997)
two-thirds are government employees
Moldova
agriculture 40%, industry 14%, services 46% (1998)
fish, garments, bananas, black pepper
Moldova
foodstuffs, textiles, machinery
Japan, US, Guam (2000)
Moldova
Russia 39%, Romania 11.4%, Italy 10.4%, Germany 7.1%,
Ukraine 7.1%, Belarus 5.2%, US 4.3% (2003)
4 states; Chuuk (Truk), Kosrae
(Kosaie), Pohnpei (Ponape), Yap
Moldova
32 raions (raioane, singular - raionul), 3 municipalities
(municipiul), 1 autonomous territorial unit (unitatea teritoriala
autonoma), and 1 territorial unit (unitatea teritoriala)
counties: Anenii Noi, Basarabeasca, Briceni, Cahul, Cantemir,
Calarasi, Causeni, Cimislia, Criuleni, Donduseni, Drochia, Dubasari,
Edinet, Falesti, Floresti, Glodeni, Hincesti, Ialoveni, Leova,
Nisporeni, Ocnita, Orhei, Rezina, Riscani, Singerei, Soldanesti,
Soroca, Stefan-Voda, Straseni, Taraclia, Telenesti, Ungheni
municipalities: Balti, Bender, Chisinau
autonomous territorial unit: Gagauzia
territorial unit: Stinga Nistrului
black pepper, tropical fruits and
vegetables, coconuts, cassava (tapioca), betel nuts, sweet potatoes;
pigs, chickens
Moldova
vegetables, fruits, wine, grain, sugar beets, sunflower
seed, tobacco; beef, milk
6 (2003 est.)
Midway Islands
3 (2003 est.)
Moldova
24 (2003 est.)
25.8 births/1,000 population (2004
est.)
Moldova
14.81 births/1,000 population (2004 est.)
revenues: $161 million ($69 million
less grants)
expenditures: $160 million, including capital expenditures of NA
(1998 est.)
Moldova
revenues: $474.8 million
expenditures: $443.4 million, including capital expenditures of NA
(2003 est.)
Economic activity consists primarily
of subsistence farming and fishing. The islands have few mineral
deposits worth exploiting, except for high-grade phosphate. The
potential for a tourist industry exists, but the remote location, a
lack of adequate facilities, and limited air connections hinder
development. In November 2002, the country experienced a further
reduction in future revenues from the Compact of Free Association -
the agreement with the US in which Micronesia received $1.3 billion
in financial and technical assistance over a 15-year period until
2001. The country''s medium-term economic outlook appears fragile due
not only to the reduction in US assistance but also to the slow
growth of the private sector. Geographical isolation and a poorly
developed infrastructure remain major impediments to long-term
growth.
Midway Islands
The economy is based on providing support services
for the national wildlife refuge activities located on the islands.
All food and manufactured goods must be imported.
Moldova
Moldova remains the poorest country in Europe despite recent
progress from its small economic base. It enjoys a favorable climate
and good farmland but has no major mineral deposits. As a result,
the economy depends heavily on agriculture, featuring fruits,
vegetables, wine, and tobacco. Moldova must import almost all of its
energy supplies from Russia. Energy shortages contributed to sharp
production declines after the breakup of the Soviet Union in 1991.
As part of an ambitious reform effort, Moldova introduced a
convertible currency, freed prices, stopped issuing preferential
credits to state enterprises, backed steady land privatization,
removed export controls, and freed interest rates. The government
entered into agreements with the World Bank and the IMF to promote
growth and reduce poverty. The economy returned to positive growth,
of 2.1% in 2000, 6.1% in 2001, 7.2% in 2002, and 6.3% in 2003.
Further reforms will come slowly because of strong political forces
backing government controls. The economy remains vulnerable to
higher fuel prices, poor agricultural weather, and the skepticism of
foreign investors.','120b8c50d31dd0ac71c143eca10db0ea801003cec829d469470b925e9d3b4616','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05c7f31e2b0398542224b245037384b9e81c29477b95c443bad55354d2493d41',2004,'MN','Mongolia','economy',759,'total: 11
over 3,047 m: 1
2,438 to 3,047 m: 10 (2003 est.)
total: 25
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 11
914 to 1,523 m: 2
under 914 m: 5 (2003 est.)
limited natural fresh water resources in some areas; the
policies of former Communist regimes promoted rapid urbanization and
industrial growth that had negative effects on the environment; the
burning of soft coal in power plants and the lack of enforcement of
environmental laws severely polluted the air in Ulaanbaatar;
deforestation, overgrazing, and the converting of virgin land to
agricultural production increased soil erosion from wind and rain;
desertification and mining activities had a deleterious effect on
the environment
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
2.2% (FY02)
2.225 billion kWh (2001)
2.194 billion kWh (2001)
196 million kWh (2001)
25 million kWh (2001)
33% (2003 est.)
lowest 10%: 2.1%
highest 10%: 37% (1995)
herding/agriculture 46%, manufacturing 6%, trade 10.3%,
public sector 4.7%, other/unemployed 33% (2001)
copper, livestock, animal products, cashmere, wool, hides,
fluorspar, other nonferrous metals
China 46.1%, US 23.2%, Russia 6.7%, Singapore 5.7%,
Australia 5.5%, UK 4.2% (2003)
21 provinces (aymguud, singular - aymag) and 1
municipality* (singular - hot); Arhangay, Bayanhongor, Bayan-Olgiy,
Bulgan, Darhan Uul, Dornod, Dornogovi, Dundgovi, Dzavhan,
Govi-Altay, Govi-Sumber, Hentiy, Hovd, Hovsgol, Omnogovi, Orhon,
Ovorhangay, Selenge, Suhbaatar, Tov, Ulaanbaatar*, Uvs
wheat, barley, potatoes, forage crops, sheep, goats,
cattle, camels, horses
36 (2003 est.)
21.44 births/1,000 population (2004 est.)
Mongolian People''s Army (comprising Ground Forces, Air
Defense Forces), Border Guards, Internal Security Forces,
Construction Corps Forces, Civil Defense Authority
revenues: $387 million
expenditures: $428 million, including capital expenditures of NA
(2001 est.)
Economic activity traditionally has been based on
agriculture and breeding of livestock. Mongolia also has extensive
mineral deposits; copper, coal, molybdenum, tin, tungsten, and gold
account for a large part of industrial production. Soviet
assistance, at its height one-third of GDP, disappeared almost
overnight in 1990-91 at the time of the dismantlement of the USSR.
Mongolia was driven into deep recession, prolonged by the Mongolian
People''s Revolutionary Party''s (MPRP) reluctance to undertake
serious economic reform. The Democratic Union Coalition (DUC)
government embraced free-market economics, eased price controls,
liberalized domestic and international trade, and attempted to
restructure the banking system and the energy sector. Major domestic
privatization programs were undertaken, as well as the fostering of
foreign investment through international tender of the oil
distribution company, a leading cashmere company, and banks. Reform
was held back by the ex-Communist MPRP opposition and by the
political instability brought about through four successive
governments under the DUC. Economic growth picked up in 1997-99
after stalling in 1996 due to a series of natural disasters and
declines in world prices of copper and cashmere. In August and
September 1999, the economy suffered from a temporary Russian ban on
exports of oil and oil products, and Mongolia remains vulnerable in
this sector. Mongolia joined the World Trade Organization (WTrO) in
1997. The international donor community pledged over $300 million
per year at the Consultative Group Meeting, held in Ulaanbaatar in
June 1999. The MPRP government, elected in July 2000, was anxious to
improve the investment climate; it also had to deal with a heavy
burden of external debt. Falling prices for Mongolia''s mainly
primary sector exports, widespread opposition to privatization, and
adverse effects of weather on agriculture in early 2000 and 2001
restrained real GDP growth. Despite drought problems in 2002, GDP
rose 4.0%, followed by a solid 5.0% increase in 2003. The first
applications under the land privatization law have been marked by a
number of disputes over particular sites. Russia claims Mongolia
owes it $11 billion from the Soviet period; any settlement could
substantially increase Mongolia''s foreign debt burden.','2702215eef77fc8e257a71a69709c5df15eaa1725befe690052e2608e64fe184','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cfd15097f7f4261cf6d243af2776e3d7cb3858f331aa0fa3735f9f512ec0913',2004,'MS','Montserrat','economy',760,'total: 1
under 914 m: 1 (2004 est.)
land erosion occurs on slopes that have been cleared for
cultivation
2.5 million kWh (2001)
2.325 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
electronic components, plastic bags, apparel, hot
peppers, live plants, cattle
US, Antigua and Barbuda
3 parishes; Saint Anthony, Saint Georges, Saint Peter
cabbages, carrots, cucumbers, tomatoes, onions, peppers,
livestock products
1 (2003 est.)
17.63 births/1,000 population (2004 est.)
no regular indigenous military forces; Police Force
revenues: $31.4 million
expenditures: $31.6 million, including capital expenditures of $8.4
million (1997 est.)
Severe volcanic activity, which began in July 1995, has
put a damper on this small, open economy. A catastrophic eruption in
June 1997 closed the airports and seaports, causing further economic
and social dislocation. Two-thirds of the 12,000 inhabitants fled
the island. Some began to return in 1998, but lack of housing
limited the number. The agriculture sector continued to be affected
by the lack of suitable land for farming and the destruction of
crops. Prospects for the economy depend largely on developments in
relation to the volcano and on public sector construction activity.
The UK has launched a three-year $122.8 million aid program to help
reconstruct the economy. Half of the island is expected to remain
uninhabitable for another decade.','1d48983912a3e6df162074d5154edda8a9360db64d375c74421c19638c4666d9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8038a6a84a30ead1fda2b3ba6e65c8baef69ad2bd22afdd5df0563485201a490',2004,'MA','Morocco','economy',761,'total: 25
over 3,047 m: 11
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 38
2,438 to 3,047 m: 2
1,524 to 2,437 m: 10
914 to 1,523 m: 15
under 914 m: 11 (2004 est.)
land degradation/desertification (soil erosion resulting
from farming of marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw sewage; siltation of
reservoirs; oil pollution of coastal waters
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Environmental Modification, Law of the Sea
4.8% (2003)
13.35 billion kWh (2001)
14.61 billion kWh (2001)
2.2 billion kWh (2001)
0 kWh (2001)
19% (1999 est.)
lowest 10%: 2.6%
highest 10%: 30.9% (1998-99)
agriculture 40%, industry 15%, services 45% (2003 est.)
clothing, fish, inorganic chemicals, transistors, crude
minerals, fertilizers (including phosphates), petroleum products,
fruits, vegetables
France 26.5%, Spain 16.7%, UK 7.2%, Germany 5.2%, Italy 5%,
US 4% (2003)
16 regions: Casablanca, Chaouia-Ourdigha, Doukkala-Abda,
Fes-Boulmane, Gharb-Chrarda-Beni Hssen, Guelmim-Es Smara,
Laayoune-Boujdour-Sakia El Hamra, Marrakech-Tensift-El Haouz,
Meknes-Tafilalet, Oriental, Oued Eddahab-Lagouira,
Rabat-Sale-Zemmour-Zaer, Souss-Massa-Draa, Tadla-Azilal,
Tangier-Tetouan, Taza-Al Hoceima-Taounate
barley, wheat, citrus, wine, vegetables, olives; livestock
64 (2003 est.)
22.79 births/1,000 population (2004 est.)
Royal Armed Forces: Army, Navy, Air Force
revenues: $13.8 billion
expenditures: $14 billion, including capital expenditures of $2.1
billion (2004 est.)
Morocco faces the problems typical of developing countries -
restraining government spending, reducing constraints on private
activity and foreign trade, and achieving sustainable economic
growth. Despite structural adjustment programs supported by the IMF,
the World Bank, and the Paris Club, the dirham is only fully
convertible for current account transactions. Reforms of the
financial sector are being contemplated. Droughts depressed activity
in the key agricultural sector and contributed to a stagnant economy
in 2002. Morocco reported large foreign exchange inflows from the
sale of a mobile telephone license, and partial privatization of the
state-owned telecommunications company and the state tobacco
company. Favorable rainfall in 2003 led to a growth of 6%.
Formidable long-term challenges include: preparing the economy for
freer trade with the EU and US, improving education, and attracting
foreign investment to boost living standards and job prospects for
Morocco''s youth.
gas 695 km; oil 285 km (2004)','888f46a734b3563194c84d1326b8ca8a2b4164df3035232ec02ce2d45f07a87f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb59826ff8563a1c44af531f37d70525ffc8bd22e663b2aa7debd25e2c467c1',2004,'MZ','Mozambique','economy',762,'total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (2004 est.)
total: 136
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 34
under 914 m: 87 (2004 est.)
a long civil war and recurrent drought in the hinterlands
have resulted in increased migration of the population to urban and
coastal areas with adverse environmental consequences;
desertification; pollution of surface and coastal waters; elephant
poaching for ivory is a problem
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
2.2% (2003)
7.193 billion kWh (2001)
1.39 billion kWh (2001)
500 million kWh (2001)
5.8 billion kWh (2001)
70% (2001 est.)
lowest 10%: 2.5%
highest 10%: 31.7% (1997)
agriculture 81%, industry 6%, services 13% (1997 est.)
aluminum, prawns, cashews, cotton, sugar, citrus, timber;
bulk electricity
Belgium 26%, South Africa 14.4%, Italy 9.6%, Spain 9.5%,
Germany 8.3%, Zimbabwe 4.7% (2003)
10 provinces (provincias, singular - provincia), 1 city
(cidade)*; Cabo Delgado, Gaza, Inhambane, Manica, Maputo, Cidade de
Maputo*, Nampula, Niassa, Sofala, Tete, Zambezia
cotton, cashew nuts, sugarcane, tea, cassava (tapioca),
corn, coconuts, sisal, citrus and tropical fruits, potatoes,
sunflowers; beef, poultry
158 (2003 est.)
36.06 births/1,000 population (2004 est.)
Army, Navy, Air and Air Defense Forces, Special Forces
revenues: $1.089 billion
expenditures: $1.269 billion, including capital expenditures of
$479.4 million (2003 est.)
At independence in 1975, Mozambique was one of the
world''s poorest countries. Socialist mismanagement and a brutal
civil war from 1977-92 exacerbated the situation. In 1987, the
government embarked on a series of macroeconomic reforms designed to
stabilize the economy. These steps, combined with donor assistance
and with political stability since the multi-party elections in
1994, have led to dramatic improvements in the country''s growth
rate. Inflation was reduced to single digits during the late 1990s
although it returned to double digits in 2000-03. Fiscal reforms,
including the introduction of a value-added tax and reform of the
customs service, have improved the government''s revenue collection
abilities. In spite of these gains, Mozambique remains dependent
upon foreign assistance for much of its annual budget, and the
majority of the population remains below the poverty line.
Subsistence agriculture continues to employ the vast majority of the
country''s workforce. A substantial trade imbalance persists although
the opening of the MOZAL aluminum smelter, the country''s largest
foreign investment project to date has increased export earnings.
Additional investment projects in titanium extraction and processing
and garment manufacturing should further close the import/export
gap. Mozambique''s once substantial foreign debt has been reduced
through forgiveness and rescheduling under the IMF''s Heavily
Indebted Poor Countries (HIPC) and Enhanced HIPC initiatives, and is
now at a manageable level.
gas 649 km; refined products 292 km (2004)','275865ed7302bdacc8c0c8280ddee2e98f0f25ed2789a104119e584073759273','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4384b55953e39ba63953c5518d88cbcb9674f304dbe833b7e20e536dd0e5c0c7',2004,'NA','Namibia','economy',763,'total: 21
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 13
914 to 1,523 m: 4 (2004 est.)
total: 115
2,438 to 3,047 m: 2
1,524 to 2,437 m: 22
914 to 1,523 m: 71
under 914 m: 20 (2004 est.)
very limited natural fresh water resources; desertification;
wildlife poaching; land degradation has led to few conservation areas
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
2.5% (2003)
26.95 million kWh (2001)
603.1 million kWh (2001)
578 million kWh; note - electricity supplied by South Africa
(2001)
0 kWh (2001)
50% (2002 est.)
lowest 10%: NA
highest 10%: NA
agriculture 47%, industry 20%, services 33% (1999 est.)
diamonds, copper, gold, zinc, lead, uranium; cattle,
processed fish, karakul skins
EU 79%, US 4% (2001)
13 regions; Caprivi, Erongo, Hardap, Karas, Khomas, Kunene,
Ohangwena, Okavango, Omaheke, Omusati, Oshana, Oshikoto, Otjozondjupa
millet, sorghum, peanuts; livestock; fish
136 (2003 est.)
33.51 births/1,000 population (2004 est.)
Namibian Defense Force: Army (including Naval Wing, Air
Wing), Police
revenues: $1.434 billion
expenditures: $1.62 billion, including capital expenditures of $NA
(2003)
The economy is heavily dependent on the extraction and
processing of minerals for export. Mining accounts for 20% of GDP.
Rich alluvial diamond deposits make Namibia a primary source for
gem-quality diamonds. Namibia is the fourth-largest exporter of
nonfuel minerals in Africa, the world''s fifth-largest producer of
uranium, and the producer of large quantities of lead, zinc, tin,
silver, and tungsten. The mining sector employs only about 3% of the
population while about half of the population depends on subsistence
agriculture for its livelihood. Namibia normally imports about 50%
of its cereal requirements; in drought years food shortages are a
major problem in rural areas. A high per capita GDP, relative to the
region, hides the great inequality of income distribution; nearly
one-third of Namibians had annual incomes of less than $1,400 in
constant 1994 dollars, according to a 1993 study. The Namibian
economy is closely linked to South Africa with the Namibian dollar
pegged to the South African rand. Privatization of several
enterprises in coming years may stimulate long-run foreign
investment. Mining of zinc, copper, and silver and increased fish
production led growth in 2003.','c3a2b902cf10ff4cebd3a79e972f00a5852c402d6415b49d599eb73be670c2f9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5afa3ea1edb2d4d9998a5580177cec6071cfcb73996428d4a585b75c3dd1d397',2004,'NR','Nauru','economy',764,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
limited natural fresh water resources, roof storage tanks
collect rainwater, but mostly dependent on a single, aging
desalination plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and NZ consortium - has left the
central 90% of Nauru a wasteland and threatens limited remaining
land resources
Navassa Island
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
NA
30 million kWh (2001)
27.9 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
employed in mining phosphates, public administration,
education, and transportation
phosphates
Japan 42.3%, India 38.5%, South Korea 7.7% (2003)
14 districts; Aiwo, Anabar, Anetan, Anibare, Baiti, Boe,
Buada, Denigomodu, Ewa, Ijuw, Meneng, Nibok, Uaboe, Yaren
coconuts
1 (2003 est.)
25.61 births/1,000 population (2004 est.)
no regular military forces; Nauru Police Force
revenues: $23.4 million
expenditures: $64.8 million, including capital expenditures of NA
(FY95/96)
Revenues of this tiny island have traditionally come from
exports of phosphates, but reserves are now depleted. Few other
resources exist with most necessities being imported, mainly from
Australia, its former occupier and later major source of support.
The rehabilitation of mined land and the replacement of income from
phosphates are serious long-term problems. In anticipation of the
exhaustion of Nauru''s phosphate deposits, substantial amounts of
phosphate income have been invested in trust funds to help cushion
the transition and provide for Nauru''s economic future. As a result
of heavy spending from the trust funds, the government faces virtual
bankruptcy. To cut costs the government has called for a freeze on
wages, a reduction of over-staffed public service departments,
privatization of numerous government agencies, and closure of some
overseas consulates. In recent years Nauru has encouraged the
registration of offshore banks and corporations. In 2004 the
deterioration in housing, hospitals, and other capital plant
continued, and the cost to Australia of keeping the government and
economy afloat has substantially mounted. Few comprehensive
statistics on the Nauru economy exist, with estimates of Nauru''s GDP
varying widely.
Navassa Island
Subsistence fishing and commercial trawling
activities within refuge waters.','5da9ff51066d40ce730dbd7bec19ea51803383c463fb64612548479e6b52b68d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8eab0832fe011fc4b19847a04e8db95e48b12794ac333f891bec5424c74ec85',2004,'NP','Nepal','economy',765,'total: 9
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 7 (2004 est.)
total: 37
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 29 (2004 est.)
deforestation (overuse of wood for fuel and lack of
alternatives); contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
1.6% (2003)
1.755 billion kWh (2001)
1.764 billion kWh (2001)
227 million kWh (2001)
95 million kWh (2001)
42% (1995-96)
lowest 10%: 3.2%
highest 10%: 29.8% (1995-96)
agriculture 81%, industry 3%, services 16%
carpets, clothing, leather goods, jute goods, grain
India 50.7%, US 26%, Germany 6.6% (2003)
14 zones (anchal, singular and plural); Bagmati, Bheri,
Dhawalagiri, Gandaki, Janakpur, Karnali, Kosi, Lumbini, Mahakali,
Mechi, Narayani, Rapti, Sagarmatha, Seti
rice, corn, wheat, sugarcane, root crops; milk, water buffalo
meat
46 (2003 est.)
31.96 births/1,000 population (2004 est.)
Royal Nepalese Army (includes Royal Nepalese Army Air
Service), Nepalese Police Force
revenues: $665 million
expenditures: $1.1 billion, including capital expenditures of NA
(FY99/00 est.)
Nepal is among the poorest and least developed countries in
the world with 42% of its population living below the poverty line.
Agriculture is the mainstay of the economy, providing a livelihood
for over 80% of the population and accounting for 40% of GDP.
Industrial activity mainly involves the processing of agricultural
produce including jute, sugarcane, tobacco, and grain. Security
concerns in the wake of the Maoist conflict and the 11 September
2001 terrorist attacks in the US have led to a decrease in tourism,
a key source of foreign exchange. Nepal has considerable scope for
exploiting its potential in hydropower and tourism, areas of recent
foreign investment interest. Prospects for foreign trade or
investment in other sectors will remain poor, however, because of
the small size of the economy, its technological backwardness, its
remoteness, its landlocked geographic location, its civil strife,
and its susceptibility to natural disaster. The international
community''s role of funding more than 60% of Nepal''s development
budget and more than 28% of total budgetary expenditures will likely
continue as a major ingredient of growth.','a6e094998dfc2c4fb661d6d4540d5aa3cb0c655b45c26efd4c20135c230063ef','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d135c1cd78644782c9e3ddb0cb9592b71675c16560ca09be88a192d9b8986d33',2004,'NL','Netherlands','economy',766,'total: 20
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 2 (2004 est.)
Netherlands Antilles
total: 5
over 3,047 m: 1
2038 to 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2004 est.)
water pollution in the form of heavy metals, organic
compounds, and nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Netherlands Antilles
NA
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Kyoto Protocol, Law of
the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
1.6% (2003)
88.32 billion kWh (2001)
Netherlands Antilles
1.061 billion kWh (2001)
99.42 billion kWh (2001)
Netherlands Antilles
986.8 million kWh (2001)
21.49 billion kWh (2001)
Netherlands Antilles
0 kWh (2001)
4.209 billion kWh (2001)
Netherlands Antilles
0 kWh (2001)
NA
Netherlands Antilles
NA
lowest 10%: 2.8%
highest 10%: 25.1% (1994)
Netherlands Antilles
lowest 10%: NA
highest 10%: NA
agriculture 4%, industry 23%, services 73% (1998 est.)
Netherlands Antilles
agriculture 1%, industry 13%, services 86%
(2000 est.)
machinery and equipment, chemicals, fuels; foodstuffs
Netherlands Antilles
petroleum products
Germany 25.3%, Belgium 12.6%, France 10.2%, UK 10.1%,
Italy 6%, US 4.5% (2003)
Netherlands Antilles
US 21.3%, Venezuela 16%, Bahamas, The 7.6%,
Singapore 5.2%, Honduras 4.9%, Guatemala 4.4% (2003)
12 provinces (provincies, singular - provincie);
Drenthe, Flevoland, Friesland (Fryslan), Gelderland, Groningen,
Limburg, Noord-Brabant, Noord-Holland, Overijssel, Utrecht, Zeeland,
Zuid-Holland
Netherlands Antilles
none (part of the Kingdom of the Netherlands)
note: each island has its own government
grains, potatoes, sugar beets, fruits, vegetables;
livestock
Netherlands Antilles
aloes, sorghum, peanuts, vegetables, tropical
fruit
27 (2003 est.)
Netherlands Antilles
5 (2003 est.)
11.41 births/1,000 population (2004 est.)
Netherlands Antilles
15.36 births/1,000 population (2004 est.)
Royal Netherlands Army, Royal Netherlands Navy
(including Naval Air Service and Marine Corps), Royal Netherlands
Air Force, Royal Constabulary, Defense Interservice Command
Netherlands Antilles
National Guard, Police Force
revenues: $237.1 billion
expenditures: $249.5 billion, including capital expenditures of NA
(2003)
Netherlands Antilles
revenues: $710.8 million
expenditures: $741.6 million, including capital expenditures of NA
(1997 est.)
The Netherlands has a prosperous and open economy, which
depends heavily on foreign trade. The economy is noted for stable
industrial relations, moderate unemployment and inflation, a sizable
current account surplus, and an important role as a European
transportation hub. Industrial activity is predominantly in food
processing, chemicals, petroleum refining, and electrical machinery.
A highly mechanized agricultural sector employs no more than 4% of
the labor force but provides large surpluses for the food-processing
industry and for exports. The Netherlands, along with 11 of its EU
partners, began circulating the euro currency on 1 January 2002. The
country continues to be one of the leading European nations for
attracting foreign direct investment. Economic growth slowed
considerably in 2001-03, as part of the global economic slowdown,
but for the four years before that, annual growth averaged nearly
4%, well above the EU average. The government is wrestling with a
deteriorating budget position, and is moving toward the EU 3% of GDP
budget deficit limit.
Netherlands Antilles
Tourism, petroleum refining, and offshore
finance are the mainstays of this small economy, which is closely
tied to the outside world. Although GDP has declined or grown
slightly in each of the past seven years, the islands enjoy a high
per capita income and a well-developed infrastructure compared with
other countries in the region. Almost all consumer and capital goods
are imported, the US and Mexico being the major suppliers. Poor
soils and inadequate water supplies hamper the development of
agriculture. Budgetary problems hamper reform of the health and
pension systems of an aging population.
condensate 325 km; gas 6,998 km; oil 590 km; refined
products 716 km (2004)','5359b45a36587bd9b7c35dde036df12143205e415dd6e0da0c7349e97a906223','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f02a6534de9863aca4290d2de1c1889327a04abec26c84a520d0f53fd1bf60f',2004,'NC','New Caledonia','economy',767,'total: 11
over 3,047 m: 1
914 to 1,523 m: 8
under 914 m: 2 (2004 est.)
total: 14
914 to 1,523 m: 8
under 914 m: 6 (2004 est.)
erosion caused by mining exploitation and forest fires
NA
1.613 billion kWh (2001)
1.5 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 7%, industry 23%, services 70% (1999 est.)
ferronickels, nickel ore, fish
Japan 21.8%, France 19.2%, Taiwan 14%, Spain 11%,
South Korea 8.5%, Australia 7.2%, Italy 5.1% (2003)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 3 provinces named Iles Loyaute, Nord, and
Sud
vegetables; beef, deer, other livestock products
25 (2003 est.)
18.98 births/1,000 population (2004 est.)
no regular indigenous military forces; French Armed
Forces (including Army, Navy, Air Force, Gendarmerie); Police Force
revenues: $861.3 million
expenditures: $735.3 million, including capital expenditures of $52
million (1996 est.)
New Caledonia has about 25% of the world''s known
nickel resources. Only a small amount of the land is suitable for
cultivation, and food accounts for about 20% of imports. In addition
to nickel, substantial financial support from France - equal to more
than one-fourth of GDP - and tourism are keys to the health of the
economy. Substantial new investment in the nickel industry, combined
with the recovery of global nickel prices, brightens the economic
outlook for the next several years.','167310ce921f0d76c9b4532c6f2ab6ea9669691e558f3ce66c4ce9cd75c25e19','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f91971653ab829cd101d4354f617c561401eb18ee25af93667435c5cb23b68',2004,'NZ','New Zealand','economy',768,'total: 46
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 11
914 to 1,523 m: 27
under 914 m: 5 (2004 est.)
total: 70
1,524 to 2,437 m: 2
914 to 1,523 m: 29
under 914 m: 39 (2004 est.)
deforestation; soil erosion; native flora and fauna
hard-hit by species introduced from outside
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic Seals, Marine Life Conservation
1% (FY02)
37.51 billion kWh (2001)
34.88 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: 0.3%
highest 10%: 29.8% (1991 est.)
agriculture 10%, industry 25%, services 65% (1995)
dairy products, meat, wood and wood products, fish,
machinery
Australia 21.8%, US 14.6%, Japan 11%, China 4.9%, UK
4.8% (2003)
13 regions; Auckland, Bay of Plenty, Canterbury,
Gisborne-Hawke''s Bay, Manawatu-Wanganui, Nelson-Marlborough,
Northland, Otago, Southland, Taranaki, Waikato, Wellington, West
Coast
wheat, barley, potatoes, pulses, fruits, vegetables;
wool, beef, dairy products; fish
113 (2003 est.)
14.04 births/1,000 population (2004 est.)
New Zealand Army, Royal New Zealand Navy, Royal New
Zealand Air Force
revenues: $32.14 billion
expenditures: $30.13 billion, including capital expenditures of NA
(2003)
Over the past 20 years the government has transformed
New Zealand from an agrarian economy dependent on concessionary
British market access to a more industrialized, free market economy
that can compete globally. This dynamic growth has boosted real
incomes (but left behind many at the bottom of the ladder),
broadened and deepened the technological capabilities of the
industrial sector, and contained inflationary pressures. Per capita
income has been rising and is now 80% of the level of the four
largest EU economies. New Zealand is heavily dependent on trade -
particularly in agricultural products - to drive growth, and it has
been affected by the global economic slowdown and the slump in
commodity prices. Thus far the economy has been resilient, and
growth should continue at the same level in 2004. Expenditures on
health, education, and pensions will increase proportionately.
gas 2,213 km; liquid petroleum gas 79 km; oil 160 km;
refined products 304 km (2004)','5b3eab374497684d039725b97c4b2b2604290abce3e895be0a8afbd8ff85e449','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5410beb554bc32e3fae3655c515505f5aeb37b2fe1a4bcfffd9d8c59949567f9',2004,'NI','Nicaragua','economy',769,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2004 est.)
total: 165
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 141 (2004 est.)
deforestation; soil erosion; water pollution
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.2% (2003)
2.549 billion kWh (2001)
2.388 billion kWh (2001)
17 million kWh (2001)
0 kWh (2001)
50% (2001 est.)
lowest 10%: 0.7%
highest 10%: 48.8% (1998)
agriculture 42%, industry 15%, services 43% (1999 est.)
coffee, shrimp and lobster, cotton, tobacco, bananas,
beef, sugar, gold
US 35.9%, El Salvador 17.2%, Costa Rica 8.1%, Honduras
7.3%, Mexico 4.6%, Guatemala 4.3% (2003)
15 departments (departamentos, singular - departamento)
and 2 autonomous regions* (regiones autonomistas, singular - region
autonomista); Atlantico Norte*, Atlantico Sur*, Boaco, Carazo,
Chinandega, Chontales, Esteli, Granada, Jinotega, Leon, Madriz,
Managua, Masaya, Matagalpa, Nueva Segovia, Rio San Juan, Rivas
coffee, bananas, sugarcane, cotton, rice, corn, tobacco,
sesame, soya, beans; beef, veal, pork, poultry, dairy products
176 (2003 est.)
25.5 births/1,000 population (2004 est.)
Army (includes Navy), Navy
revenues: $672.5 million
expenditures: $954.9 million, including capital expenditures of $NA
(2003 est.)
Nicaragua, one of the hemisphere''s poorest countries,
faces low per capita income, massive unemployment, and huge external
debt. Distribution of income is one of the most unequal on the
globe. While the country has made progress toward macroeconomic
stability over the past few years, GDP annual growth of 1.5% - 2.5%
has been far too low to meet the country''s need. Nicaragua will
continue to be dependent on international aid and debt relief under
the Heavily Indebted Poor Countries (HIPC) initiative. Nicaragua has
undertaken significant economic reforms that are expected to help
the country qualify for more than $4 billion in debt relief under
HIPC in early 2004. Donors have made aid conditional on the openness
of government financial operation, poverty alleviation, and human
rights. A three-year poverty reduction and growth plan, agreed to
with the IMF in December 2002, guides economic policy.
oil 54 km (2004)','decb766e59cf34f483ec62af5f652433c680d12abf2dfc68e380a8b929dd585d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee276df163bc3378eadf525fb1b8b60f5d63bc15a639d987cef70e641f82de8',2004,'NE','Niger','economy',770,'total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
under 914 m: 1 (2004 est.)
total: 18
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 2 (2004 est.)
overgrazing; soil erosion; deforestation; desertification;
wildlife populations (such as elephant, hippopotamus, giraffe, and
lion) threatened because of poaching and habitat destruction
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Law of the
Sea
1.1% (2003)
242 million kWh (2001)
325.1 million kWh (2001)
100 million kWh (2001)
0 kWh (2001)
63% (1993 est.)
lowest 10%: 0.8%
highest 10%: 35.4% (1995)
agriculture 90%, industry and commerce 6%, government 4%
uranium ore, livestock, cowpeas, onions
France 42.2%, Nigeria 28.9%, Japan 17.2%, Spain 4.4% (2003)
7 departments (departements, singular - departement) and 1
capital district* (capitale district); Agadez, Diffa, Dosso, Maradi,
Niamey*, Tahoua, Tillaberi, Zinder
cowpeas, cotton, peanuts, millet, sorghum, cassava (tapioca),
rice; cattle, sheep, goats, camels, donkeys, horses, poultry
27 (2003 est.)
48.91 births/1,000 population (2004 est.)
Army, Air Force, National Intervention and Security Force
revenues: $320 million - including $134 million from foreign
sources
expenditures: $320 million, including capital expenditures of $178
million (2002 est.)
Niger is a poor, landlocked Sub-Saharan nation, whose economy
centers on subsistence agriculture, animal husbandry, and reexport
trade, and increasingly less on uranium, because of declining world
demand. The 50% devaluation of the West African franc in January
1994 boosted exports of livestock, cowpeas, onions, and the products
of Niger''s small cotton industry. The government relies on bilateral
and multilateral aid - which was suspended following the April 1999
coup d''etat - for operating expenses and public investment. In
2000-01, the World Bank approved a structural adjustment loan of
$105 million to help support fiscal reforms. However, reforms could
prove difficult given the government''s bleak financial situation.
The IMF approved a $73 million poverty reduction and growth facility
for Niger in 2000 and announced $115 million in debt relief under
the Heavily Indebted Poor Countries (HIPC) initiative. Further
disbursements of aid occurred in 2002. Future growth may be
sustained by exploitation of oil, gold, coal, and other mineral
resources.','c4fff4f9c3dc51126575144a8b49db85678adea0bbf8c50e88431e7396f75165','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('468bdac78bd597a220e031b5ab863b488c7461c00b5b210ad18dda47caf92b2c',2004,'NG','Nigeria','economy',771,'total: 36
over 3,047 m: 7
2,438 to 3,047 m: 11
1,524 to 2,437 m: 9
914 to 1,523 m: 6
under 914 m: 3 (2004 est.)
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 18 (2004 est.)
soil degradation; rapid deforestation; urban air and water
pollution; desertification; oil pollution - water, air, and soil;
has suffered serious damage from oil spills; loss of arable land;
rapid urbanization
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.9% (2003)
15.67 billion kWh (2001)
14.55 billion kWh (2001)
0 kWh (2001)
20 million kWh (2001)
60% (2000 est.)
lowest 10%: 1.6%
highest 10%: 40.8% (1996-97)
agriculture 70%, industry 10%, services 20% (1999 est.)
petroleum and petroleum products 95%, cocoa, rubber
US 38.3%, India 9.9%, Brazil 6.8%, Spain 6.2%, France 5.6%,
Japan 4% (2003)
36 states and 1 territory*; Abia, Adamawa, Akwa Ibom,
Anambra, Bauchi, Bayelsa, Benue, Borno, Cross River, Delta, Ebonyi,
Edo, Ekiti, Enugu, Federal Capital Territory*, Gombe, Imo, Jigawa,
Kaduna, Kano, Katsina, Kebbi, Kogi, Kwara, Lagos, Nassarawa, Niger,
Ogun, Ondo, Osun, Oyo, Plateau, Rivers, Sokoto, Taraba, Yobe, Zamfara
cocoa, peanuts, palm oil, corn, rice, sorghum, millet,
cassava (tapioca), yams, rubber; cattle, sheep, goats, pigs; timber;
fish
70 (2003 est.)
38.24 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $8.026 billion
expenditures: $11.09 billion, including capital expenditures of NA
(2003 est.)
Oil-rich Nigeria, long hobbled by political instability,
corruption, inadequate infrastructure, and poor macroeconomic
management, is undertaking some reforms under the new civilian
administration. Nigeria''s former military rulers failed to diversify
the economy away from overdependence on the capital-intensive oil
sector, which provides 20% of GDP, 95% of foreign exchange earnings,
and about 65% of budgetary revenues. The largely subsistence
agricultural sector has failed to keep up with rapid population
growth - Nigeria is Africa''s most populous country - and the
country, once a large net exporter of food, now must import food.
Following the signing of an IMF stand-by agreement in August 2000,
Nigeria received a debt-restructuring deal from the Paris Club and a
$1 billion credit from the IMF, both contingent on economic reforms.
Nigeria pulled out of its IMF program in April 2002, after failing
to meet spending and exchange rate targets, making it ineligible for
additional debt forgiveness from the Paris Club. The government has
lacked the political will to implement the market-oriented reforms
urged by the IMF, such as to modernize the banking system, to curb
inflation by blocking excessive wage demands, and to resolve
regional disputes over the distribution of earnings from the oil
industry. During 2003, however, the government deregulated fuel
prices and announced the privatization of the country''s four oil
refineries. GDP growth probably will rise marginally in 2004, led by
oil and natural gas exports.
condensate 105 km; gas 1,896 km; oil 3,638 km; refined
products 3,626 km (2004)','a38da3843cbf062aa242835d42d802fc32d8e71a8cd594e36e681d6d40ebaf34','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('465cc4f1adf4c5a1a088aba5ed2b98d5a33876b7392d97ee35ce10e4c2809a4c',2004,'NU','Niue','economy',772,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
increasing attention to conservationist practices to counter
loss of soil fertility from traditional slash and burn agriculture
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification
signed, but not ratified: Law of the Sea
3 million kWh (2001)
2.79 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
most work on family plantations; paid work exists only in
government service, small industry, and the Niue Development Board
canned coconut cream, copra, honey, vanilla, passion fruit
products, pawpaws, root crops, limes, footballs, stamps, handicrafts
New Zealand mainly, Fiji, Cook Islands, Australia (2000)
none; note - there are no first-order administrative divisions
as defined by the US Government, but there are 14 villages at the
second order
coconuts, passion fruit, honey, limes, taro, yams, cassava
(tapioca), sweet potatoes; pigs, poultry, beef cattle
1 (2003 est.)
NA births/1,000 population (2004 est.)
no regular indigenous military forces; Police Force
revenues: NA
expenditures: NA, including capital expenditures of NA
The economy suffers from the typical Pacific island problems of
geographic isolation, few resources, and a small population.
Government expenditures regularly exceed revenues, and the shortfall
is made up by critically needed grants from New Zealand that are
used to pay wages to public employees. Niue has cut government
expenditures by reducing the public service by almost half. The
agricultural sector consists mainly of subsistence gardening,
although some cash crops are grown for export. Industry consists
primarily of small factories to process passion fruit, lime oil,
honey, and coconut cream. The sale of postage stamps to foreign
collectors is an important source of revenue. The island in recent
years has suffered a serious loss of population because of migration
of Niueans to New Zealand. Efforts to increase GDP include the
promotion of tourism and a financial services industry, although
Premier LAKATANI announced in February 2002 that Niue will shut down
the offshore banking industry. Economic aid from New Zealand in 2002
was about $2.6 million.','914b22629133bb25773550e23ab2a0732bdeaf661ff9f41a60422b17c22d62cd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b583e334b2ab1e4e888cab7c27fc057ecfdfd35923572a0ed028579acb0e732',2004,'NF','Norfolk Island','economy',773,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
NA
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
tourism NA, subsistence agriculture NA
postage stamps, seeds of the Norfolk Island pine and
Kentia palm, small quantities of avocados
Australia, other Pacific island countries, NZ, Asia,
Europe
none (territory of Australia)
Norfolk Island pine seed, Kentia palm seed, cereals,
vegetables, fruit; cattle, poultry
1 (2003 est.)
NA births/1,000 population (2004 est.)
revenues: $4.6 million
expenditures: $4.8 million, including capital expenditures of NA
(FY92/93)
Tourism, the primary economic activity, has steadily
increased over the years and has brought a level of prosperity
unusual among inhabitants of the Pacific islands. The agricultural
sector has become self-sufficient in the production of beef,
poultry, and eggs.','3b25d4241e1e832dbdb7a56cc1c82ddda8b982e10dd619dd08ae82186bade7cf','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa89feb6a4878c60524646fdd8ab631ed37fafeec3f895ec7dc8d6cf45a4ae8f',2004,'MP','Northern Mariana Islands','economy',774,'total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2004 est.)
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
contamination of groundwater on Saipan may
contribute to disease; clean-up of landfill; protection of
endangered species conflicts with development
NA kWh
NA kWh
0 kWh
0 kWh
NA
lowest 10%: NA
highest 10%: NA
NA
garments
US (2000)
none (commonwealth in political union with
the US); there are no first-order administrative divisions as
defined by the US Government, but there are four municipalities at
the second order; Northern Islands, Rota, Saipan, Tinian
coconuts, fruits, vegetables; cattle
6 (2003 est.)
19.77 births/1,000 population (2004 est.)
revenues: $193 million
expenditures: $223 million, including capital expenditures of NA
(FY01/02 est.)
The economy benefits substantially from
financial assistance from the US. The rate of funding has declined
as locally generated government revenues have grown. The key tourist
industry employs about 50% of the work force and accounts for
roughly one-fourth of GDP. Japanese tourists predominate. Annual
tourist entries have exceeded one-half million in recent years, but
financial difficulties in Japan have caused a temporary slowdown.
The agricultural sector is made up of cattle ranches and small farms
producing coconuts, breadfruit, tomatoes, and melons. Garment
production is by far the most important industry with employment of
17,500 mostly Chinese workers and sizable shipments to the US under
duty and quota exemptions.','33fc22db3ef0b9a83b7b8883ecfa3af080584ba7e47bb553fb8a3a5742ab1041','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8af507a757f2481cc0aaddb4c54bcc397bfc9f384a508797afdc5e02f539f47d',2004,'NO','Norway','economy',775,'total: 65
2,438 to 3,047 m: 13
1,524 to 2,437 m: 12
914 to 1,523 m: 14
under 914 m: 26 (2004 est.)
total: 36
914 to 1,523 m: 7
under 914 m: 29 (2004 est.)
water pollution; acid rain damaging forests and adversely
affecting lakes, threatening fish stocks; air pollution from vehicle
emissions
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.9% (2003)
120.1 billion kWh (2001)
115.3 billion kWh (2001)
10.76 billion kWh (2001)
7.162 billion kWh (2001)
NA
lowest 10%: 4.1%
highest 10%: 21.8% (1995)
agriculture, forestry, and fishing 4%, industry 22%, services
74% (1995)
petroleum and petroleum products, machinery and equipment,
metals, chemicals, ships, fish
UK 21.3%, Germany 13%, Netherlands 9.6%, US 8.7%, France
8.2%, Sweden 7.4% (2003)
19 counties (fylker, singular - fylke); Akershus, Aust-Agder,
Buskerud, Finnmark, Hedmark, Hordaland, More og Romsdal, Nordland,
Nord-Trondelag, Oppland, Oslo, Ostfold, Rogaland, Sogn og Fjordane,
Sor-Trondelag, Telemark, Troms, Vest-Agder, Vestfold
barley, wheat, potatoes; pork, beef, veal, milk; fish
101 (2003 est.)
11.89 births/1,000 population (2004 est.)
Norwegian Army, Royal Norwegian Navy (including Coast
Artillery and Coast Guard), Royal Norwegian Air Force (Kongelige
Norske Luftforsvaret, RNoAF), Home Guard
revenues: $129.8 billion
expenditures: $105.5 billion, including capital expenditures of NA
(2003 est.)
The Norwegian economy is a prosperous bastion of welfare
capitalism, featuring a combination of free market activity and
government intervention. The government controls key areas, such as
the vital petroleum sector (through large-scale state enterprises).
The country is richly endowed with natural resources - petroleum,
hydropower, fish, forests, and minerals - and is highly dependent on
its oil production and international oil prices, with oil and gas
accounting for one-third of exports. Only Saudi Arabia and Russia
export more oil than Norway. Norway opted to stay out of the EU
during a referendum in November 1994. The government has moved ahead
with privatization. With arguably the highest quality of life
worldwide, Norwegians still worry about that time in the next two
decades when the oil and gas begin to run out. Accordingly, Norway
has been saving its oil-boosted budget surpluses in a Government
Petroleum Fund, which is invested abroad and now is valued at more
than $43 billion. GDP growth was a lackluster 1% in 2002 and 0.5% in
2003 against the background of a faltering European economy.
condensate 411 km; gas 6,199 km; oil 2,213 km; oil/gas/water
746 km; unknown (oil/water) 38 km (2004)','e107016a147a4df34e3d9900a34939074fd94955f9d9d70a95574015d37db2d6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5820d098c50272567433e021edf3e1061ed0bb6288700910eac987cf9cfef6ef',2004,'OM','Oman','economy',776,'total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 130
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 52
914 to 1,523 m: 34
under 914 m: 35 (2004 est.)
rising soil salinity; beach pollution from oil spills; very
limited natural fresh water resources
Pacific Ocean
endangered marine species include the dugong, sea
lion, sea otter, seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
11.4% (2003)
9.274 billion kWh (2001)
8.625 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
petroleum, reexports, fish, metals, textiles
South Korea 18.7%, China 18.5%, Japan 16.2%, Thailand 12.2%,
UAE 7.8%, Iran 4.1% (2003)
5 regions (manaatiq, singular - mintaqat) and 3 governorates*
(muhaafazaat, singular - muhaafaza) Ad Dakhiliyah, Al Batinah, Al
Wusta, Ash Sharqiyah, Az Zahirah, Masqat*, Musandam*, Zufar*
dates, limes, bananas, alfalfa, vegetables; camels, cattle; fish
135 (2003 est.)
37.12 births/1,000 population (2004 est.)
Royal Omani Armed Forces: Army, Navy, Air Force
revenues: $8.218 billion
expenditures: $7.766 billion, including capital expenditures of NA
(2003 est.)
Oman is a small, well-off middle Eastern economy with large oil
and gas resources, a substantial trade surplus, and low inflation.
The government is moving ahead with privatization of its utilities,
the development of a body of commercial law to facilitate foreign
investment, and increased budgetary outlays. Oman continues to
liberalize its markets and joined the World Trade Organization (WTO)
in November 2000. In order to reduce unemployment and limit
dependence on foreign countries, the government is encouraging the
replacement of expatriate workers with local people, i.e., the
process of Omanization. Training in information technology, business
management, and English support this objective. Industrial
development plans focus on gas resources.
Pacific Ocean
The Pacific Ocean is a major contributor to the world
economy and particularly to those nations its waters directly touch.
It provides low-cost sea transportation between East and West,
extensive fishing grounds, offshore oil and gas fields, minerals,
and sand and gravel for the construction industry. In 1996, over 60%
of the world''s fish catch came from the Pacific Ocean. Exploitation
of offshore oil and gas reserves is playing an ever-increasing role
in the energy supplies of the US, Australia, NZ, China, and Peru.
The high cost of recovering offshore oil and gas, combined with the
wide swings in world prices for oil since 1985, has led to
fluctuations in new drillings.
gas 3,754 km; oil 3,212 km (2004)','2e8dfc4e59b569c9fc71526ce27b6a72c22a46f90b051de8c9bc24c4cf4efd2f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b70b2fe7fa9dad46d2230eee2060241680f02d4e03c19071396c5d67c1fe587',2004,'PK','Pakistan','economy',777,'total: 92
over 3,047 m: 14
2,438 to 3,047 m: 22
1,524 to 2,437 m: 32
914 to 1,523 m: 18
under 914 m: 6 (2004 est.)
total: 39
over 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 9
under 914 m: 21 (2004 est.)
water pollution from raw sewage, industrial wastes, and
agricultural runoff; limited natural fresh water resources; a
majority of the population does not have access to potable water;
deforestation; soil erosion; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
3.9% (FY02/03)
66.96 billion kWh (2001)
62.27 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
35% (2001 est.)
lowest 10%: 4.1%
highest 10%: 27.6% (FY96/97)
agriculture 44%, industry 17%, services 39% (1999 est.)
textiles (garments, bed linen, cotton cloth, and yarn),
rice, leather goods, sports goods, chemicals, manufactures, carpets
and rugs
US 23.1%, UAE 9.4%, UK 7.1%, Germany 5.1%, Hong Kong 4.6%
(2003)
4 provinces, 1 territory*, and 1 capital territory**;
Balochistan, Federally Administered Tribal Areas*, Islamabad Capital
Territory**, North-West Frontier Province, Punjab, Sindh
note: the Pakistani-administered portion of the disputed Jammu and
Kashmir region includes Azad Kashmir and the Northern Areas
cotton, wheat, rice, sugarcane, fruits, vegetables; milk,
beef, mutton, eggs
129 (2003 est.)
31.22 births/1,000 population (2004 est.)
Army, Navy, Air Force
revenues: $12.08 billion
expenditures: $15.41 billion, including capital expenditures of NA
(2003 est.)
Pakistan, an impoverished and underdeveloped country, has
suffered from decades of internal political disputes, low levels of
foreign investment, and a costly, ongoing confrontation with
neighboring India. However, IMF-approved government policies,
bolstered by generous foreign assistance and renewed access to
global markets since late 2001, have generated solid macroeconomic
recovery the last two years. The government has made substantial
inroads in macroeconomic reform since 2000, although progress on
more politically sensitive reforms has slowed. For example, in the
third and final year of its $1.3 billion IMF Poverty Reduction and
Growth Facility, Islamabad has continued to require waivers for
energy sector reforms. While long-term prospects remain uncertain,
given Pakistan''s low level of development, medium-term prospects for
job creation and poverty reduction are the best in nearly a decade.
Islamabad has raised development spending from about 2% of GDP in
the 1990s to 4% in 2003, a necessary step towards reversing the
broad underdevelopment of its social sector. GDP growth is heavily
dependent on rain-fed crops, and last year''s end to a four-year
drought should support moderate agricultural growth for the next few
years. Foreign exchange reserves continued to reach new levels in
2003, supported by robust export growth and steady worker
remittances.
gas 9,945 km; oil 1,821 km (2004)','f43ff2302f2b9d0972d5725117de024fe685b6cc49d11e02eaf57ed7d1e1221e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16f667bc8f77b8722b68f76eecc4c2d67caa9a4694be56c33d649dbdd6576288',2004,'PW','Palau','economy',778,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 2
1,524 to 2,437 m: 2 (2004 est.)
Palmyra Atoll
total: 1
1,524 to 2,437 m: 1 (2004 est.)
inadequate facilities for disposal of solid waste; threats to
the marine ecosystem from sand and coral dredging, illegal fishing
practices, and overfishing
Palmyra Atoll
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
NA
NA
lowest 10%: NA
highest 10%: NA
agriculture 20%, industry NA, services NA (1990)
shellfish, tuna, copra, garments
US, Japan, Singapore (2000)
16 states; Aimeliik, Airai, Angaur, Hatohobei, Kayangel,
Koror, Melekeok, Ngaraard, Ngarchelong, Ngardmau, Ngatpang,
Ngchesar, Ngeremlengui, Ngiwal, Peleliu, Sonsorol
coconuts, copra, cassava (tapioca), sweet potatoes
3 (2003 est.)
Palmyra Atoll
1 (2003 est.)
18.69 births/1,000 population (2004 est.)
no regular military forces; Police Force
revenues: $57.7 million
expenditures: $80.8 million, including capital expenditures of $17.1
million (FY98/99 est.)
The economy consists primarily of tourism, subsistence
agriculture and fishing. The government is the major employer of the
work force, relying heavily on financial assistance from the US.
Business and tourist arrivals numbered 50,000 in FY00/01. The
population enjoys a per capita income twice that of the Philippines
and much of Micronesia. Long-run prospects for the key tourist
sector have been greatly bolstered by the expansion of air travel in
the Pacific, the rising prosperity of leading East Asian countries,
and the willingness of foreigners to finance infrastructure
development.
Palmyra Atoll
no economic activity','e576ed9bb8180a06afb6ad083cc9f0a5cb090d5e86526d156f7dcc19d519d30f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abd06cc58fd774f55e0e88b6d95a41c97e1f71bbf087c1b9d4ebe9e9d812af19',2004,'PA','Panama','economy',779,'total: 44
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 15
under 914 m: 22 (2004 est.)
total: 61
914 to 1,523 m: 12
under 914 m: 49 (2004 est.)
water pollution from agricultural runoff threatens fishery
resources; deforestation of tropical rain forest; land degradation
and soil erosion threatens siltation of Panama Canal; air pollution
in urban areas; mining threatens natural resources
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
1.2% (2003)
4.039 billion kWh (2001)
3.681 billion kWh (2001)
43 million kWh (2001)
118 million kWh (2001)
37% (1999 est.)
lowest 10%: 1.2%
highest 10%: 35.7% (1997)
agriculture 20.8%, industry 18%, services 61.2% (1995 est.)
bananas, shrimp, sugar, coffee, clothing (1999)
US 13.9%, Nigeria 9.8%, Germany 8.1%, South Korea 7.8%, Peru
5.1%, Costa Rica 4.9%, Belgium 4.8%, Japan 4.5% (2003)
9 provinces (provincias, singular - provincia) and 1
territory* (comarca); Bocas del Toro, Chiriqui, Cocle, Colon,
Darien, Herrera, Los Santos, Panama, San Blas*, and Veraguas
bananas, rice, corn, coffee, sugarcane, vegetables;
livestock; shrimp
103 (2003 est.)
20.36 births/1,000 population (2004 est.)
an amendment to the Constitution abolished the armed forces,
but there are security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National Maritime Service,
and National Air Service)
revenues: $2.995 billion
expenditures: $3.421 billion, including capital expenditures of $471
million (2003 est.)
Panama''s dollarised economy rests primarily on a
well-developed services sector that accounts for three-fourths of
GDP. Services include operating the Panama Canal, banking, the Colon
Free Zone, insurance, container ports, flagship registry, and
tourism. A slump in Colon Free Zone and agricultural exports, the
global slowdown, and the withdrawal of US military forces held back
economic growth in 2000-03. The government has been backing public
works programs, tax reforms, new regional trade agreements, and
development of tourism in order to stimulate growth. Unemployment
remains at an unacceptably high level.','0bc8aff0e722ab7a8877e736f024eb279e1bf09c514bbe49d23a33e9e1afea43','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91c15d4eb82f5e1f5ad8e6984f5c234834aa0f608b9b0e86d76fcb802bde5707',2004,'PG','Papua New Guinea','economy',780,'total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
Paracel Islands
total: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 550
1,524 to 2,437 m: 10
914 to 1,523 m: 62
under 914 m: 478 (2004 est.)
rain forest subject to deforestation as a result of
growing commercial demand for tropical timber; pollution from mining
projects; severe drought
Paracel Islands
NA
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
1.4% (FY02)
1.496 billion kWh (2001)
1.391 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
37% (2002 est.)
lowest 10%: 1.7%
highest 10%: 40.5% (1996)
agriculture 85%, industry NA, services NA
oil, gold, copper ore, logs, palm oil, coffee,
cocoa, crayfish, prawns
Australia 25.6%, Japan 7.4%, China 5.8% (2003)
20 provinces; Bougainville, Central, Chimbu,
Eastern Highlands, East New Britain, East Sepik, Enga, Gulf, Madang,
Manus, Milne Bay, Morobe, National Capital, New Ireland, Northern,
Sandaun, Southern Highlands, Western, Western Highlands, West New
Britain
coffee, cocoa, coconuts, palm kernels, tea, rubber,
sweet potatoes, fruit, vegetables, poultry, pork
559 (2003 est.)
Paracel Islands
1 (2003 est.)
30.52 births/1,000 population (2004 est.)
Papua New Guinea Defense Force: Ground Force,
Maritime Operations Element, and Air Operations Element
revenues: $954.1 million
expenditures: $996.8 million, including capital expenditures of $344
million (2003 est.)
Papua New Guinea is richly endowed with natural
resources, but exploitation has been hampered by rugged terrain and
the high cost of developing infrastructure. Agriculture provides a
subsistence livelihood for 85% of the population. Mineral deposits,
including oil, copper, and gold, account for 72% of export earnings.
The economy has faltered over the past four years. Former Prime
Minister Mekere MORAUTA had tried to restore integrity to state
institutions, to stabilize the kina, restore stability to the
national budget, to privatize public enterprises where appropriate,
and to ensure ongoing peace on Bougainville. The government has had
considerable success in attracting international support,
specifically gaining the backing of the IMF and the World Bank in
securing development assistance loans. Challenges face Prime
Minister Michael SOMARE, including curbing inflation, gaining
further investor confidence, continuing efforts to privatize
government assets, maintaining the support of members of Parliament,
and balancing relations with Australia, the former colonial ruler.
Paracel Islands
China announced plans in 1997 to open the islands
for tourism.
oil 264 km (2004)','ce1a4f7081d0ed1ef797af6ad7d2a8910e166cbadc98c506a0b5f6dc55c5aebd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3560f59955cf9ae99b97b945ab1fa05644db2996af725b16b6406bb9ce819873',2004,'PY','Paraguay','economy',781,'total: 12
over 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 4 (2004 est.)
total: 866
1,524 to 2,437 m: 26
914 to 1,523 m: 323
under 914 m: 517 (2004 est.)
deforestation; water pollution; inadequate means for waste
disposal present health risks for many urban residents; loss of
wetlands
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.9% (2003)
44.89 billion kWh (2001)
2.637 billion kWh (2001)
0 kWh (2001)
39.11 billion kWh (2001)
36% (2001 est.)
lowest 10%: 0.5%
highest 10%: 43.8% (1998)
agriculture 45%
soybeans, feed, cotton, meat, edible oils, electricity,
wood, leather
Brazil 34.2%, Uruguay 19.6%, Switzerland 7.8%, Argentina
5.3% (2003)
17 departments (departamentos, singular - departamento) and
1 capital city*; Alto Paraguay, Alto Parana, Amambay, Asuncion*,
Boqueron, Caaguazu, Caazapa, Canindeyu, Central, Concepcion,
Cordillera, Guaira, Itapua, Misiones, Neembucu, Paraguari,
Presidente Hayes, San Pedro
cotton, sugarcane, soybeans, corn, wheat, tobacco, cassava
(tapioca), fruits, vegetables; beef, pork, eggs, milk; timber
880 (2003 est.)
29.78 births/1,000 population (2004 est.)
Army, Navy (includes Naval Air and Marines), Air Force
revenues: $937.8 million
expenditures: $988.4 million, including capital expenditures of $700
million (2003 est.)
Paraguay has a market economy marked by a large informal
sector. The informal sector features both reexport of imported
consumer goods to neighboring countries as well as the activities of
thousands of microenterprises and urban street vendors. Because of
the importance of the informal sector, accurate economic measures
are difficult to obtain. A large percentage of the population
derives their living from agricultural activity, often on a
subsistence basis. The formal economy grew by an average of about 3%
annually in 1995-97; but GDP declined slightly in 1998, 1999, and
2000, rose slightly in 2001, only to fall again in 2002. On a per
capita basis, real income has stagnated at 1980 levels. Most
observers attribute Paraguay''s poor economic performance to
political uncertainty, corruption, lack of progress on structural
reform, substantial internal and external debt, and deficient
infrastructure.','ca497800b5ff71e5c63e4cc656c98a9cc348871583d7841abda09ced9e18688f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cfe1a02ceb89c71c053b51d44b12cb2f39c319f0745b4ac385a8e562106e1c8',2004,'PE','Peru','economy',782,'total: 52
over 3,047 m: 5
2,438 to 3,047 m: 20
1,524 to 2,437 m: 16
914 to 1,523 m: 9
under 914 m: 2 (2004 est.)
total: 182
1,524 to 2,437 m: 21
914 to 1,523 m: 62
under 914 m: 99 (2004 est.)
deforestation (some the result of illegal logging); overgrazing
of the slopes of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers and
coastal waters from municipal and mining wastes
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.3% (2003)
20.59 billion kWh (2001)
19.15 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
54% (2003 est.)
lowest 10%: 1.6%
highest 10%: 35.4% (1996)
agriculture 5.9%, mining and quarrying 0.4%, manufacturing
12.6%, construction 5.3%, commerce 26.3%, household work 4.9%, other
services 44.6% (2004)
fish and fish products, gold, copper, zinc, crude petroleum and
byproducts, lead, coffee, sugar, cotton
US 27.1%, UK 12.4%, China 7.7%, Switzerland 7.6%, Chile 4.7%,
Japan 4.4% (2003)
24 departments (departamentos, singular - departamento) and 1
constitutional province* (provincia constitucional); Amazonas,
Ancash, Apurimac, Arequipa, Ayacucho, Cajamarca, Callao*, Cusco,
Huancavelica, Huanuco, Ica, Junin, La Libertad, Lambayeque, Lima,
Loreto, Madre de Dios, Moquegua, Pasco, Piura, Puno, San Martin,
Tacna, Tumbes, Ucayali
note: some reports indicate that the 24 departments and 1
constitutional province are now being referred to as regions; Peru
is implementing a decentralization program whereby these 25
administrative divisions will begin to exercise greater governmental
authority over their territories; in November 2002, voters chose
their new regional presidents and other regional leaders; the
authority that the regional government will exercise has not yet
been clearly defined, but it will be devolved to the regions over
the course of several years
coffee, cotton, sugarcane, rice, wheat, potatoes, corn,
plantains, coca; poultry, beef, dairy products, wool; fish
233 (2003 est.)
21.27 births/1,000 population (2004 est.)
Army (Ejercito Peruano), Navy (Marina de Guerra del Peru;
includes Naval Air, Naval Infantry, and Coast Guard), Air Force
(Fuerza Aerea del Peru; FAP)
revenues: $15.86 billion
expenditures: $17.05 billion, including capital expenditures of $1.6
billion (2003 est.)
Peru''s economy reflects its varied geography - an arid coastal
region, the Andes further inland, and tropical lands bordering
Colombia and Brazil. Abundant mineral resources are found in the
mountainous areas, and Peru''s coastal waters provide excellent
fishing grounds. However, overdependence on minerals and metals
subjects the economy to fluctuations in world prices, and a lack of
infrastructure deters trade and investment. After several years of
inconsistent economic performance, the Peruvian economy was one of
the fastest growing in Latin America in 2002 and 2003, growing by 5%
and 4%, respectively, with the exchange rate stable and an annual
inflation lower than 2%. Foreign direct investment also was strong,
thanks to the ongoing Camisea natural gas pipeline project
(scheduled to begin operations in 2004) and investments in gold
mining. Risk premiums on Peruvian bonds on secondary markets reached
historically low levels in late 2003, reflecting investor optimism
and the government''s fiscal restraint. Despite the strong
macroeconomic performance, political intrigue and allegations of
corruption continued to swirl in 2003, with the TOLEDO
administration growing increasingly unpopular, and local and foreign
concern rising that the political turmoil could place the country''s
hard-won fiscal and financial stability at risk. Moreover, as of
late 2003, unemployment had yet to respond to the strong growth in
economic activity, owing in part to rigid labor market regulations
that act as an impediment to hiring.
gas 388 km; oil 1,557 km; refined products 13 km (2004)','e22366a829b2f29635ebb7f6e0ec3a239eaa67d1967f18d472356823e725d082','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65d9f432bc6d7ae80386383d453979ea11c612e411c6e6dbd2fabd1aa9e6e189',2004,'PH','Philippines','economy',783,'total: 82
over 3,047 m: 4
2,438 to 3,047 m: 6
1,524 to 2,437 m: 26
914 to 1,523 m: 35
under 914 m: 11 (2004 est.)
total: 173
1,524 to 2,437 m: 5
914 to 1,523 m: 68
under 914 m: 100 (2004 est.)
uncontrolled deforestation especially in watershed
areas; soil erosion; air and water pollution in major urban centers;
coral reef degradation; increasing pollution of coastal mangrove
swamps that are important fish breeding grounds
Pitcairn Islands
deforestation (only a small portion of the original
forest remains because of burning and clearing for settlement)
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.5% (FY98)
45.21 billion kWh (2001)
Pitcairn Islands
NA kWh; note - electric power is provided by a
small diesel-powered generator
42.04 billion kWh (2001)
Pitcairn Islands
NA kWh
0 kWh (2001)
0 kWh (2001)
40% (2001 est.)
Pitcairn Islands
NA
lowest 10%: 1.7%
highest 10%: 38.4% (2000)
Pitcairn Islands
lowest 10%: NA
highest 10%: NA
agriculture 45%, industry 15%, services 40% (2003 est.)
Pitcairn Islands
no business community in the usual sense; some
public works; subsistence farming and fishing
electronic equipment, machinery and transport equipment,
garments, coconut products, chemicals
Pitcairn Islands
fruits, vegetables, curios, stamps
US 20.1%, Japan 15.9%, Hong Kong 8.5%, Netherlands 8.1%,
Taiwan 6.9%, Malaysia 6.8%, Singapore 6.7%, China 5.9% (2003)
Pitcairn Islands
NA (2000)
79 provinces and 116 chartered cities
provinces: Abra, Agusan del Norte, Agusan del Sur, Aklan, Albay,
Antique, Apayao, Aurora, Basilan, Bataan, Batanes, Batangas,
Biliran, Benguet, Bohol, Bukidnon, Bulacan, Cagayan, Camarines
Norte, Camarines Sur, Camiguin, Capiz, Catanduanes, Cavite, Cebu,
Compostela, Davao del Norte, Davao del Sur, Davao Oriental, Eastern
Samar, Guimaras, Ifugao, Ilocos Norte, Ilocos Sur, Iloilo, Isabela,
Kalinga, Laguna, Lanao del Norte, Lanao del Sur, La Union, Leyte,
Maguindanao, Marinduque, Masbate, Mindoro Occidental, Mindoro
Oriental, Misamis Occidental, Misamis Oriental, Mountain Province,
Negros Occidental, Negros Oriental, North Cotabato, Northern Samar,
Nueva Ecija, Nueva Vizcaya, Palawan, Pampanga, Pangasinan, Quezon,
Quirino, Rizal, Romblon, Samar, Sarangani, Siquijor, Sorsogon, South
Cotabato, Southern Leyte, Sultan Kudarat, Sulu, Surigao del Norte,
Surigao del Sur, Tarlac, Tawi-Tawi, Zambales, Zamboanga del Norte,
Zamboanga del Sur, Zamboanga Sibugay
chartered cities: Alaminos, Angeles, Antipolo, Bacolod, Bago,
Baguio, Bais, Balanga, Batangas, Bayawan, Bislig, Butuan,
Cabanatuan, Cadiz, Cagayan de Oro, Calamba, Calapan, Calbayog,
Candon, Canlaon, Cauayan, Cavite, Cebu, Cotabato, Dagupan, Danao,
Dapitan, Davao, Digos, Dipolog, Dumaguete, Escalante, Gapan, General
Santos, Gingoog, Himamaylan, Iligan, Iloilo, Isabela, Iriga,
Kabankalan, Kalookan, Kidapawan, Koronadal, La Carlota, Laoag,
Lapu-Lapu, Las Pinas, Legazpi, Ligao, Lipa, Lucena, Maasin, Makati,
Malabon, Malaybalay, Malolos, Mandaluyong, Mandaue, Manila, Marawi,
Markina, Masbate, Muntinlupa, Munoz, Naga, Olongapo, Ormoc,
Oroquieta, Ozamis, Pagadian, Palayan, Panabo, Paranaque, Pasay,
Pasig, Passi, Puerto Princesa, Quezon, Roxas, Sagay, Samal, San
Carlos (in Negros Occidental), San Carlos (in Pangasinan), San
Fernando (in La Union), San Fernando (in Pampanga), San Jose, San
Jose del Monte, San Pablo, Santa Rosa, Santiago, Silay, Sipalay,
Sorsogon, Surigao, Tabaco, Tacloban, Tacurong, Tagaytay, Tagbilaran,
Tagum, Talisay (in Cebu), Talisay (in Negros Oriental), Tanauan,
Tangub, Tanjay, Tarlac, Toledo, Tuguegarao, Trece Martires,
Urdaneta, Valencia, Valenzuela, Victorias, Vigan, Zamboanga
Pitcairn Islands
none (overseas territory of the UK)
rice, coconuts, corn, sugarcane, bananas, pineapples,
mangoes, pork, eggs, beef, fish
Pitcairn Islands
wide variety of fruits and vegetables, goats,
chickens
253 (2003 est.)
Pitcairn Islands
none (2003 est.)
25.8 births/1,000 population (2004 est.)
Pitcairn Islands
NA births/1,000 population
Armed Forces of the Philippines (AFP): Army, Navy
(includes Coast Guard and Marine Corps), Air Force
revenues: $11.56 billion
expenditures: $15.25 billion, including capital expenditures of $2.4
million NA (2003)
Pitcairn Islands
revenues: $729,900
expenditures: $878,100, including capital expenditures of NA
(FY94/95 est.)
The Philippines was less severely affected by the Asian
financial crisis of 1998 than its neighbors, aided in part by annual
remittances of $6-7 billion from overseas workers. From a 0.6%
decline in 1998, GDP expanded by 2.4% in 1999, and 4.4% in 2000, but
slowed to 3.2% in 2001 in the context of a global economic slowdown,
an export slump, and political and security concerns. GDP growth
accelerated to 4.4% in 2002 and 4.2% in 2003, reflecting the
continued resilience of the service sector, gains in industrial
output, and improved exports. Nonetheless, it will take a higher,
sustained growth path to make appreciable progress in poverty
alleviation given the Philippines'' high annual population growth
rate and unequal distribution of income. The MACAPAGAL-ARROYO
Administration has promised to continue economic reforms to help the
Philippines match the pace of development in the newly
industrialized countries of East Asia. The strategy includes
improving the infrastructure, strengthening tax collection to
bolster government revenues, furthering deregulation and
privatization of the economy, enhancing the viability of the
financial system, and increasing trade integration with the region.
Prospects for 2004 will depend on the economic performance of two
major trading partners, the US and Japan, and on increased
confidence on the part of the international investment community.
Pitcairn Islands
The inhabitants of this tiny isolated economy exist
on fishing, subsistence farming, handicrafts, and postage stamps.
The fertile soil of the valleys produces a wide variety of fruits
and vegetables, including citrus, sugarcane, watermelons, bananas,
yams, and beans. Bartering is an important part of the economy. The
major sources of revenue are the sale of postage stamps to
collectors and the sale of handicrafts to passing ships.
gas 565 km; oil 135 km; refined products 100 km (2004)','115e43fd9bc9c0dabcb584aaeaaedee00f722f1efd9b578e960dfecaa0a05241','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c769471cd41530c52eb1867c392618391b7ae3c8047106bb286c9bd98508a2ca',2004,'PL','Poland','economy',784,'total: 84
over 3,047 m: 3
2,438 to 3,047 m: 30
1,524 to 2,437 m: 40
914 to 1,523 m: 8
under 914 m: 3 (2004 est.)
total: 39
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 13
under 914 m: 21 (2004 est.)
situation has improved since 1989 due to decline in heavy
industry and increased environmental concern by post-Communist
governments; air pollution nonetheless remains serious because of
sulfur dioxide emissions from coal-fired power plants, and the
resulting acid rain has caused forest damage; water pollution from
industrial and municipal sources is also a problem, as is disposal
of hazardous wastes; pollution levels should continue to decrease as
industrial establishments bring their facilities up to European
Union code, but at substantial cost to business and the government
party to: Air Pollution, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Kyoto Protocol, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 94
1.71% (2002)
135 billion kWh (2001)
118.8 billion kWh (2001)
4.306 billion kWh (2001)
11.04 billion kWh (2001)
18.4% (2000 est.)
lowest 10%: 3.2%
highest 10%: 24.7% (1998)
agriculture 27.5%, industry 22.1%, services 50.4% (1999)
machinery and transport equipment 30.2%, intermediate
manufactured goods 25.5%, miscellaneous manufactured goods 20.9%,
food and live animals 8.5% (1999)
Germany 32.3%, France 6.1%, Italy 5.8%, UK 5%, Netherlands
4.5%, Czech Republic 4.1% (2003)
16 provinces (wojewodztwa, singular - wojewodztwo);
Dolnoslaskie, Kujawsko-Pomorskie, Lodzkie, Lubelskie, Lubuskie,
Malopolskie, Mazowieckie, Opolskie, Podkarpackie, Podlaskie,
Pomorskie, Slaskie, Swietokrzyskie, Warminsko-Mazurskie,
Wielkopolskie, Zachodniopomorskie
potatoes, fruits, vegetables, wheat; poultry, eggs, pork
122 (2003 est.)
10.64 births/1,000 population (2004 est.)
Land Forces, Navy, Air Force
revenues: $39.13 billion
expenditures: $48.64 billion, including capital expenditures of NA
(2003)
Poland has steadfastly pursued a policy of economic
liberalization throughout the 1990s and today stands out as a
success story among transition economies. Even so, much remains to
be done. The privatization of small and medium state-owned companies
and a liberal law on establishing new firms has encouraged the
development of the private business sector, but legal and
bureaucratic obstacles alongside persistent corruption are hampering
its further development. Poland''s agricultural sector remains
handicapped by structural problems, surplus labor, inefficient small
farms, and lack of investment. Restructuring and privatization of
"sensitive sectors" (e.g., coal, steel, railroads, and energy),
while recently initiated, have stalled. Reforms in health care,
education, the pension system, and state administration have
resulted in larger than expected fiscal pressures. Further progress
in public finance depends mainly on privatization of Poland''s
remaining state sector, the reduction of state employment, and an
overhaul of the tax code to incorporate the growing gray economy and
farmers, most of whom pay no tax. The government''s determination to
enter the EU has shaped most aspects of its economic policy and new
legislation; in a nationwide referendum in November 2003, 77% of the
voters voted in favor of Poland''s EU accession, now scheduled for
May 2004. Improving Poland''s export competitiveness and containing
the internal budget deficit are top priorities. Due to political
uncertainty, the zloty has recently depreciated in relation to the
euro, while currencies of the other euro-zone aspirants have been
appreciating. GDP per capita equals that of the three Baltic states.
gas 13,552 km; oil 1,772 km (2004)','025a60fc6029d66b789ac8bc496fbfb351021e6f3a632a71b2fdf94a7d3ead4b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c015baa5f00fa9013495d0e6485d4f4b2cc1a1b1c09aef1f7d78908a83473fd3',2004,'PT','Portugal','economy',785,'total: 42
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 3
914 to 1,523 m: 15
under 914 m: 10 (2004 est.)
total: 23
914 to 1,523 m: 1
under 914 m: 22 (2004 est.)
soil erosion; air pollution caused by industrial and
vehicle emissions; water pollution, especially in coastal areas
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Environmental
Modification
2.3% (2003)
44.32 billion kWh (2001)
41.48 billion kWh (2001)
3.743 billion kWh (2001)
3.479 billion kWh (2001)
NA
lowest 10%: 3.1%
highest 10%: 28.4% (1995 est.)
agriculture 10%, industry 30%, services 60% (1999 est.)
clothing and footwear, machinery, chemicals, cork and paper
products, hides
Spain 22.7%, Germany 15.2%, France 12.9%, UK 10.5%, US
5.8%, Italy 4.8%, Belgium 4.6% (2003)
18 districts (distritos, singular - distrito) and 2
autonomous regions* (regioes autonomas, singular - regiao autonoma);
Aveiro, Acores (Azores)*, Beja, Braga, Braganca, Castelo Branco,
Coimbra, Evora, Faro, Guarda, Leiria, Lisboa, Madeira*, Portalegre,
Porto, Santarem, Setubal, Viana do Castelo, Vila Real, Viseu
grain, potatoes, olives, grapes; sheep, cattle, goats,
poultry, beef, dairy products
66 (2003 est.)
10.9 births/1,000 population (2004 est.)
Army, Navy (PON; including Marines), Air Force (FAP),
Republican Guard (including Fiscal Guard)
revenues: $64.81 billion
expenditures: $69.09 billion, including capital expenditures of NA
(2003 est.)
Portugal has become a diversified and increasingly
service-based economy since joining the European Community in 1986.
Over the past decade, successive governments have privatized many
state-controlled firms and liberalized key areas of the economy,
including the financial and telecommunications sectors. The country
qualified for the Economic and Monetary Union (EMU) in 1998 and
began circulating the euro on 1 January 2002 along with 11 other EU
member economies. Economic growth has been above the EU average for
much of the past decade, but fell back in 2001-03. GDP per capita
stands at 70% of that of the leading EU economies. A poor
educational system, in particular, has been an obstacle to greater
productivity and growth. Portugal has been increasingly overshadowed
by lower-cost producers in Central Europe and Asia as a target for
foreign direct investment. The coalition government faces tough
choices in its attempts to boost Portugal''s economic competitiveness
and to keep the budget deficit within the 3% EU ceiling.
gas 1,099 km; oil 8 km; refined products 174 km (2004)','c3bbaf9ff64eaf40b51d067ded4734e725a53ab5ad45950a083fb63054750ed4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9368f8f1ce7b189ef8baeb00dd4382cc27f73dd37c4e668930527b28b92a7042',2004,'PR','Puerto Rico','economy',786,'total: 17
over 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 5 (2004 est.)
total: 13
1,524 to 2, 437 m: 1
914 to 1,523 m: 2
under 914 m: 10 (2004 est.)
erosion; occasional drought causing water shortages
20.9 billion kWh (2001)
19.44 billion kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 3%, industry 20%, services 77% (2000 est.)
Reunion
agriculture 13%, industry 12%, services 75% (2000)
chemicals, electronics, apparel, canned tuna, rum,
beverage concentrates, medical equipment
US 90.3%, UK 1.6%, Netherlands 1.4%, Dominican Republic
1.4% (2002 est.)
none (commonwealth associated with the US); there are no
first-order administrative divisions as defined by the US
Government, but there are 78 municipalities (municipios, singular -
municipio) at the second order; Adjuntas, Aguada, Aguadilla, Aguas
Buenas, Aibonito, Anasco, Arecibo, Arroyo, Barceloneta,
Barranquitas, Bayamon, Cabo Rojo, Caguas, Camuy, Canovanas,
Carolina, Catano, Cayey, Ceiba, Ciales, Cidra, Coamo, Comerio,
Corozal, Culebra, Dorado, Fajardo, Florida, Guanica, Guayama,
Guayanilla, Guaynabo, Gurabo, Hatillo, Hormigueros, Humacao,
Isabela, Jayuya, Juana Diaz, Juncos, Lajas, Lares, Las Marias, Las
Piedras, Loiza, Luquillo, Manati, Maricao, Maunabo, Mayaguez, Moca,
Morovis, Naguabo, Naranjito, Orocovis, Patillas, Penuelas, Ponce,
Quebradillas, Rincon, Rio Grande, Sabana Grande, Salinas, San
German, San Juan, San Lorenzo, San Sebastian, Santa Isabel, Toa
Alta, Toa Baja, Trujillo Alto, Utuado, Vega Alta, Vega Baja,
Vieques, Villalba, Yabucoa, Yauco
sugarcane, coffee, pineapples, plantains, bananas,
livestock products, chickens
30 (2003 est.)
14.1 births/1,000 population (2004 est.)
no regular indigenous military forces; paramilitary
National Guard, Police Force
revenues: $6.7 billion
expenditures: $9.6 billion, including capital expenditures of NA
(FY99/00)
Puerto Rico has one of the most dynamic economies in the
Caribbean region. A diverse industrial sector has far surpassed
agriculture as the primary locus of economic activity and income.
Encouraged by duty-free access to the US and by tax incentives, US
firms have invested heavily in Puerto Rico since the 1950s. US
minimum wage laws apply. Sugar production has lost out to dairy
production and other livestock products as the main source of income
in the agricultural sector. Tourism has traditionally been an
important source of income, with estimated arrivals of nearly 5
million tourists in 1999. Growth fell off in 2001-03, largely due to
the slowdown in the US economy.','a393489e1c6232b02dfde58472d596711fff24317703200cc29b3995dd4e6c61','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad44dc7ea2b472b9545ffa7f5a050754263a316a534931e8e1c01bddd64cbd61',2004,'QA','Qatar','economy',787,'total: 2
over 3,047 m: 2 (2004 est.)
Reunion
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
limited natural fresh water resources are increasing
dependence on large-scale desalination facilities
Reunion
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
10% (FY00)
9.264 billion kWh (2001)
Reunion
1.08 billion kWh (2001)
8.616 billion kWh (2001)
Reunion
1.005 billion kWh (2001)
0 kWh (2001)
Reunion
0 kWh (2001)
0 kWh (2001)
Reunion
0 kWh (2001)
NA
Reunion
NA
lowest 10%: NA
highest 10%: NA
Reunion
lowest 10%: NA
highest 10%: NA
petroleum products, fertilizers, steel
Reunion
sugar 63%, rum and molasses 4%, perfume essences 2%, lobster
3%, (1993)
Japan 46%, South Korea 18.5%, Singapore 9.5% (2003)
Reunion
France 74%, Japan 6%, Comoros 4% (2000)
10 municipalities (baladiyat, singular - baladiyah); Ad
Dawhah, Al Ghuwayriyah, Al Jumayliyah, Al Khawr, Al Wakrah, Ar
Rayyan, Jarayan al Batinah, Madinat ash Shamal, Umm Sa''id, Umm Salal
Reunion
none (overseas department of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 4 arrondissements, 24 communes, and 47
cantons
fruits, vegetables; poultry, dairy products, beef; fish
Reunion
sugarcane, vanilla, tobacco, tropical fruits, vegetables,
corn
4 (2003 est.)
Reunion
2 (2003 est.)
15.6 births/1,000 population (2004 est.)
Reunion
19.69 births/1,000 population (2004 est.)
Land Force, Qatari Amiri Navy (QAN), Amiri Air Force
Reunion
no regular indigenous military forces; French forces
(including Army, Navy, Air Force, and Gendarmerie)
revenues: $8.202 billion
expenditures: $6.981 billion, including capital expenditures of $2.2
billion (2003 est.)
Reunion
revenues: $1.26 billion
expenditures: $2.62 billion, including capital expenditures of NA
(1998)
Oil and gas account for more than 55% of GDP, roughly 85% of
export earnings, and 70% of government revenues. Oil and gas have
given Qatar a per capita GDP about 80% of that of the leading West
European industrial countries. Proved oil reserves of 14.5 billion
barrels should ensure continued output at current levels for 23
years. Qatar''s proved reserves of natural gas exceed 17.9 trillion
cubic meters, more than 5% of the world total and third largest in
the world. Long-term goals feature the development of offshore
natural gas reserves to offset the ultimate decline in oil
production. Since 2000, Qatar has consistently posted trade
surpluses largely because of high oil prices and increased natural
gas exports.
Reunion
The economy has traditionally been based on agriculture, but
services now dominate. Sugarcane has been the primary crop for more
than a century, and in some years it accounts for 85% of exports.
The government has been pushing the development of a tourist
industry to relieve high unemployment, which amounts to one-third of
the labor force. The gap in Reunion between the well-off and the
poor is extraordinary and accounts for the persistent social
tensions. The white and Indian communities are substantially better
off than other segments of the population, often approaching
European standards, whereas minority groups suffer the poverty and
unemployment typical of the poorer nations of the African continent.
The outbreak of severe rioting in February 1991 illustrates the
seriousness of socioeconomic tensions. The economic well-being of
Reunion depends heavily on continued financial assistance from
France.
condensate 319 km; condensate/gas 209 km; gas 1,024 km; liquid
petroleum gas 87 km; oil 702 km; oil/gas/water 41 km (2004)','31fd2a5bc7dcd57711091d89cd5d260764b2fb36cce94203a23a90ca74db9654','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bbb65bd83d9564d2d1a36396938d36e0825d816ec1a247c4819a4f76974e4dc',2004,'RO','Romania','economy',788,'total: 25
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12 (2004 est.)
Russia
total: 585
over 3,047 m: 56
2,438 to 3,047 m: 201
1,524 to 2,437 m: 122
914 to 1,523 m: 100
under 914 m: 106 (2003 est.)
total: 36
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 24 (2004 est.)
Russia
total: 2,024
over 3,047 m: 19
2,438 to 3,047 m: 34
1,524 to 2,437 m: 120
914 to 1,523 m: 261
under 914 m: 1,590 (2003 est.)
soil erosion and degradation; water pollution; air pollution
in south from industrial effluents; contamination of Danube delta
wetlands
Russia
air pollution from heavy industry, emissions of coal-fired
electric plants, and transportation in major cities; industrial,
municipal, and agricultural pollution of inland waterways and
seacoasts; deforestation; soil erosion; soil contamination from
improper application of agricultural chemicals; scattered areas of
sometimes intense radioactive contamination; groundwater
contamination from toxic waste; urban solid waste management;
abandoned stocks of obsolete pesticides
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
Russia
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulfur 94, Climate
Change-Kyoto Protocol
2.47% (2002)
Russia
NA
50.86 billion kWh (2001)
Russia
915 billion kWh (2003)
46.1 billion kWh (2001)
Russia
773 billion kWh (2001)
400 million kWh (2001)
Russia
7 billion kWh (2001)
1.6 billion kWh (2001)
Russia
21.16 billion kWh (2001)
44.5% (2000)
Russia
25% (January 2003 est.)
lowest 10%: 3.2%
highest 10%: 25% (1998)
Russia
lowest 10%: 5.9%
highest 10%: 47% (2001)
agriculture 41.4%, industry 27.3%, services 31.3% (2000)
Russia
agriculture 12.3%, industry 22.7%, services 65% (2002 est.)
textiles and footwear, metals and metal products, machinery
and equipment, minerals and fuels, chemicals, agricultural products
Russia
petroleum and petroleum products, natural gas, wood and wood
products, metals, chemicals, and a wide variety of civilian and
military manufactures
Italy 24.3%, Germany 15.7%, France 7.4%, UK 6.7%, Turkey
5.1% (2003)
Russia
Germany 7.8%, Netherlands 6.5%, Italy 6.3%, China 6.2%,
Belarus 5.7%, Ukraine 5.7%, US 4.6%, Switzerland 4.4% (2003)
41 counties (judete, singular - judet) and 1 municipality*
(municipiu); Alba, Arad, Arges, Bacau, Bihor, Bistrita-Nasaud,
Botosani, Braila, Brasov, Bucuresti*, Buzau, Calarasi,
Caras-Severin, Cluj, Constanta, Covasna, Dimbovita, Dolj, Galati,
Gorj, Giurgiu, Harghita, Hunedoara, Ialomita, Iasi, Ilfov,
Maramures, Mehedinti, Mures, Neamt, Olt, Prahova, Salaj, Satu Mare,
Sibiu, Suceava, Teleorman, Timis, Tulcea, Vaslui, Vilcea, Vrancea
Russia
49 oblasts (oblastey, singular - oblast), 21 republics
(respublik, singular - respublika), 10 autonomous okrugs
(avtonomnykh okrugov, singular - avtonomnyy okrug), 6 krays (krayev,
singular - kray), 2 federal cities (singular - gorod), and 1
autonomous oblast (avtonomnaya oblast'')
oblasts: Amur (Blagoveshchensk), Arkhangel''sk, Astrakhan'', Belgorod,
Bryansk, Chelyabinsk, Chita, Irkutsk, Ivanovo, Kaliningrad, Kaluga,
Kamchatka (Petropavlovsk-Kamchatskiy), Kemerovo, Kirov, Kostroma,
Kurgan, Kursk, Leningrad, Lipetsk, Magadan, Moscow, Murmansk,
Nizhniy Novgorod, Novgorod, Novosibirsk, Omsk, Orenburg, Orel,
Penza, Perm'', Pskov, Rostov, Ryazan'', Sakhalin (Yuzhno-Sakhalinsk),
Samara, Saratov, Smolensk, Sverdlovsk (Yekaterinburg), Tambov,
Tomsk, Tula, Tver'', Tyumen'', Ul''yanovsk, Vladimir, Volgograd,
Vologda, Voronezh, Yaroslavl''
republics: Adygeya (Maykop), Altay (Gorno-Altaysk), Bashkortostan
(Ufa), Buryatiya (Ulan-Ude), Chechnya (Groznyy), Chuvashiya
(Cheboksary), Dagestan (Makhachkala), Ingushetiya (Magas),
Kabardino-Balkariya (Nal''chik), Kalmykiya (Elista),
Karachayevo-Cherkesiya (Cherkessk), Kareliya (Petrozavodsk),
Khakasiya (Abakan), Komi (Syktyvkar), Mariy-El (Yoshkar-Ola),
Mordoviya (Saransk), Sakha [Yakutiya] (Yakutsk), North Ossetia
(Vladikavkaz), Tatarstan (Kazan''), Tyva (Kyzyl), Udmurtiya (Izhevsk)
autonomous okrugs: Aga Buryat (Aginskoye), Chukotka (Anadyr''), Evenk
(Tura), Khanty-Mansi, Komi-Permyak (Kudymkar), Koryak (Palana),
Nenets (Nar''yan-Mar), Taymyr [Dolgano-Nenets] (Dudinka), Ust''-Orda
Buryat (Ust''-Ordynskiy), Yamalo-Nenets (Salekhard)
krays: Altay (Barnaul), Khabarovsk, Krasnodar, Krasnoyarsk,
Primorskiy (Vladivostok), Stavropol''
federal cities: Moscow (Moskva), St. Petersburg (Sankt-Peterburg)
autonomous oblast: Yevrey [Jewish] (Birobidzhan)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
wheat, corn, barley, sugar beets, sunflower seed, potatoes,
grapes; eggs, sheep
Russia
grain, sugar beets, sunflower seed, vegetables, fruits; beef,
milk
62 (2003 est.)
Russia
2,609 (2003 est.)
10.69 births/1,000 population (2004 est.)
Russia
9.63 births/1,000 population (2004 est.)
Ground Forces, Naval Forces, Air and Air Defense Forces
(AMR), Civil Defense
Russia
Ground Forces, Navy, Air Forces; Airborne troops, Strategic
Rocket Forces, and Military Space Forces are classified as
independent combat arms, not subordinate to any of the three branches
revenues: $17.06 billion
expenditures: $18.38 billion, including capital expenditures of NA
(2003 est.)
Russia
revenues: $83.99 billion
expenditures: $73.75 billion, including capital expenditures of NA
(2003)
Romania began the transition from Communism in 1989 with a
largely obsolete industrial base and a pattern of output unsuited to
the country''s needs. The country emerged in 2000 from a punishing
three-year recession thanks to strong demand in EU export markets.
Despite the global slowdown in 2001-02, strong domestic activity in
construction, agriculture, and consumption have kept growth above
4%. An IMF standby agreement, signed in 2001, was accompanied by
slow but palpable gains in privatization, deficit reduction, and the
curbing of inflation. The IMF Board approved Romania''s completion of
the standby agreement in October 2003, the first time Romania had
successfully concluded an IMF agreement since the 1989 revolution.
In July 2004, the Executive Board of the IMF approved a 24-month
standby arrangement for $367 million. The Romanian authorities do
not intend to draw on this arrangement, viewing it as a precaution.
Meanwhile, recent macroeconomic gains have done little to address
Romania''s widespread poverty, and corruption and red tape handicap
the business environment.
Russia
Russia ended 2003 with its fifth straight year of growth,
averaging 6.5% annually since the financial crisis of 1998. Although
high oil prices and a relatively cheap ruble are important drivers
of this economic rebound, since 2000 investment and consumer-driven
demand have played a noticeably increasing role. Real fixed capital
investments have averaged gains greater than 10% over the last four
years and real personal incomes have averaged increases over 12%.
Russia has also improved its international financial position since
the 1998 financial crisis, with its foreign debt declining from 90%
of GDP to around 28%. Strong oil export earnings have allowed Russia
to increase its foreign reserves from only $12 billion to some $80
billion. These achievements, along with a renewed government effort
to advance structural reforms, have raised business and investor
confidence in Russia''s economic prospects. Nevertheless, serious
problems persist. Oil, natural gas, metals, and timber account for
more than 80% of exports, leaving the country vulnerable to swings
in world prices. Russia''s manufacturing base is dilapidated and must
be replaced or modernized if the country is to achieve broad-based
economic growth. Other problems include a weak banking system, a
poor business climate that discourages both domestic and foreign
investors, corruption, local and regional government intervention in
the courts, and widespread lack of trust in institutions. In
addition, a string of investigations launched against a major
Russian oil company, culminating with the arrest of its CEO in the
fall of 2003, have raised concerns by some observers that President
PUTIN is granting more influence to forces within his government
that desire to reassert state control over the economy.
gas 3,508 km; oil 2,427 km (2004)
Russia
condensate 122 km; gas 150,007 km; oil 75,539 km; refined
products 13,771 km (2004)','2ad29fecc74c566b98dac8b1ad113461f7cc03cb94288f830a4815525b6f28c6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65a9e1bbbcca9aed94625c0eec66b9fb2a5189159d837ce69ce485eb34821b2e',2004,'RW','Rwanda','economy',789,'total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
Saint Helena
total: 1
over 3,047 m: 1 (2004 est.)
total: 5
914 to 1,523 m: 2
under 914 m: 3 (2004 est.)
deforestation results from uncontrolled cutting of trees for
fuel; overgrazing; soil exhaustion; soil erosion; widespread poaching
Saint Helena
NA
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
2.9% (2003)
96.78 million kWh (2001)
Saint Helena
5 million kWh (2001)
140 million kWh (2001)
Saint Helena
4.65 million kWh (2001)
50 million kWh (2001)
Saint Helena
0 kWh (2001)
0 kWh (2001)
Saint Helena
0 kWh (2001)
60% (2001 est.)
Saint Helena
NA
lowest 10%: 4.2%
highest 10%: 24.2% (1985)
Saint Helena
lowest 10%: NA
highest 10%: NA
agriculture 90%
Saint Helena
agriculture and fishing 6%, industry (mainly
construction) 48%, services 46% (1987 est.)
coffee, tea, hides, tin ore
Saint Helena
fish (frozen, canned, and salt-dried skipjack, tuna),
coffee, handicrafts
Indonesia 39.2%, Germany 4.6%, China 3.9% (2003)
Saint Helena
US 26.7%, Tanzania 21.9%, Indonesia 9.4%, UK 8.7%,
Japan 7.4%, Netherlands 7.2%, Nigeria 6.8%, Poland 5%, Spain 4.9%
(2003)
12 prefectures (in French - prefectures, singular -
prefecture; in Kinyarwanda - plural - NA, singular - prefegitura);
Butare, Byumba, Cyangugu, Gikongoro, Gisenyi, Gitarama, Kibungo,
Kibuye, Kigali Rurale, Kigali-ville, Umutara, Ruhengeri
Saint Helena
1 administrative area and 2 dependencies*; Ascension*,
Saint Helena, Tristan da Cunha*
coffee, tea, pyrethrum (insecticide made from
chrysanthemums), bananas, beans, sorghum, potatoes; livestock
Saint Helena
corn, potatoes, vegetables; timber; fish, crawfish (on
Tristan da Cunha)
9 (2003 est.)
Saint Helena
1 (2003 est.)
40.01 births/1,000 population (2004 est.)
Saint Helena
12.68 births/1,000 population (2004 est.)
Rwandan Defense Forces (Army, Air Forces)
revenues: $365.9 million
expenditures: $402.9 million, including capital expenditures of $NA
(2003 est.)
Saint Helena
revenues: $11.2 million
expenditures: $11 million, including capital expenditures of NA
(FY92/93)
Rwanda is a poor rural country with about 90% of the
population engaged in (mainly subsistence) agriculture. It is the
most densely populated country in Africa; landlocked with few
natural resources and minimal industry. Primary foreign exchange
earners are coffee and tea. The 1994 genocide decimated Rwanda''s
fragile economic base, severely impoverished the population,
particularly women, and eroded the country''s ability to attract
private and external investment. However, Rwanda has made
substantial progress in stabilizing and rehabilitating its economy
to pre-1994 levels, although poverty levels are higher now. GDP has
rebounded, and inflation has been curbed. Export earnings, however,
have been hindered by low beverage prices, depriving the country of
much needed hard currency. Attempts to diversify into
non-traditional agriculture exports such as flowers and vegetables
have been stymied by a lack of adequate transportation
infrastructure. Despite Rwanda''s fertile ecosystem, food production
often does not keep pace with population growth, requiring food to
be imported. Rwanda continues to receive substantial aid money and
was approved for IMF-World Bank Heavily Indebted Poor Country (HIPC)
initiative debt relief in late 2000. But Kigali''s high defense
expenditures cause tension between the government and international
donors and lending agencies.
Saint Helena
The economy depends largely on financial assistance
from the UK, which amounted to about $5 million in 1997 or almost
one-half of annual budgetary revenues. The local population earns
income from fishing, the raising of livestock, and sales of
handicrafts. Because there are few jobs, 25% of the work force has
left to seek employment on Ascension Island, on the Falklands, and
in the UK.','ddbbd466b715f545a0a9760da3567292e36cef2b38dbef4583a084263369ed52','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('256819c6030f8ace075090fc0f04ace3ec1e593386408eea6da18c0bf00e1ed3',2004,'KN','Saint Kitts and Nevis','economy',790,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
NA
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
100.3 million kWh (2001)
93.26 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
NA
machinery, food, electronics, beverages,
tobacco
US 61.4%, UK 15.7%, Canada 8.6%, Germany 4.3%
(2003)
14 parishes; Christ Church Nichola Town, Saint
Anne Sandy Point, Saint George Basseterre, Saint George Gingerland,
Saint James Windward, Saint John Capesterre, Saint John Figtree,
Saint Mary Cayon, Saint Paul Capesterre, Saint Paul Charlestown,
Saint Peter Basseterre, Saint Thomas Lowland, Saint Thomas Middle
Island, Trinity Palmetto Point
sugarcane, rice, yams, vegetables, bananas;
fish
2 (2003 est.)
18.26 births/1,000 population (2004 est.)
Saint Kitts and Nevis Defense Force (including
Coast Guard), Royal Saint Kitts and Nevis Police Force (including
Special Service Unit)
revenues: $89.7 million
expenditures: $128.2 million, including capital expenditures of
$19.5 million (2003 est.)
Sugar was the traditional mainstay of the
Saint Kitts economy until the 1970s. Although the crop still
dominates the agricultural sector, activities such as tourism,
export-oriented manufacturing, and offshore banking have assumed
larger roles in the economy. As tourism revenues are now the chief
source of the islands'' foreign exchange, a decline in stopover
tourist arrivals following the 11 September 2001 terrorist attacks
has eroded government finances. The opening of a 1,000+ bed Marriott
hotel in February 2003 was expected to bring in much-needed revenue.','a52e20421a838b942777e9b2d5f582788a99434cd56041ae714f20b857c4856d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a33bbad02a04ef5ed15084653622aea0e17f7d307ec1a4242e69f9e7c19759e',2004,'LC','Saint Lucia','economy',791,'total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
deforestation; soil erosion, particularly in the
northern region
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
120.2 million kWh (2001)
111.8 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 21.7%, industry, commerce, and manufacturing
24.7%, services 53.6% (2002 est.)
bananas 41%, clothing, cocoa, vegetables, fruits,
coconut oil
UK 48%, US 24%, Antigua and Barbuda 6%, Dominica 6%,
Grenada 4% (2003)
11 quarters; Anse-la-Raye, Castries, Choiseul, Dauphin,
Dennery, Gros-Islet, Laborie, Micoud, Praslin, Soufriere, Vieux-Fort
bananas, coconuts, vegetables, citrus, root crops, cocoa
2 (2003 est.)
20.5 births/1,000 population (2004 est.)
Royal Saint Lucia Police Force (including Special
Service Unit, Coast Guard)
revenues: $141.2 million
expenditures: $146.7 million, including capital expenditures of
$25.1 million (2000 est.)
Changes in the EU import preference regime and the
increased competition from Latin American bananas have made economic
diversification increasingly important in Saint Lucia. The island
nation has been able to attract foreign business and investment,
especially in its offshore banking and tourism industries. The
manufacturing sector is the most diverse in the Eastern Caribbean
area, and the government is trying to revitalize the banana
industry. Economic fundamentals remain solid.','5bda2c094b781edbccf71f66743a90635ddc0ae90be370a76a8e309f1251cffb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d63b2b339b274520ba63e230cd680ae3f5c471004b85fed176e08c31f878e91',2004,'PM','Saint Pierre and Miquelon','economy',792,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
recent test drilling for oil in waters
around Saint Pierre and Miquelon may bring future development that
would impact the environment
42.03 million kWh (2001)
39.08 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
fishing 18%, industry (mainly
fish-processing) 41%, services 41% (1996 est.)
fish and fish products, soybeans, animal
feed, mollusks and crustaceans, fox and mink pelts
US 42.9%, Ecuador 28.6%, Canada 14.3%,
France 14.3% (2003)
none (territorial collectivity of France);
note - there are no first-order administrative divisions as defined
by the US Government, but there are two communes - Saint Pierre,
Miquelon at the second order
vegetables; poultry, cattle, sheep, pigs;
fish
2 (2003 est.)
14.15 births/1,000 population (2004 est.)
revenues: $70 million
expenditures: $60 million, including capital expenditures of $24
million (1996 est.)
The inhabitants have traditionally earned
their livelihood by fishing and by servicing fishing fleets
operating off the coast of Newfoundland. The economy has been
declining, however, because of disputes with Canada over fishing
quotas and a steady decline in the number of ships stopping at Saint
Pierre. In 1992, an arbitration panel awarded the islands an
exclusive economic zone of 12,348 sq km to settle a longstanding
territorial dispute with Canada, although it represents only 25% of
what France had sought. The islands are heavily subsidized by France
to the great betterment of living standards. The government hopes an
expansion of tourism will boost economic prospects. Recent test
drilling for oil may pave the way for development of the energy
sector.','143c9bd41eb8adc5e91fa0439ad9f743a672e53461f944f0c718d586af2363be','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8980a26f7fc8c4a508a91dcd58012ce47ad47301beaabe69e18ebd5bfff10362',2004,'VC','Saint Vincent and the Grenadines','economy',793,'total: 5
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
pollution of coastal waters and
shorelines from discharges by pleasure yachts and other effluents;
in some areas, pollution is severe enough to make swimming
prohibitive
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA
92.48 million kWh (2001)
86 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
agriculture 26%, industry 17%,
services 57% (1980 est.)
bananas 39%, eddoes and dasheen
(taro), arrowroot starch, tennis racquets
France 52.7%, UK 6.9%, Greece 6.4%,
Spain 6.4% (2003)
6 parishes; Charlotte, Grenadines,
Saint Andrew, Saint David, Saint George, Saint Patrick
bananas, coconuts, sweet potatoes,
spices, small numbers of cattle, sheep, pigs, goats, fish
6 (2003 est.)
16.77 births/1,000 population (2004
est.)
Royal Saint Vincent and the
Grenadines Police Force (includes Special Service Unit), Coast Guard
revenues: $94.6 million
expenditures: $85.8 million, including capital expenditures of NA
(2000 est.)
Economic growth in this
lower-middle-income country hinges upon seasonal variations in the
agricultural and tourism sectors. Tropical storms wiped out
substantial portions of crops in 1994, 1995, and 2002, and tourism
in the Eastern Caribbean has suffered low arrivals following 11
September 2001. Saint Vincent is home to a small offshore banking
sector and has moved to adopt international regulatory standards.
Saint Vincent is also a large producer of marijuana and is being
used as a transshipment point for illegal narcotics from South
America.','0ea5279711ba6e8de802a72b0ba03a4315155e34ff8e0b78aa4d7407d30082a7','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1809c9850e38c64f29bc04d131b802438bfa4d3264ab54f6eb3d6d2126631a3',2004,'WS','Samoa','economy',794,'total: 3
2,438 to 3,047 m: 1
under 914 m: 2 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
soil erosion, deforestation, invasive species, overfishing
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
NA
105.1 million kWh (2001)
97.74 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
NA
lowest 10%: NA
highest 10%: NA
NA
fish, coconut oil and cream, copra, taro, automotive parts,
garments, beer
Australia 63.6%, Indonesia 15.2%, US 5.1% (2003)
11 districts; A''ana, Aiga-i-le-Tai, Atua, Fa''asaleleaga,
Gaga''emauga, Gagaifomauga, Palauli, Satupa''itea, Tuamasaga,
Va''a-o-Fonoti, Vaisigano
coconuts, bananas, taro, yams, coffee, cocoa
4 (2003 est.)
15.69 births/1,000 population (2004 est.)
no regular armed services; Samoa Police Force
revenues: $105 million
expenditures: $119 million, including capital expenditures of NA
(2001-02)
The economy of Samoa has traditionally been dependent on
development aid, family remittances from overseas, and agriculture
and fishing. The country is vulnerable to devastating storms.
Agriculture employs two-thirds of the labor force, and furnishes 90%
of exports, featuring coconut cream, coconut oil, and copra. The
manufacturing sector mainly processes agricultural products. The
decline of fish stocks in the area is a continuing problem. Tourism
is an expanding sector, accounting for 25% of GDP; about 88,000
tourists visited the islands in 2001. The Samoan Government has
called for deregulation of the financial sector, encouragement of
investment, and continued fiscal discipline, meantime protecting the
environment. Observers point to the flexibility of the labor market
as a basic strength for future economic advances. Foreign reserves
are in a relatively healthy state, the external debt is stable, and
inflation is low.','f4209d578ba008d07fc43a64f378ec7afc790ae9514a0d93a478362b34ff1e93','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('806ea8bea2a798e0ffb5b39932c8801881695a17ea6b6255a3f2cf32b59e87e4',2004,'ST','Sao Tome and Principe','economy',795,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
deforestation; soil erosion and exhaustion
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
0.8% (2003)
17 million kWh (2001)
15.81 million kWh (2001)
0 kWh (2001)
0 kWh (2001)
54% NA (2004 est.)
lowest 10%: NA
highest 10%: NA
population mainly engaged in subsistence
agriculture and fishing
note: shortages of skilled workers
cocoa 80%, copra, coffee, palm oil
Netherlands 41.7%, Canada 16.7%, Belgium 8.3%,
Germany 8.3%, Philippines 8.3% (2003)
2 provinces; Principe, Sao Tome
note: Principe has had self-government since 29 April 1995
cocoa, coconuts, palm kernels, copra,
cinnamon, pepper, coffee, bananas, papayas, beans; poultry; fish
2 (2003 est.)
41.36 births/1,000 population (2004 est.)
Army, Coast Guard, Presidential Guard,
National Guard
revenues: $38.59 million
expenditures: $42.04 million, including capital expenditures of $54
million (2003 est.)
This small poor island economy has become
increasingly dependent on cocoa since independence 29 years ago.
Cocoa production has substantially declined in recent years because
of drought and mismanagement, but strengthening prices helped boost
export earnings in 2003. Sao Tome has to import all fuels, most
manufactured goods, consumer goods, and a substantial amount of
food. Over the years, it has been unable to service its external
debt and has had to depend on concessional aid and debt
rescheduling. Sao Tome benefited from $200 million in debt relief in
December 2000 under the Highly Indebted Poor Countries (HIPC)
program. Sao Tome''s success in implementing structural reforms has
been rewarded by international donors, who pledged increased
assistance in 2001. Considerable potential exists for development of
a tourist industry, and the government has taken steps to expand
facilities in recent years. The government also has attempted to
reduce price controls and subsidies. Sao Tome is optimistic about
the development of petroleum resources in its territorial waters in
the oil-rich Gulf of Guinea; production could begin as early as 2004.','d8c18c2be0d21567e83af04652334791f06c567e4809c39d4f0b1a16fe612143','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bb4886de1dfbdff5cec54e2a3c2157adcd41b2bc44740c64707534705e4a902',2004,'AQ','Antarctica','economy',796,'total: 20
over 3,047 m: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 6 (2004 est.)
in 1998, NASA satellite data showed that the antarctic
ozone hole was the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased ultraviolet
light coming through the hole damages the DNA of icefish, an
antarctic fish lacking hemoglobin; ozone depletion earlier was shown
to harm one-celled antarctic marine plants; in 2002, significant
areas of ice shelves disintegrated in response to regional warming
there are no developed public access airports or landing
facilities; 30 stations, operated by 16 national governments party
to the Antarctic Treaty, have restricted aircraft landing facilities
for either helicopters and/or fixed-wing aircraft; commercial
enterprises operate two additional aircraft landing facilities;
helicopter pads are available at 27 stations; runways at 15
locations are gravel, sea-ice, blue-ice, or compacted snow suitable
for landing wheeled, fixed-wing aircraft; of these, 1 is greater
than 3 km in length, 6 are between 2 km and 3 km in length, 3 are
between 1 km and 2 km in length, 3 are less than 1 km in length, and
2 are of unknown length; snow surface skiways, limited to use by
ski-equipped, fixed-wing aircraft, are available at another 15
locations; of these, 4 are greater than 3 km in length, 3 are
between 2 km and 3 km in length, 2 are between 1 km and 2 km in
length, 2 are less than 1 km in length, and 4 are of unknown length;
aircraft landing facilities generally subject to severe restrictions
and limitations resulting from extreme seasonal and geographic
conditions; aircraft landing facilities do not meet ICAO standards;
advance approval from the respective governmental or nongovernmental
operating organization required for landing; landed aircraft are
subject to inspection in accordance with Article 7, Antarctic Treaty
(2003 est.)','5ae01d6d54c9167c83ff49896e8255124f01f47afca276ac518f5504828a5dd3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6311b31e22099d968d63cd3e40b5b66683b10ab8e036dd668af6fea2423b41e9',2004,'AD','Andorra','economy',797,'deforestation; overgrazing of mountain meadows contributes
to soil erosion; air pollution; wastewater treatment and solid waste
disposal
party to: Hazardous Wastes
signed, but not ratified: none of the selected agreements
NA kWh
NA kWh
NA kWh; note - most electricity supplied by Spain and
France; Andorra generates a small amount of hydropower
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 1%, industry 21%, services 78% (2000 est.)
tobacco products, furniture
Spain 58%, France 34% (2000)
7 parishes (parroquies, singular - parroquia); Andorra la
Vella, Canillo, Encamp, La Massana, Escaldes-Engordany, Ordino, Sant
Julia de Loria
small quantities of rye, wheat, barley, oats, vegetables;
sheep
none
9.32 births/1,000 population (2004 est.)
no regular military forces, Police Service of Andorra
revenues: $385 million
expenditures: $342 million, including capital expenditures of NA
(1997)
Andorra la Vella
Andorran Democratic Center Party or CDA (formerly Democratic
Party or PD) [leader NA]; Liberal Party of Andorra or PLA (formerly
Liberal Union or UL) [Albert PINTAT]; Social Democratic Party or PS
(formerly part of National Democratic Group or AND) [leader NA]','39e7c48cc2260e3fb3fa338ec4c8bd86d0a7b7aa267613d8f83631f67533d5b9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1606db9fc35866a5917bb75d3fbdc17e910f7227516b3bef4d487da5797c5b2b',2004,'HM','Heard Island and McDonald Islands','economy',798,'NA
Holy See (Vatican City)
NA
No indigenous economic activity,
but the Australian Government allows limited fishing around the
islands.
Holy See (Vatican City)
This unique, noncommercial economy is
supported financially by an annual contribution from Roman Catholic
dioceses throughout the world, as well as by special collections
(known as Peter''s Pence); the sale of postage stamps, coins, medals,
and tourist mementos; fees for admission to museums; and the sale of
publications. Investments and real estate income also account for a
sizable portion of revenue. The incomes and living standards of lay
workers are comparable to those of counterparts who work in the city
of Rome.','4ede0a981d5d5c6c2ebddb9669ce44fab90f7973717b7964dd4ab86f94e7f4f6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be351dbeccc337e60ef642efb8e69ce08b051d5368ab4184b3ec4f872dd8ae02',2004,'LI','Liechtenstein','economy',799,'NA
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Law of the Sea
NA
lowest 10%: NA
highest 10%: NA
agriculture 1.3%, industry 47.4%, services 51.3% (31
December 2001 est.)
small specialty machinery, connectors for audio and
video, parts for motor vehicles, dental products, hardware, prepared
foodstuffs, electronic equipment, optical products
EU 62.6% (Germany 24.3%, Austria 9.5%, France 8.9%,
Italy 6.6%, UK 4.6%), US 18.9%, Switzerland 15.7%
11 communes (Gemeinden, singular - Gemeinde); Balzers,
Eschen, Gamprin, Mauren, Planken, Ruggell, Schaan, Schellenberg,
Triesen, Triesenberg, Vaduz
wheat, barley, corn, potatoes; livestock, dairy
products
none (2003 est.)
10.65 births/1,000 population (2004 est.)
revenues: $424.2 million
expenditures: $414.1 million, including capital expenditures of NA
(1998 est.)
Despite its small size and limited natural resources,
Liechtenstein has developed into a prosperous, highly
industrialized, free-enterprise economy with a vital financial
service sector and living standards on a par with its large European
neighbors. The Liechtenstein economy is widely diversified with a
large number of small businesses. Low business taxes - the maximum
tax rate is 20% - and easy incorporation rules have induced many
holding or so-called letter box companies to establish nominal
offices in Liechtenstein, providing 30% of state revenues. The
country participates in a customs union with Switzerland and uses
the Swiss franc as its national currency. It imports more than 90%
of its energy requirements. Liechtenstein has been a member of the
European Economic Area (an organization serving as a bridge between
the European Free Trade Association (EFTA) and the EU) since May
1995. The government is working to harmonize its economic policies
with those of an integrated Europe.
gas 20 km (2004)','abc4991dd69332f5aef2f35cfb38e71a5096cc841124186b562a4a7e91700876','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6329613504931e1e717b6c176d4675a2e93b6bb533a1b0d68d4c16a55201965',2004,'MC','Monaco','economy',800,'NA
party to: Air Pollution, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA kWh
NA kWh
note: electricity supplied by France
NA
lowest 10%: NA
highest 10%: NA
none; there are no first-order administrative divisions as
defined by the US Government, but there are four quarters
(quartiers, singular - quartier); Fontvieille, La Condamine,
Monaco-Ville, Monte-Carlo
none
none; linked to the airport at Nice, France by helicopter
service (2003) (2003 est.)
9.36 births/1,000 population (2004 est.)
revenues: $518 million
expenditures: $531 million, including capital expenditures of NA
(1995)
Monaco, bordering France on the Mediterranean coast, is a
popular resort, attracting tourists to its casino and pleasant
climate. In 2001, a major construction project extended the pier
used by cruise ships in the main harbor. The principality has
successfully sought to diversify into services and small,
high-value-added, nonpolluting industries. The state has no income
tax and low business taxes and thrives as a tax haven both for
individuals who have established residence and for foreign companies
that have set up businesses and offices. The state retains
monopolies in a number of sectors, including tobacco, the telephone
network, and the postal service. Living standards are high, roughly
comparable to those in prosperous French metropolitan areas. Monaco
does not publish national income figures; the estimates below are
extremely rough.','388037271187d10f3931dd3e64ad43d3635c43b4e935bbdd85685c9cf63544e7','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b92247809c74a53c9c0049a60f07fe7d23aff2daca38a908f8a68fb010812e51',2004,'SM','San Marino','economy',801,'NA
party to: Biodiversity, Climate Change, Desertification
signed, but not ratified: Air Pollution
NA
NA
lowest 10%: NA
highest 10%: NA
agriculture 1%, industry 42%, services 57% (2000 est.)
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, ceramics
9 municipalities (castelli, singular - castello);
Acquaviva, Borgo Maggiore, Chiesanuova, Domagnano, Faetano,
Fiorentino, Montegiardino, San Marino Citta, Serravalle
wheat, grapes, corn, olives; cattle, pigs, horses, beef,
cheese, hides
none (2003 est.)
10.31 births/1,000 population (2004 est.)
Voluntary Military Force (Corpi Militari Voluntar); note
- the Voluntary Military Force performs ceremonial duties and
limited police assistance
revenues: $400 million
expenditures: $400 million, including capital expenditures of NA
(2000 est.)
The tourist sector contributes over 50% of GDP. In 2000
more than 3 million tourists visited San Marino. The key industries
are banking, wearing apparel, electronics, and ceramics. Main
agricultural products are wine and cheeses. The per capita level of
output and standard of living are comparable to those of the most
prosperous regions of Italy, which supplies much of its food.','a15457b7ccc29b29841d8d69115490a4f5fec9a4513a079901f3d421bac7076e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

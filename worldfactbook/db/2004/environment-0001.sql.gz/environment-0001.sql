SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c22738a17825d84d47210c327004ad49ed9adab42d6c33f9a28b8f8096800b5',2004,'KN','Saint Kitts and Nevis','environment',182,'Geography - note:
vegetation scanty
People Saint Pierre and Miquelon
Population:
6,995 (July 2004 est.)
Age structure:
0-14 years: 24.6% (male 878; female 840)
15-64 years: 64.9% (male 2,316; female 2,227)
65 years and over: 10.5% (male 323; female 411) (2004 est.)
Median age:
total: 33.3 years
male: 33 years
female: 33.6 years (2004 est.)
Population growth rate:
0.26% (2004 est.)
Birth rate:
14.15 births/1,000 population (2004 est.)
Death rate:
6.72 deaths/1,000 population (2004 est.)
Net migration rate:
-4.86 migrant(s)/1,000 population (2004 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1.01 male(s)/female (2004 est.)
Infant mortality rate:
total: 7.76 deaths/1,000 live births
female: 6.55 deaths/1,000 live births (2004 est.)
male: 8.91 deaths/1,000 live births
Life expectancy at birth:
total population: 78.28 years
male: 75.97 years
female: 80.7 years (2004 est.)
Total fertility rate:
2.05 children born/woman (2004 est.)
HIV/AIDS - adult prevalence rate:
NA
HIV/AIDS - people living with HIV/AIDS:
NA
HIV/AIDS - deaths:
NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups:
Basques and Bretons (French fishermen)
Religions:
Roman Catholic 99%
Languages:
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Government Saint Pierre and Miquelon
Country name:
conventional long form: Territorial Collectivity of Saint Pierre
and Miquelon
conventional short form: Saint Pierre and Miquelon
local short form: Saint-Pierre et Miquelon
local long form: Departement de Saint-Pierre et Miquelon
Dependency status:
self-governing territorial collectivity of France
Government type:
NA
Capital:
Saint-Pierre
Administrative divisions:
none (territorial collectivity of France); note - there are no
first-order administrative divisions as defined by the US
Government, but there are two communes - Saint Pierre, Miquelon at
the second order
Independence:
none (territorial collectivity of France; has been under French
control since 1763)
National holiday:
Bastille Day, 14 July (1789)
Constitution:
28 September 1958 (French Constitution)
Legal system:
French law with special adaptations for local conditions, such as
housing and taxation
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France (since 17 May
1995), represented by Prefect Albert DUPUY (since 10 January 2005)
elections: French president elected by popular vote for a five-year
term; election last held, first round - 21 April 2002, second round
- 5 May 2002 (next to be held NA 2007); prefect appointed by the
French president on the advice of the French Ministry of Interior;
president of the General Council is elected by the members of the
council
head of government: President of the General Council Marc
PLANTAGENEST (since NA)
cabinet: NA
Legislative branch:
unicameral General Council or Conseil General (19 seats - 15 from
Saint Pierre and 4 from Miquelon; members are elected by popular
vote to serve six-year terms)
elections: elections last held 19 and 26 March 2000 (next to be held
NA April 2006)
election results: percent of vote by party - NA; seats by party - PS
12, PRG 2, UDF-RPR 5
note: Saint Pierre and Miquelon elect 1 seat to the French Senate;
elections last held NA September 1995 (next to be held NA September
2004); results - percent of vote by party - NA; seats by party - RPR
1; Saint Pierre and Miquelon also elects 1 seat to the French
National Assembly; elections last held, first round - 9 June 2002,
second round - 16 June 2002 (next to be held NA 2007); results -
percent of vote by party - NA; seats by party - UDF 1
Judicial branch:
Superior Tribunal of Appeals or Tribunal Superieur d''Appel
Political parties and leaders:
PRG [leader NA]; Rassemblement pour la Republique or RPR (now UMP)
[leader NA]; Socialist Party or PS [leader NA]; Union pour la
Democratie Francaise or UDF [leader NA]
Political pressure groups and leaders:
NA
International organization participation:
UPU, WFTU
Diplomatic representation in the US:
none (territorial collectivity of France)
Diplomatic representation from the US:
none (territorial collectivity of France)
Flag description:
a yellow sailing ship facing the hoist side rides on a dark blue
background with yellow wavy lines under the ship; on the hoist side,
a vertical band is divided into three parts: the top part (called
ikkurina) is red with a green diagonal cross extending to the
corners overlaid by a white cross dividing the rectangle into four
sections; the middle part has a white background with an ermine
pattern; the third part has a red background with two stylized
yellow lions outlined in black, one above the other; these three
heraldic arms represent settlement by colonists from the Basque
Country (top), Brittany, and Normandy; the flag of France is used
for official occasions
Economy Saint Pierre and Miquelon
Economy - overview:
The inhabitants have traditionally earned their livelihood by
fishing and by servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining, however, because of
disputes with Canada over fishing quotas and a steady decline in the
number of ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic zone of 12,348 sq km
to settle a longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought. The islands are
heavily subsidized by France to the great betterment of living
standards. The government hopes an expansion of tourism will boost
economic prospects. Recent test drilling for oil may pave the way
for development of the energy sector.
GDP:
purchasing power parity - $48.33 million - supplemented by annual
payments from France of about $60 million (2003 est.)
GDP - real growth rate:
NA
GDP - per capita:
purchasing power parity - $6,900 (2001 est.)
GDP - composition by sector:
agriculture: NA
industry: NA
services: NA
Population below poverty line:
NA
Household income or consumption by percentage share:
lowest 10%: NA
highest 10%: NA
Inflation rate (consumer prices):
2.1% (1991-96 average)
Labor force:
3,261 (1999)
Labor force - by occupation:
fishing 18%, industry (mainly fish-processing) 41%, services 41%
(1996 est.)
Unemployment rate:
9.8% (1997)
Budget:
revenues: $70 million
expenditures: $60 million, including capital expenditures of $24
million (1996 est.)
Agriculture - products:
vegetables; poultry, cattle, sheep, pigs; fish
Industries:
fish processing and supply base for fishing fleets; tourism
Industrial production growth rate:
NA
Electricity - production:
42.03 million kWh (2001)
Electricity - consumption:
39.08 million kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
0 kWh (2001)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
600 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Exports:
$10 million f.o.b. (2002)
Exports - commodities:
fish and fish products, soybeans, animal feed, mollusks and
crustaceans, fox and mink pelts
Exports - partners:
US 42.9%, Ecuador 28.6%, Canada 14.3%, France 14.3% (2003)
Imports:
$106 million f.o.b. (2002)
Imports - commodities:
meat, clothing, fuel, electrical equipment, machinery, building
materials
Imports - partners:
France 51%, Canada 31.4%, Italy 11.8% (2003)
Debt - external:
NA (2003 est.)
Economic aid - recipient:
approximately $60 million in annual grants from France
Currency:
euro (EUR)
Currency code:
EUR
Exchange rates:
euros per US dollar - 0.886 (2003), 1.0626 (2002), 1.0626 (2001),
1.08540 (2000), 0.93863 (1999)
Fiscal year:
calendar year
Communications Saint Pierre and Miquelon
Telephones - main lines in use:
4,800 (2002)
Telephones - mobile cellular:
0 (1994)
Telephone system:
general assessment: adequate
domestic: NA
international: country code - 508; radiotelephone communication with
most countries in the world; 1 earth station in French domestic
satellite system
Radio broadcast stations:
AM 1, FM 4, shortwave 0 (1998)
Radios:
4,000 (1997)
Television broadcast stations:
0 (there are, however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions:
4,000 (1997)
Internet country code:
.pm
Internet Service Providers (ISPs):
1 (2000)
Internet users:
NA
Transportation Saint Pierre and Miquelon
Highways:
total: 114 km
paved: 69 km
unpaved: 45 km
Ports and harbors:
Saint Pierre
Merchant marine:
none
Airports:
2 (2003 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
Military Saint Pierre and Miquelon
Military - note:
defense is the responsibility of France
Transnational Issues Saint Pierre and Miquelon
Disputes - international:
none
This page was last updated on 10 February, 2005
======================================================================
@Saint Vincent and the Grenadines
Introduction Saint Vincent and the Grenadines','f4eed12b9c5fcfe64761022b6896260efb2d8b47e01d5fc3e7c3c568556bdb4b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

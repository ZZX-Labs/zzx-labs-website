SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd6337de8d7e3ef12e361c33a39658bd0aa43d38c09064b5d3dd390bba3ac7c5',2004,'ZW','Zimbabwe','people-and-society',3,'Population
Birth rate
Death rate
Infant mortality rate
Life expectancy at birth - total
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS - deaths
Economy Zimbabwe
Economy - overview:
The government of Zimbabwe faces a wide variety of difficult
economic problems as it struggles with an unsustainable fiscal
deficit, an overvalued exchange rate, soaring inflation, and bare
shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the country''s failure to meet budgetary goals.
Inflation rose from an annual rate of 32% in 1998 to 383% in 2003,
and is expected to reach 700% in 2004. The government''s land reform
program, characterized by chaos and violence, has badly damaged the
commercial farming sector, the traditional source of exports and
foreign exchange and the provider of 400,000 jobs.
GDP:
purchasing power parity - $24.03 billion (2003 est.)
GDP - real growth rate:
-13.6% (2003 est.)
GDP - per capita:
purchasing power parity - $1,900 (2003 est.)
GDP - composition by sector:
agriculture: 17.3%
industry: 24.5%
services: 58.3% (2003)
Investment (gross fixed):
8.9% of GDP (2003)
Population below poverty line:
70% (2002 est.)
Household income or consumption by percentage share:
lowest 10%: 1.97%
highest 10%: 40.42% (1995)
Distribution of family income - Gini index:
50.1 (1995)
Inflation rate (consumer prices):
384.7% (2003 est.)
Labor force:
4.17 million (2003 est.)
Labor force - by occupation:
agriculture 66%, industry 10%, services 24% (1996)
Unemployment rate:
70% (2002 est.)
Budget:
revenues: $1.568 billion
expenditures: $2.004 billion, including capital expenditures of NA
(2003)
Public debt:
41.3% of GDP (2003)
Agriculture - products:
corn, cotton, wheat, coffee, sugarcane, peanuts; sheep, goats, pigs
Industries:
mining (coal, gold, copper, nickel, tin, clay, numerous metallic
and nonmetallic ores), steel, wood products, cement, chemicals,
fertilizer, clothing and footwear, foodstuffs, beverages
Industrial production growth rate:
-14.7% (2003 est.)
Electricity - production:
6.735 billion kWh (2001)
Electricity - consumption:
9.813 billion kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
3.55 billion kWh (2001)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
23,000 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Current account balance:
$-346 million (2003)
Exports:
$1.261 billion f.o.b. (2003 est.)
Exports - commodities:
tobacco, gold, ferroalloys, textiles/clothing
Exports - partners:
Zambia 6.3%, South Africa 6.1%, China 5.3%, Germany 4.6%, Japan
4.4% (2003)
Imports:
$1.691 billion f.o.b. (2003 est.)
Imports - commodities:
machinery and transport equipment, other manufactures, chemicals,
fuels
Imports - partners:
South Africa 51.3%, Congo, Democratic Republic of the 6.1%, Germany
2.8% (2003)
Reserves of foreign exchange & gold:
$78 million (2003)
Debt - external:
$3.404 billion (2003 est.)
Economic aid - recipient:
$178 million; note - the EU and the US provide food aid on
humanitarian grounds (2000 est.)
Currency:
Zimbabwean dollar (ZWD)
Currency code:
ZWD
Exchange rates:
Zimbabwean dollars per US dollar - NA (2003), 55.0358 (2002),
55.0521 (2001), 44.4179 (2000), 38.3012 (1999); note - these are
official exchange rates, non-official rates vary significantly
Fiscal year:
1 January - 31 December
Communications Zimbabwe
Telephones - main lines in use:
300,900 (2003)
Telephones - mobile cellular:
379,100 (2003)
Telephone system:
general assessment: system was once one of the best in Africa, but
now suffers from poor maintenance; more than 100,000 outstanding
requests for connection despite an equally large number of installed
but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; two international digital gateway exchanges (in Harare and
Gweru)
Radio broadcast stations:
AM 7, FM 20 (plus 17 repeater stations), shortwave 1 (1998)
Radios:
1.14 million (1997)
Television broadcast stations:
16 (1997)
Televisions:
370,000 (1997)
Internet country code:
.zw
Internet hosts:
4,501 (2003)
Internet Service Providers (ISPs):
6 (2000)
Internet users:
500,000 (2002)
Transportation Zimbabwe
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge (313 km electrified) (2003)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1999 est.)
Waterways:
on Lake Kariba, length small (2003)
Pipelines:
refined products 261 km (2004)
Ports and harbors:
Binga, Kariba
Airports:
404 (2003 est.)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2004 est.)
Airports - with unpaved runways:
total: 387
1,524 to 2,437 m: 5
914 to 1,523 m: 186
under 914 m: 196 (2004 est.)
Military Zimbabwe
Military branches:
Zimbabwe National Army, Air Force of Zimbabwe, Zimbabwe Republic
Police (includes Police Support Unit, Paramilitary Police)
Military manpower - military age and obligation:
18 years of age (est.) (2004)
Military manpower - availability:
males age 15-49: 3,285,007 (2004 est.)
Military manpower - fit for military service:
males age 15-49: 2,033,978 (2004 est.)
Military expenditures - dollar figure:
$105 million (2003)
Military expenditures - percent of GDP:
1.7% (2003)
Transnational Issues Zimbabwe
Disputes - international:
the Botswana, Namibia, Zambia, and Zimbabwe boundary convergence is
not clearly defined or delimited
Refugees and internally displaced persons:
IDPs: 100,000-150,000 (Mugabe-led political violence, human rights
violations, land reform, and economic collapse) (2004)
Illicit drugs:
transit point for African cannabis and South Asian heroin, mandrax,
and methamphetamines destined for the South African and European
markets
This page was last updated on 10 February, 2005
======================================================================
@2001 GDP
purchasing power parity - $24.03 billion (2003 est.)
This page was last updated on 10 February, 2005
======================================================================
@2002 Population growth rate (%)
0.68% (2004 est.)
This page was last updated on 10 February, 2005
======================================================================
@2003 GDP - real growth rate (%)
-13.6% (2003 est.)
This page was last updated on 10 February, 2005
======================================================================
@2004 GDP - per capita
purchasing power parity - $1,900 (2003 est.)
This page was last updated on 10 February, 2005
======================================================================
@2006 Dependency status
Akrotiri
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus','a91ead2bc72d7acb2ba3e4a89d5ac9e2915b9f9dedd7f1839c77daac3330ddfb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c01b9a6cace3f462bf7ffb25cae837a55526b875b7c5378954809e31925e973e',2004,'TC','Turks and Caicos Islands','people-and-society',32,'This category includes the entries dealing with the characteristics of
the people and their society.
People - note
This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization
The Factbook capitalizes the surname or family name of individuals for
the convenience of our users who are faced with a world of different
cultures and naming conventions. The need for capitalization, bold
type, underlining, italics, or some other indicator of the individual''s
surname is apparent in the following examples: MAO Zedong, Fidel
CASTRO Ruz, George W. BUSH, and TUNKU SALAHUDDIN Abdul Aziz Shah ibni
Al-Marhum Sultan Hisammuddin Alam Shah. By knowing the surname, a
short form without all capital letters can be used with confidence as
in President Castro, Chairman Mao, President Bush, or Sultan Tunku
Salahuddin. The same system of capitalization is extended to the names
of leaders with surnames that are not commonly used such as Queen
ELIZABETH II.
Personal Names - Spelling
The romanization of personal names in the Factbook normally follows the
same transliteration system used by the US Board on Geographic Names
for spelling place names. At times, however, a foreign leader
expressly indicates a preference for, or the media or official
documents regularly use, a romanized spelling that differs from the
transliteration derived from the US Government standard. In such
cases, the Factbook uses the alternative spelling.
Personal Names - Titles
The Factbook capitalizes any valid title (or short form of it)
immediately preceding a person''s name. A title standing alone is not
capitalized. Examples: President PUTIN and President BUSH are chiefs
of state. In Russia, the president is chief of state and the premier is
the head of the government, while in the US, the president is both
chief of state and head of government.
Petroleum
See entry for "oil."
Petroleum products
See entry for "oil."
Pipelines
This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders
This entry includes a listing of significant political organizations
and their leaders.
Political pressure groups and leaders
This entry includes a listing of organizations with leaders involved in
politics, but not standing for legislative election.
Population
This entry gives an estimate from the US Bureau of the Census based on
statistics from population censuses, vital statistics registration
systems, or sample surveys pertaining to the recent past and on
assumptions about future trends. The total population presents one
overall measure of the potential impact of the country on the world and
within its region. Note: starting with the 1993 Factbook, demographic
estimates for some countries (mostly African) have explicitly taken
into account the effects of the growing impact of the HIV/AIDS
epidemic. These countries are currently: The Bahamas, Benin, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central
African Republic, Democratic Republic of the Congo, Republic of the
Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti, Honduras,
Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria, Rwanda, South
Africa, Swaziland, Tanzania, Thailand, Togo, Uganda, Zambia, and
Zimbabwe.
Population below poverty line
National estimates of the percentage of the population falling below
the poverty line are based on surveys of sub-groups, with the results
weighted by the number of people in each group. Definitions of poverty
vary considerably among nations. For example, rich nations generally
employ more generous standards of poverty than poor nations.
Population growth rate
The average annual percent change in the population, resulting from a
surplus (or deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or negative.
The growth rate is a factor in determining how great a burden would be
imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources
(e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as threatening by neighboring countries.
Ports and harbors
This entry lists the major ports and harbors selected on the basis of
overall importance to each country. This is determined by evaluating a
number of factors (e.g., dollar value of goods handled, gross tonnage,
facilities, military significance).
Public debt
This entry records the cumulative total of all government borrowings
less repayments that are denominated in a country''s home currency.
Public debt should not be confused with external debt, which reflects
the foreign currency liablities of both the private and public sector
and must be financed out of foreign exchange earnings.
Radio broadcast stations
This entry includes the total number of AM, FM, and shortwave broadcast
stations.
Railways
This entry states the total route length of the railway network and of
its component parts by gauge: broad, standard, narrow, and dual. Other
gauges are listed under note.
Reference maps
This section includes world and regional maps.
Refugees and internally displaced persons
This entry includes those persons residing in a country as refugees or
internally displaced persons (IDPs). The definition of a refugee
according to a United Nations Convention is "a person who is outside
his/her country of nationality or habitual residence; has a well-
founded fear of persecution because of his/her race, religion,
nationality, membership in a particular social group or political
opinion; and is unable or unwilling to avail himself/herself of the
protection of that country, or to return there, for fear of
persecution." The UN established the Office of the UN High Commissioner
for Refugees (UNHCR) in 1950 to handle refugee matters worldwide. The
UN Relief and Works Agency for Palestine Refugees in the Near East
(UNRWA) has a different, operational definition for a Palestinian
refugee: "a person whose normal place of residence was Palestine during
the period 1 June 1946 to 15 May 1948 and who lost both home and means
of livelihood as a result of the 1948 conflict." However, UNHCR also
assists some 400,000 Palestinian refugees not covered under the UNRWA
definition. The term "internally displaced person" is not specifically
covered in the UN Convention; it is used to describe people who have
fled their homes for reasons similar to refugees, but who remain within
their own national territory and are subject to the laws of that state.
The United Nations High Commissioner for Refugees (UNHCR) estimated
that in December 2003 there was a global population of 9.7 million
refugees and as many as 25 million IDPs.
Religions
This entry is an ordered listing of religions by adherents starting
with the largest group and sometimes includes the percent of total
population.
Reserves of foreign exchange and gold
This entry gives the dollar value for the stock of all financial assets
that are available to the central monetary authority for use in meeting
a country''s balance of payments needs as of the end-date of the period
specified. This category includes not only foreign currency and gold,
but also a country''s holdings of Special Drawing Rights in the
International Monetary Fund, and its reserve position in the Fund.
Sex ratio
This entry includes the number of males for each female in five age
groups - at birth, under 15 years, 15-64 years, 65 years and over, and
for the total population. Sex ratio at birth has recently emerged as an
indicator of certain kinds of sex discrimination in some countries. For
instance, high sex ratios at birth in some Asian countries are now
attributed to sex-selective abortion and infanticide due to a strong
preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually it could cause unrest among young adult
males who are unable to find partners.
Suffrage
This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
Telephone numbers
All telephone numbers in the Factbook consist of the country code in
brackets, the city or area code (where required) in parentheses, and
the local number. The one component that is not presented is the
international access code, which varies from country to country. For
example, an international direct dial telephone call placed from the US
to Madrid, Spain, would be as follows:
011 [34] (1) 577-xxxx, where
011 is the international access code for station-to-station calls;
01 is for calls other than station-to-station calls,
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another country
to the US would be as follows:
international access code + [1] (202) 939-xxxx, where
[1] is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system
This entry includes a brief general assessment of the system with
details on the domestic and international components. The following
terms and abbreviations are used throughout the entry:
Africa ONE - a fiber-optic submarine cable link encircling the
continent of Africa.
Arabsat - Arab Satellite Communications Organization (Riyadh,
Saudi Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
cellular telephone system - the telephones in this system are
radio transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station in
its area (cell), from which the telephone signal is fed to a telephone
exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with each
other.
coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a cylindrical
conducting shell; a large number of telephone channels can be made
available within the insulated space by the use of a large number of
carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network
or Autovon); basic general-purpose, switched voice network of the
Defense Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization
(Paris).
fiber-optic cable - a multichannel communications cable using a
thread of optical glass fibers as a transmission medium in which the
signal (voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised
by the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-
kHz range.
Inmarsat - International Maritime Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
landline - communication wire or cable of any sort that is
installed on poles or buried in the ground.
Marecs - Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in
the Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay, linking
Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially started in
Morocco in 1970 by the Arab Telecommunications Union (ATU) and was
known at that time as the Middle East Mediterranean Telecommunications
Network.
microwave radio relay - transmission of long distance telephone
calls and television programs by highly directional radio microwaves
that are received and sent on from one booster station to another on an
optical path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system
that was developed jointly by the national telecommunications
authorities of the Nordic countries (Denmark, Finland, Iceland, Norway,
and Sweden).
Orbita - a Russian television service; also the trade name of a
packet-switched digital telephone network.
radiotelephone communications - the two-way transmission and
reception of sounds by broadcast radio on authorized frequencies using
telephone handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
SAFE - South African Far East Cable
satellite communication system - a communication system consisting
of two or more earth stations and at least one satellite that provide
long distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
satellite earth station - a communications facility with a
microwave radio transmitting and receiving antenna and required
receiving and transmitting equipment for communicating with satellites.
satellite link - a radio connection between a satellite and an
earth station permitting communication between them, either one-way
(down link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super high frequency; any radio frequency in the 3,000- to
30,000-MHz range.
shortwave - radio frequencies (from 1.605 to 30 MHz) that fall
above the commercial broadcast band and are used for communication over
long distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
telefax - facsimile service between subscriber stations via the
public switched telephone network or the international Datel network.
telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
telex - a communication service involving teletypewriters
connected by wire through automatic exchanges.
tropospheric scatter - a form of microwave radio transmission in
which the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to
3,000-MHz range.
VHF - very high frequency; any radio frequency in the 30- to 300-
MHz range.
Telephones - main lines in use
This entry gives the total number of main telephone lines in use.
Telephones - mobile cellular
This entry gives the total number of mobile cellular telephones in use.
Television - broadcast stations
This entry gives the total number of separate broadcast stations plus
any repeater stations.
Terminology
Due to the highly structured nature of the Factbook database, some
collective generic terms have to be used. For example, the word Country
in the Country name entry refers to a wide variety of dependencies,
areas of special sovereignty, uninhabited islands, and other entities
in addition to the traditional countries or independent states.
Military is also used as an umbrella term for various civil defense,
security, and defense activities in many entries. The Independence
entry includes the usual colonial independence dates and former ruling
states as well as other significant nationhood dates such as the
traditional founding date or the date of unification, federation,
confederation, establishment, or state succession that are not strictly
independence dates. Dependent areas have the nature of their dependency
status noted in this same entry.
Terrain
This entry contains a brief description of the topography.
Total fertility rate
This entry gives a figure for the average number of children that would
be born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each
age. The total fertility rate is a more direct measure of the level of
fertility than the crude birth rate, since it refers to births per
woman. This indicator shows the potential for population growth in the
country. High rates will also place some limits on the labor force
participation rates for women. Large numbers of children born to women
indicate large family sizes that might limit the ability of the
families to feed and educate their children.
purchasing power parity - $231 million
(2000 est.)
3.03% (2004 est.)
4.9% (2000 est.)
purchasing power parity - $9,600 (2000 est.)
overseas territory of the UK
Virgin Islands
organized, unincorporated territory of the US with
policy relations between the Virgin Islands and the US under the
jurisdiction of the Office of Insular Affairs, US Department of the
Interior
Wake Island
unincorporated territory of the US; administered from
Washington, DC, by the Department of the Interior; activities on the
island are conducted by the US Army under a caretaker permit from
the US Air Force','acb321fba6b0cb4211747503cc6dfd444ed6ad4b94a8fd872a1a29ca44365878','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69506047553c9db6c606db37db43a44927c83123c79e4137319da8dd2c62d1de',2004,'AR','Argentina','people-and-society',223,'Religions:
nominally Roman Catholic 96%, Protestant 2%, other 2%
Languages:
Spanish (official), numerous indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.4%
male: 93.8%
female: 93.1% (2003 est.)
Government Venezuela
Country name:
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local long form: Republica Bolivariana de Venezuela
local short form: Venezuela
Government type:
federal republic
Capital:
Caracas
Administrative divisions:
23 states (estados, singular - estado), 1 federal district*
(distrito federal), and 1 federal dependency** (dependencia
federal); Amazonas, Anzoategui, Apure, Aragua, Barinas, Bolivar,
Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**, Distrito
Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva
Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas, Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Independence:
5 July 1811 (from Spain)
National holiday:
Independence Day, 5 July (1811)
Constitution:
30 December 1999
Legal system:
based on organic laws as of July 1999; open, adversarial court
system; has not accepted compulsory ICJ jurisdiction
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Hugo CHAVEZ Frias (since 3 February
1999); Vice President Jose Vicente RANGEL (since 28 April 2002);
note - the president is both the chief of state and head of
purchasing power parity - $435.5 billion (2003 est.)
1.02% (2004 est.)
8.7% (2003 est.)
purchasing power parity - $11,200 (2003 est.)
chief of mission: Ambassador Lino GUTIERREZ
embassy: Avenida Colombia 4300, C1425GMN Buenos Aires
mailing address: international mail: use street address; APO
address: Unit 4334, APO AA 34034
telephone: [54] (11) 5777-4533
FAX: [54] (11) 5777-4240','0da0c78f3758cca0504356c9fac1f2bd5e3e59506f8b30ba9eab6e7f4c22d2bb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f405fb03bcf745154dfe4afddebfa5afec7c6ba1918eb6aa13b5d9f1af72d64',2004,'AF','Afghanistan','people-and-society',225,'purchasing power parity - $20 billion (2003 est.)
4.92%
note: this rate does not take into consideration the recent war and
its continuing impact (2004 est.)
29% (2003 est.)
note: this high growth rate reflects the extremely low levels of
activity between 1999 and 2002, as well as the end of a four-year
drought and the impact of donor assistance
purchasing power parity - $700 (2003 est.)
chief of mission: Ambassador Zalmay KHALILZAD
embassy: The Great Masood Road, Kabul
mailing address: 6180 Kabul Place, Dulles, VA 20189-6180
telephone: [00] (2) 230-0436
FAX: [0093] (2) 230-1364
Akrotiri
none (overseas territory of the UK)','11434fe2c7c392bc6a817ad5e5cb34254b6dc7f725b716e29134244865b5cf80','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4780c7a5a65b08a4c6b57fbfaccad2ea56f0aa517dbbbdcbd4f4c5245e4cf0bc',2004,'AL','Albania','people-and-society',226,'purchasing power parity - $16.13 billion (2003 est.)
0.51% (2004 est.)
7% (2003 est.)
purchasing power parity - $4,500 (2003 est.)
chief of mission: Ambassador Marcie B. RIES
embassy: Rruga Elbasanit, Labinoti #103, Tirana
mailing address: U. S. Department of State, 9510 Tirana Place,
Dulles, VA 20189-9510
telephone: [355] (4) 247285
FAX: [355] (4) 374957 and [355] (4) 232222','87204d1cd2ba4915aa2ae7ad61d496db653924e1c8b2297100e6e955666e5a5e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eed3cc91ad40159218a18b2fe473281607f504ccf34232e66075b79acdc5d868',2004,'DZ','Algeria','people-and-society',227,'purchasing power parity - $196 billion (2003 est.)
1.28% (2004 est.)
7.4% (2003 est.)
purchasing power parity - $6,000 (2003 est.)
chief of mission: Ambassador Richard W. ERDMAN
embassy: 4 Chemin Cheikh Bachir El-Ibrahimi, Algiers
mailing address: B. P. 408, Alger-Gare, 16030 Algiers
telephone: [213] (21) 691-425/255/186
FAX: [213] (21) 69-39-79','fdf278a64430a36187f73e70b78936a0e45c3d53448064f9ca995d5d29cbd70a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3648d4356c3c4066e5ac2fddef3156d07aed8d4505d8eda908ce9aad49214409',2004,'AS','American Samoa','people-and-society',228,'purchasing power parity - $500 million (2000 est.)
0.04% (2004 est.)
NA
purchasing power parity - $8,000 (2000 est.)
unincorporated and unorganized territory of the US;
administered by the Office of Insular Affairs, US Department of the
Interior
none (territory of the US)','14f73b87628b592463d0218951b107c0bcbd3d1c21c28a7982336890fd79cadd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c581fc56c19755a985a35ca0c240510281b9cd29d0ccc0ec028e848d7eb7f489',2004,'AD','Andorra','people-and-society',229,'purchasing power parity - $1.3 billion (2000 est.)
1% (2004 est.)
3.8% (2000 est.)
purchasing power parity - $19,000 (2000 est.)
the US does not have an embassy in Andorra; the US
Ambassador to Spain is accredited to Andorra; US interests in
Andorra are represented by the Consulate General''s office in
Barcelona (Spain); mailing address: Paseo Reina Elisenda, 23, 08034
Barcelona, Spain; telephone: [34] (93) 280-2227; FAX: [34] (93)
280-6175','95c059cc1d6cc2e70ce2d4257be89914f0027475ff926989917e548513524930','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc149c68f948aeff7a76c1e3ad9e4483614b66b49967f19eff0f653cfd038801',2004,'AO','Angola','people-and-society',230,'purchasing power parity - $20.42 billion (2003 est.)
1.93% (2004 est.)
1.5% (2003 est.)
purchasing power parity - $1,900 (2003 est.)
chief of mission: Ambassador Christopher William DELL
embassy: number 32 Rua Houari Boumedienne (in the Miramar area of
Luanda), Luanda
mailing address: international mail: Caixa Postal 6468, Luanda;
pouch: American Embassy Luanda, Department of State, Washington, DC
20521-2550
telephone: [244] (2) 445-481, 447-028, 446-224
FAX: [244] (2) 446-924','180cca5c352495d438532a7f7626d12b96a06e84bb72b37da32fae1fb9547e55','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b7a844b713caeb5642f15826da1258cb9daf85ac02299e806efda128d6bb563',2004,'AI','Anguilla','people-and-society',231,'purchasing power parity - $104 million (2001 est.)
1.98% (2004 est.)
2.8% (2001 est.)
purchasing power parity - $8,600 (2001 est.)
overseas territory of the UK
none (overseas territory of the UK)','e0d2660c9d5ee8ec97b9d136c1345f24f3230c597814243c59b58f3e40b52aa0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cef1641a47fe808d931bd0452d4fcfcd770a0076ebf1250abbaaed20a1c2cf2a',2004,'AG','Antigua and Barbuda','people-and-society',232,'purchasing power parity - $750 million (2002
est.)
0.6% (2004 est.)
3% (2002 est.)
purchasing power parity - $11,000 (2002 est.)
the US does not have an embassy in Antigua and
Barbuda (embassy closed 30 June 1994); the US Ambassador to
Barbados, Ambassador Mary E. KRAMER, is accredited to Antigua and
Barbuda','3256d134ce8b5e17b40944cf11b862e4e53bf4eebb2bc108d60c65f341643d22','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7ca2a86626543de130e017f062a815f7f6adb6ab2352113b5d2ce0788b7bafe',2004,'AM','Armenia','people-and-society',233,'purchasing power parity - $11.79 billion (2003 est.)
-0.32% (2004 est.)
9.9% (2003 est.)
purchasing power parity - $3,500 (2003 est.)
chief of mission: Ambassador John M. EVANS
embassy: 18 Baghramyan Ave., Yerevan 375019
mailing address: American Embassy Yerevan, Department of State, 7020
Yerevan Place, Washington, DC 20521-7020
telephone: [374](1) 521-611, 520-791, 542-117, 542-132, 524-661,
527-001, 524-840
FAX: [374](1) 520-800','e511917fed3df6ef832ce126974ded26d3e5921254d011421e2ac30f7bbe3d39','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a743dde8b617ac4945943b73a4622d1bdaf1284c33781105d59b4414964c7a66',2004,'AW','Aruba','people-and-society',234,'purchasing power parity - $1.94 billion (2002 est.)
0.51% (2004 est.)
-1.5% (2002 est.)
purchasing power parity - $28,000 (2002 est.)
part of the Kingdom of the Netherlands; full autonomy in
internal affairs obtained in 1986 upon separation from the
Netherlands Antilles; Dutch Government responsible for defense and
foreign affairs
Ashmore and Cartier Islands
territory of Australia; administered by
the Australian Department of Transport and Regional Services
Baker Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Bassas da India
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
the US does not have an embassy in Aruba; the Consul General
to Netherlands Antilles, Robert E. SORENSON, is accredited to Aruba
Ashmore and Cartier Islands
none (territory of Australia)','320a3866a3100d04aff578f56a471a8ed7a6258bc06c414f69164be35a13a027','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdc2d96d111912419a0e6b845b8277fe9e3859b696e64950a82ce4807facd59b',2004,'AU','Australia','people-and-society',235,'purchasing power parity - $571.4 billion (2003 est.)
0.9% (2004 est.)
3% (2003 est.)
purchasing power parity - $29,000 (2003 est.)
chief of mission: Ambassador J. Thomas SCHIEFFER
embassy: Moonah Place, Yarralumla, Canberra, Australian Capital
Territory 2600
mailing address: APO AP 96549
telephone: [61] (02) 6214-5600
FAX: [61] (02) 6214-5970
consulate(s) general: Melbourne, Perth, Sydney','1c9ae3bbe3bf4d1ccc59496600ba92bd41b2b1bfd4062334892dba3c9dda3d20','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e79f664bba5599bc8c20ea48d726d0202e6c6b61186d8f3ade1be7ec8812aa35',2004,'AT','Austria','people-and-society',236,'purchasing power parity - $245.3 billion (2003 est.)
0.14% (2004 est.)
0.7% (2003 est.)
purchasing power parity - $30,000 (2003 est.)
chief of mission: Ambassador William Lee LYONS BROWN, Jr.
embassy: Boltzmanngasse 16, A-1090, Vienna
mailing address: use embassy street address
telephone: [43] (1) 31339-0, 31375, 31335
FAX: [43] (1) 3100682','be4c6f6241d6eac156c182e78315a9306312f9e55eb219bce22a9394f60dc516','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1211fbd83cc6590ccd77e13844170b1d55842f7364c5da7fe2e1521f9788a04f',2004,'AZ','Azerbaijan','people-and-society',237,'purchasing power parity - $26.65 billion (2003 est.)
Bahamas, The
purchasing power parity - $5.049 billion (2003 est.)
0.52% (2004 est.)
Bahamas, The
0.72% (2004 est.)
11.2% (2003 est.)
Bahamas, The
0% (2003 est.)
purchasing power parity - $3,400 (2003 est.)
Bahamas, The
purchasing power parity - $16,700 (2003 est.)
chief of mission: Ambassador Reno L. HARNISH III
embassy: 83 Azadlyg Prospecti, Baku AZ1007
mailing address: American Embassy Baku, Department of State, 7050
Baku Place, Washington, DC 20521-7050
telephone: [9] (9412) 98-03-35, 36, 37
FAX: [9] (9412) 656-671
Bahamas, The
chief of mission: Ambassador John D. ROOD
embassy: 42 Queen Street, Nassau
mailing address: local or express mail address: P. O. Box N-8197,
Nassau; Department of State, 3370 Nassau Place, Washington, DC
20521-3370
telephone: [1] (242) 322-1181, 328-2206 (after hours)
FAX: [1] (242) 356-0222','e88843e89da327f61287b6821cfcae3927d1f4a92ce253eb5bddf111a6834925','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('223f90646acf76c3c8e7cb8dc94ca900a0a39b37e8e001b278359324704011ef',2004,'BH','Bahrain','people-and-society',238,'purchasing power parity - $11.29 billion (2003 est.)
1.56% (2004 est.)
4.9% (2003 est.)
purchasing power parity - $16,900 (2003 est.)
chief of mission: Ambassador William T. MONROE
embassy: Building #979, Road 3119 (next to Al-Ahli Sports Club),
Block 331, Zinj District, Manama
mailing address: American Embassy Manama, PSC 451, FPO AE
09834-5100; international mail: American Embassy, Box 26431, Manama
telephone: [973] 1724-2700
FAX: [973] 1725-6242 (consular)','92d86f5d4e3dd242fc83a4ad269d6b784e196e0db1f9cb926e3e251a28089f6b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71260239b149fa0313cb87189acbd051f667c7fdb485401e73e2c39586ae46f4',2004,'BD','Bangladesh','people-and-society',239,'purchasing power parity - $258.8 billion (2003 est.)
2.08% (2004 est.)
5.3% (2003 est.)
purchasing power parity - $1,900 (2003 est.)
chief of mission: Ambassador Harry K. THOMAS, Jr.
embassy: Madani Avenue, Baridhara, Dhaka 1212
mailing address: G. P. O. Box 323, Dhaka 1000
telephone: [880] (2) 885-5500
FAX: [880] (2) 882-3744','f69d704b5624f95ece008c67401eabb0143fa6d4c424d1974d091d4fccf5db36','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cc4d8d9f00ad83769f7a0d753e4015a0cff2bb72e57bde310f895b672de895c',2004,'BB','Barbados','people-and-society',240,'purchasing power parity - $4.355 billion (2003 est.)
0.36% (2004 est.)
2.2% (2003 est.)
purchasing power parity - $15,700 (2003 est.)
chief of mission: Ambassador Mary E. KRAMER
embassy: Canadian Imperial Bank of Commerce Building, Broad Street,
Bridgetown; (courier) ALICO Building-Cheapside, Bridgetown
mailing address: P. O. Box 302, Bridgetown; CMR 1014, APO AA 34055
telephone: [1] (246) 436-4950
FAX: [1] (246) 429-5246, 429-3379','cf15d42e01b80df308aa8cb7f1db24bdb8cd3c7eb2a2246ae242d1f4cee126ac','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af2db30d9a57b6816012e1c429bbb43d33ff734c7cbd817e57341270c8060982',2004,'BY','Belarus','people-and-society',241,'purchasing power parity - $62.56 billion (2003 est.)
-0.11% (2004 est.)
6.8% (2003 est.)
purchasing power parity - $6,100 (2003 est.)
chief of mission: Ambassador George A. KROL
embassy: 46 Starovilenskaya St., Minsk 220002
mailing address: PSC 78, Box B Minsk, APO 09723
telephone: [375] (17) 210-12-83, 217-7347, 217-7348
FAX: [375] (17) 234-7853','4f4b0983d60aab065627e5d21c02ca22f16d09b55f12c78e5bfed7cd7c3c682b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('317da8a303c8c1f8e0de6fdd5525c56c3cd47aa467c5d46ea60004fedaa36322',2004,'BE','Belgium','people-and-society',242,'purchasing power parity - $299.1 billion (2003 est.)
0.16% (2004 est.)
1.1% (2003 est.)
purchasing power parity - $29,100 (2003 est.)
chief of mission: Ambassador Tom C. KOROLOGOS
embassy: Regentlaan 27 Boulevard du Regent, B-1000 Brussels
mailing address: PSC 82, Box 002, APO AE 09710
telephone: [32] (2) 508-2111
FAX: [32] (2) 511-2725','7712dab5e8818c3c2b333fe599dea70dc32ecc68648545f4d2c5171925245438','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e21818fcd9bb686d45cc7aef56c70d258ade59a7f8de35712c020edd0141eb8',2004,'BZ','Belize','people-and-society',243,'purchasing power parity - $1.28 billion (2002 est.)
2.39% (2004 est.)
3.7% (2002 est.)
purchasing power parity - $4,900 (2002 est.)
chief of mission: Ambassador Russell F. FREEMAN
embassy: 29 Gabourel Lane, Belize City
mailing address: P. O. Box 286, Belize City
telephone: [501] 227-7161 through 7163
FAX: [501] 2-30802','9c3cb2acfe89f598b5bde63b2c13f21bbb7f2da98cf89b2f28f5af48c9360d75','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0af7c88d643e3637d748f48e13902754e3e50440b68291ca8ecdcf3cf9d9da28',2004,'BJ','Benin','people-and-society',244,'purchasing power parity - $7.742 billion (2003 est.)
2.89% (2004 est.)
5.5% (2003 est.)
purchasing power parity - $1,100 (2003 est.)
chief of mission: Ambassador Wayne NEILL
embassy: Rue Caporal Bernard Anani, Cotonou
mailing address: 01 B. P. 2012, Cotonou
telephone: [229] 30-06-50
FAX: [229] 30-06-70','4385021a4e751023e2a4fceb33c6c042e3fbd4c25b680c180edeab657d5b1eaf','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504af4e2419c4e6b8f424ca6335c8af21a8987288e2eb0fc5756cc6d1e228b45',2004,'BM','Bermuda','people-and-society',245,'purchasing power parity - $2.33 billion (2003 est.)
0.68% (2004 est.)
2% (2003 est.)
purchasing power parity - $36,000 (2003 est.)
overseas territory of the UK
chief of mission: Deputy Chief of Mission Antoinette BOECKER
consulate(s) general: Crown Hill, 16 Middle Road, Devonshire DVO3
mailing address: P. O. Box HM325, Hamilton HMBX; American Consulate
General Hamilton, Department of State, 5300 Hamilton Place,
Washington, DC 20520-5300
telephone: [1] (441) 295-1342
FAX: [1] (441) 295-1592, [1] (441) 296-9233','eb4b777afc406718bcdb7810dc783d0530374631ec12e22da386b1e69bb28a68','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cca1c203440be5af8f0dcd7340ff99246f57e8a5e702a5a27ded5db41c5eeac8',2004,'BT','Bhutan','people-and-society',246,'purchasing power parity - $2.7 billion (2002 est.)
Bolivia
purchasing power parity - $21.01 billion (2003 est.)
2.12% (2004 est.)
Bolivia
1.56% (2004 est.)
7.7% (2002 est.)
Bolivia
2.5% (2003 est.)
purchasing power parity - $1,300 (2002 est.)
Bolivia
purchasing power parity - $2,400 (2003 est.)
the US and Bhutan have no formal diplomatic relations,
although informal contact is maintained between the Bhutanese and US
Embassy in New Delhi (India)
Bolivia
chief of mission: Ambassador David N. GREENLEE
embassy: Avenida Arce 2780, San Jorge, La Paz
mailing address: P. O. Box 425, La Paz; APO AA 34032
telephone: [591] (2) 2430120, 2430251
FAX: [591] (2) 2433900','0a3b1b8437722845cad25d310b0c8c154c8d364094c84ed97405366b761af55f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51dca321bc8798c93084cde94530aa321fe1284504766f9e7a1c49487dd80ea5',2004,'BA','Bosnia and Herzegovina','people-and-society',247,'purchasing power parity - $24.31 billion
(2003 est.)
0.45% (2004 est.)
3.5% (2003 est.)
purchasing power parity - $6,100 (2003 est.)
chief of mission: Ambassador Douglas L.
McELHANEY
embassy: Alipasina 43, 71000 Sarajevo
mailing address: use street address
telephone: [387] (33) 445-700
FAX: [387] (33) 659-722
branch office(s): Banja Luka, Mostar','042aad3ade7e8c87c93b6338d2c9d45f34d17284f5cc9d077da0fd7346c1f9fa','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c0015a10277cdbe098bf3db13a5a7b01dc10f392ef1d83e6336e146439df3e1',2004,'BW','Botswana','people-and-society',248,'purchasing power parity - $14.2 billion (2003 est.)
-0.89% (2004 est.)
7.2% (2003 est.)
purchasing power parity - $9,000 (2003 est.)
chief of mission: Ambassador Joseph HUGGINS
embassy: address NA, Gaborone
mailing address: Embassy Enclave, P. O. Box 90, Gaborone
telephone: [267] 353982
FAX: [267] 312782','f153ddaa534e6e6aea6654916f32db492e2ad90cb807a11097070c2d8092d279','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9498c85693ceb0fe3dc2ade7554b931e6d1ab46b4d8529597c8cb15a0ac93230',2004,'BR','Brazil','people-and-society',249,'purchasing power parity - $1.375 trillion (2003 est.)
British Virgin Islands
purchasing power parity - $320 million (2002
est.)
Brunei
purchasing power parity - $6.5 billion (2002 est.)
1.11% (2004 est.)
British Virgin Islands
2.06% (2004 est.)
Brunei
1.95% (2004 est.)
-0.2% (2003 est.)
British Virgin Islands
1% (2002 est.)
Brunei
3% (2002 est.)
purchasing power parity - $7,600 (2003 est.)
British Virgin Islands
purchasing power parity - $16,000 (2002 est.)
Brunei
purchasing power parity - $18,600 (2002 est.)
chief of mission: Ambassador John DANILOVICH
embassy: Avenida das Nacoes, Quadra 801, Lote 3, Distrito Federal
Cep 70403-900, Brasilia
mailing address: Unit 3500, APO AA 34030
telephone: [55] (61) 312-7000
FAX: [55] (61) 225-9136
consulate(s) general: Rio de Janeiro, Sao Paulo
consulate(s): Recife','298d5db676d330f7a7dff932996662d87c068bc7b69b60c1a8071d63cf1dd9be','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77a0b6e1677c6a246c7ba616600914cc19d88da7a60ba1a355b923d202af0f4d',2004,'BG','Bulgaria','people-and-society',250,'purchasing power parity - $57.13 billion (2003 est.)
-0.92% (2004 est.)
4.3% (2003 est.)
purchasing power parity - $7,600 (2003 est.)
chief of mission: Ambassador James William PARDEW
embassy: 16 Kozyak Street, Sofia 1407
mailing address: American Embassy Sofia, Department of State, 5740
Sofia Place, Washington, DC 20521-5740
telephone: [359] (2) 937-5100
FAX: [359] (2) 937-5230','e892e7ed240ab454ca487fda924811c63dd22e6cd5bbe4b85ac73ead0c5734af','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d8d5a82d91a1839f139dd90f1cf8933043776152f19518b73124d4a7dcacf24',2004,'BF','Burkina Faso','people-and-society',251,'purchasing power parity - $14.55 billion (2003 est.)
Burma
purchasing power parity - $74.53 billion (2003 est.)
2.57% (2004 est.)
Burma
0.47% (2004 est.)
5.2% (2003 est.)
Burma
-0.5% (2003 est.)
purchasing power parity - $1,100 (2003 est.)
Burma
purchasing power parity - $1,800 (2003 est.)
chief of mission: Ambassador Anthony HOLMES
embassy: 602 Avenue Raoul Follereau, Koulouba, Secteur 4
mailing address: 01 B. P. 35, Ouagadougou 01; pouch mail - U. S.
Department of State, 2440 Ouagadougou Place, Washington, DC
20521-2440
telephone: [226] 306723
FAX: [226] 303890
Burma
chief of mission: Charge d''Affaires Carmen M. MARTINEZ
embassy: 581 Merchant Street, Rangoon (GPO 521)
mailing address: Box B, APO AP 96546
telephone: [95] (1) 379 880, 379 881
FAX: [95] (1) 256 018','b3b13961185318de27a1515f9c6e26fb6b495bb39e9c2fb9704351f8a2d0d1b3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ae65d009d8bdb38a39035093b590fbb4744d071c4b1787b2a1f2bdebeca8320',2004,'BI','Burundi','people-and-society',252,'purchasing power parity - $3.78 billion (2003 est.)
2.2% (2004 est.)
-1.3% (2003 est.)
purchasing power parity - $600 (2003 est.)
chief of mission: Ambassador James Howard YELLIN
embassy: Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone: [257] 223454
FAX: [257] 222926','919926f15ce6fa64c891a8eeb90c12cad2ff50ec0a938deb2ee8f35961d25cf6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f56ff5e1d2c4dad11753dcd637a16b3d5644bbcfe577b49a4765f29c39d0941',2004,'KH','Cambodia','people-and-society',253,'purchasing power parity - $25.02 billion (2003 est.)
1.8% (2004 est.)
5% (2003 est.)
purchasing power parity - $1,900 (2003 est.)
chief of mission: Ambassador Charles Aaron RAY
embassy: 27 EO Street 240, Phnom Penh
mailing address: Box P, APO AP 96546
telephone: [855] (23) 216-436/438
FAX: [855] (23) 216-437/811','9dfd0b4a14e05e81b96b12965252bce2d142770fa805e11b101c50028f2ed3e0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9810b35d55ca962fe90c4d090ef19d6e64a0934a0cb2db24ef2179158e33598',2004,'CM','Cameroon','people-and-society',254,'purchasing power parity - $27.75 billion (2003 est.)
1.97% (2004 est.)
4.2% (2003 est.)
purchasing power parity - $1,800 (2003 est.)
chief of mission: Ambassador George McDade STAPLES
embassy: Rue Nachtigal, Yaounde
mailing address: P. O. Box 817, Yaounde; pouch: American Embassy,
Department of State, Washington, DC 20521-2520
telephone: [237] 223-05-12, 222-25-89, 222-17-94, 223-40-14
FAX: [237] 223-07-53
branch office(s): Douala','ea706f87288788897d3e8bc718fdf6df37bf70a1ed77cde7706f94a55b80d82e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb5a58e9e4d16ef3969065ccb098775884c0ce7cab04f367c49df7c4cf4187d2',2004,'CA','Canada','people-and-society',255,'purchasing power parity - $958.7 billion (2003 est.)
Cape Verde
purchasing power parity - $600 million (2002 est.)
0.92% (2004 est.)
Cape Verde
0.73% (2004 est.)
1.7% (2003 est.)
Cape Verde
4% (2002 est.)
purchasing power parity - $29,800 (2003 est.)
Cape Verde
purchasing power parity - $1,400 (2002 est.)
chief of mission: Ambassador Paul CELLUCCI
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburgh, NY 13669-0430
telephone: [1] (613) 238-5335, 4470
FAX: [1] (613) 688-3082
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
Vancouver, Winnipeg
Cape Verde
chief of mission: Ambassador Donald C. JOHNSON
embassy: Rua Abilio m. Macedo 81, Praia
mailing address: C. P. 201, Praia
telephone: [238] 61 56 16, 61 56 17
FAX: [238] 61 13 55','8f0b3ac3aac5e76710cdb3682d2fd88b53116ad737d198b811dbd92f460918e4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2677bb1c5d78073ca08bf6a0009abe97565bce22f6b77cde7e79592bda68c181',2004,'KY','Cayman Islands','people-and-society',256,'purchasing power parity - $1.27 billion (2002 est.)
2.71% (2004 est.)
1.7% (2002 est.)
purchasing power parity - $35,000 (2002 est.)
overseas territory of the UK
none (overseas territory of the UK)','c29adca17c318579d6a0b77529a686052439591a38d8ae4ff93004a36d2b53a9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b7b7d1c3e3dce876a359fd21715c78590be6645bcba036c8419f31219e6e537',2004,'CF','Central African Republic','people-and-society',257,'purchasing power parity - $4.183 billion
(2003 est.)
1.56% (2004 est.)
-7% (2003 est.)
purchasing power parity - $1,100 (2003 est.)
chief of mission: Ambassador (vacant)
embassy: Avenue David Dacko, Bangui
mailing address: B. P. 924, Bangui
telephone: [236] 61 02 00
FAX: [236] 61 44 94
note: The embassy is currently operating with a minimal staff','b8a084c6f78fca3bda24a18ad6220d9d6ffb7762aec4bdb08a1cae6a69897c3b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f878aadf3cc77452ca53cf7449f07909207f8a5efff3ee7a20cabe9194f651bd',2004,'TD','Chad','people-and-society',258,'purchasing power parity - $10.67 billion (2003 est.)
3% (2004 est.)
15% (2003 est.)
purchasing power parity - $1,200 (2003 est.)
chief of mission: Ambassador Christopher E. GOLDTHWAIT
embassy: Avenue Felix Eboue, N''Djamena
mailing address: B. P. 413, N''Djamena
telephone: [235] (51) 70-09
FAX: [235] (51) 56-54','f89348acaa574710e8621df7657a2e494728b09f6c4bd3a89c69805f3f4871ca','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('217bfbe88e21c1f8cf717c6de7bc0f2a07ede985714ebdd749b13c9fcd48fec8',2004,'CL','Chile','people-and-society',259,'purchasing power parity - $154.7 billion (2003 est.)
1.01% (2004 est.)
3.3% (2003 est.)
purchasing power parity - $9,900 (2003 est.)
chief of mission: Ambassador Craig A. KELLY
embassy: Avenida Andres Bello 2800, Las Condes, Santiago
mailing address: APO AA 34033
telephone: [56] (2) 232-2600
FAX: [56] (2) 330-3710','bf003f2d559d04d341ca03b243dc82a25a72df4cd4731813c90166518a626024','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2cb9ddda39928e31fc1222e4cc0b2dcb73623d6fbb862c68e9b1110332447a',2004,'CN','China','people-and-society',260,'purchasing power parity - $6.449 trillion (2003 est.)
0.57% (2004 est.)
9.1% (official data) (2003 est.)
purchasing power parity - $5,000 (2003 est.)
chief of mission: Ambassador Clark T. RANDT, Jr.
embassy: Xiu Shui Bei Jie 3, 100600 Beijing
mailing address: PSC 461, Box 50, FPO AP 96521-0002
telephone: [86] (10) 6532-3831
FAX: [86] (10) 6532-6929
consulate(s) general: Chengdu, Guangzhou, Hong Kong, Shanghai,
Shenyang','629a49eeabc7d6e03e4b557f75784f35b421f9d4d6ae3c1204880d259f48679e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73a98febd22f81bf1bac803885b6b2607eba7d2d15bd151a5a0a6978e4193906',2004,'CX','Christmas Island','people-and-society',261,'purchasing power parity - NA
-9% (2004 est.)
NA
purchasing power parity - NA
territory of Australia; administered by the
Australian Department of Transport and Regional Services
Clipperton Island
possession of France; administered by France from
French Polynesia by a high commissioner of the Republic
none (territory of Australia)','5a54ede5e9b3e9aa8eac17ffbc12a1bb33b6e0ef46de7deb4eeb680d4bef22a5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88e7a06c80b0f675b9a7bbc578abadf9a191191eaf06ed9eb6de0f2a77e285aa',2004,'CC','Cocos (Keeling) Islands','people-and-society',262,'purchasing power parity - NA
0.002% (2004 est.)
NA
purchasing power parity - NA
territory of Australia; administered from
Canberra by the Australian Department of Transport and Regional
Services
none (territory of Australia)','27a2a615917c924e17710db584d804f1f835a12c91dd83d7e40c69afa09a8e49','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3c9da218400af394766cb937446689e7ee2fb218cd20b759fc74683af585feb',2004,'CO','Colombia','people-and-society',263,'purchasing power parity - $263.2 billion (2003 est.)
1.53% (2004 est.)
3.7% (2003 est.)
purchasing power parity - $6,300 (2003 est.)
chief of mission: Ambassador William B. WOOD
embassy: Calle 22D-BIS, numbers 47-51, Apartado Aereo 3831
mailing address: Carrera 45 #22D-45, Bogota, D.C., APO AA 34038
telephone: [57] (1) 315-0811
FAX: [57] (1) 315-2197','925c9a9b966b22bd7dffee7b24ba39cc03a588a289d4bdeb9474d1982c70a4ab','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9a18af4d842a91fc2bb6aa115e730e559f758281b95ac5c890d93cf0dec83d',2004,'KM','Comoros','people-and-society',264,'purchasing power parity - $441 million (2002 est.)
Congo, Democratic Republic of the
purchasing power parity - $40.05
billion (2003 est.)
Congo, Republic of the
purchasing power parity - $2.148 billion
(2003 est.)
2.94% (2004 est.)
Congo, Democratic Republic of the
2.99% (2004 est.)
Congo, Republic of the
1.42% (2004 est.)
2% (2002 est.)
Congo, Democratic Republic of the
6.5% (2003 est.)
Congo, Republic of the
1.3% (2003 est.)
purchasing power parity - $700 (2002 est.)
Congo, Democratic Republic of the
purchasing power parity - $700
(2003 est.)
Congo, Republic of the
purchasing power parity - $700 (2003 est.)
the US does not have an embassy in Comoros; the ambassador
to Mauritius is accredited to Comoros
Congo, Democratic Republic of the
chief of mission: Ambassador
Aubrey HOOKS
embassy: 310 Avenue des Aviateurs, Kinshasa
mailing address: Unit 31550, APO AE 09828
telephone: [243] (88) 43608
FAX: [243] (88) 43467
Congo, Republic of the
chief of mission: Ambassador Robin R. SANDERS
embassy: NA
mailing address: NA
telephone: [243] (88) 43608
note: the embassy is temporarily collocated with the US Embassy in
the Democratic Republic of the Congo (US Embassy Kinshasa, 310
Avenue des Aviateurs, Kinshasa)','a3ce2f57bd5024cf2fb1b35143c087ec02c4299039278e6f25b70114c12e2235','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44cb9354c763fba7111e2afe17b31f1305bb9d101d666ecdebdd0e87da7a3204',2004,'CK','Cook Islands','people-and-society',265,'purchasing power parity - $105 million (2001 est.)
NA (2004 est.)
7.1% (2001 est.)
purchasing power parity - $5,000 (2001 est.)
self-governing in free association with New Zealand;
Cook Islands is fully responsible for internal affairs; New Zealand
retains responsibility for external affairs and defense, in
consultation with the Cook Islands
Coral Sea Islands
territory of Australia; administered from Canberra
by the Department of the Environment, Sport, and Territories
Dhekelia
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus
Europa Island
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
Falkland Islands (Islas Malvinas)
overseas territory of the UK; also
claimed by Argentina
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)','2b43c723507e8766077072868456fd456ab6934d6fa1a6365030b982c4d13ad7','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f33e21088731121420b8476744439b7c31fb7ec90f23016f2c36a3600e83a1e8',2004,'CR','Costa Rica','people-and-society',266,'purchasing power parity - $35.34 billion (2003 est.)
Cote d''Ivoire
purchasing power parity - $24.51 billion (2003 est.)
1.52% (2004 est.)
Cote d''Ivoire
2.11% (2004 est.)
5.6% (2003 est.)
Cote d''Ivoire
-1.9% (2003 est.)
purchasing power parity - $9,100 (2003 est.)
Cote d''Ivoire
purchasing power parity - $1,400 (2003 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Douglas M. BARNES
embassy: Calle 120 Avenida O, Pavas, San Jose
mailing address: APO AA 34020
telephone: [506] 220-3939
FAX: [506] 519-2305
Cote d''Ivoire
chief of mission: Ambassador Arlene RENDER
embassy: 5 Rue Jesse Owens, Abidjan
mailing address: B. P. 1712, Abidjan 01
telephone: [225] 20 21 09 79
FAX: [225] 20 22 32 59','d366609196ba69f8d3684bdcdefe0b3fb0fdcddb28527c121105e0bdedf8d899','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f413cdeb5354dcef2f8006d31abb566dd90ee9cba72e9c2297c964d33ae47c14',2004,'HR','Croatia','people-and-society',267,'purchasing power parity - $47.05 billion (2003 est.)
-0.02% (2004 est.)
4.3% (2003 est.)
purchasing power parity - $10,600 (2003 est.)
chief of mission: Ambassador Ralph FRANK
embassy: 2 Thomas Jefferson, 10010 Zagreb
mailing address: use street address
telephone: [385] (1) 661-2200
FAX: [385] (1) 661-2373','b62694a66be2445074e7eebc063c6dfc23f4c27e0d8611014abb625b43eee7d3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a882dca8f8a1defbfbbc2d2d0995a7c20468ea60d2b9915e4b653bff6ffdd5d',2004,'CU','Cuba','people-and-society',268,'purchasing power parity - $32.13 billion (2003 est.)
0.34% (2004 est.)
2.6% (2003 est.)
purchasing power parity - $2,900 (2003 est.)
none; note - the US has an Interests Section in the Swiss
Embassy, headed by Principal Officer James C. CASON; address: USINT,
Swiss Embassy, Calzada between L and M Streets, Vedado, Havana;
telephone: [53] (7) 833-3551 through 3559 (operator assistance
required); FAX: [53] (7) 833-3700; protecting power in Cuba is','2cdc63d464e2c632124ef4827a8d52ca7da8473b04af2057ee3280f7d8016b33','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16aa38e6b228f8cf65afa3fcbd038212abde52d773be4501112a6761900a46eb',2004,'CY','Cyprus','people-and-society',269,'Republic of Cyprus: purchasing power parity - $14.82 billion
(2003 est.); north Cyprus: purchasing power parity - $1.217 billion
(2003 est.)
Czech Republic
purchasing power parity - $161.1 billion (2003 est.)
0.55% (2004 est.)
Czech Republic
-0.05% (2004 est.)
Republic of Cyprus: 1.9% (2003 est.); north Cyprus: 2.6%
(2003 est.)
Czech Republic
2.9% (2003 est.)
Republic of Cyprus: purchasing power parity - $19,200 (2003
est.); north Cyprus: purchasing power parity - $5,600 (2003 est.)
Czech Republic
purchasing power parity - $15,700 (2003 est.)
chief of mission: Ambassador Michael KLOSSON
embassy: corner of Metochiou and Ploutarchou Streets, Engomi, 2407
Nicosia
mailing address: P. O. Box 24536, 1385 Nikosia
telephone: [357] (22) 393939
FAX: [357] (22) 780944
Czech Republic
chief of mission: Ambassador William J. CABANISS
embassy: Trziste 15, 11801 Prague 1
mailing address: use embassy street address
telephone: [420] (2) 5753-0663
FAX: [420] (2) 5753-0583','68324e5e6617aa931444cf774d43b92446e179843d8e9206e86795ee78fad826','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ac2a3249276c95a100d4f7eaf26f03ba5e799ba625a8f5f4a22042b10cbedfc',2004,'DK','Denmark','people-and-society',270,'purchasing power parity - $167.2 billion (2003 est.)
0.35% (2004 est.)
0% (2003 est.)
purchasing power parity - $31,100 (2003 est.)
chief of mission: Ambassador Stuart A. BERNSTEIN; note -
will leave 15 January 2005
embassy: Dag Hammarskjolds Alle 24, 2100 Copenhagen
mailing address: PSC 73, APO AE 09716
telephone: [45] 35 55 31 44
FAX: [45] 35 43 02 23
Dhekelia
none (overseas territory of the UK)','e6bb5daab8f55c1ddc70cf1735e0982b0d1d2a3f381ef35b45cc41d69964af99','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb329c068458f32e35b89dfa2124f986c69286cd641ea63a7e6d9ba2c00768bc',2004,'DJ','Djibouti','people-and-society',271,'purchasing power parity - $619 million (2002 est.)
2.1% (2004 est.)
3.5% (2002 est.)
purchasing power parity - $1,300 (2002 est.)
chief of mission: Ambassador Marguerita RAGSDALE
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40','f9c60916ec209455909e2866485c9a4b90f9b6120c005fbec863efad60e06046','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2c1e8647e34f476085a74d3aa9b922a5ae0a7100aacfd4d0a5ee50cf546a6e',2004,'DM','Dominica','people-and-society',272,'purchasing power parity - $380 million (2002 est.)
-0.45% (2004 est.)
-1% (2003 est.)
purchasing power parity - $5,400 (2002 est.)
the US does not have an embassy in Dominica; the US
Ambassador to Barbados, Ambassador Mary E. KRAMER, is accredited to','9045ca8bd7fe670fccf8707c3ab006648b2139f0387d3977fc085dbb3500cc78','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f3f6400e04e4b53c1f91a139cc9c0c01c7ea4170a8abbf9032125fabeff0280',2004,'DO','Dominican Republic','people-and-society',273,'purchasing power parity - $52.71 billion (2003
est.)
East Timor
purchasing power parity - $440 million (2001 est.)
1.33% (2004 est.)
East Timor
2.11% (2004 est.)
-0.7% (2003 est.)
East Timor
-3% (2003 est.)
purchasing power parity - $6,000 (2003 est.)
East Timor
purchasing power parity - $500 (2001 est.)
chief of mission: Ambassador Hans H. HERTELL
embassy: corner of Calle Cesar Nicolas Penson and Calle Leopoldo
Navarro, Santo Domingo
mailing address: Unit 5500, APO AA 34041-5500
telephone: [1] (809) 221-2171
FAX: [1] (809) 686-7437
East Timor
chief of mission: Ambassador Grover Joseph REES
embassy: Avenida de Portugal, Praia dos Conqueiros, Dili
mailing address: Department of State, 8250 Dili Place, Washington,
DC 20521-8250
telephone: (670) 332-4684
FAX: (670) 331-3206','b8df4d743e760380be28dbc9a13ba2837c129a8dd55311c10c460f827292b6a4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3deaca6cd76b23886de5151d60a398edeabfc60d3f0ca7d0bb06ef8d25e5b713',2004,'EC','Ecuador','people-and-society',274,'purchasing power parity - $45.65 billion (2003 est.)
1.03% (2004 est.)
2.5% (2003 est.)
purchasing power parity - $3,300 (2003 est.)
chief of mission: Ambassador Kristie Anne KENNEY
embassy: Avenida 12 de Octubre y Avenida Patria, Quito
mailing address: APO AA 34039
telephone: [593] (2) 256-2890
FAX: [593] (2) 250-2052
consulate(s) general: Guayaquil','1a6aa3fcf5eb879e9489461ee03a4ab209a76223469b61ad1de66b698567a9e5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a349b367a1c40c1fc8007826b16a5434e5088fe692b87b275ceede2a725348c6',2004,'EG','Egypt','people-and-society',275,'purchasing power parity - $295.2 billion (2003 est.)
1.83% (2004 est.)
3.1% (2003 est.)
purchasing power parity - $4,000 (2003 est.)
chief of mission: Ambassador C. David WELCH
embassy: 8 Kamal El Din Salah St., Garden City, Cairo
mailing address: Unit 64900, Box 15, APO AE 09839-4900
telephone: [20] (2) 797-3300
FAX: [20] (2) 797-3200','bd0b32446794077e957e2326d7c2f03108500bd0895ad4ae66fa0bd68e72e17a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f96d015719897e1298d15ea6211018026be8811942f14732bd338c765a24a421',2004,'SV','El Salvador','people-and-society',276,'purchasing power parity - $30.99 billion (2003 est.)
1.78% (2004 est.)
1.4% (2003 est.)
purchasing power parity - $4,800 (2003 est.)
chief of mission: Ambassador H. Douglas BARCLAY
embassy: Final Boulevard Santa Elena Sur, Antiguo Cuscatlan, La
Libertad, San Salvador
mailing address: Unit 3116, APO AA 34023
telephone: [503] 278-4444
FAX: [503] 278-5522','746fbda40292cc5e18d6aa15f9797f93a7454d8e2462d60fde00a7b632eff40a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ab56f02c4de1002130336eaa90993cd5f1902ff125f438282080eb24ecc29f6',2004,'GQ','Equatorial Guinea','people-and-society',277,'purchasing power parity - $1.27 billion (2002 est.)
2.43% (2004 est.)
20% (2002 est.)
purchasing power parity - $2,700 (2002 est.)
the US does not have an embassy in Equatorial
Guinea (embassy closed September 1995); the US ambassador to
Cameroon is accredited to Equatorial Guinea; the US State Department
is considering opening a Consulate Agency in Malabo','4f9522efb87ceb7ec30c3f250d92ac3155eca2a503dc1addd1e65b3f4f2448ab','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcbd390123accc61fa0ca33469d552ce840043248685d0f2b1429a500671c412',2004,'ER','Eritrea','people-and-society',278,'purchasing power parity - $3.3 billion (2002 est.)
2.57% (2004 est.)
2% (2002 est.)
purchasing power parity - $700 (2002 est.)
chief of mission: Ambassador Scott H. DELISI
embassy: Franklin D. Roosevelt Street, Asmara
mailing address: P. O. Box 211, Asmara
telephone: [291] (1) 120004
FAX: [291] (1) 127584','9426d63f29634785db01c4da89aa6d5f40ed0ba6b5b803ff7017058398867c07','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77e69a2a9ff30ed2521544270055c26f3a2ffd5d502cc3604746d79a3cccf388',2004,'EE','Estonia','people-and-society',279,'purchasing power parity - $17.35 billion (2003 est.)
-0.66% (2004 est.)
4.7% (2003 est.)
purchasing power parity - $12,300 (2003 est.)
chief of mission: Ambassador Aldona Zofia WOS
embassy: Kentmanni 20, 15099 Tallinn
mailing address: use embassy street address
telephone: [372] 668-8100
FAX: [372] 668-8134','aa6caacfe79653800c5bfbe4d52083623fe350cb23399c205344f7b985b1caa8','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f84a3dd35b9057d3338314b551c9fe1d3b3a6911b3a65fd960767e1d1d081ff1',2004,'ET','Ethiopia','people-and-society',280,'purchasing power parity - $46.81 billion (2003 est.)
European Union
purchasing power parity - $11.05 trillion (2004 est.)
Falkland Islands (Islas Malvinas)
purchasing power parity - $75
million (2002 est.)
1.89% (2004 est.)
European Union
0.17% (July 2004 est.)
Falkland Islands (Islas Malvinas)
2.44% (2004 est.)
-3.8% (2003 est.)
European Union
1% (2004 est.)
Falkland Islands (Islas Malvinas)
NA
purchasing power parity - $700 (2003 est.)
European Union
purchasing power parity - $25,700 (2004 est.)
Falkland Islands (Islas Malvinas)
purchasing power parity - $25,000
(2002 est.)
chief of mission: Ambassador Aurelia A. BRAZEAL
embassy: Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 550666
FAX: [251] (1) 551328
European Union
chief of mission: Ambassador Rockwell SCHNABEL
embassy: 13 Zinnerstraat (Rue Zinner), B-1000 Brussels
mailing address: same as above
telephone: [32] (2) 508-2222
FAX: [32] (2) 512-5720
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)','29275436e94ad2ed4bd842977a97d792d0797eddb70b4d47a3a1e2fe1c8e0f9b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2359499fa1f5070fb3b2b61d39fe63b62087891a83031f5b998be00d991131fd',2004,'FO','Faroe Islands','people-and-society',281,'purchasing power parity - $1 billion (2001 est.)
0.66% (2004 est.)
10% (2001 est.)
purchasing power parity - $22,000 (2001 est.)
part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark since 1948
none (self-governing overseas administrative division
of Denmark)','03dcc07e66949c72e6e27fa2943d84ad4de6d32cfa85a0f94307c9447bbda742','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8cb4c40557247a30f9f691d11f28a7d1a7456c7bc860f789fa45f6976ffbfe5',2004,'FJ','Fiji','people-and-society',282,'purchasing power parity - $5.012 billion (2003 est.)
1.41% (2004 est.)
4.8% (2003 est.)
purchasing power parity - $5,800 (2003 est.)
chief of mission: Ambassador David L. LYON
embassy: 31 Loftus Street, Suva
mailing address: P. O. Box 218, Suva
telephone: [679] 331-4466
FAX: [679] 330-0081','1f82cb4cb9ddfc22cf7389172563fb2b9265f57005dbb06b682a0d4f2c235df2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('200cbb915304b8de7f5d6122555b09773312608715a93834fe83ab6a0b411c5a',2004,'FI','Finland','people-and-society',283,'purchasing power parity - $142.2 billion (2003 est.)
0.18% (2004 est.)
1.9% (2003 est.)
purchasing power parity - $27,400 (2003 est.)
chief of mission: Ambassador Earle I. MACK
embassy: Itainen Puistotie 14B, FIN-00140, Helsinki
mailing address: APO AE 09723
telephone: [358] (9) 616250
FAX: [358] (9) 6162 5800','a3f3dadba8f188c2363ddcf83ed1df934488bf151242cd2000c9869cb90cd15d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d50b065a0a49af99e3582fcfe011dac523e86d55172e517c0e1b266dd9b9dd29',2004,'FR','France','people-and-society',284,'purchasing power parity - $1.661 trillion (2003 est.)
0.39% (2004 est.)
0.5% (2003 est.)
purchasing power parity - $27,600 (2003 est.)
chief of mission: Ambassador Howard H. LEACH
embassy: 2 Avenue Gabriel, 75008 Paris Cedex 08
mailing address: PSC 116, APO AE 09777
telephone: [33] (1) 43-12-22-22
FAX: [33] (1) 42 66 97 83
consulate(s) general: Marseille, Strasbourg','826752d380b32bb41fb442dd0f1c997444940397e971c8bfbf82e1b312243644','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bacfa395b474ee0786c070b9af4d1ccad42cba77ec9be2d4e17339cd3c033eb',2004,'GF','French Guiana','people-and-society',285,'purchasing power parity - $1.551 billion (2003 est.)
2.25% (2004 est.)
NA
purchasing power parity - $8,300 (2001 est.)
overseas department of France
none (overseas department of France)','b439058aebd5a3929b18c6cf7f1af766a32790319ac1db5e7775c52f00024c9b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5223c11111b3f94aef19b82112a3342e6e125677f5c17c8a6e2a6aed78aa6751',2004,'PF','French Polynesia','people-and-society',286,'purchasing power parity - $4.58 billion (2003 est.)
1.57% (2004 est.)
4% (2001 est.)
purchasing power parity - $17,500 (2001 est.)
overseas territory of France since 1946
French Southern and Antarctic Lands
overseas territory of France
since 1955; administered from Paris by Administrateur Superieur
Michel CHAMPON (since 20 December 2004), assisted by Secretary
General Jean-Yves HERMOSO (since NA)
none (overseas territory of France)
French Southern and Antarctic Lands
none (overseas territory of
France)','952103f9bc8d6280e7a9e02f462099c357320184e86c4418289ad02d212f71e2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d9fc9118c7b720b3c60d54f83daf626c8c3607f4a45906e17047a2d1c8d3d2',2004,'GA','Gabon','people-and-society',287,'purchasing power parity - $7.301 billion (2003 est.)
Gambia, The
purchasing power parity - $2.56 billion (2003 est.)
Gaza Strip
purchasing power parity - $768 million (2003 est.)
2.5% (2004 est.)
Gambia, The
2.98% (2004 est.)
Gaza Strip
3.83% (2004 est.)
1.2% (2003 est.)
Gambia, The
3% (2003 est.)
Gaza Strip
4.5% (2003 est.)
purchasing power parity - $5,500 (2003 est.)
Gambia, The
purchasing power parity - $1,700 (2003 est.)
Gaza Strip
purchasing power parity - $600 (2003 est.)
chief of mission: Ambassador Kenneth P. MOOREFIELD
embassy: Boulevard de la Mer, Libreville
mailing address: Centre Ville, B. P. 4000, Libreville
telephone: [241] 76 20 03 through 76 20 04, after hours - 74 34 92
FAX: [241] 74 55 07
Gambia, The
chief of mission: Ambassador Jackson McDONALD
embassy: Kairaba Avenue, Fajara, Banjul
mailing address: P. M. B. No. 19, Banjul
telephone: [220] 392856, 392858, 391971
FAX: [220] 392475','11b3f7caa44a60d78aa578ee6a3153abf9b6bf9887c20ee10873b799dbf2117e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d67fdcff01900d845e4ff5f5ef6bd3bd9f911ccf69ba74c9f596715a29841c6c',2004,'GE','Georgia','people-and-society',288,'purchasing power parity - $12.18 billion (2003 est.)
-0.36% (2004 est.)
5.5% (2003 est.)
purchasing power parity - $2,500 (2003 est.)
chief of mission: Ambassador Richard M. MILES
embassy: #25 Atoneli Street, T''bilisi 0105
mailing address: 7060 Tbilisi Place, Washington, DC 20521-7060
telephone: [995] (32) 989-967/68
FAX: [995] (32) 933-759','4db7536500190b605fcf617d1274dc8d46226b2ea37c37d4531d19352dc29863','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03a795b466db100ea97ae9a9ed1fca5fb6fb162831a1501c22214b9652c328ae',2004,'DE','Germany','people-and-society',289,'purchasing power parity - $2.271 trillion (2003 est.)
0.02% (2004 est.)
-0.1% (2003 est.)
purchasing power parity - $27,600 (2003 est.)
chief of mission: Ambassador Daniel R. COATS
embassy: Neustaedtische Kirchstrasse 4-5, 10117 Berlin; note - a new
embassy will be built near the Brandenburg Gate in Berlin; ground
was broken in October 2004 and completion is scheduled for 2008
mailing address: PSC 120, Box 1000, APO AE 09265
telephone: [49] (030) 8305-0
FAX: [49] (030) 8305-1215
consulate(s) general: Duesseldorf, Frankfurt am Main, Hamburg,
Leipzig, Munich','1c8e0cc4237f97aded487487bfc88c8483afa4730ae42b343283a15f0c1ac6d3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9cf746b6bd82526d908f738d94ee7128ff3b3d8fa25e0f8662804f935d9ba87',2004,'GH','Ghana','people-and-society',290,'purchasing power parity - $44.44 billion (2003 est.)
1.36% (2004 est.)
4.7% (2003 est.)
purchasing power parity - $2,200 (2003 est.)
chief of mission: Ambassador Mary Carlin YATES
embassy: 6th and 10th Lanes, 798/1 Osu, Accra
mailing address: P. O. Box 194, Accra
telephone: [233] (21) 775-347, 775-348
FAX: [233] (21) 701-813','c07dd886af82932aa2675d011f50196a5e50c980bb6ebb36305e94023ca62cc2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6179ac8aad0f1400e8fa6e0538a5a1f1f729ece7a2334723a379c9b8503b0d14',2004,'GI','Gibraltar','people-and-society',291,'purchasing power parity - $500 million (1997 est.)
0.19% (2004 est.)
NA
purchasing power parity - $17,500 (1997 est.)
overseas territory of the UK
Glorioso Islands
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
none (overseas territory of the UK)
Glorioso Islands
none (possession of France)','299f11b3dfa5b7906cc7d9e5301b8e1bd7aea79fd5fad779347ee2726f680900','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a305c9e944f9e980fb5b5bdee63e69d68a38e2d716a0ada9fa5f14b5e70e83a',2004,'GR','Greece','people-and-society',292,'purchasing power parity - $213.6 billion (2003 est.)
0.2% (2004 est.)
4.7% (2003 est.)
purchasing power parity - $20,000 (2003 est.)
chief of mission: Ambassador Charles RIES
embassy: 91 Vasilissis Sophias Avenue, 10160 Athens
mailing address: PSC 108, APO AE 09842-0108
telephone: [30] (210) 721-2951
FAX: [30] (210) 645-6282
consulate(s) general: Thessaloniki','02a79815e6a355329b37947bb9fb880749546f7a428bec5fb80613f0e62885a9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4614cce572666ab90430d1a9fbb590ccdcc4fc55bc4b363cd1275122522ab61',2004,'GL','Greenland','people-and-society',293,'purchasing power parity - $1.1 billion (2001 est.)
-0.01% (2004 est.)
1.8% (2001 est.)
purchasing power parity - $20,000 (2001 est.)
part of the Kingdom of Denmark; self-governing overseas
administrative division of Denmark since 1979
none (self-governing overseas administrative division of
Denmark)','00eba7aa27d5f8d68a35e908bc2971bef53160ccfc1ddcf1634b3c55c3781053','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31622ffc1aca34323943161bd7ed0394ff3660f4849fe04ab9b67ab6f586a999',2004,'GD','Grenada','people-and-society',294,'purchasing power parity - $440 million (2002 est.)
0.14% (2004 est.)
2.5% (2002 est.)
purchasing power parity - $5,000 (2002 est.)
chief of mission: the US Ambassador to Barbados, Ambassador
Mary E. KRAMER, is accredited to Grenada
embassy: Lance-aux-Epines Stretch, Saint George''s
mailing address: P. O. Box 54, Saint George''s, Grenada, West Indies
telephone: [1] (473) 444-1173 through 1176
FAX: [1] (473) 444-4820','4ae08bc99b7db80c5f2db6fae27402b0682ac2582746e1efc6be6d3a42ae3168','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23160a74eaf0001f12a3d907aa0f1db58ea243fe073a143c2fb00dc3c2309196',2004,'GP','Guadeloupe','people-and-society',295,'purchasing power parity - $3.513 billion (2003 est.)
0.96% (2004 est.)
NA
purchasing power parity - $8,000 (2001 est.)
overseas department of France
none (overseas department of France)','3659168a7ece18d0a5501db6653715ffc418637fe594089db5a9ff462f9ecc76','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf2abc25d9766e423d7d10c600526c271b28d5c946b772c98c06bd48d4e684eb',2004,'GU','Guam','people-and-society',296,'purchasing power parity - $3.2 billion (2000 est.)
1.5% (2004 est.)
NA
purchasing power parity - $21,000 (2000 est.)
organized, unincorporated territory of the US with policy
relations between Guam and the US under the jurisdiction of the
Office of Insular Affairs, US Department of the Interior
none (territory of the US)','19c04175166e2eef5a8b9f78bea92b54dd93bbbac4e56b19a93be21d2c020dea','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64c601be2cd81c43b75f989a45d7c3eea47f24cdec2ba2936a910e743747b02c',2004,'GT','Guatemala','people-and-society',297,'purchasing power parity - $56.5 billion (2003 est.)
2.61% (2004 est.)
2.1% (2003 est.)
purchasing power parity - $4,100 (2003 est.)
chief of mission: Ambassador John R. HAMILTON
embassy: 7-01 Avenida Reforma, Zone 10, Guatemala City
mailing address: APO AA 34024
telephone: [502] 2331-1541/55
FAX: [502] 2334-8477','eff1127be42c12f9a7fcfeb6a7a17a96c5b3e9cd86a373107fabfccafc6dcb14','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('003f6e34355d582fa2f90f8c626290b011ac5b7cbef88eb5c0abd73afd6f94b6',2004,'GG','Guernsey','people-and-society',298,'purchasing power parity - $1.3 billion (1999 est.)
0.31% (2004 est.)
5.7% (1999 est.)
purchasing power parity - $20,000 (1999 est.)
British crown dependency
none (British crown dependency)','6264885cd5484fce768d5eaef441d30d0bf26fd75e0f1fe2a0d4c9ccdc30437c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04e7b8c624fb6f738e8415381baeac4ccbf0f3bc6451842d2e917ed560a2b90d',2004,'GN','Guinea','people-and-society',299,'purchasing power parity - $19.02 billion (2003 est.)
2.37% (2004 est.)
3% (2003 est.)
purchasing power parity - $2,100 (2003 est.)
chief of mission: Ambassador Barrie R. WALKLEY
embassy: Rue Ka 038, Conakry
mailing address: B. P. 603, Conakry
telephone: [224] 41 15 20, 41 15 21, 41 15 23
FAX: [224] 41 15 22','16af2f9bec92c29d139323c9efc737fe9905574393038302aeebee68639f0f04','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bae78b963dcbb8d0f3efacc941cda9a785f26494fb0da8b1adeb9171fefb40ee',2004,'GW','Guinea-Bissau','people-and-society',300,'purchasing power parity - $1.063 billion (2003 est.)
1.99% (2004 est.)
-7% (2003 est.)
purchasing power parity - $800 (2003 est.)
the US Embassy suspended operations on 14 June 1998 in
the midst of violent conflict between forces loyal to then President
VIEIRA and military-led junta; US embassy Dakar is responsible for
covering Guinea-Bissau: telephone - [221] 823-4296; FAX - [221]
822-5903','a42363000d69a4ec6fae640257f261bc0478395f171f62268dcadab678cd3923','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6bfe4a316e454e5d9d4041fde1fd9da352d66b84516f8606f86f49c2918d6f6',2004,'GY','Guyana','people-and-society',301,'purchasing power parity - $2.797 billion (2003 est.)
0.61% (2004 est.)
0.5% (2003 est.)
purchasing power parity - $4,000 (2003 est.)
chief of mission: Ambassador Roland BULLEN
embassy: 100 Young and Duke Streets, Kingston, Georgetown
mailing address: P. O. Box 10507, Georgetown
telephone: [592] 225-4900 through 4909
FAX: [592] 225-8497','44d1d09fa962c9adc6fe62ad1ce764a5fe7578ffef3a95f857cbda6f71cb6ce6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4ea093647f8e8965078f18db6c998d54257fc1ca20e69ca25f42dd2514959dd',2004,'HT','Haiti','people-and-society',302,'purchasing power parity - $12.3 billion (2003 est.)
1.71% (2004 est.)
Holy See (Vatican City)
0.01% (2004 est.)
0% (2003 est.)
purchasing power parity - $1,600 (2003 est.)
chief of mission: Ambassador James B. FOLEY
embassy: 5 Harry S Truman Boulevard, Port-au-Prince
mailing address: P. O. Box 1761, Port-au-Prince
telephone: [509] 222-0354, 222-0269, 222-0200, 222-0327
FAX: [509] 223-1641 or 222-0200 ext 460','013f46606008cb79e0c232159ae0448e80593d08b0a99c8b1eeace292526ab2c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12f7e44151500b31dad22daf841d4a28f2e47fc5106b5e94fa58b4c6902033dd',2004,'HN','Honduras','people-and-society',303,'purchasing power parity - $17.55 billion (2003 est.)
2.24% (2004 est.)
3% (2003 est.)
purchasing power parity - $2,600 (2003 est.)
chief of mission: Ambassador Larry Leon PALMER
embassy: Avenida La Paz, Apartado Postal No. 3453, Tegucigalpa
mailing address: American Embassy, APO AA 34022, Tegucigalpa
telephone: [504] 238-5114, 236-9320
FAX: [504] 236-9037','2dd14c45998af3b6626a7414d98509336aa2fac686da494b6321d91da1a3d840','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6187e5fe6ab5ebbc518f12b74d0aad41187d1524ce1beac8a5fca6acf6cf0237',2004,'HK','Hong Kong','people-and-society',304,'purchasing power parity - $213 billion (2003 est.)
0.65% (2004 est.)
3.3% (2003 est.)
purchasing power parity - $28,800 (2003 est.)
special administrative region of China
Howland Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Jan Mayen
territory of Norway; since August 1994, administered from
Oslo through the county governor (fylkesmann) of Nordland; however,
authority has been delegated to a station commander of the Norwegian
Defense Communication Service
Jarvis Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
chief of mission: Consul General James KEITH
consulate(s) general: 26 Garden Road, Hong Kong
mailing address: PSC 461, Box 1, FPO AP 96521-0006
telephone: [852] 2523-9011
FAX: [852] 2524-0860','45354327a9c014b48921e09dc0b28b3f7e197b10c678da0f010899d995c1e8f0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68d0036ed980c2a121713a8c84a4bcb4c3702d30a9ab7a403b946532e25d7a09',2004,'HU','Hungary','people-and-society',305,'purchasing power parity - $139.8 billion (2003 est.)
-0.25% (2004 est.)
2.9% (2003 est.)
purchasing power parity - $13,900 (2003 est.)
chief of mission: Ambassador George Herbert WALKER
embassy: Szabadsag ter 12, H-1054 Budapest
mailing address: pouch: American Embassy Budapest, 5270 Budapest
Place, Department of State, Washington, DC 20521-5270
telephone: [36] (1) 475-4400
FAX: [36] (1) 475-4764','7e51093caa29bad6b7dbf07bc5bc8ea16259463e67c9b8c9c10c7a2550f56198','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd2f76828ed65fbf02ff6eb78ca62f7fc3e7d239111c4e8cec6a79cc3a60471f',2004,'IS','Iceland','people-and-society',306,'purchasing power parity - $8.678 billion (2003 est.)
0.97% (2004 est.)
2.6% (2003 est.)
purchasing power parity - $30,900 (2003 est.)
chief of mission: Ambassador James I. GADSDEN
embassy: Laufasvegur 21, 101 Reykjavik
mailing address: US Embassy, PSC 1003, Box 40, FPO AE 09728-0340
telephone: [354] 562-9100
FAX: [354] 562-9118','7c88050dcaa03c3174c4351812d2548759c3ccbbd30488f03304aacd9a657032','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25cc1b30d9ef8cb6b590a613e521d5fd92bc684d0ad36d17f9edff96b7fe54b6',2004,'IN','India','people-and-society',307,'purchasing power parity - $3.033 trillion (2003 est.)
1.44% (2004 est.)
8.3% (2003 est.)
purchasing power parity - $2,900 (2003 est.)
chief of mission: Ambassador David C. MULFORD
embassy: Shantipath, Chanakyapuri, New Delhi 110021
mailing address: use embassy street address
telephone: [91] (11) 2419-8000
FAX: [91] (11) 2419-0017
consulate(s) general: Chennai (Madras), Kolkata (Calcutta), Mumbai
(Bombay)','49689f3163493f6516e47e4b96d3df6566847462ef7773dbc763c344da6d40ed','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('314951605ddc6d5228d04a21b51e4f708f453f49f690720812f0882eaf812ee3',2004,'ID','Indonesia','people-and-society',308,'purchasing power parity - $758.8 billion (2003 est.)
Iran
purchasing power parity - $478.2 billion (2003 est.)
1.49% (2004 est.)
Iran
1.07% (2004 est.)
4.1% (2003 est.)
Iran
6.1% (2003 est.)
purchasing power parity - $3,200 (2003 est.)
Iran
purchasing power parity - $7,000 (2003 est.)
chief of mission: Ambassador B. Lynn PASCOE
embassy: Jalan 1 Medan Merdeka Selatan 3-5, Jakarta 10110
mailing address: Unit 8129, Box 1, FPO AP 96520
telephone: [62] (21) 3435-9000
FAX: [62] (21) 385-7189
consulate(s) general: Surabaya
Iran
none; note - protecting power in Iran is Switzerland','7ea43da659cab7e0c06936c4cb6bdd625be3f08541084985b1b0f5117e023944','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b466dd23736c8552090271356a8886c1b36f9e324210dbd5d99b06e99441e366',2004,'IQ','Iraq','people-and-society',309,'purchasing power parity - $37.92 billion (2003 est.)
2.74% (2004 est.)
-21.8% (2003 est.)
purchasing power parity - $1,500 (2003 est.)
chief of mission: Ambassador John D. NEGROPONTE
embassy: Baghdad
mailing address: APO AE 09316
telephone: 00-1-240-553-0584 ext. 4354; note - Consular Section
FAX: NA','d74d662fd2e7747a3beef97a00e8970cd8ea14377914e91c9f2aedb27ba1941b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3e7b495791b48c5221f05f5bcf84e5cb0e2c333805eab445067012d3bda7f2',2004,'IE','Ireland','people-and-society',310,'purchasing power parity - $116.2 billion (2003 est.)
1.16% (2004 est.)
1.4% (2003 est.)
purchasing power parity - $29,600 (2003 est.)
chief of mission: Ambassador James C. KENNY
embassy: 42 Elgin Road, Ballsbridge, Dublin 4
mailing address: use embassy street address
telephone: [353] (1) 668-8777
FAX: [353] (1) 668-9946','fbfa839979435c0e6c862b02225d8e5479742c0975fdcc508b7466bd6d11c6f9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecac31591f6f027cbc1a6d5ac449d5002613c85413fa89ceef58a3767a50efc1',2004,'IL','Israel','people-and-society',311,'purchasing power parity - $120.9 billion (2003 est.)
1.29% (2004 est.)
1.3% (2003 est.)
purchasing power parity - $19,800 (2003 est.)
chief of mission: Ambassador Daniel C. KURTZER
embassy: 71 Hayarkon Street, Tel Aviv 63903
mailing address: PSC 98, Box 29, APO AE 09830
telephone: [972] (3) 519-7369/7453/7454/7457/7458/7551/7575
FAX: [972] (3) 516-4390
consulate(s) general: Jerusalem; note - an independent US mission,
established in 1928, whose members are not accredited to a foreign','988a35ba572c27cfe0da2e6a530e4ee0ecc9e626970bf8d31bf3e829a3940afd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72e1c1cb2c75c5dc87ae223f31c67fc5fb2ead3560dd3a80afe6f7bde4436f65',2004,'IT','Italy','people-and-society',312,'purchasing power parity - $1.55 trillion (2003 est.)
0.09% (2004 est.)
0.4% (2003 est.)
purchasing power parity - $26,700 (2003 est.)','2db67674a1bd56975d0cdaf006ad4643a0f5256be515d1936b790390d137f1d6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60bc9b1d5fe63052250dae7ed68f9b4b7c880a236e2a597cfede491a8fd04dfb',2004,'JM','Jamaica','people-and-society',313,'purchasing power parity - $10.61 billion (2003 est.)
0.66% (2004 est.)
1.9% (2003 est.)
purchasing power parity - $3,900 (2003 est.)','4f46043d90b933058a826b9009872fb821e19cde4a2df64fb8d2b2f9f02819af','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8a00fac552ed6a26ff4a701a5376bf1a7f59eaef533733375acdaf3cf929a8d',2004,'JP','Japan','people-and-society',314,'purchasing power parity - $3.582 trillion (2003 est.)
0.08% (2004 est.)
2.7% (2003 est.)
purchasing power parity - $28,200 (2003 est.)','77de3a302cd806dd95bcc42ac48fc9205662ea9e57606ad1b76f298724eae25b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa1eceba1d652ef7df968f2c369bbbf388525b06d97f19c2d6bb3be4b881ea3f',2004,'JE','Jersey','people-and-society',315,'purchasing power parity - $2.2 billion (1999 est.)
0.36% (2004 est.)
NA
purchasing power parity - $24,800 (1999 est.)
British crown dependency
Johnston Atoll
unincorporated territory of the US; administered from
Honolulu, HI, by Pacific Air Forces, Hickam Air Force Base, and the
Fish and Wildlife Service of the US Department of the Interior as
part of the National Wildlife Refuge system
Juan de Nova Island
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
Kingman Reef
unincorporated territory of the US; administered from
Washington, DC, by the US Fish and Wildlife Service of the
Department of the Interior
note: on 1 September 2000, the Department of the Interior accepted
restoration of its administrative jurisdiction over Kingman Reef
from the Department of the Navy; Executive Order 3223 signed 18
January 2001 established Kingman Reef National Wildlife Refuge to be
administered by the Director, US Fish and Wildlife Service; this
refuge is managed to protect the terrestrial and aquatic wildlife of
Kingman Reef out to the 12-nautical-mile territorial sea limit
Macau
special administrative region of China
Man, Isle of
British crown dependency','98d31f080618bb3fb0fcb428e5dfdfed9d1a6783954f765f4d77680755a2296b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9f61ab5488394ece9bd5b3660878c138a454eed76326e32cd6c7cb4032e1781',2004,'JO','Jordan','people-and-society',316,'purchasing power parity - $23.64 billion (2003 est.)
2.67% (2004 est.)
3.1% (2003 est.)
purchasing power parity - $4,300 (2003 est.)','16b0e3e070fbd1050e38c93c6c001c0a8cbb47522da289ded740398e6b3d1eb1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7f1bb6cc0bac2b8637dfe08a684a7483a724631c97c6f7f9331bb0695c183b6',2004,'KZ','Kazakhstan','people-and-society',317,'purchasing power parity - $105.5 billion (2003 est.)
0.26% (2004 est.)
9.2% (2003 est.)
purchasing power parity - $6,300 (2003 est.)','e87c71ec6750859e2dfd20dc1ee35f33b26680a8f66f33b73b2a3fe4e5d5758f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ab9223246a8dbbdcd7e0a206fe9ba2d9095057c53b695c34d233339b74c2032',2004,'KE','Kenya','people-and-society',318,'purchasing power parity - $33.03 billion (2003 est.)
1.14% (2004 est.)
1.5% (2003 est.)
purchasing power parity - $1,000 (2003 est.)','4c9d495150f8184339e1766f0a7e7e2cd53c7ba91eb93cbf65b1c23b7eb5bdb8','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8feab11161a09273d0dd01190198f8a752d2dd07b2abda741438b16ae0d8c01',2004,'KI','Kiribati','people-and-society',319,'purchasing power parity - $79 million - supplemented by a
nearly equal amount from external sources (2001 est.)
Korea, North
purchasing power parity - $29.58 billion (2003 est.)
Korea, South
purchasing power parity - $857.8 billion (2003 est.)
2.25% (2004 est.)
Korea, North
0.98% (2004 est.)
Korea, South
0.62% (2004 est.)
1.5% (2001 est.)
Korea, North
1% (2003 est.)
Korea, South
3.1% (2003 est.)
purchasing power parity - $800 (2001 est.)
Korea, North
purchasing power parity - $1,300 (2003 est.)
Korea, South
purchasing power parity - $17,800 (2003 est.)','cf7a2f32f21a1c264130256625e1659c2adb07cace85250e432e74cf30b70aa5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1da1ef2255f7319771f2d1f42ddb68c2d676ca5f2fcc0dd7d0fb395d15a8ffae',2004,'KW','Kuwait','people-and-society',320,'purchasing power parity - $41.46 billion (2003 est.)
3.36%
note: this rate reflects a return to pre-Gulf crisis immigration of
expatriates (2004 est.)
4.6% (2003 est.)
purchasing power parity - $19,000 (2003 est.)','889e0e3b695c51c32b5a00caa256db74783f8fc9c2ae589d5e8c1bccf1cfe296','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('909c9fcd3086c4f01a17894d5f4a38d4a24867483bd4c209dbda88fda01e465e',2004,'KG','Kyrgyzstan','people-and-society',321,'purchasing power parity - $7.808 billion (2003 est.)
Laos
purchasing power parity - $10.32 billion (2003 est.)
1.25% (2004 est.)
Laos
2.44% (2004 est.)
6.7% (2003 est.)
Laos
5.5% (2003 est.)
purchasing power parity - $1,600 (2003 est.)
Laos
purchasing power parity - $1,700 (2003 est.)','b425fc6a419e42d94c7b0cdba5bcb6446f3c133e9be213373aa34f51cb74101d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68f100432a67db561a4e47e6d3604ec6ca44f81fa0ea9ba69ddea03748786882',2004,'LV','Latvia','people-and-society',322,'purchasing power parity - $23.9 billion (2003 est.)
-0.71% (2004 est.)
7.4% (2003 est.)
purchasing power parity - $10,200 (2003 est.)','fe4921681ab8ae63a24f8e2c59c41beef817fac8fc50a6d554a35dd0a56d4ba2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3a7094d934194a347992cd971c930f86207a8213770e283d92fdfb14a94e7f7',2004,'LB','Lebanon','people-and-society',323,'purchasing power parity - $17.82 billion (2003 est.)
1.3% (2004 est.)
3% (2003 est.)
purchasing power parity - $4,800 (2003 est.)','0e8442e298629003a6a53fd3925a49bdfcc6d79af69fa0b667bef482c9e110fa','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36ac9074eea1e7327ea54c2937a87ca83e113157c873eec057abdbb529a45ae8',2004,'LS','Lesotho','people-and-society',324,'purchasing power parity - $5.583 billion (2003 est.)
0.14% (2004 est.)
4% (2003 est.)
purchasing power parity - $3,000 (2003 est.)','36f5f276ff4772367ce97a45dc77f195bcef242013fb4844cf17f0e5fc00424a','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b1be8674cd6b907291e9125a7ae1fdbcdc6a0e6f2afb10484dff24370cb24f',2004,'LR','Liberia','people-and-society',325,'purchasing power parity - $3.261 billion (2003 est.)
2.7% (2004 est.)
3% (2003 est.)
purchasing power parity - $1,000 (2003 est.)','92edc5d83554505620a67dd7b351c462b16fd5d468d64efe6b4fb13bcf19cd63','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cda8cce7289fc89a735acc459389324d4a3d73e234e13d6d4dd02cfe25bb073',2004,'LY','Libya','people-and-society',326,'purchasing power parity - $35 billion (2003 est.)
2.37% (2004 est.)
3.2% (2003 est.)
purchasing power parity - $6,400 (2003 est.)','3494ccac70be8100d40221a96d815439c731f7d64c1c27c50963f15671efb1dd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d445b61855149a6ba4b0257255a6911b67c6219a256df9bbce21a096ef7d9923',2004,'LI','Liechtenstein','people-and-society',327,'purchasing power parity - $825 million (1999 est.)
0.86% (2004 est.)
11% (1999 est.)
purchasing power parity - $25,000 (1999 est.)','ca187e854e8cd18a054313ddbcbb15c92414078d54196b1e358f74e431be0b63','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('787eeebc3bdbe6c274b2ce11b624ddd00ff8d2754340443a9d4f60ce4c09ebef',2004,'LT','Lithuania','people-and-society',328,'purchasing power parity - $40.88 billion (2003 est.)
-0.33% (2004 est.)
9% (2003 est.)
purchasing power parity - $11,400 (2003 est.)','88b9179744e1e4c74f2a2d8cfdf328db03d8f3eaa86d07b2c6d6488611920553','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a9eadb7b8de8aaf2c7103c9815fe8cc755a22c0a269219012baed06b5c920b',2004,'LU','Luxembourg','people-and-society',329,'purchasing power parity - $25.01 billion (2003 est.)
Macau
purchasing power parity - $9.1 billion (2003 est.)
Macedonia
purchasing power parity - $13.81 billion (2003 est.)
1.28% (2004 est.)
Macau
0.87% (2004 est.)
Macedonia
0.39% (2004 est.)
1.2% (2003 est.)
Macau
4% (2003 est.)
Macedonia
2.8% (2003 est.)
purchasing power parity - $55,100 (2003 est.)
Macau
purchasing power parity - $19,400 (2003 est.)
Macedonia
purchasing power parity - $6,700 (2003 est.)','22ab3aa9785c45f452fa167f771d409951bf8f8ea6325ae574f2c30f0ad8ab6f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0dd043a5f0ba63e516f9f2c19c3f138d4dc4dececd8de30a1f414b64c748ec4',2004,'MG','Madagascar','people-and-society',330,'purchasing power parity - $13.02 billion (2003 est.)
3.03% (2004 est.)
6% (2003 est.)
purchasing power parity - $800 (2003 est.)','709e04090e95c8b95fabad7d3b5eb3f592642a51e75657e1fd757756026aaa41','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7ff78516dbd167a14c7a1bf969bcdbd1c5cfa377a12c5c3f5d721bd2452ba3c',2004,'MW','Malawi','people-and-society',331,'purchasing power parity - $6.845 billion (2003 est.)
2.14% (2004 est.)
1.7% (2003 est.)
purchasing power parity - $600 (2003 est.)','2ce7ee041f96b716ebea2dac7b49ad2f8833b7861597ff236e92ad5704e759c2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fae012c9aa30434dc71c75bdd5fa62fb1765a096d322604e1415ec0b08f1298',2004,'MY','Malaysia','people-and-society',332,'purchasing power parity - $207.8 billion (2003 est.)
1.83% (2004 est.)
5.2% (2003 est.)
purchasing power parity - $9,000 (2003 est.)','ad73c409ec5e1f13f0a6fca30fe6aa6e69eeda3b93f22b9a6f91c3fd7fc47079','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d007e0ac32d9948a1b8426d455f6110232512fbbdb1f4bd2d678bd31d7b88dbd',2004,'MV','Maldives','people-and-society',333,'purchasing power parity - $1.25 billion (2002 est.)
2.86% (2004 est.)
2.3% (2002 est.)
purchasing power parity - $3,900 (2002 est.)','b8a3d9e3ebc68a7f7b235b4a16b152d3223ede5562a6ffe913bf7402a11392b6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('516fe02b75eeb4e997cf0fd399db46bdb0de6bfc4f68d013a838b2e715762e99',2004,'ML','Mali','people-and-society',334,'purchasing power parity - $10.53 billion (2003 est.)
2.78% (2004 est.)
0.5% (2003 est.)
purchasing power parity - $900 (2003 est.)','c55ecbdc0979b13f7ec6f8aea2dcb8f365a9a4192f2858a85e4793553064eb4b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec77cf052934275192b945a846210068412c8329c6b5728b750a8854d0818030',2004,'MT','Malta','people-and-society',335,'purchasing power parity - $7.082 billion (2003 est.)
Man, Isle of
purchasing power parity - $1.6 billion (2001 est.)
0.42% (2004 est.)
Man, Isle of
0.53% (2004 est.)
0.8% (2003 est.)
Man, Isle of
13.5%
purchasing power parity - $17,700 (2003 est.)
Man, Isle of
purchasing power parity - $21,000 (2001 est.)','2ca60f8c812665cb582804175cd320adbb62dc1e975214b69ac62583af266f8b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a40142552123f0cdb1a1419b6ed89cb8340aca9f9b82a8a0abdefc5cde39f7cf',2004,'MH','Marshall Islands','people-and-society',336,'purchasing power parity - $115 million (2001 est.)
2.29% (2004 est.)
1% (2001 est.)
purchasing power parity - $1,600 (2001 est.)','14950d2e9e2d0b003e6136afba344608b9b018293e18728eba360063d5bbf478','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e1e7f7c0558048087d77ca1f8f9957850fafd33518181d0c32262a22e68e6b3',2004,'MQ','Martinique','people-and-society',337,'purchasing power parity - $6.117 billion (2003 est.)
0.81% (2004 est.)
NA
purchasing power parity - $14,400 (2001 est.)
overseas department of France','688d46fea5ae77c1d4f28f017094f76050a6a8819c56060bdb0e651617567808','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61b262f646fcb60e450d82f264e89e810773b144037fffbc09b19622b0e6156d',2004,'MR','Mauritania','people-and-society',338,'purchasing power parity - $5.195 billion (2003 est.)
2.91% (2004 est.)
4.5% (2003 est.)
purchasing power parity - $1,800 (2003 est.)','ba72acfa3b4f5977b706ace3cbced7a5657314296e72cb1f0e16df21adf7ab9e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d33c2ad57043a3145c49f13a1961d67f431144155f32929fbb10c011d405207',2004,'MU','Mauritius','people-and-society',339,'purchasing power parity - $13.85 billion (2003 est.)
0.81% (2004 est.)
4.1% (2003 est.)
purchasing power parity - $11,400 (2003 est.)','20de49648f6d11f69ac80adb33d3c4a8d81a94b488627ee9d40fb61c8d58fffc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9f8f49292adf9a4db88e5992e934dedcf103e478939363110df871d6ec7715',2004,'YT','Mayotte','people-and-society',340,'purchasing power parity - $466.8 million (2003 est.)
4.09% (2004 est.)
NA
purchasing power parity - $2,600 (1998 est.)
territorial collectivity of France
Midway Islands
unincorporated territory of the US; formerly
administered from Washington, DC, by the US Navy, under Naval
Facilities Engineering Command, Pacific Division; this facility has
been operationally closed since 10 September 1993; on 31 October
1996, through a presidential executive order, the jurisdiction and
control of the atoll was transferred to the Fish and Wildlife
Service of the US Department of the Interior as part of the National
Wildlife Refuge system','a6241d5f37199f5cd874ddb837fb482f4ed34a96e9369e9131f64989f1d32101','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09a562a137ea06883ca9429bf9aad684f8553e65d2ffd83af78fd5ef9259d0a3',2004,'MX','Mexico','people-and-society',341,'purchasing power parity - $941.2 billion (2003 est.)
1.18% (2004 est.)
1.3% (2003 est.)
purchasing power parity - $9,000 (2003 est.)','c7a9694f4bd7bb19fa134011f1d242827e13d37ec0cfaefb421d6eefea6c6b0b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12f933d0b59df404370fce5e431cf24ff6f17746b1e45c44b763dfc67419fbdf',2004,'FM','Micronesia, Federated States of','people-and-society',342,'purchasing power parity - $277
million
note: GDP is supplemented by grant aid, averaging perhaps $100
million annually (2002 est.)
Moldova
purchasing power parity - $7.792 billion (2003 est.)
-0.02% (2004 est.)
Moldova
0.18% (2004 est.)
1% (2002 est.)
Moldova
6.3% (2003 est.)
purchasing power parity - $2,000
(2002 est.)
Moldova
purchasing power parity - $1,800 (2003 est.)','62516c8090e5d4f57b076a8e371eb9dc16e968861cc113429507ad659b86ed88','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0f94de4902735b20b5f1af21dc92e79dbc98129a4af0a3a19b033b341a7b876',2004,'MC','Monaco','people-and-society',343,'purchasing power parity - $870 million (1999 est.)
0.44% (2004 est.)
NA (2000 est.)
purchasing power parity - $27,000 (1999 est.)','950004aac72dd8f5194a56600e485eb461b035811163bc913fc77dc6cc7fc439','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f11cfa4096796c6b273fbc6c211b9ac581a83e54c36775711aabad4898e03328',2004,'MN','Mongolia','people-and-society',344,'purchasing power parity - $4.882 billion (2003 est.)
1.43% (2004 est.)
5% (2003 est.)
purchasing power parity - $1,800 (2003 est.)','2d8ea5e7ddfb14a671eddae517cd2fe98b3cd2cc030d8181ee359c4a1c4ed03e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b01dab222aeeb714f9cdac5e63503e7df1cf5d20129219aaa63225e3fceff99b',2004,'MS','Montserrat','people-and-society',345,'purchasing power parity - $29 million (2002 est.)
1.03% (2004 est.)
-1% (2002 est.)
purchasing power parity - $3,400 (2002 est.)
overseas territory of the UK
Navassa Island
unincorporated territory of the US; administered by
the Fish and Wildlife Service, US Department of the Interior, from
the Caribbean Islands National Wildlife Refuge in Boqueron, Puerto
Rico; in September 1996, the Coast Guard ceased operations and
maintenance of Navassa Island Light, a 46-meter-tall lighthouse on
the southern side of the island; there has also been a private claim
advanced against the island
Netherlands Antilles
part of the Kingdom of the Netherlands; full
autonomy in internal affairs granted in 1954; Dutch Government
responsible for defense and foreign affairs','2af69d416a9d32495f87cc839b2195d25b58693b1e6788726e5aef6b08652dc5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71dc9e0e23fdc69dcf0cc644090fe937036579f0246f5f2fceb1afb5602a52fb',2004,'MA','Morocco','people-and-society',346,'purchasing power parity - $128.3 billion (2003 est.)
1.61% (2004 est.)
6% (2003 est.)
purchasing power parity - $4,000 (2003 est.)','c9202debb099ce68a6bae8aabf81822b2ca38d98edf30b5a5c0458a420f086c5','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c81d78b82702f3165b0072bfc591d992446bdec14a8d2da0df088b7830155403',2004,'MZ','Mozambique','people-and-society',347,'purchasing power parity - $21.23 billion (2003 est.)
1.22% (2004 est.)
7% (2003 est.)
purchasing power parity - $1,200 (2003 est.)','858f09e204e9e3163f5cc38ffd204304c8ca616e5643822d5e4899cb26045898','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bebdb3b0b72b1316f78913b6e946e0cbf15fed2f115527777ea61b3368dc4cea',2004,'NA','Namibia','people-and-society',348,'purchasing power parity - $13.85 billion (2003 est.)
1.25% (2004 est.)
3.3% (2003 est.)
purchasing power parity - $7,200 (2003 est.)','eb3b207f2c57e99bd02e82659158167aaa830f0bd6e7dee36916052013cbc1ea','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('329fb3d801b6dfbcdc3a6dada5e374740b9a17763322b682601d37d338bfa135',2004,'NR','Nauru','people-and-society',349,'purchasing power parity - $60 million (2001 est.)
1.87% (2004 est.)
NA
purchasing power parity - $5,000 (2001 est.)','70c68f8425619e81395689f5dc8b7296a24acddb635dd0a18f1ff2a56a06246b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddbb38cc4f5f86f0b8ffcb12592a1a23b42f8d803d0a418d32cebb9a391d81c2',2004,'NP','Nepal','people-and-society',350,'purchasing power parity - $38.29 billion (2003 est.)
2.23% (2004 est.)
3% (2003 est.)
purchasing power parity - $1,400 (2003 est.)','b1ee95f113756c91adb9e9cc5799496bfc3af739b8e0e07d3cd53b09ae7082c9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaf6ad0a0e383abb5bb4e3eef57606ef592aa34647f5caf5ff405a9f781dd162',2004,'NL','Netherlands','people-and-society',351,'purchasing power parity - $461.4 billion (2003 est.)
Netherlands Antilles
purchasing power parity - $2.45 billion (2003
est.)
0.57% (2004 est.)
Netherlands Antilles
0.86% (2004 est.)
-0.7% (2003 est.)
Netherlands Antilles
0.5% (2003 est.)
purchasing power parity - $28,600 (2003 est.)
Netherlands Antilles
purchasing power parity - $11,400 (2003 est.)','75eea5631b3596c11be0755b1ea4894fc7d316eca9012edda7249b6b6feacb24','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad153c4af0cf92b4bca639a32e1d6522baf2805103facac4814dc12d255f149f',2004,'NC','New Caledonia','people-and-society',352,'purchasing power parity - $3.158 billion (2003 est.)
1.33% (2004 est.)
NA
purchasing power parity - $15,000 (2001 est.)
overseas territory of France since 1956','357ead0425fa49c4952da9fce17bfa75f992912dc6597a2658a923515cb89b93','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bac57a5f1407231179e98852ee421f4dbac3861ce7b50df5e46b8a9f9f14cab',2004,'NZ','New Zealand','people-and-society',353,'purchasing power parity - $85.34 billion (2003 est.)
1.05% (2004 est.)
3.5% (2003 est.)
purchasing power parity - $21,600 (2003 est.)','c2e808c2709a49c369b43f3fc9e429b7b75daac0ed0da9eb927fa249b5dd5a58','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27f2345e8631980f5bcbef2224a8db719eaa70671064bd3fadebc6ed554d440',2004,'NI','Nicaragua','people-and-society',354,'purchasing power parity - $11.6 billion (2003 est.)
1.97% (2004 est.)
2.3% (2003 est.)
purchasing power parity - $2,300 (2003 est.)','65836a45535fc5d2b6bf979aa308a7766783d75abb8054c8ca36e57c34e43f80','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2186da12c90237e68c69b639ea4efb1221ea2dcb6a8157c3ccb228b8b5609a2d',2004,'NE','Niger','people-and-society',355,'purchasing power parity - $9.062 billion (2003 est.)
2.67% (2004 est.)
3.8% (2003 est.)
purchasing power parity - $800 (2003 est.)','a0f4b1413dae127e7347a1ba83759c407dccd3c6ee1748ed388b54567e972d46','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dd3e80a10b893bb61806777e8fd7fb512044a9d0d1dac1d76245a56f356a8a1',2004,'NG','Nigeria','people-and-society',356,'purchasing power parity - $114.8 billion (2003 est.)
2.45% (2004 est.)
7.1% (2003 est.)
purchasing power parity - $900 (2003 est.)','ba7a18b3daa1e572a97327706739285bae910baaccc807a1a97383eb3cb2fcef','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edd1ff48d0efb31abcafd659b7e76529eeda9134744b63ac00bf571ff6ea6f27',2004,'NU','Niue','people-and-society',357,'purchasing power parity - $7.6 million (2000 est.)
0.01% (2004 est.)
-0.3% (2000 est.)
purchasing power parity - $3,600 (2000 est.)
self-governing in free association with New Zealand since 1974;
Niue fully responsible for internal affairs; New Zealand retains
responsibility for external affairs and defense; however, these
responsibilities confer no rights of control and are only exercised
at the request of the Government of Niue','c4c7fdc263f95f05f7091754752aa4647cc47bc6ccf1116a852f65197d340d2d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d47a9f0faed09f653a5769e102cc5a2ad710ec4e087ba268e5669a52509b6c',2004,'NF','Norfolk Island','people-and-society',358,'purchasing power parity - NA
-0.01% (2004 est.)
NA
purchasing power parity - NA
territory of Australia; Canberra administers
Commonwealth responsibilities on Norfolk Island through the
Department of Environment, Sport, and Territories','ad1af9d328e2f5796a1275b4850d70d80544c917bc6eb4be74ea420cf6a148e0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2436abf746e18af71d8ce5132374b8d2640911efd525665d81b2596b44db31a4',2004,'MP','Northern Mariana Islands','people-and-society',359,'purchasing power parity - $900 million
note: GDP estimate includes US subsidy (2000 est.)
2.71% (2004 est.)
NA
purchasing power parity - $12,500 (2000
est.)
commonwealth in political union with the
US; federal funds to the Commonwealth administered by the US
Department of the Interior, Office of Insular Affairs
Palmyra Atoll
incorporated territory of the US; privately owned, but
administered from Washington, DC, by the Fish and Wildlife Service
of the US Department of the Interior; the Office of Insular Affairs
of the US Department of the Interior continues to administer nine
excluded areas comprising certain tidal and submerged lands within
the 12 nm territorial sea or within the lagoon
Pitcairn Islands
overseas territory of the UK','347135796b1f80f2a703019eb77c9e10c61f0bbcf159d0a0369581d258ddc8ac','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5849c4a7efbfd0652bcfd900370cd9d9a456bd452b690018d957744d6a7db4e7',2004,'NO','Norway','people-and-society',360,'purchasing power parity - $171.7 billion (2003 est.)
0.41% (2004 est.)
0.6% (2003 est.)
purchasing power parity - $37,800 (2003 est.)','4521dbf4c515f3000afda55fd3ae71a3fc16ac4818cd05f7cc20795fc2bc39a6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8e8b0dcb7412e9fdcc0ad714181ac2966601873953a57a4ac2bd384b26fc8cf',2004,'OM','Oman','people-and-society',361,'purchasing power parity - $36.7 billion (2003 est.)
3.35% (2004 est.)
1.1% (2003 est.)
purchasing power parity - $13,100 (2003 est.)','2e9bb341a9a2dd77b5b5c73afe35e99ca44c8d2545c7c310218769f30e89c467','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38071e26e4e3973e9b52655db2549be8e03f204c4682712201a9c04672d209c0',2004,'PK','Pakistan','people-and-society',362,'purchasing power parity - $318 billion (2003 est.)
1.98% (2004 est.)
5.5% (2003 est.)
purchasing power parity - $2,100 (2003 est.)','02cc4498cf2a902257fcc4d4a4fcc39fac6ca0791e6fa3e5c6e6dc4a5a2bbd5f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a5da84960092b5e17a5ce18e29ec752321a212ec35c9b8dfcfc455a19418b90',2004,'PW','Palau','people-and-society',363,'purchasing power parity - $174 million
note: GDP estimate includes US subsidy (2001 est.)
1.46% (2004 est.)
1% (2001 est.)
purchasing power parity - $9,000 (2001 est.)','a4df132c7bc4ead657a8b98685141984db32da74959a2a4921a1f827fe82769d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2334ff6650bc712d371ccc6050c89647c3b58a29554801a7d1103df0cb998f15',2004,'PA','Panama','people-and-society',364,'purchasing power parity - $18.78 billion (2003 est.)
1.31% (2004 est.)
4.1% (2003 est.)
purchasing power parity - $6,300 (2003 est.)','e82300b836a95cd1c69b0b4541947ac14e7e1d5e66cf43a327a307975a5d8fd1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90738888cb419e827a12602b9e50f5a3541d7dab69ba1b6d587d888724f1d2cb',2004,'PG','Papua New Guinea','people-and-society',365,'purchasing power parity - $11.48 billion (2003 est.)
2.3% (2004 est.)
1.4% (2003 est.)
purchasing power parity - $2,200 (2003 est.)','0008a9d80767b5dfcd36df8fb75c5b8ce45b58a1245f82a06595164bd5872914','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b963d66934eeedb6ab263fca71108e8262160fb5f62e1c3ea11de44d75d515f',2004,'PY','Paraguay','people-and-society',366,'purchasing power parity - $28.17 billion (2003 est.)
2.51% (2004 est.)
1.8% (2003 est.)
purchasing power parity - $4,700 (2003 est.)','12b594fbea182ae83163bc408bbc8b893e951671dd2fbc0f30ee91c64f167ad6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b073b00fe5bd0133fe68fb9afde2e87516f44f073656834a7928f849804f0ba',2004,'PE','Peru','people-and-society',367,'purchasing power parity - $146 billion (2003 est.)
1.39% (2004 est.)
4% (2003 est.)
purchasing power parity - $5,100 (2003 est.)','f6453303786437d2110b6dbf6154f9c1a68011c2a9aba699eaa74e0a09ea9013','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8938352a86d60a03b41039e908f172082f201f922c76ff24cae0eb51a8793b5c',2004,'PH','Philippines','people-and-society',368,'purchasing power parity - $390.7 billion (2003 est.)
Pitcairn Islands
purchasing power parity - NA
1.88% (2004 est.)
Pitcairn Islands
-0.013% (2004 est.)
4.5% (2003 est.)
Pitcairn Islands
NA
purchasing power parity - $4,600 (2003 est.)
Pitcairn Islands
purchasing power parity - NA','70db6a84280690c68e062799662f1b344761223804a7fb6664d1a1055476ebc6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef5758ffbec0099ab81706f825e0fc85dd431cf6b217b659f1c9d3b2e6d3a2b',2004,'PL','Poland','people-and-society',369,'purchasing power parity - $427.1 billion (2003 est.)
0.02% (2004 est.)
3.7% (2003 est.)
purchasing power parity - $11,100 (2003 est.)','c73e598894c5b9d8255dc933401c3288abfaaaf21e17dd69bf465d2df5b857c4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de1d670002b3ec93d23b903e9df7cbf6e8f33851243d467a9a735300285a8066',2004,'PT','Portugal','people-and-society',370,'purchasing power parity - $181.8 billion (2003 est.)
0.41% (2004 est.)
-1.3% (2003 est.)
purchasing power parity - $18,000 (2003 est.)','0ad479218d0843de8dba7474f90ca8a3726746a88290e5f0788ea3b55ed3a2ef','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29a8114a3b0ec9df4de7554866b13d60d646c13d09d04e59ed8aee271f269c41',2004,'PR','Puerto Rico','people-and-society',371,'purchasing power parity - $65.21 billion (2003 est.)
0.49% (2004 est.)
1.6% (2003 est.)
purchasing power parity - $16,800 (2003 est.)
commonwealth associated with the US
Reunion
overseas department of France
Saint Helena
overseas territory of the UK','b05179ba6f6653611c7d586f7856c32d744f9bda309fd7c3537cdf0ca31a2f45','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd1493b135de6d05a88fc9f67e1d28811dc885de2873242da8f3eb3d7980dacb',2004,'QA','Qatar','people-and-society',372,'purchasing power parity - $17.54 billion (2003 est.)
Reunion
purchasing power parity - $4.348 billion (2003 est.)
2.74% (2004 est.)
Reunion
1.42% (2004 est.)
8.5% (2003 est.)
Reunion
2.5% (2003 est.)
purchasing power parity - $21,500 (2003 est.)
Reunion
purchasing power parity - $5,800 (2001 est.)','04ba26210e8779365f7cb52cfa792c7d8a1107fe334cafb07730b57508f6a61e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f62ad4ce753f3315e18835f2cadf7737244f43e10371da70dfc36ae629d9dc9',2004,'RO','Romania','people-and-society',373,'purchasing power parity - $155 billion (2003 est.)
Russia
purchasing power parity - $1.282 trillion (2003 est.)
-0.11% (2004 est.)
Russia
-0.45% (2004 est.)
4.9% (2003 est.)
Russia
7.3% (2003 est.)
purchasing power parity - $7,000 (2003 est.)
Russia
purchasing power parity - $8,900 (2003 est.)','b798b68e3cfc2874f0b5f92fa51163bb529686b64d1d9ea4b56fc75bc0b32db9','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ec992d8f64094ec7f3f9e4ef8205a0b6410977f36a7a98f4292109231dff74c',2004,'RW','Rwanda','people-and-society',374,'purchasing power parity - $10.11 billion (2003 est.)
Saint Helena
purchasing power parity - $18 million (1998 est.)
1.82% (2004 est.)
Saint Helena
0.62% (2004 est.)
3.5% (2003 est.)
Saint Helena
NA
purchasing power parity - $1,300 (2003 est.)
Saint Helena
purchasing power parity - $2,500 (1998 est.)','3cb2a90fea1092bcac1577e02be4eb45304f4448913a7dd93a7a5d8e6d04ccab','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d11cc4de4428e8cad9123f79932daf0b0a5f0bb65c1c2fce59a20b79a984081b',2004,'KN','Saint Kitts and Nevis','people-and-society',375,'purchasing power parity - $339 million (2002
est.)
0.25% (2004 est.)
-1.9% (2002 est.)
purchasing power parity - $8,800 (2002 est.)','5796ecba10f2db00dbe83f7ae8cb7a4bc9ab756641785a9b5a3b1fc15c6afbad','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7979c9d5195b6d0874d7057a0fec2582f688d75b5b7f69588ce2f8bd6881a1d3',2004,'LC','Saint Lucia','people-and-society',376,'purchasing power parity - $866 million (2002 est.)
1.27% (2004 est.)
3.3% (2002 est.)
purchasing power parity - $5,400 (2002 est.)','0b302c96d4e97256c22be6f7da93c63ba2a1aaf60450f3347711da8d2254a2dc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cf4035aced72b79a38e1bf8354d3b89e57103c04a9a91f908f37ae4ee4e7852',2004,'PM','Saint Pierre and Miquelon','people-and-society',377,'purchasing power parity - $48.33 million -
supplemented by annual payments from France of about $60 million
(2003 est.)
0.26% (2004 est.)
NA
purchasing power parity - $6,900 (2001
est.)
self-governing territorial collectivity of','cc3faf1bb1827e37c2eb4fe3a100bf8fd9d0c2b00d313dccd31fe1380a146343','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6558eee32106bb99d7c994d734667dcf2a655acc4705e1a54ec3bb946b421fb',2004,'VC','Saint Vincent and the Grenadines','people-and-society',378,'purchasing power parity - $342
million (2002 est.)
0.31% (2004 est.)
0.7% (2002 est.)
purchasing power parity - $2,900
(2002 est.)','6ebb14e4ca66dca503a1263d3ca301bd0c68eaba55d14627a414296ace94abf2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd2194558adf3a5c19329b4238efcedf13e467d27d7d4d81790dad6946a7591',2004,'WS','Samoa','people-and-society',379,'purchasing power parity - $1 billion (2002 est.)
-0.25% (2004 est.)
5% (2002 est.)
purchasing power parity - $5,600 (2002 est.)','fe738a99ac26a65a328d8e662b7f92a4c03acbcfca0ecdb630d8405342e563a1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c86d4e917946b9409fa83b08414b363f919a68d98c5ad77c616fad3dd25623f6',2004,'SM','San Marino','people-and-society',380,'purchasing power parity - $940 million (2001 est.)
1.33% (2004 est.)
7.5% (2001 est.)
purchasing power parity - $34,600 (2001 est.)','f6be4c3219c1478c20a3d79124d5f3d2255fb3fd3eb618f35d8746acb6b11507','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d58c04b4e23055d59104814f53ac28d23e98073f57d5fc12af1c533c61c49664',2004,'ST','Sao Tome and Principe','people-and-society',381,'purchasing power parity - $214 million (2003
est.)
3.18% (2004 est.)
5% (2003 est.)
purchasing power parity - $1,200 (2003 est.)','4fe9d00b2e5ce7b4719fc7f0bdf6f3f60cab2e4fd595830e32d64ac272aeea9e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('519aa5f43c26194d56d973b1f42c38ce5b6c4d1e66e858d48520fcdcba1606fe',2004,'SA','Saudi Arabia','people-and-society',382,'purchasing power parity - $287.8 billion (2003 est.)
2.44% (2004 est.)
5.3% (2003 est.)
purchasing power parity - $11,800 (2003 est.)','c4c9975669c840feb9614be581f2726d340d2c488073b6622596e93224500e17','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128bc47f4c0782f20634aac5ccea2d02080d373ff4204cb1dbd30fb448d53c88',2004,'SN','Senegal','people-and-society',383,'purchasing power parity - $17.09 billion (2003 est.)
Serbia and Montenegro
purchasing power parity - $23.89 billion (2003
est.)
2.52% (2004 est.)
Serbia and Montenegro
0.03% (2004 est.)
5.5% (2003 est.)
Serbia and Montenegro
1.5% (2003 est.)
purchasing power parity - $1,600 (2003 est.)
Serbia and Montenegro
purchasing power parity - $2,200 (2003 est.)','b373aed87921ff0340e4e2e565ca505ab28ce3a0dc8651bf5d18ffb9c90169fd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfc408a95f1b58fb45b9538bcff40cd3c4fe5355486d1971edb0172ec74e00f5',2004,'SC','Seychelles','people-and-society',384,'purchasing power parity - $626 million (2002 est.)
0.45% (2004 est.)
1.5% (2002 est.)
purchasing power parity - $7,800 (2002 est.)','5633e36fb82f820b38b456ae53b2aac5bc95dd9f318dc7bba532773803a73058','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ff363f0952153f689e2e959cf0cfa2670f691b138fe7c020d9ef89fff645b42',2004,'SL','Sierra Leone','people-and-society',385,'purchasing power parity - $3.057 billion (2003 est.)
2.27% (2004 est.)
6.5% (2003 est.)
purchasing power parity - $500 (2003 est.)','da607c26672026ac1a414106a4eeae6d9cd0e7ce77114714bae20ad1aa758d51','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5957d9b1b3be650ae414b03edc99d42755f11c3846e5b965a914439d829200ae',2004,'SG','Singapore','people-and-society',386,'purchasing power parity - $109.4 billion (2003 est.)
1.71% (2004 est.)
1.1% (2003 est.)
purchasing power parity - $23,700 (2003 est.)','1acfb2e5d9e59c81cae15fd26cdd68aed248b3ac1e7def97582afc2362ebb60b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6475001f82ed44354b1d944ccd34bacf44e8b39197241e4f5eec14494d0beff6',2004,'SK','Slovakia','people-and-society',387,'purchasing power parity - $72.29 billion (2003 est.)
0.14% (2004 est.)
3.9% (2003 est.)
purchasing power parity - $13,300 (2003 est.)','a9a61705006cc447213cdbd5b6acc6f43858dd7a48724bfbd3dde72ab98da47f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12212a519be0aa2908f699b935380e2616faaba6fd5929511770c21330607f50',2004,'SI','Slovenia','people-and-society',388,'purchasing power parity - $36.82 billion (2003 est.)
-0.01% (2004 est.)
2.3% (2003 est.)
purchasing power parity - $19,000 (2003 est.)','31eca4c992195ebff0a64f5e006090620652e370756c56d226461bf277d813bd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11bca93faf4a1d444c9653cf0b407db606894040e3aecb52235660f0e8cdd496',2004,'SB','Solomon Islands','people-and-society',389,'purchasing power parity - $800 million (2001 est.)
2.76% (2004 est.)
-10% (2001 est.)
purchasing power parity - $1,700 (2001 est.)','3168184387a0ec4d39246f4bbdee520c7c5e3c65c0311e4b3b8f972695bf04f1','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7ab1f615c8ef05852ef99c9008e45167f9dc49243d8881d5773a717a1ac126a',2004,'SO','Somalia','people-and-society',390,'purchasing power parity - $4.361 billion (2003 est.)
3.41% (2004 est.)
2.1% (2003 est.)
purchasing power parity - $500 (2003 est.)','e5a14cb1e2e5d4ae220c6886868e7a0cdaad25ef906623efaff5f4bfcfb19793','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('894f25cd71e65296f296f27b9837a1ecb727123ec88b6bcb4f7b940375616dd2',2004,'ZA','South Africa','people-and-society',391,'purchasing power parity - $456.7 billion (2003 est.)
-0.25% (2004 est.)
1.9% (2003 est.)
purchasing power parity - $10,700 (2003 est.)','37e23537a7a7c5eaa52c120bfe812b65882d74f6f02c9fc9f3a2130892cba092','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('618a09deaf64e19a7cf443c7f71c0e39e7da8a3ca3ade3add8279ebba89d07d1',2004,'ES','Spain','people-and-society',392,'purchasing power parity - $885.5 billion (2003 est.)
0.16% (2004 est.)
2.4% (2003 est.)
purchasing power parity - $22,000 (2003 est.)','4cfce81d488863f71cc64471737d11e44af1aad52e5f6c87791986cae0acc5f4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a779e0337c6a441dc9b3fd12ce766ec176e615d4543d2ad7dcff889a27a498',2004,'LK','Sri Lanka','people-and-society',393,'purchasing power parity - $73.7 billion (2003 est.)
0.81% (2004 est.)
5.5% (2003 est.)
purchasing power parity - $3,700 (2003 est.)','32aa1bcdafc390199002b572dab3972c40c8d78a2dcc4892b719ed64e8f305dc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0699d85b80e03a76cbdd0c4d486fc7b8bac764e71865b60bddadbbb114a62454',2004,'SD','Sudan','people-and-society',394,'purchasing power parity - $70.95 billion (2003 est.)
2.64% (2004 est.)
5.9% (2003 est.)
purchasing power parity - $1,900 (2003 est.)','958f62a2a41dd900ddf369edfea36f1a02a50479cd98838ade8758ccf4b3993b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7505c508d5879323856b5bf9d9a7c3a64628ccefd3bece2d6f9d13c6f85004e2',2004,'SR','Suriname','people-and-society',395,'purchasing power parity - $1.752 billion (2003 est.)
Svalbard
purchasing power parity - NA
Swaziland
purchasing power parity - $5.702 billion (2003 est.)
0.31% (2004 est.)
Svalbard
-0.02% (2004 est.)
Swaziland
0.55% (2004 est.)
5% (2003 est.)
Svalbard
NA
Swaziland
2.2% (2003 est.)
purchasing power parity - $4,000 (2003 est.)
Svalbard
purchasing power parity - NA
Swaziland
purchasing power parity - $4,900 (2003 est.)','49829db0f4e5b63b9741cf587bb8f38efb2965489726f78429985c791a69bade','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf7d6be5a7992a66a8302a5db418ea55df0fb1bfdd784fb6b138175e810b4e8',2004,'SE','Sweden','people-and-society',396,'purchasing power parity - $238.3 billion (2003 est.)
0.18% (2004 est.)
1.7% (2003 est.)
purchasing power parity - $26,800 (2003 est.)','dd48faaa5bb030800373dec23f4e527451410d935a77f6919b7364a9abf7bcf0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37d8cab2af173511b81e1a0f6e03317d0635680c168d45396a28369da3319cc0',2004,'CH','Switzerland','people-and-society',397,'purchasing power parity - $239.3 billion (2003 est.)
Syria
purchasing power parity - $58.01 billion (2003 est.)
Taiwan
purchasing power parity - $528.6 billion (2003 est.)
0.54% (2004 est.)
Syria
2.4% (2004 est.)
Taiwan
0.64% (2004 est.)
-0.5% (2003 est.)
Syria
0.9% (2003 est.)
Taiwan
3.2% (2003 est.)
purchasing power parity - $32,700 (2003 est.)
Syria
purchasing power parity - $3,300 (2003 est.)
Taiwan
purchasing power parity - $23,400 (2003 est.)','ab2d7ea9ec868c404afc758dce82f7cb6049ac92805e6e2ad7ff7665c18e4c20','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee76603cd7fb6e32b49abbcf82b35c0fbf966ebba453104e06907d1b286c1f59',2004,'TJ','Tajikistan','people-and-society',398,'purchasing power parity - $6.812 billion (2003 est.)
Tanzania
purchasing power parity - $21.58 billion (2003 est.)
2.14% (2004 est.)
Tanzania
1.95% (2004 est.)
7% (2003 est.)
Tanzania
5.2% (2003 est.)
purchasing power parity - $1,000 (2003 est.)
Tanzania
purchasing power parity - $600 (2003 est.)','b1c49880fa311c11ba200cfc84afed086ed755c0e1dd957e5532e7418a5bba5e','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa6a656863d2776c38adc3e74db3f15872426de81897de69ceb3a67ac386c442',2004,'TH','Thailand','people-and-society',399,'purchasing power parity - $477.5 billion (2003 est.)
0.91% (2004 est.)
6.7% (2003 est.)
purchasing power parity - $7,400 (2003 est.)','b6c30fc259135f4a26cc5152958a3bbf9f49f329496409e35e47316c9e1ff5f3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b3f3be1c14f39b54b81019dcad77a5f57e8318dcb0e7fb579137340eb413498',2004,'TG','Togo','people-and-society',400,'purchasing power parity - $8.257 billion (2003 est.)
2.27% (2004 est.)
3.3% (2003 est.)
purchasing power parity - $1,500 (2003 est.)','9019e73f1323497bfff6c32459931f70159daffe890fcbf1be554ed4b4a851f4','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e198b2bf20776b06be820ef001eb9960f2e68a795a8c32e203a274e11c7a6e86',2004,'TK','Tokelau','people-and-society',401,'purchasing power parity - $1.5 million (1993 est.)
-0.01% (2004 est.)
NA
purchasing power parity - $1,000 (1993 est.)
self-administering territory of New Zealand; note -
Tokelauans are drafting a constitution and developing institutions
and patterns of self-government as Tokelau moves toward free
association with New Zealand
Tromelin Island
possession of France; administered by a high
commissioner of the Republic, resident in Reunion','7354450dd65de8a171b956f029a3cc34fd07100d2883d99c229969f3531ff93d','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44223f3f77eabaf1094f82b90d128d04680b21339a58c852beb5e180520f615b',2004,'TO','Tonga','people-and-society',402,'purchasing power parity - $236 million (2001 est.)
1.94% (2004 est.)
3% (2001 est.)
purchasing power parity - $2,200 (2001 est.)','58bbcfdf19c9619f8f768541f8ebdec36edef122863bfaeefe87eb06417a4701','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e6ef614a9687080f94f586aa0f954a78f19b1e6eaacb8c94c29704348dcb2d3',2004,'TT','Trinidad and Tobago','people-and-society',403,'purchasing power parity - $10.52 billion (2003
est.)
-0.71% (2004 est.)
3.7% (2003 est.)
purchasing power parity - $9,500 (2003 est.)','1ed9d30c7a0aa8d0335cb7d5620769f559bba8d3efad37bba7bafac27c572be2','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('956ecb4555d8f10d5dc2a6cb2b854e5dd0b15448927bd39d1da01ed93eedb201',2004,'TN','Tunisia','people-and-society',404,'purchasing power parity - $68.23 billion (2003 est.)
Turkey
purchasing power parity - $458.2 billion (2003 est.)
1.01% (2004 est.)
Turkey
1.13% (2004 est.)
5.1% (2003 est.)
Turkey
5.8% (2003 est.)
purchasing power parity - $6,900 (2003 est.)
Turkey
purchasing power parity - $6,700 (2003 est.)','1874b3f4ff93bf11c3ccf401373eff172eb39fed95d8a4b5d1d2342dbe9f5add','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51f369cb0dbb976d71d3dc864b35897ab614a369683e04f4b26e7d29449fea6c',2004,'TM','Turkmenistan','people-and-society',405,'purchasing power parity - $27.88 billion (2003 est.)
1.81% (2004 est.)
23.1% (2003 est.)
purchasing power parity - $5,800 (2003 est.)','0ba058cc43eed809e545ff469ccda9d439e7ce9f0b33b96cafb875bf87f7de61','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09f4fec74f23687497659f2d458ce9c144e3c1e76a3d142e074a19fb77466f87',2004,'TV','Tuvalu','people-and-society',406,'purchasing power parity - $12.2 million NA (2000 est.)
1.44% (2004 est.)
3% (2000 est.)
purchasing power parity - $1,100 (2000 est.)','16ecf302c0293c19776d4fa8b86ab485121b28ece3bbbd74a244dc5a97185f6f','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f3063ce18cb9a880ea4d4635a5d9a281da96ed4c2c78cd0306907e1ebea6f2',2004,'UG','Uganda','people-and-society',407,'purchasing power parity - $36.1 billion (2003 est.)
2.97% (2004 est.)
4.4% (2003 est.)
purchasing power parity - $1,400 (2003 est.)','0380a82c78f3fe8fa95113932bc376774de0ccbe6b4a55c583e802bd2f18de1b','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f748f79154d7b59a5923f149e24c76a635482924f5ded3a0ee3ae3d8bc2bc3e',2004,'UA','Ukraine','people-and-society',408,'purchasing power parity - $260.4 billion (2003 est.)
-0.66% (2004 est.)
9.4% (2003 est.)
purchasing power parity - $5,400 (2003 est.)','a3a75c796e948e895f0f401080ab337564de71543a42053d48962fcd65aca5f3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('220ea051ff7515bdfcb4b06eb28758770aa15d0e7341268eb25a2fd6ae59be29',2004,'AE','United Arab Emirates','people-and-society',409,'purchasing power parity - $57.7 billion (2003
est.)
1.57% (2004 est.)
5.2% (2003 est.)
purchasing power parity - $23,200 (2003 est.)','67b50fa50e2a4c2f2ea34408843b56d9aaee24a26f82174827a590d164067ca0','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b4470f703f0137737268dd01c412cbb4770e13ba94a22983999b630fc011b4f',2004,'GB','United Kingdom','people-and-society',410,'purchasing power parity - $1.666 trillion (2003 est.)
0.29% (2004 est.)
2.2% (2003 est.)
purchasing power parity - $27,700 (2003 est.)','64e6ee1710c5d7f878bc55920988742e46b3c122f1ec2a42d1935471fbaee385','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ea2479125b7ffb5c0cb092c6b8cbb0974e010b615c90f7d81ecec5c5d05950',2004,'US','United States','people-and-society',411,'purchasing power parity - $10.99 trillion (2003 est.)
0.92% (2004 est.)
3.1% (2003 est.)
purchasing power parity - $37,800 (2003 est.)','6446c8fb19e081e275d0c8df64b125a8e1c92f113a72e4dd0dff4b8808c952ea','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1f2dbaca57f6514d2866793c047105002fb90900614a575e98fdb0b01cdb0d',2004,'UY','Uruguay','people-and-society',412,'purchasing power parity - $43.67 billion (2003 est.)
0.51% (2004 est.)
2.5% (2003 est.)
purchasing power parity - $12,800 (2003 est.)','ab90bfdf0b080079eb21c197cde0bf2d403ecdf128cc3354d53168ab4cc430f6','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bec1afe98dc0f393adb58e2179852693ad6785248fa93bbf69d102bdcd36aa4',2004,'UZ','Uzbekistan','people-and-society',413,'purchasing power parity - $43.99 billion (2003 est.)
1.65% (2004 est.)
3.1% (2003 est.)
purchasing power parity - $1,700 (2003 est.)','1332c50f59a4c3cb932fd9be38a7c320a80527b3475e9638b715464219bc17bc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d48d70e714c217792e60715a119955db8bda0204da76c2cfb0693494f91b2992',2004,'VU','Vanuatu','people-and-society',414,'purchasing power parity - $563 million (2002 est.)
Venezuela
purchasing power parity - $117.9 billion (2003 est.)
Vietnam
purchasing power parity - $203.7 billion (2003 est.)
Virgin Islands
purchasing power parity - $2.5 billion (2002 est.)
1.57% (2004 est.)
Venezuela
1.44% (2004 est.)
Vietnam
1.3% (2004 est.)
Virgin Islands
-0.05% (2004 est.)
-0.3% (2002 est.)
Venezuela
-9.2% (2003 est.)
Vietnam
7.2% (2003 est.)
Virgin Islands
2% (2002 est.)
purchasing power parity - $2,900 (2002 est.)
Venezuela
purchasing power parity - $4,800 (2003 est.)
Vietnam
purchasing power parity - $2,500 (2003 est.)
Virgin Islands
purchasing power parity - $17,200 (2002 est.)','268d0e1c80196fec517628bb85a6b772de2ea292ed801d2c835614ca79ac1a28','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a662297c343d81e51f2653eaa057cedf0bbda0a64352b704ed0c87f6dd8cc4cc',2004,'WF','Wallis and Futuna','people-and-society',415,'purchasing power parity - $57.59 million (2003
est.)
West Bank
purchasing power parity - $1.7 billion (2002 est.)
NA
West Bank
3.21% (2004 est.)
NA
West Bank
-22% (2002 est.)
purchasing power parity - $3,700 (2001 est.)
West Bank
purchasing power parity - $800 (2002 est.)
overseas territory of France
This page was last updated on 10 February, 2005
======================================================================
@2007 Diplomatic representation from the US','1773be641533bebb34556a391da4b03a0d782e15d2df8514a4aa5a5aad3341a3','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2698f937d411c8b7e3b43c719176fe13a4c3290d680fb1209a85f4efcdff7277',2004,'EH','Western Sahara','people-and-society',416,'purchasing power parity - NA
World
GWP (gross world product) - purchasing power parity - $51.48
trillion (2003 est.)
NA
World
1.14% (2004 est.)
NA
World
3.8% (2003 est.)
purchasing power parity - NA
World
purchasing power parity - $8,200 (2003 est.)','86f95137a13a998f5f68d4e9eaf2faec47fdff7cfb3bec444d3bc44fe56bac63','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7fa5a50bd527bba523e200c4f6a723f75d8d4b735f437cb7d8382b7609afd7f',2004,'YE','Yemen','people-and-society',417,'purchasing power parity - $15.09 billion (2003 est.)
3.44% (2004 est.)
2.8% (2003 est.)
purchasing power parity - $800 (2003 est.)','5f5a1cc20fbb3d2fab4293f28e540191506949717ef855b9c938f5ce9637f5fb','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a7219865e6256fae51e5d567769c0d2dd85a8cb7706630800a8e080029d8710',2004,'ZM','Zambia','people-and-society',418,'purchasing power parity - $8.596 billion (2003 est.)
1.47% (2004 est.)
4% (2003 est.)
purchasing power parity - $800 (2003 est.)','26c2331bbe2a26326eeeb63738849aee8167085c25f4960292322bc49c28a6cd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1384a12209d5bec8dc35c9d3fd6708dfb0b31191f7dade0ec7ca3851970b190',2004,'BV','Bouvet Island','people-and-society',419,'territory of Norway; administered by the Polar
Department of the Ministry of Justice and Police from Oslo','a602d22c9c2afea39d62ac445c6985ef01fa76486b333f2b4b13ad104c4d49dd','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b64f4b9758b6b1878436cef37090c0fef65f5c92c574d20bbfe564b36877a2b9',2004,'IO','British Indian Ocean Territory','people-and-society',420,'overseas territory of the UK;
administered by a commissioner, resident in the Foreign and
Commonwealth Office in London
British Virgin Islands
overseas territory of the UK; internal
self-governing
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Gene B. CHRISTY
embassy: Third Floor, Teck Guan Plaza, Jalan Sultan, Bandar Seri
Begawan
mailing address: PSC 470 (BSB), FPO AP 96507
telephone: [673] (2) 229670
FAX: [673] (2) 225293','5a94b1d60d16e8e19e9b30595fc5aa14501ea8bdaa80b6fb397b937e62b7554c','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc4a4ffa32bf6cea883b0faa2592ce3dd8e9605da66f301eeebce78d24f6633a',2004,'HM','Heard Island and McDonald Islands','people-and-society',421,'territory of Australia;
administered from Canberra by the Australian Antarctic Division of
the Department of the Environment and Heritage
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Ambassador (vacant)
embassy: Villa Domiziana, Via delle Terme Deciane 26, 00153 Rome
mailing address: PSC 59, Box 66, APO AE 09624
telephone: [39] (06) 4674-3428
FAX: [39] (06) 575-8346','c720d7cddca9e2694c18fc97b230290e0e3a68e885210f549960ab46dad3d734','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ba926117de716297179674d9c61014ed4808c40737ce68822dea5a43708e23',2004,'GS','South Georgia and the South Sandwich Islands','people-and-society',422,'overseas territory of
the UK, also claimed by Argentina; administered from the Falkland
Islands by a commissioner, who is concurrently governor of the
Falkland Islands, representing Queen ELIZABETH II; Grytviken,
formerly a whaling station on South Georgia, is a scientific base
Svalbard
territory of Norway; administered by the Polar Department
of the Ministry of Justice, through a governor (sysselmann) residing
in Longyearbyen, Spitsbergen; by treaty (9 February 1920)
sovereignty was awarded to Norway','7e971d51ab96a582acbf1aa2eb6d17adb08c5a590ed34379f74ebe4d95de64bc','internet-archive','theciaworldfactb27559gut','txt','432c120ecf9e079878048dfc50ebd6cc723a78a5b968e74eaf330e4a28ebc624','https://archive.org/download/theciaworldfactb27559gut/27559.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

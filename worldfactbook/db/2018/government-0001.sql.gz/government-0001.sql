SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88fbcf0006fc04bbd2bd7723deecfe2711cda114aab65cdc8424c67f7b0c54cd',2018,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and ci vil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts :
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
ey ais National Assembly and Senate (1/3 of seats) (October 1973); Presidential
0
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influenti a? force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO. IMCO, IMF, ITU, NATO, OECD, Regional
rather has Development, Seabeds Committee (observer), U.N., UNESCO,
447
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
Sere','49099b5e9c45b3b5d46175efa1d3065c75b0f852d14bdef354a8a20e1a861556','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d5afe7e04b2927aff73ec5c37b66c6122161ecf1fcfdbb5c32289ad4aa93fb7',2018,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
_ Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
mar erhse National Assembly and Senate (1/3 of seats) (October 1973); Presidential
1980
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
Peopic''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Repiblican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party 1]]lega]
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
345
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998','ab13b7d52498cd92944d61b57e729cf5486b777d25f34bb9dbaa98cdf50e7cd0','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d51affaf4190b83c68246c15fb5dfdae5fd1b1a0616a7bafed095a5e52ebc067',2018,'UY','Uruguay','government',5,'Legal name: Republic of Turkey
210
Type: republic
‘Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
- members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
- Government leaders: President Fahri Koruturk, Prime
Minister Bulent Ecevit
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977,
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971 and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF,
1O0C, IPU, ITC, ITU, NATO, OECD, Regional Coopera-
tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG, WTO','41fba0988e8c7d82b7162fa89ea52dde1c9f7a425df0650d26b34f629e768764','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4c5d1b70db8c270f45a4a18f532b89c2047562bff25d8166d53ddc8fd52e85',2018,'TV','Tuvalu','government',10,'Legal name: Tuvalu
Type: independent state within commonwealth
Capital: Funafuti .
House of Assembly: eight members
Government leader: Prime Minister Toalipi Lauti','819e66a045ff3d1eecf365ac3f3e9f61688709035be878b92e320ed52bed0b56','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29b3248612200d3acad624e640aa8f081af610f41dfffceb5f40028baa9475ea',2018,'TH','Thailand','government',4,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory IC]
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; Prime
Minister Bulent Ecevit
Suffrage: universal over age 2]
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977;
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
Democratic Party (DP), Faruk Sukan; Republican Reliance
Party (RRP), Turhan Feyzioglu; Nationalist Action Party
(NAP), Alpaslan Turkes; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government-in March 1971 and -
remains an influential force in national affairs
Member of: ASSIMER, Council of Europe, EC (associate
member), ECOSOC, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF, IOOC, IPU,
ITC, ITU, NATO, OECD, Regional’ Cooperation for
Development, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO','ee13dc06ddd6e05c7c25be75fec842843c31b043d0bef5dd2fc66a050603ff16','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc4f72d6a4e5c2f71797b400fe6224b98e45009d662d65f5503bbc2ea3208c3c',2018,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Acting Prime Minister Ferit Melen
Suffrage: universal over age 21
Elections: National Assembly (1973); Presidential (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party eh Bulent Ecevit; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyziogiu; New Turkey Party (NIP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbas{; Unity Party (UP), Mustafa Timisi; Republican Party (RP), Kemal
Satir (formed in 1972); Communist Party illegal
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% Reliance Party, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Other political or pressure groups: military overthrew government in 1960, forced
resignation of Demirel government in March 1971 and remains the dominant
force behind the new government
437
SECRER-
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRET.
GOVERNMENT (cont''d):
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECO, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO','f4f1ddb6b130a5df944f2a48ea3a62bd2ed409297de9eded809ce7b08c85e07a','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0052393b4daeb001df874a75a91357a9f97f413a2e52086e5574017f0661e89',2018,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961, judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament, Prime Minis-
ter appointed by President from members of parliament,
Prime Minister is effective executive, cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; Prime
Minister Bulent Ecevit
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977;
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
~SEGREL
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971 and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
IGAC, ICAO, IDA, IEA, IFC, 1HO, ILO, IMCO, IMF,
1OOC, 1PU, ITC, ITU, NATO, OECD, Regional Coopcra-
tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG, WTO','2767abfc309d869870d586c4b894db2fbcbbefba5816fbf276efac70f3bc04af','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2dbc81d655b31555e89edc0c4f5616c83b85893a3fab09661713fa51e3b9230',2018,'','','raw',1,'C ENTRAL Approved for Release: 2022/12/08 C06979333
winact Us
INTELLIGENCE
AGENCY
English
Library
THE WORLD FACTBOOK
La ae APPENDICES | FAQs (../docs/faqs.html) | CONTACT
Ch
THE WORLD FACTBOOK ARCHIVE (/library/publications/download)
North America :: Mexico & (../geos/print_mx.htm))
PAGE LAST UPDATED ON SEPTEMBER 10, 2020
(_/attachments/summaries/MX-summary.pdf)
(../attachments/maps/MX-map.iog.
"sho Tyuanay Vex calli ay?
Erna Ro
UNITED STATES tls
Guif of oa
(../attachmentg
ONE-PAGE|
SUMMARY i..
% opolobampo = —-_Torre6n
Culilacén *
lan
TRAVEL - NORTH
FACTS (../alta - PACIFIC : Aguascatientes, Potosi ‘i ms
‘| Puarto Leén pico
OCEAN . A Vallarta, if ie Querdiard bance
. Guadalaiars MEXICO CITY Grrovere
1 ISAS *” anzanilio” Toluca® ™ ‘3 Veractuz
REVILLAGICEDO . . . Puebla Yolen:
Jumptodepioe27608 FFA5T4G GIRt4G TH LASTP4AS TA7PG7H SPINS THBAAy FEBTA-4599 - /
Approved for Release: 2022/12/08 C06979333
e« Open All
« Close All Approved for Release: 2022/12/08 C06979333
introduction :: Mexico
Background (../docs/notesanddefs.html#325): This entry usually highlights major historic events and current issues and may include a
statement about one or two key future trends.
(_/fields/325.htmi#MX)
The site of several advanced Amerindian civilizations - including the Olmec, Toltec, Teotihuacan, Zapotec, Maya, and Aztec - Mexico
was conquered and colonized by Spain in the early 16th century. Administered as the Viceroyalty of New Spain for three centuries, it
achieved independence early in the 19th century. Elections held in 2000 marked the first time since the 1910 Mexican Revolution that
an opposition candidate - Vicente FOX of the National Action Party (PAN) - defeated the party in government, the Institutional
Revolutionary Party (PRI). He was succeeded in 2006 by another PAN candidate Felipe CALDERON, but Enrique PENA NIETO
regained the presidency for the PRI in 2012. Left-leaning antiestablishment politician and former mayor of Mexico City (2000-05) Andres
Manuel LOPEZ OBRADOR, from the National Regeneration Movement (MORENA), became president in December 2018.
The global financial crisis in late 2008 caused a massive economic downturn in Mexico the following year, although growth returned
quickly in 2010. Ongoing economic and social concerns include low real wages, high underemployment, inequitable income distribution,
and few advancement opportunities for the largely indigenous population in the impoverished southern states. Since 2007, Mexico''s
powerful drug-trafficking organizations have engaged in bloody feuding, resulting in tens of thousands of drug-related homicides.
Geography :: Mexico
Location (../docs/notesanddefs.html#276): This entry identifies the country''s regional location, neighboring countries, and adjacent
bodies of water.
Es
(. fields/276. htmi#Mx)
North America, bordering the Caribbean Sea and the Gulf of Mexico, between Belize and the United States and bordering the North
Pacific Ocean, between Guatemala and the United States
Geographic coordinates (../docs/notesanddefs.html#277): This entry includes rounded latitude and longitude figures for the centroid or
center paint of a country expressed in degrees and minutes; it is based on the locations provided in the Geographic Names Server
(GNS), maintained by the National Geospatial-Intelligence Agency on behaif of the US Board on Geographic Names.
_(..fields/277.htmi#MXx)
23 00 N, 102 00 W
Map references (../docs/notesanddefs.html#278): This entry includes the name of the Factbook reference map on which a country may
be found. Note that boundary representations on these maps are not necessarily authoritative. The entry on Geographic coordinates
ee be helpful in finding some smaller countries.
LEM
(../fields/278.html#MX)
North America
Area (../docs/notesanddefs.html#279): This entry includes three subfields. Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is ‘the sum of the surfaces of all inland water bodies,
such as lakes, reservoirs, or rivers, as delimited by international boundaries and/or coastlines.
(..fields/279.html#MX)
total: 1,964,375 sq km
land: 1,943,945 sq km
water: 20,430 sq km
country comparison to the world: 15 (../fields/279rank.html#MX)
Area - comparative (../docs/notesanddefs.html#280): This entry provides an area comparison based on total area equivalents. Most
entities are compared with the entire US or one of the 50 states based on area measurements (1990 revised) provided by the US
Bureau of the Census. The smaller entities are compared with Washington, DC (178 sq km, 69 sq mi) or The Mall in Washington, DC
(0.59 sq km, 0.23 sq mi, 146 acres).
(./fields/280.htmt#MX)
slighily less than three times the size of Texas
Area eompatieen map:
Land boundaries (../docs/notesanddefs.html#281): This entry contains the total length of all land boundaries and the individual lengths
for each of the contiguous border countries. When available, offi icial lengths published by national statistical agencies are used.
+QPRtTNZAPIAGS TIGAE4IG GtAt4G tH cGStF45 THPAFA PBSS THORPG FASTA-4E 97 /
Approved for Release: 2022/12/08 C06979333
Because surveying methods may differ ~~ ntry border lengths reported by contiguous ¢~""~ies may aier.
Approved for Release: 2022/12/08 C06979333
(. Mields/281 .tml#MX) -
total: 4,389 km
border countries (3): Belize 276 km, Guatemala 958 km, US 3155 km
Coastline (../docs/notesanddefs.html#282): This entry gives the total length of the boundary between the land area (including islands)
and the sea.
(..fields/282.htmi#MX)
9,330 km
Maritime claims (../docs/notesanddefs.htmi#283): This entry includes the following claims, the definitions of which are excerpted from
the United Nations Convention on the Law of the Sea (UNCLOS), which alone contains the full and definitive descriptions: territorial
sea - the sovereignty of a coastal state extends beyond its land territory and internal waters to an adjacent belt of sea, described as the
territorial sea in the UNCLOS (Part Il); this sovereignty extends to the air space over the territorial sea as well as its underlying s. . .
more (../docs/notesanddefs.html#283)
(..ffields/283.html#MX)
territorial sea: 12 nm
exclusive economic zone: 200 nm
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
Climate (../docs/notesanddefs.html#284): This entry includes a brief description of typical weather regimes throughout the year; in the
Word entry only, it includes four subfields that describe climate extremes:ten driest places on earth (average annual precipitation)
describes the annual average precipitation measured in both millimeters and inches for selected countries with climate extremes. ten
wettest places on earth (average annual precipitation) describes the annual average precipitation measured in both millimeters andi. .
. more (../docs/notesanddefs.html#284)
(../fields/284.html#MX) :
varies from tropical to desert
Terrain (../docs/notesanddefs.html#285): This entry contains a brief description of the topography.
(../fields/285.htmi#MX)
high, rugged mountains; low coastal plains; high plateaus; desert
Elevation (../docs/notesanddefs.html#407): This entry includes the mean elevation and elevation extremes, lowest point and highest
point.
(..fields/407.htmi#MX)
mean elevation: 1,111 m
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,636 m
Natural resources (../docs/notesanddefs.html#287): This entry lists a country''s mineral, petroleum, hydropower, and other resources of
commercial importance, such as rare earth elements (REEs). In general, products appear only if they make a significant contribution to
the economy, or are likely to do so in the future.
(..fields/287 htmi#MX)
petroleum, silver, antimony, copper, gold, lead, zinc, natural gas, timber
Land use (../docs/notesanddefs. html#288): This entry contains the percentage shares of total land area for three different types of land
use: agricultural land, forest, and other; agricultural land is further divided into arable land - land cultivated for crops like wheat, maize,
and rice that are replanted after each harvest, permanent crops - land cultivated for crops like citrus, coffee, and rubber that are not
replanted after each harvest, and includes land under flowering shrubs, fruit trees, nut trees, and vines, and permane . . . more
(..docs/notesanddefs.htmi#288)
(..fields/288.html#MX)
agricultural land: 54.9% (2011 est.) :
arable land: 11.8% (2011 est.) / permanent crops: 1.4% (2011 est.) / permanent pasture: 41.7% (2011 est.)
forest: 33.3% (2011 est.)
other: 11.8% (2011 est.)
irrigated land (../docs/notesanddefs.htmi#289): This entry gives the number of square kilometers of land area that is artificially supplied
with water.
(../fields/289.htmi#MX)
65,000 sq km (2012)
Population distribution (../docs/notesanddefs.html#348): This entry provides a summary description of the population dispersion within
a country. While it may suggest population density, it does not provide density figures.
(_ifields/348.htmi#MX)
most of the population is found in the middle of the country between the states of Jalisco and Veracruz; approximately a quarter of the
populgtiqntivesinand@round Mexico Gilet 4 46 cAREF4S FAPO7AR PHAR THBRPG FERRARA TF /
Approved for Release: 2022/12/08 C06979333
Natural hazards (../docs/notesanddets *''-''"zyz): Inis entry lists potential natural aisarr~"~ ~or Counties where vuIuariG avuviy io
common, a voleanism subfield highligt = Approved for Release: 2022/12/08 C06979333
le
(~Hfields/292.htmi#MX)
tsunamis along the Pacific coast, volcanoes and destructive earthquakes .in the center and south, and hurricanes on the Pacific, Gulf of
Mexico, and Caribbean coasts
volcanism: volcanic activity in the central-southern part of the country; the volcanoes in Baja California are mostly dormant; Colima
(3,850 m), which erupted in 2010, is Mexico''s most active volcano and is responsible for causing periodic evacuations of nearby
villagers; it has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth''s Interior,
worthy of:study due to its explosive history and close proximity to human populations; Popocatepetl (5,426 m) poses a threat to Mexico
City; other historically active volcanoes include Barcena, Ceboruco, El Chichon, Michoacan-Guanajuato, Pico de Orizaba, San Martin,
Socorro, and Tacana; see note 2 under "Geography - note"
Environment - current issues (../docs/notesanddefs.html#293): This entry lists the most pressing and important environmental
problems. The following terms and abbreviations are used throughout the entry: Acidification - the lowering of soil and water pH due to
acid precipitation and deposition usually through precipitation; this process disrupts ecosystem nutrient flows and may kill freshwater
fish and plants dependent on more neutral or alkaline conditions (see acid rain). Acid rain - characterized as containing harmful levels
of sulfur dioxi . .. more (../docs/notesanddefs.html#293) :
(..fields/293.htmi#MX)
scarcity of hazardous waste disposal facilities; rural to urban migration; natural freshwater resources scarce and polluted in north,
inaccessible and poor quality in center and extreme southeast; raw sewage and industrial effluents polluting rivers in urban areas;
deforestation; widespread erosion; desertification; deteriorating agricultural lands; serious air and water pollution in the national capital
and urban centers along US-Mexico border; land subsidence in Valley of Mexico caused by groundwater depletion
note: the government considers the lack of clean water and deforestation national security issues
Environment - international agreements (,./docs/notesanddefs.html#294): This entry separates country participation in international
environmental agreements into two levels - party to and signed, but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
(..ields/294.html#MX)
party to: Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Geography - note (../docs/notesanddefs.himl#295): This entry includes miscellaneous geographic information of significance not
included elsewhere.
(..ields/295.html#MX)
note 1: strategic location on southern border of the US; Mexico is one of the countries along the Ring of Fire, a belt of active volcanoes
and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world''s volcanoes
occur within the Ring of Fire
note 2: the "Three Sisters” companion plants - winter squash, maize (corn), and climbing beans - served as the main agricultural crops
for various North American Indian groups; all three apparently originated in Mexico but then were widely disseminated through much of
North America; vanilla,.the world''s most popular aroma and flavor spice, also emanates from Mexico
note 3: the Sac Actun cave system at 348 km (216 mi) is the longest underwater cave in the world and the second longest cave
worldwide, after Mammoth Cave in the United States (see "Geography - note" under United States)
note 4: the prominent Yucatan Peninsula that divides the Gulf of Mexico from the Caribbean Sea is shared by Mexico, Guatemala, and
Belize; just on the northern coast of Yucatan, near the town of Chicxulub (pronounce cheek-sha-loob), lie the remnants of a massive
crater (some 150 km in diameter and extending well out into the Gulf of Mexico); formed by an asteroid or comet when it struck the earth
66 million years ago, the impact is now widely accepted as initiating a worldwide climate disruption that caused a mass extinction of
75% of all the earth''s plant and animal species - including the non-avian dinosaurs
People and Society :: Mexico
Population (../docs/notesanddefs.html#335): This entry gives an estimate from the US Bureau of the Census based on statistics from
population censuses, vital statistics registration systems, or sample surveys pertaining to the recent past and on assumptions about
future trends. The total population presents one overall measure of the potential impact of the country on the world and within its
region. Note: Starting with the 1993 Factbook, demographic estimates for some countries (mostly African) have explicitly taken into
account t...more (./docs/notesanddefs.himi#335) ;
(..fields/335.html#MX)
128,649,565 (July 2020 est.)
country comparison.to the world: 10 /fields/335rank him: + ace 222 168526 TEBTA-459F |
&
Approved for Release: 2022/12/08 C06979333
Nationality (../decs/notesanddefs.htmi#22** This entry provides the identifying terms fe~ ~"~ens - noun and adjective.
ee Approved for Release: 2022/12/08 C06979333
(../fields/336.htmi#MX) : -
noun: Mexican(s)
adjective: Mexican
Ethnic groups (../docs/notesanddefs.hitml#400): This entry provides an ordered listing of ethnic groups starting with the largest and
normally includes the percent of total population.
( fi elds/400.htmi#MX)
mestizo (Amerindian-Spanish) 62%, predominantly Amerindian 21%, Amerindian 7%, other 10% (mostly European) (2012 est. )
. note: Mexico does not collect census data on ethnicity
Languages (../docs/notesanddefs.html#402): This entry provides a listing of languages spoken in each country and specifies any that
are official national or regional languages. When data is available, the languages spoken in each country are broken down according to
the percent of the total population speaking each language as a first language. For those countries without available data, languages
are listed in rank order based on prevalence, starting with the most-spoken language.
(. /fields/402. htmi#MX)
Spanish only 92.7%, Spanish and indigenous languages 5.7%, indigenous only 0. 8%, unspecified 0.8% (2005)
note: indigenous languages include various Mayan, Nahuatl, and other regional ianadauee
Religions (../docs/notesanddefs.htm!#401): This entry is an ordered listing of religions by adherents starting with the largest group and
sometimes includes the percent of total population. The core characteristics and beliefs of the world''s major religions are described
below. Baha''i - Founded by Mirza Husayn-Ali (known as Baha''u''llah) in Iran in 1852, Baha''i faith emphasizes monotheism and believes
in one eternal transcendent God. Its guiding focus is to encourage the unity of all peoples on the earth so that justice and peacem...
more (../docs/notesanddefs.html#401)
(..fields/401 .htmi#MX)
Roman Catholic 82.7%, Pentecostal 1.6%, Jehovah''s Witness 1.4%, other Evangelical Churches 5%, other 1.9%, none 4.7%,
unspecified 2.7% (2010 est.)
Age structure (../docs/notesanddefs.html#341): This entry provides the distribution of the population according to age. Information is
included by sex and age group as follows: 0-14 years (children), 15-24 years (early working age), 25-54 years (prime working age), 55-
64 years (mature working age), 65 years and over (elderly). The age structure of a population affects a nation’s key socioeconomic
issues. Countries with young populations (high percentage under age 15) need to invest more in schools, while countries with older
population . . . more (../docs/notesanddefs.html#341)
ey)
(..fields/341 .ntmi#MX)
0-14 years; 26.01% (male 17,111,199/female 16,349,767)
15-24 years: 16.97% (male 11,069,260/female 10,762,784)
25-54 years: 41.06% (male 25,604,223/female 27,223,720)
55-64 years: 8.29% (male 4,879,048/female 5,784,176)
65 years and over: 7.67% (male 4,373,807/female 5,491,581) (2020 est.)
population pyramid:
a
Dependency ratios (../docs/notesanddefs.htmi#342): Dependency ratios are a measure of the age structure of a population. They
relate the number of individuals that are likely to be economically "dependent" on the support of others. Dependency ratios contrast the
ratio of youths (ages 0-14) and the elderly (ages 65+) to the number of those in the working-age group (ages 15-64). Changes in the
dependency ratio provide an indication of potential social support requirements resulting from changes in population age structures. As
fertility leve .. . more (../docs/notesanddefs.html#342)
+
(..fields/342.html#MX)
total dependency ratio: 50.3
youth dependency ratio: 38.8
elderly dependency ratio: 11.4
potential support ratio: 8.7 (2020 est.)
Median age (../docs/notesanddefs.html#343): This entry is the age that divides a population into two numerically equal groups; that is,
half the people are younger than this age and half are older. It is a single index that summarizes the age distribution of a population.
Currently, the median age ranges from a low of about 15 in Niger and Uganda to 40 or more in several European countries and Japan.
See the entry for "Age structure” for the importance of a young versus an older age structure and, by implication, a low versus a high ..
. more (../docs/notesanddefs.html#343)
( ifields/343.htmi#MxX) .
total 29S MAS tag TFO514R Ltd 16 iG2tF45 FOOHPe 286052 THASIH TEATA-4594 /
Approved for Release: 2022/12/08 C06979333
male: 28.2 years
female: 30.4 years (2020 est.) - Approved for Release: 2022/12/08 C06979333
country comparison to the world: 132 (..1000u3/343rank.himl#MX)
Population growth rate (../docs/notesanddefs.htmi#344): The average annual percent change in the population, resulting from a surplus
(or deficit) of births over deaths and the balance of migrants entering and leaving a country. The rate may be positive or negative. The
growth rate is a factor in determining how great a burden would be imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources (e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as .. . more (../docs/notesanddefs.html#344)
(_.fields/344.htmi#MX)
1.04% (2020 est.)
country comparison to the world: 102 (../fields/344rank.html#MX)
Birth rate (../docs/notesanddefs.html#345): This entry gives the average annual number of births during a year per 1,000 persons in the
population at midyear; also known as crude birth rate. The birth rate is usually the dominant factor in determining the rate of population
growth. it depends on both the level of fertility and the age structure of the population.
(..Aields/345.htmi#MX)
17.6 births/1,000 population (2020 est.)
country comparison to the world: 95 (../fields/345rank.html#MX)
Death rate (../docs/notesanddefs.html#346): This entry gives the average annual number of deaths during a year per 1,000 population
at midyear; also known as crude death rate. The death rate, while only a rough indicator of the mortality situation in a country,
accurately indicates the current mortality impact on population growth. This indicator is significantly affected by age distribution, and
most countries will eventually show a rise in the overall death rate, in spite of continued decline in mortality at all ages, as declining...
more (../docs/notesanddefs.htmi#346)
es
(../fields/346.htmi#MX)
5.4 deaths/1,000 population (2020 est.) :
country comparison to the world: 186 (../fields/346rank.htmil#MX)
Net migration rate (../docs/notesanddefs.html#347): This entry includes the figure for the difference between the number of persons
entering and leaving a country during the year per 1,000 persons (based on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56 migrants/1,000 population); an excess of persons leaving the country as net
emigration (e.g., -9.26 migrants/1,000 population). The net migration rate indicates the contribution of migration to the overall level of
population chan . . . more (../docs/notesanddefs.html#347)
(../fields/347.htmi#MX)
1.9 migrant(s)/1,000 population (2020 est.)
‘country comparison to the world: 166 (../fields/347rank.html#MX)
Population distribution (../docs/notesanddefs.html#348): This entry provides a summary description of the population dispersion within
a country. While it may suggest population density, it does not provide density figures.
(../fields/348.html#fMX)
most of the population is found in the middle of the country between the states of Jalisco and Veracruz; approximately a quarter of the
population lives in and around Mexico City
Urbanization (../docs/notesanddefs.html#349): This entry provides two measures of the degree of urbanization of a population. The
first, urban population, describes the percentage of the total population fiving in urban areas, as defined by the country. The second,
rate of urbanization, describes the projected average rate of change of the size of the urban population over the given period of time. It
is possible for a country with a 100% urban population to still display a change in the rate of urbanization (up or down). For example . .
. more (../docs/notesanddefs.html#349)
(es
(..fields/349.html#MX)
urban population: 80.7% of total population (2020)
rate of urbanization: 1.59% annual rate of change (2015-20 est.)
Major urban areas - population (../docs/notesanddefs.html#350): This entry provides the population of the capital and up to six major
cities defined as urban agglomerations with populations of at least 750,000 people. An urban agglomeration is defined as comprising
the city or town proper and also the suburban fringe or thickly settled territory lying outside of, but adjacent to, the boundaries of the
city. For smaller countries, lacking urban centers of 750,000 or more, only the population of the capital is presented.
(..{fields/350.html#MX)
21.782 million MEXICO CITY (capital), 5.179 million Guadalajara, 4.874 million','f95d816b46624aa413e4e9ba72cf19257cae722ba9b873b2d5792b6bccc75dc4','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24a40b5bd55f39aaca45e942c2219c1ec78f6b57093688743e27bd2febd2be3e',2018,'','','raw',2,'Monterrey, 3.195 million Puebla, 2.467 million Toluca de
Lerdo, 2.140 million Tijuana (2020)
Sex ratio (../docs/notesanddefs.htmi#351): This entry includes the number of males for each female in five age groups - at birth, under
15 years, 15-64 years, 65 years and over, and for the total population. Sex ratio at birth has recently emerged as an indicator of certain
kinds of sex discrimination in some countries. For instance, high sex ratios at birth in some Asian countries are now attributed to sex-
selective abortion and infanticide due to a strong preference for sons. This will affect future marriage patterns and fertilit .. . more
(../docs/notesanddefs.htmi#351) .
(../fields/351 .htmi#MX) oa
at birfh> iOS Tala(SitemaleFGSt 4H ORISA TH ARPES THAIS PERS PABST FEST A-F45 FF /
Approved for Release: 2022/12/08 C06979333
0-14 years: 1.05 male(s)/female im.
15-24 years: 1.03 male(s)/female ‘ Approved for Release: 2022/12/08 C06979333
25-54 years: 0.94 male(s)/female ail
55-64 years: 0.84 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.96 male(s)/female (2020 est.)
Mother''s mean age at first birth (../docs/notesanddefs.html#352): This entry provides the mean (average) age of mothers at the birth of
their first child. It is a useful indicator for gauging the success of family planning programs aiming to reduce maternal mortality, increase
contraceptive use — particularly among married and unmarried adolescents — delay age at first marriage, and improve the health of
newborns.
(.Mields/352.htmi#MX)
21.3 years (2008 est.)
Maternal mortality rate (../docs/notesanddefs.htmi#353): The maternal mortality rate (MMR) is the annual number of female deaths per
100,000 live births from any cause related to or aggravated by pregnancy or its management (excluding accidental or incidental
causes). The MMR includes deaths during pregnancy, childbirth, or within 42 days of termination of pregnancy, irrespective of the
duration and site of the pregnancy, for a specified year.
(..ields/353.html#MX)
33 deaths/100,000 live births (2017 est.)
country comparison to the world: 108 (../fields/353rank.html#MX)
Infant mortality rate (../docs/notesanddefs.html#354): This entry gives the number of deaths of infants under one year old in a given
i per 1,000 live births in the same year. This rate is often used as an indicator of the level of health in a country.
Es
(..fields/354,.htmi#MX)
total: 10.7 deaths/1,000 live births
male: 12 deaths/1,000 live births
female: 9.2 deaths/1,000 live births (2020 est.)
country comparison to the world: 127 (../fields/354rank.html#MX)
Life expectancy at birth (../docs/notesanddefs.html#355): This entry contains the average number of years to be lived by a group of
people born in the same year, if mortality at each age remains constant in the future. Life expectancy at birth is also a measure of
overall quality of life in a country and summarizes the mortality at all ages. It can also be thought of as indicating the potential return on
investment in human capital and is necessary for the calculation of various actuarial measures.
(../fields/355.html#MX)
total population: 76.7 years
male: 73.9 years
female: 79.6 years (2020 est.)
country comparison to the world: 94 (../fields/355rank.himl#MX) :
Total fertility rate (..;docs/notesanddefs.html#356): This entry gives a figure for the average number of children that would be born per
woman if all women lived to the end of their childbearing years and bore children according to a given fertility rate at each age. The
total fertility rate (TFR) is a more direct measure of the level of fertility than the crude birth rate, since it refers to births per woman. This
indicator shows the potential for population change in the country. A rate of two children per woman is considered the replaceme ...
more (../docs/notesanddefs.html#356)
es
(..Aields/356.htmi#MX)
2.19 children born/woman (2020 est.) ;
country comparison to the world: 94 (../fields/356rank.htmi#MX)
Contraceptive prevalence rate (../docs/notesanddefs.html#357): This field gives the percent of women of reproductive age (15-49) who
are married or in union and are using, or whose sexual partner is using, a method of contraception according to the date of the most
recent available data. The contraceptive prevalence rate is an indicator of health services, development, and women’s empowerment.
it is also useful in understanding, past, present, and future fertility trends, especially in developing countries.
By,
(../fields/357.html#MX)
66.9% (2015)
Drinking water source (../docs/notesanddefs.html#361): This entry provides information about access to improved or unimproved
- drinking water sources available to segments of the population of a country. Improved drinking water ~ use of any of the following
sources: piped water into dwelling, yard, or plot; public tap or standpipe; tubewell or borehole; protected dug well; protected spring; or
rainwater collection. Unimproved drinking water - use of any of the following sources: unprotected dug well; unprotected spring; cart
with small tank or... more (../docs/notesanddefs.html#361)°
(..ffields/361.himl#MX)
improved: urban; 100% of population
rural: 96.6% of population
total: 100% of population :
unimproved: urban: 0% of population
rural: 3.4% of population : : :
total: O%Adf DEAMISHOAU20 11798 4G GERI 4H te iGAt7As TEPAPE FA: F2 T8G57R FRBTA-A5 9% fh
Approved for Release: 2022/12/08 C06979333
Current Health Expenditure (../docs/not----ddefs.himl#409): Current Health Expenditur~ ‘“4E) describes the share of spending on
health in each country relative to the si) Approved for Release: 2022/12/08 C06979333ing to the final consumption of health
care goods and services and excludes ....<stment, exports, and intermediate consumptiun. CHE shows the importance of the health
sector in the economy and indicates the priority given to health in monetary terms. Note: Current Health Expenditure replaces the
former Health Expenditures field .. . more (../docs/notesanddefs.html#409)
(..fields/409,html#MX)
5.5% (2017)
Physicians density (../docs/notesanddefs.html#3§9): This entry gives the number of medical doctors (physicians), including generalist
and specialist medical practitioners, per 1,000 of the population. Medical doctors are defined as doctors that study, diagnose, treat, and
prevent illness, disease, injury, and other physical and mental impairments in humans through the application of modern medicine.
They also plan, epee and evaluate care and treatment plans by other health care providers. The World Health Organization
estimates that f.. . more (../docs/notesanddefs.html#359)
(iields/389. html#MX)
2.38 physicians/1,000 population (2017)
Hospital bed density (../docs/notesanddefs.html#360): This entry provides the number of hospital beds per 1,000 people; it serves as a
general measure of inpatient service availability. Hospital beds include inpatient beds available in public, private, general, and
specialized hospitals and rehabilitation centers. In most cases, beds for both acute and chronic care are included. Because the level of
inpatient services required for individual countries depends on several factors - such as demographic issues and the burden of disease
~ there is... more (../docs/notesanddefs.html#360)
(..fields/360.htmi#MX)
1.5 beds/1,000 population (2015)
Sanitation facility access (../docs/notesanddefs.htmi#398): This entry provides information about access to improved or unimproved
sanitation facilities available to segments of the population of a country. Improved sanitation - use of any of the following facilities: flush
or pour-flush to a piped sewer system, septic tank or pit latrine; ventilated improved pit (VIP) latrine; pit latrine with slab; or a
composting toilet. Unimproved sanitation - use of any of the following facilities: flush or pour-flush not piped to a sewer system, septic
tank... more (../docs/notesanddefs.htmi#398)
Oe ca nas
improved: urban: 99.3% of population
rural: 91.9% of population
total: 97.8% of population
unimproved: urban: 0.7% of population
rural: 8.1% of population
-total: 2.2% of population (2017 est.)
HIV/AIDS - adult prevalence rate (. /docs/notesanddefs. html#363): This entry gives an estimate of the percentage of adults (aged 15-
49) living with HIV/AIDS. The adult prevalence rate is calculated by dividing the estimated number of adults living with HIV/AIDS at
yearend by the total adult population at yearend.
(..Mields/363.html#MX)
0.2% (2018 est.)
country comparison to the world: 107 (../fields/363rank.html#MXx)
HIV/AIDS - people living with HIV/AIDS (../docs/notesanddefs.html#364): This entry gives an estimate of all peopie (adults and
children) alive at yearend with HIV infection, whether or not they have developed symptoms of AIDS.
(../fields/364.html#MX)
230,000 (2018 est.)
country comparison to the world: 25 (../fields/364rank.html#MX)
HIV/AIDS - deaths (../docs/notesanddefs.html#365): This entry gives an estimate of the number of adults and children who died of
AIDS during a given calendar year.
Ci elds/365.htmi#MX)
4,000 (2017 est.)
country comparison to the world: 32 (../fields/365rank.html#MX)
Major infectious diseases (../docs/notesanddefs.html#366): This entry lists major infectious diseases likely to be encountered in
countries where the risk of such diseases is assessed to be very high as compared to the United States. These infectious diseases
represent risks to US government personnel traveling to the specified country for a period of less than three years. The degree of risk
is assessed by considering the foreign nature of these infectious diseases, their severity, and the probability of being affected by the
_ diseases present. Th... more (../docs/notesanddefs.html#366)
i
(../fields/366.html#MX)
degree of risk: intermediate (2020)
food or waterborne diseases: bacterial diarrhea and hepatitis A
vectorborne diseases: dengue fever
note: a new coronavirus is causing sustained community spread of respiratory iliness (COVID-19) in Mexico; sustained community
spreacsmearSahatinddple havitiekh itfegted with thevidé, BEnhCMaAMErS they Beda iMfecléd’td Aatkagwn, and the spreadis /
Approved for Release: 2022/12/08 C06979333
ongoing; illness with this virus has range~ *~m mild to severe with fatalities reported; as ~*~ “ugust 2U2U, Mexico nas reported 445,015
confirmed cases of COVID19 with 48,01. Approved for Release: 2022/12/08 C06979333
Obesity - adult prevalence rate (../docs,,...sanddefs.htmi#367): This entry gives the pé.cci. of a country''s population considered to be
obese. Obesity is defined as an adult having a Body Mass Index (BMI) greater to or equal to 30.0. BMI is calculated by taking a
person''s weight in kg and dividing it by the person''s squared height in meters. P
(..Aields/367.html#MX)
28.9% (2016)
country comparison to the world: 29 (../fields/367 rank.html#MX)
Children under the age of § years underweight (../docs/notesanddefs.html#368): This entry gives the percent of children under five
considered to be underweight. Underweight means weight-for-age is approximately 2 kg below for standard at age one, 3 kg below
standard for ages two and three, and 4 kg below standard for ages four and five. This statistic is an indicator of the nutritional status of
a community, Children who suffer from growth retardation as a result of poor diets and/or recurrent infections tend to have a greater
risk. of suffering illness and death.
fe}
(..ffields/368.htmi#MX)
4.2% (2016)
country comparison to the world: 87 (../fields/368rank.htmi#MX)
Education expenditures (../docs/notesanddefs.html#369): This entry provides the public expenditure on education as a percent of GDP.
(../fields/369.htmnl#MX)
4.9% of GDP (2016) :
country comparison to the world: 66 (../fields/369rank.htmi#MX)
Literacy (../docs/notesanddefs.html#370): This entry includes a definition of literacy and UNESCO''s percentage estimates for
populations aged 15 years and over, including total population, males, and females. There are no universal definitions and standards of
literacy. Unless otherwise specified, all rates are based on the most common definition - the ability to read and write at a specified age.
Detailing the standards that individual countries use to assess the ability to read and write is beyond the scope of the Factbook. Info . .
. more (../docs/notesanddefs.html#370)
(..fields/370.htmi#MX)
definition: age 15 and over can read and write
total population: 95.4%
male: 95.8%
female: 94.6% (2018) . .
School life expectancy (primary to tertiary education) (../docs/notesanddefs.html#371): School life expectancy (SLE) is the total number
of years of schooling (primary to tertiary) that a child can expect to receive, assuming that the probability of his or her being enrolled in
schoo! at any particular future age is equal to the current enrollment ratio at that age. Caution must be maintained when utilizing this
indicator in international comparisons. For example, a year or grade completed in one country is not necessarily the same in terms of
educational content or qualit .. . more (../docs/notesanddefs.html#37 1)
eee
total: 14 years
male: 14 years
female: 14 years (2016)
Unemployment, youth ages 15-24 (../docs/notesanddefs.html#373): This entry gives the percent of the total labor force ages 15-24
unemployed during a specified year.
(../fields/373.html#MX)
total: 6.9%
male: 6.5%
female: 7.6% (2018 est.)
country comparison to the world: 152 (../fields/373rank.html#MX)
Government :: Mexico ;
Country name (../docs/notesanddefs.htmi#296): This entry includes all forms of the country''s name approved by the US Board on
Geographic Names (Italy is used as an example): conventional long form (Italian Republic), conventional short form (Italy), local long
form (Repubblica Italiana), local short form (Italia), former (Kingdom of Italy), as well as the abbreviation. Also see the Terminology
note.
Es
(..fields/296.html#MX)
conventional long form: United Mexican States
conventional short form: Mexico
local long form: Estados Unidos Mexicanos
local short form: Mexico ; .
etymology: named after the capital city, whose name stems from the Mexica, the largest and most powerful branch of the Aztecs; the
meaning of the name is uncertain
Government type (../docs/notesanddefs.html#299): This entry gives the basic form of government. Definitions of the major
governmental terms are as follows. (Note that for some countries more than one definition applies. ): Absolute monarchy - a form of
vernmental terms are aS follows, (Note a Or Same CONES TOS AE Dasee VeMe Tao ta tas
Approved for Release: 2022/12/08 C06979333
government where the monarch rules u~*''~dered, i.e., without any laws, constitution, or ''~~-"y organized opposition. Anarcny - a
condition of lawlessness or political dig Approved for Release: 2022/12/08 C0697933300rity. Authoritarian - a form of
government in whic . . . more (../docs/nucoanddefs.html#299)
(../flelds/299.html#MX)
federal presidential republic :
Capital (../docs/notesanddefs.htmi#301): This entry gives the name of the seat of government, its geographic coordinates, the time
difference relative to Coordinated Universal Time (UTC) and the time observed in Washington, DC, and, if applicable, information on
daylight saving time (DST). Where appropriate, a special note has been added to highlight those countries that have multiple time
zones.
(..ields/301 .html#MX)
name: Mexico City (Ciudad de Mexico)
geographic coordinates: 19 26 N, 99 08 W
time difference: UTC-6 (1 hour behind Washington, DC, during Standard Time)
daylight saving time: +1hr, begins first Sunday in April; ends last Sunday in October
note: Mexico has four time zones
etymology: named after the Mexica, the largest and most powerful branch of the Aztecs; the meaning of the name is uncertain
Administrative divisions (../docs/notesanddefs.html#302): This entry generally gives the numbers, designatory terms, and first-order
administrative divisions as approved by the US Board on Geographic Names (BGN). Changes that have been reported but not yet
acted on by the BGN are noted. Geographic names conform to spellings approved by the BGN with the exception of the omission of
diacritical marks and special characters.
(..fields/302.html#MX)
32 states (estados, singular - estado); Aguascalientes, Baja California, Baja California Sur, Campeche, Chiapas, Chihuahua, Coahuila,
Colima, Cuidad de Mexico, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon,
Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan,
Zacatecas
Independence (../docs/notesanddefs.html#305): For most countries, this entry gives the date that sovereignty was achieved and from
which nation, empire, or trusteeship. For the other countries, the date given may not represent "independence" in the strict sense, but
rather some significant nationhood event such as the traditional founding date or the date of unification, federation, confederation,
establishment, fundamental change in the form of government, or state succession. For a number of countries, the establishment of
statehood . .. more (../docs/notesanddefs.html#305)
(..ields/305.html#MX)
16 September 1810 (declared independence from Spain); 27 September 1821 (recognized by Spain)
= holiday (../docs/notesanddefs.htmi#306): This entry gives the primary national day of celebration - usually independence day.
(FE,
(../fields/306.html#MX)
independence Day, 16 September (1810)
Constitution (../docs/notesanddefs.html#307): This entry provides information on a country''s constitution and’includes two subfields.
The history subfield includes the dates of previous constitutions and the main steps and dates in formulating and implementing the
latest constitution. For countries with 1-3 previous constitutions, the years are listed; for those with 4-9 previous, the entry is fisted as
“several previous,” and for those with 10 or more, the entry is “many previous.” The amendments subfield summarizes the process of
am... more (../docs/notesanddefs.html#307)
fe
(../fields/307.hitmi#MX)
history: several previous; latest approved 5 February 1917
amendments: proposed by the Congress of the Union; passage requires approval by at least two thirds of the members present and
approval by a majority of the state legislatures; amended many times, last in 2020 :
Legal system (../docs/notesanddefs.html#308): This entry provides the description of a country''s legal system. A statement on judicial
review of legislative acts is also included for a number of countries. The legal systems of nearly all countries are generally modeled
upon elements of five main types: civil law (including French law, the Napoleonic Code, Roman law, Roman-Dutch law, and. Spanish
law); common law (including United State law); customary law; mixed or pluralistic law; and religious law (including islamic law). An
addition . . . more (../docs/notesanddefs.html#308)
ES
(../fields/308.html#MX)
civil law system with US constitutional law influence; judicial review of legislative acts
international law organization participation (../docs/notesanddefs.html#309): This entry includes information on a country''s acceptance
of jurisdiction of the International Court of Justice (ICJ) and of the International Criminal Court (ICCt); 59 countries have accepted ICJ
jurisdiction with reservations and 11 have accepted ICJ jurisdiction without reservations; 122 countries have accepted ICCt jurisdiction.
Appendix B: International Organizations and Groups explains the differing mandates of the ICJ and ICCt.
(..fields/309.htmi#MX)
accepts compulsory LC.) jursdiction with reservations, agcepts4eChinvedigiona 5% TAOR7H TRATA-45 94 ''
Approved for Release: 2022/12/08 C06979333
Citizenship (../docs/notesanddefs.htmi#?*™: This entry provides information related to thagacquisition and exercise of citizenship; it
includes four subfields: citizenship by bh Approved for Release: 2022/12/08 C06979333}lace of birth, known as Jus soli,
regardless of the citizenship of parents. uu.enship by descent only describes the acquisition of citizenship based on the sea of
Jus sanguinis, or by descent, where at least one parent is a citizen of the state and being born within the territorial limits of the s .
more (../docs/notesanddefs. html#310)
( ffields/310.htmi#MX)
citizenship by birth: yes
citizenship by descent only: yes
dual citizenship recognized: not specified
residency requirement for naturalization: 5 years
Suffrage (../docs/notesanddefs.html#311): This entry gives the age at enfranchisement and whether the right to vote is universal or
restricted.
(.ifields/311.ntmi#MX)
18 years of age: universal and compulsory :
Executive branch (../docs/notesanddefs.html#312): This entry includes five subentries: chief of state; head of government; cabinet;
elections/appointments; election results. Chief of state includes the name, title, and beginning date in office of the titular leader of the
. Country who represents the state at official and ceremonial functions but may not be involved with the day-to-day activities of the
government. Head of government includes the name, title of the top executive designated to ameanege the executive branch of the
government, a... more (../docs/notesanddefs.html#312)
4}
(. fi elds/312.html#MX)
chief of state: President Andres Manuel LOPEZ OBRADOR (since 1 December 2018); note - the president is both chief of state and
head of government
head of government: President Andres Manuel LOPEZ OBRADOR (since 1 December 2018)
cabinet: Cabinet appointed by the president; note - appointment of attorney general, the head of the Bank of Mexico, and senior treasury
officials require consent of the Senate
elections/appointments: president directly elected by simple majority popular vote for a single 6-year term; election last held on 1 July
2018 (next to be held in July 2024)
election results: Andres Manuel LOPEZ OBRADOR elected president; percent of vote - Andres Manuel LOPEZ OBRADOR (MORENA)
53.2%, Ricardo ANAYA (PAN) 22.3%, Jose Antonio MEADE Kuribrena (PRI) 16.4%, Jaime RODRIGUEZ Calderon 5.2% (independent),
other 2.9%
Legislative branch (../docs/notesanddefs. html#313): This entry has three subfields. The description subfield provides the legislative
structure (unicameral — single house; bicameral — an upper and a lower house); formal name(s); number of member seats; types of
constituencies or voting districts (single seat, multi-seat, nationwide); electoral voting system(s); and member term of office. The
elections subfield includes the dates of the last election and next election. The election results subfield lists percent of vote by
party/coalition an . . . more (../docs/notesanddefs.html#313)
(..fields/313.htmi#MX)
description: bicameral National Congress or Congreso de la Union consists of:
Senate or Camara de Senadores (128 seats; 96 members directly elected in multi-seat-constituencies by simple majority vote and 32
directly elected in a single, nationwide constituency by proportional representation vote; members serve 6-year terms)
Chamber of Deputies or Camara de Diputados (500 seats; 300 members directly elected in single-seat constituencies by simple majority
vate and 200 directly elected in.a single, nationwide constituency by proportional representation vote; members serve 3-year terms)
elections:
Senate - last held on 1 July 2018 (next to be held on 1 July 2024)
Chamber of Deputies - last held on 1 July 2018 (next to be held on 1 July 2021)
election results:
Senate - percent of vote by party - percent of vote by party. - NA; seats by party - MORENA 58, PAN 22, PRI 14, PRD 9, MC 7, PT 7,
PES 5, PVEM 5, PNA/PANAL 1; composition - men 65, women 63, percent of women 49.3%
Chamber of Deputies - percent of vote by party - NA; seats by party - MORENA 193, PAN 79, PT 61, PES 58, PRI 42, MC 26, PRD 23,
PVEM 17, PNA/PANAL 1; compositi','f27da93db5fd61ba62f2937d2a7ce1a09df1146beb8d6a1ee0530d4856b5b7e8','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c90a985c73a3ad434d9adfd33787470f90edce649b61e38001b5301d03c07749',2018,'','','raw',3,'on - men 259, women 241, percent of women 48.2%; note - total National Congress percent of
women 48.4%
note: for the 2018 election, senators will be eligible for a second term and deputies up to 4 consecutive terms
Judicial branch (../docs/notesanddefs.html#314): This entry includes three subfields. The highest court(s) subfield includes the name(s)
of a country''s highest level court(s), the number and titles of the judges, and the types of cases heard by the court, which commonly
are based on civil, criminal, administrative, and constitutional law. A number of countries have separate constitutional courts. The judge
selection and term of office subfield includes the organizations and associated officials responsible for nominating and appointing j ..
more (../docs/notesanddefs.himl#314)
(..ffields/314.html#MX)
highest courts: Supreme Court of Justice or Suprema Corte de Justicia de la Nacion (consists of the chief justice and 11 justices and
organized into civil, criminal, administrative, and labor panels) and the Electoral Tribunal of the Federal Judiciary (organized into the
superior court, with 7 judges including the court president, and 5 regional courts, each with 3 judges)
judge selection and term of office: Supreme Court justices nominated by the president of the republic and approved by two-thirds vote of
the members present in the Senate; justices serve fg ind terms; Electoral Tribunal su uperier. and regional court qui judges nominated by
THOME ES SA7GHY TIGCT4EG STATS 1H iASTP4S FAPAPR PETSS TEGO TARt a+ /
Approved for Release: 2022/12/08 C06979333
the Supreme Court and elected by two-th''-+- vote of members present in the Senate; sur~"-" court president elected trom among is
members to hold office for a 4-year term Approved for Release: 2022/12/08 C06979333taggered, 9-year terms
subordinate courts: federal level includes v., wit, collegiate, and unitary courts; state and wou: level courts
Note: in mid-February 2020, the Mexican president endorsed a bill on judicial reform, which proposes changes to 7 articles of the
constitution and the issuance of a new Organic Law on the Judicial Branch of the Federation
Political parties and leaders (../docs/notesanddefs.html#315): This entry includes a listing of significant political parties, coalitions, and
electoral lists as of each country''s last legislative election, unless otherwise noted.
Ey
(./fieids/315.himl#MX) :
Citizen''s Movement (Movimiento Ciudadano) or MC [Clemente CASTANEDA]
institutional Revolutionary Party (Partido Revolucionario Institucional) or PRI [Claudia RUIZ Massieu]
Labor Party (Partido del Trabajo) or PT [Alberto ANAYA Gutierrez]
Mexican Green Ecological Party (Partido Verde Ecologista de Mexico) or PVEM [Carlos Alberto PUENTE Salas]
Movement for National Regeneration (Movimiento Regeneracion Nacional) or MORENA [Andres Manuel LOPEZ Obrador]
National Action Party (Partido Accion Nacional) or PAN [Damian ZEPEDA Vidales]
Party of the Democratic Revolution (Partido de la Revolucion Democratica) or PRD [Manuel GRANADOS]
International organization participation (../docs/notesanddefs.html#317): This entry lists in alphabetical order by abbreviation those
international organizations in which the subject country is a member or participates in some other way.
(../fieids/317 .htmi#MX)
APEC, Australia Group, BCIE, BIS, CAN (observer), Caricom (observer), CD, CDB, CE (observer), CELAC, CSN (observer), EBRD,
FAO, FATF, G-3, G-15, G-20, G-24, G-5, IADB, IAEA, IBRD, ICAO, ICC (national committees), ICCt, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, IMSO, Interpol, OC, IOM, IPU, ISO, ITSO, ITU, ITUC (NGOs), LAES, LAIA, MIGA, NAFTA, NAM (observer), NEA,
NSG, OAS, OECD, OPANAL, OPCW, Pacific Alliance, Paris Club (associate), PCA, SICA (observer), UN, UNASUR (observer),
UNCTAD, UNESCO, UNHCR, UNIDO, Union Latina (observer), UNWTO, UPU, WCO, WFTU (NGOs), WHO, WIPO, WMO, WTO
Diplomatic representation in the US (../docs/notesanddefs.html#318): This entry includes the chief of mission, chancery address,
telephone, FAX, consulate general locations, and consulate locations. The use of the annotated title Appointed Ambassador refers to a
new ambassador who has presented his/her credentials to the secretary of state but not the US president. Such ambassadors fulfill all
diplomatic functions except meeting with or appearing at functions attended by the president until such time as they formally present
their credentials at a White Hou . . . more (../docs/notesanddefs.htmi#318)
(..ields/318.html#MX)
Ambassador Martha BARCENA Coqui (since 11 January 2019); note - Ambassador BARCENA Coaui is Mexico''a first-ever female
ambassador to the US
chancery: 1911 Pennsylvania Avenue NW, Washington, DC 20006
telephone: [1] (202) 728-1600
FAX: [1] (202) 728-1698
consulate(s) general; Atlanta, Austin, Boston, Chicago, Dallas, Denver, El Paso (TX), Houston, Laredo (TX), Los Angeles, Miami, New
York, Nogales (AZ), Phoenix, Sacramento (CA), San Antonio (TX), San Diego, San Francisco, San Jose (CA), San Juan (Puerto Rico),
Saint Paul (MN)
consulate(s): Albuquerque (NM), Anchorage (AK), Boise (ID), Brownsville (TX), Calexico (CA), Del Rio (TX), Detroit, Douglas (AZ),
Eagle Pass (TX), Fresno (CA), Indianapolis (IN), Kansas City (MO), Las Vegas, Little Rock (AR), McAllen (TX), Minneapolis (MN), New
Orleans, Omaha (NE), Orlando (FL), Oxnard (CA), Philadelphia, Portland (OR), Presidio (TX), Raleigh (NC), Salt Lake City, San
Bernardino (CA), Santa Ana (CA), Seattle, Tucson (AZ), Yuma (AZ); note - Washington DC Consular Section is located in a separate
building from the Mexican Embassy and has jurisdiction over DC, parts of Virginia, Maryland, and West Virginia
Diplomatic representation from the US (../docs/notesanddefs.html#319): This entry includes the chief of mission, embassy address,
Ee address, telephone number, FAX number, branch office locations, consulate general locations, and consulate locations.
Ele
(../fields/319.html#MX)
chief of mission: Ambassador Christopher LANDAU (since 26 August 2019)
telephone: (011) 52-55-5080-2000
embassy: Paseo de la Reforma 305, Colonia Cuauhtemoc, 06500 Mexico, Distrito Federal
mailing address: P. O, Box 9000, Brownsville, TX 78520-9000
FAX; (011) §2-55-5080-2005
consulate(s) general: Ciudad Juarez, Guadalajara, Hermosillo, Matamoros, Merida, Monterrey, Nogales, Nuevo Laredo, Tijuana
Flag description (../docs/notesanddefs.html#320): This entry provides a written flag description produced from actual flags or the best
information available at the time the entry was written. The flags of independent states are used by their dependencies unless there is
an officially recognized local flag. Some disputed and other areas do not have flags.
(..fields/320.htmi#MX)
three equal vertical bands of green (hoist side), white, and red; Mexico''s coat of arms (an eagle with a snake in its beak perched on a
cactus) is centered in the white band; green signifies hope, joy, and love; white represents peace and honesty; red stands for hardiness,
bravery, strength, and valor; the coat of arms is derived from a legend that the wandering Aztec people were to settle at a location where
they would see an eagle on a cactus eating a snake; the city they founded, Tenochtitlan, is now Mexico City
notes similarto-the:fiag of itaigewhich isshortes, uses lighter SHadestoF 9fen Afid Ken, BAGAES idt@isplaxafything in its white band /
Approved for Release: 2022/12/08 C06979333
National symbol(s) (../docs/notesa
distinctive object - that over time h
OE rrve }: A national symbol Is a faunal, fre" -r ntner abstract representation - or some
few countries have more than one.
pproved for Release: 2022/12/08 C06979333¢ all countries have national symbols; a
(..fields/321 .html#MX)
golden eagle; national colors: green, white, red
National anthem (../docs/notesanddefs.html#322): A generally patriotic musical composition - usually in the form of a song or hymn of
praise - that evokes and eulogizes the history, traditions, or struggles of a nation or its people. National anthems can be officially
recognized as a national song by a country''s constitution or by an enacted law, or simply by tradition. Although most anthems contain
lyrics, some do not.
(_ifields/322.html#MX)
name: "Himno Nacional Mexicano” (National Anthem of Mexico)
lyrics/music: Francisco Gonzalez BOCANEGRA/Jaime Nuno ROCA
note: adopted 1943, in use since 1854; also known as "Mexicanos, al grito de Guerra” (Mexicans, to the War Cry); according to
tradition, Francisco Gonzalez BOCANEGRA, an accomplished poet, was uninterested in submitting lyrics to a national anthem contest;
his fiancee locked him in a room and refused to release him until the lyrics were completed
0:00 / 1:41
Economy :: Mexico
Economy - overview (../docs/notesanddefs.html#207): This entry briefly describes the type of economy, including the degree of market
orientation, the level of economic development, the most important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12 months and may include a statement about one or two
eo future macroeconomic trends.
Ee:
(..fields/207 .ntmi#MX)
Mexico''s $2.4 trillion economy — 11th largest in the world - has become increasingly oriented toward manufacturing since the North
American Free Trade Agreement (NAFTA) entered into force in 1994. Per capita income is roughly one-third that of the US; income
distribution remains highly unequal.
Mexico has become the US'' second-largest export market and third-largest source of imports. In 2017, two-way trade in goods and
services exceeded $623 billion. Mexico has free trade agreements with 46 countries, putting more than 90% of its trade under free trade
agreements. In 2012, Mexico formed the Pacific Alliance with Peru, Colombia, and Chile.
Mexico''s current government, led by President Enrique PENA NIETO, has emphasized economic reforms, passing and implementing
sweeping energy, financial, fiscal, and telecommunications reform legislation, among others, with the long-term aim to improve
competitiveness and economic growth across the Mexican economy. Since 2015, Mexico has held public auctions of oil and gas
exploration and development rights and for long-term electric power generation contracts. Mexico has also issued permits for private
sector import, distribution, and retail sales of refined petroleum products in an effort to attract private investment into the energy sector
and boost production.
Since 2013, Mexico''s economic growth has averaged 2% annually, falling short of private-sector expectations that President PENA
NIETO''s sweeping reforms would bolster economic prospects. Growth is predicted to remain below potential given failing oil production,
weak oil prices, structural issues such as low productivity, high inequality, a large informal sector employing over half of the workforce,
weak rule of law, and corruption. Mexico''s economy remains vulnerable to uncertainty surrounding the future of NAFTA — because the
United States is its top trading partner and the two countries share integrated supply chains — and to potential shifts in domestic
policies following the inauguration of a new a president in December 2018.
GDP (purchasing power parity) (../docs/notesanddefs.html#208): This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. A nation''s GDP at purchasing power parity (PPP) exchange rates is the
sum value of all goods and services produced in the country valued at prices prevailing in the United States in the year noted. This is
the measure most economists prefer when looking at per-capita welfare and when comparing living conditions or use of resources
across countries. The measur . . . more (../docs/notesanddefs.html#208)
(../fields/208.htmi#MX)
$2.463 trillion (2017 est.)
$2.413 trillion (2016 est.)
$2.346 trillion (2015 est.)
note: data are in 2017 dollars
couniry comparison to the world: 11 (../fields/208rank.html#MX) :
GDP (official exchange rate) (../docs/notesanddefs.html#209): This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. A nation''s GDP at official exchan tes (OER) is the home- a
PEAT ORT EOD TaOC Tae CTAT AD. TE tear eae TORR Sas TROL Oe TEOTACae a omecurency
Approved for Release: 2022/12/08 C06979333
denominated annual GDP figure divided hy the bilateral average US exchange rate with that country in thal year. [he measure Is
simple to compute and gives a oo ae for Release: 2022/12/08 C06979333this measure when gauging the
s power an economy maint -... more (../docs/notesanddefs.html#20-,
(.. fields/209.htmi#MX)
$1.151 trillion (2017 est.)
GDP - real growth rate (../docs/notesanddefs.html#210): This entry gives GDP growth on an annual basis adjusted for inflation and
expressed as a percent. The growth rates are year-over-year, and not compounded.
fed
(.. fields/210.html#MX)
2% (2017 est.)
2.9% (2016 est.)
3.3% (2015 est.)
‘country comparison to the world: 152 (../fields/2 10rank.html#MX)
GDP - per capita (PPP) (../docs/notesanddefs.htmi#211): This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
E)
(..ffields/211.html#MX)
$19,900 (2017 est.)
$19,700 (2016 est.)
$19,400 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 90 (../fields/211rank.html#MX) :
Gross national saving (../docs/notesanddefs.html#212): Gross national saving is derived by deducting final consumption expenditure
(household plus government) from Gross national disposable income, and consists of personal saving, plus business saving (the sum
of the capital consumption allowance and retained business profits), plus government saving (the excess of tax revenues over
’ expenditures), but excludes foreign saving (the excess of imports of goods and services over exports). The figures are presented as a
percent of GDP. A negative .. . more (..docs/notesanddefs.html#212)
(../fields/212.html#MX)
21.4% of GDP (2017 est.)
21.6% of GDP (2016 est.)
20.7% of GDP (2015 est.)
country comparison to the world: 85 (../fields/212rank.html#MX)
GDP - composition, by end use (../docs/notesanddefs.html#213): This entry shows who does the spending in an economy: consumers,
businesses, government, and foreigners. The distribution gives the percentage contribution to total GDP of household consumption,
government consumption, investment in fixed capital, investment in inventories, exports of goods and services, and imports of goods
and services, and will total 100 percent of GDP if the data are complete. household consumption consists of expenditures by resident
households, and by nonprofit insti. . . more (../docs/notesanddefs.html#213)
(../fields/213.htmi#MX)
household consumption: 67% (2017 est.)
government consumption: 11.8% (2017 est.)
investment in fixed capital: 22.3% (2017 est.)
investment in inventories: 0.8% (2017 est.)
exports of goods and services: 37.8% (2017 est.)
imports of goods and services: -39.7% (2017 est.)
GDP - composition, by sector of origin (../docs/notesanddefs.html#214): This entry shows where production takes place. in an economy.
The distribution gives the percentage contribution of agriculture, industry, and services to total GDP, and will total 100 percent of GDP if
the data are complete. Agriculture includes farming, fishing, and forestry. Industry includes mining, manufacturing, energy production,
and construction. Services cover government activities, communications, transportation, finance, and all other private economic
a that do not prod . . . more (../docs/notesanddefs.himi#214)
El:
(.. fields/214.html#MX)
agriculture: 3.6% (2017 est.)
industry: 31.9% (2017 est.)
services: 64.5% (2017 est.)
Agriculture - products (../docs/notesanddefs.htmi#215): This entry is an ordered listing of major crops and products starting with the
most important.
eae
(../fields/215.htmil#MX) .
corn, wheat, soybeans, rice, beans, cotton, coffee, fruit, tomatoes; beef, poultry, dairy products; wood products
industries (../docs/notesanddefs.html#216): This entry provides a rank ordering of industries starting with the largest by value of annual
output. . E
Ey
(igl@si2 1GRIMNPD 19a5t4 BALE. TH cORETIS PACMAG PESR THOM FABLA-A999. /
Approved for Release: 2022/12/08 C06979333.
food and beverages, tobacco, che
tourism pproved for Release: 2022/12/08 C06979333
Industrial production growth rate (..eecsmotesanddefs.html#217): This entry gives t... u.....ul percentage increase in industrial
production (includes manufacturing, mining, and construction).
(..fields/217 html#MX)
-0.6% (2017 est.)
country comparison to the world: 174 (..fields/217rank.html#MX)
Labor force (../docs/notesanddefs.html#218): This entry contains the total labor force figure.
(ee
(..ffields/218.html#MX)
54.51 million (2017 est.)
country comparison to the world: 12 (..fields/218rank.html#MX)
Labor force - by occupation (../docs/notesanddefs.html#219): This entry lists the percentage distribution of the labor force by sector of
occupation. Agriculture includes farming, fishing, and forestry. Industry includes mining, manufacturing, energy production, and
construction. Services cover government activities, communications, transportation, finance, and all other economic activities that do
not produce material goods. The distribution will total less than 100 percent if the data are incomplete and may range from 99-101
percent due to rounding. more (../docs/notesanddefs.htmi#219)
''e q and steel, petroleum, mining, textiles, c''o*"in~ motor vehicles, consumer durables,
(../fields/219.html#MX)
agriculture: 13.4%
industry: 24.1%
services: 61.9% (2011)
Unemployment rate (../docs/notesanddefs.html#220): This entry contains the percent of the labor force that is without jobs. Substantial
- underernployment might be noted.
if
(../fields/220.htmi#MXx)
3.4% (2017 est.)
3.9% (2016 est.)
note: underemployment may be as high as 25%
country comparison to the world: 42 (../fields/220rank.html#MX)
Population below poverty line (../docs/notesanddefs.htmi#221): National estimates of the percentage of the population falling below the
poverty line are based on surveys of sub-groups, with the results weighted by the number of people in each group. Definitions of
poverty vary considerably among nations. For example, rich nations generally employ more generous standards of poverty than poor
nations.
(.fields/221.htmi#MX)
46.2% (2014 est.)
note: from a food-based definition of poverty; asset-based poverty amounted to more than 47%
Household income or consumption by percentage share (../docs/notesanddefs.html#222): Data on household income or consumption
come from household surveys, the results adjusted for household size. Nations use different standards and procedures in collecting
and adjusting the data. Surveys based on income will normally show a more unequal distribution than surveys based on consumption.
The quality of surveys is improving with time, yet caution is still necessary in making inter-country comparisons.
(_Mields/222, htmi#Mx)
lowest 10%: 2%
highest 10%: 40% (2014)
Budget (../docs/notesanddefs.html#224): This entry includes revenues, expenditures, and capital expenditures. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
(../fields/224.html#MX)
revenues: 261.4 billion (2017 est.)
expenditures: 273.8 billion (2017 est.)
Taxes and other revenues (../docs/notesanddefs.html#225): This entry records total taxes and other revenues received by the national
government during the time period indicated, expressed as a:percent''of GDP. Taxes include personal and corporate income taxes,
value added taxes, excise taxes, and tariffs. Other revenues include social contributions - such as payments for social security and
hospital insurance - grants, and net revenues from public enterprises. Normalizing the data, by dividing total revenues by GDP, enables
easy comparisons acr . . . more (../docs/notesanddefs.html#225)
(..fields/225.htmi#MX)
22.7% (of GDP) (2017 est.)
country comparison to the world: 137 (. fields/225rank.html#MX)
Budget surplus (+) or deficit (-) (../docs/notesanddefs.html#226): This entry records the difference between national government
revenues and expenditures, expressed as a percent of GDP. A positive (+) number indicates that,revenues exceeded expenditures (a
Boe eat ee eee eee eo aeRO Oates Tame ye LOTR tar ;
Approved for Release: 2022/12/08 C06979333
budget surplus), while a negative (-) numer indicates the reverse (a budget dericit). Norm="zing Ine aala, Dy alviding ine Duaget
balance by GDP, enables easy OO sc: for Release: 2022/12/08 C06979333}0vernment saves or borrows money.
Countries with high budget deficits more (../docs/notesanddefs.himl#226)
(../fields/226.htmi#MX)
-1.1% (of GDP) (2017 est.)
country comparison to the world: 83 (../fields/226rank.html#MX)
Public debt (../docs/notesanddefs.html#227): This entry records the cumulative total of all government borrowings less repayments that
are denominated in a country''s home currency. Public debt should not be confused with external debt, which reflects the foreign
currency liabilities of both the private and public sector and must be financed out of foreign exchange earnings.
{../fields/227.html#MX)
54.3% of GDP (2017 est.)
56.8% of GDP (2016 est.)
country comparison to the world: 82 (../fields/227rank.htmi#MxX)
Fiscal year (../docs/notesanddefs.html#228): This entry identifies the beginning and ending months for a country’s accounting period of
12 months, which often is the calendar year but which may begin in any month. All yearly references are for the calendar year (CY)
unless indicated as a noncalendar fiscal year (FY).
idl
(../fields/228,.html#MX)
calendar year
Inflation rate (consumer prices) (../docs/notesanddefs.html#229): This entry furnishes the annual percent change in consumer prices
compared with the previous year''s consumer prices.
(..ffields/229, html#MX)
6% (2017 est.)
2.8% (2016 est.)
country comparison to the world: 186 (../fields/229rank.htmi#MX)
Current account balance (../docs/notesanddefs.html#238): This entry records a country’ ''s net trade in goods and services, plus net
earnings from rents, interest, profits, and dividends, and net transfer payments (such as pension funds and worker remittances) to and
from the rest of the world during the period specified. These figures are calculated on an escnange rate basis, i.e., not in purchasing
power parity (PPP) terms.
(ifields/238.htmi#MX)
-$19.35 billion (2017 est.)
-$23.32 billion (2016 est.)
country comparison to the world: 198 (../fi elds/238rank.htmi#MX)
Exports (../docs/notesanddefs.html#239): This entry provides the total US dollar amount of merchandise exports on an f.o.b. (free on
board) basis. These figures are calculated on an exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
(../fields/239,html#MX)
$409.8 billion (2017 est.) -
$374.3 billion (2016 est.)
country comparison to the world: 12 (../fields/239rank.html#MX)
Exports - partners (../docs/notesanddefs.html#241): This entry provides a rank ordering of trading partners starting with the most
important; it sometimes includes the percent of total dollar value.
(../fields/241 .htmi#MX)
US 79.9% (2017)
Exports - commodities (. Idocsinotesanddefs. html#240): This entry provides a listing of the highest-valued exported products; it
sometimes includes the percent of total dollar vaiue.
Le
manufactured goods, electronics, vehicles and auto parts, oil and oil products, silver, plastics, fruits, vegetables, coffee, cotton; Mexico
is the world''s leading producer of silver
Imports (../docs/notesanddefs.html#242): This entry provides the total US dollar amount of merchandise imports on a c.if. (cost,
insurance, and freight) or f.o.b. (free on board) basis. These figures are calcul','d0226b83cce0449d466d4294dc0b5540a81deb5201f28b415b6571738922b16d','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4d188ca54a21a1c836a23e17ab620905ac2f1da9085005f632db885e7e1a710',2018,'','','raw',4,'ated on an exchange rate basis, i.e., not in purchasing
power parity (PPP) terms.
et
(../fields/242.htmH##MX)
$420.8 billion (2017 est.)
$387.4 billion (2016 est.)
country comparison to the world: 14 (../fields/242rank.html#MX)
Imports - commodities (../docs/notesanddefs.html#243): This entry provides a listing of the highest-valued imported products; it
on includes the percent of total dollar vaiue.
ed
(Hields/243. htmi#MX) :
tOOOPESSSPEGG FIGS 4K TRIS 46 ESTT SS EEO OR: C2 TAGE FEGEA-F59F |
Approved for Release: 2022/12/08 C06979333
aircraft, aircraft parts, plastics, natur pproved for Release: 2022/12/08 C06979333 oe
Imports - partners (../docs/notesandGers.mml#403): This entry provides a rank orderiny uru ading partners starting with the most
important; it sometimes includes the percent of total dollar value.
metalworking machines, steel mill ot agricultural macninery, Sieciical Equipme™ —nuUIE pans iul aascniviy anu rspan,
Seat rd
(../fields/403.htmi#MX)
US 46.4%, China 17.7%, Japan 4.3% (2017)
Reserves of foreign exchange and gold (../docs/notesanddefs.html#245): This entry gives the dollar value for the stock of all financial
assets that are available to the central monetary authority for use in meeting a country''s balance of payments needs as of the end-date
of the period specified. This category includes not only foreign currency and gold, but also a country''s holdings of Special Drawing
Rights in the International Monetary Fund, and its reserve position in the Fund.
(..ffields/245.html#MX)
$175.3 billion (31 Decernber 2017 est.)
$178.4 billion (81 December 2016 est.)
note: Mexico also maintains access to an $88 million Flexible Credit Line with the IMF
country comparison to the world: 14 (../fields/245rank.htmi#MX)
Debt - external (../docs/notesanddefs.htmi#246): This entry gives the total public and private debt owed to nonresidents repayable in
internationally accepted currencies, goods, or services. These figures are calculated on an exchange rate basis, i.e., not in purchasing
power parity (PPP) terms. ‘
(..fields/246.html#MX)
$445.8 billion (31 December 2017 est.)
$450.2 billion (31 December 2016 est.)
country comparison to the world: 28 (../fields/246rank.html#MX)
Exchange rates (../docs/notesanddefs.html#249): This entry provides the average annual price of a country''s monetary unit for the time
period specified, expressed in units of local currency per US dollar, as determined by international market forces or by official fiat. The
International Organization for Standardization (ISO) 4217 alphabetic currency code for the national medium of exchange is presented
in parenthesis. Closing daily exchange rates are not presented in The World Factbook, but are used to convert stock values - e.g., the .
.. more (../docs/notesanddefs.html#249)
(..fields/249.html#MX)
Mexican pesos (MXN) per US dollar -
18.26 (2017 est.)
18.664 (2016 est.)
18.664 (2015 est.)
15.848 (2014 est.)
13.292 (2013 est.)
Energy :: Mexico
Electricity access (../docs/notesanddefs.htmi#251): This entry provides information on access to electricity. Electrification data ~
collected from industry reports, national surveys, and international sources — consists of four subfields. Population without electricity
provides an estimate of the number of citizens that do not have access to electricity. Electrification — total population is the percent ofa
country''s total population with access to electricity, electrification — urban areas is the percent of a country''s urban populationw...
more (../docs/notesanddefs.html#251)
(../fields/251.htmi#MX)
electrification - total population: 100% (2016)
Electricity - production (../docs/notesanddefs.htmi#252): This entry is the annual electricity generated expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the amount consumed and/or exported is accounted for
as loss in transmission and distribution.
(.fields/252,htmi#MX)
302.7 billion kWh (2016 est.)
country comparison to the world: 73 (../fields/252rank.htmi#MX)
Electricity - consumption (../docs/notesanddefs.html#253): This entry consists of total electricity generated annuaily plus imports and
minus exports, expressed in kilowatt-hours. The discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and distribution.
_ (#fields/253.html#MX)
258.7 billion kWh (2016 est.)
country comparison to the world: 14 (_/fields/253rank.htmi#MxX)
Electricity - exports (../docs/notesanddefs.html#254): This entry is the total exported electricity in kilowatt-hours.
(..fields/254.html#MX)
7.308 billion kWh (2016 est.)
COUn YS. RAMBATSOR ieuihe wore 2io(--GiPeSZEAPATNS TA2E7G AAAS THBA7S TAETA- AATF: /
Approved for Release: 2022/12/08 C06979333
Electricity - imports (../docs/notesanddefs,html#255): This entry is the total imported e!e~''-ity in kilowatt-hours.
ey GB or0v01 for Release: 2022/12/08 C06979333
(..fields/255.html#MX)
3,532 billion kWh (2016 est.)
country comparison to the world: 47 (..fields/255rank.htmi#MX)
Electricity - installed generating capacity (../docs/notesanddefs.html#256): This entry is the total capacity of currently installed
generators, expressed in kilowatts (kW), to produce electricity. A 10-kilowatt (kW) generator will produce 10 kilowatt hours (kWh) of
electricity, if it runs continuously for one hour.
(../fields/256.html#MX)
72.56 million kW (2016 est.)
country comparison to the world: 17 (../fields/256rank.html#MX)
‘Electricity - from fossil fuels (../docs/notesanddefs.html#257): This entry measures the capacity of plants that generate electricity by
burning fossil fuels (such as coal, petroleum products, and natural gas), expressed as a share of the country''s total generating
capacity.
(..fields/257.html#MX)
71% of total installed capacity (2016 est.)
country comparison to the world: 106 (../fields/257rank.html#MX)
Electricity - from nuclear fuels (../docs/notesanddefs.html#258): This entry measures the ree of plants that generate electricity
through radioactive decay of nuclear fuel, expressed as a share of the country''s total generating capacity.
(Hfields/258. html#MX)
2% of total installed capacity (2017 est.)
country comparison to the world: 27 (../fields/258rank.htmi#MxX)
Electricity - from hydroelectric plants (../docs/notesanddefs.html#259): This entry measures the capacity of plants that generate
a by water-driven turbines, expressed as a share of the country''s total generating capacity.
[iz}¢,
(..ields/259.htmi#MX)
17% of total installed capacity (2017 est.)
country comparison to the world: 96 (../fields/259rank.html#MX)
Electricity - from other renewable sources (../docs/notesanddefs.html#260): This entry measures the capacity of plants that generate
electricity by using renewable energy sources other than hydroelectric (including, for example, wind, waves, solar, and geothermal),
‘ a as a share of the country''s total generating capacity.
( i elds/260.htmi#MX)
9% of total installed capacity (2017 est.)
country comparison to the world: 82 (../fields/260rank.html#MX)
Crude oil - production (../docs/notesanddefs.html#261): This entry is the total amount of crude oil produced, in barrels per day
(bbi/day).
(../fields/261 .html#MX)
1.852 million bbi/day (2018 est.)
country comparison to the world: 13 (../fields/261rank.html#MX)
Crude oil - exports (../docs/notesanddefs.html#262): This entry is the total amount of crude oil exported, in barrels per day (bbi/day).
(../fields/262.html#MX)
4.214 million bbi/day (2017 est.)
country comparison to the world: 11 (../fields/262rank.html#MX)
Crude oil - imports (../docs/notesanddefs.html#263): This entry is the total amount of crude oil imported, in barrels per day (bbi/day).
(..fields/263.htmi#MX)
0 bbi/day (2017 est.)
country comparison to the world: 166 (../fields/263rank.himl#MX)
Crude oil - proved reserves (../docs/notesanddefs.html#264): This entry is the stock of proved reserves of crude oil, in barrels (bbl).
Proved reserves are those quantities of petroleum which, by analysis of geological and engineering data, can be estimated with a high
degree of confidence to be commercially recoverable from a given date forward, from known reservoirs and under current econornic
conditions.
(..ffields/264.htmH#MX)
6.63 billion bbl (1 January 2018 est.)
country comparison to the world: 19 (../fields/264rank.html#MX)
Refined petroleum products - production (../docs/notesanddefs.html#265): This entry is the country''s total output of refined petroleum
products, in barrels per day (bbi/day). The discrepancy between the amount of refined petroleum products produced and/or imported
the amount consumed and/or exported is due to the omission of stock changes, refinery gains, and other complicating factors.
Ely:
(../fields/265.html#MX) : ;
B441GOO Ody A204Mest.} FHST AG ARTI 1A sGSEFAG TAPHOR PHS PHA AR FER TA-45-44
Approved for Release: 2022/12/08 C06979333
Refined petroleum products - cons pproved for Release: 2022/12/08 C069793330uNtIy''s total consumption of refined
petroleum products, in barrels per d day). The discrepancy between the amou... -. ....ned petroleum products produced and/or
imported and the amount consumed and/or exported is due to the omission of stock changes, refinery gains, and other complicating
factors.
country comparison to the world: 23 GB ro vesterres
(../fields/266.html#MX)
1.984 million bbi/day (2017 est.)
country comparison to the world: 11 (../fields/266rank.html#MX)
Refined petroleum products - exports (../docs/notesanddefs.html#267): This entry is the country''s total exports of refined petroleum
products, in barrels per day (bbi/day).
(../fields/267 .html#MX)
155,800 bbl/day (2017 est.)
country comparison to the world: 35 (../fields/267rank.html#MX)
Refined petroleum products - imports (../docs/notesanddefs.html#268): This entry is the country''s total imports of refined petroleum
products, in barrels per day (bbi/day).
(../fields/268.html#MX)
867,500 bbi/day (2017 est.)
country comparison to the world: 10 (../fields/268rank.htmi#MX)
Natural gas - production (../docs/notesanddefs.html#269): This entry is the total natural gas produced in cubic meters (cu m). The
discrepancy between the amount of natural gas produced and/of imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
(../fields/269.html#MX)
31.57 billion cu m (2017 est.)
country comparison to the world: 24 (../fields/269rank.html#MX)
Natural gas - consumption (../docs/notesanddefs.html#270): This entry is the total natural gas consumed in cubic meters (cu m). The
discrepancy between the amount of natural gas produced and/or imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
Ee
(../fieids/270.htmi#MX)
81.61 billion cu m (2017 est.)
country comparison to the world: 9 (../fields/270rank. html#MX)
Natural gas - exports (../docs/notesanddefs.html#271): This entry is the total natural gas exported in cubic meters (cu m).
(..fields/27 1.html#MX)
36.81 million cu m (2017 est.)
country comparison to the world: 51 (../fields/27 1rank.html#MX)
Natural gas - imports (../docs/notesanddefs.htmi#272): This entry is the total natural gas imported in cubic meters (cu m).
(../fields/272.htmi#MX)
50.12 billion cu m (2017 est.)
country comparison to the world: 8 (../fields/272rank.html#MX) :
Natural gas - proved reserves (../docs/notesanddefs.htmi#273): This entry is the stock of proved reserves of natural gas in cubic
meters (cu m). Proved reserves are those quantities of natural gas, which, by analysis of geological and engineering data, can be
estimated with a high degree of confidence to be commercially recoverable from a given date forward, from known reservoirs and
under current economic conditions.
(..Mields/273.html#MX)
279.8 billion cu m (1 January 2018 est.)
country comparison to the world: 38 (..fields/273rank.html#MX)
Carbon dioxide emissions from consumption of energy (../docs/notesanddefs.html#274): This entry is the total amount of carbon
dioxide, measured in metric tons, released by burning fossil fuels in the process of producing and consuming energy.
(../fields/274.html#MX)
454.1 million Mt (2017 est.)
country comparison to the world: 14 (../fields/274rank.html#MX)
Communications :: Mexico
Telephones - fixed lines (../docs/notesanddefs.html#196): This entry gives the total number of fixed telephone lines in use, as well as
the number of subscriptions per 100 inhabitants.
!
(../fields/196.html#MX)
total subscriptions: 21,645,699
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 12 (../fields/196rank.html#MX)
+AOOETEATPLGG tIGTt4G GLAT4G TH GSEF4S FAOAPH PHIGe HASH TERtA-4099
Approved for Release: 2022/12/08 C06979333
Telephones - mobile cellular (../doc
subscribers, as well as the number
developed countries, the number of
pproved for Release: 2022/12/08 C06979333¢ Ubiquity of mobile phone use in
ptions per 100 inhabitants can exceed 10L.
yee 97): This entry gives the tote! ™''''™ner of Mobile Celular teiepnone
[ey
(..fields/197.htmi#MX)
total subscriptions: 120,173,510
subscriptions per 100 inhabitants: 95 (2018 est.)
country comparison to the world: 14 (../fields/197rank.html#MX)
Telecommunication systems (../docs/notesanddefs.html#198): This entry includes a brief general assessment of a country''s
telecommunications system with details on the domestic and international components. The following terms and abbreviations are
used throughout the entry: 2G - is short for second-generation cellular network. After 2G was launched, the previous mobile wireless
network systems were retroactively dubbed 1G. While radio signals on 1G networks are analog, radio signals on 2G networks
are digital. Both systems use digital signaling . . . more (../docs/notesanddefs. html#198)
Ey
(..fields/198.htmi#MX)
general assessment: adequate telephone service for business and government; improving quality and increasing mobile cellular
availability, with mobile subscribers far outnumbering fixed-line subscribers; relatively low broadband and mobile penetration, potential
for growth; extensive microwave radio relay network; considerable use of fiber-optic cable and coaxial cable; two main MNOs despite
efforts for competition; 5G development slow given the existing capabilities of LTE; Mexico''s first local Internet Exchange Point opens in
Mexico City; regulator strives to bring competition and foreign investment to Mexico; regulator brings back SIM card registration program
(2020)
domestic: competition has spurred the mobile-cellular market; fixed-line teledensity exceeds 17 per 100 persons; mobile-cellular
teledensity is about 95 per 100 persons; domestic satellite system with 120 earth stations (2018)
international: country code - 52; Columbus-2 fiber-optic submarine cable with access to the US, Virgin islands, Canary Islands, Spain,
and Italy; the ARCOS-1 and the MAYA-1 submarine cable system together provide access to Central America, parts of South America
and the Caribbean, and the US; satellite earth stations - 120 (32 Intelsat, 2 Solidaridad (giving Mexico improved access to South
America, Central America, and much of the US as well as enhancing domestic communications), 1 Panamsat, numerous Inmarsat
mobile earth stations); linked to Central American Microwave System of trunk connections (2016)
the COVID-19 outbreak is negatively impacting telecommunications production and supply chains globally; consumer spending on
telecom devices and services has also slowed due to the pandemic''s effect on economies worldwide; overall progress towards
improvements in all facets of the telecom industry - mobile, fixed-line, broadband, submarine cable, and satellite - has moderated
Broadcast media (../docs/notesanddefs.html#199): This entry provides information on the approximate number of public and private TV
and radio stations in a country, as well as basic information on the availability of satellite and cable TV services.
(../fields/499.htmi#MX)
telecom reform in 2013 enabled the creation of new broadcast television channels after decades of a quasi-monopoly; Mexico has 821
TV stations and 1,745 radio stations and most are privately owned; the Televisa group once had a virtual monopoly in TV broadcasting,
but new broadcasting groups and foreign satellite and cable operators are now available; in 2016, Mexico became the first country in
Latin America to complete the transition from analog to digital transmissions, allowing for better image and audio quality and a wider
selection of programming from networks :
Internet country code (../docs/notesanddefs.htmi#202): This entry includes the two-letter codes maintained by the International
Organization for Standardization (ISO) in the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers Authority (IANA) to
country-coded top-level domains (ccTLDs).
Bay
(..fields/202.htmi#MX)
.mx
Internet users (../docs/notesanddefs.html#204): This entry gives the total number of individuals within a country who can access the
internet at home, via any device type (computer or mobile) and connection. The percent of population with Internet access (i.e., the
penetration rate) helps gauge how widespread Internet use is within a country. Statistics vary from country to country and may include
a who access the Internet at least several times a week to those who access it only once within a period of several months.
ig)
(../fields/204 html#MX)
total: 82,843,369
percent of population: 65.77% (July 2018 est.)
country comparison to the world: 9 (../fields/204rank.html#MX)
Broadband - fixed subscriptions (../docs/notesanddefs.html#206): This entry gives the total number of fixed-broadband subscriptions,
as well as the number of subscriptions per 100 inhabitants. Fixed broadband is a physical wired connection to the Internet (e.g., coaxial
cable, optical fiber) at speeds equal to or greater than 256 kilobits/second (256 kbit/s).
f
(../fields/206.htmi#MX)
total: 18,359,028
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 10 (..Mields/206rank.himl#MX)
Military and Security :: Mexico
Military and security forces (../docs/notesanddefs.html#331): This entry lists the military and security forces subordinate to defense
ministries or the equivalent (typically ground, naval, air, and marine forces), as well as those belonging to interior ministries or the
equivalent (typically gendarmeries, border/coast guards, pare Te police, and other internal security forces),
toe
FROROETESQECRG «FIOST4A GPATGG 7G :ASt74& FOGG 2H5R TAOPG THBTA-TS
Approved for Release: 2022/12/08 C06979333
a
(../fields/33 1 .Atml#MX) Approved for Release: 2022/12/08 C06979333
Secretariat of National Defense (Sec... «we Defensa Nacional, SEDENA): Army (Ejc.~...,, Mexican Air Force (Fuerza Aerea
Mexicana, FAM); Secretariat of the Navy (Secretaria de Marina, SEMAR): Mexican Navy (Armada de Mexico (ARM), includes Naval Air
Force (FAN), Mexican Naval Infantry Corps (Cuerpo de Infanteria de Marina, Mexmar or CIM)); Ministry of Security and Citizen
Protection: Federal Police (includes Gendarmerie), National Guard (2019)
note: the National Guard was formed in 2019 and consists of personnel from the Federal Police and military police units of the Army and
Navy
Military expenditures (../docs/notesanddefs.html#330): This entry gives estimates on spending on defense programs for the most
recent year available as a percent of gross domestic product (GDP); the GDP is calculated on an exchange rate basis, i.e., not in terms
of purchasing power parity (PPP). For countries with no military forces, this figure can include expenditures on public security and
police. :
(../fields/330.html#MX)
0.5% of GDP (2019)
0.54% of GDP (2018)
0.47% of GDP (2017)
0.56% of GDP (2016)
0.66% of GDP (2015)
country comparison to the world: 148 (../fields/330rank.htmi#MX)
Military and security service personnel strengths (../docs/notesanddefs.html#410): This entry provides estimates of military and security
services personnel strengths. The numbers are based on a wide-range of publicly available information. Unless otherwise noted,
military estimates focus on the major services (army, navy, air force, and where applicable, gendarmeries) and do not account for
activated reservists or delineate military service members assigned to joint staffs or defense ministries.
EM
(../fields/410.htmi#MX)
the Mexican armed forces have approximately 270,000 active personnel (200,000 Army; 60,000 Navy; 8,000 Air Force); approximately
60,000 National Guard (2019 est.)
Military equipment inventories and acquisitions (../docs/notesanddefs.html#4 11): This entry provides basic information on each
country''s military equipment inventories, as well as how they acquire their equipment; it is intended to show broad trends in major
military equipment holdings, such as tanks and other armored vehicles, air defense systems, artillery, naval ships, helicopters, and
fixed-wing aircraft. Arms acquisition information is an overview of major arms suppliers over a specific period of time, including second-
hand arms delivered as aid, with a focus on m. . . more (../docs/notesanddefs.html#4 11)
et
(.. Mields/411 btmi#MX)
the Mexican military inventory includes a mix of domestically-produced and imported equipment from a variety of mostly Western
suppliers; since 2010, France, Spain, and the US are the leading suppliers of military hardware to Mexico; Mexico''s defense industry
produces naval vessels and light armored vehicles (2019 est.)
Military service age and obligation (../docs/notesanddefs.htmi#333): This entry gives the required ages for voluntary or conscript
military service and the length of service obligation.
(../fields/333.html#MX)
18 years of age for compulsory military service (selection for service determined by lottery), conscript service obligation is 12 months; 16
years of age with consent for voluntary enlistment; cadets enrolled in military schools from the age of 15 are considered members of the
armed forces; women are eligible for voluntary military service (2012)
Transportation :: Mexico
National air transport system (../docs/notesanddefs.html#377): This entry includes four subfields describing the air transport system of
a given country in terms of both structure and performance. The first subfield, number of registered air carriers, indicates the total
number of air carriers registered with the country''s national aviation authority and issued an air operator certificate as required by the
Convention on International Civil Aviation. The second subfield, inventory of registered aircraft operated by air carriers, lists the total
number .. . more (../docs/notesanddefs.html#377)
(.ields/377.htmi#MX)
number of registered air carriers: 21 (2015)
inventory of registered aircraft operated by air carriers: 357 (2015)
annual passenger traffic on registered air carriers: 45,560,063 (2015)
annual freight traffic on registered air carriers: 713,985,467 mt-km (2015)
Civil aircraft registration country code prefix (../docs/notesanddefs.html#378): This entry provides the one- or two-character
alphanumeric code indicating the nationality of civil aircraft. Article 20 of the Convention on International Civil Aviation (Chicago
Convention), signed in 1944, requires that all aircraft engaged in international air navigation bear appropriate nationality marks, The
aircraft registration number consists of two parts: a prefix consisting of a one- or two-character alphanumeric code indicating nationality
and a registration suffix of one to fi... more (../docs/notesanddefs.html#378)
(..fields/378.html#MX)
XA (2016)
Airports (../docs/notesanddefs.html#379): This entry gives the total number of airports or airfields recognizable from the air. The
runway(s) may be paved (concrete or asphalt surfaces) or unpaved (gr','3f4602db5aa5ed8009e7f578c5f9b726f8d6ac6eabfb2fb1b7b4bcf020770017','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55e3d8121cc77b5da3638efbee582aa78a7e65c42573b70b777c8c18cf7401a1',2018,'','','raw',5,'ass, earth, sand, or gravel surfaces) eng, may include closed or
$PORTETLICGGE FOUTS GERT4H TA VERtF4S LAOMCH PACES TEGRPS TATA
Approved for Release: 2022/12/08 C06979333
abandoned installations. Airports or ~**~''“~ that are no longer recognizable (overgrov''" ~~ “aciiues, ew; are Hot iGiuueY, ote iat
not all airports have accommodatio! Approved for Release: 2022/12/08 C06979333
(ey
(..fields/379.htmi#MX)
1,714 (2013)
country comparison to the world: 3 (../fields/379rank.html#MX)
Airports - with paved runways (../docs/notesanddefs.html#380): This entry gives the total number of airports with paved runways
(concrete or asphalt surfaces) by length. For airports with more than one runway, only the longest runway is included according to the
following five groups - (1) over 3,047 m (over 10,000 ft), (2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000 to 8,000
ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5) under 914 m (under 3,000 ft). Only airports with usable runways are included in this
listing. Not all... more (../docs/notesanddefs.html#380)
(../fields/380.html#MX)
total: 243 (2017)
over 3,047 m: 12 (2017)
2,438 to 3,047 m: 32 (2017)
1,524 to 2,437 m: 80 (2017)
914 to 1,523 m: 86 (2017)
under 914 m: 33 (2017)
Airports - with unpaved runways (../docs/notesanddefs.html#381): This entry gives the total number of airports with unpaved runways
(grass, dirt, sand, or gravel surfaces) by length. For airports with more than one runway, only the longest runway is included according
to the following five groups - (1) over 3,047 m (over 10,000 ft), (2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000 to
8,000 ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5) under 914 m (under 3,000 ft). Only airports with usable runways are included in
this listin. .. more (../docs/notesanddefs.html#381) :
P ;
(..ields/381 btmi#MX)
total: 1,471 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 42 (2013)
914 to 1,523 m: 281 (2013)
under 914 m: 1,146 (2013)
Heliports (../docs/notesanddefs.html#382): This entry gives the total number of heliports with hard-surface runways, helipads, or
landing areas that support routine sustained helicopter operations exclusively and have support facilities including one or more of the
following facilities: lighting, fuel, passenger handling, or maintenance. It includes former airports used exclusively for helicopter
operations but excludes heliports limited to day operations and natural clearings that could support helicopter landings and takeoffs.
rf.
(./fields/382.htmi#MX)
4 (2013)
Pipelines (../docs/notesanddefs.htmi#383): This entry gives the lengths and types of pipelines for transporting products like natural gas,
crude oil, or petroleum products.
15,986 km natural gas (2019), 10,365 km oil (2017), 8,946 km refined products (2016)
Railways (../docs/notesanddefs.html#384): This entry states the total route length of the railway network and of its component parts by
gauge, which is the measure of the distance between the inner sides of the load-bearing rails. The four typical types of gauges are:
broad, standard, narrow, and dual. Other gauges are listed under note. Same 60% of the world''s railways use the standard gauge of
1.4 m (4.7 ft). Gauges vary by country and sometimes within countries. The choice of gauge during initial construction was mainly in
resp... more (../docs/notesanddefs.html#384)
EN
(..fields/384,htmt#MX)
total: 20,825 km (2017)
standard gauge: 20,825 km 1.435-m gauge (27 km electrified) (2017)
country comparison to the world: 14 (../fields/384rank.himl#MX)
Roadways (../docs/notesanddefs.htmi#385): This entry gives the total length of the road network and includes the length of the paved
and unpaved portions.
ey :
(../fields/385.htmi#MX)
total: 398,148 km (2017) ;
paved: 174,911 km (includes 10,362 km of expressways) (2017)
unpaved: 223,237 km (2017)
country comparison to the world: 18 (../fields/385rank.himl#MX)
Waterways (../docs/notesanddefs.html#386): This entry gives the total length of navigable rivers, canals, and other inland bodies of
water. aad
(-ffields/386.htmi#MX)
2,900 km (navigable rivers and coastal canals mostly connected with ports on the country''s east coast) (2012)
country comparison to the world: 33 (../fields/386rank.himl#MX) oo ek ein Feet A aCe
Approved for Release: 2022/12/08 C06979333
Merchant marine (../docs/notesandd=f= #14387): This entry provides the total and tr ~~ er of eacn type OT privaleély or pupiicry
owned commercial ship for each co Approved for Release: 2022/12/08 C06979333!clude: bulk carrier - for cargo such as
coal, grain, cement, ores, and grave., u.....ner ship - for loads in truck-size containers, « «.1sportation system called containerization;
general cargo - also referred to as break-bulk containers - for a wide variety of packaged merchandise, such as textiles, furniture . ..
more (../docs/notesanddefs.html#387)
er
(..fields/387 htmi#MX)
total: 637
by type: bulk carrier 6, general cargo 10, oil tanker 35, other 586 (2019)
country comparison to the world: 35 (../fields/387 rank.html#MX)
Ports and terminals (../docs/notesanddefs.html#388): This entry lists major ports and terminals primarily on the basis of the amount of
cargo tonnage shipped through the facilities on an annual basis. in some instances, the number of containers handled or ship visits
were also considered. Most ports service multiple classes of vessels including bulk carriers (dry and liquid), break bulk cargoes (goods
loaded individually in bags, boxes, crates, or drums; sometimes palletized), containers, roll-on/roll-off, and passenger ships. The listing
le... more (../docs/notesanddefs.html#388) ,
(..Aields/388.htmlf#MX)
major seaport(s): Altamira, Coatzacoalcos, Lazaro Cardenas, Manzanillo, Veracruz
oil terminal(s): Cayo Arcas terminal, Dos Bocas terminal
cruise port(s): Cancun, Cozumel, Ensenada
container port(s) (TEUs): Manzanillo (2,830,370), Lazaro Cardenas (1,149,079) (2017)
LNG terminal(s) (import): Altamira, Ensenada
Transnational Issues :: Mexico
Disputes - international (../docs/notesanddefs.html#326): This entry includes a wide variety of situations that range from traditional
bilateral boundary disputes fo unilateral claims of one sort or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State. References to other situations involving borders or frontiers
may also be included, such as resource disputes, geopolitical questions, or irredentist issues; however, inclusion does not necessarily
constitute .. . more (../docs/notesanddefs.html#326)
ir
abundant rainfall in recent years along much of the Mexico-US border region has ameliorated periodically strained water-sharing
arrangements; the US has intensified security measures to monitor and control legal and illegal personnel, transport, and commodities
across its border with Mexico; Mexico must deal with thousands of impoverished Guatemalans and other Central Americans who. cross
the porous border looking for work in Mexico and the US; Belize and Mexico are working to solve minor border demarcation
discrepancies arising from inaccuracies in the 1898 border treaty
Refugees and internally displaced persons (../docs/notesanddefs.htmi#327): This entry includes those persons residing in a country as
refugees, internally displaced persons (IDPs), or stateless persons. Each country''s refugee entry includes only countries of origin that
are the source of refugee populations of 5,000 or more. The definition of a refugee according to a UN Convention is "a person who is
outside his/her country of nationality or habitual residence; has a well-founded fear of persecution because of his/her race, religion,
nationality, membership in a . . . more (../docs/notesanddefs.html#327)
(../fields/327.html#MX)
refugees (country of origin): 5,155 (El Salvador) (2018); 73,494 (Venezuela) (economic and political crisis; includes Venezuelans who
have claimed asylum, are recognized as refugees, or have received alternative legal stay) (2020) ‘ ‘
IDPs: 345,000 (government''s quashing of Zapatista uprising in 1994 in eastern Chiapas Region; drug cartel violence and government''s
military response since 2007; violence between and within indigenous groups) (2019)
stateless persons: 13 (2018)
Illicit drugs (../docs/notesanddefs.html#329): This entry gives information on the five categories of illicit drugs - narcotics, stimulants,
depressants (sedatives), hallucinogens, and cannabis. These categories include many drugs legally produced and prescribed by
doctors as well as those illegally produced and sold outside of medical channels. Cannabis (Cannabis sativa) is the common hemp
plant, which provides hallucinogens with some sedative properties, and includes marijuana (pot, Acapulco gold, grass, reefer),
tetrahydroca . . . more (../docs/notesanddefs.html#329)
(../fields/329.html#MX)
major drug-producing and transit nation; Mexico is estimated to be the world''s third largest producer of opium with poppy cultivation in
2015 estimated to be 28,000 hectares yielding a potential production of 475 metric tons of raw opium; government conducts the largest
independent illicit-crop eradication program in the world; continues as the primary transshipment country for US-bound cocaine from
South America, with an estimated 95% of annual cocaine movements toward the US stopping in Mexico; major drug syndicates control
the majority of drug trafficking throughout the country; producer and distributor of ecstasy; significant money-laundering center; major
supplier of heroin and largest foreign supplier of marijuana and methamphetamine to the US market
Privacy (/about-cia/site-policies/#privacy-notice) Copyright (/about-cia/site-policies/#copy)
De wk A 8 RE Re EE et ek EP
Approved for Release: 2022/12/08 C06979333
Site Policies (/about-cia/site-policie-" *~ USA. cov (http:/Awww.ur 7 0")
Approved for Release: 2022/12/08 C06979333
FOIA (https:/Mwww.cia.govilibrary/r LINE. YUY UInparwy weer
NoFEAR Act (/about-cia/no-fear-act/) Inspector General (/offices-of-cia/inspector-general/)
Contact CIA Site Map (/sitemap.html)
KGOV :
(/open/)
GO TOP
eet A Sie EO 2 ae TEBEE-40 94
Approved for Release: 2022/12/08 C06979333','f8f59d909f413d90321c580dad2babfef6b3506d7b05ce1cfa2478468dfc27f9','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e4efde8d148717f4bb59f2cd3fca2c639eb0602d8925b7be410c543300a9a24',2018,'','','raw',1,'Approved for Release: 2018/04/27 C06727039
>
“NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this “ ARCHIVAL RECOR!
Factbook, copies of which should be destroyed FLEAS? RETURN TO ;
AGENCY ARCHIVES, ELDG. 4+.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published
semiannually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by Office of the Geographer, Department of
State and by components of the Defense Intelligence Agency
and the Central Intelligence Agency. Comments and suggestions
should be addressed to the Office of Basic and Geographic
Intelligence (Attn: NIS Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Additional copies of the Factbook, both classified and un-
classified issues, are obtainable through established channels for
dissemination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF THE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTHORIZED PERSON IS PROHIBITED BY LAW.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(OC) testes Confidential
(S)ve. 32) Secret
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
“SECRET.
Table of Contents
Page
SAN: MARINO: ce 6 cee See ge Sere Se a lade Gee an A ee ie a ae 383
SAUDE ARABIA g:o5 3 sd. ceed & Reel Se) eS ee es 385
SENEGAL 2. fms oe So te a te Se at ee LE Si eh aes PE eee 387
SEYCHELLES cigar ee eas oe be este eS he Ge so es eee Sa ae So Be 389
Sharjah (see UNITED ARAB EMIRATES)
STERRA (LEONE: ~) 05. &. gee Sees ete A Sa ae te Re ey ne ye pe en ee 391
ST KKEM 3.2 caste see A es ce sl ee Gave Con Be eee, Ree ee We eS 393
STINGAPORE 6 ~ eieccoe otesecs desea We: obo eG" Annee Moh ee io oes nao es Wee eee 395
SOMALTA Sic: senor SBS ee Pa EE ne ae ie een ee eee “al GE ws Rees of? 397
SOUTH: AFRICA? oc. cei eo 8 See eer te ar ee Ss Tee 0 We ee Se 399
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA. . . 2. 2 1 ee we ee te we te 403
SPAINGG se Se oe Se ee ls Ba Sera tS re wl hee os tay Janine 8s 405
SPANTSH ‘SAHARA 5. 232-0. ee kee ee ee see ee eee ww Ce 409
SRE LANKA Ses setae ib tie es re ote Sore a wren ie) eo ee tated See ae 411
SUDAN o. ie-.g. oe sehen Sek mol as he Bh “Seer se tgs Sha tah re win et ems NS Ge tee eh oe 415
SURINAME. 02 xsc260 ve sei Soro ce A SE ee eR he ee as ar tar Sh eee eee 419
SWAZILAND =. 2.62 ccs S) nO ee Fe Oo Se Blea Mek % Bee, Byway teu ke 421
SWEDEN cue ce nea caetot le conte on medic phase, Gti Gams Mean Se 423
SWITZERUAND sc od ce ''o: 1,006 os van ts Fen Saas Ag Be, eae! Tey Cage 427
SYR TRG oy ec secs etek be ee ek eng es areas 429
-T:
Tanganyika (see TANZANIA)
TANZANTAS ob cake. oie eh ce etn eh nin 8 Case a a te cle Ca aS wate Se 431
Tasmania (see AUSTRALIA)
THAILAND 3. wc -8 we ees eR ee be aoe & ie we ee 495
TOGO a: yee UR Ow aw ae ee wd Se ee A Se wee ee 439
TONGA © 6. edge ee Se Sc ae eS rae ; : ‘ 44]
oe AND TOBAGO. F Bae bode al eh awe hare ee ss . . =. 443
iia Bah GPL Baa aE ND ON Cie DER ea vs ect aay ce Fs 445
TURKEY gn eh weet Ai APS ae i sg ge eet, BMG ee eit te aa Sk: 447
-U-
UGANDA 555 io oe eo do reser ree ee nse ae a eles wes es ee 451
nes al Qaiwain (see UNITED ARAB EMIRATES)
Sk, ake Byles Be Sw Gon Ey fa els NDR ne Ot age, ee 453
ED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain. ........2... 457
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 1 we ee ee ee we tt ee te et 459
UNETED “STATES. o°-2 oc. se? Gece oe an ce ere Vel Gh ewe Sal Bek ele ne a 497
UPPER: VOLTA so: o:ce) te tee es oe I ee Be BO be Oe bes 463
URUGUAY cei eo ie eho eae Ser ay Boal ww Boer SP Gee: Be, Sas 82 weer 8 465
-V-
VATICAN: CLI a: 22-2, ecg: sés fortes Se et Se ea SCR te. ae a Gales 469
VENEZUELA se 5- ower ver era RS, “eee eee te yee el HS Bey Sere Re 471
VIETNAM, ‘NORTH gees detec tee ca eel ceive ei Ba ee ee 475
VEETNAM,. “SQUTHD ec. ce ios wee ae Se ee ee ae ee EP 479
v
SEGRE.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
““SRCRET.
NIS 27 TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.','d81506181d04ffbecc364831122ff5a940f94bbc6ccef504917bcbbdae630814','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9cc90cbf6118ba10eb5fcfa09f496809f131edc26f0776e5730e2a64786a8bb',2018,'','','raw',1,'Approved for Release: 2025/12/08 C071 83805,
Venezuela ‘Or Wot Fok
Cont ili hi
blcatons a
World Facthook (lbraryipublicatjonsl
Approved for Release: 2025/12/08 C07183805
‘Approved for Release: 2025/12/08 CO7183805.
~ Background (- MocaMnotneariddetd himiv25): This entry usually highlights major historic eventa end current lesuee end
* Inglude & statement about one or two kay future trenda, a : : ed
a. nee "Qc a ~
es ons of three couririea that emerged from the colapee of Gran Coloribla In 1830 (the others ng''Eouedor and)
: » New Granadb which became Coloma), For moet ofthe fr helo he 20h cortury, Venaziele was fed by pevesaly :
: benavolent pale puangTen who promoted the cll Industry and lowed for some social reforms. Democretically elected L-
pd Its powers
; ing witlespread shortages of basis consumer goods, medicine, and medical suppliey.
+ Geography f: Venezuela : : i ‘ 4 ; ‘
Location (. regia endde himis276): This entry Kientifies the country’s regional location, neighboring countries, and
Norther Soith America, dering the Caribbean Sea end the North Avetic Ocean, between Colombia grid Guyana
sognap d ‘This entry Includes rounded latflude and longitude Eigures for the
centroid orjcanter point of a j expreased in degrees and minutes; & ia based on the focations the
Names Seive {GN8), matninined by the National Geospaiis}intatigence Agency on behalf of the US Board on Geographic
re : : . : s oa
7" (Mfieidal27?. . ts :
, SOON, s8gaw 7 : sts ; 7 7 Q
Map reference: (docainotesanddefa,htmi#276): This entry Includes the name of the Factbook reference map on which ''@ ,
iad, GOUurty be fours’. Note that boundary representations on these mapa are not necessasfly authoritative. The entryon -
77. ae phi coordinates msy be helpful in finding some emaier counties. . 4
‘South Ametica =~ :
“Area (_Jddeslnotesanddefs.htmit270}: Thie entry Includes three subflads, Total area le the aurn of ail lard and water areas
debmited & ‘international boundaries and/oc constines. Land area Is tha aggregate ofall surfaces delimited by
intemational ~
. 7, bound op andior cosstines, excluding inland water bodies (lakes, reservors, rivera), Water aréa Is the eum of the surfaces of
2-2; 2 ate bodies, such as lakes, feservoirs, or vers, es delintied by Imlarnetional boundaries andlor coastlines.
ei: z . : - ; é. eae :
''. ,, “htips://spww.cia.govlibreryfpublications/the-world-fubtbook/geos/vehtml °° ~=—=—=—«5/17/2019
etter nntaerremnerrrn FA ODTOVE for Release: 2025/12/08 CO7183805-———-______-
‘Approved for Release: 2025/12/08 CO7183805:
qm (. octane anak This try
: ations Convention Law of
hat hui more moderate in noha
“Terrain (./doea
6, Cee ‘
“A hains and Maracaibo | Lowands’ in narthweat — pains fiignos);’ Gulane Highlands In gor saat a
; “Zevaton t pie aca This entry neces the ‘mean nacelle and sievatlon sx a8, — pole ind,
“Iga polnd Cartobean Sea 0 m
Hanes Pico Bolivar 4,878 m
m Pp fs t- a , oy
,cia.govilibeésy/publivationsithe-world-féétbook/geas/ve.htm! “. S/LF#2019''. *
Approved for Release: 2025/12/08 C07183805
Approved for Release: 2025/12/08 CO7183805.
Venezuela ~@ue World Factbook = Central Intelligenc@Meency *) Page 4 of 28 °
3 ose ( MdocaMnotenandcte.himis287): T Ta enty ists « country’s miners, pairoloum; hylropower, and other
senqurces of mercial importance, such as rere earlit elements (REEs) fn goniea, procs eppede :
ee hss es
” rubber that a Se pane caehe te ease Srerefeieyen cpl
Balhuhi#VE)
‘aban ot eet 008 2 4
. ) it pra sar: 2.08 01 eet)
“Tota (seaman Ty eer sat ct daa ta
89. htmiVE) , oe a0
dish (.fdocamoteehnddefa himlsS4a): This erty providoe anna aise Hm pn apr
it eine pen ah, dost ve ery ge. csi
.
0 be coiatdits isi neni weetem
_— 4 an ic ng eto srt nora st
U4 {. tmilk2e2); Th ny Int pote neural ators, For curries whore volo
# volcantem subfield highlights history acve volcancea.
‘
IrimidA284):
J exvtronmental egreements into two levels « ee ee ee feted in *
ee ee ts .
& farciic Treaty, victim Climate Change, Climate Change-Xyoto Protoca, Desertifoation, Eni
Hazardous fap m Mariné Life Consecvation, Ozote Scions
; o jected agreements
nae ey ie nn pe tn.
a
try en ma rine os — a
.
sa hoe somo ofthe moei unique gectogy in he word: tapua are mesaive table-top mountains ofthe western,
ighlands that tend to be fecleted.and thus support unique endemic plant and animal species; thelr sheer cffsides
i gore of fre moet epeciaculerweterae in the word inung Angel Fa, te west highest 070 fat crops of.
1
cis. gov/library/publications/the-world-fidtbook/geos/ve.html snag S
i
Approved for Release: 2025/12/08 C07183805. ~
Approved for Release: 2025/12/08 CO7183805.
“South Amé ca : Venezuela he World Factbook - Central Inteligenf{\\gency Page Sof 28 =
Acapecred {Jecandasandt ini; Ti ry geen eto fom te Us Buea te Canin bone ot dior
popula) Censuses, vitel siatieticg registration aysterns, or sample surveys pertaining to the recent end] on
pi bout fulure trends, The tote! population presents one overall messure of the potential Impact of country on the
on to the world: 43 (Miekial336renk himieve} ©
Simla): a Say eres Pa amet ing Nene Se ewe -naun nd eect,
an(s) “ ; 4 :
gro (celtic ng ok ip tog wh eye
: p nageen pee of pocuny ‘
Bp fen, Poruguoes Arab, German, Affican, Indigenous paople -
k.Mocahotosandde sry rok bg engage ack nach any a wan,
* ny thet Oficial netionsl or regional languages: “When dete Is avaliable, the languages spoken in each courffry are broken
. down accord 9 ton paca ofthe taal popuationepecing sch enguge on at language For hose core wit:
ve fears ia cr bad ners age onan GN 7
{ Q dialects
_, Rafigionsa (4 docenotesanddets, himi#401); Tie nti an ordered Bing of regione ty adherens stating withthe largest :
i otimes includes the percert of total population. The core chanscterietica and and Walefe of the world''s major religions
ip bd below. Bahat- + Founded by Mirza HusayreAd (known 8s Babalu''ah) in iran in 1852, Baha''t faith
fv and peace mon (-AcceenSaS aR une HAY oan cn ea ie
oe and peace m... smora (..Adocainctesanddats.himi#4ot) :
a
Par
ot pmieVE) ae . ;
cprofile (idoceénotesenddats, himi#S40): This entry describes a country’s key key domographis festures and trends
pre ow bs vary among ragional, ay eee eae ne ecrne cts hes emma mo papas
clure, Tertitty, heath, mortality, poverty, Oo ee
| benVE) ae 5 ond : Php
ent in Venequela during the CHAVEZ reduced poverty from nearly’ 50% in 1900 to shout 27%
Gecressed infant and chid mortality, and improved ecosas to potable water and
social Investment. "Missions" fo education, ‘care, and sankation were funded through
5 While CHA sas pitino and upper-ciasa Venéduslana are esiimated to have
emigrated. pail =tereocaret fe lcnetry ormerh. paral aipartairevghaa rates onder aca
6 avaabiity of education and health cara, Venezuele lao has been a felty accommodating host to Colombian
ambering about 170,000 as of year-end 2016. However, since 2014, falling oll prices have driven a mejor economic
as pushed Venecuelans petefee today Pobelyey aroha nl fmpernoey hy rng
See aaa ene cee <x STA0I9 >
Approved for Release: 2025/12/08 C07183805. = as
hy
South Amefica !: Venezuela oe World Factbook - Central eg "Page 6 of 28 .
and to deport Megal Venezusien migrants - Ecuador and Peru in August 2016 Began requiring valid passports for
aaa Obtein fos Veneauelens, eae aaa re ag to avoid econ cope st
é
‘
iniBAVE)
0-14 year: "04% (ral 4800 906 Nemo 4,170,618)
6-24 years: 16.82% (mala 2,709,250 female 2,824,681)
25-54 years: 40.85% (male 6,393,114 female 8,487,570) }
65-64 years: 8 3.14% (male.1,239,524 Homnaie 1,836,083) .
Ta il 1004 ra 23 ve nt
ae
det ratloe(, docetoteeancdeta hamite zi: i Dia tniserey lin en rib ol a gs scenuniod a sogidetin:
“They relate tha number of individuals that are fly to be economically "dependent" on the support of others. Dependency ratios
contrast the Fa o of youths (ages 0-14) and the siderly (ages 85+) to the number of those In the working-age group lages 15-
64). Change inthe depenseney io roi an cation of pole soc upper rquemers reg fom changes
eee ne Lee.
cy ratlo: 62.8(2016 eat) . y
nati: 43 (2015 eat.) . : :
mney rate: 9.6 (2015 eat) — JN Ps '', : 4
pport raiio: 10.5 (2015 eat} ''
Zann nT ayn ge pp nai ''
tye people are younger than this ége and half ere older, It ts a single index thal surnmarizas the age distribution of a-
‘ he inedlan age renee fom a low of about 16 in Niger end Upanda to 40 or more in saveral Europea
“counties sid d Japan. Spe the’ entry for "Age structure" for the Importsince of. young versus an older age structure and, by
pee alsa nn
sala
E himlVE)
0 1a cahnlasenddetaonisG44y: Tho wrerage anual percent changain ite poplaton, retirg om a
ot) of ths over desthes and the balance of iigrania entering and leaving 2 county. ‘The rate may bé positive or
» growth rate fa factor in determining how great a burden woudd be impoted on a country by the changing neede
eopie for infrastructure (e.g., schools, hasplials, houdliig, reads), redources (e.g., 400d, Water, slectrictly), and Joba. Répld
ZS fh can be seen av... more (.docamotenanddete,imitS44)
p the work 0 nk desta *
Bikth rata (.JdocaMnotesanddets. himiiS48}; This entry gives the average annual number of birtha during a year per 1,000
* persons in § i gst a ston aoa eninan marlon
d growth, It depends on both the level of ferifty and the age siructure of the
{
}
1 iatigh atthe istier shdialng tla aieek sabi ee
“population e nie eo town cute ea The eat wen eg naar ony enn,
a golibrary ublicatonate-warld-dbook/ geowve ht f+ samanis
U
Approved for Release: 2025/12/08 C07183805. ae
Approved for Release: 2025/12/08 CO07183805,
South Am i Veneta Qe Worl Feetbook - Cental Intelligen@Pgency Page 70f 28
as si actek enc plan al ats & acetic masts
f ee Sone el cree nr 91 8 ta peal oth at, bp or ante icRow het
aad am ing.. ... more (, }docenotesanddefa himwS46)
ag
t : ined
Q iso to the work: 167 ( Jelde/s46renk himeVE)
‘ rate ( Aloca/notesanddsts.himits47): This erty belshon Ge fere Sor Go Gleaie ets ie outer at
ent g end leaving a.country during the Year per 1,000 parsons {based on midyear population). An excess of persone
: entating the bo try Is referred to as net immigration (6.9., 3.68 migranta’1,000 ,000 popuistion); an excess of persons leaving the
., county as np ley el nten mae (Aecataeshaasetinaay enero
- to the ove a ioe popaeton an - More (./docanotesahddefs. hiniv347}
la
“( we)
: 12 mgr), 000 pope 208 ea) ¢ .
: 0 to thé work: 147 (. feldel347renk hive) .
b oahu oT ype sary dsc of ppt depen
Whe may sgt pop deny oe et rove dant dansity figures.
r -
* §.ffiekiars neni)
moat of the pop bs coca th nara sn wea igang ut ptt ation ot
: ba thet includes the capital of Caracas
ee THdssuby jain lol banners a degree sberlin ofa ponies
ban poputation, describes the percentage of the total population living In urban arees, aa definad by the county. The
uty of urbanization, describes the projected average rate of change of the elze-of the irban population averthe given
esac i, Additionally, Maumee
= canada priaing th. . .more (/docamnotesanddefe.hini#348)
G r: 88.2% of total popadation (20 (2018) Wo :
b Or: 428% rate of change (2016-20-eal) - “
sary areas - population (. ity oi ia adn a po
defined ps urberi agglomeratiana with populations of at least 760,000 people, An urben epgiomeration Ie defined am
fie ity of town proper and aisa the’suburban fringe or thickly settled territory lying outiide of, but adlecent to, the
eae eae oan een ane tae OTA moe, oy pec ofc
A
354). hemiVE)
on CARACAS (capital), 217 nia Mca, 784 Bo Vi 1:0 ay, 1.168 million
ats) (ante) g
cainotess fa htmi¥351): This entry Includes the number of males for each female in fve age groups - atbirth,
46-64 years, 65 yenra and over, and for the total poptéstion. Bex ratio at birth hes recently emerped ma an“ an
Kinds of sax discrimination In some countries. For instance, high sex ratios at birth in-eome Asian counitten
th ee ee ee) es eee es aang paper Cr aes: TN ee Bt Dar ore
eri... more (. docuinotesanofs. tit) a! Ad 5 3
BC 0.99 mate(e)femate (2015 eat)
vortaly rate (. _/docafroteaanddefa.hirnt#S63): The maternal mortality rate (MMR) Is the annual number at ferhale
Heaths per 100,000 lve birth from any caus related to or aggravated by pregnancy or Rs management (exchiding accidental
Or Incident tac, eh aang a, A oe tern ot pa
respect Le ea eee ae od . :
eS htm) a ak
710,000 five births (2018 eat :
parison tothe world 73 (Melda/35Srenichiri#VE) od
be oct eesti eal ela cad ; SAL TR019-
—~~romauanaammenenen A ODHroved for Release: 2025/12/08 CO7183805— aa a aa
*Approved for Release: 2025/12/08 CO7183805:
* 5 i
; .? bp 1 : ~ #2
America :: Veriezuela he World Factbook - Cental InteltigencM™yency - Rage 8 of 28
ra
: 4 7 ; . . . .
alty rate (./docsinotesanddsfs.himl¥354): This entry gives the nimber of dedths of Infante under oie year old in a
pe 1,000 live birtha Insthe eame yeer. ‘This rate W often used as an indicator of the {evel of health In a country.
SB4ihvalVE} 3
pthel 1,000 live births :
deathal,0OORve births bepld 5
Heaths/,000 live biths (2018 est) - ~ :
‘country comparigon ta the word: 417 (. pik . . me on ee
\\, Ute éxpactancy et birth (./docs/notesanddefa.trtm! : Thie entry contains the averags number of years to be lived by a group |
.” of people bam in the same year, If mortality at ‘each remains constant in the future. Life expectancy at birth Ie leo a
PeReuNE of bye af quailty of fife In a country and summarizes the mortality et al ages. It can alsa be thought of as Indicating the
«potential nots On Investment In human capital and Is necessary forthe calculation of varlous actuaraj measures, as
; ;
populatibn: 76.2 yeaa =~ - 5
e : : : ard oo a
(2018 est} : ; ce Hy
ity rate (,/docaMnotesanddefs.himls358): This entry gives @ figure for the average number of chikdren that would be
if ei! women Bved to the end of thelr childbesring years and bore children according to a given fertility rate at
total fertiity rate (TFR) lee mone direct measure of the level of fertility then the crude birth rate, sinca It refers to
b . This indicator shows the potential for population change.in the country. A.raig of two children per woman Is
‘
f data. The i end
itl also unehi in understanding, pest, prewar, and future ferlly trends, especially in developing
By himitVE) ‘ ae a (4
ppendii (. /docainotesanddefs.ttmii368): This entry provides total expenditure on health ae-a percentage of
GOP. Health expenditures are Broadly defined ax activities performed elther institutions or individuals through the application
of medical, jpeaxemedicel, andlor nursing knowledge end technology, the primary purpose of which Is ta promate, restore, of
.” Mmalrtein hébpit . mg ae
& - : - .
{.Abieide/368.htmiVE) as
iP (2074) : é
onjparisen to the world: 132 (.{felde/5érank honlVE) ‘
bed density (./doce/notesanddets himi#360): This entry provides the number of hospital beds par 1,000 paople; It
Geheral measure of inpatient service svallability. Hospital beds include Inpatient beds avallable in publla, private, - tats
ned ed hospitals and rehabiiftation centem. in moet cases, beds for both acute and chronic care ere nokided. =~ a eats
. Because ® level of Inpatient eervices required for Individual countries depands on several factors - such ag demographic Pe
if ~
Se »
G0. hirnliVE) ; .
DOG population (2014) : : . .
iter eourcs ( Jdoce/notesanddats,himitS81): This entry provides information about access to improved or : Wie
ac drinking water sources avallabis io segments of the popuistion of @ county. Improved drinking water - use of any of aS estes
hig S0urce piped water Into dwelling, yard, or plot public tap or standpipe; tubewell or borehole; protected dug well; rr
ipting; OF relnweater’ collection. Unimproved drinking water - use of any of th following sources: unprotected dug wel; Be ae
Inprotected spring; cart with amall tank or... . moré {. /docamotesanddets.himi#361} ae - a :
“{B- : ''
BihtmWVE) : ee as : ae
cia.gbv/library/piblications/the-world-fictbook/geowve.bimal |= _ samo
~Approved for Release: 2025/12/08 CO07183805-
Approved for Release: 2025/1 2/08 CO7183805-——___.—__-____—_ - ,
Turek 22.1% population . j ‘
totek €.8% o poll pe ;
, Sanitation ccreos oefcleanet ni} Thi ery preva eoaton abot acne to rover .
" ninprove enter fctes eva sogrent of tho pope ofa ou. bmproved sanitation - Spr fae
"folowing fe : us of pours & pec sower yale, spl ten pt ite; vented improved pt {3P) latrine: pil
om, septic tank... more (Adocsotesanddefa himis3o8) ae | : %
388, himuFVE) zy .
__iprovedcurt 676 of popeton (2016 eat) ; ''
‘Turek @0.0% pf population (2016 est} 5 oe pee ‘
fotak 94.4% bf population (2016 est). Pp Te . .
unimproved: rber: 2.6% of populétion (2046 ost)” se j ‘
_ Murat 30.1% Df population (2048 est) : ts : { oy
" totat 6.6% ol popuiation (2016 eat :
: HIMAIDS - pecan OEE ey I Ora fry gives sn estinate of thé percentage of aduts
mt aged 16 §) hing with HIVIADDS. Tho echt prevelonce rei caltlvied by cing te the eatimated numberof adujie ving wit
vot a yearend by the tobal adult popuistion at yearend, Sok
ca 63
0.8% (2016 pat)
county compay ato the won 85 {.Aetdanrwchamdne)
HIVIAIDS - regi hn nn: iat tot pt eit
ae oan sn nr et yh oe a AIDS.
“et (ollokds964, hiniaVE) . a Bie op, a 2
. 120,000 (2046 ent) ‘ : : ''
», Stniry comparison to the world: 40 (.fhekderse4renk
. ° SAIDBA g''s ghen calendar yeer.
2,000 (2018 at) : i . .
comp to the world: 47 {.
‘Major Infect ( Thi etry Bota mejor Infectious daeacs Rely tobe encountered in:
countries tha risk of such dssases Is sesesaed to be very high-as compared.to the United ‘Stales. These infectious
diseases rep t risks to US goverment {reveling to the epeciied county for @ period of leas than three years, The
Gegres of fs assessed by considering the foreign nature of these Infectious disexesa, thelr severity, and the probability of .
a i ha cra aera ee eee - a : : .
(ff : :
see is i icboh 201)
‘ moase: acl aren ai hepa A 2046
vecbome dengue fever and materia (2018) -
note: og tanatalon of Zka via by Aedes apcie mosasioes has bean Kent inhi coun (an of August
ae: _ 2018) pa : a en important dak (a large number of casse possible) among US cttizens If bitien by an infective moaquito; other
ered ways to gel Za ee trough an, i ood keto, rds pregnancy, wich te pregnant woman pastes
virus to
Coeahy - ef prevalence rebs ./docainctesenidefs.htmi#967): Thia entry gives the percent of a country’s ® population .
ca dtp ba obaes. Obesity defined as an adult having a Body Mase Index (BM!) greeter to or equal to S00, Bhi le
cakcadaioa f ga aa el ah ara oY
Hs > a F % :
" 2ha% (2016
_ country comparise sn tho worl: 60 (eld hi AVE} . ak:
Chikdren ui dor the age of 6 years underweight ( {..ocafnotesendéets.htmitdeg}: This entzy gives the percent of chidren under
five considared fo be underweight. Underweight means weight-for-age Is approximately 2 kg below for atandard at age one, 3 kg
. below etanpard for ages twa and thres,. end 4 kg below stendsid for ages four and fve. This statietic Ia an indicalor of the .
“.. RidrRional (tates of a community, Cieiran to ite bom grat eerie 6 ail of poor dels sor ceca btectcws
+ fend to he ee eee eee
'' TORS es ee
Sr aaa ‘Approved for Release: 2025/12/08 C07183805-—~ a
b; oF a compoating foiet, Urimproved saat se of ay of th folowing felon hush or pos fush not ped _
himl#VE) "So pak art
HIVIAIDS - Heat | ocahsonace 0 They ghee nti of be ier of acuta chen wo ed
_ Abttpsiftw Se coebecasiuaiie neces caluahe rele 7) -smaoig. >
ee for Release: aoa 2/08 CO71 83803
sou America :: Meceonis -@: World Factbook - — nage ’ Page 10 0f 28 .
3 : :
+ eide/Se ty ne
2.8% (z009| * ee ;
county compariso tothe work 103 (fhtdaoesnicHavE)
expand a aca ic Piety ee one
4
eo
parle rte ort: 16 ( lator
coc .himi#370): This entry inces x detirition of Iterecy and Cansus Bureau percentages for the
gio niaoe, and foriaes. The are no rivers deidlona i ane of Rorncy: Ursees choice apecibeg, ol
ratea are bazed on the most common definition - the abiily to read and write at a specified ege. Detailing the standards that
Indhidual oq knoe omen sly ore wa bmp i Fc. aban cn Ba, %
rn ct measu . ci acer aaa i
‘Jote! population: 87.1% . be
_ female: G7.2% (2076 ast.)
"School fe daqpects Gna oy ey acne i aca Lb
eo Be of schooling (primady to tectlery) thal a chid cen expect to récelve, assuming that tha probabltty of his or her
being enrofed In schoo! al any particular future ‘aga 1s equal to tha current enrolment ratio at that age. Caution must be .
abiied utlzing this Indicator In international comparisons, For example, a or on country is.
: pone sseen i teres elie tenia a a: (eno oe
VN
7
i
{
}
i
ins
,
ployree ram 504 hn i Thy Gt ro ir
ployed during a specified year, :
, “e i SS ge —s 3
. = '' : : aa aaee
.
"a i at , Sous, ; . ie?
county comp ot te word 7 (. Melt 7Srankchimi@VE) ie 7 . aoa
pot Ro
Country 2c ieersink Liiae Guiedvencs 4 ofthe country’s name ape by he Ut Board
4 - on Geographic Nemes (italy is used an an example): conventional long {iteflan Republic), conventional short form (thaly), °
ow p (Repubblica Hallana), focal short form (Italia), former (Kingdom of Htaly), 8g well ss the ebbrevistion. Also see the
g egy noe. . ‘ é ae Sie | Z
i?
1 a ee “
foes buon Lak Maraclbo rorindes ener Alonso de OJEDA ai Aerio VESPUCC!
gs in Venice and so they named the region “Venezuola," which in Italian means "Lite Venice”
({docalnotesshddefe himi#200): This entry gives the basic ferm of goverment. Deiniions of the mejor
tal terms are #e follows. (Note that for some counties more then one definkion applies.) : Absolute monarchy ~ #.forrn-
Overune where the monarch rulss unhindered, Le, withdut erty laws, constitution, or legally organized opposition. Anarchy
=a condiid Fo Senet 2 pene aera Les Sak oy Ue NRCS Of Govern neren Sees autherlty. Authoritarian - a torn
lacenolesaitddefs, htmis2e8)
“of goverment in whic’. ... mare {fd
ie
" \\httpas//eyprw.cia. govAibrary/publications/the-world-Setbook/geds/ve.html | - + 7/2019
: pos 2 : , : é . ,
‘Approved for Release: 2025/12/08 C07183805-
~~~ Approved for Release: 2025/12/08 CO7183805 -
a: ae World Ractbock - Cextral oe Page 11 of 28 -
sinotesancdefe ht ot Td anya ta eof heat tavern. Bs tec core,
: ca relative to Coordinated Univeral Time (UYC) and the tne observed in Waahinghos De, and, If applicable,
lial ato ag onl aa ae Where appropri spect he boon add oN hes cnn at
hi a0) hinevey pS ; : : ~ _ \\ t .
name. . ty :
geographic boordinstes: 1029N,6862W .- - .
tims differerie /UTO-4 (tourer of Wstlngfen, OC, ui Clavier Tse)
hte tent hy ey ee umbers, designatory terme, and frit:
8 divisions a8 approved the US Board on Geographic Names (BGN}. Citanges thet have bean neported
d on by the BGN are noted. Drees ace coats rine te BON wine capo cf
iad of ct te pc cea ; ze
/
i hime)
"23 stains (eptado ago 1 cal det cpa, era Spee epee ie :
Atnazonas, fr Apure, Aragua, Berines, Bolver, Carebobo, Cojedes, Delta Amacuro, Dependencies Federaiss (Federsl
ns)", Disttho Capital (Captal Disc Felcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva Experts,
Sucre, Techice, Trufle, Vargas, Yaracuy, Zila 5
“note: the''fe ie dependency conslats of 14 federally controled isend groupe with a total of 72 Individual Ilends
denc (.{MocaMnotessnddete. himi#S05): For most countries, this entry gives the date that sovereignty was achieved and ;
. nation, empire, or trustoeship. For tha other countries, the date glvan may not represent “indapendanca” i the wbict
- genes, bun nfl Sena art naltonhood event such as the rational founding date or the dete of unitcation federation,
onfecerats hppa yuparey ren hla oh uae aoa Pantene ¢ Saree,
Rablighment of statehood .... more ¢..jdoceMnotasanddefe himi#305) 4
of B.himiVE)
Bayt from Spain}
Sona hn i py ten usually
Raila piri 3 ’ . : . . % %
inge ce 2 Day, 6 July (1811) = : ;
onsditu {..Adoce/notesanddets. himi#307): Téa eniry provides infomation on # county’ coratiasion anil includes two’
sb i Nietory subfield Includes the dates of previ','8bb9819258ccf75a9df7dedf6481d66fab07f6d64ba3590bababd0df9cdde32a','internet-archive','cia-readingroom-document-07183805','txt','cf6a10ea00c36eb3db411ead5f1899246ed82cec14abf11f90452ebef3d181eb','https://archive.org/download/cia-readingroom-document-07183805/07183805_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3e84624685957d4b8644f9f464649a72ede27554f3aef4a99395b38af8217df',2018,'','','raw',2,'ous constitutions and the main steps and dates In formulating and
p the latest constitution. For countries with 1-9 previous constitutions, the yeara are Rated; for those with 4-0 *
previous, entry la listed as “several previous,” end for those with 10 or more, the entry fs “miity previous.” The Spe enens
subfield izes = the process of am . . - More (.doca/inotesanddefs.himi#307)
4
af} 7 hive) * ft icf. . 7 Pg
Louse samirepmeticlirnersoge effective $0 December 1609
aenonrener ys proposed raugh sgreeme hy o leet 20% ffs Nadonel AamerioW membership, by the prosdent ofthe
eeeng with the cabinet of ministera, or by petition of at isast 18% of registered voters; votsra; passage requires eimpie .
‘ fe by the Assembly and slniple majority aoprovel hu ha referendum; amended 2008; note - in 2016, Presklent MADURO
fesued a der: 2 to hold en election to form a constituent eesembly fo fo change the consiution; the election In July 2017 approved -
atic Seyret ” A aegis ei area
end Groupe explains the differing mandates of the ICJ and
“https://wpw.cia. gov/libriry/publicationsithe-world:fttbook/geow/ve htm! = s/t7/2019
Approved for Release: 2025/12/08 CO07183805.
sree! Approved for Release: 2025/12/08 C07183805
"South Amari :: Venezuela (Qe World Faotbook- Central Intelligenc@ency Page 120828. *
oan 7 , * ‘ "7 act
‘) A a
( elds t 7
has not sub Ried iy 6) puicicto!acotuton; ecxapte ICCt furtsdiction
Chtzanship jSotactatandiet henley Tiber junion Wseiacs scded ns would ekaae-*
ft ncluces four subfields: clizenahip by bith describes the acquiation of cltzeriship based on place of bit, lriown :
28 Jus oa of the citizenship of parents, chtzenship by descent only describes the acquisition of cliizenship basad’on
: oof Jus sanguints, or by descent, where si legat one parent faa cftzen of the ainte end being born within the
tenritodel irrite ofthe @ . . + more {./decalnotesendcets.Hom#S10)
‘{Meldarsia.henwve) : 4 - .
exspil aapetdal Mae a i # ee as ;
Executive b ocala Tia ley ch iene: tn: ti Gh pscemonte oo
cabinet, Gio election results. Chief of state Includes the name, tite, and beginning data in office of the thular
leader of t Gia who prea then fic anderen incon nyo be ved wh be .
activities of the govemment. Head Na -
‘executive branch of the govemment, e .. more (.idocemnotesanddets.himihS 12) :
14 himifVE}
seein Sacer ae Sle vgn UNDO nn nara Poo Veo ‘ ;
Proakient Nitot [MADURO Moros sinos 19 Apt 2043; tacit Vien Present Deley RODRIGUEZ Gombe (hoe 14 June
2016); note the president ls both chief of state and heed of goverment
‘head af go Pr Nie MADURO Mo i 0 2018; xs Vie Pr Dey RODRIGUEZ
Gomez ( qe 14 aie 2018) ee
cabinet: Co ol of Miniatacs appointed by-the president :
Fi ety oy a mao pp you no ih cn
held on 208 ay 2018 (net acon aceced fo 2024)
v- ‘election re : Nicolas MADURO Moros reeleciad preside; percant of vate - Nicdias MADURO Moros {PEUV) 68%, Herat
‘FALCON pate, devier BERTUCCH 11%; note - the siection waa marked by serious shortcomings arid electoral fraud; voter
-tumout wae @ taly 48% due largely to eri Opposition boycott of the election '' :
Leglalative brand (.docaMnetseanddeta. imix 1): ‘This entry hes three subvfekda, The description sublild provides the. -
logialative structure (unicameral ~ single house; bicameral = an upper and a lower house); formal name(s); number of mamber
‘eents; type Of conatituencies or voting discs (single set, mUlt-seet, nationwide); eléctoral voting aysiem{s); and rember
>” tear of of chutkaknn GER ee
al in by party/coalition an . aa greek be a 8
© §Alekia/9 1 rent
description: {sniés
ito ant abd rst 13 mabe ety dein ee rt
bile by almple majority vot, 81 directly Glected in muii-seat constituencies by closad, party-tet proportional
Ne Bil Ce rr een acias cf Vaniaeily ahaaibene marys © yest iene) :
lectiona: held on € Dackmtser 2016 (head to bs held by 2020) ‘ . 4
lection resilite: percent of vote by pasty - = MUD (opposition coalition) 68.2%, PBUV (pro-government) 40.9%, char 2.0%; vet t,
by patty c 0 108, PeUV 66 Indigenous peoples 8; composition - men 148, women''24, percent of women 14.4%
{-Mocufnotheanddefs himl#314): This entry includes three subfields. The highost court(s) sublleld inches the *
saet el country’s highest level courts), the number end tea of the judges, and the types of cesses heard by the court,
oa minonty are based on. vi, criminal; sdminiatretive, and constiutionel law. A number of countries have seperate
Miutiona! courts, The judge eelection and term of office subfield Inchides fhe organizations and associated officials
aponalh for nomineting and eppolnting |. ct a rcsaeaaic 2 J
ld niniavE) ;
Noheet og ipa Ta kn one of 2h ed ter pant, ec,
pid ap a ease aa divisions) ~
a
+
cia. govlibrary/publications/the-world-fufibook/jeosivelim! =. ° ~~ SANQ019 |
Approved for Release: 2025/12/08 CO7183805—_____--.
Approved for Release: 2025/12/08 CO7183805:
ica: Vera @> Wei rtenk- Cont sap ecy "Page 13 of 28-
erects si te of fle: gen proposed th Con oul Poston (nlndopendert lof .
lsc wpe cnon a tn pu can pe caper Shee tc
able 12-year terms; note - ~ in July 2017; the National Assembly named 33 Judges to the court to replace & eesles of
alst-party-ded
the new judge ap ter ap ovornpstel ohana ol
ohare : Superior o¢ Appeeis Courts (Ttbunales, Supedords}; District Tribunals (Tifbunales de Distrito): Courts of First
od Prarie; Pata Coste uni de Pro Justices of the Peace (Junticie de Paz)
a es und leaders (.Jdoceinotesanddefs.himi#S 18): This enty inctudiea « Hetl of pada aloes
A laine lc tan of nh arya igi ey re rn ia ty
es loyal to Hugo CHAVEZ — ~ Gromi Pattiotic Pole or GPP | } MADURO}
partiea = The Democratic Unity Tebie qr MUD [Joss CARTAYA]~
eauela or VV [Maria MACHADO} ‘ .
j of Venequeta or PCV [Oscar FIGUERA]
Action of AD [Henry RAMOG ALLUP] : ee
or PJ (Judio BORGES) . wk AS “ 7
o¢'' VP [Leopoldo LOPEZ] ea ee ae A ‘
or AP [Hens FALCON] P ; . ‘
ee OF LL Cauna R [Andres VELAZQUEZ] _ BO te og
fet Party of Venezuela or PSUV [Nicolas MADURO] ait ae)
ae
ye
FEO]. - ‘
send outs nutkh be abjedcanty ke amacaworsetavene nana cnar ea abbreviation
canara ales eae inane an cal oles way. ’ }
2
<2 1 ( Alighialst nmi ’ :
pb , CD, CDB, CELAC, FAO, 6-18, 6-24, @-77, 1ADB, IAEA, IBRD, ICAO, 16 (ronal commitaca), (2 .
RM, IDA, IFAD, IFC, FRCS, IHO, 1.0, IMF, FMC, IMBO, interpol, OC, [OM, PU, a ITU, ITUG (NGOs), LAES, \\
does er), MIGA, NAM, OAS, OPANAL, OPCW, OPEC, PGA, Petrocaribe, UN, UNASU R, UNCTAD, UNEBCO, .
#00, Union Latina, UNWTO, UPU, WCO, WIFTU (NGOs), WHO, WIPO, WMO, WTO :
pi to nth US ocacaendet AO Th ety chat cht of mao, chancay
tole a, FAX, consulate general lopstions, and consulate locations. The use of the annotated tile Appointed
bassador refers to a new ambassador who has presented his/her credentials to the secretary of ataie but not the US .
preeldent. Such smbsusscors fill all dplomaio incon except meetng wth or appearing atfuncfona atondd bythe 2
: See a, meer ae ee eee ee at + more { (kdoca/actesancdeefa hile 1)
sion: Ambasaador (vacant); Cian na HERE? rs ey 2
p. 1080 30th Street NW, Weshington, DC
Upset a “
- coneuiatse yeneral: Boston, “Chicago, Houston, New Orleans, New York, San Francisco, San Juan (Puerto Rie)
on from the US (:/doca/notesanddefs.himi#319): This ently includes the chief of misalon,
36, telaphone number, FAX number, branch offices ocations, conaulate general locations, and
s rs ne i “-.
ion: Ambassador (vacant); Deputy Chief of Mission James “Jimmy“ STORY (since July 2018); nate -duetosirsined
etween the US and Venezuelan Govemments, netther country has shared ambassadors sinea 2010; on 22 May 2018,
Mee ee ee
Ordered the N expelled
aF con Calle Suagure, Ubarizacion Cana Vie Ar, Caracas 1080 : e of
ai P. ©, Bax €2201, Caracas 1060-A; APO AA 24087 *- wo 1.
+ Amlephane: {B8).(212) 876-6414, 807-8400 (after hours) ae : c ; .
FAX [58 (412) 007-8108 ong )
ia, govfiary bilatnatn-wosldiok gecefve hal "| SALPAOLS |
Approved for Release: 2025/12/08 CO07183805.
Approved for Release: 2025/12/08 CO07183805
f
outh Amarica Venom @e ‘Mod Fetpook- Conn! Tnetienelleny Pie 14 of 28
"Flag des on (.Jdocanpbasanddefs htmH#320}: jiicer ebibe splae bg escaped apie ae
: best infor atlo don avaliable atthe tine te entry was wean. "The hageofndeperdent late Gre used by tar dependences
‘ sa Ce ee ee
+ (flelds/20 himigVE) =
teseagal ordinte ade feo op a incon of aman hl a yh bandana
. eight white § d stars centered in the blue band; the flog retalns.the thres squal horizontal bands and three riialn colors of .
the banner o Gan Clonbl, Sout Aneta mb al sk 00 yl trend a cg :
of the land, b fr the courage ofa peopl, and fd forthe blood ahed In attaining Independence; the soven sia onthe
ggiginal Sag fepresentad tha seven provinces In Venezuala thal united In the wer of independance: in 2008, then President Huge
CHAVEZ orgered an eighth atar added to the eterarc- a deciaicn that sparked much controversy - ~ ta conform with the fag
‘prociaimed ky Simon Bolvar In 1827 and to reprasent the historic province of Guayana , 3
| National pak) (.Jdocwrictesanddefs.hirite321): Anetional aymbol ts a faunel, fore, or other abstract representation - or
some dintiieive oblect « Se eerie ie cores be Henely amet wits Soni or sity. Net comes nao
ot Counties have more than ons. :
- (-Meidafa2; NimVE) . gen cat . a ya 1 ;
trouplal (bird);
National anthe {..Kloca/natganddeta.htik322): ik pani pelo wend Coveiealioa stil i ie vie a''s ag
‘hymn of p that evokes and eulogizes the history, Gaditions, or-struggies of a nation or Its people, National antheria can ba
: offically hea a a a ca a sila a aap shi
a in lyrlen, soma do nat 2 “
. (ath Pa 2 hint} mon ls . .
nome: “Gk Meer sais wav kaautecis ; -
_ , Wyrlcetmusic! Vicente BALIAS/iian Joes LANDAETA
note: adopted 1881; rn tian ni mon yen oh ALAS nd LAAETA rt.”
seg Ver rule''s struggle for Independence
i
v7 Eeoneny (.fdocainotesancdefehimik207} This ry iy dni be ype teary, licludtig the degre of
+ Market orlertation, the level of ecanomic development, the most important natural.resourcas, and the unique areas of
" |), Spectadizagp lo tracts major Sones evra ply changes nthe moa acer 12 mart er maybe,
. Satemant ab tone or two key future macroaconomic trends. a
oa :
highly dependent on oll revenues, which secount tor almost al export earings and nest half ofthe.
. 8 reverie, despite & conitnued deciine in oll 2017. in the absence of official statistics, foreign axperts
‘ eatinats GDP contracted 12% in 2017, inflation exceeded , people fecad wiiespread shortages of consumer goods
* end = tend the central banks international reserves dwindled. in lats 2017, Venezuata also entered selective defautt on
ome of ie on and state o8 company, Petroleos de Venazuela, $.A., (PDYSA) bonds, Domestic production and Industry
* continues bd ster underprorn an tha Venezuen Goverment counsel on inprts meet bal fod and
Consumer gpods needs. .
Fat ot oa cicestttateagsies a ia cabiads weal adlindaceaieaaee price controls, andrighd
gis Galati Wil PCNA poer teat he tava uted ried Hits cerraes eke onde Lh ocee tapes ;
d POVSA''a poor cath flow have slowed Investment in the petroleum sstcor, ene eeene hee
Unelee P t Nicolas MADURO, the-Venequstan Government''s response to the economic craia has been to incroaee eta
.” control a ope eee ra
on distribution of basic goods to thd military and to focal soclaliet party member committees. ent hes
Sc mainteined trict currency controls since 2003. The goverimant has been unable to austaln its mechantgms for dlatibuting
~dollars tot Se eee ee re ee ee ere
Bt aoa Parmer
4
- htipew/wprw.cia.govlibrary/ublicationsithe-world-fietbook/geoyvehtml . =). “S/ITQOI9 ~
Approved for Release: 2025/12/08 CO07183805——-—------
pena for Release: cua 2/08 Cort e002
ty
Ametioa : Aeon World Fastbooc- - Cex nag ay _ Page 15 0f 28
| papen basal jl a eben oclug gs a leeks a
Jnaintain tire ree arte eo race tat Epenalonas mocha pollen ae coréncy coils heen
Sreated 0 oppor for exbltrogs end comuption and fueled rapid increcse fn black market det.
mchieing dower parity) _Socahciosncdel i208): The entry pve the gross donate produ (2 of vélue of
good & and services luced within a nation in a given yeer. Anation’s GDP at eo 00) 9
sachange retea js the sum vaiue of ell goods and services produced In the Gourtry valued a! prices pravaiing in tie United
.o* Btates int qj Yeet noted, Thia Is the mesaure most economists prefar when looking at péc-caplta welare and when comparing
> Bving conditip M OF usa.of resources across counties, The measur. + more (,/docaMnolasandefs himi#208}
on to the work: 47 (,/feida/20erank html?) ,
flict J exchenge rts) (-hdocahnotesanefs hrA200} ‘This entry gives the gross domestic product (DP) or value of al
services produced within # nation in a given year. A nation’s GDP at official exchange rates (OER) ls the home-
d annual GDP figure divided by the bUsterel average US exchange rete with thet country in thet year, The .
nS, T : D tcompeand ie prec ears fo vn of up. Many einai reer ie meaie wn
~ _oe céno ic power an economy maintains vis-.. , More (..docafnotessinckiets, himi#200) oe
iy? 7
: t
tabi ‘ Pa . ‘ x zd os : io ace : ¢
(2017est)
grow ahammar? go ono ba i
oc. @ percent. The growth rates are year-over-yeer, and trot compounded.
+ f f
hind) ee des io
ont the wor: 222 (.Meidar2 torankchimltVE} , ; o
d PP amon Tey te Pn rp
oe
v -
6 eat) ; 7 Sts: ee ee
. pea) ; "at
in 2017 dotiars es woe
ie0 to the work: 128 (Melde/2ttranichimitVE)
‘saving (./docahnotesenddefe hill 12): Grose national seving fs dedved by deducting nel conauription
goverment) from Gross national Ingome, and consists of personal saving, pis
Meldel2 3. himiiNvE)
; ae oe ms 8
ingly pubtaonste- werd Alico geote inl : Be SAFAOLS
Approved for Release: 2025/12/08 C07183805- = AERA Sag a ee
Approved for Release: 2025/12/08 CO7183805
i . :
‘
ore @Or7 ot) Wt BP a) fine he OH es
LL
a3
83
g
oa and sorvions 10.7% (2017 sat) * ; i
compasitie pct ag (mans biz chy howe ar cin nn cane ‘
-economiy, The distribution gives the percentage contribution of agricuture, Industry, and services to total GDP, and will total 100
9, energy production, and construction. Services caver government activities, communications, Ct
| ecthr pat economic chee ht onc ro. ae aaa asa a
(ahr Try enn a a ie
Jv .
t * '' : Boge | he
& himiaVE)
, garare, es, bananas, vei, ib; bet, pa, oe fish
Ao ney peer e ce at ra M
sopton rowel Monaholoemsioek F Teeny! the =a fn ncuetrtal
didoceinoeeanideate hint’ a increase
= des manufacturing, ming, end conan), ils eer
‘ Be a6
; a : weet 0 Z
0 Sib inewnad ni Cadena) Ma he :
eta iz Ti hy be ire
f 7 et) : OO tte Sr
tothe wat: 4 (ites) . }
u {.idocaMnotesanddets ht
oi OCCUR jr a energy
“Prodution, and! construction. Services cover gavamement activites, communications, transportation, franes,’and ail other
EO ee etna mn Ei 360 peat Minn Sess ri:
and may sm 89-101 ee ee eye eg ee rT oe Lg
ae x ty,
rnp rate ( (.doca¢notwsanddata.nimi#220). Thence parte er ce tit
betentie underemployment ight be ned ~
) ™:
erfanc to tha weit si nlc
opine sce reg sarcanetranqeir-cit Ao RCT a OO
” poverty ine are based on surveys of eub-groups, with the résuits weighted by.the number of people In each group. *
Me innadaa co eo ee eee nee
uth Ams joa: Veh - Qe World Factbook es ad Page 16 0f 28
‘product osc i nal, uy id lied inl cui on construction mails, mica.
" SAT—2019 -
Approved for Release: 2025/12/08 CO7183805 eras a
‘Approved for Release: ee 2/08 CO71 Bape
Ambsiva a Word Fetbook cam mse Page 17 of
we ’
“procedures Saat eed seeing re ccm Rio facet \\
a ge ee ree
i ” : aa - . 4
highest 10%) $2.7% (2008) *
Distribution jof family Income - “hl (Simi ia cs vas tse bgac ve
pf family inicomé in @ country. The Index le calculated from the Lorenz curve, in which cumulative family income ls
Plotied aged inate number of famliss srranged from the poorest to the richest. The indax lathe ratio of (a) the area between a
income datbuton, be coewia am Sealnameanasenaiee ee eR
intry‘e Income diatribution, the closer ite .. - «thors { .fdocainotesanddefe.himi#223) +
00229. tinteVE) ‘ : : eee em . “ae 3
.
0 fo the word 74 (. feld2z3cnk hiifVE) =
d a himi224): This enry included revernsoe, experkftures, end fecal eit. Th a
ie onan change bile, eared eA canal, ;
de/224,himiVE) ‘
: 84.6 billon (2017 dat)
: Ea07 tion O17 ext) :
p Poem (gti eles tao Lad wise ca fecelved by the
go tt during the time period indiceted, expressed as a percent of GDP, Taxes indude end corporats *
Incorne tax 5, valve aided taxis, excise taxes, and tariffs, Other revenues Include social contributions - auch es payments for
i hesduenati grants, and net revenues from public enterprisse. oe :
b Sere eee ae . Inpre {.docafnotessnddets.hitmie225)
ayaa aia : hes
on fo the wort: 26 (.1 himigfVE) é
(of a) cantante Mh ery ec he enc betwen nao govt
and expendiwes, aypreseed as & percent of GDP. A positive (+) number rxicates that revenues excendad
oepanvitt Fates H GDh, outs enh earecerenn mae cette Normedizing the dita, by.
ding t apace Beenee by SF: Gnables easy compartadne across countries and Indicates whether a national govamment
tb that sre Genominsted in @ country’s home currency. Carrocy, Plc dott shoud ne coded wh exional dot hich
rec ofr cen eis oboe tn an pu aren rte fered oof re exchange :
41.9% of GB (2016 ext) . Ae ot
note: date cre oven a vod tov ch comp POV te aa le my
abt hetd frente: the gta chi ome det asd by subatonal ‘entities, se well ee Inragovemmental debt:
Of treasury. borrowings from surpluses In the social furnis, auch ae for ratirentent, nee ,
erect tuna oa ar ae ek
‘ 3 . + . .
{cia govilibrary/yublications/ine-world-fidtbook/geos/ve html - SATROID
‘Approved for Release: 2025/12/08 CO7183805- —— asst ate te aa
Approved for Release: 2025/1 2/08 C071 S389;
%
"South Am ida: Veena he Word Fetook- cea iigeaesy - Page 18 0f28
-'' e tos
:
Inftation ta ite uae ri Ty tien ea ppm age am
prices compa shad car Jah acoder
AG leldal224 a aa t a A SF : 4 poe
- 4,087,685 (2017 eat} G ee wage’ %
. "254.4% 201 ebt) .
on to the world: 226 (. a eyed:
, a chon some i oo
a6 een ee ene ee eens ee
(iekdar23h.himiVE) 1
20.5% (2018) '' ae, .
county compa : dni fo the world: 1 ( ftekdar23Greri
JymRVE) ~
bank pn onda reo docahteeandea hi Ti x poide singe average of arian”
a ‘Hrentn a inn aa reas aeige sd
| -(lfiokdar2s 4, m speed a ns o
++ 24.4% (81 Discomber 2017 est) - ¥ * : a ‘
_ 20.78% (81 Devember 2016 est) «. : ” : :
"| country comparison to the word: 12 Mekdr2S tran hit) ae
-, Stock ofne money (,/docanotesanddafs. htmst234): This entry, ies ea a cae elon en:
; “currency tn bira 1 Secon Glan ‘an cae} pos deeded cepvea detiphaded ie be nadie tere tntdte eaten cence
Inethtions, fatets and governments, pubic enterprises, and the private esctor economy,
apecific po ti time. Netional currency unite have bsen converted to US dofars at the closing exchange rata for the dite of the
+ Q Ge een inona {. 34)
eldarash hp . a - ; :
"$148.8 bil Go Deseaiber007 eet} st oi? ‘ M
"$163.3 billion (91 December 2018 est) boys
* country compariso pede ele cheobec ara
: Stock of broad money (,./docanotesanddefs.htmi#235): This enty cavers all of "Narrow money," plus the total quantity oftine °
and spot ce won dept, batudonl money tharket funds, short-term repurchase agreenients between the
dour scalpel bar sna ls ssn byoxt sr, etd
- st4ngb Dacre aii Gis cae A
” $189.9 biton (31 December 2016 est)" tae, :
* _ suuniry comparison to the world: 29 (../fieida/235rank himi#VE) :
- , Stock of deme re caholancl ni) T any etolquay of ce, eno at
‘Tae CUTONGY, i d by financial insttutions to the central bank, state and focal governments, public non-financial corporations,;
“+ and the pi mycket core Use ee eb ecg eb
ve ; ofthe ari sai .
$68.97 bifdh (31 December 2017 est) are -
$1485 {8t December 2016 est) ‘ ‘ ‘ ;
country conjparise fo-the world: 60 (. Melda/236rank himi#Ve)
* Maricett oot pti sen artnet faa ny sy
* Yaded co ‘ata price determined in the national stock markets on the final day of the period Indicated. It Is simply the
latest p oer ahr ped ye el maar usardg wana, med own cgren itd ce pare oe
e " A ; : : ‘ St et
(ute hina : Lie ; ‘ ot
$25.3 ba on (83 December 2012 est) . fg eet
+ 95.148 biliy {91 December 2014 eat) + s . i
“i+ $8.001 blitgn (31 Depsmber 2011 eat) . '' _ # Be me: tea” ea
attpa:/fwyw.cia.gov/library/publicdtions/the-world-fittbook/gessvehtmt ~~ > sn7mo19
Approved for Release: 2025/12/08 CO07183805.
Approved for Release: 2025/12/08 CO718380:
4 Se .
etic = Veiezucla — ge World Factbook - Conia Incligenoygpgency <Page 19 of 28.
‘ imifVE}
rt telanpe (.Aocalnaouen dics SMRZSEE Tie ntyvecerds« ouuréy‘s net rai tn gost ant eordath lie
net eamings Fo renta, interest, profite, and dividends, end net transfer payment (such se penglon funds and worker
-TemiBanesa) to Gee ee ne
‘baals, Le., no in purchasing power partty (PPP) terms. -
Hfiekds/236rank hime},
ocenotesanddet tT#220): Ths entry provides the total UA doller amicunt of merchendiee eiports on an tas.
tee Tegal on an ears sb np po Paty PPP ‘
XK eo 8 a £5 he -
p to the workt 3. Melder236randchil#VE) ‘
arine telco) poet rank orig ted per ag wh hn.
onetime inch the peronto ttl doar aki.
. 7.2% Cl 1%, Netcen ren 82%, Spas 6.2% Cuba 42% TA - ’
ad ae
1
: d fachimt#242}: Thie Tito ecey svete ts it UF dehes Soomnt of Gootherniee aslitacelaclt ial”
Spaces Reo rower mera :
’
1
) . .
14.2%, Mexico 6.8% (2017] } ; ae
roti esc hecion ad oie toscsudasit ns orly Shds Ws cr iekio i a tk af a
ots that are available to the centre! monetary authority for usa in meeting a county''s balance of paymenta needs as *
sis of he beriod specified. This category incladee not only foreign cusrancy ie
een enn ne ee enn eee,
.fieides24Srank himiVE) |
i (Fenn iT ry ra be i sr nt oto ei
pest mcpaet een see cr eaioen: Teens ees re ate een ee ee
g power perty (PPP) tenn. em
bicueve
{31 December 2047 est, : : ae 7 a -
(31 December 2016 est.) : - = . ei : x.
yw cia, govilibrary/publicationsthe-world-fictbook/geos/vekbim!
Approved for Release: 2025/12/08 C07183805 ae been Bis
Approved for Release: 2025/12/08 C071 83808, 3
, : ee Se t- - ‘
ie ‘ ae . ? . Z + ‘ : ”
lea eas “eee World — - a Intelligend@@ gency Page 20 of 28
county oo oir at 4 (iki te ee ee
frect foreign investment - at home (. 7: This entry gives the cumata! US dolar valua of.”
renti i In the home country made directly tesidents «primarily companies « bt other couricen ofthe end of the
q indicated, Se eee ene nee eee of shares:
47 kntVE) ) wes : ,
qn (jt December 2017est) . a .?
31 December 2018 eat) - 4 7
ariso to he wo 70 ada AVE
i i kang couetig nome etachy wo osu = primarily. Ti ty ge com sieeaete
sirits companies thé home country, as of the and of
indicated. Direct investment excludes Investment Swough purchase of shares.
Z
? 4
AeshimiVE) :
a ipl Decnber 2047 ca}
: 834, {abba (31 Daceinber 2010 est)
tet tos (, protien hl qvenage enreitpisd ofa coumbyyé monetary orf for
the time pa ne ant rwanda (SO)? omen oo eee
8 Intemational Standardization
oa
eat) ;
Gest) y a :
eat) -
ect) oh i : ee .
dct (sicctiaeatittes hia Ti ry on ema nana cy. Blectrifation data |.”
pm industry reports, national surveys, and intemationsl souross — chnelets of four subfisida. Population without
provides an estimate of the number of-citizens that do not have access to electricity. Electrification ~ total population is ;
8 fila habe carmerntasyededc or lectrtfication —urben areas {a the peroant of a country’s :
pital Sach aera aeaeter
~
oot
ivy
Zetec: 100,000 (2013)
~ total population: 88.7% (2013)
atlo} - urban sreae: 98.8% (2013) .
of ~ rune areas: 88.6% (2013)
production (-Moceinotesend
dete. himt#252): Th nt ie srt sty goer epee Mo
cy between the-amount of elacticity generated andor kaporied and Sie aricunt consumed end
\\ potinceny deipuoeatninarnblpciaA craggy : ;
. ,
da/252 himivVE) ; : -
on kWh (2016 eat) : ina ca a8 :
ariao Be 42 :
Blecticlly ~c co ri ieee ct ich cy id sy gt
expresaed in Klowati-hours, The apse barrel i agua a apace
on if ccaue','8037172173875135d5b2af51d62f25f72db65f33701714bc9fa031675386c361','internet-archive','cia-readingroom-document-07183805','txt','cf6a10ea00c36eb3db411ead5f1899246ed82cec14abf11f90452ebef3d181eb','https://archive.org/download/cia-readingroom-document-07183805/07183805_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a58666b4d20726dcb9a818c9cc37fd3cd66947a0d05b678444bb7ff097f06c6d',2018,'','','raw',3,'d andr expat i accourd to axis rarindon and aon
(8 . is ;
"7. bln TS xt) ae , i &
parison fo the world: 3e (“Jflelde/26Srank himi#VE). me SMA ae
Electicky or (Seance erat Tk ny bel erred decay i doe ; ¢ gay
i265 himBAVE) ~ a e & oy ~* 7
i Ls a ee - . 7 sy = " re mene
cia. gov/library/publications/the-world-finthook/geos/ve.htndl f+ snqpois” -
aaa Approved for Release: 2025/12/08 CO7183805--___—_—---
hime} ;
mort (-sdocaMncineandidets.hirés263}: Try ah anc fog bare,
SS B 1 7
eG ya. html) fs
4 O bbdoy (216 ent) A,
ied are tate aria
‘ Lovisbnan ec reserves are those quaniiies of petroleum which, by enalyals of
and engineering date, can
imw« oo oe
ey le eae ene
(Me
Ria for Release: 2025/12/08 cor 83805 |
‘South erica Vawnaie Qe World Faetook i toy “Page 21 of 28.
: ‘ . F r ®
. . !
Wh (2018 est), ne C
BD wor ie _fhektar255rark himihVE) . ; <
* Bieta Ingtalled generating ‘ (/docenotesanddals.himi#266):
This entry Is the total capacky of curently indtalfed °
exprosaad in Kllowatta to produce electricity. A 10-idowait Serene se eae 22 eaten
a nciricity We rane conlieuoanty for one het, . ”
ig nie a eny meomre he capacty f tht prerl ly
Seth ce pea ch cr ean Te
This enty massures the of thet
* rer eal
miVE) x
hyn eee
ipartaon to himiVE)
gob bread aed pd
(Jiocelelsbanddefs he): This enky measures the capacty of plants that generale
Sey enn aes ee nen ed erage
P ; ae aA
oe ca) ‘
;
eee, ,
production (, finite Th yt mcf ie pr pre perce
imi pe tee 7
biwdey @017 eat). L
on to the workh 11 (./lleida/261 pork * F
(.tdoa : This entry Ia the tots! aricunt of erude ol exported, in barrels per day
E} 7 te 3 . u
bday (2016 est) . :
eriaon to the world: 8 ¢.Mefda/2e2renk
. f ate ‘
; _
county comiparizon to the wortd: 212 ekdecerark me cies
* Crude of - proved reserves (../docanotssanddefa himkk264):
This enty fe the ston
Pra
known reservoirs
ES f : 7 n
‘cia. gov/library/publicationa/the-world-Athcok/geos/ve html -
~~Approved for Release: 2025/12/08 C07183805-
Approved for Release: 2025/12/08 CO7183805.
a ''
‘ a ts : -
Asrerice :: Venemiela —@e World Factbook - Central Intelligenczency Paaiiaot
. V 7 = .
em be
es
- $02.5 billonibbi (1 January 2018 est) ‘ at. te
disc fo the world: 1 { Melds/284renik himeVE} .
eiroieum products - Tica cle aitomeadie aibsie: tas way ee inde waGdd aes
oni ducts, in barrels per day. (biiiday). The clecrepancy between the amount of refined pebrloum products produced -
sndiorimpy Sa ee Nene a eee eee agen refinery geine, antl other
~ ‘
(2016 ext) Pea -
ia cx bape NE eee é
evoloum products - ~ opuapion{.Aiccalotavoandsuds.hasdati: This ery ef county''s nl ooneustgen of
stenta products, In barrels per day (gbitday). The discrapsnoy between the amount of refined patrolaiim products,
ey sala nese ahead Sindtor exported Is due to the omlasion of stock changes, refinery galne,
me,
2G est). ° tes * : : . Rh. os ''
o lie cae ee
8 m er 7 Ty tars el pat tad
peeum fod, n bai per day (Ste), . ‘ Rk tae
‘bby (2016 est) : : isi F3 .
hémHVE).
pe products - lps aetna nT ery art imports ofretined.
: outs, bara per day (ne ‘ se
(iG est) - s : : a oe ee
barton to the wesid: 117 (Jfetas2eeenkhinave)
: on (catnip na a
‘ iim waa exported is
. Se, ene mene
.
OS himHAVE) * . . a
pum (2017 eat) bugs tg : :
20n to the workd: 28 (.Melda/28Granic htm) ‘ cad fi
ai - conaumation (docainotesanddee il#270): Tia ery the tte natural ges Gonsumed incu metrs (cr
‘ Ls
= Hésion of stock changes and other complicating actors,
himievE)
cu mi (2017 eat.) +
arieon to the world: 89 {. fhekds/27 Ordink. htin¥#VE)
a ene ee Ti ay th ta nfl genera aoe m).-
/ an Mee cree
oat . be ore ‘ ns a)
fo the world: 200 (.eld27 ‘rendchtmiev) :
-Hdocamnotasenddefs: SATA wats Ou et etal os aeedhicdes eis at
. wool
:
4 oe
wwe
awis toe Wes: 200 (Near Torark gai
gps abl raderarcon rir retin OR a REE
engineering data, can
" Netural gaa
Dp ivyordinh ). Proved reserves are these quaritities of natural ges, which, by analysis af gclogical and
3
cum (1 January 201B eat) te Sy ; a
erigon to the work: 7.(Aekdei27SrenkhonwVE) - - 4:
s . . . oe? mS ai
t= : Pa 2 a
¥ .cia.gov/library/publications/the-world-4book/geos/ve htm! ;
Approved for Release: 2025/12/08 C07183805. PP eore ne as
eases . Approved for Release: 2025/12/08 C07183805
* South Ambricaz Venemiela— ge Word Fetbook- Cental nteligene@iency | Pag 23 of 28
i e
fe m OK i es oe : ‘
(Carbon iioaide emissions from coneumption of energy (./doca/notesanddefs himi#274): This entry Ie the total amount of carbon’
= est od in metric tons, released by buming fossil fueis in the procees of proctucing and consuming energy.
{. Mloids/274.himWVE) : ae ,
20.9 milion Rt(2017 est} 2’ oe F Site
‘country comparison to tha world: $6 {.Melda/2?4rank htmigVE)
munications 2; Yenaguela
“Tekephte 24 hoc Ties {.Adoceinotesancets.hiri#106): This entry gives the total number of xed telephone thes in use: es
wo anteats ve
ber of subscriptions per 100
becriptions: 6,828,714 (2017 est.) - : : ; : ‘
becriptions per 100 inhabltente: 19 (2017 eat) “3 : . f
Soountry comp on to the world: 27 (. Mekia/1@8rank himieVizy 6 Te Pir wae
plaphones ~ Mobile celular (, /doce/ndtasanddefe.himu/197): Thia eniiy gives the‘total number of mobile Cellular telephone
ubscribe 8 wall as the number of subscription’ per 100 inhabitants. Note thaf bacausa of the ublquily of mobile phone use
oped countries, tha number of subscriptions per 100 inhablents can maceed 100; mn
Seidel 197, ro, My 7
total subscriptions: 24,403,687 (2017 est.) . . Ss .
bacriptions per 100 inhabitants: 76 (2017 eet) , : .
Country comperieon to the world: 60 (_/eldal1@7rank him¥eVE) .
Telephone syate (.Joca/notesanddefs.htmi#168): Thia entry inoludes a brief general easeesment of the system with detells
on the dompet and International components. The following terms end abbreviations are used throughout the entry: Arabast \\
Anah Satelite Communications Orgenization (Riyadh; Saudi Arabia), Autodin - Automatic Digital Netwerk (US Department of
Defense). GB - citizen''s band moble radio communications, Cetiuler telephone system «the telephones in this aystem are radia 5
braviscs ‘with each Instrumentshaving he 0. . more (.Adocsnoteagnddets. him 08) : ‘ oa
: i Bg oh? oh eres a
(ffiekia1 8. niene#VE) coe foe ee : eo i
n aeqaarment. modem and expanding; by late 2018 has dus to in the with
Pela ee ern bis
‘country due bo Anandal concems of customers, decrepit sate of fixed-line network and to pay for equipment from foreign
iS yendons; p y of social networks has given growth to mobile data traffic; LTE population coverage 47%
domestic: two domestic’ systems with three darth stations; telephone service in''rural
g recent improvement in
areas; . of @ nstional inter-urban fiber-optic network capable of digital multimedia services; 3 melor providers operate in
Bilbo! Pi and compete with stabe-cwned company, fteecine 18iper 100 and moblle-celtar telephones eubscrbership
i country code - 68; submarine cable systems provide cofinectivity to Cuba and the Carthbaan, Central and South ‘
H US; satadite earth atetions 4 Intelsat (Adentic Oosan) and 1 PanAmSat; participating with Colombia, Ecuador,
melivia in tre construction of an Intemational fiber-optic network = - sfoe. .
{..Adoca/notessnddefa.himi#180): This entry provides Information on the approximate numiber of pubic and
well a8 basic Information on the availability of satelite and cable TV sendces. -
dtmb202); :
Pe een Ht enc used by the Internet Assigned Numbers Aulhorty Sth
i r C Pe 7 :
r] ms .
ae S&S (
: : A .
littnsul/wrg}wicis. gov ibrary/publications/the-woild-Retbook/geosive.himl
Approved for Release: 2025/12/08 CO07183805. —- Eaten else
ener for Release: 202011 2/08 CO71 83805,
A
ica: Vente Wott sa chase . Page''24 of 28
i
''
ue ne . =
Reeve)
otal 18,547)981 (July 2018 eat).
‘percent of pap (ation: 60% (July 2016 eet}
fxd subocripions(./dceanoleeanddefsMinl#208): This erty ged the total mumble of fied-bedbend :
Subscriptions, ae well ae the number of subscriptions per 100 inhabitants, Fixed f cal wired
oe (eg cme ie eal erp ter an aa cents we
ig 4 * *
,
i)
,
Serengeti arn
: =e aon wagewannie, +more (-ddocahnotmeanddeta himit877) . ;
od ek carters: 17 (2018
d alycraft operated ay alc carters: 122 eons -
‘ fr er traffic on registered alr ‘camera: 8,468,863 (2015) : a
annual fraig talc on registred ale carer: 6.204.086 mf-on 2076) é oe : : : t
“ohiales i pgistration country cove prefix (.Jdocamotssanddets.hirilkS76): Thia entry provides the one- ortwo-charecter °
registration number consists of two perts: a prefix consisting of two-character alphanumeric
d ance rain aif on mas (cent aS
Jeti bee yD ate
0 dd Hmif’370): Th ‘erty gives the itl numberof dy bina git kos bath
Ste eee
b d inataliations. Airports or eicflelis thet are no loger recognizable (overgrown, no facilities, eta) are not Re,
G Pn ee ne ene: 5 ay
7 ce
__ aunty himuiVE}
- Alsports - f paved rurwaya (/doca/noteeatdets hii#360) Tha etry gle the total nanber of sirport with paved rurways.
Ssephall surfaces) by length. For alrports with than one runway, only the longest runwely Is Included
. ollewing five groupe = (1) over 3,047 m (over 10,000 oan gts Meats: Gea he
: eooot B.000 fy, 1) B14 to 1.28 m (3.0001 6,000 and (5) under 814 m (under 3,000. “Only airport with
, tonweys & poner eee Notall,.. more (. fe cS
y
nea han Tin don bel mb iat wh were
ent art depron bg For airports with more than one runway, only the-longest runvay Is
included abcort 9 to tha following five aroun) ove S047 fv #01000, 2) 2488 S047 (8,000 000M)
37 rm (6,000 to 8,600 A); (4) po egret pel ore aces Only airports
i ele ba dea i Riera acc carta
daf3ht
4
}
~ a °
cia. govibrary /publigations/the-world-Aictbodkd geod/ve.hiral 7 “5/17/2019
Approved for Release: 2025/12/08 CO07183805. a —— =
AppIoved for Release: 2025/1 | 2/08 C071 83805-
B29 m: 127 (2013)
i
under 914 m: 190 (2013)
ocainctosenddets., #082) The enty ee the teal number ot heliport wth hard-surfece runways, helipads, or
that eupport routine sustained wichabvely andi have aunport facie bichaing ane ce rete
clea adh fuel, pagaenger operate aaa ergo fu oo upp nang
/ddeahnotasenddefe himl#S83): This’ the lengthe and types of for
percept so lengths types som rt pt
Ban cide, Gtk 7 en i, 78 ats pc 9
§ IPS06: Tid ny elt rae tstn langle eo nine) bbiva ad b eoncoiee
. ich aw measure fo data beter th gr eso th lo bouhgrala The ar yp ype ot
oterdard, narrow, and dual, Other gauges are feted ander note, Some 60% of the world''s ralhvaya use the
gi male hd On Le en
On Wee Teap.... more Moceinctesanddets.himit384)
gt 447 km 1.436 gauge (4.4 kr elected) (2014)
to the workd: 116 (.
Th ye elie of roa nat ene rh
ed portions. : _
Te . : a ie Ue Me ,
een 2014) Se bade te OH .
OM pai tothe wort 42 (.Melde/S86rinic mtv)
Warm iSoccoessea ae Ti ry hosel nigh of eve er, ppirabaalreac apes
so Fv {000 er a cn ein agate went dcr
co on to the workd: 20 (.elde/38Grenk htm¥AVE)
Marchant my (Adocainotesanddefs henliS87): Merchant marie may’be detned es ai ships engagedtn the cariage of
“+ goods; or al commercial vesselg (8 cpposed to all nonmltary ships), which excludes tugs, flehing vessels, offshore off riga,”
trechuches tf ruber af shipe (1,000 GRT or aver, total DWT for those ‘ships, and totel GRT Yor those ships. DWT or dead ©
Weight tooroge fe the total weight ofc... more (ocahotsesnddete himi#67) : : :
‘Bau, b eater inntnaa nag pooner sa oa Salen ok
a d passenger ships. The ling ie. . ee ey F
: exp {..sdocainotesehddete himlé330}: This ‘This entry gives wai cl lua tela 9 a ee wea
wastes Serco fren ene po (COP te GOP moa nan geen a bbe
: : c ” 8 A d eee ik :
a atiebacae el Old al al eck SA72019
a7 om . . 7 be ie i .
a ~—~~-Approved for Release: 2025/12/08 CO7183805——-—----------
South America :: Vso he Wat Ca ag Page 25 of 28 .
ttc. This erfy contains information in four subiekis - total, ahips by type, forelgn-owned, and registered in other countries. Total
‘Approved for Release: 2025/12/08 CO7183805- 7
. Rennes - 4 s
b power pasty (PPP), Forcounties wih no mary forces, ie fgure can incuce expenditures on pubs secarty and
)
pinpariaon to the world: 114 (.fffeida/330mink himlaVE)
branches (/doca/notesanddele, himi#@34): Tir se evo bce bora dts i ct
of play round, reve, aed mane free), : & oe
ms x . a 3
i Antes *
of Armed Fite (Fuerza Armada Nii Gand, FANB): Baran Ay (co (Gert Savana, 0, FB)
‘Bolveran - y (Amada Bolvariana, AB: Includes Naval Infantry, Cosst Guard, Naval-A\\ Aviaion}, Bolvatan .
‘(Aviecion Mildar Bolivaiana, AMB; Includes Air National Guard), Bobvara Neon Gerd (Guarda Neco! Bott, GN) ‘
. Bolvarian tia (Milica Botivartana, NB} (2018)
“Miltary sebvice to bon (Mecano cma
’ oe eee
4
383,himWVE}
fy ieee (00 ri a iy se eg ney eat
8 mininum service obligation js 12 months (2016)
: ts (, .Adocanotesanddels_himie3s4); ‘This entry describes the threat of pimcy, an defined in Article 101, UN
0 on the Law of the Sea (UNCLOS), or amped robbery against ships, 8s defined In Resdlution A. 1026 (28) adopted
cH {chr ar ts und, ve hae og ibe sn te coos se W208 ee ers
d and this increased to 12 stacks In 2017 making Venezuela the fourth faxth most dangerous area in the Word.
group ornare pon ean tpt
ies blac pclae red at aa headquartered. Detaie
ofgantneatc ap a acca amar aaa
parson | Moots This erty inudes a wide veiety of sues that range fo
ataral boundary disputes to unliateral claims of one sort or another. Information regarding diaputes over
al toroatrial and Martine boundaries hes been reviewed by the US Department of Stain. Referinoes to ther
a vat 9 borders or frontiers may siso be incktied, tuxh 83 resqurce disputes, reread ,
aE an rennet eee: oe
Secnile iis Gas wen dio ego pera pans any ain lw wos edn Guyana has" :
* expressed Fitenfon Join Barbados In asserting cleims before ihe UN Convention oo the Law of the Sea thet Trinidad and
: e boundary with Venezuela extends into thelr weters; dispute with Colombls over martiime boundary and
ule Sintra Loe Moros lance nar the Gui of Venezu; Colomian organized Hegel nacoesend peranfay
é ea eee nee U8; France, and the Netherlands recognize Venezuele''s granting fl
Y ia govlbrarypbications/te-word-fltbook/geoshe btm : i ; "5/07/2019
Approved for Release: 2025/12/08 C07183805.
b Gosia tanned telsa tence eran sencieavoioee ara The entry Indudes the number of +
ee . : : - ” ried ke po?
Atherics :: Venezuela “Ov Factbook - Central Ineligencg@gency Page 26 0f 28, ake
ees for Release: 2025/12/08 C071 a
erica :: Vege Wo Facttvook - - Cr neon “Page 27.028
owalcondnatiel silt eamadiea ever portion
i as ‘
sieve ;
cet 1287 Cale 2017} a 7 ae ss
persons ( _docainotesanddets.himi#328): Trafficktrig kn persons si ows A Wotina who are.
Ged, or coerced Into isbor or sexual axpioltation. The sprain nai i vo ‘
fh eddreeding labor standerds, 1
ti dre Yoneda sesso er stabi cry ree, won me chin eu acetng en
0 ff Venemuelan women and girs, sometimes luréd from poor Interior regions to urban arid tourlet areas, are trafficked
8 on within the country, &8 Well as in the Carfubéen; Venezuelan chikdren are exploited, frequently by their
conditions
~ Venezuela dose not fuly comply withthe minimum standards for the emmineton of traficking and is nat
ig Be gan: 2044, be goverment appeared to Increase eforts to hold trefichere ofialy
d bit a lack ot government data metie inw enforcement efforts dfffcutt to assess, publonlly avetiathe
dicated many cases pureued under licking lew involved
2): This enby givea iniomaticn on the fve categories of ict druge - riteotios,
_ sea Gs stn) ara oma These ctogries clude many crgelgaly produced and,
preectbed by doctors as well as those Megaily produced and sok! outside of medical channels. Cannabla (Cannabis sativa) ia .
conund hes a oe cae tin mmf Aa
pen € grass, refer), a nana .
nM
J
. rualbacsle i te ec lt ch Aa t cala cela ica Sudan Gears lenge Guanes of
cocaine, hete snd marfijuena transit the country from bound for US and Europe; significant narcotice-raiated money °
‘ti laundering ciivity, ampecialty along thé border with rb omar erga cael ai :
pes al eee a ee a eee Sone ty Connie Pees See
“4a
cia. govilibrary/publicationa/the-world-Letbook/geowvehimt =. * 5/17/2019
‘Approved for Release: 2025/12/08 CO07183805. oe','fdf8dba056d175ac9b6931caca34f5dd21367e9e89d3cab9f35b11af5d360ad2','internet-archive','cia-readingroom-document-07183805','txt','cf6a10ea00c36eb3db411ead5f1899246ed82cec14abf11f90452ebef3d181eb','https://archive.org/download/cia-readingroom-document-07183805/07183805_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('186e60bd20b347d326f77d290382c7a59def59dad41a5da0668a8f11048f758b',2018,'','','raw',1,'Approved for Release: 2018/04/27 C06726998
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998 :
ae
teow
i
{
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entitics worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
_» gence Agency. The data are prepared by Office of the Geographer, Department
of State and by componcnts of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and canuestions should be addressed to the
Office of Basic ana Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
~ channels for dissemination of the NIS.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
Table of Contents
Page
SAN MARINO. 2... 2 ee ee ee ee ee ee eS 293
SAUDI ARABIA... - ee ee eee tee et ee eee 295
SENEGAL. . 2-2 ee et et ee te ee eee te eee 297
SEYCHELLES . 2. ee ee eet te ee te ee 299
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE. 2. we ee ee ee ee ee et 301
SIKKIM... 2 ee ee ee ee tt eet te HE 303
SINGAPORE. . .- - 2 es © eng aoe: Re a Meas lee SARI a NES, TEES Ms 305
SOMALIA. . .. 2. - eee ponies ee Yornlg vies Ro eee dats tet Se wee We 2 . . 307
SOUTH AFRICA... ee ee ee te ee ee 309
Southern Rhodesia (see RHODESTAJ
Sil aaah AFRICA. .... > bees Je ghigs vate Go are em 6 ieee ise uy
SPANISH SAHARA... .- hc le wale “ae ae Gah tae ee ogi Cee SS 317
SRI LANKA. 2. ee ee te et ee ee 319
SUDAN. . .. 2 ss eo eel Wes eee ce tat gi rel cal get, Ser ton ah Say va Sg, ea nes 321
SURINAM. » 2 ee ee ee te ee 323
SWAZILAND be gy ose ental a: atctah eae pO) be bg Wik en WE TES Be ew TS 325
SWEDEN . 2. we ee te ee te ee ewe ee ee ee 327
SWITZERLAND. . 2... 2 ee ee ee te ee eee ee eS oe « 329
SYRIA. 2. ew ee et te tee we ee ES 331
-T-
Tanganyika (see TANZANIA)
TANZANIA. wc eee te ee ee et ee ee & 333
Tasmania (see AUSTRALIA)
THAILAND... 2... ee ee te ee te ees gf ehhiig ig fe eel eh % 3330
TOGO... . es cia, ais tae ong. And Keen oper ae Pah te NS a ject wy eS
TONGA, . 2 ee ee et tte ett we eet we ee ee . . 339
TRINIDAD AND TOBAGO. ....-+.-s Se clbt ee hg seh ke Tal yor et to? ow) Ca seas . 341
TUNISIA. 2 2. ew ee ee eee te ee ee Sag Se 2849
TURKEY . 2... ee ee ee ee Band May US Sain EPS Mee tay seh ain aie S. te es TORO GS 345
-U-
UGANDA. 2. we ee ee te ee te ee wee ee 347
Umm al Qaiwain (see UNITED ARAB EMIRATES)
| ee eee ee PP To a 349
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Unm al Qaiwain . . 2 2 6 eee ees 351
United Arab Republic (see EGYPT)
UNITED KINGDOM... . eee ee eee te ee ee eee 353
UNITED STATES. . 2. eee ee te eee eet ee he eH 379
UPPER VOLTA, . . 2. ee ee eee et ee ee ee ee eee 355
URUGUAY. . .. 2 «> Ly cgi gh tortie. Ue dies Nel vas Meneses Sept ere, ee? cote ree. 357
-y-
VATICAN CITY 2. 2 we ee ee ee ee 359
VENEZUELA. . 2. 1 ee ee ee et ee ee ee he eee 361
VIETNAM, NORTH. . 2... - ee ee we ee Sree nds. Ghceear barr") sat War 0 eso fe 363
VIETNAM, SOUTH . 2. 6 6 we ee te ee eee te eh ee ee 365
v
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive SPRY
Land boundaries: 1,600 mi. Seat
cover SAUDI
WATER: "Sy nama
Limits of territorial waters (claimed): 6 n. mi. Be
except in Black Sea where it is 12 n. mi. SUDAN ‘
(fishing, 12 n. mi.) £ RSS
Coastline: 4,475 mi. ETHIOPYA','a24946e0eda2487814d38bc598fdbba53715746ebaacc57387c8bc055ad24a8d','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d82d23f1aa9eba0112bfd23af5221df46c7ba55f3267312ca0d33dec2aa8b941',2018,'','','raw',1,'Approved for Release: 2018/04/27 C06727040
. January 1979
Zz
0)
a4
0
3
z)
1)
9
¥,
0
5.
a
0
- eet: . | National Basic Intelligence
$1 FACTBOOK
ay
>
0
as |
‘@
n°
0
f
y
[ GC BIF _
January 1979
Approved for Release: 2018/04/27 C06727040
eee ee eer etahe tet,
Approved for Release: 2018/04/27 C06727040
FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
- Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
U.S, Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5
Approved for Release: 2018/04/27 C06727040
rr
: Approved for Release: 2018/04/27 C06727040
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-001035.
Approved for Release: 2018/04/27 C06727040
’ viii
‘WESTERN SAMOA
Approved for Release: 2018/04/27 C06727040
—TI—
TONGA oo... picts cetera dd halk tas 42M acl lace Bage Rt ang a eeIR eg
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ........c..cccssssssssssssssvsssssevesssctessssessesssssssisisteeeceessissnesseeee','229191d21c5e7113b8bc9c7834f6ee045e559d212a2c62569a00745b896f5e03','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de390880dfff30034e9ba27a95ff4e6c1471fa97bff0e1c130d2095cd2abc957',2018,'TN','Tunisia','raw',2,'TURKEY
ye
UGANDA) ):ecce ie tctivinl Gaiid neil ti lnetin dain Minion iieas alae SAS AS
Umm al Qaiwain (see UNITED ARAB EMIRATES)
UNS SRE soos eciecdid Setaa ces Hideo ae ses enbevicah oe esn ave tuapiea vests eaetabaebeyainsvedavays ba dan dagas¥ deaddeceetbagnetyeee
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain
United Arab Republic (see EGYPT)
UNITED KINGDOM: 0).50$:68.00sisstcta neve ieee ie atch hier
UNITED STATES) «ies st ndecta isda iigetenensc ce ie deed rhe tcien aroatinnaedieuaties
UPPER VOLTA > f.)cs dees hei hedhccsidesess ese ad dete as ae Gaetan','87fea2c6025fe50108bbe7331561928567fe86fd954f857c29e9754a3d429d1f','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41fb0df40dcf2aaa734e6fb6fe21110210e3fa9300044d36170b534daac2cd21',2018,'UY','Uruguay','raw',3,'—v—
VATICAN CITY. o.cisciicckectests tisaetes cats at etch ee enesetn dens Uonhieintieaatinia cael
VENEZUELA s c3fcicccdeseseh estecccbesqntenaessncdans gti nates gts Se aadead bps bts Gedaderebenpaniebecsae Beuthanea
VIETNAM
—w—
WALLIS and FUTUNA oon. ce ceric crete cnererrscnsecescrseseeecieersesneeteeereecreges
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
y=
YEMEN (Aden)
YEMEN (Sana)
YUGOSLAVIA
=7=
ZAMBIA. < ciscceisivshetes Hass aoe sess el eens eens tae a Gai ane a eae dent
Zanzibar (see TANZANIA)
Approved for Release: 2018/04/27 C06727040
January 1979
213
Approved for Release: 2018/04/27 C06727040
January 1979
TUNISIA/TURKEY
key centers are Safaais, Susah, Bizerte, and Tunis; 100,000
telephones (1.7 per 100 popl.); 8 AM, 3 FM, and 7 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,273,000; 718,000 fit
for military service; about 75,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1978, $153 million; 6% of central government budget
Ankara
TURKEY
oa
\\: ae GA =~
Since ats
{Sas reference map V}
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','2718b31987e7b789819ff5bb67cdf4eab1f34054cdda210d0c8cee0a45e8c535','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4cdb529ade2a09001db399ada527dfdedc9088a87b07062bd8e743b52881391',2018,'','','raw',1,'if 4a. Approved for Release: 2018/04/27 C0672 704 2s
: Seer’ 1 @E%. National |
| a (a) ce. | os sig
Center
; National
| | Basic Intelligence |
| Factbook | :
July 1979
GLEEAIRE »-— Jo0g398,y soUESTTPOIUT aISeg PeUOHEN
a Sa
4
|
t
Secret :
GC BIF 79-002
July 1979
\\
Approved for Release: 2018/04/27 C06727042
i
F
\\
t
i
L
!
f
|
i
| Warning Notice .
|
:
re National Security Unauthorized Disclosure
| | Information * Subject to Criminal Sanctions
F
|
|
;
‘|
|
|
|
|:
| : Dissemination Control! ——
! Abbreviations :
! —
4 ;
il y .
;
i _
|
f oe
Pr
|
l
a |
Oe
—————VK— KEE
Approved for Release: 2018/04/27 C06727042
c—,
7
=f Nes
BRS
oe ee Doo — palate as ws y . tomer 4
: Ne Por ited
Approved for Release: 2018/04/27 C06727042 ;
4n x5
Ma National “Sercret-
tie Aaceceniel | : (b)(3)
SZ Contes :
National
Basic Intelligence
Factbook
July 1979
Supersedes the January 1979
edition, copies of which should
be destroyed.
The Factbook, a compilation of basic data on political
entities worldwide, is produced semiannually by the
Office of Geographic and Cartographic Research
with contributions provided by various components of .
the Central intelligence Agency, the Defense intelli-
gence Agency, and the Department of State. Com-
ments, suggestions, and requests for additional copies
may be addressed to:
Office of Geographic and Cartographic Research
(Attn: Factbook)
Central intelligence Agency
Washington, D.C. 20505
Unless otherwise indicated,
individual entries are Unclassified.
~Secret—
GC BIF 79-002
July 1979
Approved for Release: 2018/04/27 C06727042
viii
.TAIWAN
Approved for Release: 2018/04/27 C06727042
=f
Tanganyika (see TANZANIA)
TANZANIA 835528 i ato cheats Sing Selene AM scaled Abatement de cles tae Moc ietee eA Glae La,
Tasmania (see AUSTRALIA) :','17c76fc57964e9e265cdb7e01247ff344b48f8f5bed7f69f931d495d9a334a11','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2fd47e69ce5b2abe6e9e316548c90dbbf2f84793d42c24594df39976e1565d9',2018,'TH','Thailand','raw',2,'—U—
UGANDA °:cicc0c ine diaries fot hd eh codeine lt da
Umm al. Qaiwain (see UNITED ARAB EMIRATES)
USiS Re xP ei AS a oe AB de sel tah etna ic alban aaa dal ee
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain o.oo... cece teetteec eee
United Arab Republic (see EGYPT)
UNITED’ KINGDOM: ii.chetnde eee ease oi ineeulaten caunranniiieaieald
WINITED: STATES © esc tics pick ageh csesessertestolentiveaedguist ae gateactavtear ue mueaadonua soto
UPPER: VOLTA) i icsisescitend, dy acto aha ieee oe aN ha aR ae
URUGUAY 2.2025 sd on acs th ceebdeelth deaail bs it aa poidivoes be patsagus Reve ee iS Meera te
Vv
VATICAN CITY
VENEZUELA
VIETNAM
—w—
WALLIS. and: FUTUNA: | o5:) 022.5 Sic iecsa facets cove idk Mieiadan dls svtasadeaedelde Wgec es
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
WESTERN SAMOA
ys
YEMEN (Aden)
YEMEN (Sana)
YUGOSLAVIA
Zanzibar (see TANZANIA)
ZIMBABWE-RHODESIA
Approved for Release: 2018/04/27 C06727042
248
July 1979
Approved for Release: 2018/04/27 C06727042
July 1979
éSea reference map V)
LAND
766,640 km?*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','4a3473dce6e084136ed98a392f13f6d6cce4c4e03f22d2b86f9359158600c544','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc28128dd4d70b072489969c3293a5ff602d623caca20d42517cc59ab6c7636e',2018,'','','raw',1,'A pproved for Release: 2018/04/27 C06726997 =
NATIONAL INTELLIGENCE SURVEY
; BASIC INTELLIGENCE FACTBOOK
JANUARY 1973
$
Py
; CHIVAL RECORD
des t 1972 i f this Factbook, ''ARCHIV. ,
Supersedes the July 1972 issuance of this Factboo i PLEASE RETURN TO |
copies of which should be destroyed. AGEN i ARCHIVES,
a ORT
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRE—
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entitics worldwide, is coordinated and published
scmiamnually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by components of the Defensc Intelligence
Agency and the Central Intelligence Agency. Comments and
suggestions should be addressed to the Office of Basic and
Geographic Intelligence (Attn: NIS Factbook), Central Intel-
ligence Agency, Washington, D.C. 20505.
Additional copics of the Factbook, both classificd and un-
classificd issucs, are obtainable through established channels for
disscmination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF TIIE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTIIORIZED PERSON IS PROHIBITED BY LAW.
CLASSIFIED BY 58-0001, EXEMPT FROM GENERAL DECLASSIFICATION SCHEDULE
OF €. O. 11652 EX zea CATEGORIES SB (2) AND (3). DECLASSIFIED ONLY
ON APPROVAL OF OCI
Approved for Release: 2018/04/27 C06726997
em det
ee ee
Approved for Release: 2018/04/27 C06726997
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(2) ee Confidential
(S)...... Secret
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
Table of Contents (cont''d):
SENEGAL. oe be so ec bs Bate oor Ra we ee el ee SO ale le or SP es
SEYCHELLES =o) 5.95. et te ee A fe ee ee Sa es oa hte erie eae
Sharjah (see UNITED ARAB EMIRATES)
STERRA LEONE: 3. 3. 3,6: jose aoe koe: eee eo Aca 4 be ee RE are
SIKKIM esol aoe Wn ea ey eee ae ee SO We we Aaa ter eS ete
SOMALT As. for) ec se coh Oe ewe se ee Gc ce ites) Srl a as ae ew ele
SOUTHARRIGCA |e. oi: eh ee il el oe ere ww Bea ch Swe wwe als
Southern Rhodesia (see RHODESIA)
SOUTH=WEST |AFRIGAS: e555 55 Soke, Woe les ae ec OS es
SPAIWNs o.oo oe lertene ce mar Cove! Cee oh Wow LSS? o> He Rua coy See ee Ged Saas
SRT LANKA si i50c3. oe hate faa tes. a ER a ee EK ey
i i i i i i |
2Tz
|
Middl (see peace
THAILAND... .... B Meas i) Ate ha kak oA Gheeiued Ma, Mor iy ode te melee fo
TONGA. ee, ee rare
TRINTOAD AND TOBAGOs 2 3 Gav 0 Soba actbnoe and fo aces a
TUNISIA. 2... ww ee Sol Gat cat anh oy Weel oe aoe ol Ga Sakae fee be oh Oe
TURKEY, |, 5353-6 co: sic ae Ges Gos 0 as a te ec Bye Pol Gn eS Tecate faire a
-U-
S.R
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm "al Qaiwain. .. 1. ee ew eee
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 2 we ee ee ee
UNITED: STATES > 5. eas ce. Ss ber evs ie el en a eee ee
UPPER ‘VOLTA S. a ten ves és ce ete oe Nel ie Sele a? ec ee ea Mee ea
URUGUAY 6 ese ccs aise Melee yee og oo ley ty ce: Sa i a ea ey tea eS La ee
-\\-
VATICAN CLIN io a oe dee ae ht a Rees ae es I ae ae cas
VENEZUELA cece seas ol a as $05 ar dk a ce ave dap Pe ay Sa a Se, lw Ae
VIETNAM, NORTH... ....., BS Ae Sia Bye ROSENT RS Jet te be a dh, ae eect, ye
VIETNAM, SOUTH . . 1 eee ee eee we ee eee tt tts
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
—~Sterer—
NIS 27 TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER: Pare
Limits of territorial waters (claimed): 6 n. mi. .
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mt.)
Coastline: 4,475 mi.','3d010a63a9223686fb0d93a0591b381470714a42cab3b49d027269a6eff5c8a9','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f20037a511ce5ca4c919101088472f9fba8a19d3298e190aede5242147e97a',2018,'','','raw',1,'Bee
Approved for Release: 2018/04/27 C06727041
National 59 U (3° “Secret
Foreign
Assessment
Center
National
Basic Intelligence
Factbook
January 1979
~Seeret_
GC BIF 79-001
January 1979
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
NATIONAL SECURITY INFORMATION
Unauthorized Disclosure Subject to Criminal Sanctions
DISSEMINATION CONTROL ABBREVIATIONS
NOFORN-— Not Releasable to Foreign Nationals
NOCONTRACT~- Not Releasable to Contractors or
Contractor /Consultants
PROPIN- Caution—Proprietary Information Involved
NFIBONLY— NFIB Departments Only
ORCON- Dissemination and Extraction of Information
REL...
Controlled by Originator
This Information has been Authorized for
Release to...
Unless otherwise indicated, individual items are
TUNCTASSHHED.———
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
FOREWORD
The National Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published semiannually
by the Central Intelligence Agency. The data are prepared by components
of the Central Intelligence Agency, the Defense Intelligence Agency, and
the Department of State. Comments and suggestions should be addressed to
the Office of Geographic and Cartographic Research (Att: Factbook),
Central Intelligence Agency, Washington, D.C. 20505.
This publication is prepared for the use of U.S. Government officials.
The format, coverage and contents of the publication are designed to mect
the specific requirements of those users. U.S. Government officials may
obtain additional copies of this document directly or through liaison
channels from the Central Intelligence Agency.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
~SECRET- January 1979
-t- Page
TANZANIA, loses ht tee teak te tl Ra A aM poate al oN ath 244
Tasmania (see AUSTRALIA)
THAILAND: os sscisechtist Seustecs eae aee cet, Shab clei ab a OR eels Pts cout Maree tt elaes BOR ot 245
FOG, ieecrisk EL AI Nol Sole hk AN EY Oya tt ote dedthee ch ped nd eve 247
TONGA ooo llassiinad tia dba ots ale het ae ea oa ee ed tenth tal Mids faut Seven 248
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ooo. cceccecececcecesestctetevtte coves ceteveseiteteeeetece 249
TUNISIA ee 2oee Se STON get ales SPN es eel ee ase SAN etl Oct a pe 251
CORRE ic. 2e5ote 502 oN ciel ats po eile as ee aN Me la on Be ek oat a ete ee ta vt 252
TUVALU (formerly Ellice Islands) 00.0.0 ceccccccecee tcc cecececeeeeeeeeeeeeeee ce, 254
=
UGANDA 2) acted ese acd deed te i Trt Lele a tak ttn togh ote 255
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USSR? siesta ee Nees a eet Sas tet el ee ne a Saf Te OT a 256
UNITED ARA® EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain oo. 259
United Arab Republic (see EGYPT)
UNITED KINGDOM ooo ccc cece cccececacecetevavenerestetieevins ss ccutvevestititeteveveneees 260
UNITED “STATES © ects. csc inal Pah Sia Re COT uh Ee peda itn oie ay 280
UPPER VOLEAS f3cccess3 20) ag ea Ge Ee ae se ea ts aaa 262
URUGUAY > -5s:che eset och iat ath tes lahat ae Le Ma A Cat, (heel val iy 263
ye.
VATICAND CIV. 2.3 ited Stat etek e al Orie ld, Grech tte ce eee A ade 265
VENEZUELA 220.3 5 footy Ei ec ett reech conden aloha es eR es oe 266
VIETNAM 252.022 css. Dect LE sea seerass Seen t Nl inn Sane chet ee tet ge! Be 268
—w—
WALLIS and FUTUNA once cc ccsesceecesteeestevsecetevesesceteeceveteteteeeteeere, 270
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) 0.0.0.0. cocccceccccceseeeeeceeeeccce 270
WESTERN SAMOA ooo ccceecces sees sense nes ecucevevevevevesteseatsisesitivatesttavstivesteseterteceece. 271
—y—
YEMEN. (Adon). ¢:c0:2.35.05 Sy. esa tn a en Hei dewees din lee Ai rece, nie & 272
YEMEN ''(Sona) \\ 20: 30.6 Ones aes Recetas eon, Ga 8 OR a a ak 273
VUGOSLAVIA 4. iee tases, etegsle iS ea bebe Aten tenty hvac Mae aba 275
—7—
LAURE ects weet teen beaded land ihe So, nA RO Nt et tat ate cms ee a Ht ae Le Pog 277
AMBIA Shep Me vet Beret recenseblen at ert ithe, Wee EE De BER as ot tee ae Ct aie! 278
Zanzibar (see TANZANIA)
viii ~SECREF-
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
SECRER.
NR Record TURKEY NR Record
NR Record
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
252 “SEGREL_
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
“SECRET
TURKEY
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','91cbd5d071dd25ea465713c0f86903693de45bbebdbbbc2608e54b323ca18688','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

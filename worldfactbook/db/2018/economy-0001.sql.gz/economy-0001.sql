SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15dc0dfc10a73feb97ecb5ae8a19b385f36780278de5fed4fd3f6aa3105d94e0',2018,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $390.5 million extended by Communist countries 1955-December 1971; none
extended in 1971; total U.S. economic, $2,727.9 million (1946-71); total
U.S. military $3,250.2 million (July 1946-June 1971); $603 million in aid
commitments from international tes (1946-71); $657 million in bilateral
aid from other sources 1960-70
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','4c5921c18d539de60f8b6e157cd7b171fa7672f2c9502dc3d789c30404de55ea','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47857270f4e7429622bc39ca512318938c466ef6f2c13e077fbb1fdee513a34a',2018,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971 :
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
Mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','a893c8676599b7e8f9599afa88721528d836b28df6ec5629e7a51b3407d7a703','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bddb90bd183b081f7e30bfdf78a7c26efb36f5751bd627c44dd651402b69e883',2018,'UY','Uruguay','economy',6,'GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Approved for Release: 2018/04/27 C06727040
Approved for Release: 2018/04/27 C06727040
January 1979
TURKEY/TUVALU
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million (f.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Budget: (FY77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year; 1 March-28 February','6d481c40eef294111bb6be0fe2d7c7299f0393ba2d3ccfb9026500459e9c72ad','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('193114c26d4b76e007b6f7b6eece6a53b450f3b88ad33560dbc7db385ea6c33e',2018,'TH','Thailand','economy',5,'GNP: $48.7 billion (1978), $1,181 per capita; 2.7% real
growth 1978, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton,. tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average. years
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
245
Approved for Release: 2018/04/27 C06727042
NR Record
Approved for Release: 2018/04/27 C06727042
“SEEREL.
July 1979
TURKEY
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1978); 22 billion
kWh produced (1978), 505 kWh per capita
Exports: $2,288 million (f.0.b., 1978); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $4,599 million (c.i.f., 1978); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: 22.1% West Germany, 9.3% Italy,
6.9% U.S., 6.2% Switzerland, 5.4% France (1977)
Aid: economic authorizations: U.S., $535 million (FY70-
71), other Western (ODA and OOF), $1,130 million (1970-
77); Communist, $1,094 million (1970-77); OPEC, ODA,
$362 million (1974-77); military authorizations: U.S., $1,414
million (FY70-77)
Budget: (FY78) revenues $13.1 billion, expenditures $14.7
billion, deficit $1.6 billion
Monetary conversion rate: 25.25 Turkish liras=US$1 -
(July 1978)
Fiscal year: 1 March-28 February','0706127ee1bc228b95463f7c80bfb44fe749b490522311d4a84d801c4b70c202','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3a74f4f803020169733c5f2d18548b7a5e7b22fd0ef56326f06b48f56dc37c3',2018,'','','economy',4,'GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electrtc power: 2.6 million kw, capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 192, U.S. 102, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $1,602 million assistance disbursed 1963-69 by the Aid of Turkey Consortium
consisting of the U.S., 13 additiona) OECD member countries, the IMF, IBRD,
and European Fund of the EMA; $390.5 million extended by Communist countries
1955-December 1971; none extended in 1971; total U.S. economic, $2,727.9
million (July 1946-Ju : total U.S. military $3,250.2 million
(July 1946-June 1971)
Monetary conversion rate: urkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','1de57ea31cf866407b6e812547f4485a4e5342ee730fa5f2945b98c2595fcb1c','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c51b9d5c6c8de83b579e4c4fc0f00b005243dd7e99d12836c6bbe1350ff93ff',2018,'','','economy',4,'GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar bects, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million (£.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals .
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Aid: economic authorizations: U.S., $512 million (FY70-
77); other Western (ODA and OOF), $1,575 million (1971-
77); Communist, $808 million (1970-77), OPEC, ODA,
$1,553 million (1974-76); military authorizations: U.S.,
$1,289 million (FY70-77)
Budget: (FY77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year: 1 March-28 February','f065ae42814d383b3ed98a795c4b6e29d59c19b97c157830a90148f812c491e6','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

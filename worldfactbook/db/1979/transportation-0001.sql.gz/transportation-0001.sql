SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('548bea998492d0e551ac7cbdcf2123e4c4f0551ab7b13c666b3fe00930f1c500',1979,'NZ','New Zealand','transportation',353,'Pipelines: natural gas, 785 km
Ports: 3 major
177
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
July 1979
NEW ZEALAND/NICARAGUA
Civil air: about 40 major transport aircraft:
Airfields: 198 total, 183 usable; 23 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m, 49 with
runways 1,220-2,439 m
Telecommunications: excellent international and domes-
tic systems; 1,570,000 telephones (52 per 100 popl.); 60 AM
stations in 3] cities, no FM, 11 TV stations, and 129
repeaters; submarine cables extend to Australia and Fiji
Islands; 1 ground satellite station','3b99d170c19624b030b7d183a50a1cd9c9c359a5868f93704a6abb1c03281715','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b58dec70814e404b8832e441366b68d3f51b225b61efa1b6a8743fd6a56c00',1979,'NI','Nicaragua','transportation',354,'LAND
147,900 km?; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 200
nm; continental shelf, including sovereignty over superjacent
waters)
Coastline: 910 km
178
Managua {
{See reference map Il)','21903ff9a9b02ab025f80f57d237802be768a171dbf7179d16e921b0e41dd56a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef02b1ce439e731ae929dd1bfeb5e4bbd2539e1cdde41751a23c27f9388cf68',1979,'NZ','New Zealand','transportation',417,'Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: about 40 major transport aircraft
Airfields: 193 total, 183 usable; 23 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m, 49 with
runways 1,220-2,439 m; 5 seaplane stations
152
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
NEW ZEALAND /NICARAGUA
Telecommunications: excellent international and domes-
tic systems; 1,570,000 telephones (52 per 100 popl.); 60 AM
stations in 31 cities, no FM, 11 TV stations, and 129
repeaters; submarine cables extend to Australia and Fiji
Islands; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 7 1 3,000; 716,000 fit for
military service; average number reaching military age (20)
annually about 30,000
Military budget: proposed for fiscal year ending 31
March 1979, $281.8 million; about 3.6% of central govern-
ment budget','3f82b0d06e976f4cff0c951952a335216732c2eb4d5623d9e877164cad64f7b0','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b5cd0d7ee9a93e07c195958e8aa5ab24ced7437122ce0b052ad99ec13d70167',1979,'NI','Nicaragua','transportation',418,'LAND
147,900 km 2 ; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 200
nm; continental shelf, including sovereignty over superjacent
waters)
Coastline: 910 km','ea54919bd39cf22eea41009514c3ea291dbf6f319d4d231a3d0b2271a2247508','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('533126d6701cc9ab1754c0d70aa3c5ba895b41a4a19abfa4a4657e833b3b0961',1979,'NZ','New Zealand','transportation',405,'Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: about 40 major transport aircraft
Airfields: 198 total, 183 usable; 23 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m, 49 with
runways 1,220-2,489 m; 5 seaplane stations
CIA-RDP79-01051A001000010001-5
AAA TEL
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
NEW ZEALAND/NICARAGUA
Telecommunications: excellent international and domes-
tic systems; 1,570,000 telephones (52 per 100 popl.); 60 AM
stations in 31 cities, no FM, 11 TV £ stations, and 129
repeaters; submarine cables extend to Australia and Fiji
Islands; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 773,000; 716,000 fit for
military service; average number reaching military age (20)
annually about 30,000
Military budget: proposed for fiscal year ending 31
March 1979, $281.8 million; about 3.6% of central govern-
ment budget','287be9db0ab421e7d1be91f220f7d005dfa35e00a24e2a64bfbe6d555d487bf9','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08a88026d1d4e6b9948a0eaa676a8f9d0e80d64024c6ed678ac28c164a09e3c9',1979,'NI','Nicaragua','transportation',406,'Caribbean Sea
Managua
Pacific Ocean
(See reference map tl)
LAND
147,900 km*; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 200
nm: continental shelf, including sovereignty over superjacent
waters)
Coastline: 910 km','89e01d8117799a83d4e3726eebcc70b8d5f4ac19c50570e96dbefb5ca70ef0bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc7f618b46e79d4ee9ca5712362d01391fbf6470fbfdd358ce0451a96038e4ff',1979,'TH','Thailand','people-and-society',3,'Population: 44,236,000 (July 1979), average annual
growth rate 2.5% (current) 2
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 85% Turkish, 12% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish) - . ,
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 17.2 million; 57% agriculture, 18% industry,
25% service; substantial shortage of skilled Jabor; ample
unskilled labor (1978)
Organized labor: 25% of labor force
“SECRET
“SEGREL_
''TURKEY','ce3b376e10fc5e3a157f57875953b44003b707f40a7aaade114ae7e9325da507','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69cf91ec4f7f9dbd0c0abf8a273fbeffa98c7f8e7236df122fd4fe977f1e0455',1979,'','','people-and-society',2,'Population: 43,767,000 (January 1979), average annual
growth’ rate 2.6% (current)
Nationality: noun—Turk(s); adiective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled Jabor (1978)
Organized labor: 12% of labor force','22268bb44b86a205c3b4ea61403dc1dc6cd510e8f55b8a6eaab3eacf86bd965b','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65f0222265c172f47a54bba2c547bd34660e5bd26cab3f6adc2697426d7fd48b',1979,'UY','Uruguay','people-and-society',4,'Population: 43,767,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and_ Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled labor_(1978)
Organized labor: 12% of labor force','b3be774a70e97b42b56eab0897304b7fe2e4ba82dbcc0a8e815e1168ee37187e','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75b904b1e250a339d4b95328fc35451d8dce99dd5b16fd1c4d2b13688a5c6e56',1979,'TV','Tuvalu','people-and-society',9,'Population: 6,000 (preliminary total from census of 8
December 1973)
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','71c6fec5a487b746bbff47adacd4268d5e738eb3f75fcdfd86e912a45c23f6dc','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf3c46dcd229354f8cebd4d64484ce9c5b58c20de38563048d1b109b40aa73c',1979,'AF','Afghanistan','people-and-society',4,'Population: 14,702,000 (July 1979),
growth rate 2.2% (current)
average annual
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: under 10%
Labor force: about 5.88 million (FY78 est.); 75%-80%
agriculture and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','3228bbdb359406b7c8449b5799ea6fdc576f0dbb921f30eeec2f888670576de6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a658321f669a7fba85e2f69c7dea000222fd432b189ee795fe55595edf92f1b9',1979,'AL','Albania','people-and-society',9,'Population: 2,626,000 (July 1979), average annual growth
rate 2.2% (current)
Nationality: noun—Albanian(s); adjective—Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world’s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural','ae2d666770be45bd6117f799b4987fd52ea23ef513cc3be973bf1543f698d63a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02b5c773103d9d204260a21fce451dbe1b956e6b8af44d69d08048fea358dba0',1979,'DZ','Algeria','people-and-society',13,'Population: 18,249,000 (July 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Algerian(s); adjective—Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front
Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,866,000 (July 1979), average annual
‘growth rate 0.7% (current)
Nationality: noun—Portuguese (sing. & pl.); adjective—
Portuguese
197
25X11
25X11
25X1
25X11
25X1
25X1
25X11
25X1
25X11
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
Population: 6,412,000 (July 1979), average annual growth
rate 2.7% (current)
Nationality: noun—Tunisian(s); adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
243
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
25X11
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979','5418ee4415908474e967990dd4b508e71f939b8785c0d3464dc9794f9cc68a73','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b23f6ec71d7da2262cee06ee58e6c3d7eefe3d0e6058d2bdde71dbb330619b21',1979,'AD','Andorra','people-and-society',17,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun—Andorran(s); adjective—Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers','f7084cd572659294510a16ea22b2d2048e5e091e984b273f87334ad62f851d4f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da150831978309b0d70d775735aa8bc8eac61a4471d664b124e76b84d1c648ab',1979,'AO','Angola','people-and-society',21,'Population: Angola (including Cabinda), 6,606,000 (July
1979), does not take into account emigration from Angola,
average annual growth rate 2.4% (current); Cabinda,
106,000 (July 1979), average annual growth rate 3.3% (12-60
to 12-70)
Cabinda¥ ’
Luanda
ZAMBIA ue
>>
Atlantic 2 Ne :
Ocean
; UG
©
(See reference mep V1)
Nationality: noun—Angolan(s); adjective—Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10-15%
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 74,000 (July 1979), average annual growth
rate 1.3% (7-70 to 7-77)
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
25X11
25X11
25X1
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
July 1979
ANTIGUA/ARGENTINA
Nationality: noun—Antiguan(s); adjective—Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant),
Protestant sects, and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment','7b29fb8d1e17382863160aa3165c7f667d27fbfe3f5fa89b4a51eebe7b08fac8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('235ab73d116b9316dbd03fb920403bd0795cacada22d34d34bf179637d209322',1979,'AR','Argentina','people-and-society',25,'Population: 26,829,000 July 1979), average annual
growth rate 1.3% (current)
Nationality: noun—Argentine(s); adjective—Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
SECRET
Le
mm eA i
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Pane a eee Cae ere aan CE Na Oe ORR apy, Nie OE
-
a ee ary
AD ha
ee a ee ee a
a Se ee ee ae ea ee, ee
ee
ee ae Ee ee a OE ae ee ee:
'' Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
BOLIVIA
Buenos Aires
Atlantic Ocean
> FALKLAND ISLANDS 7
(See reference map tii}
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 2.2% estimated unemployment
(1977)
Organized labor: 25% of labor force (est.)
Population: 14,400,000 (July 1979), average annual
growth rate 1.1% (current)
10 SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP0O8-00534R000100020001-0
ibs Se ane de eae en: ads AE ee
ra ee
=.
ee, i ee a a i a i i ee
July 1979
SECRET','84c76adda78cdbeea2eea032c762a784300715ecffbde2f9569b3cd28f3e9ecf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48134a45ed1143de33fc6910e4f24eced5d8e57244c969990445abbe13dae08d',1979,'BR','Brazil','people-and-society',26,'Pacitic
Ocean
Population: 124,428,000 (July 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Brazilian(s); adjective—Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
15.38% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 199,000 (July 1979), average annual growth
rate 2.4% (current)
30
Nationality: noun—Bruneian(s); adjective—Bruneian
52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Ethnic divisions:
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force
Population: 7,781,000, excluding nomadic Indian tribes,
(July 1979), average annual growth rate .3.0% (current)
Nationality: noun—Ecuadorean(s); adjective—Ecuador-
ean
Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other services and activities
Organized labor: less than 15% of labor force
Population: 824,000 (July 1979), average annual growth
rate 1.3% (current)
Nationality: noun—Guyanese (sing., pl.); adjective—
Guyanese
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other :
Language: English
Literacy: 86%
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force
Population: 398,000 (July 1979), average annual growth
rate 2.8% (1-59 to 1-77) :
Nationality: noun—Surinamer(s); adjective—Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown ;
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
and is lingua franca among others; Hindi; Javanese
Literacy: 80% :
Labor force: 118,000
Organized labor: approx. 33% of labor force
Population: 535,000 (July 1979), average annual growth
rate 2.7% (5-66 to 8-76)
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
- Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
eatin
SS ee eS
png a Nag gt ey ara ga Ng ne Sa Sr NG nea Samer mgr grr ow
J
|
ne Na ag a se gl? ag A RT et oe
4 f - i '' ‘ ee
— é —
July 1979
SECRET
SWAZILAND/SWEDEN
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 35% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor: about 15% of wage earners are
unionized','dbca288a7f63df21e9a67ad5560a948093495a1a4f1d8739c77f8d2531b2f4ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07d13cd1c6fb764d24c6bd10e32c333adc280cdbb6a47501cf33be6cd1cf4259',1979,'AU','Australia','people-and-society',29,'Nationality: noun—Australian(s); adjective—Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5% ;
Labor force: 6.3 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6% unemployment
Organized labor: 44% of labor force
(See reference map Vill)
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation
(See reference map Vill}
Nationality: noun—Nauruan(s); adjective—Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (two-thirds Protestant, one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal
Population: 141,000 (July 1979), average annual growth
rate 1.6% (current)
Nationality: noun—New Caledonian(s); adjective—New
Caledonian
Ethnic divisions: Melanesian 42%; French 40%; remain-
der Vietnamese, Indonesian, Chinese, Polynesian
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II] period; immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 104,000 (July 1979), average annual growth
rate 2.2% (7-74 to 7-77)
Nationality: noun—New Hebridean(s); adjective—New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%
Population: 9,000 (official estimate for 1 July 1977)
Nationality: noun—Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective—Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','1a0d991b026a2fcdd91ceceb4ecc94e56a42edc31f403c561a5c0a7e89f5852a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94c17a9b9f39ef040503e4462583d915e4f501e67c354d4010c972e70d98a9cc',1979,'AT','Austria','people-and-society',35,'Population: 7,498,000 (July 1979), average annual growth
rate —0.1% (1-77 to 7-78)
12
July 1979
AUSTRALIA/AUSTRIA
,
FEDERAL S&. ow
REPUBLIC
OF GERMANY CZECHOSLOVAKIA
Vienna ,
YUGOSLAVIA
(See reference map IV)
Nationality: noun—Austrian(s); adjective—Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,757,700 (1978); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.1%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number 176,710
Organized labor: about two-thirds of wage and salary
workers (1971)
Population: 233,000 (July 1979), average annual growth
rate 2.8% (7-76 to 7-77)
Nationality: noun—Bahamian (sing., pl.); adjective—
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Language: English
Labor force: 84,228 (1976), 25% organized; 25% unem-
ployment (1977)
Population: 25,000 (July 1979), average annual growth
rate 1.6% (7-75 to 7-77)
Nationality:','16d45c42c43f50d1564ccc0ff6af67f17581cb2f4ff737c8123cbabcb51dadaf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e9cdd755f00a50580a490ff26192d237ad600d88b2ae959f1dd864f7cbc2bca',1979,'BH','Bahrain','people-and-society',39,'Population: 365,000 (July 1979), average annual erowih
rate 4.5% (current)
Nationality: noun—Bahraini(s); adjective—Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% others
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40%
Labor force: 100,000 (1978)
SECRET','50633576f2479b0624de1e7f5d2d1cdf08b9404e9539d844fca4d86e72eaca20','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32264720cc2fcddc42aa8913564feb11f6aa5c6b636caafcf1268577c505d0cb',1979,'BD','Bangladesh','people-and-society',43,'Population: 88,092,000 (July 1979), average annual
growth rate 2.7% (current)
noun—Bangladeshi(s);
Nationality: adjective—Bangla-
desh
16
Bay of Bengal
(See reference map Vil)
Ethnic divisions: predominantly Bengali; fewer than 1
million “Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 20 million; extensive export of labor to
U.A.E., Qatar, Kuwait, Iraq, and Oman; over 75% of labor
force is in agriculture','53326d32e1612c9446b134fb99e6eba92050c2650fe0df24201e58c1b981a37e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e68c752b50ace3d0132223ad927ac937bd239d69b6b763d23cc516429db2904a',1979,'BB','Barbados','people-and-society',47,'Population: 273,000 (July 1979), average annual growth
rate 1.2% (1-68 to 1-78)
Nationality: noun—Barbadian(s); adjective—Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners,
unemployment 20-25% (1976)
Organized labor: 32%','9a8feb628bb945bb43a7c271ed2e642ea41ea958e319361c037b977a634f20ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f1480cd79e0280ff07aa5db5710ce9aa56a87767ddba2b2a36868153866b4ee',1979,'BE','Belgium','people-and-society',51,'Population: 9,874,000 (July 1979), average annual growth
rate 0.2% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
Literacy: 97%
Labor force: 4.09 million (July 1978); in June 1976, 46.7%
in services, 28.0% in mining and manufacturing, 7.4% in
construction, 6.6% in transportation, 3.2% in agriculture,
1.0% commuting foreign workers, 0.4% in ‘public works,
6.7% unemployed; 7% unemployed 1978 annual average
Organized labor: 48% of labor force (1969)','48de0e0746fb434abefecb75151e02d2d0c1ec6b2aa6ccc733e5bb30116dae2b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('492d48d947d3933518a64e5de033588cb6dbc9601e1acbb22b3eff6779642f6f',1979,'BZ','Belize','people-and-society',55,'Population: 156,000 (July 1979), average annual growth
rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Red BSA ie RS ae SA a Oy th SERS GR ca ER ee ee i a pe oe Se
25X11
a
]
- Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
''
}
|
t
July 1979
SECRET
Gulf of
Mexico Caribbean
Sea
Pacific
Ocean
(See reference map tl}
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force','5924acf713ff12df25894e57c6d7be5b547271da68697178450914aadc786d36','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('693187b80468c989663ca7adaca7b3ac9cb0024f9cff040290d3d895b2caa21d',1979,'BJ','Benin','people-and-society',59,'Population: 3,379,000 (July 1979), average annual growth
rate 2.7% (current)
Nationality: noun—Beninese (sing. & pl.); adjective—
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
22
Language: French official; Fon and Yoruba most
common vernaculars in ‘south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions
Population: 61,000 (July 1979), average annual growth
rate 1.3% (7-70 to 7-77)
Nationality: noun—Bermudian(s); adjective—Bermudian
Ethnic divisions: approximately 59% black, 41% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)','034fbad306ee05f4058ad0d6ad5fe7de2f5aa3a3272b91f65f8d42f9aee50248','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22d4f465507ce1b9c7112d3c96cf26a5ad121f547e3a6b8d61faccc674540051',1979,'BT','Bhutan','people-and-society',63,'Population: 1,297,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Bhutanese (sing., pl.); adjective—
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
Religion: 75% lLamaistic Buddhism, 25%
influenced Hinduism
Buddhist-
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,216,000 (July 1979), average annual growth
rate 2.6% (current)
Nationality: noun—Bolivian(s); adjective—Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation','3ac05815f8daa3cab2689646c9ee535f42fd8ad347353ede05e65d1a59c7084e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e141b7678166409d8af63ebbf2e93e510efc6627c519e8bd5b71aaee3229de11',1979,'BW','Botswana','people-and-society',68,'Population: 770,000 (July 1979), average annual growth
rate 2.7% (current)
Nationality: noun—Botswana (sing.),
adjective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school graduates
SECRET
Batswana (pl.);
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized Jabor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)','78853d0e2575bc178f3f582daa8aa67fb7f2461b2637aa3595a153b0ee7b1881','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b6fc5edb8301cae6479974c9a8736cb570d338d943b02aebbf83acfc7a97a7',1979,'BG','Bulgaria','people-and-society',75,'Population: 8,892,000 (July 1979), average annual growth
rate 0.5% (current)
Nationality: noun—Bulgarian(s); adjective—Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 33,517,000 (July 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burman(s); adjective—Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages
Literacy: 70% (official claim)
Labor force: 12.2 million (1976); 67% agriculture, 9%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor organiza-
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
tions have been disbanded, and government is forming one 25X1
central labor organization
Population: 22,057,000 (July 1979), average annual
growth rate 0.8% (current) ;
Nationality: noun—Romanian(s); adjective—Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, ] million Protestants, 60,000 Jews, 30,000
Muslims
'''' Increase in French presence results from relocation of Indian
Ocean Naval Command Headquarters from Madagascar.
202
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 12.0 million (1977); 40% agriculture, 25%
industry, 35% other nonagricultural','8110ab8edad963f89e9f03c32b4fcc172825f41e144322c81a160b943dc20175','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b36d5ffca01693937a1316c0dcc1278035fdd12726db8f0d1c6b1af4f7b2489c',1979,'BI','Burundi','people-and-society',79,'Population: 4,314,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Burundian(s); adjective—Burundi
Ethnic divisions: Africans—85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
10,000 Zairians (approximately 40,000 were recently repatri-
ated), and 40,000 Rwandans; non-Africans include about
3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2% Muslims
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
SECRET
4
if
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
}
. Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
GSO NT OLE act EL eT NN OO ME PT GORE Se SR re ie, Ne bal Seal alla
reihts wo
ne
i we eT a a OR
July 1979
SECRET
BURUNDI/CAMEROON
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
Organized labor: sole group is the Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting “active
membership” have been unobtainable','378d9aa58614467b2222f23b67361128caeb59f0a6053add778808e22ef406fd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('857c62971011be470e4e3acee9c02f8ad6d48f75939c666aa2164ba6cb3c2505',1979,'CM','Cameroon','people-and-society',83,'Population: 8,168,000 (July 1979), average annual growth
rate 2.0% (current) :
Nationality: noun—Cameroonian(s); adjective—Camer-
oonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 13% other African, less than 1%
non-African
Religion: about one-half animist, one-third Christian; one-
sixth Muslim
Language: English and French official, 24 major African
language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force
Population: 341,000 (July 1979), this estimate does not
take into account emigration from Equatorial Guinea during
the last several years, which could have amounted to one-
third of the total population; average annual growth rate
1.8% (7-68 to 7-69); Rio Muni, 239,000, average annual
growth rate 1.5% (7-68 to 7-69); Fernando Po, 103,000,
average annual growth rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjective—
Equatorial Guinean ,
Ethnic divisions: indigenous population of Province
Macias Nguema Biyogo, primarily Bubi, some Fernandinos;
of Rio Muni primarily Fang; less than 1,000 Europeans,
primarily Spanish
Religion: natives al] nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 20%
Labor force: most Equatorial Guineans involved in
subsistence agriculture
Atlantic
Ocean
{See reference map Vi}
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 20,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: government claims more than 80% of school age
children in school, but literacy rate is substantially below this
figure
Labor force: about 280,000 of whom 129,000 are wage
earners in the modern sector
Organized labor: no data available
Population: 584,000 (July 1979), average annual growth
rate 2.7% (current)
Nationality: noun—Gambian(s); adjective—Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
SECRET
THE Banjul mn,
{See reference map Vi}
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsist-
ence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,793,000, including East Berlin (July 1979),
average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 53% ‘Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate 25X1
Language: German, small Sorb (West Slavic) minority —
Literacy: 99% ;
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction; 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16.8% services; 2.5%
other
Organized labor: 87.7% of total labor force ;
Population: 61,181,000, including West Berlin (July
1979), average annual growth rate —0.2% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99% Germanic,-1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners','db33cccbe33274266bed90bfa45be6f907fee2281f5837e6b8c1b827f6fa1367','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('303df6142664a6bd6b5aaa51dfecdf9861babfb58ae67354045e3cf719ef3fb3',1979,'CA','Canada','people-and-society',86,'Population: 23,755,000 (July 1979), average annual
growth rate 1.1% (current)
Nationality: noun—Canadian(s); adjective—Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 10.789 million (January 1978 rev.); 29%
service, 22% manufacturing, 16% trade, 8% transportation
and utilities, 6% agriculture, 6% construction, 8% other; 8.4%
unemployment (1978 average); 7.9% unemployment (March
1979) ,
Organized labor: 30% of labor force
Population: 328,000 (July 1979), average annual growth
rate 2.1% (current)
Nationality: noun—Capeverdean(s); adjective—Capever-
dian
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words
Literacy: 14%
Labor force: bulk of population engaged in subsistence
agriculture
Population: 2,418,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and_ linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
_ largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 24% animist, 8%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
Central African(s); adjective—Cen-
Language: French official; Sangho, lingua franca and
national language
40
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Literacy: estimated at 5%-10%
Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force
Population: 4,523,000 (July 1979), average annual growth
rate 2.3% (current)
Nationality: noun—Chadian(s); adjective—Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups—Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force','70236f40a71d28fb0d7943a0ed52873499e61dd62f535ad1a01c5f6c3df2b383','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a25eded3eb161908e89e26963ceaaaf0aec6959edd53dd6e1c03c486a22e4de3',1979,'CL','Chile','people-and-society',90,'Population: 10,850,000
growth rate 1.5% (current)
(July 1979),
average annual
Nationality: noun—Chilean(s); adjective—Chilean
SECRET
ay a ee OY OO SR Oe
Se ee
25x14
a!
25x11 ,
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0 i
{r
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
SECRET
: BOLIVIA
2 eo te {See refere: ce map Til) ‘
Ethnic divisions: 95% European stock and mixed
European with some Indian admixture, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1977)
Labor force: 3.7 million economically active (1977); 30%
agricultural, 29% industry and construction, 7% services,
10% commerce, 7% mining, 9% transportation, 8% other
(1977)
Organized labor: 25% of labor force (1973)
Population: 1,017,477,000 (July 1979), average annual
growth rate 1.5% (current)
SECRET
25X1
25X11
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
)
|
j
A
;
b
July 1979
SECRET','9550160f250561a9375a12c4a7d283880d554bd1e9ab93c80c9e0cca4c3dd87f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63835d8ab681960864dc75284d7e6899e751a78691ed660218fd80e214cebe13',1979,'CN','China','people-and-society',93,'Nationality: noun—Chinese (sing., pl.); adjective—
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 26,115,000 (July 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Colombian(s); adjective—Colombian
Ethnic divisions: 58% mestizo, 20% caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
SECRET
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-18% unemployment (1975)
Organized labor: 13% of labor force (1968)
Population: 39,544,000 (July 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Korean(s); adjective—Korean
_ Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000) ‘
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority (16.6%
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 13.9 million (1978); 42% agriculture,
fishing, forestry; 22% mining and manufacturing; 36%
services and other; average unemployment 3.2% (1978)
Organized labor: about 13% of nonagricultural labor
force','6b3778ddf4c5f95ef655a406ad242854c7b6d46d090d855fa37b8bdc10958857','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62850579f87dc4f905d31d79158b8c6ef4d361010a3946203360fc1dbb072868',1979,'MG','Madagascar','people-and-society',98,'Population: 323,000 (July 1979), average annual growth
rate 2.1% (current)
Nationality: noun—Comoran(s); adjective—Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
‘Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural
Legal mame: Federal and Islamic Republic of -the
Comoros , ;
Type: three of the four islands comprise an independent
republic, following local government’s unilateral declaration
of independence from France in July 1975; other island,
ge re a ee a gegen gi ee
Territorial community
- Capital: Moroni
Political subdivisions: the three islands are organized into
7 regions .
Legal system: French and Muslim law
Branches: Mohamed Abdallah elected President of the
Comoros, October 21, 1978, having regained power last May
following a coup, led by French-born mercenary Bob
Denard, which toppled Ali Soilih; Soilih had come to power
in 1977 through a coup that ousted Abdallah; Soilih was
killed in the recent coup
Suffrage: universal adult
Elections: next presidential election scheduled ‘to take
place in 1984
Communists: information not available
Member of: G-77, NAM, OAU, U.N.
Population: 8,358,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Malagasy (sing. and pl.); adjective—
Malagasy
SECRET
Antananarivo
*
MADAGASCAR ©
Q)
Population: 65,000 (July 1979), average annual growth
rate 2.1% (current)
Nationality: noun—Seychellois (sing. & pl.); adjective—','c7223a85ca978cc6e426044f39b140b7f27427fa64959c7e29e50a1f7136706a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c9c1345cd4c4f603c44cc50e9e1d4701db3d51d5c448c9ecc27fee9b77fd2af',1979,'CG','Congo','people-and-society',101,'Population: 1,504,000 (July 1979), average annual growth
rate 2.7% (current)
Nationality: noun—Congolese (sing., pl.); adiective—
Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north; about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim ,
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20% :
Labor force: about 40% of population ecoridémically
active, most engaged in subsistence agriculture; ‘79,100 wage
earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','19aafde62044b8f5d3ba9af2b7869b0d4bc14eeb78f554b86d31c278ceecd69c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b78762329d6ac30cff75e118ae5d772cd446e12c4288118a77d072ea0a279ef9',1979,'CK','Cook Islands','people-and-society',105,'Population: 18,000 (official estimate for 30 June 1977)
Nationality: noun—Cook Islander(s); adjective—Cook
Islander
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','c9373f66aba39dd14d578a3a89ff7f616bd70dd50704a71d9b74680aecd8b1a7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21086df4b2be36e600f1833a826189d683f94ddf93f2a264f1d652761deca496',1979,'CR','Costa Rica','people-and-society',109,'Population: 2,168,000 (July 1979), average annual growth
rate 2.8% (current) :
Nationality: noun—Costa Rican(s); adjective—Costa
Rican
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 793,000 (1978 est.); 32.6% agriculture; 13.8%
manufacturing; 15.8% commerce; 6.1% construction; 5.2%
transportation, utilities; 20.8% service (government, educa-
tion, social); 0.5% other; 4.4% unemployment (1978 est.)
Organized labor: about 11.5% of labor force','73584221324630bff0fae0b22bf142855b73384970f733e88df52126dd6116eb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b557a4a5d315c2a75f7fe7e34b9fa85a4008497eaab152f17b7ef22bea666b0',1979,'CU','Cuba','people-and-society',113,'Population: 9,824,000 (July 1979), average annual growth
rate 1.2% (current)
Nationality: noun—Cuban(s); adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.7 million in 1976; 33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed','99127063e84450a25872379a6c168a9a4d0d4a9f83c4f4d52f5cdce2a5c6097c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3912ffdfa258186800d838eea842dec7eedff3a563211855ba30ba7666dfafc',1979,'CY','Cyprus','people-and-society',117,'Population: 614,000 (July 1979), average annual growth
rate 0.1% (8-76 to 8-77)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
SECRET
Religion: 78% Greek Orthodox, 18% Muslim, 4% Maron-
ite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 89% of population 15 years or older, 99%
of population aged 15-39
Greek Sector labor force: 202,700 (1977), 27.5% services;
25.8% industry; 23.0% agriculture, forestry, fishing; 5%
public administration; 15.2% employed overseas or in
military; 83% unemployed
Turkish Sector labor force: 179,400 (145,900 employed,
33,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)','4b3b87882fbec6fc91063ab4161277c06516ec188a65035835a8b9489349b3c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e83adad15edbc00712295f564bc88e0324e749c123d03a5c97b6c3afb8104c85',1979,'RO','Romania','people-and-society',121,'Population: 15,240,000 (July 1979), average annual
growth rate 0.7% (current)
Nationality: noun—Czechoslovak(s); adjective—Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others','18d6e6f6ce4accf840d1d831b6ed361a21c17191b7d0d4342ad238929c010673','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('262e24ec4888f8ca734ae386f4d1de60a849be58a80ad5ce5c844024c128f9ad',1979,'DK','Denmark','people-and-society',125,'Population: 5,118,000 (July 1979), average annual growth
rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority 25X1
Supply: produces substantial quantities of infantry weap- Literacy: 99% _ ;
ons, rocket launchers, ammunition, trucks, tactical signal Labor force: 2,625,223 (January 1979); 8.6% agriculture,
equipment, APC’s, self-propelled AA guns, and_ tanks; forestry, fishing, 24.6% manufacturing, 8.1% construction,
produces copies of Soviet antitank missiles, and jet trainer 15.4% commerce, 6.6% transportation, 5.4% services, 29.3% |
and small transport aircraft government, 2.0% other; 7.7% (190,600) registered unem- 25X1
ployed as a percentage of total labor force (1978 annual 25X11
dependent on the U.S.S.R. for more average) 25X1
complex equipment and combat aircraft; amphibious Organized labor: 65% of labor force
armored reconnaissance cars obtained from Hungary COVERNMENT 25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
Communists: 7,500-8,000; a number of sympathizers, as
indicated by 114,034 Communist votes cast in 1977 elections
Member of: ADB, Council of Europe, DAC, EC, EEC,
ELDO (observer), EMA, ESRD, EURATOM, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA, IFC,
THO, ILO, International Lead and Zine Study Group,
IMCO, IMF, IPU, ISO, ITC, ITU, IWC—International
Wheat Council, NATO, Nordic Council, OECD, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG','6372522bdd4b965c7de9b579b7e07eb4281e13ca6f8152f793b374b814416c5f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('893684f8cc410c2da243d65c7c190ab463f41293262509b4fb3650f4832699af',1979,'ET','Ethiopia','people-and-society',128,'Population: 314,000 (July 1979), average annual growth
rate 2.3% (current)
Nationality: noun—Afar(s), Issa(s); adjective—Afar, Issa
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
Organized labor: some 3,000 railway workers organized
Population: 31,743,000 (July 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Ethiopian(s); adjective—Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized labor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','dee1ae345d7a6fa5ae06f02d8e461171900887feb665149763a5a3d1171f5b66','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0908a59abe51fc0c0db0a0caac4db90fcfa57ddb61b22ab1f2143ef1fe856f73',1979,'DM','Dominica','people-and-society',132,'Population: 78,000 (July 1979), average annual growth
rate 0.7% (1-75 to 1-77)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture; 24%
unemployment
Organized labor: 25% of the labor force','85b4c1ce734a3c6ca5a113ee9a85af18cc2f2418343f1bd5d9c3676e710d5cbb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da89837e1daacb6f53aa4b5faa4fa00d5b102d5e152d89273b04b2a6b2802dfb',1979,'DO','Dominican Republic','people-and-society',136,'Population: 5,539,000 (July 1979), average annual growth
rate 2.7% (current)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force','7fdc80594deb841265ef7ac6e27a4de85fa74e9de28353ba53f436c36ecab31f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c112050afaa71f9924cc765f3d8828a0c60e8b38798ea2c344831688fa415936',1979,'EC','Ecuador','people-and-society',142,'Population: 40,958,000 (July 1979),
growth rate 2.7% (current)
average annual
Nationality: noun—Egyptian(s); adjective—Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
66
Labor force: 13 million; 45 to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and other;
shortage of skilled labor
Organized labor: 1 to 3 million','cc61b66a47fdea3f058fafcee3e0e9b700709caf91be7866006c8a883221e9ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f794adf12ce91389b4c3121eb906ef80eb42f4f466e9de8f49f4ea9aec852063',1979,'SV','El Salvador','people-and-society',144,'Population: 4,646,000 (July 1979), average annual growth
rate 2.9% (current)
Nationality: noun—Salvadoran(s); adjective—Salvadoran
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','c9afda89f558fbdf245374aa8553ad60a2ec177a6af99aac886d3302445f96a6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0037fb4fd61540754f3eca5ceafac456d27d2e52f048b7e2cae3469ca73d980',1979,'FO','Faroe Islands','people-and-society',151,'Population: 43,000 (July 1979), average annual growth
rate 1.4% (1-75 to 1-77)
Nationality: mnoun—Faroese (sing., pl.); adjective—
Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
SECRET:
° Norwegian
» Sea
FAROE =
ISLANDS
Atlantic
Ocean
{See reference map tv)
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce :','9c9077136eb58a5c920b4a7bb1112582417513233dffaf12ff56cc2bdd6f642b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a7f277535d4db82d24e96c84cccf0eb9704205a7be23f08c4c5b4d9a00dae38',1979,'FJ','Fiji','people-and-society',155,'Population: 621,000 (July 1979), average annual growth
rate 1.6% (current) ;
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 44% Fijian, 50% Indian; 6% European,
Chinese and others
74
Coral Sea ~','4f1c3bc49cbce4653a328652c69d4c02832f9b3707659e3461eafe5698d3beb6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50ae77b5132e7a6838e4b9e663f83fc908c2412c51d675da3fb17c5a119d3c8e',1979,'FR','France','people-and-society',160,'Population: 53,451,000 (July 1979), average annual
growth rate 0.3% (current)
SECRET
(See reference mep IV)
Nationality: noun—Frenchman (men); adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois—Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22.4 million (est. in mid-1978); 47% services,
38% industry, 10% agriculture, 6% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force','0b73d48264eb4d5fb1e2a52ba96308985061dfae8f9c326369fcdb3ae8421e11','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4e3b1ce64f250261778539837f3aa9af0382189f6cdb479c914c783eaa9803',1979,'GF','French Guiana','people-and-society',164,'Population: 61,000 (July 1979), annual growth rate 2.2%
(10-74 to 11-77)
Nationality: noun—French Guianese (sing., pl.); adjec-
tive—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
‘Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force','f1d2323fea88ae7296f8adb580eb6b39932c4250cdbfc8c3e9b1826ab2850fa4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('137352b78f15fb5d915103115ae5a97e66d6fbf90cee68991d55d901e7274927',1979,'PF','French Polynesia','people-and-society',168,'Population: 144,000 (July 1979), annual growth rate 2.3%
(current)
Nationality: noun—French Polynesian(s); adiective—
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic','17c1984967d9c897184202d52afcdefc21d674805e2811531058e7c0a60ceb26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3136a84971b32a12c65afcfb0abeae2f9f4521a9df7e10113136c7d8020313d0',1979,'GA','Gabon','people-and-society',172,'Population: 580,000 (July 1979), this estimate does not
take into account immigration to Gabon during last several
years; average annual growth rate 1.7% (7-66 to 7-70)
Nationality: noun—Gabonese (sing., pl.); adjective—
Gabonese
81
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
-Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
é i
YW ™~
Population: 82,000 (July 1979), average annual growth
rate 1.2% (current)
Nationality:
Tomean
noun—Sao Tomean(s): adjective—Sao
Ethnic divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant,
Seventh Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','237c56c4cd29a38c400c75e2a166862be7d9cd5cd121ce69498e5445d5b7564d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e9845129c2bae034b63b6b5a69cf7ad5bd7f1ae6600ab3d31bee5ac88c9d3c7',1979,'GN','Guinea','people-and-society',175,'Population: 11,741,000 (July 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Ghanaian(s); adjective—Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Military budget: for fiscal year ending 31 December Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
1979, $18.9 million; about 18% of the proposed central 8%
government budget
25X1
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 25X1
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation, and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force','bcc2e8ed0effc5977acef0edbc936506aaeef9afa0000bc6f44049fb3496ace2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af0a546195d3c5863c439921d17124c70ce18b6d7e9335fc981a9746225acb86',1979,'MA','Morocco','people-and-society',180,'Population: 30,000 (official estimate for 1 July 1977)
Nationality: noun—Gibraltarian; adjective—Gibraltar
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
Religion: predominantly Roman Catholic
16 km
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000
Population: 52,000 (preliminary total from census of 8
December 1973) -
Nationality: noun—Gilbertese or Gilbert Islander(s);
adjective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%
Population: 19,751,000 (July 1979), average annual
growth rate 3.0% (current) ;
Nationality: noun—Moroccan(s); adjective—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 20%
Labor force: 5 million (1977 est.); 50% agriculture, 15%
industry, 26% services, 9% other; at least 20% of urban labor
unemployed
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT), but new Democrat- -
ic Confederation of Labor expanding rapidly','8ecb2d7d21c0ab60519f59336a52ad660e4867bf0b57284e4fa06cb91c8314d2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('348138cb0f39da20e4ec7b33a5ce40952285b7870cc83fbe582d41104e863741',1979,'GR','Greece','people-and-society',184,'Population: 9,390,000 (July 1979), average annual growth
rate 0.7% (7-68 to 7-77)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 98.8% Greek, 0.2% Turkish, 1.0% other
Religion: 99% Greek Orthodox, 0.3% Moslem, 0.7% other
Language: Greek; English and French widely understood
Literacy: males about 94%; females about 79%; total
about 86%
Labor force: 3.4 million (1978 est.); approximately 38%
agriculture, 19% industry, 8% construction, 30% services, 1%
other; unemployment 4%; urban unemployment is under
8%, but substantial unreported unemployment exists in
agriculture
Organized labor: 10-15% of total labor force, 20-25% of
urban labor force
Population: 49,000 (July 1979), average annual growth
rate 0.2% (1-73 to 1-78)
Nationality:
land
noun—Greenlander(s); adjective—Green-
93
25X11
25x1
25X11
25X1
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
GREENLAND/GRENADA
Ethnic divisions: 86% Greenlander (Eskimos and Green-
land-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','2773362c84000c48bb1b7737b1e224f42632720c794210dd7a7e16e9314d0f30','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3303f59b72853da10505d791bc3e787836fca9d1ebd9f58c6bfecf31d2dd2b96',1979,'GD','Grenada','people-and-society',188,'Population: 107,000 (July 1979), average annual growth
rate 1.4% (4-70 to 7-77)
Nationality: noun—Grenadian(s); adjective—Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','76838ec7f0f4393752095c195a9db10e27464c7781a9eeac6a311011c53514c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c5782d2d5ca969d6529ecb4a0c06af7b835a194b7b12febea480506fe9807d9',1979,'GP','Guadeloupe','people-and-society',192,'Population: 318,000 (July 1979), average annual growth
rate 0.1% (10-67 to 1-78)
Nationality: noun—Guadeloupian(s); adjective—Guade-
loupe ;
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','2885ddaf8fcbe252a763236249f9407cef6034dd24161bc502b14db9a6b8560a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1be1f0b0ef15b2eb9fd99155fc91ad8fa52a5004ac9d19c19ee39cbc2fa1af9',1979,'MX','Mexico','people-and-society',196,'Population: 6,817,000 (July 1979), average annual growth
rate 2.9% (current)
Nationality: noun—Guatemalan(s); adjective—Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 30%
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)
Population: 66,114,000 (July 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Mexican(s); adjective—Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0 |
a
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDPO8-00534R000100020001-0
a Oa SC On Oe Va Se
25X1
Ce ed
25X1
25X11
a ate Mee
aie ah ho oe 2
tt kt
July 1979
SECRET
Gulf
of Mexico
Pacific Ocean
(See reference map fi)
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 18.0 million (1978) (defined as those 12 years
of age and older); 33.0% agriculture, 16.0% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and :
transport, 3% government, 5.4% unspecified activities, 10%
unemployed, 40% underemployed
Organized labor: 20% of total labor force
Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun—Monacan(s) or Monegasque(s); adjec-
tive—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
“Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete','70e1e10117f834a183e220489eef0967b2a27c7614bf627bc5c7daa6375d7a2a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7590cc78239b487c5fc52759a4e89f9e75726ec05aaf8930664b6afbda3447c0',1979,'DE','Germany','people-and-society',199,'Population: 5,276,000 (July 1979), average annual growth
rate 2.8% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: 99% African (3 major tribes—Fulani,
Malinke, Susu; and 15 smaller tribes)
~ Religion: 75% Muslim, 25% animist, Christian, less than
1% ;
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language -
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force’
loosely affiliated with the National Confederation of
Guinean Workers, which is closely tied to the PDG
Population: 18,717,000 (July 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor
Population: 44,236,000 (July 1979), average annual
growth rate 2.5% (current) f
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 85% Turkish, 12% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish) - . f
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 17.2 million; 57% agriculture, 18% industry,
25% service; substantial shortage of skilled labor; ample
unskilled labor (1978)
Organized labor: 25% of labor force
(See reference map V}
SECRET','0375d2bf74ee7053f5004daeec1e82396c1e54482b916a6120baef5506ade2cd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('633f157e380124fefa188e6ce33a8a4e5485ec10ae5059fa3fa9d289b65af0a9',1979,'GW','Guinea-Bissau','people-and-society',201,'Population: 634,000 (July 1979), average annual growth
rate 1.9% (current) ;
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Labor force: 90% of economically active population
engaged in subsistence agriculture','5cc54b770ea30e5d3f5dd0886dbe9d060f29e80c9f50979db81c26c74870893e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27702b74f80d14115a978db71da6b65c2b03758c5e7420c1be0ddd9b6da8f325',1979,'JM','Jamaica','people-and-society',206,'Population: 5,666,000 (July. 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
_ few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant
Organized labor: less than 1% of labor force
- Population: 2,233,000 (July 1979), average annual growth
rate 1.4% (current)
Nationality: noun—Jamaican(s); adjective—Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist ‘cults
. Language: English
_ Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 672,000 (1975); 29% in agriculture, forestry,
fishing and mining, 12% manufacturing/mining, 8% public
administration, 5% construction, 10% commerce, 3% trans-
portation and utilities, 33% services; 25% unemployed;
shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 116,051,000, including Ryukyus (July 1979),
average annual growth rate 1.0% (current)
Nationality: noun—Japanese (sing., pl.); adjective—
Japanese
SECRET
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data)
Labor force (1978): 55.3 million; 11% agriculture,
forestry, and fishing; 34% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33% of labor force','39f043602a9e0b2d3fcf59b54ea05fb17fdde2b7b0c2dfbbe32bbd019783ce0e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c0aaaed1eb39f7c501871f312ad6fd093d65be915dc2c50cea24a7326c55174',1979,'HN','Honduras','people-and-society',210,'Population: 3,639,000 (July 1979), average annual growth
rate 3.4% (current)
Nationality: noun—Honduran(s); adjective—Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 75: to 10% of labor force (mid-1972)','365750f9c62d8aad83008e4dafff1262609357eb021474985963f830d9705afa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dca0de806106cc362b315ecd95a2c3d26f3511118676da508f5b914c1fb8613f',1979,'HK','Hong Kong','people-and-society',214,'Population: 4,693,000 (July 1979), average annual growth
rate 1.9% (7-71 to 7-78)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions ;
Language: Chinese, English
Literacy: 75%
Labor force (1976 Census): 1.87 million; 45.8% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.7% other;
underemployment is a serious problem
Organized labor: 21% of 1976 labor force','8c8c636fded755528534d32e179750dff7655b9c0a67f273dfffedb040d45fd1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30854f4db96d58acf562ffcd9efe5e554dd45aec001207122c5a581151dd2a35',1979,'HU','Hungary','people-and-society',219,'Population: 10,735,000 (July 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Hungarian(s); adjective—Hungarian
Ethnic ‘divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other.
Religion: 67.5% Roman Catholic, 20.0% Calvinist; 5.0%
Lutheran, 7.5% atheist and other ;
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,230,000 (1977); 20% agriculture, 34%
industry and building, 46% other non-agriculture
SECRET
! Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
en reer
i
‘Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
ee a let ee eee a ia eee ad
eR TN ng ON Ne gy ag ae og
a I a oe
July 1979
SECRET','a92a232d35b584bed0dc2dfe9eab9d631e7eb4552ab4e62ca4c455a9b086951e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6465e1e8c641bbd60bbd95c1bf31fc20c8ba4a328ee194670e21e089d1d9ae64',1979,'IS','Iceland','people-and-society',223,'Population: 225,000 (July 1979), average annual growth
rate 0.8% (12-77 to 12-78)
Nationality: noun—Icelander(s); adjective—Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 90,000; 9.0% agriculture; 5.4% fishing; 8.0%
fish processing; 16.8% other manufacturing; 12.2% construc-
tion; 18.6% commerce, finance, and services; 6.3% transpor-
tation and communications; 23.7% other; unemployment
1977, 0.6%
Organized labor: 60% of labor force','06cf0ca1bd261c38437ee789586e3f7378f0ce6c55e18175ba6b9e7d1a784911','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bedd5e827a7fd24b05f7d97d9b5898c0cbfb3b3d3db3516ad8bcbc1de9020bfb',1979,'IN','India','people-and-society',226,'Population: 669,785,000, including Sikkim and_ the
Indian-held part of disputed Jammu-Kashmir (July 1979),
average annual growth rate 2.0% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0:7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
énjoys “associate” status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India ;
Literacy: males 39%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force
: Population: 148,085,000, including East Timor and Irian
Jaya (July 1979), average annual growth rate 2.1% (current)
ees
;
,
>
25x1
} Supply: increasingly self-sufficient including manu-
facture/assembly of own small arms, artillery, ammunition, 25X11
t
‘
>
}
So eer
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
July 1979','552c8e882ddf0e9515fd76fd14c98ab7dead28d7d0e219f66579aa25e91d0bfb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c206098ef3dac3b348d1caac255905c54f086481bde505b4fd37beeffc7148ca',1979,'ID','Indonesia','people-and-society',230,'Indian Ocean
{See reference map Vil}
Nationality: noun—Indonesian(s); adjective—Indonesian
Ethnic divisions: majority of Malay stock comprising 45%
Javanese, 14% Sundanese, 7.5% Madurese, 7.5% coastal
Malays, 26% other
Religion: 90% Muslim, 5% Christian, 3% Hindu, 2% other
Language: Indonesian (modified form of Malay) official,
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 55 million; 64% agriculture, 12% trade, 7%
industry, 17% other
Organized labor: 10% of labor force
Population: 37,582,000 (July 1979), average annual
growth rate 3.0% (current)
Nationality: noun—lIranian(s); adjective—Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 13%
other Iranian, 18% Turkic, 3% Arab and other Semitic, 1%
other ;
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha''is
Language: Persian (Farsi), Turkish dialects, Kurdish,
Arabic
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976; 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial','c883d37f2b891d5711cbf82418bf491e8fbff7ba7b0ec6b1d7fcad17d57e39bb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b236289ab02888c7f1a69376494f7b3abdae2c833ebe4e7bacf54382e85a9ad',1979,'IQ','Iraq','people-and-society',235,'Population: 12,907,000 (July 1979), average annual
growth rate 3.4% (current)
SECRET
Baghdad,
Neutral Zone <<','be662a8c53d82dc626a237bb307968522394d0e396cc62b6ed1acee18987528c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea24b244662b6599ce0927c7ab2931ed186bab9c617d5bb4d41fa0f9732d55c6',1979,'SA','Saudi Arabia','people-and-society',236,'(See reference map V}
Nationality: noun—Iraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim (50% Shia Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force
{See reference mep V}
Nationality: noun—Kuwaiti(s); adjective—Kuwaiti
Ethnic divisions: 83% Arabs, 15% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 40%
Labor force: 360,000 (1978 est.); 74% services, 11%
industry, 11% construction; 70% of labor force is
non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
Population: 8,103,000 (July 1979), average annual growth
rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi Arabian or
Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 33% (one-half foreign) of population;
44% commerce, services, and government; 28% agriculture,
21% construction, 4% industry, 3% oil and mining','47582fec0d36c34b4311c1bd4e4e602eea2823b17917df42c6f31ce03943f8d0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3137ec071dd9d1102c7b3660aca5972a2e181956b4204a7453e48bbfe30380be',1979,'IE','Ireland','people-and-society',241,'Population: 3,267,000 (July 1979), average annual growth
rate 1.1% (current)
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
7
)
:
:
'' Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
. Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0°
SECRET
Atlantic ?
“X
ot
Ocean
IRELAND?
(See reference map iV}
Nationality: noun—Irishman(men), Irish (collective pl.);
adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 22% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99% ;
Labor force: about 1,128,000 (1978); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
9.0% unemployment (February 1979)
Organized labor: 36% of labor force','2f554ae3002973082fa3fa47f0a05a2a8d7326272ac0f64386f124a48abcba5c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e8ec93b16f1211ab9d42341a6dd2a7d58ce7d735d562e2826253849e800ffd3',1979,'IL','Israel','people-and-society',245,'Population: 3,663,000, excluding East Jerusalem and the
other occupied territories (July 1979), average annual
growth rate 2.1% (7-77 to 7-78)
Nationality: noun—lIsraeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language : :
Literacy: 88% Jews, 48% Arabs
Labor force: 1,252,000; 6.1% agriculture, forestry and
fishing; 23.8% industry, mining, and manufacturing; 1.1%
electricity and water; 6.6% construction and public works;
11.9% commerce; 6.9% transport, storage, and communica-
tions; 7.3% finance and business; 29.7% public services; 6.6%
personal and other services (1978)
Organized labor: 90% of labor force
Population: 56,924,000 (July 1979), average annual
growth rate 0.4% (current) ~
Nationality: noun—Italian(s); adjective—Italian
120
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972); illiteracy
varies widely by region
Labor force: 20,125,000 (July 1978); 15.0% agriculture,
42.9% industry, 39.0% other (1975); 7.1% unemployment
(1978); 1.5 million Italians employed in other Western
European countries
Organized labor: 50-55% (est.) of labor force','5ef6728f254f562a0ae92bae8a087d881887b5148b6fb01e102a4097abcd2c8f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27172f34f0feb7b83eb68c61159cb5656979660f9976165cb2604e0c31a97ff',1979,'IT','Italy','people-and-society',249,'Population: 7,465,000, resident African population only,
(July 1979), average annual growth rate 2.7% (current)
Nationality: noun—Ivorian(s); adjective—Ivorian
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately
2 million foreign Africans, mostly Upper ‘Voltans; about
75,000 to 90,000 non-Africans (50,000 to 60,000 French and
25,000 to 30,000 Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of ‘population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in government, industry, commerce, and _ professions
Organized labor: 20% of wage labor force
Population: 52,558,000 (July 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Vietnamese (sing. & pl.); adjective—
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain tribesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','0b00ffb58ff86788addd5a0ed59b56b9fb3d9ce8884697bb26e728fd661817cb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ad55fa1b63a23baea87f31ddf6bcce6d030445d492ea0cda5c6340a037c3aa8',1979,'JO','Jordan','people-and-society',256,'Population: 3,055,000, including West Bank and East
Jerusalem (July 1979), average annual growth rate 3.2% (7-
70 to 7-76); East Bank, 2,249,000, average annual growth
rate 3.5% (7-71 to 7-76); West Bank, including East
Jerusalem, 806,000, average annual growth rate 2.0% (1-71
to 1-77) ‘
Nationality: noun—Jordanian(s); adjective—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood:
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
“than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of Sabor force
SECRET
Population: 7,957,000 (July 1979), average annual growth
rate 1.8% (current) ;
Nationality: noun—Kampuchean(s); adjective—Kampu-
chean
Ethnic divisions: 90% Khmer -(Kampuchean), 5% Chi-
nese, 5% other minurities °
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','145adfeed56c654b10b7fcd2f4e95cd392b92c59e493a6453177daa836748a97','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beb86d9f7b5f055bbe9cf5f0ceab9e10dda1827b9d5164a8347860d3d684146b',1979,'KE','Kenya','people-and-society',260,'Population: 15,364,000 (July 1979), average annual
growth rate 3.6% (current) -
129
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
25X11
25X11
25X11
- Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDPO8-00534R000100020001-0
July 1979
Indian
Ocean
(See reference map Vi}
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic); 2% Asian; 1% Euro-
pean, Arab, and others ; ;
Religion:. 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (89%) in
monetary economy (1967)
Organized labor: about 215,000','06d35bb670ad25a94eb2c972475f2f3013365dacd02d91c47a123729cb59f3b7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c719bca979ea9b91a257d91a037f3786157c38ff20110f2c417090c03dd16cfd',1979,'KW','Kuwait','people-and-society',266,'Population: 1,278,000 (July 1979), average annual growth
rate 5.9% (current)
SECRET
7 ee
eS eS ee ae,
ee ee
eS SN a Tee ee
aN 5 ah len ie Nl I ili te A ei I CR Rl Re Ri i a al a TS lee Ee I at Bi NE ate Ue Milter, CR ee ee, Ee Mi, a On, eaitiogs i
July 1979
SECRET','4f93369e0ea937b7fd676fa4e0c5d4c2283dd905d7282597b5e8e73d9b1975dc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4e7e493f795d1cab24b5589f4c7adeb5a3b9e54ebbfe22d01542901184fe2f3',1979,'TH','Thailand','people-and-society',268,'Population: 3,630,000 (July 1979), average annual growth
rate 2.4% (current); this estimate does not take into account
emigration from Laos during the past few years
Nationality: noun—Lao (sing., Lao or Laotian); adjec-
tive—Lao or Laotian
Ethnic divisions: 48% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 13% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party
Population: 46,350,000 (July 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Thai (sing. & pl.); adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry
238
Bay
of Bengal
/
Indian Ocean','c3868de16a3d779c2265b1de7b97db229657cc26d8a4f40b2a78dcffab82b9c3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11f3c9b60d5e9351dd14bff071e826202d976e429cd126783e6053cbba28e28d',1979,'LB','Lebanon','people-and-society',272,'Population: 2,943,000 (July 1979), average annual growth
rate 2.6% (current); this estimate does not take into account
any demographic consequences of the 1975-76 civil war
Nationality: noun—Lebanese (sing. and pl.); adjective—
Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority
Language: Arabic (official), French is widely spoken
Literacy: 86% :
Labor force: about 1 million economically active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
Organized labor: about 65,000','9cc7b6f7bd7cb74a80c5b3b6ccc09482a82fb2bd0d4989b6501bce8afea524d6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63babca3b78a03a15b047f2e79e7ee3e91079bd1e2dcb61914d372d49b10360b',1979,'LS','Lesotho','people-and-society',276,'Population: 1,306,000 (July 1979), average annual growth
rate 2.2%. (current) ;
SECRET','4d14d0a9dc0f6251808422ee40005a93220ce10055da02d73133ebe5dee167ef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ac1670bde0c72ce003d3362dc4c805488c4e0b34a0f1e4b92858367f0d3e034',1979,'ZA','South Africa','people-and-society',277,'Indian Qcean °
aod
(See reference map Vi)
Nationality: noun—Mosotho (sing.), Basotho (pl.); adjec-
tive—Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians
Religion: 70% or more Christian, rest animist
Language: al] Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible
« Indian Ocean
(See reference map Vi)
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Mer-
ina (1,643,000) and related Betsileo (760,000), on the orie
hand, and coastal tribes—collectively termed the Cotiers—
with mixed Negroid, Malayo-Indonesian, and Arab ancestry
on the other; coastal tribes include Betsimisaraka 941,000,
Tsimihety 442,000, Sakalava 375,000, Antaisaka 415,000;
there are also 10-12,000 European French, 5,000 Indians of
French nationality, and 5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
laneous ,
Organized labor: 4% of labor force
Population: 28,094,000, including Bophuthatswana and
Transkei (July 1979), average annual growth rate 2.5% (7-75
to 7-76); Bophuthatswana 1,135,000 (July 1979), average
annual growth rate 2.2% (current); Transkei 2,238,000 (July
1979), average annual growth rate 2.2% (current)
Nationality: noun—South African(s); adjective-—South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 538% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); relatively smal] African
unions have no bargaining power
Population: 37,551,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (July 1979),
average annual growth rate 1.2% (current)
Nationality: noun—Spaniard(s); adjective—Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
221
25X11
25X11
25X11
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
Population: 7,560,000 (July 1979), average annual growth
rate 3.5% (current)
Nationality: noun—Zimbabwe-Rhodesian(s); adjective—
Zimbabwe-Rhodesian : :
Ethnic divisions: 96% African (over 70% of which are
members of Shona-speaking subtribes, 20 to 25% speak
Ndebele); less than 4% European, less than 0.5% coloreds
and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few’ Muslim
Language: English official; Shona and Ndebele also
widely used
Literacy: 25-30% of black; nearly 100% of whites
Labor force: (1972) 778,000 Africans (above 30%
migrants, many resident for many years, from Zambia and
Malawi), 108,000 Europeans, Asians, and coloreds (people of
mixed heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 40% transport and services
Organized labor: about one-third of European wage
earners are unionized, but only a small minority of Africans','403460ccbeadd100e925e04afdd32a9ccf6fb45c5e59533d539931085d1f19d2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecae7f20cd074b35a504ef8dd21cb4646932d5c9f707845ddb024e0538cba60b',1979,'LR','Liberia','people-and-society',282,'Population: 1,789,000 (July 1979), average annual growth
rate 3.3% (current)
Nationality: noun—Liberian(s); adjective—Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist °
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor: 2% of labor force
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
>
i
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
ee ee ei
yt
A olin It
ow et ere Wee” rng
Stee ed
OD I i ee I er ae a ga a a ae
i a oe aes
i a a iL
'' Declassified in Part - Sanitized
July 1979
SECRET
Population: 2,873,000 (July 1979), average annual growth
rate 4.1% (current)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
142
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','a5b98c6ccde279de573c6991e01ad81bc8b5587cc23477aa985af4a3663fa56c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7edb7595771b2aeb4d5f878440a681fe0375ef928f8b7a426d2793c7b0621a7',1979,'LI','Liechtenstein','people-and-society',287,'noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce,
13% professional and other, 8% agriculture','19c3d644c91b1001bbce2d78f6982f704d2af89a88edbe57748ea4ec0179ba43','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92019d622b1528536c904009aff0dc6bcf2acd0d2ea7908c487f1e767eec99fb',1979,'LU','Luxembourg','people-and-society',292,'Population: 357,000 (July 1979), average annual growth
rate 0.3% (current)
Nationality: noun—Luxembourger(s); adjective—Luxem-
bourg ‘ :
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish ,
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1977) 147,300; one-third of labor force is
foreign, comprised mostly of workers from Portugal, Italy,
France, Belgium, and West Germany (1977); unemployment
0.2% (1977)','36c612ff6691c28f77bdc35be46569133ab02ebcde3356f283e645db37137533','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b747741ff1e2a5c6c91efca4fea2eabcc4690894f23f74832e6cc76637c2b46',1979,'MO','Macao','people-and-society',296,'‘Population: 272,000 (July 1979), average annual growth
rate 1.1% (current)
Nationality: noun—Macaon(s); adjective—Macaon
146
AGSHONG KONG
- PHILIPPINES
(See reference map Vit)
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
one-half are Chinese
about
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population .
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)','438c2a90ce8911f9d94818bcb292802980782f27001f2ed4679eb1d8a8e4ba4e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('698068d8d9265131d641f7c2b20c5f1bbdc9975ac3ab49f0f189a24cdd8bb592',1979,'MW','Malawi','people-and-society',301,'Population: 5,861,000 (July 1979), average annual growth
rate 2.9% (8-66 to 10-77)
Nationality: noun—Malawian(s); adjective—Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
- 13% manufacturing, 10% administration, 26% miscellaneous
services, 6,000 Europeans permanently employed
'' SECRET
Organized labor: small minority of wage earners are
unionized','f5d530852ede00d698bcbcf1a0296b2c2f6a5b62bc7d3964f0f84e222ed4095f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71ef621d41d40bc507b5ada9e5bef7d1f9530dbe39f5dd50ccdbfbf5ac6bb4d',1979,'MY','Malaysia','people-and-society',305,'Population: 13,280,000 (July 1979), average annual
growth rate 2.8% (current)
Peninsular Malaysia: 11,068,000, average annual
growth’ rate 2.6% (8-70 to 1-77)
Sabah: 990,000, average annual growth rate 4.8% (8-70
to 1-77)
Sarawak: 1,222,000, average annual growth rate 2.6%
(8-70 to 1-75)
Nationality: noun—Malaysian(s); adjective—Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 53% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10% other
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other :
Religion: :
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP0O8-00534R000100020001-0
July 1979
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Labor force:
Malaysia: 4.5 million (1977)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 18% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry,.and
fishing, 6% manufacturing and construction, 13% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas','d03ee5f340d4a2e7dd8581a622c3e7ba6b5b078f75c83cc0f4cdd6f3121bf82f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be5abf1d67f9e83aedd7790fc455b3d9abfb71655b132708568e384c74fb6088',1979,'MV','Maldives','people-and-society',311,'Population: 144,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Maldivian(s); adjective—Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population
Population: 6,350,000 (July 1979), average annual growth
rate 2.0% (current)
Nationality: noun—Malian(s); adjective—Malian |
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
154
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions
Population: 343,000 (July 1979), average annual growth
rate 1.0% (7-72 to 7-78)
Nationality: noun Maltese (sing. and pil.); adijec-
tive Maltese
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
: Literacy: about 83%; compulsory education introduced in
1946
Labor force: 119,554 (November 1977); 32% services
(except government), 18% government (except job corps),
5% job corps, 26% manufacturing, 6% agriculture, 3%
construction, 5% utilities and drydocks; 3.3% registered
unemployed
Organized labor: approximately 40% of labor force','490f6b9183c6e73126f3c8035c48e23264e451b16a1714c10a6e5f8f7687856b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be7b48a66fe0c15ed1444387713a21ab7d8a2d6b44be4ad081eb11f34fb2607',1979,'MQ','Martinique','people-and-society',315,'Population: 315,000 (July 1979), average annual growth
rate —0.1% (10-67 to 1-78)
Nationality: noun Martiniquais (sing. and pl.); adjective
Martiniquais
Ethnic divisions: 90%. African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X11
25X11
25X1
- Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
SECRET
OOMINICAN Atlantic Ocean
eo REPUBLIC #
2° PUERTO ° .
RICO mores
a
Pe
Q
MARTINIQUE 4
. q
Caribbean Sea
VENEZUELA
(See reference map ti}
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','6b7f4d41a27692936745c63391110c4c3a872c8041d3e7eee078abebc38876d2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cf6bc2761c132a25e62187a23e96df0638a7a471dcbe00be5ac5030ae4de209',1979,'MR','Mauritania','people-and-society',319,'Population: 1,558,000 (July 1979), average annual growth
rate 2.0% (current)
Nationality: noun—Mauritanian(s); adjective— Mauri-
tanian
Ethnic divisions: nearly one third Moor, at least one third
Black, one third mix Moor/Black
Religion: nearly 100% Muslim
. Language: Arabic is the national language, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 95,000 wage earners (1979); remain-
der of population in farming and herding; considerable
unemployment
Organized labor: 30,000 union members claimed by
single union, Mauritanian Workers’ Union :
Population: 933,000 (July 1979), average annual growth
rate 1.8% (7-71 to 7-77)
Nationality: noun—Mauritian(s); adjective—Mauritian
Ethnic divisions: 67% Indians, 29% Creoles, 3.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force','ecffe3b037b033f28fbaa93d77dd34cb97c30f910ba899be3405cc925c8121c1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e358670c6e25c62b073cf9cb3309c9711e4b20161462b4b24fb42abbb6798d89',1979,'MN','Mongolia','people-and-society',323,'Population: 1,639,000 (July 1979), average annual growth
rate 3.3% (current)
Nationality: noun—Mongolian(s); adjective—Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese :
Literacy: about 80% -
Labor force: primarily agricultural, over half the
population is in the labor force, including a large percentage
of Mongolian women; shortage of skilled labor (no reliable
. information available)','f99428166ead6919bb01320ebf1f3e4aa84d1ed107f0182887ae897e1afa4f29','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf4f4836428a712154d9ff4471cc4504ef6e73fc6b37b5da5c8342970668e47e',1979,'MZ','Mozambique','people-and-society',327,'Population: 10,108,000 (July 1979),
growth rate 2.4% (current)
average annual
Nationality: noun—Mozambican(s),; adjective—Mozam-
bican
Ethnic divisions: over 99% native African, less than 1%
European and Asian :
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP0O8-00534R000100020001-0
ee
y
4 .
. Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
,
)
MOZAMBIQUE/NAMBIA
,
»
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
5 2.4% other
Legal name: People’s Republic of Mozambique
Type: peoples republic; achieved independence from
Portugal in June 1975
Capital: Maputo
Political subdivisions: 10 provinces subdivided into about
94 districts; administrators are appointed by central','943c4609874f354b0156cdbf10b176906e6cf3e964de88bc669b03efc084d3a9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7ca1a9951092cf81d61bcfd370f24ea608d1d4ae9531c8ae8d95b69b009dd9f',1979,'NA','Namibia','people-and-society',331,'Population: 992,000 (July 1979), average annual growth -
rate 2.9% (current)
Nationality: noun—Namibian(s); adjective—Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 18% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','8ff8e03ae03ac7cba3fdbfb6d90dd7aaf164c7c7b7c175c4579911929f208967','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af9b0ff8091d272f60c218fd574ab58db8bf8f1a49890b0943b23a6289b25e1e',1979,'NR','Nauru','people-and-society',335,'Population: 7,000 (preliminary total from the census of 22 |
January 1977)
SECRET
NAURUe
Pacific Ocean
Coral Sea','73542eebe521436a5b982a9b66d2f691c18108c4a6164df771556e787ffd0dad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f69c23093107e7ead69241c7089e88fe5f2b2318732d2951f2f6d18f66de647',1979,'NP','Nepal','people-and-society',337,'Population: 14,028,000 (July 1979), average annual
growth rate 2.5% (current)
Nationality: noun—Nepalese (sing. and pl.); adjective—
Nepalese ,
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry;
great lack of skilled labor','223edab6fb195335a6e7929bb3d6a1b59a9dad316c077fd918a0503c5ae6cb1b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d276691aa09bf870537ed2e0cd76e359147f25e68689ec6325d7ae902ef6279',1979,'NL','Netherlands','people-and-society',341,'Population: 14,015,000 (July 1979), average annual
growth rate 0.6% (current)
Nationality: noun—Netherlander‘(s); adiecive=Nahoe
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 31% Protestant, 40% Roman Catholic, 24%
unaffiliated
Language: Dutch
Literacy: 98%
171
25X11
“25x1
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
Labor force: 4.8 million (1978); 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5%
unemployment, April 1979
Organized labor: 33% of labor force','e074faf0379024ed5960f89910f3d134c78399fd542b84dd5433e3e339ffd393','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdaf0d43f465f5bed8ddc6269a376b23b371f167e51f57870018b7814c540a56',1979,'CO','Colombia','people-and-society',345,'Population: 241,000 (July 1979), average annual growth
rate 1.0% (current)
Nationality: noun—Netherlands Antillean(s); adjective—
Netherlands Antillean
Ethnic divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish minorities
Language: officially Dutch; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force
173
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X1
25X11
25X1
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDPO8-00534R000100020001-0
July 1979
NETHERLANDS ANTILLES','55599cbdc481715612459151ee733a699077a453c70bc5255e8bdca7bb0835d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91bea69fe761dc7bcd3873f35d9c0a3b2e0a2cf03c2867810cd674dc857112d8',1979,'NZ','New Zealand','people-and-society',350,'Population: 3,119,000 (July 1979), average annual growth
rate 0.4% (7-75 to 7-78) :
Nationality: noun—New Zealander(s); adjective—New
Zealand
SECRET .
_ Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
a 1
aa ee a i a ee es a a ak Ha oe a A Ga ee
a are aes
July 1979
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
(See reference map Vill)
Ethnic divisions: 87% European, 9% Maori, 2% Pacific
Islanders, 2% other
Religion: 81% Christian, 1% Hindu, Confucian, and
other, 18% none or unspecified
Literacy: 98%
Labor force: 1,207,700; 11% agriculture, 34% manufac-
turing, mining, and construction, 9% transportation and
communications, 22% commerce and finance, 24% adminis-
trative and professional; unemployment 2.4% (1978)
Organized labor: 46% of labor force','1e62f3cfb3e0e283ca1c0f0ccf9f2102002828b47c1bf40efbf03e01c6a07943','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37630ba1410c31155959ef93da7245ce41707f49bf451f04ab542343e35cd527',1979,'NI','Nicaragua','people-and-society',355,'Population: 2,485,000 (July 1979), average annual growth
rate 3.1% (current)
_Nationality: noun—Nicaraguan(s);
guan
’ Ethnic divisions: 69% mestizo, 17% white, 9% Negro, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking minority
on Atlantic coast
Literacy: 52% of population 10 years of age and over
Labor force: 728,419 (1977 est.); 43% agriculture, 15%
manufacturing, 13% commerce, 29% other; shortage of
skilled Jabor, but underemployment of ‘unskilled labor
except during harvest
Organized labor: about 5% of labor force; Confederation
of Labor Unification (CUS), a national, democratic confed-
eration. with approximately 8,000 members; Nicaraguan
adjective—Nicara-
“ Worker’s Central (CTN), a major leftist confederation with a
Social Christian orientation, its 3,000-4,000 members are
mostly in the hospital sector; Independent Genera] Confed-
eration of Workers (CGT-I); a Moscow-line Communist-
dominated confederation, its membership is estimated at
12,000-15,000, making it the largest labor group; General
Confederation of Workers (CGT), 10,000 members strong,
its leadership is controlled by the GON','eb264d9819460bf13e65482958f8f42de2a0dc260f87be8d79279511d636c06b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc35277dc523ae710381ad2d06559c7bb5881a61ef855906abc71864775e2a4d',1979,'NE','Niger','people-and-society',360,'Population: 5,133,000 (July 1979), average annual growth
rate 2.8% (7-77 to 7-78)
Nationality: noun—Nigerien (sing. and pl.); adiective—
Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Dierma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
180
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible','eb1843a4a1e2cbaf99fdbb97ae96706487648746699cef63db3129c4ff617885','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e05ca80a8fbfe3acf296304dba96261d573bf0118a6ea93a37caba7ccf4d4c12',1979,'NG','Nigeria','people-and-society',364,'Population: 74,604,000 (July 1979), average annual
growth rate 3.8% (current)
Nationality: noun—Nigerian(s); adjective—Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Hausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans .
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also
widely used ,
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3 million wage earners, of whom
560,000 work in modern enterprises
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions','02d1ab1dee61a71359b891758d0e98aca2cd459bed2886aca43cf613b9275010','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5474f342aacade6da1bc1432ce7c819ac291cd5380ece54f7fb154c327933940',1979,'NO','Norway','people-and-society',368,'Population: 4,077,000 (July 1979), average annual growth
rate 0.4% (1-77 to 1-78)
Nationality: noun—Norwegian(s); adjective—Norwegian
SECRET
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-speaking
minorities
Literacy: 100%
Labor force: 1.8 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.38% commerce, 9.9% transportion and communica-
tion, 28.5% services; 2.3% unemployed (third quarter 1978)
Organized labor: 60% of labor force','44b32ad9e3561cb91981cc87aab92130b594c54db523252a50b1c422cdc215c3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f5fb778346ffae97cae984692b1fd597d34debca5e0d6b6e6bd26a1d52c1159',1979,'OM','Oman','people-and-society',372,'Population: 565,000 (July 1979), average annual growth
rate 3.0% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: 10%','ee2067d3aa83302f06af21a3d4e731ad6ff53bf7c817785188976ab93ab59867','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc04976e56286120d5ea14aed630fda88c99c8dbb8fa162046a15599f6a87abe',1979,'PK','Pakistan','people-and-society',376,'Population: 80,171,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir,
(July 1979), average annual growth rate 3.0% (current)
Nationality: noun—Pakistani(s); adjective—Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages—7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 22 million (1978 est.); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed
Organized labor: 5% of labor force
Population: 1,862,000 (July 1979), average annual growth
rate 2.7% (current)
SECRET 187
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDPO8-00534R000100020001-0
July 1979','0c523d91ac60279fa61f3b4b1670ecf6496a5337f8913b29498919eec075af33','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce5d0c06a4c7623bed3f3e17ec21703eb12197d6d48894cedd2a316bd59900f6',1979,'PA','Panama','people-and-society',379,'Nationality: noun—Panamanian(s); adjective—Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 515,000 (1977); 39.5% commerce, finance
and services; 33.9% agriculture, hunting and fishing; 9.7%
manufacturing and mining; 6.8% construction; 5% Canal
Zone; 3.9% transportation and communications; 1.2% utili-
ties; active and inactive unemployed estimated at 12-16%
(1976-77); shortage of skilled labor but an oversupply of
unskilled labor
Organized labor: 10-15% of labor force (1978 est.)','661cf58b23ef93dea845fa9a955599c04f531cae9dc84352a4f4d0ba231780bc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae506bbd9ecfa3980fbb18a7decddafe88b86920bd6c18e4f42102217ffd1bb7',1979,'PG','Papua New Guinea','people-and-society',384,'Population: 3,064,000 (July 1979), average annual growth
rate 2.6% (7-73 to 7-77)
Nationality: noun—Papua New Guinean(s); adjective—
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: -over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 83 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: no available figures; mostly subsistence
farmers','d2155cc3bd284cbe78499411e44ecd62bbce57e0879a56c1fde9d678d32e0d8a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('283bda27639f6e5785f35b69d7800542e6d24aade1608926b9207b8eeaca7b75',1979,'PY','Paraguay','people-and-society',388,'Population: 3,160,000 (July 1979), average annual growth
rate 2.9% (current) ;
Nationality: | noun—Paraguayan(s); adjective—Para-
guayan
‘SECRET
_ Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
ee ee ee ee ee a aes
oe a a ee ee ae
-—_— mie
me a ee ae ee ee ee ee
me meee ee eee
y
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RD
ee ce i ee ae Nn ee tat ene ae
_ Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
SECRET
BOLIVIA ; ‘BRAZIL
; Zp Atlantic Ocean
(See reference map tit)
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 52.6% agriculture,
forestry, fishing; 28.2% services; 19.2% manufacturing and
mining (1970)
Organized labor: about 5% of labor force','814373f2c59fb7562684381f7b44bc5fd0fec6c7ac4736a448f54da57dbb19e9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a1ce9e903826b857e7e4abd984bf0e0581e6068f1fccf4478f4a23b561631ac',1979,'PE','Peru','people-and-society',392,'Population: 17,287,000 (July 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Peruvian; adjective—Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','ede25bca260b7446f1efdb926571108e28771163ad79728afa2203772de53058','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7de1bb3e34f73f6a9023b6b8e6fda5c70d35ec56438710fc8dc02da0659fa6c1',1979,'PH','Philippines','people-and-society',396,'Population: 46,893,000 (July 1979), average annual
growth rate 2.2% (current) ~
Nationality: noun—Filipino(s); adjective—Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
arable land, 5%
194
Literacy: about 83%
Labor force: 15.4 million (1976); 60% agriculture,
forestry, fishing, 12% manufacturing, 10.5% commerce,
10.5% government and services (business, recreation, domes-
tic, personal), 3.5% transport, storage, communication, 3%
construction; 0.5% other','619370eb28a4fd0bfb23c76892d9217ae6d4cde817d47cc05dc2be53564a7eba','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5f545d397b3f61238fb28c7e166b90ccc4b2838d3cc2d77b7a57ef34adc658c',1979,'PL','Poland','people-and-society',400,'Population: 35,391,000 (July 1979), average annual
growth rate 1.0% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 18.8 million; 32% agriculture, 25% industry,
43% other non-agricultural (1977)','d9f857c85d29f5d9192edcd3ae1af7ba1f6234061c7f6708f57ab0fc11bed972','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e87f9f58b95c136e9f91c1bd09cbc5e0b40bfa6bb12faacb287c39cb28c832',1979,'PT','Portugal','people-and-society',403,'Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
number less than 100,000
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1978) 4.1 million; 83% agriculture, 33%
industry, 34% services; unemployment—now more than
13%—is largely due to influx of refugees from former
colonies, returning migrant workers, military cutbacks, and
government efforts to slow economic growth in the short run °
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers—National Intersindi-
cal (CTP-IN) claims to represent 77% of the labor force; the
Socialists and Social Democrats have gained ground over the
last year because of the formation of the General Union of
Workers (UGT)','2316bb0bb536b04adadda338add2faf901226dbd519bedbfdb548127bee91dba','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e362e241cff9391463e2a9b268a4de40f8d3c5c6af9e438d56fd1d77fb0bd30c',1979,'QA','Qatar','people-and-society',408,'Population: 167,000 (July 1979), average annual growth
rate 3.2% (current)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 38% Arab; 15%. Iranian; 29% Pakistani;
18% other; native Qataris are a minority
Religion: Muslim
Language: Arabic, English is commonly used second
language ~
199
25X1
25X1
25X1
25X11
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
July 1979
"SAUDI ARABIA
(See reference map V)
Literacy: 25%
Labor force: primarily foreign','5f45b6994b5649a8959d231013dffdf6da1502d3fcda17a8b9dec64fb47fc87e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('488abd7409606c53ab78c80924a8b2d2fd7ceabcfeb8dad6d29eb6673dcb70a7',1979,'MU','Mauritius','people-and-society',412,'Population: 503,000 (July 1979), average annual growth
rate 1.4% (7-77 to 7-78)
Nationality: noun—Reunionese (sing. & pl.); adjective—
Reunionese
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','6d61db448f5da290b0727a6191b5ed8ff64a61cda8591d3a820e47c422d4e957','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a867455748c50e3edd1e9fb2ec5f10892e79f8b27ad771fa1927aeefd14335f',1979,'RW','Rwanda','people-and-society',416,'Population: 4,573,000 (July 1979), average annual growth
rate 2.9% (current)
Nationality: noun Rwandan(s); adjective—Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
203
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X1
25X1
25X11
25X1
20X1
ZOA1
25X1
25X11
25X11
_ Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
July 1979
(See reference map Vi)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 25% in French and Kinyarwanda
Labor force: approximately 5% in cash economy','dd9e15885ecec3ec7b912d524dfaf18571dbc79d02605e32aa811880fd0758df','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ed3c22dfba5498286a4de7119d575aaa57f0bbfa55dbd9e646a08f669a5aade',1979,'AI','Anguilla','people-and-society',420,'Population: 58,000 (July 1979), average annual growth
rate 1.1% (7-76 to 7-77)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s), Anguillan(s);
adjective—Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.) ©
Organized labor: 6,700
SECRET
Legal name: State of St. Christopher-Nevis-Anguilla
Type: dependent territory with full internal autonomy as
a British “Associated State”; Anguilla formally seceded in
May 1967 but has not been recognized as an independent
state by any government; in July 1968 a legislative council
headed by Ronald Webster was elected to govern Anguilla;
in March 1969 the U.K. sent troops to Anguilla, placing the
island again under colonial rule; in 1971, Anguilla reverted
to its former colonial relationship with the U.K. although
nominally remaining part of the Associated state of St.
Christopher-Nevis-Anguilla, Webster became leader of
Anguillan -Counci] after constitutionally held elections
(1972); in February 1976, the U.K.° granted a new
constitution to Anguilla which gave it a greater degree of
autonomy in domestic affairs; in February 1977 Emile
Gumbs replaced Webster as Chief Minister
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution
of 1960; highest judicial organ is Court of Appeal of
Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier, Lee Moore; U.K. Gover-
nor, Probyn Inniss
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent December
1975
Political parties and leaders: St. Chirstopher-Nevis-An-
guilla Labor Party, C. A. P. Southwell; People’s Action
Movement (PAM), William Herbert; Nevis Reformation
Party (NRP), Ivor Stevens
Voting strength (December 1975 election): St. Christo-
pher-Nevis-Anguilla Labor Party won 7 seats in the House of
Assembly, NRP won 2, and 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: CARICOM, ISO
Population: 121,000 (July 1979), average annual growth
rate 1.7% (current)
Nationality: noun—St. Lucian(s); adjective—St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture; 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 113,000 (July 1979), average annual growth
rate 1.8% (4-60 to 1-76)
Nationality: noun—St. Vincentian(s) or Vincentian(s);
adjectives—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force','0613fb41b0ffa05f8207abdc90fe7db1d69a9e1cf79f2e1bc681f31d7042fea2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e8f0917b8db84c3063addb737046cc60ccf726399cca30d3d804c0c179417e3',1979,'SM','San Marino','people-and-society',424,'Population: 20,000 (official estimate for 30 June 1977)
Nationality: noun—Sanmarinese (sing. & pl.); adjective—
Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members','d83a15b3e24d01a1b3bafbbce6bac32b80111bd706cec5283699b7543cf9d43a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f76db81e6041023d52b3a0b62acaf09fe0c81e1faf75802d19b56ab73be0b4ab',1979,'SN','Senegal','people-and-society',430,'Population: 5,519,000 (July 1979), average annual growth
rate 2.6% (current)
Nationality: noun—Senegalese (sing. & pl.); adjective—
Senegalese :
‘Ethnic divisions: 36% Wolof, 17.5 Fulani, 16.5 Serer, 9%
Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African, 1%
Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading—now spoken to some
degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central unions, major central is CNTS,
an affiliate of governing party','1be2c6bbad35acad51c9ac4754ede01ab2d15c9e0b69fa341b287cd11e388a46','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d8ff367c3949350ee2833001414cdc9ad67b7a152f46295c529ded197d52fc',1979,'SC','Seychelles','people-and-society',433,'Ethnic. divisions: Seychellois ‘(admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited; 90% of school-age population is
attending school -
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
83% public sector employment, 20% private sector employ-
ment in agricuture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','d2de8486ef99a0b826bc62d3529df6638dab40f8a836137567c785014d6cce0c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8cb9a34ed5d350d8d6b684e0521ca1fd7213bde0c70cbf3b45104690e7de466',1979,'SL','Sierra Leone','people-and-society',438,'Population: 3,351,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Sierra Leonean, adjective—Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','1ddde11edad407e5c8556a9aa6a214a89488a00bc42be18c36906676f3ed4658','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23d435a58acbc6a6db6fdd73560d1da671182d093aba1c95cf2d50e918c4e326',1979,'SG','Singapore','people-and-society',441,'Population: 2,361,000 (July 1979), average annual growth
rate 1.1% (7-77 to 7-78)
216
Nationality: noun—Singaporean(s), adjective—Singapore
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 919,000; 2.2% agriculture, forestry, and
fishing, 0.2% mining and quarrying, 27.2% manufacturing,
80.5% services, 4.6% construction, 23.5% commerce, 11.7%
transport, storage, and communications
Organized labor: 24% of labor force','9e9bb96e8ca9a8afbcf941b879187159b6303ffa6d7c0c2cf0ef333f3f9565f2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea64e1e5b742f13965eed05974612efc0088d66d7f4e963653edb0d033869dc',1979,'SB','Solomon Islands','people-and-society',444,'Population: 219,000 (July 1979), average annual growth
rate 3.2% (current)
Nationality: noun—Solomon Islander(s); adjective—Solo-
mon Islander
Ethnic divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian;.Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60%','89344fdb679428aefbf38fd570dbfd9debf688647dce4a1d8a45625428415ca6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('571d0e3289dc1a6002e2666af06ef76ca3d0d1531a4ccbb0205b25ae77ddecc2',1979,'SO','Somalia','people-and-society',448,'Population: 3,469,000 (July 1979), average annual growth
rate 2.4% (current)
Nationality: noun—Somali(s); adjective—Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1972); Arabic, Italian, English
Literacy: 5-10%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X1
_ Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP0O8-00534R000100020001-0
'' Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
ee ee ae ee Aa
ee ESE ee Ree ee Se parece PRN. TE Deere ie:
July 1979
SECRET
SOMALIA/SOUTH AFRICA
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977','e122204593ad476a49f59f5172db527f67ed0e9e062d3b9bd5f3aceb87642b94','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fe145635ef27c6685f5511bc0d0afb2497233ccaf2f1283c0d542f143728719',1979,'ES','Spain','people-and-society',453,'Language: Castilian Spanish spoken by great majority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97%
Labor force (1979): 13.2 million; 19% agriculture, 27%
industry, 10% construction 41% services; unemployment
now estimated at nearly 8% of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent 30-
85% of the labor force (1979)','45fa0ee52111fc5cd66afcc07d767d48b60f0d2b44daa7a7a76f2bb0b903369d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e50c9f90b91e4f9fa2485b0440178cd9b9e4156c5ab6c9388c27b5f2de773f',1979,'LK','Sri Lanka','people-and-society',458,'Population: 14,502,000 (July 1979), average annual
growth rate 1.5% (current)
Nationality: noun—Sri Lankan(s); adjective—Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other :
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other
Language: Sinhala official, Sinhala and Tamil listed as
national languages, Sinhala spoken by about 70% of
population; Tamil spoken by about 22%; English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons—53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates','594859e15ae4db0f0c93357c1728d297697a1e4369ceb30567a0bc628663bbfb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51ad26957724a299f70b5dfd976b329d9105d46d8dce6c9b6935d180fa251650',1979,'SD','Sudan','people-and-society',462,'Population: 20,941,000 (July 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Sudanese (sing. and pl.); adjective—
Sudanese
Ethnic divisions: 89% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other ;
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 8.2 million (1978); 85% agriculture, 15%
industry, commerce, services, etc.; labor shortages exist for
almost all categories of employment','60de0ee4f0e8a8204229f4b8763145feaf2a72b754d01d0ca02dca566441ff3a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79064feb4a4d4906f0c4e5b68552331363797e4dce03cdca8e4fb9c68c1569a3',1979,'SE','Sweden','people-and-society',466,'Population: 8,300,000 (July 1979), average annual growth
rate 0.3% (7-77 to 7-78)
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities
Literacy: 99%
Labor force: 5.9 million; 5.8% agriculture, forestry,
fishing; 26.1% mining and manufacturing; 7.1% construc-
tion; 14.9% commerce; 6.8% communications; 33.3% services
including government; 6.0% banking; 2.8% unemployed
(March 1978)
Organized labor: 80% of labor force','8e724e1bd3d7c2d3cbf1604f423b6198c752e852ca76bbced4f322c08c85c311','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aac88adb64af3a064700bc8aa260cea4252967f5e0b6533e5363e68890396e1b',1979,'CH','Switzerland','people-and-society',470,'Population: 6,284,000 (July 1979), average annual growth
rate —0.1% (1-77 to 1-78)
Nationality: noun—Swiss (sing. & pl.); adjective-—Swiss
Ethnic divisions: total population—69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals—74% German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population—69%
German, 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98% :
231
25XK1
25X1
25X1
25X1
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
July 1979
Labor force: 2.6 million, about one-tenth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.38% unemployed in July 1978
Organized labor: 20% of labor force
Population: 8,395,000 (July 1979), average annual growth
rate 3.38% (current)
SECRET
Nationality: noun—Syrian(s); adjective—Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% Alawites, Druze,
and other Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 1.8 million; 32% agriculture, 26% industry
(including construction), 42% miscellaneous services; major-
ity-unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 17,440,000, excluding the population of
Quemoy and Matsu Islands and foreigners (July 1979),
average annual growth rate 1.8% (7-77 to 7-78)
SECRET
py aes
25X11 ;
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
?
gah et
July 1979
SECRET
TAIWAN
Nationality: noun
Chinese
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
Religion: 98% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 6.12 million (1978); 26.2% primary industry
(agriculture), 39% secondary industry (including manufac-
turing, mining, construction), 34.8% tertiary industry (in-
cluding commerce and services) 1977; 2% unemployment
Chinese (sing., pl.); adjective—
‘ (1976)
Organized labor: about 12% of 1972 labor force
(government controlled)
Population: 17,358,000 (July 1979), average annual
growth rate 3.0% (current)
Nationality: noun—Tanzanian(s); adjective—Tanzanian
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Mainland—40% Animist, 30% Christian, 30%
Muslim; Zanzibar—almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher education;
Swahili widely understood and generally used for communi-
cation between ethnic groups; first language of most people
is one of the local languages
Literacy: 61%
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0 ;,
29K
25XK1
er Te a Sag a RS — Sg I~ Re NSS
July 1979
SECRET
TANZANIA
Labor force: 456,000 in paid employment, over ,90% in
agriculture
Organized labor: 15% of labor force','ad4d213364bf9433aedf1fa788087df789fb4a4c73fbce5da8ce97171d8c0696','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3c70aecd41ff006c502980e157ea98bf59f7176a0eb865dc0bb23cce4e091fc',1979,'TG','Togo','people-and-society',474,'Population: 2,528,000 (July 1979), average annual growth
rate 2.8% (current)
239
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDPO8-00534R000100020001-0
July 1979
UPPER
VOLTA
Gulf of Guinea
(See reference map Vi}
Nationality: noun—Togolese (sing. & pl.); adjective—
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: | national union, the CNTT organized
in 1972
Population: 92,000 (July 1979), average annual growth
rate 0.3% (current)
Nationality: noun—Tongan(s); adjective-—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
_ Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
SECRET
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','1bb446be1d66171c5aa629909aa4ac29c10b03c05f6e89d3f6ddbf0205ddc35e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41aaec84383ac23d302ca4d97657b9956f1eb12608c9278871cac7f887b60b39',1979,'TT','Trinidad and Tobago','people-and-society',478,'Population: 1,136,000 (July 1979), average annual growth
rate 1.1% (7-70 to 7-76)
Nationality: noun—Trinidadian(s), Tobagonian(s); adjec-
tive—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31:2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
242
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 23.0% services, 2.9% other
Organized labor: 30% of labor force','53c38ee042db0ef0990f57c77350799d454cdca4faa931c8db4bbb86d50e9cdf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cefb3a4554e1a04dd9b3631a52d0cf9d6a5b6a65e46b7604644517f4081668e',1979,'TN','Tunisia','people-and-society',481,'Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and _ utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party','40f858b5ea2891f620ff73db738089bd94f30a1dff56f2a2e311c15c9888bcb1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f276171b7fb8ed8352badb2b6c97478c9b08254e8f71a89bdfcad2eccb8bb5ce',1979,'TV','Tuvalu','people-and-society',485,'Population: 6,000 (preliminary total from census of 8
December 1973) +:
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','2d1818da4bd0e5f063cc5d0a81706546798f098a8322b2555ec922eda4229793','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3bf4d7b6f3c06daa9c11a7366f5db68bb3f3ab5c7906f40da804f10142d00c',1979,'UG','Uganda','people-and-society',488,'Population: 13,225,000 (July 1979), average annual
growth rate 3.5% (current) :
Nationality: noun—Ugandan(s); adjective—Ugandan
Ethnic divisions: 99% African, 1% European, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist .
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 263,818,000 (July 1979), average annual
growth rate 0.9% (current)
Nationality: noun—Soviet(s); adjective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups
Language: more than 200 languages and dialects (at least
18 with more than | million speakers); 76% Slavic group, 8%
other Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 138 million (mid-year 1978), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported','c60ae3a61fbbd4fc2e8c07ee07e9ce224ddec6187b1d19299e5fb97936ff22de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8451d60084a70a1b01672bf630f409657add61117e3458740a7a9430dc3dc71',1979,'AE','United Arab Emirates','people-and-society',491,'‘Population: 862,000 (official estimate for 31 December
1977)
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians)
8%
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 490,000 (1978 est.); 538% services; 87%
foreign workers','69d7f5ec88965fd72ac4ee2039e7c3fd619cf846108af7887a2d27e1fd53019b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cda5a2e30d8433642b03f3ea8f035131f36f0044f2fbf5fee863b3265c9b094',1979,'GB','United Kingdom','people-and-society',495,'Population: 55,822,000 (July 1979), average annual
growth rate —0.1% (current)
Nationality: noun—Briton(s), British
adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5% Welsh, 3%
Irish
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
(collective pl.);
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
{
25X1
<
25X11
25X11.
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
)
en ae
me en ae re en Tn ne ne rr me me re ae a a mS em ng a a a ge = nn pr nS names ei ma mar meee ant mr cue Neh
: ’
July 1979
SECRET
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other; 2.1%
unemployed
Organized labor: 40% of labor force
Population: 6,656,000 (July 1979), average annua! growth
rate 2.2% (current)
Nationality: noun—Upper Voltan(s); adjective—Upper
Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence farm-
ing, and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union groups','4f5f02349ef042b27ed2db060cde00eec29199207ee2370a70afe9e6f3d6b4ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('690084a2b01d44b9e2d401a49917fdbb8067f318ee003f14a2a6c5f7964a74c6',1979,'UY','Uruguay','people-and-society',498,'Population: 2,910,000 (July 1979), average annual growth
rate 0.6% (current)
Nationality: noun—Uruguayan(s); adjective—Uruguayan
Ethnic divisions: 85-95% white, 5% Negro, 5-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors—25% government; 34% industry; 10%
service; 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1977)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
SECRET
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories—executives, officeworkers, and
salaried employees
Organized labor: none
Population: 14,534,000, excluding Indian jungle popula-
tion (July 1979), average annual growth rate 3.38% (current)
Nationality: |_noun—Venezuelan(s); adjective—Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 96% Roman Catholic, 2% Protestant
Language: Spanish (official); “Indian” dialects spoken by
about 200,000 aborigines in the interior
Literacy: 74% (claimed, 1970 est.)
258
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroléum, utilities, and other
Organized labor: 45% of labor force','bebc41cc5aa94cd36d44b0ed5d020cd2a2e17a17ccdc5abbab49f5304c1f619c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02aa596cfb666f4b41020bb9543907317e161e2e32c1639bce5b2ff40916b011',1979,'EH','Western Sahara','people-and-society',504,'Population: 75,000 (total from the census of November
1974)
’ Nationality: noun—Saharan(s); adjective—Saharan
_ Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: Hassaniya Arabic
Literacy: among Moroccans, probably nearly 20%; among
Saharans, perhaps 5%
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none
rate 1.0% (current)
ern Samoa
associated with the London Missionary Society)
Language: Samoan (Polynesian), English
from 7-15 years)
ing 1,716 (1961)
Organized labor: unorganized
Population: 1,781,000, excluding the islands of Perim and
Kamaran for which no data are available (July 1979),
average annual growth rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,125,000 (July 1979), average annual growth
rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 22,174,000 (July 1979),
growth rate 0.9% (current)
average annual
Nationality: noun—Yugoslav(s); adjective—Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
SECRET
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
oe
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
.
[
¥
[
|
bp
July 1979
SECRET
YUGOSLAVIA
Literacy: 80.3% (1961)
Labor force: 8.6 million (1978); 33% agriculture, 24%
mining and manufacturing, 17% other nonagricultural
activities; estimated unemployment averaged 6.8% of
domestic labor force in 1978
Population: 27,869,000 (July 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Zairian(s); adjective-—Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes—Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 60% Christian, 35% animist, 5% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official languages
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
25X1
25X1
25XK1
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
{
[
ae Oe ee | ee Oe ee
Oe Te ll cin a Ml ie i i i ee el
a a a ee cel
NT TT a TR Ta
OT a a i Eg I Ne
July 1979
SECRET
ZAIRE
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 18% in wage
structure','319dcb82d50ff2289e0561dcc8fa74902eb51478450f4a13633752474436d2bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab969d5b16e00859b52244d21d4789ce4900831ee5436fa0c892ddfd1906f92d',1979,'ZM','Zambia','people-and-society',508,'Population: 5,647,000 (July 1979), average annual growth
rate 3.2% (7-77 to 7-78)
Nationality: noun—Zambian(s); adjective—Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
270
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellaneous services
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','e6f0ae5c20602ef64a65aefd81a6b416dc015722b9c6cd0440a2583a4c23f2b7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('444e563cea6203de32b6ab273411d54556faf3d4887e3065db856f4b3e151d8c',1979,'US','United States','people-and-society',512,'Population: 220,232,000 (July 1979), average annual
growth rate 0.8% (current) :
Ethnic divisions: 86.5% white, 11.7% black, 1.9% other
Religion: total membership . in religious bodies,
129,714,000; Protestant 69,743,000, Roman Catholic
48,882,000, Jewish 6,115,000, other religions 4,973,000
(1975) ;
Language: English, predominantly
Literacy: almost complete
Labor force: 96.9 million, unemployment 7.7% (1976)
Organized labor: 20.1% of total (1976 prelim.)','081a845e6ef0210eef5d220fbb4988409683b1eaed2122b70d4f87d6078b4c5c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad1465a680516bec3319e553d6028fd3ce32422032b8daa586a735a8f55853cc',1979,'AF','Afghanistan','people-and-society',9,'Population: 14,541,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun— Afghan(s); adjective — Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: under 10%
Labor force: about 5.88 million (FY78 est. ); 75%-80%
agriculture and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','ef90429354d724079b7d86b71fdbc9797e9d26c94c7c8425b7d0aeb5c4ec9af1','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74c96c32532d5730675813a5b79d250e81538bb02c4c19f286747d663b5ee790',1979,'AL','Albania','people-and-society',14,'Population: 2,597,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun — Albanian(s); adjective — Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world’s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural','f304e838327c6d7c27c96c18c23ed24c383bececc1e7ea13f58fde3adb292e26','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f58bd2bbfdb5eb102f928b0a96e28e35d7f125a6c29204290807013b7439bc93',1979,'DZ','Algeria','people-and-society',18,'Population: 17,944,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun— Algerian(s); adjective— Algerian
Ethnic divisions: 99% Arab- Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front','7a58a5782db99e35cbb2a2e1ccd5079fbe9f82cd1eb95daccf39628d425c336a','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7022f107bd2f65ce996ea5e246ba21217d648fbb7d7da52cf8819610bd535328',1979,'AD','Andorra','people-and-society',22,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun — Andorran(s); adjective — Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers','3ad3d9ede9bd512dcb10a78f7b1891627cade01b690e39b289ad2bb212dcb963','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fcd7ea27d4e3416c5e99598cf1fdc12d29bd552dfb7771e40fdc97f2e0d77a2',1979,'AO','Angola','people-and-society',26,'Population: Angola (including Cabinda), 6,527,000 (Janu-
ary 1979), does not take into account emigration from
(See reference map V!)
Atlantic
Ocean
Angola, average annual growth rate 2.4% (current); Cabinda,
105.000 (January 1979), average annual growth rate 3.3%
(12-60 to 12-70)
Nationality: noun — Angolan(s); adjective — Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10-15% j
Labor force: 2.6 million economically active (1964);
531.000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 73,000 (January 1979), average annual
growth rate 1.3% (7-70 to 7-77)
Nationality: noun — Antiguan(s); adjective — Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects, and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment','c7cd1a4043f4f95ae502fac859307349bd3c7be6e2afaa0288b209a968ba8531','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdebc03cafc2cf6a72d51188dcc997e4a57dea66f16f832f9624f5590ee7df9f',1979,'AR','Argentina','people-and-society',30,'Population: 26,658,000 (January 1979), average annual
growth rate 1.3% (current)
Nationality: noun — Argentine(s); adjective — Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 4-5% estimated unemployment
Organized labor: 25% of labor force (est.)','cec594c9cf70250799b8d00150be163aa57b9fa3d325ea3bd31c536182dd34dd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba00a89ecaba202da6d26fce6a5c380ecd2083bfeb89d97c12236e74be0f333c',1979,'AU','Australia','people-and-society',34,'Population: 14,298,000 (January 1979), average annual
growth rate 1.1% (current)
Nationality: noun— Australian(s); adjective— Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6% unemployment
Organized labor: 44% of labor force','7a29fcc52e1685d121ddfc17a999ad3750f04f6da8ca5abc167a2db875d8c489','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70d8c73a5d30f483665c5951e39546dcfd0fd6d9043a23eeba97da2b7118e642',1979,'AT','Austria','people-and-society',39,'Population: 7,511,000 (January 1979), average annual
growth rate -0.0% (1-77 to 1-78)
Nationality: noun— Austrian(s); adjective— Austrian
(See reference map IV)
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,784,635 (1977); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.4%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number more than 200,000 (1972); unemployment
1.2% (September 1977)
Organized labor: about two-thirds of wage and salary
workers (1971)','b23a0f3abe1d39b4aceb6b30b891fe4d64531c3fb5390eb850107c3432d1c62c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('138355ca3e35678d25b69d0d8897024037115371328236762967555ae7e41e8e',1979,'BS','Bahamas','people-and-society',44,'Population: 229,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77)
Nationality: noun— Bahamian (sing., pi.); adjective —
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
11
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
January 1979
THE BAHAMAS /BAHRAIN
Language: English
Labor force: 84,228 (1976), 25% organized; 25% unem-
ployment (1977)','3976f60f233e0e8d10bb10d465c1bd13b27af8680b176cceefa0f2faca6a9d0c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59ed5f16657a9151ddfab4e2b1b5b7b1a4732bc67770e85e0c25df06030caf6d',1979,'BH','Bahrain','people-and-society',47,'Population: 289,000 (January 1979), average annual
growth rate 3.5% (7-75 to 7-76)
Nationality: noun — Bahraini(s); adjective Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 78,507 (1976)
12
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BAHRAIN/BANGLADESH','87580b90bc5609d78499dac2ad6ec90e4557ba3d20348f82f7c4f45036c3bf0d','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e735d2dfc7e85852f9c30533b8c97bcbe73e7c50f375c252732173840be9078',1979,'BD','Bangladesh','people-and-society',51,'Population: 86,931,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun — Bangladeshi(s); adjective — Bangla-
desh
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
13
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: predominantly Bengali; fewer than 1
million “Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 20 million; extensive export of labor to
U.A.E., Qatar, Kuwait, Iraq, and Oman; over 75% of labor
force is in agriculture','1f2cd9ce4392bd365cb318b0d407a67e5f2266f25a8aa36e6069f6f99e3955cb','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a227aa561613ea1fbc345207f905bab216cfab3d2b3725800b63079307170202',1979,'BB','Barbados','people-and-society',55,'Population: 260,000 (January 1979), average annual
growth rate 1.5% (1-76 to 1-77)
Nationality: noun — Barbadian(s); adjective — Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners;
unemployment 20-25% (1976)
Organized labor: 32%','1c3d45416efb24381a38ffd4183debc427daf8fa48ba85d57ff42e8ec7f6544f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a148fe50653d031d67a6894a05286e5e409fd4c9e83c0ecb64fccd0e4a5ccbf',1979,'BE','Belgium','people-and-society',59,'Population: 9,842,000 (January 1979), average annual
growth rate 0.0% (current)
Nationality: noun— Belgian(s); adjective— Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
Literacy: 97%
Labor force: 4.09 million (July 1978); in June 1976, 46.7%
in services, 28.0% in mining and manufacturing, 7.4% in
construction, 6.6% in transportation, 3.2% in agriculture,
1.0% commuting foreign workers, 0.4% in public works,
6.7% unemployed; 8.1% unemployed first quarter 1978,
seasonally adjusted
Organized labor: 48% of labor force (1969)','5f3daaab2df7eb0a1a15d40580b635667f4351b9039601074af574471e21031a','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8e689ffa57403b98865e5a7c2a7d210f4bc81fe3cefc86e5fdc2db5e09f57a9',1979,'BZ','Belize','people-and-society',62,'Population: 154,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun — Belizean(s); adjective — Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
17
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
BELIZE/BENIN
Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force','c6b3416e6852e84106d170bc29a0dbbb7b7344fe3346be9b7af7706fe2617f3c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('873e1a40f4ae4cac3201998fa47f9945479416f74cdee5af7e6292b285046744',1979,'BJ','Benin','people-and-society',66,'Population: 3,333,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun — Beninese (sing. & pi.); adjective —
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans
18
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BENIN /BERMUDA
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions','d17e0f804d90df04070a0fc60cfe45f84e83f9b3aebfc344ea38d36223c5f9f1','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e32dc5a9dee702e68516a7697175420a81ff00c781e026dd5a5f7de00e71df21',1979,'BM','Bermuda','people-and-society',70,'Population: 60,000 (January 1979), average annual
growth rate 1.2% (7-70 to 7-76)
Nationality: noun — Bermudian(s); adjective — Bermudian
Ethnic divisions: approximately 59% black, 41% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)','e89881631d52d4d8dc1b845f58371a171d32f8a13786aedd132668025ca73e62','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5873be7550c30ae6b03f8bf51ca129f85187d9c854bd503536ca9a6030f6d37',1979,'BT','Bhutan','people-and-society',74,'Population: 1,282,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun — Bhutanese (sing., pi.); adjective —
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
20
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979 BHUTAN /BOLIVIA
Religion: 75% Lamaistic Buddhism, 25% Buddhist-
influenced Hinduism
Language: Bhotias speak various Tibetan dialects, most^
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,149,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun— Bolivian(s); adjective— Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
21
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BOLIVIA
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation','0cedd0fc3c634de07bd72de58d260575a5c657b6cc46b8ede84bc1e8d90d4d55','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13bbc90753ebaccf5f33dd4fe5cddb61e081f632be464b827458e7aa14d11a0e',1979,'BW','Botswana','people-and-society',78,'Population: 760,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun— Botswana (sing.), Batswana (pi.);
adjective — Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)
Population: 27,754,000, including Bophuthatswana and
Transkei (January 1979), average annual growth rate 2.5%
(7-75 to 7-76); Bophuthatswana 1,123,000 (January 1979),
average annual growth rate 2.2% (current); Transkei
2,214,000 (January 1979), average annual growth rate 2.2%
(current)
Nationality: noun — South African(s); adjective — South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 53% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); relatively small African
unions have no bargaining power','e205410004bc616f6e7af9fdfc72e39170a6ed58c4fe5a49786d8072019fa382','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d1e76968d71cd9e555c69a1d8baef2166a8f15ce6cecf500acf12205da47f1',1979,'BR','Brazil','people-and-society',82,'Population: 122,602,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun — Brazilian(s); adjective — Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
15.3% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 190,000 official estimate for 1 July 1977
Nationality: noun— Bruneian(s); adjective — Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
25
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
BRUNEI/ BULGARIA
January 1979
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force','3d4c50fede94c3a176dcec9656bae92df86e2bacd305fa3f70bda42e2806abbe','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ad0f511cb5f59d4240a3679368758b3639934053a979c8bc68e6765d3573f44',1979,'BG','Bulgaria','people-and-society',86,'Population: 8,871,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun — Bulgarian(s); adjective — Bulgarian
26
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 33,123,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun — Burman(s); adjective — Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages
Literacy: 70% (official claim)
Labor force: 12.2 million (1976); 67% agriculture, 9%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor organiza-
tions have been disbanded, and government is forming one
central labor organization','eae17e40daf622ac7639bb576f7b827d45f005afb592c2c5eaf94f09545e0b54','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ce12179d69da552343005faea16c7bbfa7146c8071a251a176a69aca9a53e03',1979,'BI','Burundi','people-and-society',90,'Population: 4,263,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun— Burundian(s); adjective— Burundian
Ethnic divisions: Africans — 85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
50,000 Zairians and 40,000 Rwandans; non-Africans include
about 3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animisl plus perhaps 2% Muslims
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
Organized labor: sole group is the Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting “active
membership’ have been unobtainable','c9f1519c48ce524289c8b5debdf05d9f9d73f14ed416e3c38d99f02d55ea92af','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbffee7cc0b37bd955d2f09666b0b9002e4880dee327b704a4f95f88b8e216a0',1979,'CM','Cameroon','people-and-society',94,'Population: 8,088,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: noun — Cameroonian(s); adjective — Came-
roonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 13% other African, less than 1%
non-African
Religion: about one-half animist, one-third Christian; rest
Muslim
Language: English and French official, 24 major African
language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','431bad8e70d513c9313734e64f89ad6beb54acd619b16786c09058bf32a292bf','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa320ec1cf70030c5d35dd73f76ef75b8324f0902cd2bb190b11ddd0a8dbd84',1979,'CA','Canada','people-and-society',98,'Population: 23,712,000 (January 1979), average annual
growth rate 1.1% (1-77 to 1-78)
Nationality: noun — Canadian(s); adjective — Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other
Religion: 48% Protestant, . 47% Catholic, 5% other
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
31
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Language: English and French official
Labor force: 11.1 million; 29% service, 22% manufactur-
ing, 16% trade, 8% transportation and utilities, 6% agricul-
ture, 6% construction, 8% other; 8.5% unemployment
(September 1978)
Organized labor: 30% of labor force
Population: 318,000 (January 1979), average annual
growth rate 1.9% (12-70 to 7-76)
Nationality: noun — Capeverdean(s); adjective — Capever-
dian
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words
Literacy: 14%
Labor force: bulk of population engaged in subsistence
agriculture
Population: 1,934,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun— Central African(s); adjective— Cen-
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 24% animist, 8%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
Language: French official; Sangho, lingua franca and
national language
Literacy: estimated at 5%-10%
Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force','d980c9e674e96c2db1055fa1ec58dd5c307cd50bc3d9432e9a6ba35c2c6cfee3','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c6a667cdf09837239c7283429ffacca425e5478f7c7e261b3ed8661f261957e',1979,'TD','Chad','people-and-society',102,'Population: 4,472,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun — Chadian(s); adjective — Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups — Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force','e8a90cd3fdbbcad341d45063027331a57acdcfc8559ee3a9ad43d825f4aa1271','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04cd04c4392ae62236cb98d8826f5a846880455cafce313728bd3e156f184bf9',1979,'CL','Chile','people-and-society',106,'Population: 10,770,000 (January 1979), average annual
growth rate 1.5% (current)
Nationality: noun— Chilean(s); adjective— Chilean
Ethnic divisions: 95% European stock and mixed
European with some Indian admixture, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1977)
Labor force: 3.7 million economically active (1977); 30%
agricultural, 29% industry and construction, 7% services,
10% commerce, 7% mining, 9% transportation, 8% other
(1977)
Organized labor: 25% of labor force (1973)','d238d0f4398e9ed0f5c7f7207f91d9bc21b7cc1bd3f34797f6471a7d4057f657','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec125a7c3776ab9483c3bef73cacee4f7395fd3a3be21f5e2290507cae157dd8',1979,'CN','China','people-and-society',110,'Population: 1,014,074,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun — Chinese (sing., pi.); adjective —
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2.%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 17,124,000, excluding the population of
Quemoy and Matsu Islands and foreigners (January 1979),
average annual growth rate 1.8% (1-77 to 1-78)
Nationality: noun— People of Taiwan; adjective — Taiwan
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 6.12 million (1978); 26.2% primary industry
(agriculture), 39% secondary industry (including manufac-
turing, mining, construction), 34,8% tertiary industry (in-
cluding commerce and services) 1977; 2% unemployment
(1976)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
39
Approved For Release 2004/06/24 : CIA-RDP79-01051A001 00001 0001 -5
January 1979
TAIWAN /COLOMBIA
labor: about 12% of 1972 labor force
Electric power: 7,100,000 kW capacity (1977); 30 billion
1 1 Q771 1 780 kWl.
Organized
(government controlled)
Population: 39,206,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun — Korean(s); adjective — Korean
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority (16.6%
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 12.9 million (1977); 42% agriculture,
fishing, forestry; 22% mining and manufacturing; 36%
services and other; average unemployment 3.8% (1977)
Organized labor: about 13% of nonagricultural labor
force','5cadd8d1d4e2bcf0319cf46e841a191f9a2571cc5c3a9e0d3736567ba5f78049','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('570ade14d8c20039fd62c78bd2d9b155d5fbac1c06b22aa01986566808ebb596',1979,'CO','Colombia','people-and-society',114,'Population: 25,837,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun— Colombian(s); adjective— Colombian
Ethnic divisions: 58% mestizo, 20% Caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-13% unemployment (1975)
Organized labor: 13% of labor force (1968)','9b7eaa9a348e177dde8bdc935f5b37e827ad524c973a8f5e0f56ec610369d1cb','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('148670407d1178860c7f06310c7169aacb2fd9dc81a90e6676f0e2d709ce9566',1979,'KM','Comoros','people-and-society',118,'Population: 320,000 (January 1979), average annual
growth rate 2.1% (current)
Nationality: noun — Comoran(s); adjective — Comoran
(See reference map VI)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural
Population: 1,484,000 (January 1979), average annual
growth '' rate 2.7% (current)
Nationality: noun— Congolese (sing., pi.); adjective—
Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north, about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically
active, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','09ddda88b5382ce7a4268c2be9dada24141e3f32868aeda1417f515f2f2523f3','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b092509675d112c93344963778db3442810983c91a283c65e0f3bfaec196f86d',1979,'CK','Cook Islands','people-and-society',122,'Population: 18,000 (total from the census of 1 December
1976)
Nationality: noun— Cook Islander(s); adjective— Cook
Islander
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','0e6e6da2e8c4e231cf9421ed9d382837f59e5210d185956d2cee79f8015ebd65','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbe4aef467642a840e25490d0499539a1e914d2d4f01b90d85d60663fb388657',1979,'CR','Costa Rica','people-and-society',126,'Population: 2,144,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun — Costa Rican(s); adjective Costa
Rican
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 657,709 (1976); 32.6% agriculture; 13.8%
manufacturing; 15.3% commerce; 6.1% construction; 5.2%
transportation, utilities; 20.3% service (government, educa-
tion, social); 0.5% other; 6.2% unemployment (1976)
Organized labor: about 11.5% of labor force','28f75b4668b2b54661438de52b761de27592abf5159e8887d5e04c6a3338f8ef','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71fe246f654a557c066858c9a6533a3e7f0e72ef008e719a145beb4d4bec0b5e',1979,'CU','Cuba','people-and-society',130,'Population: 9,874,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun — Cuban(s); adjective — Cuban
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
46
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
CUBA/CYPRUS
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.7 million in 1976; 33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed','35f62d4a07f3209c01b3e90df2d827d482e49702fe8a936c543d1982d8d6b0e5','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('839e56f44f3512ba3f7aab13fc44816137b2d3f91be124930fb8e9bd5991f5cd',1979,'CY','Cyprus','people-and-society',134,'Population: 642,000 (January 1979), average annual
growth rate 0.2% (7-76 to 7-77)
Nationality: noun — Cypriot(s); adjective — Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Maron-
ite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Greek Sector labor force: 207,700 (1976), 22% agricul-
ture, forestry, fishing; 14% manufacturing; 6% construction;
1% mining and quarrying; 14% services; 10% trade and
finance; 3% transportation and communications; 5% public
administration, 25% other; unemployment 4% (1977)
Turkish Sector labor force: 179,400 (145,900 employed,
33,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)
Population: 15,189,000 (January 1979), average annual
growth rate 0.7% (current)
Nationality: noun— Czechoslovak(s); adjective — Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
49
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
CZECHOSLOVAKIA
January 1979
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others','a79b265c7879115828f60b3f03de672e890d768bc993e692e976979745b1df16','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e46303940d64ea598a6bc0e80ff4521f2f2f93be0d7719d5aaf29cfff83f5e9',1979,'DK','Denmark','people-and-society',138,'Population: 5,112,000 (January 1979), average annual
growth rate 0.3% (current)
Nationality: noun — Dane(s); adjective — Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2,579 million (October 1977); 8.6% agricul-
ture, forestry, fishing, 24.6% manufacturing, 8.1% construc-
tion, 15.4% commerce, 6.6% transportation, 5,4% services,
29.3% government, 2.0% other; 6.4% (164,000) registered
unemployed as percentage of total labor force (1977 annual
average)
Organized labor: 65% of labor force','124483f12daed09404a794a2a0dff2464b9754d5c341d7fb53a258cfdac9d0bd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d7ba90359b2b21e1c805212664347372f4b97585a7b9cc528ee72f57f926913',1979,'DJ','Djibouti','people-and-society',142,'Population: 180,000 (official estimate for 1972)
Nationality: noun — Afar(s), Issa(s); adjective — Afar, Issa
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
52
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
DJIBOUTI/ DOMINICA
Organized labor: some 3,000 railway workers organized','dded0f1737a6c28c92f01c19425ad1191ddbc1c153c578fa59aeb9dd703a907c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5c171a03ea6f372915fff31c1109545943b5330d978638b613e64a8b697e3c3',1979,'DM','Dominica','people-and-society',146,'Population: 78,000 (January 1979), average annual
growth rate 0.7% (1-75 to 1-77)
Nationality: noun — Dominican(s); adjective — Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture; 24%
unemployment
Organized labor: 25% of the labor force','3c123799e59311d5ab55a9f972a1cf5fa341acbe727ee3ef1ff16c8350c08fe2','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61479df037756005c3cc5b107375832f9fe7835ca44ccba8c65e5a52c4559d1b',1979,'DO','Dominican Republic','people-and-society',150,'Population: 5,466,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun — Dominican(s); adjective — Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force','9b4693cb2906f103f7f5152441a5f28f99337f75a71f6f79ec89c6251d98ffd7','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfff9a1644be519584317cdd89b749c879979175ae2aa9418b243ef75be52945',1979,'EC','Ecuador','people-and-society',154,'Population: 7,665,000, excluding nomadic Indian tribes,
(January 1979), average annual growth rate 3.0% (current)
Nationality: noun — Ecuadorean(s); adjective — Ecuador-
ean
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
55
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other services and activities
Organized labor: less* than 15% of labor force','1677f0ce51077d0b8056c985817544c305ef34f569e7a6c309c8ef341e7f03d8','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a9510aa45afefe98110879a57f089e37f194c5dedd14004ef816cf73bdbf88a',1979,'EG','Egypt','people-and-society',158,'Population: 40,424,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun — Egyptian(s); adjective— Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
Labor force: 12 million; 45 to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and other;
shortage of skilled labor
Organized labor: 1 to 3 million','8218b3de5c24fff846e353afd847f2c7c674a72f91adcb8e5b286f96d6d1b448','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4583a48190a1a7979bad44e97b4bb3c4d3ec4bf4fe37fb7ceae9ea42c76f24a',1979,'SV','El Salvador','people-and-society',162,'Population: 4,580,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun — Salvadoran(s); adjective — Salvadoran
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably
97% -98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','f57c7cec0991fd176dc83c9456c607221082af9e7e0bea3fe421519cd5133372','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3eb89191b94868f5e63f988c8cdee1d87cc2b7f5333674dfd7f87ebd051a18c',1979,'GQ','Equatorial Guinea','people-and-society',166,'Population: 339,000 (January 1979), this estimate does not
take into account emigration from Equatorial Guinea during
the last several years, average annual growth rate 1.8% (7-68
to 7-69); llio Muni, 237,000, average annual growth rate
1.5% (7-68 to 7-69); Fernando Po, 102,000, average annual
growth rate 2.6% (7-68 to 7-69)
Nationality: noun — Equatorial Guinean(s); adjective —
Equatorial Guinean
Ethnic divisions: indigenous population of Province
Macias Nguema Biyogo, primarily Bubi, some Fernaridinos;
of Rio Muni primarily Fang; less than 1,000 Europeans,
primarily Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 20%
Labor force: most Equatorial Guineans involved in
subsistence agriculture','a9aab79d6e2fe9360e5c21f5d3078942e18b0386365a4d496a67f043a4549a1b','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f2cc62e92b086a02c8c662cde30ea572c67f9b3202ce4a1c8904ed1d30a653',1979,'ET','Ethiopia','people-and-society',170,'Population: 31,341,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun — Ethiopian(s); adjective — Ethiopian
60
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: Galla 40%, Arnhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1 %
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized labor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','87f7d9bfd2d51c9312f2da46e721d184c90f02a5f218fe9a3afb1dabee83c4c3','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceafd08ef9617482c68b3dc23154bbf5618b4812431ebd905dbf12bf379bbc6d',1979,'DE','Germany','people-and-society',175,'Population: 2,000 (official estimate for 31 December
1977)
Nationality: noun— Falkland Islander(s); adjective— Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding
Population: 35,808,000 (January 1979), average annual
growth rate 3.0% (current)
Nationality: noun — Iranian(s); adjective — Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 13%
other Iranian, 18% Turkic, 3% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha’is
Language: Persian (Farsi), Turkish dialects, Kurdish,
Arabic
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976; 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial
Population: 43,767,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun— Turk(s); adjective— Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled l abor ( 1978)
Organized labor: 12% of labor force','bdf304a9779c1f2145126fc2fc274bb94d2936b2d80541f2b76e9c378f854b99','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff6dda18dd61401af880099fd5583f7572fa3c3a5e768d4dd77a279fa6b509f6',1979,'IS','Iceland','people-and-society',178,'Population: 43,000 (January 1979), average annual
growth rate 1.4% (1-75 to 1-77)
Nationality: noun — Faroese (sing., pi); adjective
Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce
Population: 224,000 (January 1979),- average annual
growth rate 0.7% (12-76 to 12-77)
Nationality: noun — Icelander(s); adjective — Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 90,000; 22.6% agriculture and fishing; 25.6%
mining and manufacturing; 10.7% construction; 12.8%
commerce; 7.8% transportation and communications; 15.2%
services; and 5.7% other; unemployment 1977, 0.6%
Organized labor: 60% of labor force','bce9c786603df2e8a9861dd4efddb3894c2a829ae71701ef57831bb39f48d90c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('631ddc4b1075fd7bd3054f22d7e6406ebdcf6478bd8a456fb33d582c72ecd8e2',1979,'FJ','Fiji','people-and-society',182,'Population: 615,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun— Fijian(s); adjective — Fijian
Ethnic divisions: 44% Fijian, 50% Indian, 6% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation','657d71853592e7a0f59fc299ecb36dfbce449f0ec06ec52555c91360288b470c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97c0f3a3e76979d5d3c15051630ac64eb8285afccc7aae50aff874f76aa92412',1979,'FI','Finland','people-and-society',186,'Population: 4,755,000 (January 1979), average annual
growth rate 0.3% (1-77 to 1-78)
Nationality: noun — Finn(s); adjective — Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture, forestry, and
fishing, 26.4% mining and manufacturing, 8.4% construc-
tion, 15.4% commerce, 6.8% transportation and communica-
tions, 4.0% banking and finance, 20.1% services; 6.1%
(136,000) unemployed 1977 annual coverage
Organized labor: 60% of labor force','fb18704c66a8cdc4a6c49eda4463f6b087cf4843774545a5922fe85112a5e4cd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af6141bc37e2db45dc2c91740e18a4ba5407aa3ca6b323dc8cf87073cf3d3bff',1979,'FR','France','people-and-society',190,'Population: 53,536,000 (January 1979), average annual
growth rate 0.6% (current)
Nationality: noun — Frenchman (men); adjective —
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois — Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22 million (est. in mid-1977); 47% services,
38% industry, 11% agriculture, 5% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force
Population: 7,431,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun — Rhodesian(s); adjective — Rhodesian
Ethnic divisions: 96% African, less than 4% European,
less than 0.5% coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also
widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some
migrants from Zambia and Malawi), 108,000 Europeans,
Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40%
transport and services
Organized labor: about one-third of European wage
earners are unionized, but only a small minority of Africans
(1966)','128935babf32b73e1f21ff30469688a95c0c0aedeb66ed3068f16e2522e1c08f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e1ca791c34ca3f5f391013dc4cd98ada62e27f3a6b8e3861eedc38a280641cd',1979,'GF','French Guiana','people-and-society',194,'Population: 60,000 (January 1979), annual growth rate
2.2% (10-74 to 11-77)
Nationality: noun — French Guianese (sing., pi ); adjec-
tive — French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% Caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force','01c3fb563babde54bcc846ccb28e5d7fdae47425b8f50ebdae8fd997535226db','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ea407992b1370a77254fc8a4e9078a35323c2b774e4646bae95f8416cbcc98b',1979,'PF','French Polynesia','people-and-society',198,'Population: 143,000 (January 1979), annual growth rate
2.3% (current)
Nationality: noun — French Polynesian(s); adjective —
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic','11846460cef3f9260ae2944366b5227d1d4789eb363ae71d9d5d0499ca71d3c9','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c812cfdf12a220a8e9f9918e29eed9d2170454bc2f54058ff40b23c5ea7fb2f5',1979,'GA','Gabon','people-and-society',202,'Population: 575,000 (January 1979), average annual
growth rate 1.7% (7-66 to 7-70)
Nationality: noun — Gabonese (sing., pi.); adjective —
Gabonese
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 30,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage
earners in the modern sector
Organized labor: less than 30% of wage labor force','a4ef9295d1c5000bd4a708736f87848bef0a527f6309795e4f5f3cdca8988944','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7536f8f8653c2529c0dc4ec7f3c37fe2ccf124d06a8fe5b2db5078f1d6071041',1979,'GM','Gambia','people-and-society',206,'Population: 576,000 (January 1979), average annual
growth rate 2.7% (7-76 to 7-77)
Nationality: noun — Gambian(s); adjective — Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
71
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Labor force; approx. 165,000, mostly engaged in subsist-
ence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor; 25% to 30% of wage labor force at most
Population: 16,783,000, including East Berlin (January
1979), average annual growth rate 0.1% (current)
Nationality: noun — German(s); adjective— German
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction; 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16.8% services; 2.5%
other
Organized labor: 87.7% of total labor force
Population: 61,262,000, including West Berlin (January
1979), average annual growth rate —0.1% (current)
Nationality: noun — German(s); adjective — German
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners','9596455b55758975ec26397439ae82c9985839cb988a0d663c3e31f566906b5f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49cdd7b81ff97e16e7f3055d6a09f88029812607aa8817c2efea46f30e8d3660',1979,'GH','Ghana','people-and-society',210,'Population: 11,553,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun— Ghanaian(s); adjective— Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8 %
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
75
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
GHANA/ GIBRALTAR
January 1979
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation, and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force','d99bdd07ff742460dc8fc880e5347a65748cbd3d0b43433d47582d2d7fdcec03','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fa6aa0ec3c2c9be33533504faf95784fb915d51a2367ef5813df9ab60c51268',1979,'GI','Gibraltar','people-and-society',214,'Population: 30,000 (official estimate for 1 July 1977)
Nationality: noun — Gibraltarian; adjective — Gibraltar
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
76
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GIBRALTAR/GILBERT ISLANDS
(See reference map IV )
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000
Population: 52,000 (preliminary total from census of 8
December 1973)
Nationality: noun — Gilbcrtese or Gilbert Islander(s);
adjective— Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%','23f7e6159719feec927ee8ca2803ad10ad2c68ac449b11b1f75f8186da1857e6','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b2c9751624335d1fdf0d2d329c3ddc7ca8d3a628aa39fb142275e64e5c4c6ac',1979,'GR','Greece','people-and-society',218,'Population: 9,372,000 (January 1979), average annual
growth rate 0.6% (7-67 to 7-77)
Nationality: noun — Greek(s); adjective — Greek
Ethnic divisions: 96% Greek, 2% Turkish, 2% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total
about 82%
Labor force: 3,400,000 (1975 est. ); 40.5% agriculture,
25.6% industry, 33.7% services; unemployment 3%, but there
is substantial underemployment in agriculture
Organized labor: 20% of labor force est.','945e37ed0f427b7d9f7b7b36c08be40e9f52281226374f3e89f09393695947d8','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f14529da50a407277c7154abf2045dc169c8abc6c4f3fd0f3d06886b904c97c7',1979,'GL','Greenland','people-and-society',222,'Population: 50,000 (January 1979), average annual
growth rate 0.2% (1-75 to 1-77)
Nationality: noun — Greenlander(s); adjective — Green-
land
Ethnic divisions: 86% Greenlander (Eskimos and Green-
land-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','9d1ad83c7be51de31a22988297afbe1fb047a3df736686277d740e15c9467002','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6086f542315cd96a6c88d3828c24a432fbddd1777019caaf0aeea3196bd50c09',1979,'GD','Grenada','people-and-society',226,'Population: 106,000 (January 1979), average annual
growth rate 1.4% (4-70 to 7-77)
Nationality: noun — Grenadian(s); adjective Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','007bb40e4acccb60e4895da367d30f320f0c8353b963d29814ef79a540b8a34d','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2745403c464bcc5b93b6c692972e03a957813e73d63501642941e057d0526ff',1979,'GP','Guadeloupe','people-and-society',230,'Population: 324,000 (January 1979), average annual
growth rate 0.3% (10-67 to 1-76)
Nationality: noun — Guadeloupian(s); adjective — Guade-
loupe
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','570bd2875c52a86547d1947ef9ca9a5113492bf8c70266596e4d4463b729209c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7129983a7a3c684d06296295e78690a2b074cc48821170031f0aada29ccb9ca4',1979,'GT','Guatemala','people-and-society',234,'Population: 6,716,000 (January 1979), average annual
growth rate 2.9% (7-76 to 7-77)
Nationality: noun— Guatemalan(s); adjective — Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 30%
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)','f23f94759077df9cbe19ed79160a930631c0411b88c78dd42621dbb5bd412ac9','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc58b8dcdf5cad4c6505d3cb3ca7e35c41de2a4b50c5a285c8aa8c387acc4647',1979,'GN','Guinea','people-and-society',238,'Population: 5,973,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun — Guinean(s); adjective — Guinean
Ethnic divisions: 99% African (3 major tribes — Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1 %
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language
84
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GUINEA/ GUINEA-BISSAU
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of
Guinean Workers, which is closely tied to the PDG','402e5f2b01aaa083fb7a05a9d547db885ce3be22dc80506e0ca4ff0ad21a847b','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('262e53cf47e3e5e0901ba94399b225e1cd8ad6d7328f1073da0e04879597e4e5',1979,'GW','Guinea-Bissau','people-and-society',242,'Population: 625,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun — Guinean(s); adjective — Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
85
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GUINEA-BISSAU /GUY AN A
Language: Portuguese and numerous African languages
Literacy: 3% to 5 %
Labor force: 90% of economically active population
engaged in subsistence agriculture','a708daa6a754d3388e4ebd0b1ffa093e4dd9dbbb1344cfd2f308eb23a287448c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('483cec4255f10e9aee6b759e535c554aa49cbc53705d43172772f35f1f6983a9',1979,'GY','Guyana','people-and-society',246,'Population: 818,000 (January 1979), average annual
growth rate 1.3% (current)
Nationality: noun — Guyanese (sing., pi.); adjective
Guyanese
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86%
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force','36642e7d34458b61159b8ee7aaa5c1e0414b7149828348ebc395186c092ad015','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8a3663e5868ca163d8e785719265ef4e1cebbe5d518ec518e63d8b10afd0063',1979,'HT','Haiti','people-and-society',250,'Population: 5,600,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun — Haitian(s); adjective — Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant
Organized labor: less than 1% of labor force','83c9104bd20428134ca7391333a01dc8c352b146f0e1c43efac96d0128d2ee50','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d593840311ddd03c3edab558d14ca6bfbd4c85708285c1d536870d4cf0a163da',1979,'HN','Honduras','people-and-society',254,'Population: 3,578,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun — Honduran(s); adjective — Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-19/2)','9202eb466b11b078ae043dbe4f71718da1445ad0ae5e18461265eca88b24e483','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('278e997b74b7ca6e8c51a2fee1253ced715a78bacc81dc92c6545774576aec76',1979,'HK','Hong Kong','people-and-society',258,'Population: 4,622,000 (January 1979), average annual
growth rate 1.6% (7-76 to 7-77)
Nationality: adjective — Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions
Language: Chinese, English
Literacy: 75%
Labor force (1976 Census): 1.87 million; 45.3% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.7% other;
underemployment is a serious problem
Organized labor: 21% of 1976 labor force
90
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
HONG KONG/HUNGARY','1f7a9a7c06c351d4fbf04b74940da5609bab5d7b01c3e505a81075a7a9b138da','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('005031fa9c14b35fceecffea88e24b01f4695073b69f28b66f2a2fe9f3ecbb9c',1979,'HU','Hungary','people-and-society',263,'Population: 10,715,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun— Ilungarian(s); adjective— Hungarian
Ethnic divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,230,000 (1977); 20% agriculture, 34%
industry and building, 46% other non-agriculture
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
91
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
January 1979','938c3ecad8d1fa829586f9fc7ab6830f85242b36572974045ea77dbc44a824f2','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd74f68f2148210fd2e4b27c1099838dead9d2e75576b0efe07a7c1da74540c',1979,'IN','India','people-and-society',268,'Population: 667,907,000, including Sikkim and the
Indian-held part of disputed Jammu-Kashmir (January
1979), average annual growth rate 2.2% (current)
Nationality: noun — Indian(s); adjective — Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys “associate” status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force','2202f14fc8f4f9d7bb91d752b19f30a48860d99b6dd7ff50423db17063a59f17','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c13eba5a7819a3b16e9cba0cde3653f34870ba945b5668d95c4d68599bf303',1979,'ID','Indonesia','people-and-society',273,'Population: 145,958,000, including East Timor and West
Irian (January 1979), average annual growth rate 2.1%
(current)
Nationality: noun — Indonesian(s); adjective — Indonesian
Ethnic divisions: majority of Malay stock comprising 45%
Javanese, 14% Sundanese, 7.5% Madurese, 7.5% coastal
Malays, 26% other
Religion: 90% Muslim, 5% Christian, 3% Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 55 million; 64% agriculture, 12% trade, 7%
industry, 17% other
Organized labor: 10% of labor force','8684fc0788e9a6a25babc11f829fe926fe7d890c62cf5b0170bfe901b6ac188a','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('090f173c91612b11b1e12d1ba92632eb4c807e7eb7e74173143850a7d88d182a',1979,'IQ','Iraq','people-and-society',277,'Population; 12,689,000 (January 1979), average annual
growth rate 3.4% (current)
98
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
IB AQ/ IRELAND
Nationality: noun— Iraqi(s); adjective — Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0,7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim (50% Shiah Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force','0d63644d6dce6a67db8595e5f9b70c60fc6cd6aa677b61520b08875fd6e084e6','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b6c7584afd9ff563bd26f5de69f6066330afbe807e0abd540a8218ab4e2327',1979,'IE','Ireland','people-and-society',281,'Population: 3,242,000 (January 1979), average annual
growth rate 1.0% (7-75 to 7-77)
Nationality: noun — Irishman! men), Irish (collective pi.);
adjective — Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99%
Labor force: about 1,143,000 (1976); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
9.8% unemployment (February 1976)
Organized labor: 36% of labor force','00e2c8704c790272c07e2650f517cf9634db49d146162c3a3fb2cd01217a2164','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e549050ef814d6858be30a11697b6905ac4af87feea1c9d0969819e89257718',1979,'IL','Israel','people-and-society',285,'Population: 3,712,000, excluding East Jerusalem and the
other occupied territories (January 1979), average annual
growth rate 2.4% (1-77 to 1-78)
Nationality: noun— Israeli(s); adjective— Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry and
fishing; 25.3% manufacturing (mining, industry); 0.9%
electricity and water; 8.1% construction and public works;
12.2% commerce; 7.7% transport, storage, and communica-
tions; 6.5% finance and business; 26.1% public services; 6.7%
personal and other services (1974)
Organized labor: 90% of labor force','2eea33b1c1858f86455b249fa3f6e325c6ab6657936ebc7eabdbc4ebc2342fd8','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5c84d67ce25dc3a31e99228f17af46ed2134b62c78bc0e5b6bdc8a44b561b1',1979,'IT','Italy','people-and-society',289,'Population: 56,867,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun — Italian(s); adjective Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
102
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d ’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972); illiteracy
varies widely by region
Labor force: 20,125,000 (July 1978); 15.0% agriculture,
42.9% industry, 39.0% other (1975); 7.1% unemployment
(1978); 1.5 million Italians employed in other Western
European countries
Organized labor: 50-55% (est.) of labor force
Population: 7,365,000, resident African population only,
(January 1979), average annual growth rate 2.7% (current)
Nationality: noun — Ivorian(s); adjective — Ivorian
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately
2 million foreign Africans, mostly Upper Voltans; about
75.000 to 90,000 non- Africans (50,000 to 60,000 French and
25.000 to 30,000 Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in government, industry, commerce, and professions
Organized labor: 20% of wage labor force','ee7ca41c00e931000d1cc318b8618e39947c43a32f9ce06b385c893d487a7d06','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a83f5d003eff7d06cf90966e699aac10ba6f52e2fe9fe1a35243419a41e6bd6',1979,'JM','Jamaica','people-and-society',293,'Population: 2,217,000 (January 1979), average annual
growth rate 1.4% (current)
Nationality: noun— Jamaican(s); adjective — Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
105
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
January 1979
(See reference map II)
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 672,000 (1975); 29% in agriculture, forestry,
fishing and mining, 12% manufacturing/mining, 8% public
administration, 5% construction, 10% commerce, 3% trans-
portation and utilities, 33% services; 25% unemployed;
shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)','e3fc07064ce6d65576fe9eae5daa70d7a84924852b8fb596a9eb76bfb4af130f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55527b2eae816a9ee262c93db2711993b05889c4330b8367759434bdb1c2f0e7',1979,'JP','Japan','people-and-society',297,'Population: 115,493,000, including Ryukyus (January
1979), average annual growth rate 1.0% (current)
Nationality: noun— Japanese (sing., pi); adjective—
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data)
Labor force (1977): 54.5 million; 11% agriculture,
forestry, and fishing; 34% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33.7% of labor force
Population: 3,008,000, including West Bank and East
Jerusalem (January 1979), average annual growth rate 3.2%
(7-70 to 7-76); East Bank, 2,224,000, average annual growth
108
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
JORDAN /KAMPUCHEA
January 1979
rate 3.6% (7-70 to 7-76); West Bank, including East
Jerusalem, 784,000, average annual growth rate 1.9% (1-71
to 1-77)
Nationality: noun— Jordanian(s); adjective — Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force
Population: 8,087,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun — Kampuchean(s); adjective — Kampu-
chean
Ethnic divisions: 90% Khmer (Kampuchean), 5% Chi-
nese, 5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','fdac97fac79e0cc6fc1fc5bacd074ace50cb86059771be18b609317715626142','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0ed77e22a1c82fde2c6529906e81031694e38c749e2a95e62abc61b01860999',1979,'KE','Kenya','people-and-society',301,'Population: 15,096,000 (January 1979), average annual
growth rate 3.6% (current)
Nationality: noun — Kenyan(s); adjective — Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic); 2% Asian; 1% Euro-
pean, Arab, and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 18,421,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun — Korean(s); adjective — Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6. 1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor
Population: 57,000 (January 1979), average annual
growth rate 1.1% (7-76 to 7-77)
Ethnic divisions: mainly of African Negro descent
Nationality: noun — Kittsian(s), Nevisian(s), Anguillan(s);
adjective — Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 120,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun — St. Lucian(s); adjective St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture; 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 112,000 (January 1979), average annual
growth rate 1.8% (4-60 to 1-76)
Nationality: noun— St. Vincentian(s) or Vincentian(s);
adjectives — St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force','603248cc7be88b342919da30ff0b085c6dffe25a09bd368b51620edbee2ee07d','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('573ffe44099d07e2637e34012cd637ebf2eaba196f7761b72d4dad845a8936c1',1979,'KW','Kuwait','people-and-society',305,'Population: 1,241,000 (January 1979), average annual
growth rate 5.9% (current)
114
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
KUWAIT/LAOS
January 1979
Nationality: noun — Kuwaiti(s); adjective — Kuwaiti
Ethnic divisions: 85% Arabs, 13% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 340,000 (1976 est.); 26% manufacturing, 25%
services, 35% government and professions, 9% commerce,
5% oil industry; two-thirds of labor force is non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
Population: 3,587,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun — Lao (sing., Lao or Laotian); adjec-
tive — Lao or Laotian
Ethnic divisions: 48% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 13% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
115
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
LAOS
January 1979
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party','4978dd4e731ece107f4029ba17a221318cc4d32340fbdb4d4cd006b51625bf9b','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc8c58c5dd1a940cbbd3053d9d69a9efc05a5687d9a0285222fa3477a2d416a0',1979,'LB','Lebanon','people-and-society',309,'Population: 2,568,000 (January 1979), average annual
growth rate 2,3% (current)
Nationality: noun— Lebanese (sing, and pi ); adjective
Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
Approved For Release 2004/06/24 :
NOTE: Between early 1975 and late 1976, Lebanon was
torn by civil war between its Christians then aided by
Syrian troops— and its Muslims and their Palestinian allies,
The cease-fire established in October 1976 between the
domestic political groups has generally held, despite
occasional fighting, although the country is still under the
occupation of Arab peacekeeping forces, almost entirely
Syrian. In March 1978 southern Lebanon was invaded by
Israeli troops. When the Israelis withdrew in June, they
turned much of the south over to a United Nations interim
force, but left Christian militias in control of zones along the
border. The country’s own army is gradually being re-
established but is still too fragile to give the central
government effective power. Israel’s support of the Chris-
tians and Syria’s recent support of the Palestinians have
brought the two sides into rough equilibrium, but no
progress has been made on national reconciliation or
political reforms— the original cause of the war. The
following description is based on the present constitutional
and customary practices of the Lebanese system.
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and
civil law system; constitution mandated in 1920; no judicial
review of legislative acts; legal education at University of
Lebanon; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 22 November
Branches: power lies with President elected by parlia-
ment (Chamber of Deputies); cabinet appointed by Presi-
dent, approved by parliament; independent secular courts
on French pattern; religious courts for matters of marriage,
divorce, inheritance, etc.; by custom. President is a Maronite
Christian, Prime Minister a Sunni Muslim, and president of
parliament a Shia Muslim; each of 9 religious communities
represented in parliament in proportion to national numeri-
cal strength
Government leader: President Ilyas Sarkis
Suffrage: compulsory for all males over 21; authorized for
women over 21 with elementary education
Elections: Chamber of Deputies held every 4 years or
within 3 months of dissolution of Chamber; latest April 1972
Political parties and leaders: political party activity is
organized along sectarian lines; numerous political groupings
exist, consisting of individual political figures and followers
motivated by religious, clan, and economic considerations;
all parties have well-armed militias which are still involved
in occasional clashes
117
CIA-RDP79-01 051 A001 00001 0001 -5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
LEBANON /LESOTHO
January 1979
Communists: only legal Communist party in Middle East;
legalized in 1970; members and sympathizers estimated at
2,000-3,000
Other political or pressure groups: Palestinian guerrilla
organizations
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, IWC—
International Wheat Council, NAM, U.N., UNESCO, UPU,
WHO, WMO, WSG, WTO','47bdec50df0e285361417358efb07991f41d4b91e7660be71893d22d8f97c83c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925e45898c4bfabac6d63dd5a6e2dc09182aec51b281fe067b38c734114d5d69',1979,'LS','Lesotho','people-and-society',312,'Population: 1,291,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun — Mosotho (sing.), Basotho (pi.); adjec-
tive — Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible','d35549ef2f6ddd561d9baae63eb8da7f377dc6f8e47a2aeac0b80404d237db72','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8a31c7be03364c9ef847f414f9b2a09b14d8d61841a4ba043bf02c1f7e4c95d',1979,'LR','Liberia','people-and-society',316,'Population: 1,761,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun — Liberian(s); adjective— Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor: 2% of labor force
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
119
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
LIBERIA/LIBYA
January 1979','07cd040c1cee1187da7426940d4c3f99a7bc872beaf462bd8e9806725fc92c5e','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc3cf9c8ddb28c3fc666f111694e7951a2c09af0ab7f368d98d1d313ae9dd7ea',1979,'LY','Libya','people-and-society',320,'Population: 2,816,000 (January 1979), average annual
growth rate 4.1% (current)
Nationality: noun— Libyan(s); adjective— Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','1ec2f46bb1263a7c663c0085aeff7c5837d538b496628ae82ebc4a5ccb54ffb8','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33ea0397277dcf6bd6674583f26c7f38692e37d3d8207287199809e5e1651cc6',1979,'LI','Liechtenstein','people-and-society',324,'Population: 22,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun— Liechtensteiner(s); adjective —
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce,
13% professional and other, 8% agriculture','f7f9cc0f790e10cf0622bbad9e84332121f43ce9bbc8712454117474e55a6060','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3138343a04339f2a634b4c884e812773b66de1b3ee549cdb81481f6def7b0e5d',1979,'LU','Luxembourg','people-and-society',328,'Population: 358,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun — Luxembourger(s); adjective — Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1977) 147,300; one-third of labor force is
foreign, comprised mostly of workers from Portugal, Italy,
France, Belgium, and West Germany (1977); unemployment
0.2% (1977)','dfe306477e4686be261b96335129412a3432c9155e59d6644ee751c082a07d0a','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96a32455665ac00038809733724187056cb15cb98a99c18aafc7d445aebd49bd',1979,'MO','Macao','people-and-society',332,'Population: 285,000 (January 1979), average annual
growth rate 1.5% (current)
Nationality: noun — Macaon(s); adjective — Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about
one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)','48fb30456e71d3b3cb2e58e7bd4e606945f953d12460e2763e068ce9c0645091','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f2ec04bb96c75ee96720592359d7bd5e95048ed35e90db7114b12e03dd1edc2',1979,'MG','Madagascar','people-and-society',336,'Population: 8,258,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun— Malagasy (sing, and pi.); adjective—
Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Mer-
ina (1,643,000) and related Betsileo (760,000), on the one
hand, and coastal tribes with mixed Negroid, Malayo-Indo-
nesian, and Arab ancestry on the other; coastal tribes include
Betsimisaraka 941,000, Isimihety 442,000, Sakalava
375,000, Antaisaka 415,000; there are also 10-12,000
European French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
laneous
Organized labor: 4% of labor force','af480c01310f4e9c3a40e6517b71cb8417fc8ec4240286504f3d98d603231e43','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7463fa6e571f1627f34dc150733f8ec5f604244fe93bb67ed2515f4f2b3ab29f',1979,'MW','Malawi','people-and-society',340,'Population: 5,777,000 (January 1979), average annual
growth rate 2.9% (8-66 to 10-77)
Nationality: noun — Malawian(s); adjective— Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
13% manufacturing, 10% administration, 26% miscellaneous
services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized','404449fffa009b0f05799c516afaaaf2c6644de4befc950e64ffaf23c0960536','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af1905d4602f6ff9dfa669ec714110fec4d3d179b7e9c0535111aa933c5a0240',1979,'MY','Malaysia','people-and-society',346,'Population: 13,099,000 (January 1979), average annual
growth rate 2.8% (current)
Peninsular Malaysia: 10,926,000, average annual
growth rate 2.6% (8-70 to 1-77)
Sabah: 967,000, average annual growth rate 4.8% (8-70
to 1-77)
Sarawak: 1,206,000, average annual growth rate 2.6%
• (8-70 to 1-75)
Nationality: noun — Malaysian(s); adjective — Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 53% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sahah: 21% Chinese, 69% indigenous tribes, 10% other
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas
128
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979','8d1f91dbc60109a26239cf53570bd51aea7d653f4103992f6e8f9531824dbd36','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f393cb5acf23ac2bdd2cd3c57bdaef323fbd4cb76c3bd35e598476f1dbc359af',1979,'MV','Maldives','people-and-society',352,'Population: 143,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun — Maldivian(s); adjective— Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population','43338ccb03893c44c4d80c421f59a0a7db11180645beb14768f453a3ca7204dd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2540bbf515e86e06d10c69e3473c3305895186081ff6ac1922921aed97bc0d3d',1979,'ML','Mali','people-and-society',356,'Population: 6,287,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: noun — Malian(s); adjective — Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions','f971641a5659ee2b587e918da2afed22f98aff4b9f91abb8438b8671438358ad','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa2268c2027ab15556aa4823946922cc80ce14cc7eff6a38476707b539eec8b',1979,'MT','Malta','people-and-society',360,'Population: 326,000 (official estimate for 31 December
1977)
Nationality: noun Maltese (sing, and pi.); adjec-
tive Maltese
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Labor force: 119,554 (November 1977); 32% services
(except government), 18% government (except job corps),
5% job corps, 26% manufacturing, 6% agriculture, 3%
construction, 5% utilities and drydocks; 4% registered
unemployed
Organized labor: approximately 40% of labor force','dec7fcd589d9c7e253c78a48d560e0df8a8f98ade01bbc9a8ef470fc1d767858','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('499692bf84224285a0e671fcb520a79bcaf804571a149ffc1b83e8db8ae9f900',1979,'MQ','Martinique','people-and-society',364,'Population: 319,000 (January 1979), average annual
growth rate -0.0% (10-67 to 1-77)
Nationality: noun Martiniquais (sing, and pi.); adjective
Martiniquais
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','0597e8c2dc4d61cc1ed746d67d84e6342092b25c5edfa337d1d5b9dcb8c195b6','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d082d8329d025bfe2a53fa0645d300b284878344e78a029a9a3f95ef30398807',1979,'MR','Mauritania','people-and-society',368,'Population: 1,562,000 (January 1979), average annual
growth rate 2.7% (7-72 to 7-75)
Nationality: noun— Mauritanian(s); adjective— Maurita-
nian
Ethnic divisions: nearly one third Moor, at least one third
Negro, one third mix Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national language
spoken by some 80% of the population, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976); remain-
der of population in farming and herding; considerable
unemployment
Organized labor: 18,000 union members claimed by
single union, Mauritanian Workers’ Union','02a4546c7d79918fdfc95310c252a4df07571f206ff33bad803b2548f11d3e83','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aefd7f28dc1927c5dd52f7c06bb5bb12161ca2d9fd04c9264f4cb4542d9af7db',1979,'MU','Mauritius','people-and-society',372,'Population: 927,000 (January 1979), average annual
growth rate 1.3% (7-71 to 7-77)
Nationality: noun — Mauritian(s); adjective — Mauritian
Ethnic divisions: 67% Indians, 29% Creoles, 3.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force','efd6f451fddf6127661acfbc856e1eac347ae57bc2b913e58fe9f96327e6a626','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('516ee21c6f0bde297295f7fa8089544431869f9537b81d7da3f80d4e03d2ca28',1979,'MX','Mexico','people-and-society',376,'Population: 66,938,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun— Mexican(s); adjective— Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 17.6 million (1977) (defined as those 12 years
of age and older); 33.0% agriculture, 16.0% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and
transport, 3% government, 5.4% unspecified activities; 10%
unemployed, 40% underemployed
Organized labor: 20% of total labor force','21d495441c6464fcafe1828c728e4e99c4798bd2c81ecc6219b0ab127e5a66d7','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75742820ac2f1c65863710c961575c615470c7f6943e376893768ac07b38378b',1979,'MC','Monaco','people-and-society',380,'Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun — Monacan(s) or Monegasque(s); adjec-
tive — Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete','f0c93edf2e6c9e2c7921118b0dfe073c8686991e0d3c642d96995e3eba15a05d','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('871bee0ee0a3c4165de66f11f24a0cf69049100e8b8740d64dd496d005ccd428',1979,'MN','Mongolia','people-and-society',384,'Population: 1,612,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun — Mongolian(s); adjective — Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large percentage
of Mongolian women; shortage of skilled labor (no reliable
information available)','3903637d2143eb91353c784881a76fdc66ae7fe60c8d0ed86268b115b5dd2705','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6826a6aa1017d1ec6ff0951ff467d08d0405f196a695c52cc47cedfbf597315d',1979,'MA','Morocco','people-and-society',388,'Population: 19,199,000 (January 1979), average annual
growth rate 3.0% (7-75 to 7-76)
Nationality: noun— Moroccan(s); adjective — Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 20%
Labor force: 5 million (1977 est.); 50% agriculture, 15%
industry, 26% services, 9% other; 10-20% unemployment
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT)','c939f30ed96e31a8b35e2fdb6153e49db964b62727b16b73b37392f12919429f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('071693ab72ca854cd601e5ef8f96d212c071584c4f84424d13f0d8803a09b123',1979,'MZ','Mozambique','people-and-society',392,'Population: 9,987,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun— Mozambican(s); adjective— Mozam-
bique
142
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
MOZAMBIQUE/NAMIBIA
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-African wage
earners, 560,000 African wage earners in Mozambique;
290,000 additional African wage earners temporarily work-
ing in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or
remain in subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are
white','d65c5efaade5ff7182160097b325593e6b6ebaa21c5e420cc6af33b0290ebafe','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82cc347c1a11f7936cf11f027f7394db1a1a85d3e7d69ea7e6f8e6b23ef65f55',1979,'NA','Namibia','people-and-society',396,'Population: 978,000 (January 1979), average annual
growth rate 2.9% (current)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
143
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Nationality: noun— Namibian(s); adjective— Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','a99bfe0d0d8e106677d153273dd4dc6cbd724b663455259f54a3f7a40b7c345b','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96665b0f219a95fa658f345c6b17a8e02b72241085fe052a73c11869055bfce5',1979,'NR','Nauru','people-and-society',400,'Population: 7,000 (official estimate for 30 June 1969)
Nationality: noun— Nauruan(s); adjective— Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (two-thirds Protestant, one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal','02ac3a5830f47d17d1cc8a8b44c12a6855d8fe0c06a5e1dfed71878b3cd48d54','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa25ba76c9b96e0e5cc19ece2eb80f73e28c0aa5894d1e24bf075233744e222d',1979,'NP','Nepal','people-and-society',404,'Population: 13,854,000 (January 1979), average annual
growth rate 2.5% (current)
Nationality: noun — Nepalese (sing, and pi.); adjective
Nepalese
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy; about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry;
great lack of skilled labor','ca75a2ecefeb9302f600cedf80e9df21b42baac6e97097019e50e9674aa7f40f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf50af26fdc598e1432518c80c478f1bec8d73aa8401022dae327a5ee05c5a7',1979,'NL','Netherlands','people-and-society',407,'Population: 13,976,000 (January 1979), average annual
growth rate 0.6% (current)
Nationality: noun — Netherlander(s); adjective — Nether-
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 31% Protestant, 40% Roman Catholic, 24%
unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5.1%
unemployment, March 1977
Organized labor: 33% of labor force
Population: 249,000 (January 1979), average annual
growth rate 1.3% (1-76 to 1-77)
Nationality: noun— Netherlands Antillean(s); adjective —
Netherlands Antillean
Ethnic divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish minorities
Language: officially Dutch; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force','48dabe6b4f3ec7868aef62809bf67ee0e92bf106326d076e0b7e115debbb22f6','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2a88480a58925afd4e737d1f1b9385ee342cd9708356fdb35e3daa6c15049d6',1979,'NC','New Caledonia','people-and-society',410,'Population: 140,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun — New Caledonian(s); adjective — New
Caledonian
Ethnic divisions: Melanesian 42%; French 40%; remain-
der Vietnamese, Indonesian, Chinese, Polynesian
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II period; immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 102,000 (January 1979), average annual
growth rate 2.2% (7-74 to 7-77)
Nationality: noun— New Hebridean(s); adjective— New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','c8ba2f2440ad5b07429267f6d25a41eff9548c90e03cc13e9f35423462fdaaa3','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86cb032f9e76671aa5c251cae34e32e281b5d475497d930a08978509a1d3f218',1979,'NZ','New Zealand','people-and-society',414,'Population: 3,176,000 (January 1979), average annual
growth rate 0.8% (1-75 to 1-78)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
151
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Nationality: noun — New Zealander(s); adjective — New
Zealand
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified; 1%
Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 33% manufac-
turing and construction, 9% transportation and communica-
tions, 24% commerce and finance, 21% administrative and
professional; unemployment 5.7% (1976)
Organized labor: 52% of labor force','5c5caec228e204e02c6885801be00f6cb85735642937fd1f88b847a62b5496f3','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf882d25c778895efd40c1bafd6ae0f0d94bff4ad61f99a55ec163d7c845254',1979,'NI','Nicaragua','people-and-society',419,'Population: 2,447,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun— Nicaraguan(s); adjective — Nicara-
guan
Ethnic divisions: 69% mestizo, 17% white, 9% Negro, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking minority
on Atlantic coast
Literacy: 52% of population 10 years of age and over
Labor force: 728,419 (1977 est.); 43% agriculture, 15%
manufacturing, 13% commerce, 29% other; shortage of
skilled labor, but underemployment of unskilled labor
except during harvest
Organized labor: about 5.6% of labor force','51ddf9df13c2affe7afd74c6ce4d2ad514fda548e0e9304bcbe640c436397a3b','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cec992e8aef0e745e11c3a9a36abf6daa19cbc8a3c610930fba1aa4f0499e47',1979,'NE','Niger','people-and-society',424,'Population: 5,064,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77)
Nationality: noun — Nigerien (sing, and pi.); adjective —
Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible','5508b7274f36588f77b54bb04e5f4399f3ef203a916fe068e8ba81d9058d4e77','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6488f20da8952f1c7bcfe87bd0762647ccf724d2ddc8d4c78135ecceda3621d2',1979,'NG','Nigeria','people-and-society',428,'Member of: AFDB, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, IAEA, IBRD, ICAO, ICO, IDA, IFC,
Population: 69,492,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun — Nigerian(s); adjective — Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Ilausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27.000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Ilausa, Yoruba, and Ibo also
widely used
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3 million wage earners, of whom
560.000 work in modern enterprises
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions','ca97a10821cd903f7d8f52a8b0c074cdada2d8d6480f0e243f772e7d3ff8f45d','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b04b96cc1a439d466bde1bfe2fb4138436cb25ba3635270ab18b172d9e3ac5be',1979,'NO','Norway','people-and-society',432,'Population: 4,067,000 (January 1979), average annual
growth rate 0.4% (1-77 to 1-78)
Nationality: noun — Norwegian(s); adjective — Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-speaking
minorities
Literacy: 100%
Labor force: 1.9 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.3% commerce, 9.9% transportion and communica-
tion, 28.5% services; 1.4% unemployed (average annual
1977)
Organized labor: 60% of labor force','e2db89fd10f5c3bc9f9f425fafcb658608af08f170e41f0294d0e24e67336dfe','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc52b922156be57bb6ca240c13e23daf8c41685c9aa129c06475bc1581676f07',1979,'OM','Oman','people-and-society',436,'Population: 558,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun — Omani(s); adjective — Omani
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','b628f474a216e17796a68ccd38a1b645c0ad1a2222f67cd61904467a75ba0d7e','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('790fe993ed1553edf404df27a70dbcdb85f9000562277e6b5ffbfef6fffd4aa4',1979,'PK','Pakistan','people-and-society',440,'Population: 78,978,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir,
(January 1979), average annual growth rate 3.0% (current)
Nationality: noun — Pakistani(s); adjective Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages 7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 22 million (1978 est.); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed
Organized labor: 5% of labor force','e4cf010e91054cda38a6602613a125729b4a46fb3145cbdffc89f780d85afacb','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5474db54843df355107f8bd35b0ed0103ac746a78914e1518d15ffb1dbc6ad29',1979,'PA','Panama','people-and-society',444,'Population: 1,837,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun— Panamanian(s); adjective— Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 482,200 (1972 est); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and fishing;
9.7% manufacturing and mining; 6.8% construction; 5%
Canal Zone; 3.9% transportation and communications; 1.2%
utilities; unemployment estimated at 10% to 13%; shortage
of skilled labor but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','663a8769b1f75dc99b11789cda0bdc820d8f4a33e3681967931bab7ab333be07','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ce073e3f3d1f9bda820e5f397637e85d92aedbfae23dfb9dd85da729ceb5c99',1979,'PG','Papua New Guinea','people-and-society',448,'Population: 3,024,000 (January 1979), average annual
growth rate 2.6% (7-73 to 7-77)
Nationality: noun — Papua New Guinean(s); adjective —
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 3 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: no available figures; mostly subsistence
farmers','9e2a6ca316709c48d4907235cd6e698035241a5bdadf9f7baacfc2f6e1d76572','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41f35df575891ec9dc13b6113c1ce46318c9197bf80bebef4662fcce05cd607',1979,'PY','Paraguay','people-and-society',452,'Population: 3,143,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun — Paraguayan(s); adjective — Para-
guayan
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 52.6% agriculture,
forestry, fishing; 28.2% services; 19.2% manufacturing and
mining (1970)
Organized labor: about 5% of labor force','679fb9de1dc75444a52f749b6b5d28ed176ed8d82902a02a45d2ae64088c5369','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38e714fafa74dc519c3c2864ede9f6c2e82da0e22d0fc5f2690b5dc4f15d6f60',1979,'PE','Peru','people-and-society',456,'Population: 17,053,000 (January 1979), average annual
growth rate 2.8% (current)
Nationality: noun — Peruvian; adjective — Peruvian
164
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','6237f1a4dbc6249115eb03b466f1fb03b2a715e9a489d13d7ff46f0c949930b9','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ae87a6247ad24a6a75a109ad7200b5e70ffa3d410eb7e952996f2e053010e2d',1979,'PH','Philippines','people-and-society',460,'Population: 46,388,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun— Filipino(s); adjective — Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 15.4 million (1976); 60% agriculture,
forestry, fishing, 12% manufacturing, 10.5% commerce,
10.5% government and services (business, recreation, domes-
tic, personal), 3.5% transport, storage, communication, 3%
construction; 0.5% other','cbd10a3081cc0bef84dc3621b8bd01410d3d104fa9ae295046087b6079d7d34f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('766a4081549991f2457b54d9a3a6d9cdec51b388a0f24722e81d01955a3c6e5b',1979,'PL','Poland','people-and-society',464,'Population: 35,210,000 (January 1979), average annual
growth rate 1.0% (current)
Nationality: noun — Pole(s); adjective — Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 18.8 million; 32% agriculture, 25% industry,
43% other non-agricultural (1977)','753fe1bb25217889160741a708ce771834fb12f42d0d7492ff363f192f41776a','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58cf716c01a7e6e02733846d36007a9f025af3ce15f43255521ebdb2afe92c9a',1979,'PT','Portugal','people-and-society',468,'Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,833,000 (January 1979), average
annual growth rate 0.7% (current)
Nationality: noun — Portuguese (sing. & ph); adjective —
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
number less than 100,000
168
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Religion; 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1976) 3.2 million; 27% agriculture, 36%
industry, 37% services; unemployment— now more than
14% — is largely due to influx of refugees from former
colonies, returning migrant workers, and military cutbacks
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers — National Intersindi-
cal (CJTP-IN) claims to represent 85% of the labor force; the
Socialists and Social Democrats have lost ground over the last
year despite efforts to improve their standing with organized
labor','a490f3df8a71bb283863eef064fc8ac01e1ffbe7cb805fe1dad708019b7c1fab','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abd0f644176bc74025d3205002012d3f01a57472124d4cb14bda8fd4250f85fb',1979,'QA','Qatar','people-and-society',472,'Population: 165,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun — Qatari(s); adjective — Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion; Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign
Population: 505,000 (January 1979), average annual
growth rate 1.3% (1-74 to 1-78)
Nationality: noun— Reunionese (sing. & pi ); adjective—
Reunionese
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','9a52802965e4ea08cf89a59e4598532bfaa16aa2ef6e553b84a74a1f01b76282','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8edb19ba713dd67f36041eb06e46db2ab155dd1cd502e3c145b32910ff159751',1979,'RO','Romania','people-and-society',475,'Population: 21,964,000 (January 1979), average annual
growth rate 0,8% (current)
Nationality: noun — Romanian(s); adjective — Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 60,000 Jews, 30,000
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.2 million (1975); 38% agriculture, 31%
industry, 31% other nonagricultural','be8d722ec3446c8b95e85e5aac3ae4c7b2bc74c0646e30b083c28181ab8d793f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd77934834857768d11d093458d48bdcf7e6015238e97d89cb9673b0820f519',1979,'RW','Rwanda','people-and-society',479,'Population: 4,508,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun Rwandan(s); adjective — Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','e11db3968809c37a987bcd4206845f75921d83ee5f6426756547b2cb49c75eee','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4455d36c29c387953c4c111e9ca4829875a040c69abbf4719997237c758b6819',1979,'SM','San Marino','people-and-society',483,'Population: 21,000 (official estimate for 30 June 1977)
Nationality: noun — Sanmarinese (sing. & pi.); adjective —
Sanmarinese
178
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members','dea283c2175642a9b20f66e5ba8ed08644c46a4d16b6a793925c18ff8424b379','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95b4d4b207e4c24a369e4fd6f6b28a56a182a57e6938e8ff12fdb45916694f93',1979,'ST','Sao Tome and Principe','people-and-society',487,'Population: 82,000 (January 1979), average annual
growth rate 1.2% (current)
Nationality: noun — Sao Tomean(s): adjective — Sao
Tomean
Ethnic divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant,
Seventh Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','03a756d9e3ed68a0d526c4129ef5033f23892c345db892a893f94f725b2e455f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ae702e984f5fc31427518718cc4d1643756ca0dca20023316ee497f30491ad',1979,'SA','Saudi Arabia','people-and-society',491,'Population: 7,984,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun — Saudi(s); adjective — Saudi Arabian or
Saudi
Ethnic divisions: 90% Arab, 10% Afro- Asian (est.)
Religion; 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 33% (one-half foreign) of population;
40% agriculture and herding, 12% construction, 12% service,
12% government, 11% commerce, 13% other','9c02582f8e132187eb0b0fc7a392eb3babd01aa4dfbcd59920661564fb4782fd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91318b1a4fd84c35dc127d9a84a3d36f233a5d3dcfde51a50b4a42d6f0389085',1979,'SN','Senegal','people-and-society',495,'Population: 5,450,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun — Senegalese (sing. & pi.); adjective —
Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer,
9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African,
1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading — now spoken to some
degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central unions, major central is CNTS,
an affiliate of governing party
Population: 64,000 (January 1979), average annual
growth rate 2.4% (7-72 to 7-77)
Nationality: noun — Seychellois (sing. & pi.); adjective —','875c99868dd255e7577ff0982c5978d1b6a0a0d56e022a0f80dcfdef5fb2c865','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1465b32078417bd9e2f55261b3ee1db03234dd5c24be42c1a81779ca32e7365',1979,'SC','Seychelles','people-and-society',498,'Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited; 90% of school-age population is
attending school
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
33% public sector employment, 20% private sector employ-
ment in agricuture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','4dfae44dbb17cefafefeb30dbf8b29c27b9329ab1ffb9da9a156209fe0e7d981','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('840979195b3a92cf3a87f1fbf17f6a755a10dc301f1a8d8018b17f0c7d7526ae',1979,'SL','Sierra Leone','people-and-society',503,'Population: 3,293,000 (January 1979), average annual
growth rate 2.3% (12-74 to 7-76)
Nationality: noun — Sierra Leonean, adjective — Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','9a94ca2c39290d5bcfc12afc2bce98b6d133a008660b4a19cd8038cdc11fe52f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bb8dcded28214b64c73aee18d40c361061395117aead45b28ae2d1f9c37ba27',1979,'SG','Singapore','people-and-society',506,'Population: 2,354,000 (January 1979), average annual
growth rate 1.3% (7-76 to 7-77)
Nationality: noun — Singaporean(s), adjective — Singapore
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 919,000; 2.2% agriculture, forestry, and
fishing, 0.2% mining and quarrying, 27.2% manufacturing,
30.5% services, 4.6% construction, 23.5% commerce, 11.7%
transport, storage, and communications
Organized labor: 24% of labor force','6c1a1046bf6f88548c2d418985bb624b477d046c389d13a12c5807184d79b926','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd636256b42c9f06ca193795a093495ff4e1b27bfed65b703c6b9de9af3be21a',1979,'SB','Solomon Islands','people-and-society',509,'Population: 215,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun — Solomon Islander(s); adjective — Solo-
mon Islander
Ethnic divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60%','e357f6b2453b00e4e920d12f1d397dee3bd24b6d5ce286c9ddad3abae7e3d99e','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5cb78d0eb62689c00832fdeb909aaf5debaec045a84222adc6048b249ff5db7',1979,'SO','Somalia','people-and-society',513,'Population: 3,428,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun — Somali(s); adjective — Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1976); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977','6b4abb44e5ca53e3959ab7bfc72ba471533db918b475c81e4e2e3c60452dc0bd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f34b5c5e96ea04711ff3fb7b4d0e96fb9e46430019323607e821919eebe46b',1979,'ZA','South Africa','people-and-society',518,'Population: 2,214,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun — Transkeian(s); adjective — Transkeian
Ethnic divisions: 98.9% African, 0.6% white, 0.5%
colored (mulatto); Africans belong to Xhosa ethnic group
Religion: whites and coloreds predominantly Christian;
Africans either animist or Christian
Language: whites, coloreds, and educated minority of
Africans speak Afrikaans or English; bulk of Africans speak
Xhosa
Literacy: high for whites and coloreds; low for Africans
Labor force: roughly 400,000 of whom only 50,000 are
regularly employed in Transkei; bulk are migrant workers in
Organized labor: no trade union, although some Trans-
keians employed in South Africa belong to South African
unions','d16f4198ce41f0976f790f1c76ea7691d720dbe37d4982855eb8bbef10ea4795','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3a85f9f301b55c74579d50fbfbbdbcb6f3c81dd1cc293407febb60ef9a1623',1979,'ES','Spain','people-and-society',521,'Population: 37,774,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (January
1979), average annual growth rate 1.2% (current)
Nationality: noun — Spaniard(s); adjective — Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97%
Labor force (1976): 13.3 million; 21% agriculture, 38%
industry, 41% services; unemployment now estimated at 8%
of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent about
25% of the labor force','6aaa6740be7e8874caa3059fdcbac3f7a1d572c7a14d08314c82c53f56ed235a','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9da1d47cd51878d10c0b33a7d5816c981644f18aecf0d11c7277e9f2a27a1627',1979,'LK','Sri Lanka','people-and-society',524,'Population: 14,393,000 (July 1978), average annual
growth rate 1.5% (current)
Nationality: noun — Sri Lankan(s); adjective — Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other
Language: Sinhala official, spoken by about 70% of
population; Tamil spoken by about 22%; English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons— 53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
193
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
SRI LANKA/SUDAN
January 1979','1f90431038da56da3f5a23aa50183f43a1185714425d83c82dfaeba546e28ca8','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f30c202fad6fc3d3b7b5d348f85524cf8d0b81b17563f687fc875d940e44171f',1979,'SD','Sudan','people-and-society',528,'Population: 17,912,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun— Sudanese (sing, and pi.); adjective—
Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry,
commerce, services, etc.; labor shortages exist for almost all
categories of employment','af33e83f91329090a67230b878e1d7dcb1323f6631f4db51464efbe015e7f064','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28602d262ebc723c84ebebb56107e2254aaad0d35e18b295f6e43d63b56bf7e2',1979,'SR','Suriname','people-and-society',532,'Population: 388,000 (January 1979), average annual
growth rate 1.5% (1-63 to 1-77)
Nationality: noun — Surinamer(s); adjective — Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
and is lingua franca among others; Hindi; Javanese
Literacy: 80%
Labor force: 118,000
Organized labor: approx. 33% of labor force
Population: 533,000 (January 1979), average annual
growth rate 2.8% (5-66 to 8-76)
Nationality: noun— Swazi(s); adjective — Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 35% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor: about 15% of wage earners are
unionized','619a967a1a0fa43c542ed34e1bb9bd41dce84da77fb24028978e9e4599cac482','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66f381c97f6305a7948c46994ca8677783ae4d8900f0c33d9d0bf29f83efc49d',1979,'SE','Sweden','people-and-society',536,'Population: 8,285,000 (January 1979), average annual
growth rate 0.2% (current)
Nationality: noun— Swede(s); adjective— Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities
Literacy: 99%
Labor force: 4.2 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2% construc-
tion; 13.6% commerce; 6.5% transportation and communica-
tions; 29.8% services including government; 5% banking;
75,000 or 1.8% unemployed (average annual 1977)
Organized labor: 80% of labor force
198
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24
January 1979','32fe6c90944c4c5982404a3a4ae72bb212e0434e0f672fd2f5eeed94b70eeeae','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5865147e892143d1db7b807b8cd7206942392974ea428348c8560db8ef77104b',1979,'CH','Switzerland','people-and-society',540,'Population: 6,286,000 (January 1979), average annual
growth rate —0.1% (1-77 to 1-78)
Nationality: noun— Swiss (sing. & pi ); adjective Swiss
Ethnic divisions: total population— 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals— 74% German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals — 74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population— 69%
German, 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 2.6 million, about one-tenth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry,
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.3% unemployed in July 1978
Organized labor: 20% of labor force
Population: 8,260,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun— Syrian(s); adjective — Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% Alawites, Druze,
and other Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 1.8 million; 32% agriculture, 26% industry
(including construction), 42% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 17,098,000 (January 1979), average annual
growth rate 3.0% (current)
Nationality: noun — Tanzanian(s); adjective — Tanzanian
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Mainland— 40% Animist, 30% Christian, 30%
Muslim; Zanzibar — almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher education;
Swahili widely understood and generally used for communi-
cation between ethnic groups; first language of most people
is one of the local languages
Literacy: 61%
Labor force: under 400,000 in paid employment, over
90% in agriculture
Organized labor: 15% of labor force','bcf671cf9bf6ff128e970dc7c972e8e79ba6cca6541e7f01833edd0c7e950635','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63298f8eabcc5222ae148e5cba514a81e344866bdbab815e16bdd3f3aa914ade',1979,'TH','Thailand','people-and-society',544,'Population: 46,443,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun-Thai (sing. & ph); adjective— Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry','504fb507fb3d8f8dd291452521e279de2e409d9d313dea84225b39dc7d4ec7c5','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b327b5f7d124572493fbcdc318b0e6300f616617bdf5d962d60735892bb46e14',1979,'TG','Togo','people-and-society',548,'Population: 2,493,000 (January 1979), average annual
growth rate 2.8% (current)
Nationality: noun— Togolese (sing. & pi ); adjective —
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: 1 national union, the CN FT organized
in 1972','5e5785d741b213f3663be985b375ad356b9cce9fc98d8f52e415daf09a679c43','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c3cadbc6538bf9d481c366a41459f9f1dd41d6f476b202013918eb78b678717',1979,'TO','Tonga','people-and-society',552,'Population: 91,000 (January 1979), average annual
growth rate 0.3% (current)
Nationality: noun — Tongan(s); adjective — Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','548ba68eb0c9ade4b03abc6278e73e4ffff6f39b83ddadcf519221cee695eb52','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2150f03eb83601bc610db00431acaf0aae22d659aea1fc49b3bd7770b65c9614',1979,'TT','Trinidad and Tobago','people-and-society',556,'Population: 1,129,000 (January 1979), average annual
growth rate 1,1% (7-70 to 7-76)
Nationality: noun — Trinidadian(s), Tobagonian(s); adjec-
tive — T rinidadian
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 23.0% services, 2.9% other
Organized labor: 30% of labor force','1de16859f5a9438530a3f4ecc6d853d2be2544df5fd48bac4625f9a1f902c2f1','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10c00691af38b2fa52a19b7ca71743612e3e9bf6b920f9217fc550d841943604',1979,'TN','Tunisia','people-and-society',560,'Population: 6,327,000 (January 1979), average annual
growth rate 2.7% (current)
208
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Nationality: noun — Tunisian(s); adjective — Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party','6425d755f122e498b0d886a769ae3bbe83adb40615a32491b9dd42769cd84ec0','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2562681df1aa1f3d00e141425c891aa92d5a639a17cb06ca81c4185b35a7a964',1979,'TV','Tuvalu','people-and-society',564,'Population: 6,000 (preliminary total from census of 8
December 1973)
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','71c6fec5a487b746bbff47adacd4268d5e738eb3f75fcdfd86e912a45c23f6dc','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7db02ee3e1e3dc6bdb2ebd043f9c447e27d5e2f04f9f67d6dcc921e567aaef22',1979,'UG','Uganda','people-and-society',567,'Population: 13,002,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun — Ugandan(s); adjective— Ugandan
Ethnic divisions: 99% African, 1% European, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 262,586,000 (January 1979), average annual
growth rate 0.9% (current)
Nationality: noun — Soviet(s); adjective — Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim,
3% other
Language: more than 200 languages and dialects (at least
18 with more than 1 million speakers); 76% Slavic group, 8%
othei Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 138 million (mid-year 1978), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported','7f62c5c9f7acf7a0d8540b46809796c4fe607aa750eff05cddae8bd83c91ee72','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47dfb80e97bae13c96cd5bf38fdc50b5eb99dc051d5745ed56051a9123c7593a',1979,'AE','United Arab Emirates','people-and-society',571,'Population: 656,000 (preliminary total from the census of
29 August 1975)
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians)
8 %
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry; 2%
U.A.E. Arabs, 7% non-U.A.E. Arabs, 91% Indians, Pakistanis,
Iranians','d74608505fad9ae81ad2bfd7821e714fa55cf22820b02dd8235942497c6cd23c','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7b14076b789c656f0ed29d2429e8e0428cc7af7a9a63957888675e97ae4fc2f',1979,'GB','United Kingdom','people-and-society',575,'Population: 55,846,000 (January 1979) average annual
growth rate -0.1% (current)
Nationality: noun— Briton(s), British (collective pi.);
adjective — British
Ethnic divisions: 83% English, 9% Scottish, 5% Welsh, 3%
Irish
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other; 2.1%
unemployed
Organized labor: 40% of labor force
Population: 6,582,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun — Upper Voltan(s); adjective — Upper
Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence farm-
ing, and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union groups','e3bdacb3dc24de85feadc30c55c9d32ab822661ea3709b34a2c0f33446871439','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0ed38a7e42cc0c75bc24703c656169bb67439101252df1792c94415a75ebeef',1979,'UY','Uruguay','people-and-society',579,'Population: 2,902,000 (January 1979), average annual
growth rate 0.6% (current)
Nationality; noun — Uruguayan(s); adjective — Uruguayan
Ethnic divisions: 85-95% white, 5% Negro, 5-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors — 25% government; 34% industry; 10%
service; 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1977)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories — executives, officeworkers, and
salaried employees
Organized labor: none
Population: 14,541,000, excluding Indian jungle popula-
tion (January 1979), average annual growth rate 2.2%
(current)
Nationality: noun— Venezuelan(s); adjective — Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 45% of labor force
Population: 51,883,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun — Vietnamese (sing. & pi.); adjective —
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Chain, and mountain tribesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','862166ea5a6413b01ac1b6e6c457e77bd52b903a24ae09d0fb2cc980e0b75890','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b81c40dd997b19d2346d628c3102ad7586e03d042ea3555bf1ca74ea4f221e0',1979,'WF','Wallis and Futuna','people-and-society',583,'Population: 9,000 (official estimate for 1 July 1973)
Nationality: noun — Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective — Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','6dfd9bc543cdb7a2dc6b1ec42487f3a379d432bccb747766ef512415ba7ac66f','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74c2454137b2e8398ad82b7120f05d9c1709130ac1b433d928ea1b470f408be8',1979,'EH','Western Sahara','people-and-society',587,'Population: 75,000 (total from the census of 1974)
Nationality: noun — Saharan(s); adjective — Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: Hassaniya Arabic
Literacy: among Spanish, probably nearly 100%; among
nomads, perhaps 5%
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none
Population: 155,000 (January 1979), average annual
growth rate 1.0% (1-76 to 1-77)
Nationality: noun— Western Samoan(s); adjective— West-
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
Labor force: agriculture 19,148; mining and manufactur-
ing 1,716 (1961)
Organized labor: unorganized
Population: 1,765,000, excluding the islands of Perim and
(See reference map V)
Arabian
Sea
Indian
Ocean
Kamaran for which no data are available (January 1979),
average annual growth rate 1.9% (current)
Nationality: noun— Yemeni(s); adjective — Yemeni
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,078,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun — Yemeni(s); adjective — Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 22,074,000 (January 1979), average annual
growth rate 0.9% (current)
Nationality: noun — Yugoslav(s); adjective — Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, LIungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.2 million (1976); 36% agriculture, 20%
mining and manufacturing, 44% other nonagricultural
activities; estimated unemployment averaged 5% of domes-
tic labor force in 1976
Population: 27,474,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun — Zairian(s); adjective — Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes— Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13% in wage
structure','bab9e958ba086766f484af71933835fa4f0fb366c575c9b9b408caba4430cd74','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e05e1e47792dc54f65cd05dd73f62b4065dcf8d51cb896a9342a0dcb9824bd24',1979,'ZM','Zambia','people-and-society',591,'Population: 5,559,000 (January 1979), average annual
growth rate 3.2% (7-76 to 7-77)
Nationality: noun— Zambian(s); adjective— Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellaneous services,
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','e8c6f51d5efe0a1a340ea084bcac092d20504904475c1597701012adc5ec2ef7','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2097c3da91bc3167aef40ff343bfb2cfddfb277012d7349598032e4a0c402853',1979,'US','United States','people-and-society',595,'Population: 219,334,000 (January 1979), average annual
growth rate 0.8% (current)
Ethnic divisions: 86.5% white, 11.7% black, 1.9% other
Religion: total membership in religious bodies,
129,714,000; Protestant 69,743,000, Roman Catholic
48,882,000, Jewish 6,115,000, other religions 4,973,000
(1975)
Language: English, predominantly
Literacy: almost complete
Labor force: 96.9 million, unemployment 7.7% (1976)
Organized labor: 20.1% of total (1976 prelim.)','5a133779d93a00d6c29f3b1934f16c0c16eeefc36ecbb029760ce29db8840929','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4d3d0ac2b199d596caba92222fb4fcf55bc0392d14cf64463c49795bc1307d2',1979,'AF','Afghanistan','people-and-society',9,'Population: 14,541,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: under 10%
Labor force: about 5.88 million (FY78 est.); 75%-80%
agriculture and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','ff03394bfc292a75a1e18333359fd932a9777ac2f28cc3c3354e69eb2ebbf38c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2735e6df55b6cbb963ce5a1c91a905366ce5d1b30337f45f925da6a722e00a5e',1979,'AL','Albania','people-and-society',14,'Population: 2,597,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Albanian(s): adjective—Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world’s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural','13d57d39bd2775b2d6f8719df9ba03d4d9040f4844be35357a9a4c780194f420','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2e674b736dbc96e3507ab9427c02431ddcf37db10dc0fd392d56d35d7b0ac33',1979,'DZ','Algeria','people-and-society',18,'Population: 17,944,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Algerian(s); adjective—Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front','74476db1bb137e25cdaf9d3a8c2740a34fec1df7c85d9ad6e5f7573bedeb0a6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b19d79b9a9d78627721f973f61a8f2a39efd8aef51aa9d6538a36ffa08c67a20',1979,'AD','Andorra','people-and-society',22,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun—Andorran(s); adjective—Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers','f7084cd572659294510a16ea22b2d2048e5e091e984b273f87334ad62f851d4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb1d30ab32c408ce87e8c4b267f1e57ffcb4e9bbaa34551da3eca735d2774052',1979,'AO','Angola','people-and-society',26,'Population: Angola (including Cabinda), 6,527,000 (Janu-
ary 1979), does not take into account emigration from
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Atlantic
Ocean
(See reference map VI)
Angola, average annual growth rate 2.4% (current); Cabinda,
105,000 (January 1979), average annual growth rate 3.3%
(12-60 to 12-70)
Nationality: noun—Angolan(s); adjective—Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10-15% |
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 73,000 (January 1979), average annual
growth rate 1.3% (7-70 to 7-77)
Nationality: noun—Antiguan(s); adjective—Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects, and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment','d681f30e27b1253c293a44bbd48fa7bde27922b2625b7503a37e70741c797900','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de264145f8e86b88ae75c672dcdbb8d15cf4ca593a1ec06931cdd4a9317a3895',1979,'AR','Argentina','people-and-society',30,'Population: 26,658,000 (January 1979), average annual
growth rate 1.3% (current)
Nationality; noun—Argentine(s),; adjective—Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 4-5% estimated unemployment
Organized labor: 25% of labor force (est.)','0f1a61a7c0b0d8b2bd5a551440fb3f50683f453464186f0fe1ffc3a1121f5608','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a2d831861f18d464e45d1d087e608d373d79e664ae10a06cc8eb0cd27a3911',1979,'AU','Australia','people-and-society',34,'Population: 14,298,000 (January 1979), average annual
growth rate 1.1% (current)
Nationality: noun—Australian(s); adiective—Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6% unemployment
Organized labor: 44% of labor force','4400773745a722d7737ae5c5f391fa0bf19e07678497ac92549219ee12fa3da4','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54fe7e7dfb7658e18791d9ce7345a22d5df9e558a36a6c584ed1458aae47a949',1979,'AT','Austria','people-and-society',39,'Population: 7,511,000 (January 1979), average annual
growth rate —0.0% (1-77 to 1-78)
Nationality: noun—Austrian(s); adjective—Austrian
10
Vienna,
Y AUSTRIA §
(See reference map iV}
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,784,635 (1977); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.4%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number more than 200,000 (1972); unemployment
1.2% (September 1977)
Organized labor: about two-thirds of wage and salary
workers (1971)
Population: 229,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77)
Nationality: noun—Bahamian (sing., pl.); adjective—
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
11
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
THE BAHAMAS/BAHRAIN
UNITED
STATES
A tantic Ocean
THE
by BAHAMAS
OMINICAN
REPUBLIC
Caribbean Sea
{See reference map fl}
Language: English
Labor force: 84,228 (1976), 25% organized; 25% unem-
ployment (1977)','7096cf30d895e35b56d7d929aae2006997968b44476cf3d8ec96e87bca7da9fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d8cb5dbf487c62cab998f288b483fbbc1913a4285b82e1cb031296ba131e3d',1979,'BH','Bahrain','people-and-society',43,'Population: 289,000 (January 1979), average annual
growth rate 3.5% (7-75 to 7-76)
Nationality: noun—Bahraini(s); adjective—Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 78,507 (1976)
: CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BAHRAIN/BANGLADESH
Arabian
Sea
(See reference map V}','4ba35752a5104cf21293669da1e2045d18757126520d51fb72b0088d680c59c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('921a7ef21b5858e4eabec3655919143da23919af12b8a670d00bc04648c3a696',1979,'BD','Bangladesh','people-and-society',47,'Population: 86,931,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality:
desh
noun—Bangladeshi(s); adiective—Bangla-
13
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
{See reference map Vil}
Ethnic divisions: predominantly Bengali; fewer than 1
million “Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 20 million; extensive export of labor to
U.A.E., Qatar, Kuwait, Iraq, and Oman; over 75% of labor
force is in agriculture','9dfdd650efc320ebd2029e842b3a07edb12111f3d2f19c86b5d1996d31b33511','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da3117e420c1cdb1e98497779f205ff8f13265bf0825a92374eaa015cfa9af04',1979,'BB','Barbados','people-and-society',51,'Population: 260,000 (January 1979), average annual
growth rate 1.5% (1-76 to 1-77)
Nationality: noun—Barbadian(s); adjective—Barbadian
Ethnic divisions; 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1978 est.) wage and salary earners;
unemployment 20-25% (1976)
Organized labor: 32%','985794c16299e882c8bcbef4502d78a5805efec0f3e36bbe83689b3aafca8839','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd4eb7fb53974803d8233e150ca6d266ca6678ee602e2db0a41c47e2ef48a317',1979,'BE','Belgium','people-and-society',55,'Population: 9,842,000 (January 1979), average annual
growth rate 0.0% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
16 Approved For Release 2004/06/24
Literacy: 97%
Labor force: 4.09 million (July 1978); in June 1976, 46.7%
in services, 28.0% in mining and manufacturing, 7.4% in
construction, 6.6% in transportation, 3.2% in agriculture,
1.0% commuting foreign workers, 0.4% in public works,
6.7% unemployed; 8.1% unemployed first quarter 1978,
seasonally adjusted
Organized labor: 48% of labor force (1969)','10c6e56fbb3b90fd078960d4c9c28c0e2ca6aeb132956e794654af62a5400e46','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23e7572ddc9251e9cdca782ff6cfbc189ad873d8a701f315c4b3bd9f0ee4dcac',1979,'BZ','Belize','people-and-society',59,'Population: 154,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
17
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BELIZE/BENIN
Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force','b9c5e312456d77b46ca4291dd906787e1c7ac8534e4b557da96534be283b4bbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e37177d92b42390c2c88232fca29e58be41dcb40bee5380cee8a5dac28118cde',1979,'BJ','Benin','people-and-society',63,'Population: 3,333,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Beninese (sing. & pl.); adjective—
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BENIN/BERMUDA
(See reference map Vi}
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions','f23c7eba73a5d4b3ef71c8f18ec671aaf46c0c666302a5f7825fed65916dceb8','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d04b8883ea5e35b4425f024c0a26136d77ce20c5b8772b501e0562d698d5ff',1979,'BM','Bermuda','people-and-society',67,'Population: 60,000 (January 1979),
growth rate 1.2% (7-70 to 7-76)
Nationality: noun—Bermudian(s); adjective—Bermudian
average annual
Ethnic divisions: approximately 59% black, 41% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)','1171a556b9d8c4fc48d3b1df6f4150d18307471f022de2895c9f30b71dace1d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63dea28434a771402507d6b4205f16d1ce4191d26ebc8e6b261ba303ef79bef4',1979,'BT','Bhutan','people-and-society',71,'Population: 1,282,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Bhutanese (sing., pl.); adjective—
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BHUTAN/ BOLIVIA
(See referance map vit)
Religion: 75% Lamaistic Buddhism, 25% Buddhist-
influenced Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,149,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Bolivian(s); adjective—Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
21
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BOLIVIA
! Pacific
Ocean
(See reference map Ill)
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation','4d99587d4ba8941a1cb0cd292d53b7fa70218ea35598ea567095dee7b3cda214','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae42e9a832e7b948ace54e413ba3b2f6c16d21ae556b0adbe27d72290ae8540f',1979,'BW','Botswana','people-and-society',75,'Population: 760,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Botswana (sing.), Batswana (pl.);
adjective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)','02752f5b143805c0377a030ec1caf565cdb1e55fac18449408555429fb392875','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('696d1c5b5e9f71c514d0d44f5a6cd5425f1fa689a18079fb80757c88b7399845',1979,'BR','Brazil','people-and-society',79,'Population: 122,602,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Brazilian(s); adjective—Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
15.3% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 190,000 official estimate for 1 July 1977
Nationality: noun—Bruneian(s); adjective—Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
25
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
BRUNEI/BULGARIA
HETNAM
BRUNEI
: Bandar Seri. Bagawa
{See reference mag Vif}
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services, 2.9% other
Organized labor: 8.4% of labor force','bfae889f200b0882f5ceaabfd7d63f0c41e7d4d87f385ba6fe6ac9cc7c835113','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6cd85c14d9773c5c8ff7e83b233afb082e52dc851d65a475e46ea962e490b70',1979,'BG','Bulgaria','people-and-society',83,'Population: 8,871,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun—Bulgarian(s); adjective—Bulgarian
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
ET
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Black Sea
*
Sofia
{See reference map {V)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 33,123,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burman(s); adjective—Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages
Literacy: 70% (official claim)
28
Labor force: 12.2 million (1976); 67% agriculture, 9%
industry, 20% services, commerce, and _ transportation
Organized labor: no figure available; old labor organiza-
tions have been disbanded, and government is forming one
central labor organization','d314ea62c47557d383d540ed998ec0b4e94eca6ced4fd3b4c8148e25085951b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c53b687156852ac4bcaa527303e3aa3a12cae938cc8b46514f1318bc52ee58c',1979,'BI','Burundi','people-and-society',87,'Population: 4,263,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burundian(s); -adjective—Burundian
Ethnic divisions: Africans—85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
50,000 Zairians and 40,000 Rwandans; non-Africans include
about 3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2% Muslims
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
(See reference map Vi}
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
Organized labor: sole group is the Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting “‘active
membership” have been unobtainable','280e65d55d5b683990f6ce19e07ee266617194c6cb927215b5d2d616954adb4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b6c995a68d8fea1d3b387a1023fdeed813378290a1f79fa5487770b383f5d6b',1979,'CM','Cameroon','people-and-society',91,'Population: 8,088,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: noun—Cameroonian(s); adjective—Came-
roonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
‘Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 18% other African, less than 1%
non-African
Religion: about one-half animist, one-third Christian; rest
Muslim
Language: English and French official, 24 major African
language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
63,000 paid
agricultural workers, 49,000 in manufacturing
including 22,000 government employees,
Organized labor: under 45% of wage labor force','f96456547f44ff77f5df9f41c6984d3bbad836340164a8bb4c88f81f239eea07','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('979e054578319e06f65eceeaf4fdcaf477e9caaa4815028e6d1245ee8fbe4055',1979,'CA','Canada','people-and-society',95,'Population: 23,712,000 (January 1979), average annual
growth rate 1.1% (1-77 to 1-78)
Nationality: noun—Canadian(s); adjective—Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other
Religion: 48% Protestant,. 47% Catholic, 5% other
31
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Language: English and French official
Labor force: 11.1 million; 29% service, 22% manufactur-
ing, 16% trade, 8% transportation and utilities, 6% agricul-
ture, 6% construction, 8% other; 8.5% unemployment
(September 1978)
Organized labor: 30% of labor force
Population: 318,000 (January 1979), average annual
growth rate 1.9% (12-70 to 7-76)
Nationality: noun—Capeverdean(s); adjective—Capever-
dian
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words
Literacy: 14%
Labor force: bulk of population engaged in subsistence
agriculture
Population: 1,934,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Central African(s); adjective—Cen-
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and_ linguistic
characteristics; Banda (82%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 24% animist, 8%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
Language: French official; Sangho, lingua franca and
national language
Literacy: estimated at 5%-10%
Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force','9cfb824ee397e9e0dbe925f8bd26132b2b812fb690e4e450bb2c0429060b4105','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537547932758ab2e344fec304518f81b536571627ad73282d5a35767bbc2c0f5',1979,'TD','Chad','people-and-society',99,'Population: 4,472,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Chadian(s); adjective—Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups—Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
_ Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force','084e46065742cabd11a03cee72015cca64714db88a53b1b212fff2e3a8c6da8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a96e0ddb1a44dc2c0bf485c6ddd35fc93406d1ff74302e1bf6548b01ecca81a4',1979,'CL','Chile','people-and-society',103,'Population: 10,770,000 (January 1979), average annual
growth rate 1.5% (current)
Nationality: noun—Chilean(s); adjective—Chilean
Ethnic divisions: 95%
European with some Indian admixture, 8% Indian, 2% other
European stock and mixed
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1977)
Labor force: 3.7 million economically active (1977); 30%
agricultural, 29% industry and construction, 7% services,
10% commerce, 7% mining, 9% transportation, 8% other
(1977)
Organized labor: 25% of labor force (1973)
Population: 1,014,074,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun—Chinese (sing., ‘pl.); adjective—
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
38 Approved For Release 2004/06/24
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 17,124,000, excluding the population of
Quemoy and Matsu Islands and foreigners (January 1979),
average annual growth rate 1.8% (1-77 to 1-78)
Nationality: noun—People of Taiwan; adjective—Taiwan
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 6.12 million (1978); 26.2% primary industry
(agriculture), 39% secondary industry (including manufac-
turing, mining, construction), 34.8% tertiary industry (in-
cluding commerce and services) 1977; 2% unemployment
(1976)
39
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
TAIWAN/COLOMBIA
Organized labor: about 12% of 1972 labor force
(government controlled)','a60da3f5e33f65c0217a025453ccc180b956f4d879a7143bac72df568459bf2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a350715bd161402ec5e5eb63acb370673f53010cb4ab151b0920bb7f4a86fc75',1979,'CO','Colombia','people-and-society',107,'Population: 25,837,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Colombian(s); adjective—Colombian
Ethnic divisions: 58% mestizo, 20% caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-13% unemployment (1975)
Organized labor: 13% of labor force (1968)','87fd539872faa664366bdb65fff71d1ae4f2d498ee35106615d2b27508ed0e33','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3838b291e13105de18a93914a8bfb7188508c147154ee7a3a5cce61dda0f432d',1979,'KM','Comoros','people-and-society',111,'Population: 320,000 (January 1979), average annual
growth rate 2.1% (current)
Nationality: noun—Comoran(s); adjective—Comoran
42
Approved For Release 2004/06/24 :
Indian Ocean
Moroni comoanos
(Ses reference mep VI}
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural
Population: 64,000 (January 1979), average annual
growth rate 2.4% (7-72 to 7-77)
Nationality: noun—Seychellois (sing. & pl.); adjective—','56c0526e8afb4a38e409f091654f0772c2d1cbc1acc35ad20c766bad6a32de61','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bed9317e11a8a6ef49fc6c4ea29fbf4ced95bae4d65e822ee3e558ff5383f70',1979,'CG','Congo','people-and-society',115,'Population: 1,484,000 (January 1979), average annual
growth’ rate 2.7% (current)
Nationality: noun—Congolese (sing., pl.); adjective—
Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north, about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically
active, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','c062da69940ad5e4f7aa96792608c40fd79c8759f14ea2d23bc02557f6201798','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e30399a121ee330ffc4a5a11c3ddb0d5b48c2196c6d7c12cfea1ff19ea974e31',1979,'CK','Cook Islands','people-and-society',119,'Population: 18,000 (total from the census of 1 December
1976)
Nationality: noun—Cook Islander(s); adjective—Cook
Islander
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','3855b69c52f20514210529abd95a624cefd1f4c6011268f09c1a7b50a5ee69ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('512c577c855046b8efd6cd0aaee8338d9ee15d376588c3174beddac53fb170d0',1979,'CR','Costa Rica','people-and-society',123,'Population: 2,144,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: adjective—Costa
Rican
noun—Costa_ Rican(s);
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
(See reference mep H)
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 657,709 (1976), 32.6% agriculture, 13.8%
manufacturing; 15.8% commerce; 6.1% construction; 5.2%
transportation, utilities; 20.3% service (government, educa-
tion, social); 0.5% other; 6.2% unemployment (1976)
Organized labor: about 11.5% of labor force','a80340cb9e1564f19849207a9cee319ae6fa380b453457d715b15cad7dc7c931','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d8540314c3a15da7c9ee36002c611482251efa00f1b97fbde8f73d86dbef99c',1979,'JM','Jamaica','people-and-society',127,'Population: 9,874,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Cuban(s); adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
’ CUBA/CYPRUS
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.7 million in 1976; 33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed
Population: 5,466,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force
Population: 2,217,000 (January 1979), average annual
growth rate 1.4% (current)
Nationality: noun—Jamaican(s); adjective—Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
105
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Atlantic
JAMAICA x
ingsten —
Caribbean Sea
(See reference map ff)
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 672,000 (1975); 29% in agriculture, forestry,
fishing and mining, 12% manufacturing/mining, 8% public
administration, 5% construction, 10% commerce, 3% trans-
portation and_ utilities, 33% services; 25% unemployed;
shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 115,498,000, including Ryukyus (January
1979), average annual growth rate 1.0% (current)
Nationality: noun—Japanese (sing., pl.); adjective—
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Labor force (1977): 54.5 million; . 11% agriculture,
forestry, and fishing; 384% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33.7% of labor force','11e8689e0ec42211e03518b13206c7603b280aa6a6df9f0e54837dfb5beef5e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21e67c32e1530bde6997664ddfe76adefe14f35d68708fff338cadac937a602f',1979,'CY','Cyprus','people-and-society',131,'Population: 642,000 (January 1979), average annual
growth rate 0.2% (7-76 to 7-77)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Maron-
ite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Greek Sector labor force: 207,700 (1976), 22% agricul-
ture, forestry, fishing; 14% manufacturing; 6% construction;
1% mining and quarrying; 14% services; 10% trade and
finance; 3% transportation and communications; 5% public
administration, 25% other; unemployment 4% (1977)
Turkish Sector labor force: 179,400 (145,900 employed,
38,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)
Population: 15,189,000 (January 1979), average annual
growth rate 0.7% (current)
Nationality: noun—Czechoslovak(s); adjective—Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
49
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
CZECHOSLOVAKIA
ee oe a
{See reference map iV)
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others','454d2a153d40ca22d2064bdf2cfb6a17a284c9606ee667b3782bd98592262b39','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61d53649c60ce1d93ddc280dfc612fbd237025ac1f4146aa73341661d06e98e5',1979,'DK','Denmark','people-and-society',135,'Population: 5,112,000 (January 1979), average annual
growth rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2,579 million (October 1977); 8.6% agricul-
ture, forestry, fishing, 24.6% manufacturing, 8.1% construc-
tion, 15.4% commerce, 6.6% transportation, 5.4% services,
29.3% government, 2.0% other; 6.4% (164,000) registered
unemployed as percentage of total labor force (1977 annual
average)
Organized labor: 65% of labor force','72ce53a107dc71f932b7d8a71c08c427ae0907bd902764d686a00f215e63c1f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd9d62b792a866d6f1fd228438459aec01d6a044a5dde0407a3e5a421cca8047',1979,'DJ','Djibouti','people-and-society',139,'Population: 180,000 (official estimate for 1972)
Nationality: noun—Afar(s), Issa(s); adjective—Afar, Issa
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
DJIBOUTI/DOMINICA
Organized labor: some 3,000 railway workers organized','d27b72c734a49de82ccbf64f86e6efd4683b54b2d18d03256013e4bc708a4d50','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a34c91128297a4bbe9db903f2d66feac58df822e1eb90bd9cfd80b0177ae761',1979,'DM','Dominica','people-and-society',143,'Population: 78,000 (January 1979), average annual
growth rate 0.7% (1-75 to 1-77)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture; 24%
unemployment
Organized labor: 25% of the labor force','b2e1a33665b43649e259ff85d70da47f9a388e9036e2c9f189a3f98f35a21928','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183979827d488ba5a2b7c7bc61aab563de27d723d2e2fcf41fdd61000c2762e0',1979,'EC','Ecuador','people-and-society',148,'Population: 7,665,000, excluding nomadic Indian tribes,
(January 1979), average annual growth rate 3.0% (current)
Nationality: noun—Ecuadorean(s); adjective—Ecuador-
ean
55
: CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Neero, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other services and activities
Organized labor: less* than 15% of labor force
Population: 40,424,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Feyptian(s); adjective—Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Labor force: 12 million; 45 to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and _ other;
shortage of skilled labor
Organized labor; 1 to 3 million','a6d247714ad9da4f5bdcefaef2b6c8c4b15119c178b171d54778c7ff352bc7e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b978d25829d2abdaac8c05d380fc33537f14e5c0f3278b5272691f36b97b44e0',1979,'SV','El Salvador','people-and-society',152,'Population: 4,580,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Salvadoran(s); adjective—Salvadoran
58 Approved For Release 2004/06/24 :
Caribbean
| $¢a
Pacific Ocean
{See reference map fl)
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','d08317eeca4797ae30fc50a742575193a2b3b7e5ff4f2013951360031448f876','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6962c774568c96bc191451f22d512ccb3e544cf22c1d87372424d17a1bcbde0',1979,'GQ','Equatorial Guinea','people-and-society',156,'Population: 339,000 (January 1979), this estimate does not
take into account emigration from Equatorial Guinea during
the Jast several years, average annual growth rate 1.8% (7-68
to 7-69); Rio Muni, 237,000, average annual growth rate
1.5% (7-68 to 7-69); Fernando Po, 102,000, average annual
growth rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjective—
Equatorial Guinean
Ethnic divisions: indigenous population of Province
Macias Nguema Biyogo, primarily Bubi, some Fernandinos;
of Rio Muni primarily Fang; less than 1,000 Europeans,
primarily Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 20%
Labor force: most Equatorial Guineans involved in
subsistence agriculture','91534de0f63584fd6d74d75b1238affe56faf5baa06dbf7275a43f16df5233ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d131e3618f204921bc513312fa4f684076d88f3df14c7517443b35815426c56',1979,'ET','Ethiopia','people-and-society',160,'Population: 31,341,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Ethiopian(s); adjective—Ethiopian
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
ETINIOPIA —
(See referance map V1)
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized labor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','beeaf252b74b68f2da04bdff1b21be1f1d0d13ba7a229a3e63273138726f4f51','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f887be7b43607e0b438bddbd7e4f03db705426f35131a59493d454e4043f898c',1979,'DE','Germany','people-and-society',165,'Population: 2,000 (official estimate for 31 December
1977)
Nationality: noun—Falkland Islander(s); adjective—Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding
Population: 35,808,000 (January 1979), average annual
growth ‘rate 3.0% (current)
Nationality: noun—Iranian(s); adjective—Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 13%
other Iranian, 18% Turkic, 3% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha’is
Language: Persian (Farsi), Turkish dialects, Kurdish,
Arabic
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976; 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial
Population: 48,767,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 18% industry,
95% service; substantial shortage of skilled labor; ample
unskilled labor (1978)
Organized labor: 12% of labor force','a50ce94de395f987950fb4731a532a6a193727981cd1b7a9f91c890264f5daa0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd24ddfed7e23f8a98e4acef493e2645ea05306989ba3f60f93e8dfb0b737516',1979,'FO','Faroe Islands','people-and-society',168,'Population: 43,000 (January 1979), average annual
growth rate 1.4% (1-75 to 1-77)
Nationality:
Faroese
noun—Faroese (sing., pl.); adjective—
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce','96ea7dda82cea025d576793537d5b1e2d0365367fd5211e038729889f12b64a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce56cb941cb44774d5f5b60767ff49701ddcb88a06c9826510d4b108dfa1421d',1979,'FJ','Fiji','people-and-society',172,'Population: 615,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 44% Fijian, 50% Indian, 6% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
64
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation','96db4a5ce4f99ee3594a6ca02de57d4ba03df58a259c879a17a337c8d6e64fc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d2fb35a2e626172d55a6a23545f7734223ebb299c38735ddfcc9bcb56376e8e',1979,'FI','Finland','people-and-society',176,'Population: 4,755,000 (January 1979), average annual
growth rate 0.3% (1-77 to 1-78)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture, forestry, and
fishing, 26.4% mining and manufacturing, 8.4% construc-
tion, 15.4% commerce, 6.8% transportation and communica-
tions, 4.0% banking and finance, 20.1% services; 6.1%
(136,000) unemployed 1977 annual coverage
Organized labor: 60% of labor force','3f73fcfd83143d1c8b884d7982e7a8a4849a2a76dcc53cf109d7bce24eb2873d','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('092c8b8a79aac587f16871838bb73abf9ba643be68726adff92a0f7cc7f70d67',1979,'FR','France','people-and-society',180,'Population: 53,536,000 (January 1979), average annual
growth rate 0.6% (current)
Nationality: noun—Frenchman (men); adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois—Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22 million (est. in mid-1977); 47% services,
38% industry, 11% agriculture, 5% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force
Population: 7,431,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun—Rhodesian(s); adjective—Rhodesian
Ethnic divisions: 96% African, less than 4% European,
less than 0.5% coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also
widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some
migrants from Zambia and Malawi), 108,000 Europeans,
Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40%
transport and services
Organized labor: about one-third of European wage
earners are unionized, but only a small minority of Africans
(1966)','cb35d9bea808a384070178babf7f330e9d02879aca9ea0e05466a09a8a690768','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a5f74fb60c04ea273ffce244bd0c2daab072e847bb7eeecfe1afad7610d7f4d',1979,'GF','French Guiana','people-and-society',184,'Population: 60,000 (January 1979), annual growth rate
2.2% (10-74 to 11-77)
Nationality: noun—French Guianese (sing., pl.); adjec-
tive—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force','58a84a5f0785e8dd26644b9f4de9bb131eb5a2d85db3a36ed5086f74f332de4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbf92c97abd7ed9e25efcd734906a50f6fe079f68cac40a78090b1ffdac5f56e',1979,'PF','French Polynesia','people-and-society',188,'Population: 143,000 (January 1979), annual growth rate
2.3% (current)
Nationality: noun—French Polynesian(s); adjective—
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic','9626f88d901fa2e43c55161f586d2c035bd4994306deef3fb8be42a429510ef7','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c913f621162645dfb0a60dce0b852d4858cbfe35dbac2633d7aa08e89a52559c',1979,'GA','Gabon','people-and-society',192,'Population: 575,000 (January 1979), average annual
growth rate 1.7% (7-66 to 7-70)
Nationality: noun—Gabonese (sing., pl.); adjective—
Gabonese
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 30,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage
earners in the modern sector
Organized labor: less than 80% of wage labor force
Population: 576,000 (January 1979), average annual
growth rate 2.7% (7-76 to 7-77)
Nationality: noun—Gambian(s); adjective—Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official, Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
71
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Labor force: approx. 165,000, mostly engaged in subsist-
ence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,783,000, including East Berlin (January
1979), average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnie divisions: 99.7% German, .3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction; 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16.8% services; 2.5%
other
Organized labor: 87.7% of total labor force
Population: 61,262,000, including West Berlin (January
1979), average annual growth rate —0.1% (current)
Nationality: noun—German(s); adjective--German
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
74
Approved For Release 2004/06/24
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners','c5688f00d270a618dca9be24e9ec2433cf87cba54dca165161a1dba275e81b8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea2ccda571e28a67eefa1446b5289306d4dbdbb432a5dca2318c577987c9780',1979,'GH','Ghana','people-and-society',196,'Population: 11,553,000 (January 1979), average annual
growth rate 3.8% (current)
_ Nationality: noun—Ghanaian(s); adjective—Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8%
75
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GHANA/GIBRALTAR
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation, and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force','b634392bf99d67f0dbce3862b9f2c9c19c379be4028fc1a8a8bb63be4708af1a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69bebd1324e44a9d3b6d007155d2453c62b3893de25b62e83dad57eb7747fe50',1979,'GI','Gibraltar','people-and-society',200,'Population: 30,000 (official estimate for 1 July 1977)
Nationality: noun—Gibraltarian; adjective—Gibraltar
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GIBRALTAR/GILBERT ISLANDS
- Atlantic Ocean
(See reference map 1V)
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000
Population: 52,000 (preliminary total from census of 8
December 1973)
Nationality: noun—Gilbertese or Gilbert Islander(s);
adiective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%','000e6d729976817b1c1c09b56eb1cec8628a60fd650a077782eeae07f1fa3dd1','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75a9bde3bcb0a573d2cc93fdf004617046293b57883f8674db431d3f7102c339',1979,'GR','Greece','people-and-society',204,'Population: 9,372,000 (January 1979), average annual
growth rate 0.6% (7-67 to 7-77)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 2% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total
about 82%
Labor force: 3,400,000 (1975 est.); 40.5% agriculture,
25.6% industry, 33.7% services; unemployment 3%, but there
is substantial underemployment in agriculture
Organized labor: 20% of labor force est.','3ba7d8d2b8201f004a597b7495a81bad8a9a51a7f37343f09ac949685fffe1b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd110a7d5303742e138aa32366e5e3005af30e4831338eb5b0c70df097026b47',1979,'GL','Greenland','people-and-society',208,'Population: 50,000 (January 1979),
growth rate 0.2% (1-75 to 1-77)
average annual
80
Nationality: noun—Greenlander(s); adjective—Green-
land
Ethnic divisions: 86% Greenlander (Eskimos and Green-
land-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','40710931835fb2c26ddacb25b931545ee5d54d11cb988003a80013513568133d','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f638ebed41503d59e3db7fbf7bc54c6282917e5e37062e95435e74511209fe31',1979,'GD','Grenada','people-and-society',212,'Population: 106,000 (January 1979), average annual
growth rate 1.4% (4-70 ‘to 7-77)
Nationality: noun—Grenadian(s); adjective—Grenadian
Ethnic divisions: mainly of Atrican-Negro descent
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','852c83cdd7d4b725743abfe817d43e652a5170271c1db2aea833c318ffb87309','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eee64ec17a28bee079099dcbf11288ee3fd96b69de6d75750b7ad7156c73794',1979,'GP','Guadeloupe','people-and-society',216,'Population: 324,000 (January 1979), average annual
growth rate 0.3% (10-67 to 1-76)
Nationality: noun—Guadeloupian(s); adiective—Guade-
loupe
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
82 Approved For Release 2004/06/24 :
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','07f2919cf358385965c7506a9188083e9c0cbfcafca8f26ce4429e2814300157','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41267ea5e26d6369d6b4d860df016a325c7b6e294fb25604a3f968d7d9bbfd66',1979,'GT','Guatemala','people-and-society',220,'Population: 6,716,000 (January 1979), average annual
growth rate 2.9% (7-76 to 7-17)
Nationality: noun—Guatemalan(s); adjective—Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 30%
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)','05ff2a2837f8d7913d04eb4cbfa55a3ce7bc9b79d2529d41e762a1835ebdc57c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccfa57b158d69ede66d6bea1a7e5459bc337930e5ec5b719552996e15f0f7507',1979,'GN','Guinea','people-and-society',224,'Population: 5,973,000 (January 1979), average arinual
growth rate 2.6% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: 99% African (3 major tribes—Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language
CIA-RDP79-01051A001000010001-5
a
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GUINEA/GUINEA-BISSAU
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of
Cuinean Workers, which is closely tied to the PDG
Population: 7,365,000, resident African population only,
(January 1979), average annual growth rate 2.7% (current)
Nationality: noun—Ivorian(s); adjective—Ivorian
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately
2 million foreign Africans, mostly Upper Voltans; about
75,000 to 90,000 non-Africans (50,000 to 60,000 French and
25,000 to 30,000 Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in government, industry, commerce, and_ professions
Organized labor: 20% of wage labor force','83fa15bc80970c7f3aca34c7e4eed520bc7b4e7115de1fa0184e6d54c5254b80','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71a0bf4543ec541916ee27d49afb4dc1895b2f62c7b623eeec4c58d726f3cea8',1979,'GW','Guinea-Bissau','people-and-society',228,'Population: 625,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
85
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
GUINEA-BISSAU/GUYANA
{Sea reference map Vi}
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Labor force: 90% of economically active population
engaged in subsistence agriculture','86aea2812f6ba5140aa95dee270fd44cbee5a317eda3f5ba4bd309df612c0060','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7459ce0bee40c0e951614b4605a611ef63ab894a6931f3fa56a164ca4541b230',1979,'GY','Guyana','people-and-society',232,'Population: 818,000 (January 1979), average annual
growth rate 1.3% (current)
Nationality: noun—Guyanese (sing., pl.); adjective—
Guyanese
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86%
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force','0e6cee108b03fd5ca002cdf1b37500e984acd6b094a07e11e87c2ca39711c0fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('060a76a71e61fa266fdf985bc51793b4aaa837ebccaa231fcfb57276128a1688',1979,'HT','Haiti','people-and-society',236,'Population: 5,600,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12% .
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant
Organized labor: less than 1% of labor force','1d2d2d2c469fc033f39e8ae51f03cd4044b129e9538fb9535b9cded1f10d4150','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29acd5a66d4296a68c7c73070f7c3d968e29227e45771ea99326c82ac960bac2',1979,'HN','Honduras','people-and-society',240,'Population: 3,578,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Honduran(s), adjective—Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)','34a55a26c114f8894c11f4b4d598636485e51afa8c114c03e4e27153abe6404a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545eb4a22704a7afb7e0f0748e59a48e27b460b6f97e224f2b5a120bf0253b8b',1979,'HK','Hong Kong','people-and-society',244,'Population: 4,622,000 (January 1979), average annual
growth rate 1.6% (7-76 to 7-77)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions
Language: Chinese, English
Literacy; 75%
Labor force (1976 Census): 1.87 million; 45.8% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.7% other;
underemployment is a serious problem
Organized labor: 21% of 1976 labor force
sa Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
HONG KONG/HUNGARY','8c8e6eb41e976d60ca3db8f9d7b0c6740d948054f0249dcafb407db3139de74b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91b57e9b14821103b6f35f171addd4c1fb4ea95095e22a46fbe479356ad1b99f',1979,'HU','Hungary','people-and-society',249,'Population: 10,715,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Hungarian(s); adjective—Hungarian
Ethnic divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,230,000 (1977); 20% agriculture, 34%
industry and building, 46% other non-agriculture
91
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
{Sea reference map IV)','9140ac41c279eb91d9cb5a1fa989abd7072992e8b49b468647ecf21802f2f60b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('297e5220b6c4b2d5243b5503bb0d0d89490567c99f126fd301fa4e0cdd8a6ea5',1979,'IS','Iceland','people-and-society',254,'Population: 224,000 (January 1979),- average annual
growth rate 0.7% (12-76 to 12-77) ;
Nationality: noun—Icelander(s); adjective—Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 90,000; 22.6% agriculture and fishing; 25.6%
mining and manufacturing; 10.7% construction; 12.8%
commerce; 7.8% transportation and communications; 15.2%
services; and 5.7% other; unemployment 1977, 0.6%
Organized labor: 60% of labor force','e80d17aa765cf6e06d5ab2cd9dab83bf927eb72179ce16a643a6b304504f2eb3','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e53e3a823b0ffb0b2795d37653f6deb90d14751123979c400f7c1b3ced1d7e30',1979,'IN','India','people-and-society',258,'Population: 667,907,000, including Sikkim and the
Indian-held part of disputed Jammu-Kashmir (January
1979), average annual growth rate 2.2% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys “associate” status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force','416e35e1b2547398c2a11d21690e0e369aecbc05346c5a5772b032ac8d8ca55b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91c00fc2dff645ae58104a7189c673f1386fa446c08d9a1876536e6757131689',1979,'ID','Indonesia','people-and-society',263,'Population: 145,958,000, including East Timor and West
Irian (January 1979), average annual growth rate 2.1%
(current)
Nationality: noun—Indonesian(s); adjective—Indonesian
Ethnic divisions: majority of Malay stock comprising 45%
Javanese, 14% Sundanese, 7.5% Madurese, 7.5% coastal
Malays, 26% other
Religion: 90% Muslim, 5% Christian, 3% Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor foree: 55 million; 64% agriculture, 12% trade, 7%
industry, 17% other
Organized labor: 10% of labor force','b3eae2a6ac10db6efb0a2e59d7ff33f0dc07e01362019f802ee1f5fe79e023e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fb5cf4879ffdba64ded3a14274de4cfea3348582ca81f630d296a786a74afa7',1979,'IQ','Iraq','people-and-society',267,'Population: 12,689,000 (January 1979), average annual
growth rate 3.4% (current)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
IRAQ/IRELAND
Nationality: noun—Iraai(s); adjective—Iraai
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim (50% Shiah Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force','f2d40436253ba5c949d46d33201bb18577259c54ee1b81b549ff2e7bea6cee8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1e678e4039716cd50b1622fe5c22b76e373a3968e6b312764b125c3a614aa30',1979,'IE','Ireland','people-and-society',271,'Population: 3,242,000 (January 1979), average annual
growth rate 1.0% (7-75 to 7-77)
Nationality: noun—Irishman(men), Irish (collective pl.);
adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99%
Labor force: about 1,143,000 (1976); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 1%
construction; 5% transportation; 4% government; 24% other;
9.8% unemployment (February 1976)
Organized labor: 36% of labor force','3843ce0f505653d4fda9d4386ceb5edb91bce0de1756ff3604d55d72034172d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a7e00f2287565a7812af5d64cfb0f853d83e6f87ff8caa41471ed1ed1f9613',1979,'IL','Israel','people-and-society',275,'Population: 3,712,000, excluding East Jerusalem and the
other occupied territories (January 1979), average annual
growth rate 2.4% (1-77 to 1-78)
Nationality: noun—Israeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry and
fishing; 25.3% manufacturing (mining, industry); 0.9%
electricity and water; 8.1% construction and public works;
12.2% commerce; 7.7% transport, storage, and communica-
tions; 6.5% finance and business; 26.1% public services; 6.7%
personal and other services (1974)
Organized labor: 90% of labor force','f5d9450bc3de79c2cf4230a9c2a95ac739c973c8fca827b4d5bc543d3eb9ef62','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4d29bdf84b4e6cc14eb87808714c9f24d53c38bc4daba1aa2a20060acdee695',1979,'IT','Italy','people-and-society',279,'Population: 56,867,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun—Italian(s); adjective—Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
(See reference map IV}
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972); illiteracy
varies widely by region
Labor force: 20,125,000 (July 1978); 15.0% agriculture,
49.9% industry, 39.0% other (1975); 7.1% unemployment
(1978); 1.5 million Italians employed in other Western
European countries
Organized labor: 50-55% (est.) of labor force','78f74b5ac17dc1075b18c222efe763f68a1fa796c389d0ae57f325471310e4a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75dcbff587cb59eee6b9c5a943d22a993d670fdfa49bf66511faf5c52fec609c',1979,'JO','Jordan','people-and-society',283,'Population: 3,008,000, including West Bank and East
Jerusalem (January 1979), average annual growth rate 3.2%
(7-70 to 7-76); East Bank, 2,224,000, average annual growth
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
rate 3.6% (7-70 to 7-76); West Bank, including East
Jerusalem, 784,000, average annual growth rate 1.9% (1-71
to 1-77)
Nationality: noun—Jordanian(s); adjective—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force
Population: 8,087,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Kampuchean(s); adjective—Kampu-
chean
Ethnic divisions: 90% Khmer (Kampuchean), 5% Chi-
nese, 5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','953b368c750f1c28d87dd3ed3cffce2e036937c8b9178f47635f900c5efd3a05','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04ab3c632442786c77dab82e2db6a441b95b9e0a6c4de4b11649e2e595433064',1979,'KE','Kenya','people-and-society',287,'Population: 15,096,000 (January 1979), average annual
growth rate 3.6% (current)
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic), 2% Asian; 1% Euro-
pean, Arab, and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 18,421,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Korean(s); adjective—Korean
112
January 1979
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor
Population: 57,000 (January 1979), average annual
growth rate 1.1% (7-76 to 7-77)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s), Anguillan(s);
adjective—Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor; 6,700
Population: 120,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—St. Lucian(s); adjective-—St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture; 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 112,000 (January 1979), average annual
growth rate 1.8% (4-60 to 1-76)
Nationality: noun—St. Vincentian(s) or Vincentian(s),
adjectives—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force','99661adf40582da5335f6fd41451ad42e328beadbfc6eda8e0ffc6b7803069ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1310853bbf5493bc4443b16f4c7c7a71db7e1e21bf27cf8b312eea07a3633bb0',1979,'CN','China','people-and-society',292,'Population: 39,206,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition, pervasive folk
religion (Shamanism); vigorous Christian minority (16.6%
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 12.9 million (1977); 42% agriculture,
fishing, forestry; 22% mining and manufacturing; 36%
services and other; average unemployment 3.8% (1977)
Organized labor: about 13% of nonagricultural labor
force
Population: 285,000 (January 1979), average annual
growth rate 1.5% (current)
Nationality: noun—Macaon(s); adjective—Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about
one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)','f106e5f5bb4171968959ff78f25a44cc6164b1d871c2e0782393050fa4c36ff2','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d673e13cd15199dceea56e3a1b18f0d20e9a988e37feaceb2baa4ef770e769c7',1979,'KW','Kuwait','people-and-society',295,'Population: 1,241,000 (January 1979), average annual
growth rate 5.9% (current)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
KUWAIT/LAOS
Nationality: noun—Kuwaiti(s); adjective—Kuwaiti
Ethnic divisions: 85% Arabs, 13% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 340,000 (1976 est.); 26% manufacturing, 25%
services, 35% government and professions, 9% commerce,
5% oil industry; two-thirds of labor force is non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
Population: 3,587,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Lao (sing., Lao or Laotian); adjec-
tive—Lao or Laotian
Ethnic divisions: 48% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 183% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
115
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
LAOS
{See reference map Vit}
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party','91571636ff1ac6c756d57b0d8a09f60e3e7ab373c98cf6cc2e2b322dc83aef26','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17487ae112d78755128c52a73e2cc79cd7bcc0bf6994019800d43fffa8e270ec',1979,'LB','Lebanon','people-and-society',299,'Population: 2,568,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Lebanese (sing. and pl.); adjective—
Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically. active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
LAOS /LEBANON
Organized labor: about 65,000','ee92435f348badfe6642301c4ed4054a41816e57f158849c25fdd4e772612ecb','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb44896cfccfcf5a5d151ec0e3313eafd41352512cf736347ac3c083f878abb',1979,'LS','Lesotho','people-and-society',303,'Population: 1,291,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Mosotho (sing.), Basotho (pl:); adjec-
tive—Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible','afe69f99e0b73efe92560c3ab2dddc0afa1cda1c8c5ac9d381e2d97cec1f6fd9','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1845373a8f616ddbd725b26ac07f7da3aca9e7d5fd21c4ccd2fe59a4e80b0e9a',1979,'LR','Liberia','people-and-society',307,'Population: 1,761,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Liberian(s); adjective—Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor; 2% of labor force
119
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
LIBERIA/LIBYA','6a0aa819fd843c5fac90542be50fdb5718529e5785e339e9826e8fffb5d6a0ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4e8f97b06a1e18623327e0d23ecb354fe1771072c1980d9984c11c710e76035',1979,'LY','Libya','people-and-society',311,'Population: 2,816,000 (January 1979), average annual
growth rate 4.1% (current)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','bc26c6ae60a85eaa74c7f94c2cdedc000c18f9abe3a72d915201fc9fd1f6d527','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c66f846575c5288d227f6132d173d812fde852658bb009a6a7ea1d0ab1c74c14',1979,'LI','Liechtenstein','people-and-society',315,'Population: 22,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: | noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce,
18% professional and other, 8% agriculture','bed8f841ab4f16f859472296cae52582364b73359cd7f38577f547249ed3c274','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3764307b2366e12ef5873972f1dcd2747fb18d7d7933f8474217bd6681224623',1979,'LU','Luxembourg','people-and-society',319,'Population: 358,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Luxembourger(s); adjective—Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 8% Protestant
and Jewish
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1977) 147,300; one-third of labor force is
foreign, comprised mostly of workers from Portugal, Italy,
France, Belgium, and West Germany (1977); unemployment
0.2% (1977)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5','300177f69d5dbf63dea7093534337c38962de66f401973c0b9b4fd7927f7115e','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('763ca42e92629bbcebf16477478591aded38e5a45e0fa53575efe5af104089b9',1979,'MG','Madagascar','people-and-society',324,'Population: 8,258,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Malagasy (sing. and pl.); adjective—
Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Mer-
ina (1,643,000) and related Betsileo (760,000), on the one
hand, and coastal tribes with mixed Negroid, Malayo-Indo-
nesian, and Arab ancestry on the other, coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000, Sakalava
375,000, Antaisaka 415,000; there are also 10-12,000
European French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
laneous
Organized labor: 4% of labor force','69ce4305985c85ae56a35a3dc888a0a44d88a007acc6866dac8863aaa9587529','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d784215ae0822b2b11e6dc2c1c7bdd39f6f2861adada8d3143137679a4a98208',1979,'MW','Malawi','people-and-society',328,'Population: 5,777,000 (January 1979), average annual
growth rate 2.9% (8-66 to 10-77)
Nationality: noun—Malawian(s); adjective—Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
13% manufacturing, 10% administration, 26% miscellaneous
services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized','9727b14252dc35b95a93f61cb36343dc6bb2edc8dd87a90cdde00d3a1b871d79','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f93e24b7441cde6d840e8dcbb62c7f7921c5626990d3d94fad2d894e609413c',1979,'MY','Malaysia','people-and-society',334,'Population: 13,099,000 (January 1979), average annual
growth rate 2.8% (current)
Peninsular Malaysia: 10,926,000,
growth rate 2.6% (8-70 to 1-77)
Sabah: 967,000, average annual growth rate 4.8% (8-70
to 1-77)
Sarawak: 1,206,000, average annual growth rate 2.6%
average annual
- (8-70 to 1-75)
Nationality: noun—Malaysian(s); adjective—Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 53% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10% other
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 18% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 18% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas
CIA-RDP79-01051A001000010001-5
A na
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979','600be7e1beaa392495a6c65bab5697b4634c14ef0d3a3cd5a1d9a3908cacdf6e','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08ab0d5220520e2b930d5facd9f6b25828bea24bd45b04c04ee0d0dfb652dc7a',1979,'MV','Maldives','people-and-society',340,'Population: 143,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Maldivian(s); adjective—Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population','3944863cdbf1ec3ff71d5d7cfdb970b064c57ec3f02f50bf3d130bf7ec4a87da','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6bb4f495a4f6921b571cbee8914fb7541e3ce074e000e9f7550fd6e4b2b6aca',1979,'ML','Mali','people-and-society',344,'Population: 6,287,000 (January 1979), average’ annual
growth rate 2.0% (current)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions','cfa4300b2331cd8230ec3640e73bba111718ac788ffc4d394a7a9adc67eed326','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0cbbd599dc5cbaa8a38d7caa99425420d8baed6122ead32f02e70a338e60163',1979,'MT','Malta','people-and-society',348,'Population: 326,000 (official estimate for 31 December
1977)
Nationality:
tive Maltese
noun’ Maltese (sing. and pl.); adjec-
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Labor force: 119,554 (November 1977); 82% services
(except government), 18% government (except job corps),
5% job corps, 26% manufacturing, 6% agriculture, 3%
construction, 5% utilities and drydocks; 4% registered
unemployed
Organized labor: approximately 40% of labor force','28d2ee4766a1ddc7af2f6bbc0e0289812d41b6c6f88ea6d5b947c5ace1f0cd62','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cfd743f12b6e253b8f3ebc7036b253e94083584a6a29579d29f4ecfb6f776a7',1979,'MQ','Martinique','people-and-society',352,'Population: 319,000 (January 1979), average annual
growth rate —0.0% (10-67 to 1-77)
Nationality: noun Martiniquais (sing. and pl.); adjective
Martiniquais
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
134
Approved For Release 2004/06/24 :
January 1979
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','0bda8de78f653d33b3da4cdfcadd27940b5cfd2007c491a728829b8fd296f942','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aeb5b021788dab3d2e0435eadbacd4b940bee20b8acd6a8c0a9f8b75a38a88f',1979,'MR','Mauritania','people-and-society',356,'Population: 1,562,000 (January 1979), average annual
growth rate 2.7% (7-72 to 7-75)
Nationality: noun—Mauritanian(s); adjective—Maurita-
nian
Ethnic divisions: nearly one third Moor, at least one third
Negro, one third mix Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national language
spoken by some 80% of the population, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976); remain-
der of population in farming and _ herding; considerable
unemployment
Organized labor: 18,000 union members claimed by
single union, Mauritanian Workers’ Union','3bbb45e0c4416d4e52b989f615099ec59c1dc2024e4861db507c05695ddf988b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f99520aa5f3986af59a99bf4954d1a9094235de5b9497a493159f84cdbc970c5',1979,'MU','Mauritius','people-and-society',360,'Population: 927,000 (January 1979), average annual
growth rate 1.8% (7-71 to 7-77)
Nationality: noun—Mauritian(s); adjective—Mauritian
Ethnic divisions: 67% Indians, 29% 8.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 505,000 (January 1979), average annual
growth rate 1.3% (1-74 to 1-78)
Nationality: noun—Reunionese (sing. & pl.); adiective—
Reunionese
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','86de649dace13a485a87ac2a585e2907cada4aff3cd2a67a015a7074fbdc897e','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('203a44efedd23053686558469f31800d0f282c3abb28c05efd6cc90b7ee687c0',1979,'MX','Mexico','people-and-society',364,'Population: 66,938,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 17.6 million (1977) (defined as those 12 years
of age and older); 33.0% agriculture, 16.0% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and
transport, 3% government, 5.4% unspecified activities, 10%
unemployed, 40% underemployed
Organized labor: 20% of total labor force','80a30fa9159cb1c59190bf5397a38cd83963afc5584c3555fd9d2685b76d3e36','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3a3f11232137f918a437112e524c1c1aec46975b152042695e007d2971a48ee',1979,'MC','Monaco','people-and-society',368,'Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun—Monacan(s) or Monegasque(s); adjec-
tive—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete','f7f3fde77e2e142ae67c13d0a18f8c3b8f6cf22d7fd5577b014c9229c3fe22b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0e95ae0857609008bf755654d7a52a55eedf101b9570889d514ed50447a55aa',1979,'MN','Mongolia','people-and-society',372,'Population: 1,612,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Mongolian(s); adjective—Mongolian
140
Approved For Release 2004/06/24 :
Ethnie divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese
Literacy: about 80%
Labor force: primarily agricultural, half the
population is in the labor force, including a large percentage
of Mongolian women; shortage of skilled labor (no reliable
information available)','aaa2fdf8de05662cdf8c01a5fc0fb490ff35dd37a9799518ad8c9964aa38bf88','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38d0513eb4fcca1ba3f0689c25057e8f128edaaceb3d41496acdc191f2041121',1979,'MA','Morocco','people-and-society',376,'Population: 19,199,000 (January 1979), average annual
growth rate 3.0% (7-75 to 7-76)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Nationality: noun—Moroccan(s); adjective—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official), several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 20%
Labor force: 5 million (1977 est.); 50% agriculture, 15%
industry, 26% services, 9% other; 10-20% unemployment
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT)','09a84f3477c3c3bc662e381ba5b76a698e210bbfb9c94956fa88cf85188fbb04','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ca4cda3daf720b7cdb585695e840fb947213c7c2d20ff8a9ac97e9b359e869f',1979,'MZ','Mozambique','people-and-society',380,'Population: 9,987,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Mozambican(s); adjective—Mozam-
bique
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-African wage
earners, 560,000 African wage earners in Mozambique;
290,000 additional African wage earners temporarily work-
ing in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or
remain in subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are
white','f6e6f53bac26c64ea69accb026dfdc3e999e3f3e47b90bf265c62f516962b4be','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c52946e56b563c9b3cb8d88625c50a4de2c1c352a4e07c354ead7784f19037a',1979,'NA','Namibia','people-and-society',384,'Population: 978,000 (January 1979), average annual
growth rate 2.9% (current)
143
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Atlantic
Ocean
~ NAMIBIA
Windhoek
SOUTH AFRICA oe? *
(WALWIS BAY} a
indian
Ocean
(See reference map Vi}
Nationality: noun—Namibian(s); adjective—Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 18% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','45d7893ec0e577f85b428360fa5f1461b36f3a497626d97ce1e562b0a9932c31','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('704a70fbeeeec55ba4da2f43b1d1123fe6c9d31c43f6a157a672496db5e43126',1979,'NR','Nauru','people-and-society',388,'Population: 7,000 (official estimate for 30 June 1969)
Nationality: noun—Nauruan(s); adjective-—Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (two-thirds Protestant, one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal','3a206d657b3ac6b2ece8f2ede5dd3fcb1c3729eb9a8c5c84944df47f1221453c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcb16097c0bc01280646186b00709accfbbd0d9f3fc6ebddf95791b4418f77f0',1979,'NP','Nepal','people-and-society',392,'Population: 13,854,000 (January 1979), average annual
growth rate 2.5% (current)
Nationality: noun—Nepalese (sing. and pl.); adjective—
Nepalese :
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry;
great lack of skilled labor','eb8dec5a54db3c9ad4ba18f1ac035b2139fcc19e5c7901b760c0cb1aa6dbc5bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3569a8340f16383b0553b588357efab8f2da21a9d31cf9e770cb3ebbe50f8f12',1979,'NL','Netherlands','people-and-society',395,'Population: 13,976,000 (January 1979), average annual
growth rate 0.6% (current)
Approved For Release 2004/06/24
Nationality: noun—Netherlander(s); adjective—Nether-
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 81% Protestant, 40% Roman Catholic, 24%
unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5.1%
unemployment, March 1977
Organized labor: 33% of labor force
Population: 249,000 (January 1979), average annual
growth rate 1.8% (1-76 to 1-77)
Nationality: noun—Netherlands Antillean(s); adjective—
Netherlands Antillean
Ethnie divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish minorities
Language: officially Dutch; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force','f11f910d9f76ee874f90ba096cb316bf20e68b23c015e01fb279cf35c710a041','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dac434e3ac24176548ecd383e4813168a43f69c10bc8ea979d758219d0b2597d',1979,'NC','New Caledonia','people-and-society',398,'Population: 140,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—New Caledonian(s); adjective—New
Caledonian
Ethnic divisions: Melanesian 42%; French 40%; remain-
der Vietnamese, Indonesian, Chinese, Polynesian
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II period; immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
ae Approved For Release 2004/06/24
Population: 102,000 (January 1979), average annual
growth rate 2.2% (7-74 to 7-77)
Nationality: noun—New Hebridean(s); adjective—New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','fb0d643ffadd563058e5c1edd606467c6138a5751c9353ec2b5ae90b927835a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93009b8182fd5602725f77b35da8dc2222a1d2e7a20a6968fd2f6e88926cbc7c',1979,'NZ','New Zealand','people-and-society',402,'Population: 3,176,000 (January 1979), average annual
growth rate 0.8% (1-75 to 1-78)
151
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
a
7 Pacific
SS Ocean
Coral Sea
Tasman
Sea
NEW %
: ney: Wellington
{See reference map Vill}
Nationality: noun—New Zealander(s); adjective—New
Zealand
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified; 1%
Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 33% manufac-
turing and construction, 9% transportation and communica-
tions, 24% commerce and finance, 21% administrative and
professional; unemployment 5.7% (1976)
Organized labor: 52% of labor force','7c2d51190d261e191b619cb0f2c3d3ffb6238780927b2ad7b5db1ad9797db15a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78f0530cc91155f0df24809e0decce25fe61561de2c49912de7119c605417f5d',1979,'NI','Nicaragua','people-and-society',407,'Population: 2,447,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun—Nicaraguan(s);
guan
Ethnic divisions: 69% mestizo, 17% white, 9% Negro, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking minority
on Atlantic coast
Literacy: 52% of population 10 years of age and over
Labor force: 728,419 (1977 est.); 43% agriculture, 15%
manufacturing, 13% commerce, 29% other; shortage of
adjective—Nicara-
skilled labor, but underemployment of unskilled labor
except during harvest
Organized labor: about 5.6% of labor force
Population: 5,064,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77)
Nationality: noun—Nigerien (sing. and pl.); adjective—','f2b61a51531be466220f97d031b45ee08aa0fd7ad454882722477c5df4a72d3c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f6a93db220c11b739154c7447cfd91a49e8fa8a99184bf09b9f9e0d69ab33dd',1979,'NE','Niger','people-and-society',411,'Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Dierma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible','46a83d9a25f4fa2a8e5c557b5f1d735d73e9ad81d2810013ecda17b15f1a3dcc','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb8b29293ea3b458495f1358760191f33d1a699d7ef3fdabbc07cc4479367a2e',1979,'NG','Nigeria','people-and-society',416,'Population: 69,492,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Nigerian(s); adjective—Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Iausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also
widely used ‘
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3 million wage earners, of whom
560,000 work in modern enterprises
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions','d77983ca1ad647b5fdebe86891056b33a3b8338a4c0ff3837160f0b5a9a1064b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4db600e42147697e81d1b579c7b3fc1072d6a461f80c6bd632a3d8d6130650',1979,'NO','Norway','people-and-society',420,'Population: 4,067,000 (January 1979), average annual
growth rate 0.4% (1-77 to 1-78)
Nationality: noun—Norwegian(s); adjective—Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-speaking
minorities
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
(See reference mep iV)
NIGERIA/NORWAY
Literacy: 100%
Labor force: 1.9 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.3% commerce, 9.9% transportion and communica-
tion, 28.5% services, 1.4% unemployed (average annual
1977)
Organized labor: 60% of labor force','eb4297b2ddffcf054c4ef9f73be994eac33d4fe14b1de83f79ec1edef5a34a9d','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21aeb7fa104c66025d9892128bc77456632a986dccb00ba55e8c25c39b5eddae',1979,'OM','Oman','people-and-society',424,'Population: 558,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','43b96c119772a04e99e36d4c1efe9d3b4a369290d2d9651a91048a28335ad6f0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b20756f0430e7f9f0c14fb2b0179ff8dad0314b0b5b7dff49e315c4e0efe940',1979,'PK','Pakistan','people-and-society',428,'Population: 78,978,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area-of Jammu-Kashmir,
(January 1979), average annual growth rate 3.0% (current)
Nationality: noun—Pakistani(s); adiective—Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages—7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 22 million (1978 est.); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed
Organized labor: 5% of labor force','e7e1dc77d24e8aefc996803c8578726e19cb56b5524522d879fd467b1697bd72','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c116c516df191c219da341d245d68fc13314e1b3a2c75dee612a63255d3470a',1979,'PA','Panama','people-and-society',432,'Population: 1,837,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: | noun—Panamanian(s); adjective—Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and fishing;
9.7% manufacturing and mining; 6.8% construction; 5%
Canal Zone; 3.9% transportation and communications; 1.2%
utilities; unemployment estimated at 10% to 13%; shortage
of skilled labor but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','b58a08469fdf3941bab432051d159e2f1692a37f32b9dd97a7e9a02dd4c32324','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81f7e72486293c05ce2bc75a6afbcc41932a162b84156d5b0625bffb4b086b39',1979,'PG','Papua New Guinea','people-and-society',436,'Population: 3,024,000 (January 1979), average annual
growth rate 2.6% (7-73 to 7-77)
Nationality: noun—Papua New Guinean(s); adjective—
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 3 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: no available figures; mostly subsistence
farmers','6501f8e394e930be12c344d7529a82be8516e05f4ac5cd50a1042b3cc8a20bd0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eeed61be8e21ad46616fe5993ab76676c64cae9f57e52d4ac27486990d2883e',1979,'PY','Paraguay','people-and-society',440,'Population: 3,143,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality:
guayan
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
noun—Paraguayan(s); adjective—Para-
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 52.6% agriculture,
forestry, fishing; 28.2% services, 19.2% manufacturing and
mining (1970)
Organized labor: about 5% of labor force','a07cd8ccd7dbce91c130f2ae0d25f7ca4445e340e29380d160fff1eb4fb0aae5','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d10d681df487911756eabdc38743b6e00964922350d2a3b8f599323cac847d',1979,'PE','Peru','people-and-society',444,'Pepulation: 17,053,000 (January 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Peruvian; adjective—Peruvian
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish,. Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','5e7c077d7456a287d0247df49ddefa47c8cc63c1cf600c038a33a9f31acc8e96','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae59017c2292eb3cada47c4852e79a012b8a686ebf1899b53e192a97569d3a85',1979,'PH','Philippines','people-and-society',448,'Population: 46,388,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Filipino(s); adjective—Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 15.4 million (1976); 60% agriculture,
forestry, fishing, 12% manufacturing, 10.5% commerce,
166
10.5% government and services (business, recreation, domes-
tic, personal), 3.5% transport, storage, communication, 3%
construction; 0.5% other','1a4f52022b128665e5e3ea4851fe8c3b8870b96d34142e4366c7be2ca6455685','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb8af4c01a609197a2bdab8e280132894d6c286afdaf99231f4c24d8beee2dd',1979,'PL','Poland','people-and-society',452,'Population: 35,210,000 (January 1979), average annual
growth rate 1.0% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 18.8 million; 32% agriculture, 25% industry,
43% other non-agricultural (1977)','28e77f4c6a5ef5aed254c82a8ad2c460a5d9830212aa87e46c561c2a8a82405f','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c7f016121fa75e6cde6884a8121517f2f2c48e654978e6a53e466cf469e6814',1979,'PT','Portugal','people-and-society',456,'Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,833,000 (January 1979), average
annual growth rate 0.7% (current)
Nationality: noun—Portuguese (sing. & pl.); adjective—
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
number less than 100,000
168 Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1976) 3.2 million; 27% agriculture, 36%
industry, 37% services; unemployment—now more than
14%—is largely due to influx of refugees from former
colonies, returning migrant workers, and military cutbacks
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers—National Intersindi-
cal (CJTP-IN) claims to represent 85% of the labor force; the
Socialists and Social Democrats have lost ground over the last
year despite efforts to improve their standing with organized
labor','bda55236821c666cb2c289f72256e8020cbe33fd1ef64d2e6ceec912cfa1181c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('236b43bd99be921f01a0efd65c14d10937e378cc1165b5112691543660dbf83f',1979,'QA','Qatar','people-and-society',460,'Population: 165,000 (January 1979), average annual
growth rate 3.2% (current)
170
Approved For Release 2004/06/24 :
(See reference map V)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign','6fce42e11f9b853c270603af5cee4e0baa57e86153922ac22e523262e3013dc2','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c0b20159d76d21befa4dd7eace4c61d98976310e6543b0d0ee87736e2d64bf8',1979,'RO','Romania','people-and-society',463,'Population: 21,964,000 (January 1979), average annual
growth rate 0.8% (current)
Nationality: noun—Romanian(s); adjective—Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 60,000 Jews, 30,000
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.2 million (1975); 38% agriculture, 31%
industry, 81% other nonagricultural','540e3064eb0a47e2ae5b466bf17da86ba590bc217d3549947879e13c452ae86e','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d63a5e2660baf07cbb8d2e876742049ad2c4b14869e819386ec04d96dcdc25b9',1979,'RW','Rwanda','people-and-society',467,'Population: 4,508,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun Rwandan(s); adiective—Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','a0b6dc1830a785595d548f571df08f3260a513a891884ddf98a5d9b2a1cef699','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82df42ce6e6c40783865e7e209fe5f9102faed899e57cb6ac595032108e215c1',1979,'SM','San Marino','people-and-society',471,'Population: 21,000 (official estimate for 30 June 1977)
Nationality: noun—Sanmarinese (sing. & pl.); adjective—
Sanmarinese
CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
(See reference map iV}
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members','5a50d206ac182dae4c32d1754d6e39bdb84c51ed50d3498d589a92c1e0834c16','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fba3ce0fee72d18b8b443f6308aefcee7dfcaae0f32be8a93bcce3e4260a3d5',1979,'ST','Sao Tome and Principe','people-and-society',475,'Population: 82,000 (January 1979), average annual
growth rate 1.2% (current)
Nationality: noun—Sao Tomean(s): adjective—Sao
Tomean
Ethnic divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant,
Seventh Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
180 Approved For Release 2004/06/24
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','05528c20ec044c909c813ecca2f1625405ba117e6611075af0a76cbff18ddb6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8da2ff74b280c88e4836c884256e71123bd275335f78bdada73d04c6eba1240d',1979,'SA','Saudi Arabia','people-and-society',479,'Population; 7,984,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi Arabian or
Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% -(est.)
Labor force: about 33% (one-half foreign).of population;
40% agriculture and herding, 12% construction, 12% service,
12% government, 11% commerce, 18% other
Population: 8,260,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Syrian(s); adjective—Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% Alawites, Druze,
and other Muslim sects, 18.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 1.8 million; 32% agriculture, 26% industry
(including construction), 42% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 17,098,000 (January 1979), average annual
growth rate 3.0% (current)
Nationality: noun—Tanzanian(s); adjective—Tanzanian
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Mainland—40% Animist, 30% Christian, 30%
Muslim; Zanzibar—almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher education;
Swahili widely understood and generally used for communi-
cation between ethnic groups; first language of most people
is one of the local languages
Literacy: 61%
Labor force: under 400,000 in paid employment, over
90% in agriculture
Organized labor: 15% of labor force','9082db2129a4af8942445b3fe6562af308176db26a576d8a43c98fcd147c6fe6','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac36c5375066c18fc1bf5a9074f112eebdc4b372e53dce48868f19330197df42',1979,'SN','Senegal','people-and-society',483,'Population: 5,450,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Senegalese (sing. & pl.); adjective—
Senegalese
Ethnic divisions: 36%. Wolof, 17.5% Fulani, 16.5% Serer,
9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African,
1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
182
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading—now spoken to some
degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers, about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central unions, major central is CNTS,
an affiliate of governing party','4cdb910eaf57694880a6e5165c16f2f9ae7fb95ab0c4e53a9b98e1c0024d51cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da8d254cd16890af2e948a9b3d0b00e9d58c2676a6d276e5a2aa870a513f1aa6',1979,'SC','Seychelles','people-and-society',487,'Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited; 90% of school-age population is
attending school
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
33% public sector employment, 20% private sector employ-
ment in agricuture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','4dfae44dbb17cefafefeb30dbf8b29c27b9329ab1ffb9da9a156209fe0e7d981','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a81d3490054b97116225060817f60bd7a32e117488997bcbf3e4882e02d3697',1979,'SL','Sierra Leone','people-and-society',491,'Population: 3,293,000 (January 1979), average annual
growth rate 2.3% (12-74 to 7-76)
Nationality: noun—Sierra Leonean, adjective—Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','d4bc890803c145a95a2ebb878d8533048aaae9064b07a79a66c584a8e5caef6b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9583fe6ec49b8160c65dbf4c342f37b5cfc6cb4a8e3a6c0d5d2079d5dbf42f20',1979,'SG','Singapore','people-and-society',494,'Population: 2,354,000 (January 1979), average annual
growth rate 1.8% (7-76 to 7-77)
Nationality: noun—Singaporean(s), adjective—Singapore
Ethnic divisions: 76.2%. Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 919,000; 2.2% agriculture, forestry, and
fishing, 0.2% mining and quarrying, 27.2% manufacturing,
30.5% services, 4.6% construction, 23.5% commerce, 11.7%
transport, storage, and communications
Organized labor: 24% of labor force','40468bed8a00dc353f3e1a3abc7780acfee192736884b57b8fed5b05ee9670d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bf6c0159eba111dc5d1387b4c2f98224e21af4afda143012f65e48dc3e99ab7',1979,'SB','Solomon Islands','people-and-society',497,'Population: 215,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Solomon Islander(s); adjective—Solo-
mon Islander
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Ethnic divisions: 93.0% Melariesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60%','f5d6607ba427c9a997991fd9c1ff6fa09e02d1127b49d2e59dec5e91eab492f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a58726ad761cad5d055026ef1ab06c288ceeaadb70631da4479e806125a0334b',1979,'SO','Somalia','people-and-society',501,'Population: 3,428,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Somali(s); adjective—Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1976); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977','f1b0e7f2c1faf68d070567a09ccd6fe128eb73a995d57d2bbe8a27f6b0a7a8f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08545954cbb41a3474ffecdc527aa29c127701b7df734bdba3a6c66264978802',1979,'ZA','South Africa','people-and-society',505,'Population: 27,754,000, including Bophuthatswana and
Transkei (January 1979), average annual growth rate 2.5%
(7-75 to 7-76); Bophuthatswana 1,123,000 (January 1979),
average annual growth rate 2.2% (current); Transkei
2,214,000 (January 1979), average annual growth rate 2.2%
(current)
Nationality: noun—South African(s); adjective—South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 53% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); relatively small African
unions have no bargaining power
Population: 2,214,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Transkeian(s); adjective—Transkeian
Ethnic divisions: 98.9% African, 0.6% white, 0.5%
colored. (mulatto); Africans belong to Xhosa ethnic group
Religion: whites and coloreds predominantly Christian;
Africans either animist or Christian
Language: whites, coloreds, and educated minority of
Africans speak Afrikaans or English; bulk of Africans speak
Xhosa
Literacy: high for whites and coloreds; low for Africans
Labor force: roughly 400,000 of whom only 50,000 are
regularly employed in Transkei; bulk are migrant workers in
Organized labor: no trade union, although some Trans-
keians employed in South Africa belong to South African
unions
Population: 37,774,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (January
1979), average annual growth rate 1.2% (current)
Nationality: noun—Spaniard(s); adjective—Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97%
Labor force (1976): 13.3 million; 21% agriculture, 38%
industry, 41% services; unemployment now estimated at 8%
of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent about
25% of the labor force','545ec71d988b34e786f1d237a928aa7265a70e4cdb896e0bc1fa2059cdff3008','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('598faf84e1e5a05cb377f99c03a87c9844a63a43a64ada19ee0e6f91ac48d8fd',1979,'LK','Sri Lanka','people-and-society',511,'Population: 14,393,000 (July 1978), average annual
growth rate 1.5% (current)
Nationality: noun—Sri Lankan(s); adjective—Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other
Language: Sinhala official, spoken by about 70% of
population; Tamil spoken by about 22%; English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons—53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates
193
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
SRI LANKA/SUDAN','955e27b1bd6e4a6caa84ad7e13af6dbf7d2aa3f2d336c5d13a049f789262ebf0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469d5611508e48007b043afbd7968de0b0665d3819d37ec2ee1c8e33a4001141',1979,'SD','Sudan','people-and-society',515,'Population: 17,912,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Sudanese (sing. and pl.); adjective—
Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry,
commerce, services, etc.; labor shortages exist for almost all
categories of employment','9bc3cd37d1cff048ed49015d6dd85c884c296c8ca08584bc86b3a30b0dca9a75','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b6681882f454e9cb03a362a1ba6c2bf21d098e41a7ad6a1ef5377ea3a1e7103',1979,'SR','Suriname','people-and-society',519,'Population: 388,000 (January 1979), average annual
growth rate 1.5% (1-68 to 1-77)
Nationality: noun—Surinamer(s); adjective—Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.8% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
and is lingua franca among others; Hindi; Javanese
Literacy: 80%
Labor force: 118,000
Organized labor: approx. 33% of labor force
Population: 533,000 (January 1979), average annual
growth rate 2.8% (5-66 to 8-76)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnie divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 835% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor: about 15% of wage earners are
unionized','d28b5025367246345b187204462750e7820bb86c598e76f38f921c295b41498c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35e223388643f951e6e13983c3d84fb00ac2e31a297d8c3475c678e42d278c0',1979,'SE','Sweden','people-and-society',523,'Population: 8,285,000 (January 1979), average annual
growth rate 0.2% (current)
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities
Literacy: 99%
Labor force: 4.2 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2% construc-
tion; 13.6% commerce; 6.5% transportation and communica-
tions; 29.8% services including government; 5% banking;
75,000 or 1.8% unemployed (average annual 1977)
Organized labor: 80% of labor force
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 |: CIA-RDP79-01051A001000010001-5
January 1979','8086a90d97ad8ef44274db024983bcadc7018d7047552c5ccc15f9d4ab3c465a','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efb779e697b483116cb60572beb004dd0c8fc6167f4088106146b9d38b516304',1979,'CH','Switzerland','people-and-society',527,'Population: 6,286,000 (January 1979), average annual
growth rate —0.1% (1-77 to 1-78)
Nationality: noun—Swiss (sing. & pl.); adjective—Swiss
Ethnic divisions: total population—69% German, 19%
French, 10% Italian, 1% Romansch, 1%
nationals—74% German, 20% French, 4%
Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population—69%
German, 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 2.6 million, about one-tenth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry.
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.3% unemployed in July 1978
Organized labor: 20% of labor force
other; Swiss
Italian, 1%','4888db248d30c7309a6a11e8778502b15f19b7b02b4de99b4e77a2bbb8f70b83','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4e59870d9639999afafa9dc41b16318e1519ed168bb685da67f043410f19cb7',1979,'TH','Thailand','people-and-society',533,'Population: 46,443,000 (January 1979), average annual
growth rate 2.6% (current)
204 Approved For Release 2004/06/24
Nationality: noun—Thai (sing. & pl.); adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry','ff276ce4010505e39f7ec079b084287e6fd994616180acc2f9c5682895a84b27','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04bf1fea7af2bd9f4358d2d9fddb58fd5c3e5718a88a5c943b8225b5ce81a415',1979,'TG','Togo','people-and-society',537,'Population: 2,493,000 (January 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Togolese (sing. & pl.); adjective—
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: 1 national union, the CNTT organized
in 1972','8b54605226bc44dfb7224c5ddcf751696cd66441b9e35fa4ab1a96950e953a6f','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3716df11f295360ed708cd6878636f1e82044682a06a0609e1fa78029769af8e',1979,'TO','Tonga','people-and-society',541,'Population: 91,000 (January 1979), average annual
growth rate 0.3% (current)
Nationality: noun—Tongan(s); adjective—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free: Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,3038; mining 599
Organized labor: unorganized','342dba46ffe59d8f6d8fa255077319a0f8eca2fd19a8bbf669fbf56e2d809ce0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a45703623ae366daed9404624e1386ca31b5779971617d8efad00daec9cd06a0',1979,'TT','Trinidad and Tobago','people-and-society',545,'Population: 1,129,006 (January 1979), average annual
growth rate 1.1% (7-70 to 7-76)
Nationality: noun—Trinidadian(s), Tobagonian(s); adjec-
tive—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 23.0% services, 2.9% other
Organized labor: 30% of labor force','e32b4ab1ad782c8d1a44bdffee2efb068ebf06b77776eb3f9c2b3296320efaf8','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e2a742010830358c5bab8b29aee3220ec2f3536ad5fbd4a01de972afe614b1',1979,'TN','Tunisia','people-and-society',549,'Population: 6,327,000 (January 1979), average annual
growth rate 2.7% (current)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
{See reference map Vi)
Nationality: noun—Tunisian(s); adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
‘Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party','f9c5062e0d3039fe6a0657051751939c6005bb21246fb32cea45a217ccb1a6bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d5d09218a394b6d23694732ef6f4517e8bd722be7a6efb9ce17cf4472faf4d1',1979,'TV','Tuvalu','people-and-society',553,'Population: 6,000 (preliminary total from census of 8
December 1973)
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','71c6fec5a487b746bbff47adacd4268d5e738eb3f75fcdfd86e912a45c23f6dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8cc7a040ec4bfd3b120d53b33938df29a16070b9b87d3bafa46344562700a47',1979,'UG','Uganda','people-and-society',556,'Population: 13,002,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun—Ugandan(s); adijective—Ugandan
Ethnic divisions: 99% African, 1% European, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist
Language: English official, Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 262,586,000 (January 1979), average annual
growth rate 0.9% (current)
Nationality: noun—Soviet(s); adjective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim,
3% other
Language: more than 200 languages and dialects (at least
18 with more than ] million speakers); 76% Slavic group, 8%
othe. Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 138 million (mid-year 1978), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported','107f8eafd2e4e88746a7e37c8ab7cb1de6cbe446641dbf11c7f7eb4d7773b1f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61ab03083018701ab64fd03d87ef1d4eda4354546c44f4a337fcc1b0388cf75e',1979,'AE','United Arab Emirates','people-and-society',560,'Population: 656,000 (preliminary total from the census of
29 August 1975)
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians)
8%
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry; 2%
U.A.E. Arabs, 7% non-U.A.E. Arabs, 91% Indians, Pakistanis,
Iranians','f557f0c0a1f6b17f87b7a55879ff389eff3cd23a53775e03b78e301198484524','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16a4e1443500f43763ee54af167aef7ca8453930c89f4afc3db80fab0b9ca761',1979,'GB','United Kingdom','people-and-society',564,'Population: 55,846,000 (January 1979) average annual
growth rate —0.1% (current)
Nationality: noun—Briton(s), British (collective pl.);
adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5% Welsh, 3%
Irish
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other; 2.1%
unemployed
Organized labor: 40% of labor force
Population: 6,582,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Upper Voltan(s); adiective—Upper
Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence farm-
ing, and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union groups','655a39674ad3866a1e3d963277fe0addae75926d83350a4f4daebcb41e4cae8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2325617f6b3988c3695b0108d797b9264bacd6b0b30953500cb5227f56c9957b',1979,'UY','Uruguay','people-and-society',568,'Population: 2,902,000 (January 1979), average annual
growth rate 0.6% (current)
218
Nationality: noun—Uruguayan(s); adjective—Uruguayan
Ethnic divisions: 85-95% white, 5% Negro, 5-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors—25% government; 34% industry; 10%
service; 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized ‘labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1977)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories—executives, officeworkers, and
salaried employees
Organized labor: none
Population: 14,541,000, excluding Indian jungle popula-
tion (January 1979), average annual growth rate 2.2%
(current)
Nationality: | noun—Venezuelan(s); adjective—Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 45% of labor force
Population: 51,883,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Vietnamese (sing. & pl.); adjective—
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain tribesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','aedada49bc500596b019aeb8ec5a4cc2c1afb26aa6c36ea48c3d5716ff75e3d1','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e42b8cb65692a5057c5380659a5e6baf82529aa7fe8301f16780741ac4e648dc',1979,'WF','Wallis and Futuna','people-and-society',572,'Population: 9,000 (official estimate for 1 July 1973)
Nationality: noun—Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective—Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','eee2ded006719b315e3ecd4d0f9059021c8b24cfd43bd59d59294889fe8428ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('645397b6ec89f7b98e5c51bf12bbbfee04e7426e7e7e1883effc28df61631c81',1979,'EH','Western Sahara','people-and-society',576,'Population: 75,000 (total from the census of 1974)
Nationality: noun—Saharan(s); adjective—Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: Hassaniya Arabic
Literacy: among Spanish, probably nearly 100%; among
nomads, perhaps 5%
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none
Population: 155,000 (January 1979), average annual
growth rate 1.0% (1-76 to 1-77)
Nationality: noun—Western Samoan(s); adjective—West-
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
Labor force: agriculture 19,148; mining and manufactur-
ing 1,716 (1961)
Organized labor: unorganized
Population: 1,765,000, excluding the islands of Perim and
Arabian
Sea
Indian
Ocean
{See reference map V)
Kamaran for which no data are available (January 1979),
average annual growth rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,078,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 22,074,000 (January 1979), average annual
growth rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.2 million (1976); 36% agriculture, 20%
mining and manufacturing, 44% other nonagricultural
activities; estimated unemployment averaged 5% of domes-
tic labor force in 1976
Population: 27,474,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes—Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 18% in wage
structure','5ffec54059f38012ed14e561e11dab8854a136eda5b9d1da7c2a83453c047391','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f54c4e5b25ba14e1bf8c6eea07cdda082cc70747da464620fec7e0724c36242c',1979,'ZM','Zambia','people-and-society',580,'Population: 5,559,000 (January 1979), average annual
growth rate 3.2% (7-76 to 7-77)
Nationality: noun—Zambian(s); adjective—Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
230
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellancous services,
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','74860cac0108a32c2d6c01e4112be2e3e343d5c197965827cfb6ce8b45c8dff3','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b88b6831f252e5fc7c9de664774e630c2f5263f94b1f06744c22bdf387fdd1ee',1979,'US','United States','people-and-society',584,'Population: 219,334,000 (January 1979), average annual
growth rate 0.8% (current)
Ethnic divisions: 86.5% white, 11.7% black, 1.9% other
Religion: total membership in bodies,
129,714,000; Protestant 69,743,000, Roman Catholic
48,882,000, Jewish 6,115,000, other religions 4,973,000
(1975)
Language: English, predominantly
religious
Literacy: almost complete
Labor force: 96.9 million, unemployment 7.7% (1976)
Organized labor: 20.1% of total (1976 prelim.)','468840bf6b162bcedd3c7897ffa883a60d65078cd3ac6aa21674934c5705f130','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eac3f776ae9c36aba6ac9fb932148b41aeb465cb0a800b9af00f5cbe29cb89f',1979,'HK','Hong Kong','military-and-security',213,'(See reference map Vil}
LAND
1,036 km?; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
SECRET
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km','c97dc09138a63ce30d2b05b5fef01a412004f900388d9862f2219ebbdd1c76f7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('553b5000642b93409e8424b114cd239d61229c14ced283b9bb375e65a6a35559',1979,'HK','Hong Kong','military-and-security',257,'/See reference map VII)
LAND
1,036 km 2 ; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km','6ed5127ff956516b4c72f3c796305512c1900f4b4c6f87fd0bfab353d16baaac','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7d4cbd064a05dace968b877da9d3fa6e33e1978719e081ef5be102de214355',1979,'HK','Hong Kong','military-and-security',243,'es
(See reference imep Vit}
LAND —
1,036 km?; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km','0609506b30b8e2d82e8753e08d374ea7ab9876e5724b1087e2b1e3c06fec2e4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

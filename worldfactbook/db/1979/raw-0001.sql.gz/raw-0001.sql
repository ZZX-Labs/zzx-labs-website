SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e9db6d8acb179a305edf1545ec32b31b86c408f3529b5f61649816a37d159f',1979,'','','raw',1,'if 4a. Approved for Release: 2018/04/27 C0672 704 2s
: Seer’ 1 @E%. National |
| a (a) ce. | os sig
Center
; National
| | Basic Intelligence |
| Factbook | :
July 1979
GLEEAIRE »-— Jo0g398,y soUESTTPOIUT aISeg PeUOHEN
a Sa
4
|
t
Secret :
GC BIF 79-002
July 1979
\\
Approved for Release: 2018/04/27 C06727042
i
F
\\
t
i
L
!
f
|
i
| Warning Notice .
|
:
re National Security Unauthorized Disclosure
| | Information * Subject to Criminal Sanctions
F
|
|
;
‘|
|
|
|
|:
| : Dissemination Control! ——
! Abbreviations :
! —
4 ;
il y .
;
i _
|
f oe
Pr
|
l
a |
Oe
—————VK— KEE
Approved for Release: 2018/04/27 C06727042
c—,
7
=f Nes
BRS
oe ee Doo — palate as ws y . tomer 4
: Ne Por ited
Approved for Release: 2018/04/27 C06727042 ;
4n x5
Ma National “Sercret-
tie Aaceceniel | : (b)(3)
SZ Contes :
National
Basic Intelligence
Factbook
July 1979
Supersedes the January 1979
edition, copies of which should
be destroyed.
The Factbook, a compilation of basic data on political
entities worldwide, is produced semiannually by the
Office of Geographic and Cartographic Research
with contributions provided by various components of .
the Central intelligence Agency, the Defense intelli-
gence Agency, and the Department of State. Com-
ments, suggestions, and requests for additional copies
may be addressed to:
Office of Geographic and Cartographic Research
(Attn: Factbook)
Central intelligence Agency
Washington, D.C. 20505
Unless otherwise indicated,
individual entries are Unclassified.
~Secret—
GC BIF 79-002
July 1979
Approved for Release: 2018/04/27 C06727042
viii
.TAIWAN
Approved for Release: 2018/04/27 C06727042
=f
Tanganyika (see TANZANIA)
TANZANIA 835528 i ato cheats Sing Selene AM scaled Abatement de cles tae Moc ietee eA Glae La,
Tasmania (see AUSTRALIA) :','17c76fc57964e9e265cdb7e01247ff344b48f8f5bed7f69f931d495d9a334a11','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ad26d7eeaf8730f5c21a2d35fdccb089d029694faac804631cbc3c82a1c1084',1979,'TH','Thailand','raw',2,'—U—
UGANDA °:cicc0c ine diaries fot hd eh codeine lt da
Umm al. Qaiwain (see UNITED ARAB EMIRATES)
USiS Re xP ei AS a oe AB de sel tah etna ic alban aaa dal ee
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain o.oo... cece teetteec eee
United Arab Republic (see EGYPT)
UNITED’ KINGDOM: ii.chetnde eee ease oi ineeulaten caunranniiieaieald
WINITED: STATES © esc tics pick ageh csesessertestolentiveaedguist ae gateactavtear ue mueaadonua soto
UPPER: VOLTA) i icsisescitend, dy acto aha ieee oe aN ha aR ae
URUGUAY 2.2025 sd on acs th ceebdeelth deaail bs it aa poidivoes be patsagus Reve ee iS Meera te
Vv
VATICAN CITY
VENEZUELA
VIETNAM
—w—
WALLIS. and: FUTUNA: | o5:) 022.5 Sic iecsa facets cove idk Mieiadan dls svtasadeaedelde Wgec es
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
WESTERN SAMOA
ys
YEMEN (Aden)
YEMEN (Sana)
YUGOSLAVIA
Zanzibar (see TANZANIA)
ZIMBABWE-RHODESIA
Approved for Release: 2018/04/27 C06727042
248
July 1979
Approved for Release: 2018/04/27 C06727042
July 1979
éSea reference map V)
LAND
766,640 km?*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','4a3473dce6e084136ed98a392f13f6d6cce4c4e03f22d2b86f9359158600c544','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56daf669fc953063bf56b21555ec8b28544f0fd6cf6734232215db1305d28a5a',1979,'','','raw',1,'Bee
Approved for Release: 2018/04/27 C06727041
National 59 U (3° “Secret
Foreign
Assessment
Center
National
Basic Intelligence
Factbook
January 1979
~Seeret_
GC BIF 79-001
January 1979
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
NATIONAL SECURITY INFORMATION
Unauthorized Disclosure Subject to Criminal Sanctions
DISSEMINATION CONTROL ABBREVIATIONS
NOFORN-— Not Releasable to Foreign Nationals
NOCONTRACT~- Not Releasable to Contractors or
Contractor /Consultants
PROPIN- Caution—Proprietary Information Involved
NFIBONLY— NFIB Departments Only
ORCON- Dissemination and Extraction of Information
REL...
Controlled by Originator
This Information has been Authorized for
Release to...
Unless otherwise indicated, individual items are
TUNCTASSHHED.———
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
FOREWORD
The National Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published semiannually
by the Central Intelligence Agency. The data are prepared by components
of the Central Intelligence Agency, the Defense Intelligence Agency, and
the Department of State. Comments and suggestions should be addressed to
the Office of Geographic and Cartographic Research (Att: Factbook),
Central Intelligence Agency, Washington, D.C. 20505.
This publication is prepared for the use of U.S. Government officials.
The format, coverage and contents of the publication are designed to mect
the specific requirements of those users. U.S. Government officials may
obtain additional copies of this document directly or through liaison
channels from the Central Intelligence Agency.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
~SECRET- January 1979
-t- Page
TANZANIA, loses ht tee teak te tl Ra A aM poate al oN ath 244
Tasmania (see AUSTRALIA)
THAILAND: os sscisechtist Seustecs eae aee cet, Shab clei ab a OR eels Pts cout Maree tt elaes BOR ot 245
FOG, ieecrisk EL AI Nol Sole hk AN EY Oya tt ote dedthee ch ped nd eve 247
TONGA ooo llassiinad tia dba ots ale het ae ea oa ee ed tenth tal Mids faut Seven 248
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ooo. cceccecececcecesestctetevtte coves ceteveseiteteeeetece 249
TUNISIA ee 2oee Se STON get ales SPN es eel ee ase SAN etl Oct a pe 251
CORRE ic. 2e5ote 502 oN ciel ats po eile as ee aN Me la on Be ek oat a ete ee ta vt 252
TUVALU (formerly Ellice Islands) 00.0.0 ceccccccecee tcc cecececeeeeeeeeeeeeeee ce, 254
=
UGANDA 2) acted ese acd deed te i Trt Lele a tak ttn togh ote 255
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USSR? siesta ee Nees a eet Sas tet el ee ne a Saf Te OT a 256
UNITED ARA® EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain oo. 259
United Arab Republic (see EGYPT)
UNITED KINGDOM ooo ccc cece cccececacecetevavenerestetieevins ss ccutvevestititeteveveneees 260
UNITED “STATES © ects. csc inal Pah Sia Re COT uh Ee peda itn oie ay 280
UPPER VOLEAS f3cccess3 20) ag ea Ge Ee ae se ea ts aaa 262
URUGUAY > -5s:che eset och iat ath tes lahat ae Le Ma A Cat, (heel val iy 263
ye.
VATICAND CIV. 2.3 ited Stat etek e al Orie ld, Grech tte ce eee A ade 265
VENEZUELA 220.3 5 footy Ei ec ett reech conden aloha es eR es oe 266
VIETNAM 252.022 css. Dect LE sea seerass Seen t Nl inn Sane chet ee tet ge! Be 268
—w—
WALLIS and FUTUNA once cc ccsesceecesteeestevsecetevesesceteeceveteteteeeteeere, 270
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) 0.0.0.0. cocccceccccceseeeeeceeeeccce 270
WESTERN SAMOA ooo ccceecces sees sense nes ecucevevevevevesteseatsisesitivatesttavstivesteseterteceece. 271
—y—
YEMEN. (Adon). ¢:c0:2.35.05 Sy. esa tn a en Hei dewees din lee Ai rece, nie & 272
YEMEN ''(Sona) \\ 20: 30.6 Ones aes Recetas eon, Ga 8 OR a a ak 273
VUGOSLAVIA 4. iee tases, etegsle iS ea bebe Aten tenty hvac Mae aba 275
—7—
LAURE ects weet teen beaded land ihe So, nA RO Nt et tat ate cms ee a Ht ae Le Pog 277
AMBIA Shep Me vet Beret recenseblen at ert ithe, Wee EE De BER as ot tee ae Ct aie! 278
Zanzibar (see TANZANIA)
viii ~SECREF-
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
SECRER.
NR Record TURKEY NR Record
NR Record
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
252 “SEGREL_
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
“SECRET
TURKEY
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','91cbd5d071dd25ea465713c0f86903693de45bbebdbbbc2608e54b323ca18688','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9921eb1750116333338f9cc2fc3654184c0c86035c94b5249c726824e630662f',1979,'','','raw',1,'Approved for Release: 2018/04/27 C06727040
. January 1979
Zz
0)
a4
0
3
z)
1)
9
¥,
0
5.
a
0
- eet: . | National Basic Intelligence
$1 FACTBOOK
ay
>
0
as |
‘@
n°
0
f
y
[ GC BIF _
January 1979
Approved for Release: 2018/04/27 C06727040
eee ee eer etahe tet,
Approved for Release: 2018/04/27 C06727040
FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
- Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
U.S, Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5
Approved for Release: 2018/04/27 C06727040
rr
: Approved for Release: 2018/04/27 C06727040
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-001035.
Approved for Release: 2018/04/27 C06727040
’ viii
‘WESTERN SAMOA
Approved for Release: 2018/04/27 C06727040
—TI—
TONGA oo... picts cetera dd halk tas 42M acl lace Bage Rt ang a eeIR eg
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ........c..cccssssssssssssssvsssssevesssctessssessesssssssisisteeeceessissnesseeee','229191d21c5e7113b8bc9c7834f6ee045e559d212a2c62569a00745b896f5e03','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4413ea7ba7b0098ce17831be4982fa9a1c8aa594fc9b7b65351ea3a7221533',1979,'TN','Tunisia','raw',2,'TURKEY
ye
UGANDA) ):ecce ie tctivinl Gaiid neil ti lnetin dain Minion iieas alae SAS AS
Umm al Qaiwain (see UNITED ARAB EMIRATES)
UNS SRE soos eciecdid Setaa ces Hideo ae ses enbevicah oe esn ave tuapiea vests eaetabaebeyainsvedavays ba dan dagas¥ deaddeceetbagnetyeee
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain
United Arab Republic (see EGYPT)
UNITED KINGDOM: 0).50$:68.00sisstcta neve ieee ie atch hier
UNITED STATES) «ies st ndecta isda iigetenensc ce ie deed rhe tcien aroatinnaedieuaties
UPPER VOLTA > f.)cs dees hei hedhccsidesess ese ad dete as ae Gaetan','87fea2c6025fe50108bbe7331561928567fe86fd954f857c29e9754a3d429d1f','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a00e67a3a89b3f82f02ceb50c0e01d29e474d988f043fc3a755c8b6e5a984ec1',1979,'UY','Uruguay','raw',3,'—v—
VATICAN CITY. o.cisciicckectests tisaetes cats at etch ee enesetn dens Uonhieintieaatinia cael
VENEZUELA s c3fcicccdeseseh estecccbesqntenaessncdans gti nates gts Se aadead bps bts Gedaderebenpaniebecsae Beuthanea
VIETNAM
—w—
WALLIS and FUTUNA oon. ce ceric crete cnererrscnsecescrseseeecieersesneeteeereecreges
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
y=
YEMEN (Aden)
YEMEN (Sana)
YUGOSLAVIA
=7=
ZAMBIA. < ciscceisivshetes Hass aoe sess el eens eens tae a Gai ane a eae dent
Zanzibar (see TANZANIA)
Approved for Release: 2018/04/27 C06727040
January 1979
213
Approved for Release: 2018/04/27 C06727040
January 1979
TUNISIA/TURKEY
key centers are Safaais, Susah, Bizerte, and Tunis; 100,000
telephones (1.7 per 100 popl.); 8 AM, 3 FM, and 7 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,273,000; 718,000 fit
for military service; about 75,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1978, $153 million; 6% of central government budget
Ankara
TURKEY
oa
\\: ae GA =~
Since ats
{Sas reference map V}
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','2718b31987e7b789819ff5bb67cdf4eab1f34054cdda210d0c8cee0a45e8c535','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a96e0945120c657206a3434825ea3c7d29f377ccc3c66f3ca935a7865acda7f',1979,'','','raw',1,'Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0 ,
» | echt ‘ ational —Seeret—
; a : Auceconent 25K
we Center
.
t x ~
4
7c
! ‘
National
Z | Basic Intelligence
S| Factbook
s
—
¢
, & July 1979 ‘
Bt
—
= :
oo
! @ i
ae
me
Te
@
=
io) a
@ ~
io «s
bo) i
La
on 1
7
Les
a
2
| =
eee
a
oe
. Secret . | Sere
GC BIF 79-002
July 1979 :
eclassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP0O8-00534R000100020001-0 nae
O
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
~@&
V4
Pod
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
[e 4
4
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
oa National secret
i
Factbook
! if y roroen 25X1.
! cs aa |
}
, |
I |
i |
7 ;
| National
Basic Intelligence
July 1979
25X1
The Factbook, a compilation of basic data on political
entities worldwide, is produced semiannually by the
Office of Geographic and Cartographic Research
with contributions provided by various components of
the Central intelligence Agency, the Defense intelli-
gence Agency, and the Department of State. Com-
ments, suggestions, and requests for additional copies
may be addressed to:
Office of Geographic and Cartographic Research
(Attn: Factbook)
Central intelligence Agency
Washington, D.C. 20505
25X11
Secret
GC BIF 79-002
July 1979
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
= ; \\
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
)
} July 1979 SECRET 25X14
} $
|
J
CONTENTS
Page
; Abbreviations for International Organizations 2.2.0.0... eters - x
| Commodity Organizations 0.0.0.0... ec ieee erete eerie ete tenenereeeeeneneeseeeneneeny Ri ° x
, United Nations (U.N.): Structure and Related Agencies ................: cee xii
—A—
'' Abu Dhabi (see UNITED ARAB EMIRATES) ;
. AFGHANISTAN: sce 2orctcsent efor Mes cole i hateamad Alb Sta bs sat suds duda sh estsigisy aks wad ainbes |
‘Ajman (see UNITED ARAB EMIRATES) :
ALBANIA Hoe es ci esses ce cesac anand ciate od ante a sland th ccs amet eas NS ogra bapetnarteaget 2
ALGERIA Ssiccci ce diadk ed tetra rehee e AN a oscdini ons agate tenet Sheba aerate -4
ANDORRA. scsctestscoicsoctevieodceds angie sateued aiagids Soneveaebeaplad lg! Ghote hi catsa tenet sates eeatbenteny 5
ASAINGOLAS Soe ieettsdeedk saat utcetaadies abacus Wet patanday dan dseaeeatincesS idoeeanuneas astantgeel a needs 6
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA s+ :cvcsete tecthab iad eheren ds iatheehot iedevedeeliatie Me aie ae Oe ae Gen seh 7
ARGENTINA ...........00 IPRS anette nant aca ad MAS silanol ole 8
AUSTRALIA ............ NG lel edi le ae Sea eget pl Say aan 10
PG STR ee alte hehe Meee ee Me ae taes sean oath See atts ALD
Azores (see PORTUGAL) ,
— p=
BAHAMAS: THE: wiitsaee tle ad cle Ble test ane Roatan daa ed oh ev biies Gabecvasten 14
BAHRAIN? (asaveetnc ck eine ch atte et aati akog mates nO Ree ee 15
Balearic Islands (see SPAIN)
BANGLADESH? 2. cscesncifhc.cctteas ced jes tean ted ox Bieltienie salad oneaeaeteess oy asds dy dee do stueeen cadbalten ass 16
BARBADOS 028.08, 08st dcistalootltonl akties RIA as ERA AU ee ie AL SE Ree AG 17
BEL CHUAN, lease ve teens et ctafen id ha dR tat ec er Sancta seth ttal aight alam eaccdtenies 18
BELIZE 223 osetia led tae Mane aia cess A A ae tabeess taal ihn eee thecal S fdsbatageae 20
BENIN 22s sifecenenestets cnaneten Mahara cl avsceg Ranedans Misdaldea vaginitis yeas) lefts Senos 22
BERMUDAS 2) esse 50 pe vccntscha causa tecy tse tacine ss tatdes teens dda baa nina sacitpner eteye en nesteet 23
BHUTAN :c.i6e Soke eect ve hottie deh aatsua lois Fedseanines yea onan noes Sle et dea ye ana 24
BOLIVIA). Gte.duen eros Pace SE cae Getta che kad antes Flot cet yaaa eens Gita tect 25
Bophuthatswana (see SOUTH AFRICA)
BOTSWANA ooo. ccccccceeceeete cette eteeteneneeneeestoney Si aka his Bak te & dea neemidenng ances 27
BRAZIL: 202. stosse eel atead anette cules ig Ph seattdies dussese den taseds owes sates oeanats ot cede esha pleas : 28
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNE) ssiissncrc lope tonte, tA Ae A acts dade edna eeemn edt ete syndy 30
BULGARIA 22.5 c5osocci os os ees hedges atenolol 31
BURMA: shot Tenedtiia hee eccpeetiest Aiea PA Chagea tte aatenats hunitnasae a aig 33
BURUNDI 2ciiccdc ct hehe Meteora haces cerca es earn abit ate Had Mus Madera gs th 34
2G
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON? iiicois secs secsenlin het Sabie tages cease ie A at ghee ete 35
GANADA® 5.02. iiNet atolls nete a ee Sulvngeae ght 37
SECRET iii
: Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
(
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Sa
per ae -Page
Canary Islands (see SPAIN)
CAPE VERDE? 3b ca ttc hate aa tana Sapte tb shied park lds viet gtaiae betta hee ouas ete 39
CENTRAL AFRICAN EMPIRE... ccc cccccccceececeteeeseeseeseesececesensenseeteeteetenteeeees 40
Ceylon (see SRI LANKA)
GHA De ieawrasnactthess ueden esha rear ldette ted out et et tustaveandi den Gaamuatan netic ben eones totale dada afonhacdads 4
CHILE: aqiaciacisdea iti bind iacattaa centeierde tan duteterertaan Allg dacuc iw dee 42
CHINA? Sic s trait ont Meu nacasier coast te Ltaaht ito, Sturunabieentatlean aad saat eaa ls ost mata ut 44
COLOMBIA 0... cece eeeereees Sadi cd Nai san celioas bai alssh al ace toa tay gach loaseaceun so wantanaaiaetaneseess 47
COMOROS 3502 ethene sae eta ne Oe ee at 48
CONGO (Brazzaville) ooo... cece cee eee ene cree ecnsensessetssnsceresevereirsneesesareats 49
Congo (Kinshasa) (see ZAIRE)
COOK ISEANDS sno i alee SUN OR LE el ota Sa A ts ee 51
COSTA: RICA’ Bir BUR eee ek be ahh ddcaleae ist ae uaadddcagy hah tS ea iculicantesluleieoests 2st 52
CUBAS esc 2stecies diastase eet Mote ete eae Raed eel ee el 53
CYPRUS. sete deceptions cteian ements tt malas tean tale ite, ete prea cate hance hy Maes Dales fase oa 55
EZECHOSLOVAKIA ois. cfr fsecsss cepa Aaageznggas vst epee an caah teas thana gees aescael gaeenoree teeter eens 57
=—D—
Dahomey (see BENIN)
DENMARK © ie sesceoce eee crc healt a he i ble Cait Witte de Leta lial Ae ah et ao 59
DJIBOUTI (formerly French Territory of the Afars and Issas) .......0.000..0. cc 61
DOMINICA) x5 ccseto sess cseceeann, te hata isa ot ie tece thew retiae aad eae tBant oli abeeg eva a eds toeth semnamaemnabaate den cae 62
DOMINICAN REPUBLIC ooo... ccecccec cee ceeeeeeceteeeeeerennesnstniesetvrtiesieeseeseseeeeees 63
Dubai (see UNITED ARAB EMIRATES)
pn oe
ECUADOR: cps itei ui aA Nia dA edb AALS AS GAY AAEM ANI 1 otal Ach ARE 64
EGYPT ........... neh Aah aeteh A aoe He lets a tbltstslhhs Melcher ete ste Saeki stds eee te 66
Ellice Islands (see TUVALU)
EL) SAEVADOR'' 2. .c5cicoc aie heist acatneanendinss Rae deo ats Saleen ea a ca 67
EQUATORIAL GUINEA |... reid sethinnbeyiieh aie sesnte Sets eating duds Seva eene 69
ETHIOPIAS, sosectec fs acs, tte, cet oe ever dec NetedPan ae ad As Me nce AUS Se ROE a me oa lao 2 70
—F—
FALKLAND ISLANDS (MALVINAS) 2000.00.00 cccccccccecccceceeeeeeeeeeseeneensenstnsetserireneentes 72
FAROE: “ISLANDS © etc secenicth cathe sexnzstcsteiaat tak thal ad eta a see a ota eee are eesngundls aerate 73
Fernando Po (see EQUATORIAL GUINEA)
BU: cept eh eee teh ee Lets ie Le aes dd oe ol al oe settee beaten damier imubaratai ty 74
FINLAND 3 x5, Sooke ee Se RAE acy aad tte sie Lid acai atke Gat Qouuitt ttuera 75
RAIN GG ipechict tia csa apiece ihetaedu tanh crachacliclarteeetienhancae: estate hme te ae 77
FRENGH: (GUIANA tose Foo Gis al tee ad oon eu etait A catia ean 79
FRENCH POLYNESIA ooo. cece Batts Sha vea Woe ibaa Mandi A bas costal eed lake 8]
French Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
a
GABON 5) bose 3 Ste ctewteet chia ali etna sta tobias pupene tytd eenbt emer tars cath cmtelnge dete ata iaeta athe 81
GAMBIA, THE 22.) 5... 2:0cses Bodin hadi aati orcas A aman ieee 83
July 1979 25X1
J
(
|
|
|
‘i
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 :
July 1979
j
|
4
ae
GERMAN DEMOCRATIC REPUBLIC oooo....cccccccsccccccscecsesceeeeeseeee.
GERMANY, FEDERAL REPUBLIC OF oooooiccccccccccccccsceeceeseeseeees
ROTI ass ttonacetartenes se Oat sue theese acd Say eensatts Altes tas Se
GIBRALTAR 305. ccsh adsl Sa Tutradia rik elec head el alt iindees aac
GILBERT ISLANDS ooo... ccc cccccccccesessessessesssessesstesvessesstestes eevee.
REECE Sais teed neti itnrate MIMS Eade ete tg aati dh:
GREE INGA oie hn thts: Od eoaltcchgc ah cat blne asc neArny Casha ete an
GRENADAG ites ke sioner uk scos aw aninnalatieaceniuss le cracantivalca ted,
‘ GU ADELGUBE = hse. tarts ce, latices ceyuulse ge motnats ote iieariaat
: UATE MADR ssa e ote Uae lindas ui at ats nau ate dueiectte
| GUINEA eric ipctas eedtatesd hicthiit oii Poca biel sahara fi karahin ah Pade
| GUINEA-BISSAU ooo cccccccesccsseesseeresseteeeressessesevesteseseeseeees
Guinea, Portuguese (see GUINEA-BISSAU)
GUANA: iso M vile sdeatl che ciecstcactiesent dade atte Mesut peteacet antici
| —H—
| RUA cates cetenee Ty Aap tng Bs Borate tothe, 2 Sash Rosette
HONDURAS cisiacclih i il cel 5 gs 8 Satie tt rusiin maki ssvmna toons
HONG: KONG css! itt) cehipdindic ves aanineceell se vse ounhl yh obagset ek
| PUA RY a oes cateon ciate RTE nies Sheil cance tl
} —|—
ct a 2.) | eee eer eel Re? Pond a eo ERE ew ee POE
. DINU sche is celNoa teba tye taidt ae candle Suit Vatace tated len tage
) INDONESIA: 322 cicctev hcicdenes a eal S Seduced sce cri tech Aedsie toa eat ty
3 PN 8c esate SoA eal ane cee nl ARAN ttalnsl este as ns
RA oi eect fetal ARIANA Ad hadi, au daate stale Na cece
| READ socal redhat soli tte Sahat Son aia ial Si acd
ASR Ele aactsrasd ceecrries cera racta steerer actinic Ar ane Noa ke Md as
ALY Scat siea Med ane Nernachdce bad Dies Wore cach an Saeed ae eae
| IVORY COAST os iosctoersatecbedbatinks So ed anaaiss Mutaatts, oceania a hte boite
es
DAMAICR: Sesh cnutettyitl inant rials citi Mh Ne pas
AAI sts seacoahchet kage asec atte yh caNihoasa Mla asaneciaietitiasnetuae
SORIA IN stereo ae cheery cast rtatuaon eter ai thera tandem nt hehe eect
)
! Ke
KAMPUCHEA (formerly Cambodia) ..0..0.000000.00cccccccceceeeeeeeee
REN lcd ete a a hi a IO aah et art
: KOREA, NORTH) .20ci.clccle0nicu.derssicvinsicaslstvelesastasalsvant ihasannleaiecs
KOREA, SOUTH? 4cccciecit ssvasisiauits abeichanlsadsticunesonieesiateseiefiverassssite
| © ROWANTS Soe th ss dagisbevteaiccnterecent bwin ttaaiet nenenstayiawhaaen eonh eeeloostaes
| oe,
| EROS Mints aigeshiasianunbetiec saat ta tta lulu bicb ha ce Ea Nag
BEB A INOIN dep ccticl ota cah Sa Meceee ss ayer cialatsieylataosnchMael whee
: CES OTH Orie eli otenilan i IAt a len ars
|
i
| SECRET
'' Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 :
CIA-RDP08-00534R000100020001-0
SECRET
25X11
CIA-RDP08-00534R000100020001-0
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET July 1979 25X1
pet [aes Page
LIBER(AS siesta hag aan caer tenaanuninaraaustia artic oeeee comely 140
DUB Ag cal nc Daa tae cee aa yet ne a a Bata cues: SIAR act 142
LIEGHTEN STEIN cles Ga chee Ll nih Aileen clan GN EO gt Be DM we 144
LUXEMBOURG) 2.0: Gita et one iita dels cecil bes ade edlet Seek lecherous bet actos hee he 145
—M—
WPA Cicer oh es See Naedecta nna nte Metco eRe nes uf NO Piacente 146
WADARS CAR utes cere te tet nice ots title Nara itbaie ledge ish ary eoe 147
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
WALA WIE i iiia eat oat ae cea PEL acetal gi Seth Matra Wrastedtnatendig iaaiass 149
MALAYSIA (5.32529 Gideon cet ised a Hata eathn deeaetiact Maal eauedet st da adieeace eee c wed tes 150
MALDIVES A seve ep BRIA, LAB he ces ne rua thatch cect h las AGES is cla Nak le ate tlas i 1s, 153°
MA cst vermitingtoncde as: shexteladndtardeteee scat Stahl acc, sh steatcatly dtm ceutiucenn efotad hi ondhs ChIb tm tie 154
MALTAS vss ccteotistist abetosian old bttetebe ts, cue alee eaten ds abetasdsiatscacateuergtegieeh demeraceta bed a 155
MARTINIQUE: 5 iccssoj eee stepvajautibg oaoodentas Bop cur cee den eee tealan an lp cheat eae olen cette Phas 156
MAURITANIA 2i5 cas fhctucae oa ase eta abe ht wis dads Soot deb lid ocaudlas te untcene Acclenreck esd Peaeoe 158
MAURIIIOS: oo oe eat ccee sg cap declare aatts Ass daptutus ad tulien Md oRanven tae anh De cole i ediiend nas ta es 159
IMEX C Oo 0 eset cos ae Rea cates sia Stee Mectpnca ae adeecccae peop dave vaatdelssettty add paaeett valtenas 160
MONACO bole isiinaiis hued deat cuta Met nel ott ceca tae uke tell Anes te ho Annet cade 162
MONGOLIA ss Se nasi, Soe ra Be Lt ae hoe nes date hs ead adhe a so id al lo: ene 163
MOROCCO ®. e:socbocectetatguanl est gngawe need uated es Priaspesegseaeegeieagviews Ghee ieyicePeaniquzset reece eees 164
MOZAMBIQUE \\i iiss. oietinnee dena Mihara ay have lela al tent ei eadteeteo atta 166
- aes
NAMIBIA (South-West Africa) 000.0000. cccce cece cec cece cee enteteeeseteceetuetetiterieenteeee: 167
INNAURU oie ae tented ee rekon cies shee ha, is etl mil le dedi, Uoaiaas Toca Al ole te 9c 169
NEPAL coisseastens actos conteiveeeheh A mh ieiiecdei ety hag etnaserndes ton duane sotysiaplelie men lGN Shes 170
NETHERLANDS «i. :s6) 230: eid cause diem saci navend, seeds eat iclaadescaieehatdaenntn addaes 171
NETHERLANDS ANTILLES 000.0000. e eee cceee tees eteteestie tte etetettentisetieees 173
INNEW:“CALEDONIA® Sy 3cancdietania Beate of cs Blevet undoes eden hehe ides URE a dnd a acans about 3 atadaeds 175
NEW HEBRIDES S feist stitute tnseritatuade, innate ata ade die es trt eaeeicrae dad: 176
NEW: “ZEALAND © oo. in 8 caer scaconn dentin ds ely ea I Se aia lh Bacal he 176
NICARAGUA) oicccsu.shrig cients Hediad desea Wa ateeds ta ahagee ae Eee 178
INGER (ose tartare ase Scealbacy ce tes eae ted Se ra tat lat fea ca atl ne cen cake Mah ead 180
NIGERIAS geeiucn wets elena tities pocintee aye vtindna cs Guided vee awed: 181
Northern Rhodesia (see ZAMBIA)
BOR WAY). ccscis sae Ne oh Seprtaicran LNT ee. 5t Pesan netater ead hh Monash icacneinens tera authles tre noses 183
—O—
OMAN: se nciidittehihitee ttt tia hu lsndtneia cas tel dial eear tN Sok eat ate etal a 184
—p_. .
PAKISTAN creo Mecastnesisd Gellhrs tek eee NL AAA Bie ey OT el ha a Ne hale A ee 186
PANAMA 2 occ Aunt ia eee wl Gia Hed Re lakead dia tines Ae dghecten sd bosants so Ataecee 187
=p :
PAPUA NEW GUINEA ooo. cccccccccc cscs tenses tetecenertusvinititiettttrtititititeesnerenaten 189
vi SECRET - fl
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0 1
I
\\
_Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 :
July 1979
| rage Page
} PARAGUAY. Jocstaer cecee tse en cect et Darn sl laity id Nias 190
Pemba (see TANZANIA) =
} PRU: atest iteta st tacts wile inhibi lca cree ati SEs ase Ciba cam Rate 192
PHILIPPINES cx cvtssssstsiopsissinens candvensaant es ta angans Aidioens ataldudadeda thi emoretcAe ie Laide 194
POLAND eae eat ttoeit oA aie ch ace td eh in sea la tals th alt, fonts 195
POR TOGA cee laste a ate latte han ecdee tend ciate be Besnas:datacle dat avhatitehade wabaaMleraddae? 197
I Portuguese Guinea (see GUINEA-BISSAU)
\\ Portuguese Timor (see INDONESIA)
}
} —Q—
}
H QATAR........... Bede Seca a paentetes cepa abate Nth neha 0 a tite Bi tt nicl alse Bee crac 199
r{ —R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
REVI ores haan sare eng hice nuda eae becca sh al uae epactgnbanane eee sheet 201
Rhodesia (see ZIMBABWE-RHODESIA)
Rio Muni (see EQUATORIAL GUINEA)
KS ROMANIA® Saccticatiens lateral nana hiner saucnnanduan aida WNastueines eltieatt 202
VIIA erg areca tan cept tu td wet e easiashestaalaain icone diate nate Se a Mitt cde at tas 203
‘ =
ST. CHRISTOPHER-NEVIS-ANGUILLA ooo. occ cccceccccecceceeecsseeceseeteeveeevereeveneeteceverees 205
y £7 EO] - Se S P 206
! STI EIN acts Malice Cia eoe il Sina ted sasha ennai dat win egctanG 207
SAN SMARRING: orirciatioctiss Paste, fs Mil Anas haele hs isan PR engl tN cata Dua ata’ 208
SAO TOME and PRINCIPE ooo... ccccccccccccscsscssesesseevssesesesveeesvesesitsttevacteveteveveeeesdies 209
! SAUDI, RA BUA cei Me NI Nal arse ld TN he, ele ea el 210
SEINE A So 225 fo atte AS 0 ch re cia ANS lad gl aces ca cea 211
SA Se cert cacahatetectg tal ruantetia tecatshineintaa icant hea tes aslo detlata unas Metta SoA Matt 213
5 Sharjah (see UNITED ARAB EMIRATES)
ae SIERRA; LEONE: cote xcid soca) ttt cote am ola untae Leake atlantida letaenie opted 214
r * SINGAPORE ooo. ce tcteteee ices cradle tae MOR patted ead dhc te ae ola ccet teens 216
. SOLOMON ISLANDS (formerly British Solomon Islands) 0.000.000.0002... ene 217
SONALI oe oe hati coche Mak Mines OAR hcl ctoeach clad tesa cipcatev Na eiinciat arenas cotinine 218
SUT NGA ce ett ac tN a i oar EAN tl ea cel Gea 219
Southern Rhodesia (see ZIMBABWE-RHODESIA)
j South-West Africa (see NAMIBIA)
SPAIN css: tecttconst Actetiert cect flee ondescasdse howdy tuaven dusts dias atetea sta taatatccihdlaroa tated ahd 221
Spanish Sahara (see WESTERN SAHARA)
SRI LANKA (formerly Ceylon) 0.000.000 ee ener terres ceeretreieenenesteenienees 224
SUDAN ooo ccccccccccceeee arrest alte: Sead tent tices aut nett anne ore ten oatNe te 225
SECU RUA WA cies cataract ah ng eather chek dah ured ced eae dees aegis 227
SVL NA IN cs ee OR depen OOS ae ee Sho cae 228
. PGW EDIEING ciated is de rack na tel nite Ohad SITY eel ag on dete al 229
SWITZERUAND eresc ak se Naru hao tes tah Ri cane duh ie dia PO aa. 231
SHRI Scot tahdel wba ante dak Pal tng fle denscc bal aad emna Nac RASA Sete B aie aclu tape 233
: SECRET
" Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 :
CIA-RDP08-00534R000100020001-0
SECRET 25X1
_ Vii
CIA-RDP08-00534R0001 00020001-0
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1925X1
SECRET
viii
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
ey ae Page
PAIWAIN GE elt Li ioe SRS Idee E AA Soh cet nce nce A ua acelin alleen BW, Ditton Mala herein ta 234
Tanganyika (see TANZANIA)
TANZANIA 20icce coeds coset ta Gao vont cab ncettin Sela sestck tous abs Guoeed Aint Wal atens uN ada eae 236
Tasmania (see AUSTRALIA)
THAILAND: oie). scot cn Sh kt econ ethteintecn etl adil bal Mie hea ha ST eceatd ened Sethe See 238
TOGO 2:9 itt A eRe: Racks lee Relea ute et AMM te abt Le yak IDs tech cde aa 239
TONGA Geli casso liatemeehNialse 2 Ante bier Se ceg steel Ait id eh taatencatih asa Mnd tire mabtectis 241
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ooo cect tt tec ee citer tbestetscesentnesaetitnetereetes 242
TUNISIA? cicada sdtedotens Maca aris l caty SNA Se nde a aa 243
TURKEN, o2.22.7.0%, 40 .Sois et es Sy a alates ant dan ah Me Uh thi oh Ss th ad AS Bh, 245
TUVALU (formerly Ellice Islands) oo... ccc cette sees cece te etevittreeteeertittereeeseeey 246
—U—
UGANDA) 22 ovsocin serach scesocu etieehstrtate a pon eclevantitenetvnan tent man aad ee tane gta 247
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USS Re MA ete tei, das egtalle at tates wah cobra daha atic gy aeeereaadares Mieicgel at tus aM ate eee 248
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain ooo... cceccceccceeceesecseesereeseeee 251
United Arab Republic (see EGYPT)
UNITED ‘KINGDOM. 53 528cpico sacha tecetaak cers detuaay cas tuces anaes a etptetinget aes avis onevas ney 252
UNITED: STATES: ccrscsicecveesestocnsocenteinvite beatnts sehen. Ms Sacha ease aac yTscbashee sete esther & 273
UPPER: VOULTAG oi cetierc tein ect Peete le Hh eM SMS oo AS Muhn satind cs Ma ole Se cite 254
URUGUAY 18 eh Riles tel tacit da seed hits rab git dena crates eaten tate nad anaes as ot aden lasabot 255
Vy
VATICAN “CUIY.: Sch. Ses tgettiteel ie titi memnunidu tien dis ihe shite eed Gas 257
VENEZUELA 10! ose cee earl Sanh eal ei 2 teag a Rd ool cate bh tes dee senes ose date iateein aNes 258
VIETNAM ss: S 5.08 vs ere seep aks Pe ere ade teat ea Roy ah ey On vlinclasian aed 259
—w—
WALLIS cand: FUTUNA? 3 icc. cufe veda bic ci cseedestestaccacsculls, eegleedbebestiage mtivtaeeeeadeacee: 261
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) ......0.0000000000.0cccccccccceceeeereeeeeeees 262
WESTERN ‘SAMOA: 6. oc.8 5 ).iitvttetaa ate i esefera tere es ANON A tea eles deuce: ae te le tile 263
—_yY—
YEMEN (Aden) '':stisiedticacie Tacit oa a Ae ia calla tae heea odin Label an ene ate tees 264
VEMEN: (SOG) 2293 28 05 oh oat Sat sea tute edi tit ote pelea, tah aaah atau bt, gtihen 265
NUGOSLAVIA® ii histo SNe iat Re te all ool Aa Mh elite eile Shia al and lnees 266
pa, Sa
AIRES 2 eh eg ought Sess tak hd UNE AN AN ae ad sh ML a to ae nothin ce orb hth a Baas Ghee 268
ZAMBIA: getict re Ri 0 8 fos oor eco on od thon teed Dieses hire Loy tte ses adel ona ve ae vdeoN es vse dk coeds 270
Zanzibar (see TANZANIA)
ZIMBABWE-RHODESIA ooo. cece ees ssseseeteteseeceesrsevevitetisissvavseseseieatteserteees 271
SECRET
7
i
{
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979 SECRET 25X1
MAPS
| CANADA
Il MIDDLE AMERICA
Hl SOUTH AMERICA
IV EUROPE
V_ THE MIDDLE EAST
VI AFRICA
Vil U.S.S.R. and ASIA
Vill OCEANIA
SECRET ix
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
= ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
G-77
IADB
ICES
IDB
IEA
1HO
IPU
IRC
LAFTA
LICROSS
NAM
NATO
OAS
OAU
OCAM
ODECA
OECD
July 1979 29X11
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People’s Solidarity Organization
Asian Development Bank
African Development Bank 4
ANZUS Council; treaty signed by Australia, New Zealand, and the','74ff49de8413a309d3c003e38f34054d7e908d6b6eb0829f1529d0201324aa32','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca4ac04ec0bbeb57f182b0c450b977cd0f369aa2575442c3d01e59c5bc0656a3',1979,'US','United States','raw',2,'Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance ‘Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Group of 77
Inter-American Defense Board
International Cooperation in Ocean Exploration
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
Non-Aligned Movement
North Atlantic Treaty Organization
Organization of American States
Organization of African Unity
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
i
Bs
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
ds a aed
Fa
_—
STN FS Na Ne agg Ng TR Rg Sg gm I a SE RN a I ea gg I fg Ag gy Pm ae!
July 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
SELA
UDEAC
UEAC
WEU
WPC
WTO
AIOEC
ANRPC
APC
ASSIMER
CIPEC
IATP
IBA
ICAC
IicCO
ICO
1ooc
SECRET
Latin American Economic System’
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
World Tourism Organization
COMMODITY ORGANIZATIONS
Association of Iron Ore Exporting Countries
Association of Natural Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producer
International Bauxite Association
International Cotton Advisory Committee
International
International
International
International
International
International
International:
International
Cocoa Council
Coffee Organization
Lead and Zinc Study Group
Olive Oil Council
Sugar Organization
Tin Council
Whaling Commission
Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting: Countries
International
Wool Study Group
SECRET
xi
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
SC Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
es Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children’s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
Xe GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WFC — ‘World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA- RDP08-00534R000100020001-0
July 1979 25X1
SECRET
}
}
Declassified in Part - Sanitized Copy Approved for Releas
er OE ee ee ee ee
a ee ee
.
a gE ORR yg IE Nae, ie Si
e 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
SECRET
Approximate Metric Conversions
Symbol When You Know Multiply by To Find Symbol
LENGTH
mm millimeters 0.04 inches in
cm centimeters 0.4 inches in
m meters 3.3 feet ft
m meters 1.1 yards yd.
km kilometers 0.6 __miles mi
AREA
cm? _—s square centimeters 0.16 square inches in?
m? square meters 1.2. square yards = yd?
km? —s square kilometers 0.4 square miles mi?
ha hectares (10,000 m?)_2.5 acres
MASS (weight)
g gram 0.035 ounces oz
kg kilograms 2.2 pounds Ib
t tonnes (1000 k 1.1 short tons
VOLUME
ml milliliters 0.03 fluid ounces fl oz
I liters 2.1 pints pt
| liters 1.06 quarts qt
| liters 0.26 gallons gal
m° cubic meters 35 cubic feet ft?
m? cubic meters 1.3 cubic_yards yd?
SECRET
Symbol When You Know Multiply by To Find Symbol
LENGTH
in inches 2.5 centimeters cm
ft feet 30 centimeters cm
yd yards 0.9 meters m
mi miles 1.6 _ kilometers km
AREA
in? square inches 6.5 square centimeterscm?
ft? square feet 0.09 square meters m?
yd? square yards 0.8 square meters =m?
mi? square miles 2.6 square kilometers km?
acres 0.4 _ hectares ha
MASS (weight)
oz ounces 28 grams g
Ib pounds 0.45 kilograms kg
short tons 0.9 tonnes
(2000 Ib)
VOLUME
tsp teaspoons 5 milliliters ml
Tbsp tablespoons 15 milliliters rl
floz_ fluid ounces 30 milliliters ml
c cups 0.24 liters |
pt pints 0.47 liters l
qt quarts 0.95 liters |
gal gallons 3.8 _ liters I
ft cubic feet 0.03 cubic meters m3
yd cubic_yards 0.76 cubic meters m>
xiii
25X1
| Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
SECRET July 1979 25X1
Dates of Information: The information in this edition of the Factbook is current as of mid- to
late-April 1979 except as follows: {
* Population estimates have been projected to 1 July 1979,
* Military manpower estimates are as of 1 January 1979, except for numbers of males
reaching military age, which are projected averages for the five-year period 1979-83.
Explanatory Notes:
Land Utilization: Most of the land utilization percentages are rough estimates. Figures
for “arable” land in some cases reflect the area under cultivation rather than the total
cutivable area.
Maritime Zones: Fishing and economic zones claimed by coastal states are included only
when they differ from territorial sea limits.
GNP vs. GDP: For some countries GDP, rather than GNP, is shown. GDP is the total
market value of all goods and services produced within the domestic borders of a country
over a particular time period, normally a year. GNP equals GDP plus the income accruing F
to domestic residents arising from investment abroad less income earned in the domestic
market accruing to foreigners abroad. {
dh pA
Money: All money figures are in U.S. dollars unless otherwise indicated.
Fiscal Year: The abbreviation FY stands for U.S. fiscal year; all years are calendar years
unless otherwise indicated.
ay . SECRET
Declassified in Part - Sanitized Copy Approved for Release 2012/08/29 : CIA-RDP08-00534R000100020001-0
July 1979
SECRET','19a6da200ccc53afdd651c0d13fdc975fa0d473f7d2f56689f997cf0ce0c2cdc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8aa0c1f3869283c0add2b0a17b90d07531a3273fdba79e6f883b07f3ad46da0',1979,'AF','Afghanistan','raw',3,'Arabian Sea c 4
(See reference map Vil)
LAND
647,500 km*; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','ea1ff15ef686df54a0167e31e3c26d8df89744297286566eea7612be7f8442dc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100020001-0','txt','a231307bc80ebbcc6f07eed34358a19c56bf51427821b537f78cc6e847dc3e6b','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100020001-0/cia-rdp08-00534r000100020001-0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e0932364f08fad8434a540522c372646d6a6a468e0b26d075655f48c87430a7',1979,'','','raw',1,'National Basic Intelligences FACTBOOK - Jai
January 1979
ApprovecTFor Release 2004/06/24 : CIA-RDP79-01051A001 00001 0001 -5
National Basic Intelligence
FACTBOOK
DIA and DOS review(s) completed.
DIA AND DOS HAVE NO OBJECTION TO
DECLASSIFICATION AND RELEASE.
GC BIF 79-001
January 1979
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
FOREWORD
rhe National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
National Basic Intelligence
FACT BOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5.
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001 00001 0001 -5
January 1979
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook
Page
Abbreviations for International Organizations x
United Nations (U.N.): Structure and Related Agencies x ''<
— A —
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN 1
''Ajman (see UNITED ARAB EMIRATES)
ALBANIA 2
ALGERIA 3
ANDORRA 4
ANGOLA 5
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA 6
ARGENTINA 7
AUSTRALIA 9
AUSTRIA 10
Azores (see PORTUGAL)
— B—
BAHAMAS, THE 11
BAHRAIN 12
Balearic Islands (see SPAIN)
BANGLADESH 13
BARBADOS 15
BELGIUM 16
BELIZE 17
BENIN 18
BERMUDA 19
BHUTAN 20
BOLIVIA 21
BOTSWANA 23
BRAZIL 24
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNEI 25
BULGARIA 26
BURMA 28
BURUNDI 29
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON 30
CANADA 31
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
— C—
Canary Islands (see SPAIN)
CAPE VERDE
CENTRAL AFRICAN EMPIRE
Ceylon (see SRI LANKA)','adbe78501f890cfc34f2ac007cf371777315c631e074dadfcec0529150ebf178','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d58877f85372ffd7951af35563fdedc2b422945e8d765cf95c2deb769ea3ea86',1979,'PF','French Polynesia','raw',2,'French Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
— G —','edab88f43de0e22865550213fd66e59f5871fbffd6f04a8b912e1ca77436a8ed','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad86ff9f2db4ec939282f713cce2b843e8b9c024de89442dfff7c7b5a4668af6',1979,'GA','Gabon','raw',3,'GAMBIA, THE
GERMAN DEMOCRATIC REPUBLIC
51
52
53
54
55
57
58
59
60
62
63
64
65
66
68
69
70
71
72
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
January 1979
Page
GERMANY, FEDERAL REPUBLIC OF 74
GHANA 75
GIBRALTAR 76
GILBERT ISLANDS 77
GREECE 78
GREENLAND 80
GRENADA 81
GUADELOUPE 82
GUATEMALA 83
GUINEA 84
GUINEA-BISSAU 85
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA 86
— H—
HAITI 88
HONDURAS 89
HONG KONG 90
HUNGARY 91
ICELAND 93
INDIA 94
INDONESIA 95
IRAN 97
IRAQ 98
IRELAND 99
ISRAEL 101
ITALY 102
IVORY COAST 104
JAMAICA 105
JAPAN 107
JORDAN 108
— K —
KAMPUCHEA (formerly Cambodia) 109
KENYA 110
KOREA, NORTH 112
KOREA, SOUTH 113
KUWAIT 114
LAOS 115
LEBANON 117
LESOTHO 118
LIBERIA 119
LIBYA 120
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
V
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979','ca3a43c3db21a1e119632cbc493d78516b167d776108330270b671e03d2876c8','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0e9957d74f03245bd08738a3258dade72d65dcff582c6c15b0acc718457396a',1979,'PE','Peru','raw',4,'Page
122
123
124
125
127
128
130
131
132
134
135
136
137
139
140
141
142
143
145
145
147
148
150
151
151
153
154
155
157
158
159
160
162
163
164
vi
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
— P—','9ca4728216bfeb63d69d8bb0fc0258b7dc027ac797c26a673f7578903576d020','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e817173d854708f09605d91f4f59799cf1b5364b9fc44c6331982b5410f1ebb',1979,'QA','Qatar','raw',5,'— R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
REUNION
RHODESIA
Rio Muni (see EQUATORIAL GUINEA)','aa007d59408ed08dcd20ac082b0074a298a96d9b91de91aa3d042fbe14367b20','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89720dec3dbd9c1ffaa69743f8330c3854ef352ba2ae9d3afb06e495fc3222a2',1979,'CH','Switzerland','raw',6,'SYRIA
— T—
TAIWAN
Tanganyika (see TANZANIA)
TANZANIA
Tasmania (see AUSTRALIA)
Page
166
167
168
170
171
172
173
175
176
177
178
178
180
181
182
183
184
186
187
188
188
191
193
194
196
197
198
200
201
202
202
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Page
— T—
THAILAND 204
TOGO 205
TONGA 206
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO 207
TUNISIA 208
TURKEY 210
TUVALU (formerly Ellice Islands) 211
— U—
UGANDA 212
Umm al Qaiwain (see UNITED ARAB EMIRATES)
U.S.S.R 213
UNITED ARAB EMIRATES: Abu Dhabi, ''Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain 214
United Arab Republic (see EGYPT)
UNITED KINGDOM 215
UNITED STATES 231
UPPER VOLTA 217
URUGUAY 218
— V—
VATICAN CITY 219
VENEZUELA 220
VIETNAM 221
— W—
WALLIS and FUTUNA 223
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) 223
WESTERN SAMOA 224
— Y—
YEMEN (Aden) 225
YEMEN (Sana) 226
YUGOSLAVIA 227
— Z—
ZAIRE 228
ZAMBIA 230
Zanzibar (see TANZANIA)
viii Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
MAPS
I CANADA
II MIDDLE AMERICA
III SOUTH AMERICA
IV EUROPE
V THE MIDDLE EAST
VI AFRICA
VII U.S.S.R. and ASIA
VIII OCEANIA
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
ix
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CAR I COM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
G-77
IADB
ICES
IDB
IEA
IHO
IPU
IRC
LAFTA
□CROSS
NAM
NATO
OAS
OAU
Afro-Asian People''s Solidarity Organization
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand, and the','0cd14a2460cb403142e992b159d57a4fb668cd2835b0b3778a171b77f0dd5524','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf278e9134036b8cbcf03911191375b2a470689c1929d59f55f0670bdcad4415',1979,'US','United States','raw',7,'Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Group of 77
Inter-American Defense Board
International Cooperation in Ocean Exploration
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
Non-Aligned Movement
North Atlantic Treaty Organization
Organization of American States
Organization of African Unity
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01 051 A001 00001 0001 -5
January 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OCAM
ODECA
OECD
SELA
UDEAC
UEAC
WEU
WPC
WTO
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Latin American Economic System
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
World Tourism Organization
COMMODITY ORGANIZATIONS
AIOEC
ANRPC
APC
ASSIMER
CIPEC
IATP
IBA
ICAC
ICCO
ICO
IOOC
ISO
ITC
IWC
IWC
OAPEC
OPEC
UPEB
WSG
Association of Iron Ore Exporting Countries
Association of Natural Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producers
International Bauxite Association
International Cotton Advisory Committee
International Cocoa Council
International Coffee Organization
International Lead and Zinc Study Group
International Olive Oil Council
International Sugar Organization
International Tin Council
International Whaling Commission
International Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting Countries
International Wool Study Group
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
xi
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
SC Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
. . . Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children''s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
xii
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Political, sociological, and economic data, including monetary conversion rates, generally
reflect information through mid-October 1978, except for population estimates, which have
been projected to 1 January 1979. Military manpower estimates are as of 1 July 1978 except
for average number of males reaching military age, which are projected averages for the 5-
year period 1978-82. Military and communications data are as of 31 October 1978 unless
otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of the
statistical data are rounded (thousands and millions). Figures for arable may reflect only
the area actually under crops rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the two is
in the addition or subtraction of the value of return on foreign investment. GDP equals GNP
plus income earned in the country but sent abroad, minus income earned abroad but sent into
the country. GDP thus tends to exceed GNP in debtor countries, and the reverse is true in
creditor countries.
Major ports are the largest maritime ports of the country, relative to other ports of the
same country, on the basis of estimated port capacity, alongside berthing accommodations,
and commercial or naval importance. Minor ports are the remaining ports of a country which
have, relative to the major ports, significantly lower estimated capacity, fewer alongside
berthing accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise stated. The abbreviation FY
stands for U.S. fiscal year; all years are calendar years unless otherwise indicated.
Approximate Metric Conversions
Symbol
When You Know
Multiply by To Find
Symbol
LENGTH
mm
millimeters
0.04 inches
in
cm
-centimeters
0.4 inches
in
m
meters
3.3 feet
ft
m
meters
1.1 yards
yd
km
kilometers
0.6 miles
mi
AREA
cm 2
square centimeters
0.16
squore inches
in 3
m 2
square meters
1.2
square yards
yd=
km 2
square kilometers
0.4
square miles
mi 2
ha
hectores (10,000 r
»'') 2-5
acres
MASS (weight)
9
gram
0.035
ounces
oz
kg
kilograms
2.2
pounds
lb
t
tonnes (1000 kg)
1.1
short tons
VOLUME
ml
milliliters
0.03
fluid ounces
ft oz
1
liters
2.1
pints
pt
1
liters
1.06
quarts
q*
1
liters
0.26
gallons
gal
m 3
cubic meters
35
cubic feet
ft 3
m J
cubic meters
1.3
cubic yards
yd 3
Symbol
When You
Know Multiply by To Find
Symbol
LENGTH
in
inches
2.5
centimeters
cm
ft
feet
30
centimeters
cm
yd
yards
0.9
meters
m
mi
miles
1.6
kilometers
km
AREA
in 2
square inches
6.5
squate centimeters
cm 2
ft 2
square feet
0.09
square meters
m 2
yd 2
square yards
0.8
square meters
m 2
mi 2
square miles
2.6
square kilometers
km 2
acres
0.4
hectares
ha
MASS (weight)
oz
ounces
28
grams
8
lb
pounds
0.45
kilograms
kg
short tons
0.9
tonne 5
t
(2000 lb)
VOLUME
tsp
teaspoons
5
milliliters
ml
Tbsp
tablespoons
15
milliliters
ml
fl oz
fluid ounces
30
milliliters
ml
c
cups
0.24
liters
1
pf
pints
0.47
liters
1
q*
quart 5
0.95
liters
1
gal
gallons
3.8
liters
1
ft 5
cubic feet
0.03
cubic meters
m J
yd>
cubic yards
0.76
cubic meters
m J
xiii
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979','92d857bf52aea9d2475a7e3f37a3fe01d33d2f8daf01f9e30abf391c3af907c0','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('885319a9e955c76c64739b9bfa90ce3396ae02ac63f99fff7507de03cc4337c0',1979,'AF','Afghanistan','raw',8,'(See reference map VII)
LAND
647,500 km 2 ; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','d32d753fe8a47da6297aeae6b9c958c2e78c5ee95141c10640bc2be8ef1713dd','internet-archive','CIA-RDP79-01051A001000010001-5','txt','e30340e8593900ce2832469d53959cf696877cae926bf1ab6e3357f0000fff29','https://archive.org/download/CIA-RDP79-01051A001000010001-5/CIA-RDP79-01051A001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c461b1f3145b0ef6e37e541245d64311eba6dda21c16ace351357311915d6437',1979,'','','raw',1,'q JeuoHeN
1ef - YOOSLOVSA 9
ise
2us61191uU] ro)
‘
H
January 1979 .
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
National Basic Intelligence
FACTBOOK
DIA and DOS review(s) completed.
DIA AND DOS HAVE NO OBJECTION TO
-001
DECLASSIFICATION AND RELEASE. syuaed {$79
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
em Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00108-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
a a a a a
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5.
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook
Page
Abbreviations for International Organizations 0.0.2.0... ee ee x
United Nations (U.N.): Structure and Related Agencies 0... te xii
iA
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN oooccccccccccecccccccescceceseeseecetesneceesssareeceeessceeenenteeeeteseetteeeeeneetetiinsenaeeeaes 1
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA. Secccs ccccsccceesthde bese senesced eta Se occu ees eta NE a os ees cee da 2
AVGERVA tiene ecietecitisboties poets ie Rada dt et eet el ha nak alent 3
ANDORRA osc tection tected hailey Ae rita Martane tet ea ieee ees aki 4
ANGOLA: seesscvesccet ite teal aereeedigtaastoih cave a vaworafatuhdias dad nda LeMans ney aie Mises 5
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA scence date eboternariae een dene AS Metal brent egy eviges 6
ARGENTINAe ye. esccc path eecoeestecg eelea eases teitag Sianp antenna aa des uess at a Neat becca igh Beales does 7
AUSTRALIA ses ited cece aittea taste ane Ce iG. aie ee ntoeia iit detent, 9
AUSTRIA: ciensteheed cave teeth Aittiend otsen, eb aWSbn eagaceedines He Hapiatisespgteds thine aes 10
Azores (see PORTUGAL)
—B—
BAHAMAS, THE ouun..cccccccccccccccceseeecerereeteccreetenesnscneessessenseneteeeeneeneeetaseeerentasietiasenenseaey 11
BAHRAIN... cesceceesesseehstoccodbel ale ccceGy piece cde cot axaae ts aties net ouenn raha haa aied ea eieenlniaatnare tae 12
Balearic Islands (see SPAIN)
BANGLADESH) cectereeathenith racer Ati atin el ean ee bee ee 13
BARBADOS: coxcexdeciccdadeeie diane Heads alia tetene aes mages Miele aA are desed a 15
BELGIUM e gf cssictedclacevoctsecutaptiiay fashsausa ts enanvecctoagnieesa at bev cutaa beasts Hagen net ae Plate Ginasees 16
BELIZE sjsicclseedagecee sede SoA ati ashes ik dec dte nett seta poreetntnmiongeiaa ae eat taut heads 17
BENIN: scissrcnescsnctecncgegtaccehncness dees lasanncavh0y. sos cha teevieuns tievencn eal Sotasan ev egg naedesete eeleahud ahs te corsa 18
BERMUDA we isccseccessiuads Ma diettace as er sehddegelic seabed elie Be Goa Ahan wer Gee a ate 19
BIWITAN oso ce cca serosa 2h Fone Mvaan ih seegiea Peat ae acne Stee a SO eae eet set 20
BOLIVIA ® coxcicts Se RAE aon Se ivieiadigd tartan aah aes ee i nes 21
BOTSWANA — 3iocsecetiitcss Sn iectets ale teitecde, caestuencwthdetitiecdigds to hebbdiaaetad ab eames ands lee ente gets 23
BRAZIL? fccesan Qed Mah aatehsn cin ieinde aah tetas iophht en Giatinge ets ities 24
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNE L: veecs elder ac ent Seeeietaas dion Deaataahs ah een nk ae eee le eG 25
BULGARIA: -2tices isch cies stan hoses eck eerie te seeps as Ra ahaa gd eed ae eee a 26
BISRIMAS och ocs foie eed nti hcel at aha teas da as gen ncaa ae oe niente ian a A eee tee 28
BURUNDI) c2fetececce st care ott ce Scrorwen altace dh doden ceva ot aoondaneat thers stdaaiansehqaegspereiauy Gbet tends 29
= oo
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON) 2.eisicnle he We Aedes ee Tape at yotieoaa ince 30
CANADA. 2cecscadiake. Sit era ee reset Blea eh es ar 31
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
iii
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
SiGe: Page
Canary Islands (see SPAIN)
CARE VERDE 2h Gesecatananahseccnoehosa wing ete cits aekeeathyelek eaten ie OAbe MO thes ta ounbtausts 33
CENTRAL AFRICAN EMPIRE... cccccccccccscccsescsssssesessussessestesvesesvareesestesverseveaeeeees 34
Ceylon (see SRI LANKA)
ROE aoaciea th aton ipiomict a cstad Athan anda licuee clea Ucn cela Mat ok icaid te natel aah eat eat 35
MPA cas sehsear isha Pua apt NONNS Gaon ld Se Rs INY Sng tenis ds atest taba Meld 36
NOURI wich ili Mast ct So pea de tected tt OR Selah chad SUSUR lt ita cane SAR oN ahi Ng 38
COR CNB IA hss hist becca esters tea toes lena tea noe LBs steals ace wey Bp eilte ee 40
COMOROS sis. cries enamide a Onen tale ces A has it aii an SUVA eg heat ccat 42
CONGO (Brerzzery ile} cc. ccs cisansinid csenis sak''enea vonsbeivocradushdy teystorvasntocaintive voventeteesseeaelte 43
Congo (Kinshasa) (see ZAIRE)
COE SEAS Ne cassis oe sects iN R Seu sia GE Sr Se do hse rcstaaee toe ct Be ote 44
COSTA: (RIGA 2. yciishutce seats Ae diiecd Sachi dest iak ogusle thea ofhi acai hates icea kets eekese ss 45
COME Az sties Srasatende rg canta guinetent map ade tal uh OP ase ial acesMab ty danse ts erp d et 00 ae ah oe 46
CVPR S ont iachlactien oem ate iba Nie MON cee BO na saal. ny os fsa Set al ees! aot 47
PZECHOSLOVAKIA eeiinsasscieiceeverssrissthrsavondwlal auuadeed eeeesali cebebvteseniveebeluiadciidecssiadettonsd 49
—D—
Dahomey (see BENIN)
DENMARK pci. 08, isice Gusset gata facet candice Pin ante teavdd ovat ates semua shocked rsesoud sLocadetteumiee, 51
DJIBOUTI (formerly French Territory of the Afars and Issas) oo... 52
DOMINICA ies crete tt Sieg tthe era suchiteds cl clue. cai song cacaat ed te an avtattne Reg Ett ce asa othe 53
DOMINICAN. (REPUBLIC™ 5 ss scasiucs vatevdveryavaihidlrgosutbidalalsintarsligcceitdberndiencsinsateoanit 54
Dubai (see UNITED ARAB EMIRATES)
=
ECUADOR © decsktcitel apie abteniasa Muraorease iat es nas aren tts fe Si ome 55
VP ht eta ta ae eeu ig nesrmav nena etn, ay vat amie ease eC ac ech is P ites 57
Ellice islands (see TUVALU)
EL SEV ADOR iscsi yuguesedt eds ds ea slbspeh ote on Leni eben Ss euathy in dhsdimdinc bbe deo betottaat 58
EQUATORIAL: SGUINEA ® sscisisepsats tetas savosdesndassdvces ful ve uiiodedlaaus df godess cstcee aelseideh aibisesie: 59
ERI seas iths aba atsiata mea ination Wei leas baisfaciyl tactile wim acetate aan Rit Se eed caxyu ti 60
—F—
FALKLAND ISLANDS (MALVINAS) oo... ccccccccccccecececssescscesesescscetesesteviteceeeeseeenee. 62
FARGQE: ISLANDS (feiss, sessedilts ass nosdsdeateucde awed doastunstetnasieaeieveresn castes leat thocats 63
Fernando Po (see EQUATORIAL GUINEA)
PDN a ieeak ila nt Gl iin stort akc shat Mar seca cdceaaten da vy lecbtieseaccie asi wisest hes, 64
PUNLAND © ii soci tee Sosnes lege seat ire sn Bases vce these ettabanude/So res Bega saedhabon die ete 65
PRAIN CE esata ns oes satteuns a rdeate ti teaveat donee waited va utieatiodee tied sah en he Be eee 66
FRENCH GUIANA oor: Re isi sna lila doe eae ocak 68
FRENCH) POLVINESIA: 2 coi site saseit te mele eee McBride ON ts STAG SLs | cl 69
French Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
=C—
GABOMNE ciaretienses icicles SG oiSh Recent A Renta gett lat ik ANS. is sted i a SO at PEN he, 70
GAMBIA, “THE sicctscsicssco ted ceed eM ale bette 8 tees Raat atl Tae ad AIO ttl canal 71
GERMAN DEMOCRATIC REPUBLIC oo... ccccccccceeseceeesescescstesceveresestetiveeseeees 72
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
eis Page
GERMANY, FEDERAL REPUBLIC OF oo... een eeieerrenietnieeniteregs 74
GHANA } icdidedciectavn aiden So tle ieieroaad atari tannaubeerhienastonhete a eat 75
GIBRALTAR 5:3: sescac tind ec nh aN ea nh oak iain nar egind diag 76
GILBERT. “ISLANDS | essigei atewni tie aia sand aa teeniaiioe site entitle abide AS 77
GREECE: feted caveat Sica eet Gaited ie eri kta ee ts 78
GREENLAND ~ ces centric. hii iutes da tend chil aaebesathead aundeteam aegis decodes amas 80
GRENADA, 6. ficticcsentisesscectan dio ead aueena aap jen eile remnants! 81
GUADELOUPE: sredcsnct tice na eh Qasr ad ele eo aie Gu enaem tea ae 82
GUATEMALA, doseesienti mintdstin nlite tien leben idee aeadgitieeaiie eh, ieee eek 83
GUINEA ete totee ce tavcrtycuiaded onl tect te gaatet Sesh oeydtse cpeezesianeid dacnbanta sage sane Peapedeaagientee Dseerseasts 84
GUINEA-BISSAU! « gecscsssedecoesudaiecornetahiteds cuaacest yb Peamietinal eit gs ademas ai teceween 85
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA 2c eis ceria rset: cca tect guialeusa natant RAR LAI OME fact es sted 86
—H—
HAND weisigceyiegel Gi at dager Sidadind iagraa tbe deel est atid ra adie stash 88
HONDURAS becca le i Wed oti iain, stra Selene amv alts aun tnaanaaracs waasveteeaes 89
HONGKONG) ieee 3. veel taate tial ened weal hah i rea ota beet aendaden ane teaie 90
HUNGARY © secc.ed ci ndeccifens Metin ak ese bel aS eat el a a Abie 91
eal ae
ICELAND sienier tidbit esirntih daeethss dea a da thh debe eiays tee eine eA 93
INDIA tecnica hectic avian Aue neesmniaseen ete stepatastes panda uaauiineteotan tastes nahh rts 94
INDONESIA ices cova tsieed chin een Amit ie Aldean isillistaens 95
DRAIN ss isfrretescasedenis cha fs Lease nditulea eats le taal peat sees oy bie aunt cay vis as eanie eB Hina ammeter 97
IRAQ sc oh. hae eatisep etitnte Ree Bas ee oe ee ei ele eddie eas 98
IRELAND © si icteescoe ts ecdt hoy succes ic eat aul ai baeiladeshapuaacasieecceateianues Maapn a ee ak ey A at 99
ISRAELS -2ieciscith sorte nett baeedendnn heise a a as ene 101
ITALY 42.5). cosaveeaet teats tas erage cd teens nade tices deeded Rida anand teh ye 102
IVORY. COAST ovis cist tater te ltetnes Beivedad utaes shott lust as demtadt eet nade aaadae iow uiniaretey eee 104
ane (ae
JAMAICA, scicih Seach testes ish sala alee Nhe ae ee LA ot Stas raedlacen Ge Ae Ne 105
JAPANS gene terarattenss cis cao caeed tes Adi haa in e ee ae eee ra 107
JORDAN) 325553 xgeeschncete acres eed oan tana egeaet ts CAD as daaieriobaatiaavend Gatteiacaaa UMauate 108
— Kos
KAMPUCHEA (formerly Cambodia) 2.00.0... ect tee reer tterrreteeniey 109
KENYA» jcchiistiecsn ilietaad Ma ieee ei eaten hata aed eh aa he 110
KOREA; “NORTH | c..5 035 ss edcds rec gaat ash ete: acetal thea eee her 112
KOREA: “SQUTHL ...cecccteccsdec easier tueantendeanlaat d tenabaatiead iataes taarueatin ie anette 113
KUWAIT fete Shs io Ae patie edabenedi ct Blea ana tat tna tha das ene ulna gatch eea tet anesmaneh Sanaa eae 114
=
UA OS: «sais tele doen hater iionan aera alii eee Ae Ms i leet oat 115
LEBANON oi eccviiacincu epee eectes ues aderd Aaa ia benis aeti ened ngenicainer acme 117
LESOTHO ecsiecic ded oii d Seder mneiderel Aleta Meas anche sareecuttepeamaebortn eh on manera 118
UIBERIAS ccstd fees c ih Mcterite he ten eee tah ch Det Sie Ueki oe elle tdi hs a diag ar meas ele cg 119
LIBVAs Serie estes Sodas seek seas cdl nests Pera eae ete dis ak ean tael LP sedate 120
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Pp Page
LIECHTENSTEIN oo..ccccccccccccccc ccc cen renee ence ee eee ee nn Erne eee tee EEE nee rents 122
LUXEMBOURG oocccccccccccccccce cece cee reece ee een eee nr ED ee reese errr tener nner ners Eset 123
—M—
1Y,V-\\ YX © Sean U TENT ET ETE OPOESSSPERTIESESSITOCCOCETOCROOOOCOOOOOOOOOOOCOOO OOOOOOSEE 124
VON DY CGT: O70: San OOOOSOOCOOOOOOOOOOOOOOOOOOOOSS 125
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
FV A] EEE OOOOCOOOOOOOOOOOOOOOOOOOSOIOSS 127
F010 6-17: SEE SECOSOCOOOOCICOEOOOOOOOOOOOOOOOOOSS 128
FVD) Ad <5 ESTERS OOOCOOCOOOOOOOOOOOOOOOOOOOSS 130
MABEL soos cc eshesiaich feta ceceanzein tess been ese ads op sured. camnteeet ges Haes is tin te eee eeeeaeen need ree eet nate 131
NON is FEE OOOO OOOCOOOOOOOOOOOOSS 132
MARTINIQUE......ccc0cccccccecccceceecececteesectecceeeeneeecteeeneeecoeeetteeenirtineroneessnersnesseeesnere nine ices 134
MAURITANIA ........000cccccccccccereeeee ee seeeeeenetteeeeeesennntaeesernccisaess (ose Svs idle Ua temetn yuan tee ten ts 135
AVON 0] 0 010 kn EEOC OOOOCOOOOOEOOOOOOOOOOSIOS 136
MEXICO osociccetacccnoevegie elu hidetuhactenscedadey hee ccteeeieed a vad Alaska tavprsag se nae eed a Pag Tab Aa eae ed 137
FXO) 5X GX © en EDU EE TEESE EEEIS SOON ICO SIES TES SCRSOCCOOSSOOIOOOOCOOOOOCEOOOOOIOSS 139
FVC@) 1 1) A 7 Se EEE E EOE SSESTSNOEOTSSESEEESSSECELEOOCOOOOOOOOOOOOOOOOOOOOSIOOOSS 140
FCO) °(@ | Gl Ok © Sn RETO EE SEES SE ODIO ECECEITEO OOOO OOOROOOOOCOOSOOOOOOOCESOOOOOOSS 141
MOZAMBIQUE ......0.0 ccc ties Boda ss eae oa Aet abhen MMe ransaumnnnnethatae 142
oaiN
NAMIBIA (South-West Africa) 0... ccc citi rn cteeseneiee rest ttitins 143
NAURU cooccccccccccccccnececeesssscssececececcecersseeneeseeseaeseteeeseenneeetteeeeteneeeenpeeeeeeeneesaeeeneeenee scenery 145
NEPAL is''scccessstcsac tytn taced ig ticle ee Aging act eda ats haw dane sk dat ee ed ender eee ees 145
NETHERLANDS. ......cccccccceccccceccc ec ccee cette eee nte tre eeeeete eet penne eeernreescniesenneeeeneneineces ee 147
NETHERLANDS ANTILLES 200.0000... cee ce cc eee rt rt rr ee risee erie eninge si iere 148
NEW CALEDONIA ooocccccccccccccccscecteececrrececteneersretccste rieneririisirresisee scrierrienen 150
NEW HEBRIDES oo...ccccccccccccccccce ccc ente rece en nn EERE rE EE EE eee 151
INT hts A oN | D EEE OSOOOECOOOOOOOOOOOOCOOOOOOOOSE 151
NTL OP SCO] 0): Can EES EEE OCOOOOOEOOOOOOOOOICOOOOS 153
a EESTI OOSOOOOOOOOOOOOOOOOOOOOOE 155
Northern Rhodesia (see ZAMBIA)
NCO) 02 EEOC OS OCSCOOOOOCOOOOOOOOOOOOOOSSOOSIOSS 157
—o—
CY 0-1 EEE EEO SEE DEEEETESESECEOESESCOOEOSIOOOCOOOOOCOOOOOOOOCOOOES 158
_——p—
PAKISTAN ......ccccccccccceeceucnscececeeesseseeeeececeeee ee eect enn eee e eee RD E EEE EEO EDEL EEE SEEE EEE E EEC EEE EEE TEE 159
TNs : OEE OCEOOSOOCOOOOOOOOOOOOOOOOOOOOOOOOOOS 160
—P—
PAPUA NEW GUINEA ooo... creer err ee i nnn rte rrr erent irre niiecen “162
PARAGUAY oooocccccccccccccccceceseececeesee tec tttee tees seen tere eset ec ciseeeetentiniiceerecneguereetestigereeresnens 163
Pemba (see TANZANIA)
PERU «isc. cocccotsccccedvaecofeisolanghliasetarbes@sses tag liberbendePiaenets ( eachaciecedy ottaky stented ik OLS ee 164
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
=i Page
PHILIPPINES sscfecc cesses eeieces ees inetinehibanetedan eat baeeag cc fo She Mie edo ic heme gat onpaatas 166
POLAND ® oe:ccc: iessnahasnicags tess Gaveod san Dotttnadaly dang ecanen Seder all pared dake La gee npee a sea sey Shee pe Ne eet ty 167
PORTUGAL. 2.5: Soscieisditicheeacinn A aie Slash haar reriacetomatelta aetna tae strrrernaae 168
Portuguese Guinea (see GUINEA-BISSAU)
Portuguese Timor (see INDONESIA)
=o
QATAR cc seccnetetzny listeled taishe Geet asd nede alesis caugenem ate ees copter asked males cs 170
—R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
REUNION: Geccsettees Acids teleoi w addi. podiaanttavacthanaiiannes eee 171
RHODESIA® sis :scnscosiecocucpees Sete RAE OE capac th Wit erunigear lace ant et ueaint Heaesaieaar teenies 172
Rio Muni (see EQUATORIAL GUINEA) :
ROMANIA: ioc dohacietadihelnwth detente healedra apa eabiteer art elliot 173
RWANDA sess: custites cia cca tule. tess Ate daavdaatadane Heese tahetineneet daartg tera eredbapay teases 175
==s-—
ST. CHRISTOPHER-NEVIS-ANGUILLA ooo... et titre cere 176
STetLUGIA: setics eee eeecde NOR ch A ee a ake ae 177
ST. OVINCENT fii csee fakes Gated oteeteomn Mee aan ae ee bated oe 178
SAN -MARINO® ccssceroecn dees ccadecrt tea edabdewas casei stair verge tasee ei tiaadaladhathargent thas Mantas 178
SAO TOME and PRINCIPE ......::cccccce escent iP dice cegaauecad atest 180
SAUDI “ARABIA® Sseccicoetiacetsudsotnray Ges eka eee Auk Sed ee tie eee aeasbeet 181
SENEGAL ose cintiitisaecnacetevTageula nia rdied Mumm ahian ct bhi sare ceda beatita da papal eh cee ee MR ae 182
SEV. GHELUES. oesverictccve foc halon Sea cot cp Re asec eh ice ed A cea ce ay Sse teehee srg 183
Sharjah (see UNITED ARAB EMIRATES)
SIERRA: LEONE? ieccscccideeedsdegetrnnis chs dando ke seetee eek eran sgiares Gada Gee Nedaccedaytetoaeseh stints 184
SINGAPORE vcce sce dssiecesweinvipndaawi'' ia bates hennes Ghes aes cegaasee tation AE EAR AN ap pats tap anes, 186
SOLOMON ISLANDS (formerly British Solomon Islands) ............:.006 eld tea 187
SOMALIA sicscctsass eer Sead idee tel aae ae. ene oa a ete ata te tn Saat caeaebe tiie 188
SOUTH? AFRICA «ce. sccatsiessks vncdea te atl ee eG hay ai gactn erates conta artes eke 188
Southern Rhodesia (see RHODESIA)
South-West Africa (see NAMIBIA)
SPAIN: es decb eee iia doc aasageaicessaca dennunsva thas nadesn ton danad tha sathaeodsonne sa bans tapi saatlonasgeyccetohs waste 191
Spanish Sahara (see WESTERN SAHARA)
SRI LANKA (formerly Ceylon) o......0..cc ccc teeter rere errr eieennenieieierieny 193
SUDAN: gs olendescytrnstedavesatna abiee Daan phedes Shed ap ag ona aed oui niald and Yyoeah ab erntie gh duedee cage eat ace tenes 194
SURINAME, 6: scuscssschtendes cettehittveniadentas sates ik a Weld ol diene neg den earns Tete 196
SWAZILAND ® ocdccscussedrnseennes bebe islierss terete eeteastlan anne ended elses evade biaas de ates? ~ 497
SWEDEN sateen yeiteetiicnncsicg teu date tis Gri. leatd etneee tas itl oe Game eer Fens Lae 198
SWITZERLAND ois, jeitecrccdeaitetes Gsestaiciss cocies oa Teatsbe dents Hasapah san Poatatpes atu eed sheeh eeaar sees 200
SYRIA L iccaes odiseecces pee Sete dries heist acd ehanas dng deg ots a Sivaanh teagan eae din 201
=
TAIWAN occ cece Su eaeea hdd duel valle dad ries dac atetyred sin deka Aa iddanta Vagecaiteadt yaa ean agiens detest a ange 202
Tanganyika (see TANZANIA)
TANZANIA ciitesl ie eke Auk ie ee bales id selitenamtintegstt teste Aa ie heat 202
Tasmania (see AUSTRALIA)
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5 vii
Approved For Release 2004/06/24 :
= =','eaedb5b3a7f9185d847bbe4f4aa028d9d3f8d943784880be70bc566d434b413c','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dfb37b0f007aa12bf87523c30e22daddda63368a9a942bb2ca7f85923e3de29',1979,'UG','Uganda','raw',2,'TOGO) eceeg age entire nt Gi asain ch cannons
CIA-RDP79-01051A001000010001-5
January 1979
Page
Umm al Qaiwain (see UNITED ARAB EMIRATES)
WES ISERS: sdeccensresded Ok oes eaten sae
213
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain
United Arab Republic (see EGYPT)
UNITED KINGDOM 000.0... tr etc','03bfc13dd6559ac9a2deab5e8b92ad7bb7fee32dff22e1e92e69c89283bcec68','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34dcda20a0f44d6bf3f5b9e4f4c5b1e9ce69dc43b804fd937814d7a625d523a7',1979,'US','United States','raw',3,'UPPER VOLTA
ASEAN Association of Southeast Asian Nations
ASPAC Asian and Pacific Council
BENELUX Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
CACM Central American Common Market
CARICOM Caribbean Common Market
CARIFTA Caribbean Free Trade Association
CEAO West African Economic Community
CEMA Council for Economic Mutual Assistance
CENTO Central Treaty Organization
Colombo Plan
hig as Council of Europe
DAC Development Assistance Committee (OECD)
EAMA African States associated with the EEC
EC European Communities (EEC, ECSC, EURATOM)
ECOWAS Economic Community of West African States
ECSC European Coal and Steel Community
EEC European Economic Community (Common Market)
EFTA European Free Trade Association
EIB European Investment Bank
ELDO European Space Vehicle Launcher Development Organization
EMA European Monetary Agreement
ENTENTE Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Community
G-77 Group of 77
{ADB Inter-American Defense Board
ICES International Cooperation in Ocean Exploration
IDB Inter-American Development Bank
IEA International Energy Agency (Associated with OECD)
IHO International Hydrographic Organization
IPU Inter-Parliamentary Union
IRC International Red Cross
LAFTA Latin American Free Trade Association
LICROSS League of Red Cross Societies
NAM Non-Aligned Movement
NATO North Atlantic Treaty Organization
OAS Organization of American States
OAU Organization of African Unity
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OCAM
ODECA
OECD
SELA
UDEAC
UEAC
WEU
WPC
WT
AIOEC
ANRPC
APC
ASSIMER
CIPEC
\\ATP
IBA
ICAC
ICCO
Ico
looc
ISO
ITC
IWC
Iwc
OAPEC
OPEC
UPEB
WSG
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Latin American Economic System
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
World Tourism Organization
COMMODITY ORGANIZATIONS
Association of Iron Ore Exporting Countries
Association of Natural Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producers
International Bauxite Association
International Cotton Advisory Committee
International Cocoa Council
International Coffee Organization
International Lead and Zinc Study Group
International Olive Oil Council
International Sugar Organization
International Tin Council
international Whaling Commission
International Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting Countries
International Wool Study Group
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
xi
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
Tc Trusteeship Council
ICJ International Court of Justice
eo Ge Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children’s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
‘UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
ATT
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Political, sociological, and economic data, including monetary conversion rates, generally
reflect information through mid-October 1978, except for population estimates, which have
been projected to 1 January 1979. Military manpower estimates are as of 1 July 1978 except
for average number of males reaching military age, which are projected averages for the 5-
year period 1978-82. Military and communications data are as of 31 October 1978 unless
otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of the
statistical data are rounded (thousands and millions). Figures for “arable” may reflect only
the area actually under crops rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the two is
in the addition or subtraction of the value of return on foreign investment. GDP equals GNP
plus income earned in the country but sent abroad, minus income earned abroad but sent into
the country. GDP thus tends to exceed GNP in debtor countries, and the reverse is true in
creditor countries.
Major ports are the largest maritime ports of the country, relative to other ports of the
same country, on the basis of estimated port capacity, alongside berthing accommodations,
and commercial or naval importance. Minor ports are the remaining ports of a country which
have, relative to the major ports, significantly lower estimated capacity, fewer alongside
berthing accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise stated. The abbreviation FY
stands for U.S. fiscal year; all years are calendar years unless otherwise indicated.
Approximate Metric Conversions
Symbol When You Know Multiply by To Find Symbol Symbol When You Know Multiply by To Find Symbol
LENGTH LENGTH
ee
mm millimeters 0.04 inches in in inches 2.5 centimeters om
cm centimeters 0.4 inches in tt foot 30 centimeters cm
m meters 3.3 feet ft yd yards 09 meters m
m meters WW yards yd mi miles 1.6 kilometers km
km kilometers 0.6 miles mi AREA
= AREA in? square inches 6.5 squate centimeters cm?
cm? = square centimeters 0.16 — square inches in? ft? squore feet 0.09 square meters m
m? square meters 1.2 square yards ya? yd? = square yards 0.8 square meters m
km? — square kilometers 0.4 square miles mi? mi? square miles 2.6 square kilometers km?
ha hectores (10,000 m7) 2.5 acres acres 0.4 hectares ho
MASS. (weight) MASS (weight)
@ gram 0.035 ounces oz oz ounces 28 grams 9
kg kilograms 2.2 pounds Ib Ib pounds 0.45 kilograms
1___tonnes (1000 kg) __1.1___ short tons short: fons ai) | “fonnee :
VOLUME ae 20007 IB)
a
ml milliliters 0.03 fluid ounces fl oz VOLUME
1 liters 2.1 pints pt tsp teaspoons 5 milliliters mi
( liters 1.06 — quarts at Tbsp tablespoons 15 miltiliters m
| liters 0.26 — gallons gal fl oz fluid ounces 30 milliliters ml
mm cubic meters 35 cubic feet fP ¢ cups 0.24 liters |
m cubic meters 13 cubic yards yd? pt pints 0.47 titers i]
at quarts 0.95 liters |
gal gallons 3.8 liters |
f° cubic feet 0.03 cubic meters m
yd? cubic_ yards 0.76 cubic meters mm
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979','373e13233be36936d3e6211dba09aff19f980c6e9b56bba470c20b26239f0c6f','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9abd220422da79d3a3a46bc5e90ba28a57f7e240a2636cd97103bb8b5a9acda3',1979,'UY','Uruguay','raw',4,'—Vv—
VATICAN CITY
VENEZUELA cio cesscceste tock escent dhaatatia dei aetds
VIETNAM
—_—w—','a49b55fba0576f9683da9334f9b3b50d72a2901b1e4c2073493ae2ca2ede8c47','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d56c2832ff65d33b7d26e8246127e1418d1a6b2d252d920ec6066b25316a651',1979,'WF','Wallis and Futuna','raw',5,'Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
WESTERN SAMOA
y=
YEMEN (AGO) «scsersissssicosssslscsdusisocsiassdannneisnesiete
YEMEN (Sana)
YUGOSLAVIA','ed456a78e3fae06010b84bee3b12e1127d7bc11cf6c072941ff39273322a94da','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74e4da4c93ad336f8c884051592c5d46d5f9c3d3408991443e770ed7a354745b',1979,'ZM','Zambia','raw',6,'Zanzibar (see TANZANIA)
viii
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
Vill
MAPS','e82da1b244158a2b63bf2652a67bc5a93786be94b3f60ccf8968869f763a1fd0','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd1171dcb21f03c93a024806a206aa4636e57018ab7dc80cf6accb6c2faa4d96',1979,'CA','Canada','raw',7,'MIDDLE AMERICA
SOUTH AMERICA
EUROPE
THE MIDDLE EAST
AFRICA
U.S.S.R. and ASIA
OCEANIA
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
Approved For Release 2004/06/24 : CIA-RDP79-01051A001000010001-5
January 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO Afro-Asian People’s Solidarity Organization
ADB Asian Development Bank
AFDB African Development Bank
ANZUS ANZUS Council; treaty signed by Australia, New Zealand, and the','6c23838bad3bc1086780f8265691a50b637a9fa5871b5a9ab6c7992876c15bd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1a64c8b557c55755105e5525d1b906d30ba7097a302b34342373fec80c77f25',1979,'AF','Afghanistan','raw',8,'Kabul
Arabian Sea
(See reference map Vil}
LAND
647,500 km?; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','74e9f1f5ed8eb33150d19edd52863266a8a90ade83997e09e7c589115578fd3f','internet-archive','cia-readingroom-document-cia-rdp79-01051a001000010001-5','txt','422ad07db5fb06bfcdf08a15908d7b6293aa0c9ba757bd3d849b78adbf370269','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a001000010001-5/cia-rdp79-01051a001000010001-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

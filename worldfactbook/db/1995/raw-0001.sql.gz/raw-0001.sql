SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e50b51b4d8aa491451905c4834ec0e6bbce60d69cacf90b1dbc50f52c4aa8f70',1995,'','','raw',1,'The Project Gutenberg EBook of The 1995 CIA World Factbook, by
United States Central Intelligence Agency
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1995 CIA World Factbook
Author: United States Central Intelligence Agency
Posting Date: August 3, 2008 [EBook #571]
Release Date: June 1996
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1995 CIA WORLD FACTBOOK ***
Produced by Dr. Gregory B. Newby
To search for information on a specific country from the list below,
search for @country: @Afganistan, for example. You can also search
directly for one of the categories of that country as follows:
@Afganistan:Geography
@Afganistan:People
@Afganistan:Government
@Afganistan:Economy
@Afganistan:Transportation
@Afganistan:Communications
@Afganistan:Defense Forces
TABLE OF CONTENTS
Publication Information
Notes, Definitions, and Abbreviations','991dd9fd67daa25516bc4972c15c002533870aff611c72ae22d9d845cfd80aa8','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49d2b66817e99af4722b37ae24d131a720b20a09bc71a6f1ca23b4a03b4bb0eb',1995,'ZW','Zimbabwe','raw',2,'Appendices
A. The United Nations System (a graphical file not available in the
Project Gutenberg edition)
B. Abbreviations for International Organizations and Groups
C. International Organizations and Groups
D. Abbreviations for Selected International Environmental Agreements
E. Selected International Environmental Agreements
F. Weights and Measures
G. Estimates of Gross Domestic Product on an Exchange Rate Basis
H. Cross-Reference List of Geographic Items
________________________________________________________________________
Publication Information for The World Factbook 1995
The printed version of the Factbook is published annually in July by
the Central Intelligence Agency for the use of US Government
officials, and the style, format, coverage, and content are designed
to meet their specific requirements. Information was provided by the
American Geophysical Union, Bureau of the Census, Central Intelligence
Agency, Defense Intelligence Agency, Defense Mapping Agency, Defense
Nuclear Agency, Department of State, Foreign Broadcast Information
Service, Maritime Administration, National Science Foundation (Polar
Information Program), Naval Maritime Intelligence Center, Office of
Territorial and International Affairs, US Board on Geographic Names,
US Coast Guard, and others.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public and Agency Information
Washington, DC 20505
Telephone: [1] (703) 351-2053
US Government officials should obtain copies of The World Factbook
directly from their own organization or through liaison channels from
the Central Intelligence Agency. This publication is also available in
microfiche, magnetic tape, or computer diskettes.
This publication may be purchased by telephone (VISA or MasterCard) or
mail from:
Superintendent of Documents
P.O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800
A subscription to this publication may be purchased from:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, DC 20540
Telephone: [1] (202) 707-9527
This publication may be purchased in printed form, photocopy,
microfiche, magnetic tape, or computer diskettes from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (703) 487-4650
This publication may be purchased in photocopy or microform from:
Photoduplication Service Library of Congress
Washington, DC 20540-5234
Telephone: [1] (202) 707-5640
________________________________________________________________________
NOTES, DEFINITIONS, AND ABBREVIATIONS
There have been some significant changes in this edition. The Trust
Territory of the Pacific Islands became the independent nation of
Palau. The gross domestic product (GDP) of all countries is now
presented on a purchasing power parity (PPP) basis rather than on the
old exchange rate basis. There is a new entry on Age structure and the
Airports entry now includes unpaved runways. The Communications
category has been restructured and now includes the entries of
Telephone system, Radio, and Television. The remainder of the entries
in the former Communications category-Railroads, Highways, Inland
waterways, Pipelines, Ports, Merchant marine, and Airports-can now be
found under a new category called Transportation. There is a new
appendix listing estimates of gross domestic product on an exchange
rate basis for all nations. A reference map of the Republic of South
Africa is included. The electronic files used to produce the Factbook
have been restructured into a database. As a result, the formats of
some entries in this edition have been changed. Additional changes
will occur in the 1996 Factbook.
Abbreviations: (see Appendix B for abbreviations for international
organizations and groups and Appendix D for abbreviations for selected
international environmental agreements)
avdp. -- avoirdupois
c.i.f. -- cost, insurance, and freight
CY -- calendar year
DWT -- deadweight ton
est. -- estimate
Ex-Im -- Export-Import Bank of the United States
f.o.b. -- free on board
FRG -- Federal Republic of Germany (West Germany); used for
information dated before 3 October 1990 or CY91
FSU -- former Soviet Union
FY -- fiscal year
FYROM -- The Former Yugoslav Republic of Macedonia
GDP -- gross domestic product
GDR -- German Democratic Republic (East Germany); used for
information dated before 3 October 1990 or CY91
GNP -- gross national product
GRT -- gross register ton
GWP -- gross world product
km -- kilometer
kW -- kilowatt
kWh -- kilowatt hour
m -- meter
NA -- not available
NEGL -- negligible
nm -- nautical mile
NZ -- New Zealand
ODA -- official development assistance
OOF -- other official flows
PDRY -- People''s Democratic Republic of Yemen [Yemen (Aden) or
South Yemen]; used for information dated before 22 May 1990 or
CY91
sq km -- square kilometer
sq mi -- square mile
UAE -- United Arab Emirates
UK -- United Kingdom
US -- United States
USSR -- Union of Soviet Socialist Republics (Soviet Union); used
for information dated before 25 December 1991
YAR -- Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used
for information dated before 22 May 1990 or CY91
Administrative divisions: The numbers, designatory terms, and
first-order administrative divisions are generally those approved by
the US Board on Geographic Names (BGN). Changes that have been
reported but not yet acted on by BGN are noted.
Airports: Only airports with usable runways are included in this
listing. For airports with more than one runway, only the longest
runway is included. Not all airports have facilities for refueling,
maintenance, or air traffic control. Paved runways have concrete or
asphalt surfaces; unpaved runways have grass, dirt, sand, or gravel
surfaces.
Area: Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate
of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers).
Comparative areas are based on total area equivalents. Most entities
are compared with the entire US or one of the 50 states. The smaller
entities are compared with Washington, DC (178 sq km, 69 sq mi) or The
Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Birth rate: The average annual number of births during a year per
1,000 population at midyear; also known as crude birth rate. Dates of
information: In general, information available as of 1 January 1995 is
used in the preparation of this edition. Population figures are
estimates for 1 July 1995, with population growth rates estimated for
calendar year 1995. Major political events have been updated through
April 1995.
Death rate: The average annual number of deaths during a year per
l,000 population at midyear; also known as crude death rate.
Digraphs: The digraph is a two-letter "country code" that precisely
identifies every entity without overlap, duplication, or omission. AF,
for example, is the digraph for Afghanistan. It is a standardized
geopolitical data element promulgated in the Federal Information
Processing Standards Publication (FIPS) 10-3 by the National Bureau of
Standards (now called National Institute of Standards and Technology)
at the US Department of Commerce and maintained by the Office of the
Geographer at the US Department of State. The digraph is used to
eliminate confusion and incompatibility in the collection, processing,
and dissemination of area-specific data and is particularly useful for
interchanging data between databases.
Diplomatic representation: The US Government has diplomatic relations
with 184 nations, including 178 of the 185 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, former Yugoslavia,
and the US itself). In addition, the US has diplomatic relations with
6 nations that are not in the UN - Holy See, Kiribati, Nauru,
Switzerland, Tonga, and Tuvalu.
Economic aid: This entry refers to bilateral commitments of official
development assistance (ODA) and other official flows (OOF). ODA is
defined as financial assistance which is concessional in character,
has the main objective to promote economic development and welfare of
LDCs, and contains a grant element of at least 25%. OOF transactions
are also official government assistance, but with a main objective
other than development and with a grant element less than 25%. OOF
transactions include official export credits (such as Ex-Im Bank
credits), official equity and portfolio investment, and debt
reorganization by the official sector that does not meet concessional
terms. Aid is considered to have been committed when agreements are
initialed by the parties involved and constitute a formal declaration
of intent.
Entities: Some of the nations, dependent areas, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. "Nation" refers to a people politically organized into a
sovereign state with a definite territory. "Dependent area" refers to
a broad category of political entities that are associated in some way
with a nation. Names used for page headings are usually the short-form
names as approved by the US Board on Geographic Names. There are 266
entities in The World Factbook that may be categorized as follows:
NATIONS
184 -- UN members (excluding the former Yugoslavia, which is still
counted by the UN)
7 -- nations that are not members of the UN--Holy See, Kiribati,
Nauru, Serbia and Montenegro, Switzerland, Tonga, Tuvalu
OTHER
1 -- Taiwan
DEPENDENT AREAS
6 -- Australia--Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 -- Denmark--Faroe Islands, Greenland
16 -- France--Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic
Lands, Glorioso Islands, Guadeloupe, Juan de Nova Island,
Martinique, Mayotte, New Caledonia, Reunion, Saint Pierre and
Miquelon, Tromelin Island, Wallis and Futuna
2 -- Netherlands--Aruba, Netherlands Antilles
3 -- New Zealand--Cook Islands, Niue, Tokelau
3 -- Norway--Bouvet Island, Jan Mayen, Svalbard
1 -- Portugal--Macau
16 -- United Kingdom--Anguilla, Bermuda, British Indian Ocean
Territory, British Virgin Islands, Cayman Islands, Falkland
Islands, Gibraltar, Guernsey, Hong Kong, Jersey, Isle of Man,
Montserrat, Pitcairn Islands, Saint Helena, South Georgia and the
South Sandwich Islands, Turks and Caicos Islands
14 -- United States--American Samoa, Baker Island, Guam, Howland
Island, Jarvis Island, Johnston Atoll, Kingman Reef, Midway
Islands, Navassa Island, Northern Mariana Islands, Palmyra Atoll,
Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 -- Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West
Bank, Western Sahara
OTHER ENTITIES
4 -- oceans--Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean
1 -- World
266 -- total
Exchange rate:
The official value of a nation''s monetary unit at a given date or over
a given period of time, as expressed in units of local currency per US
dollar and as determined by international market forces or official
fiat.
GDP methodology: In the "Economy" section, GDP dollar estimates for
all countries are derived from purchasing power parity (PPP)
calculations rather than from conversions at official currency
exchange rates. The PPP method normally involves the use of
international dollar price weights, which are applied to the
quantities of goods and services produced in a given economy. In
addition to the lack of reliable data from the majority of countries,
the statistician faces a major difficulty in specifying, identifying,
and allowing for the quality of goods and services. The division of a
GDP estimate in local currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. On average, one thousand
dollars will buy the same market basket of goods in the US as one
thousand dollars - converted to the local currency at the PPP
conversion rate - will buy in the other country. Whereas PPP estimates
for OECD countries are quite reliable, PPP estimates for developing
countries are often rough approximations. Most of the GDP estimates
are based on extrapolation of numbers published by the UN
International Comparison Program and by Professors Robert Summers and
Alan Heston of the University of Pennsylvania and their colleagues.
Currency exchange rates depend on a variety of international and
domestic financial forces that often have little relation to domestic
output. In developing countries with weak currencies the exchange rate
estimate of GDP in dollars is typically one-fourth to one-half the PPP
estimate. Furthermore, exchange rates may suddenly go up or down by
10% or more because of market forces or official fiat whereas real
output has remained unchanged. On 12 January 1994, for example, the 14
countries of the African Financial Community (whose currencies are
tied to the French franc) devalued their currencies by 50%. This move,
of course, did not cut the real output of these countries by half. One
important caution: the proportion of, say, defense expenditures as a
percentage of GDP in local currency accounts may differ substantially
from the proportion when GDP accounts are expressed in PPP terms, as,
for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: The numbers for GDP
and other economic data can not be chained together from successive
volumes of the Factbook because of changes in the US dollar measuring
rod, revisions of data by statistical agencies, use of new or
different sources of information, and changes in national statistical
methods and practices.
Gross domestic product (GDP): The value of all final goods and
services produced within a nation in a given year.
Gross national product (GNP): The value of all final goods and
services produced within a nation in a given year, plus income earned
abroad, minus income earned by foreigners from domestic production.
Gross world product (GWP): The aggregate value of all goods and
services produced worldwide in a given year.
Growth rate (population): The annual percent change in the population,
resulting from a surplus (or deficit) of births over deaths and the
balance of migrants entering and leaving a country. The rate may be
positive or negative.
Illicit drugs: There are five categories of illicit drugs - narcotics,
stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by
doctors as well as those illegally produced and sold outside medical
channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana
(pot, Acapulco gold, grass, reefer), tetrahydrocannabinol (THC,
Marinol), hashish (hash), and hashish oil (hash oil).
Coca (Erythroxylum coca) is a bush, and the leaves contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa,
which comes from cacao seeds and is used in making chocolate, cocoa,
and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal,
phenobarbital), benzodiazepines (Librium, Valium), methaqualone
(Quaalude), glutethimide (Doriden), and others (Equanil, Placidyl,
Valmid). Drugs are any chemical substances that effect a physical,
mental, emotional, or behavioral change in an individual. Drug abuse
is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an
individual. Hallucinogens are drugs that affect sensation, thinking,
self-awareness, and emotion. Hallucinogens include LSD (acid,
microdot), mescaline and peyote (mexc, buttons, cactus), amphetamine
variants (PMA, STP, DOB), phencyclidine (PCP, angel dust, hog),
phencyclidine analogues (PCE, PCPy, TCP), and others (psilocybin,
psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant
(Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is the Southwest Asian slang term for methaqualone, a
pharmaceutical depressant.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis
sativa).
Methaqualone is a pharmaceutical depressant, in slang referred to as
Quaaludes in North America or Mandrax in Southwest Asia Narcotics are
drugs that relieve pain, often induce sleep, and refer to opium, opium
derivatives, and synthetic substitutes. Natural narcotics include
opium (paregoric, parepectolin), morphine (MS-Contin, Roxanol),
codeine (Tylenol with codeine, Empirin with codeine, Robitussan AC),
and thebaine. Semisynthetic narcotics include heroin (horse, smack),
and hydromorphone (Dilaudid). Synthetic narcotics include meperidine
or Pethidine (Demerol, Mepergan), methadone (Dolophine, Methadose),
and others (Darvon, Lomotil).
Opium is the milky exudate of the incised, unripe seedpod of the opium
poppy. Opium poppy (Papaver somniferum) is the source for many natural
and semisynthetic narcotics. Poppy straw concentrate is the alkaloid
derived from the mature dried opium poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of catha edulis
that is chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and
activity, and include cocaine (coke, snow, crack), amphetamines
(Desoxyn, Dexedrine), phenmetrazine (Preludin), methylphenidate
(Ritalin), and others (Cylert, Sanorex, Tenuate).
Infant mortality rate: The number of deaths to infants under one year
old in a given year per l,000 live births occurring in the same year.
International disputes: This category includes a wide variety of
situations that range from traditional bilateral boundary disputes to
unilateral claims of one sort or another. Information regarding
disputes over international boundaries and maritime boundaries has
been reviewed by the Department of State. References to other
situations involving borders or frontiers may also be included, such
as resource disputes, geopolitical questions, or irredentist issues.
However, inclusion does not necessarily constitute official acceptance
or recognition by the US Government.
Irrigated land: The figure refers to the land area that is
artificially supplied with water.
Land use: The land surface is categorized as arable land - land
cultivated for crops that are replanted after each harvest (wheat,
maize, rice); permanent crops - land cultivated for crops that are not
replanted after each harvest (citrus, coffee, rubber); meadows and
pastures - land permanently used for herbaceous forage crops; forest
and woodland - under dense or open stands of trees; and other - any
land type not specifically mentioned above (urban areas, roads,
desert).
Leaders: The chief of state is the titular leader of the country who
represents the state at official and ceremonial functions but is not
involved with the day- to-day activities of the government. The head
of government is the administrative leader who manages the day-to-day
activities of the government. In the UK, the monarch is the chief of
state, and the Prime Minister is the head of government. In the US,
the President is both the chief of state and the head of government.
Life expectancy at birth: The average number of years to be lived by a
group of people all born in the same year, if mortality at each age
remains constant in the future.
Literacy: There are no universal definitions and standards of
literacy. Unless otherwise noted, all rates are based on the most
common definition - the ability to read and write at a specified age.
Detailing the standards that individual countries use to assess the
ability to read and write is beyond the scope of this publication.
Maritime claims: The proximity of neighboring states may prevent some
national claims from being extended the full distance.
Merchant marine: All ships engaged in the carriage of goods. All
commercial vessels (as opposed to all nonmilitary ships), which
excludes tugs, fishing vessels, offshore oil rigs, etc. Also, a
grouping of merchant ships by nationality or register.
Captive register - A register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships
owned in the parent country; also referred to as an offshore register,
the offshore equivalent of an internal register. Ships on a captive
register will fly the same flag as the parent country, or a local
variant of it, but will be subject to the maritime laws and taxation
rules of the offshore territory. Although the nature of a captive
register makes it especially desirable for ships owned in the parent
country, just as in the internal register, the ships may also be owned
abroad. The captive register then acts as a flag of convenience
register, except that it is not the register of an independent state.
Flag of convenience register - A national register offering
registration to a merchant ship not owned in the flag state. The major
flags of convenience (FOC) attract ships to their registers by virtue
of low fees, low or nonexistent taxation of profits, and liberal
manning requirements. True FOC registers are characterized by having
relatively few of the ships registered actually owned in the flag
state. Thus, while virtually any flag can be used for ships under a
given set of circumstances, an FOC register is one where the majority
of the merchant fleet is owned abroad. It is also referred to as an
open register.
Flag state - The nation in which a ship is registered and which holds
legal jurisdiction over operation of the ship, whether at home or
abroad. Flag state maritime legislation determines how a ship is
manned and taxed and whether a foreign-owned ship may be placed on the
register.
Internal register - A register of ships maintained as a subset of a
national register. Ships on the internal register fly the national
flag and have that nationality but are subject to a separate set of
maritime rules from those on the main national register. These
differences usually include lower taxation of profits, manning by
foreign nationals, and, usually, ownership outside the flag state
(when it functions as an FOC register). The Norwegian International
Ship Register and Danish International Ship Register are the most
notable examples of an internal register. Both have been instrumental
in stemming flight from the national flag to flags of convenience and
in attracting foreign owned ships to the Norwegian and Danish flags.
Merchant ship - A vessel that carries goods against payment of
freight; commonly used to denote any nonmilitary ship but accurately
restricted to commercial vessels only.
Register - The record of a ship''s ownership and nationality as listed
with the maritime authorities of a country; also, the compendium of
such individual ships'' registrations. Registration of a ship provides
it with a nationality and makes it subject to the laws of the country
in which registered (the flag state) regardless of the nationality of
the ship''s ultimate owner.
Money figures: All money figures are expressed in contemporaneous US
dollars unless otherwise indicated.
National product: The total output of goods and services in a country
in a given year. See GDP methodology, Gross domestic product (GDP),
and Gross national product (GNP).
Net migration rate: The balance between the number of persons entering
and leaving a country during the year per 1,000 persons (based on
midyear population). An excess of persons entering the country is
referred to as net immigration (3.56 migrants/1,000 population); an
excess','f3ace5aba235b363a09ae3e6d0a3eaa8ddee5e06721f10631c8e393e75ce6be9','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fc64fe0f24f0bdfa41517fc27e3027ef27194f7094ece7a0fcc988641774d64',1995,'ZW','Zimbabwe','raw',3,'of persons leaving the country as net emigration (-9.26
migrants/1,000 population).
Population: Figures are estimates from the Bureau of the Census based
on statistics from population censuses, vital statistics registration
systems, or sample surveys pertaining to the recent past, and on
assumptions about future trends. Starting with the 1993 Factbook,
demographic estimates for some countries (mostly African) have taken
into account the effects of the growing incidence of AIDS infections;
in 1993 these countries were Burkina, Burundi, Central African
Republic, Congo, Cote d''Ivoire, Kenya, Malawi, Rwanda, Tanzania,
Uganda, Zaire, Zambia, Zimbabwe, Thailand, Brazil, and Haiti.
Telephone numbers: All telephone numbers presented in the Factbook
consist of the country code in brackets, the city or area code (where
required) in parentheses, and the local number. The one component that
is not presented is the international access code which varies from
country to country. For example, an international direct dial phone
call placed from the United States to Madrid, Spain, would be as
follows:
011 [34] (1) 577-xxxx where
011 is the international access code for station-to-station calls
(01 is for calls other than station-to-station calls),
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange,
and xxxx is the local telephone number.
An international direct dial phone call placed from another country to
the United States would be as follows:
international access code + [1] (202) 939-xxxx where
[1] is the country code for the United States,
(202) is the area code for Washington, DC,
939 is the local exchange,
and xxxx is the local telephone number.
Total fertility rate: The average number of children that would be
born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each
age. Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY). FY93/94 refers to the fiscal year that
began in calendar year 1993 and ended in calendar year 1994 as defined
in the Fiscal Year entry of the Economy section for each nation.
FY90-94 refers to the four fiscal years that began in calendar year
1990 and ended in calendar year 1994.
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates. The Handbook of International Economic
Statistics, published annually in September by the Central
Intelligence Agency, contains detailed economic information for the
Organization for Economic Cooperation and Development (OECD)
countries, Eastern Europe, the newly independent republics of the
former nations of Yugoslavia and the Soviet Union, and selected other
countries. The Handbook can be obtained wherever The World Factbook is
available.
________________________________________________________________________','ba2a1eb5a89a4900223c84416c48fa7777cd95a92fbce1ac2d8878ee1c546ba1','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd690033376ee933fba6a3a179fd10db82fc72c11cd02f92810e91739e0a0aa3',1995,'AF','Afghanistan','raw',4,'@Afghanistan:Geography
Location: Southern Asia, north of Pakistan
Map references: Asia
Area:
total area: 647,500 sq km
land area: 647,500 sq km
comparative area: slightly smaller than Texas
Land boundaries: total 5,529 km, China 76 km, Iran 936 km,
Pakistan 2,430 km, Tajikistan 1,206 km, Turkmenistan 744 km,
Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: periodic disputes with Iran over Helmand water
rights; Iran supports clientsin country, private Pakistani and Saudi
sources also are active; power struggles among various groups for
control of Kabul, regional rivalries among emerging warlords,
traditional tribal disputes continue; support to Islamic fighters in
Tajikistan''s civil war; border dispute with Pakistan (Durand Line);
support to Islamic militants worldwide by some factions
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Natural resources: natural gas, petroleum, coal, copper, talc,
barites, sulphur, lead, zinc, iron ore, salt, precious and
semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
meadows and pastures: 15%
forest and woodland: 3%
other: 39%
Irrigated land: 26,600 sq km (1989 est.)','d85622e6f4df890e532be30e0aab41690b54ad55b5e0725cf90cf519ff0ea3fa','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e2fad4180d59ee941e5f45afda670c5ca69974aa43189632a33115b520ff1a4',1995,'CA','Canada','communications',49,'international: 5 coaxial submarine cables; 5 INTELSAT earth stations
(4 Atlantic Ocean and 1 Pacific Ocean)
Radio:
broadcast stations: AM 900, FM 29, shortwave 0
radios: NA
Television:
broadcast stations: 53 (repeaters 1,400)
televisions: NA
@Canada:Defense Forces
Branches: Canadian Armed Forces (includes Land Forces Command or LC,
Maritime Command or MC, Air Command or AC, Communications Command or
CC, Training Command or TC), Royal Canadian Mounted Police (RCMP)
Manpower availability: males age 15-49 7,570,877; males fit for
military service 6,522,092; males reach military age (17) annually
151,590 (1995 est.)
Defense expenditures: exchange rate conversion - $9.0 billion, 1.6% of
GDP (FY95/96)
________________________________________________________________________
CAPE VERDE
@Cape Verde:Geography
Location: Western Africa, group of Islands in the North Atlantic
Ocean, west of Senegal
Map references: World
Area:
total area: 4,030 sq km
land area: 4,030 sq km
comparative area: slightly larger than Rhode Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: temperate; warm, dry, summer; precipitation very erratic
Terrain: steep, rugged, rocky, volcanic
Natural resources: salt, basalt rock, pozzolana, limestone, kaolin,
fish
Land use:
arable land: 9%
permanent crops: 0%
meadows and pastures: 6%
forest and woodland: 0%
other: 85%
Irrigated land: 20 sq km (1989 est.)','5d474855ad93065d839ddc3a779a8c3251c264778840b568224a28f0550070c3','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

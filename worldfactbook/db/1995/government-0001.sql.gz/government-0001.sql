SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06d2a5ba878e2471b24224b06c1ab8969dc933e6404edbf78f2a4ac22a89144',1995,'BM','Bermuda','government',33,'@Bermuda:People
Population: 61,629 (July 1995 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.76% (1995 est.)
Birth rate: 15.07 births/1,000 population (1995 est.)
Death rate: 7.3 deaths/1,000 population (1995 est.)
Net migration rate: -0.13 migrant(s)/1,000 population (1995 est.)
Infant mortality rate: 13.16 deaths/1,000 live births (1995 est.)
Life expectancy at birth:
total population: 75.03 years
male: 73.36 years
female: 76.97 years (1995 est.)
Total fertility rate: 1.81 children born/woman (1995 est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic divisions: black 61%, white and other 39%
Religions: Anglican 37%, Roman Catholic 14%, African Methodist
Episcopal (Zion) 10%, Methodist 6%, Seventh-Day Adventist 5%, other
28%
Languages: English
Literacy: age 15 and over can read and write (1970)
total population: 98%
male: 98%
female: 99%
Labor force: 32,000
by occupation: clerical 25%, services 22%, laborers 21%, professional
and technical 13%, administrative and managerial 10%, sales 7%,
agriculture and fishing 2% (1984)
@Bermuda:Government
Names:
conventional long form: none
conventional short form: Bermuda
Digraph: BD
Type: dependent territory of the UK
Capital: Hamilton
Administrative divisions: 9 parishes and 2 municipalities*;
Devonshire, Hamilton, Hamilton*, Paget, Pembroke, Saint George*, Saint
Georges, Sandys, Smiths, Southampton, Warwick
Independence: none (dependent territory of the UK)
National holiday: Bermuda Day, 24 May
Constitution: 8 June 1968
Legal system: English law
Suffrage: 21 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February 1952),
represented by Governor Lord David WADDINGTON (since 25 August 1992)
head of government: Premier John William David SWAN (since NA January
1982); Deputy Premier J. Irving PEARMAN (since 5 October 1993)
cabinet: Cabinet; nominated by the premier, appointed by the governor
Legislative branch: bicameral Parliament
Senate: consists of an 11-member body appointed by the governor
House of Assembly: elections last held 5 October 1993 (next to be held
by NA October 1998); results - percent of vote by party UBP 50%, PLP
46%, independents 4%; seats - (40 total) UBP 22, PLP 18
Judicial branch: Supreme Court
Political parties and leaders: United Bermuda Party (UBP), John W. D.
SWAN; Progressive Labor Party (PLP), Frederick WADE; National Liberal
Party (NLP), Gilbert DARRELL
Other political or pressure groups: Bermuda Industrial Union (BIU),
Ottiwell SIMMONS
Member of: CARICOM (observer), CCC, ICFTU, INTERPOL (subbureau), IOC
Diplomatic representation in US: none (dependent territory of the UK)
US diplomatic representation:
chief of mission: Ambassador Robert A. FARMER
consulate(s) general: Crown Hill, 16 Middle Road, Devonshire, Hamilton
mailing address: P. O. Box HM325, Hamilton HMBX; PSC 1002, FPO AE
09727-1002
telephone: [1] (809) 295-1342
FAX: [1] (809) 295-1592
Flag: red with the flag of the UK in the upper hoist-side quadrant and
the Bermudian coat of arms (white and blue shield with a red lion
holding a scrolled shield showing the sinking of the ship Sea Venture
off Bermuda in 1609) centered on the outer half of the flag
@Bermuda:Economy
Overview: Bermuda enjoys one of the highest per capita incomes in the
world, having successfully exploited its location by providing luxury
tourist facilities and financial services. The tourist industry
attracts more than 90% of its business from North America. The
industrial sector is small, and agriculture is severely limited by a
lack of suitable land. About 80% of food needs are imported.
National product: GDP - purchasing power parity - $1.7 billion (1994
est.)
National product real growth rate: 2.5% (1994)
National product per capita: $28,000 (1994 est.)
Inflation rate (consumer prices): 2.5% (1993)
Unemployment rate: 6% (1991)
Budget:
revenues: $327.5 million
expenditures: $308.9 million, including capital expenditures of $35.4
million (FY90/91 est.)
Exports: $60 million (f.o.b., 1991)
commodities: semitropical produce, light manufactures, re-exports of
pharmaceuticals
partners: US 62.4%, UK 20%
Imports: $519 million (f.o.b.,1993)
commodities: fuel, foodstuffs, machinery
partners: US 38%, UK 5%, Canada 5%
External debt: $NA
Industrial production: growth rate NA%
Electricity:
capacity: 140,000 kW
production: 504 million kWh
consumption per capita: 7,745 kWh (1993)
Industries: tourism, finance, structural concrete products, paints,
pharmaceuticals, ship repairing
Agriculture: accounts for less than 1% of GDP; most basic foods must
be imported; produces bananas, vegetables, citrus fruits, flowers,
dairy products
Economic aid:
recipient: US commitments, including Ex-Im (FY70-81), $34 million;
Western (non-US) countries, ODA and OOF bilateral commitments
(1970-89), $277 million
Currency: 1 Bermudian dollar (Bd$) = 100 cents
Exchange rates: Bermudian dollar (Bd$) per US$1 - 1.0000 (fixed rate)
Fiscal year: 1 April - 31 March
@Bermuda:Transportation
Railroads: 0 km
Highways:
total: 210 km
paved: 210 km
note: in addition, there are 400 km of paved and unpaved roads that
are privately owned
Ports: Hamilton, Saint George
Merchant marine:
total: 65 ships (1,000 GRT or over) totaling 3,144,245 GRT/5,152,030
DWT
ships by type: bulk 14, cargo 4, container 7, liquefied gas tanker 15,
oil tanker 16, refrigerated cargo 2, roll-on/roll-off cargo 5,
short-sea passenger 1, vehicle carrier 1
note: a flag of convenience registry; includes 12 countries among
which are UK 6 ships, Canada 4, US 4, Sweden 3, Hong Kong 2, Mexico 2,
Norway 2, Australia 1, Germany 1, NZ 1
Airports:
total: 1
with paved runways 2,438 to 3,047 m: 1
@Bermuda:Communications
Telephone system: 52,670 telephones; modern, fully automatic telephone
system
local: NA
intercity: NA
international: 3 submarine cables; 2 INTELSAT (Atlantic Ocean) earth
stations
Radio:
broadcast stations: AM 5, FM 3, shortwave 0
radios: NA
Television:
broadcast stations: 2
televisions: NA
@Bermuda:Defense Forces
Branches: Bermuda Regiment, Bermuda Police Force, Bermuda Reserve
Constabulary
Defense expenditures: $NA, NA% of GDP
Note: defense is the responsibility of the UK
________________________________________________________________________','349c3aaa031c053a9b068da760d629f547a42261b50303cfa76e79a6c4e7128e','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('655f5a893e6cdaceb6ccc085084d6afaaf92c2ac554440ff251f66c670607525',1995,'BT','Bhutan','government',34,'@Bhutan:Geography
Location: Southern Asia, between China and India
Map references: Asia
Area:
total area: 47,000 sq km
land area: 47,000 sq km
comparative area: slightly more than half the size of Indiana
Land boundaries: total 1,075 km, China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: varies; tropical in southern plains; cool winters and hot
summers in central valleys; severe winters and cool summers in
Himalayas
Terrain: mostly mountainous with some fertile valleys and savanna
Natural resources: timber, hydropower, gypsum, calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 70%
other: 23%
Irrigated land: 340 sq km (1989 est.)','093683121f410fd015fe09be6d1340e615febd9b0b21f9b15bd93ff0471a257e','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa1d4f3268bf5281253020ba4e4b9df0467b40585eea03e30302c709a95767b1',1995,'GL','Greenland','government',104,'National product: GDP - purchasing power parity - $NA
National product real growth rate: NA%
National product per capita: $NA
Inflation rate (consumer prices): 1.3% (1993 est.)
Unemployment rate: 6.6% (1993 est.)
Budget:
revenues: $667 million
expenditures: $635 million, including capital expenditures of $103.8
million (1993 est.)
Exports: $330.5 million (f.o.b., 1993 est.)
commodities: fish and fish products 95%
partners: Denmark 79%, Benelux 9%, Germany 5%
Imports: $369.6 million (c.i.f., 1993 est.)
commodities: manufactured goods 28%, machinery and transport equipment
24%, food and live animals 12.4%, petroleum products 12%
partners: Denmark 65%, Norway 8.8%, US 4.6%, Germany 3.8%, Japan 3.8%,
Sweden 2.4%
External debt: $297.1 million (1993)
Industrial production: growth rate NA%
Electricity:
capacity: 84,000 kW
production: 210 million kWh
consumption per capita: 3,361 kWh (1993)
Industries: fish processing (mainly shrimp), lead and zinc mining,
handicrafts, some small shipyards, potential for platinum and gold
mining
Agriculture: sector dominated by fishing and sheep raising; crops
limited to forage and small garden vegetables; 1988 fish catch of
133,500 metric tons
Economic aid: none
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: Danish kroner (DKr) per US$1 - 6.034 (January 1995),
6.361 (1994), 6.484 (1993), 6.036 (1992), 6.396 (1991), 6.189 (1990)
Fiscal year: calendar year
@Greenland:Transportation
Railroads: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
Ports: Faeringehavn, Frederikshaab, Holsteinsborg, Nanortalik, Narsaq,
Nuuk (Godthaab), Sondrestrom
Merchant marine: none
Airports:
total: 10
with paved runways over 3,047 m: 1
with paved runways 2,438 to 3,047 m: 1
with paved runways 1,524 to 2,437 m: 1
with paved runways 914 to 1,523 m: 1
with paved runways under 914 m: 2
with unpaved runways 1,524 to 2,438 m: 1
with unpaved runways 914 to 1,523 m: 3
@Greenland:Communications
Telephone system: 17,900 telephones; adequate domestic and
international service provided by cables and microwave radio relay
local: NA
intercity: microwave radio relay
international: 2 coaxial submarine cables; 1 INTELSAT (Atlantic Ocean)
earth station
Radio:
broadcast stations: AM 5, FM 7 (repeaters 35), shortwave 0
radios: NA
Television:
broadcast stations: 4 (repeaters 9)
televisions: NA
@Greenland:Defense Forces
Note: defense is responsibility of Denmark
________________________________________________________________________','cfca928bb01e875e1c4ddf8381b7a2a93911e1a7a2469164de5094483d56cc1a','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac786fa04ec1c3457c9ebee96bd39196cbc5e913e4ef1fa364b3927e62c1b567',1995,'GD','Grenada','government',105,'@Grenada:Geography
Location: Caribbean, island in the Caribbean Sea, north of Trinidad
and Tobago
Map references: Central America and the Caribbean
Area:
total area: 340 sq km
land area: 340 sq km
comparative area: slightly less than twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Natural resources: timber, tropical fruit, deepwater harbors
Land use:
arable land: 15%
permanent crops: 26%
meadows and pastures: 3%
forest and woodland: 9%
other: 47%
Irrigated land: NA sq km','cd90a63a418d5963d817e9160c3a8cbd43563b2f2f3992be42da7d680fd4d85b','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1592cfb0e04ea671ccc50bef07ffdcc6eb8caf3e164dfcba03acf68f5a326931',1995,'ID','Indonesia','government',120,'Suffrage: 15 years of age; universal
Executive branch:
supreme leader (rahbar) and functional chief of state: Leader of the
Islamic Revolution Ayatollah Ali Hoseini-KHAMENEI (since 4 June 1989)
head of government: President Ali Akbar Hashemi-RAFSANJANI (since 3
August 1989); election last held June 1993 (next to be held June
1997); results - Ali Akbar Hashemi-RAFSANJANI was elected with 63% of
the vote
cabinet: Council of Ministers; selected by the president with
legislative approval
Legislative branch: unicameral
Islamic Consultative Assembly (Majles-e-Shura-ye-Eslami): elections
last held 8 April 1992 (next to be held April 1996); results - percent
of vote by party NA; seats - (270 seats total) number of seats by
party NA
Judicial branch: Supreme Court
Political parties and leaders: there are at least 76 licensed parties;
the three most important are - Tehran Militant Clergy Association,
Mohammad Reza MAHDAVI-KANI; Militant Clerics Association, Mehdi
MAHDAVI-KARUBI and Mohammad Asqar MUSAVI-KHOINIHA; Fedaiyin Islam
Organization, Sadeq KHALKHALI
Other political or pressure groups: groups that generally support the
Islamic Republic include Hizballah, Mojahedin of the Islamic
Revolution, Muslim Students Following the Line of the Imam; armed
political groups that have been almost completely repressed by the
government include Mojahedin-e Khalq Organization (MEK), People''s
Fedayeen, Kurdish Democratic Party; the Society for the Defense of
Freedom
Member of: CCC, CP, ECO, ESCAP, FAO, G-19, G-24, G-77, IAEA, IBRD,
ICAO, ICC, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM (observer), ISO, ITU, NAM, OIC, OPEC,
PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL, WFTU, WHO, WMO, WTO
Diplomatic representation in US:
chief of mission: Iran has an Interests Section in the Pakistani
Embassy in Washington, DC
chancery: Iranian Interests Section, 2209 Wisconsin Avenue NW,
Washington, DC 20007
telephone: [1] (202) 965-4990
US diplomatic representation: protecting power in Iran is Switzerland
Flag: three equal horizontal bands of green (top), white, and red; the
national emblem (a stylized representation of the word Allah) in red
is centered in the white band; Allah Alkbar (God is Great) in white
Arabic script is repeated 11 times along the bottom edge of the green
band and 11 times along the top edge of the red band
@Iran:Economy
Overview: Iran''s economy is a mixture of central planning, state
ownership of oil and other large enterprises, village agriculture, and
small-scale private trading and service ventures. Over the past
several years, the government has introduced several measures to
liberalize the economy and reduce government intervention, but most of
these changes have moved slowly because of political opposition. Iran
has faced increasingly severe financial difficulties since mid-1992
due to an import surge that began in 1989 and general financial
mismanagement. At yearend 1993 the Iranian Government estimated that
it owed foreign creditors about $30 billion; an estimated $8 billion
of this debt was in arrears. At yearend 1994, Iran rescheduled $12
billion in debt. Earnings from oil exports - which provide 90% of
Iran''s export revenues - are providing less relief to Iran than usual
because of reduced oil prices.
National product: GDP - purchasing power parity - $310 billion (1994
est.)
National product real growth rate: -2% (1994 est.)
National product per capita: $4,720 (1994 est.)
Inflation rate (consumer prices): 35% (1994)
Unemployment rate: over 30% (1994 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Exports: $16 billion (f.o.b., FY92/93 est.)
commodities: petroleum 90%, carpets, fruits, nuts, hides
partners: Japan, Italy, France, Netherlands, Belgium/Luxembourg,
Spain, and Germany
Imports: $18 billion (c.i.f., FY92/93 est.)
commodities: machinery, military supplies, metal works, foodstuffs,
pharmaceuticals, technical services, refined oil products
partners: Germany, Japan, Italy, UK, UAE
External debt: $30 billion (December 1993)
Industrial production: growth rate 4.6% (1993 est.); accounts for
almost 30% of GDP, including petroleum
Electricity:
capacity: 19,080,000 kW
production: 50.8 billion kWh
consumption per capita: 745 kWh (1993)
Industries: petroleum, petrochemicals, textiles, cement and other
building materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating, armaments and military
equipment
Agriculture: accounts for about 20% of GDP; principal products -
wheat, rice, other grains, sugar beets, fruits, nuts, cotton, dairy
products, wool, caviar; not self-sufficient in food
Illicit drugs: illicit producer of opium poppy for the domestic and
international drug trade; produced 35-70 metric tons in 1993; net
opiate importer but also a key transshipment point for Southwest Asian
heroin to Europe
Economic aid:
recipient: US commitments, including Ex-Im (FY70-80), $1 billion;
Western (non-US) countries, ODA and OOF bilateral commitments
(1970-89), $1.675 billion; Communist countries (1970-89), $976 million
note: aid fell sharply following the 1979 revolution
Currency: 10 Iranian rials (IR) = 1 toman; note - domestic figures are
generally referred to in terms of the toman
Exchange rates: Iranian rials (IR) per US$1 - 1,749.04 (January 1995),
1,748.75 (1994), 1,267.77 (1993), 65.552 (1992), 67.505 (1991); black
market rate: 3,000 rials per US$1 (December 1994)
Fiscal year: 21 March - 20 March
@Iran:Transportation
Railroads:
total: 4,850 km; note - 480 km under construction from Bafq to
Bandar-e ''Abbas; segment from Bafq to Sirjan has been completed and is
operational; section from Sirjan to Bandar-e ''Abbas still under
construction
broad gauge: 90 km 1.676-m gauge
narrow gauge: 4,760 km 1.432-m gauge
Highways:
total: 140,200 km
paved: 42,694 km
unpaved: gravel, crushed stone 46,866 km; improved earth 49,440 km;
unimproved earth 1,200 km
Inland waterways: 904 km; the Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been dredged to 3
meters and is in use
Pipelines: crude oil 5,900 km; petroleum products 3,900 km; natural
gas 4,550 km
Ports: Abadan (largely destroyed in fighting during 1980-88 war),
Ahvaz, Bandar Beheshti, Bandar-e ''Abbas, Bandar-e Anzali, Bandar-e
Bushehr, Bandar-e Khomeyni, Bandar-e Mah Shahr, Bandar-e Torkeman,
Jazireh-ye Khark, Jazireh-ye Lavan, Jazireh-ye Sirri, Khorramshahr
(limited operation since November 1992), Now Shahr
Merchant marine:
total: 132 ships (1,000 GRT or over) totaling 3,816,820 GRT/6,991,693
DWT
ships by type: bulk 48, cargo 38, chemical tanker 5, combination bulk
2, liquefied gas tanker 1, oil tanker 26, refrigerated cargo 3,
roll-on/roll-off cargo 8, short-sea passenger 1
Airports:
total: 261
with paved runways over 3,047 m: 28
with paved runways 2,438 to 3,047 m: 12
with paved runways 1,524 to 2,437 m: 32
with paved runways 914 to 1,523 m: 20
with paved runways under 914 m: 46
with unpaved runways over 3,047 m: 2
with unpaved runways 2,438 to 3,047 m: 2
with unpaved runways 1,524 to 2,438 m: 18
with unpaved runways 914 to 1,523 m: 101
@Iran:Communications
Telephone system: 2,143,000 telephones; 35 telephones/1,000 persons
local: NA
intercity: microwave radio relay extends throughout country; system
centered in Tehran
international: 3 INTELSAT (2 Atlantic Ocean and 1 Indian Ocean) earth
stations; HF radio and microwave radio relay to Turkey, Pakistan,
Syria, Kuwait, Tajikistan, and Uzbekistan; submarine fiber optic cable
to UAE
Radio:
broadcast stations: AM 77, FM 3, shortwave 0
radios: NA
Television:
broadcast stations: 28
televisions: NA
@Iran:Defense Forces
Branches: Islamic Republic of Iran Ground Forces, Navy, Air and Air
Defense Force, Revolutionary Guards (includes Basij militia with its
ground, air, and naval forces), Law Enforcement Forces
Manpower availability: males age 15-49 14,639,290; males fit for
military service 8,703,732; males reach military age (21) annually
615,096 (1995 est.)
Defense expenditures: according to official Iranian data, Iran spent
1,785 billion rials, including $808 million in hard currency, in 1992
and budgeted 2,507 billion rials, including $850 million in hard
currency, for 1993
note: conversion of rial expenditures into US dollars using the
current exchange rate could produce misleading results
________________________________________________________________________','0bb26f9cedc09fa6ba2991c32fd7dc227cc1b29eff6fe8b7e5763733cce36074','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7e3fd89d2e7fb7b0231aeda2087d420c72c07729ba4c461666059fe9837821c',1995,'IQ','Iraq','government',121,'@Iraq:Geography
Location: Middle East, bordering the Persian Gulf, between Iran and','0ec4559620cd26619c507f7150e50a0433d84cc3984183a00360a4737ab13023','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b63ceca6d76c1a4e62e0d03b5528f35535f0602da7de90313322d9ab406bfd83',1995,'KW','Kuwait','government',122,'Map references: Middle East
Area:
total area: 437,072 sq km
land area: 432,162 sq km
comparative area: slightly more than twice the size of Idaho
Land boundaries: total 3,631 km, Iran 1,458 km, Jordan 181 km, Kuwait
242 km, Saudi Arabia 814 km, Syria 605 km, Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm
International disputes: Iran and Iraq restored diplomatic relations in
1990 but are still trying to work out written agreements settling
outstanding disputes from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of navigation and
sovereignty over the Shatt al Arab waterway; in November 1994, Iraq
formally accepted the UN-demarcated border with Kuwait which had been
spelled out in Security Council Resolutions 687 (1991), 773 (1993),
and 883 (1993); this formally ends earlier claims to Kuwait and to
Bubiyan and Warbah islands; potential dispute over water development
plans by Turkey for the Tigris and Euphrates Rivers
Climate: mostly desert; mild to cool winters with dry, hot, cloudless
summers; northern mountainous regions along Iranian and Turkish
borders experience cold winters with occasionally heavy snows which
melt in early spring, sometimes causing extensive flooding in central
and southern Iraq
Terrain: mostly broad plains; reedy marshes along Iranian border in
south; mountains along borders with Iran and Turkey
Natural resources: petroleum, natural gas, phosphates, sulfur
Land use:
arable land: 12%
permanent crops: 1%
meadows and pastures: 9%
forest and woodland: 3%
other: 75%
Irrigated land: 25,500 sq km (1989 est)','3636e015faa2433224589a52d56a268b8227a7b521ef4ea061393d017d296171','internet-archive','theciaworldfactb00571gut','txt','699fe135ca80d513456b98d358b2cea4f56355851407fcc95ca7504ae4860e57','https://archive.org/download/theciaworldfactb00571gut/571.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

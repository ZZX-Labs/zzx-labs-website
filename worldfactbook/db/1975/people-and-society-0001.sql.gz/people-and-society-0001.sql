SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54e9344f024f510e4753ece16b87e8bc6375352454fa23fb6f4a50a587306414',1975,'AF','Afghanistan','people-and-society',7,'Population: 19,1*17,000, average annual growth
rate 2.3% (7/72-7/73)
Nationality: noun — Afghnn(s); adjective — Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9%
Uzbeks, 9% Hazaras, minor ethnic groups include
Chahnr, Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim,
1% other
Language: 50% Pushtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily Uzbek and
Turkmen), 10% 30 minor languages (primarily
Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about *1.3 million (official cst.); 75%-
80% agriculture and animal husbandry, 20%-25%
commerce, small industry, services; massive shortage
of skilled labor
Organized labor: none','99c52cf13992f931f388cb401562f3200f3019c6414a59aee011e38567b29e32','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ba2b43578d8ee4a74cc10c605374534a02ecd34ba0dd7fba77a497830c0eb7e',1975,'DZ','Algeria','people-and-society',14,'Population: 10.701. 000. average annual growth
rate 3 27 (7/737/74)
Nationality: noun — A lgerian(s ). adjective —
Algerian
Ltlmie divisions: 00 S’ Arah-llerhers, less than I 7
Europeans
Religion: 097 Muslim, 17 Christian and Hebrew
Language: Arabic (official ). Trench, Berber dialects
Literacy: 23 ri (37 Arabic, 97 Trench, Ilf? both)
Labor force: 2 8 million; *17?? agriculture, 87
industry. 247 other (military, police, civil service,
transportation workers. teachers. merchants,
construction workers); 407 of urban labor unem-
ployed
Organized labor: 1 7 r7 of labor force claimed.
General Union of Algerian Workers (U(>TA) is the
only labor organization and is subordinate to the
National Liberation front','196c64b92804f21ae64aa3db9a2f45688aa0835d8209123356f833117cc6b2de','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1f22696640b03e25475fe4962e3299445a664d07c7e0381609cc546ebd5da94',1975,'AD','Andorra','people-and-society',18,'Population: 19,000 (official estimate for 1 July
1969)
Nationality: noun — Aiidorran(s); adjective —
Andorran
Ethnic divisions: Catalan stock; 30% Andorrans,
61% Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French
and Castilian
Labor force: unorganized; largely shepherds and
farmers','88cdd8e90acbb9299763647fc3cf81f462c3635c7667a87ca5d1315c63cfe4ea','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('555935abd2bce4d811565631d8bf8600f9f2fb0f3e85e2defd61c851c7061402',1975,'AO','Angola','people-and-society',22,'Population: 6,099,000, average annual growth rate
1.6% (12/60-12/70)
Nationality: noun — Angolan(s); adjective —
Angolan
Ethnic divisions: 93% African. 5% Europeans, 1%
mestizos
Religion: about 84% nnimist, 12% Roman
Catholic, 4% Protestant
Language: Portuguese (official), many native
dialects
Literacy: lOfr-15%
Labor force: 2.6 million economically active
(196-1); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 80,000, average annual growth rutc
2.6% (4/60-4/70)
6
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
ANTIGUA/AliGENTINA
Nationality! noun — Antlguun(s); adjective —
Antiguan
Filmic divisions! almost entirely African Negro
Religion: Church of Fuglaml (predominant J, oilier
Protestant sects and some Homan Catholic
Language: English
Literacy! about 80b
Organized labor! 18,000','363b19ca663d1c506bcfa2cf005bef94991e1aed92b89822201080373dee42ad','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00c633ba696941eb808b7298aad9c8ade2b77e5f66365fce05566e5f3eab1757',1975,'AT','Austria','people-and-society',31,'Population: 7,575,000, average annual growth rate
0.4% (7/73-7/74)
Nationality: noun — Austrian(s); adjective—
Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian,
0.3% Slovene, O f % other
Religion: 85% Roman Catholic, 7% Protestant, 8%
none or other
10
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1 1)75
AUSTIUA
Language; German
Literacy: 98%
Labor force; 2,050,922 (1971); 1 8 agriculture
and forestry, 49%. industry ami crafts, 18% trade and
communications, 7% professions, 0% public service,
2% oilier; 2.1% registered unemployed; an estimated
2()(),()()() Austrians are employed in other European
countries; foreign laborers in Austria number more
than 200, 000 (1972); unemployment 2.1% (1972)
Organized labor: about 2/3 of wage and salary
workers ( 1971 )
Population: 205,000, average ar rural growth rate
3. Off (4/70-7/73)
12
Nationality: noun — Bahamian (sing., pi ); adjec-
tive— Bahamian
Ethnic divisions: 80ff Negro, 1 Off. white, I Off
mixed
Religion: Baptists 29ff, Church of England 23b'' ,
Roman Catholic 23b'' , smaller groups of other
Protestant. Greek Orthodox, and Jews
Language: English
Labor force: 69, 000 (1970); 25ff organized','7fb6dc4b684d676b15dff031b2e1a63bd891c0ca46ae2f2ba5b13177b7f6772a','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37593926c7f6a51df83cd11a87ecb305dab589e8fd579dcc6b3c729fa75839bf',1975,'BH','Bahrain','people-and-society',35,'Population: 240,000, average annual growth rate
2.8% (2/(35-4/71)
Nationality: noun — Hahrainl(s); adjective —
Bahraini
Ethnic divisions: 00% Arab, 7% Iranian, Pakistani,
and Indian. 3% other
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 00,301 (1971)','c0cdfc7003116875bf7b349150e4beff2919ae93153afbf405c18f1954131154','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebf17e93886b49cf5aa5e4441de11bbc8e503f8b57c9a90dd1801519bfc3b77f',1975,'BD','Bangladesh','people-and-society',40,'Population: 73,746,000, average annual growth rate
2.8% (current)
Nationality: noun — Bcngnlee(s); adjective —
Ethnic divisions: predominantly Bengali; fewer
than 1 million "Bihnris” and fewer than 1 million
t riba Is
Religion: about 83% Muslim, 16% Hindu; less
than 1% Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive un-
deremployment; over 80% of labor force is in
agriculture','9d40a958732451c52a8a9111b7aed5cf752997f0aa9966a45d05c5c190ffe8cc','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ff4f73c8127df4a5a7523d10ac0c59792ef25ef22e552eb22e2748193e5da59',1975,'BB','Barbados','people-and-society',44,'Population: 239,000 (official estimate for 1 July
1973)
15
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
llAtlHAI)OS/llU CIVM
July 11175
Nathmalil vi IM Mill II < i r I m f t j 1 1 1 1 ( % ) . adjective --
Hut I ifidtmi
Filmic divisions! NO1/ African, 1 7b mlsrd, 4b
European
Hellglom Anglican, Human Catholic, Methodist,
and Moravian
Language! Ktif''llsli
Literacy! over 90b
Labor form 07.000 ( HIT* I esl.) wage and salary
earners
Organized lahori 32b','71cc5c58ca0a744fd7d67f52af20bba2d968cb12dce81879bfa4c57c0801b038','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d46a13c54421331437fb5a97e37c2e8e937b01091fba6cdcabb757578231d57b',1975,'BE','Belgium','people-and-society',48,'Population: 9,792,000, average annual growth rate
0.2b (current)
l(i
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
!v ^proved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
IllK.ltM
Nationality: noun Belgian(s). adjective Belgian
Ethnic divisions! 3.V, llemmgs. lib'' Walloons.
1 2b mixed of other
Hclighm: ! >7 '' * Homan ( ’athnlie. 3b none or other
Iamguugc: Erench, Mcmish (Dutch). German, in
^ ilia 1 1 mm of eastern Belgium. divided along ethnic
lines
Literacy: 07 b
laibor fnrcc*i 10 million, approximate!* 93b is
found III llie following sectors- 32b’ manufacturing.
2l*i services, I fib* commerce. hanking. mid insurmice,
8b conslf iielion, 7.5b tr.mspnrtatinn mid communi-
cation. lb agriculture, forestry, mid fishing. I 2b
minimi, OHb pulilic utilities mid saiiitar* serving
( 1972); b. Ob unemploved. enrl\\ 107a
Organized labor: 48 *7 of Libor force (1000)
oovkhnment
Leg: I name: Kingdom of Belgium
Type: constitution.il monarchy
Capital: Brussels
Political subdivisions: 0 provinces
Legal system: civil law ssstem influenced by
English constitutional theory; constitution adopted
1831, since amended; judicial review of legislative
acts; legal education at I law schools, accepts
compulsory IGJ jurisdiction, with reservations
Branches: executive branch consists of King ami
cabinet; cabinet responsible to bicameral parliament;
independent judiciary; coalition governments are
usual
Government leader: Head of State, King
Bamlouin; Prime Minister Leo Tindrmam
Suffrage: universal over age 21
Elections: held 10 March 1074 (held at least once
every I years)
Political parties and leaders: Social Christian,
(''hades- Ferdinand Nothomb and Wilfred Martens,
■ o president'',, So* ltdisl. Andie ( «H 1 1*, and Wills < Lo s,
co presidents. Mill tl\\ and Pmgiess, Si -unlot p
|)esi (lamps, national president. Fibrin! Denim ruffe
and Pluralist Pmt\\, Holland Gllbl. pmlv president,
I lam tiplioue Democratic I root Walloon Balls
{Walloon nationalist ). I.eo Defosset, national
president , N olksuuie (Flemish Nationalist I, lingo
Scldil/. parts president. < ommtmM. I.onis \\ an (ant.
president of political bureau
Voting strength (1074 election)! 72 seats Social
(Inisli-in. 59 seats Soiiallst, 10 seals Libcrls and
Progress, 22 seats Volksiiiiie, 22 -cals Francophone
Democratic I rout Wallomi Balls . I seal'' ( ntntmmisl.
• I seals Democratic and Pluralist
Communists: 10,000 members (es| )
Other political or pressure groups: ClirMiun and
Socialist I fade Luious, tin Federation of Belginm
Industries, uuitiermis other associations representing
hankers, manufacturers, middle ( lass artisans, and the
legal and medical professions, two major organiza-
tions represent the cultural interests ol Mambas and
Wallonia
Member of: Hem lux. HI, Id'' ( Belgium Lux-
embourg I count nic Lnion). Council of Europe, E< !E.
ECOSOC. EC. EM A. I AO. IAEA. ICAO. 11 A. I ME.
NATO. OECD. Scalwds Cnmmiltrr. V N . CNESCO.
WEI1. WHO','15a04e0fee3426e1b8d916a52c74993bf33dbb436b57a1040d068e7ffc154ced','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('405acd22a447df55a021f590eca59a2283ed3a48d20509751a4be6c3647f78a5',1975,'BZ','Belize','people-and-society',53,'Population: 50, (MX), average annual growth rate
l.fitt (l/f>8-l/7l)
Nationality: noun— Berrnudan(s); adjective—
Bermudan
Ethnic divisions: approximately €53 rc African, 37b''
white
Religion: 47..V7 Church of England, 38.2^ other
Protestant, I0.2rr Catholic, 4. Iff other
Language: English
Literacy: virtually HMHr
Labor force: 2-1.855(1974)','bcac432f2d3c1bd0ca3417ccb58867a376a660b61471b0bde502c37080d253e5','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9374d1590e8448e4815072cfd857e7d6754087f7338fa65ce88e211ac61cf02',1975,'BT','Bhutan','people-and-society',55,'Population: 1,174,000, average annual growth rate
2.8b'' (current )
Nationality: noun- •Bhutanese (sing., pi );
adjective— Bhutanese
Ethnic divisions: 00% Bhotias, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamnistie Buddhism. 25% Bud-
dhist-influenced Hinduism
language: Bhotias speak various Tibetan dialects,
most widely spoken dialect is Dzongkha, the official
language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 800,000; 90% agriculture. 1%
industry; massive lack of skilled labor','b6d0acdbc5a38f4becec33f91dfa47aef174ac2dd0975e7c92e1cec4439272ca','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('774833fdb76123ad304be1ffb2d82362d5628d8d38f37d62f43519c1e5a2c8fb',1975,'IN','India','people-and-society',59,'Population: 5,272, 000, average annual growth rate
2.8ft (current)
Nationality: noun — Bolivia n(s): adjective —
Bolivian
Ethnic divisions: 50ft-75ft Indian, 20 ft -35ft
mestizo, 5ft- 15ft white
Heligbm: predominantly Unman Catholic; aclise
protestant minority, especialls Methodist
lamgimge: Spanish. Aymara, yurclma
Literacy: 35ft- I0f7
Ioihor force: 2 5 million ( 1972); 09, 1 *7 agriculture,
3.3ft mining, 9.0ft services and utilities, 8!7
mamifaeturing, I0f7 oilier
Organized labor: 1 50.0tK)-2(H),(HH). concentrated in
mining, industry, construction, and transportation
Population: 600,207.000 (including the Indian-
held part of disputed Jammu-Kashmir), average
annual growth rate 2.4% (current)
Nationality: noun— Indhm(s); adjective— Indian
Ethnic divisions: 72% Indo-Arynn, 25% Dravidlan,
3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh,
2.6% Christian, 0.7% Buddhist, 0.7% other
Language; 24 languages spoken by a million or
more persons each; numerous other languages and
dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of
30% of the people; English enjoys ‘‘associate** status
but is the most important language for national,
political, and commercial communication; Hindu-
stani, a popular variant of Ilindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 20%
(1971 census)
Labor force: about 184 million; 70% agriculture,
more than 10% unemployed end underemployed;
shortage of skilled labor is significant and
unemployment is rising
Organized labor: about 2.5% of total labor force','92db64b4401ee8b77b1d28726f407bff7046130d560c3ae4b1ba4be57c095cfd','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16e8bfce6d0ff5c76e17022a828090375447f37f5321b36381a8f8d6b5f11cba',1975,'BW','Botswana','people-and-society',61,'Population; <>77,(MX). average annual growth rate
2.4% (current)
Nationality: noun — Botswana (sing., pi ); adjec-
tive— Botswana
Ethnic divisions: 94% Iswami, 5% Bushmen, 1%
European
22
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
IIOrSWANA/HHA/U,
Religion: 8, V. nuimist. I.Vi ChtisMnn
I .OltgllllgCI A f 9 h 1 1 f I % speak Tswntlll Vermicular
Literacy: iiImiiiI 22fV In 1, 1 1 p.l f % 1 1 . about 32*7 in
Tswuiiu, less t (lit n l''» secondary school graduates
latbor lorm 385.000, inusl mr engaged in cattle
raising nml subsistence agileullmr, iiIhiiiI 51. 000 in
Internal cash economy, another 00,000 spend til least
0 to 1) months per year as v age earners in Smilli Alrlrti
(1071)
Organized labor: eight trade unions organized i 1 1 1
n lot ill Iiifdil Mf slii I ) of appmximalelv 11.000 ( 11)72 rst )','025fb2700c6022cdc7b07f851cbaab414c8e26f7afff50f69a4122983fce5420','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fb0a8a4e5a6cdc48e18b1ff27136f2345a61a9a8911c7cf47e2fba229a0b4b9',1975,'BR','Brazil','people-and-society',65,'Population: 107,013,000, average annual growth
rate 2.817 (current)
23
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
0
July 1975
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
lUtA/lt.
Nationality: mum Bra/ilianM, adjective
Brazilian
Filmic* divisions (»0\\ white, HO'', mixed. 8\\
Negro, and 2*V Indian (1960 est )
Bcligton: 93*7 Unman ( aitlmlic (nominal)
language: Portuguese
Literacy: 67*7 of llir population 15 years or older
(1070)
l-abor force t about HO million in 1970 (est), M.2*»
agriculture, livestock, forestry, ami fishing, 17 8*/
industrv, 15.3*7 services, transportation, and
communication. HD''i commerce*. I 8*7 social
activities. 3.9*7 public administration, a 1 f7 cither
Organized labor: about 50*7 of labor force; onlv
about 1.5 million pay dues
GOVKHNMENT
Legal name: Federative* Hcpuhlic of Brazil
Type: federal republic; military-hacked presiden-
tial regime since April 100 1
Capital: Brasilia
Political subdivisions: 21 states. I territories,
federal district (Brasilia)
Legal system: based on Latin code''s; dual system of
courts, state and federal; constitution adopted 1007
and extensively amended in 1909; lias not accepted
compulsory ICJ jurisdiction
Brandies: strong executive svith very hroad powers;
bicameral legislature (powers of the two bodies have
been sharply reduced); I Lilian Supreme Court
Government leader: President Ernesto Goisel
Suffrage: compulsory over age 18. except illiterates
and those stripped of their political rights;
approximately HO million registered voters in October
1070
Elections: President Medici s successor was chosen
by a 505-member electoral college, composed of the
members of Congress and delegates selected from the
state legislatures, on S5 January 1974 and took office
24
on 15 Man h 1071. (n isei was tlir* choice of Medici
ami lop mililatv chiefs
Voting strength: (November 1070 congressional
elections). 10'',’ AHENA.25*7 MI)B, 28 5''. blank and
void
Political parties and leaders! National Hcneual
Alliance (ABFNA). pm government Luis Vi.mna
lilho. president. Brazilian Ib’inoeralie Movement
(MI)B). opposition. tOisses (biliiiaraes, president
Communists: 0.000. 1,000 militants
Other political or pressure groups: excepting the
million, the Catholic Church is the onlv active
nationwide pressure group, however, divisions within
the Church often prevent it from speaking with one
voire- labor and student groups have almost no
Influence on the government
Member of: I AO. GATT. IADB. IAEA. IBBI).
ICAO, I MB. ILO. IMCO, IMF. MU. LAI TA. (MS.
Seabeds Committee. UN, UNESCO. CPC. WHO,
WMO
Population: 155.000. average annual growth rate
5 5r»* (H 7 1 -7/75)
Nationality: noun — Bnmeian(s). adjective —
Bruneian
Ethnic divisions: 52 ''7 Malays. 28''« Chinese, 1 5r7
indigenous tribes. 5 other
Religion: 00r< Muslim (Islam official religion); 8f7
Christian. 52 fV other (Buddhist and animist)
language: Malay and English official. (Tines**
Literacy: ■I5r*
I^ibor force: 52.155; 50, 5%’ agriculture; 52. 8*7
industry, manufacturing, and construction; 55.8*7
trade, transport, services; 2.95 other
Organized labor: 8.4*7 of labor force
Population: 8,74!,tM)0, average annual growth rate
0.7 T f (current)
Nationality: noun — Rulgarian(s); adjective —
Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks,
2.8% Gypsies, 2.5% Macedonians. 0.3% Armenians,
0.2/< Russians, 0.8%> other
Religion: regime promotes atheism; religious
background of population is 85% Bulgarian
Orthodox. 13% Muslim, 0.8% Jewish, 0.7% Roman
Catholic, 0.5%- Protestant, Gregorian- Armenian and
other
Language: Bulgarian; secondary languages closely
correspond to ethnic breakdown
Literacy: 95% (est.)
Labor forcer 4.8 million (July 1073); 32%
agriculture, 33% industry. 35% other
Population: 30,429,000, average annual growth
rate 2.3% (7/70-7/73)
Nationality: noun — Burman(s); adjective — Bur-
mese
Ethnic divisions: 72% Burinan, 7% Karen, 6%
Shan, 2% Kuchin, 2% Chin, 2% Chinese, o% Indian,
6% other
Religion: 85% Buddhist, 15% nnimist and other
Language: Burmese; minority ethnic groups have
their own languages
Literacy: 70% (official claim)
Labor force: 10 million; 67% agriculture, 13%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor
organizations have been disbanded, and government
is forming one central labor organization
Population: 3,777,000, average annual growth rate
2.4% (7/70-7/73)
Nationality: noun — Burundian(s); adjective—
Burundian
Ethnic divisions: Africans — 86% Mutu (Bantu),
13% Tutsi (Hamitic), 1% Twa (Pigmy); non-Africans
include (late 1968) 3,000 Europeans. 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10%
Protestant); rest mostly animist plus small number of
Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili,
and 6%> in French
tabor force: 1,865,471 (1970 cst.)
Organized labor: sole group is the Union of
Burundi Workers (UTB), membership about 30,000,
affiliated with government party','e785899aadac669471498dd97750994f2ffbd60c7e195adf1eaed6418f7d1082','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e92a6b961f6cb82b23bc1a32a99dc5b54a002c90996452b52132603e23e3bc29',1975,'KH','Cambodia','people-and-society',69,'Population: 7.054.000, average annual growth rate
2.217 (7/08-7/00)
Nationality: noun — Cambodian(s) or Khmer
(sing., pi.); adjective — Cambodian or Khmer
Ethnic divisions: 80rf Khmer (Cambodian), 517
Vietnamese. 517 Chinese, 317 other minorities
Religion: 1)517 Thcravada Buddhism. 5 17 various
other
language: Cambodian
Literacy: 5517 (est.)
30
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1117ft
CAMHODIA/CAMIMOON','924261bdea7eb2d3f4f63ed14e5231bc3eecbb5e6994b7e9d0af85091f8ad4a1','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('691bfbe84fd02bf68abe0c0c98b82eb51c33711621d13af84dc71ea16499238c',1975,'CM','Cameroon','people-and-society',73,'Population: 6,303.(XM), average annual growth rate
1.717 (7/6K-7/70)
Nationality: noun— Oumeroonian(s); adjeCtve —
Cameroonian
Ethnic divisions: about 200 tribes of widely
differing background; 3117 Cameroon Highlanders,
1917 Equatorial Bantu, 817 Northwestern Bantu, 1017
Fulani, 717 Eastern Nigritic, 1117 Kirdi, 1317 other
African, less than 117 non-African
Religion: about one-half animist, one-third
Christian; rest Muslim
language: English and French official. 24 major
African language groups
Literacy: South 40*7, North 1017
tabor force: most of population engaged in
subsistence agriculture and herding; 2(X),()(X) wage
earners (maximum) including 22,000 government
employees, 63,000 paid agricultural workers, 49,000 in
manufacturing
Organized labor: under 4517 of wage lalmr force','98a14d154c0d1d9424968f1ad162d0d1ba4dba0a190c15cdec365c3acc44b5d8','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537ccea0b243f04c901586d4830593382b0c25daf4d3d45a4aadf727c8f9354e',1975,'CF','Central African Republic','people-and-society',80,'Population! 1,787,000, average annual growth fate
2.2ft (7/07-7/71)
Nationality: noun -■-< lent ml Africun(s); adjective—
Central African
Etlmic divisions! approximately 80 ethnic groups,
the majority ol which have related ethnic and
linguistic characteristics; llanda (82ft) and Hava-
Mandjla (20ft) ate largest single groups; 0,500
Europeans, oi whom 0,000 are French ami majority of
the rest Portuguese
Religion: 40ft Protestant, 28ft Catholic, 27ft
animist, 5ft Muslim; animistic beliefs and practices
strongly influence the Christian majority
language: French official; Sanglm, the lingua
franea and unofficial national language
Litcrucy: estimated at 5ft- 10ft
I^ahor force: about half the population economi-
cally active, 80ft of whom are in agriculture;
approximately 04.000 salaried workers
Orguni/cd labor: I ft of labor force','4eb78d6b6cd712d2f832f5e427a42edf77a7c14bc6095c05aafb062f6611c358','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6303a8880bb830cf9f3e079787debedff4faefa9e6dca6a6d47cd925813b46c3',1975,'TD','Chad','people-and-society',84,'Population: *1,028,000, average annual gin wilt rate
25 (7/71-7/72)
Nationality: noun — ( !hadian(s); adjective —
Chadian
Ethnic divisions: over 210 tribes representing 12
major ethnic groups — Muslims (Arabs, Toubnu,
Fiilani. Kotoko. Itausa, Kanrmlmii, Haguirmi.
Rouluki, ami Wadai) in the north and center and non-
Muslims (Sj. ra, Mayo-Krhbi. and ( lint ri ) in the south;
some 150,000 nonindigenous. 5.000 of them French
Religion: about half Muslim. 55 Christian,
remainder animist
language: French official; Chadian Arabic is
lingua franca in north, Sara and Sanho in smith
Literacy: estimated 55-105
Labor force: only 555 of population in
economically active group, of which 905 are engaged
in unpaid subsistence farming, herding, and fishing;
•17.000 wage earners in industry and civil service
Organized labor: about 205 of wage labor force','a402f6b1376c07c5877f52dda3fd798d960c61784aa9798770ba52ac8b236349','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cb51b9261f90d9b0883684ccc14573fb7e90bf2d19c43032f26d26aaea65f46',1975,'CL','Chile','people-and-society',89,'Population: 012, 012, (KK), average annual growth
rate 2.1% (current)
Nationality} noun— -Chinese (slug., pi.); adjec-
tive— Chinese
Ethnic divisions! 01% Man Chinese; 0% Chtiang,
Ulglmr, i I ui , Yi. Tibetan. Mian. Manchu. Mongol,
I’u-I, Korean, and nutnernus lesser nationalities
Religion: most people, even before 1 010. have been
pragmatic and eclectic, not seriously religions; most
important elements of religion are Confucianism,
Taoism, Buddhism, ancestor worship; about 2%-8%
Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also
Cantonese, Wu, I''ukieuese, Amoy, Hsiang, Kali,
llnkka dialects), and minority languages (see ethnic
divisions above)
Literacy: at least 25%
Labor force: 8 85 million (mid-IOWi); 85%
agriculture. 15% other; shortage of skilled labor
(managerial, technical, mechanics, He.); surplus of
unskilled labor
Population: 15,982,000 (excluding the population
nf Qiienmy and Matsu Islands and foreigners),
average annual growth rate 1.8*7 (7/75*7/74)
Nationality: noun — Chinese (sing., pi ); adjec-
tive— Chinese
Ethnic divisions: 84 ft Taiwanese, 14*7 mainland
Chinese, 2ft aborigines
Religion: 95*7 mixture of Buddhism, Confucian-
ism, and Taoism; 1.5ft Christian; 2.5ft other
Language: Chinese Mandarin (official language),
also Taiwanese and Hakka dialect
Literacy: about 00ft
Labor force: 4.9 million; 58ft primary industry
(agriculture), 82.1ft secondary industry (including
manufacturing, mining, construction), 84.9ft tertiary
industry (including commerce and services) 1972
Organized labor: about 12ft of 1972 labor force
(government controlled)
39
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
CHINA • HI.I''VHUC OI/COl.OMHIA
July 11)75
coveiinment
Legal name: llcpohllr of Chinn
TypiM republic; our party presidential regime
Capital: Taipei
Political %til>cli v I % i on % t Hi counties. 1 cities, 1
special municipality (TitipH)
Legal system: based on civil law system,
constitution adopted 1017, (intended IlMiO to pennil
( ,‘hlang Kui-sliek to Ite irelected, and amended 11)72
to permit President to restructure certain government
organs; accepts compulsory H ''] jurisdiction, with
reservations
Branches: 5 Independent launches (executive,
legislative, judicial, plus traditional ( Chinese functions
of examination and control), dominated by executive
branch; President and Vice President elected by
National Assembly
Covcrnincnt leaders: President Yen Chia-kan;
Premier Chhiug Ching*kuu
Suffrage: universal over age 20
Elections: national level — legislative yuan every 0
years Imt no general election held since 1948 idection
on mainland (partial election for Taiwan province
representatives December 11)00 and December 1072);
lond level — provincial assembly, county and
municipal executives every I years; county and
municipal assemblies every I years
Political parties and leaders: Kuumintaiig. or
National Party, led by Chairman Chians Cliing-kuo,
has rm real opposition; 2 insignificant parties are
Democratic Socialist Party, Young China Parly
Voting strength (1072 provincial assembly
election): 58 scats Kuomintang, 1*1 scats in-
dependents
Ollier political or pressure groups: none
Member of: expelled from U.N. (General Assembly
and Securitv Council on 25 October 1071 and
withdrew on same date from other charter-designated
subsidiary organs; attempting to retain membership in
international financial institutions','0d501f17e44c44a1fc7493b74cb2622897ffcbd976ee9f334969702bbc4bae5b','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14e286b757f6ede52e9a27f8a0bfd467b36c7ccb1aedb1b6be4289afbe4e5028',1975,'CO','Colombia','people-and-society',91,'Population: 22,217,000. average annual growth
rale 0.2//- (current)
Nationality) rimm — ( lolumhianfs); adjective—
( ‘nlomhian
Ethnic divisions! 58''/ mestizo, 20% Caucasian.
14%'' mulatto, 1% Negro, 0% mixed Negro-Indinn, 1%
Indian
Religion: 05% Homan Catholic
Language: Spanish
Literacy: 17 %• of population over 15 years old
I^ahor force: 5.0 million (1000); 17% agriculture,
15% manufacturing, 18% services. 0%'' commerce,
18% other (1001)
Organized labor: 18%'' of labor force (1008)
Population: 2f 1,000, average annual growth rate
2.0% (0/06-0/72)
Nationality: noun — Comornn(s); adjective —
Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural','ae9437255e88f3a416ab23e4bee06d32d838a3667d0213eee88ff5186fa2c7ce','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1f1a2f3263f72ab9c1026d901c6855c9726b701ff8ae4b0932dca8a361a48b1',1975,'CG','Congo','people-and-society',95,'Population: 1,310,000, average annual growth rate
2.5% (current)
Nationality: noun — Congolese (sing., pi.); ndjee-
live — Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided
into some 75 tribes, almost all Bantu; most important
ethnic groups are Kongo (-18%-) in south, Teke (17%)
in center, M''Bochi (12% ) and Saugha (20% ) in north;
about 8,500 Europeans, mostly French
Religion: about half aulmlst, half nominally
Christian, less than I %• Muslim
language: French official, many African lan-
guages with Ungala and Kikongo most widely used
Literacy: about 20%
laibor force: about 40% of population economi-
cally active, most engaged in subsistence agriculture;
70,100 wage earners; ‘10,000*00,000 unemployed
Organized labor: 10% of total labor lorce (1005
est.)','c462350a108258345f4a1f70d8ef7a4176ab0804d45e401164bf83484809c6e9','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f4aebe507bcf872a04309db67e8b8eec1c770396fdf8bec52c367f6e9d9949c',1975,'CK','Cook Islands','people-and-society',99,'Population: 21,000, official estimate for 30
September 1073
Nationality: noun — Cook Islander(s); adjective —
Cook Islander
Ethnic divisions: 81.3% Polynesian (full blood),
7.7%> Polynesian and European, 7.7% Polynesian and
other, 2.4% European, 0.9% other
Religion: Christian, majority of populace members
of Cook Islands Christian Church','fd24a6beb10f201f81eac3a9ac3070b535be12e7b3bec5c22bb0718404799cec','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d5ba9621578dac1ef591d669bbafcef0e2f1c98a050012b5d1c629058deaee4',1975,'CR','Costa Rica','people-and-society',103,'Population: 1,968,000, average annual growth rate
2.55 (current)
(St* iff# nut mtp II)
Nationality: noun— Costa Hlcan(s); adjective —
Costa Rican
Ethnic divisions: 985 white (including mestizo).
25 Negro
Religion: 955 Roman Catholic
Language: Spanish
Literacy: about 855
I«ahor force: 607,000 (1973); 40.35 agriculture;
13.25 manufacturing; 1 1 5 commerce; 85 construc-
tion, transportation, and communications; 21.55
other; shortage of skilled labor (1968)
Organized labor: about 1 1.55 of labor force','12ac490ac5f176e34b7d47ebe3844f630c8155eda6eddd275d0ea8dc67ce7059','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f41cfd3d8c1456c8a364f255433cfac0a84e75f105c669b5466eee8b88fdffbc',1975,'CU','Cuba','people-and-society',107,'Population: 9,252,000, average annual growth rate
1.8ft (current)
Nationality: noun— Cuban(s); adjective— Cuban
Ethnic divisions: 51ft mulatto, 37ft white, lift
Negro. I ft Chinese
Religion: at least 85ft nominally Roman Catholic
before Castro assumed power
Language: Spanish
Literacy: about 96ft
Labor force: 2.36 million; 34ft agriculture. 17ft
industry, 6ft construction, 6ft transportation, 29ft
services, 8ft unemployed and underemployed
Organized labor: 46ft of total force','a343dc835fc30403569a47046be7581ce7562cdc06964eaa7c86287e97151541','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66b277ed1e18fe17c90be2434e69bede38f1e0a39835953f869ec9ce68ef2c30',1975,'CY','Cyprus','people-and-society',113,'Population: 14,804,000. average annual growth
rate 0.8% (current)
Nationality: noun— ( !/echoslovak(s); adjective —
( 1/echoslovak
Ethnic divisions: 65.0% Czechs, 29. 2‘V Slovaks.
1.0% Magyars, 0.6%'' Germans, 0.5%'' Foies, 0.1%''
Ukrainians, 0.3% others (Jews, Gypsies)
Religion: 77% Roman Gatbolic, 20% Protestant.
2ft Orthodox, 1% other
language: Czech, Slovak, Hungarian
Literacy: almost complete
I>abor force: 7.1 million; 18%'' agriculture, 37%
industry, 11% services. 34ft construction, com-
munications and others
Population: 3,105,000. average annual growth rate
2.8% (8/72-8/74)
Nationality: noun- -Dahorncan(s); adjective —
Dahomcan
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
DAHOMEY /DEN MAW K
Mimic divisions: 00% Africans (42 ethnic groups,
most Important bring Foil, Ad)a. Yoruba, Rnrilm),
5,500 Europeans
Religion: 12% Muslim, 8% (Christian, 80% anlmlst
Language: French official; Fun and Yoruba most
common vernaculars in south, at least 0 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in
agriculture; 15% civil service, artisans, and Industry
Organized labor: approximately 75% of wage
earners, divided among two major and several minor
unions','9bf98e757606a444ed0c82c726b5b487ade100df8eb8d3d398a89918428d4529','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ab4f85a017d51a72aba5d8a8a777f9ab72baeedb9ef6e7e839ceb6bfd546ba1',1975,'DK','Denmark','people-and-society',115,'Population: 5, 07*1, 000, average annual growth rate
0.1% (current)
Nationality: noun— Danc(s); adjective— Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran. 3% other
Protestant and Roman Catholic, 1% other
Language: Danish; small German-speaking
minority
Literacy: 99%
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing. 26.6% manufacturing, 8.3% construction,
15.7% commerce, 6.8% transportation, 5.6% services,
25.7% government, 1.8% other; 6.3% of registered
labor force unemployed (September 1974)
Organized labor: 65% of labor force
Population: 2,000 (preliminary total from the
census of 3 December 1072)
Nationality: noun — Falkland Islander(s); adjec-
tive— Falkland Island
Ethnic divisions: almost totally Hritixh
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age I I
Luhor force: 1,100 (est. ); over 95 tV (est.) in
agriculture, mostly sheepherding','f01c4ec227cd004dfdc0c7774a1a7f59300dada3193bb67c8056502ad6f2bb54','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff7a24fd909955b841c668645ce4165837ea647a3f5161bdbdcb3403c81227b5',1975,'DM','Dominica','people-and-society',119,'Population: 76.0(H), average annual growth rate
1.6% (4/60-4/70)
Nationality: noun — l)oininieun(s); adjective —
Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Human Catholic, Church of England,
Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23.0(H); about 50% in agriculture
Organized labor: 25% of the labor force','15c4049a2b87303b12195cd82457f27d3c314a870923d3dadcdb77d0786c0d8e','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6426ac0ca1b308907da6fc524746210acf82b502b2dd0d2f4d0a78e68acf5bb6',1975,'EC','Ecuador','people-and-society',123,'Population: 6,705,000 (excluding nomadic Indian
tribes), average annual growth rate 2.0ft (I i/02-6/74)
Nationality: noun— Kcuadoroan(s); adjective—
Ecuadorean
Ethnic divisions: 40ft mestizo, 40ft Indian, 10ft
white, 5ft Negro, 5ft Oriental and other
Religion: 95ft Roman Catholic (majority
nonpracticing)
55
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1975
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
EQVAIWR
language: Spanish, Qurchuu
Literacy i 57%
Labor force: 2 million, of which 50% agriculture,
15% manufacturing, -1% construction, 7% commerce,
■!% public lUlministration, 10%. otlier services and
activities
Organized labor: less than 15% of labor force','92371b304f6901f1315ebef83c5587fe9ac142292af0e0d35e30084c914370ca','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53b6a66303d710b4561142696c336385884bc4b70b0726f2231988939f5bf2ef',1975,'EG','Egypt','people-and-society',127,'Population: 37,335,000. average annual growth
rate 2.4% (current)
Nationality: noun -Kgyptife »); adjective —
Egyptian or United Arab Republic
Ethnic divisions: 90% Eastern llamitic stock; 10%
Greek, Italian, Syro- Lebanese
Religion: (official estimate) 94% Muslim, 0% (''opt
and other
Language: Arabic official, English and French
widely understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 in’llion; 45% to 50%
agriculture, 10% industry, 10% trade and finance,
30% services and other; serious shortage of skilled
labor
Organized labor: 1 to 3 million','7cbf779ca36ddfc671c7ce2b3f2067b18c32470668e7b3363d3ce7bd3f1a01ea','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8525784ec17b49d6c25b763c49bc9939c3310b1f798b2852f020fead2a0dcb7',1975,'SV','El Salvador','people-and-society',131,'Population! 1,100,000, average annual growth raV.''
5.0'';. (7/75-7/7''i)
Nationality! noiiti Salvadoran(s); ad)eclive —
Salvadoran
Ethnic divisions! 84 !7 -88 ft- mestizo; Indian and
white ininorilies, Oft'' -8 ft each
Religions predominantly Roman Catholic,
probably 07ft -98ft
lainguagci Spanish
Literacy! 50 ''V ol population 10 years of age and
over (1975 esl. )
Lihor force! 1,595,000 (esl. 1975); 57 S’ agricnl-
tore, I I ft servicer. I 1 ft manufaet uring, 0ft
eominerce, 9ft oilier; shortage of skilled Li !>or and
large pool of unskilled labor, but manpower training
programs improving situation
Organized labor: 5.5ft of total labor force, 0.0ft of
uonagriculhiru! labor b :ce (1972 est.)','bad089652c88151b44c41a14dac3523ecfc3e2b794b7a8ebd6d48578176ec171','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53db4e32c38123d7219812ca9c4a03021da3352b43ee8366cb4ab2f0a9191ebf',1975,'ET','Ethiopia','people-and-society',138,'Population: 27,948,000. average annual growth
rate 2.6% (7/73-7/74)
60
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
i.ruioriA
(Sh rwffrmr* mtf VI/
Nationality: noun— Fthiopiun(s); adjective —
Ethiopian
Ethnic divisions: C •alia 40%'', Ainlumi am! Tig mi
32%, Sidamo 9%, Shankella 0%, Somali 6%, Afar 4%''-,
Cnrage 2%, other I %
Religion: 35%-40% Ethiopian Orthodox, 40%-45%*
Muslims, 1 5% -2()%- aniinist, 5% other
Language: Ainhuric official; many local languages
and dialects; English major foreign language taught
in schools
Literacy: about 5%
Labor force: 00% agriculture'' and animal
husbandry; 10% government, military, ami qnasi-
Population: 40,000, average annual growth rate
0.9% (4/66-11/70)
Nationality: noun — Faerocse (sing., pi.); adjec-
tive— Faerocse
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeioese (derived from Old Norse),
Danish
Literacy: 90%
I .ah or force: 15,000; largely engaged in fishing,
manufacturing, transportation, and commerce','177ba9cd4e683fe51dffa2e5df5cc7e67ac8a9b5f50703b94e28b3cc61bdd4cd','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('914b1de5bc4c8fbc0ab80c83df821873910ff7c367e1807bddc4504ee192a519',1975,'FJ','Fiji','people-and-society',142,'Population: 572,000, average annual growth rate
1.8% (7/72-7/73)
Nationality: noun — Fijian(s); adjective — Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8%
European, Chinese and others
Religion: Fijians mainly Christian. Indians are
Hindu with a Muslim minority
Language: English and Fijian (official), Hindu-
stani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force
organized into 22 unions; unions organized along lines
of work, breakdown by ethnic origin causes further
fragmentation','292c2de110e1a65e8ca30841b015744db3728b78f7a69d0dc17c3fde2ede9cd5','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c1d3808b7ed9046f94f52304f61f6efef086dac6e1c8c32f2d1d3f85190317',1975,'FI','Finland','people-and-society',146,'Population: 4,701.000, average annual growth rate
0.4% (1/73-1/74)
Nationality: noun — Finn(s); adjective — Finnish
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek
Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%. Swedish 7%; small I^app-
and Russian-speaking minorities
Literacy: 99%
Labor force: 2,2 million; 10.0% agriculture,
forestry, and fishing, 29. 4% mining and manufactur-
ing, 8.4% construction, 15.4% commerce, 9,8%
transportation and communications, 4.0% banking
and finance, 20,1% services; 1.8% unemployed
Organized labor: 90% of labor force','b6d36c51facdf0d96f10c89ab22dbe6c2533eac2cb854fc92eeeff3add52eeef','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6368c277d79e9575e4a1dc615ef59e1ba5ce908b52a84ab1980566e5ae754c46',1975,'FR','France','people-and-society',149,'Population: 53,038,000, average annual growth
rate 0.9% (7/69-7/78)
Nationality: noun — Frenchman (men); adjective
French
Ethnic divisions: 85% Celtic; remainder Latin,
Germanic, Slav, Basque
66
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
ihanci:
Religion: 83% Catholic, 2% IVoteshmt, I %< J i* wish.
\\% Muslim (North African workers), 13% mmffiliutrd
Language: French ''( 100% of population); rapidly
declining regional patois — Provencal, P''clon,
Germanic, Corsican. Catalan, Basque, Flemish
Literacy: 07%
laihor force: 21,900,000 (esl. In October 1071);
■17%'' services, 30% industry, 1 2 % agriculture, 2%
unemployed
Organized labor: 17% of labor force, 28,1%. of
salaried labor fence
GOVEHNMENT
Legal name: French Republic
Type: republic, with president having wide* powers
Capital: Paris
Political subdivisions: 05 metropolitan depart-
ments, 21 regional economic districts
Legal system: civil law system with indigenous
concepts; new constitution adopted 1058, amended
concerning election of President in 1002; judicial
review of administrative hut not legislative acts; legal
education at over 25 schools of law
Branches: president ially appointed Prime Minister
heads Council of Ministers, which is formally
responsible to National Assembly; bicameral
legislature — National Assembly (100 members),
Senate (283 members) restricted to a delaying action;
judiciary independent in principle
Government leader: President Valery Giseard
d’Estuing
Suffrage: universal over age 18; not compulsory
Elections: National Assembly — every 5 years, last
election March 1973, direct universal suffrage, 2
ballots; Senate — indirect collegiate system for 0
years, renewable by one-third every 3 years; President
— direct, universal suffrage every 7 years, 2 ballots,
last election May 197*1
Political parties and leaders: Union of Democrats
for the Republic (UDR); Independent Republicans
(IR), Valery Giseard dEstaing; Communist (PCF),
George Marchais; Progress and Modern Democracy
(PDM), J act pies Duhamel; Left Radical Party, Robert
Fabrc; Center Democratic Party, Jean Lecanuet;
Radical Socialists and Reformers, Jean Jacques
Servais Shreiber; Socialist Party, Francois Mitterrand;
Unified Socialist Party (PSU), Michel Vlousel
Voting strength (first ballot, 1974 cdcction); 43.2%»
Communist Socialist Alliance, 32. 6% IR, 15.1% UDR.
9.1% other
Communists: 250,000-300, (100 (est.); Communist
voters, 5 million average
Other political or pressure groups: Communist-
controlled labor union (Confederation Generalc du
Travail) nearly 1,500,000 members (est.), National
Connell of Fiencli Employers (Consell National du
Pntrount Franeais*— ( INPF or Patronat)
Member of: Council of Europe, F.O, FAO, IAEA,
IBM). ICAO, IIIR. ILO. 1MCO. IMF. ITU, NATO
(signatory), OECD, SraOcds Committee, SEATO,
South Pacific Commission, U.N., UNESCO, UPU,
WEU, WHO, WMO','4e6da99a95c76ab2ecabe6e1c514d8fe3a5d3204aa7f99416ed507bd3908620a','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b9862eedbc2291bc8bf247337edbf6f010cee5970ab56d1e15106166fd95edb',1975,'GF','French Guiana','people-and-society',152,'Population: 55,000, average annual growth rate
2.4ft (7/68-7/73)
68
Nationality: noun— French Guianese (sing., pi );
adjective—* French Guiana
Ethnic divisions: 05ft Negro or mulatto, 5ft
Caucasian, 10,000 East Indian, Chinese
Religion: predominantly Homan Catholic
language: French
Literacy: 73ft
I*ahor force: 17,012 (1967 census); services 40ft.
emstruninu 21ft, agriculture 18ft, industry 8ft.
transportation -Ift; information on unemployment
unavailable
Organized labor: 7ft of labor force
Population: 120.000 official estimate for I July
1973
Nationality: noun — French Polynesian(s), adjec-
tive— French Polynesian
Ethnic divisions: 78?,'' Polynesian, 12?; Chinese.
6?r local French, 4% metropolitan French
Religion: mainly Christian; 55?,'' Protestant, 32?,''
Catholic
Population: 125.000 (official estimate for I July
1907)
Nationality: noun— Afar(s), Issa(s); adjective—
Afars, Issas
Ethnic divisions: 59,350 Somalis (large number of
the Somalis arc temporary immigrants from Somalia,
not citizens of territory), 53,050 Afars, 0,000 Arabs,
7,000 French (inclusive of French military forces)
Religion: 94% Muslim. 0%) Christian
Language: Somali, Afar. French, Arabic, all widely
used
Literacy: about 5%
Labor force: a small number of semiskilled laborers
at port
Organized labor: some 3,000 railway workers
organized','3d125e8a9b105cf23c7c35351c9f1e1a224ae99d80533ebd877dbc9b14c08721','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3302fa8fd93fe69954058233593ae1203a3db14794653ac618a9006a74ee2694',1975,'GM','Gambia','people-and-society',159,'Population: 523,<HK), average annual growth rate
2.517 (7/08-7/74)
Nationality: noun — Cambian(s); adjective —
Camhian
Ethnic divisions: over 9917 Africans (Mali like
40.817, Fulani 13.517, Wolof 12.917. remainder made
up of several smaller groups), fewer than 1 17
Europeans and Lebanese
Religion: 8517 Muslim. 1517 animist and Christian
Language: English official; Malinkc and Wolof
most wiuelv used vernaculars
Literacy: about 1017
Labor force: approx. 165,000, mostly engaged in
subsistence farming; abo.it 15.0(H) are wage earners
(government, trade, services)
Organized labor: 2517 to 3017 of wage labor force
at most
Population: 16,885,000 (including East Berlin),
average annual growth rate -0.2ft (current)
Nationality: noun— German(s); adjective— Ger-
man
Ethnic divisions: 99.7ft German. .3ft Slavic and
other
Religion: ,53ft Protestant, 8ft Roman Catholic,
39ft uuaffiliated or other; less than 5ft of Protestants
and about 25ft of Roman Catholics actively
participate
Language: German, small Sorb (West Slavic)
minority
Literacy: 99ft
Labor force: 8.2 million; 34.1ft industry; 4.7ft
handicrafts; 6.8ft construction; 11.9ft agriculture;
6.8ft transport and communications; 10. 1 ft
commerce; 16.8ft services; 2.5ft other
Organized labor: 87.7ft of total labor force
Population: 02,155,000 (including West Berlin),
average annual growth rate 0.2 ft (current)
Nationality: noun — Cerrnanfs); adjective — Ger-
man
Ethnic divisions: 9957 Germanic, 157 other
Religion: 4957 Protestant, ‘1*1.057 Roman Catholic,
0.457 other
Language: German
Literacy: 9997
Labor force: 26.7 million; 44. 1 % in manufacturing
and construction, 15.297 services, 12.897 commerce,
8.25c government, 7.257 agricultuie. 5.457 com-
munication and transportation, 157 mining; 2.057
average unemployed as of 1974, excluding self
employed
Organized labor: 31 57 of total labor force; 37.557 of
wage and salary earners','d091265c6ec0d46a2a9c5d91d6a4d06f6bbd1a53a424c90640b1527622fbb046','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5af2d1f5b870a3240494d22ce7bbcc6e9d52f8dad321f9d4ac1d544d55142bd8',1975,'GH','Ghana','people-and-society',163,'Population: 9,810,000, average annual growth rate
2.6% (7/71-7/72)
Nationality: noun — Ghanaian(s); adjective —
Ghanaian
Ethnic divisions: 99.8% Negroid African (major
tribes Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12%
Muslim
Language: English official; African languages
include Akan 44%, Mole-Dagbani 16%, Ewe 13%,
and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and
fishing, 16.8% industry, 15.2% sales and clerical, 4.1 %
services, transportation, and communications, 2.9%
professional; 400,000 unemployed
76
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July i Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
UIIANA/GlimALTAH
Organized labors 350,000 or approximately 10% of
labor force','131a0c4f96c785e961fba0e0e6e6c8cab41962860ab4d4333c4477989d95c44b','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ce7fe7182d91ce395b86570fbacc0cb6baec88cfb161d871cf510b8e364c6f8',1975,'GI','Gibraltar','people-and-society',167,'Population: 50,000 (official estiinnle lor I July
1975)
Nationality: noun — CibrultHrinn(s); adjective—
Ethnic divisions: mostly Italian, English. Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman (Catholic
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian also
spoken; English used in the schools and for all official
purposes
Literacy: illiteracy is negligible
Labor force: approx. 1 ‘1,800, including non-
Gibraltarian laborers
Organized labor: over 0,000','cc6ad6cc8862892d4cf47c8529e2fad2967219698a1a57ff3ebe235fa80de132','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a589d4fce1b7f65e8a590d28c34a3a03e60025aef0f00188fde1786384fcbf92',1975,'NL','Netherlands','people-and-society',172,'copulation: 66,000, average annual growth rate
2.5% (7/63-7/73)
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Ju^fiftroved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
ciuiEHT and i.i.ua: isi.ANDs/ani i.ci:
Pacific Ocean
uNinrtv
RfAUS p
[T^ss> s
Myw JaNFA v Vv
A ^
••.;“~fllL0EnT ANO^
'' ELLICE ISLANDS
J\\
AU8TI1AUA V
** FIJI
ISLANDS
fS*9 tifut/Ht m*/i Villi
Nationality: noun— Gilbertese, Kills Islunder(s) or
(Jilbcrl and Kills Islamlcr(s); adjective— Gilbertese,
Ellis Islander, or Gilbert and Kills Islander
Ethnic divisions: 83.9% Mlcronesian, 13.9%
Polynesian, 0.9% European. 0.1%. Chinese. 1.2%
mixed and other races
Religion: mainly Christian; 55% Protestants, *12%
Catholics
Literacy: less than 50%
Population: 13,634,000, uverage annual growth
rate 0.7% (current)
145
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
NE Til Eli LANDS
July 1075
Nationality! noun— Netherlnndcr(s); mljectlvo— •
Ethnic divisions! 00% Dutch, 1% Indonesian and
other
Religion: 41% Protestant, 40% Roman Catholic,
10% unafliliated
language! Dutch
Literacy! 08%
Labor ft :c! 4,7 million; 30% manufacturing, 24%
services, 10% commerce, 10% agriculture, 0%
construction, 7% transportation and communications,
4% other; average unemployment rate 3% (Jan. -Aug.
1073); no shoituge of skilled labor but shortage of
semi-skilled labor; 129,000 unfilled vacancies reported
by employers in January 1071
Organized labor! 33% of labor force
Population: 240,000, average unnual growth rate
1.6% (1/71-1/73)
Nationality: noun — Netherlands Antillean(s);
adjective — Netherlands Antillean
Ethnic divisions: 85% largely mixed Negro stock
except on Aruba where 12% Negro and approx. 55%
mixed Curib Indian and European; rest European
with some Chinese, especially on Arubu
Religion* predominantly Roman Catholic; sizable
Protestant, smaller Jewish minorities
Language* officially Dutch; predominantly
English; colloquial "pnplumcnto," a Spanish-
Portugucse-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry,
21% unemployed, 8% construction, 41% government
and services, 8% other
Organized labor: upprox. 15% of labor force','60a66286f1ad317a6c19e63ad0318a8964c6f531e1c8f786cbebe04d7a84f7ec','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('309e7ae7cd7fb33f65ef751b85134221b494712808c9377b5a1f244cf2c158ad',1975,'GR','Greece','people-and-society',175,'Population: 9,094,000, average annual growth rate
0 % (7/70-7/73)
nationality: noun— Greek(s); adjective— Greek
Ethnic divisions: 96% Greek, 2% Turkish, 1%
Albanian, 1 % other
Religion: 97% Greek Orthodox, 2.5% Muslim.
0.5% other
Language: Greek; English and French widely
understood
Literacy: males about 9^%- fcmiJes about 73%;
total about 82%
Labor force: 3.8uC,P0() (19C9 cot.); ,50% ^ricu)
lure. 15% industry, 9% trade, L6% other; i. nphr, .
July 11)75
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
ciu.iia:
mrnl mid underemployment, 20% (olid In till fields;
shortage of skilled labor in iionagricultuml sectors
uggravnted by large-scale emigration
Organized labor: I ( ) r’/ of labor force
COVEIINMENT
Legal name? Hellenic Republic
Iypei presidential parliamentary government;
monarchy rejected by referendum December 8, 1071
Capital! Athens
Political subdivisions: 52 departments (nomoi)
constitute basic administrative units for country; each
nonius headed by officials appointed by central
government and policy and programs tend to be
formulated by central ministries; degree of flexibility
each nonius may have in altering or avoiding
programs imposed by Athens depends upon tradition
( I hessaloniki and other areas exercise considerable
traditional autonomy in local administrative
decisions) and influence which prominent local
leaders and citizens may exercise vis-a-vis key figures
in central government
Legal system: new constitution being debated by
Parliament
Branches: executive consisting of a President (to be
elected by Parliament) and a Prime Minister and
cabinet; legislative comprising the 300-member
Parliament; independent judiciary
Government leaders: provisional President
Michael Stassinopoulis; Prime Minister Constantine
Karamanlis
Suffrage: universal age 21 and over
Elections: every I years; latest November 17, 1971
Political parties and leaders: Center Union-New
Forces, George Muvros; New Democracy, Constan-
tine Karamanlis; New Democratic Union, Petros
Garoufalias; Panhellenie Socialist Movement,
Andreas Papandrcau; Communist Party — Exterior,
Harilaos Florukis; Communist Party — Interior,
Manila mhos Drakopoulos; and the United Demo-
cratic Left, Ilias I lion — in disarray since the election
Voting strength: New Democracy, 216 scats;
Center Union-New Forces, 01 scats; Panhellenie
Socialist Moment, 15 seats; Left, 8 scats
Communis;..: an estimated 25,000-30,000 members
and sympathizers
Member of: EC (associate member), FAO, FUND,
IAEA, IBRD, ICAO, IDA. IFC, I MB. ILO, IMCO,
1 1 U, NATO, OECD, Scabcds Committee, U.N.,
UNESCO, UPU, WHO, WMO','c365b5dc686202000e68ba4c7a0be953e6b93b64f75827f5031b924e69969fe8','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0247c4ecc1d2b1d0e7ce19ef19d68abe0b23303db344c5f663c29f0eb4d4c610',1975,'GL','Greenland','people-and-society',178,'Population: 51,000, average annual growth rate
1.6% (1/72-1/74)
Nationality: noun — Grccnlander(s); adjective —
Ethnic divisions: 86% Greenlander (Eskimos and
Greenland-horn whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Libor force: 12,000; largely engaged in fishing and
sheep breeding','7060a77b5cec44e46fbafea15dbd3e447975633f769248999b9fab905a2f0e25','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc9b6b50840de577eda2a5cd1bbca3a4946b48386029d26272dee861025a4b80',1975,'GD','Grenada','people-and-society',182,'Population: 98,000, average annual growth rate
0.6% (7/60-4/70)
Nationality: noun— Grcnadian(s); adjective—
Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant
sects; Roman Catholic
Language: English; sonic French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force
82
Population: 052,000, average annual growth rate
1.5% (7/72-7/70)
Nationality: noun — Guadeloupian(s); adjective —','068a664f2b78e6e21348b3526e7cbc88f28e11385c9efa55c8d69c4578b5b694','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80d0d6c664d259fa10bd6d089f199252268e3aa608137c593268a417f0800da9',1975,'GP','Guadeloupe','people-and-society',185,'Ethnic divisions: 90// Negro or Mulatto, less than
o% Fast Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5r/ Hindu and
pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25%
unemployed
Organized labor: 1 1 % of labor force','188572b3a436978fe6a308fb446de51ceca7f783406d693916c51557a38c4c25','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b9d31d754b150e73198f0246005040181499ec618c004768fcddb87a932eea',1975,'GT','Guatemala','people-and-society',190,'Population: 5.8.53,000, average annual growth rate
2.87 (7/72-7/73)
Nationality: noun— Guatemalan(s); adjective —
Ciiatemalan
Ethnic divisions: 11.17 Indian, 58.07 badino
(mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 107 of the
population speaks an Indian language as a primary
longue
Literacy: about 307
Labor force (1974): 1.75 million; 057 agriculture,
11.37 manufacturing; 11.27 services, 6.47 to
commerce, 2.67 construction, 2.47 transport. 0.27
84
mining, 0.27 electrical, 0.87 other. Unemployment
estimates vary from 3 to 257
Organized labor: 47 of labor force (197 I )','265a525a6d4e88bb0eadbfe993a660e3e53cc327c506456344137b467fbb9f1d','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03f13252c8fb6c898baf598c30c033449fa0fbf166a3b382d9c945c72a4a5992',1975,'GN','Guinea','people-and-society',193,'Population: 4,418,000. average annual giowtli rate
2.5% (current)
Nationality: noun — Guinean(s); adjective —
Guinean
Ethnic divisions: 99% African (3 major tribes —
Fulani, Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% auimist, Christian, less
than 1%
Language: French official; each tribe has own
language
Literacy: 5% to 10%; French only significant
written language
Labor force: 1.8 million, of whom less than 10%
are wage earners; most of population engages in
subsistence agricult lire
Organized labor: virtually 100% of wage labor
force loosely affiliated with the National Confedera-
tion of Guinean Workers, which is closely tied to the
PDC','fc0a880565d6dfae53d036d0dd1945a7f021dcefa180c2284a74ca3abca4866f','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99b1bdc3fdaeeed4ac3418ac6e63bcd9b07497d80b77955dd4a76fa852ecc9f8',1975,'GW','Guinea-Bissau','people-and-society',197,'Population: 492,000, average annual growth rate
0.2ft (7/68-7/69)
Nationality: noun — Guinean(s); adjective —
Guinean
Ethnic divisions: about 99ft African (Balanta 30ft,
Fulani 20ft, Mandvako 14%, Malinke 13ft, and 23ft
other tribes); less than I ft European and mulatto
Religion: 66ft animist. 30ft Muslim. 4ft Christian
Language: Portuguese and numerous African
languages
Literacy: 3ft to 5ft
Labor force: bulk of population engaged in
subsistence agriculture
86
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
GlItNEA-IUSSAll/CVYANA','c0df080f75438ca5fc538e9fd09d281ba7ecd5ce3e986d9a7c406bff4bdd0dac','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abfe2ed164748dadb1768ee8e7e65213491ce95ad1e8e38be02c2039cd46bd60',1975,'GY','Guyana','people-and-society',201,'Population: 811,000, average annual growth rate
2.5% (4/60-4/70)
Nationality: noun— Guyanese (sing., pi.); adjec-
tive— Guyanese
Ethnic divisions: 51% East Indians, 43% Negro
and Negro mixed, 4% Amerindian, 2% white and
Chinese
Religion: 57% Christian, 33(7 Hindu, 9% Muslim,
I % other
Language: English
Literacy: 86%
Labor force: 201.000; about 25% agriculture, 14%
manufacturing, 16% services, 11% commerce, 3%
mining and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force','ecfba6a61a882eecb85565572551e0bfedd577b7f989addf80862dc2852e4fae','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba1b4135a591ca63359c46e7fdf6461e52fe284cdb4d370b67f0c06c3050755',1975,'HT','Haiti','people-and-society',205,'Population: 4,569,000. average annual growth rate
1.6% (current)
Nationality: noun — Haitian(s); adjective — Haitian
Ethnic divisions: over 90% Negro, nearly 10%
mulatto, few whites
88
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
Religion* 10%> Protestant, 7597 to 80/7 Roman
Catholic \\<)[ which an overwhelming majority also
practice Voodoo)
language: French (official) spoken hv only 10% of
population; all speak Creole
Literacy: 1097 to 12%
Labor force: 2.0 million (est. January 1008); 80%
agriculture, 12% industry, 2% unemployed; shortage
of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force','9843748280f4749ec04d6ada1c72cec5cc45fddb50601e50791e755432c94e44','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32759e64e0af67d6525294ccfd822a62b0389ca12f8be757a22b4d9b0300528d',1975,'HN','Honduras','people-and-society',209,'Population: 2,7-19,000, average annual growth rate
2.7ft (-1/61 -3/7-1)
Nationality: noun — I londuran(s); adjective-
Honduran
Ethnic divisions: 90*7 mestizo. 7ri Indian, 2f7
Negro, and Iff white
Religion: about 07 fr Roman Catholic
language: Spanish
Literacy: 57.4 fr of persons 10 years of age and over
(est. 1970)
I*abor force: approx. OOO.tKM) (est. mid- 1 972); 66*7
agriculture, I2fr services, 87 manufacturing, 57
commerce, 67 unemployed, 37 unspecified
Organized labor: 77 to 107 of labor force* (mid-
1972)','50a78c428ee73d4557289d965ec9178e7ec6b0e00c91591540c41eacf18d7fb4','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dd23fddfcfe77c2ab61116d92d13f18ff11518dbc119e6b728368905d4c1ab3',1975,'HK','Hong Kong','people-and-society',213,'Population: 4.519.000, average annual growth rate
1.0% (7/71-7/74)
Nationality: adjective —Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian. 90% eclectic mixture of
local religions
Language: Chinese. English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 45%
manufacturing, 20% services, 11% construction,
mining, quarrying and utilities, 15% commerce. 4%
agriculture, forestry, fisheries, and hunting, 7%
communications, 2%- other; underemployment is a
serious problem
Organized labor: 12% of 1909 labor force','18ed215bd3ef6663be80add403c3c4c996813462502106114e101d3bcb9c0a4c','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e023d1346e2c3776192da6ca7f635338fe2b8a2f07d65969b2421ed1d0327b66',1975,'HU','Hungary','people-and-society',217,'Population: 10,541,000, average annual growth
rate 0.6% (current)
Nationality*, noun — llungarian(s); adjective —
Hungarian
Ethnic divisions: 93.3% Magyar, 2.5% German,
2.4% Gypsy. 0.7% Jews, 1.1% other
Religion: 67.5! Roman Catholic, 20.0% Calvinist.
5.0% Lutheran, 7.o% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,061.200 (1 January 1973); 24%
agriculture, 44% industry and building, 16% trade
and transport, 16% other nonugricultural','39cc18080f0cac2e77dba7de24e01f49c1bb36a8f94948fff20b1f0e98546043','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20c85b83e40d83d51b5832572ded1c5c3d65cce60a7a6266d370e6df9adcc47e',1975,'IS','Iceland','people-and-society',221,'Population: 218.000, overage annual growth rate
1.2% ( 1 2/00* 1 2/7*1)
Nationality: noun — lcelander(s); adjective —
Icelandic
Ethnic divisions: homogeneous white population
Religion: 05% Evangelical Lutheran. 3% other
Protestant and Roman Catholic. 2% no affiliation
Language: Icelandic
Literacy: 00%
Labor force: 85,000; 22.0% agriculture and
fishing; 25.0% mining and manufacturing; 10.7%
construction; 12.8% commerce; 7.8% transportation
and communications; 15.2% services; and 5.7% other;
unemployment is insignificant
Organized labor: 00% of labor force','9d66d7d2a8207a8ef0730d3af0bc7c11affb659bd2e9c27fa6e0feb96993276d','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e45270507f6729f505cf2c979913c2ad1dc8fa800ee5f4d0c0773555ffeba131',1975,'ID','Indonesia','people-and-society',225,'Population: 131,166,000 (including West Irian),
average annual growth rate 2.6% (current)
Nationality: noun — Indonesian(s); adjective —
Indonesian
96
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
Ethnic divisions: *15% Javanese*, M% Soudanese,
7.5% Madurese, 7.5% Coastal Malays, 26% oilier
Religion: 90% Muslim, 1% Christian, 2%
Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay)
official; English, and Dutch leading foreign languages
Literacy: 60% (ext.); 72% in 6-16 age group
Labor force: II million; 70% agriculture, 15%
industry, 15% miscellaneous and unemployed
Organized labor: 10% of labor force
Population: 33,200,000, average annual growth
rate 8ft (1/71-1/72)
Nationality: noun — Iranian(s); adjective — Iranian
Ethnic divisions: 63ft Ethnic Persians, 3ft Kurds,
13ft other Iranian, 18ft Turkic, 3ft Arab and other
Semitic, 1ft other
Religion: 93ft Shiu Muslim; 5ft Sunni Muslim;
2ft Zoroastrians, Jews, Christians and Baha is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 37ft of those 7 years of age and
older (1972 est.)
Labor force: 9.2 million; lift agriculture, 20ft
manufacturing; shortage ol skilled labor substantial
Organized labor: 8ft ui labor force','9195afa5e5af2bfa65f3333dfdf4a0f613831d6ea69ff40ec23ef9afdb7ebb62','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ac8a1227318d7d831cd4263d0e31969b2f32f04166a40670c2f4ee3d5bd7a4',1975,'IQ','Iraq','people-and-society',229,'Population: 11.021,000, uveruge annual growth
rate 3.4 % (10/73-10/74)
Nationality: noun — lra<ji(s); adjective — Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4%'' Turkomans, 7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks
Kurdish
Literacy: 20% to 40%
I>ahor force: 2.4 million; 70% agriculture, 6.5%
industry, 6.7% government, 16.8% other; rural
underemployment high, hut not serious because low
subsistence levels make it easy to care for
unemployed; severe shortage of technically trained
personnel
Organized labor: 1 1 % of labor force','35561276a92316d05ad2f279d960149982ff6eba1b666a71ea8af161d373912c','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d548f93c5f7f64f4805fa16ebfaa2d59c98233d7ce29eff071edfc45d0d769c',1975,'IE','Ireland','people-and-society',233,'Population: 3,000,000 average annual growth rale
0.0b (7/fW-7/7.-I)
Nationality: noun — Irishinoii(meu), Irish (roller-
Hvr pl.); adjective -Irish
i:ihi.ic* divisions! racially homogeneous Cells
Religion: 01 b Roman Catholic, I b Anglican, 2*7
other
laingungri English and Gaelic official; English is
generally spoken
Literacy! 98b-09b
Labor forcer about I.I.''H.OOO (1971); 2 0b
agriculture. forestry, fishing; 19b'' manufacturing;
15b*. commerce; 7b construction; 5b'' transportation;
•lb'' government; 2-lb other
Orgunl/cd labor: 30b of labor force
GOVKHNMKNT
Legal tiarnct Ireland, Lire (Gaelic)
Typci republic
Capital: Dublin
Political subdivisions! 20 counties
Legal system! based on Lnglish common law,
substantially modified by indigenous concepts;
constitution adopted 1957; judicial review of
legislative acts in Supreme Court; lias not accepted
compulsory fCJ Jurisdiction
Brandies: elected President; bicameral parliament
reflecting proportional and vocational representation;
judiciary appointed by President on advice of','48ddcffdc9809ddf58b8c625913f99047ed70a567065fc39364805bbd0210dd5','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6ca5bd6f1a7197896e25f0aa567b65c4dee8ab4ebd093db555ca6a96109b7c5',1975,'IL','Israel','people-and-society',237,'Population: 0,372.000 (excluding East Jerusalem),
average annual growth rate 2.7ft (7/73-7/74)
Nationality: noun — Israeli(s); adjective — Israel
Ethnic divisions: 85ft Jews, 15ft non-Jews (mostly
Arabs)
Religion: 89 ft Judaism, 8ft Islam. 3ft other
Language: Hebrew official; Arabic used officially
for Arab minority; English most commonly used
foreign language
Literacy: 88ft Jews, 48ft Arabs
Labor force: 1. 1 17.000; 7.4ft ugiieultme. Imestry
and llshlng; 24.11ft maiiulucluilng (mining. Industrs ),
1.0ft electricity and water; 0.0ft’ coustmctlor iml
public works; 12.0ft commetce; 7.1ft Inmsport.
storage, and communications; 0,2ft llnancc ami
business; 21,0ft public services; 0.0ft personal and
other services ( 1073)
Organized lalmr: 00ft'' ol labor force','16b2c6247bb596ff63e7bbd7d36548e5977e3eed0dc01dad88bf86cc718f9346','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a314ac6f485464d9e049e95c171d4d6133b67ebab76199a02a801fd00a2f608a',1975,'IT','Italy','people-and-society',243,'Population: 4.885.000 (resident African population
only), average annual growth rate 2.6b (current)
Nationality: noun — Ivorian(s); adjective — Ivorian
Kth nic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20b of imputation;
most important arc Agnl. Ilannle. Krou, Senoufoti.
Mundingu; approx. I million foreign Africans, mostly
Voltaic*; about 33.000 non-Africans (23.000 French)
Religion: 00b animist. 22b Muslim. 12b
Christian
language: French official, over 00 native dialects.
Dioula most widely spoken
Literacy: about 20b
Labor force: over 83b of imputation engaged in
agriculture, forestry, livestock raising; about lib of
labor force arc wage earners, nearly half in agricul-
ture. remainder in government, industry, commerce,
and professions
Organized labor: 20b of wage labor force','e2219eb898b825971c5c583a9946763fdaf1e49da971d3b5c0e74805ae7f3d9a','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97ab5436e43986af18b102f81f56850d6eed26b013512170e10ce161607d1485',1975,'JM','Jamaica','people-and-society',245,'Population: 2,053.000. average annual growth rate
1.9b (7/71-7/73)
106
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July l»75
(5h i»l***tf If I
Nationality: iioun--inmulenii(s); adjective —
Jamaican
Ethnic divisions: African 70. 3??, Afru-Europenn
15. 1%, Chinese arid Afro*( Chinese 1.2b'', East I iidlii ti
and Afro-East Indian 34 b''. white 3.2b. other 0.9b
Religion: predominantly Protestant, some Itoman
Catholic, some spiritualist cults
language: English
Literacy] government claims 82b, but probably
only about one-half of that number are functionally
literate
Iadior force: 80S. 3(H); 20 b in agriculture, forest rv,
fishing and mining. 10?/ manufacturing. 8b public
administration. 5 ?f construction. 10?? commerce. 3b
transportation and utilities, 1 5b services. 23b
unemployed (seasonal unemployment in agriculture
can push the unemployment figure to 25b ); shortage
of technical and managerial personnel
Organized labor: about 25?? of labor force (1000)','13dd8f9fbee90c8ff13d3ee391f841d7a21bcd3fbda7b7ac9dbc866e074956cf','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2775fe4e1845042ae3fe52db3e54229d7c8c1e67e3c2dcf743549bb9b45c58e6',1975,'JP','Japan','people-and-society',249,'Population: 1 1 0.032.000 (including Ryukyus).
average annual growth rate 1.17 (7 /OI-7/7-I )
Nationality: noun — Japanese (sing., pi.); adjec-
tive— Japanese
Ethnic divisions: 99.2% Japanese, .8% other
(mostly Korean)
Religion: most Japanese observe both Shinto and
Buddhist rites; about 107 belong to other faiths,
including 0.87 Christian
Language: Japanese
Literacy: 97.87 of those 15 years old and above
(I960 data)
Labor force (1969 figures): 5! million; 18.07
agriculture, forestry, and fishing; 31.27 rnanufactui
ing, mining, anti construction; 36.17 trade and
services; 6.67 transportation; 3. 1 7 government; 1.17
unemployed; shortage of skilled labor 1.5 million;
unskilled .5 million (est.)
Organized labor: 207 of labor force','42487088b71fb47b9206901c41933968dabae01866dea1ccc86fcc8327adb2e1','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9104df558612f3898b2feaeae4509b66b9fd37ce182f2b5f8596b2566da0370',1975,'JO','Jordan','people-and-society',253,'Population: 2,708,000 (including West Bank and
Fast Jerusalem), average annual growth rate 3.3%
(7/70-7/73)
Nationality: noun — Jordanian(s); adjective —
Jordanian
Ethnic divisions 98% Arab, 1% Circassian, 1%
Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 50% in Fast Jordan; somewhat less
than (50% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force','0df979fabd991a15011acf8af8661f0fcdbba4b8771b3300177c8cd2604e06cf','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b53843ebdfea5f13332bc3d568ffdcb87c1461e203027e9c24edebe508f4db5',1975,'KE','Kenya','people-and-society',257,'Population: 13,357,000, average annual growth
rate 3.4% (7/73-7/74)
Nationality: noun — Kenyan(s); adjective — Kenyan
Ethnic divisions: 97% native African (including
Bantu, Nilotic, Hamitic and Nilo-Hamitie); 2%
Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist,7% Muslim,
1% Hindu
110
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
KENYA/ KOHEA* NOHTII
bmgungo: English and Swahili official; cadi tribe
has own language
Literacy i 27%
Labor force: 2.5 million; about 1)77, 000 (39%), In
monetary economy (1907)
Organized labor: about 215,000
Population: 16,507,000, average annual growth
rate 3.1 % (current)
111
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
KOHIl/ 1, NOM''II/KOMIA . .SOC/TH
July 1075
Nationality! noun — Korcan(s); adjective — Korean
Ethnic divisional racially homogeneous
Religion: Buddhism unci Confucianism; religious
activities now almost nonexistent
language: Korean
Literacy! 90% (est.)
Ijibor force: 0.1 million; 18% agriculture, 52 %
non-a^ricultural; shortage of skilled and unskilled
labor
Population! 11,2.11,000, average annual growth
rate 2.0% (current )
Nationality: noun— Korean(s); ud|ective— Korean
Filmic divisions: hmiingeneous; small Chinesr
minnrily (approx. 20,000)
Religion: strong Confucian tradition; pervasive
folk religion (Shamanism); vigorous Christian
minority (5,5*7 of population); Buddhism (including
estimated 20,000 member*, of Soku Cakkal).
Chnmlokyn (religion of the heavenly way), eclectic
religion with nationalist overtones founded in 19th
century, claims about 1.5 million adherents
language: Korean
Literacy: about 90%
tabor force: about 10.2 million (1071); 10.2*7
agriculture, fishing, forestry, 12. 1*7 services, 14%
mining ami manufacturing, 1% const ruction, ‘1.5*7
unemployed
Organized labor: about 1 0f; of nonagriculturo!
IuImu force','02e3918bd9df8b7252a4cf110a296b4e9238b9ef9f2132d67b05e3e2e415da61','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db88382d78de93b0bf6d523ae52816dd88cc4428b30ba9ff143d62f14295a5a',1975,'KW','Kuwait','people-and-society',261,'Population! 978.000. average annual growth rate
5.3% (7/73-7/74)
Nationality} noun — Kuwaiti(s); adjective— Ku-
waiti
Ethnic divhioit*! 87% Arabs, 12% Iranians,
Indians, and Pakistani, 1% other
Religiom 95% Muslim, 5% Christian. Hindu.
Pars!, other
language! Arabic; English commonly used foreign
language
Literacy! about 42.8% (1970)
Labor force: 238,(XM) ( 1970); *11% manufacturing,
25% services, 22% government and professions 9%
commerce
Organized labor: labor unions, first authorized in
1904, formed in oil industry and among government
; ***sonnel
Population: 3,33(UX>0, average annual growth rate
2.4% (7/72-7/73)
Nationality: noun— lam (sing., pi.); adjective—
Lao or Liotiun
Ethnic divisions: 47% Liu; 14% Tribal Tai; 25%
I’houtheung (Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% uni mist and other
Language: Lao official, French predominant
foreign language ulso used in administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agri-
culture; 159.286 engaged in manufacturing and
services; 28,400 (22,400 civil and 6,000 police)
government employees in FY72
Organized labor: a labor federation was formed in
mid- 1974, but labor organization remains in Us
infancy
115
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : Cl A-RDP86T00608R0006001 00003-3
July 1075
LAOS','d34ae06f6ba0d122d4ee1cdb79bff8f41422b09defa0d5ee6c47f8240394b6d1','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc5e5eb6b66492e261f8761e391c6c138204e6f3857ceacddc83f61e11b64579',1975,'LB','Lebanon','people-and-society',265,'Population: 2. 449, (MX), average uiimml growth rate
3.1% (current)
Nationality: noun — I*olmnese (sing, and pi );
adjective — Lebanese
Ethnic divisions: 93% Aral). 6% Armenian. 1%
other
Religion: 55% Christian, 44% Muslim and Druze.
1% other (official estimates); Muslims believed to
constitute slight majority
language: Arabic (official); French is widely
spoken
Literacy: 86%
Labor force: about I million economically active;
49% agriculture. 11% industry. 14% commerce. 26%
other; moderate unemployment
Organized labor: about 65, 000','abea20b3032dc6e13248bf6a97e58e766b71f9e29c8cb01ead54426bdeeb5002','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b2be56ba1e49a9133c9286a992771b0384de1679a295c69ae23890e55c2e8ae',1975,'LS','Lesotho','people-and-society',269,'Population: 1,088.000. average annual growth rate
2.2% (7/73-7/74)
118
Nationality! notin Ibisotban(s). ad|ecllvr
llasolbaii
Ethnic'' divisions! 00 7% Sntbo, I .(UK) Europeans,
8(H) Asians
Religion: 70% or more Christian, rest auiitiM
language! all Africans speak Sesnlho vernacular,
English Is second language for literates
Literacy: 10%
fadror force! 87 1% of resident popidatlun engaged
In subsistence agriculture; 150.000 to 250 000 spend 0
tuontbs to many years as wwy/ earners lit South Afric a
Organized labor: negligible','b7019f262eeffd13f8ca5f2f6cac7f4652d79521a0f4b96945a2c9bb205360a7','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('171f897c5f17ecea40678412a0f76c63a6b0b4b5e5fd35a19e04660cc028300b',1975,'LR','Liberia','people-and-society',273,'Population: 1,702.000. average annual growth rate
2.9% (current)
Nationality: noon— Liberlun(s); adjective —
Liberian
Ethnic divisions: 5% descendants of immigrant
Negroes; 95% indigenous Negroid Africa!! tribes
including Kpelle. Itassa, Km. Orcbo, Cola. Kissi,
Kruhn, and Mandingo
Religion! probably more Muslims than Christians;
70% -80% auimist
language: English official; 28 tribal languages or
dialects, pidgin English used by about 20%
Literacy: about 24% over age 5
labor force: 500,000. of which 150,000 are in
modern economy; about 2.000 non-African foreigners
hold about 95% of the top level management and
engineering jobs
Organized labor: 2% of labor force','9bd1d28f5bcfc070bd2378c882ca42a9a65f9f45a78b9f73d376a2ee77eb7af6','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c506b5a3792594615ad8a141bfa48ba4dd251719e367ba490fc4b502d8931767',1975,'LY','Libya','people-and-society',279,'Population: 2,-1 18, (KM), average annual growth rule
''11% (7/7:1-7/71)
Nationality! noun — l.lhvnn(s); ndlrcllvr— Libyan
Ethnic divisions: 97 ?r llerher mid Arab with some
Negro stock; some Greeks, Multcse. Jews, Itulhms.
Egyptians
Religion: 97ft Muslim
I-anguagct AruHe; Ilullati and English widely
understood In major cities
Literacy) 85 ft
tabor forcer 185,000; he! ween ages 15-01,
40.)l000*480,(H)0; (il/i- of labor force in agriculture
(1904)','dd3d7160a884d10104c2473ac3d3e4623f90059ffef3e40fceddc247be4beb05','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98925d75698fba4a29aeace0d014f18d2246a570bc7bb6c17b2d6d35ad7c9c6c',1975,'LI','Liechtenstein','people-and-society',283,'Population: 21,000. average annual growth rate
2.5ft (12/00.12/70)
Nationality: noun— Liecliteusteiner(s); adjective—
Ethnic divisions: 95ft Germanic, Oft Italian and
other
Religion: 92ft Roman Catholic
Language: German (dialect)
Literacy: 98ft
Labor force: 7.0(H), 0.5(H) loreign workers (mostly
form Austria and Italy); 59ft industry. 20ft trade and
commerce, 13ft professional and other, 8ft
agriculture','d063aa58e87ca8ffd1d764b3ce67115a45783a776e40fb3b0b604649011ecb1b','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e742ea194c77555855f04606e328546458b01c2ab4d9cf764cca76c5a245091',1975,'LU','Luxembourg','people-and-society',288,'Population: 357,000, average annual growth rate
0.7% (1/(56-1/74)
Nationality: noun — Luxembourger(s); adjective —
Ethnic divisions: 83% Luxernbourger, including an
estimated 5% of Italian descent; remainder French.
German, Belgian, etc.
Religion: 07% Homan Catholic, remaining 3%
Protestant und Jewish
Language: Luxembourgish. German. French; most
educated Luxembourgers also speak English
Literacy: 98%
Labor force: (1973) 1 5*1, 000; 10% agriculture
(including forestry and fishing), 48% industry, 42%
services, no significant unemployment; 28% of labor
force is foreign, comprising workers from neighboring
areas of Belgium, France, and West Germany, as well
as Italy and Portugal
Organized labor: 45% of labor force','c63e6c957502ad508dee414ec8fd02fe9d4d11405d849fbf3eb2e754d6585ef3','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50636350871d3d1ec4284a853eea3d27b39b80f17d245eb7bbe9651a1c7e0683',1975,'MO','Macao','people-and-society',292,'Population: 251,000 (official estimate for 1 Julv
1972)
Nationality: noun — Mucaon(s); adjective —
Macao n
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
about one-ludf are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and
Macanese; no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing,
3% construction, 1% utilities, 27% commerce, 8%
transportation and communications, 26% services
(I960 data)','fb06ec9e477d22bb159e789c5ed4bbea18d942999b006caca9020dee1ddc16ca','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b282132914ad958bcdb83c8a74de39201aa3d943e3f392eeeee8332a5873d858',1975,'MG','Madagascar','people-and-society',296,'Population: 7,553,000, average annual growth rate
2.3% (7/69-7/70)
(Stft nfwnit mi p VI/
Nationality: noun— Malagasy (sing, and pi.);
adjective— Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Mu* jyu-Indonesiun origin, consisting
of Merina (1,643,0/0) and related Bctslleo (760,000),
on the one hand, and coastal tribes with mixed
Negroid, Malayodndoneslan, and Arab ancestry on
the other; coastal tribes include Hctsimisarakn
041.000. Tsimihety 442,000. Sakalavu 375.000.
Antaisaka 415.000; there are also 38,000 French,
66.000 other
Religion: more than half ailin'', 1st; about 41%
Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 00% are
nonsalariod family workers engaged in subsistence
agriculture; of 175.000 wage and salary earners, 26%
agriculture, 17% domestic service. 15% industry, 14%
commerce, 11% construction, 9% services. 6%
transportation, 2% miscellaneous
Organized labor: 1% of labor force','06fc8db78d2abb088408d43a9710b98c52916db2e900df87a88c0414b327ff42','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4c5a220d82f797b91a4a6aa96c5e9d8870cce0d63d19b32e401fc6e7d73fd10',1975,'MW','Malawi','people-and-society',300,'Population! 5,042,000, average annual growth rate
2 6ft (7/71-7/70)
Nationality! noun — Muiuvviun(s); adjective —
MuLwhin
Ethnic divisions! over 99ft unlive African, less than
! ft European and Asian
Religion: majority animlsl; rest Christian and
Muslim
Language! English and Cliichewu official; Loimve
Is second African language
literacy: 0% of population over 2i years old
Labor force: 225,000 wage earners employed in
Malawi (1974); 0.000 Europeans permanently
employed; 300,000 Malawians live and work In
Rhodesia, South Africa, and Zambia; 30?r agriculture,
lift construction, 10ft commerce, 13ft manufac-
turing, 10ft administration, 25ft miscellaneous
services
Organized labor! small minority of wage earners
are unionized','046f8dbda1f46239a4a3a8dee22af82e51354a8b1fa17dbb0a2620ad0ab57106','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec5f035f7b5867de247630cf983d05a4a4da4409f13293290cc8df5265e89cbc',1975,'MY','Malaysia','people-and-society',304,'Population: 11,860.000, average annual growth
rate 2.7 % (current)
West Malaysia: 0,965,000, average annual growth
rate 2.65c (6/57-8/70)
Sabah: 783,000, average annual growth rate 3.757
(8/60*8/70)
Sarawakt 1.112.0(H), average annual growth rale
2.7(7 (6/60-8/70)
Natinnulityr noun — Malayslan(s); adjective —
Malaysian
Ethnic divisions:
Malaysia: 44(7 Malay, 30(7 Chinese. 8(7 tribal,
10(7 Indian and Pakistani, 2(7 other
West Mulaysia: 50.1(7 Malay, 30.0(7 Chinese, 1 1 (7
Indian and Pakistani, 2(7 other
Subalii 23.1(7 Chinese, 07.3(7 indigenous tribes,
0.0(7* other
Surawak: 31.5(7 Chinese, 50(7 indlgeiioiis tribes,
17.5(7 Malay. 1(7 other
Religion:
West Malaysia: Malays nearly all Muslim, Chinese
predominantly Buddhists, Indians predominantly
Hindu
Suhuh: 38(7 Muslim, 17(7 Christian, 45(7 other
Sarawak: 23(7 Muslim. 24(7 Buddhist and
Confneianist, 10(7 Christian, 35(7 tribal religion, 2(7
other
language:
West Malaysia: Malay (official); English. Chinese
dialects, Tamil
Suhuh: English. Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among
Chinese
Sarawak: English. Malay, Mandarin, numerous
tribal languages
Literacy:
West Malaysia: about 48(7
Sabah and Sarawak: 23(7
Labor force:
Malaysia: 3.45 million (1007)
West Malaysia: 2.9 million; 55 (7 agriculture,
forestry, and fishing, 1 1 (7 manufacturing and
construction, 34(7 trade, transport, and services
Sabah: 213.0(H) (1967); 80(7 agriculture, forestry,
and fishing. 6(7 manufacturing and construction. 13(7
trade and transportation, 1(7 other
Sarawak: 341,000 (1987); 80(7 agriculture, forestry,
and fishing, 6ft manufacturing and construction, 13(7
trade, transportation, and services, 1(7 other
Organized labor: 370,(XK) (official 1967 est.) about
1 0.5(7 of total labor force; 28(7 of wage labor force;
unemployment about 857 of total labor force, but
higher in urban areas','e5449758e4a22391f900bb792c42640d9607b0250e4bf25fcb206e425a3f329c','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4ed477d73eabe786dc5e2fb58774f0bea90bf2df850c06d850975d6355dee0c',1975,'MV','Maldives','people-and-society',308,'Population! 130,000, average annual growth rate
2% (current)
Nationality! noun — Mnldivlun(s); adjective —
Maldivian
Ethnic divi sions: admixtures of Sinhalese,
Dravidian. Arab and Negro
Religion! official Sunni Muslim
Language: Divehl (dialect of Sinliala)
Literacy! largely illiterate
Labor force: fishing Industry employs most of the
nude population','22383c6782da67672e340aefd847b4b17c088e88a9ac3a9d0c4a6570e7a9d993','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4971aa81158754d51b121bf5befd8b283ee43f63167eee7b6ab139bcc03c0a3d',1975,'ML','Mali','people-and-society',312,'Population: 5,622,000, average annual growth rate
2,3% (7/72-7/73)
Nationality: noun— Malian(s); adjective— Malian
Ethnic divisions: 99% native African including
tribes of both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African
languages, of which Mundc group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried,
50,000 of whom are employed by the government;
most of population engaged in agriculture and animal
husbandry
131
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
MAU/MAI.TA
Major trade partner*! mostly with f rum* /tun* mid
Organized lulmri IJNTM, which claimed all
eligible employees, dissolved; thirteen national unions
currently directed by a government controlled
Coordination Committee of Mall Trade Unions
(CCS VI)','3ed386197cc0ab557ad1c5fe5b40cdb56c932c26738170918271946fff3497c5','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b63db52bcf1e1c91e789b9c48fca101e1cc3d9a9d3ecd6b3db826c7001886288',1975,'MT','Malta','people-and-society',316,'Population! .''122,000 (official estimate for 00
September 1974
Nationality! noun— Maltese (sing, and pi );
adjective— Maltese
Ethnic division*! mixture of Aral), Sicilian.
Norman, Spanish, Italian, British
Religion) 98% Homan Catholic
Language! English and Maltese
Literacy! about 83%; compulsory education
introduced In 1940
Labor force t 107,500; 29% services, 23%
government, 24% manufacturing, 0% agriculture, 4%
construction, 4% transportation and communications,
5% utilities and drydocks; 5% unemployed
Organized labor! approximately 35% of labor force','b436517eef1725ff67c47aa72c14919eb5705fc5c4c725b9dab33f26eb9c8563','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4d263bf5bd2931af84e697c3123a1014eb23c52726e42ad4ce15764aa22cfba',1975,'MQ','Martinique','people-and-society',319,'Population: 147,000, average annual growth rate
0.5% (7/70-7/73)
Nationality: noun — Martinicjuais (sing, and pi.);
adjective— Martini(|uais
Ethnic divisions: 90% African and African-
Caueasian-Indian mixture, less than 5% East Indian
Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture. 20% public
services. 11% construction and public works, 10%
commerce and banking, 10% services, 9% industry,
17% other
Organized labor: 11% of labor force','1f1ee6cca1f5dbfe115a5dba8768209d4a2328a23139280c3983a8ea2b087397','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9708a30c54b3856ffd3f823c2fcf6ca13ca5ca2ad3ad9f991860ee946c09e5',1975,'MR','Mauritania','people-and-society',322,'Population! I,323,(HH), average annual growth rate
2.5% (current)
Nationality! noon— Maurltanlan(*); adjective—
Mauritanian
Ethnic division*! 80% Moor, 20% Negro
Religion! nearly l(H)% Muslim
Language! Ilassanlya Arabic in the national
language spoken by Mime 80% of the population,
French I* the working language for government and
commerce
Literacy* about 10%
Labor forcet about 18, (HH) wage earners (1973);
remainder of population in farming and herding
Organized labor* 1 8,000 union members claimed
by single union, Mauritanian Workers'' Union','9357cb904f5a667e8a768231d44ce562a72f2f5df7816280e263b8c42cc9ec65','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b5301eef21f169e7c9c287d632f7efbb35a34a7fa2632959193c1dd71560de8',1975,'MU','Mauritius','people-and-society',326,'Population: 885, 000, average annual growth rate
1.1% (1/73-1/74)
Nationality: noun— Mauritian(s); adjective—
Mauritian
Ethnic divisions: Indians 67%, Creoles 29%,
Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly
Catholic with a few Anglican Protestants), 16%
Muslim
Language: English official language; Hindi,
Chinese, French Creole
Literacy: estimated 60% for those over 21. and 90%
for those of school age
Labor fore-*: 175,000; 50% agriculture. 6%
industry; 20% government services; 14% arc
unemployed, under-employed, or self-employed, 10%
other
Organized labor: about 35% of labor force','10486421a58af9e7d4abe0aade19d07785246572dcb40844aacdc7ef3f4020a8','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76b3baf131727869d4fa101fe9d16b3b1c1438a98f6a6da90beaa3a2109201a5',1975,'MX','Mexico','people-and-society',330,'Population: 58,075,000, average unnuul growth
rule 3.2% (current)
Nationality: noun — Mexicun(s); adjective—
Mexican
Ethnic divisions: 60% mestizo, 30% Indian or
predominantly Indian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic, 3%
other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force (1973): 13.1 million (defined as those
12 years of age and older); 39.5% agriculture, 16.7%
manufacturing, 16.6% services, 16.8% construction,
utilities, commerce, and transport, 3% government,
7.4% unspecified activities
Organized labor: 20% of total labor force','1d3afe49d985bd0fb5062d37d33d37f683580b12dd1961451ab029a5680e7079','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a7edb826d6f8d827758b9e237c2d763cf0e370f18d707f365f0eba1150e8f0d',1975,'MC','Monaco','people-and-society',334,'Population: 24,000 (official estimate for 1 July
1973)
Nationality: noun — Monacan(s) or Moncgasque(s);
adjective — Monacan or Moncgasquc
Ethnic divisions: Rhuctian stock
Religion: Roman Catholicism is official state
religion
Language: French
Literacy: almost complete','c1d2447f3cb7e18142971614ca84f43ade78537d7d059edba12eb240218e762a','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('574471ccd3f41cba243c89c320af704ae9e25920cb49d448561fe31ccdb6c1d3',1975,'MN','Mongolia','people-and-society',338,'Population: 1,444,000, average annual growth rate
3% (current)
Nationality: noun — Mongollan(s); adjective —
Mongolian
Ethnic divisions: 90% Mongnl, 4% Kazakh, 2%
Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about
4% Muslim, limited religious activity because of
Communist regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian,
and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is In the labor force, including a large
percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable
information available)','f618d8faf78736c318dc79b60b553436df3c7db03c812f10363cf8a4704e59dc','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5971174d99855164ca3f921aeeba1860e03dc8ff478c37e8eacb1d3a0b55899b',1975,'MA','Morocco','people-and-society',342,'Population: 1 7,27*1, (XK), average annual growth
rate 2.9% (7/72-7/73)
Nationality: noun — Morocean(s); adjective —
Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish,
0.7% non-Moroccun
Religion: 98.7% Muslim, 1.1% Christian, 0.2%
Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government,
diplomacy, and postprimary education
Literacy: 20%
Labor force: 6.3 million (1971 t\\t.); 50%
agriculture, 15% industry, 26% services, 9% other
Organized labor: about 5% of the labor force,
mainly in the Union Moroccan Workers (UMT)','f2e382784651d3446446fe991b2ef850b4c9a829a6384f108a26aa7f78d411d7','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1170f3a366fce9085cf3679f05e8c0ddab2a96c4547f93ca69275d398b6ebe45',1975,'MZ','Mozambique','people-and-society',346,'Population: 9,081,000, average annual growth rutc
2.2% (9/60-12/70)
Nationality: noun — Mozambican(s); adjective —
Ethnic divisions: 97% African, 3% European,
Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5%
Muslim, 2.4% other
Language: Portuguese (official); many tribal
dialects
Literacy: 7%-10% (cst.)
Labor force: (1963 cst.) 610,000; 50,000 non-
African wage earners, 560,000 African wage earners in
Mozambique; 290,000 additional African wage
earners temporarily working in Rhodesia and South
Africa; unemployment serious problem; most native
Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970);
75% arc white','f8f176d2e0d1edbfa32e90d5886a28b39706ab8c6be4d4985135f22fb524ad7a','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663bb255bd39b96ae3bfa5a48aedb8066cbd65eaa63a0e2b0d5fc36886a6232d',1975,'NR','Nauru','people-and-society',350,'Population: 7,000 (official estimate for 30 June
1969)
Nationality: noun— -Nauruan(s); adjective —
Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (% Protestant, % Catholic)
Language: Nauruan, a distinct Pacific Island
tongue; English, the language of school instruction,
spoken and understood by nearly all
Literacy: nearly universal
143
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
NAURU /NEPAL
July 1075','07204cd91aa5280ed2f92ca08ac55337ba6c2a0249de89f73b816ea551004581','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('164e2037f959a1afa9c227d038b91d2a9aca98678bfc4aeea0706a19de5e8847',1975,'NP','Nepal','people-and-society',354,'Population: 12,550,000, averuge annuul growth
rate 2.1% (6/61-6/71)
Nationality: noun — Nepalese (sing, and pi.);
adjective — Nepalese
Ethnic divisions: two main categories, Indo-
Ncpalcsc (about 80%) and Tibeto-Nepalcsc (about
20%), representing considerable intermixture of Indo-
Aryan and Mongolian racial strains; country divided
among many quasi-trihal communities
Religion: only official Hindu Kingdom in world,
although no sharp distinction between many Hindu
and Buddhist groups; smull groups of Muslims and
Christians
Language: 20 mutually unintelligible languages
divided into numerous dialects; Nepali officiul
language and lingua franca for much of the country;
same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5%
industry; great lack of skilled labor','6cf9c799266ee2dd92613060120136d5a8006fd01e47561c197889573438f82f','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5a2d82c0bb6863e7e0a781ed7fa7a89888617d921b630bb7ec6de99fded9a04',1975,'NC','New Caledonia','people-and-society',358,'Population: 133,000, average unnual growth rate
3.8% (7/61-7/72)
Nationality: noun — New Culcdonian(s); adjec-
tive— New Caledonian
Ethnic divisions: Mcluncsiun-Polyncsian ud mix-
ture, over 28,000 Europeans of French extraction
Religion: natives 90% Christiun
Language: Mclanusian-Polyncsian dialects
Literacy: unknown
Labor force: size unknown; Javanese and
Tonkinese laborers were imported for plantations and
mines in pro- World War II period; immigrant labor
now coming from Wallis Islands, New Hebrides, and','9c200873a5dedd5115e7625c482dfa5668f079ab3b110d08d1db764f7df93c71','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('682eb32e5ca0d4fe99705faccb6f8d304ccbf9b11358125a345d36bc5297a187',1975,'PF','French Polynesia','people-and-society',359,'Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
NEW CALEDON I A/ NEW HEmilDES
Organized labor* unorganized
Population: 95,000, average annuul growth rate
2.5% (7/68-7/73)
Nationality: noun — New Hcbridcan(s); adjec-
tive— New Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3%
European, remainder Vietnamese, Chinese, and
various Pacific Islanders
Religion: most at least nominally Christian
Literacy: probably 10% -20%','5131d575a518be8fdcea6f49887692480b7a5583ce58dbac334915c66bb094a1','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4075e654199c5973d0749c88626cdbbf349c73879a5951f8fd6a5a28fc7e863f',1975,'NZ','New Zealand','people-and-society',366,'Population: 3,092,000, average annual growth rate
2.2% (1/73-1/74)
150
Nationality: noun — New Zeulunder(s); adjective —
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified;
1% Hindu, Confuciun, and other
Literacy: 98%
Labor force: 1,021,800; 13% agriculture, 36%
manufacturing and construction, 9% transportation
and communications, 18% commerce and finance,
6% services, 16% administrative and professional, 2%
unspecified (I960 figures)
Organized labor: 36% of lubor force','91f414260d9566e02afab60d634037c4b825461a7a9a93fcb778b12cfdec42e8','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfe8e8e3271beb18531b2f3eaa18359b064c033d070e37fe369866b1585c6d4d',1975,'NI','Nicaragua','people-and-society',368,'Population: 2,153,000, average annual growth rate
3.3% (7/70-7/74)
Nationality: noun — Nicaraguan(s); adjective —
Nicaraguan
Ethnic divisions: 69% mestizo, 17% white, 9%
Negro, 5% Indian
Religion: 95% Rmnun Catholic
Language: Spanish (official); small English-
speaking minority on Atlantic coast
Literacy: 50% of population 10 years vA age and
over
Labor force: 620,000 (1974 cst.); 50% agriculture,
12% manufacturing, 14% service.'';, 24% other;
shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force','e388c80c15c19cb6d9e7255742b6a6eeb9545ec16489bd6affdb6b29d606ff23','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8496a8058a5691c110407333b5f497d4c56abe767e4a011bf14dd74a570c52a',1975,'NE','Niger','people-and-society',372,'Population: 4,599,000, average annual growth rate
2.7% (7/70-7/74)
Nationality: noun — Nigerois (sing, and pi.);
adjective — Niger
Ethnic divisions: main Negroid groups 75% (of
which, Hausa 50%, Djcrma and Songhai 21%);
Caucasian elements include Tuareg, Toubous, and
Tnmachcks; mixed group includes Fulani
Religion: 80% Muslim, remainder largely animists
and a very few Christians
Language! French official, many African lan-
guages; Itausa used for trade
Literacy: about 5%
Labor force: 20,000 wage earners; hulk of
population engaged In subsistence agriculture and
animal husbandry
Organized labor: negligible','5a29759182f37eb2ffbe4eb2c57c8d75e84ed3346f01317f38d3eff559b1f1af','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e2fe113122f17a0881de6396b3cd9afb4f2a976c69df8343887f4402c37762',1975,'NG','Nigeria','people-and-society',376,'Population: 63,022,000. average unnual growth
rate 2.9% (current)
Nationality: noun — Nigcriun(s); adjective —
Nigerian
15*1
Ethnic divisions: 250 tribal groups, of which most
important are Iluusu-Fulnnl (north), Ibo and Yombu
(south); these 3 tribes total over 60% of population;
about 27, 000 non-Africans
Religion: 47% Muslim. 34% Christian, 19% other
Literacy: cst. 25%
language: English official; llausa, Yombu, and
Ibo also widely used
Labor force: approx. 22.5 million; about 41% of
total population; roughly 1.3 million wage earners, of
whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners,
approx. 2.4% of total labor force, belong to some 700
unions','7f735664c56b8ee2cda3b7307bebeca3d280b4eb83141937adf2e4ae5b73e29b','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb99e43e208949fdecb3493bf5c814834860b1de4ed75716ed1a1b7a08acfea',1975,'NO','Norway','people-and-society',380,'Population: 4,014,000, uverage annual growth rate
0.7% (7/73-7/74)
Nationality: noun — Norwegian(s); adjective —
Norwegian
155
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Ethnic divisional homogeneous while population,
small Lappish minority
Religion: 00% Evangelical Lutheran, . 4% other
Protestant ami Homan Catholic, \\% other
Language: Norwegian, small Lapp and Finnish-
speaking minorities
Literacy: 00%
Labor forcct 1.0 million; 10.5% agriculture,
forestry, fishing, 27.0% mining and manufacturing,
0.5% construction, 13.3% commerce, 11,0%
transportation and communication, 17.7% services;
1.0% unemployed
Organized labor: 00% of labor force','f0c03a510742161613466b93452ce31b73bfe07df5b1bb9875e0addf932e0dc9','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4b3198ee668fb8a641b872c134b5505399a8ca72ca59c9c5432c2f3a7ae494d',1975,'OM','Oman','people-and-society',384,'Population: 497,000, average annual growth rate
2.9% (current)
Nationality: noun— Omani(s); adjective— Omani
Ethnic divisions: almost entirely Arab with small
groups of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','909312cc6af1bc6c5c1de476f0f7822306c4caf95b84d1a6a1455f93ceb37836','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55b8d3b8561c4d9fdea59641db511a30482315b4e6a27b10e3265aea7212c180',1975,'PK','Pakistan','people-and-society',388,'Population: 70,938, 000 (excluding Junagurdh,
Manavadur, Gilgit, Bultistun, and the disputed area
of Jammu-Kashmir), average annual growth rate
3. 1 % (current)
Nationality: noun — Pakistani(s); adjective —
Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages
-7% Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu,
9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (cst. 1961); 60%
agriculture, 16% industry, 7% commerce, 15% service,
2% unemployed
Organized labor: 5% of labor force','ef95f170525d86e7284a8b911cfcb935de66fcf5720e1e95f384c5e72654f481','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6257a9a390f60d5363a526a6fe4250ebdf8d6d91e3af3a22a5c037af76c512f',1975,'PA','Panama','people-and-society',392,'Population! 1,668,009. average annual growth rate
3.1% (7/73-7/74)
Nationality! noun— Paiuiinaiilan(s); adjective—
Panamanian
Ethnic divisions: 70% mestizo, 14% Negro, 9%
white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder
mainly Protestant
Language: Spanish; about 14% speak English as
native tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and
over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and
fishing; 9.7% manufacturing and mining; 6,8%
construction; 5% Canal Zone; 3.9% transportation
and communications; 1.2% utilities; national average
of 6.8% unemployed; shortage of skilled labor hut an
ovcrsupply of unskilled labor
Organized labor: 8.4% of labor force (1972 cst.)','b65329fb0e9111180f434f59a7b805993ca56d520df31780574de96aaa8ae9cc','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab4f68505aeb635b99978a7a707f3c869e7e4da739bb56d42e42948de416b366',1975,'PG','Papua New Guinea','people-and-society',396,'Population: 2,805,000, average annual growth rate
2.8% (7/66-7/72)
Nationality: noun— Papua New Guincan(s);
udjectivc — Papua New Guinean
160
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July Improved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
PAPUA NEW (WINE A
(SH mtf Vl‘f}
Ethnic divisions] predominantly Melanesian and
Papuan, some Negrito, Micronesia::, and Polynesian
types
Religion] over onc-half of population nominally
Christian (490,000 Catholic, 320.0(H) Lutheran, other
Protestant sects); remainder anlmist
Language] 700 indigenous languages; pidgin
English and 2 or 3 native languages are linguae
franeue for over onc-half of population; English
spoken by 1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly
subsistence farmers','f4ede6f4db2843f2aa796af2daad3dfaec8603e2ff81ed8b8f7756bdc7a3723f','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a905cbb2d004724d14d6b1903381195c9e5abdd22f994a6b8ed366a54223930b',1975,'PY','Paraguay','people-and-society',400,'Population: 2,547,000, average annual growth rate
2.7% (10/62-7/72)
Nationality! noun — Purugiiuynn(s); adjective —
Paraguayan
Ethnic divisions! 95% mestizo, 5% white and
Indian
Religion! 97% Homan Catholic
language! Spanish and Guarani
Literacy: officially estimated at 74% above age 10,
but probably much lower (40%)
Labor force! 800,000 (1971 est.); 55% agriculture,
forestry, fishing; 8% transport and other services; 19%
manufacturing and construction; 13% commerce und
professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force','a5bea714b4ff1de5d42758c9bfae34c863d243c37f84f32626640ea5d894f298','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a1f14dd71ea8b5ebb41697b60d80005ca63091ef5c271bca02faa507894092',1975,'PE','Peru','people-and-society',404,'PopulaCion: 14,819,000 (excluding Indian jungle
population which was estimated at 101,000 in 1961),
average unnual growth rate 2.9% (7/61-6/72)
Nationality: noun— Peruvian; adjective — Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (whitc-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Qucclma, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture,
17% services, 14% manufacturing. 9% trade, 4%
construction, 4% transportation. 2% mining, 4% other
Organized labor: 25% of labor force','5ec49ee1f2eecf85f995aad5092250bb33a0fda5665f50c6cfd5bb82fe8d08f6','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d3f80905e83245114478360e34a65da9f44b2422b76f30a5085e43bd1808349',1975,'PH','Philippines','people-and-society',408,'Population: 42,845.000, average annual growth
rate 3.3% (current)
Nationality: noun — Filipino(s); adjective — Philip-
pine
Ethnic divisions: 91.5% Christian Malay. 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Homan Catholic, 10% Protestant,
4% Muslim, 3% Buddhist und other
Language: Tagalog (renamed Filipino) is the
national language of the Philippine Republic; English
is the languugc of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry,
fishing. 12% manufacturing, 10.5% commerce, 10.5%
government and services (business, recreation,
domestic, personal), 3.5% transport, storage,
communication, 3% construction; 0.5% other','ebb7b2a0799dd09eb250c904ae147907fc4ff5597010112bc00b0176b94759ca','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09fd400a807e7179e67007565b95ee4606ca6583fb843eda1437cf4973995fa0',1975,'PL','Poland','people-and-society',412,'Population: 34,022,000, average annual growth
rate 1.0% (current)
Nationality: noun— Pole(s); adjective— Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians,
0.5% Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Cutholic (about 75%
practicing), 5% Uni ate, Greek Orthodox, Protestant,
and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26%
industry, 36% other non-agricultural','6ddea7a7b0fbd5866cece74b390cff6f1669e5d1cac544f4e460d2561acbd646','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc165e03afbe9d7670718a51b3b0c9023080a9749b4d4df74ef381ba4928ad28',1975,'PT','Portugal','people-and-society',416,'Population: metropolitan Portugal (including the
Azores and Madeira Islands, but excluding the Cape
Verde Islands) 8,499,000, average annual growth rate
—0.4% (7/70-7/73); Cape Verde Islands 270,000
(official estimate for 1 July 1972)
Nationality: noun— Portuguese (sing. & pi.);
djectivc — ■ ortugi^sc
167
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3 My ">75
Ktllllk'' (llviftloil*! linMIUgCIICOUS M f* 1 1 H ( * m M M Ml 1 1
stork In mulnhmd. Azores, Madeira InIiikmIh
Religion: 07% Homan Cull mile. I %- Protestant
sects, 2% ol hr r
Language: Portuguese
Literacy: (a figure considered high hy somr
m Hirers)
Iaibor forcfli 8.5 million (1071); 25''% agriculture,
31% Industry, 2d % services; 8% military, 12% other;
government rstlnmtrs that approximately 1 80.0(H)
persons or 5% of labor force are unemployed
Organized labor: about one-third of labor force Is
organized in trade unions; legislation promulgated
May 1075 unites unions under one confederation, the
Communist-dominated lotersyndlcal
Population: 693,000, average annual growth rate
2.9% (12/70-7/72)
Nationality: noun — Portuguese Timoran(s);
adjective— Pc, tuguese Timoran
Ethnic divisions: 95% indigenous Timorese
belonging to the Malay racial group; 9 ethnic
divisions, each speaking a distinct dialect of Malay
structure; approx. 4,600 Chinese and 10,000 ludfeuste*
Religion: 17% Christian (almost equally divided
between Catholic and Protcstunt), remainder practice
animism
Language: an estimated 9-15 dialects, of Malay
origin but mutually unintelligible; 75% of the
population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very
low; in 1971 total school enrollment was 35,000 out of
total school-age population of 80, (HH); 5% of natives
can speak Portuguese
Labor force: 90% engaged in primitive village
subsistence economy, 10% engaged us town laborers
and domestics','56fcac5c3d721b666548f633af4487ce327fbb71f4602ed31151e2d211de5e6b','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1978532aae0035d8c10eb7f075d26966908662fbca10b1956ec3ef01bf10b310',1975,'QA','Qatar','people-and-society',420,'Population: 185, (KK), average annual growth rate
10.8% (7/64-7/69)
Nationality: noun— Qatari(s); adjective— Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14%
Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10% -15%
Labor force: 48,000 (1969)
Population: 494,000, average annual growth rate
2.1% (7/70-7/73)
Nationality: noun — Reunionuis (sing. & pi.);
adjective — Rcunionais
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French, African,
Malagasy, Chinese, and Indian origin
Religion: 94% Homan Catholic
Language: French (official). Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high
seasonal unemployment
Population: 6,314,000, average annual growth rate
3.5% (7/68-7/74)
Nationality: noun — Rhodesian(s); adjective —
Rhodesian
Ethnic divisions: 96% African, 3% European, less
than 1 % Coloreds and Asians
Religion: 51% syncretic (part Christian, part
animist), 24% Christian, 24% uni mist, a few Muslim
Language: English official; Chishonu and
Sindcbclc also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including
some migrants from Zambia und Malawi), 108,000
Europeans, Asians, and coloreds (people of mixed
heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 40% transport and services
Organized labor: about one-third of European
wage earners are unionized, but only a small minority
of Africans (1966)
172
Approved For Release 2002/07/03
CIA-RDP86T00608R0006001 00003-3
July loftpproved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
IUIODESIA/ HOMAN I A','b3c8a1ab96d30495f5e06cf327c6c43a1b1ed941ba1c461d25b531d772066cd6','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5574cd11658a8506bdd7e4771f281c033f9a53a7e40fe18e1ff68f872695cfd7',1975,'RO','Romania','people-and-society',424,'Population: 21,245,000, average annual growth
rate 1.0% (current)
173
.Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : Cl A-RDP86T00608R0006001 00003-3
July 1975
Nationality: noun — Romunian(s); adjective —
Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian,
2% German, 3% other
Religion: M million Romanian Orthodox, I million
Roman Catholic, I million Protestants, 100,000 Jews,
30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (cst. 1 July I960); 57%
agriculture, 19% industry, 24% other nonagricultural','fc062ef1b343cd6d2e108fe28629a8b37d01b8d3943697e31101c171b679effd','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5089542030696b63be4bfc0723b16b71d13207dfcdaa0302a388213ffd865921',1975,'RW','Rwanda','people-and-society',428,'Population: 4,241,000, average annual growtli rate
2.0% (7/72-7/73)
Nationality: noun— Hwandan(s); adjective—
Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1%
Muslim, rest animist
Language: Kinyarwaru"^ and French official;
Kiswubili used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','fb0a0f3c41e4945b1dde52f6fffc5578b07fc76c5d2f4ac181a0a28686929da6','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72e2416c8675b6e18b20474f9ed28e0afefb1a9ccaa43e3fbe32d16addfbc9e9',1975,'AI','Anguilla','people-and-society',432,'Population: 68,000, average annual growth rate
1.2% (4/60-4/70)
Ethnic divisions: muinly of African Negro descent
Nationality: noun — Kittsian(s), Nevisian(s),
Anguillan(s); adjective— Kittsian, Ncvisian, An-
guillan
Religion: Church of England, other Protestant
sects, Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (I960 est.)
Organized labor: 6,700
Population: ii9,000, average annual growth rate
1.6% (4/60-4/70)
Nationality: noun — St. Lucian(s); adjective — St.
Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Homan Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (I960); 50% agriculture;
unemployment 30%-35% (1975)
Organized labor: 20% of labor force
Population: 94,000, average annual growth rate
1.1% (4/60-4/70)
Nationality: noun — St. Vinccntian(s) or Vin-
centian^); adjective — St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian
and Carib Indian
Religion: Church of England, Methodist, Roman
Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1072 est.); about 00%
unemployed
Organized labor: 10% of labor force','430c8beeb3be43b08d7dc284ac7d48994a703b235a9e762cf1eaab32493249e2','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfafc2a597ab8f2adb8d456769df4874d4edda166401fde89777cac9f5bc02a8',1975,'SM','San Marino','people-and-society',436,'Population: 19,000 (official estimate for 30 June
1974)
Nationality: noun — Sanmarinese (si rift. & pi.);
ad j ret i ve — San ma ri nesc
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation
of Sanmarinese Workers (affiliated with ICFTU) has
about 1,800 members; Communist-dominated
Camera del Lavoro, about 1,000 members','fb0df41dc0bfbef09a9db9f2991fe7bbf9b14a0417336a4f2a82de019b030ddb','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e0a3027431694bf72cf87879a9c8a4f630f918de5b1376b5855807dee64f33d',1975,'SA','Saudi Arabia','people-and-society',440,'Population: 6.087,000, average annual growth rate
2.8% (current)
(Sn ttUttnif mtp VI
Nationality: noun — Saudi(s); adjective— Saudi
Arabian or Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asrn (est. )
Religion: 100% Muslim
Language: Aruhic
Literacy: 15% (est.)
Labor force: about 25% of population; 40%
agriculture and herding, 12% construction, 12%
service, I2%- government, 1 1 % commerce, 13% other','23bd15c85a93b8f48c048b7b15e2008951ec7032c335c63e9a9bce97462225d3','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c0b7ac59c9fede77ccc422019e6330c3eab422f30672b5451cc259a19fec792',1975,'SL','Sierra Leone','people-and-society',445,'Population: 2,25t,(HH), average annual growth rate
I 05 (7/73-7/7-1)
Nationality: noun — Singaporan(s); adjective —
Singaporan
Ethnic divisions: 70.25'' Chinese, 155 Malay, 75
Indians and Pakistani, 1.85 other
Religion: mnjnrits n| ( ,’hinese are Buddhists or
atheists; Malays neadv all Vlnslini; minorities include
Christians, Hindus, Sikhs, TauMs, Cotifiieianists
laingiiuge: national language is Malav; Cliinese,
Malay, laiml. and English are official languages
Literacy: 705 (1070)
lailinr fort''!*: 171.718, 0 55 agriculture, forestry,
and fishing. 0.15 mining and quarrying. .''12 25
maniilaetiiring, 50 15 services, ,5.25 roust na tion,
21 55 commerce, 0.85 transport, storage, and
coiuumuieatintis
Organized labor: 215'' of labor force','62142f0f2105419555cebdf977df704060a578575a8fb95e89ca9b39262f9220','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7d400de89df5e64ff95b2f72d32d32d81d7d7efff24af078fe05a214e57532d',1975,'ZA','South Africa','people-and-society',451,'Population: 24,904,000, i verage annual growth
rate 2.0% (7/75-7/74)
Nationality: noun — Smith Alriean(s); adjective —
South African
Ethnic divisions: 17.8% while, 69.9% African,
9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and
African; 60% of Africans are anirnlsts
language: Afrikaans and English official. Africans
have mans vernacular languages
Literacy: almost all white population literate;
government estimates 55% of Afrieans literate
I^ibor force: 8.7 million (total of economically
active, 1970); 55% agriculture, 8% manufacturing,
7% mining. 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); nonwhites have no
bargaining power
Population: 889,000, average annual growth rale
2.2*7 (current)
Nationality: noun— South West Alrican(s);
adjective — Soul''ll West Alriean
Ethnic divisions: M‘7 white, 81*7 Africans. 5*7
Colored (imilattocs); almost half tin* Africans belong
to Ovamho trihe; Damara trihe has almost *15.000
members; I lerero, ( )kavango, Naina tribes have about
00.000 members each
Religion: whites predominantly Christian,
nonvvhites either animist or Christian
Iamguage: Afrikaans principal language ol about
70*7 of white population. Corman of 22*7 and English
of 8*7; several African languages
Literacy: high bo while population; low lor
nonwhile
I*ahor force: 205.800 (total of economically active.
1070); 08*7 agriculture, 15*7 railroads. 18*7 mining,
•1*7 fishing
Organized labor: no Irade unions, although some
while wage earners belong to South African unions','394fa7694f8a41277073edc0e59ee3f1c330d07318e87bf070f51722bcb5d56b','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8190787f06fa2bedd412bb60b66835e54dfcb8c3c9acb6b6cb11487bbc24be45',1975,'ES','Spain','people-and-society',455,'Population: 83.500.000 (including the Balearic and
Canary Islands; also including Alhuccmas. Ceuta.
Cliafarinas. Mehlla. and lVnon tie Velez de la
Camera ). average annual growth rate LI *7 (current)
Nationality: noun — Spaniard(s); adjective —
Spanish
Ethnic divisions: homogeneous composite of
Mediterranean and Nordic types
Religion: 09*7 Homan Catholic. 1*7 other sects
Language: Castilian Spanish spoken by great
majority; hut 17*7 speak Catalan. 7*7 (Galician, and
27r Bastpie
Literacy: about 90*7
Labor force (1973): 12 7 million; 25* / ngrieiiflmr,
30*7 industry. 30 *7 services; registered unemployment
is 2.l*i nl labor force, in reality about 4*7
Organized labor: 007 nl labor force in compulsory
government -cont tolled sMidicatcs
Population: 70.000 (estimate for 1971)
Nationality: noun— Spanish Saharan(s); adjec-
tive— Spanish Saharan
Ethnic divisions: 7 1.5*7 Aral), Berber, and Negro
nomads; 28.5*7 Spanish
Religion: 72(7 Muslim, 28(7 Catholic
Language: Spanish (official), local Arabic or
Ilassania
Literacy: among Spanish, probably nearly 100*7;
among nomads, perhaps 5(7
Labor force: 12,000; 50*7- agriculture. 50*7 other
Organized labor: none','77121a575da5a8b71cf3cd1e8c24f854aaa84761a7f032c3e4ef867d58ddd6dd','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a2b66ba506a226db4a8fdc03968162a0c4b605b92fd655c91c8419af927a6d',1975,'LK','Sri Lanka','people-and-society',459,'Population: 13,763.000. average annual growth
rate l.9''7 (7/70-7/7''])
Nationality: noun — Ceylonese (sing, and pi);
adjective — ( Ceylonese
Ethnic divisions: 71m Sinhalese. 21*7- Tamil, 6''7
Moor, 2J7 other
Religion: 01 ''7 Buddhist. 20m Hindu. 9r7
Christian, 6(7 Muslim, 1*7 other
language: Sinhala official, spoken by about 70m
of population; Tamil spoken by about 22rf; English
commonly used in government and spoken by about
10 57 of the population
Literacy: H2% (1070 est.)
Labor force: I million; I7T7 unemployed,
employed persons — 53. -I ft agriculture, I 1.877 mining
and mamifacttiring. 1 2.-1 Tr trade and transport. JO.-ITr
services and other
Or^nizcd labor: 43/f of labor force, over 50ff of
which lunploved on tea, rubber, and coconut estates','fd73104fe07b15e1298371199b437612db7d800bca0a537a46e86e6ec1708477','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0deab23dabddd26ee6dcfe8ed2c768ee7cd4d853e7b6794f17247522188e2f1',1975,'SD','Sudan','people-and-society',463,'Population: 17.758.000. average autuir '' rowlh
rate 2 5% (7 ''73-7 74 )
Nationality: mum Sudanese (sing ai
adjective— -Sudanese
Ethnic divisions: 39% Arab. 6% ileja. 52% Negro.
2% foreigners. 1% other
Religion’ 73% Sunni Muslims in north, 23%
pagan. 4% Christian (mostly in smith)
language: Arabic. Nubian. Ta Bedawic. diverse
dialects of Nilotic, Milo- 1 l.imitie, and Siidanic
languages. English; progr.un of Arabization in process
Literacy: 5% to 10%
iaibor force: 5 8 million; 85% agriculture. 15%
industry, commerce, services, etc , labor shortages
exist for almost all categories of employment
Population; 8 I 0,7000 iacM|M'' MimM.ll glow lit late
O 1 7 ( t ««r f •'' nl I
Natinuality i mom Sssrdels). mljttliw N v\\ «-« It*. | p
| . limit'' divisions: hnumgrtM •« » i »•- ss 1 1 i f «■ pMpul.tl ini,
in. ill I .uppish miMMiih
Religion: 0.*''. I7amv lii .il Lutheran, 7 7 other
Pit tit ''.l.illl . Ilniu.i M Culhnlir. I .stem Orthodox I 7
other
Ijutguaget Sssttlisli, small Lapp ami I nine-h
.pe aking miiiiint i«*s
Literacy: 007
|j»l»or Inrcci I .0 million 0 17 agriculture. Inresltv .
1 1 % 1 1 1 1 1 1* 20 27 minim'' ami maim! at tmiiii''.. 7 27
(onvlrmtiim. I ''x I.’, enmmrrrr. 0 77 transportation
ami I ttiiw.''.mn limns. 20 87 snxiirs im Indim/.
gnserniio-nl. 77 banking 2 7 unrmplnsrd
Orgutvijrd lul»or: 807 o( labor font''','bbc1ab3e5af90de2898eb87996d6abcd217fb537254ff833ef20782521594e1a','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609ba35154110a37e3674265df812d5ab569769e1b4d028472bcdced75c0da6a',1975,'CH','Switzerland','people-and-society',466,'Population: 0..>2 |. (KM), average annual growth rate
0.7 *7 (7/72-7/7.7)
100
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
swn/.l III. ANI)
July 1075
Nationality! noun Swiss (sing A pi ). ad|n live
Sw is*.
I''.tlltMC (livisloilM lllldi | M 1 1 1 ! 1 1 ; 1 1 1 ( 1 1 1 09b'' ( •«'' t II lil 1 1 .
Ml1'' French. 10b lliiliiin. lb lii uiiii fist’ll, I * • other .
Swiss ii 1 1 iutiiils 7l*i German. 20b French. I'',
I In tin li. t 1 i ItoniiillM 1 1 . I S'' ntliri
Religion; 55b Protestant. |0b limn. in ( 1 1 1 10) i « ’
Languages Swiss notion. ds 7 IS German. 20b
I mull. IS llalioii, IS Ihimotisch. IS other. total
| h »| ml; ilinti t»!IS German. IDS’ French. IDS
1 1 ;• litif I. I S Itomonsch. I S t it )»«*«
Literacy: 98b
lad>or force: ''10 million, ohont om* fifth foreign
workers, most I \\ Italian. llib oglicult lire and forest r\\ .
17''; ini I ns! r\\ and trull s. 20 S'' trade ami trails
(Mutation. Vi'' prolessinns. 2b in pulilie serviee.
I0S domestic and other, no significant itnemplm
"lent shortage <>l hoth skilled and unskilled labor
(>.•557 unfilled vaeaneies in April 1072
Organized labor: 20 b of labor force
COVKNNMKNT
Legal name: Swiss Confederation
Type: federal republic
Capitul: Hern
Political subdivisions: 22 cantons (A divided into
half cantons), a local referendum held in Hern Canton
in 1975 indicated that three districts wished to form a
separate canton for a portion of the French-speaking
Jura region
I -egul system: civil law system influenced In
customary law. constitution adopted 1871, amended
since, judicial review of legislative acts, except with
res peel to Federal decrees of general obligators
character, legal education at Cniversities of Hern.
Geneva and Lausanne, and four other university
schools of law. accepts compulsory ICJ jurisdiction,
w it h reservations
Branches: bicameral parliament has legislative
aiithoritx. lederal council (Huridcsrat) lias executive
authority, justice left chiefly to cantons
Government leader: Pierre Gruber (I -year term as
President began on January 1975). President
Suffrage: universal over age 20
Flections: held every I sears, next elections 1075
Political parties and leaders: Social Democratic
Parts (SI’S), Arthur Schmid, president. Radical
Democratic Party (LDP). Ileuri Schmitt, president.
Christian Conservative People’s Party (GVP). Lranz
Josef Kurmarm. president; Farmer, Artisan, and
Middle (.lass Party (BCH). Hans Con/ett, president;
Communist Part, (PdA). Jean Vincent, leading
Secretariat member; Republican Movement (RKP).
National Action (N.A.), James Sell warzen bach
Voting strength (1071 election): 19 seals LDP. I t
seats ( VP. Hi seals SPS. 25 seats RGB. 5 seals PdA. i
seals N A . 7 seals HLP, 22 seats others
Cniuiiiiinists: 5.500. 50.851 voles in 1971 election
Member of: ( if o| L.nrope. FITA. LAO.
I A I1, A. ICAO, ILA. 01(1) Seahrds Committer. 1 1 N
(permanent observer), WHO. WMO
1’npnlutinn: 7,3 15 (MX), average annual growth rate
3.3b (7/73-7/71)
Nationality: noun Svrian(s); adjec tive Syrian
Ethnic divisions: 00.3b Arab; 07b'' Kurds,
Armenians, and other
Religion: 70.5b Sunni Muslim. 10.3b other
Muslim sects, 13.2b Christians of various sects
Language: Arabic, Kurdish. Armenian; I1 tench ami
English widely understood
Literacy: about 10b''
Labor force: 2 million; 07b agriculture. 12b
industrv (including construction). 21 b miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5b of labor force
Population: 15,149.000. average annual growth
rate 2.7''V (7 73-7 74)
Nationality: mum — Tanznniau(s); adjeetixe —
Tanzanian
Ethnic divisions: 90S native Africans consisting of
well over 100 tribes, |\\ Asian. European, and Arab
Religion: Tanganyika — 40''. animist. 30r,
Christian. 30f; Muslim; Zanzibar — almost all
Muslim
language: Swahili English and official English
Primary language of commerce, administration and
higher education; Swahili widely understood and
generally used for communication between ethnic
groups, first language of most people is one of the
local languages
Literacy: ! 5*7 -205''
Labor force: under -100,000 in paid employment,
over 90rf in agriculture
Organized labor: 15*7 of labor force','f1d06fc2d16b002b2f65691ff207647a42f8117fabf353d12b20a5bab8bdc345','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20513fbfe8e992bef89a4c1033632a594786fd1335d5e3d4c443d3adb692175c',1975,'TH','Thailand','people-and-society',470,'Population: 12. 208. 000. average annual growth
rale 5 I 5 (7 75-7/71)
Nationality: noun — Thai (sing & pi. ); arljeelive h>
Thai
Ethnic divisions: 755 Thai. 115 Chinese. 115
minorities
Religion: 05.55* Buddhist. 15 Muslim, 0.55
( hristian
loinguagc: Thai; English secondars language of
elite
Literacy: 705
I«ahor force: 785 agriculture. 155 services. 75
indust r\\','3bd98a6182377d73d9b300e9c095849cc0296e86303c5a902696286ef7ad0472','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5da82c173844532ed0985a9dbc3eaa81444c2c4b38c02b2eee355aa81e383b79',1975,'TG','Togo','people-and-society',474,'Population: 2.222,000, average annual growth rate
2.0V,'' (1/70-1/72)
Nationality: noun— Togolese (sing. & pl,);
adjective — Togolese
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in smith and Cabrais in north;
under IV, European and Syrian- Lebanese
Religion: ahout 20V,'' Christian, 5V,'' Muslim, 75V,''
animist
language: Fiv-nch. both official and language of
commerce; major African languages arc Ewe and
Mina in south and Dagoma. Tim, and Cabrais in
north
Literacy: 5V,‘ to 10V,''
Zaibor force: over 00f7 of population engaged in
subsistence agriculture; about 50, (MM. wage earners,
evenly divided between public and private sectors
Organized labor: less than half of wage earners
divided among 2 major and several minor unions','f831722555a376a142569dba99f5477cd22173fa8e96b073564c3fbbfaff39fe','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83e843a86c9088a5622a55b7717fd34387d821060686b5046772072d86f07c9f',1975,'TO','Tonga','people-and-society',478,'Population: 97.000, average annual growth rate
2.6% (7/67-7/78)
Nationality: noun — Tongan(s); adjective — lougan
Ethnic divisions: Polynesian, about 800 Europeans
Religion: Christian; Free Wesleyan Church claims
over 80,000 adherents
Language: Tongan, English
Literacy: 90% -95%; compulsory education for
children between ages of 6-14
Labor force: agriculture 10,808; mining 500
Organized labor: unorganized','8732a96f5a50423932b6f407816290058f90d59526e29f64b1f9ac394514bb17','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f7b0cdeac3d2c983ef9c0da15a2e96b3eb9608836bdd82a85a372682dd314f',1975,'TT','Trinidad and Tobago','people-and-society',482,'Population: 1,013,000, average annual growth rate
1.3% (4/60-4/70)
Nationality: noun — Trinidadiun(s), Tobagan(s);
adjective — Trinidadian and Tobugan
Ethnic divisions: 43% Negro, 40% East Indian,
i4% mixed, 1% white, 2% other
I St* nlupnct m»p II)
Religion: ?6.8% Protestant, 31.2% Homan
Catholic, 23% Hindu. 0% Muslim, 13% unknown
language: English
Literacy: 89%
I-ah»r force: about 376,000 (1973 est ), about
15.4% agriculture. I8,7%> mining, quarrying, and
manufacturing, 16.7% commerce; 16.2% construction
and utilities; 7.4% transportation and com-
munications; 21.8% services, 3.8% other
Organized labor: 30% of labor force','f18e0692b95f09c07080a1d10df853244048f33171d871e3ae8a32034c988d9e','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('555f311409d1efb00199ae46e2888fea259bb1099ef31d2c2e6e2cae32dd943c',1975,'TN','Tunisia','people-and-society',486,'Population: 5,770,000, average annual growth rate
2.4% (7/73-7/74)
Nationality: noun — Tunisian(s); adjective—
Tunisian
Ethnic divisions: 98% Arab. 1% European, less
than 1% Jewish
208
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July I1>7r,
rVSIHA/ IMIKI V
Religion: 07'', Muslim. C, < In ivf hm . I''* i%li
lainguayei A f u1 (i« (ollu iul). A i ii I »i* and I t** im Ii
(cnlilOiricr )
Literacy: about 10''*
Labor form I l million. t7\\ agii< nlhin , Pi''.
itinnnlu< Iminy and i onstrnctinn, 7''* trade and
finance 3''* transportation. comuniniralions. iiml
utilities. 22* minim’. 27'', underemployed. shortage of
skilled l.ilior
Organized labor* 10''. of labor lour, Cetietal
( t nion of I unisiaii Wntkeis (IT I T). subordinate In
Destourian Socialist Parts','3c815661f857f6ebe5c9ec191c9f12999d15201de12b8eee4c31f6298f90dc4f','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('766555bf949ef33c464e96e1fddf26959f1a6238fe40d4fd5b1ccd38f90dc40f',1975,'UG','Uganda','people-and-society',490,'Population: 11,510.000. average annual growth
rate 31 *7 (c urrent )
Nationality: noun — Fgandan(s). adjective —
Cgandan
Ethnic divisions: 005 African. I 5 European.
Asian, Aral)
llcliginn: about 005 nonnnalls ( lirrhan. 55 ftp,
Mir, Inn. rest .unmisl
language: English official I Uganda and Sss.ditli
widr|\\ used, other II. min and Nilotic languages
Literacy: ahoul /O''r 10''.
Ijihor four: estimated I 5 million of ulmh
.ihont / iO.OOO m paid lahor. remaining, m suhsistencr
at 1 1\\ dies
Organized lahor: 1/5 000 muon members
COVEHNMKN T
l^egfll name: Itcpuhhc of t ganda
''lype: repuhhc independent since October I0(i/
Capital: Kampala
Political subdivisions: |0 pm-, inces and U districts
Ia*gal system: based on English common lass and
customary law. n institution adopted 1007. present
government rules despotic alls . has intimidated
judicial officials and has made constitution of no
consnpience. legal education at Makcrerc I''liiversity.
Kampala, accepts compulsory ICJ jurisdiction. with
reservations
Branches: (Gen Amin rules }>y decree, assisted hy
( .mined of Ministeis and Defense* ( louiicil. a group of
military officers
(Government leader: (Gen Idi Amin. Preyjdent
Suffrage: universal adult
Elections: none scheduled hy military government
Political parties: none
Communists: possihls a less svinpathi/ers
Member of: AEDB. Commonwealth. EAC. IAEA.
If - AO. II. O. ()Al\\ Seaheds Conirnitter. l? N .
UNESCO. WHO
Population: 251.0 IS. 000. average animal growth
rate I '' « (( orient I
Nationality: mmn Soviet(s). adjective Soviet
Ethnic divisions: 715 Slavic, 205 among some 170
ethnic groups
Religion: 705 atheist. 185 Russian Orthodox. 05
Muslim. 15 other
lamguagc? more than 200 languages and dialects
(at least |H with more than 1 million speakers). 705
Slavic group. 85 other Indo-European. 115 Altaic.
35 I''rali. m. 25 ( aiiirasiun
Literacy: OS 55 of poptd ,«''inn (ages 0- Ml)
Iaihor force: civilian 120 million (107 1). 275
agriculture. 735 industry and other non agricultural
fields. imeiuploN ed not rc|H»rted. shortage ol skilled
labor rejwirtcd
C;()VERNMENT
I^egal name: Onion of Soviet Socialist Republics
Type: ( aiumnmid state
Capital: Moscow
Political subdivisions: 15 union republics. 20
autonomous republics. 0 krays, 120 oblasts, and H
autonomous oblasts
l.egal system: vivil law system as modified bv
Communist legal theory, constitution adopted 1030,
no judicial review of legislative acts; legal education
at IK universities and 4 law institutes, has not
accepted compulsory 1CJ jurisdiction
Branches: Council of Ministers (executive).
Supreme Soviet (legislative). Supreme Court of
U S S R, (judicial)
Government leaders: l^ennid I. Bre/.lmev, General
Secretary of the Central Committee of the Communist
212
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Jm)v |f)75 Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
r VS H / I ''M I I I) AH All I.MIHA IIS
Parts, Alekvev N Kosvgiu. ( hairman o| I In* ( « m if t« ll
of MIiiMmv Nikolas V Pmlgnrnsv. ( hairman n| the
Presidium nl I lif'' l'' S S |( Supreme Smn l
Silllragn 1 1 1 1 1 v < '' r *• 1 1 1 river age IS. direi I, «''< |
Fleetioim in Supreme Snvii 4 even 1 sear.. 1.517
deputies elected iti 1 117 I. 7.! 23 parts members
Political parties anil leaders: ( iminmiml Parts ol
ill** Sfivlfl ( ’tilon (( !|’SI 1 ) mtl\\ p.irl v p« r 1 1 1 H I ( « I
Voting strength (1970 election)! 153.237.112
persons over IH. claimed 99 905 voted
Communists: 1 .7.000. (MK) pml\\ members
Olhrr political nr pressure groups: Komsomol.
Ir.ulr unions, and nllirr organizations which facilitate''
< oimmmlsl control
Member of: ( IM A (o urs a Disarmament
Conference. IAEA. KAO. II, O. IMCO. ITC.
Seaheds Comniiller. V N . I’NESCO. CPU. Warsaw
Pact. WHO. \\VM( ). Cniveisal ( !op\\ right * .onsenliou','770ca2897f7712ea6d3926bdf863fd39b0009537cfad5aac5ac890af91187a49','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a2c729feb531b501d9303fccb2e2ccb365d3601eb2add7ccff79f8841fcd7c9',1975,'AE','United Arab Emirates','people-and-society',492,'Population: 1711,000 (census nl 15 March 10 April
\\WH)
Ethnic divisions: Arabs 72''/ . others t ncT u< li*
Iranians. Pakistanis, and Indians
Hcligion: Muslim 9(Pi , ( iliiislian. Hindu and oilier
r;
laingmigc: Arabic
Literacy: 20*7 est
Labor force: 155,000(1075)','ec437fbe93754e286a6f1195acb80c6d1dc8f306ec5cd81ed6c01f3bc8c9bdc5','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecdbfe0bdd03e1bb35eb3ed0d7a7411d4900f580b4ae2b0bf81ea976fc602664',1975,'GB','United Kingdom','people-and-society',498,'Population: 5,t)8(i1(MM), average annual growth rate
2 2 % (7/71 7/72)
Nationality: noun Upper Yoltan(s), adjective
Upper Ynltnn
Ktlmic divisions: more than 50 tribes, principal
tribe Is Mnssl (about 2 5 million), other important
groups are Curimsi, Senuln, I, obi, Bobo. Maude, and
Itrlani
Religion: majurilv of population animist, about
20% Muslim. 5% Cliristian (mainly Catholic)
language: French official; tribal language* belong
to Sudunie family, spoken by 50% of the population
Literacy: 5% -10%
Iaihor force: about 95% of the economically active
population engaged in animal husbandry, subsistence
(arming, and related agricultural pursuits; about
80, (MM) are wage earners; about 20% ol male labor
lorce migrates annually to neighboring countries for
seasonal employment
Organized labor: 8 primnrv and several small
specialized unions
Population: 4, 004. (MM), average annual growth rate
1.2*7 (7/74-7/74)
Nationality: noun l 1 rugua\\an(s I; adjective —
Uruguayan
Ethnic divisions: 85*7-90*7 white. 5*7 Negro, 5b-
10*7 mestizo
Religion: 66b Roman Catholic (less than half
adult population attends church regularly)
language: Spanish
Literacy: 90.5*7 for those 15 scars of age nr older
I>ahor force: 1.01 5. 500 (1964 census); of those
employed in important sectors — 25*7 government,
54*7 industry; 1 0b service; 25*7 other; 8*7
agriculture, forestry, fishing and mitring; no shortage
of skilled labor
Organized labor: .damt 25''7 of labor force (largely
Communist influenced)
Population: 1 .000 (official estimate for I July 1964)
Ethnic divisions: primarily Italians hut also many
other nationalities
Religion: Homan Catholic
Language: Italian. I*atin, and various modern
languages
Literacy: virtually complete
218
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July u$PProved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Vatican ci /t/ Venezuela
Idibor force: approx. 700; Vatican City employees
divided into 0 categories — executives, officeworkers,
and salaried employees
Organized labor: none
Population: 11,980,000 (excluding Indian jungle
population estimated at .''12,000 in 1001), average
annual growth rate 3.0% (7/73-7/7*1)
Nationality: noun-Venezueian(s); adjective—
Venezuelan
Ethnic divisions: 07 % mestizo. 2 1 % white, 10/7
Negro, 2% Indian
Religion: 01 % nominally Roman Catholic
language: Spanish
Literacy: 7*1% (claimed, 1970 est.)
Labor force: 3 million (1909); 24% agriculture, 0%
construction, 17% manufacturing, 0% transportation,
18% commerce, 25% services, 4% petroleum, utilities,
and other
Organized labor: 15% of labor force
Population: 24,323,000, average annual growth
rate 2.0% (current)
Nationality: noun — North Vietnamese (sing. &
pi ); adjective— North Vietnamese
Ethnic divisions: 85%-90% predominantly
Vietnamese; ethnic minorities include Muong, Thai,
Meo, and Man
Religion: Confucianism, Buddhism. Taoism.
Catholicism
Ijunguagc! closely corresponds to the hreukdov/n of
ethnic groups
Literacy: claimed to he 95% (1901)
I''flbor force*: (I January 1970) 9.0 million, not
including military; about 70% agriculture and I0%>
industry
Population: 20,813,000, average annual growth
rate 2.6% (7/65-7/71)
Nationality: noun South Vietnamese (sing At
pi ); adjective South Vietnamese
Ethnic divisions: 87 7% Vietnamese, 0% Chinese.
3 2%'' mountain tribesmen. 2 9% Khmer, 0 2% Cham
Religion: 70%'' Ituddbist (at least 5% I loti llao). 5%
Can Dai, and 10%''- Catholic, others include animlst,
ami small numbers of Protestant. Muslim and Nimbi,
most buddbisls are of Mabavaiia school or practice
combination of !tuddhis,:\\ Taoism, and Confucian
ism
language: Vietnamese, French. Chinese. English,
Khmer, tribal languages (Mon- Khmer and Malavo
Polynesian). Cham (Malavo Polynesian dialect)
Ijilmr force: civilian work force 5 8 million (not
including tinned lorees), 67% agriculture, fishing, tine)
forestry; 15% industry and commerce; 0% domestic
and personal services; 5% government; 19%
unemployed
Organized labor: 500,000','42725132730525f7b665e0cda9fc64c106cbffcde58772cc57d7585fb079d4ea','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925fca34340d18dd9cfcd01ab705ffbe7c3dea56e4872cda838b0ceae97766d9',1975,'WF','Wallis and Futuna','people-and-society',500,'Population: 9.<MH). official estimate for I Jn!\\ 197’$
Nationality: noun Wallisian(s). Intmian(s). or
Wallis and Futuna Islander, adjective Walhsj.in.
I'' oilman, or Wains and Futuna Islanders
Fthnic divisions; almost entirely Polvnesian
Religion: largelv Homan Catholic
Population: 1.14.000. average annual growth rate
2,49 (7 /fit -7/74)
Nationality: noun— Western Samoan(s), adjec-
tive— Western Samoa
Ethnic divisions: Polynesians, about 12. CKH)
Knronesians (persons of European and Polynesian
blood). 700 Europeans
Religion: 99.79 Christian (about half of
population associated with tin* London Missionars
Society)
language: Samoan (Polynesian). English
Literacy: 819 -909 (education compulsors for all
children from 7-1.1 years)
Labor force: agriculture 19.14ft; mining and
manufacturing 1 .7 Hi ( lOfil )
Organized labor: unorganized','13cc0144d4241e925df11eb4cea9c07236538ccde232aacc54e51251c44015c1','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1a3a07161330d0819342fdddd7466c505da19f7224143690d0553e26d095206',1975,'WS','Samoa','people-and-society',506,'Population: 1 ,64 1 ,000n average annual growth
rate* 2.7''7 (7/75-7/74)
Nationality: noun — Yemeni(s); adjective — Yemeni
Ethnic divisions: almost all Arabs; a few Indiiins.
Somalis, and Europeans in Aden
Religion: Muslim
language: Arabic*
Literacy: probably no higher than 1 0r# ; Aden 55r«
(est.)','7009e2bac6f87c570eefcf9043c4229dd3f9933261ec2054cd107db4b8630137','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7fe05470b20e7c23200a0f3dbc03f28ea05a938d603263aaf81557a040ff366',1975,'YE','Yemen','people-and-society',510,'Population: 0,539. (MX). average annual growth rate
2.0*7 (7/71-7/72)
Nationality: noun — Yemeni(s). adjective — Yemeni
Ethnic divisions: 90*7 Arab, 10*7 Afro-Arab
(mixed)
Religion: 100*7 Muslim
Language: Arabic
Literacy: I5?r (est.)
Labor force: almost entirely agriculture and
herding
Population: 2 1 .3 10,000, avriogc annual growth
rati1 0 0b (current)
Nationality: noun Yugoslav(s). adjective
Yugoslav
Ethnic divisions: 307*7 Serb. 22 lb Croal. S .lb
Muslims. 8,2*7 Slovene, 5.8b Macedonian. 2 5b
Mnntenegrin. 6 4b Albanian. 2 3b llimgarian. I O'',
other (1071 census)
Religion: lib Serbian Orthodox. 32b Homan
Catholic. 12*7 Muslim. 3b other. 12b none (10.53
census)
lautgituge: Serho-( ao.it ian, Slovene, Macedonian
A III anian, Hungarian, and Italian
Literacy: 80 3b (1061 )
Labor force: 13.5 million (1070); 40. fib
agriculture. 10b mining and mamifactiiring. 34.4b
other nonugricultiiral activities; reported iinernploy-
ment averaged 8b of registered labor force (social
sector) in 1007
Population! 24,899,(HM). average annual growth
rate 2 H[''v (7/7.''l 7/7*1)
Nationality! noun - Ziiirljm(s); adjective Zairian
Ethnic divisions: over 2<M) African ethnic primps,
t In* timlorily are Hautii; four largest tribes Motion,
Luba, Kongo (till Itantu), tiiul tin* Muugbetu A/.iiik It*
( ! liimltic) make up iilmut 15/7 of the population
Religion] 51ft Christian, 45ft uniniist, 4ft other
Language: French, English, Lingula, Svvnliili.
Klkoiigo, mid Chilulm art* all classified as official
languages
Literacy] 5 ''7- fluent iu French, about 55-7 have an
acquaintance with French
Iaibor force: about H million, but only about 13ft
in wage structure','237e707ff24c1bff0f6a978350674d08f28051819dba6f32214cea301d3cf826','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0897438ee23fc21fb77b45d655b5561349f743e7f657007af3469710b17b77c3',1975,'ZM','Zambia','people-and-society',512,'Population: *1,870.000, average annual growth rah*
2.3% (7/73-7/7*1)
Nationality: noun — Zainbian(s); adjective —
Zambian
Ethnic divisions: 98.7 r7 African, 1.1/7 European,
.2% other
Religion: 82*7 aniinist, almut \\1% Christian, and
under 1% Hindu and Muslim
Language: English official; wide variety of
indigenous languages
Literacy: 2H%
Labor force: *102,000 wage earners; 375.000
Africans, 27.0(H) non-Africans; 15/7 mining, 9*7
agriculture. 9% domestic service, 19T7 construction.
9% commerce, 10T7 manufacturing. 23*7 government
and miscellaneous services, (Y7 transport
Organized labor: HM).(MM) wage earners, primarily
in industrial sector, are unionized (early 1908)','ee5800da000640fe3d29ed25094658cbc5225b01d7ddafb3689c9c789b945bbe','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b756c2de9f360c91e588b1372255cb8fe8d49c2b347276a9d7f708d0745e2dc',1975,'US','United States','people-and-society',516,'Population: 213,450,000, average annual growth
rate 0.7% (current)
Ethnic divisions: 87.2% white, 11.3% negro, 1.4%
other
Religion: total membership in religion*, bodies,
131 .43 1.000. Tmte.lant 7 1.0 10.000, Homan Catholic
48.400.000, lewish 0.115,000, other religions
3.84 1 .301
language: English, predominantly
Literacy! almost complete
laibor force: 93 million (1974)
Organized labor: 21 8''’; of total (1972)','f2366026f8184476330a61c68b2e60622e75c8546866eb57966d27dd82001ffe','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ed6620a72429f5e2894fbd9eb128fa336919d537b6a0b5db7c3784c17757813',1975,'AF','Afghanistan','people-and-society',4,'Population: 19,147,000, average annual growth
rate 2.3% (7/72-7/73)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 255 Tajiks, 9%
Uzbeks, 9% Hazaras, minor ethnic groups include
Chahar, Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim,
1% other
Language: 50% Pushtu, 35% Afghan Persian
(Dari), 11S Turkic languages (primarily Uzbek and
Turkmen), 10% 30 minor languages (primarily
Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-
8050 agriculture and animal husbandry, 20-25%
commerce, staall industry, services; massive shortage
of skilled labor
Organized labor: none','7881369a2623ceac03bc0439a74a8e0bc95b9511ebd450518e530b7b82e8d72c','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c03698a8cf5df148d2f9df9476f04e89d3f28cc58febad0ddd7a8f5b5460cc92',1975,'RO','Romania','people-and-society',9,'Population: 2440 1.000, average anncal growth pate
Qe (current)
Nationality:
Alboserndaas
Kthnte divisions: 060 Albanian, rennatiatiagy de are
Greeks, Vinchs, Gypsies, and Brlpuardians
Religion: 708 Mastin, 206° Albanian Onthodes,
10% Roman Catholle Cobserssinees prohibited,
Albsanita elajms to be the world’s first athedst state)
Language: Albanian, Greek
noun -Albuniant, adjective
Literacy: wbout 70%. no teliable current statisties
available, bat probably greathy tiiproved
Labor force: 11.000 (1969), G55 agriculture,
ITO industry, 21.65 other nonagricultaral
P-pulation: 21,245,000, average annual growth
rate 1.0% (current)
173
te
soy
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
{See selerence map lV)
Nationality: noun—Romanian(s); adjective—
Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian,
2% German, 3% other
Religion: 14 million Romanian Orthodox, | million
Roman Catholic, | million Protestants, 100,000 Jews,
30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57%
agricultare, 19% industry, 24% other nonagricultural
Population: 24,409,000, average annaal growth
rate 2400 (7/T3-7/74)
Nationality: noun -—Zairlan(s), adjective Zain
Ethnic divisions: over 200 Afflean ethnic groups,
the majority ace Bantu four largest tbes Mongo,
Luba, Kongo (all Banta), and the Mangbetu-Agande
(anttio) make up about 45% of the population
Religion: 50 Christhan, 45° animist, 47 other
Language: French, English, Lingala, Swahili,
Kikongo, and Chiluba are all classified as offieial
Languages
Literacy: 5° fluent in French, about 85° lave an
seqnaintince with French
Labor force: about 8 million, but only about 13%
in wage strretare','f9a11d9c8b376faf388ac8a7d3329d4cb79de4ee0d653567c05777bb3182c501','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d50b94a17e73cf8e1946f8ea67cdd446a00b4d2c7f69059af462c76c41e8452e',1975,'AD','Andorra','people-and-society',16,'Population: 19,000 (official estimate for 1 July
1969)
Nationality:
Andorran
Ethnic divisions: Catalan stock; 30% Andorrans,
61% Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French
and Castilian
Labor force: unorganized; largely shepherds and
farmers','9ff358e49014bcce731e53c2293e363d495791778289f5986bd88ca3c3b7e0e0','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22eb6ebc6f18efc674fbc3734db30c7a119909c48f213a67e8200625444af490',1975,'AO','Angola','people-and-society',20,'Population: 6,099,000, average annual growth rate
1.69% (12/60-12/70)
Nationality: noun—Angolan(s); adjective
Angolan
Ethnic divisions: 935 African, 5° Europeans, 1%
mestizos
Religion: about 845% animist,
Catholic, 4% Protestant
Language: Portuguese (official), many native
dialects
Literacy: 108-155
Labor force: 2.6 million economically active
(1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 80,000, average annual growth rate
2.6% (4/60-4/70)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
ANTIGUA/ARGENTINA
Nationality: noun—Antiguan(s); adjectlve—
Antiguan
Kthnie divisions: almost entirely Afrlean Negro
Religion: Chureh of Mngland (predominars j, other
Protestant sects and some Roman Cathoile
Languages English
Literacy: about 80%
Organized labor: 18,000
Population: 1,346,000, average annual growth rate
2.5% (current)
Nationality: noun—Congolese (sing, pls adjec-
tive-~Conpolese of Congo
Ethnie divisions: about 15 ethnic groups divided
jnto some 75 tribes, almost all Bantu; most lmportint
ethnic groups ure Kongo (489) in south, Teke (17%)
in-center, M''Bocht (1250) and Sangha (20%) in north:
about 8,500 Europeans, mostly French
Religion: about: half animist, half nominally
Christian, less than 1S Muslim
Language: French official, many African lan-
guages with Lingala and Kikongo most widely used
Literacy: about 206%
Labor foree: about 40% of population economl-
cally active, most engaged in subsistence agriculture;
70,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16° of total labor toree (1965
est.)','88d882a11614b98e6104af1aba1eb93ef3a64a25c4f14c33d366163b4863309c','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03ffda15b3a4f16d9aca8998371f23553fc7f184ce7fc50fc7ca4170118e4a28',1975,'AU','Australia','people-and-society',27,'Population: 15,57-4,000, average annual growth
rate LSS (7/66-7/74)
Nationality: noun—Australian(s); adjective—
Australian
Ethnic divisions: 99% Caucasian, 1% Asian and
aborigine
Religion: 98% Christian, 2° animist and others
Language: English
Literacy: 98.5%
Labor force: 4.76 million, I agriculture, 32%
industry, 387% services, [57 commerce, 2% other
Organized labor: 44° of labor force
(See seference map Vil}
Ethnic divisions: 459% Javanese, 119 Sundanese,
7.5% Madurese, 7.5% Coastal Malays, 26% other
Religion: 90% Muslim, 49 Christian, 2%
Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay)
official; English, and Dutch leading foreign languages
Literacy: 6096 (est.); 729% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15%
industry, 1596 miscellaneous and unemployed
Organized labor: 10% of labor force
Population: 33,200,000, average annual growth
rate 3% (1/71-1/72)
Nationality: noun—Iranian(s); adjective—Tranian
Ethnic divisions: 635° Ethnic Persians, 3% Kurds,
13% other [ranian, 189¢ Turkic, 3% Arab and other
Semitic, 15 other
Religion: 93% Shia Muslim; 5% Sunni Muslim;
2% Zoroastrians, Jews, Christians and Baha‘is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 37% of those 7 years of age and
older (1972 est.)
98
Labor force: 0.2 milflon; Ale aydeulture, 206
minufaeturiage: shortage: of skilled labor substantial
Organized daborn 3° of labor force
Population: 159,000, average annual growth rate
23% (7/64-7/74)
Nationality: noun—Western Samoan(s),adjec-
tive-—Western Samoa
12.000
Enronesians (persons of European and) Polynesian
blood), 700 Europeans
Religion: 99.7% Christian (about) half of
population associated with the London Missionary
Society)
Ethnic divisions: Polynesians, about
Language: Samoan (Polynesian), English
Literacy: 85° -90% (education compulsory for all
children from 7-15 years)
Labor force: agriculture 19.148; mining and
manufacturing 1,716 (1961)
Organized labor: unorganized','44114faf654b4ab333895c6c4c9b0546cc34dc736e3c743de4c9a573657d07bf','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('931a3cae494c81a9a2b831947758fd797d0c2598fbdb7a72735c4f76eee987f9',1975,'AT','Austria','people-and-society',33,'Population: 7,575,000, average annual growth rate
0.490 (7/73-7/74)
Nationality:
Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian,
0.3% Slovene, 0.6% other
Religion: 855 Roman Catholic, 7% Protestant, 8%
none or other
noun—Austrian(s); adjective—
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
YUGOSLAVIA
(See toferenca map iV}
Language; German
Literacy: 98%
Labor force: 2,656,922 (1974); 18° agriculture
and forestry, 49% dadustry and crafts, 18% trade and
communications, 7% professtons, 6% public service,
20% other; 2.40% registered unemployed; an estimated
200,000 Austrians are employed in other Furopean
countries; foreign laborers in Austria number more
than 200,000 (1972); unemployment 2.1% (1972)
Organized labor: about 2/3 of wage and salary
workers (LOTE)
Population: 205,006, average arnual growth rate
3.0% (4/70-7/73)
12
UNITED
Atlantic Ocoan
ee
og
0 vs
tay 2 o-
, ~
co cd
Cornet pal gadis
fy.
Sa me ase
Caribbean Sea NEPUBLIC
(See teterence map tt)
Nationality: noun——-Bahamian (sing., pls adjec-
tive—Bahamian
Ethnic divisions: 80% Negro, 10% white, 10%
mixed
Religion: Baptists 29%, Church of England 23%,
Roman Catholic 239%, smaller groups of other
Protestant, Greek Orthodox, and Jews
Language: English
Labor force: 69,000 (1970); 25% organized','2e79181f0d443da8784f417f011ba5cd82c2d5eb1e0a4069d3a114d1ff661c07','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dcbbce00b6d5b7b38e4c0ddf463470e3f3b63147d2ba1dd0ea2f873d2d123e7',1975,'BH','Bahrain','people-and-society',37,'Population: 240,000, average annual growth rate
2.89 (2/65-4/71)
Nationality:
Bahraini
Ethnic divisions: 90% Arab, 796 Trantan, Pakistani,
and Indian, 396 other
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 4096 (1970)
Labor force: 60,301 (1971)','70f369c246e16c52dc83b2342d42168a34557ad46bcdc607eb1283ced8936622','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e86f38749cd2ad05879c0eb6fe23e4931f47db735b7b0d37d5c0fb1a135770f',1975,'CN','China','people-and-society',43,'Population: 73,746,000, average annual growth rate
2.8% (current)
Nationality: noun—Bengalee(s); adjective—
Population: 15,982,000 (excluding the population
of Quemoy and Matsui Istands and. foreigners),
average annual growth rate 1.8% (7/73-7/74)
Nationality: noun—Chinese (sing... pl.):
tive—Chinese
Ethnic divisions: 84°
Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucian-
ism, and Taoism; 4.5%C Christian: 2.35 other
Language: Chinese Mandarin (official language),
also Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 4.9 million; 33° primary industry
(agriculture), 32.15 secondary industry (including
manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972
Organized labor: about 12% of 1972 labor force
(government controlled)
adjec-
Taiwanese, 14% mainland
39
CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 :
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 107f
CHINA, REPUBLIC OF/COLOMBIA
COVERNMENT
Leyal name: Republic of Ching
Typer republic; one-party preddential regime
Capital Talpel
Politteal subdivisions: 16 counties, ti cithes, |
speclal municipality CPaipel)
Legal system: based oon civil law system,
combitition adopted 147, amended (G0 to permit
Chiang Kai-shek to be reelected, and anended: 1972
to permit President to restructure certain government
aris; accepts compulsory LCP jurisdiction, with
reservations
Branches: 5 independent branches (esecutive,
leyistative, judictil, plas traditional Chinese finetions
of examination and control), dominated by esecutive
brneh: President and View President elected by
National Assembly
Goverament leaders: President: Yer Chia-kan;
Premier Chiang Ching-kuo
Suffrage: universal over aye 20
Elections: national level — legislative yuan every 3
years but no general election held since 1948 election
on mainland (partial election for Taiwan province
representatives December 1969 and December 1972);
local level — provincial assembly, county and
municipal executives every of years, county aod
municipal assemblies every 4 years
Political parties and leaders: Kuomintang, or
National Party, led by Chairman Chiang Ching-kuo,
has no real opposition, 2. insignificant: parties are
Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly
election): 58 seats Kuomintang, 13> seats tne
dependents
Other political or pressure groups: none
Member of: expelled from UN. General Assembly
and Security. Council on 25 Getober 1971 and
withdress on same date from other charter-designated
subsidiary organs; attempting to retain membership in
international financial institutions
Population: 251,000 (official estimate for 1 July
1972)
Nationality:
Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
about one-half are Chinese
Language: Chinese 98%, Portuguese 25%
Literacy: almost 100% among Portuguese and
Macanese; no data on Chinese population
Labor force: 56 agriculture, 830% manufacturing,
3% construction, 19% utilities, 27% commerce, 8%
transportation and communications, 26% services
(1960 data)
Population: 42,298,000, average annual growth
rate BE (F T8-TITAD)
Nationality: noun—- Thai (sing. & plo: adjective —
Vhai
Ethnic divisions: 75% Thai, Li Chinese. TES
minorities
Religion: 95.5%
Christian
Buddhist, 46 Muslim. 0.56
Language: Vhai, English secondary language of
clite
Literacy: 70%
Labor force: 78% agriculture, LS services, 7%
industry','f133dd32a63d0d4342d12116093b183e4335d041ab895b023f696fe94e4dff1f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c423290a05781c2ca72acaef4f66c7a869f6389f08a16d59c4f4a1ad6e810eb4',1975,'BD','Bangladesh','people-and-society',44,'Ethnic divisions: predominantly Bengali; fewer
than t million “Biharis” and fewer than 1 million
tribals
Religion: abuut 839% Muslim, 16% Hindu; less
than 19% Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive un-
deremployment; over 80% of Jabor foree is in
agriculture','04179e440067fe9bda50aac4631ae8fbb925f859364ade5e65986952a9f38286','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8574289682ee1709183ac4a14fd0dd8b79cab45f4687f7480dbf6869cb443ce9',1975,'BB','Barbados','people-and-society',48,'Population: 239,000 (official estimate for 1 July
1973)
15
CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
BANHADOS/HELGUM
Natlonalitys Warbsclisn(sd, adjective —
Mareloectiaate
Kthote divistans: SO Afilean, 17S nibved, 4%
Mirrepean
Religion: Anglican, Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 905
Labor force: 97,090 (L973 est.) wage and: suliary
Cures
Organteed labor: 32%','9c764bcf35c2c8d83d8d359123a5f727c0a682187a1ff582294ce3781810454b','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f461c58b2ccb75585e74b21b702c0ab6675d1c9507721aae2e592670db7dff9',1975,'BE','Belgium','people-and-society',52,'Population: 9,792,000, average annual growth rate
0.2% (current)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 10
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
North Sea
(Soe retergace map {¥)
Nationality: noun Belyients, adjective. telpian
Ethnic divistona: 356 Blemings, G36 Walloons,
26 anived or other
Religions O70 Homan Catholic, 36 none or other
Languages Freneh, Flemish (Dutch Geamnan, in
small area of eastern Belpiain, divided alonye ethnic
lines
Literacy: U7:
Labor forces 4.0 million, approsimately 95% is
found tu the following, sectors: S20 manafacturiagse,
24 services, 16% commerce, banking. and insurance,
SS construction, 7.55 transportation and communi
cation, 4S aydeultare, forestey, and fishing. 125
mining, OKT public utilities and sanitans services
(1972). 6.0% unemployed. early 1975
Organized labor: 48°C of Labor force (1969)','6f2aea53a233328131286084092bb26944427947d58c6bd88fb2c5bf8960bd56','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7c39ff765a8a19d17875787dd6d4b3b91bbe77c6fc67daac73769e6edb5ed63',1975,'MX','Mexico','people-and-society',57,'Population: 158,000, average annital growth rate
2 (4 /60-4/70)
Nationality:
Belizean
Ethnic divisions: 51% Nein, 22° mestizo, 1%
Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-day Adventist, Methodist, Baptist, Jehovah''s
Witnesses, Mennonite
Language: English, Spanish, Mava, and Carib
Literacy: 70% -SO%
Labor force: 34,500, 39% agriculture, 14%
manofacturing, 8% commerce, 12% construction and
transport, 2057 services, 7% other: shortage of skilled
labor and all types of technical personnel; over 15%
are uncimploved
Organized labor: 8% of labor force
Population: 58,075,000, everage annual growth
rate 3.2% (current)
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo, 30% Indian or
predominantly Indian, 9% white or predominantly
white, 19% other
Religion: 97% nominally Roman Catholic, 3%
other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force (1973): 13.1 million (defined as those
12 years of age and older); 39.5% agriculture, 16.7%
manufacturing, 16.6% services, 16.8% construction,
utilities, commerce, and transport, 3% government,
7.4% unspecified activities
Organized labor: 20% of total labor force','181b99a94150200fee166ada7786da21b841bbb10d0a2360e3ee75e11343acd6','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eacefdcaf4b0b524cc516ef324db506970a1399b6576c2f12dc05b0e044733d',1975,'BM','Bermuda','people-and-society',61,'Population: 56,000, average annual growth rate
1.65% (1/68-1/74)
Nationality: noun—Bermudan(s); adjective—
Bermudan
Ethnic divisions: approximately 63% African, 37%
white
Religion: 47.5% Church of England, 34.2% other
Protestant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 24,855 (1974)','93c07debad018371c1ffb7817b7ace330128dc51696aca11b1e2ef3f05614804','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95f4571ddbd153d7b1a12b89d721dcbbc0698bf0630affc1d32e3d0619170f89',1975,'BT','Bhutan','people-and-society',64,'Population: 1,174,000, average annual growth rate
2.566 (Current)
Nationality: noun--Bhutanese (sing.. pl):
adjective —Bhutanese
Ethnic divisions: 60% Bhatias, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamuaistic Buddhism, 254 Bud-
dhist-influenced Hinduism
Language: Bhotias speak various Tibetan dialects,
most widely spoken dialect is Dzongkha, the official
language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99° agriculture, 1%
industry; massive lack of skilled labor','67651328f4a295dac64a57088fa792aa069198ec0a6cd91aa537768db5e82da4','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cfaccd79c2d99121d4a055d321caf172f4a6532cbc29f471965ba13dda2124e',1975,'IN','India','people-and-society',68,'Population: 5,272,000, average annual growth rate
2.6% (current)
Nationality: noun—Bolivian(s); adjective —
Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35°
mestizo, 5%-15% white
Approved For Release 2002/07/03 :
Pacific
Ocean
CHI
Population: 600,297,000 (including the Indian.
held part of disputed Jammu-Kashmir), average
annual growth rate 2.4% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian,
3% Mongoloid and other
Religion: 83.59 Hindu, 10.7% Muslim, 1.8% Sikh,
2.6% Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or
more persons each; numerous other languages and
dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of
30% of the people; English enjoys “associate” status
but is the most important language for national,
political, and commercial communication; Hindu-
stani, a popular variant: of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 3996; females 1856; both sexes 29%
(1971 census)
Labor foree: about 184 million; 70% ayriculture,
more than 10% unemployed end underemployed;
shortage of skilled labor is signifieant’ and
unemployment is rising
Organized labor: about 2.5% of total labor force','c86b5881c8162d662475fc7280870b27c625a3c044580d11380715b72313fcba','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4699a2a9f46ada60c2fe67c72f2df75f236168e0002bcffda2a6a5e2c86fc434',1975,'AR','Argentina','people-and-society',69,'{See retovonce map til}
Religion: predominantly Roman Catholie; active
protestant minority, especiilly Methodist
Language: Spanish, Aymara, Quechua
Literacy: 355 40%
Labor force: 2.5 million (1972), BOE agedeulture,
3.5% mining, (6% services and utilities, 8°
nuinafactaring, TOS other
Organized labor: 150,000-200,000, concentrated in
mining, industry, construction, and transportation
Population: 3.064.000, avenge annual growth nate
1.2% (0/73-7/74)
Nationality:
Uruguayan
Ethnic divisions: 85-90% white, 5° Negro, 37-
noun CUriagnavants): adjective —
10% mestizo
Religion: 66% Roman Catholic (less than duilf
adult population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 13 vears of age or older
Labor force: 1,015,500 (1963) census);
employed in important sectors — 25% government,
BAG 10% 23% so
agriculture, forestey, fishing and mining; no shortage
of skilled labor
Organized labor: alavut 25°) of labor foree (largely
Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modem
languages
Literacy: virtually complete
july ipproved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
VATICAN CLTY/VENEZUELA
_ATALY write
CN YUGOBLAV
bs
‘ettty’
N VATICAN
™“
. ALb
Tytthentan
Sea
Mediterranean
Sea','729d5e5b3ecdf8c380af35bd104c5d23a6fab988262bd4bdf674277cdd9af0ce','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a865acb76284a96c1b4f27ca712ee08afb1a0567fe7838c199b0a70baf14d666',1975,'BW','Botswana','people-and-society',71,'Population: 677,000, average annual growth rate
2.4% (current)
Nationality: noun—Botswana (sing. pl); adjec-
tive— Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1£%
European
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
BOTSWANA/BHATIE,
Religions 45° animist, Lot) Chaistian
Language: Africans speak Taste vermacuhar
Literacy: about 22° in Baytlish, about 32° dn
Tewsuias less han PS secondary seliool yradtistes
Labor force: $85,000, most ate engaged dn enttle
raising: und subsitecee agtieultitre, about Sf.000 bn
Internal cash economy, another GO000 spend at feast
GtoVomnonths per vearas veayte carters in South Aftbes
(tO71)
Organized labor: eight tride ridons organized with
atotal membership af approsimately 2000 (1972 est)','c3cbc652b1b08442a3ae4d1a07921781a46c9d4fc3d9aecb849016acfca14209','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f41902f7b3568ae4d928cbca3e65d1a5209c4a88bd68afe32a608e483bba233',1975,'BR','Brazil','people-and-society',75,'Population: 107,613,000, average annual growth
rate 2.85% (current)
23
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July L075
Atlantic
Ocean
BRAZIL )
a
ee ate
tee eelocvare map fits
Nationality: Bravzitian(s), adjective
Brasilia
Ethnic divisions: GOO white, 30% mived, 85
Negro, and 2° Pncian (1960 est)
Religion: 03% Roman Catholic (nominal)
Thats
Language: Portuguese
Literacy: 675 of the population 15 years or older
(1970)
Labor force: about 30 million in LOTO (est); 44.25
apdeullure, livestock, forestry, and) fishing, [7.8%
5.56 serdeces, transportation, and
communication, 8.9% soci
wetivities, 3.9% public administuvtion, 5.6% other
Organized Jabor: about 50° of labor force; only
about 1.5 million pay dues
Population: 140.000, average aoninal growth tate
Qe CT /67-7/79)
Nationality: noun. Uritish Solomon islanders),
adjective Witish Solomon Istander
Ethate divisions: OS.0% Melinestans, 0%
Polynesians, 15° Micronesians, 095° Chinese, 05%
Korapeans, O68 athens
Religion: almost all at least nominally Chiisthan,
Homan Catholic, Anglican, and Methodist churches
dominant
Literacy: 60%
(See tetecence mag tit)
Nationality: noun—French Guianese (sing, pl):
adjective—French Guiana
Negro or imuilatte, 5%
caucasian, 10,000 East Indian, Chinese
Kthnie divisions: 95%
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%,
censtrucdion 21%, agriculture IS, industry 8,
transportation 4%; information. on unemployment
unavailable
Organized labor: 7% of labor force','2b86b0e70de708d0d73927ab9354ad4045e317402fa083c981075ee7db520616','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f19d352b8964ee31c4fb7c7f33a32dfbdbc76c30e483048e8d38405df82f0789',1975,'MY','Malaysia','people-and-society',79,'Population: 155,000, average annual growth rate
33% (SPTL-T/7T3)
Nationality:
Bruneian
Ethnic divisions: 52°% Malays, 26% Chinese, 15"
indigenous tribes, 34 other
Religion: 60° Muslim (Isham official religion); So
Christian, 32° other (Buddhist and animist)
noun—Braneian(s): adjective —
Language: Malay and English official, Chinese
Literacy: 15%
Labor foree: 32.155; 30.5% agriculture: 32.8%
industry, manufacturing, and construction: 33.8%
trade, transport, services; 2.9% other
Organized labor: 8.4 of labor force','1459653381b73341687415eb3af255384137362ad60057cd7e7bcdbebac864c7','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8955ee43aba5e4f5728c5726ab66b1071bcd046eb2b7d9820ffa6a96b63f2aeb',1975,'BG','Bulgaria','people-and-society',83,'Population: 8,741,900, average annual growth rate
0.7% (enrrent)
Nationality; noun—Bulgarian(s); adjective —
Bulgarian
Ethnic divisions: 85.3° Bulgarians, 8.5°C Turks,
2.6% Gypsies, 2.5% Macedonians, 0.3°¢ Armenians,
0.25% Russians, 0.6% other
Religion: regime promotes atheism, religious
background of population is 85% Bulgarian
Orthodox, 13% Muslim, 0.85% Jewish, 0.76 Roman
Catholic, 0.5% Protestant, Gregorian-Azmenian and
other
Language: Bulgarian; secondary languages closely
correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.6 milllon (July 1973); 52%
gdeulture, 88% ladustry, 85°¢ other
Population: 30,429,000, average annual growth
rate 2.3% (7/70-7/73)
Nationality: noun—Burman(s); adjective—Bur-
mese
Ethnic divisions: 72% Burman, 7% Karen, 6%
Shan, 29% Kachin, 2% Chin, 2% Chinese, 9% Indian,
6% other ;
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have
their own languages
Literacy: 70% (official claim)
Labor force: 10 million; 679 agriculture, 13%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labur
organizations have been disbanded, and government
is forming one central labor organization','e0c603cd5e2802e06705c039798145eab63aafdc1fdb919c941e3ce44e23682f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b6a93802f4ca1721c5f4994f6274359cceb2a1d5c248dd111eb8452149af99',1975,'BI','Burundi','people-and-society',87,'Population: 3,777,000, average annual growth rate
2.4% (7/70-7/73)
Nationality: noun—Burundian(s); adjective—
Burundian
Ethnic divisions: Africans — 865 Hutu (Bantu),
13% Tutsi (Hamitic), 1% Twa (Pigmy); non-Africans
include (late 1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10%
Protestant); rest mostly animist plus small number of
Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili,
and 65 in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of
Burundi Workers (UTB), membership about 30,000,
affiliated with government party','862e0ce211a879b982d3f861e301a8c572a1b0001fdd313e34ef691218e2b224','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('419e26ea62faa4ee7f26187a48262e0bf19f72c560615d6e093bf390b3f4e193',1975,'TH','Thailand','people-and-society',91,'Population: 7,634,000, average annual growth rate
2.2% (7/68-7/69)
Nationality: noun—Cambodian(s) or Khmer
(sing., pl}; adjective—Cambodian or Khmer
Ethnic divisions: $9°% Khmer (Cambodian), 3°
Vietnamese, 55% Chinese, 35¢ other minorities
Religion: 95% Theravada Buddhism. 5% various
other
Language: Cambodian
Literacy: 55% (est.)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
|
vr cs a
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
CAM BODIA/CAMEROON','03992e6cd47661b8cd44f8c28f77042e36cecfd14fc1c192744f5c6a87ff2deb','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c6bd6984c2a444deb50732ba83402dd4e512915b041c0a3001b0a2ed661769',1975,'CM','Cameroon','people-and-society',95,'Population: 6,363,000, average annual growth rate
1.7% (7/68 -7/70)
Nationality: noun—Cameroonian(s); adjective—
Cameroonian
Ethnic divisions: about 200 tribes of widely
differing background; 31 Cameroon Highlanders,
19% Equatorial Bantu, 8f¢ Northwestern Bantu, LOS
Fulani, 7% Eastern Nigritie, 11S Kirdi, 13° other
African, less than 1% non-African
Religion: about) one-half animist, one-third
Christian; rest Muslim
Language: English and French official, 24 major
African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in
subsistence agriculture and herding; 200,000 wage
earners: (tmaximum) including 22,000) government
employees, 63,000 paid agricultural workers, 49,000 in
manufacturing
Organized labor: under 45% of wage labor force','15d18c2baa456b6da5a34032ea9334d4986e400cc31d9564fd6befe4b56d356f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df86cafe01b031748880662a98d900b3d1606bd071cfbc8fd1787e47ef2b3d9c',1975,'CA','Canada','people-and-society',100,'Population: 22,741,000, average annual prowth
nite soe (7/O0-7/74)
Natlonality: nown—-Canadlan(s); adjective ~
Cunadise
Ethnic divisions: 44% British Fades estyin, BOS
French origin, 26% other
Religion: 14% Protestant, 47% Catholle, 5% other
Language: Baglish and French official
Labor force: 8.4 million: 209% service, 226%
tanuhictucing, 16S trade, 84% transportation and
utilities, 62 agriculture, 65 construction, 8% other,
5% anemployed
Organized labor: 27% of labor force','9b3f6f2fb0a18376ca462ecc3fdbede4739bd329bfeec82d7eb0a0fc5a2cef52','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7343a98f97f1c92550a6e6c06a2cac6789b77f069985d435004f89670ae59c8b',1975,'CF','Central African Republic','people-and-society',104,'Populations 1,787,000, avepaye annual growth nite
2.2% (7/07-7/71)
Nationality: noun--Central African(s): adjective---
Central African
Ethnic dividons: approximately 80 ethnic groups,
the majority of which have related cthuie and
linguistic charmeterisdes; Banda (32) and) Baya-
Mandjia (20%) ase laggest single pproups; 6,500
Buropeans, of who 6,000 are French and majority of
the rest Portuyruese
Religion: 40% Protestant, 28 Catholle, 279
animist, 5° Muslim; animistic beliefs and: practices
strongly influence the Cliristhin majority
Language: French official; Sangho, the linjgua
franca and unoffichal national language
Literacy: estimated at 59-10%
Labor force: about half the population economi-
cally active, SO% of whom are in agriculture;
approximately 64,000 salaried workers
Organized labor: UC of labor force','ffa7cce7625eee1741a9a8b508d2a71eff60c9f9fa71e74335e9b63b9a251338','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67f0a52f2ce16ae4c4ae08db56feef00cef298bb6002bda6dcc9a1644e11d434',1975,'TD','Chad','people-and-society',108,'Population: 4,025,000, average annual growth nite
2° (7/71-7/72)
Nationality:
Chadian
Ethnic divisions: over 240 tribes representing 12
major ethnic groups: — Mustims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) ia the north and center and non-
Muslims (Sara, Mavo-Kebbi, and Chari) in the south,
some 150,000 nonindigenous, 5,000 of them French
half Muslim, 3°
noun—Chadian(s): adjective—
Religion: about Christian,
remainder animist
Language: French official; Chadian Anibic is
lingua franca in north, Sara and Sanho in south
Literacy: estimated 5°%-10%
Labor force: only 55% of population in
economically active group, of which 90° are engaged
in unpaid subsistence farming, herding, and fishing:
47,000 wage earners in industry and civil service
Organized labor: about 20% of wage labor force','10eb5f29923cdfcaa1f993549a25e8b39fe35f1aa25cc6ff3c112d040559b621','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f73a7bc8233e2a3ad145e8681a117400252f842e1becc7b8853360e6b62c104',1975,'CL','Chile','people-and-society',112,'Population: 10,584,000, avetaye annual growth
male 1.7% (7/73-7/74)
Nationality: noun — Chilean(s); adjective —
Chilean
Ethnic divisions: 95% European stock and mixed
Kuropean with some fndian admixture, 3° Indiin,
2% other
Religion: 80% Homan Catholic, LES Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.3 million (1973); 196 agricultural,
28% industry and construction, 206 services, EL
commerce, 55% mining, 5° other (1973)
Organized labor: 25% of labor force (1973)
Population: 942,012,000, average annual growth
rate 2.4% (current)
Nationality: nown—Chinese (sing, pl); adjec-
tive-—— Chinese
Ethnic divisions: 04° Han Chinese: 66 Chuang,
Uighur, Hui, Yi, ‘Tibetan, Mivo, Manchu, Mongol,
Pu-l, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most
important clements af religion are Confuchanism,
Taoism, Buddhism, ancestor worship: about 260-3%
Muslim, 1% Christian
Language: Chinese (Mandarin mainly: also
Cantonese, Wu, Fukienese, Amoy, Ufsiang, Kan,
Hakka dialects), and minority languages (see ethnic
divisions above)
Literacy: at least 25%
Labor force: 3385 million (mid-1966); 85%
agriculture, 155 other; shortage of skilled Jabor
(managerial, technical, mechanics, ete): surplus of
unskilled labor','f44267c2cf9b5f9c8222d2b614933e91ec0a01f31f819c9fd81b607ebc8cbf5a','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c45edb9c1e300ab821f7a179f491600565fdd7d329e6d0e2619a48ecbc5b945c',1975,'CO','Colombia','people-and-society',117,'Populations 22,217,000, average annual growth
nite S20 (current)
Nationality: noun-—Colombian(s) adjective—
Colombian
Ethnic divisions: 586° mestlzo, 20% caucasian,
14S mulatto, 49 Negro, 85% mixed Negro-Indian, U6
Indian
Religion: 055 Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 4766 agriculture,
13% manufacture, 186 services, 96 commerce,
138 other (L964)
Organized labor: 13% of labor force (1968)','da28debc78b41b37bdcdac62ce22902ca4c269563d91c0584805924dbb4f3fc2','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61b5a7a80cbebeafe9a4e2b4a828b1b174305008edcfd200b8809c069cefa5d5',1975,'MG','Madagascar','people-and-society',121,'Population: 261,000, average annual growth rate
2.0% (9/66-9/72)
Nationality: noun—Comoran(s); adjective—
Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural
Population: 7,553,000, average annual growth rate
2.3% (7/69-7/70)
Tananotlve
os
MADAGASCAR ©
ea
Indian Ocean
{See roterence map Vij
Nationality: noun—Mualagasy (sing. and pl;
udjective--Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Mylayo-Indonesian origin, consisting
of Merina (1,643,050) and related Betsileo (760,000),
on the one hand, and) coustal tribes with mixed
Negroid, Malayo-lndonesian, and Arab ancestry on
the other; coastal tribes fnelude Betsimisaraka
941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415.000; there are also 38,000) French,
66,000 other
Religion: more than half aninsist; about 4b
Chiristian, 76 Muslim ,
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 906 are
nonsalaried family workers engaged in subsistence
agriculture; of 175,000 wage and salary carners, 26%
agriculture, 179 domestic service, 155¢ industry, 145
commerce, 11% construction, 9% services, 6%
transportation, 25 miscellaneous
Organized labor: 45 of labor force','c2068ecf48e21e40c61de59f2115143887bda98c107f8879e1297ee3efe7b6bc','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f71e20f54ed88871a4e0d0aa036c5edc32da65baf38193f26ee6463b903d1daa',1975,'CK','Cook Islands','people-and-society',125,'Population: 21,000, official estimate for 30
September 1973
Nationality: noun—Cook Ishander(s); adjective.
Cook Islander
Ethnic divisions: $1.3%% Polynesian (full: blood),
7.7% Polynesian and Earopean, 7.7% Polynesian and
other, 2.4% European, 0.9% other
Religion: Christian, majority of populace members
of Cook Islands Christian Church','eae1b285aedcd51990a6ec055ac6c8ece1acc99d7e1f67947bc5d3034c0e0e6a','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1675aa7fa1bfd9169a40a714f4bf923f4f89486bae2f3720780a845102b698c5',1975,'CR','Costa Rica','people-and-society',128,'Population: 1,968,000, average annual growth rate
5% (current)
Caribbean Sea
Nera
ban Joxé
cast whys OR
Pacific Ocean |
(Seo relecsmie map tl}
Nationality: noun—Costa) Rean(s); adjective—
(losta Rican
Ethnic divisions: 98% white (including mestizo).
2c Negro
Religion: 956 Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 607,000 (1973); 46.35% agriculture;
13.2% manufacturing; 119 commerce; 8S construc:
tion, transportation, and communications; 21.596
other; shortage of skilled labor (1968)
Organized labor: about 11.59% of labor force','ee8cd67ed6198e608be60ceda81f009076ad462659a1f577632b5d9f64264515','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c96d316c54756e35c29d9330bbd09b4733ea2b123de7c48db11ac1057d825a8',1975,'CU','Cuba','people-and-society',132,'Population: 9,252,000, average annual growth rate
1.85 (current)
Nationality: noun—Cuban(s); adjective—Cuban
Ethnic divisions: 51 mulatto, 37% white, 11S
Negro, 1% Chinese
Religion: at least 85% nominally Roman Catholic
before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 3.4% agriculture, 1756
industry, 65 construction, 6% transportation, 29%
services, 8% unemployed and underemployed
Organized labor: 46° of total force','9581668b25a82598bc3a86a7d0c1569646aa9c1d93d592ab4f4ec7cbccf7f873','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d509e89a9b3bdbb3e35a5a1bd61191e65f737d1b08c6773c14988a20a5a7264',1975,'CY','Cyprus','people-and-society',136,'Population: 650,000, avenyge annual growth nite
Nida (7/72-7/79)
Nationality: noun--Cypriot(s); adjective: Cypriot
Bthnie divisions: 74% Greek: 18° ‘Turkish: 4%
Brith, Armenian, and other
Religion: 78% Greek Otthodox, 18 Muslim, 4%
Annentan Orthodox and other
Language: Greek, Turkish, English
Literacy: about 42% of population 7 years or older
Labor force: 267,000 (1970 est.), 3855 agoulture,
23% Industry, OF commerce, 25 mining, 28 ather;
3.130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,804,000, average annual growth
rate 0.8% (current)','da20487f00b95cc1ddf5e456d8726eb63f6cf15e9ff39ecf6c817edb3f0a8fa6','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f67095bad20022da4245b2629962fed838e1084437d0af98d3ffdb7663177a2b',1975,'PL','Poland','people-and-society',139,'{See toterence map 1V)
Nationality: noun—Czechoslovak(s); adjective —
Crechosloviak
Ethnic divisions: 65.0% Czechs, 29.2% Slovaks,
4.0% Magyar, 0.66 Germans, 0.59 Poles, 0.4%
Ukrainians, 03° others (Jews, Gypsies)
Religion: 77° Roman Catholic, 20% Protestant,
2°, Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18S agriculture, 376%
industry, ERC services, 34% construction, com.
munications and others
Population: 34,022,000, average annual growth
rate 1.0% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians,
0.59 Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox, Protestant,
and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor ferce: 16.3 million; 38% agriculture, 26%
industry, 36% other non-agricultural','0654b46f2860c75ac17f32963e0714f27693cd4176aa0655e8099c9bd7a489d1','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91452fa8edbefd2cc37d8834909ee4cacf0ed31ac403dd658aaf9fa017a84ed4',1975,'NG','Nigeria','people-and-society',144,'Population: 3,105,000, average annual growth rate
2.8% (8/72-8/74)
Nationality: noun- -Dahomean(s); adjective—
Dahomean
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
DAHOMEY/DENMARK
Ethnic divisions: 99% Africans (42 ethnte groups,
most Important being Fon, Adja, Yoruba, Barba),
5,500 Europeans
Religion: 12% Muslim, 8% Christian, 40% antinist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in
agriculture; 15% civil service, artisans, and industry
Organized labor: approximately 75% of wage
earners, divided among two major and several minor
unions
Population: 515,000, average annual growth rate
1.70 (7/66-7/70)
Nationality: nown—Gabonese (sing, plod adjec:
tive-—Gubonese
Ethnic divisions: about 40 Bantu tribes, including
Aoanajor tribal groupings (Fang, Eshin Mbede,
Okande); about 20,000 expatdate Afrlenis and
Kuropeans, including, 14,000 French
Religion: 55% to 75% Christian, less than ES
Muslin, remainder animist
Languages Freneh official language and medium
of instruction In schools: Fang isa ntiajor vernacular
language
Literacy: about 12%
Lahor force: about 280,000 of whom 74,000 ate
wage earners in the modern sector
Organized labor: less than 30° of wage labor force
Population: 63,022,000, average annual growth
rate 2.9% (current)
Nationality: noun—Nigerian(s); adjective—
Nigerian
154
ey
| Lager
Zee
{See totorsace mop Vi}
Ethnic divisions: 250 tribal groups, of which most
Important are Hausa-Fulind (north), Tbo and Yoruba
(south); these 3 tribes total over 609% of population;
avout 27,000 non-Afreans
Religion: 475 Muslim, 34% Christian, 19% other
Literacy: ost. 25%
Language: English official; Hausa, Yoruba, and
tho also widely used
Labor force: approx, 22.5 million; about 419 of
tetal population; roughly 1.3 million wage earners, of
whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners,
approx, 2.4% of total labor force, belong to some 700
unions
Population: 2,222,000, average annual growth rate
2.6% (1/70-1/72)
Nationality: noun—''fogolese (sing. & — pl.);
adjective—Togolese
Ethnic divisions: some 40 tribes; largest and most
imporkint are Ewe in south and Cabrais in north;
under 1% European and Syrian- Lebanese
Religion: about 20% Christian, 3% Muslim, 73%
animist
Language: Pieich, both official and language of
commerce; major African languages are Ewe ind
Mina in south and Dagoma, ‘Tim, and Cabrais in
north
Literacy: 5% to LO%
Labor force: over 90% of population engaged in
subsistence agriculture; about 50,000 wage carers,
evenly divided between public and private sectors
Organized labor: less than half of wage earmers
divided among 2 major and several minor unions','fd364266fb92530e24a4caedef5430b1cf332cb8cc081db78d7a0761d9ce77e8','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('205817d658f62ca93e6869ed998c6c70a4b6cde992c706d74019f5c615531aa2',1975,'DK','Denmark','people-and-society',148,'Population: 5,074,000, average annual growth rate
0.4% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 19% other
Language: Danish; small German-speaking
minority
Literacy: 995%
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing, 26.65% manufacturing, 8.3% construction,
15.7% commerce, 6.8% transportation, 5.6% services,
25.7% government, 1.8% other; 6.3% of registered
labor force unemployed (September 1974)
Organized labor: 65% of labor force
Populations 2,000) (preliminary total from the
census of 8 December 1972)
Nationality: noun—Falkland Islander(s); adjec-
tive—Falklind Island
Ethnic divisions: almost totully British
Religion: predominantly Chureh of England
Language: English
Literacy: compulsory education up to age 1
Labor force: 1,100) (estds over 95% (est.) in
agriculture, mostly sheepherding
Population: 572,000, average annual growth rate
1.8% (7/72-7/73)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8%
European, Chinese and others
Religion: Fijians mainly Christian, Indians are
Hindu with a Muslim minority
Language: English and Fijian (official), Hindu-
stani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force
organized into 22 unions; unions organized along lines
of work, breakdown by ethnic origin causes further
fragmentation','0f21b085d02b9cc053f2c0abededbf8dadd8c7a7497149786fa2891ceb47a943','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e89c59960ae821c6c8443ec4d2f6f6f0186608296835d71a39b934d92b634d8a',1975,'DM','Dominica','people-and-society',152,'Population: 76,000, average annual growth rate
1.6% (4/60-4/70)
Nationality: noun—Dominican(s); adjective—
Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England,
Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture
Organized labor: 25° of the labor force','0ab8311fe258288733b72353045de69171b6bc75bdc5c78ab24839169973736a','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4057c35b2c35bebe4271bbe0cc01aced6805e962876870679311d0ef546eff44',1975,'DO','Dominican Republic','people-and-society',156,'Populations 1,697,000, average annual ro wth nite
2. (7/72-7/73)
Nationality: noun—-Dominiean(s)s adjective--
Domintean
Kthnte divisions: 73 mulatto, 16S white, EL
Negro
Religion: 95° Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 millfon: 73% ayriculture, 4%
industry, LOS services and other
Organized Jabor: 12° of labor force','362190093fdf8209e83344b41e044b94f1112d301fbb2ad0f1aa4208f3f4e9f8','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ad47916950126a5356f3cdc16c55e16c080e151fa386c292a77cbeb1ca65467',1975,'EC','Ecuador','people-and-society',160,'Population: 6,705,000 (excluding nomadic Indian
tribes), average annual growth rate 2.95% (11/62-6/74)
Nationality: noun—EKcuadorean(s); adjective—
Ecuadorean
Ethnic divisions: 405¢ mestizo, 40% Indian, 105%
white, 55¢ Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority
nonpracticing)
CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
EQUADOR
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture,
139% manufacturing, 49% construction, 79% commerce,
49% public ddministration, 16% other services and
activities
Organized labor: less than 15% of labor force
Population: 37,335,000, average annual growth
rate 2.496 (current)
Nationality: neun- -Egypti« +);
Egyptian or United Arab Republic
Ethnic divisions: 90% Eastern Hamitic stock; 10%
Greek, Italian, Syro-Lebanese
Religion: (official estimate) 945 Muslim, 6% Copt
and other
1.570 ani, (1967), excludes
adjective —
Language: Arbic official, English and French
widely understood by educated classes
Literacy: around 40%
Labor force; 8 to 12 m''llion; 45% to 505%
avriculture, 10% industry, 10% trade aud finance,
30% services and other; serious shortage of skitied
labor
Organized labor: 1 to 3 million','9549cc88e436537e9780e06614700d69c151f3eacc2aaf6c0a55a306e82cedf9','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308c3670894bedd0ce3576c400428721f4e58e99ed94a88cdf32f05f55dcbdc0',1975,'GN','Guinea','people-and-society',166,'Population: 318,000, average annual growth rate
1.8% (7/68-7/69); Rio Muni, 223,000, average
annual growth rate 1.5° (7/68-7/69); Fernando Po,
93,000, average annual growth rate 2.6% (7/68-7/69)
Nationality: noun—Equatorial Guinean(s); adjec-
tive—Equatorial Guinean
Ethnic divisions: indigenous populstion of
Province Francisco Macias Nguema primaaty Bubi,
59
CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
EQUATORIAL GUINEA/ETHLOPIA
some Fernindinas; of Mo Mund primiacily Pang; some
300-400 Nigerians, mostly on Fernando Po; les than
1,000 Maropeans, primasily Spanish
Relighon: natives all nominally Christian and
predominantly
practices retained
Roman Catholic; some pagin
Language: Spanish official language of govern:
ment and business: also pidgin Bnglish, Many
Literacy: 125% (est.)
Labor force: most Equatorial Gulneans involved in
subsistence agriculture
Population: 4,415,000, average annual giowth rate
2.5% (current)
Nationality:
Guinean
noun—Guinean(s); adjective—
Ethnic divisions: 99% African (3 major tribes —
Fulani, Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25%¢ auimist, Christian, less
than 1%
Language: French official: cach tribe has own
language
Literacy: 5% to 10%; French only significant
written language
Labor force: 1.8 million, of whom less than 10%
are wage earners; most of population engages in
subsistence agriculture
Organized labor: virtually 1005 of wage labor
force loosely affiliated with the National Confedera-
tion of Guinean Workers, which is closely tied to the
PDG','c13c35985b35bec2078e101b2c1ab1f5d4a93c0b17c2df8f45b7def39a328788','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59c4bbd420a30c739102976f9ffcade45eca5fd4ede5196f6a86662077405e56',1975,'ET','Ethiopia','people-and-society',169,'Population: 27,948,000, average annual growth
rate 2.6% (7/73-7/74)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
(Soe seteronce map Vi}
Nationality: noun—Ethiopian(s); adjective —
Ethlopian
Ethnie divisions: Galla 40%. Amhara and Tigra
3256, Sidamo 0%, Shankella 6%, Somali 6%, Afar,
Gurage 2%, other 1%
Religion: 359-400 Ethiopian Orthodox, 40% 45%
Muslims, 155-206 animist, 59% other
Language: Amharic official; many local languages
wnd dialects; English major foreign language taught
in schools
Literacy: about 5%
Labor force: 905 agriculture and animal
husbandry; 105 government, military, and) quasi-
Population: 40,000, average annual growth rate
0.9% (4/66-11/70)
Nationality: noun—Facroese (sing... pl); adjec-
tive—Facroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
62
Languages: Faciwese (derived from Old Norse),
Danish
Literacy: 90%
Labor foree: 15,000; lungely engaged dn fishing,
mantfacturing, transportation, and commerce','5211b4a72f2738e03f59ecb347c476d431748fa329e7a144365d495d61a99680','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98ee2d39c36922a2c43ebf4cdc7fbc0c0a2854ef599cdc59239cafb7366eb7c1',1975,'FI','Finland','people-and-society',173,'Population: 4,701,000, average annual growth rate
0.490 (1/738-1/74)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 93 Evangelical Lutheran,
Orthodox, 1% other, 5% no affiliation
Language: Finnish 9256, Swedish 7%; small Lapp-
and Russian-speaking minorities
Se Greek
Literacy: 1%
2.2 million; 16.696 agriculture,
forestry, and fishing, 26.46% mining, and manufacture
ing, 8oAlo construction, 15.4% commerce, 6.8%
transportation and) communications, 4.06% banking
Labor force:
and finance, 20,1 services; 1.85 unemployed
Organized labor: 606 of labor force','9c9e53e1b295fb701b5ab8753f6e046f451d5b2a2415662d4963193488d56943','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae70b487872f835ccb5424706c56ab9cb2c60bd663473905ce6a1fb91e11ee13',1975,'FR','France','people-and-society',176,'Population: 53,034,000, average annual growth
rate 0.9% (7/69-7/7-4)
Nationality: noun—Frenchman (men); adjective —
French
Ethnic divisions: 45% Celtic; remainder Latin,
Germanic, Slav, Basque
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
Religion: 639% Catholic, 20% Protestant, 1 Jewish,
196 Muslim (North African workers), [36 unaffiliated
Language: French (00% of population); rapidly
declining reydonal puteis — Provencal, Neston,
Germanie, Corsican, Catalan, Basque, Flemish
Literacy: 17 6
Labor foree: 21,900,000 (est, in October 1974);
A7¢6 services, BOC industry, 129 agriculture, 24%
unemployed
Organized labor: 17% of labor force, 25.49. of
salaried labor force
Population: 5.853.000, .verage annual growth rate
2.8% (7/72-7/73)
Nationality: noun—Guatemalan(s); adjective—
Guatemalan
Ethnic divisiens: 41.4% Indian, 58.6% fadino
(mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the
population speaks an Indian language as a primary
tongue
Literacy: about 30%
Labor force (1974): 1.75 million; 65% agriculture,
11.3% manufacturing; 1L.2% services, 6.4458 to
commerce, 2.6% construction, 2.4% transport, 0.2%
84
mining, O26 electrical, 0.89% other, Unemployment
estimates vary from 3 to 25%
Organized labor: 4% of labor force (L974)','cc53ed47a7f02f5578fdfa8aaf61f7cf815cdac3705b7b118b5e9a09b154546b','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a34ae536252dd1ec0c249f0a609dd0a5ceda0787f3bf0d8ae1b5d543a96532d',1975,'GF','French Guiana','people-and-society',180,'Population: 55,000, average annual growth rate
2.4% (7/68-7/73)
68
tes
Atlantic Qcess1
FOENCH
GUIANA
“Cayenne','83f8d9916a9d6729ebd899fd718b42d4957d66ba8e80f16d329812ca3e4b5d23','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf5791e7ad9df4b74e032ec40b09025d7059a67d46437f38a2a1c7c019d924c',1975,'PF','French Polynesia','people-and-society',182,'Population: 120,000 official estimate for 1 July
1973
Nationality: noun—KFrench Polynesian(s), adjec-
tive—French Polynesian
Ethnic divisions: 785 Polynesian, 12% Chinese,
6% local French, 49@ metropolitan French
Religion: mainly Christian; 55°% Protestant, 326%
Catholic
Population: 125.000 (official estimate for 1 July
1967)
Nationality: noun—Afar(s), Issa(s); adjective—
Afars, Issas
Ethnie divisions: 59,350 Somalis (large number of
the Somalis are temporary immigrants fron Somalia,
not citizens of territory), 53,650 Afars, 6,000 Arabs,
7,000 French (inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely
used
Literacy: about 5%
Labor force: a small number of semiskilled laborers
at port
Organized labor: some 3,000 railway workers
organized
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
NEW CALEDONIA/NEW HEBRIDES
Organized labor: unorganized
Population: 95,000, average annual growth rate
2.5% (7/68-7/73)
Nationality: noun—New Hebridean(s); adjec-
tive—New Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3%
European, remainder Vietnamese, Chinese, and
various Pacific Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','18ad026403946785eff9b1065431c53ed50f38c7074e8daa8da3c3295adc63c8','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a34f89ec50d814c32f576b78bacf01a8e3c761ae77399401e86b5d1442f9ba0',1975,'GM','Gambia','people-and-society',186,'Population: 525,000, average annual growth rate
2.5% (7/68-7/74)
Nationality: noun—-Gambian(s); adjective—
Gambian
Ethnic divisions: over 99% Africans (Malinke
40.800, Fulani 13.5%, Wolof 12.9%, remainder made
up oof several smaller groups), fewer than 1%
Europeans and Lebanese
Religion: 85°C Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof
most wicely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in
subsistence farming; about 15.000 are wage eamers
(government, trade, services)
Organized labor: 25% to 30% of wage labor force
at most
Population: 16,885,000 (including East) Berlin),
average annual growth rate —0,2% (currert)
Nationality: noun—German(s); adjective—Ger-
man
Ethnic divisions: 99.75% German, .3% Slavic and
other
Religion: 53% Protestant, 8% Roman Catholic,
396 unaffiliated or other; less than 55¢ of Protestants
and about 25% of Roman Catholics actively
participate
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7%
handicrafts; 6.856 construction; 11.99 agriculture;
6.8% transport and communications; 10.1%
commerce; 16.8% services; 2.5% other
Mod 4
Organized labor: 87.7% of total labor force
Population: 62,155,000 (including West Berlin),
average annual growth rate 0.2% (current)
Nationality: noun—German(s); adjective—Ger-
man
Ethnic divisions: 99° Germanic, 16 other
Religion: 49°66 Protestant, 44.65 Roman Catholic,
6.4% other
Language: German
Literacy: 9956
Labor force: 26.7 million; 44.1% in manufacturing
and construction, 15.25 services, 12.89 commerce,
8.2% povernment, 7.2% agriculture, 5.4% com-
munication and transportation, 19% mining; 2.6%
average unemployed as of 1974, excluding self
employed
Organized labor: 31% of total labor force: 37.5% of
wage and salary earners','aac4e1eee10cd87b3d65bcfd65d0107f48d8969a5eb0b8786c5b0eae477d4639','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b88c6773fe89b94241b569f1babaecb0c722237a8f93eb189c7f8afab5bd9ce',1975,'GH','Ghana','people-and-society',190,'Population: 9,810,000, average annual growth rate
2.6% (7/71-7/72)
Nationality:
Ghanaian
Ethnic divisions: 99.8% Negroid African (major
tribes Ashanti, Fante, Ewe), 0.2% European and other
Religion: 455 animists, 43% Christian, 1298
Muslim
Language: English official; African languages
include Akan 44%, Mole-Dagbani 1653, Ewe 13%,
and Ga-Adangbe 8%
Literacy: about 255¢ (in English)
Labor force: 3.4 million; 61% agriculture and
fishing. 16.8% industry, 15.253 sales and clerical, 4.1%
services, transportation, and communications, 2.96
professional; 400,000 unemployed
noun —Ghanaian(s); adjective—
a g Zane
July iftpproved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
(SHANA/GIBRALTAR
Organized labor: 350,000 or approximately 10% of
labor force','989f3ff16bd821def4da8cb47b501a49f825f39ab644a715db89994baf1dade1','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccffc11906ae167c7a873e83ac913132266d51f0e81c4d5e5d66d8f15b7bbc5d',1975,'GI','Gibraltar','people-and-society',194,'Population: 30,000 (official estimate for 1 July
1973)
Nationality: noun—Gibraltarian(s); udjective-—
Ethnie divisions: mostly Wallan, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary
languages; [tallan, Portuguese, and Russian also
spoken; English used in the schools and for all official
purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltarian laborers
Organized labor: over 6,000','e529e565a5eaf8738ce0cf663126a40ca518b81b4c4f160785d4602b93c4af36','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fb2b6516febf4aa92730493967f45d35d0b32e75e9540fbe7c699da12972309',1975,'NL','Netherlands','people-and-society',199,'‘opulation: 66,000, average annual growth = rte
2.5% (7/68-7/73)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
jul Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
uly [D7
GILBERT AND ELLICE ISLANDS/GREECE
; UNttt
Pacitic Ocean eld
va GILBERT anol"
., ELLICE ISLANDS
"tae
a
© Flt
{ISLANDS
(See reference mag Vill)
Nationality: noun—Gilbertese, Ellis Estander(s) or
Gilbert’ and Ellis IMander(s); adjective—Gilbertese,
Ellis Islander, or Gilbert and Ellis Islander
Ethnic divisions: 83.99 Micronesian, 13.9%
Polynesian, O.99¢ Enropean, 0.18% Chinese, 1.2%
mixed and other races
Religion: mainly Christian: 55% Protestants, 42%
Catholics
Literacy: Jess than 50%
Population: 13,634,000, average annual growth
rate 0.7% (current)
145
: CIA-RDP86T00608R000600100003-3
“
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Nationality: nown—Netherlander(s); adjective—
Ethnic divisions: 999 Dutch, 1% Indonestan and
other
Religion: 41% Protestant, 49% Roman Catholic,
199 unaffiliated
Language: Dutch
Literacy: 08 %
Labor fo. ve: 4.7 million; 30% manufacturing, 24%
services, 169 commerce, 10% agriculture, 9%
construction, 79 transportation and communications,
4% other; average unemployment rate 3% (Jan.-Aug.
1973); no shortage of skilled labor but shortage of
seml-skilled labor; 129,000 unfilled vacancies reported
by employers in January 1971
Organized labor: 339 of labor force
Population: 240,000, average annual growth rate
1.6% (1/71-1/73)
Nationality: noun—Netherlands Antillean(s);
adjective—Netherlands Antillean
Ethnic divisions: 85% largely mixed Negro stock
except on Aruba where 12% Negro and approx. 55%
mixed Carib Indian and European; rest European
with some Chinese, especially on Aruba
\\
? Pa ,
Ka pom Atlentic Ocean
= =
°
9
WETHERLANDS =
ANTILLES
Caribbean
Sea
{See setoronce map tl}
Religion: predominantly Roman Catholic; sizable
Protestant, smaller Jewish minorities
Language: officially Dutch; predominantly
English; colloquial “papiainento,” a) Spanish-
Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 2190 industry,
21% unemployed, 8% construction, 41% government
and services, 8% other
Organized labor: approx. 15% of lubor force','36de5d6fe52f5db5c6cdd7a9301cd555701437bda984cb1f905b1f2c5da44e9e','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc35a06a284f768dec9217cded6b64e06df8dc86267a057248bb1c74953d28d7',1975,'GR','Greece','people-and-society',202,'Population: 9,094,000, average annual growth rate
O08 (7199-7 /73)
sationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 1%
Albanian, 15 other
Religion: 975 Greek Orthodox, 2.5% Muslim.
0.550 other
Language: Greck; English and French widely
understood
Literacy: males about 99%: females about 73%;
total about 825%
Labor force: 3.600.000 (!969 est.): 50°. “rien
Aplas -
ture, 15% industry, 95 trade, 26% other;
at
pany
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
ment and underemployment, 20% total in all fields;
shortaye of skilled labor in nonagrioultural sectors
aggravated by large-seate emigration
Organized ladon: 10% of labor force','a62b83fd658a0566e5351f4f5b4faecf880a7a3e5df4ea193c40f12a4446361f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d74600ee0ac9b214a1c9a3e00dfc86bcc59c0e6ed58296e0e0fb88ffb005185',1975,'GL','Greenland','people-and-society',206,'Population: 51,000, average aniual growth rate
6% (1/72-1/74)
Nationality:
Ethnic divisions: 86% Greenlander (Eskimos and
Greenland-born whites), 1456 Duties
Religion: Evangelicet Lutheran
Language: Danish, Eskimo dialects
(approx., includes minor
noun—Greenlander(s); adjective—
Literacy: 09%
Labor force: 12,000; largely engaged in fishing and
sheep breeding,','615b76721f4ab1c9b909fd3e7c9ee34bfffeb54847fcb6f1087d3a64ade26267','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44cc49c3803a27641aac7c95d3907abd421d88e902298e0e9d0f805b84136f29',1975,'GD','Grenada','people-and-society',210,'Population: 98,000, average annual growth rate
0.6% (7/60-4/70)
Nationality: noun—Grenadian(s); adjective—
Grenadian
Ethniz divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant
sects; Roman Catholic
Language: Finglish; some Frenck patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force
82','e2f1985cfc620b3c4a9dc180c6cdffc3bbdbf4e367ebd9d724eed58b390a3082','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01aa91834a21b2f1e5acce251bb08f3962620f25cb6f09e80a5f1495ce637959',1975,'GP','Guadeloupe','people-and-society',214,'Population: 352.000, average annual growth rate
1.5% (7/72-7/73)
Nationality: noun—Guadeloupian(s); adjective-—
Ethnic divisions: 905% Negro or Mulatto, less than
550 East Indian, Lebanese, Chinese, 5% Caucasian
Religion: 955 Roman Catholic, 5% Hindu and
pagan African
Language: French, creole patois
Literacy: over 70S
Labor force: 120,000; 25% agriculture, 25%
unemployed
Organized labor: 119 of labor force','4c2bac7a3b3e06f4fa86ce8563ba79371aa043681838a73d34604006463c6b77','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c48331e682158858f09a668d9a4770783e812bf29113a487aa64d6ab97aabddb',1975,'GW','Guinea-Bissau','people-and-society',220,'Population: 492,000, average annual growth rate
0.25% (7/68-7/69)
Nationality:
Guinean
Ethnic divisions: about 99% African (Balanta 30%,
Fulani 20%, Mandyako 149, Malinke 15%, and 23%
other tribes); less than 16 European and mulatto
Religion: 66% animist, 830% Muslim, 4% Christian
Language: Portuguese and numerous African
languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in
subsistence agriculture
noun—Guinean(s); adjective—
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
GUINEA-BISSAU/GUYANA','fdc18b613c078aa0802699ec324d8d9427f7975f7df2b1c3cb9f6fa4942db0cb','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6834a9ba134fa70dc9de7177b8ed4a345ced2df8c62d5f88a491881cca00a589',1975,'GY','Guyana','people-and-society',224,'Population: 811,000. average annual growth rate
2.5% (4/60-4/70)
Nationality: noun—Guyanese (sing., pl); adjec-
tive—Guyanese
Ethnic divisions: 51°¢ East Indians, 43% Negro
and Negro mixed, 45 Amerindian, 2% white and
Chinese
Religion: 57% Christian, 33% Hindu, 96¢ Muslim,
1% other
Language: English
Literacy: 86%
Labor force: 201.000; about 25% agriculture, 14%
manufacturing, 165¢ services, 11% commerce, 356
mining and quarrying, 10% other; 215 unemployed
Organized labor: 34° of labor force','3e5aa9026941eb474c5e58cb531988a2cabc0c705326414a22be5dc01115de95','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8296ca0599e54605019883d4ad023603af39e21d4bc5af43cbfd878e0e700316',1975,'HT','Haiti','people-and-society',228,'Population: 4,569,000, average annual growth rate
1.6% (current)
Nationality: noun—Haitian(s); adjective— Haitian
Ethnic divisions: over 90% Negro, nearly 10%
mulatto, few whites
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
(See reference reap it}
Religion: 10% Protestant, 75% to 800% Roman
Catholic (of which an overwhelming majority. also
practice Voodoo)
Language: French (official) spoken by only 106% of
population; all speak Creole
Literacy: 10% to [2%
Labor foree: 2.6 million (est, January 1968); 86%
agriculture, 1256 industry, 29% unemployed; shortage
of skilled dabor; unskilled labor abundant
Organized labor: less than 1 of labor force','a16a47cbae1eeb2c63b2cadefe912acce70303b2d6b800771ef4f86dfbd63cac','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21ab763fa044a7787450c06f4afaf5651ca7cdcf7905a5ed15a39c6aaeb2aeda',1975,'HN','Honduras','people-and-society',232,'Population: 2,719,000, average annual growth rate
2.7% (4/61-3/74)
Nationality:
Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2%
Negro, and 1¢¢ white
Religion: about 97% Roman Catholic
Language: Spanish
noun—EHonduran(s); adjective -
Litesacy: 57.4% of persons 10 years of age and over
(est. 1970)
Labor force: approx. 900,000 (est. rnid- 1972); 66%
agriculture, 12[¢ services, 8% manufacturing, 5%
commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to LOS of labor force (mid-
1972)','8ea316dd0d66c32d793ddb53d4ae99b92d6e91c709463d239baa878a31c93282','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a819fb60e7a90c6317440d08143dbf0e3bc3534ac51b37f48491aebe31040ca',1975,'PH','Philippines','people-and-society',237,'Population: 4,319,000, average annual growth rate
L650 (7/71-7/74)
Nationality: adjective —Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of
local religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 15%
manufacturing, 206 services, ELS construction,
mining, quarrying and utilities, 135 commerce, 4%
agriculture, forestry, fisheries, and hunting, 7%
communications, 2% other; underemployment is a
serious problem
Organized labor: 12% of 1969 labor force
Population: 42,845,000, average annual growth
rate 3.3% (current)
Nationality: noun—Filipino(s); adjective—Philip-
pine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.55 Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant,
4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the
national language of the Philippine Republic; English
is the language of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry,
fishing, 129 manufacturing, 10.59% commerce, 10.5%
government and. services (business, recreation,
domestic, personal), 3.5% transport, storage,
communication, 3% construction; 0.5% other','04006e3c46854bfc248aae9ef13db8430c067ab707adb67ba98ed1f8f37fd937','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1695d0d0d341e6f3e0542faae35f7bda68d850469dfb0c75930d0a7a5e0c0447',1975,'HU','Hungary','people-and-society',241,'Population: 10,541,000, average annual growth
rate 0.650 (current)
Nationality: noun—Hungarian(s); adjective—
Hungarian
Ethnic divisions: 93.35 Magyar, 2.5% German,
2.459 Gypsy, 0.7% Jews, 1.196 other
Religion: 67.5'' Roman Catholic, 20.0% Calvinist,
5.050 Lutheran, 7.056 atheist and other
Language: 98.2% Magyar, 1.8%¢ other
Literacy: 97%
Labor force: 5,061,200 (1 January 1973), 24%
agriculture, 449 industry and building, 16% trade
and transport, 165 other nonagricultural','a64bd0ba3bdcf2f21bb61c940c0122e58128cba578d6bbd21fa5ed5a432825fb','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e013ee689a1411704258956006b4259e044a7dc85a84ce37171f831e6d5d9f21',1975,'IS','Iceland','people-and-society',245,'Population: 218,000, average annual growth rate
1.2% (12/69-12/74)
Nationality: noun—Icelander(s); adjective —
Ieclandic
Ethnie divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 25 no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and
fishing; 25.6% mining and manufacturing; 10.7%
construction; 12.85 commerce; 7.8% transportation
and communications; 15.2% services: and 3.7% other;
tnemployment is insignificant
Organized Jabor: 6056 of labor force','107bc9ac9e5b13b4a8ea05d04368c3331ba216c970164fa3d051bf19a71cd519','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8a609c119764a15d65433fbb3d07419a26286a2b4d6d2a59afd832183312409',1975,'ID','Indonesia','people-and-society',249,'Population: 131,166,000 (including West Irian),
average annual growth rate 2.656 (current)
Nationality: noun—Indonesian(s); adjective—
Indonesian
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
South China
Sea
ALAYSIA Pacific
Ocean
@
“Tsar Ex? eos
* eke f & mee ao 3
gos
Si
eee INDONESIA 4
an
ee | we
TOES FFwon
Indian Ocean','9dbb8c731e2b4552c041eae2e1789342e3649edcd6cd3770f3f742923df05c8e','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('561dc44e9789b67be22638ffa79f581f8fef12bf01b9db4992a02fdc5b604e76',1975,'IQ','Iraq','people-and-society',251,'Population: 11,024,000, average annual growth
rate 3.4% (10/73-10/74)
Nationality: noun—Lraqi(s); adjective—lraqi
Ethnic divisions: 70.9% Arabs, 18.3°% Kurds, 0.7%
Assyrians, 2.40% ‘Turkomans, 7.75% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Kurdish minority speaks
Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.55
industry, 6.7% government, 16.8% other: raral
underemployment high, but not serious because low
Arabic,
subsistence levels make it easy to care for
unemployed; severe shortage of technically trained
personnel
Organized labor: 115 of labor force','0457323ed84e6a9c73abaa687030668b73d736bca346fa92944350d78dcddd23','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d7bdab28fb7c8f6602bfea2ed7eef3ad939aa58a5e175ed61f653c51ba07a11',1975,'IE','Ireland','people-and-society',255,'Population: 3,066,000 average annual growth rate
0.6% (7/65-7/73)
Nationality: noun—trishman(men), Dish (collec.
tive pl): adjective --Drish
Ethnic divisions: nicially homogeneous Celts
Religion: 04° Roman Catholle, 4% Anglican, 2°
other
Language: English and Gaelic official, English ds
generally spoken
Literacy: 989% 0%
Labor foree: about 1.194,000 (1971): 26%
agriculture, forestry, fishing; 106% mianifacturiing:
15% commerce; 7% construction; 5% transportation;
AS government; 24% other
Organized labor: 865 of labor force
Population: 3,372,000 (excluding East Jerusalem),
average annual growth rate 2.75% (7/73-7/74)
Nationality: noun—Isracli(s); adjective—Isracl
Ethnic divisions: 85% Jews, 155 non-Jews (mostly
Arabs)
Religion: 895 Judaism, 8% Islam, 3% other
Language: Hebrew official; Arabic used officially
for Arab minority; English most commonly used
foreign language
Literacy: 88% Jews, 48% Arabs
102
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
IRELAND /TSRAEL
Labor foreer LUT 000) 746 aguiculture, forestry
andl fistibnges 24.00% muemafvetorieg Gaining. inalistes ),
1.0% eleetielty and water; 9.05 construetion vid
public works; 12.0 commerce, TTS Taunsport,
wtorage, aed communications, G24 flnatiee ane
business; 24.6% public seavlees; 6.0 personal and
other serviers (1975)
Organized labor: 90% of labor force','dbb798110bdfa401c39725517f93204cb69d72aec7fc2ea7475c39512f16fad6','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73af6e7136f34a9726850215d19344e038993fc9cfb60012bfaf1ba8c482572d',1975,'IT','Italy','people-and-society',261,'Population: 4,545,000 (resident African population
only), average annual growth rate 2.65 (current)
Nationality: noun—Ivorian(s); adjective— Ivorian
Ethnic divisions: 7 major indigenous ethnic
groups, no singe tribe more than 20% of population;
most dinportant are Agni, Baoule, Krou, Senoufou,
Mandingo: approx. | million foreign Africans, mostly
Voltaies; about 33,000 non-Africans (25,000 French)
Religion: 66% animist, 22% Muslim, 12%
Christian
Language: French official, over 60 native dialects,
Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about PE of
labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce,
and professions
Organized labor: 20° of wage labor force','b998de7702f3304989b1075f83f704eb7d4906208f91d87a1db056e98877c5c9','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3e1899167f106eceaabceb247ae627016ad3dcd8bc1425cdb2f48801be0693b',1975,'JM','Jamaica','people-and-society',263,'Population: 2,053,000. average annual growth rate
1.95¢ (7/71-7/73)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
july 1075
Atlantic
Ocean
ane
Chart nOMINt
CU, 7 OMT
He
gee ie
JAMAICA “nasa
Caribbean Sea
(Soe retoreace mop itt
Nationality: noun--Tamaicun(s): adjective —
Jamalean
Ethnic divistons: Afrean 76.3%, Afro-EKuropesan
15.1%, Chinese and Afro-Chinese 12%, Bast tndian
and Afro-Bast Indian 3.4%, white 3.2, other 0.9°%
Religion: predominantly Protestant, some Romar
Catholic, some spiritualist cults
Language: English
Literacy: government. claims 82%, but probably
oply about one-half of that number are functionally
literate
Labor force: $08,300; 265 in agriculture, forestry,
fishing and mining. 10% manufacturing, 8% public
administration, 5° construction, 10% commerce, 36%
transportation and —utilitdes, 15% services, 25%
unemployed (seasonal unemployment in agriculture
can push the unemployment figure to 25%); shortaye
of technical and managerial personnel
Organized labor: about 25% of labor force (1966)','77dc2c449d6086732e00d775cf0b0aeb7891be14b116c995f9e44eba74345df5','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a016882370067062318f880f5df40b5e8f1cb08628bb7fa0f5782f8efcdd004',1975,'JP','Japan','people-and-society',267,'Population: 110,932,000 (inctuding, Ryukyus),
average annual growth rate 1.1% (7/64-7/74)
Nationality: noun—Japanese (sing., pl); adjec-
tive—Japanese
Ethnic divisions: 99.2% Japanese, .8% other
(mostly Korean)
Religion: most Japanese observe both Shinto and
Buddhist rites; about 16% belong to other faiths,
including 0.86 Christian
Language: Japanese
Literacy: 97.85% of those 15 years old and above
(1960 data)
Labor force (1969 figures): 5! million; 18.6%
agriculture, forestry, and fishing; 34.25 manufactur:
ing, mining, and construction; 36.49 trade and
services; 6.6% transportation; 3.1% government; 1.1%
unemployed; shortage of skilled labor 1.5 million;
unskilled .5 million (est.)
Organized labor: 20% of labor force
Population: 1,641,000° average annual growth
rate 2.7% (7/73-7/74)
Nationality: noun—Yemeni(s), adjective— Yemeni
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
s Language: Arabic
Literacy: probably no higher than 10%; Aden 35%
(est.)
vie GOVERNMENT
Legal name: Peoples Democratic Republic of','3b9b8ce10889c437fb7b54099284d57e0c4302bb7ac71c6a688340b62245819f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('510a02489ff6305c420f312f8d5756e7c66d6b54ceae31e10cb0985df2ec5e2b',1975,'JO','Jordan','people-and-society',271,'Population: 2,708,000 (including West Bank and
East Jerusalem), average annual growth rate 3.3%
(7/70-7/73)
Nationality: noun—Jordanian(s); adjective—
Jordanian
Ethnic divisions: 985 Arab, 1% Circassian, 1%
Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 50% in East Jordan; somewhat less
than 609% in West Jordan
Labor force: 564,000; 335¢ unemployed
Organized labor: 56 of labor force','987f3abaa1b0b357f512ba0eb8336db9c7a9853c17e1270744e49f1ccc4a9e4b','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59c465f46dce235e777ade610a30adb87943cae4dd32c4900e297bcfc9a0f86a',1975,'KE','Kenya','people-and-society',275,'Population: 13,357,000, average annual growth
tate 3.4% (7/73-7/74)
Nationality: noun—Kenyan(s); adjective-—Kenyan
Ethnic divisions: 97% native African (including
Bantu, Nilotic, Hamitic and Nilo-Hamitic); 2%
Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim,
1% Hindu
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
KENYA/KOREA, NORTH
Language: English and Swahili officials eneh tribe
hus own language
Literacy: 27%
Labor foree: 2.5 million; about 977,000 (80%), tn
monetary economy (1967)
Organized labor: about 215,000
Population: 16,507,000, average annual growth
rate 3.1% (current)
111
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
KOREA, NORTH/ KOREA, SOUTH
°
Ce CC Abitnat ‘2
raya
Rtgs
aor fest
China Sea
{Soe reteronts mop Vil}
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: racially homogencous
Religion: Buddhism and Confucianism, religious
uctivitles now almost nonexistent
Language: Korean
Literacy: 905 (est)
Labor force: 6.1 millon; 48% agriculture, 52%
non-agricultural; shortage of skilled and unskilled
labor
Population: 34.254,000, average annual growth
rate 2.0% (current)
Nationality: noun—Korean(s); adjective— Korean
Ethnic divisions: humeoeeneous: stall Chinese
minority (approx, 20,000)
Religions strong Confucian tradition: pervasive
folk celigion (Shamanism); vigorous Cheisthon
minority (5.5° of population): Buddhism (including
estimated 20,000 members of Soka Gakkai),
Chondokyo (religion of the heavenly way), eclectic
religion with natlonalist overtones founded in lth
century, claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971), 46.2%
agdeulture, fishing, forestry, 32.55 services, 14%
mining and manufacturing, 3% construction, 4.5%
unemployed
Organized labor: about 10% of nonagricultural
labor force','52982d2d3981982405c1e876b78fc76a1c1aecda169078166dd4cfff31f3b0f1','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a5d7ed78826dd44c54764b840f830cee2b6461b681ae18577970d807987d461',1975,'KW','Kuwait','people-and-society',279,'Population: 974.000, avenge annual growth rate
9.5% (7/73-7/74)
Nationality: noun—Kuwaiti(s);
waltl
Ethnic divisions: 87% Arabs, 12° Tranians,
tndiuns, and Pakistan bt other
Religion: 95° Muslim, 3% Christian, Hindu,
Parsi, other
Language: Arbic; English commonly used foreign
language
Literacy: about 42.8% (1970)
Labor force: 238,000 (1970); 41 manufacturing,
25% services, 22% government und professions 9%
commerce
Organized labor: labor untons, first authorized in
1964, formed in oil industry and among government
yosonnel
Population: 3,336,000, average annual growth rate
2.4% (7/72-7/73)
Nationality: noun—Lao (sing., pl); adjective —
Lao or Laotian
Ethnic divisions: 47° Lao; 14% Tribal Tai; 2596
Phoutheung (Kha); 145% Meo, Yao, and other
Religion: 50% Buddhist, 505 animist and other
Language: Lao official, French predominant
foreign language also used in administration
Literacy: about 125
Labor force: about 1,268,000; 8055-90% ugri-
culture; 159,286 engaged in) manufacturing and
services; 28,400 (22,400 civil and 6,000 police)
government employees in FY72
Organized labor: a labor federation was formed in
mid-1974, but labor organization remains in its
infancy
115
CIA-RDP86T00608R000600100003-3
x
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
LAOS','0dcf2d1753094d9ddb117ef19f932d29bab97cd5f983c7e5bc8521621b6f11f8','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fca2b5afe9a33587e2585b736339fa53d0d229e9daad01b84606e670a907df48',1975,'LB','Lebanon','people-and-society',283,'Population: 2.4.49,000, average annual growth rate
3.196 (current)
Nationality: noun—Lebanese (sing. and pl.)
udjective— Lebanese
Ethnic divisions: 93° Arab, 6S Armenian, 1%
other
Religion: 55% Christian, 445° Muslim and Druze,
15% other (official estimates); Muslims believed to
constitute slight’ majority
Language: Arabic (official); French is widely
spoken
Literacy: 86%
Labor force: about | million economically active;
4956 agriculture, 1156 industry, 149 commerce, 26%
other; moderate unemployment
Organized labor: about 65,000','494628d1b7ee6a08f169107b9a27a0c8401d59d7855e802384a8b1d85b41abd7','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e9b2fc6c3346a9380238050abed0ad12aaff62d3d412e29c88a0ad4f6bc7d56',1975,'ZA','South Africa','people-and-society',287,'Population: 1,038,000, average annual growth rate
2.2% (7/73-7/74)
118
Nathonality: noun Sasothan(s), adjective —-
Wasothion
Bthole divistons: 00.76 Sothe, 1.000 Barropessnos,
SOO Asians
Kelighon: 70° of more Chiisthin, cost andinist
Languages all Africans speak Sesotho vernacubar
Engl ds second language for literates
Literacy: 40%
Labor force: 87.48 of resident population enpasged
In stibsistence agdoultire: 150,000 to 250000 spend 6
Months to many years us wage earners dh South Africa
Organized labors: negligible
Population: 24,964,000, cverage annual growth
rate 2.6% (7/73-7/74)
Nationality: noun-—South African(s): adjective—
South African
Ethnic divisions: 17.8%
O46 Colored, 2.9° Asian
Religion: primarily Christian except) Asian and
African, 60° of Africans are animists
African,
white, 69.9%
Language: Afrikaans and English official, Africans
have many vernacular Languages
Literacy: almost all) white population. literate;
government estimates 35°C of Africans literate
Labor force: 8.7 million (total of economically
active, 1970); 53°C agriculture, 8° manufacturing,
To mining, 3S commerce, 27° miscellaneous services
Organized labor: about 7% of total labor foree is
unionized (mostly white workers): nonwhites have no
bargaining power
Population: 436,000, average annual growth rate
2.26% (current)
Nationality: uwoun--South West African(s);
udjective—South West Abrican
Ethnic divisions: [4% white, 81 Africans, 5%
Colored (mulattoess; almost half the Africans belong
to Ovambo tribe; Damara tribe has almost 45,000
members; Herero, Okavango, Nama tribes have about
30,000 members each
Religion: whites predominantly Christian,
nonwhites either animist or Christian
Language: Afrikaans principal language of about
70% of white population, German of 22° and English
of 8£e. several African languages
Literacy: high for white population; low for
nonwhite
Labor force: 203.300 (total of economically active,
1970); G8 agriculture, 15°C railroads, 13°C mining.
4 fishing
Organized labor: no trade anions, although some
white wage earners belong to South Afmean unions','44589c433b8c3d04dbbb03a1b5336eecc243bdd9d0e6f708320857eef6f630cd','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa79c1ddab5aea736f81519ce71fe39f818aa14b2932f285ba7366c8a56b5b6b',1975,'LR','Liberia','people-and-society',291,'Population: 1,762,000, avenge annual growth rate
2.0% (current)
Nationality:
Liberian
noun— Libertan(s); adjective —
Ethnic divisions: 5% descendants of immigrant
Negroes; 95% indigenous Negroid Afrlean tribes
including Kpelle, Bassa, Keo, Grebo, Gola, Kiss,
Krahn, and Mandingo
Religion: probably more Muslims than Christhuns;
TO%-BOS animist
Language: English official, 28 tribal languages or
dialects, pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 500,000, of which 150,000 are in
modern economy; about 2,000 non-African foreigners
hold about 95% of the top level management and
engineering jobs
Organized labor: 2% of labor force','b7569c550ee4b43d52b84c93d6d11d93bff8fa593f272b7c87f6f5358ac6113f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0fe32bf1199a1eca242e0a0c82af5d2cfaeb96dc8173be06b955114e9eb0b6c',1975,'DE','Germany','people-and-society',296,'Population: 2,418,000, average anni growth rate
S79 (7/79-9/74)
Nationality: noun —Libvan(s); adjective-- Libyan
Ethnic divistons: 979% Merber and Arab with some
Negro stocks some Greeks, Maltese, Jews, Hullans,
Eyypthains
Religion: 075 Muslin
Language: Aralte; Italian and) English widely
understood in niafor cities
Literacy: 35%
Labor force: 485,000; between ages 15-64,
405,000-4590,000; GES of labor foree in ugrtcultuce
(196-4)
Population: 24,000, average annual growth rate
2.5% (12/60-12/70)
Nationality: noun—Liechtensteiner(s); adjective—','8d190445123add8888e47b0866577c16567eb5586ca64a8caafbe16f6fd55bc6','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('000e6b76740814d5e4fdf9f370ccb9006e11cd5647e6f774e7354052c398159f',1975,'LI','Liechtenstein','people-and-society',299,'Ethnic divisions: 95% Germanic, 55% Italian and
other
Religion: 92% Roman Catholic
Language: Germin (dialect)
Literacy: 985
Labor force: 7,900, 3.500 foreign workers (mostly
from Austria and Italy); 59% industry, 20% trade and
commerce, 135 professional and other, 8%
agriculture
122','bf017df6ffe077fca35e53fa213cd76e1f434a416dc5113b587d2820641ab3ea','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e7a8b06b35a557b01e075a3015299b8be540b385232b8b4e3937a61131bbb08',1975,'LU','Luxembourg','people-and-society',304,'Population: 357,000, average annual growth rate
0.7% (1/66-1/7-4)
Nationality: noun—Luxembourger(s); adjective—
Ethnic divisions: §3% Luxembourger, including an
estimated 55 of Italian descent; remainder French,
German, Belgian, ete.
Religion: 97% Roman Catholic, remaining 3%
Protestant and Jewish
Language: Luxembourgish, German, French; most
educated Luxembourgers also speak English
Literacy: 98%
Labor force: (1973) 154,000; 10% agriculture
(including forestry and fishing), 48% industry, 425¢
services, no significant unemployment; 28% of labor
force is foreign, comprising workers from neighboring
areas of Belgium, France, and West Germany, as well
as Italy and Portugal
Organized labor: 4556 of labor force','5cc1937db190aed5101933dc1b41ff3786f0182e00f0423ed19bd8989aeda114','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3c06b3626ff3136baac72b17c1135e0864a5c264110ea197f82fccbe75d1293',1975,'MW','Malawi','people-and-society',310,'Population: 5,042,000, average annual growth rate
2.6% (7/71-7/73)
Natlonallty: noun—Malhawian(s); adjective —
Maluwian
Ethnic divisions: over 10% native African, less than
1% European and Asian
Religion: majority animist: rest’ Christian’ and
Muslim
Language: English and Chichewa official: Lomwe
is second African language
Literacy: 69 of population over 21 years old
Labor force: 225,000 wage earners employed in
Malawi (1974); 6,000) Europeans permanently
employed; 300,000 Malawians live and work in
Rhodesia, South Africa, and Zambia; 306% agriculture,
11% construction, 10% commerce, 13S manufae-
turing, 105 administration, 26% miscellaneous
services
Organized labor: small minority of wage earners
are unionized','0ef08182768c5448fcfdc3e7dec11ba2c80382e071e4188fd7301a4fadf5f34d','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('318d490fcdb72e920a7c32ea58869ddd4dd80d888fca0e5430a664baa85cd7c5',1975,'MV','Maldives','people-and-society',314,'Population: 130,000, average annual growth rate
2% (current)
Nationality:
Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: lurgely illiterate
Labor force: fishing industry employs most of the
male population','ba32d903736f83d8e44f67148950222b84d45a8d3decdcd0090579f281dd8d6e','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04788d20e614fab9705f024907e84f7b092e42c29d67fd6f8c228c122a2734d5',1975,'MR','Mauritania','people-and-society',318,'Population: 5,622,000, average annual growth rate
2.3% (7/72-7/78)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: $9% native African including
tribes of both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African
languages, of which Mande group most widespread
Literacy: under 5%
Usher force: approximately 100,000 salaried,
50,000 of whom are employed by the government;
most of population engaged in agriculture and animal
husbandry
131
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
MALIL/MALTA
Organized labors UN''TM, which claimed all
eligible employees, dissolved; thirteen national unions
currently directed by a government. controfled
Coordination Committee of Mali ‘Trade Unions
(CCSM)
Population: 1,525,000, average annual growth rate
2.5% (current)
Nationality: noun—Mauritaniin(s); adjective—
Maeltienhan
Fihnte divistons: 40% Moor, 20% Negro
Religions nearly 100% Muslim
Language: Huassaniya Atable iy the national
language spoken by some KOS of the population,
French ts the working language for government and
commerce
Literacy: about 10%
Labor force: ubout 14,000 wage earners (1973);
remainder of population in farming and herding
Organized labor: 18,000 union member chimed
by single union, Mauritanian Workers’ Union','f0938cf47993e0e452d428347e33816f8e906cd04597c702f291886087acc08d','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc90ab2d999496d4004fac6773b5b0a4b5f291cd663615d5eef7e80c443ab2e0',1975,'MT','Malta','people-and-society',322,'Population: $22,000) (offlelal estimate for 30
September 1974
Nationality: noun—Maltese (sing. and pl);
udjective—Muattese
Ethnic divisions: mixture of Amb, Sieilian,
Norman, Spanish, ttalian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 839%; compulsory education
introduced in 1946
Labor force: 107,500; 209 services, 23%
government, 2496 manufacturing, 656 ajtriculture, 456
construction, 49 transportation and communications,
5% utilities and drydocks; 5% unemployed
Organized labor: approximately 35% of labor force','45f4fe6fb1866118a5dbc0746e5958c62a2f4b9c8a7cd862e85737c3ff603fda','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0efae5035698e15c3d764c7545856d1fcf623be406900be1179e1dd04ee9cdd4',1975,'MQ','Martinique','people-and-society',325,'Population: 347,000, average annual growth rate
0.598 (7/70-7/73)
Nationality: noun—Martiniquais (sing. and pl.);
adjective—Martiniquais
Ethnic divisions: 90% African and Afriean-
Caucasian-fndian mixture, less than 5% East Indian
Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 2350 agriculture, 20% public
services, 115¢ construction and public works, 10%
commerce and banking, 10% services, 9% industry,
17% other
Organized labor: 11% of labor force','66eea54fb041c3ed9ac9364a2d68f9d1240e3ee69dba6d088ae06e03eaba09bd','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d21c8ec1129286ea59375d75241c978565eaf681867cf293c32f0c35c564023a',1975,'MU','Mauritius','people-and-society',327,'Population: 885,000, average annual growth rate
1.1% (1/73-1/74)
Nationality: noun—Mauritian(s); adjective—
Mauritian
Ethnic divisions: Indians 67%, Creoles 29%,
Chinese 3.5%, English and French 0.5%
Religion; 51% Hindu, 339% Christian (mostly
Catholic with a few Anglican Protestants), 16%
Muslim
Language: English official language; Hindi,
Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90%
for those of school age
Labor forces: 175,000; 50% agriculture, 6%
industry; 20% government services; 14% ure
unemployed, under-employed, or self-employed, 10%
other
Organized labor: about 35% of labor force','c73c26864eeec7f22b7c27637af8545d60183f0b91fe7b9e356481919d9866f3','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c21021645b44765f2d3c6f5ef9febc81a7c977412d4e9df8d9271ac14a95f7f',1975,'MC','Monaco','people-and-society',331,'Population: 24,000 (official estimate for 1 July
1973)
Nationality: noun—Monacan(s) or Monegasque(s);
adjective—Monacan or Monegasque
Ethnic divisions: Rhactian stcck
Religion: Roman Catholicism is officiai state
religion
Language: French
Literacy: almost complete
\\ i. * —
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
aa : we oe ert','f180230ae33851c48246a872aee09d69a1244255bae4d813ce52d927ac21d337','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e8c6ceb8bd10bb3e54e06da752cf4c3d8ee9c3915474b1d264ca21ac3794c3',1975,'MN','Mongolia','people-and-society',335,'Population: 1,444,000, average annual growth rate
3% (current)
Nationality: noun—Mongolian(s); adjective—
Mongolian
Ethnic divisions: 90% Mongal, 45 Kazakh, 25
Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about
4% Muslim, limited religious activity because of
Communist regime
Languages: Khalkha Mongol used by over 905% of
population; minor languages include Turkic, Russian,
and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large
percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable
information available)','a0d3c8a066e68f7f748fe6d7faabf8f3a0498a8d89371e753122cef87f90717f','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d6038ae7a6146eb6eb709a50d5ce6b232619d74dd7a582a54beecf25192a873',1975,'MA','Morocco','people-and-society',339,'Population: 17,274,000, average annual growth
rate 2.99 (7/72-7/73)
Nationality: noun—Moroccan(s); adjective—
Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish,
0.7% non-Morocean
Religion: 98.7% Muslim, 1.1% Christian, 0.2%
Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, goverment,
dipiainacy, and postprimary education
Literacy: 20%
Labor force: 6.3 million (1971 ext.); 50%
agriculture, 15% industry, 26% services, 9% other
Organized labor: about 5% of the labor force,
mainly in the Union -£ Moroccan Workers (UMT)','d3276089f58a3dc7710ee61fed5bbc88560fec9f7c49eea23cfbfbbcc774a1a2','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66e5b114afab06de6e3b819a3f853ee4f5822f99c3a3da8ee32d0ea5fc712eae',1975,'MZ','Mozambique','people-and-society',343,'Population: 9,081,000, average annual growth rate
2.2% (9/60-12/70)
Nationality: noun—Mozambican(s); adjective—
Ethnic divisions: 97% African, 8% European,
Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5%
Muslim, 2.4% other
Language: Portuguese (official); many tribal
dialects
Literacy: 79-1096 (est.)
Labor force: (1963 est.) 610,000; 50,000 non-
African wage earners, 560,000 African wage earners in
Mozambique; 290,000 additional African wage
carners temporarily working in Rhodesia and South
Africa; unemployment serious problem; most native
Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970);
75% are white
Population: 15,149,000, average annual growth
rate 27% (7 73-7 TA)
Nationality:
Tanzanian
Ethnic divisions: 99% native Africans consisting, of
well over 100 tribes: 1 Asian, European, and Arab
noun-— Tanzanian(s): sdjective—
Religion: ‘Tanganyika — 406 animist. 30%
Christian, 80% Muslim: Zanzibar — almost all
Muslim
Language: Swahili English and official English
primary language of commerce, administration and
higher education: Swahili widely understood and
generally used for communication between ethnic
groups, first language of most people is one of the
local languages
Literacy: 15-20%
Labor force: under 400,000 in paid employment,
over 90% in agriculture
Organized labor: 15° of labor force','775fc9214872cee09cf4cb3492209c595b8ecf077d2022d0750a0cceefe0d45e','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bb9cd8c4a91e9870c025ab3ff79cbd69179521fcd58a55fabd3ef23d9fd87b1',1975,'NR','Nauru','people-and-society',347,'Population: 7,000 (official estimate for 30 June
1969)
Nationality:
Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (% Protestant, 4 Catholic)
Language: Nauruan, a distinct Pacific Islund
tongue; English, the language of school instruction,
spoken and understood by nearly all
Literacy: nearly universal
noun—Nauruan(s); adjective—
143
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
NAURU/NEPAL','6e3fe7b6d6de68451764353832ad4c88a5338df493d7f59b92f6356c19a46391','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcea48a4dfdec021e1bc30cb4cdc91755ee42fb8896c9b09e41fc992e42330c4',1975,'NP','Nepal','people-and-society',351,'Population: 12,550,000, average annual growth
rate 2.1% (6/61-6/71)
Nationality: noun—Nepalese (sing. and pl.);
adjective—Nepalese
Ethnic divisions: two main categories, Indo-
Nepalese (about 80%) and Tibeto-Nepalese (ubout
20%), representing considerable intermixture of Indo-
Aryan and Mongolian racial strains; country divided
among many quasi-trbal communities
Religion: only official Hindu Kingdom in world,
although no sharp distinction between many Hindu
and Buddhist groups; small groups of Muslims and
Christians
Language: 20 mutually unintelligible languages
divided into numerous dialects; Nepali official
language and lingua franca for much of the country;
same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5%
industry; great lack of skilled labor','1e00f21eff8050e0b3b0d90e63ab8ec073646c46099444694b0e3a7d9e947535','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a900606e8a9ccbbcb5eac9951a3d1f0224316baa0fad728e6c60888d48ec421c',1975,'NC','New Caledonia','people-and-society',355,'Population: 133,000, average annual growth rate
3.8% (7/61-7/72)
Nationality: noun—New Caledonian(s); adjec-
tive—New Caledonian
Ethnic divisions: Mclancsian-Polyncsian admix-
ture, over 28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Mclanvsian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and
Tonkinese laborers were imported for plantations and
mines in pre-World War II period; immigrant labor
now coming from Wallis Islands, New Hebrides, and','e260b126c9432fd06fa1496c9320b2fa82b8c00468366e93c866c27b5a05c446','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7806a8a3379d005c84502c7c3b842a93966bb2a8feca57da78dab799b07c85be',1975,'NZ','New Zealand','people-and-society',357,'Population: 3,092,000, average annual growth rate
2.2% (1/73-1/74)
150
July 1075
.
a
"pacitic
Ocean
aX
{See reference mag Vlh,
Nationality: noun—New Zealander(s); adjective—
Ethnic divisions: 93% European, 7% Muaorl
Religion: 90% Christian, 996 none or unspecified;
19 Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,021,800; 135 ugriculture, 36%
manufacturing and construction, 99 transportation
and communications, 18% commerce and finance,
G5 services, 16% udministrative and professional, 2%
unspecified (1966 fis,uses)
Organized labor: 36% of labor force','384ce348ea9488628b26c0fc4f55f84b740596a6ef4450664e5553f7c0b62ad7','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca0b993c36b7ab08a464b0a17767681dd145f285a01cd181625f68fbc7232b5',1975,'NI','Nicaragua','people-and-society',361,'Population: 2,153,000, average annual growth rate
3.3% (7/70-7/74)
Nationality:
Nicaraguan
Ethnic divisions: 69% mestizo, 17% white, 9%
Negro, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); small English-
speaking minority on Atlantic coast
Literacy: 50% of population 10 years cf age and
over
Labor force: 620,000 (1974 est.); 509 agriculture,
12% . manufacturing, 14% services, 24% other:
shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force','9e49cbcf1ef5039372938c3f65a37c89b6cee13ca3c971dd6a8be27a2ed8b9bb','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('757f626a9219c34f64b83a7f4b7cbab03716b0525c2265e76e2b1afcdf58b3d4',1975,'NE','Niger','people-and-society',365,'Populaiion: 4,599,000, average annual grov*h rate
2.7% (7/70-7/74)
Nationality: noun—Nigerois (sing. and pl.):
adjective—Niger
Ethnic divisions: main Negroid groups 75% (of
which, Hausa 50%, Djerma and Songhai 21%);
Caucasian elements include Tuareg, Toubous, and
Tamacheks; mixed group includes Fulani
Religion: 80% Muslim, remainder largely animists
and a very few Christians
Approved For Release 2002/07/0
Language: French official, many Afrlean lan.
guages; Plausa used for trade
Literacy: about 5%
Labor force: 26,000 wage carmen; bulk of
population engaged tn subsistence agdeulture and
animal hushandey
Organized labor: negligible','6a719aa24af937ece452e7b55313f844955bfb61fd6d5bb370f8743a5daacca1','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6138852c8a4a8a11b549732d90250b1c034bb709784d27e48b4f0260bb9fb9cf',1975,'NO','Norway','people-and-society',368,'Population: 4,014,000, average annual growth rate
0.7% (7/73-7/74)
Nationality: noun—Norwegian(s); adjective—
Norwegian
155
CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
Ethnic divisions: homogencous white population,
small Lappish minority
Religion: 96% Evangelical Lutheran, 496 other
Protestant and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-
speaking minorities
Literacy: 00%
Labor foree: 1.6 million; 19.5% agriculture,
forestry, fishing, 27.09% mining and manufacturing,
9.590 construction, 13.3% commeree, 11,99
transportation and communication, 17.79 services;
1.0% unemployed
Organized labor: 60% of labor force','082c8b3a94f849f4c7c26a64e122a4cc033f5e8b26e6507e06ee834265663b78','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('280ec8ae545e668958f7a53c2b47f841ae511dd1ed6d61b0f8c6905727873f31',1975,'OM','Oman','people-and-society',372,'Population: 497,000, average annual growth rate
2.9% (current)
Nationality: noun —Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small
groups of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Approved For Release 2002/07/03 : SRD Cet O eee OC Enos
s
Literacy: very low','0ce73a47c8f5dd210099b3ba2ec5abed770d138563d3c5123b6dfeca9e78ad37','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc9fa4b968c8284a3f4d29855d9d2d097ef07ad70e233078d07c7e0a326d18d8',1975,'PK','Pakistan','people-and-society',376,'Population: 70,938,000 (excluding Junagardh,
Manavadar, Gilgit, Baltistan, and the disputed area
of Jammu-Kashmir), average annual growth rate
3.19 (current)
Nationality:
Pakistani
Religion: 9796 Muslim, 3% other
Language: official, Urdu; total spoken languages
—7% Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu,
9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60%
agriculture, 16% industry, 7% commerce, 15% service,
2% unemployed
Organized labor: 5% of labor force','da2323db13211e83e6b6da3e47fd78f31af941f8adfa811e383acbea530bceee','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbb73e8e66683168c7877b4555f9f25bf628ac8593b7c06c174fb3237c8901bd',1975,'PA','Panama','people-and-society',380,'Population: 1,668,000, average annual growth rate
3.19 (7/78-7/74)
Nationality: noun—Panamanian(s); adjective—
Panamanian
Ethnic divisions: 70% mestizo, 149 Negro, 9%
white, 79 Indian and other
Religion: over 90% Roman Catholic, remainder
mainly Protestant
Language: Spanish; about 14% speak English as
native tongue; many Panamanians bilingual
Literacy: 82% of populaticn 10 years of age and
over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and
fishing; 9.7% manufacturing and mining; 6.8%
construction; 5% Canal Zone; 3.9% transportation
and communications; 1.2% utilities; national average
of 6.89 unemployed; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','a404b52b51acf6f6e8b9a65b300b1728d3f82729bee58b41da977352842c3cfd','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cefa50e77c92c3118e79a30edf18bc27e751b8037db0db425393929c27443f8',1975,'PG','Papua New Guinea','people-and-society',384,'Population: 2,805,000, average annual growth rate
2.8% (7/66-7/72)
Nationality: noun—Papua New Guinean(s);
adjective—Papua New Guinean
July ipfpProved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Pacific Ocean
. ~,
EE|PAPUN tc-aZ7 RIN
INEW OUINEA ~ SOLOMONS
ow ry
ane Patt * \\
- )
Merethy” 35s
Coral Sea
{See reference map Vi''t}
Ethnic divisions: predominantly Melanesian and
Papuan, some Negrito, Micronestan, and Polynesian
types
Religion: over one-half of population nominally
Chaistian (490,000 Catholic, 320,000 Lutheran, other
Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin
English and 2 or 3 native languages ure linguae
francae for over one-half of population; English
spoken by 19% to 2% of population
Literacy: 19%; in English, 0.19%
Labor force: no available figures; mostly
subsistence farmers','2521b5559dde695a9fdf99030caf6879f88214cd8f273fb67b5164dc6d2cda32','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17519e020d213cbcc932f585c775e595df26d05429566c13ea1a38e80b04d7dd',1975,'PY','Paraguay','people-and-society',388,'Population: 2,547,000, average annual growth rate
2.7% (10/62-7/72)
162
July 1975
ss UINEA/PARAGUAY
Nationality:
Paraguayan
Ethnic divisions: 959) mestlzo, 5% white and
Tran
Religion: 07% Roman Catholle
Language: Spanish and Guarani
Literacy: offictally estimated at 74% above age 10,
but probably much lower (4054)
Labor force: 800,000 (1971 est.): 55% agriculture,
forestry, fishing: 89 transport and other services: 199%
manufacturing and constructions 1399 eammerce and
professions; 596 miscellaneous (est, 1962)
Organized labor: about 5% of labor force','73e18f1840823df8a82867660dff4fab189b9bb090a16031d76c535144f93572','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('614eaf25c2c10fa09a368f1423efc4597b33d2a4313b3db84e923ccb98e605a8',1975,'PE','Peru','people-and-society',392,'Population: 14,819,000 (excluding Indian jungle
population which was estimated at 101,000 in 1961),
average annual growth rate 2.9% (7/61-6/72)
Nationality: noun—Peruvian; adjective—Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indiun); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture,
17% services, 149% manufacturing, 9% trade, 49
construction, 4% transportation, 29% mining, 4% other
Organized labor: 25% of labor force','f8ab9d5a942d3728594657825c28ab4f81edf9ca4c4b0f6101a2b8a608f4a73a','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47cfde2b05a033642b530222ca1fa62f56d1dc0d716897003094fd599c838565',1975,'PT','Portugal','people-and-society',397,'Population: metrcpolitan Portugal (including the
Azores and Madeira Islands, but excluding the Cape
Verde Islands) 8,499,000, average annual growth rate
—0.4% (7/70-7/73); Cape Verde Islands 270,000
(official estimate for 1 July 1972)
Nationality: noun—Portuguese (sing. & pl.);
djective—. ortugesse
167
: CIA-RDP86T00608R000600100003-3
a ar ; 5
cc ‘ <i, sae . a
Uae ns otal
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3 July 1075
Ethnle divisions: homogeneous Mediterranean
stock in mainland, Azores, Madeira Islands
Religions 979 Boman Catholle, Ef Protestant
sects, 25 other
Language: Portuguese
Literacy: 65% (a figure considered high by some
sources)
Labor fores: 3.5 million (1974); 25 agriculture,
319% industry, 249% services; 84% military, 12% other;
government estimates that approximately 180,000
persons or 596 of labor force are unemployed
Organized labor: about one-third of labor force ds
organized in trade unions; legislation promulgated
May 1975 unites unions ander one confederation, the
Communist-dominated ntersyndical
Population: 693,000, average annual growth rate
2.9% (12/70-7/72)
Nationality: noun—Portuguese Timoran(s);
adjective —Pe cuguese Timoran
Ethnic divisions: 95% indigenous ‘Timorese
belonging to the Malay racial group; 9 ethnic
divisions, each speaking a distinct dialect of Malay
structure; approx. 4,600 Chinese and 10,000 halfeastes
Religion: 179 Christian (almost equally divided
between Catholic and Protestant), remainder practice
animism
Language: an estimated 9-15 dialects, of Malay
origin. but) mutually unintelligible; 75% of the
population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very
low; in 1971 total school enrollment was 35,000 out of
total school-age population of 80,000; 5% of natives
can speak Portuguese
Labor force: 90% engaged in primitive village
subsistence economy, 10% engaged as town laborers
and domestics','55dc9484faf625b03cbb5f0e4cc5ed7f714ecfc5f37d1a9104a2a95acac111bc','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b664c50dba7c666c13dd71d04a515742f37dd9e12c41133f3a519f49fefb9bd9',1975,'SA','Saudi Arabia','people-and-society',401,'Population: 185,000, average annual growth rate
10.8% (7/64-7/69)
Nationality: noun—Qatari(s): adjective—Qatari
Ethnic divisions: 565% Arab; 239% Iranian: 149%
Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)
Population: 494,000, average annual growth rate
2.15¢ (7/70-7/73)
Nationality: noun—Reunionais (sing. & pl.);
adjective—Reunionais
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French, African,
Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 809 among younger generation
Labor force: primarily agricultural workers; high
seasonal unemployment
Population: 6,314,000, average annual growth rate
3.5% (7/68-7/74)
Nationality: noun—Rhodesian(s); adjective—
Rhodesian
Ethnic divisions: 96% African, 3% European, less
than 1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part
animist), 24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and
Sindebele also widely used
Literacy: 25%-309%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including
some migrants from Zambia and Malawi), 108,000
Europeans, Asians, and coloreds (people of mixed
heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 40% transport and services
Organized labor: about one-third of European
wage earners are unionized, but only a small minority
of Africans (1966)
86T00608R000600100003-3
Ped ‘
eet
July 1pApproved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
RHODESITA/ROMANIA
Population: 6,087,000, average annual growth rate
2.8% (current)
180
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Ler .
>
Aliyedh,
SAUDI
ANABIA
= Arabian
Sea
(See reterence map V)
Nationality: noun—Saudi(s); ad{ective—Saudi
Arabian or Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asi--a (est. )
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40%
agriculture and herding, 12% construction, 12%
service, 12% eovernment, 11S commerce, 1390 other','15048e08c4aa9846d08f7dbb7bc4a7fb680938065bc416f812add1b0db6cb631','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa32ba412b39ad1aa9c61183baf5bf6ab193531714f1b06d714044533233e949',1975,'RW','Rwanda','people-and-society',405,'Population: 4,241,000, average annual growth rate
2.9% (7/72-7/78)
Nationality: noun—Rwandan(s); adjective—
Rwandan
Ethnic divisions: 90% Hutu, 9% ‘Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1%
Muslim, rest animist
Language: Kinyarwan’. and French official;
Kiswahili used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','8d2fede2e6073783f1661f02e654274d21a3c84ff11279a419ad9c2d025a2a97','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a52098987a322d53862d49e6f12ef49980d57dd6038fec6822a41a7b33a06ce9',1975,'AI','Anguilla','people-and-society',409,'Population: 68,000, average annual growth rate
1.2% (4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s),
Anguillan(s); adjective—Kittsian, Nevisian, An-
guillan
Religion: Church of England, other Protestant
sects, Roman Catholic
Language: English
176
rR it For eae 2002/07/03 : CIA-RDP86T00608R000600100003-3
Literacy: about 80%
Labor forces 19,616 (1960 est.)
Organized labor: 6,700
Population: 119,000, average annual growth rate
1.6% (4/60-4/70)
Nationality: noun—St.
Lucian
Lucian(s); adjective—St.
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patols
Literacy: about 80%
Labor force: 38,000 (1969); 509% agriculture;
unemployment 30%-35% (1975)
Organized labor: 20% of labor force
Population: 94,000, average annual growth rate
1.19 (4/60-4/70)
Nationality: noun—St. Vincentian(s) or Vin-
centian(s); adjective—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian
and Carib Indian
Religion: Church of England, Methodist, Roman
Catholic
Language: English, some French patois
178
Literacy: about 80%
Labor forces 50,000 (1972 est); about 60%
unemployed
Organized labor: 10% of labor force','75dbf976362e9d1583260cb0045038f95e8efee2fc952046d8eb15ffc455a56c','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('264b78c2e72b7f9e26f1a5d2e7127706e490fa1db2f997389ce5003aa95c7c72',1975,'SM','San Marino','people-and-society',413,'Population: 19,000 (official estimate for 30 June
1974)
Nationality: noun—Sanmarinese (sing. & pl.);
adjective—-Sanmuarinese
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation
of Sanmarinese Workers (affiliated with ICFTU) has
about 1,800 members; Communist-dominated
Camera del Lavoro, about 1,000 members','762c004888258ac788c011bbf35b8fbc386a5ea8f3cd9e97a57cb12c9ebc0215','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70080380594cceb2d9a20f1a2ca6ef47c9ae34e6250475019a9e2a6321a6f544',1975,'SN','Senegal','people-and-society',417,'Population: (00.000) avenge anniial growth cate
225 67 7 491
Nationality:
noun Senegiabese (ange a pbb
dyective Senegalese
Ethnic divisions: joo) Wolof 1755 Bulso 16 9%
Serer, OO Vokotir 96 Dyefa O55 Malinke. $95
other Virean, Po Barrepecais aod Lebanese
Religion: 50° Mahi 15 animist) 5o Chastian
(mostly Rotien Catholiet
Language: French offend but regular ase tinited
to diterate minority most Senetalece speak own tubal
Janie se of Wolof cemnacular spreading HON
spoken tosome degree by neark half the population
Literacy: 56 TOC Cest ban Tt plas age roup
Labor foree: 1.732.000. about SUS sub stenece
agncultiral workers. abeut P25 000 waste eaeners
Organized Jabur: magents of wage Libor force
however dues poavaitng
represented by unions,
nembership ver limited','886050c9982c8932253a3f0e25099f2e53f458a202208761b05138fb17309e3d','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('003116587f67a76853a5ee825a2e47a99a9bf95bd30c069c43092d838d2ccf45',1975,'SC','Seychelles','people-and-society',421,'Population: 59.000, avenge anil growth nate
24 (7/68 7/72)
Nationality: noun
Seschelles
Ethnie divisions: Sevchellois (adimivture of Asians,
Africans, Europeans)
Keligion: VO% Roman Catholic
Language: English official, Creole most) widely
spoken
Sevehellois (sings & pl ),
wiljective
Literacy: limited
Labor force: 22,000 agricultuce
Organized labor: 3 major trade unions','826b95afe369323a53a3dc61632811e9079105edbe0983e25ef74d543a5be087','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('231fb2c10b59ea33ba53f84ee5ada056520c75fc9a59e1a72a10e528a2f58db2',1975,'SL','Sierra Leone','people-and-society',425,'Population: 2.748.000, averaye annual growth rate
Were ceca ase
Nationality: noun - Siena Leoneants), adrective
Sierra Leonean
Ethnic divisions: over 99% native African. rest
European and Asian. [3 tabes
Religion: 70% animist, 25° Muslim, 5% Christian
Language: English official, but regular use limited
to literate minority. principal vernaculats are Mende
in south and ‘Temmne in north, “Kerio” a form of
pidgin Engtish, is also widely spoken
Lateracy: about 10%
Labor force: about 1.5 million, most of population
engages in subsistence ayericulture, only small
minority, some TO.000, cam wages
Organized labor: 35° of wage carers','cb97346ea7502f781f5a7bd6765b9fb061d74630287be51440a3792ac661b493','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4318f6659607ac5dd7c4d57cbf7d6177d0ae1ac2f47019f928c259833f6faaf1',1975,'SG','Singapore','people-and-society',429,'Population: 2,251,000, average annual growth rate
1.6% (7/73-7/74)
Nationality:
Singaporan
Ethnic divisions: 76.2°% Chinese.
Indians and Pakistani, 1.8% other
noun—Singaporan(s); adjective—
15% Malay, 7%
biitseaniinvetes
Religion: majority of Chinese are Buddhists ar
atheists; Mativs nearly all Maslinn: minorities include
Christians, Elindus, Sikdis, Phaalsts, Goufuedanists
Language: national Lange is Malays Chinese,
Malay, Tamil, and Maglish are official bangers
Literacy: TOM (1970)
Labor force: ATATIS, OST ageiculture,
and) fishing, O06
minubaeturinag,
2138
COMMUNE CaT EOS
Organized labor: 245 of labor force','c0256bf42d668ce251ff7168064f75d56377aeb4b57d20349fa793ff71ee401e','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d4c9ebd1aeac7ca4497ac68dcbae6bdeff5f6e56000d3740cd25cc493e5f86',1975,'SO','Somalia','people-and-society',433,'Population: 3,153,000, average annual growth rate
24° (7/65-7/72)
Nationality: noun---Somali(s), adjective-- Somali
Ethnie divisions: 45° Ebimitic, rest mainly Bantu:
30,000 Arabs, 3.000 Europeans, 800 Asians
Keligion: almost entirely Mastin
Language: Somali (written form recently instituted
by yovernment): Arabie, Htalian, English
Literacy: under 5%
Labor force: 965,000 (1968 est). very few are
skilled laborers. TOC
agcriculturists, government employees, traders,
fishermen, handicraftsisen, other
pastoral nomads, 30%
Organized Jabor: law providing for government-
controlled labor union promulgated in June L971, but
union so far not established','dd0ac40855add3e9aa691b341f9b29e987f2ecbfefe4d4d0394943c2437bb332','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82f2621abc2647bba24111c5e6abd725f7dbe718957dcc6089d85c56fd376a36',1975,'DZ','Algeria','people-and-society',437,'Population: 35,596,000 (including the Balearic and
Canary Islands; alse including Alhucemas, Ceuta,
Chafarinas, Mehllas and = Penon de Velez de la
Gomera), average annual growth rate 1.1 (current)
Nationality: noun—Spaniard(s); adjective —
Spanish
Ethnic divisions: homogeneous composite of
Mediterranean and Nordic types
Religion: 99° Roman Catholic. 1° other sects
Language: Castilian Spanish spoken) by great
majority; but 17% speak Catalan, 7% Galician, and
2% Basque
Literacy: about 90%
190
Labor force (1973): 12.7 million: 25° 0 apricultace,
36 industry, SYS services: registered unemployment
iS 2.1% of labor force, in reality about 4%
Organized labor: 900 of labor force in compulsory
yovernment-controlled: svidicates
Population: 70,000 (estimate for (974)
Nationality: noun—Spanish Saharan(s):
tive—Spanish Saharan
Ethnic divisions: 71.5% Arab, Berber, and Negro
nomads; 28.5¢ Spanish
Religion: 72% Muslim, 28° Catholic
Language: Spanish (official), local Arabie or
Hassania
adjec-
Literacy: among Spanish, probably nearly 100%:
among nomads, perhaps 3%
Labor force: 12,000; 50% agriculture, 50 other
Organized labor: none','82dc6c6d07758d16a93e6eb9108e8fa63be6ba98c016121ed6d6000b0c184c32','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23f22d9249e8b77a8310929fa6381ab1c51beae7475f43cd5c64eae3fc050159',1975,'LK','Sri Lanka','people-and-society',439,'Population: 13,763,000, average annual growth
rate LOS (7/70-7/75)
Nationality: noun—Ceylonese (sing. and pl.)
adjective—Cevlonese
Ethnic divisions: 71{C Sinhalese, 21 Tamil, 6%
Moor, 2% other
Religion: 64% Buddhist, 20%
Christian, 6% Muslim, 1° other
Language: Sinhala official, spoken by about 70%
of population, Tamil speken by about 22%: English
Hindu, 9%
commonly used in government and spoken by about
10% of the population
Literacy: 82% (1970 est.)
Labor force: 4° million; 17% unemployed,
employed persons — 53.4% agriculture, 14.8% mining
and manufacturing, 12.4% trade and transport, 19.4%
services and other
Oraanized labor: 435% of labor force, over 50% of
which employed on tea, rubber, and coconut estates','97f9ad18f96da6767d13818aaeea9409dbe24628715b8be11392eb346d3bc9c3','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc176c21b6e03dedacca9ef10afe7209d4b7d38c4b6b8d9fa0ba2448eb78715f',1975,'SD','Sudan','people-and-society',443,'Population: (7.758.000, average anni’
rate 250 (FITB-T TAY
Nationality:
adjective —Sudanese
‘rowth
noun Sudsinese (singe. ut
Ethnie divisions: JO Arab, 6° Beja. 52° Negro,
2° foreigners, Eo other
Religions 73° Sunni Muslims in’ north, 259%
pagan, €% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse
dialects of Nilotie, Nilo-Hiamitic, and = Sudanic
languages, English: program of Arabization in process
Literacy: 5% to LOS
Labor force: 5.8 million; $5% agriculture, 15%
industry, commerce, services, ete, labor shortages
exist for almost all categories of employment
Population: U7 000) venue annual jrowth rate
ie Sree CS Or)
Nationality: noun Stememerts, adjective
Surrvatany
Ethniv divisions: 5.0%. Creole (Negrasand mixed).
MET Phndastand (east Thdnan Dido. fassanese,
8 Mosh Neg J Amenndin, b6t Chinese,
Ph BKuropeans Po other and onknown
Miastin, Hinde,
other in cotder of size (%
Religion Morasvien. Remven
Catholte,
tinknowe)
fiytures
Language: Dutch official, English widely spoken,
Taki Taki (Strnin Crealer as native binguage of
Creoles and lage franca, Hinds, fis anese
Literacy: 70%) to T4G
Labor foree: 100,000 (1971)
Organized labor: approw ks ef Labor force
Population: 494.000, averse annual growth rate
$25 Couerent)
Nationality: noun | Swazi(s), adjective -Swazt
Ethnic divisions: 06% Aftican, 36 Furopean, bf
tolatte
Religion: 43° animist, 576 Chastion
Language: Enyvlish and Swath are offend
languages, government business conducted in English
Literacy: about 25%
Labor force: 120,000, about 60,000 enyayted an
subsistence agdeulture, 35-60,000 Wate CUNO rs, TAN
agriculture, Tbe:
government. ERS manufacturing, £2 mining and
forestry, 35°C other (E968 est), 7,900 emploved in
South African mines (1969)
Organized labor: about 15° of wage earners are
unionized','ecb763551f1bc6b8d3dc891aaa5914b042cf3198aec362c511bd3763544a4714','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a019e212e749077a39b2cefdc6d8c1ecd802ec19ed444887d19f305e1f9af06',1975,'SE','Sweden','people-and-society',447,'Populations 4 POO avenute waned prow th pete
d''s Catterent)
Nationalety: neun Swedetd adjective Swedish
Kthate divistoas: homogenecons white population,
tral Larppishe receerits
Heligion: O26. Evaogelical Lathenan, 7o other
Protestant. Homan Catholic, boaters Onhedow 1S
other
Language: Swedish, sell Lapp and Pranish
peaking. minorities
Literacy: W.
Labortorce: tO mmillion. 6 €6: agriculture, forestry.
fishing, POLS mining and) manufoctonag. Tt
copstinetien, Pe és commerce 6095 tran portation
amth ocomeramee ations, 2056 senees ane ludings
rovermment, Oo ferakingeg 2 7 unemploved
Organicd labor: 805 of labor farce','dbdaa86889e0d0ddef800cbbd2a3ef2228a2ac8c8c16ccb006594bb377e4d5d3','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df17ec9cacb0f604029302d85a228f7b6475e61208e025f13a4ff98d53d3a323',1975,'CH','Switzerland','people-and-society',449,'Population: 6,524,000, average annual growth rate
OT (7/72-7/73)
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
SWITZENMLAND
Nationality: noun Swiss (singe de pl ho udjective
Savas
Ethnic divisions: total population 60° German,
19. French. 10% Dhl, 1 Romanseh. 15) other,
Saviss nationals THe German, 280° Preach,
Italian. 0 Homsed, bo other
Religions 335 Protestant, 466° Rone Catholic
Languages Swiss nationals TH German, 20%
French. AS Padian 1 Homioseli do: other, tatal
population OUT German EO Peeneh, 10%
fhilinn. PO Romanseh, Po other
Literacy: O8%
Labor force: 30 million, about one-fifth foreign
workers. mostly Elalion, GOS agriculture and forestry,
WS industey and: crafts, 20% trade and trans:
portation, 9° professions, 2° in public service,
10% domestic and other, no significant anemploy
ment shortage of both skilled and aaskitled kibor
6.597 unfilled vacancies in April 1972
Organized laber: 20°C of labor force
Population: 7,545 000, averyre annial prowth rate
BOO (T/T8-T/TN)
Nationality: noun Syrian(s), adjective Syrian
Kehuic divisions: 90.3 Arab: OF 7G Kands,
Acnenians, and other
Religion: 70.95 Sunni Maslin, 16.5% other
Muslim sects. 13.257 Christians of various sects
Language: Aribic, Kurdish, Armenian; French and
Kalish widely understood
Literacy: about 1%
Labor foree: 2 million, 67° ayricultare, 126
inclastey Gineluding, construction), 216 miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force','b240c98ba730fa33b38201489ea1a1088a88748b1e400a709eaf959f32186435','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c37ab6842c28e267bb0e15b9838b82c80d984aac0cc7d22f56d79febab2c602',1975,'TO','Tonga','people-and-society',453,'Population: 97,000, average annual growth rate
2.6 (7/67-7/73)
Nationality: noun—Tongan(s): adjective— Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian, Free Wesleyan Church chaims
over 30,000 adherents
Language: Tongan, English
Literacy: 90%%-95%; compulsory education — for
children between ages of 6-14
Labor force: agriculture 10,303; mining, 599
Organized labor: unorganized','67eac93b1c4ec850854c8bdbe76193a44a058c50e0bcf5a5b7f117737c05867a','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12e3733586a690c541fcdac5c3833f0187e7aafc7391c070041aae39b2023e79',1975,'TT','Trinidad and Tobago','people-and-society',457,'Population: 1,013,000, average annual growth rate
1.3% (4/60-4/70)
Nationality: noun—Trinidadian(s), Tobagan(s);
adjective—Trinidadian and Tobagan
Ethnic divisions: 43% Negro, 409 East Indian,
14% mixed, 1% white, 2% other
Approved For Release 2002/07/03
2.
AO ees
we
*
Caribbean Sav
S "y
nee 4 8 ca
Atlantic Ocean
TAINIDAD
AND TOBAQO
VENEZUELA
“AS
(See retevonce nap ti}
Religion: %6.8% Protestant, 31.2% Roman
Catholic, 236 Hindu, 6° Muslin, 13S unknown
Language: English
Literacy: 49%
Labor force: about 376,000 (1973 est.). about
164% agriculture, 18.7% mining, quarrying, and
manufacturing, 16.75° commerce; 16.2°¢ construction
and utilities; 7.40 transportation. and) com-
munications; 21.8% services, 3.8°¢ other
Organized labor: 30% of labor force','ea3ef0030ffbade332e8fed6f80bd0be976c164bb0ab2506f61e076745b05152','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0c684460948bcd33b9366b5e9e8cda81ebbd3830a68461eab5025b488382d7f',1975,'TN','Tunisia','people-and-society',461,'Population: 5,776,000, average annual growth rate
2.4% (7/73-7/74)
Nationality:
Tunisian
Ethnic divisions: 98% Arab, 1% European, less
than 1% Jewish
noun—Teunisian(s): adjective—
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
TUNISA/ TURKEY
Religion: 955) Mastin 66 Chiristion. (ou) Jewidh
Language: Arabic (official), Arabic and) Prench
(commerce)
Literacy: about 30%
Labor force: Et aiflion, 0%) apriendtere, Los
thangtaecturinge and consteetion, 55 teade and
finwiee, OS transporte diem, comanunioations, wel
utililies, 25 mining, 255 onderemploved, shontayce of
skied Labor
Organized labor: 10% of labor force, General
Union of Tunisiin Worker (UO TT), subordinate te
Destourian Soctalist Parts
Population:
rite 2055) Courrent)
SOTO OOO) avenge said growth
Nationality: noun Turks), adjective Vurkish
Ethnic divisions: 905 Turkish. 7 Kurd, 36 other
Religion: 995 Muslin Gnosth Sunni bo other
CGosth Christuan and pewsshy
Language: Turkish, Kurdish, Anite, English
Literacy: 555
Labor force: LSS mithon, GSS agnenlture, [Oo
industry, 16 serece, substantial shortage of chilled
Jaber. ample unskilled Libor
Organized labor: 10% of Ladi fotoe
(See toferonce map IV)
Labor force: approx. 700; Vatican City employees
divided into 3 categories — executives, officeworkers,
und salaried employees
Organized labor: none
COVERNMENT
Legal name; State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St.
Peter''s, the Vatican Palace and Museum and
neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries,
enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of
1929 serve some of the functions of a constitution
Branches: the Pope possesses full executive,
legislative, and judicial powers; he delegates these
powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican
offices include the Secretariat of State, the College of
Cardinals (chief papal advisers), the Roman Curia
(which carries on the central administration of the
Roma Catholic Church), the President of the
Prefecture for the Economy, and the synod of bishops
(created in 1965)
Government leader: Supreme Pontiff, Paul VI,
(Giovanni Battista Montini, born 26 September 1897,
elected Pope 21 June 1963)
Suffrage: limited to cardinals tess than 80 in age
Elections: Supreme Pontiff clected for life by
College of Cardinals
Communists: none known
Other political or pressure groups: none (exclusive
of influence exercised by other church officers in
univers! Roman Catholic Church)
Member: IAEA, Seabeds Committee
Population: 11,980,000 (excluding Indian jungle
population estimated at 32,000 in’ 1961), average
annual growth rate 3.0% (7/73-7/74)
Nationality: noun-—Venezuclan(s); adjective—
Venezuelan
Ethnic divisions: 67% mestizo, 21% white, 10%
Negro, 2% Indian
Religion: 949% nominally Roman Catholic
Language: Spanish
Literaev: 74% (claimed, 1970 est.)
Labor force: 3 million (1969); 24% agriculture, 6%
construction, 17% manufacturing, 6%6 transportation,
18% commerce, 25% services, 4% petroleum, utilities,
and other
Organized labor: 15% of labor force
Population: 24,323,000, average annual growth
rate 2.0% (current)
Nationality: noun—North Vietnamese (sing. &
pl.); adjective—North Vietnamese
Ethnic divisions: 85%-90% predominantly
Vietnamese; ethnic minorities include Muong, Thai,
Meo, and Man
Religion: Confucianism, Buddhism, Taoism.
Catholicism
Language: closely conesponds to the breakdown of
ethnic groups
Literacy: claimed to be 95 (1964)
Labor force: (1 January 1970) 9.6 million, not
including military, about 706 agriculture and 10%
industry
Population: 20,843,000, average annual growth
rate 2.6% (7/65-7/71)
222
South Vietnamese (singe &
South Vietnamese
Nationality: nour
pl): adjective
Ethnic divisions: 47 7 Vietnamese, 65 Chinese,
32° mountain tribesmen, 20% Khmer 025 Chain
Religion: 70% Buddhist Gat besast 5° Hoa Tio), 36
Cao Dai, and 106 Catholic, others inchide animist,
and sinall atimbers of Protestant, Mastin and Bindu,
tnost Buddhists are of Mahayana school or practice
combination of Buddhiss, Taoism, and Contuciin-
isn
Language: Vietnamese, French, Chinese, Enydish,
Khiner, tribal languages (Mon-Khiner and Mative
Polynesian), Cham (Matayo-Polynesian dialect)
Labor force: civilian work force 3.8 million (not
including armed forees), 67° agriculture, fishings, and
forestry; 15S industry and commerce; 385 domestic
and personal serviees, 5% government, 10%
unemployed
Organized labor: 500,000','8d88afca88926f4aa22691259d0d2ab67e90673f23ffc14f29064e16fdfecee6','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('349bb081c34c0e7d6715dead935c4326da8e888ad942b166241705c30f4e43dc',1975,'UG','Uganda','people-and-society',465,'Population: 11,549,000. average annual growth
rate 3.4% (current)
Nationality: noun—Ugandan(s),
Ugandan
Ethnic divisions: 90%
Asian, Arab
adjective —
African, ES European,
Approved For Release 2002/07/03 :
Lae sete oar mop Ut
Religion: about 606 qomeoally Chrstun. ot 105
Nfoodita, cost cusenpest
Language: Prnyteh official buyanda and Swahel
widely used. other Banta aitd Nilotie Langenages
Literacy: about 205 10%
Labor force: extunated f5 unlhon. of whieh
whout 290,000 00 paid labor remiarnimnye in sabuastence
ACTIVE EES
Organized labor: (25.000 union members
Population: 254.635.0000, avenge antnal serawth
nite Poe Coureent)
Nationality: noun Soviet(s), adjective Saviet
Ethnic divisions: 74 Slavie, 265° among some [70
ethnic grapes
Religion: 70% atheist, IK Russian Orthodox, 9%
Muslim. 346 other
Language: more than 200 hinguages and dialects
Gait least IS with more than Emilion speaker), 76%
Slavie group, 8& other Indo-European, PEG Altice.
30 Uralian, 2° Caueasion
Literacy: 98.550 of popu! dion Gages 9-49)
Labor force: civilian 129 million CIOT4) 27%
agriculture, 739 industry and other non-agricultural
fields, unemployed not reported, shortage of skilled
labor reported','600bf0bb9c2362d4f5270ff223b5c640e5139e8591b9bf313e83558ee5037300','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c962d0bee11e55ecf46954c340e6b3e27f4f514ca0601bcf9d372f1587a5a0cb',1975,'GB','United Kingdom','people-and-society',471,'Population: 56,102,000, overage annual growth
nite O.00 (eurrent)
Nationality: noun-—Briton(s), British (collective
pl); adjective—British
Ethnic divisions: 83° Knglish, 9° Scottish, 5%
Welsh, 3% Trish
Religion: 27.0 million Church of Kagland, 5.5
million Roman Catholic, 2.0 million Presbyterians,
760,000 Methodist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic (about
100,000 in Scotland)
Literacy: 98° to 99%
Labor force: 25 million; 3% agriculture, 2%
mining, 35% manufacturing, 6% government, 8%
transportation and ubilities, 66 construction, TES
distributive trades, 23¢7 services, 3% other, 36%
unemployed
Organized laber: 406¢ of labor force
Population: 5,046,000, averaye aintal yrowth nate
Qe (T/T 7/72)
Nationality: noun Upper Veltants), adjective
Upper Voltian
Ethnic divisions: more than 50 tribes, principal
tribe is Mossi (about 2.5 millon): other dimportient
yroups are Gorunsi, Senufo, Bobi, Bobo, Mande, and
Maulani
Religion: majority of population animist, about
20 Muslim, 5° Chiristhin (mainly Catholic)
Language: French official, tribal langgaygees belong
to Sudanic family, spoken by 50°C of the population
Literacy: 5° -10%
Labor force: about $5 of the economically active
population engaged in animal husbandry, subsistence
farming, and related agricultural pursuits; about
30,000 are wage carmen: about 20% of male labor
force migrates annually to peighboring, countries for
seasonal employment
Organized labor: 3) primary and several small
specialized unions','598ea07c2c075f9ca2b658723d29d61aac5fd548bc7a4dd5e8281d90b6d181a1','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('134ce70b77b94e868c741f24d0cc25a1cf0c4f03e744efee19ccb5e5a7209fc0',1975,'WF','Wallis and Futuna','people-and-society',475,'Population: 9,000, official estimate fort July 1973
Nationality: noun WallisonG, Futunan(s), or
Wallis and Futuna tshuider, adjective -Wallision,
Futuna, or Wane and Futuna bstanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','935dba56590673d4bd2fc5e5060424aefe4ec622016d850abc0d021f27ea4a66','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa34299c340190c3b8e2ef0a8b12dac38f4f0f058d9081affbe595ce3ea692d2',1975,'YE','Yemen','people-and-society',480,'Type: republic; power centered in ruling National
Front Party
Capital: Aden; Madinat ash Shab, administrative
capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal
matters) and English common law (for commercial
matters); highest judicial organ, Federal High Court,
*Excluding the islands of Perim and Kamaran for which no
data are available.
Approved For Release 2002/07/03
Interprets constitution and determine. disputes
between siites
Nranches: Presidential Council cabinet Sapretie
People s Couned
leaders: Chaitman of Presidents
Cound, Salton Hubavsi Al Pritae Minister Ali Nuasi
Muhwrined al Pheani, NE Sectetun General Abed
AL Battal tserait
Suffrage: veanted by constitution to all citizens 18
Population: 6,539,000, average annual growth rate
2.6% (7/T1-7/72)
Nationality: noun—Yemeni(s): adjective—Yemeni
Etknic divisions: 906 Arab, 10% Afro-Arab
(mixed)
Religion: i00% Muslim
Language: Arabic
Literacy: 15° (est.)
Labor force: almost entirely agriculture and
herding
226
July 197%','3c04b283b7f43120fe8fb9dc94513b40676db07f0d2f010489df0fadfa32658c','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fad1d2dfc3aa9ccd069df352dde09cb2d39fecb866ccb0722c2f4e19967900cc',1975,'ZM','Zambia','people-and-society',485,'Population: 4,870,000, average annual growth rate
2.5% (7/73-7/7T4)
Nationality: noun—Zambian(s), adjective —
Zambian
Ethnic divisions: 98.7 African, 1.15 European,
2% other
Religion: 82% animist, about 17% Christian, and
under 1S Hindu and Muslim
Language: English official; wide variety of
indigenous languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000) non-Africans; 155 mining, 9°
agriculture, 9% domestic service, 19% construction,
9% commerce, 10% manufacturing, 23°C government
and miscellaneous services, 65% transport
Organized labor: 100,000 wage earners, primarily
in industrial sector, are unionized (early 1968)','872d0dc7e28a4c43f23a659ffc977641036d0587787dcf3aa3f5a76bf14b3222','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4896a495407bc85fc46d6eb8794fbb2981e654b008ea5228109a0b43b466464',1975,'US','United States','people-and-society',488,'Population: 213,450,000, average annual growth
rate 0.7% (current)
Ethnic divisions: 87.2% white, 11.3% negro, 1.4%
other
Religion: total membership in religious bodies,
ISDA E000, Protestant 76,649,000, Ronin Catholic
4H AGO,000, 6.115.000, other
SAL SG
Language: Knylish, predominantly
lewish religions
Literacy: altnost complete
Labor force: 03 million (1974)
Organized labor: 214% of total (1972)','26c161ec5046c0daf6dcc102eb205a03a810d8e3189b28d9a33125cd25b82e07','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('244dbe47fc9057ff1372a379bfd4ffd1d3626949e651fe85e206debc37fde821',1975,'AF','Afghanistan','people-and-society',4,'Population: 18,928,000, average annual growth
rate 2.3% (7/72-7/78)
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9%
Uzbeks, 9% Hazaras, minor ethnic groups include
Chahar, Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim; 12% Shia Muslim,
1% other
Language: 50% Pushtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily Uzbek and
Turkmen), 10% 80 minor languages (primarily
Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.8 million (official est.); 75%-
80% agriculture and animal husbandry, 20%-25%
commerce, small industry, services; massive shortage
of skilled labor
Organized labor: none','adeeed7788ead14b3816e35eba22a77636b0cc86569254159f6116e1ef240181','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68f5639d269b4e37445cef2bc7504639f069554f7ebde37d1e2643da4bd100a4',1975,'AL','Albania','people-and-society',9,'Population: 2,421,000, average annual growth rate
2.9% (current)
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Religion: 70% Muslim, 20% Albanian Orthodox,
10% Roman Catholic (observances prohibited;
Albania claims to be the world’s first atheist state)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics
available, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture,
17.9% industry, 21.6% other nonagricultural','f2215f6d94a5ab80fdd6125fa4b661d13126ef1d82c7ad9c5a77d14308af648f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381b9dc7108fd72dc8d214c7ebfe8560dfb233240f269d8c5350f8d3ef7e952d',1975,'DZ','Algeria','people-and-society',13,'Population: 16,529,000, average annual growth
rate 3.2% (7/68-7/78)
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8%
industry, 24% other (military, police, civil service,
transportation workers, teachers, merchants,
construction workers); 40% of urban labor unem-
ployed
Organized labor: 17% of labor force claimed:
General Union of Algerian Workers (UGTA) is the
only labor organization and is subordinate to the
National Liberation Front
Population: 19,000 (official estimate for 1 July
1969)
Ethnic divisions: Catalan stock; 30% Andorrans,
61% Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French
and Castilian
Labor force: unorganized; largely shepherds and
farmers
Population: 52,803,000, average annual growth
rate 0.9% (7/68-7/73)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Population: 62,215,000 (including West Berlin),
average annual growth rate 0.2% (current)
Ethnic divisions: 99% Germanic, 1% other
Religion: 49% Protestant, 44.6% Roman Catholic,
6.4% other
Language: German
Literacy: 99%
Labor force: 27.2 million; 36.3% in manufacturing
and construction, 13.4% services, 12.2% commerce,
5.7% communication and_ transportation, 7.6%
mining, 8.4% agriculture, 15.0% self employed,
2.4% unemployed as of September 1974
Organized labor: 31% of total labor force; 37.5% of
wage and salary earners
Population: 35,410,000 (including the Balearic and
Canary Islands; also including Alhucemas, Ceuta,
Chafarinas, Melilla, and Penon de Velez de la
Gomera), average annual growth rate 1.1% (current)
Ethnic divisions: homogeneous composite of
Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great
majority; but 17% speak Catalan, 7% Galician, and
2% Basque
Literacy: about 90%
Labor force (1973): 12.7 million; 25% agriculture,
36% industry, 39% services; registered unemployment
is 1.5% of labor force
Organized labor: 90% of labor force in compulsory
government-controlled syndicates
Population: 70,000 (estimate for 1974)
Ethnic divisions: 71.5% Arab, Berber, and Negro
nomads; 28.5% Spanish
Religion: 72% Muslim, 28% Catholic
Language: Spanish (official), local Arabic or
Hassania
Literacy: among Spanish, probably nearly 100%;
among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none','73137cff491733dae7a52226b3d8b115ac94b41578e9e25ee38d7739717d4b82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8a3ea8eb88fc2c248678ddb5758efd91aabe9a0d884ec8239449f7cccd20dfd',1975,'AO','Angola','people-and-society',17,'Population: 6,051,000, average annual growth rate
1.6% (12/60-12/70)
Ethnic divisions: 93.6% African, 5% Europeans,
1.4% mulatto (1960)
wie
LIBYA PYRE suns 3
Religion: about 84%
Catholic, 4% Protestant
Language: Portuguese (official), many native
dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active
(1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','854e5c3a0ac82e2f72ad75d0ddb309297341ef637e68ba71a1098f88b609346b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c87250c98966175b56266808a7f02b0474a83eef900c7965f98e3033dbc586e',1975,'BR','Brazil','people-and-society',22,'Population: 79,000, average annual growth rate
2.6% (4/60-4/70)
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Population: 24,841,000, average annual growth
rate 1.5% (7/72-7/73)
Ethnic divisions: approximately 85% white, 15%
mestizo, Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less
than 20% practicing), 2% Protestant, 2% Jewish, 6%
other e
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25%
manufacturing, 20% services, 11% commerce, 6%
transport and communications, 19% other
Organized labor: 25% of labor force (est.)
Population: 202,000, average annual growth rate
8.0% (4/''70-7/78)
Ethnic divisions: 80% Negro, 10% white, 10%
mixed
Religion: Baptists 29%, Church of England 23%,
Roman Catholic 23%, smaller groups of other
Protestant, Greek Orthodox, and Jews
Language: English
Labor force: 69,000 (1970);.25% organized
Religion: Anglican, Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary
earners
Organized labor: 82%
Population: 5,206,000, average annual growth rate
2.6% (current)
Ethnic divisions: 50%-75% Indian, 20%-35%
mestizo, 5%-15% white :
Religion: predominantly Roman Catholic; active
protestant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972); 69.1% agriculture,
3.3% mining, 9.6% services and utilities, 8%
manufacturing, 10% other
Organized labor: 150,000-200,000, concentrated
in mining, industry, construction, and transportation
Population: 107,394,000, average annual growth
rate 2.8% (current)
Ethnic divisions: 60% white, 30% mixed, 8%
Negro, and 2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older
(1970)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8%
industry, 15.3% services, transportation, and
communication, 8.9% commerce, 4.8% social
activities, 3.9% public administration, 5.1% other
Organized labor: about 50% of labor force; only
about 1.5 million pay dues
Population: 187,000, average annual growth rate
2.9% (7/72-7/78)
Ethnic divisions: 93.0% Melanesians, 4.0%
Polynesians, 1.5% Micronesians, 0.3% Chinese, 0.8%
Europeans, 0.4% others
Religion: almost all at least nominally Christian;
Roman Catholic, Anglican, and Methodist churches
dominant
Literacy: 60%
Population: 152,000, average annual growth rate
3.3% (8/71-7/73)
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8%
industry, manufacturing, and construction; 33.8%
trade, transport, services; 2.9% other
Organized labor: 8.4% of labor force
Population: 22,600,000, average annual growth
rate 1.3% (6/68-6/73)
Ethnic divisions: 44% British Isles origin, 30%
French origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 8.4 million; 29% service, 22%
manufacturing, 16% trade, 8% transportation and
utilities, 6% agriculture, 6% construction, 8% other,
5.4% unemployed
Organized labor: 27% of labor force
Population: 25,184,000, average annual growth
rate 3.2% (current)
Ethnic divisions: 58% mestizo, 20% caucasian,
14% mulatto, 4% Negro, 3% mixed Negro-Indian, 1%
Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture,
13% manufacturing, 18% services, 9% commerce,
13% other (1964)
Organized labor: 13% of labor force (1968)
Population: 288,000, average annual growth rate
2.0% (9/66-9/72)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Population: 1,923,000, average annual growth rate
2.5% (current)
Ethnic divisions: 98% white (including mestizo),
2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85% :
Labor ferce: 607,000 (1973); 46.3% agriculture;
13.2% manufacturing; 11% commerce; 8% construc-
tion, transportation, and communications; 21.5%
other; shortage of skilled Jabor (1968)
Organized labor: about 11.5% of labor force
Population: 9,218,000, average annual growth rate
2.1% (current)
Ethnic divisions: 51% mulatto, 37% white, 11%
Negro, 1% Chinese
Religion: at least 85% nominally Roman Catholic
before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17%
industry, 6% construction, 6% transportation, 29%
services, 8% unemployed and underemployed
Organized labor: 46% of total force
Population: 4,630,000, average annual growth rate
2.9% (7/72-7/78)
Ethnic divisions: 73% mulatto, 16% white, 11%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8%
industry, 19% services and other
Organized labor: 12% of labor force
Population: 4,001,000, average annual growth rate
3.5% (5/61-6/71)
Ethnic divisions: 84%-88% mestizo; Indian and
white minorities, 6%-8% each
Religion: predominantly Roman Catholic,
probably 97%-98%
Language: Spanish
55
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Population: 349,000, average annual growth rate
1.5% (7/72-7/73)
Ethnic divisions: 90% Negro or Mulatto, less than
5% East Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, creole patois
Literacy: over 70% :
Labor force: 120,000; 25% agriculture, 25%
unemployed
Organized labor: 11% of labor force
Population: 5,773,000, average annual growth rate
2.8% (7/72-7/78)
Ethnic divisions: 41.4% Indian, 58.6% Ladino
(mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the’
population speaks an Indian language as a primary
tongue
80
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Literacy: about 30%
Labor force (1974): 1.75 million; 65% agriculture,
11.3% manufacturing; 11.2% services, 6.4% to
commerce, 2.6% construction, 2.4% transport, 0.2%
mining, 0.2% electrical, 0.8% other. Unemployment
estimates vary from 3 to 25%
Organized labor: 4% of labor force (1974)
Population: 5,004,000, average annual growth rate
2.1% (current)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
HAITI/HONDURAS
Ethnic divisions: over 90% Negro, nearly 10%
mulatto, few whites
Religion: 10% Protestant, 75% to. 80% Roman
Catholic (of which an overwhelming majority also
practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86%
agriculture, 12% industry, 2% unemployed; shortage
of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force
Population: 346,000, average annual growth rate
0.5% (7/70-7/73)
128
Approved For Release 2004/11/01 : CIA-RDP79-01051A000
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, less than 5% East Indian
Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10%
commerce and banking, 10% services, 9% industry,
17% other
Organized labor: 11% of labor force
Population: 58,835,000, average annual growth
rate 3.5% (current)
13]
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Population: 238,000, average annual growth rate
1.6% (1/71-1/78)
Ethnic divisions: 85% largely mixed Negro stock
except on Aruba where 12% Negro and approx. 55%
mixed Carib Indian and European; rest European
with some Chinese, especially on Aruba
Religion: predominantly Roman Catholic; sizable
Protestant, smaller Jewish minorities
Language: officially Dutch; predominantly
English; colloquial ‘“‘papiamento,” a Spanish-
Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry,
21% unemployed, 8% construction, 41% government
and services, 8% other
Organized labor: approx. 15% of labor force
Population: 2,089,000, average annual growth rate
2.4% (4/71-7/73)
Ethnic divisions: 75% mestizo, 15% white, 10%
Negro, Indian or mulatto
Religion: 95% Roman Catholic
Language: Spanish (official); small English-
speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and
over
Labor force: 620,000 (1974 est.); 50% agriculture,
12% manufacturing, 14% services, 24% other;
shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 2.5% of labor force
Population: 4,444,000, average annual growth rate
2.2% (7/72-7/78)
146
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700
Ethnic divisions: main Negroid groups 75% (of
which, Hausa 50%, Djerma and Songhai 21%);
Caucasian elements include Tuareg, Toubous, and
Tamacheks; mixed group includes Fulani
Religion: 80% Muslim, remainder largely animists
and a very few Christians
Language: French official, many African lan-
guages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of
population engaged in subsistence agriculture and
animal husbandry
Organized labor: negligible
Population: 1,643,000, average annual growth rate
3.1% (7/70-7/73)
Ethnic divisions: 70% mestizo, 14% Negro, 9%
white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder
mainly Protestant
Language: Spanish; about 14% speak English as
native tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and
over
152
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and
fishing; 9.7% manufacturing and mining; 6.8%
construction; 5% Canal Zone; 3.9% transportation
and communications; 1.2% utilities; national average
of 6.8% unemployed; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)
Population: 2,514,000, average annual growth rate
2.7% (10/62-7/72)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Population: 14,618,000 (excluding Indian jungle
population which was estimated at 101,000 in 1961),
average annual growth rate 2.9% (7/61-6/72)
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Queehua, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture,
17% services, 14% manufacturing, 9% trade, 4%
construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force
Population: 68,000, average annual growth rate
1.2% (4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant
sects, Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 109,000, average annual growth rate
1.6% (4/60-4/70)
Ethnic divisions: mainly of African Negro descent
_ Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture
Organized labor: 20% of labor force
Population: 94,000, average annual growth rate
1.1% (4/60-4/70) :
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian
and Carib Indian
Religion: Church of England, Methodist, Roman
Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60%
unemployed
Organized labor: 10% of labor force
Population: 412,000, average annual growth rate
2.3% (1/64-1/72)
Ethnic divisions: 35.5% Creole (Negro and mixed),
84.7% Hindustani (East Indian), 14.9% Javanese,
8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese,
1.3% Europeans, 1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman
Catholic, other — in order of size (% figures
unknown)
Language: Dutch official; English widely spoken;
Taki-Taki (Surinam Creole) is native language of
Creoles and lingua franca; Hindi; Japanese
Literacy: 70% to 75%
Labor force: 100,000 (1971)
Organized labor: approx. 33% of labor force
187
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
SURINAM/SWAZILAND
Population: 486,000, average annual growth rate
8.2% (current)
Ethnic divisions: 96% African, 3% European, 1%
mulatto
Religion: 43% animist, 57% Christian
Language: English and Swati are official
languages; government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in
subsistence agriculture; 55-60,000 wage earners, many
only intermittently, with 31% agriculture, 11%
government, 11% manufacturing, 12% mining and
forestry, 85% other (1968 est.); 7,900 employed in
South African mines (1969)
Organized labor: about 15% of wage earners are
unionized
Population: 1,006,000, average annual growth rate
1.3% (4/60-4/70)
Ethnie divisions: 43% Negro, 40% East Indian,
14% mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman
Catholic, 23% Hindu, 6% Muslim, 13% unknown
Language: English
Literacy: 80%
Labor force: about 376,000 (1973 est.), about
15.4% agriculture, 18.7% mining, quarrying, and
manufacturing, 16.7% commerce; 16.2% construction
and utilities; 7.4% transportation and com-
munications; 21.8% services, 3.8% other
Organized labor: 28% of labor force
Population: 11,901,000 (excluding Indian jungle
population estimated at 32,000 in 1961), average
annual growth rate 3.38% (1/73-1/74)
Ethnic divisions: 67% mestizo, 21% white, 10%
Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1969); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation,
18% commerce, 25% services, 4% petroleum, utilities,
and other
Organized labor: 45% of labor force
Population: 24,108,000, average annual growth
rate 1.9% (current)
Ethnic divisions: 85%-90% predominantly
Vietnamese; ethnic minorities include Muong, Thai,
Meo, and Man
Religion: Confucianism, Buddhism, Taoism,
Catholicism
Language: closely corresponds to the breakdown of
ethnic groups
211
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
VIETNAM, NORTH/VIETNAM, SOUTH
VIETNAM
Jd
MALAYSIA ae
Vay
INDONESIA”
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not
including military; about 70% agriculture and 10%
industry
Population: 20,579,000, average annual growth
rate 2.6% (7/65-7/71)
Ethnic divisions: 87.7% Victnamesc, 6% Chinese,
3.2% mountain tribesmen, 2.9% Khmer, 0.2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5%
Cao Dai, and 10% Catholic; others include animist,
and small numbers of Protestant, Muslim and Hindu;
most Buddhists are of Mahayana school or practice
combination of Buddhism, Taoism, and Confucian-
ism
Language: Vietnamese, French, Chinese, English.
Khmer, tribal languages (Mon-Khmer and Malayo-
Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not
including armed forces); 67% agriculture, fishing, and
forestry; 15% industry and commerce; 3% domestic
and personal services; 5% government; 10%
unemployed
Organized labor: 500,000','2ddc0365cf14cbd1bf0f1625bd012a4dd4cf9449b9c82c884b2f621fea1e1d12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24c14e3630009c89213b735ae5453de335a0ba737f81af44513572cc11d804f8',1975,'AU','Australia','people-and-society',31,'Population: 13,505,000, average annual growth
rate 1.8% (7/66-7/73)
Ethnic divisions: 99% Caucasian, 1% Asian and
aborigine
Religion: 98% Christian, 2% animist and others
Language: English
Literacy: 98.5%
Labor force: 4.76 million; 14% agriculture, 32%
industry, 37% services, 15% commerce, 2% other
Organized labor: 44% of labor force
Population: 930,916,000, average annual growth
rate 2.4% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang,
Uighur, Hui, Yi, Tibetan, Miao, Manchu, Mongol,
Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most
important elements of religion are Confucianism,
Taoism, Buddhism, ancestor worship; about 2%-3%
Muslim, 1% Christian
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
\\-
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
CHINA, PEOPLE’S REPUBLIC OF /CHINA, REPUBLIC OF
Language: Chinese (Mandarin mainly; also
Cantonese, Wu, Fukienese, Amoy, Hsiang, Kan,
Hakka dialects), and minority languages (see ethnic
divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85%
agriculture, 15% other; shortage of skilled labor
(managerial, technical, mechanics, ete.); surplus of
unskilled labor
Population: 566,000, average annual growth rate
1.8% (7/72-7/78)
Ethnic divisions: 42% Fijian, 50% Indian, 8%
European, Chinese and others
Religion: Fijians mainly Christian, Indians are
Hindu with a Muslim minority
Language: English and Fijian (official), Hindu-
stani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force
organized into 22 unions; unions organized along lines
of work, breakdown by ethnic origin causes further
fragmentation
Population: 129,053,000 (including West Irian),
average annual growth rate 2.4% (7/70-7/78)
Ethnic divisions: 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% Coastal Malays, 26% other
Religion: 90% Muslim, 4% Christian, 2%
Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay)
official; English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15%
industry, 15% miscellaneous and unemployed
Organized labor: 10% of labor force
Ethnic divisions: 90% Mongol, 4% Kazakh, 2%
Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about
4% Muslim, limited religious activity because of
Communist regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian,
and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large
percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable
information available)
Population: 7,000 (official estimate for 30 June
1969)
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese,
428 Europeans, 1,532 other Pacific Islanders
Religion: Christian (4 Protestant, 4 Catholic)
Language: Nauruan, a distinct Pacific Island
tongue; English, the language of school instruction,
spoken and understood by nearly all
Literacy: nearly universal
Population: 3,094,000, average annual growth rate
2.2% (1/73-1/74)
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified;
1% Hindu, Confucian, and other
Literacy: 98%
143
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
NEW ZEALAND/ NICARAGUA
Labor force: 1,021,800; 138% agriculture, 36%
manufacturing and construction, 9% transportation
and communications, 18% commerce and finance,
6% services, 16% administrative and professional, 2%
unspecified (1966 figures)
Organized labor: 36% of labor force
Population: 683,000, average annual growth rate
2.9% (12/70-7/72)
Ethnic divisions: 95% indigenous Timorese
belonging to the Malay racial group; 9 ethnic
divisions, each speaking a distinct dialect of Malay
structure; approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided
between Catholic and Protestant), remainder practice
animism
161
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
PORTUGUESE TIMOR/QATAR
Language: an estimated 9-15 dialects, of Malay
origin but mutually unintelligible; 75% of the
population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very
low; in 1971 total school enrollment was 35,000 out of
total school-age population of 80,000; 5% of natives
can speak Portuguese
Labor force: 90% engaged in primitive village
subsistence economy, 10% engaged as town laborers
and domestics','24a844f3304558b52187dde2211536e889e8f321d32cc9571d229adb2bccb360','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e7e5342477853b8914cd11ec528cd66b59693ddd43423afced8d7083b4a7000',1975,'AT','Austria','people-and-society',37,'Population: 7,575,000, average annual growth rate
0.5% (1/78-1/74)
Ethnic divisions: 98.1% German, 0.7% Croatian,
0.38% Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8%
none or other
Language: German
Literacy: 98%
10
Labor force: 2,608,300 (1973); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and
communications, 7% professions, 6% public service,
2% other; 2.4% registered unemployed; an estimated
200,000 Austrians are employed in other European
countries; foreign laborers in Austria number more
than 200,000 (1972); unemployment 2.1% (1972)
Organized labor: about 2/3 of wage and salary
workers (1971)','8f59bf73496bd38d839b9ae059e457ed4622881e08764727ece20d465fb699bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('613c8019026ad7e157782787d0a58f08d8d989a7d212c971a11423c799178673',1975,'BH','Bahrain','people-and-society',41,'Population: 237,000, average annual growth rate
2.8% (2/65-4/71)
Ethnie divisions: 90% Arab, 7% Iranian, Pakistani,
and Indian, 3% other
Religion: Muslim
Language: Arabic
Literacy: about 30% (1965)
Labor force: 53,274 (1965)','ae608cc5247dbe8be70a4604f394311126533b19fe47c50dbbb9d6c168e9a260','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('784b904e80e47d37b4b2cd94228e886540ab262d9e3783f099eb4c3aa81c0841',1975,'BD','Bangladesh','people-and-society',46,'Population: 79,570,000, average annual growth
rate 2.7% (current)
Ethnie divisions: predominantly Bengali; fewer
than 1 million “Biharis” and fewer than 1 million
tribals
Religion: about 83% Muslim, 16% Hindu; less
than 1% Buddhist and other
‘Language: Bengali
Literacy: about 20%
Labor force: over 26 million; extensive un-
deremployment; over 80% of labor force is in
agriculture','6447b3da62a1924e3b5457d842b6997d5f5239fa46cae21eedd3ea754189733c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0babeaa5b0082a3590da1a61f617301b1a9dd6e39f5dba6a2cb87b126b54b262',1975,'BB','Barbados','people-and-society',50,'Population: 239,000 (official estimate for 1 July
1973)
Ethnic divisions: 80% African, 15% mixed, 5%
European
~
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
BARBADOS/BELGIUM
VENEZUELA','295a77191a4a611c72d81bff4f175b97d0db0da8c0e19c5ac41d40375ac584dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c2a70a1c69968bbf40b25fdee968b89a87ba514f6b1a2b13ca2d55296877c01',1975,'BE','Belgium','people-and-society',52,'Population: 9,780,000, average annual growth rate
0.2% (current)
Ethnic divisions: 55% Flemings, 33% Walloons,
12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in
small area of eastern Belgium; divided along ethnic
lines
Literacy: 97%
Labor force: 4.0 million; approximately 95% is
found in the following sectors: 32% manufacturing,
24% services, 16% commerce, banking, and insurance,
8% construction, 7.5% transportation and communi-
cation, 4% agriculture, forestry, and fishing, 1.2%
mining, 0.8% public utilities and sanitary services
(1972); 4.1% unemployed, early 1974
Organized labor: 48% of labor force (1969)','8e94fbd631b9de69226f157efbd960f99c53bedda6515b69d8c3f0f0e94e1f3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e718f3e5be7239a0a0b6d70bae0d7c5ecc3cb70dd4da59c0468d56896d95f21',1975,'BZ','Belize','people-and-society',56,'Population: 137,000, average annual growth rate
2.9% (4/60-4/70)
Ethnic divisions: 51% Negro, 22% mestizo, 19%
Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-day Adventist, Methodist, Baptist, Jehovah’s
Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14%
manufacturing, 8% commerce, 12% construction and
transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel; over 15%
are unemployed
Organized labor: 8% of labor force','827be1400e42987c551358f14c3257430d662e293a122cfed7bbd1a2707864ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8389bc6ea0ddf512f1daea35535c15761b145aec791e42f3c3519eafacf342c3',1975,'BM','Bermuda','people-and-society',60,'Population: 56,000, average annual growth rate
1.6% (1/68-1/74)
Ethnic divisions: approximately 63% African, 37%
white
Religion: 47.5% Church of England, 38.2% other
Protestant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 24,700 (1970)','2d2a32f8ff99a820e4e1d7665a072a4dc0d3f2c46dadfbb94bc2cdc21db69dae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee2f735e896bee8182e3dffa029e9611592deead55b7bcef45e8faeb14f6f3a',1975,'BT','Bhutan','people-and-society',64,'Population: 1,161,000, average annual growth rate
2.3% (current)
Ethnic divisions: 60% Bhotias, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Bud-
dhist-influenced Hinduism
Language: Bhotias speak various Tibetan dialects,
most widely spoken dialect is Druk-ke, the official
language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1%
industry; massive lack of skilled labor','d6a971799a917e745cf2571ee2adae09981a90b147443a88bf6a1b265348513a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd42f508c3906b99b9ef49664a38b08a4ba519a95c15f0479dd45cdf7aeeec70',1975,'BW','Botswana','people-and-society',69,'Population: 669,000, average annual growth rate
2.4% (current)
Ethnic divisions: 94% Tswana, 5% Bushmen, 1%
European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in
Tswana; less than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle
raising and subsistence agriculture; about 51,000 in
internal cash economy, another 60,000 spend at least
6 to 9 months per year as wage earners in South Africa
(1971)
Organized labor: eight trade unions organized with
a total membership of approximately 9,000 (1972 est.)','fd22c18097307bcc92d2e1fb6cd6d8cbe2afd5101bae19b0367b1b8d9760dfe1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f30b9d8daad1c9974cc730a02dcbaff5da9a2fce4895a27d7391695e0c74dafb',1975,'BG','Bulgaria','people-and-society',73,'Population: 8,700,000, average annual growth rate
0.6% (current)
25
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks,
2.6% Gypsies, 2.5% Macedonians, 0.3% Armenians,
0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious
background of population is 85% Bulgarian
Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman
Catholic, 0.5% Protestant, Gregorian-Armenian and
other
Language: Bulgarian; secondary languages closely
correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.6 million (July 1973); 32%
agriculture, 38% industry, 35% other
Population: 30,078,000, average annual growth
rate 2.3% (7/70-7/78)
Ethnic divisions: 72% Burman, 7% Karen, 6%
Shan, 2% Kachin, 2% Chin, 2% Chinese, 3% Indian,
6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethni¢ groups have
their own languages
Literacy: 70% (official claim)
Labor force: 10 million; 67% agriculture, 18%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor
organizations have been disbanded, and government
is forming one central labor organization','762c4e499795412782222b7e17a12da013d28ea68ab8a562f1a8a76dbef31a63','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3050e88796fd122dd38377a6d1081fb7931f945d6c68ec24de4cbe990933a628',1975,'BI','Burundi','people-and-society',77,'Population: 3,732,000, average annual growth rate
2.4% (7/70-7/73)
Ethnic divisions: Africans — 86% Hutu (Bantu),
13% Tutsi (Hamitic), 1% Twa (Pigmy); non-A fricans
include (late 1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10%
Protestant); rest mostly animist plus small number of
Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili,
and 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of
Burundi Workers (UTB), membership about 30,000,
affiliated with government party','a7e5e53c7e891941e2706e0820a1ee09f616e1cf202293b911144d93ea3da046','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe1b327bf52e57bc393d6ebb0b989c04d668f6a3034f9b33cb54278d8df6fda9',1975,'KH','Cambodia','people-and-society',81,'Population: 7,552,000, average annual growth rate
2.2%. (7/68-7/69)
Ethnic divisions: 89% Khmer (Cambodian), 3%
Vietnamese, 5% Chinese, 3% other minorities
Religion: 95% Theravada Buddhism, 5% various
other
Language: Cambodian
Literacy: 55% (est. )
Labor force: 2.56 million; 80.9% agriculture, 5.5%
sales, 4.7% manufacturing, transport, communica-
tions, 3.9% professional, administrative, clerical, 3.5%
defense; 1.5% unemployed
Organized labor: 0.5% of labor force','2f7521c37c2bd819a486ae311990fd0c70664b530425a34f5a50cfd0b1d2daf8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0177c256ab0dedfee720793d08c78432b51128e3c57f8b197c4fe11a3883385b',1975,'CM','Cameroon','people-and-society',85,'Population: 6,308,000, average annual growth rate
1.7% (7/69-7/70)
Ethnic divisions: about 200 tribes of widely
differing background; 31% Cameroon Highlanders,
19% Equatorial Bantu, 8% Northwestern Bantu, 10%
Fulani, 7% Eastern Nigritic, 11% Kirdi, 18% other
African, less than 1% non-African
30
Religion: about one-half animist, one-third
Christian; rest Muslim
Language: English and French official, 24 major
African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in
subsistence agriculture and herding; 200,000 wage
eamers (maximum) including 22,000 government
employees, 63,000 paid agricultural workers, 49,000 in
manufacturing
Organized labor: under 45% of wage labor force','bc467ec44fcb4e185ef0ed7da2272a5a69bc7cb0e22a262da9ebf1fd1dc04455','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('899f2890c6697a164472d7a8dd05a99cdaa37f4ec741364c10d34de2f6ac6804',1975,'CF','Central African Republic','people-and-society',90,'Population: 1,767,000, average annual growth rate
2.2% (7/67-7/71)
Ethnic divisions: approximately 80-ethnic groups,
the majority of which have related ethnic and
linguistic characteristics; Banda (82%) and Baya-
Mandjia (29%) are largest single groups; 6,500
Europeans, of whom 6,000 are French and majority of
the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27%
animist, 5% Muslim; animistic beliefs and practices
strongly influence the Christian majority
Tosi A000 OOO OOO
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Language: French official: Sangho, the lingua
franca and unofficial national language
Literacy: estimated at 5%-10%
Labor force: about half the population cconomi-
cally active, 80% of whom are in agriculture;
approximately 64,000 salaried workers
Organized labor: 1% of labor force','ae1d7fd4251a797338cae53f85a0de7c0a901db025cb6c7d1b5a5d30e6801275','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccd6c850fd3b8de50d6501c4d499fdb8ea04b4f7bec9c9988e37a01c2f082a5e',1975,'TD','Chad','people-and-society',94,'Population: 3,988,000, average annual growth rate
2% (7/T1-7/72)
Ethnic divisions: over 240 tribes representing 12
major ethnic groups — Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-
Muslims (Sara, Mayo-Kebbi, and Chari) in the south;
some 150,000 nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian,
remainder animist
Language: French official; Chadian Arabic is
lingua franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in
economically active group, of which 90% are engaged
in unpaid subsistence farming, herding, and fishing;
47,000 wage earners in industry and civil service
Organized labor: about 20% of wage labor force','662883440432c95d809bb8ec397af67eaf130736bede7df2a40c7e627f30b5a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99afe833816c8560104d0139824eb828c0fbcb3f88e49dff3e118520080b5a8b',1975,'AR','Argentina','people-and-society',97,'Population: 9,804,000, average annual growth rate
2.0% (current)
Ethnic divisions: 85%-90% chileno (mixture of
European and Indian stock), 3% Indian, 7%
European, Asiastic, and other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.3 million (1973); 19% agricultural,
28% industry and construction, 29% services, 14%
commerce, 5% mining, 5% other (1973)
Organized labor: 25% of labor force (1973)
Population: 7,068,000 (excluding nomadic Indian
tribes), average annual growth rate 3.4% (7/72-7/73)
Ethnic divisions: 40% mestizo, 40% Indian, 10%
white, 5% Negro, 5% Oriental and other
Religion: 95%
nonpracticing)
Roman Catholic (majority
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture,
13% manufacturing, 4% construction, 7% commerce,
4% public administration, 16% other services and
activities
Organized labor: less than 15% of labor force
Population: 36,825,000, average annual growth
rate 2.2% (7/70-7/73)
Ethnie divisions: 90% Eastern Hamitic stock; 10%
Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt
and other
Language: Arabic official, English and French
widely understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50%
agriculture, 10% industry, 10% trade and finance,
30% services and other; serious shortage of skilled
labor
Organized labor: 1 to 3 million
Population: 801,000, average annual growth rate
2.5% (4/60-4/70)
Ethnic divisions: 51% East Indians, 48% Negro
and Negro mixed, 4% Amerindian, 2% white and
Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim,
1% other
Language: English
Literacy: 86%
‘Labor force: 201,000; about 25% agriculture, 14%
manufacturing, 16% services, 11% commerce, 3%
mining and quarrying, 10% other, 21% unemployed
Organized labor: 34% of labor force
Population: 3,047,000, average annual growth rate
1.2% (7/72-7/73)
208
Ethnic divisions: 85%-90% white, 5% Negro, 5%-
10% mestizo
Religion: 66% Roman Catholic (less than half
adult population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those
employed in important sectors — 25% government;
384% industry; 10% service; 23% other; 8%
agriculture, forestry, fishing and mining; no shortage
of skilled labor
Organized labor: about 25% of labor force (largely
Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern
languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories — executives, officeworkers,
and salaried employees
Organized labor: none','89a49ecba99211804a18779925fcdddd409adae7bbb83b386803f8d57c0108e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4aa041c4f200070b1895a347a8a34f739dfef9c7abdacc23eef7887c81b29f8',1975,'PH','Philippines','people-and-society',99,'Population: 15,846,000 (excluding the population
of Quemoy and Matsu Islands and foreigners),
average annual growth rate 1.8% (1/73-1/74)
Ethnic divisions: 84% Taiwanese, 14% mainland
Chinese, 2% aborigines
Religion: 98% mixture of Buddhism, Confucian-
ism, and Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language),
also Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 4.9 million; 33% primary industry
(agriculture), 32.1% secondary industry (including
manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972 _
Organized labor: about 12% of 1972. labor force
(government controlled)
Population: 41,960,000, average annual growth
rate 3% (7/68-7/73)
Ethnic divisions: 91.5% Filipino (Malay), 4%
Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant,
4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the
national language of the Philippine Republic; English
is the language of school instruction and government
business
Literacy: about 83%
. Labor force: 11 million; 60% agriculture, forestry,
fishing, 12% manufacturing, 10.5% commerce, 10.5%
government and services (business, recreation,
domestic, personal), 3.5% transport, storage,
communication, 3% construction; 0.5% other','52ac796a7333663ce68169df2a2c92286b7f0f46d96ead342153c53a2c140f3d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('166ced82586e9c9b4a43d4d204afc50c6dfe2013dc185ee80c0a498b9bd1c17c',1975,'CG','Congo','people-and-society',103,'Population: 1,330,000, average annual growth rate
9.5% (current)
Ethnic divisions: about 15 ethnic groups divided
into some 75 tribes, almost all Bantu; most important
ethnic groups are Kongo (48%) in south, Teke (17%)
in center, M’Bochi (12%) and Sangha (20%) in north;
about 8,500 Europeans, mostly French
Religion: about half animist, half nominally
Christian, less than 1% Muslim
Language: French official, many African lan-
guages with Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economi-
cally active, most engaged in subsistence agriculture;
79,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965
est.)','e40571a59c17135c94af9f3a76ebcf3b99d986105204aa3e2688c0bd1e4cd452','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c5d3c96456b18f16a0d3054a964f248d92ae2a6bf4340d3d4dc5dab0b29545c',1975,'CK','Cook Islands','people-and-society',107,'Population: 21,000, official estimate for 1 July 1972
Ethnic divisions: 81.3% Polynesian (full blood),
7.7% Polynesian and European, 7.7% Polynesian and
other, 2.4% European, 0.9% other
Religion: Christian, majority of populace members
of Cook Islands Christian Church','1431dd1dec21b4ca6ff92012b5aca562041377e71f3cd193ef2a58da068b6465','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34b0c064819f458f19063b36d54b91e9d31fc30cf75481c95deba745fedd61e4',1975,'CY','Cyprus','people-and-society',112,'Population: 670,000, average annual growth rate
1.4% (7/71-7/73)
45
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Ethnic divisions: 78% Greck; 18% Turkish; 4%
British, Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4%
Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture,
23% industry, 9% commerce, 2% mining, 28% other;
3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,742,000, average annual growth
rate 0.7% (current) ;
Ethnic divisions: 65.0% Czechs, 29.2% Slovaks,
4.0% Magyars, 0.6% Germans, 0.5% Poles, 0.4%
Ukrainians, 0.3% others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant,
2% Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37%
industry, 11% services, 34% construction, com-
munications and others
Population: 3,061,000, average annual growth rate
2.7% (8/68-8/72)
Ethnic divisions: 99% Africans (42 ethnic groups,
most important being Fon, Adja, Yoruba, Bariba),
5,500 Europeans
” Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in
agriculture; 15% civil service, artisans, and industry
Organized labor: approximately 75% of wage
earners, divided among two major and several minor
unions','b6c73ce2d43043060572a9c6e96211a3d2f04c504ed612f616081eea960243a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51678b8779a4480abf9f0a44057cf89954a4e2ef58a695c0ebaa793d7ad34f57',1975,'DK','Denmark','people-and-society',116,'Population: 5,064,000, average annual growth rate
0.4% (current)
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 1% other
Language: Danish;
minority
Literacy: 99%
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing, 26.6% manufacturing, 8.3% construction,
15.7% commerce, 6.8% transportation, 5.6% services,
25.7% government, 1.8% other; 6.3% of registered
labor force unemployed (September 1974)
Organized labor: 65% of labor force
small German-speaking
49
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Population: 2,000 (preliminary total from the
census of 8 December 1972)
Ethnie divisions: almost totally British
Religion: predomingntly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in
agriculture, mostly sheepherding','dbcff0b5d0e9e5ff37f0889b3a476722ccbadf3e2285fbb46ad904224ee1f6ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8340a8c55140db5220e5b0c062a8591566723f6fd092a4d477390dfca53b764f',1975,'CO','Colombia','people-and-society',121,'Population: 76,000, average annual growth rate
1.6% (4/60-4/70)
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England,
Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in
agriculture
Organized labor: 25% of the labor force
Population: 97,000, average annual growth rate
0.6% (4/60-4/70)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant
sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force
Population: 2,034,000, average annual growth rate
2.0% (7/71-7/73)
102
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Ethnic divisions: African 76.3%, Afro-European
15.1%, Chinese and Afro-Chinese 1.2%, East Indian
and Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman
Catholic, some spiritualist cults
Language: English
Literacy: Ministry of Education estimates between
43% and 57% of adult population functionally literate
Labor force: 808,300; 26% in agriculture, forestry,
fishing and mining, 10% manufacturing, 8% public
administration, 5% construction, 10% commerce, 3%
transportation and_ utilities, 15% services, 23%
unemployed (seasonal unemployment in agriculture
can push the unemployment figure to 25%); shortage
of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 110,256,000 (including Ryukyus),
average annual growth rate 1.2% (7/65-7/73)
Ethnic divisions: 99.2% Japanese, .8% other
(mostly Korcan)
Religion: most Japanese observe both Shinto and
Buddhist rites; about 16% belong to othcr faiths,
including 0.8% Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above
(1960 data)
Labor force (1969 figures): 51 million; 18.6%
agriculture, forestry, and fishing; 34.2% manufactur-
ing, mining, and construction; 36.4% trade and
services; 6.6% transportation; 3.1% government; 1.1%
unemployed; shortage of skilled labor 1.5 million;
unskilled .5 million (est.)
Organized labor: 20% of labor force','66c7875bea65ab312d517e263330b49ecb74342051308a2da94625b0ce23c676','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99f2f4ab31b34dba36359e0ed3f8a074e80f826fdec8af557c2cad0a8c397986',1975,'SV','El Salvador','people-and-society',125,'Literacy: 50% of population 10 years of age and
over (1973 est.}
Labor force: 1,395,000 (est. 1973); 57% agricul-
ture, 14% services, 14% manufacturing, 6%
commerce, 9% other; shortage of skilled labor and
large pool of unskilled labor, but manpower training
programs improving situation
Organized labor: 3.5% of total labor force; 6.6% of
nonagricultural labor force-(1972 est.)','0cf10fba2fea3c3f1ba3ab30f81e54b5923bde17c5ab485dcdbaabd055ccd292','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4619543e2209cd777c691f798b560f482b40963489a61fc0478f99a110c80b2',1975,'GQ','Equatorial Guinea','people-and-society',129,'Population: 315,000, average annual growth rate
1.8% (7/68-7/69); Rio Muni, 223,000, average
annual growth rate 1.5% (7/68-7/69); Fernando Po,
92,000, average annual growth rate 2.6% (7/68-7/69)
Ethnic divisions: indigenous population of
Province Francisco Macias Nguema primarily Bubi,
some Fernandinos; of Rio Muni primarily Fang; some
300-400 Nigerians, mostly on Fernando Po; less than
1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and
predominantly Roman Catholic; some pagan
practices retained
Language: Spanish official language of govern-
ment and business; also pidgin English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in
subsistence agriculture','06e9fba8937d2700d09faee456f9788abae1b17a443e40aefdd15f341f8d4bfd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b316039e20323b4fe9bf4443eb15840f37914eca646b0dfaeb492690344e67ce',1975,'ET','Ethiopia','people-and-society',133,'Population: 27,628,000 average annual growth rate
2.6% (7/68-7/72)
Ethnic divisions: Galla 40%, Amhara and Tigrai
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45%
Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages
and dialects; English major foreign language taught
in schools
Literacy: about 5%
58
Labor force: 90% agriculture and animal
husbandry; 10% government, military, and quasi-
Population: 3,344,000 (excluding East Jerusalem),
average annual growth rate 2.7% (7/73-7/74)
Ethnic divisions: 85% Jews, 15% non-Jews (mostly
Arabs)
Religion: 89% Judaism, 8% Islam, 3% other
Language: Hebrew official; Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,047,400; 8.0% agriculture, forestry
and fishing; 23.7% manufacturing (mining industry);
0.9% electricity and water; 9.5% construction and
public works; 13.1% commerce: 7.4% transport,
storage, and communications; 5.8% finance and
business; 24.1% public services; 7.5% personal and
other services (1972)
Organized labor: 90% of labor force','41dd08d486b1688d95d789085a0e70bdcb49d7dbd5550064504f1b01519add30','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a9ce6da3ceec8a84fecf8e4610b66e5e8746c1e27a535a8eb5d095587deb5f1',1975,'FR','France','people-and-society',137,'Population: 40,000, average annual growth rate
0.9% (4/66-11/70)
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faerocse (derived from Old Norse),
Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing,
manufacturing, transportation, and commerce
Ethnic divisions: 45% Celtic; remainder Latin,
Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish,
1% Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly
declining regional patois — Provencal, Breton,
Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 21,200,000 (1972 est.); 47% services,
39% industry, 12% agriculture, 2% unemployed
Organized labor: 17% of labor force, 23.4% of
salaried labor force
Population: metropolitan Portugal (including the
Azores and Madeira Islands, but excluding the Cape
Verde Islands) 8,515,000, average annual growth rate
—0.4% (7/70-7/73); Cape Verde Islands 270,000
(official estimate for 1 July 1972)
Ethnic divisions: homogeneous Mediterranean
stock in mainland, Azores, Madeira Islands; small,
but growing number of black workers principally from
the Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant
sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered very high by
some sources)
Labor force: 3.5 million (1974); 25% agriculture,
31% industry, 24% services; 8% military, 12% other;
unemployment is increasing duc to the return of
emigrants from other West European countries as well
as military forces from Africa
Organized labor: probably less than 50% of labor
force in trade unions which are united by Communist-
dominated intersyndical organization','1c50893267769c315d0ce5ef9c8df477b5e6ada7ff85add9de76c0b22fd70247','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('438849a5b74438da185d18144b006a34a9e2452fad944816a98cbe3ac759997b',1975,'FI','Finland','people-and-society',143,'Population: 4,684,000, average annual growth rate
0.4% (1/78-1/74)
62
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek
Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp-
and Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 15.9% agriculture,
forestry, and fishing, 26.9% mining and manufactur-
ing, 8.0% construction, 15.6% commerce, 7.0%
transportation and communications, 4.2% banking
and finance, 20.4% services; 2.0% unemployed
Organized labor: 60% of labor force','1699e54d361e3fcaa3cc8a4696ab0f9b605ae937a6ee9635f38e71bb89457e3b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c540884b0e60e0c781d66405b30b3d3f484ecf798ea98004573aec772683cf1',1975,'GF','French Guiana','people-and-society',147,'Population: 54,000, average annual growth rate
2.4% (7/68-7/73)
Ethnic divisions: 95% Negro or mulatto, 5%
caucasian, 10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%,
construction 21%, agriculture 18%, industry 8%,
transportation 4%; information on unemployment
unavailable
Organized labor: 7% of labor force','8262e086902590341be165ec1523c3c2f4f1c6f11247c5f92ef8a507e9361c97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e826d6e71432bbc3d7946cff21bd9019a8aeafa5238e6dcc1d4862e4867452',1975,'PF','French Polynesia','people-and-society',151,'Population: 120,000 official estimate for 1 July
1973
Ethnic divisions: 78% Polynesian, 12% Chinese,
6% local French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32%
Catholic
Population: 125,000 (official estimate for 1 July
1967)
Ethnic divisions: 59,350 Somalis (large number of
the Somalis are temporary immigrants from Somalia,
not citizens of territory), 53,650 Afars, 6,000 Arabs,
7,000 French (inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely
used
Literacy: about 5%
Labor force: a small number of semiskilled laborers
at port
Organized labor: some 3,000 railway workers
organized
Organized labor: unorganized
Population: 94,000, average annual growth rate
2.6% (7/66-7/73)
Ethnic divisions: 92% indigenous Melanesian, 3%
European, remainder Vietnamese, Chinese, and
various Pacific Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','f6a779f278442d9f3630f0250d4409f80ba18bfcf1a8efd9c5c3b5b4d112ef14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7d419eacae8ea856f1f425d514f5dcc648607cfed02edd31aab1f89ba7d9f92',1975,'GA','Gabon','people-and-society',155,'Population: 539,000, average annual growth rate
1.7% (7/66-7/70)
Ethnic divisions: about 40 Bantu tribes, including
4 major tribal groupings (Fang, Eshira, Mbede,
Okande); about 21,000 expatriate Africans and
Europeans, including 14,000 French
. Religion: 55% to 75% Christian, less than 1%
Muslim, remainder animist
Language: French official language and medium
of instruction in schools; Fang is a major vernacular
language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are
wage earners in the modern sector
Organized labor: less than 30% of wage labor force','339ff3603cdcc78564bb7a428f11ff1d4e80269f8f2ad77fdf1ac20a0b7cadac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dd4c72b1a3c65111ca3657d8f803b0c4b7ff99dfb683ec800eda0b1ce5419f2',1975,'GM','Gambia','people-and-society',159,'Population: 512,000, average annual growth rate
2.2% (7/66-7 /72)
Ethnic divisions: over 99% Africans (Malinke
40.8%, Fulani 13.5%, Wolof 12.9%, remainder made
up of several smaller groups), fewer than 1%
Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof
most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in
subsistence farming; about 15,000 are wage earners
(government, trade, services)
Organized labor: 25% to 30% of wage labor force
at most
Population: 16,885,000 (including East Berlin),
average annual growth rate —0.4% (current)
Ethnic divisions: 99.7% German, .3% Slavic and
other
Religion: 53% Protestant, 8% Roman Catholic,
39% unaffiliated or other; less than 5% of Protestants
and about 25% of Roman Catholics actively
participate
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7%
handicrafts; 6.8% construction; 11.9% agriculture;
70
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
6.8% transport and communications, 10.1%
commerce; 16.8% services; 2.5% other
Organized labor: 87.7% of total labor force','c5acfbc1cb08399fa89e644ad3f06bb70a82d9510195a13cfed568901ef89f60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f20c81be0883a57baf0d240eef9e3086c6874ddd737c9c778520d910823ef92f',1975,'GH','Ghana','people-and-society',163,'Population: 9,686,000, average annual growth rate
2.6% (7/71-7/72)
Ethnic divisions: 99.8% Negroid African (major
tribes Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12%
Muslim
Language: English official; African languages
include Akan 44%, Mole-Dagbani 16%, Ewe 13%,
and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and
fishing, 16.8% industry, 15.2% sales and clerical, 4.1%
services, transportation, and communications, 2.9%
professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of
labor force','20520a17280359daffff53bd071d9b0d7f7f2f60ee1bc04a1272eef36abfb8b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6ee40323348003bef7b290444a34c5a4ea09a135ceb500bdc8e63ccdfaff401',1975,'GI','Gibraltar','people-and-society',167,'Population: 29,000 (official estimate for 1 July
1972)
Ethnie divisions: mostly Italian, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian also
spoken; English used in the schools and for all official
purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltarian laborers
Organized labor: over 6,000','fa6a67fbc6f5b2a21d081b26fb186dc515ec9b30deb0d1e32d4317a5f194f38c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e311323bdf438ce11f3cc902596c3cc769d4c2b14421204fa30bdfa62ec1809',1975,'NL','Netherlands','people-and-society',172,'Population: 65,000, average annual growth rate
2.5% (7/63-7/73)
Ethnic divisions: 83.9% Micronesian, 13.9%
Polynesian, 0.9% European, 0.1% Chinese, 1.2%
mixed and other races
Religion: mainly Christian; 55% Protestants, 42%
Catholics
Literacy: less than 50%
Population: 13,584,000, average annual growth
rate 0.7% (current)
Ethnic divisions: 99% Dutch, 1% Indonesian and
other
Religion: 41% Protestant, 40% Roman Catholic,
19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 830% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9%
construction, 7% transportation and communications,
4% other; average unemployment rate 3% (Jan.-Aug.
1973); no shortage of skilled labor but shortage of
semi-skilled labor; 129,000 unfilled vacancies reported
by employers in January 1971
Organized labor: 33% of labor force','475e09c77c7f04e39397df21e77bd316a3dd1b65d4d1ae0856baa0982c5d6dd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60dc8df7fd1fc96a757b0a143799457980045cb773c680b00925b9960334797b',1975,'LY','Libya','people-and-society',175,'Population: 9,084,000, average annual growth rate
0.6% (7/68-7/72)
Ethnic divisions: 96% Greek, 2% Turkish, 1%
Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim,
0.5% other
Language: Greek; English and French widely
understood
Literacy: males about 92%; females about 73%;
total about 82%
Labor force: 3,866,000 (1969 est.); 50% agricul-
ture, 15% industry, 9% trade, 26% other; unemploy-
ment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors
aggravated by large-scale emigration
Organized labor: 10% of labor force','e414f89f8df4b2689f3cb2cd9fd17c4bedb140cac4e07f57c83a5f2aa0967a92','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf5adb4b11343e8a1aec2cdab959bf1727e06857bb4827efb7ef51c32d2a6bf5',1975,'GL','Greenland','people-and-society',180,'Population: 50,000, average annual growth rate
1.7% (1/70-1/72)
Ethnic divisions: 86% Grecnlander (Eskimos and
Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and
sheep breeding
Population: 216,000, average annual growth rate
1.1% (12/68-12/73)
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and
fishing; 25.6% mining and manufacturing; 10.7%
construction; 12.8% commerce; 7.8% transportation
and communications; 15.2% services; and 5.7% other;
unemployment is insignificant
89
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
ICELAND/INDIA
Organized labor: 60% of labor force','ca33bb59aa224af625e4e5d44e8dd632f7aeee00ebf72bd8da079cc9fb40480c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baed3404cdb96851dcb8f1f73fcce8f39c17d4e90369eb34c936c86136a9a210',1975,'GN','Guinea','people-and-society',184,'Population: 4,364,000, average annual growth rate
2.5% (current)
Ethnic divisions: 99% African (3 major tribes —
Fulani, Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less
than 1%
Language: French official; each tribe has own
language
Literacy: 5% to 10%; French only significant
written language
Labor force: 1.8 million, of whom less than 10%
are wage carers; most of population engages in
subsistence agriculture
Organized labor: virtually 100% of wage labor
force loosely affiliated with the National Confedera-
tion of Guinean Workers, which is closely tied to the
PDG','a0410434b686916d0aac943fbd83ca80f391fccdd797f3c11f9447083f1f9c2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7daa6c98d50dcbadd31e3fcdbb0da81ddd18d7f0e3337e862d0d13054205791e',1975,'GW','Guinea-Bissau','people-and-society',187,'Population: 491,000, average annual growth rate
0.2% (7/68-7/69)
Ethnic divisions: about 99% African (Balanta 30%,
Fulani 20%, Mandyako 14%, Malinke 18%, and 28%
other tribes); Jess than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African
languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in
subsistence agriculture','d6638604fded633d60b289f803e99dab14bab74338474129b77efffff4fa0d80','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48ce6460b38e41ab3d257f35a9447c8fa6c9abbe3e7a6d1ef02e44765f92b7e1',1975,'HN','Honduras','people-and-society',191,'Population: 2,931,000, average annual growth rate
3.5% (current)
Ethnic divisions: 90% mestizo, 7% Indian, 2%
Negro, and 1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57.4% of persons 10 years of age and over
(est. 1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5%
commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-
1972)','6c0bb6538e71d511fbcf66c80a04277db2c779ad20d1de61ea918387908ed36a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02da9835e090b30fc00e837297b4a9e5dcfdd634bb4b2b9f33a1494d78869a1f',1975,'HK','Hong Kong','people-and-society',195,'Population: 4,264,000, average annual growth rate
1.7% (7/70-7/73)
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of
local religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 43%
manufacturing, 20% services, 11% construction,
mining, quarrying and utilities, 13% commerce, 4%
agriculture, forestry, fisheries, and hunting, 7%
communications, 2% other; underemployment is a
serious problem
Organized labor: 12% of 1969 labor force','0050e57a753fda44748625fe278e26abaa0dbee5b1c893bb2bdbd519f3c9a5a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19b581ff058b8dbfbbeb7e628c67cc565cb9589655c229894973a19df273abca',1975,'HU','Hungary','people-and-society',199,'Population: 10,480,000, average annual growth
rate 0.3% (current)
Ethnic divisions: 93.3% Magyar, 2.5% German,
2.4% Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist,
5.0% Lutheran, 7.5% atheist and other
88
Approved For Release 2004/11/01 : CIA-RDP79-01051A0007000100
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,061,200 (1 January 1973); 24%
agriculture, 44% industry and building, 16% trade
and transport, 16% other nonagricultural','4fc625ae951afaf52a55c96cd23bd7d323453cb37b3fee3d68e9fea378209af1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7328ed4564f591383af3b903b304fd564cc54e082100bae3a6614184a84520d',1975,'IN','India','people-and-society',202,'Population: 592,815,000 (including the Indian-
held part of disputed Jammu-Kashmir, but does not
take into account the refugees who entered India from
Bangladesh during 1971, most of whom presumably
have returned), average annual growth rate 2.1%
(7/70-7/73)
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian,
3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh,
2.6% Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or
more persons each; numerous other languages and
dialects, for the: most part mutually unintelligible;
Hindi is the national language and primary tongue of
30% of the people; English enjoys “associate” status
but is the most important language for national,
political, and commercial communication; Hindu-
stani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29%
(1971 census)
Labor force: about 184 million; 70% agriculture,
more than 10% unemployed and underemployed;
shortage of skilled labor is significant and
unemployment is rising
Organized labor: about 2.5% of total labor force','d0747b3bc7521d45d03a981d180bb3a325447000a15a9f909a315a2127545f4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9ca481b176d94952722cbd7c6390e615dfe2c272376cd815d657d14b3ab7234',1975,'SG','Singapore','people-and-society',205,'Population: 32,704,000, average annual growth
rate 8% (1/71-1/72)
"93
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
IRAN
Ethnic divisions: 63% Ethnic Persians, 3% Kurds,
13% other Iranian, 18% Turkic, 3% Arab and other
Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim;
2% Zoroastrians, Jews, Christians and Baha''is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 33% of those 10 years of age and
older (1972 est.)
Labor force: 7.5 million; 47% agriculture, 53%
industry, commerce and services; shortage of skilled
labor substantial :
Organized labor: 1.1% of labor force
Population: 10,842,000, average annual growth
rate 3.4% (10/72-10/73)
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks
Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5%
industry, 6.7% government, 16.8% other; rural
underemployment high, but not serious because low
subsistence levels make it easy to care for
unemployed; severe shortage of technically trained
personnel
Organized labor: 11% of labor force
Population: 2,243,000, average annual growth rate
1.8% (7/72-7/73)
Ethnic divisions: 76.2% Chinese, 15% Malay, 7%
Indians and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or
atheists; Malays nearly all Muslim; minorities include
Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese,
Malay, Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry,
and fishing, 0.4% mining and quarrying, 32.2%
manufacturing, 30.4% services, 5.2% construction,
21.5% commerce, 9.8% transport, storage, and','64347abe4d9e8956005b596bb5d477d51a8c4365c17f364f0135275474fc090b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('356f426698639941c45932172f7da0a12989c9c5964eaefb8469f97ce7966302',1975,'IE','Ireland','people-and-society',208,'Population: 3,057,000 average annual growth rate
0.6% (7/63-7/73)
Ethnic divisions: racially homogeneous Celts
96
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Religion: 94% Roman Catholic, 4% Anglican, 2%
other
Language: English and Gaelic official; English is
generally spoken
Literacy: 98%-99%
Labor force: about 1,134,000 (1971); 26%
agriculture, forestry, fishing; 19% manufacturing;
15% commerce; 7% construction; 5% transportation;
4% government; 24% other
Organized labor: 36% of labor force','689601813424ee6fb9d7ba2dac4a2ac7a337e88db6752035d89263c3de16fa1f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49228074b30cf6147152cda35a3ed2cddc7df47361d76d95fbc474952a01ad0f',1975,'IL','Israel','people-and-society',214,'Population: 55,540,000, average annual growth
rate 0.7% (1/66-1/74)
Ethnic divisions: primarily Italian but population
includes small clusters of German-, French-, and
Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic
(de facto state religion)
Language: Italian; parts of Trentino-Alto Adige
Region (e.g., Bolzano) are predominantly German
speaking; significant French-speaking minority in
Valle d’Aosta Region; Slovene-speaking minority in
the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972);
illiteracy varies widely by region
Labor force: 19,246,000 (April 1974); 16.6%
agriculture, 43.7% industry, 89.7% other, 2.5%
unemployed; underemployment, particularly in
southern Italy, remains widespread; 1.5 million
Italians employed in other Western European
countries
Organized labor: 20% (est.) of labor force
Population: 4,822,000 (resident African population
only), average annual growth rate 2.6% (current)
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of population;
most important are Agni, Baoule, Krou, Scnoufou,
Mandingo; approx. 1 million foreign Africans, mostly
Voltaics; about 33,000 non-Africans (25,000 French)
Religion: 66% animist, 22% Muslim, 12%
Christian
Language: French official, over 60 native dialects,
Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of
labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce,
and professions
Organized labor: 20% of wage labor force','dea1e9d84766a4dfbfc41a4b16d77e7ed08d3f84694c1ad0cba8b6b02d5539bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f561a375fbeddaecad499eee2e95913baad4c8873dac4849d2279c941ce5f9e0',1975,'JO','Jordan','people-and-society',216,'Population: 2,658,000 (including West Bank and
East Jerusalem), average annual growth rate 3.6%
(11/72-11/73)
Ethnic divisions: 98% Arab, 1% Circassian, 1%
Armenian ;
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 50% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force','e11acec9e7fb61a1d171f6830dc67a5329abab70ed5e2eab1855a0a6b917bc36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cf6f19633bfa803ad29c48120d9d118f0dce3bd72f24867ad28ac0c0c8144d2',1975,'KE','Kenya','people-and-society',220,'Population: 13,133,000, average annual growth
rate 3.4% (7/72-7/73)
Ethnic divisions: 97% native African (including
Bantu, Nilotic, Hamitic and Nilo-Hamitic); 2%
Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim,
1% Hindu
Language: English and Swahili official: each tribe
has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 16,251,000, average annual growth
rate 3.1% (current)
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious
activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 47.7% agriculture, 52.3%
non-agricultural; shortage of skilled and unskilled
labor
Population: 33,741,000, average annual growth
rate 1.7% (7/72-7/73)
Ethnic divisions: homogeneous; small Chinese
minority (approx. 20,000)
Religion: strong Confucian tradition; pervasive
folk religion (Shamanism); vigorous Christian
108
minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai);
Chondokyo (religion of the heavenly way), eclectic
religion with nationalist overtones founded in 19th
century, claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971); 46.2%
agriculture, fishing, forestry, 32.3% services, 14%
mining and manufacturing, 3% construction, 4.5%
unemployed
Organized labor: about 10% of nonagricultural
labor force','cec6e963898246466b5603df9ed8a386f7c87cb446fdb084c506d1fc37ea8fe6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd5a932f8bc63b24d02ace63b6d2086612aa0b8b3739eecbc26fc98d35f7ecc1',1975,'KW','Kuwait','people-and-society',224,'Population: 954,000, average annual growth rate
5.3% (7/72-7/73)
Ethnic divisions: 87% Arabs, 12% Iranians,
Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu,
Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 55% (1965)
Labor force: 250,000 (1969); 9% manufacturing,
16% construction, 45% services, 13% commerce
Organized labor: labor unions, first authorized in
1964, formed in oil industry and among government
personnel
L09
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
KUWAIT/LAOS
Population: 3,297,000, average annual growth rate
2.4% (7/72-7/73)
Ethnie divisions: 47% Lao; 14% Tribal Tai; 23%
Phoutheung (Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant
foreign language also used in administration
Literacy: about 12%
Approved For Release 2004/11/01 : Cl
ba
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
LAOS
Labor force: about 1,268,000; 80%-90% agri-
culture; 159,286 engaged in manufacturing and
services; 28,400 (22,400 civil and 6,000 police)
government employees in FY72
Organized labor: a labor fedcration was formed in
mid-1974, but labor organization remains in_ its
infancy','7ac33e6229da856aabb062c026cb3d94d88eb3077a43197b37a38b9bfd651c09','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1cdb9374ad23d890f34a76b5fb135e59ab0daaebb93fb0c307f25186d5cb85c',1975,'LB','Lebanon','people-and-society',228,'Population: 2,412,000, average annual growth rate
3.1% (current)
Ethnic divisions: 93% Arab, 6% Armenian, 1%
other
Religion: 55% Christian, 44% Muslim and Druze,
1% other (official estimates); Muslims believed to
constitute slight majority
Language: Arabic (official); French is widely
spoken_
Literacy: 86%
Labor force: about 1 million economically active;
49% agriculture, 11% industry, 14% commerce, 26%
other; moderate unemployment
Organized labor: about 65,000','6a41096bcd8fd094e69ad99358321627ae9c466a9989f03abcb7b6d82b0c2b3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21737d09b1b54085eff63ba76726c9a033b6a1c9bbc387b883793932a9cb65a7',1975,'LS','Lesotho','people-and-society',232,'Population: 1,028,000, average annual growth rate
3.4% (7/72-7/73)
Ethnic divisions: 99.7% Sotho, 1,600 Europeans,
800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular;
English is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged
in subsistence agriculture; 150,000 to 250,000 spend 6
months to many years as wage earners in South Africa
Organized labor: negligible','0b5bf0e3ad72554dc45798aa503aa600fbe824aaba11e0e846534ed54543707d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fe708a369bb9ccf58b169eca6d43c147ece9067f127f3ec8a6920da809423e4',1975,'LR','Liberia','people-and-society',236,'Population: 1,737,000, average annual growth rate
2.9% (current)
114
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Lipya JEGYRT
%& SAUDI
Ethnic divisions: 5% coastal descendants of
immigrant Negroes; 95% indigenous Negroid African
tribes including Gola, Kissi, Vai, Kpelle, Kru, and
Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or
dialects, pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 500,000, of which 150,000 are in
modern economy; about 2,000 non-African foreigners
hold about 95% of the top level management and
engineering jobs
Organized labor: 2% of labor force','9c632c1c2944a7baa6d59af326ab6d1647cab4b6bfb71087bf39da2341781b0d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce18f46ef4dc0bef20cf0c1cf559df021184a87fba56a77a2667dea56e12dde1',1975,'DE','Germany','people-and-society',241,'Population: 2,282,000, average annual growth rate
3.7% (7/72-7/78)
Ethnic divisions: 97% Berber and Arab with some
Negro stock; some Greeks, Maltese, Jews, Italians,
Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely
understood in major cities
115
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
LIBYA/LIECHTENSTEIN
Literacy: 35%
Labor force: 485,000; between ages 15-64,
405,000-430,000; 61% of labor force in agriculture
(1964)','575bf7c5ebca649580b1b54a9058fbf8c47a96ce2cb43179816d38fafb389ce2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcc82aca5ebda2b90f00e8ba7129dc4346255919077306bd285d17acafb65ad5',1975,'LI','Liechtenstein','people-and-society',244,'Population: 24,000, average annual growth rate
2.5% (12/60-12/70)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
LIECHTENSTEIN/LUXEMBOURG
NORWAY. 2202
* c
- ASWEODEN 22
4
Ethnic divisions: 95% Germanic, 5% Italian and
other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly
from Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8%
agriculture','e8478d4877f9fe07cef0117e65a10372c5dcfa1c82143dfa04a43d051e12ce77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a394f2e7c266b946efbdbe24d739395978394972488f5a58464dbe6463dc9f07',1975,'LU','Luxembourg','people-and-society',249,'Population: 356,000, average annual growth rate
0.7% (1/66-1/74)
117
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French,
German, Belgian, etc.
Religion: 97% Roman Catholic, remaining 3%
Protestant and Jewish
Language: Luxembourgish, German, French; most
educated Luxembourgers also speak English
Literacy: 98%
Labor force; (1973) 154,000; 10% agriculture
(including forestry and fishing), 48% industry, 42%
services, no significant unemployment; 28% of labor
force is foreign, comprising workers from neighboring
areas of Belgium, France, and West Germany, as well
as Italy and Portugal
Organized labor: 45% of labor force','ec6bf0d36dd4e4f19f01c68c9c7f3d9048f84d796fd41e57a5db9bd1ce90752c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42e11bdfe6721384c05e3c6bce859ffb27aaba4b65306e34d8c64929d68b388b',1975,'MY','Malaysia','people-and-society',253,'Population: 251,000 (official estimate for 1 July
1972)
Ethnic divisions: 99% Chinesc, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and
Macanese; no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing,
3% construction, 1% utilities, 27% commerce, 8%
transportation and communications, 26% services
(1960 data)
Population: 11,706,000, average annual growth
rate 2.7% (current)
West Malaysia: 9,840,000, average annual growth
rate 2.6% (6/57-8/70)
Sabah: 769,000, average annual growth rate 3.7%
(8/60-8/70)
Sarawak: 1,097,000, average annual growth rate
2.7% (6/60-8/70)
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal,
10%. Indian and Pakistani, 2% other
Ph]
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
West Malaysia: 50.1% Malay, 36.9% Chinese, 11%
Indian and Pakistani, 2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes,
9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes,
17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly all Muslim, Chinese
predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and
Confucianist, 16% Christian, 35% tribal religion, 2%
other
Language:
West Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among
Chinese
Sarawak: English, Malay, Mandarin, numerous
tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture,
forestry, and fishing, 11% manufacturing and
construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 13%
trade and transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 13%
trade, transportation, and services, 1% other
Oxganized labor: 370,000 (official 1967 est.) about
10.5% of total labor force; 28% of wage labor force;
unemployment about 8% of total labor force, but
higher in urban areas','fe8b4acebbf777d13a2e89f833284b4e8a03e2f5605a3194db49a037d38ef5d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56f4a648975e421bcdcb31c77b4caefdc9e088af70747435299a8b9c8527eab1',1975,'MG','Madagascar','people-and-society',257,'Population: 7,469,000, average annual growth rate
2.3% (7/69-7/70)
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000),
on the one hand, and coastal tribes with mixed
Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka
941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415,000; there are also 38,000 French,
66,000 other
Religion: more than half animist; about 41%
Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence
agriculture; of 175,000 wage and salary earners, 26%
agriculture, 17% domestic service, 15% industry, 14%
commerce, 11% construction, 9% services, 6%
transportation, 2% miscellaneous
Organized labor: 4% of labor force','d089fe5ce14c4009d9a112f38e71ce71cbed2eba739c1b3846573f4da2c05106','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a22155c0f5eb6b933c140db2f0ee2f4b9f3d84198333d28a06c64c6c9ca0f1b4',1975,'MW','Malawi','people-and-society',261,'Population: 4,979,000, average annual growth rate
2.6% (7/71-7/73)
Ethnic divisions: over 99% native African, less than
1% European and Asian
Religion: majority animist; rest Christian and
Muslim
Language: English and Chichewa official; Lomwe
is second African language
Literacy: 6% of population over 21 years old
Labor force: 180,000 wage earners employed in
Malawi (1971); 6,000 Europeans permanently
employed; 300,000 Malawians live and work in
Rhodesia, South Africa, and Zambia; 30% agriculture,
11% construction, 10% commerce, 13% manufactur-
ing, 10% administration, 26% miscellaneous services
Organized labor: small minority of wage eamers
are unionized','3ac75554b746dbf1ac914ed49a8e60eca737ecac8c672b7ff5e822231019da49','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9803b922886fc1b42148d7bae4dd21c05b443090462f9be3458e463e64f7883',1975,'MV','Maldives','people-and-society',265,'Population: 118,000, average annual growth rate
2% (current)
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the
male population','c6b69aac57bb38920fe6f72786acab0746eea92ce3650947afa61dbd687fb63b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4889f8db407e0881b5aa62534a0f7d6788d4709e84e0ae1774a7b8bc2fd30ef',1975,'ML','Mali','people-and-society',269,'Population: 5,560,000, average annual growth rate
2.3% (7/72-7/73)
Ethnic divisions: 99% native African including
tribes of both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African
languages, of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried,
50,000 of whom are employed by the government,
most of population engaged in agriculture and animal
husbandry
Organized labor: UNTM, which claimed all
eligible employees, dissolved; thirteen national unions
currently directed by a government controlled
Coordination Committee of Mali Trade Unions
(CCSM)','109da4fff2347f122118d932d5ccdf1d899cf798d41bef108707d73c9484cdea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9751902e83bd3d4af0d1d4035363f6d1ba6ea90bf75a64c2f26c1072b7c28715',1975,'GR','Greece','people-and-society',272,'Population: 318,000 (official estimate for 31
December 1973)
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education
introduced in 1946
Labor force: 107,500; 29% services, 23%
government, 24% manufacturing, 6% agriculture, 4%
construction, 4% transportation and communications,
5% utilities and drydocks, 5% unemployed
Organized labor: approximately 35% of labor force','56cf21a4604d5ec350f53c9ea590730e5d2cb5266c849fbe375470b721d67c47','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88de252df51ac9ae393e1bbabc4decfd9e64cd0e0e54aca9adf9c03c6d461c7a',1975,'MR','Mauritania','people-and-society',279,'Population: 1,304,000, average annual growth rate
2.6% (current)
Ethnic divisions: 70% Moor, 30% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: about 10%
Labor force: about 18,000 wage earners (1973);
remainder of population in farming and herding
LiBYA EGYRT
SAUDI
Organized labor: 18,000 union members claimed
by single union, Mauritanian Workers’ Union','84b8e620e294f71827c757927464d8f2795fcfd151ea21c438e8c46267a80d12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a240133b97b181fd0d24a18e8edd83a0eaea4d4dca18513e2ce0d483291df18c',1975,'MU','Mauritius','people-and-society',283,'Population: 882,000, average annual growth rate
1.2% (1/72-1/73)
Ethnic divisions: Indians 67%, Creoles 29%,
Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly
Catholic with a few Anglican Protestants), 16%
Muslim
Language: English official language; Hindi,
Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90%
for those of school age
Labor force: 175,000; 50% agriculture, 6%
industry; 20% government services; 14% are
unemployed, under-employed, or self-employed, 10%
other
Organized labor: about 35% of labor force','bacb8112b87c3cfc19965779c74e3ae34aae8895ce2d30df6cc70714b58e3797','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9210513a5302b40338951215a442b090d339b726dcfab699a67ee073d0290da',1975,'MX','Mexico','people-and-society',287,'Ethnic divisions: 60% mestizo, 830% Indian or
predominantly Indian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic, 3%
other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force (1973): 13.1 million (defined as those
12 years of age and older); 39.5% agriculture, 16.7%:
manufacturing, 16.6% services, 16.8% construction,
utilities, commerce, and transport, 3% government,
7.4% unspecified activities
Organized labor: 20% of total labor force','5615a6d5840f14e9e46e037a3cc3c9d5a9524eac3abc227e7296f8550faf51fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2031afb3844c5b284c0d66430c31adced93eb8f1842bbbfad1115fa5d64cfe3d',1975,'SE','Sweden','people-and-society',291,'Population: 24,000 (official estimate for 1 July
1972)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state
religion
Language: French
Literacy: almost complete
Population: 8,180,000, average annual growth rate
0.4% (current) .
Ethnic divisions: homogeneous white population;
small Lappish minority
Religion: 92% Evangelical Lutheran, 7% other
Protestant, Roman Catholic, Eastern Orthodox, 1%
other
Language: Swedish, small Lapp- and Finnish-
speaking minorities
Literacy: 99%
Labor force: 4.0 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2%
construction; 13.6% commerce; 6.5% transportation
and communications; 29.8% services including
government; 5% banking, 2.7 unemployed
Organized labor: 80% of labor force','7a8b11a7ca7883e793b92c79d3ab7c5ad2077252132feb96bbf8735f2c8afe62','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b7c1cf597cc41a073723e48395f50f8e4811c9eed11346809bd2bb2c117784c',1975,'MN','Mongolia','people-and-society',295,'Population: 1,421,000, average annual growth rate
8% (current)
133
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
MONGOLIA/MOROCCO
INDIA y % 4
"MALAYSIA
ah','fedd8ed362f7541092da36ddcb1f5a0bb5b3adb7e3e28229ee00806dd0fa7d01','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e05e9029863f0778fe9eecb0a181a717ec3d5e6a3bb2a7c2e54bf7b1b3e67b9',1975,'MA','Morocco','people-and-society',297,'Population: 17,029,000, average annual growth
rate 2.9% (7/72-7/73)
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish,
0.7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2%
Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government,
diplomacy, and postprimary education
Literacy: 20%
Labor force: 6.3 million (1971 est.) 50%
agriculture, 15% industry, 26% services, 9% other
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers (UMT)','b3e0cf11f3188cd74c1a7d131f8cb9e81d8a09d1e89a802a4e06b1a9c46f85db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61aebb382232d45f5223dc3197927947f40184cf107b87b752e9c69a199e9d96',1975,'MZ','Mozambique','people-and-society',301,'Population: 8,984,000, average annual growth rate
2.2% (9/60-12/70)
136
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Ethnic divisions; 97% African, 3% European,
Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5%
Muslim, 2.4% other
Language: Portuguese (official); many tribal
dialects
Literacy: 7%-10% (est. )
Labor force: (1963 est.) 610,000; 50,000 non-
African wage earners, 560,000 African wage earners in
Mozambique; 290,000 additional African wage
earners temporarily working in Rhodesia and South
Africa; unemployment serious problem; most native
Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970);
75% are white','a3027a5cf81fcb7e12d40d9842d5d8f1380422965eadb10013efb480c61bd65b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc4625b81a2564ee375c06f4e9606b3de0e91aad1c9ecd6c1d39ff1bec6801ca',1975,'NP','Nepal','people-and-society',308,'Population: 12,424,000, average annual growth
rate 2.1% (6/61-6/71)
Ethnic divisions: two main categories, Indo-
Nepalese (about 80%) and Tibeto-Nepalese (about
138
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
20%), representing considerable intermixture of Indo-
Aryan and Mongolian racial strains; country divided
among many quasi-tribal communities
Religion: only official Hindu Kingdom in world,
although no sharp distinction between many Hindu
and Buddhist groups; small groups of Muslims and
Christians
Language: 20 mutually unintelligible languages
divided into numerous dialects; Nepali official
language and lingua franca for much of the country;
same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5%
industry; great lack of skilled labor','04a9dc22275e1bbf6631866e1cb8350c67c8a754447b4b7e1cb67e7be28f2f85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('207538722691d9a264143abc6867ca574dd7977fbcd6b1670f07297eae275d18',1975,'NC','New Caledonia','people-and-society',312,'Population: 128,000, average annual growth rate
8.6% (7/70-7/72)
Ethnic divisions: Melanesian-Polynesian admix-
ture, over 28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and
Tonkinese laborers were imported for plantations and
mines in pre-World War II period; immigrant labor
now coming from Wallis Islands, New Hebrides, and','fd517d2373e9a7617c145c81279ac5d02d127927c4d36f71d24d3a7aa6390c36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ff0f4998bf6d65e89be6218fe4e5256311b4bb2458513c8df41d79a8b006b73',1975,'NG','Nigeria','people-and-society',315,'Population: 62,148,000, average annual growth
rate 2.9% (current)
Ethnic divisions: 250 tribal groups, of which most
important are Hausa-Fulani (north), Ibo and Yoruba
(south); these 8 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official, Hausa, Yoruba, and
Ibo also widely used
Labor force: approx. 22.5 million; about 41% of
total population; roughly 1.3 million wage earners, of
whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners,
approx. 2.4% of total labor force, belong to some 700
unions','2a816f566bd42b781ddb260901279a5844ebea085bb9abaf9c7ab59e032ce6b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc43da8770576c826caed1ec62d268db9094093fe52bba728cfbf42a28e7fc07',1975,'NO','Norway','people-and-society',319,'Population: 3,998,000, average annual growth rate
0.6% (1/73-1/74)
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other
Protestant and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-
speaking minorities
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture,
forestry, fishing, 27.0% mining and manufacturing,
9.5% construction, 18.8% commerce, 11.9%
transportation and communication, 17.7% services;
1.0% unemployed
Organized labor: 60% of labor force','6458a860ac8f36581022e7515103c83474e983e9661d1f26a1b96695378f3ac6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('010c30668f3f996335cfa88f7cc69be31e2b2395564257f824b82fee8f3556fb',1975,'OM','Oman','people-and-society',323,'Population: 490,000, average annual growth rate
2.9% (current)
Ethnic divisions: almost entirely Arab with small
groups of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','b7e4fb9dc9958e7b8548083ec9e8a8030684afd964ae537583c08557de568159','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447c034a0f10161436b05d057c7824756e5d2aed35bcb06e82ded9617193d31a',1975,'PK','Pakistan','people-and-society',327,'Population: 70,444,000 (excluding Junagardh,
Manavadar, Gilgit, Baltistan, and the disputed area
of Jammu-Kashmir), average annual growth rate
3.6% (7/72-7/73)
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages
— 7% Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu,
9% other; English in lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60%
agriculture, 16% industry, 7% commerce, 15% service,
2% unemployed
Organized labor: 5% of labor force','17cf29514000f46cb1da6e65de1b1b662dfdb5ca90b4c4528b3e5b5793f9dba1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a49325cbe01c70d2d775612ce68ba1fdca4d5df9c498a60c274f414363e4ea43',1975,'PG','Papua New Guinea','people-and-society',333,'Population: 2,767,000, average annual growth rate
2.8% (7/66-7/72)
Ethnic divisions: predominantly Melanesian and
Papuan, some Negrito, Micronesian, and Polynesian
types
Religion: over one-half of population nominally
Christian (490,000 Catholic, 320,000 Lutheran, other
Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin
English and 2 or 8 native languages are linguae
francae for over one-half of population; English
spoken by 1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly
subsistence farmers','6cb50df74d901c3edc1845cd7299ecde196f4ba0c79d127108b58a1b6c1845d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53101f02f93d554c02a1067677948f6a056e97a8a85da7fe061acb620ee41a7b',1975,'PY','Paraguay','people-and-society',336,'Ethnic divisions: 95% mestizo, 5% white and
Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10,
but probably much lower (40%)
Labor force: 800,000 (1971 est.); 55% agriculture,
forestry, fishing; 8% transport and other services; 19%
manufacturing and construction; 18% commerce and
professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force','9c2c0b72e704b988c0b122b1f26880b38896dd96558f8db952dc87671fcb1244','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a51f4f3220f9b55b52f49a3c57f87362d66a0656bedc446bff123b1b0aaadcf',1975,'PL','Poland','people-and-society',341,'Population: 33,795,000, average annual growth
rate 0.9% (current)
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians,
0.5% Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox, Protestant,
and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26%
industry, 36% other non-agricultural
other
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
POLAND/PORTUGAL','88bfa666b79e72f88b2e9046a6e96eb23f351bb285857c5e89f6be01c1dc9226','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12cd43252f97bd248d1dc9cc7ef2d367a26b2236687f26def9b9ec9aa9bc8671',1975,'QA','Qatar','people-and-society',346,'Population: 176,000, average annual growth rate
10.8% (7/64-7/69)
Ethnic divisions: 56% Arab; 23% Iranian: 14%
Pakistani; 7% other
Religion: Muslim
Language: Arabic
-RDP79-01051A0
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
QATAR/REUNION
Literacy: 10%-15%
Labor force: 48,000 (1969)
Population: 489,000, average annual growth rate
2.0% (7/71-7/73)
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French, African,
Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high
seasonal unemployment
Population: 6,207,000, average annual growth rate
3.5% (7/68-7/74)
Ethnic divisions: 96% African, 3% European, less
than 1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part
animist), 24% Christian, 24% animist, a few Muslim
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
RHODESIA/ROMANIA
Language: English official; Chishona and
Sindebele also widely used
Literacy: 25%-380%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including
some migrants from Zambia and Malawi), 108,000
Europeans, Asians, and coloreds (people of mixed
heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 40% transport and services
Organized labor: about one-third of European
wage earners are unionized, but only a small minority
of Africans (1966)','f4af87ec580a0f9560e04caec8e3191ddd4ac44dcdc53981b3d0a2b2f9ee990f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19716054f02ea6e6350ea5951490ec6555c2f5aca8e342af2cb6e57091c3c14f',1975,'RO','Romania','people-and-society',350,'Population: 21,161,000, average annual growth
rate 1.0% (current)
Ethnic divisions: 87% Romanian, 8% Hungarian,
2% German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 100,000 Jews,
30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57%
agriculture, 19% industry, 24% other nonagricultural','77b30e8b9d7a889762c341cf24188ff3a5fea8b65c192d44e5b0d3cf02bb0ac7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6250d7e80f3dafb69ba71b99233484b1aaae1e56e977610340fbc2e32ec6e1e3',1975,'RW','Rwanda','people-and-society',354,'Population: 4,179,000, average annual growth rate
2.8% (7/71-7/72)
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45%
Muslim, rest animist
Language: Kinyarwanda and French official;
Kiswahili used in commercial] centers
Catholic, 9% Protestant, 1%
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','81fd5b73d575adac9cc62bfbb91c7f651891e746c839b7777fde8721a8669cf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed9d14dfec1729c703577f2850c9a83e6281204c63625edf17586318b0a26b99',1975,'SM','San Marino','people-and-society',361,'Population: 19,000 (official estimate for 30 June
1973)
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
ITALY YUGOSLAVIA
“SAN MARINO.
Organized labor: General Democratic Federation
of Sanmarinese Workers (affiliated with ICFTU) has
about 1,800 members; Communist-dominated
Camera del Lavoro, about 1,000 members','40b96f3cb2e221c39da44432a0d14f6f94498802118e5fcd5de62d1fc8b561ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d4e0adcd1c692ace7a4e395124e84311136a6d0b1ed1dbe0268680553c36d13',1975,'SA','Saudi Arabia','people-and-society',365,'Population: 6,005,000, average annual growth rate
2.8% (current)
Ethnie divisions: 90% Arab, 10% Afro-Asian (est. )
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40%
agriculture and herding, 12% construction, 12%
service, 12% government, 11% commerce, 13% other','7d172183682bd8de5c4e515bf3e8b574a6d28b49a6a1d14826437cda2478c0be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f275d2dad86064964bf1671e40043bcef2ef8eef5e26cb3c653deb5f10e4adb6',1975,'SN','Senegal','people-and-society',369,'Population: 4,258,000, average annual growth rate
2.2% (7/67-7/69)
Ethnic divisions: 836% Wolof, 17.5% Fulani, 16.5%
Serer, 9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5%
other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian
(mostly Roman Catholic)
Language: French official, but regular use limited
to literate minority; most Senegalese speak own tribal
language; use of Wolof vernacular spreading — now
spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence
agricultural workers; about 125,000 wage earners
Organized labor: majority of wage-labor force
represented by unions; however, dues-paying
membership very limited','12db68dd1b8ea2ead1df308230bbdad7c22e35b6a3a03c243df42d8389e2fff1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64b164be5055c4b2af90d76c4584ff6de02c589b34812cb242c57b4dd52ed145',1975,'SC','Seychelles','people-and-society',373,'Population: 58,000, average annual growth rate
2.4% (7/68-7/72)
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely
spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','dcb6619bab500cc0cbcd37b5d13bc56d63f62c202f459c9d61da4d2f2f3ff164','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d15835afe6c344f0d75fb902c7da13bd112c16ec0bd74452590a4cff5e79903a',1975,'SL','Sierra Leone','people-and-society',377,'Population: 2,727,000, average annual growth rate
1.5% (7/71-7/72)
Ethnic divisions: over 99% native African, rest
European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular usc limited
to literate minority; principal vernaculars are Mende
in south and Temne in north; “Krio,’’ a form of
pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small
minority, some 70,000, carn wages
Organized labor: 35% of wage earners
Population: 223,000, average annual growth rate
2.3% (8/61-4/71)
Ethnic divisions: 75% Nepalese; 25% Bhotias,
Lepchas, and a few tribal groups
Religion: Tibetan or Lamaist Buddhism (the state
religion) 33.3%; Nepalese majority are primarily
Hindu
Language: English, official; Nepali, lingua franca;
Bhotias and Lepchas speak Tibeto-Burman dialects
Literacy: probably less than 15%
Labor force: predominantly agricultural; minimal
skilled labor','7d0296b4e78e78d4af144eff44f40abd7b236f385fc386cc36ccf0c76d39203c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b1f8295cf6e4e87fa2bced5738cd17d639b1756158f6c3445c1a9de842bab2',1975,'SO','Somalia','people-and-society',381,'Population: 3,117,000, average annual growth rate
2.3% (7/65-7/72)
Ethnic divisions: 85% Hamitic, rest mainly Bantu;
30,000 Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form recently instituted
by government); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are
skilled laborers; 70% pastoral nomads, 30%
agriculturists, government employees, traders,
fishermen, handicraftsmen, other
Organized labor: law providing for government-
controlled Jabor union promulgated in June 1971, but
union so far not established','e649d466fb871e689df327a579246fcf931451124056afc2f99ffb89d4193187','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('487fee4f0c98642c738e77af1cbc9ac0ccf9a9581ce74f1ef1e5e76fae74b57b',1975,'ZA','South Africa','people-and-society',385,'Population: 24,718,000, average annual growth
rate 2.8% (7/65-7/73)
Ethnic divisions: 17.8% white, 69.9% African,
9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and
African; 60% of Africans are animists
Language: Afrikaans and English official, Africans
have many vernacular languages
Literacy: almost all white population literate;
government estimates 35% of Africans literate
Labor force: 8.7 million (total of economically
active, 1970); 58% agriculture, 8% manufacturing,
7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); nonwhites have no
bargaining power
Population: 815,000, average annual growth rate
1.9% (7/60-7/65)
Ethnic divisions: 14% white, 81% Africans, 5%
Colored (mulattoes); almost half the Africans belong
to Ovambo tribe; Damara. tribe has almost 45,000
members; Herero, Okavango, Nama tribes have about
30,000 members each
Religion: whites predominantly Christian,
nonwhites either animist or Christian
Language: Afrikaans principal language of about
70% of white population, German of 22% and English
of 8%; several African languages
Literacy: high for white population; low for
nonwhite
Labor force: 203,300 (total of economically active,
1970); 68% agriculture, 15% railroads, 18% mining,
4% fishing
Organized labor: no trade unions, although some
white wage earners belong to South African unions','0a1056c48b2d7248d12e5479ee4d9cd9e0781124d477b264e8f13d165dbf2a67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a762380c0e10c18943051e675f6e5337797d22f6eb3528f8f4f5934d26d4a1d7',1975,'LK','Sri Lanka','people-and-society',389,'Population: 16,633,000, average annual growth
rate 1.9% (7/70-7/78)
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6%
Moor, 2% other
Religion: 64% Buddhist, 20%
Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70%
of population; Tamil spoken by about 22%; English
commonly used in government and spoken by about
10% of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed;
employed persons — 53.4% agriculture, 14.8% mining
and manufacturing, 12.4% trade and transport, 19.4%
services and other
Organized labor: 43% of labor force, over 50% of
which employed on tea, rubber, and coconut estates
Population: 17,540,000, average annual growth
rate 2.5% (7/72-7/73)
186
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro,
2% foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23%
pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse
dialects of Nilotic, Nilo-Hamitic, and Sudanic
languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15%
industry, commerce, services, etc.; labor shortages
exist for almost all categories of employment','b3040fa42a814f36c3b507442e6c6288581f8b0e546a150364c8a1104bd15626','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c81e9126bf42f19db48a8fccfcbe4ffcb666ee64915af5bccb0720d30bd8d6a9',1975,'CH','Switzerland','people-and-society',392,'Population: 6,511,000, average annual growth rate
0.8% (7/''72-7/78)
Ethnic divisions: total population — 69% German,
19% French, 10% Italian, 1% Romansch, 1% other;
Swiss nationals — 74% German, 20% French, 4%
Italian, 1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals — 74% German, 20%
French, 4% Italian, 1% Romansch, 1% other; total
population — 69% German, 19% French, 10%
Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign
workers, mostly Italian; 16% agriculture and forestry,
47% industry and crafts, 20% trade and transporta-
tion, 5% professions, 2% in public service, 10%
domestic and other; no significant unemploy-
ment, shortage of both skilled and unskilled labor—
6,537 unfilled vacancies in April 1972
Organized labor: 20% of labor force
Population: 7,230,000, average annual growth rate
3.3% (7/72-7/73)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
SYRIA/TANZANIA
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other
Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12%
industry (including construction), 21% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 14,969,000, average annual growth
rate 2.7% (7/72-7/73)
’ Ethnic divisions: 99% native Africans consisting of
well over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika — 40% animist, 30%
Christian, 30% Muslim; Zanzibar — almost all
Muslim
Language: Swahili English and official English
primary language of commerce, administration and
higher education; Swahili widely understood and
generally used for communication between ethnic
groups; first language of most people is one of the
local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment,
over 90% in agriculture
Organized labor: 15% of labor force','03b6eaee4e706b919d1ed59ec74525ed6d8b9a59e4b75c68ba5f398a16aa8412','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3c0c388de365d4db78a1520067e20f7500b240b2638b83cce3425307df6a4b',1975,'TH','Thailand','people-and-society',396,'Population: 39,953,000, average annual growth
rate 3.2% (current)
Ethnic divisions: 75% Thai, 14% Chinese, 11%
minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5%
Christian
Language: Thai; English secondary language of
elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7%
industry
Population: 2,200,000, average annual growth rate
2.6% (1/70-1/72)
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north;
under 1% European and Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75%
animist
Language: French, both official and language of
commerce; major African languages are Ewe and
Mina in south and Dagoma, Tim, and Cabrais in
north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners,
evenly divided between public and private sectors
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
TOGO/TONGA
Organized labor: less than half of wage earners
divided among 2 major and several minor unions
Population: 96,000, average annual growth rate
2.6% (7/67-7/78)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims
over 30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for
children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','f072a90f46595b2d2f1a7010d6601f30f6b8a0c8152dc9611a61e688075c1e97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3140e81b9a1d3e7656bbeede5bb96adc5650d22062c4684d97bea7355ff242a3',1975,'TN','Tunisia','people-and-society',400,'Population: 5,711,000, average annual growth rate
2.4% (7/70-7/73)
Ethnic divisions: 98% Arab, 1% European, less
than 1% Jewish
Religion: 98% Muslim, 1% Christian, less than 1%
Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 830%
Labor force: 1.5 million; 70% agriculture, 10%
manufacturing and construction, 20% other; 25%
underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General
Union of Tunisian Workers (UGTT), subordinate to
Destourian Socialist Party
Population: 39,584,000, average annual growth
rate 2.6% (7/71-7/72)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other
(mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16%
industry, 16% service; substantial shortage of skilled
labor; ample unskilled labor
Organized labor: 10% of labor force','d6484a33355364ec9ef18c2fc66d087d5566161488361e45b8d2d3749d8f725d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('557862ef6a679e8168141d228400ba218daa9373be4e54756b8e604ee0d73b2b',1975,'UG','Uganda','people-and-society',404,'Population: 11,361,000, average annual growth
rate 3.4% (current)
Ethnic divisions: 98.7% African, 1.3% European,
Asian, Arab
Religion: about 60% nominally Christian, 5%-10%
Muslim, rest animist
Language: English official; Luganda and Swahili
widely used; other Bantu and Nilotic languages
202
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which
about 250,000 in paid labor, remaining in subsistence
activities
Organized labor: 125,000 union members
Population: 253,277,000, average annual growth
rate 1% (current)
Ethnic divisions: 74% Slavic, 26% among some 170
ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9%
Muslim, 8% other
Language: more than 200 languages and dialects
(at least 18 with more than 1 million speakers); 76%
Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 129 million (1974), 27%
agriculture, 73% industry and other non-agricultural
fields, unemployed not reported, shortage of skilled
labor reported','fe252c7fe79285bbd5cd1b88e3ea651ad12744abcfd0d5670b1972fe3fae3343','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c4793154c2118a15de524a2b6f5abaeb509e4428214f7af04c88440dbffb097',1975,'AE','United Arab Emirates','people-and-society',407,'Population: 179,000 (census of 15 March - 16 April
1968)
Ethnic divisions: Arabs 72%: others include
Iranians, Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other
4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
UNITED ARAB EMIRATES/UNITED KINGDOM','3d8ab95a9a58c7abbca43303f967e89c9d16a6459584f7e8eafeafbea6b83bfe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a0805dc0411c65482d57edfde26bbc40a37282dd908fb72d5cae5cb9c637a34',1975,'GB','United Kingdom','people-and-society',410,'Population: 56,090,000, average annual growth
rate 0.0% (current)
Ethnic divisions: 83% English, 9% Scottish, 5%
Welsh, 3% Irish
Religion: 27.0 million Church of England, 5.3
million Roman Catholic, 2.0 million Presbyterians,
760,000 Methodist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic (about
100,000 in Scotland)
Literacy: 98% to 99%
205
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Labor force: 25 million; 3% agriculture, 2%
mining, 35% manufacturing, 6% government, 8%
transportation and utilities, 6% construction, 11%
distributive trades, 23% services, 3% other; 3%
unemployed
Organized labor: 40% of labor force
Population: 5,888,000, average annual growth rate
2% (7/69-7/70)
Ethnic divisions: more than 50 tribes; principal
tribe is Mossi (about 2.5 million); other important
groups are Gurunsi, Senufo, Lobi, Bobo, Mande, and
Fulani
Religion: majority of population animist, about
20% Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong
to Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence
farming, and related agricultural pursuits; about
30,000 are wage earners; about 20% of male labor
force migrates annually to neighboring countries for
seasonal employment
Organized labor: 3 primary and several small
specialized unions','75911b5d0739deed09f32de452c5479ac27ad22073f06a630988f22a868b0f49','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c33fb435b9f169bb3a57c2eeb57a988ac7a1879e98e29941d2892a9ea6526348',1975,'WF','Wallis and Futuna','people-and-society',413,'Population: 9,000, official estimate for 1 July 1973
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic
Population: 157,000, average annual growth rate
2.3% (7/66-7/73)
Ethnic divisions: Polynesians, about 12,000
Euronesians (persons of European and Polynesian
blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London Missionary
Society)
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
WESTERN SAMOA/YEMEN (ADEN)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all
children from 7-15 years)
Labor force: agriculture 19,148; mining and
manufacturing 1,716 (1961)
Organized labor: unorganized','e5433e38faf9d1630383b6946eb6196ac296b1860a21409c7571205aeedf7f33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5945519521f96e82239ec51405e77a012eec35ab7b86514269937a5cec6d43a9',1975,'WS','Samoa','people-and-society',419,'Population: 1,619,000° average annual growth
rate 2.7% (current)
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35%
(est.)','078bda58d4f674ee12526f6409fe45a6030af29b19495b7227f4604ab88f07bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6778afb16230eacfc29b3d6261533b654d0213d4e43f5cf3a277797269716f60',1975,'YE','Yemen','people-and-society',423,'Population: 6,457,000, average annual growth rate
2.6% (7/71-7/72)
Ethnic divisions: 90% Arab, 10% Afro-Arab
(mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and
herding
Population: 21,241,000, average annual growth
rate 1% (current)
Ethnie divisions: 39.7% Serb, 22.1% Croat, 8.4%
Muslims, 8.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 2.3% Hungarian, 4.6%
other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman
Catholic, 12% Muslim, 3% other, 12% none (1953
census)
Language: Serbo-Croatian, Slovene, Macedonian,
Albanian, Ifungarian, and Italian
Literacy: 80.3% (1961)
217
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
YUGOSLAVIA
Labor force: 13.5 million (1970); 49.6%
agriculture, 16% mining and manufacturing, 34.4%
other nonagricultural activities; reported unemploy-
ment averaged 8% of registered labor force (social
sector) in 1967
Population: 24,561,000, average annual growth
rate 2.8% (7/70-7/78)
Ethnic divisions: over 200 African ethnic groups,
the majority are Bantu; four largest tribes — Mongo,
Luba, Kongo (all Bantu), and the Mangbetu-Azande
(Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili,
Kikongo, and Chiluba are all classified as official
languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13%
in wage structure','d08d083f68bb1f4d6f3100167c962de4c1aa04dd34dec87d75f41c7bed05da97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6c1a4bb6e118e2df22a9f66a49072f300b64320aafd6685900d8336c015703f',1975,'ZM','Zambia','people-and-society',425,'Population: 4,810,000, average annual growth rate
2.5% (7/73-7/74)
Ethnic divisions: 98.7% African, 1.1% European,
.2% other
Religion: 82% animist, about 17% Christian, and
under 1% Hindu and Muslim
Language: English official; wide variety of
indigenous languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non-Africans; 15% mining, 9%
agriculture, 9% domestic service, 19% construction,
9% commerce, 10% manufacturing, 23% government
and miscellaneous services, 6% transport
Organized labor: 100,000 wage earners, primarily
in industrial sector, are unionized (early 1968)','f1267433b80cb052839c1da6a182395b11b91be26978b5ffef27b2fbbfea9b18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95b6926203448bd39a06fed7b5dbbea713c2193f1e2305cd9e8cdc81aabf6905',1975,'US','United States','people-and-society',429,'Population: 212,750,000, average annual growth
rate 0.8% (current)
Ethnic divisions: 87.2% white, 11.3% negro, 1.4%
other
Religion: total membership in religious bodies,
128,470,000; Protestant 69,424,000, Roman Catholic
47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: 91 million (1978)
Organized labor: 23.5% of total (1972)','b798b69992df7d65050fa9505f3ec3bce8dd9ee948ce3c282d741c3d8a10b83c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf82a5f155d287292800c66bab174be937075c94e277e9a3dc4bfe70fe5ee96a',1975,'DE','Germany','military-and-security',330,'151
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
PAKISTAN/PANAMA
Airfields: 203 total, 108 usable; 63 with
permanent-surface runways; 1 with runway over
12,000 ft., 21 with runways 8,000-11,999 ft., 53 with
runways 4,000-7,999 ft.
Telecommunications: excellent international
radiocommunication service over CENTO links;
domestic wire and radiocommunication and
broadcast service very good; 175,026 (est. ) telephones;
1,010,000 radio and 125,000 TV sets; 19 AM, no FM,
and 3 TV stations
DEFENSE
Military manpower: males 15-49, 14,048,000;
7,550,000 fit for military service; 689,000 reach
military age (17) annually','ed2ad2672f9291c1a713a16ae49420179a1f16b16b993583a22af1586404ad37','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6e1f24fccf099b81c20e3bf4f64cdfea5a0f091f53f30aac42de42e8217bed4',1975,'BR','Brazil','military-and-security',331,'LAND
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.);
24% agricultural land (9% fallow, 4% cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
urban, and waste
Land boundaries: 390 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf including sovereignty over super-
jacent waters)
Coastline: 1,545 mi.','52540cf168f66bae44ce0257e452916bec3f6cba050d3322d65bbaf58ccfacba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdfcaed871777a2d43d213a36750aeb94f0870748705d643e8ed6a2332d5a729',1975,'','','raw',1,'; Approved For Release 2002/07/03 . CIA-RDP86T00608R000600100003-3 . „
CIAOGCR BIF 7507 Unclass. 1 of 3
FACT BOOK Jul 75
July JlfljlrZ''&d For Release 2002/07/03 : CIA-RDPff6TritJ608R0006001 00003-3
National Basie Intelligence
FACTBOOK
Approved For Releas#-2002/07/03 : CIA-RDP86T00608R0006001 00003-3
FOREWORD
Tho National Basic Intelligence Factbook, a compilation at basic
data on political entitles worldwldo, Is coordinated and published
somiannually by the Office of Geographic and Cartographic
Rosoarch, Central Intolllgenco Agency. It Is Issued for use by U.S.
Government departments and agencies. The data are prepared by
components of tho Central Intelligence Agency, the Defense
Intelligence Agency, and tho Department of State. Comments and
suggestions should be addressed to tho Office of Geographic and
Cartographic Rosoarch (Attn: Factbook), Central Intelligence Agency,
Washington, D.C. 2C505.
Federal government officials may obtain additional copies of the
Factbook directly or through liaison channels from the Central
Intelligence Agoncy.
Others may address Inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July lf)75
TABLE OF CONTENT8
Entrlo3 In all capital lottors rolor to
baalc data ohoots Included In this factbook
Fago
Abbreviations for International Organizations
United Nations (U.N.): Structure and Rolatod Agonclos
—A —
Abu Dhabi (see UNITED ARAB EMIRATES)','8d6fabd38fd4e9351a77641a98617709cbdf586641d630257eafd8e01d66356d','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b60bad1d669a47fa1b2b8850cbbab65f8e0c68cc03669cfff5b85b1c77f6722a',1975,'AF','Afghanistan','raw',2,'''Ajman (see UNITED ARAB EMIRATES)
LAND
250, ()(K) st | . ml.; 22''/,'' arable (12% cultivated. 10%
pasture), 75% desert, waste or urban, 3/,. forested
(1070)
Land boundaries: 3/125 ml.','4fc0cc28bea3d2f16f18c2410efc646b4ecdf714695f0660c8a2d9ea9fced4f6','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed42df5b2e9d2f5d837991a76a1b25e87576b6903dc04dedb3c60fff0c0cf3e0',1975,'BI','Burundi','raw',3,'1
2
3
4
5
6
7
9
10
12
13
14
15
16
18
19
20
21
22
23
25
26
27
28
29
-C—
Cabinda (see ANGOLA)','2c00f5aa75af75b0e9c6589fcd2c5258838758f635aff788a0a39829d39d20c1','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f57581e6d276175d60c89dd63e16d07f62606fdb8eaa377d5ae4ba7454d21013',1975,'CA','Canada','raw',4,'Canary Islands (see SPAIN)
Cape Verde Islands (see PORTUGAL)
CENTRAL AFRICAN REPUBLIC . . .
Ceylon (see SRI LANKA)','8193af49ebe5dcbd355dcc66391c08da78dd9d776918b5c411bdeec813ea7260','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('461a8b63ff7180094c4b3f9fabb6175cacee44a01b8b9cac6e9cd56eacf9e824',1975,'CL','Chile','raw',5,'CHINA, PEOPLE''S REPUBLIC OF . .
30
31
32
34
35
36
38
III
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July
Pago
-C-
CHINA, REPUBLIC OF 38
COLOMBIA 40
COMORO ISLANDS 42
CONGO (Brazzaville) 43
Congo (Kinshasa) (seo ZAIRE)
COOK ISLANDS 44
COSTA RICA 45
CUBA 46
CYPRUS 47
CZECHOSLOVAKIA 49
— D —
DAHOMEY 50
DENMARK 51
DOMINICA 53
DOMINICAN REPUBLIC 54
Dubai (see UNITED ARAB EMIRATES)
— E—
ECUADOR 55
EGYPT 57
EL SALVADOR 58
EQUATORIAL GUINEA 59
ETHIOPIA 60
-F—
FAEROE ISLANDS 6?
FALKLAND ISLANDS (MALVINAS) 63
Fernando Po (see EQUATORIAL GUINEA)
FIJI 64
FINLAND 65
FRANCE 66
FRENCH GUIANA . . 68
FRENCH POLYNESIA 69
FRENCH TERRITORY OF THE AFARS AND ISSAS 70
Fujairah (see UNITED ARAB EMIRATES)
-G—
GABON 71
GAMBIA 72
GERMANY, EAST 73
GERMANY, WEST 75
GHANA 76
GIBRALTAR 77
GILBERT AND ELLICE ISLANDS 78
GREECE 79
GREENLAND 81
GRENADA 82
GUADELOUPE ’ 83
GUATEMALA ‘ 84
GUINEA 85
GUINEA-BISSAU 86
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA 87
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
li)75
— H— Pago
HAITI 88
HONDURAS 90
HONG KONG 91
HUNGARY 92
ICELAND 93
INDIA 95
INDONESIA 96
IRAN 98
IRAQ 98
IRELAND 100
ISRAEL 102
ITALY 103
IVORY COAST 105
-J-
JAMAICA 106
JAPAN 108
JORDAN 109
— K—
KENYA 110
KOREA, NORTH Ill
KOREA, SOUTH 112
KUWAIT 114
•— L —
LAOS 115
LEBANON 117
LESOTHO 118
LIBERIA 119
LIBYA 120
LIECHTENSTEIN 122
LUXEMBOURG 123
-M—
MACAO 124
MmOAGASCAR 125
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI 126
MALAYSIA 128
MALDIVES 130
MALI 131
MALTA 132
MARTINIQUE 134
MAURITANIA 135
MAURITIUS 136
MEXICO 137
MONACO 139
MONGOLIA 140
MOROCCO 141
MOZAMBIQUE 142
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
— N— PQ9°
NAURU 143
NEPAL 144
NETHERLANDS 145
NETHERLANDS ANTILLES 147
NEW CALEDONIA 148
NEW HEBRIDES 149
NEW ZEALAND 150
NICARAGUA 151
NIGER 153
NIGERIA 154
Northern Rhodesia (see ZAMBIA)
NORWAY 155
— 0~
OMAN 157
— P—
PAKISTAN 158
PANAMA 159
PAPUA NEW GUINEA 160
PARAGUAY 162
Pemba (see TANZANIA)
PERU 163
PHILIPPINES 164','bec921f925e9b1daba81571e43da1d4539ed869463d22067b37e3aea135faf23','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ff312bff3889ebe48226f7637e0e5cf2ff720533a06b54973b5bca0a8860a60',1975,'PL','Poland','raw',6,'PORTUGAL 167
Portuguese Guinea (see GUINEA-BISSAU)
PORTUGUESE TIMOR 169
-Q-
QATAR ... 170
— R—
Ras al Khalmah (see UNITED ARAB EMIRATES)
REUNION 171
RHODESIA 172
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA 173
RWANDA 175
-S—
ST. CHRISTOPHER-NEVIS-ANGUILLA 176
ST. LUCIA 177
ST. VINCENT 178
SAN MARINO 179
SAUDI ARABIA 180
SENEGAL 181
SEYCHELLES 182
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE 183
SINGAPORE 185
SOMALIA 186
vl
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1075
— S—
Pago
SOUTH AFRICA 187
Southern Rhodesia (seo RHODESIA)
SOUTH-WEST AFRICA 188
SPAIN 190
SPANISH SAHARA 191
SRI LANKA (formerly Ceylon) 192
SUDAN 1g4
SURINAM 195
SWAZILAND 197
SWEDEN 198
SWITZERLAND 199
SYRIA 2°1
-T-
Tanganyika (see TANZANIA)
TANZANIA 202
Tasmania (see AUSTRALIA)
THAILAND 204
TOGO 205
TONGA 206
TRINIDAD AND TOBAGO 207
TUNISIA 208
TURKEY 209
-U-
UGANDA 211
Umm al Qalwaln (see UNITED ARAB EMIRATES)
U.S.S.R 212
UNITED ARAB EMIRATES: Abu Dhabi, ''Ajman, Dubai, Fujairah,
Ras al Khalmah, Sharjah, Umm al Qalwaln 213
United Arab Republic (see EGYPT)
UNITED KINGDOM 214
UNITED STATES 231
UPPER VOLTA 21®
URUGUAY 217
— V—
VATICAN CITY 21®
VENEZUELA 2i9
VIETNAM, NORTH 221
VIETNAM, SOUTH 222
— W-
WALLIS AND FUTUNA 223
Walvls Bay (see SOUTH AFRICA)
WESTERN SAMOA 224
— Y—
YEMEN (Aden) 225
YEMEN (Sana) 226
YUGOSLAVIA 227
vll
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1975
Pago
ZAIRE 228
ZAMBIA 230
Zanzibar (see TANZANIA)
MAPS
I CANADA
II MIDDLE AMERICA
III SOUTH AMERICA
IV EUROPE
V THE MIDDLE EAST
VI AFRICA
VII U.S.S.R. and ASIA
VIII OCEANIA
vlll
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 1975
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ACCT
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
IDB
IEA
IFCTU
IHB
IPU
IRC
LAFTA
Afro-Aslan People’s Solidarity Organization
Agency for Cultural and Technical Cooperation of
French-speaking Countries
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Aslan Nations
Aslan and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belglum-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Federation of Christian Trade Unions
International Hydrographic Bureau
Inter-Parliamentary Union
International Red Cross
Latin American Free T rade Association
ix
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July li)75
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
LICROSS
League of Red Cross Societies
NATO
North Atlantic Treaty Organization
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
OCAM
Afro-Mahgasy and Mauritian Common Organization
ODECA
Organization of Central American States
OECD
Organization for Economic Cooperation and Development
OPEC
Organization of Petroleum Exporting Countries
SEATO
South-East Asia Treaty Organization
UEAC
Union of Central African States
UDEAC
Economic and Customs Union of Central Africa
WEU
Western European Union
WCL
World Confederation of Labor
WFTU
World Federation of Trade Unions
WPC
World Peace Council
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
ECOSOC
Operating Bodies:
UNCTAD
UNICEF
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
U.N. Conference for Trade and Development
Trade and Development Board
U.N. Children’s Fund
Regional Economic Commissions:
Economic Commission for Africa
ESCAP
ECAFE Economic Commission for Asia and the Far East (see ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
IMF (FUND)
UNESCO
United Nations Educational, Scientific, and Cultural
Organization
Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Seabed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 15)75
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid -May 1975,
except for population estimates, which have been projected to 1 July
1975. Military manpower estimates are as of 1 January 1975 except
for average number of males reaching military age, which are pro-
jected averages for the 5-year period 1975-79. Military and com-
munications data are as of 30 April 1975 unless otherwise indicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for "arable" may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included only
when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The
difference between the two Is In the addition or subtraction of the
value of return on foreign Investment. GDP equals GNP plus Income
earned in the country but sent abroad, minus Income earned abroad
but sent Into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is true in creditor countries.
Major ports r«re the largest maritime ports of the country, relative
to other ports ol the same country, on the basis of estimated port
capacity, alongside berthing accommodations, and commercial or
naval importance. Minor ports are the remaining ports of a country
which have, relative to the major ports, significantly lower estimated
port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance. Major transport aircraft are those
weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise
stated. The abbreviation FY stands for U.S. fiscal year; all years are
calendar years unless otherwise indicated.
xii
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
V
Approved For Release 2002/07/03 : CIA-RDP86T00608R0006001 00003-3
July 11)75','d3fd80c527a359aebb46ce669c5e2214c08698ae103c60b48d435ef778bf6a87','internet-archive','CIA-RDP86T00608R000600100003-3','txt','150cf3f4743ae47355386ce794fec97fe3d115e8a4820245b79e52bdcc2dcdab','https://archive.org/download/CIA-RDP86T00608R000600100003-3/CIA-RDP86T00608R000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54091fb09019935c304032d9ee82fb10417cb4ec6b9a3761752739742edd061a',1975,'','','raw',1,'wees
_( Approved For Rélease 2002/07/03 ; CIA-RDP86T00608R.0006001000
CIAOGCR -
FACTBOOK
ie
July Arad For Release 2002/07/03 : CIA-RDP86TEH608R000600100003-3
<
oe .
National Basic Intelligence
FACTBOOK
DIA and DOS review(s) completed. ven
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
s~
Approved For Releas&2002/07/03 : CIA-RDP86T00608R000600100003-3
° baad
FOREWORD
The National Basic Intelligence Factbook, a compilation of basic
data on political entities worldwide, ls coordinated and published
semiannually by the Office of Geographic and Cartographic
Research, Central Intelligence Agency. It Is issued for use by U.S.
Gcvernment departments and agencies. The data are prepared by
components of the Central Intelligence Agency, the Defense
Intelligence Agency. and the Department of State. Comments and
suggestions should be addressed to the Office of Geographic and
Cartographic Research (Attn: Factbook), Central Intelligance Agency,
Washington, D.C. 20505,
Federal government officials may obtain additional copies of the
Factbook directly or through tialson channels from the Central
Intelligence Agency.
Others may address inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C, 20540
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1075
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
TABLE OF CONTENTS
Entrios In all capital lottors rofer to
basic data sheets included in this factbook
Fago
Abbreviations for Intornational Organizations . 6. 6. ee ee es ix
United Nations (U.N.): Structure and Rolated Agencies... 1. sss xl
=A
Abu Dhabi (soo UNITED ARAB EMIRATES)
AFGHANISTAN 4000 ee 1
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA . oo we ee ee ee ee 2
ALGERIA 0c 3
ANDORRA . 0. 4
ANGOLA 2g 5
Anguilla (seo ST. CHRISTUPHER-NEVIS)
ANTIGUA 2.0. cc ee ee ee ee ee ee ee es 6
ARGENTINA 0000 ce 7
AUSTRALIA 20k ee 9
AUSTRIA 6 wc 10
Azores (see PORTUGAL)
—B—
BAHAMAS, The . 0. ee 12
BAHRAIN . 0. ee 13
Balearic Islands (see SPAIN)
BANGLADESH ....-- eee et ee 14
BARBADOS .....2 0 eee et ee 15
BELGIUM 00 16
BELIZE® 2 oy ok ele a he ee a hd pe re Be RE 18
BERMUDA ... 0-0 eee et ee ee 19
BHUTAN «0c es 20
BOLIVIA . 0c ec ee ee ee 21
BOTSWANA .....000 0 ee ee 22
BRAZMs son & ena eo se ae eet bd eae, a Gee 23
British Honduras (see BELIZE)
STITISH SOLOMON ISLANDS... 7 eee eee eet 25
BRUNEL . 2 0 ee ee ee ee ee es 26
BULGARIA .. 0 ee ee 27
BURMA .....- 00 eee eee ee ee eS 28
BURUNDI . 0.0 ee 29
C4
Cabinda (see ANGOLA)
CAMBODIA «0. ee ee ee 30
CAMEROON .... 02 ee ee EE 31
CANADA 6 ctru-e bw 6 oe ale Ne Aree SOE 32
Canary Islands (see SPAIN)
Cape Verde Islands (see PORTUGAL)
CENTRAL AFRICAN REPUBLIC ... 2. ee ee eet ee ts 34
Ceylon (see SAI LANKA)
CHAD: 208. oe pote be SR eR AE Re ee a oe eG 35
CHILE 8 3 ee MAb eS ok ER AP OR AN, COd cee 36
CHINA, PEOPLE''S REPUBLIC OF ... 2 6 eee ete et tts 38
Iv
C6
CHINA, REPUBLIC OF ........0 2.00000
COLOMBIA. ce ate ee a ae ee
COMORO ISLANDS ........ 0.000 eeu
CONGO (Brazzaville) . 6 0. te
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS 1... ee ee te
COSTACRICA. sasw se Fog Wak ae ee
CUBA 6 rk cb ie ee ee ai base a aac 8 Sa ay he
Des
DAHOMEY «2.1. wt
DENMARK «ww ee
DOMINICA «1. we ee
DOMINICAN REPUBLIC .............0.04
Dubal (see UNITED ARAB EMIRATES)
a ee
ECUADOR ....... raves ao Ay, BIN Boe ee Secale Soles
EGYPT oo sic Wb ae aise Ha tae ai WA Bago: dete wales
EL SALVADOR. be ee ee
EQUATORIAL GUINEA ......... 004.8 0
ETHIOPIA | gece a ee gd a ws no ee
=F
FAEROE ISLANDS ............000 004
FALKLAND ISLANDS (MALVINAS) ..........
Fernando Po (see EQUATORIAL GUINEA)
PUD 9 sooccke ghia Fe Gene Net EE a ve le eae oe 4d, Neg Baer
FINLAND: | ep ects oe ee eee ee ee
FRANCE a8 2 asian ls oi eed oe we ee ok ee OR
FRENCH GUIANA 2.2... ee
FRENCH POLYNESIA ........0.000 2.004
FRENCH TERRITORY OF THE AFARS AND ISSAS
Fujairah (see UNITED ARAB EMIRATES)
—G—
GAMBIA. os ce a Dee eo as
GERMANY, EAST ........
GERMANY, WEST ... 7... 2. ee ee ee
GHANA ®: 65.3. ie tk ne ed ees Bk Ae ge tie a ee as ea
GIBRALTAR eon i wae ee LP ee eR
GILBERT AND ELLICE ISLANDS ...........
GREECE <a. oe icant ee Soc eects At a, vale ces LES
GREENLAND? | 46 6 aot as ete Le ee al
GRENADA: 26:6 y es eoW Bs BER Wwe eee as
GUADELOUPE .... 2... ... ee ee ee ns
GUATEMALA ...... oi en ot et bee aria Oe ake
QUINEA:. ne. i ae Oe eh eae ee we eae
GUINEA-BISSAU .. 0... 2... ee ee ee
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA» <3. fe eas es hs eH we AEN
oe 8 6 © 6 8 ee
* 6 © © © 8 8 8
Cr
o 6 6 @ © © 2 6
e © © 8 © 8 8
s 8 8 © © 8 ee 8
© 6 © ew we ew ew
eo 8 © © © 6 8
ee er)
)
oo © © © © 2 2
o 8 © © © © © 2
eo 8 © © © 6 8
Cr
ee ee |
oe 6 © © © @ © 8
[ee ee Se
oe 8 © © 8 @ 8
oe 8 6 © © © we
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
—H-- Page
HAITI) o''s. dice GG le Soa Boe Bie ac eek et a De a oe a ae 88
HONDURAS: 4. 4. Accs lice ha a ah ce a ee a 90
HONG KONG) oe 308 eae ee a ea ea Shes a ced 91
HUNGARY oie 60 a aie Bae a le a ae a Re 92
ICELAND? goo. ai 8 Ral ve say ca Ba 0) ht pa In te a aces 93
INDIA? 20h as oc Se 2 A ee a ee Oe a a Go 95
INDONESIA}. ch: oie ie es Se eee we aa eee ee ld Dae 96
NANG yah ses an Ae eA oa ed crate A 4 Me ee er gti tae Wee dae nea 2 98
PACs pda ace ah ae RG 8 iat hn Se en Gt hh te cae eats WP 98
IRELAND! hoa setsn se gerne: Gita la eta at ee at Blaine weak 100
ISRAEL dap cies: a xa cg ee owl Gea Sethe dat Soar Daa ee we es 102
ITALY sco ''y coer eo irsb ee we. Ree pel ee A RA teste Joma eae a ie ae ates 103
IVORY ‘COAST | cach ata aie fos ers he we A ae eR Cae my oe 105
a
JAMAICA: 6 ice te ee Rete ds aio aie EET: we ee aR ea we 106
WARAN! | Mares vis neteh ce, awsk, Hebd lore PINT La eatin whats SOE 108
JORDAN. ese els oa ee Ee ed we Se a a ee Ge 109
Kes
KENYA: ea fe i ec eee leek ee Bk Fe wc Area wa 110
KOREA; NORTH wg ce See Se eR es Ge ee a eae 111
KOREA; SOUTH coe ees is) BO ate ae tw ne Gace ewe 112
KUWAIT: ose ea, BOR Gee tee elt ete so lal Megs Be eee oe 114
=<Lt~
AOS eer are eae i eh a ohh 6 Vc aa me Sag Sean TA SS EW Saree 115
LEBANGON® “eo jocai ee eos ead Are ed ee oe Sat dale Ea Sa EOE GR 117
EESOTHQS oe pais to el ae oe et Aaa, & ee a. BO Je A haa gs ted 118
LIBERIA: as: bh ee ae eee Pe ad ae a a a es dee 119
PIBY AS oie! oe ie ayn A ated, Ayes Rae eee At ee ae cee deat 120
LIECHTENSTEIN | .c5: <0 8 ae fe ie ek hee ew ee ee Ae a 122
LUXEMBOURG) 5.0 Sebi ae! feta wee Gee ee te je a et Ed “ee wont a 123
—M—
MACAO? 4.5 cst ae Sd fea la ens Mee hoe hes a PA et ae 124
MADAGASCAR i556 a SMe al ee eR eee gee tae BE a a 125
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI 2 oo oe. shy. Sache OS el cane Ca Denies Weg Ee By ee wit ee 126
MALAYSIA» (66 09 Koa Gas Gta ee a Ne ta Re Res 128
MALDIVES? - 46S. needs Sol he pice, “ee ae nk aS Ge be eS as We 130
MALU ors Bele tee beh a aes, BS @ Ge el aed Glw abe eds 131
MALTA: | 328.05: se i He Maa eA GS, ee ea ee ee hehe 132
MARTINIQUE? (ices oa sie Sep eee ay as AL Bae ee ee ea 134
MAURITANIA: » 32 vacgiye eek ce tea ata dein Se erie de ed 135
MAURITIUS: 22 fo eae A See eG Re ee a ee a ee 136
MEXICO? a. eco cd eG a BU a ee eg PO we he eS 137
MONACO! 4.756 Bk A see rae aan sa EU See Meee Re edie to, 139
MONGOLIA fe acai as Seve he ee cartier es Gta ae enw aoa HOT a ae 140
MOROCCO © 5.05 6g) win ERG pe ee et a ee Be A el 141
MOZAMBIQUE «ww ww ee ee 142
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
at nt a ee
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
—N— Page
NAURU) 3.0) whe a Sle aa Oe ee bates isin 4k aiteiec 143
NEPAL staid Wee Fee eet casa eet Bs este A ey doe casa BS 144
NETHERLANDS .. 0. 1 ee ee 145
NETHERLANDS ANTILLES . 2... we tt tee et ee ee 147
NEW CALEDONIA... ww et tt 148
NEW HEBRIDES .......... Ride 28 Niciteies aca eer a eae a 149
NEW ZEALAND ... 1... ee ee Mecha acces 4 RSs 150
NICARAGUA sie te acta a a ae a HP a Wee aan vd 161
NIGER ® et. tie else ieee te A ate Ae ee So Soul ee Me Ge be as Be ig 153
NIGERIA: | ~5. 6 ess Se Beis aE GN we ue ein ae aan ane oe 154
Northern Rhodesia (see ZAMBIA)
NORWAY oe 3.4 oe wd he ted ek ee ae) Glee alae ee LS 155
=Os:
OMAN ete Ss ve ves ORS 8 Ht ce a wi AS abel eB GO a Ae Ra et 157
—P.—
PAKISTAN: 4.5 ice Gale Bn ce ow ee ae ee RO a 158
PANAMA, | foe se ke ey eles ah) Ah ae, Me SE ne Seat ay a Be Res 159
PAPUA NEW GUINEA... we 160
PARAGUAN © 32) 4h sie oe ee a et > Phe <a ae A ee 162
Pemba (see TANZANIA)
PERU ne de nie oh es pee an te ete See te iy Cane so aes at ade At dine 163
PHIEIPPINES 0 sh. Sed bid @ Ge oe Rhein te ks ee a a en 2 ee ee 164
POLAND, - 5.5: 20%. Ge seis cae Se ve a ee ce ee gs ee Dw a ee 185
PORTUGAL. fo teeter enact: ay een oe os Sen ee, BR ae dy al Sn 167
Portuguese Guinea (see GUINEA-BISSAU)
PORTUGUESE TIMOR ....... 2... pe eee Gata ea ea Ge Se. 169
—Q—
QATAR! fede FG, ey 8 See wae ae, Ace ea eee BSCS 170
pan = fae
Ras al Khaimah (see UNITED ARAB EMIRATES)
REUNION: oo ge''o nee! bol ee te OS a Seta le Sele Moers BOR, RS 171
RHODESIA. 9 goss ket ee ee Al a WAS a ee ta Se Be 172
Rio Muni (see EQUATORIAL GUINEA)
ROMANIAS ee) eic5 28 ao erin She Wad, ah ek ee a eee 173
RWANDA: . 25.00 8) oe ed ee, ee we ROS ea aoe ais 4k 175
—S—
ST. CHRISTOPHER-NEVIS-ANGUILLA .........0..050- 0804 176
ST OCIA a x, hs semted a GR ee gt ea ade Se hae abe aid ee wena acne tee ee 177
SEOVINGENT. «Si eae banks pce ota eA ON Saree De Ae Sects 178
SAN MARINO 2. ww. we 179
SAUDI:ARABIA~— o4 3.08 Ge Soe a oe BN ee ea re ae 180
SENEGAL... 2 fests eh ne! Be te GO ete dea eae Ae whe ee aS eve 181
SEYCHELLES: sor sesh tae Geek hee We eM Gl a Soe eae 182
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE: oe oe fo ee A a eee OS Bed 183
SINGAPORE: 2. joc eta oe aes clog eee SS ay hee AS te es 185
SOMALIA... verte: tous ee Steere ie, ee ca eB a ae ae ore, SS we a ee 186
vi
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
afi 2 Suige = Sep Pe a Fee |
eee ae eee saeese . peau : : Tos
Pop cieal Vinee Ome ota, tins enon +.
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
a6
Peer Page
Ron
A SOUTH AFRICA «6. we ee ee 187
Southern Rhodesla (see RHODESIA)
SOUTH-WEST AFRICA .......0 00. ioe se Mim ach Oe ethic San es oe 188
: SPAIN: ogo vos ace Sires Ne a Ge ee Be Wy ara a ae 190
oF SPANISH SAHARA .. 1. 6 ee 191
oe SRI LANKA (formerly Ceylon) .. 0... 0 ee ee se dies for oan 1 Mans, pea 192
= SUDAN. ©. fe cow U8 Se Srrds ae a) he ee en a ES aE ee a es 194
; SURINAM: | ¢.- s-seb eee a ee a ee a ate a ee a ae at 195
SWAZILAND 2... 00. ee 197
oa SWEDEN .........4.4 Sha? Tao ao tsk neh phn: Hera adbe ed: neo e NE 198
Me SWITZERLAND... 2... 7 pee the ee eh ht ew ee ee 199
= SY PAIA apc) cc es aes Ge th OR a BI ta ora BL apes Bese 201
=
Tanganyika (see TANZANIA)
ee TANZANIA: © is. Go aah ble Be, Be a ig le ed We GG, a ee 202
Here Tasmania (see AUSTRALIA)
ben THAILAND! © ng. ¢3. dered: 488 eS ed SOG a ge uae at Pe a aa 204
TOGO? 6h h5 0 ak a he ed Se eR Reg Ohi He ee oe Nt 205
TONGA: cise re cite hte ee eee oe ea a PE a ES a a a 206
TRINIDAD AND TOBAGO ... 1... 1. ee ee ee te 207
TUNISIA. 5 & Se eee eh & GR ae ie le Se As ae cee 208
TURKEY® eet. Bsty lh hs ES he ae ae es ee NE OE he Ts 209
—U—
UGANDA: - 3) dew Sola BOR Bi a, OA ae 211
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USES Re see ds Re eas Moca ae aaa NE he tea an Saha ind om at eae cass 212
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
; Ras al Khaimah, Sharjah, Umm al Qaiwain 2... ee ee ee es 213
ae United Arab Republic (see EGYPT)
UNITED KINGDOM . 2... ee ee ee 214
UNITED STATES . 2.0 1. oe ee 231
UPPER VOLTA... ww ee ee ee 216
URUGUAY 5. 62. bBo od aa at ce A Sa en ee 217
bs, —V—
VATICAN CITY 2.0 we ee 218
VENEZUELA . 2... ee 219
VIETNAM, NORTH . 2... ee eh 221
VIETNAM, SOUTH .. 1 1 we ee ee 222
—W—
WALLIS AND FUTUNA .. 0. 1 ee ee ee te ee 223
ma) Walvis Bay (see SOUTH AFRICA)
a WESTERN SAMOA... 1 we ee ee ee 224
=
YEMEN (Aden) 2. we ee 225
YEMEN (Sana) . 1. 2 ee ee ee 226
YUGOSLAVIA 20 wwe ee ee he ee 227
vil
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
se
ZAIRE... se ee
Baas ZAMBIA ........
Li ms Zanzibar (see TANZANIA)
|
i
: Il
“ IV
7 Vv
af s
tt VI
ae vit
ars vill
vill
July 1975
MAPS','bc907f22c66597a25795810abc704f34cdd3a30591dfc1768d87e55ba6ec465d','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e3e734f3fd2843b4098c2032bd2401db3b6ff960c462279b1db0cb99a2aa607',1975,'CA','Canada','raw',2,'MIDDLE AMERICA
SOUTH AMERICA
EUROPE
THE MIDDLE EAST
AFRICA
U.S.S.R. and ASIA
OCEANIA
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ACCT’
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
iDB
IEA
IFCTU
IHB
IPU
IRC
LAFTA
Afro-Asian People’s Solidarity Organization
Agency for Cultural and Technical Cooperation of
French-speaking Countries
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australla, New Zealand,
and the United States
Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Europgan Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Federation of Christian Trade Unions
International Hydrographic Bureau
Inter-Partiamentary Union
International Red Cross
Latin American Free Trade Association
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
a '' LICROSS League of Red Cross Societies
NATO North Atlantic Treaty Organization
ut OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
i OAU Organization of African Unity
i OCAM Afro-Matagasy and Mauritian Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
OPEC Organization of Petroleum Exporting Countries
SEATO South-East Asia Treaty Organization
UEAC Union of Central African States
UDEAC Econornic and Customs Union of Central Africa
WEU Western European Union
* WCL World Confederation of Labor
ye WFTU World Federation of Trade Unions
WPC World Peace Council
eo” x
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
Sc
GA
ECOSOC
TC
ICJ
Operating Bodies:
UNCTAD
TDB
UNICEF
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
U.N. Conference for Trade and Development
Trade and Development Board
U.N, Children’s Fund
Regional Economic Commissions:
ECA
ECAFE
ECE
ECLA
ESCAP
Economic Commission for Africa
Economic Commission for Asia and the Far East (see ESCAP)
Economic Commission for Europe
Economic Commission for Latin America
Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO
GATT
IBRD
ICAO
IDA
IFC
ILO
IMCO
IMF (FUND)
ITU
UNESCO
UPU
UNCTAD
WHO
WMO
Food and Agriculture Organization
General Agreement on Tariffs and Trade
International Bank for Reconstruction and Development
(World Bank)
International Civil Aviation Organization
International Development Association (IBRD Affiliate)
Inte’national Finance Corporation (IBRD Atfiliate)
International Labor Organization
Inter-Governmental Maritime Consultative Organization
International Monetary Fund
International Telacommunication Union
United Nations Educational, Scientific, and Cultural
Organization
Universal Postal Union
U.N. Conference on Trade and Development
World Health Organization
World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA
Committees:
Seabeds Committee
International Atomic cnergy Agency
United Nations Committee on the Peaceful Uses of the
Seabed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
xi
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
July 1975
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid -May 1975,
except for population estimates, which have been projected to 1 July
1975. Military manpower est!mates are as of 1 January 1975 except
for average number of males reaching military age, which are pro-
jected averages for the 5-year period 1975-79, Military and com-
munications data are as of 30 April 1975 unless otherwise indicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for “arable” may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included only
when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The
difference between the two is in the addition or subtraction of the
value of return on foreign investment. GDP equals GNP plus income
earned in the country but sent abroad, minus income earned abroad
but sent into the country. GDP thus tends io exceed GNP in debtor
countries, and the reverse Is true in creditor countries.
Major ports “ire the largest maritime ports of the country, relative
to other ports oj the same country, on the basis of estimated port
capacity, alongside berthing accommodations, and commercial or
naval importance. Minor ports are the remaining ports of a country
which have, relative to the major ports, significantly lower estimated
port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance. Major transport aircraft are those
weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The callar sign refers to U.S. dollars unless otherwise
stated. The abbreviation FY stands for U.S. fiscal year; all years are
calendar years unless otherwise indicated.
xii
Approved For Release 2002/07/03 : CIA-RDP86T00608R000600100003-3
Approved For Release 2002/07/03
July 1075
: CIA-RDP86T00608R000600100003-3
APGHANISTAN','122bd673d8d9474b7b2e77ef668f4d008da467a29159b40c54e362ebb0276b6c','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35bc7914d25f08f2b1594d49b0697ff6d2773c0accfa61eb601da3f5fd158138',1975,'AF','Afghanistan','raw',3,'Arabian Sen
{See teference map Vil}
LAND
250,000 sq. mi; 22% arable (12% cultivated, 10%
pasture), 755 desert, waste or urban, 39% forested
(1970)
Land boundaries: 3,425 mi.','f21aed29206ea7c6101046b36e1fa405f8cd600202a2195b136b3d521cd92b89','internet-archive','cia-readingroom-document-cia-rdp86t00608r000600100003-3','txt','76272b17e9471db248bbe12c679e49a654165283eabbd12db7f71dcfff235402','https://archive.org/download/cia-readingroom-document-cia-rdp86t00608r000600100003-3/cia-rdp86t00608r000600100003-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6197ffb526ec72f3076cbd1b077392e5a73d9dfd550fe1bf62ebc787dbd2bf5c',1975,'','','raw',1,'January 1975
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
National Basic Intelligence
FACTBOOK
DIA and DOS review(s)
completed..
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
OO rere,
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
FOREWORD
The National Basic Intelligence Factbook, a compilation of basic
data on political entities worldwide, is coordinated and published
semiannually by the Office of Geographic and Cartographic
Research, Central Intelligence Agency. It is issued for use by U.S.
Government departments and agencies. The data are prepared by
components of the Central Intelligence Agency, the Defense
Intelligence Agency, and the Department of State. Comments and
suggestions should be addressed to the Office of Geographic and
Cartographic Research (Attn: Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Federal government officials may obtain additional copies of the
Factbook directly or through liaison channels from the Central
Intelligence Agency.
Others may address inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
National Basic Intelligence
FACTBOOK
January 1975
Supersedes the July 1974 issuance of this Factbook, copies of
which should be destroyed.
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this factbook
Page
Abbreviations for International Organizations ...... 1... eee ix
United Nations (U.N.): Structure and Related Agencies ......... xi
=A—
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN: ©: <2 Sen aa H sted Arte ete he ne ee ke OB ak 1
‘Ajman (see UNITED ARAB EMIRATES)
ALEBANIAy © 3-205 3 04 See So eS tols GE Re Gk Blob wp od Ue Se EG 2
ALGERIA: 3:6 iegaw hts BOS, Se ee Rep oe ee Se we, ae 3
ANDORRA: «.. #5 3. a ee a ee oa gels Caan hon ec ee SA 4
ANGOLA: waco ee kG Me aa ee Bt oe lk, hae ee Ca a ae oth 5
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA, ae ein: Sree i oe A nan Ma GE RE oe OE ee ge? 6
ARGENTINA. s° 2 ko ae a eee Sh OP ee a a i ee eed V4
AUSTRALIA 1a.02 262.82 oot, Ga PE Gene AS. Bh ads ee an GR a a, Se A 9
AUSTRIA: ce ce, coer id ee So ee ee ends Bowe Gl An oy Go ga Ra Ee a 10
Azores (see PORTUGAL)
B=
BAHAMAS. 4. .:4 2-2 40-3 a BOS Ak ode ee ae we ee 11
BAHRAIN. - te <4isnie fy: Sh ee le cag ie toe ee eee ed og ee ae A, Be 12
Balearic Islands (see SPAIN)
BANGLADESH (2 2.2 2 koe. ea RO A Re ee a a 13
BARBADOS © 0. ssu-%, a sea a Bo a ec a eee a ee Oe 14
BEEGIUM®: #20. cee ho he tas Bee we ee Se ee cel el 15
BELIZE 2949.5 28 Bic inde et SS ae rae Bhs Ho ap yh Gas ee OS 17
BERMUDA: ~3.- 4 gc a BO Be Be ay eo GO. Gg 18
BHUTAN o2 i-358 vos hae be Se oe Se ge ee a ha 19
BOLIVIA 262 6) sane got SB Ade btar de a ek ah Boe ede Siege ge he ete eta 20
BOTSWANA, <¢. 285. e02 esce ck a ee a Se 21
BRAZIL 2 | soc iets, Spe it oh, SO ck RL ae ec, A nt Bete esl se, Sey Gide fe 22
British Honduras (see BELIZE)
BRITISH SOLOMON ISLANDS .... 1... ee 24
BRUNEI +3 oe ue ee ce a a Ree Le Pee ge Ee 24
BULGARIA® oc ae a Se OP ae ee ea ie ea 25
BUPRMAS 0 920 esis 8. cop st da ROR ea ee Ee he R beh ei ae i, BP 27
BURUNDI? S52 8 erie BaP ae ae eed Si Mae Sear Bee Sen 28
=4C=
Cabinda (see ANGOLA)
CAMBODIA: a. stb ae or a OR Se ie elec A ee LS 29
GAMEROON®: te e-8 e608 3 le ep ee ae ee ar a a BA es 30
GANADA® <4. <i ars ek BO Ge OE, Mick Bae de ee ae 31
Canary Islands (see SPAIN)
Cape Verde Islands (see PORTUGAL)
CENTRAL AFRICAN REPUBLIC ..... 2... ee ee ee 32
Ceylon (see SRI LANKA)
CHAD? sa oe ee a ae es Hes cae Ge Sy ae oi a Re Pe RY ane a 34
CHILES b-. .aiche Bt ce cee ls. Nea gt Ie Be be et Ba at oR be Be A a le 35
CHINA, PEOPLE’S REPUBLIC OF ....... 1... 0.2.02 008. 36
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
iii
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Page
= 6-3
CHINA, REPUBLIC OF ..............0.0..2. 0.0004 37
COLOMBIA: oc. 2 2 eckih acai le Bok GB are De eek Se ec ed 39
COMORO ISLANDS .... 1... 2. ee 40
CONGO (Brazzaville) .. 2... 41
Congo (Kinshasa) (see ZAIRE) 6
COOK ISLANDS .. 1. 1. ee 42
COSTA RIGA. 4. gee a ea SE oe ee a oO ee ee don a8 oe 43
CUBAT ae vests ant a. Gree eA Sa a Set WOR ee ek Re ee ee 44
CX PRUS*. . cress tt Se kT eh we Meee @ de ean es: ae Bak We 45
CZECHOSLOVAKIA 2... 47 ‘.
=a
DAHOMEY, <a aie. S aa Sabha le ow oye eee An de abe ok Ge Abd 48
DENMARK: | eos Senco aut aa DAL De Bleeds ce dow aig ce ete 49
DOMINICA® acca gy Bots Ehren ae Be, Pu De SOR Re SB 51
DOMINICAN REPUBLIC ........ 2... 51
Dubai (see UNITED ARAB EMIRATES)
——=
EGUADOR 6 2o4ee Sasioc ck at Bue Jy Gta A Gide Ale wt id abe 53
EG WIP? Ake frye sy “eee Sin, tel Seay fe Bo ating ot, Ry be ee RS OME thew So 54
EL SALVADOR’ |e gina geod eg RES bee 4k eh an Hg ek a ee 55
EQUATORIAL GUINEA ...... 0... 0.2... 0.222.020 087% 57
ETAIOPIA® 2.3. ac 2B Ma At SE Seal here B koala a de rere ee RE de es 58
=
FAEROE ISLANDS ..... 2. 1. ee ee 59
FALKLAND ISLANDS (MALVINAS) ..........0.. 2.0. 2.884 60
Fernando Po (see EQUATORIAL GUINEA)
PLOT i othe wh tata Seed ahha he Wh eek! ae Aare ode Gee iat edt teeth ait od ea SS 61
BINGAND? ss -5 cn Beco 6 SP eae) we we J. ek a ed ce 62
PRANCES . cece te et ee Nah ae ub S ees aR al a Seth EA ae he gel edow ty Laat He 63
FRENCH GUIANA...) ee 65
FRENCH: POLYNESIA. 20 to55 Ao ae he ee ee a Re A 66
FRENCH TERRITORY OF THE AFARS AND ISSAS ........... 67
Fujairah (see UNITED ARAB EMIRATES)
2sGe
GABON. oi) 6 ee Ae Gy he Be te ee a ae A RS 67
GAMBIA: je hee aa, A ee ek ee a ae a Ae a dee ees 69
GERMANY, EAST .... 2... ee 70
GERMANY, WEST ... . 1. 2 eee 71
GHANA .o52: So ican ate ee hon a ate oo eo cs Beet ot a on 73
GIBRALTAR® > tiles! te corso. 3. en, He es eo ee HE 74
GILBERT AND ELLICE ISLANDS ................... 75 e
GREECE? 8k ot ae ue So Bet Ge tae Se Ba de ae ere EOE 75
GREENLAND? © soo Ge Se oni Ge ee ee Mile Gp a ie Ere a aoe an 77
GRENADA. «5 <c<.5 ar Bee pre wae oe tale te aa hs A, dy trot, oh pth ch gd eS 78
GUADELOUPE? : fos. a. S04 ah 908-6 Ge omg ee ee Bera, as 79
GUATEMALA . ww wD 80 «
GUINEA: t: 251i fon fe on tk See a! lS ig ea ee ae 81
GUINEA-BISSAU . 2...) 82
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA: 2. bv8 eR la i a GR ee a oe we ek a a 83
iv
Approved For Release 2004/
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Page
—H—
HAND coe ies Soh eek os See ble Ae A Bk uk Sk BAR od 84
HONDURAS: 3-2-3 cose aoe eb ee bee we Ae Bee ea 85
HONGIKONG> “nxt sch a feb ie os Pte re es ec ene ee en meet Se 87
HUNGARY oct oe ees eke gid dng Sanaa Ee nae Ske hae os 88
panes fee
ICELAND "2 ae ewe Ble dee A es BU a By ed te 89
INDIA cass: eae oe AES he PI ge ene de eh teas hs Abe od gated 90
INDONESIA® 2.2 = cack Shoda Ae ee ett ta a aes dm Be ee 92
IPRANS 2k fesse des See Yh CA geet wi pn nat ale aS Wh ee ch de weds 93
IRAQ eos. ce, uk fee ad Beh Ws Mee ek, Ath dh aes ee 95
IRELAND? 2) 2.02 Gest AS ddan che alee Soe aoa ate ye 96
PSPUAE en ee hs ee ces oe ht oe te Bere et aa i ce tee, Fs agy He ee Reza WR GS 97
ITALY. Ao eae is se. acecegs feats ite Been de Gt BS oy Bara 99
IVORY COAST oxi ee es ee eee ee Se i eh a ee 100
yl
SAMAIGA:! hss oe ed eM ee Bg ae eto ee ee 102
JAPAN, Si oc os Wee th eee he RE Aid alee ae on 103
JORDAN: cee bak akin alge clio weil ae esl oe ee aaa, be es 104
“KS
KENYA. sli Aides cede dk efile th G1 dene ys Ge ee Dee ee ee 106
KOREA, NORTH |... 0 107
KOREA, SOUTH ... 1... 108
KUWAIT 2 cies ee ee EON eee Ae bien GA Aue "Ed ane 109
peel eee
AOS! on. e. Gch ge ahi do, NE Ge oe bh Bn Gein GE SS ae 110
LEBANON: © o,f mncsete tak a ete a hee fone aha a: eects Maes a 112
LESOTHO Me nin er ae hes cos GR shcneatina, sh tn Dap fe Bk BR 113
LIBERIA. gr cone Seek kB A eS de RAR a eek che 114
LIBYA awe tecko-n Se set te ead te Bue ee ty le dk ale re he 115
LIECHTENSTEIN .. 2... ee 116
LUXEMBOURG .... 0. ee ee 117
—M—
MACRO. 5 3 als ach hak, BOM Ben iy At aera cat on eB eg 119
MADAGASCAR: © owcnie-od cs le Se acne ce Oh Oe ee Goel ee 119
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
NVAIGAWI, © 85 are. ca oat neat ware oar Ben ie aes Rode Sekt Sethe 121
MMAIDAY SIAL”. stated haus Soc Be eral heel hed Slay) Baa ate Gos 122
IMMANIDIVES:. Ts kects te ticket 2 Nn dh de Poe ole Oe rh tend “teenies th, ste 125
NADL ons, eed tod co Se A Ce AU Beet Nic AON oe ie teins amas ove 126
MAL TAZ ~ 25 ax Sacacer eth te ete dh ca een wh eee te alte ne BUG Ae eear 127
MARTINIQUE: S208 45. nent le bo UE Aba ee ele Sees eee SS 128
MAURITANIA: cs03%. 2-e¢e 0 Bk ae bok Ble Aes Aw og nod, 2-8 Sha ae 129
MAURITIUS: «2. occ wd ree acd alec he eh ee ee SS 130
MEXICO vies} ec ete fhe de ate corns Oh RR salt sehen ah igs Bae 131
MONACO” 2oohc a ox Re ee a be ae Sa Ge A Oe Dae ee eS 133
MONGOLIA 2g: thn ak oe re iy BIRO Aas dete fe ON Se ee Be 133
MOBROCCO® eiveiscen eo ees LO a cacae ok eat eve ie ek 134
MOZAMBIQUE: 46. 3 cea dk ed gl ec ee Se ea ees 136
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Page
—N—
NAURUE vs eae 2 a Qe eed es DA GPa Soh, desde as ee es 137
NEPAL. 30) vole She ee he ag on Me is ee Bek, Spee an 138
NETHERLANDS: 2 3 cok ee bdo ee a eo ee ae a 139
NETHERLANDS ANTILLES .................. 20484, 140
NEW CALEDONIA .... 2... 142 .
NEW HEBRIDES) 9). ce geo a he ee ee Pw ek 143 ‘
NEW ZEALAND. 2 koe we i be ee ee 143
NICARAGUA .. 1 1 2 144
NIGER was%s Sir alale es Bh eo Sal cece tad eR) ae at! ho ok, oat eae we ae aoe eae oe 146
NIGERIA 4.0 keke cc okt Se ett faves aie BA ie SA Sk de OE thee 147
Northern Rhodesia (see ZAMBIA) °
NORWAY: 9005.04.03 aie ak Me ow ee ee te ho he ee ee a 148
OL:
OMAN». cage PSPS Be a ae Fo BB Batacae th ie 2G 150
—P—
PAKISTAN 2 ees eee ae A ee Wea a oe ea ee 150
PANAMA® «52 fa6 5 ne a we GE che oe ahs oR. owe Se Eee Gi nice 152
PAPUA NEW GUINEA... .. 2... 2... ee 153
PARAGUAY. oe ee Som we a BP et ee oe FOO ee ee en hee 154
Pemba (see TANZANIA)
PERU a eB cao in 0s Gaia, a Aes AN ge oe ee ok he gs ce i, Mee ol etn, ee Re hal wd 156
PHIEIPPINES: . 2.04%, .2 4, g0028¢3 = See Sunless G SIA a bl Bog leu & 157
POLAND:+ ve:cc 3h ai al ive eed te et BAe No ee ae ha Se eS 158
PORTUGAL. fone ee ae ge te eal 3S Te en ed HA ge ee das 159
Portuguese Guinea (see GUINEA-BISSAU)
PORTUGUESE TIMOR .............0. 00200000 8 161
—Q—
QATAR: ¢ fk Sh eslk we Gio i Ew sens he eo ae A aie he ot 162
—R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
PEUNION: 9:5 a: tee coreg Sl GOR eke ac arta Gls ty ale & Gow 163
RHODESIA.» ee arte ee at ae axe ee ele ak ao Ue GO Se ek ae ile Ss 164
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA gS oie eS Go te ae Sore es Sela de oh Se eo we ae 165
RWANDA) «2 ee ek a eee ae ek ee ee dee Poa a 167
—S—
ST. CHRISTOPHER-NEVIS-ANGUILLA ................. 168
ST SEO CIA ns 2 ik Ges eid eerie let air eon Matec an Gee la in kk 169
Site VINCENT <2 ae eg ee oe ae aS a ee 170 a
SAN MARINO .. 2...) 170
SAUDI ARABIA ..........., Ath Sted, Realtones UA cae tee hap SGN argh 172
SENEGAL, vsse: 30 is ae ao G0, at. Goda oe oe aD 173
SEYCHELLES Se Sao 4 me as wi wh tg oe Was ae fat Retin ole» Tee. 24 174
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE 5-6 aoc semis can Pty wd, Bae Gah oo wae Se dodee 175 :
SLIRIR IM, a meter ara ot ahs cage a te Fv us By Pk Ee A ss teks Ga 176
SINGAPORE? tote ceo a8 cg oe Ph ee ee wes Ma ee Sw 177
SOMALIA ei.ce fons Ow 3 ah Rhee ae & chow sek eee & Sob aan 178
vi
Approved For Release 2004/11/01 :
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
Page
=F
SOUTH AFRICA 2... ww ee 179
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA .... 2 ee ee 180
SPAIN? 2 ot oe idk fe GELS, Go ee Te A lag ee oa Mn ea. Be ES 182
SPANISH SAHARA .. 2. 0 0 eee 183
SRI LANKA (formerly Ceylon) . 2 6 6 6 ee 184
SUDAN) 2:4 S000 owe Boe ele ee a Bk ae ae a ine, Ae A Oe ES 186
SURINAM) <0 cc. ce ons, ee ae MO a i eee 187
SWAZILAND» «2. coc foe ae ee oe er eG a ae nO ae et 188
SWEDEN 2.6 4. 6 ee eh ee ee Pe Le 189
SWITZERLAND « ¢. Ge Se a ea 191
GYVBIRe b otano Skee ek oo ee ee A cl te Ung Ce a aa aes 192
=p
Tanganyika (see TANZANIA)
TANZANIA} oan so ae bo dee es eh cae BS Bee te tel oe ae ah Gey 193
Tasmania (see AUSTRALIA)
THAILAND: © = ace 2 sk Ae Se Se ee BOM EO, oe et eae 195
TOGO? 2) eines ae buns Gr ica tl et ah ale OP cicias ae 196
TONGA.” Avge bck wien deb eo AP ROR ie Rd ala che doe Lac 197
TRINIDAD AND TOBAGO ..... 2... ee ee 198
TUNISIA <3) 63k She Be te eee, Sa Ge Bee oh aaa 199
TURKEY: ee wc oe ne oe ee a BO, Gs Je ae a 201
Yas
WGANDA. S<s-6-eoida we ce Bo See aR ES Eee ee a ae 202
Umm al Qaiwain (see UNITED ARAB EMIRATES)
WSS Rees heed os he ee ee An eo eos. ohn “Bg Sera da cee tai rca te Gee “aah “ae 203
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain . . . 1. ee ees 204
United Arab Republic (see EGYPT)
UNITED KINGDOM ... 1. we ee 205
UNITED''STATES: « 4. cadodae e e e P oe BL Pes 221
UPPER-VOLTA. (6 ayec4.4. % 2-4 ee eed ee ee ee 207
WRUGUAY 40%. & Seen Siaee 42h ee Oe BO ee ek Ete 208
ey eo
VATICAN GITY: 9 @ a.e-4 2h eR hoe EE ROR] ere ne te Ses 209
VENEZWELA: vox ae ee oo eh eee oR ee ke a ee Sa oe Ge 210
VIETNAM, NORTH .... 2. ee ee ee ee 211
VIETNAM, SOUTH .. 1... ee ee 212
—_WwW—
WALLIS AND FUTUNA .. 0 2. 1 ee ee 214
Walvis Bay (see SOUTH AFRICA)
WESTERN SAMOA... www ee 214
—_Y—
YEMEN (Aden). ww ee 215
YEMEN (Sana) . 2 6 6s eee 216
YUGOSLAVIA 26 217
vii
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
viii
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Zanzibar (see TANZANIA)
é
VII
Approved For Release 2004/11/01 :
January 1975
Page
MAPS','0603bfa8d14f070bdf4d7ec364ca375ad594be07f75185b960544a0ce12aeb46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8586a8019c5837e0be940f5e7b3adc8e866500cb8544a500a31211e30cc9cc2',1975,'CA','Canada','raw',2,'MIDDLE AMERICA
SOUTH AMERICA
EUROPE
THE MIDDLE EAST
AFRICA
U.S.S.R. and ASIA
OCEANIA
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ACCT
ADB
AFDB
ANZUS
ASA
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
IDB
IFCTU
IHB
IPU
IRC
LAFTA
LICROSS
Afro-Asian People’s Solidarity Organization
Agency for Cultural and Technical Cooperation of
French-speaking Countries
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asia
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
Poolitical-Econommic Association of lvory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
Inter-American Development Bank
International Federation of Christian Trade Unions
International Hydrographic Bureau
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
ix
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
NATO North Atlantic Treaty Organization
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity es
OCAM Afro-Malagasy and Mauritian Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
OPEC Organization of Petroleum Exporting Countries e
SEATO South-East Asia Treaty Organization
UEAC Union of Central African States
UDEAC Economic and Customs Union of Central Africa
WEU Western European Union
WCL World Confederation of Labor
WFTU World Federation of Trade Unions
WPC World-Peace Council
?
?
Approved For Release 2004/11/01 :
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
Sc Security Council
GA General Assembly
ECOSOG Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
Operating Bodies:
Secretariat
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children’s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East (see ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization
IAEA
Committees:
Seabeds Committee
Autonomous Organization Under the U.N.:
International Atomic Energy Agency
United Nations Committee on the Peaceful Uses of the
Seabed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
xii
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid-October
1974, except for population estimates, which have been projected to 1
January 1975. Military manpower estimates are as of 1 January 1974
except for average number of males reaching military age, which are
projected averages for the 5-year period 1974-78. Military and com-
munications data are as of 31 October 1974 unless otherwise in-
dicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for “arable” may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included only
when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The
difference between the two is in the addition or subtraction of the
value of return on foreign investment. GDP equals GNP plus income
earned in the country but sent abroad, minus income earned abroad
but sent into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is true in creditor countries.
Major ports are the largest maritime ports of the country, relative
to other ports of the same country, on the basis of estimated port
capacity, alongside berthing accommodations, and commercial or
naval importance. Minor ports are the remaining ports of a country
which have, relative to the major ports, significantly lower estimated
port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance. Major transport aircraft are those
weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise
stated. The abbreviation FY stands for U.S. fiscal year; all years are
calendar years unless otherwise indicated.
Approved For Release 2004/11/01 :
January 1975
Approved For Release 2004/11/01 : CIA-RDP79-01051A000700010004-6
January 1975','6feb12e0d123f560bc04db08346fdc1d09fdd6c52b5042191d104ebd83743229','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd9fb0e484b9ebf79cb8fb5416da277c460e760981ffd2f1c2ad5f5a50315eae',1975,'AF','Afghanistan','raw',3,'LAND
250,000 sq. mi.; 22% arable (12% cultivated, 10%
.pasture), 75% desert, waste or urban, 3% forested
(1970)
Land boundaries: 3,425 mi.','d8ebf2b49722ae39337cb459e58387e366a38c7e09930c8ab8d23f5464f47cf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010004-6','txt','c04f4596b7f7f4dd35b130cf48564d96bf598b6b720bb4697e2347ba871b8e83','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010004-6/cia-rdp79-01051a000700010004-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b12861eb882001005fd00a1cbd2d090558f7a15e7443d781fabc0307d5656954',1992,'','','raw',1,'The Project Gutenberg EBook of The 1992 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1992 CIA World Factbook
Author: United States. Central Intelligence Agency.
Posting Date: February 21, 2010 [EBook #48]
Release Date: October, 1993
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1992 CIA WORLD FACTBOOK ***
Produced by Dr. Gregory B. Newby
The Project Gutenberg Edition of THE CIA WORLD FACTBOOK 1992: January 1, 1993
This edition, as are all Project Gutenberg Editions, is Plain Vanilla ASCII,
meaning there are no characters other than what you would see on paper, thus
no page returns, no markup, nothing but the characters you would type if you
were to copy this from a book on a typewriter. Repetitive paged headers and
trailing spaces are not present. Leading spaces have been preserved in fact
sections for readability.
Mail subject headers can be searched with leading :''s. . .such as:
:Afghanistan Geography
:Afghanistan People
:Afghanistan Government
:Afghanistan Government
:Afghanistan Economy
:Afghanistan Economy
:Afghanistan Communications
:Afghanistan Defense Forces
To find the beginning of any country, search for :country
To find internal information, search for :country section, as above.
THE CIA WORLD FACTBOOK 1992
:Afghanistan Geography
Total area:
647,500 km2
Land area:
647,500 km2
Comparative area:
slightly smaller than Texas
Land boundaries:
5,529 km total; China 76 km, Iran 936 km, Pakistan 2,430 km, Tajikistan
1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline:
none - landlocked
Maritime claims:
none - landlocked
Disputes:
Pashtunistan issue over the North-West Frontier Province with Pakistan;
periodic disputes with Iran over Helmand water rights; Pakistan, Saudi
Arabia, and Iran continue to support clients in country; power struggles
among various groups for control of Kabul, regional rivalries among emerging
warlords, and traditional tribal disputes continue
Climate:
arid to semiarid; cold winters and hot summers
Terrain:
mostly rugged mountains; plains in north and southwest
Natural resources:
natural gas, crude oil, coal, copper, talc, barites, sulphur, lead, zinc,
iron ore, salt, precious and semiprecious stones
Land use:
arable land 12%; permanent crops NEGL%; meadows and pastures 46%; forest and
woodland 3%; other 39%; includes irrigated NEGL%','b4737045eee36bfd7e18ff6d28d2dffd6bf41e53695a9121e8ca6fb841ac21e9','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

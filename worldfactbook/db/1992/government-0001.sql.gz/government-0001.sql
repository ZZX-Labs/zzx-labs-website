SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('240c88fe11864032ce44f33fac6f5956a3ba4cefe12fe6f59e5a3bfde590ce95',1992,'BG','Bulgaria','government',10,'Australian Labor Party, Paul John KEATING
opposition:
Liberal Party, John HEWSON; National Party, Timothy FISCHER; Australian
Democratic Party, John COULTER
Suffrage:
universal and compulsory at age 18
Elections:
House of Representatives:
last held 24 March 1990 (next to be held by NA November 1993); results -
Labor 39.7%, Liberal-National 43%, Australian Democrats and independents
11.1%; seats - (148 total) Labor 78, Liberal-National 69, independent 1
Senate:
last held 11 July 1987 (next to be held by NA July 1993); results - Labor
43%, Liberal-National 42%, Australian Democrats 8%, independents 2%; seats -
(76 total) Labor 32, Liberal-National 34, Australian Democrats 7,
independents 3
Communists:
4,000 members (est.)
:Australia Government
Other political or pressure groups:
Australian Democratic Labor Party (anti-Communist Labor Party splinter
group); Peace and Nuclear Disarmament Action (Nuclear Disarmament Party
splinter group)
Member of:
AfDB, AG (observer), ANZUS, APEC, AsDB, Australia Group, BIS, C, CCC, COCOM,
CP, EBRD, ESCAP, FAO, GATT, G-8, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA,
IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU,
LORCS, MTCR, NAM (guest), NEA, NSG, OECD, PCA, SPC, SPF, UN, UNCTAD, UNESCO,
UNFICYP, UNHCR, UNIIMOG, UNTAG, UNTSO, UPU, WFTU, WHO, WIPO, WMO, WTO, ZC
Diplomatic representation:
Ambassador Michael J. COOK; Chancery at 1601 Massachusetts Avenue NW,
Washington, DC 20036; telephone (202) 797-3000; there are Australian
Consulates General in Chicago, Honolulu, Houston, Los Angeles, New York,
Pago Pago (American Samoa), and San Francisco
US:
Ambassador Melvin F. SEMBLER; Moonah Place, Yarralumla, Canberra, Australian
Capital Territory 2600 (mailing address is APO AP 96549); telephone [61] (6)
270-5000; FAX [61] (6) 270-5970; there are US Consulates General in
Melbourne, Perth, and Sydney, and a Consulate in Brisbane
Flag:
blue with the flag of the UK in the upper hoist-side quadrant and a large
seven-pointed star in the lower hoist-side quadrant; the remaining half is a
representation of the Southern Cross constellation in white with one small
five-pointed star and four, larger, seven-pointed stars
:Australia Economy
Overview:
Australia has a prosperous Western-style capitalist economy, with a per
capita GDP comparable to levels in industrialized West European countries.
Rich in natural resources, Australia is a major exporter of agricultural
products, minerals, metals, and fossil fuels. Of the top 25 exports, 21 are
primary products, so that, as happened during 1983-84, a downturn in world
commodity prices can have a big impact on the economy. The government is
pushing for increased exports of manufactured goods, but competition in
international markets continues to be severe.
GDP:
purchasing power equivalent - $280.8 billion, per capita $16,200; real
growth rate --0.6% (1991 est.)
Inflation rate (consumer prices):
3.3% (September 1991)
Unemployment rate:
10.5% (November 1991)
Budget:
revenues $76.9 billion; expenditures $75.4 billion, including capital
expenditures of NA (FY91)
Exports:
$41.7 billion (f.o.b., FY91)
commodities:
metals, minerals, coal, wool, cereals, meat, manufacturers
partners:
Japan 26%, US 11%, NZ 6%, South Korea 4%, Singapore 4%, UK, Taiwan, Hong
Kong
Imports:
$37.8 billion (f.o.b., FY91)
commodities:
manufactured raw materials, capital equipment, consumer goods
partners:
US 24%, Japan 19%, UK 6%, FRG 7%, NZ 4% (1990)
External debt:
$130.4 billion (June 1991)
Industrial production:
growth rate --0.9% (1991); accounts for 32% of GDP
Electricity:
40,000,000 kW capacity; 155,000 million kWh produced, 8,960 kWh per capita
(1991)
Industries:
mining, industrial and transportation equipment, food processing, chemicals,
steel, motor vehicles
Agriculture:
accounts for 5% of GNP and 37% of export revenues; world''s largest exporter
of beef and wool, second-largest for mutton, and among top wheat exporters;
major crops - wheat, barley, sugarcane, fruit; livestock - cattle, sheep,
poultry
Illicit drugs:
Tasmania is one of the world''s major suppliers of licit opiate products;
government maintains strict controls over areas of opium poppy cultivation
and output of poppy straw concentrate
Economic aid:
donor - ODA and OOF commitments (1970-89), $10.4 billion
Currency:
Australian dollar (plural - dollars); 1 Australian dollar ($A) = 100 cents
Exchange rates:
Australian dollars ($A) per US$1 - 1.3360 (January 1992), 1.2836 (1991),
1.2618 (1989), 1.2752 (1988), 1.4267 (1987)
:Australia Economy
Fiscal year:
1 July - 30 June
:Australia Communications
Railroads:
40,478 km total; 7,970 km 1.600-meter gauge, 16,201 km 1.435-meter standard
gauge, 16,307 km 1.067-meter gauge; 183 km dual gauge; 1,130 km electrified;
government owned (except for a few hundred kilometers of privately owned
track) (1985)
Highways:
837,872 km total; 243,750 km paved, 228,396 km gravel, crushed stone, or
stabilized soil surface, 365,726 km unimproved earth
Inland waterways:
8,368 km; mainly by small, shallow-draft craft
Pipelines:
crude oil 2,500 km; petroleum products 500 km; natural gas 5,600 km
Ports:
Adelaide, Brisbane, Cairns, Darwin, Devonport, Fremantle, Geelong, Hobart,
Launceston, Mackay, Melbourne, Sydney, Townsville
Merchant marine:
85 ships (1,000 GRT or over) totaling 2,324,803 GRT/3,504,385 DWT; includes
2 short-sea passenger, 8 cargo, 8 container, 11 roll-on/roll-off, 1 vehicle
carrier, 17 petroleum tanker, 2 chemical tanker, 4 liquefied gas, 1
combination ore/oil, 30 bulk, 1 combination bulk
Civil air:
about 150 major transport aircraft
Airports:
481 total, 440 usable; 237 with permanent-surface runways, 1 with runway
over 3,659 m; 20 with runways 2,440-3,659 m; 268 with runways 1,220-2,439 m
Telecommunications:
good international and domestic service; 8.7 million telephones; broadcast
stations - 258 AM, 67 FM, 134 TV; submarine cables to New Zealand, Papua New
Guinea, and Indonesia; domestic satellite service; satellite stations - 4
Indian Ocean INTELSAT, 6 Pacific Ocean INTELSAT earth stations
:Australia Defense Forces
Branches:
Australian Army, Royal Australian Navy, Royal Australian Air Force
Manpower availability:
males 15-49, 4,769,005; 4,153,060 fit for military service; 138,117 reach
military age (17) annually
Defense expenditures:
exchange rate conversion - $7.5 billion, 2.4% of GDP (FY92 budget)
:Austria Geography
Total area:
83,850 km2
Land area:
82,730 km2
Comparative area:
slightly smaller than Maine
Land boundaries:
2,591 km total; Czechoslovakia 548 km, Germany 784 km, Hungary 366 km, Italy
430 km, Liechtenstein 37 km, Slovenia 262 km, Switzerland 164 km
Coastline:
none - landlocked
Maritime claims:
none - landlocked
Disputes:
none
Climate:
temperate; continental, cloudy; cold winters with frequent rain in lowlands
and snow in mountains; cool summers with occasional showers
Terrain:
mostly mountains with Alps in west and south; mostly flat, with gentle
slopes along eastern and northern margins
Natural resources:
iron ore, crude oil, timber, magnesite, aluminum, lead, coal, lignite,
copper, hydropower
Land use:
arable land 17%; permanent crops 1%; meadows and pastures 24%; forest and
woodland 39%; other 19%; includes irrigated NEGL%','102c4e8c92626cd04ca9b7e6bc5fa30ddcfcc078fba36aa10598e6c4d1919524','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e06dcbe3bca3d25ad0b73aac18d55aee3a787c9a778851763a46dd527083850b',1992,'MY','Malaysia','government',18,'Union of Democratic Forces (UDF), Filip DIMITROV, chairman, consisting of
United Democratic Center, Democratic Party, Radical Democratic Party,
Christian Democratic Union, Alternative Social Liberal Party, Republican
Party, Civic Initiative Movement, Union of the Repressed, and about a dozen
other groups; Movement for Rights and Freedoms (pro-Muslim party) (MRF),
Ahmed DOGAN, chairman, supports UDF but not officially in coalition with it
opposition:
Bulgarian Socialist Party (BSP), formerly Bulgarian Communist Party (BCP),
Zhan VIDENOV, chairman
Suffrage:
universalandcompulsoryatage 18
Elections:
National Assembly:
last held 13 October 1991; results - BSP 33%, UDF 34%, MRF 7.5%; seats -
(240 total) BSP 106, UDF 110, Movement for Rights and Freedoms 24
President:
last held 12 January 1992; second round held 19 January 1992; results -
Zhelyu ZHELEV was elected by popular vote
Communists:
Bulgarian Socialist Party (BSP), formerly Bulgarian Communist Party (BCP),
501,793 members; several small Communist parties
:Bulgaria Government
Other political or pressure groups:
Ecoglasnost; Podkrepa (Support) Labor Confederation; Fatherland Union;
Bulgarian Democratic Youth (formerly Communist Youth Union); Confederation
of Independent Trade Unions of Bulgaria (KNSB); Nationwide Committee for
Defense of National Interests; Peasant Youth League; Bulgarian Agrarian
National Union - United (BZNS); Bulgarian Democratic Center; "Nikola Petkov"
Bulgarian Agrarian National Union; Internal Macedonian Revolutionary
Organization - Union of Macedonian Societies (IMRO-UMS); numerous regional,
ethnic, and national interest groups with various agendas
Member of:
BIS, CCC, CE, CSCE, EBRD, ECE, FAO, G-9, IAEA, IBRD, ICAO, ICFTU, IIB, ILO,
IMF, IMO, INMARSAT, IOC, ISO, ITU, LORCS, NACC, NSG, PCA, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO
Diplomatic representation:
Ambassador Ognyan PISHEV; Chancery at 1621 22nd Street NW, Washington, DC
20008; telephone (202) 387-7969
US:
Ambassador Hugh Kenneth HILL; Embassy at 1 Alexander Stamboliski Boulevard,
Sofia (mailing address is APO AE 09213-5740); telephone [359] (2) 88-48-01
through 05; Embassy has no FAX machine
Flag:
three equal horizontal bands of white (top), green, and red; the national
emblem formerly on the hoist side of the white stripe has been removed - it
contained a rampant lion within a wreath of wheat ears below a red
five-pointed star and above a ribbon bearing the dates 681 (first Bulgarian
state established) and 1944 (liberation from Nazi control)
:Bulgaria Economy
Overview:
Growth in the lackluster Bulgarian economy fell to the 2% annual level in
the 1980s. By 1990, Sofia''s foreign debt had skyrocketed to over $10 billion
- giving a debt-service ratio of more than 40% of hard currency earnings and
leading the regime to declare a moratorium on its hard currency payments.
The post-Communist government faces major problems of renovating an aging
industrial plant; coping with worsening energy, food, and consumer goods
shortages; keeping abreast of rapidly unfolding technological developments;
investing in additional energy capacity (the portion of electric power from
nuclear energy reached over one-third in 1990); and motivating workers, in
part by giving them a share in the earnings of their enterprises. Bulgaria''s
new government, led by Prime Minister Filip Dimitrov, is strongly committed
to economic reform. The previous government, even though dominated by former
Communists, had taken the first steps toward dismantling the central
planning system, bringing the economy back into balance, and reducing
inflationary pressures. The program produced some encouraging early results,
including eased restrictions on foreign investment, increased support from
international financial institutions, and liberalized currency trading.
Small entrepreneurs have begun to emerge and some privatization of small
enterprises has taken place. The government has passed bills to privatize
large state-owned enterprises and reform the banking system. Negotiations on
an association agreement with the EC began in late 1991.
GNP:
purchasing power equivalent - $36.4 billion, per capita $4,100; real growth
rate --22% (1991 est.)
Inflation rate (consumer prices):
420% (1991 est.)
Unemployment rate:
10% (1991 est.)
Budget:
revenues NA; expenditures NA, including capital expenditures of $NA billion
(1991)
Exports:
$8.4 billion (f.o.b., 1990)
commodities:
machinery and equipment 55.3%; agricultural products 15.0%; manufactured
consumer goods 10.0%; fuels, minerals, raw materials, and metals 18.4%;
other 1.3% (1990)
partners:
former CMEA countries 70.6% (USSR 56.2%, Czechoslovakia 3.9%, Poland 2.5%);
developed countries 13.6% (Germany 2.1%, Greece 1.2%); less developed
countries 13.1% (Libya 5.8%, Iran 0.5%) (1990)
Imports:
$9.6 billion (f.o.b., 1990)
commodities:
fuels, minerals, and raw materials 43.7%; machinery and equipment 45.2%;
manufactured consumer goods 6.7%; agricultural products 3.8%; other 0.6%
partners:
former CMEA countries 70.9% (former USSR 52.7%, Poland 4.1%); developed
countries 20.2% (Germany 5.0%, Austria 2.1%); less developed countries 7.2%
(Libya 2.0%, Iran 0.7%)
External debt:
$11.2 billion (1991)
Industrial production:
growth rate --14.7% (1990); accounts for about 37% of GNP (1990)
Electricity:
11,500,000 kW capacity; 45,000 million kWh produced, 5,040 kWh per capita
(1990)
:Bulgaria Economy
Industries:
machine building and metal working, food processing, chemicals, textiles,
building materials, ferrous and nonferrous metals
Agriculture:
accounts for 22% of GNP (1990); climate and soil conditions support
livestock raising and the growing of various grain crops, oilseeds,
vegetables, fruits, and tobacco; more than one-third of the arable land
devoted to grain; world''s fourth-largest tobacco exporter; surplus food
producer
Illicit drugs:
transshipment point for southwest Asian heroin transiting the Balkan route
Economic aid:
donor - $1.6 billion in bilateral aid to non-Communist less developed
countries (1956-89)
Currency:
lev (plural - leva); 1 lev (Lv) = 100 stotinki
Exchange rates:
leva (Lv) per US$1 - 17.18 (1 January 1992), 16.13 (March 1991), 0.7446
(November 1990), 0.84 (1989), 0.82 (1988), 0.90 (1987); note - floating
exchange rate since February 1991
Fiscal year:
calendar year
:Bulgaria Communications
Railroads:
4,300 km total, all government owned (1987); 4,055 km 1.435-meter standard
gauge, 245 km narrow gauge; 917 km double track; 2,510 km electrified
Highways:
36,908 km total; 33,535 km hard surface (including 242 km superhighways);
3,373 km earth roads (1987)
Inland waterways:
470 km (1987)
Pipelines:
crude oil 193 km; petroleum products 418 km; natural gas 1,400 km (1986)
Ports:
Burgas, Varna, Varna West; river ports are Ruse, Vidin, and Lom on the
Danube
Merchant marine:
110 ships (1,000 GRT and over) totaling 1,234,657 GRT/1,847,759 DWT;
includes 2 short-sea passenger, 30 cargo, 2 container, 1 passenger-cargo
training, 6 roll-on/roll-off, 15 petroleum tanker, 4 chemical carrier, 2
railcar carrier, 48 bulk; Bulgaria owns 1 ship (1,000 GRT or over) totaling
8,717 DWT operating under Liberian registry
Civil air:
86 major transport aircraft
Airports:
380 total, 380 usable; about 120 with permanent-surface runways; 20 with
runways 2,440-3,659 m; 20 with runways 1,220-2,439 m
Telecommunications:
extensive radio relay; 2.5 million telephones; direct dialing to 36
countries; phone density is 25 phones per 100 persons; 67% of Sofia
households now have a phone (November 1988); broadcast stations - 20 AM, 15
FM, and 29 TV, with 1 Soviet TV repeater in Sofia; 2.1 million TV sets
(1990); 92% of country receives No. 1 television program (May 1990); 1
satellite ground station using Intersputnik; INTELSAT is used through a
Greek earth station
:Bulgaria Defense Forces
Branches:
Army, Navy, Air and Air Defense Forces, Frontier Troops, Internal Troops
Manpower availability:
males 15-49, 2,181,421; 1,823,678 fit for military service; 65,942 reach
military age (19) annually
Defense expenditures:
exchange rate conversion - 4.413 billion leva, 4.4% of GNP (1991); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
:Burkina Geography
Total area:
274,200 km2
Land area:
273,800 km2
Comparative area:
slightly larger than Colorado
Land boundaries:
3,192 km; Benin 306 km, Ghana 548 km, Ivory Coast 584 km, Mali 1,000 km,
Niger 628 km, Togo 126 km
Coastline:
none - landlocked
Maritime claims:
none - landlocked
Disputes:
the disputed international boundary between Burkina and Mali was submitted
to the International Court of Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1986, which both sides agreed to accept;
Burkina and Mali are proceeding with boundary demarcation, including the
tripoint with Niger
Climate:
tropical; warm, dry winters; hot, wet summers
Terrain:
mostly flat to dissected, undulating plains; hills in west and southeast
Natural resources:
manganese, limestone, marble; small deposits of gold, antimony, copper,
nickel, bauxite, lead, phosphates, zinc, silver
Land use:
arable land 10%; permanent crops NEGL%; meadows and pastures 37%; forest and
woodland 26%; other 27%, includes irrigated NEGL%','3beebd716e58af64c89d7682a286779405989e74618ae050f8bd49026daa4fe2','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8247c26565ef391420acb68093a82c3d8d85191b364951b32a97758b42a86bdd',1992,'AU','Australia','government',30,'Capital:
Nicosia
Administrative divisions:
6 districts; Famagusta, Kyrenia, Larnaca, Limassol, Nicosia, Paphos
Independence:
16 August 1960 (from UK)
Constitution:
16 August 1960; negotiations to create the basis for a new or revised
constitution to govern the island and to better relations between Greek and
Turkish Cypriots have been held intermittently; in 1975 Turkish Cypriots
created their own Constitution and governing bodies within the Turkish
Federated State of Cyprus, which was renamed the Turkish Republic of
Northern Cyprus in 1983; a new Constitution for the Turkish area passed by
referendum in May 1985
Legal system:
based on common law, with civil law modifications
National holiday:
Independence Day, 1 October (15 November is celebrated as Independence Day
in the Turkish area)
Executive branch:
president, Council of Ministers (cabinet); note - there is a president,
prime minister, and Council of Ministers (cabinet) in the Turkish area
Legislative branch:
unicameral House of Representatives (Vouli Antiprosopon); note - there is a
unicameral Assembly of the Republic (Cumhuriyet Meclisi) in the Turkish area
Judicial branch:
Supreme Court; note - there is also a Supreme Court in the Turkish area
Leaders:
Chief of State and Head of Government:
President George VASSILIOU (since February 1988); note - Rauf R. DENKTASH
has been president of the Turkish area since 13 February 1975
Political parties and leaders:
Greek Cypriot:
Progressive Party of the Working People (AKEL; Communist Party), Dimitrios
CHRISTOFIAS; Democratic Rally (DESY), Glafkos KLERIDES; Democratic Party
(DEKO), Spyros KYPRIANOU; United Democratic Union of the Center (EDEK),
Vassos LYSSARIDES; Socialist Democratic Renewal Movement (ADESOK), Mikhalis
PAPAPETROU; Liberal Party, Nikos ROLANDIS
:Cyprus Government
Turkish area:
National Unity Party (UBP), Dervis EROGLU; Communal Liberation Party (TKP),
Mustafa AKINCI; Republican Turkish Party (CTP), Ozker OZGUR; New Cyprus
Party (YKP), Alpay DURDURAN; Social Democratic Party (SDP), Ergun VEHBI; New
Birth Party (YDP), Ali Ozkan ALTINISHIK; Free Democratic Party (HDP), Ismet
KOTAK; note - CTP, TKP, and YDP joined in the coalition Democratic Struggle
Party (DMP) for the 22 April 1990 legislative election; the CTP and TKP
boycotted the byelection of 13 October 1991, which was for 12 seats; the DMP
was dissolved after the 1990 election; National Justice Party (MAP), Zorlu
TORE; United Sovereignty Party, Arif Salih KIRDAG
Suffrage:
universal at age 18
Elections:
President:
last held 14 February and 21 February 1988 (next to be held February 1993);
results - George VASSILIOU 52%, Glafkos KLERIDES 48%
House of Representatives:
last held 19 May 1991; results - DESY 35.8%, AKEL (Communist) 30.6, DEKO
19.5%, EDEK 10. 9%; others 3.2% seats - (56 total) DESY 20, AKEL (Communist)
18, DEKO 11, EDEK 7
Turkish Area: President:
last held 22 April 1990 (next to be held April 1995); results - Rauf R.
DENKTASH 66%, Ismail BOZKURT 32.05%
Turkish Area: Assembly of the Republic:
last held 6 May 1990 (next to be held May 1995); results - UBP
(conservative) 54.4%, DMP 44.4% YKP .9%; seats - (50 total) UBP
(conservative) 45, SDP 1, HDP 2, YDP 2; note - by-election of 13 October
1991 was for 12 seats
Communists:
about 12,000
Other political or pressure groups:
United Democratic Youth Organization (EDON; Communist controlled); Union of
Cyprus Farmers (EKA; Communist controlled); Cyprus Farmers Union (PEK;
pro-West); Pan-Cyprian Labor Federation (PEO; Communist controlled) ;
Confederation of Cypriot Workers (SEK; pro-West); Federation of Turkish
Cypriot Labor Unions (Turk-Sen); Confederation of Revolutionary Labor Unions
(Dev-Is)
Member of:
C, CCC, CE, CSCE, EBRD, ECE, FAO, G-77, GATT, IAEA, IBRD, ICAO, ICC, ICFTU,
IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, NAM,
OAS (observer), UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO,
WTO; note - the Turkish-Cypriot administered area of Cyprus has observer
status in the OIC
Diplomatic representation:
Ambassador Michael E. SHERIFIS; Chancery at 2211 R Street NW, Washington, DC
20008; telephone (202) 462-5772
US:
Ambassador Robert E. LAMB; Embassy at the corner of Therissos Street and
Dositheos Street, Nicosia (mailing address is APO AE 09836); telephone [357]
(2) 465151; FAX [357] (2) 459-571
Flag:
white with a copper-colored silhouette of the island (the name Cyprus is
derived from the Greek word for copper) above two green crossed olive
branches in the center of the flag; the branches symbolize the hope for
peace and reconciliation between the Greek and Turkish communities; note -
the Turkish cypriot flag has a horizontal red stripe at the top and bottom
with a red crescent and red star on a white field
:Cyprus Economy
Overview:
The Greek Cypriot economy is small, diversified, and prosperous. Industry
contributes 24% to GDP and employs 35% of the labor force, while the service
sector contributes 44% to GDP and employs 45% of the labor force. Rapid
growth in exports of agricultural and manufactured products and in tourism
have played important roles in the average 6.4% rise in GDP between 1985 and
1990. In mid-1991, the World Bank "graduated" Cyprus off its list of
developing countries. In contrast to the bright picture in the south, the
Turkish Cypriot economy has less than half the per capita GDP and suffered a
series of reverses in 1991. Crippled by the effects of the Gulf war, the
collapse of the fruit-to-electronics conglomerate, Polly Peck, Ltd., and a
drought, the Turkish area in late 1991 asked for a multibillion-dollar grant
from Turkey to help ease the burden of the economic crisis. Turkey normally
underwrites a substantial portion of the TRNC economy.
GDP:
purchasing power equivalent - Greek area: $5.5 billion, per capita $9,600;
real growth rate 6.0%; Turkish area: $600 million, per capita $4,000; real
growth rate 5.9% (1990)
Inflation rate (consumer prices):
Greek area: 4.5%; Turkish area: 69.4% (1990)
Unemployment rate:
Greek area: 1.8%; Turkish area: 1.2% (1990)
Budget:
revenues $1.2 billion; expenditures $2.0 billion, including capital
expenditures of $250 million (1991)
Exports:
$847 million (f.o.b., 1990)
commodities:
citrus, potatoes, grapes, wine, cement, clothing and shoes
partners:
UK 23%, Greece 10%, Lebanon 10%, Germany 5%
Imports:
$2.3 billion (f.o.b., 1990)
commodities:
consumer goods, petroleum and lubricants, food and feed grains, machinery
partners:
UK 13%, Japan 12%, Italy 10%, Germany 9.1%
External debt:
$2.8 billion (1990)
Industrial production:
growth rate 5.6% (1990); accounts for 24% of GDP
Electricity:
620,000 kW capacity; 1,770 million kWh produced, 2,530 kWh per capita (1991)
Industries:
food, beverages, textiles, chemicals, metal products, tourism, wood products
Agriculture:
accounts for 7% of GDP and employs 14% of labor force in the south; major
crops - potatoes, vegetables, barley, grapes, olives, and citrus fruits;
vegetables and fruit provide 25% of export revenues
Economic aid:
US commitments, including Ex-Im (FY70-89), $292 million; Western (non-US)
countries, ODA and OOF bilateral commitments (1970-89), $250 million; OPEC
bilateral aid (1979-89), $62 million; Communist countries (1970-89), $24
million
Currency:
Cypriot pound (plural - pounds) and in Turkish area, Turkish lira (plural -
liras); 1 Cypriot pound (#C) = 100 cents and 1 Turkish lira (TL) = 100 kurus
:Cyprus Economy
Exchange rates:
Cypriot pounds (#C) per US$1 - 0.4683 (March 1992), 0.4615 (1991), 0.4572
(1990), 0.4933 (1989), 0.4663 (1988), 0.4807 (1987); in Turkish area,
Turkish liras (TL) per US$1 - 6,098.4 (March 1992), 4,173.9 (1991), 2,608.6
(1990), 2,121.7 (1989), 1,422.3 (1988), 857.2 (1987)
Fiscal year:
calendar year
:Cyprus Communications
Highways:
10,780 km total; 5,170 km paved; 5,610 km gravel, crushed stone, and earth
Ports:
Famagusta, Kyrenia, Larnaca, Limassol, Paphos
Merchant marine:
1,228 ships (1,000 GRT or over) totaling 20,053,213 GRT/35,647,964 DWT;
includes 8 short-sea passenger, 2 passenger-cargo, 440 cargo, 83
refrigerated cargo, 22 roll-on/roll-off, 52 container, 5 multifunction large
load carrier, 107 petroleum tanker, 3 specialized tanker, 3 liquefied gas,
20 chemical tanker, 32 combination ore/oil, 394 bulk, 3 vehicle carrier, 49
combination bulk, 2 railcar carrier, 2 passenger, 1 passenger cargo; note -
a flag of convenience registry; Cuba owns at least 30 of these ships,
republics of the former USSR own 58, Latvia also has 5 ships, Yugoslavia
owns 1, and Romania 3
Civil air:
11 major transport aircraft (Greek Cypriots); 2 (Turkish Cypriots)
Airports:
14 total, 14 usable; 12 with permanent-surface runways; none with runways
over 3,659 m; 7 with runways 2,440-3,659 m; 3 with runways 1,220-2,439 m
Telecommunications:
excellent in both the area controlled by the Cypriot Government (Greek
area), and in the Turkish-Cypriot administered area; 210,000 telephones;
largely open-wire and radio relay; broadcast stations - 11 AM, 8 FM, 1 (34
repeaters) TV in Greek sector and 2 AM, 6 FM and 1 TV in Turkish sector;
international service by tropospheric scatter, 3 submarine cables, and
satellite earth stations - 1 Atlantic Ocean INTELSAT, 1 Indian Ocean
INTELSAT and EUTELSAT earth stations
:Cyprus Defense Forces
Branches:
Greek area - Greek Cypriot National Guard (GCNG; including air and naval
elements), Greek Cypriot Police; Turkish area - Turkish Cypriot Security
Force
Manpower availability:
males 15-49, 183,899; 126,664 fit for military service; 5,030 reach military
age (18) annually
Defense expenditures:
exchange rate conversion - $209 million, 5% of GDP (1990 est.)
:Czechoslovakia Geography
Total area:
127,870 km2
Land area:
125,460 km2
Comparative area:
slightly larger than New York State
Land boundaries:
3,438 km; Austria 548 km, Germany 815 km, Hungary 676 km, Poland 1,309 km,
Ukraine 90 km
Coastline:
none - landlocked
Maritime claims:
none - landlocked
Disputes:
Gabcikovo Nagymaros Dam dispute with Hungary
Climate:
temperate; cool summers; cold, cloudy, humid winters
Terrain:
mixture of hills and mountains separated by plains and basins
Natural resources:
hard coal, timber, lignite, uranium, magnesite, iron ore, copper, zinc
Land use:
arable land 37%; permanent crops 1%; meadows and pastures 13%; forest and
woodland 36%; other 13%; includes irrigated 1%','06be87425ae31f56e3c0b8cdfbb6d5f8f43bdacaa2c0f95d9374c8c4cdbc3155','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9798f755c0f3edd349f85bdc24b6ea7de3a974dc9b4e727aa3e172e607dbe0',1992,'ZA','South Africa','government',61,'Legislative branch:
unicameral Diet (Landtag)
Judicial branch:
Supreme Court (Oberster Gerichtshof) for criminal cases and Superior Court
(Obergericht) for civil cases
Leaders:
Chief of State:
Prince Hans ADAM II (since 13 November 1989; assumed executive powers 26
August 1984); Heir Apparent Prince ALOIS von und zu Liechtenstein (born 11
June 1968)
Head of Government:
Hans BRUNHART (since 26 April 1978); Deputy Head of Government Dr. Herbert
WILLE (since 2 February 1986)
Political parties and leaders:
Fatherland Union (VU), Dr. Otto HASLER; Progressive Citizens'' Party (FBP),
Emanuel VOGT; Free Electoral List (FW)
Suffrage:
universal at age 18
Elections:
Diet:
last held on 5 March 1989 (next to be held by March 1993); results - percent
of vote by party NA; seats - (25 total) VU 13, FBP 12
Member of:
CE, CSCE, EBRD, IAEA, INTELSAT, INTERPOL, IOC, ITU, LORCS, UN, UNCTAD, UPU,
WIPO
Diplomatic representation:
in routine diplomatic matters, Liechtenstein is represented in the US by the
Swiss Embassy
US:
the US has no diplomatic or consular mission in Liechtenstein, but the US
Consul General at Zurich (Switzerland) has consular accreditation at Vaduz
Flag:
two equal horizontal bands of blue (top) and red with a gold crown on the
hoist side of the blue band
:Liechtenstein Economy
Overview:
The prosperous economy is based primarily on small-scale light industry and
tourism. Industry accounts for 53% of total employment, the service sector
45% (mostly based on tourism), and agriculture and forestry 2%. The sale of
postage stamps to collectors is estimated at $10 million annually. Low
business taxes (the maximum tax rate is 20%) and easy incorporation rules
have induced about 25,000 holding or so-called letter box companies to
establish nominal offices in Liechtenstein. Such companies, incorporated
solely for tax purposes, provide 30% of state revenues. The economy is tied
closely to that of Switzerland in a customs union, and incomes and living
standards parallel those of the more prosperous Swiss groups.
GDP:
purchasing power equivalent - $630 million, per capita $22,300; real growth
rate NA% (1990 est.)
Inflation rate (consumer prices):
5.4% (1990)
Unemployment rate:
1.5% (1990)
Budget:
revenues $259 million; expenditures $292 million, including capital
expenditures of NA (1990)
Exports:
$1.6 billion
commodities:
small specialty machinery, dental products, stamps, hardware, pottery
partners:
EFTA countries 20.9% (Switzerland 15.4%), EC countries 42.7%, other 36.4%
(1990)
Imports:
$NA
commodities:
machinery, metal goods, textiles, foodstuffs, motor vehicles
partners:
NA
External debt:
$NA
Industrial production:
growth rate NA%
Electricity:
23,000 kW capacity; 150 million kWh produced, 5,340 kWh per capita (1989)
Industries:
electronics, metal manufacturing, textiles, ceramics, pharmaceuticals, food
products, precision instruments, tourism
Agriculture:
livestock, vegetables, corn, wheat, potatoes, grapes
Economic aid:
none
Currency:
Swiss franc, franken, or franco (plural - francs, franken, or franchi); 1
Swiss franc, franken, or franco (SwF) = 100 centimes, rappen, or centesimi
Exchange rates:
Swiss francs, franken, or franchi (SwF) per US$1 - 1.5079 (March 1992),
1.4340 (1991), 1.3892 (1990), 1.6359 (1989), 1.4633 (1988), 1.4912 (1987)
Fiscal year:
calendar year
:Liechtenstein Communications
Railroads:
18.5 km 1.435-meter standard gauge, electrified; owned, operated, and
included in statistics of Austrian Federal Railways
Highways:
130.66 km main roads, 192.27 km byroads
Civil air:
no transport aircraft
Airports:
none
Telecommunications:
limited, but sufficient automatic telephone system; 25,400 telephones;
linked to Swiss networks by cable and radio relay for international
telephone, radio, and TV services
:Liechtenstein Defense Forces
Branches:
Police Department
Note:
defense is responsibility of Switzerland
:Lithuania Geography
Total area:
65,200 km2
Land area:
65,200 km2
Comparative area:
slightly larger than West Virginia
Land boundaries:
1,273 km; Belarus 502 km, Latvia 453 km, Poland 91 km, Russia (Kaliningrad)
227 km
Coastline:
108 km
Maritime claims:
Contiguous zone:
NA nm
Continental shelf:
NA meter depth
Exclusive fishing zone:
NA nm
Exclusive economic zone:
NA nm
Territorial sea:
NA nm
Disputes:
dispute with Russia (Kaliningrad Oblast) over the position of the Neman
River border presently located on the Lithuanian bank and not in midriver as
by international standards
Climate:
maritime; wet, moderate winters
Terrain:
lowland, many scattered small lakes, fertile soil
Natural resources:
peat
Land use:
49.1% arable land; NA% permanent crops; 22.2% meadows and pastures; 16.3%
forest and woodland; 12.4% other; includes NA% irrigated','85b3c1f93abb66126dcb7e4e0bc345f6b2a8e135c5ae9521a68b32b771705ca6','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e4615e2dbde9c7eb8d8c9ca14d9f4071cebd3417dd14157f8f140aad2ab8b6',1992,'SG','Singapore','government',88,'People''s Action Party (PAP), LEE Kuan Yew, secretary general;
opposition:
Workers'' Party (WP), J. B. JEYARETNAM; Singapore Democratic Party (SDP),
CHIAM See Tong; National Solidarity Party (NSP), leader NA; Barisan Sosialis
(BS, Socialist Front), leader NA
Suffrage:
universal and compulsory at age 20
Elections:
President:
last held 31 August 1989 (next to be held NA August 1993); results -
President WEE Kim Wee was reelected by Parliament without opposition
Parliament:
last held 31 August 1991 (next to be held 31 August 1996); results - percent
of vote by party NA; seats - (81 total) PAP 77, SDP 3, WP 1
Communists:
200-500; Barisan Sosialis infiltrated by Communists; note - Communist party
illegal
Member of:
APEC, AsDB, ASEAN, C, CCC, CP, ESCAP, G-77, GATT, IAEA, IBRD, ICAO, ICC,
ICFTU, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, ISO, ITU,
LORCS, NAM, UN, UNCTAD, UPU, WHO, WMO
Diplomatic representation:
Ambassador S. R. NATHAN; Chancery at 1824 R Street NW, Washington, DC 20009;
telephone (202) 667-7555
US:
Ambassador Robert D. ORR; Embassy at 30 Hill Street, Singapore 0617 (mailing
address is FPO AP 96534); telephone [65] 338-0251; FAX [65] 338-4550
:Singapore Government
Flag:
two equal horizontal bands of red (top) and white; near the hoist side of
the red band, there is a vertical, white crescent (closed portion is toward
the hoist side) partially enclosing five white five-pointed stars arranged
in a circle
:Singapore Economy
Overview:
Singapore has an open entrepreneurial economy with strong service and
manufacturing sectors and excellent international trading links derived from
its entrepot history. During the 1970s and early 1980s, the economy expanded
rapidly, achieving an average annual growth rate of 9%. Per capita GDP is
among the highest in Asia. The economy grew at a respectable 6.5% in 1991,
down from 8.3% in 1990, in part because of a slowdown in overseas demand and
lower growth in the financial and business services sector.
GDP:
exchange rate conversion - $38.3 billion, per capita $13,900; real growth
rate 6.5% (1991 est.)
Inflation rate (consumer prices):
3.4% (1991 est.)
Unemployment rate:
1.5% (1991 est.)
Budget:
revenues $9.8 billion; expenditures $9.0 billion, including capital
expenditures of $2.8 billion (FY91 est.)
Exports:
$57.8 billion (f.o.b., 1991 est.)
commodities:
includes transshipments to Malaysia - petroleum products, rubber,
electronics, manufactured goods
partners:
US 20%, Malaysia 15%, Japan 9%, Hong Kong 7%, Thailand 6%
Imports:
$65.8 billion (c.i.f., 1991 est.)
commodities:
includes transshipments from Malaysia - capital equipment, petroleum,
chemicals, manufactured goods, foodstuffs
partners:
Japan 21%, US 16%, Malaysia 15%, Taiwan 4%
External debt:
$3.8 billion (1991 est.)
Industrial production:
growth rate 9% (1991 est.); accounts for 29% of GDP (1990)
Electricity:
4,000,000 kW capacity; 14,400 million kWh produced, 5,300 kWh per capita
(1990)
Industries:
petroleum refining, electronics, oil drilling equipment, rubber processing
and rubber products, processed food and beverages, ship repair, entrepot
trade, financial services, biotechnology
Agriculture:
occupies a position of minor importance in the economy; self-sufficient in
poultry and eggs; must import much of other food; major crops - rubber,
copra, fruit, vegetables
Economic aid:
US commitments, including Ex-Im (FY70-83), $590 million; Western (non-US)
countries, ODA and OOF bilateral commitments (1970-89), $1.0 billion
Currency:
Singapore dollar (plural - dollars); 1 Singapore dollar (S$) = 100 cents
Exchange rates:
Singapore dollars (S$) per US$1 - 1.6596 (March 1992), 1.7276 (1991), 1.8125
(1990), 1.9503 (1989), 2.0124 (1988), 2.1060 (1987)
Fiscal year:
1 April - 31 March
:Singapore Communications
Railroads:
38 km of 1.000-meter gauge
Highways:
2,597 km total (1984)
Ports:
Merchant marine:
468 ships (1,000 GRT or over) totaling 8,751,619 GRT/14,195,718 DWT;
includes 1 passenger-cargo, 126 cargo, 74 container, 7 roll-on/roll-off
cargo, 5 refrigerated cargo, 18 vehicle carrier, 1 livestock carrier, 144
petroleum tanker, 5 chemical tanker, 4 combination ore/oil, 1 specialized
tanker, 5 liquefied gas, 74 bulk, 2 combination bulk, 1 short-sea passenger;
note - many Singapore flag ships are foreign owned
Civil air:
38 major transport aircraft (est.)
Airports:
10 total, 10 usable; 10 with permanent-surface runways; 2 with runways over
3,659 m; 4 with runways 2,440-3,659 m; 3 with runways 1,220-2,439 m
Telecommunications:
good domestic facilities; good international service; good radio and
television broadcast coverage; 1,110,000 telephones; broadcast stations - 13
AM, 4 FM, 2 TV; submarine cables extend to Malaysia (Sabah and peninsular
Malaysia), Indonesia, and the Philippines; satellite earth stations - 1
Indian Ocean INTELSAT and 1 Pacific Ocean INTELSAT
:Singapore Defense Forces
Branches:
Army, Navy, Air Force, People''s Defense Force, Police Force
Manpower availability:
males 15-49, 847,435; 626,914 fit for military service
Defense expenditures:
exchange rate conversion - $1.7 billion, 4% of GDP (1990 est.)
:Slovenia Geography
Total area:
20,296 km2
Land area:
20,296 km2
Comparative area:
slightly larger than New Jersey
Land boundaries:
998 km total; Austria 262 km, Croatia 455 km, Italy 199 km, Hungary 83 km
Coastline:
32 km
Maritime claims:
Contiguous zone:
NA nm
Continental shelf:
200 m or to depth of exploitation
Exclusive economic zone:
NA nm
Exclusive fishing zone:
NA nm
Territorial sea:
12 nm
Disputes:
dispute with Croatia over fishing rights in the Adriatic; small vocal
minority in northern Italy seeks the return of parts of southwestern','4507fa11c08516b35d43f3709275b683975cc503e8243bec75a599610ce8a5e3','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22fdbda6b9f8985664d480d2a15e2340ba30625247f3380cceddf51e1ff5209e',1992,'SI','Slovenia','government',89,'Climate:
Mediterranean climate on the coast, continental climate with mild to hot
summers and cold winters in the plateaus and valleys to the east
Terrain:
a short coastal strip on the Adriatic, an alpine mountain region adjacent to
Italy, mixed mountain and valleys with numerous rivers to the east
Natural resources:
lignite coal, lead, zinc, mercury, uranium, silver
Land use:
arable land 10%; permanent crops 2%; meadows and pastures 20%; forest and
woodland 45%; other 23%; includes irrigated 1%','7e954a7d65e6085452c7b2bbca61eedfb3997137cd214cbd30a7d52f010f561a','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

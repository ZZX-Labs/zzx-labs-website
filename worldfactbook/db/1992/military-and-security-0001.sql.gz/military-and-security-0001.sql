SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d1a3069eefae4eb5ef63e9d6c5b501696cdba1cd5d986042a9a7589d86c014c',1992,'NR','Nauru','military-and-security',41,'Capital:
Accra
Administrative divisions:
10 regions; Ashanti, Brong-Ahafo, Central, Eastern, Greater Accra, Northern,
Upper East, Upper West, Volta, Western
Independence:
6 March 1957 (from UK, formerly Gold Coast)
Constitution:
24 September 1979; suspended 31 December 1981
Legal system:
based on English common law and customary law; has not accepted compulsory
ICJ jurisdiction
National holiday:
Independence Day, 6 March (1957)
Executive branch:
chairman of the Provisional National Defense Council (PNDC), PNDC, Cabinet
Legislative branch:
unicameral National Assembly dissolved after 31 December 1981 coup, and
legislative powers were assumed by the Provisional National Defense Council
Judicial branch:
Supreme Court
Leaders:
Chief of State and Head of Government:
Chairman of the Provisional National Defense Council Flt. Lt. (Ret.) Jerry
John RAWLINGS (since 31 December 1981)
Political parties and leaders:
none; political parties outlawed after 31 December 1981 coup
Suffrage:
none
Elections:
no national elections; district assembly elections held in 1988-89
Member of:
ACP, AfDB, C, CCC, ECA, ECOWAS, FAO, G-24, G-77, GATT, IAEA, IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM (observer), ISO,
ITU, LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UNIFIL, UNIIMOG, UPU, WCL,
WHO, WIPO, WMO, WTO
Diplomatic representation:
Ambassador Dr. Joseph ABBEY; Chancery at 3512 International Drive NW,
Washington, DC 20008; telephone (202) 686-4520; there is a Ghanaian
Consulate General in New York
US:
Ambassador Raymond C. EWING; Embassy at Ring Road East, East of Danquah
Circle, Accra (mailing address is P. O. Box 194, Accra); telephone [233]
(21) 775348, 775349
Flag:
three equal horizontal bands of red (top), yellow, and green with a large
black five-pointed star centered in the gold band; uses the popular
pan-African colors of Ethiopia; similar to the flag of Bolivia, which has a
coat of arms centered in the yellow band
:Ghana Economy
Overview:
Supported by substantial international assistance, Ghana has been
implementing a steady economic rebuilding program since 1983, including
moves toward privatization and relaxation of government controls. Heavily
dependent on cocoa, gold, and timber exports, economic growth so far has not
spread substantially to other areas of the economy. The costs of sending
peacekeeping forces to Liberia and preparing for the transition to a
democratic government have been boosting government expenditures and
undercutting structural adjustment reforms. Ghana opened a stock exchange in
1990. Much of the economic improvement in 1991 was caused by favorable
weather (following a severe drought the previous year) that led to plentiful
harvests in Ghana''s agriculturally based economy.
GDP:
$6.2 billion; per capita $400; real growth rate 5% (1991 est.)
Inflation rate (consumer prices):
10% (1991 est.)
Unemployment rate:
10% (1991)
Budget:
revenues $821 million; expenditures $782 million, including capital
expenditures of $151 million (1990 est.)
Exports:
$843 million (f.o.b., 1991 est.)
commodities:
cocoa 45%, gold, timber, tuna, bauxite, and aluminum
partners:
US 23%, UK, other EC
Imports:
$1.2 billion (c.i.f., 1991 est.)
commodities:
petroleum 16%, consumer goods, foods, intermediate goods, capital equipment
partners:
US 10%, UK, FRG, France, Japan, South Korea, GDR
External debt:
$3.1 billion (1990 est.)
Industrial production:
growth rate 7.4% in manufacturing (1989); accounts for almost 1.5% of GDP
Electricity:
1,180,000 kW capacity; 4,140 million kWh produced, 265 kWh per capita (1991)
Industries:
mining, lumbering, light manufacturing, fishing, aluminum, food processing
Agriculture:
accounts for more than 50% of GDP (including fishing and forestry); the
major cash crop is cocoa; other principal crops - rice, coffee, cassava,
peanuts, corn, shea nuts, timber; normally self-sufficient in food
Illicit drugs:
illicit producer of cannabis for the international drug trade
Economic aid:
US commitments, including Ex-Im (FY70-89), $455 million; Western (non-US)
countries, ODA and OOF bilateral commitments (1970-89), $2.6 billion; OPEC
bilateral aid (1979-89), $78 million; Communist countries (1970-89), $106
million
Currency:
cedi (plural - cedis); 1 cedi (C) = 100 pesewas
Fiscal year:
calendar year
:Ghana Communications
Railroads:
953 km, all 1.067-meter gauge; 32 km double track; railroads undergoing
major renovation
Highways:
32,250 km total; 6,084 km concrete or bituminous surface, 26,166 km gravel,
laterite, and improved earth surfaces
Inland waterways:
Volta, Ankobra, and Tano Rivers provide 168 km of perennial navigation for
launches and lighters; Lake Volta provides 1,125 km of arterial and feeder
waterways
Pipelines:
none
Ports:
Tema, Takoradi
Merchant marine:
5 cargo and 1 refrigerated cargo (1,000 GRT or over) totaling 53,435
GRT/69,167 DWT
Civil air:
8 major transport aircraft
Airports:
10 total, 9 usable; 5 with permanent-surface runways; none with runways over
3,659 m; 1 with runways 2,440-3,659 m; 7 with runways 1,220-2,439 m
Telecommunications:
poor to fair system handled primarily by microwave links; 42,300 telephones;
broadcast stations - 4 AM, 1 FM, 4 (8 translators) TV; 1 Atlantic Ocean
INTELSAT earth station
:Ghana Defense Forces
Branches:
Army, Navy, Air Force, National Police Force, National Civil Defense
Manpower availability:
males 15-49, 3,661,558; 2,049,842 fit for military service; 170,742 reach
military age (18) annually
Defense expenditures:
exchange rate conversion - $30 million, less than 1% of GNP (1989 est.)
:Gibraltar Geography
Total area:
6.5 km2
Land area:
6.5 km2
Comparative area:
about 11 times the size of the Mall in Washington, DC
Land boundaries:
1.2 km; Spain 1.2 km
Coastline:
12 km
Maritime claims:
Exclusive fishing zone:
3 nm
Territorial sea:
3 nm
Disputes:
source of occasional friction between Spain and the UK
Climate:
Mediterranean with mild winters and warm summers
Terrain:
a narrow coastal lowland borders The Rock
Natural resources:
negligible
Land use:
arable land 0%; permanent crops 0%; meadows and pastures 0%; forest and
woodland 0%; other 100%','d23392b1802d1f5826153a0e8571086f88a72811c27bb7b8b1117f1e4818ae01','internet-archive','theciaworldfactb00048gut','txt','2996761138910345bbadbad393f23f9bc8a6e4b6d0f1d640fc86446b78f13a3b','https://archive.org/download/theciaworldfactb00048gut/48.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
